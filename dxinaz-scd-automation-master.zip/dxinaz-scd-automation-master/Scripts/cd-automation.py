import json
import sys, os
import requests

git_auth_token = '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'
git_hed = {'Authorization': 'Bearer ' + git_auth_token, 'Accept': 'application/vnd.github.v3+json'}
action_id = "113"
repo_url = "https://github.albertsons.com/api/v3/repos/albertsons/dxinaz-scd-automation/actions/workflows"
action_url = repo_url+"/"+str(action_id)+"/dispatches"
dict2 = {}
app_list = []
failed_deps = []
failed_hc = []
deploy_dict = {}
host = "dxinaz.dev.westus.aks.az.albertsons.com"

def get_action_id():
  workflow_id = ""
  response = requests.get(repo_url, headers=git_hed)
  workflow_data = response.json()
  workflows = workflow_data['workflows']
  print('workflows:', workflows)
  for each in workflows:
    print("Name: %s; id: %s"% (each['name'],each['id']))
  '''
    if 'deploy-nonprod' in (each['name']):
      workflow_id = each['id']
  '''
  return None

def execute_action_api(filename, brname, env):
  ## deploying applications
  dict_apps = check_version(filename, env)
  for key, value in dict_apps.items(): 
    data = {"ref":brname, "inputs": {"app_name":key,"image_tagid":value,"env_name":env}}
    app_name = key
    print('Triggering workflow...', data)
    print('action url is: ' + action_url)
    action_response = requests.post(action_url, json=data, headers=git_hed)
    print('The response', action_response.status_code)
    if action_response.status_code != 204:
      print('The execute action failed', app_name)
      failed_deps.append(app_name)
  return failed_deps

def check_version(filename, env):
  ## checking image version
  dict_tmp = {}
  namespace = 'dxinaz-' + env
  dict_version = create_dict2(filename)
  for key, value in dict_version.items():
     app_name = key
     new_ver = value
     print('FileData - %s:%s' % (app_name, new_ver))
     deployment = os.popen('kubectl get deployment -n %s | grep -i %s' % (namespace, app_name))
     deploy_string = deployment.read().split(' ')[0]
     print('deployment name available:', deploy_string)
     if not deploy_string:
       dict_tmp[app_name] = new_ver
     else:
       output = os.popen('kubectl describe deployment %s-deployment -n %s | grep -i image' % (app_name, namespace))
       output_string = output.read().strip('\n')
       version = output_string.split(':')[2]
       print('EnvData - Image version:', version)
       if dict_version[app_name] != version:
         print('The app:%s with version:%s is changed! - new version:%s' % (app_name, version, new_ver))
         dict_tmp[app_name] = new_ver
  deploy_dict = dict_tmp
  return deploy_dict

def check_app_health(filename):
  ## checking health_urls
  common = 'health/liveness'
  dict_health = create_dict2(filename)
  for app, hc in dict_health.items():
    path = hc; health_url = 'https://%s/%s/%s' % (host, path, common)
    print('web url:', health_url)
    health_res = requests.get(health_url)
    print('new data', health_res)
    res_data = health_res.text
    if "UP" in res_data:
      print('App %s status is UP' % app)
    else:
      print('App %s not running - pls check pods status' % app)
      failed_hc.append(app)
  if len(failed_hc) == 0:
    return "No Failed Healthchecks - All Good!"
  else:
    return failed_hc

def create_dict2(filename):
  with open(filename) as fh:
    for line in fh:
      if not line.startswith("#"):
        appname, hc = line.strip().split(None,1)
        dict2[appname] = hc.strip()
  return dict2

def main():
  ##main application 
  if len(sys.argv) == 1:
    print('no arguments passed')
    print('usage: python cd-automation.py <filename> <env> <branch_name>')
    sys.exit()

  if len(sys.argv) == 4:
    filename = sys.argv[1]
    envtarget  = sys.argv[2]
    brname = sys.argv[3]
    file_exists = os.path.exists(filename)
    if file_exists:
      file_type = filename.split('.')[1]
      if 'images' not in file_type:
        print('Provide filename with .images extention')
      else:
        print('App Images filename provided:', filename)
        execute_action_api(filename, brname, envtarget)

  if len(sys.argv) == 2:
    print('No Environment given')
    print('usage: python cd-automation.py <filename> <env> <branch_name>')
    sys.exit()

if __name__ == '__main__':
  main()


