#!/usr/bin/python
# Retrieve Pod Status - aalci00 - ongoing testing

import sys, os

app='dxinaz'

def podstatus(env):
  podstatus_cmd = 'kubectl get pods -n %s-%s' % (app, env)
  os.system(podstatus_cmd)

def main():

  if len(sys.argv) == 1:
    print('no arguments passed')
    sys.exit()

  if len(sys.argv) == 2:
    env = sys.argv[1]
    podstatus(env)

if __name__ == '__main__':
  main()
