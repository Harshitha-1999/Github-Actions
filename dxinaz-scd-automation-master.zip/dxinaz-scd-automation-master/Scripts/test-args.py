#!/usr/bin/python

import sys,os.path
import json

filename = sys.argv[1]
brname  = sys.argv[2]
dict1 = {}
fun_res = "execution completed!"
json_filename = "test1.json"

def create_json(filename):
  with open(filename) as fh:
    for line in fh:
      if not line.startswith("#"):
        appname, version = line.strip().split(None,1)
        dict1[appname] = version.strip()
  out_file = open(json_filename, "w")
  json.dump(dict1, out_file, indent = 2, sort_keys = False)
  out_file.close()
  return json_filename
  
def learn_multi_args(s, brname):
  return s, brname

def main():
  print(sys.argv)
  if len(sys.argv) != 3:
    print('usage: python test-args.py filename brname')
    sys.exit(1)
  filename = sys.argv[1]
  brname = sys.argv[2]
  file_exists = os.path.exists(filename)
  if file_exists:
    extention = filename.split('.')[1]
    print(extention)
  return None

if __name__ == '__main__':
  main()


