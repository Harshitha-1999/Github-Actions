#!/usr/bin/python

import os

my_list = ['dxinaz-auditor','dxinaz-exception'] 

for each_app in my_list:
  print('dxinaz app:', each_app)
  os.system('sh check-deploy-status.sh '+ each_app)
