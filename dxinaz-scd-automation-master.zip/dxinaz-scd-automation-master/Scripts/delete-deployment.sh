#!/bin/bash

namespace=dxinaz-$2
APPNAME=$1

if [ "$#" -ne 2 ]; then
  echo "Illegal number of parameters"
  exit 1
fi

echo "Checking AppName - $APPNAME in the $namespace."
RES=`kubectl get deployments -n $namespace | grep $APPNAME`
STATUS=$?
if [ $STATUS -eq 0 ]; then
  echo "RES: $RES"
  kubectl delete deployment $APPNAME-deployment -n $namespace
  sleep 3
  echo "Deployment Name:$APPNAME-deployment deleted"
else
  echo "Deployment Name:$APPNAME-deployment Not Found!"
fi

