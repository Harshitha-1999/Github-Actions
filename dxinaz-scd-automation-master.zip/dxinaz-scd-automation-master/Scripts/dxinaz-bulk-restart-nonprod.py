#!/usr/bin/python

import sys, os, time, subprocess

app='dxinaz'
delay=45
final_list = []

def restart_job(filename, env):
  namespace = app+'-'+env
  for line in final_list: 
    pod_name = collect_job(line, env)
    if len(pod_name):
      for pn in pod_name:
        pod_name_restart = pn
        restart_cmd = 'kubectl delete pod %s -n %s' % (pod_name_restart, namespace)
        print("\nRUNNING RESTART ON POD: " + pod_name_restart)
        print(restart_cmd)
        print('SLEEPING FOR %s SECONDS.' % (delay))
        print("NEXT")
    else:
      xline = line.rstrip("\n")
      print("Service " + xline + " is not running or incorrect. Skipping")

def collect_job(sline, env):
       pname_list = []
       print("\nProcessing Service: " + sline)
       namespace = app+'-'+env
       service_name = sline.rstrip("\n")
       collect_cmd = "kubectl get pod -n %s | grep -w %s | awk -F' ' '{print $1}'" % (namespace, service_name)
       rc = os.system(collect_cmd)
       #print(rc)
       if rc == 0:
         collect_out = subprocess.check_output(collect_cmd, shell=True).strip()
         #print(collect_cmd)
         #print("\nFrom command: ")
         #print(collect_out)
         for out in subprocess.check_output(collect_cmd, shell=True).split('\n'):
           if(len(out)): 
             pname_list.append(out)
         #print("\nFrom pname_list: ")
         #print(pname_list)
       return pname_list

def convert_file(filename):
  input_list = []
  with open(filename, "r") as input:      
    for svc in input:
      input_list.append(svc.lower())
  return input_list

def clean_list(input_list):
  for item in input_list:
    if item not in final_list:
      final_list.append(item) 
  return final_list


def main():
  
  if len(sys.argv) == 1:
    print('no arguments passed')
    sys.exit()

  if len(sys.argv) == 3:
    filename = sys.argv[1]
    envtarget  = sys.argv[2]
    file_exists = os.path.exists(filename)
    if file_exists:
      file_type = filename.split('.')[1]
      if 'images' not in file_type:
        print('Provide filename with .images extention')
      else:
        input = convert_file(filename)
        #print("BEFORE: " + str(input))
        final = clean_list(input) 
        #print("AFTER: " + str(final))
        restart_job(filename, envtarget)


if __name__ == '__main__':
  main()
