#!/usr/bin/python
######################## ONGOING TESTING -- AALCI00 #####################################

import sys, os, time, subprocess

app='dxinaz'
final_list = []

def collectLog(final_list, env):
  for line in final_list:
    service = line.rstrip("\n")
    log_cmd = 'kubectl logs %s -n %s-%s > %s-log.txt' % (service, app, env, service)
    print(log_cmd)
    os.system(log_cmd)
    mail_test = "echo \"test\" | mailx -s \"test\" aalci00@safeway.com"
    print(mail_test)
    os.system(mail_test)

def getpods(service, env):
  pod_list = []
  input = "kubectl get pods -n %s-%s --no-headers | awk -F\" \" '{print $1}' | grep -w %s-deployment" % (app, env, service)
  x = os.popen(input).read()
  pod_list = x.split('\n')
  final = clean_list(pod_list)
  if len(final):
    collectLog(final, env)
  else:
    print("Service not running or possibly incorrect")
    sys.exit()

def clean_list(input_list):
  for item in input_list:
    if item not in final_list:
      final_list.append(item)
  while("" in final_list):
    final_list.remove("")
  return final_list

def main():

  if len(sys.argv) == 1:
    print('no arguments passed')
    sys.exit()

  if len(sys.argv) == 3:
    service = sys.argv[1]
    env  = sys.argv[2]
    getpods(service, env)

if __name__ == '__main__':
  main()
