#!/usr/bin/python
##kubectl set image deployment/nginx-deployment nginx=nginx:1.16.1

import sys, os, time

dict1 = {}
appName = 'dxinaz'

def update_images(filename, env):
  namespace = appName+'-'+env
  dict2 = create_dict1(filename)
  for app, version in dict2.items():
    print('app: %s version: %s' % (app, version))
    deployment = 'deployment/'+app+'-deployment'
    update_cmd = 'kubectl set image %s %s=escoacrprod01.azurecr.io/dxinaz/%s:%s -n %s' % (deployment, app, app, version, namespace)
    print('update_cmd:', update_cmd)
    os.system(update_cmd)
    print('sleeping 60 sec')
    time.sleep(60)
    print('ok - Next')

  
def create_dict1(filename):
  with open(filename) as fh:
    for line in fh:
      if not line.startswith("#"):
        appname, hc = line.strip().split(None,1)
        dict1[appname] = hc.strip()
  return dict1

def main():
  ##main application 
  if len(sys.argv) == 1:
    print('no arguments passed')
    sys.exit()

  if len(sys.argv) == 2:
    envtarget  = sys.argv[1]
    ns = 'dxinaz-'+envtarget
    print('Lets do some test on %s' % ns)
    # Testing command
    test_cmd =('kubectl get svc -n %s' % ns)
    os.system(test_cmd)
    

  if len(sys.argv) == 3:
    print('Executing k8s image update!')
    filename = sys.argv[1]
    envtarget  = sys.argv[2]
    file_exists = os.path.exists(filename)
    if file_exists:
      file_type = filename.split('.')[1]
      if 'images' not in file_type:
        print('Provide filename with .images extention')
      else:
        print('App Images filename provided:', filename)
        update_images(filename, envtarget)


if __name__ == '__main__':
  main()
 
