#!/usr/bin/python
######################## ONGOING TESTING -- AALCI00 #####################################

import sys, os, time, subprocess

app='dxinaz'
final_list = []

def collectLog(final_list, env):
  for line in final_list:
    service = line
    log_cmd = 'kubectl logs %s -n %s-%s > %s-log.txt' % (service, app, env, service)
    print(log_cmd)
    os.system(log_cmd)

def getpods(clean, env):
  pod_list = [] 
  print("passed: " + str(clean))
  for line in clean:
    ms = line.rstrip("\n")
    input = "kubectl get pods -n %s-%s --no-headers | awk -F\" \" '{print $1}' | grep -w %s-deployment" % (app, env, ms)
    x = os.popen(input).read()
    pod_list.append(x)
  for line in pod_list:
    final_list.append(line.replace("\n", ""))
  print("pod list: "+ str(final_list))
  collectLog(final_list, env)

def clean_list(input_list):
  clean_list = []
  for item in input_list:
    if item not in clean_list:
      clean_list.append(item) 
  while("" in clean_list):
    clean_list.remove("")
  return clean_list

def convert_file(filename):
  input_list = []
  with open(filename, "r") as input:      
    for svc in input:
      input_list.append(svc.lower().strip())
  return input_list

def main():
  
  if len(sys.argv) == 1:
    print('no arguments passed')
    sys.exit()

  if len(sys.argv) == 3:
    filename = sys.argv[1]
    env = sys.argv[2]
    file_exists = os.path.exists(filename)
    file_empty = os.stat(filename).st_size
    if file_exists == 'True' or file_empty != '0':
      input = convert_file(filename)
      clean = clean_list(input)
      getpods(clean, env)
    else:
      print('File %s Not Found or Is Empty. Terminating' % (filename))

if __name__ == '__main__':
  main()
