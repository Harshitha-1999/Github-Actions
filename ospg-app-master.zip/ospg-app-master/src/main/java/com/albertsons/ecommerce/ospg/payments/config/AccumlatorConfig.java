package com.albertsons.ecommerce.ospg.payments.config;

import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.PaymentGatewayServiceHelper;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

import javax.net.ssl.SSLException;

//@Profile("!local")
@Configuration
public class AccumlatorConfig {
    @Value("${accumulator.url}")
    private String accumulatorUrl;
    @Autowired
    private PaymentGatewayServiceHelper helper;

    @Bean(name = "accumulatorClient")
    public WebClient accumulatorClient() throws SSLException {
        return getBuilder()
                .baseUrl(accumulatorUrl).filter(ExchangeFilterFunction.ofResponseProcessor(this::renderApiErrorResponse))
                .build();
    }

    protected WebClient.Builder getBuilder() throws SSLException {
        return WebClient.builder();
    }

    private Mono<ClientResponse> renderApiErrorResponse(ClientResponse clientResponse) {
        if (clientResponse.statusCode().isError()) {
            return clientResponse.bodyToMono(String.class)
                    .flatMap(apiErrorResponse -> Mono.error(new ResponseStatusException(
                            clientResponse.statusCode(),
                            apiErrorResponse
                    )));
        } else {
            return modifyResponse(clientResponse);
        }
    }

    private Mono<ClientResponse> modifyResponse(ClientResponse clientResponse) {

        Mono<TransactionResponse> tranResp = clientResponse.bodyToMono(TransactionResponse.class);
        Mono<TransactionResponse> cr = tranResp.flatMap(r -> {
            r.setAmount(PaymentUtil.convertDollarsToCents(r.getAmount()));
            return Mono.just(r);
        });

        return cr.flatMap(c -> {

            return Mono.just(ClientResponse
                    .create(clientResponse.statusCode())
                    .header("Content-Type", "application/json; charset=utf-8")
                    .body(helper.getJsonPayload(c)).build());
        });
    }
}
