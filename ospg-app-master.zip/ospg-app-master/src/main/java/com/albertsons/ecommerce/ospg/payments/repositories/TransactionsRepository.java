package com.albertsons.ecommerce.ospg.payments.repositories;

import com.albertsons.ecommerce.ospg.payments.entity.PurchaseTransactionDetails;
import com.albertsons.ecommerce.ospg.payments.entity.Transaction;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

@Repository
public interface TransactionsRepository extends ReactiveCrudRepository<Transaction, String> {

	@Query("select count(t.PROVIDER_TRANSACTION_ID) from [OSPGPAYTX].[TRANSACTION_TOKEN] "
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "where t.TRANSACTION_AMT = :transactionAmt and tt.ORDER_ID=:orderId and "
			+ "tt.STORE_ID=:storeId and tt.TOKEN_NBR=:tokenNbr and "
			+ "t.TRANSACTION_TYP_CD = 2 and "
			+ "t.TRANSACTION_STAT_TYP_CD = :transactionStatusNm ")
	public Mono<Integer> fetchRefundDuplicateTransaction(BigDecimal transactionAmt,
														 BigDecimal orderId, BigDecimal storeId,
														 String tokenNbr, String transactionStatusNm);
	
	@Query("select top 1 t.PROVIDER_TRANSACTION_ID,t.TRANSACTION_TAG_TXT from [OSPGPAYTX].[TRANSACTION_TOKEN] "
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "where  tt.ORDER_ID=:orderId and "
			+ "tt.STORE_ID=:storeId and tt.TOKEN_NBR=:tokenNbr and "
			+ "t.TRANSACTION_TYP_CD in (1,5) and "
			+ "t.TRANSACTION_STAT_TYP_CD = :transactionStatusNm ")
	public Mono<PurchaseTransactionDetails> fetchDuplicateTransactionPurchase(
			BigDecimal orderId, 
			BigDecimal storeId, 
			String tokenNbr, 
			//String transactionNm,
			String transactionStatusNm);

	@Query("select TOP 1 t.PROVIDER_TRANSACTION_ID from [OSPGPAYTX].[TRANSACTION_TOKEN] "
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "where t.transaction_typ_cd in (1,5) and "
			+ "tt.ORDER_ID=:orderId and "
			+ "tt.STORE_ID=:storeId ")
	public Mono<String> fetchProviderTransactionId(String orderId, String storeId);

	@Query("select TOP 1 tt.CARD_HOLDER_NM from [OSPGPAYTX].[TRANSACTION_TOKEN]"
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "inner join [OSPGPAYTX].[TRANSACTION_RESPONSE] as resp on "
			+ "tt.TRANSACTION_TOKEN_ID = resp.TRANSACTION_TOKEN_ID "
			+ "where tt.token_nbr=:tokenNbr and "
			+ "tt.store_Id=:storeId and "
			+ "t.transaction_typ_cd = 3 and "
			+ "resp.bank_response_cd='100' "
			+ "order by resp.LAST_UPDATE_TS desc")  // and ROWNUM=1
	public Mono<String> getCardHolderNameFromAuth(String tokenNbr, BigDecimal storeId);

	@Query("select top 1 CONCAT (t.PROVIDER_TRANSACTION_ID, '-',t.TRANSACTION_TAG_TXT )  "
			+ "from [OSPGPAYTX].[TRANSACTION_TOKEN] "
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "where tt.ORDER_ID=:orderId and "
			+ "tt.STORE_ID=:storeId and "
			+ "t.transaction_typ_cd = 3 ")
	public Mono<String> fetchProviderTransactionIdAndTag(BigDecimal orderId, BigDecimal storeId);
	
	@Query("select top 1 ct.card_nm from [OSPGPAYTX].[TRANSACTION_TOKEN] tt join [OSPGPAYTX].[CARD_TYP] ct "
			+ "on tt.card_typ_cd = ct.card_typ_cd where tt.store_id = :storeId and tt.token_nbr = :tokenNbr")
	public Mono<String> fetchCardType(String storeId, String tokenNbr);
	
	@Query("INSERT INTO[OSPGPAYTX].[TRANSACTION]([TRANSACTION_ID],"
			+ "[TRANSACTION_TOKEN_ID],[MERCH_REF_TYP_CD],"
			+ "[TRANSACTION_TYP_CD],[TRANSACTION_STAT_TYP_CD],"
			+ "[VALIDATION_STATUS_TYP_CD],[TRANSACTION_AMT],"
			+ "[PROVIDER_TRANSACTION_ID],[TRANSACTION_TAG_TXT],"
			+ "[CORRELATION_ID],[AVS_RESPONSE_CD],[TRANSACTION_START_TS],"
			+ "[TRANSACTION_END_TS],[CLIENT_IP_TXT],[LAST_UPDATE_USER_ID],"
			+ "[LAST_UPDATE_TS],[EXPIRY_TS], [SELLER_ID]) "
			+ " OUTPUT inserted.TRANSACTION_ID "
			+ "VALUES "
			+ "( (NEXT VALUE FOR [OSPGPAYTX].[TRANSACTION_ID_SEQ])"
			+ ",:ttId,:merchRefCd,:transTypCd,:transStatTypCd,"
			+ ":validationStatTypCd,:transAmt,:providerTransId,:transTagTxt,"
			+ ":correlationId,:avsRespCd,:transStartTS,:transEndTS,"
			+ ":clientIPText,:lastUpdateUID,:lastUpdateTS,:expTS, :sellerId)")
	public Mono<Long> saveTransactions(BigDecimal ttId,
			Long merchRefCd,
			Long transTypCd,
			Long transStatTypCd,
			Long validationStatTypCd,
			BigDecimal transAmt,
			String providerTransId,
			String transTagTxt,
			double correlationId,
			String avsRespCd,
			String transStartTS,
			String transEndTS,
			String clientIPText,
			String lastUpdateUID,
			String lastUpdateTS,
			String expTS, String sellerId);
	@Query("select a.* from [OSPGPAYTX].[TRANSACTION] a, "
			+ "[OSPGPAYTX].[TRANSACTION_TOKEN] b"
			+ " where 	a.TRANSACTION_TOKEN_ID = b.TRANSACTION_TOKEN_ID "
			+ " and b.store_id = :storeId "
			+ " and b.order_id = :orderId "
			+ " and b.token_nbr = :tokenNumber ")
	public Mono<Transaction> getTransactionById(BigDecimal tokenNumber, BigDecimal storeId, BigDecimal orderId);

}
