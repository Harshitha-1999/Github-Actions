package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import com.albertsons.ecommerce.ospg.payments.service.FacadeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.STORE_ID;

@RestController
public class FacadeController implements IFacadeController{

    @Autowired
    private FacadeService facadeService;

    @Loggable
    private SecurityLogger log;

    @Override
    public Mono<String> getPaymentToken(TenderDeclineRequest request,
                                        @RequestHeader(value = STORE_ID, required = false) String headerStoreId,
                                        @RequestParam(value = STORE_ID, required = false) String reqStoreId) throws Exception {
        log.info("getPaymentToken(): Request to get payment token. headerStoreId : {}, reqStoreId: {}", headerStoreId, reqStoreId);
        String storeId = headerStoreId != null ? headerStoreId : reqStoreId;
        return facadeService.getPaymentToken(request, storeId);
    }
}
