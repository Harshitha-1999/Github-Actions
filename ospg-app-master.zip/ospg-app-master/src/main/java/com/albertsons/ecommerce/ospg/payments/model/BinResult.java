package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.util.Optional;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = false)
public class BinResult {

    private Boolean ecomEBTCash;
    private Boolean ecomEBTSNAP;

    public Optional<Boolean> getEcomEBTCash() {
        return Optional.ofNullable(ecomEBTCash);
    }

    public Optional<Boolean> getEcomEBTSNAP() {
        return Optional.ofNullable(ecomEBTSNAP);
    }
}
