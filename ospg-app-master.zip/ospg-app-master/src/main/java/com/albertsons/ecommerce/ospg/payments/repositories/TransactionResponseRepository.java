package com.albertsons.ecommerce.ospg.payments.repositories;

import com.albertsons.ecommerce.ospg.payments.entity.TransactionResponseEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

public interface TransactionResponseRepository extends ReactiveCrudRepository<TransactionResponseEntity, Long> {

	
	@Query("INSERT INTO [OSPGPAYTX].[TRANSACTION_RESPONSE] "
			+ "([TRANSACTION_RESPONSE_ID],[TRANSACTION_ID],"
			+ "[TRANSACTION_TOKEN_ID],[ERROR_TYP_CD],"
			+ "[BANK_RESPONSE_CD],[BANK_RESPONSE_TXT],[GATEWAY_RESPONSE_CD],"
			+ "[GATEWAY_RESPONSE_TXT],[LAST_UPDATE_USER_ID],[LAST_UPDATE_TS],"
			+ "[EXPIRY_TS]) "
			+ "VALUES "
			+ "((NEXT VALUE FOR [OSPGPAYTX].[TRANSACTION_RESPONSE_ID_SEQ]),"
			+ ":transId,:transTokenId,"
			+ ":errorTypCd,:bankRespCd,:bankRespTxt,:gatewayRespCd,"
			+ ":gatewayRespTxt,:lastUpdateUserId,:lastUpdateTS,"
			+ ":expTS)")
	public Mono<Long> saveTransactionResponse(BigDecimal transId
			,BigDecimal transTokenId
			,String errorTypCd
			,String bankRespCd
			,String bankRespTxt
			,String gatewayRespCd
			,String gatewayRespTxt
			,String lastUpdateUserId
			,String lastUpdateTS
			,String expTS);
}
