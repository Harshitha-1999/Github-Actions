package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.exceptions.MerchantLookupException;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.CreditCardType;
import com.albertsons.ecommerce.ospg.payments.model.MerchRefTyp;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.util.TransactionCacheUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * @author MSUND21
 */

@Service
public class CommonService {

	@Autowired
	private TransactionsDAO dao;

	@Autowired
	TransactionCacheUtils cacheUtils;

	private boolean storedCredentialsForDiscoverEnabled = true;

	private boolean storedCredentialsEnabled = true;

	@Loggable
	private SecurityLogger log;

	public Mono<String> fetchCreditCardType(TransactionRequest transactionRequest) {

		String cardType = null;
		String ccType = transactionRequest.getToken().getTokenData().getType();

		Mono<String> mono;

		if (StringUtils.isBlank(ccType)) {
			mono = getCardType(transactionRequest);
		} else {
			cardType = CreditCardType.getValueByKey(ccType);
			log.debug("fetchCreditCardType() >> Card type: {}", cardType);
			mono = (cardType != null) ? Mono.just(cardType) : Mono.empty();
		}
		return mono;
	}

	private Mono<String> getCardType(TransactionRequest transactionRequest) {
		return dao.fetchCardType(transactionRequest).doOnSuccess(cardTyp -> {
			log.info("getCardType() >> Card Type: {}",cardTyp);
			transactionRequest.getToken().getTokenData().setType(cardTyp);
		});
	}

	public String getMerchRefId(String storeId, String sellerId) {

		MerchRefTyp val =  cacheUtils.getMerchRefType(storeId);
		if(val == null) {
			StringBuilder exceptionStr = new StringBuilder();
			exceptionStr.append(GatewayConstants.MERCHANT_LOOKUP_VALUE_FETCH_EXCEPTION)
					.append(storeId);
			log.error("getMerchRefId() >> error for store id: {} , error message: {}",storeId,exceptionStr.toString());
			throw new MerchantLookupException(exceptionStr.toString());
		}
		return StringUtils.isEmpty(sellerId) ? val.getMerchRefNm() : val.getMarketPlaceMid();
	}

	public String getMerchRefDsc(String storeId) {

		MerchRefTyp val =  cacheUtils.getMerchRefType(storeId);
		if(val == null) {
			StringBuilder exceptionStr = new StringBuilder();
			exceptionStr.append(GatewayConstants.MERCHANT_LOOKUP_VALUE_FETCH_EXCEPTION)
					.append(storeId);
			log.error("getMerchRefId() >> error for store id: {} , error message: {}",storeId,exceptionStr.toString());
			throw new MerchantLookupException(exceptionStr.toString());
		}
		return  val.getMerchRefDsc();
	}

	public boolean getFeatureFlagValue(String featureName){
		return cacheUtils.getFeatureFlagValue(featureName);
	}

	public boolean isChaseOrbitalUrlEnabled(String primaryChaseOrbital) {
		return cacheUtils.isChaseOrbitalUrlEnabled(primaryChaseOrbital);
	}
	public boolean isChaseOutageEnabled() {
		return cacheUtils.isChaseOutageEnabled();
	}

}
