package com.albertsons.ecommerce.ospg.payments.service;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.REFUND_RETRY_TRACE_CONSTANT;

import java.util.HashMap;

import com.albertsons.ecommerce.ospg.payments.external.FiservCaller;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.ResponseStatusException;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.exceptions.ChaseServerException;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.exceptions.RefundFailureExceptions;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.model.Card;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.PaymentInstrument;
import com.albertsons.ecommerce.ospg.payments.model.request.RefundReq;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ErrorResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.RefundResp;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;
import com.albertsons.ecommerce.ospg.payments.util.ResponseCodeUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;

/**
 * @author masood mohiuddin.
 */

@Service
public class RefundTransactionService implements IRefundTransactionService {

    @Value("${chase.refund.url}")
    private String refundUrl;

    @Autowired
    private ChaseCaller caller;

    @Autowired
    private FiservCaller fiservCaller;

    @Autowired
    private TransactionsDAO dao;

    @Autowired
    private CommonService commonService;

    @Autowired
    private PaymentGatewayServiceHelper serviceHelper;

    @Loggable
    private SecurityLogger log;

    static HashMap<String, String> cardTypeMap = new HashMap<>();
	static{
		
		cardTypeMap.put("Visa", "VI");
		cardTypeMap.put("MasterCard", "MC");
		cardTypeMap.put("American Express", "AM");
		cardTypeMap.put("Discover", "DI");
	}

    /**
     * This is new detailed version of webflux where we can play around with
     * request and response according to our need.
     *
     * @param req
     * @return Mono<RefundRes>
     */
    public Mono<TransactionResponse> refund(TransactionRequest req) {
        log.info("refund() >> Refund process initiated for order id : {} refund client request : {} ",req.getOrderId(),serviceHelper.getJsonPayload(req));

        Mono<TransactionResponse> res = 
        		dao.getPurchaseDetails(req)
                        .flatMap(result -> {
                            if (StringUtils.isBlank(result.getProviderTransactionId())) {
                                log.info("refund() >> no purchase txn found for order id: {}",req.getOrderId());
                            	req.getToken().getTokenData().setCvv(null);
                                return fiservCaller.refundCall(req)
                                        .bodyToMono(TransactionResponse.class)
                                        .onErrorResume(error -> {
                                            error.printStackTrace();
                                            return Mono.error(error);
                                        });
                            } else {
                                log.info("refund() >> tranrefNum: {}",result.getProviderTransactionId());
                                req.setTransactionId(result.getProviderTransactionId());
                                req.getToken().getTokenData().setCardholderName(result.getCardHolderName());
                                req.getToken().getTokenData().setType(cardTypeMap.get(result.getCardType()));
                                return makeChaseRefundCall(req);
                            }
                        });
        
        return res;
    }
    
    private Mono<TransactionResponse> makeChaseRefundCall(TransactionRequest req){
    	log.info("makeChaseRefundCall() >> calling chase refund");
    	Mono<TransactionResponse> refundResponse = caller.callChaseService(buildRefundRequest(req), req.getStoreId(), req.getSellerId(),refundUrl)
                .bodyToMono(RefundResp.class)
                .flatMap(resp -> {
                    return Mono.just(buildTransactionResponse(req, resp));
                })
                .onErrorResume(error -> {
                    log.error("makeChaseRefundCall() >> Refund failed with error response from Chase: {} for store id: {} , order id: {}", error.getMessage(), req.getStoreId(), req.getOrderId());
                    return handleRefundErrors(error);
                });
        return refundResponse.doOnSuccess(r -> {
            dao.saveSuccessTransaction(req, r);
        });
    }

    private Mono<? extends TransactionResponse> handleRefundErrors(Throwable error)  {
        if(error instanceof ResponseStatusException){
            throw new ChaseServerException("Refund failed with reason " + error.getMessage());
        }
        if(error instanceof RefundFailureExceptions){
            throw new RefundFailureExceptions(((RefundFailureExceptions) error).getErrorResponse());
        }
        if (error instanceof WebClientResponseException) {
            try {
                WebClientResponseException ex = (WebClientResponseException) error;
                log.error("handleRefundErrors() >> Resp Status : {}, Resp Status Mssg : {}", ex.getStatusCode(), ex.getMessage());
                ObjectMapper mapper = new ObjectMapper();
                ErrorResponse errorResponse = mapper.readValue(ex.getResponseBodyAsString(),
                        ErrorResponse.class);
                throw new DataValidationException(errorResponse.getProcStatus(), errorResponse.getProcStatusMessage());
            }catch (JsonProcessingException jsonProcessingException){
                return Mono.error(error);
            }
        }
        return Mono.error(error);
    }

    public Mono<TransactionResponse> subscriptionRefund(TransactionRequest req) {
        log.info("subscriptionRefund() >> Subscription Refund process initiated for order id : {} and client request : {} ",req.getOrderId(),serviceHelper.getJsonPayload(req));
        req.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        return this.refund(req);
    }

    private RefundReq buildRefundRequest(TransactionRequest transactionRequest) {
        RefundReq request = RefundReq.builder()
                .merchant(PaymentUtil.buildMerchant())
                .paymentInstrument(buildPaymentInstrument(transactionRequest))
                .order(buildOrder(transactionRequest, transactionRequest.getAmount()))
                .version(Constants.VERSION)
                .build();
        log.info("buildRefundRequest() >> chase refund request : {}",serviceHelper.getJsonPayload(request));
        return request;
    }

    private Order buildOrder(TransactionRequest transactionRequest, String amount) {
        Order order = Order.builder()
                .orderID(transactionRequest.getOrderId())
                .amount(PaymentUtil.convertDollarsToCents(amount))
                .industryType(Constants.INDUSTRY_TYPE)
                .retryTrace(PaymentUtil.buildRetryTrace(transactionRequest.getOrderId(),REFUND_RETRY_TRACE_CONSTANT))
                .build();

        //if (null == transactionRequest.getTransactionId()) {
            
                order = order.toBuilder()
                        .txRefNum(transactionRequest.getTransactionId())
                        .build();
        //}
        return order;
    }

    private PaymentInstrument buildPaymentInstrument(TransactionRequest req) {
        if (null == req.getToken()) return PaymentInstrument.builder().build();
        Card card = Card.builder()
//                .ccExp(req.getToken().getTokenData().getExpiryDate())
//                .ccAccountNum(req.getToken().getTokenData().getValue())
                .tokenTxnType(Constants.TOKEN_TXN_TYPE)
                .cardBrand(req.getToken().getTokenData().getType())
                .build();
        PaymentInstrument paymentInstrument = PaymentInstrument.builder()
                .card(card)
                .build();
        return paymentInstrument;
    }

    private TransactionResponse buildTransactionResponse(TransactionRequest req, RefundResp resp){
        log.info("buildTransactionResponse() >> refund response from Chase: {}",serviceHelper.getJsonPayload(resp));
        if(!checkResponseHasErrorCode(resp)){
            throw new RefundFailureExceptions(resp);
        }

        String transactionStatus = Constants.NOT_PROCESSED;
        if (resp.getOrder() != null) {
            transactionStatus = ResponseCodeUtil.getTransactionStatus(resp.getOrder().getStatus());
        }

        return TransactionResponse.builder()
                .isResponseError(Boolean.FALSE)
                .isResponseFault(Boolean.FALSE)
                .token(req.getToken())
                .transactionStatus(transactionStatus)
                .amount(req.getAmount())
                .currency(req.getCurrencyCode())
                .method(req.getMethod())
                .validationStatus(resp.getOrder().getStatus().getProcStatus()
                        .equalsIgnoreCase(Constants.PROC_STATUS_CODE)
                        ? Constants.SUCCESS : Constants.FAILED)
                .transactionTag(resp.getOrder().getStatus().getAuthorizationCode())
                .transactionType(req.getTransactionType())
                .transactionId(resp.getOrder().getTxRefNum())
                .bankRespCode(resp.getOrder().getStatus().getHostRespCode())
                .bankMessage(resp.getOrder().getStatus().getProcStatusMessage())
                .gatewayRespCode(resp.getOrder().getStatus().getRespCode())
                .build();
    }

    private boolean checkResponseHasErrorCode(RefundResp resp) {
        return resp != null &&
                resp.getOrder() != null &&
                resp.getOrder().getStatus() != null &&
                resp.getOrder().getStatus().getApprovalStatus() != null;
    }
}
