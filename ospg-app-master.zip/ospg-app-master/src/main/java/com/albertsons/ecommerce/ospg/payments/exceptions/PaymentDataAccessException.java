package com.albertsons.ecommerce.ospg.payments.exceptions;

public class PaymentDataAccessException extends RuntimeException{

	private static final long serialVersionUID = 7210533956864048027L;

	public PaymentDataAccessException(String message) {
		super(message);
	}

	public PaymentDataAccessException(Throwable th) {
		super(th);
	}

	public PaymentDataAccessException(String message, Throwable th) {
		super(message, th);
	}
}
