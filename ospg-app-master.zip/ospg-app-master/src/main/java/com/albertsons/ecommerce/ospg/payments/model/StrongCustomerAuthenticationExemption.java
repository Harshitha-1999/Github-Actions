package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StrongCustomerAuthenticationExemption {
    private String scaTrustedMerchant;
    private String scaSecureCorporatePayment;
    private String scaTransactionRiskAnalysis;
    private String scaLowValuePayment;
    private String scaMerchantInitiatedTransaction;
    private String scaRecurringPayment;
    private String scaDelegation;
}
