package com.albertsons.ecommerce.ospg.payments.model;

import com.albertsons.ecommerce.ospg.payments.dao.BaseHeaderDto;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.validation.constraints.NotBlank;
import java.util.Optional;

@Data
@NoArgsConstructor
@FieldDefaults(makeFinal = false, level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper=false)
public class GetTendersResponseHeader extends BaseHeaderDto {

    @NotBlank
    String customerId;

    @Override
    public Optional<String> getCustomerId() {
        return Optional.ofNullable( customerId );
    }


}
