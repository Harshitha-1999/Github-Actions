package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@NoArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Debit implements Serializable {
    private String pin;
    private String pinKeySerialNumber;
    private String debitPinCashBack;
    private String pinlessDebitTxnType;
    private String pinlessDebitMerchantUrl;
    private String debitBillerReferenceNumber;
    private String debitPinSurchargeAmount;
    private String debitPinTraceNumber;
    private String debitPinNetworkID;
    private String pinlessDebitTotalShpmnt;
    private String debitRoutingNetwork;
}
