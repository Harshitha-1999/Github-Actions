package com.albertsons.ecommerce.ospg.payments.exceptions;

import com.albertsons.ecommerce.ospg.payments.model.response.PreauthResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class PreAuthFailureException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private PreauthResponse errorResponse;

}
