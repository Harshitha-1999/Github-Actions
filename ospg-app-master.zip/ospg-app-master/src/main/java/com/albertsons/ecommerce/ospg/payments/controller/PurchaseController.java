package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.PurchaseTransactionService;
import com.albertsons.ecommerce.ospg.payments.validation.OnPurchase;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
public class PurchaseController implements IPurchaseController {

	@Autowired
	private PurchaseTransactionService service;

	@Override
    public Mono<TransactionResponse> purchaseTransaction(@Validated({OnPurchase.class})TransactionRequest transactionRequest) {
        log.info("PurchaseController >> purchaseTransaction >> Transaction: ");
        //validateTransactionType(transactionRequest);
        return service.purchase(transactionRequest);
    }

    private void validateTransactionType(TransactionRequest request) {
        if (!request.getTransactionType().equalsIgnoreCase(TransactionType.PURCHASE.name())) {
            throw new DataValidationException(ValidationErrorCode.TRANSACTION_TYPE.getCode(),
                    ValidationErrorCode.TRANSACTION_TYPE.getMessage());
        }
    }
}
