package com.albertsons.ecommerce.ospg.payments.config;

import com.albertsons.ecommerce.ospg.payments.converter.AuthDetailsConverter;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.properties.DbProperties;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.pool.ConnectionPoolConfiguration;
import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import com.albertsons.ecommerce.ospg.payments.converter.PurchaseTxnDetailsConverter;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableR2dbcRepositories
public class DBConfig extends AbstractR2dbcConfiguration {

	@Autowired
	protected DbProperties properties;

	@Value("${poolInitialSize:10}")
	private int poolInitialSize;

	@Value("${poolMaxSize:20}")
	private int poolMaxSize;

	@Value("${maxIdleTime:60}")
	private int maxIdleTime;

	@Loggable
	private SecurityLogger log;

	@Bean
	@Override
	public ConnectionFactory connectionFactory() {
		log.info("connectionFactory() >> Connecting to database '{}'...", "localhost");
			ConnectionFactory connectionFactory = ConnectionFactories.get(ConnectionFactoryOptions.builder()
					.option(ConnectionFactoryOptions.DRIVER, "mssql")
					.option(ConnectionFactoryOptions.HOST, properties.getHost())
					.option(ConnectionFactoryOptions.USER, properties.getUser())
					.option(ConnectionFactoryOptions.PASSWORD, properties.getPassword())
					.option(ConnectionFactoryOptions.PORT, 1433)
					.option(ConnectionFactoryOptions.DATABASE, properties.getName())
					.build());
			log.info("poolInitialSize = "+poolInitialSize+ " poolMaxSize= "+poolMaxSize+" maxIdleTime= "+maxIdleTime);
		ConnectionPoolConfiguration configuration = ConnectionPoolConfiguration.builder(connectionFactory)
					.initialSize(poolInitialSize)
					.maxSize(poolMaxSize)
					.maxIdleTime(Duration.ofMinutes(maxIdleTime)) //1 hr
					.build();
		return new ConnectionPool(configuration);
	}

	@Override
	protected List<Object> getCustomConverters() {

		List<Object> converterList = new ArrayList<>();
		converterList.add(new AuthDetailsConverter());
		converterList.add(new PurchaseTxnDetailsConverter());
		return converterList;
	}

}
