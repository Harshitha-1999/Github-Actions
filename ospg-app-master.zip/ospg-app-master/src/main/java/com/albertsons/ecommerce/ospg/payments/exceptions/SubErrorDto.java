package com.albertsons.ecommerce.ospg.payments.exceptions;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.util.Optional;

@Data
@NoArgsConstructor
@FieldDefaults(makeFinal = false, level = AccessLevel.PRIVATE)
public class SubErrorDto {

    String object;
    String field;
    String rejectedValue;
    String message;

    public Optional<String> getObject() {
        return Optional.ofNullable(object);
    }

    public Optional<String> getField() {
        return Optional.ofNullable(field);
    }

    public Optional<String> getRejectedValue() {
        return Optional.ofNullable(rejectedValue);
    }

    public Optional<String> getMessage() {
        return Optional.ofNullable(message);
    }
}
