package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import reactor.core.publisher.Mono;

@RequestMapping(value = "/transaction")
public interface IRefundTransactions {

    @PostMapping(value = "/refund")
    Mono<ResponseEntity<TransactionResponse>> refund(@RequestBody TransactionRequest refReq);

    @PostMapping(value = "/subscription-refund")
    Mono<ResponseEntity<TransactionResponse>> subscriptionRefund(@RequestBody TransactionRequest refReq);
}
