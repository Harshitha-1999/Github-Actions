package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Status implements Serializable {
    private String procStatus;
    private String procStatusMessage;
    private String hostRespCode;
    private String actualRespCd;
    private String respCode;
    private String respCodeMessage;
    private String approvalStatus;
    private String authorizationCode;
    private String partialAuthOccurred;
    private String visaVbVRespCode;
    private String mcRecurringAdvCode;
    private String countryFraudFilterStatus;
    private String autoAuthProcStatus;
    private String autoAuthStatusMsg;
    private String autoAuthApprovalStatus;
    private String autoAuthResponseCodes;
    private String pymtBrandAuthResponseCode;
    private String pymtBrandResponseCodeCategory;
}
