package com.albertsons.ecommerce.ospg.payments.model.response;

import com.albertsons.ecommerce.ospg.payments.model.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class CaptureResp {
    private String version;
    private String transType;
    private Merchant merchant;
    private PaymentInstrument paymentInstrument;
    private Order order;
    private String procStatus;
    private String procStatusMessage;
}
