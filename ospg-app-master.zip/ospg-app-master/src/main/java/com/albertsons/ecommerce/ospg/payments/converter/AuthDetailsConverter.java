package com.albertsons.ecommerce.ospg.payments.converter;

import java.math.BigDecimal;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

import com.albertsons.ecommerce.ospg.payments.entity.AuthDetails;

import io.r2dbc.spi.Row;

@ReadingConverter
public class AuthDetailsConverter implements Converter<Row, AuthDetails> {

	@Override
	public AuthDetails convert(Row row){
		
		AuthDetails details = new AuthDetails();
		details.setTransactionTag(row.get("TRANSACTION_TAG_TXT", String.class));
		details.setProviderTransactionId(row.get("PROVIDER_TRANSACTION_ID", String.class));
		details.setAmount(row.get("TRANSACTION_AMT", BigDecimal.class));
		details.setCardHolderName(row.get("CARD_HOLDER_NM", String.class));
		details.setCardType(row.get("CARD_NM", String.class));
		details.setMitReceivedTransactionId(row.get("MIT_RECEIVED_TRANSACTION_ID", String.class));
		return details;
	}
}
