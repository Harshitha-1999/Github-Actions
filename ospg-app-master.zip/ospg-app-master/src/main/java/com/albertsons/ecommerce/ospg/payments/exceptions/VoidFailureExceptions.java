package com.albertsons.ecommerce.ospg.payments.exceptions;

import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Setter
@Getter
@AllArgsConstructor
public class VoidFailureExceptions extends RuntimeException{

	private static final long serialVersionUID = 1L;
	private HttpStatus status;
	private TransactionResponse errorResponse;

	public VoidFailureExceptions(TransactionResponse errorResponse) {
		this.errorResponse = errorResponse;
	}
}
