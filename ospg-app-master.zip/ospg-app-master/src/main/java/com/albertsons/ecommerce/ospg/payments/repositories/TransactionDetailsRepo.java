package com.albertsons.ecommerce.ospg.payments.repositories;
import com.albertsons.ecommerce.ospg.payments.entity.TransactionDetails;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface TransactionDetailsRepo extends R2dbcRepository<TransactionDetails, String> {

    @Query("SELECT TOP 1 MIT_RECEIVED_TRANSACTION_ID FROM [OSPGPAYTX].[TRANSACTION_TOKEN]  "
            + "WHERE "
            + "TOKEN_NBR=:tokenNbr AND "
            + "STORE_ID=:storeId AND "
            + "ORDER_ID=:orderId ")
    public Mono<TransactionDetails> fetchMitReceivedTranId(String tokenNbr, String storeId, String orderId);

    @Query("SELECT TOP 1 MIT_RECEIVED_TRANSACTION_ID FROM [OSPGPAYTX].[TRANSACTION_TOKEN]  "
            + "WHERE "
            + "TOKEN_NBR=:tokenNbr AND "
            + "MIT_RECEIVED_TRANSACTION_ID IS NOT NULL "
            + "order by last_update_ts desc"
    )
    public Mono<TransactionDetails> fetchMitReceivedTranId(String tokenNbr);

}
