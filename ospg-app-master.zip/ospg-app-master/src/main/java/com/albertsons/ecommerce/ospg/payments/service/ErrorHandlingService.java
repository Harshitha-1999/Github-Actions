package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.enumerations.OSPGTransactionCategory;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.exceptions.PaymentDataAccessException;
import com.albertsons.ecommerce.ospg.payments.exceptions.PaymentProviderDownException;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.FailedTransaction;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ErrorResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;
import com.albertsons.ecommerce.ospg.payments.util.TransactionCacheUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.ssl.SslHandshakeTimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.PrematureCloseException;

import java.util.List;
import java.util.function.Function;

@Service
public class ErrorHandlingService {

    @Autowired
    @Qualifier("accumulatorClient")
    private WebClient accumulatorClient;

    @Value("${accumulator.ospg.basePath}")
    private String accumulatorOspgBaseURL;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private TransactionCacheUtils cacheUtils;

    @Loggable
    private SecurityLogger log;

    public Mono<TransactionResponse> invokeSaveToAccumulator(OSPGTransactionCategory transactionCategory, TransactionRequest transactionRequest, TransactionResponse dummyResponse, Throwable fde) {

        log.info("invokeSaveToAccumulator() >> started");
        return invokeSaveToAccumulatorCore(transactionCategory, transactionRequest, fde, error -> {
            log.error("invokeSaveToAccumulator() >> error message: {}",error.getMessage());
            if (fde != null) {
                return Mono.error(fde);
            } else {
                return Mono.error(error);
            }
        }).flatMap(o -> {
            log.info("invokeSaveToAccumulator() >> returning dummy resp for order id: {}", o.getOrderId());
            return Mono.just(dummyResponse);
        });
    }

    private Mono<FailedTransaction> invokeSaveToAccumulatorCore(
            OSPGTransactionCategory transactionCategory,
            TransactionRequest transactionRequest, Throwable fde,
            Function<? super Throwable, ? extends Mono<? extends FailedTransaction>> fallback) {

        StringBuilder ospgCompleteURL = new StringBuilder(accumulatorOspgBaseURL);
        ospgCompleteURL.append(transactionCategory.getUrl());

        transactionRequest.setSource("RP-OSPG_" + transactionRequest.getSource());
        FailedTransaction failedTransaction = new FailedTransaction();
        failedTransaction.setGenericId(transactionRequest.getOrderId());
        failedTransaction.setType(transactionCategory.getKey());
        failedTransaction.setUrl(ospgCompleteURL.toString());
        failedTransaction.setRequest(transactionRequest);
        addExceptionDetails(fde, failedTransaction);

        log.info("invokeSaveToAccumulatorCore() >> sending failed records to accumulator, order id : {} ",transactionRequest.getOrderId());
        Mono<FailedTransaction> mono = accumulatorClient.post()
                .body(Mono.just(failedTransaction), FailedTransaction.class)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, clientResponse -> handle4XXError(clientResponse))
                .onStatus(HttpStatus::is5xxServerError, clientResponse -> handle5XXError(clientResponse))
                .bodyToMono(FailedTransaction.class)
                .onErrorResume(fallback);

        return mono;
    }

    private Mono<? extends Throwable> handle4XXError(ClientResponse clientResponse) {
        log.error("handle4XXError() >> Handling 4XX error");
        Mono<String> errorMssg = clientResponse.bodyToMono(String.class);
        return errorMssg.flatMap((message) -> {
            log.error("handle4XXError() >> error message: {}",message);
            throw new PaymentDataAccessException(message);
        });
    }

    private Mono<? extends Throwable> handle5XXError(ClientResponse clientResponse) {
        log.error("Handling 5XX error");
        Mono<String> errorMssg = clientResponse.bodyToMono(String.class);
        return errorMssg.flatMap((message) -> {
            log.error("handle5XXError() >> error message: {}",message);
            throw new PaymentDataAccessException(message);
        });
    }

    private void addExceptionDetails(Throwable fde, FailedTransaction failedTransaction) {
        if (fde == null) {
            return;
        }
        if (fde instanceof HttpStatusCodeException) {
            HttpStatusCodeException httpStatusCodeException = (HttpStatusCodeException) fde;
            failedTransaction.setOutageResponseCode(httpStatusCodeException.getStatusCode().value());
            try {
                failedTransaction.setOutageResponseBody(objectMapper.readValue(httpStatusCodeException.getResponseBodyAsByteArray(), Object.class));
            } catch (Exception ex) {
                failedTransaction.setOutageResponseBody(httpStatusCodeException.getResponseBodyAsString());
            }
        }
        failedTransaction.setOutageMessage(fde.getMessage());

    }

    public TransactionResponse getDummyAuthResponse() {

        TransactionResponse response = new TransactionResponse();
        response.setFailureCount(0);
        response.setTransactionStatus("approved");
        response.setValidationStatus("success");
        response.setTransactionType("authorize");
        response.setTransactionId("FDOWN99999");
        response.setTransactionTag("9999999999");
        response.setGatewayRespCode("00");
        response.setGatewayMessage("TransactionNormal");
        response.setCorrelationId("999.9999999999999");
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("isSuccess", "false");

        return response;
    }

    public TransactionResponse getDummyVoidResponse() {
        TransactionResponse response = new TransactionResponse();
        response.setTransactionStatus(Constants.APPROVED);
        response.setValidationStatus(Constants.SUCCESS);
        response.setTransactionType(Constants.VOID);
        response.setTransactionId(Constants.DUMMY_TRANSACTION_ID);
        response.setTransactionTag(Constants.DUMMY_TRANSACTION_TAG);
        response.setGatewayRespCode(Constants.SUCCESS_RESP_CODE);
        response.setGatewayMessage(Constants.DUMMY_GATEWAY_MESSAGE);
        response.setCorrelationId(Constants.DUMMY_CORRELATION_ID);
        return response;
    }

    public Mono<TransactionResponse> sendAuthFailureToAccumulator(TransactionRequest request,
                                                                  OSPGTransactionCategory ospgTransactionCategory,TransactionResponse dummyResponse, Throwable error) {
        log.info("sendAuthFailureToAccumulator() >> request from accumulator: {}",request.isAccumulatorRequest());
        if(!request.isAccumulatorRequest()) {
            return invokeSaveToAccumulator(
                    ospgTransactionCategory, request, dummyResponse, error);
        }else {
            return Mono.just(dummyResponse);
        }
    }

    Mono<TransactionResponse> handlePurchaseErrors(Throwable error, TransactionRequest request) {

        log.error("handlePurchaseErrors() >> Purchase failed with error response from Chase: {} for store id: {} , order id: {}", error.getMessage(), request.getStoreId(), request.getOrderId());
        OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.PURCHASE;
        if (error instanceof ResponseStatusException) {
            ResponseStatusException responseStatusException = (ResponseStatusException) error;
            List<String> procStatusList= cacheUtils.getProcStatusCode(GatewayConstants.PROC_STATUS_CODE);
            if (PaymentUtil.isChaseDownProcStatuses(procStatusList,responseStatusException,request) || responseStatusException.getStatus() != HttpStatus.BAD_REQUEST) {
                log.error("handlePurchaseErrors() >> error for order id: "+request.getOrderId()+" , error status message: "+responseStatusException.getStatus().toString()+" , error: ", error);
                throw new PaymentProviderDownException(responseStatusException.getMessage(), responseStatusException);
            } else {
                if (!org.springframework.util.StringUtils.isEmpty(request.getGuid())) {
                    log.error("handlePurchaseErrors() >> error for store id: {} , order id: {} , error message: {}", request.getStoreId(), request.getOrderId(), responseStatusException.getMessage());
                }
                return Mono.error(error);
            }
        }
        if (error instanceof PrematureCloseException) {
            PrematureCloseException prematureCloseException = (PrematureCloseException) error;
            log.error("handlePurchaseErrors() >> error for order id: "+request.getOrderId()+" , error status message: "+prematureCloseException.getMessage()+" , error: ", error);
            throw new PaymentProviderDownException(prematureCloseException.getMessage(), prematureCloseException);
        }
        if (error instanceof SslHandshakeTimeoutException) {
            SslHandshakeTimeoutException sslException = (SslHandshakeTimeoutException) error;
            log.error("handlePurchaseErrors() >> error for order id: "+request.getOrderId()+" , error status message: "+sslException.getMessage()+" , error: ", error);
            throw new PaymentProviderDownException(sslException.getMessage(), sslException);
        }
        if (error instanceof WebClientResponseException) {
            try {
                WebClientResponseException webClientResponseException = (WebClientResponseException) error;
                log.error("Resp Status : {}, Resp Status Mssg : {}", webClientResponseException.getStatusCode(), error.getMessage());

                if (webClientResponseException.getStatusCode() != HttpStatus.BAD_REQUEST) {
                    log.info("Error Code : {}", webClientResponseException.getStatusCode());
                    throw new PaymentProviderDownException(webClientResponseException.getMessage(), webClientResponseException);
                }
                ObjectMapper mapper = new ObjectMapper();
                ErrorResponse errorResponse = mapper.readValue(webClientResponseException.getResponseBodyAsString(),
                        ErrorResponse.class);
                throw new DataValidationException(errorResponse.getProcStatus(), errorResponse.getProcStatusMessage());
            } catch (JsonProcessingException jsonProcessingException) {
                return Mono.error(error);
            }
        }
        return Mono.error(error);
    }
}
