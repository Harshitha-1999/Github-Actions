package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EarlyWarningSystem implements Serializable {
    private String ewsFirstName;
    private String ewsMiddleName;
    private String ewsLastName;
    private String ewsBusinessName;
    private String ewsAddressLine1;
    private String ewsAddressLine2;
    private String ewsCity;
    private String ewsState;
    private String ewsZip;
    private String ewsPhoneType;
    private String ewsPhoneNumber;
    private String ewsCheckSerialNumber;
    private String ewsSSNTIN;
    private String ewsDOB;
    private String ewsIDType;
    private String ewsIDNumber;
    private String ewsIDState;
    private String ewsAccountStatusCode;
    private String ewsAOAConditionCode;
    private String ewsNameMatch;
    private String ewsFirstNameMatch;
    private String ewsMiddleNameMatch;
    private String ewsLastNameMatch;
    private String ewsBusinessNameMatch;
    private String ewsAddressMatch;
    private String ewsCityMatch;
    private String ewsStateMatch;
    private String ewsZipMatch;
    private String ewsPhoneMatch;
    private String ewsSSNTINMatch;
    private String ewsDOBMatch;
    private String ewsIDTypeMatch;
    private String ewsIDNumberMatch;
    private String ewsIDStateMatch;
    private String avConsumerAccountDate;
}
