package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionCacheLoaderDao;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.MerchRefTyp;
import com.github.benmanes.caffeine.cache.AsyncCacheLoader;
import com.github.benmanes.caffeine.cache.AsyncLoadingCache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Component
public class TransactionCacheUtils {

    @Autowired
    CacheManager cacheManager;

    @Autowired
    TransactionCacheLoaderDao transactionCacheLoaderDao;

    @Loggable
    private SecurityLogger log;

    private AsyncLoadingCache merchRefTypCache = merchCache();

    /**
     * This method will return the merchant RefId
     * @param key
     * @return MerchRefTyp
     */
    public MerchRefTyp getMerchRefType(String key) {
        Cache.ValueWrapper valueWrapper = null;
        try {
            Long longKey = Long.parseLong(key);
            valueWrapper = cacheManager.getCache(GatewayConstants.MERCH_REF_TYP_CACHE).get(longKey);
        } catch (NumberFormatException nfe) {
            log.error("getMerchRefType() >> error for store id: {}",key);
            return null;
        }
        return valueWrapper != null ? (MerchRefTyp) valueWrapper.get() : null;
    }

    public Boolean getFullAuthStore(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.FULL_AUTH_STORE_CACHE).get(key);
        if (valueWrapper == null || String.valueOf(valueWrapper.get()).equals("false")){
            return false;
        }

        return true;
    }

    public Boolean getStoredCredStore(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.STORED_CRED_STORE_CACHE).get(key);
        if (valueWrapper == null) return null;
        return Boolean.valueOf(String.valueOf(valueWrapper.get()));
    }

    public Long getCardTyp(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.CARD_TYP_CACHE).get(key);
        if (valueWrapper == null) return null;
        return ((BigDecimal)valueWrapper.get()).longValue();
    }

    public Long getErrorTyp(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.ERROR_TYP_CACHE).get(key);
        if (valueWrapper == null) return null;
        return ((BigDecimal)valueWrapper.get()).longValue();
    }
    public List<String> getProcStatusCode(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.PROC_STATUS_CODE).get(key);
        if (valueWrapper == null) return null;
        return (List<String>) valueWrapper.get();
    }
    public Long getTokenTyp(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.TOKEN_TYP_CACHE).get(key);
        if (valueWrapper == null) return null;
        return ((BigDecimal)valueWrapper.get()).longValue();
    }

    public Long getTransactionTyp(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.TRANSACTION_TYP_CACHE).get(key);
        if (valueWrapper == null) return null;
        return ((BigDecimal)valueWrapper.get()).longValue();
    }

    public Long getTransactionStatusTyp(String key) {
        log.info("getTransactionStatusTyp() key: "+key);
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.TRANSACTION_STATUS_TYP_CACHE).get(key);
        if (valueWrapper == null) return null;
        log.info("getTransactionStatusTyp() returning TransactionStatusTyp");
        return ((BigDecimal)valueWrapper.get()).longValue();

    }

    public Long getValidationStatusTyp(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.VALIDATION_STATUS_TYP_CACHE).get(key);
        if (valueWrapper == null) return null;
        return ((BigDecimal)valueWrapper.get()).longValue();
    }

    AsyncLoadingCache merchCache() {
        return Caffeine.newBuilder()
                .buildAsync(new AsyncCacheLoader<String, MerchRefTyp>() {
                    @Override
                    public @NonNull
                    CompletableFuture<MerchRefTyp> asyncLoad(
                            @NonNull String s, @NonNull Executor executor) {
                        // no read back required for this implementation
                        return null;
                    }
                    @Override
                    public @NonNull CompletableFuture<Map<String, MerchRefTyp>> asyncLoadAll(
                            @NonNull Iterable<? extends String> keys, @NonNull Executor executor) {
                       // Flux<MerchRefTyp> merchRefTypFlux = transactionCacheLoaderDao.loadMerchRefTypReact();
                      //  Mono<Map<String, MerchRefTyp>> mono = merchRefTypFlux.collectMap(MerchRefTyp::getStoreId);
                       // return mono.toFuture();
                        return null;
                    }
        });
    }

    public Mono<MerchRefTyp> getMerchRefTyp(String key) {
        CompletableFuture<MerchRefTyp> future = merchRefTypCache.get(key);
        return Mono.fromFuture(future);
    }

    public boolean getFeatureFlagValue(String key) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.FEATURE_FLAG_CACHE).get(key);
        if (valueWrapper == null) return false;
        return Boolean.valueOf(String.valueOf(valueWrapper.get()));
    }

    public boolean isChaseOrbitalUrlEnabled(String primaryChaseOrbital) {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.CHASE_ORBITAL_URL).get(primaryChaseOrbital);
        if (valueWrapper == null){
            return true;
        }
        return Boolean.valueOf(String.valueOf(valueWrapper.get()));
    }

    public boolean isChaseOutageEnabled() {
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(GatewayConstants.SWITCH_CHASE_OUTAGE).get(GatewayConstants.ENABLE);
        if (valueWrapper == null|| (null!=valueWrapper.get()) && valueWrapper.get().equals(false)){
            return false;
        }
        return Boolean.valueOf(String.valueOf(valueWrapper.get()));
    }
}
