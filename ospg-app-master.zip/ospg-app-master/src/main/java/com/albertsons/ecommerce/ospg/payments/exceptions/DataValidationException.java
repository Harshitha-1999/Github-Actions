package com.albertsons.ecommerce.ospg.payments.exceptions;

import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@Data
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class DataValidationException extends RuntimeException {

    private static final long serialVersionUID = 7210533956864048027L;
    private String errorCode;


    public DataValidationException(String message) {
        super(message);
    }

    public DataValidationException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public DataValidationException(Throwable th) {
        super(th);
    }


    public DataValidationException(String message, Throwable th) {
        super(message, th);
    }

    public DataValidationException(String errorCode, String message, Throwable th) {
        super(message, th);
        this.errorCode = errorCode;
    }
}
