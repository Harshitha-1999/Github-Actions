package com.albertsons.ecommerce.ospg.payments.model.request;

import com.albertsons.ecommerce.ospg.payments.model.AdditionalAuthInfo;
import com.albertsons.ecommerce.ospg.payments.model.Cryptogram;
import com.albertsons.ecommerce.ospg.payments.model.Debit;
import com.albertsons.ecommerce.ospg.payments.model.Level2;
import com.albertsons.ecommerce.ospg.payments.model.Level3;
import com.albertsons.ecommerce.ospg.payments.model.Merchant;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.SoftDesc;
import com.albertsons.ecommerce.ospg.payments.model.StrongCustomerAuthenticationExemption;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString(includeFieldNames=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
public class CaptureReq extends ChaseRequest {
    private String version;
    private Merchant merchant;
    private SoftDesc softDesc;
    private Order order;
    //private Level2 level2;
    //private Level3 level3;
    //private Cryptogram cryptogram;
    //private AdditionalAuthInfo additionalAuthInfo;
    //private StrongCustomerAuthenticationExemption strongCustomerAuthenticationExemption;
    //xprivate Debit debit;
}
