package com.albertsons.ecommerce.ospg.payments.external;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.model.request.ChaseRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;

@Component
public class ChaseCaller {

	@Autowired
	@Qualifier("chaseClient")
	private WebClient chaseWebclient;

	@Autowired
	@Qualifier("chaseSecondaryClient")
	private WebClient chaseSecWebClient;
	
	@Value("${chase.username}")
    private String username;
    @Value("${chase.password}")
    private String password;
    @Autowired
	CommonService commonService;
	@Loggable
	private SecurityLogger log;

    @Autowired
    private ObjectMapper mapper;

	public ResponseSpec callChaseService(ChaseRequest request, String storeId, String sellerId, String... pathSegments) {

		log.info("callChaseService() >> calling chase service with request: {} ,store Id: {}", stringify(request), storeId);
		ResponseSpec responseSpec = getWebClient(request).post()
                .uri(uriBuilder -> uriBuilder.pathSegment(pathSegments).build())
                .headers(httpHeadersOnWebClientBeingBuilt -> {
                	httpHeadersOnWebClientBeingBuilt.addAll(getHttpHeaders(storeId, sellerId, request));
                })
                .body(Mono.just(request), ChaseRequest.class)
                .retrieve();
		responseSpec.bodyToMono(String.class).doOnSuccess(resp -> log.info("callChaseService() >> chase response raw : ",resp));
		return responseSpec;
	}

	private WebClient getWebClient(ChaseRequest request) {
		if(commonService.isChaseOrbitalUrlEnabled(GatewayConstants.PRIMARY_CHASE_ORBITAL_URL)){
			log.info("getWebClient() >> request:{}, invoking chase primary Webclient url", stringify(request));
			return chaseWebclient;
		}
		log.info("getWebClient() >> request:{}, invoking chase Secondary WebClient url", stringify(request));
		return chaseSecWebClient;
	}

	private HttpHeaders getHttpHeaders(String storeId, String sellerId, ChaseRequest request) {
		HttpHeaders headers = new HttpHeaders();
		String merchRefId = commonService.getMerchRefId(storeId, sellerId);
		headers.add(Constants.ORBITRAL_CONN_USER, username);
		headers.add(Constants.ORBITRAL_CONN_PW, password);
		headers.add(Constants.ORBITRAL_CONN_MERCHANT, merchRefId);
		log.info("getHttpHeaders() >> sellerId: {}, merchRefId: {}, request: {}", sellerId, merchRefId, stringify(request));
		return headers;
	}
	
	private String stringify(Object object){
		
		log.info("stringify() >> Converting object to json String");
		String unmarshalled;
		try {
			unmarshalled = mapper.writeValueAsString(object);
			return unmarshalled;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  "";
	}

	public ResponseSpec callChaseServiceForDummyRequest(ChaseRequest request, String storeId, String sellerId, String... pathSegments) {

		log.info("callChaseServiceForDummyRequest() >> calling chase service with request: {} ,store Id: {}", stringify(request), storeId);
		ResponseSpec responseSpec = chaseWebclient.post()
				.uri(uriBuilder -> uriBuilder.pathSegment(pathSegments).build())
				.headers(httpHeadersOnWebClientBeingBuilt -> {
					httpHeadersOnWebClientBeingBuilt.addAll(getHttpHeaders(storeId, sellerId, request));
				})
				.body(Mono.just(request), ChaseRequest.class)
				.retrieve();
		responseSpec.bodyToMono(String.class).doOnSuccess(resp -> log.info("callChaseServiceForDummyRequest() >> chase response raw : ",resp));
		return responseSpec;
	}
}
