package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.model.request.ECHORequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ECHOResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class ExportService {
    @Autowired
    private TransactionsDAO dao;

    public Mono<ECHOResponse> exportData(ECHORequest request) {
        return dao.exportData(request);
    }
}
