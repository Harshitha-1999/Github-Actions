package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@NoArgsConstructor
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardTypeIndicator implements Serializable {
    private String ctiAffluentCard;
    private String ctiCommercialCard;
    private String ctiDurbinExemption;
    private String ctiHealthcareCard;
    private String ctiLevel3Eligible;
    private String ctiPayrollCard;
    private String ctiPrepaidCard;
    private String ctiPINlessDebitCard;
    private String ctiSignatureDebitCard;
    private String ctiIssuingCountry;
}
