package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AlphabetValidator implements ConstraintValidator<Alphabet, String> {

    private ValidationErrorCode error;

    @Override
    public void initialize(Alphabet constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        if (object == null || StringUtils.isEmpty(object)) {
            return true;
        }
        if(object.matches("^[a-zA-Z ]*$")){
            return true;
        }else{
            throw new DataValidationException(error.getCode(), error.getMessage());
        }
    }
}