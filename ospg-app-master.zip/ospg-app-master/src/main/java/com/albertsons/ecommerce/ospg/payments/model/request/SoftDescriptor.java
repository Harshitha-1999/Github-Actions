package com.albertsons.ecommerce.ospg.payments.model.request;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.Setter;

@JsonAutoDetect
@Getter
@Setter
public class SoftDescriptor {

	@JsonInclude(Include.NON_NULL)
	private String dba_name;

	@JsonInclude(Include.NON_NULL)
	private String softDescMercName;

	@JsonInclude(Include.NON_NULL)
	private String city;

	@JsonInclude(Include.NON_NULL)
	private String softDescProdDesc;
}
