package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.TRANSACTION_TYPE;

public class AuthTypeValidator implements ConstraintValidator<AuthType, String> {
    private ValidationErrorCode error;

    @Override
    public void initialize(AuthType constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(String authType, ConstraintValidatorContext constraintContext) {
        if (authType == null || authType.trim().isEmpty()) {
            throw new DataValidationException(error.getCode(), error.getMessage());
        }

        if (!authType.equals(Constants.AUTHORIZE))
            throw new DataValidationException(TRANSACTION_TYPE.getCode(), TRANSACTION_TYPE.getMessage());
        return true;
    }
}