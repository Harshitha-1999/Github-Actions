package com.albertsons.ecommerce.ospg.payments.enumerations;

import com.albertsons.ecommerce.ospg.payments.model.request.MerchantInitiatedTransaction;

import java.util.HashMap;
import java.util.Map;

public class StoredCredentials {

    // Declaring the static map
    public static Map<String, MerchantInitiatedTransaction> storedCredentialsShop;

    public static Map<String, MerchantInitiatedTransaction> storedCredentialsSubscription;
    
    public static Map<String, MerchantInitiatedTransaction> storedCredentialsPurchaseShop;
    
    public static Map<String, MerchantInitiatedTransaction> storedCredentialsPurchaseSubscription;
    
    public static Map<String, MerchantInitiatedTransaction> storedCredentialsIncrementalAuth;

    public static Map<String, MerchantInitiatedTransaction> storedCredentialsShopMC;

    // Instantiating the static map
    static
    {
        storedCredentialsShop = new HashMap<>();
        storedCredentialsShop.put("VI", new MerchantInitiatedTransaction("CEST", "Y", null));
        storedCredentialsShop.put("MC", new MerchantInitiatedTransaction("CEST", "Y", null));

        storedCredentialsShop.put("DI", new MerchantInitiatedTransaction("CGEN", "Y", null));
        storedCredentialsShop.put("AM", new MerchantInitiatedTransaction("CGEN", "Y", null));

        storedCredentialsShop.put("JC", new MerchantInitiatedTransaction("CEST", "Y", null));
    }

    static
    {
        storedCredentialsSubscription = new HashMap<>();
        storedCredentialsSubscription.put("VI", new MerchantInitiatedTransaction("CREC", "Y", null));
        storedCredentialsSubscription.put("MC", new MerchantInitiatedTransaction("CREC", "Y", null));

        storedCredentialsSubscription.put("DI", new MerchantInitiatedTransaction("CREC", "Y", null));
        storedCredentialsSubscription.put("AM", new MerchantInitiatedTransaction("CREC", "Y", null));

        storedCredentialsSubscription.put("JC", new MerchantInitiatedTransaction("CREC", "Y", null));
    }
    
    
    static
    {
        storedCredentialsPurchaseShop = new HashMap<>();
        storedCredentialsPurchaseShop.put("VI", new MerchantInitiatedTransaction("MRSB", "Y", null));
        storedCredentialsPurchaseShop.put("MC", new MerchantInitiatedTransaction("MRSB", "Y", null));

        storedCredentialsPurchaseShop.put("DI", new MerchantInitiatedTransaction("MRSB", "Y", null));
        storedCredentialsPurchaseShop.put("AM", new MerchantInitiatedTransaction("MRSB", "Y", null));

        storedCredentialsPurchaseShop.put("JC", new MerchantInitiatedTransaction("MRSB", "Y", null));
    }

    static
    {
        storedCredentialsPurchaseSubscription = new HashMap<>();
        storedCredentialsPurchaseSubscription.put("VI", new MerchantInitiatedTransaction("MREC", "Y", null));
        storedCredentialsPurchaseSubscription.put("MC", new MerchantInitiatedTransaction("MREC", "Y", null));

        storedCredentialsPurchaseSubscription.put("DI", new MerchantInitiatedTransaction("MREC", "Y", null));
        storedCredentialsPurchaseSubscription.put("AM", new MerchantInitiatedTransaction("MREC", "Y", null));
        storedCredentialsPurchaseSubscription.put("AX", new MerchantInitiatedTransaction("MREC", "Y", null));
        storedCredentialsPurchaseSubscription.put("JC", new MerchantInitiatedTransaction("MREC", "Y", null));
    }
    
    static
    {
        storedCredentialsIncrementalAuth = new HashMap<>();
        storedCredentialsIncrementalAuth.put("VI", new MerchantInitiatedTransaction("MINC", "Y", null));
        storedCredentialsIncrementalAuth.put("MC", new MerchantInitiatedTransaction("MINC", "Y", null));

        //storedCredentialsShop.put("DI", new MerchantInitiatedTransaction("CGEN", "Y", null));
        //storedCredentialsShop.put("AM", new MerchantInitiatedTransaction("CGEN", "Y", null));

        storedCredentialsIncrementalAuth.put("JC", new MerchantInitiatedTransaction("MINC", "Y", null));
    }

    static
    {
        storedCredentialsShopMC = new HashMap<>();
        storedCredentialsShopMC.put("MC", new MerchantInitiatedTransaction("CGEN", "Y", null));
    }

}
