package com.albertsons.ecommerce.ospg.payments.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class StoredCredentialResponse {
    private String initiator;
    private String indicator;
    private String schedule;
    @JsonProperty("cardbrand_original_transaction_id")
    private String cardBrandOriginalTransactionId;
    @JsonProperty("cardbrand_original_amount")
    private String cardBrandOriginalAmount;
}