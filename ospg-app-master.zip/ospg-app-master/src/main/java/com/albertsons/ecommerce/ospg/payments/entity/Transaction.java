package com.albertsons.ecommerce.ospg.payments.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serializable;
import java.math.BigDecimal;


//@Table("\"TRANSACTION\"")
@Table("[OSPGPAYTX].[TRANSACTION]")
@Builder
@Getter
@Setter
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column("TRANSACTION_ID")
	private BigDecimal transactionId;

	@Column("TRANSACTION_TOKEN_ID")
	private BigDecimal transactionTokenId;

	@Column("CLIENT_IP_TXT")
	private String clientIpTxt;

	@Column("AVS_RESPONSE_CD")
	private String avsResponseCd;

	@Column("CORRELATION_ID")
	private double correlationId;

	@Column("EXPIRY_TS")
	private String expiryTs;

	@Column("LAST_UPDATE_TS")
	private String lastUpdateTs;

	@Column("LAST_UPDATE_USER_ID")
	private String lastUpdateUserId;

	@Column("PROVIDER_TRANSACTION_ID")
	private String providerTransactionId;

	@Column("TRANSACTION_AMT")
	private BigDecimal transactionAmt;

	@Column("TRANSACTION_END_TS")
	private String transactionEndTs;

	@Column("TRANSACTION_START_TS")
	private String transactionStartTs;

	@Column("TRANSACTION_TAG_TXT")
	private String transactionTagTxt;

	@Column("MERCH_REF_TYP_CD")
	private Long merchRefTyp;
	
	@Column("TRANSACTION_TYP_CD")
	private Long transactionTyp;

	@Column("TRANSACTION_STAT_TYP_CD")
	private Long transactionStatusTyp;
	
	@Column("VALIDATION_STATUS_TYP_CD")
	private Long validationStatusTyp;

	@Column("SELLER_ID")
	private String sellerId;

}