package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Encrypted {
    private String encryptedPan;
    private String encryptedPanMethod;
    private String encryptedPanKey;
    private String encryptedPanPublicKeyFingerPrint;
    private String encryptedPanHash;
    private String encryptedMagStripeTrack2;
    private String encryptionInd;
    private String encryptionMethod;
    private String encryptionId;
}
