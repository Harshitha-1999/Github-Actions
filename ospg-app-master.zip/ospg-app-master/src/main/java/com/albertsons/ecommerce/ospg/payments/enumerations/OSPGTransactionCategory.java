package com.albertsons.ecommerce.ospg.payments.enumerations;

public enum OSPGTransactionCategory {

    PURCHASE("Purchase", "transaction/purchase"),
    SECURE_AUTHORIZE("Secure Authorize", "transaction/v2/authorize"),
    SECURE_AUTHORIZE_EST_AMT("Secure Authorize Estimated Amount", "transaction/v2/authorize-estimated-amount"),
    AUTHORIZE_EST_AMT("Authorize Estimated Amount", "transaction/v2/authorize-estimated-amount"),
    AUTHORIZE("Authorize", "transaction/authorize"),
    VOID("Void", "transaction/void");

    private String key;
    private String url;

    private OSPGTransactionCategory(String key, String url) {
        this.key = key;
        this.url = url;
    }

    public String getKey() {
        return key;
    }

    public String getUrl() {
        return url;
    }
}
