package com.albertsons.ecommerce.ospg.payments.config;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import com.albertsons.ecommerce.ospg.payments.properties.ProxyProperties;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

@Profile("local")
@Configuration
@Slf4j
public class LocalConfiguration {

    @Value("${chase.url}")
    private String url;
    @Value("${chase.username}")
    private String username;
    @Value("${chase.password}")
    private String password;
    @Value("${chase.merchantId}")
    private String merchantId;
    @Value("${chase.timeout}")
    private int timeout;
    @Autowired
	private ProxyProperties properties;

    @Bean("chaseClient")
    public WebClient getChaseWebClient()  {

        log.info("local config.........");

        HttpClient httpClient = HttpClient.create()
                .proxy(proxy -> proxy

                        .type(ProxyProvider.Proxy.HTTP)
                        .host(properties.getHost())
                        .username(properties.getUser())
                        .port(properties.getPort())
                        .password(a -> properties.getPassword()))
                .responseTimeout(Duration.ofMillis(timeout))
                //.baseUrl(url)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, timeout)
                .doOnConnected(conn -> {
                    conn.addHandlerLast(new ReadTimeoutHandler(timeout, TimeUnit.MILLISECONDS))
                            .addHandlerLast(new WriteTimeoutHandler(timeout, TimeUnit.MILLISECONDS));
                });
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .baseUrl(url)
                .filter(ExchangeFilterFunction.ofResponseProcessor(this::renderApiErrorResponse))
                .build();
    }
    
    private Mono<ClientResponse> renderApiErrorResponse(ClientResponse clientResponse) {
    	if(clientResponse.statusCode().isError()){
			log.info("is resp Error :"+clientResponse.statusCode());
			return clientResponse.bodyToMono(String.class)
					.flatMap(apiErrorResponse -> Mono.error(new ResponseStatusException(
							clientResponse.statusCode(),
							apiErrorResponse
					)));
		}else{
			log.info(" LocalConfiguration >> renderApiErrorResponse -> Success Response");
			return  Mono.just(clientResponse);
		}
		
	}

}