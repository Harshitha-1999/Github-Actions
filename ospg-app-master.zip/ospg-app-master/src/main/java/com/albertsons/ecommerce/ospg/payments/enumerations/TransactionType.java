package com.albertsons.ecommerce.ospg.payments.enumerations;

public enum TransactionType {

	VOID("void"), AUTHORIZE("authorize"), REFUND("refund"), PURCHASE("purchase"), CAPTURE("capture");

	String name;

	private TransactionType(String s) {
		name = s;
	}

	@Override
	public String toString() {
		return this.name;
	}

}
