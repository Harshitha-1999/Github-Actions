package com.albertsons.ecommerce.ospg.payments.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serializable;
import java.math.BigDecimal;

@Builder
@Getter
@Setter
//@Table("TRANSACTION_RESPONSE")
@Table("[OSPGPAYTX].[TRANSACTION_RESPONSE]")
public class TransactionResponseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column("TRANSACTION_RESPONSE_ID")
	private BigDecimal transactionResponseId;

	@Column("TRANSACTION_ID")
	private BigDecimal transactionId;

	@Column("TRANSACTION_TOKEN_ID")
	private BigDecimal transactionTokenId;


	@Column("BANK_RESPONSE_CD")
	private String bankResponseCd;

	@Column("BANK_RESPONSE_TXT")
	private String bankResponseTxt;

	@Column("EXPIRY_TS")
	private String expiryTs;

	@Column("GATEWAY_RESPONSE_CD")
	private String gatewayResponseCd;

	@Column("GATEWAY_RESPONSE_TXT")
	private String gatewayResponseTxt;

	@Column("LAST_UPDATE_TS")
	private String lastUpdateTs;

	@Column("LAST_UPDATE_USER_ID")
	private String lastUpdateUserId;

	
	@Column("ERROR_TYP_CD")
	private String errorTyp;
	
}