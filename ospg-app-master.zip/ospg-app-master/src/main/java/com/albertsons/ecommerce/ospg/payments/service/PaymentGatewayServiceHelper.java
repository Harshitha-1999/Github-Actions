package com.albertsons.ecommerce.ospg.payments.service;


import com.albertsons.ecommerce.ospg.payments.exceptions.PaymentDataAccessException;
import com.albertsons.ecommerce.ospg.payments.model.request.MerchantInitiatedTransaction;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import static com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants.*;

/**
 * This the service helper class which handles the utility methods.
 * 
 * @author APARV03
 *
 */
@Component
@Slf4j
public class PaymentGatewayServiceHelper {

	
	
	private static final String SHA_ALGORITHM = "HmacSHA256";

	/**
	 * Jackson Object mapper
	 */
	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * This method returns the map with required for the http headers and
	 * payload.
	 * 
	 * @param apiKey
	 * @param securedSecret
	 * @param token
	 * @param payLoad
	 * @return Map with all the required information for the input.
	 * @throws Exception
	 */
	public Map<String, String> getSecurityKeys(String apiKey, String securedSecret, String token,
			String payLoad) throws PaymentDataAccessException {
		Map<String, String> returnMap = new HashMap<String, String>();
		long nonce;
		try {
			nonce = Math.abs(SecureRandom.getInstance("SHA1PRNG").nextLong());
			log.debug("getSecurityKeys() >> SecureRandom nonce:{}", nonce);

			returnMap.put(APIKEY, apiKey);
			returnMap.put(NONCE, Long.toString(nonce));
			returnMap.put(TIMESTAMP, Long.toString(System.currentTimeMillis()));
			returnMap.put(TOKEN, token);
			returnMap.put(PAYLOAD, payLoad);
			returnMap.put(APISCRT, securedSecret);

			returnMap.put(AUTHORIZE, getMacValue(returnMap));
			return returnMap;
		} catch (NoSuchAlgorithmException e) {
			log.error("getSecurityKeys() >> Error while building the security keys in purchase: {}", e);
			throw new PaymentDataAccessException(e);
		}

	}

	/**
	 * This method constructs the data param by appending the parameters below
	 * in the same order as shown. a. apikey - API key of the developer. b.
	 * nonce - secure random number. c. timestamp - epoch timestamp in
	 * milliseconds. d. token - Merchant Token. e. payload - Actual body content
	 * passed as post request. Compute HMAC SHA256 hash on the above data param
	 * using the key below f. apiSecret - Consumer Secret token for the given
	 * api key
	 * 
	 * Calculates the base64 of the hash which would be our required
	 * Authorization header value.
	 * 
	 * @param data
	 *            - Map with all the input info
	 * @return HMAC Payload
	 * @throws Exception
	 */
	private String getMacValue(Map<String, String> data) throws PaymentDataAccessException {

		Mac mac;
		try {
			mac = Mac.getInstance(SHA_ALGORITHM);

			String apiSecret = data.get(APISCRT);
			log.debug("getMacValue() >> apiSecret {} " , apiSecret);
			SecretKeySpec secret_key = new SecretKeySpec(apiSecret.getBytes(), SHA_ALGORITHM);
			mac.init(secret_key);

			StringBuilder buff = new StringBuilder();
			String authorizeHash = buff.append(data.get(APIKEY)).append(data.get(NONCE))
					.append(data.get(TIMESTAMP)).append(data.get(TOKEN)).append(data.get(PAYLOAD))
					.toString();
			log.debug("getMacValue() >> authorizeHash {} " , authorizeHash);
			byte[] macHash = getMacHash(mac, authorizeHash);
			String authorizeString = Base64.encodeBase64String(toHex(macHash));
			log.debug("getMacValue() >> Authorize String Base64: {}", authorizeString);

			return authorizeString;
		} catch (NoSuchAlgorithmException e) {
			log.error("getMacValue() >> Error while getting the Mac instance using SHA algorithm : ", e);
			throw new PaymentDataAccessException(e);
		} catch (InvalidKeyException e) {
			log.error("getMacValue() >> Error while initializing the Mac instance with security key : ", e);
			throw new PaymentDataAccessException(e);
		}

	}

	/**
	 * Converts the bytes to Hex bytes
	 * 
	 * @param arr
	 * @return
	 */
	public byte[] toHex(byte[] arr) {
        String hex = Hex.encodeHexString(arr);
        log.info("toHex() >> Apache common value:{}", hex);
        return hex.getBytes();
  }


	private byte[] getMacHash(Mac mac, String authorizeHash) throws PaymentDataAccessException {
		byte[] macHash;
		try {
			macHash = mac.doFinal(authorizeHash.getBytes("UTF-8"));
		} catch (IllegalStateException e) {
			log.error("getMacHash() >> Error while getting Mac Hash : ", e);
			throw new PaymentDataAccessException(e);
		} catch (UnsupportedEncodingException e) {
			log.error("getMacHash() >> Error while getting Mac Hash : ", e);
			throw new PaymentDataAccessException(e);
		}
		return macHash;
	}

	/**
	 * This method returns the Json string of the payload.
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public String getJsonPayload(Object data) throws PaymentDataAccessException {
		try {
			return objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			log.error("getJsonPayload() >> Error while getting the Json Object : {}", e);
			throw new PaymentDataAccessException(e);
		}

	}
	
	/*public SubscriptionPaymentRequest convertJsonStringToObject(String data) throws Exception  {
		try {
			return (SubscriptionPaymentRequest)objectMapper.readValue(data, SubscriptionPaymentRequest.class);
			//return objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			log.error("Error while getting the Json Object : {}", e);
			throw new Exception(e);
		}

	}*/
	
	/*public TransactionResponse convertFirstDataRespJsonToObject(String data) throws Exception  {
		try {
			return (PaymentGatewayTransactionResponse)objectMapper.readValue(data, PaymentGatewayTransactionResponse.class);
			//return objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			log.error("Error while getting the Json Object : {}", e);
			throw new Exception(e);
		}

	}*/

	/**
	 * Method to construct the http headers with the below input values.
	 * 
	 * @param appId
	 * @param securityKey
	 * @param token
	 * @param payload
	 * @return HttpHeaders
	 * @throws Exception
	 */
	public HttpHeaders getHttpHeader(String appId, String securityKey, String token, String payload) {
		Map<String, String> encriptedHeaders = getSecurityKeys(appId, securityKey, token, payload);
		HttpHeaders header = new HttpHeaders();
		header.add(APIKEY, encriptedHeaders.get(APIKEY));
		header.add(NONCE, encriptedHeaders.get(NONCE));
		header.add(TIMESTAMP, encriptedHeaders.get(TIMESTAMP));
		header.add(TOKEN, encriptedHeaders.get(TOKEN));
		header.setContentType(MediaType.APPLICATION_JSON);
		header.add(AUTHORIZE, encriptedHeaders.get(AUTHORIZE));


		return header;
	}

	public MerchantInitiatedTransaction convertJsonToMerchIntTx(String objStr) {
		try {
			return objectMapper.readValue(objStr, MerchantInitiatedTransaction.class);
		} catch (JsonProcessingException e) {
			log.error("Error convertJsonToMerchIntTx :", e);
			throw new PaymentDataAccessException(e);
		}
	}

}
