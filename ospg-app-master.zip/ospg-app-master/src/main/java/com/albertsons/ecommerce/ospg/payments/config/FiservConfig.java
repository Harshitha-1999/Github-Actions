package com.albertsons.ecommerce.ospg.payments.config;

import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

//@Profile("!local")
@Configuration
public class FiservConfig {
    @Value("${fiserv.url}")
    private String url;
    @Value("${fiserv.timeout}")
    private int timeout;
    private HttpClient fiservClient;

    @Loggable
    private SecurityLogger log;

    @Bean("fiservClient")
    public WebClient getFiservWebclient() {
        log.info("getExternalWebclient() >> Started ");
        fiservClient = HttpClient.create().baseUrl(url);
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(fiservClient)).build();
    }
}
