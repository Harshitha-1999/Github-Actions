package com.albertsons.ecommerce.ospg.payments.exceptions;

/**
 * This Exception defines for any errors caused due to payment provider down.
 * 
 * @author schal14
 *
 */
public class PaymentProviderDownException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6251943284873475000L;

	public PaymentProviderDownException(String message) {
		super(message);
	}

	public PaymentProviderDownException(Throwable th) {
		super(th);
	}

	public PaymentProviderDownException(String message, Throwable th) {
		super(message, th);
	}
}
