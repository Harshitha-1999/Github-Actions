package com.albertsons.ecommerce.ospg.payments.external;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import reactor.core.publisher.Mono;

/**
 * @author Masood Mohiuddin
 */
@Slf4j
@Component
public class FiservCaller {

    @Autowired
    @Qualifier("fiservClient")
    private WebClient fiservWebclient;

    @Autowired
    private ObjectMapper mapper;

    @Value("${fiserv.refund.url}")
    private String fiservRefundUrl;

    /**
     * This method will fetches response from fiserv service
     * with provided request.
     * @param transReq
     * @return ResponseSpec
     */
    public ResponseSpec refundCall(TransactionRequest transReq) {
        log.info("refundCall() >> fiserv request: {}",stringify(transReq));
        ResponseSpec response = fiservWebclient
                .post()
                .uri(fiservRefundUrl)
                .body(Mono.just(transReq), TransactionRequest.class)
                .retrieve();
        return response;
    }
    /**
     * This method will log request in logger file.
     * @param object
     * @return String
     */
    private String stringify(Object object){
        String unmarshalled = StringUtils.EMPTY;
        try {
            unmarshalled = mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error("stringify() >> JsonProcessingException: {}" ,e.getMessage());
            e.printStackTrace();
        }
        return unmarshalled;
    }
}
