package com.albertsons.ecommerce.ospg.payments.enumerations;

public enum MerchRefDsc {

    SAFEWAY("SAFEWAY.COM","SAFEWAY"), ALBERTSONS("ALBERTSONS.COM","ABS"),
    CARRSQC("CARRSQC.COM","CARRS"), CARRS("CARRS.COM","CARRS"),
    ACME("ACME.COM","ACME"),  ANDRONICOS("ANDRONICOS.COM","ANDRON"),  HAGGEN("HAGGEN.COM","HAGGEN"),
    JEWELOSCO("JEWELOSCO.COM","JEWEL"), JEWEL_OSCO("JEWEL-OSCO.COM","JEWEL"), JEWEL("JEWEL.COM","JEWEL"),
    JEWELS("JEWELS.COM","JEWEL"), JEWEL__OSCO("JEWEL OSCO.COM","JEWEL"),
    PAVILLIONS("PAVILLIONS.COM","PAV"), PAVILIONS("PAVILIONS.COM","PAV"),  RANDALLS("RANDALLS.COM","RANDALL"),
    SHAWS("SHAWS.COM","SHAWS"), STAR("STAR.COM","STAR"), TOMTHUMB("TOM THUMB.COM","TOMTHUM"),
    VONS("VONS.COM","VONS") ;

    private String banner;
    private String key;


    private MerchRefDsc(String key, String banner) {
        this.key = key;
        this.banner = banner;
    }

    public String getKey() {
        return key;
    }

    public static String getValueByKey(String key) {
        MerchRefDsc[] values = values();
        for(MerchRefDsc merchRefDsc: values) {
            if(merchRefDsc.getKey().equalsIgnoreCase(key)) {
                return merchRefDsc.banner;
            }
        }
        return null;
    }
}
