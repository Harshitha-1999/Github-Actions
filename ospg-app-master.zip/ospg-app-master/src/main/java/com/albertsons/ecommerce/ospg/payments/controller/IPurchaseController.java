package com.albertsons.ecommerce.ospg.payments.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;

import reactor.core.publisher.Mono;

@RequestMapping(value = "/transaction")
public interface IPurchaseController {
	
	@PostMapping(value = "/purchase")
    public Mono<TransactionResponse> purchaseTransaction(@RequestBody TransactionRequest transactionRequest);
}
