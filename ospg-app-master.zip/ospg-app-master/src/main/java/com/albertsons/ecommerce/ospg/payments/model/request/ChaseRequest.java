package com.albertsons.ecommerce.ospg.payments.model.request;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import lombok.Getter;
import lombok.Setter;

@JsonAutoDetect
@Getter
@Setter
public class ChaseRequest {

}
