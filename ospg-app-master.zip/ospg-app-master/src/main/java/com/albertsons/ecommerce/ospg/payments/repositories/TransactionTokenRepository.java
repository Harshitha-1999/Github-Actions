package com.albertsons.ecommerce.ospg.payments.repositories;

import com.albertsons.ecommerce.ospg.payments.entity.TransactionToken;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

@Repository
public interface TransactionTokenRepository extends ReactiveCrudRepository<TransactionToken, Long> {

  @Query("INSERT INTO "
          + "[OSPGPAYTX].[TRANSACTION_TOKEN]([TRANSACTION_TOKEN_ID], [TOKEN_TYP_CD],"
          + "[TOKEN_NBR],[CARD_HOLDER_NM],[CARD_EXPIRY_DT],"
          + "[CARD_TYP_CD],[ORDER_ID],[STORE_ID],"
          + "[LAST_UPDATE_USER_ID],[LAST_UPDATE_TS],[EXPIRY_TS], [MIT_RECEIVED_TRANSACTION_ID]) "
          + "OUTPUT inserted.TRANSACTION_TOKEN_ID "
          + "VALUES"
          + "( (NEXT VALUE FOR [OSPGPAYTX].[TRANSACTION_TOKEN_ID_SEQ]), "
          + ":tokenTypCd,:tokenNmbr,:cardHolderName,"
          + ":expDt,:cardTypCd,:orderId,:storeId,:lastUpdateUID,"
          + ":lastUpdateTS,:expTS, :mitReceivedTranId)")
  public Mono<Long> saveTransactionToken(long tokenTypCd,
                                               String tokenNmbr,
                                               String cardHolderName,
                                               String expDt,
                                               Long cardTypCd,
                                               BigDecimal orderId,
                                               BigDecimal storeId,
                                               String lastUpdateUID,
                                               String lastUpdateTS,
                                               String expTS,
                                               String mitReceivedTranId);

  @Query("select top 1 TRANSACTION_TOKEN_ID from [OSPGPAYTX].[TRANSACTION_TOKEN] "
          + "where store_id = :storeId and token_nbr = :tokenNbr and order_id = :orderId")
  public Mono<Long> fetchTransactionToken (String tokenNbr, Long orderId, Long storeId);

  @Query("select top 1 TRANSACTION_TOKEN_ID from [OSPGPAYTX].[TRANSACTION_TOKEN] "
          + "where store_id = :storeId and token_nbr = :tokenNbr and order_id is null")
  public Mono<BigDecimal> fetchTransactionTokenForAuthorize(String tokenNbr, BigDecimal storeId);
}
