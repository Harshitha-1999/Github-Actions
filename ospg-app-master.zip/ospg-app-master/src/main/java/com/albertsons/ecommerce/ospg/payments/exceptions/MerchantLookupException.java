package com.albertsons.ecommerce.ospg.payments.exceptions;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MerchantLookupException extends RuntimeException{

    public MerchantLookupException (String message) {
        super(message);
    }
}