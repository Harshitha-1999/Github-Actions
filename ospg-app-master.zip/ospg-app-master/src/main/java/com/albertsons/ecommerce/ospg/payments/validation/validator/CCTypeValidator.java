package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.CARD_TYPE_INVALID_VALUE;

public class CCTypeValidator implements ConstraintValidator<CCType, String> {
    private ValidationErrorCode error;

    @Override
    public void initialize(CCType constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(String cardType, ConstraintValidatorContext constraintContext) {
        if (cardType == null || cardType.trim().isEmpty()) {
            throw new DataValidationException(error.getCode(), error.getMessage());
        }

        if (!PaymentUtil.creditCardTypMap.containsKey(cardType))
            throw new DataValidationException(CARD_TYPE_INVALID_VALUE.getCode(), CARD_TYPE_INVALID_VALUE.getMessage());
        return true;
    }
}