package com.albertsons.ecommerce.ospg.payments.model.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
public class ECHOResponse {
    private String cardHolderNm;
    private String tokenNbr;
    private int storeId;
    private String orderId;
    private String lastUpdateUserId;
    private float transactionAmt;
    private Timestamp transactionEndTs;
    private String cardExpiryDt;
    private String providerTransactionId;
    private String clientIpTxt;
    private String cardNm;
    private String merchRefDsc;
    private String merchRefNm;
    private String bannerName;
    private String bankResponseCd;
    private String bankResponseTxt;
    private int transactionResponseId;
    private Timestamp lastUpdateTs;
}
