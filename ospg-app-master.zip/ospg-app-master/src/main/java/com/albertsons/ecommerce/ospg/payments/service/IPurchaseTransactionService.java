package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;

import reactor.core.publisher.Mono;

public interface IPurchaseTransactionService {
	
	Mono<TransactionResponse> purchase(TransactionRequest transactionRequest);
}
