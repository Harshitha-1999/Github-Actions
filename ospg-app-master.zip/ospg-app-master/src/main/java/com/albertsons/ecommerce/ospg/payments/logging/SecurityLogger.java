package com.albertsons.ecommerce.ospg.payments.logging;


import com.albertsons.ecommerce.ospg.payments.util.CommonUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.Marker;


/**
 * The purpose of this wrapper class is to construct log entries by using a safe logging mechanism.
 */
public class SecurityLogger implements Logger {


    private final Logger delegate;

    private HtmlEncoder htmlEncoder = new HtmlEncoder();

    public SecurityLogger(Logger toGuard) {
        this.delegate = toGuard;
    }

    /**
     * Removes newline characters from the provided String then encodes it for HTML before returning the 'clean' version
     * to the caller.
     *
     * @param message Original message to clean.
     * @return Cleaned message.
     */
    private final String cleanMessage(String message) {
        // ensure no CRLF injection into logs for forging records
        String clean = CommonUtils.replaceCRLF(message);
        //clean = htmlEncoder.encodeForHTML(clean);
        //if (ESAPI.securityConfiguration().getLogEncodingRequired()) {
        clean = ESAPI.encoder().encodeForHTML(message);

        //}
        return clean;
    }

    private final Object[] cleanMessages(Object[] messages) {
        for (int index = 0; index < messages.length; index++) {
            if (messages[index] == null)
                continue;
            String message = messages[index].toString();
            // ensure no CRLF injection into logs for forging records
            messages[index] = cleanMessage(message);
        }
        return messages;
    }

    private final Object cleanMessage(Object message) {
        if (message == null) return null;
        return cleanMessage(message.toString());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(Marker arg0, String arg1, Object arg2, Object arg3) {
        if (isDebugEnabled(arg0)) {
            delegate.debug(arg0, cleanMessage(arg1), cleanMessage(arg2), cleanMessage(arg3));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(Marker arg0, String arg1, Object[] arg2) {
        if (isDebugEnabled()) {
            delegate.debug(arg0, cleanMessage(arg1), cleanMessages(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(Marker arg0, String arg1, Object arg2) {
        if (isDebugEnabled(arg0)) {
            delegate.debug(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(Marker arg0, String arg1, Throwable arg2) {
        if (isDebugEnabled(arg0)) {
            delegate.debug(arg0, cleanMessage(arg1), arg2);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(Marker arg0, String arg1) {
        if (isDebugEnabled(arg0)) {
            delegate.debug(arg0, cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(String arg0, Object arg1, Object arg2) {
        if (isDebugEnabled()) {
            delegate.debug(cleanMessage(arg0), cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(String arg0, Object... arg1) {
        if (isDebugEnabled()) {
            delegate.debug(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(String arg0, Object arg1) {
        if (isDebugEnabled()) {
            delegate.debug(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(String arg0, Throwable arg1) {
        if (isDebugEnabled()) {
            delegate.debug(cleanMessage(arg0), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void debug(String arg0) {
        if (isDebugEnabled()) {
            delegate.debug(cleanMessage(arg0));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(Marker arg0, String arg1, Object arg2, Object arg3) {
        if (isErrorEnabled(arg0)) {
            delegate.error(arg0, cleanMessage(arg1), cleanMessage(arg2), cleanMessage(arg3));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(Marker arg0, String arg1, Object... arg2) {
        if (isErrorEnabled(arg0)) {
            delegate.error(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(Marker arg0, String arg1, Object arg2) {
        if (isErrorEnabled(arg0)) {
            delegate.error(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(Marker arg0, String arg1, Throwable arg2) {
        if (isErrorEnabled(arg0)) {
            delegate.error(arg0, cleanMessage(arg1), arg2);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(Marker arg0, String arg1) {
        if (isErrorEnabled(arg0)) {
            delegate.error(arg0, cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(String arg0, Object arg1, Object arg2) {
        if (isErrorEnabled()) {
            delegate.error(cleanMessage(arg0), cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(String arg0, Object arg1) {
        if (isErrorEnabled()) {
            delegate.error(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(String arg0, Throwable arg1) {
        if (isErrorEnabled()) {
            delegate.error(cleanMessage(arg0), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(String arg0) {
        if (isErrorEnabled()) {
            delegate.error(cleanMessage(arg0));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName() {
        return delegate.getName();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(Marker arg0, String arg1, Object arg2, Object arg3) {
        if (isInfoEnabled(arg0)) {
            delegate.info(arg0, cleanMessage(arg1), cleanMessage(arg2), cleanMessage(arg3));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(Marker arg0, String arg1, Object... arg2) {
        if (isInfoEnabled(arg0)) {
            delegate.info(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(Marker arg0, String arg1, Object arg2) {
        if (isInfoEnabled(arg0)) {
            delegate.info(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(Marker arg0, String arg1, Throwable arg2) {
        if (isInfoEnabled(arg0)) {
            delegate.info(arg0, cleanMessage(arg1), arg2);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(Marker arg0, String arg1) {
        if (isInfoEnabled(arg0)) {
            delegate.info(cleanMessage(arg1), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(String arg0, Object arg1, Object arg2) {
        if (isInfoEnabled()) {
            delegate.info(cleanMessage(arg0), cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(String arg0, Object... arg1) {
        if (isInfoEnabled()) {
            delegate.info(cleanMessage(arg0), cleanMessages(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(String arg0, Object arg1) {
        if (isInfoEnabled()) {
            delegate.info(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(String arg0, Throwable arg1) {
        if (isInfoEnabled()) {
            delegate.info(cleanMessage(arg0), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void info(String arg0) {
        if (isInfoEnabled()) {
            delegate.info(cleanMessage(arg0));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isDebugEnabled() {
        return delegate.isDebugEnabled();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isDebugEnabled(Marker arg0) {
        return delegate.isDebugEnabled(arg0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isErrorEnabled() {
        return delegate.isErrorEnabled();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isErrorEnabled(Marker arg0) {
        return delegate.isErrorEnabled(arg0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isInfoEnabled() {
        return delegate.isInfoEnabled();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isInfoEnabled(Marker arg0) {
        return delegate.isInfoEnabled(arg0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isTraceEnabled() {
        return delegate.isTraceEnabled();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isTraceEnabled(Marker arg0) {
        return delegate.isTraceEnabled(arg0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isWarnEnabled() {
        return delegate.isWarnEnabled();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isWarnEnabled(Marker arg0) {
        return delegate.isWarnEnabled(arg0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(Marker arg0, String arg1, Object arg2, Object arg3) {
        if (isTraceEnabled(arg0)) {
            delegate.trace(arg0, cleanMessage(arg1), cleanMessage(arg2), cleanMessage(arg3));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(Marker arg0, String arg1, Object... arg2) {
        if (isTraceEnabled(arg0)) {
            delegate.trace(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(Marker arg0, String arg1, Object arg2) {
        if (isTraceEnabled(arg0)) {
            delegate.trace(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(Marker arg0, String arg1, Throwable arg2) {
        if (isTraceEnabled(arg0)) {
            delegate.trace(arg0, cleanMessage(arg1), arg2);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(Marker arg0, String arg1) {
        if (isTraceEnabled(arg0)) {
            delegate.trace(arg0, cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(String arg0, Object arg1, Object arg2) {
        if (isTraceEnabled()) {
            delegate.trace(cleanMessage(arg0), cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(String arg0, Object... arg1) {
        if (isTraceEnabled()) {
            delegate.trace(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(String arg0, Object arg1) {
        if (isTraceEnabled()) {
            delegate.trace(cleanMessage(arg0), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(String arg0, Throwable arg1) {
        if (isTraceEnabled()) {
            delegate.trace(cleanMessage(arg0), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void trace(String arg0) {
        if (isTraceEnabled()) {
            delegate.trace(cleanMessage(arg0));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(Marker arg0, String arg1, Object arg2, Object arg3) {
        if (isWarnEnabled(arg0)) {
            delegate.warn(arg0, cleanMessage(arg1), cleanMessage(arg2), cleanMessage(arg3));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(Marker arg0, String arg1, Object... arg2) {
        if (isWarnEnabled(arg0)) {
            delegate.warn(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(Marker arg0, String arg1, Object arg2) {
        if (isWarnEnabled(arg0)) {
            delegate.warn(arg0, cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(Marker arg0, String arg1, Throwable arg2) {
        if (isWarnEnabled(arg0)) {
            delegate.warn(arg0, cleanMessage(arg1), arg2);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(Marker arg0, String arg1) {
        if (isWarnEnabled(arg0)) {
            delegate.warn(arg0, cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(String arg0, Object arg1, Object arg2) {
        if (isWarnEnabled()) {
            delegate.warn(cleanMessage(arg0), cleanMessage(arg1), cleanMessage(arg2));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(String arg0, Object... arg1) {
        if (isWarnEnabled()) {
            delegate.warn(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(String arg0, Object arg1) {
        if (isWarnEnabled()) {
            delegate.warn(cleanMessage(arg0), cleanMessage(arg1));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(String arg0, Throwable arg1) {
        if (isWarnEnabled()) {
            delegate.warn(cleanMessage(arg0), arg1);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void warn(String arg0) {
        if (isWarnEnabled()) {
            delegate.warn(cleanMessage(arg0));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void error(String arg0, Object... arg1) {
        if (isErrorEnabled()) {
            delegate.error(cleanMessage(arg0), cleanMessages(arg1));
        }
    }
}
