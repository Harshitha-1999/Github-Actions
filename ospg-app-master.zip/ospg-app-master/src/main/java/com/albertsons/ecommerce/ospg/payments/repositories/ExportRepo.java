package com.albertsons.ecommerce.ospg.payments.repositories;

import com.albertsons.ecommerce.ospg.payments.model.response.ECHOResponse;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

@Repository
public interface ExportRepo extends R2dbcRepository<ECHOResponse, Long> {

    @Query("SELECT top 1 tkn.card_holder_nm, tkn.token_nbr,tkn.STORE_ID, tkn.ORDER_ID, tkn.last_update_user_id, tkn.CARD_EXPIRY_DT, trn.PROVIDER_TRANSACTION_ID, trn.transaction_amt, trn.TRANSACTION_END_TS, trn.client_ip_txt, car.card_nm, mer.merch_ref_dsc, mer.banner_name, mer.merch_ref_nm, resp.BANK_RESPONSE_CD, resp.BANK_RESPONSE_TXT, resp.TRANSACTION_RESPONSE_ID, resp.LAST_UPDATE_TS \n" +
            "FROM [OSPGPAYTX].[TRANSACTION_TOKEN] tkn\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION] trn ON\n" +
            "tkn.transaction_token_id = trn.transaction_token_id\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] resp ON\n" +
            "tkn.transaction_token_id = resp.transaction_token_id\n" +
            "JOIN [OSPGPAYTX].[MERCH_REF_TYP] mer ON\n" +
            "trn.MERCH_REF_TYP_CD = mer.MERCH_REF_TYP_CD\n" +
            "JOIN [OSPGPAYTX].[CARD_TYP] car ON\n" +
            "tkn.CARD_TYP_CD = car.CARD_TYP_CD\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_TYP] tty ON\n" +
            "tty.transaction_typ_cd = trn.transaction_typ_cd\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_STATUS_TYP] tst ON\n" +
            "tst.transaction_stat_typ_cd = trn.transaction_stat_typ_cd\n" +
            "WHERE\n" +
            "tty.transaction_nm in ('purchase', 'capture') \n" +
            "AND tkn.transaction_token_id is not null\n" +
            "AND resp.bank_response_cd =:bankResponseCd \n" +
            "AND tst.transaction_status_nm = :transactionStatNm \n" +
            "AND tkn.STORE_ID = :storeId \n" +
            "AND tkn.ORDER_ID = :orderId \n")
    public Mono<ECHOResponse> exportPurchaseOrCaptureData(String bankResponseCd, String transactionStatNm, BigDecimal storeId, String orderId);

    @Query("SELECT top 1 tkn.card_holder_nm, tkn.token_nbr,tkn.STORE_ID, tkn.ORDER_ID, tkn.last_update_user_id, tkn.CARD_EXPIRY_DT, trn.PROVIDER_TRANSACTION_ID, trn.transaction_amt, trn.TRANSACTION_END_TS, trn.client_ip_txt, car.card_nm, mer.merch_ref_dsc, mer.banner_name, mer.merch_ref_nm, resp.BANK_RESPONSE_CD, resp.BANK_RESPONSE_TXT, resp.TRANSACTION_RESPONSE_ID, resp.LAST_UPDATE_TS \n" +
            "FROM [OSPGPAYTX].[TRANSACTION_TOKEN] tkn\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION] trn ON\n" +
            "tkn.transaction_token_id = trn.transaction_token_id\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] resp ON\n" +
            "tkn.transaction_token_id = resp.transaction_token_id\n" +
            "JOIN [OSPGPAYTX].[MERCH_REF_TYP] mer ON\n" +
            "trn.MERCH_REF_TYP_CD = mer.MERCH_REF_TYP_CD\n" +
            "JOIN [OSPGPAYTX].[CARD_TYP] car ON\n" +
            "tkn.CARD_TYP_CD = car.CARD_TYP_CD\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_TYP] tty ON\n" +
            "tty.transaction_typ_cd = trn.transaction_typ_cd\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_STATUS_TYP] tst ON\n" +
            "tst.transaction_stat_typ_cd = trn.transaction_stat_typ_cd\n" +
            "WHERE\n" +
            "tkn.transaction_token_id is not null\n" +
            "AND resp.bank_response_cd =:bankResponseCd \n" +
            "AND tst.transaction_status_nm = :transactionStatNm \n" +
            "AND tkn.STORE_ID = :storeId \n" +
            "AND tkn.ORDER_ID = :orderId \n")
    public Mono<ECHOResponse> exportData(String bankResponseCd, String transactionStatNm, BigDecimal storeId, String orderId);

    @Query("SELECT top 1 tkn.card_holder_nm, tkn.token_nbr,tkn.STORE_ID, tkn.ORDER_ID, tkn.last_update_user_id, tkn.CARD_EXPIRY_DT, trn.PROVIDER_TRANSACTION_ID, trn.transaction_amt, trn.TRANSACTION_END_TS, trn.client_ip_txt, car.card_nm, mer.merch_ref_dsc, mer.banner_name, mer.merch_ref_nm, resp.BANK_RESPONSE_CD, resp.BANK_RESPONSE_TXT, resp.TRANSACTION_RESPONSE_ID, resp.LAST_UPDATE_TS \n" +
            "FROM [OSPGPAYTX].[TRANSACTION_TOKEN] tkn\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION] trn ON\n" +
            "tkn.transaction_token_id = trn.transaction_token_id\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] resp ON\n" +
            "tkn.transaction_token_id = resp.transaction_token_id\n" +
            "JOIN [OSPGPAYTX].[MERCH_REF_TYP] mer ON\n" +
            "trn.MERCH_REF_TYP_CD = mer.MERCH_REF_TYP_CD\n" +
            "JOIN [OSPGPAYTX].[CARD_TYP] car ON\n" +
            "tkn.CARD_TYP_CD = car.CARD_TYP_CD\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_TYP] tty ON\n" +
            "tty.transaction_typ_cd = trn.transaction_typ_cd\n" +
            "JOIN [OSPGPAYTX].[TRANSACTION_STATUS_TYP] tst ON\n" +
            "tst.transaction_stat_typ_cd = trn.transaction_stat_typ_cd\n" +
            "WHERE\n" +
            "tty.transaction_nm =:transactionNm \n" +
            "AND tkn.transaction_token_id is not null\n" +
            "AND resp.bank_response_cd =:bankResponseCd \n" +
            "AND tst.transaction_status_nm = :transactionStatNm \n" +
            "AND tkn.STORE_ID = :storeId \n" +
            "AND tkn.ORDER_ID = :orderId \n")
    public Mono<ECHOResponse> exportAuthorizeData(String transactionNm, String bankResponseCd, String transactionStatNm, BigDecimal storeId, String orderId);

}
