package com.albertsons.ecommerce.ospg.payments.constants;

public class GatewayConstants {

	public static final String NONCE = "nonce";
	public static final String APIKEY = "apikey";
	public static final String APISCRT = "pzsecret";
	public static final String TOKEN = "token";
	public static final String TIMESTAMP = "timestamp";
	public static final String AUTHORIZE = "Authorization";
	public static final String PAYLOAD = "payload";

	public static final String TRANSACTION_TYPE = "transaction_type";
	public static final String TRANSACTION_TAG = "transaction_tag";
	public static final String AMOUNT = "amount";
	public static final String CREDIT_CARD = "credit_card";
	public static final String CVV = "cvv";
	public static final String ZIP_POSTAL_CODE = "zip_postal_code";
	public static final String COUNTRY = "country";
	public static final String BILLING_ADDRESS = "billing_address";
	public static final String TOKEN_DATA_VALUE = "token_data : value";
	public static final String CARDHOLDER_NAME = "cardholder_name";
	public static final String EXP_DATE = "exp_date";
	public static final String ORDERID = "orderId";
	public static final String STOREID = "storeId";
	public static final String CLIENTIP = "clientIP";
	public static final String TRANSACTION_ID = "transaction_id";
	public static final String TOKEN_METHOD = "token";
	public static final String TOKEN_DATA_TYPE = "token_data : type";
	public static final String MERCHANT_REF = "merchantRef";
	public static final String TOKEN_TYPE = "token : type";
	public static final String METHOD = "method";
	public static final String CURRENCY_CODE = "currency";
	public static final String DEFAULT_COUNTRY_US = "US";
	public static final String DEFAULT_CURRENCY_CODE = "USD";
	public static final String DEFAULT_TOKEN = "FDToken";
	public static final String DEAFULT_CLIENTIP = "127.0.0.1";

	public static final String TRUE = "true";
	public static final String FALSE = "false";

	public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
	public static final String CONNECTIVITY_ERROR = "Connection Timed out";
	public static final String SERVER_ERROR = "Internal Server Error while making the payeezy call";
	public static final String DATABASE_ERROR = "Database Error while saving data";
	public static final String DUPLICATE_TRANSACTION_EXCEPTION = "Duplicate Transaction Exception";
	public static final String CARD_TYPE_FETCH_EXCEPTION = "Unable to fetch Card type";
	public static final String LOOKUP_VALUE_FETCH_EXCEPTION = "Error While fetching the look up value :";
	public static final String GENERIC_ERROR_RESPONSE_CODE = "S100";
	public static final long GENERIC_VALIDATION_RESPONSE_CODE = 3;

	public static final String SOURCE = "source";
	public static final String TRANSACTION_STATUS_APPROVED = "approved";

	public static final String ONE_DOLLAR_AUTH = "1";
	public static final String TRANSACTION_STATUS_NOT_PROCESSED = "Not Processed";
	public static final String MERCHANT_LOOKUP_VALUE_FETCH_EXCEPTION = "Error while fetching the look up MID value in merchant ref table for Store ID: ";
	public static final String STORE_NOT_ELIGIBLE_FOR_FULL_AUTH = "Store ID passed is not eligible for full auth";

	public static final String OSPG = "OSPG";
	
	// Subscription
	public static final String SUBSCRIPTION_STORE_ID="9999";
	
	// Stored Credentials
	public static final String STORED_CRED_AMEX_OFF_SCHEDULE = "X";
	public static final String STORED_CRED_DUMMY_ORIG_TRANS_ID_AMEX = "999999";
	public static final String STORED_CRED_DUMMY_ORIG_TRANS_ID_MC = "888888";

	// Caches defined
	public static final String FULL_AUTH_STORE_CACHE = "FULL_AUTH_STORE_CACHE";
	public static final String STORED_CRED_STORE_CACHE = "STORED_CRED_STORE_CACHE";
	public static final String MERCH_REF_TYP_CACHE = "MERCH_REF_TYP_CACHE";
	public static final String CARD_TYP_CACHE = "CARD_TYP_CACHE";
	public static final String ERROR_TYP_CACHE = "ERROR_TYP_CACHE";
	public static final String TOKEN_TYP_CACHE = "TOKEN_TYP_CACHE";
	public static final String TRANSACTION_TYP_CACHE = "TRANSACTION_TYP_CACHE";
	public static final String TRANSACTION_STATUS_TYP_CACHE = "TRANSACTION_STATUS_TYP_CACHE";
	public static final String VALIDATION_STATUS_TYP_CACHE = "VALIDATION_STATUS_TYP_CACHE";

	public static final String CLIENT_TOKEN = "CLIENT_TOKEN";
	public static final String ENCRYPTED_DATA = "ENCRYPTED_DATA";
	public static final String FEATURE_FLAG_CACHE = "FEATURE_FLAG_CACHE";
	public static final String CHASE_ORBITAL_URL = "CHASE_ORBITAL_URL";
	public static final String PRIMARY_CHASE_ORBITAL_URL = "PRIMARY";
	public static final String SECONDARY_CHASE_ORBITAL_URL = "SECONDARY";
	public static final String PROC_STATUS_CODE = "PROC_STATUS_CODE";
	public static final String SWITCH_CHASE_OUTAGE = "SWITCH_CHASE_OUTAGE";
	public static final String ENABLE = "ENABLE";
	public static final String DISABLE = "DISABLE";

}
