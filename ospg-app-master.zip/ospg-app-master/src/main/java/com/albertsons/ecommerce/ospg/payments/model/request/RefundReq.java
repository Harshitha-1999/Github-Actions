package com.albertsons.ecommerce.ospg.payments.model.request;

import com.albertsons.ecommerce.ospg.payments.model.Merchant;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.PaymentInstrument;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundReq extends ChaseRequest {
    private String version;
    private Merchant merchant;
    private PaymentInstrument paymentInstrument;
    private Order order;
}
