package com.albertsons.ecommerce.ospg.payments.config;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionCacheLoaderDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Slf4j
@Configuration
@EnableScheduling
public class SchedulerConfig {

    @Value("#{new Boolean('${fullAuthStoreLoadEnabled:true}')}")
    private boolean fullAuthStoreLoadEnabled;

    @Value("#{new Boolean('${storedCredStoreLoadEnabled:true}')}")
    private boolean storedCredStoreLoadEnabled;

    @Value("#{new Boolean('${merchRefTypLoadEnable:true}')}")
    private boolean merchRefTypLoadEnabled;

    @Value("#{new Boolean('${cardTypLoadEnabled:true}')}")
    private boolean cardTypLoadEnabled;

    @Value("#{new Boolean('${tokenTypLoadEnabled:true}')}")
    private boolean tokenTypLoadEnabled;

    @Value("#{new Boolean('${errorTypLoadEnabled:true}')}")
    private boolean errorTypLoadEnabled;

    @Value("#{new Boolean('${transactionTypLoadEnabled:true}')}")
    private boolean transactionTypLoadEnabled;

    @Value("#{new Boolean('${transactionStatusTypLoadEnabled:true}')}")
    private boolean transactionStatusTypLoadEnabled;

    @Value("#{new Boolean('${validationStatusTypLoadEnabled:true}')}")
    private boolean validationStatusTypLoadEnabled;

    @Value("#{new Boolean('${featureFlagLoadEnabled:true}')}")
    private boolean featureFlagLoadEnabled;

    @Autowired
    CacheManager cacheManager;

    @Autowired
    TransactionCacheLoaderDao transactionCacheLoaderDao;

    // Time in milliseconds before triggering loadAll to refresh cache
    @Scheduled(fixedDelayString = "${fullAuthStoreCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshFullAuthStoreCache() {
        if (fullAuthStoreLoadEnabled) {
            log.info("refreshFullAuthStoreCache() >> refreshLinkedAuthStoreCache are being refreshed.....");
            transactionCacheLoaderDao.loadFullAuthStoreTyp(cacheManager.getCache(GatewayConstants.FULL_AUTH_STORE_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${storedCredStoreCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshStoredCredStoreCache() {
        if (storedCredStoreLoadEnabled) {
            log.info("refreshStoredCredStoreCache() >> refreshStoredCredStoreCache is being refreshed.....");
            transactionCacheLoaderDao.loadStoredCredStoreTyp(cacheManager.getCache(GatewayConstants.STORED_CRED_STORE_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${merchRefTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshMerchRefTypCache() {
        if (merchRefTypLoadEnabled) {
            log.info("refreshMerchRefTypCache() >> refreshMerchRefTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadMerchRefTyp(cacheManager.getCache(GatewayConstants.MERCH_REF_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${cardTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshCardTypCache() {
        if (cardTypLoadEnabled) {
            log.info("refreshCardTypCache() >> refreshCardTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadCardTyp(cacheManager.getCache(GatewayConstants.CARD_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${tokenTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshTokenTypCache() {
        if (tokenTypLoadEnabled) {
            log.info("refreshTokenTypCache() >> refreshTokenTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadTokenTyp(cacheManager.getCache(GatewayConstants.TOKEN_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${errorTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshErrorTypCache() {
        if (errorTypLoadEnabled) {
            log.info("refreshErrorTypCache() >> refreshErrorTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadErrorTyp(cacheManager.getCache(GatewayConstants.ERROR_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${transactionTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshTransactionTypCache() {
        if (transactionTypLoadEnabled) {
            log.info("refreshTransactionTypCache() >> refreshTransactionTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadTransactionTyp(cacheManager.getCache(GatewayConstants.TRANSACTION_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${transactionStatusTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshTransactionStatusTypCache() {
        if (transactionStatusTypLoadEnabled) {
            log.info("refreshTransactionStatusTypCache() >> refreshTransactionStatusTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadTransactionStatusTyp(
                    cacheManager.getCache(GatewayConstants.TRANSACTION_STATUS_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${validationStatusTypCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshValidationStatusTypCache() {
        if (validationStatusTypLoadEnabled) {
            log.info("refreshValidationStatusTypCache() >> refreshValidationStatusTypCache is being refreshed.....");
            transactionCacheLoaderDao.loadValidationStatusTyp(
                    cacheManager.getCache(GatewayConstants.VALIDATION_STATUS_TYP_CACHE));
        }
    }

    @Scheduled(fixedDelayString = "${featureFlagCacheRefreshRate:21600000}",
            initialDelayString = "${initialCacheRefreshRateDelay:300000}")
    public void refreshFeatureFlagsCache() {
        if (featureFlagLoadEnabled) {
            log.info("refreshFeatureFlagsCache() >> refreshFeatureFlagsCache is being refreshed.....");
            loadFeatureFlags();
        }
    }

    public void loadFeatureFlags() {
        transactionCacheLoaderDao.loadFeatureFlags(cacheManager.getCache(GatewayConstants.FEATURE_FLAG_CACHE));
    }

   public void loadProcStatusCodes() {
        transactionCacheLoaderDao.loadProcStatusCode(cacheManager.getCache(GatewayConstants.PROC_STATUS_CODE));
    }
}
