package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Profile implements Serializable {
    private String addProfileFromOrder;
    private String customerRefNum;
    private String profileOrderOverideInd;
    private String customerName;
    private String customerEmail;
    private String customerPhone;
    private String accountUpdaterEligibility;
    private String profileProcStatus;
    private String profileProcStatusMsg;
    private String profileAction;
    private String customerAddress1;
    private String customerAddress2;
    private String customerCity;
    private String customerState;
    private String customerZIP;
    private String customerCountryCode;
    private Status status;
    private String customerProfileAction;
    private String scheduledDate;
}
