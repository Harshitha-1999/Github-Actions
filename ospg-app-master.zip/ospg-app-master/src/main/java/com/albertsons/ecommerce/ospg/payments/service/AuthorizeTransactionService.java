package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.entity.TransactionDetails;
import com.albertsons.ecommerce.ospg.payments.enumerations.*;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.exceptions.PreAuthFailureException;
import com.albertsons.ecommerce.ospg.payments.exceptions.UserBlockedException;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.external.TokenVaultCaller;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.*;
import com.albertsons.ecommerce.ospg.payments.model.request.MerchantInitiatedTransaction;
import com.albertsons.ecommerce.ospg.payments.model.request.PreAuthRequest;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ErrorResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.PreauthResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.StoredCredentialResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;
import com.albertsons.ecommerce.ospg.payments.util.ResponseCodeUtil;
import com.albertsons.ecommerce.ospg.payments.util.TransactionCacheUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.ssl.SslHandshakeTimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.PrematureCloseException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.*;

/**
 * @author MSUND21
 */

@Service
public class AuthorizeTransactionService implements IAuthorizeTransactionService {

    @Autowired
    private ChaseCaller caller;

    @Autowired
    private TokenVaultCaller tokenVaultCaller;

    @Value("${chase.preauth.url}")
    private String preauthChaseUrl;

    @Value("${token.vault.fetch.tokens.uri}")
    private String fetchBatchTokensUrl;

    @Autowired
    private TransactionsDAO transactionsDAO;

    @Autowired
    private TransactionCacheUtils cacheUtils;

    @Autowired
    private PaymentGatewayServiceHelper serviceHelper;

    @Autowired
    private ErrorHandlingService errorHandlingService;

    @Autowired
    CommonService commonService;

    @Loggable
    private SecurityLogger log;

    /**
     * This method will call the chase url to make preauth
     *
     * @param request
     * @return Mono<PreauthResponse>
     */
    @Override
    public Mono<TransactionResponse> preauth(TransactionRequest request) {
        log.info("preauth() >> for order id : {} , client request : {}", request.getOrderId() , serviceHelper.getJsonPayload(request));
        try {
            log.info("preauth() >> for order id : {} , switch chase outage flag {}", request.getOrderId(), commonService.isChaseOutageEnabled());

            if (commonService.isChaseOutageEnabled()) {
                OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.AUTHORIZE;
                return errorHandlingService.sendAuthFailureToAccumulator(request, ospgTransactionCategory, errorHandlingService.getDummyAuthResponse(), new Exception(CHASE_OUTAGE_MESSAGE));
            }
            return callChase(request);
        } catch (Exception e) {
            log.error("preauth() >> Preauth failed for order id: "+request.getOrderId()+" , store id: "+request.getStoreId()+", exception : ", e);
        }
        return null;
    }

    public Mono<TransactionResponse> preAuthAndCapture(TransactionRequest request){
        log.info("preAuthAndCapture() >> calling AC for order id: {} , client request: {}",request.getOrderId(),serviceHelper.getJsonPayload(request));
        request.setTransactionType(TransactionType.PURCHASE.name());
        PreAuthRequest preauthRequest = buildChasePreAuthRequest(request, true);
        preauthRequest.setTransType(Constants.CHASE_AUTHORIZE_CAPTURE);
        preauthRequest.getOrder().setRetryTrace(PaymentUtil
                .buildRetryTrace(request.getOrderId(),
                        Constants.PURCHASE_RETRY_TRACE_CONSTANT));

        if(request.getStoreId().equals(Constants.SUBCRIPTION_STORE_ID)) {
            String cardType = request.getToken().getTokenData().getType();
            if(StringUtils.hasText(cardType) && cardType.equals("MC")) {
                MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsPurchaseSubscription.get(cardType);
                preauthRequest.setMerchantInitiatedTransaction(merchantInitiatedTransaction);
                //}else if(request.getCardBrandOriginalTransactionId() != null) {
            } else {
                if (StringUtils.hasText(request.getCardBrandOriginalTransactionId())) {
                    log.info("preAuthAndCapture() >> cardBrandOriginalTransactionId: {}, cardType: {}", request.getCardBrandOriginalTransactionId(), cardType);
                    buildStoreCredentalsForSubscriptionPurchase(request.getCardBrandOriginalTransactionId(), preauthRequest, cardType);
                    return processPreAuthAndCapture(request, preauthRequest);
                }
                return fetchMitReceivedTranIdByToken(request).flatMap(r -> {
                    log.info("preAuthAndCapture(),  r.getMitReceivedTransactionId(): {}, tokenData: {}",
                            r.getMitReceivedTransactionId(), request.getToken().getTokenData().getValue());
                    if (StringUtils.hasText(r.getMitReceivedTransactionId())) {
                        log.info("preAuthAndCapture() >> r.getMitReceivedTransactionId(): {}, cardType: {}", r.getMitReceivedTransactionId(), cardType);
                        buildStoreCredentalsForSubscriptionPurchase(r.getMitReceivedTransactionId(), preauthRequest, cardType);
                    } else {
                        log.info("preAuthAndCapture() >> SET MIT TYPE CREC, tokenData:{}", request.getToken().getTokenData().getValue());
                        MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsSubscription.get(cardType);
                        //merchantInitiatedTransaction.setMitMsgType("CREC");
                        preauthRequest.setMerchantInitiatedTransaction(merchantInitiatedTransaction);
                    }
                    return processPreAuthAndCapture(request, preauthRequest);
                }).switchIfEmpty(Mono.defer(() -> {
                    log.info("preAuthAndCapture() switchIfEmpty >> SET MIT TYPE CREC, tokenData:{}", request.getToken().getTokenData().getValue());
                    MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsSubscription.get(cardType);
                    //merchantInitiatedTransaction.setMitMsgType("CREC");
                    preauthRequest.setMerchantInitiatedTransaction(merchantInitiatedTransaction);
                    return processPreAuthAndCapture(request, preauthRequest);
                }));
            }
        } else {
    		String cardType = request.getToken().getTokenData().getType();
            MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsPurchaseShop.get(cardType);
            String providedTransactionId = request.getTransactionId();
            if(null == providedTransactionId) {
                log.info("preAuthAndCapture() >> SET MIT TYPE CGEN, OrderId: {}", request.getOrderId());
                if(StringUtils.hasText(cardType)){
                    merchantInitiatedTransaction.setMitMsgType("CGEN");
                    preauthRequest.setMerchantInitiatedTransaction(merchantInitiatedTransaction);
                }
            } else {
                log.info("preAuthAndCapture() >> getTransactionIdFromTokenVault, OrderId: {}, MitReceivedTransactionId: {}"
                        , request.getOrderId(), request.getMitReceivedTransactionId());

                if(StringUtils.hasText(request.getMitReceivedTransactionId())) {
                    setMerchIntTx(request.getMitReceivedTransactionId(), preauthRequest, merchantInitiatedTransaction);
                    return doAC(preauthRequest, request);
                } else {
                    return getMitReceivedTranId(request)
                        .flatMap(r -> {
                            log.info("preAuthAndCapture() >> getTransactionIdFromTokenVault, OrderId: {}, MitReceivedTransactionId: {}"
                                    , request.getOrderId(), r.getMitReceivedTransactionId());
                            setMerchIntTx(r.getMitReceivedTransactionId(), preauthRequest, merchantInitiatedTransaction);
                            return doAC(preauthRequest, request);
                        }).switchIfEmpty(Mono.defer(() -> {
                            return getTransactionIdFromTokenVault(request.getCustomerId())
                                .flatMap(res -> {
                                    log.info("preAuthAndCapture() >> getTransactionIdFromTokenVault, OrderId: {}, OriginalTransactionId: {}"
                                            , request.getOrderId(), res);
                                    setMerchIntTx(res, preauthRequest, merchantInitiatedTransaction);
                                    return doAC(preauthRequest, request);
                                }).onErrorResume(error ->{
                                    preauthRequest.setMerchantInitiatedTransaction(null);
                                    return doAC(preauthRequest, request);
                                });
                        }));
                }
            }
        }
        return processPreAuthAndCapture(request, preauthRequest);
    }

    private void setMerchIntTx(String merchIntTxId, PreAuthRequest preauthRequest, MerchantInitiatedTransaction merchantInitiatedTransaction) {
        try {
            if(merchantInitiatedTransaction != null) {
                MerchantInitiatedTransaction merchInttxClone = new MerchantInitiatedTransaction();
                String objStr = serviceHelper.getJsonPayload(merchantInitiatedTransaction);
                merchInttxClone = serviceHelper.convertJsonToMerchIntTx(objStr);
                if (StringUtils.hasText(merchIntTxId))
                    merchInttxClone.setMitSubmittedTransactionID(merchIntTxId);
                preauthRequest.setMerchantInitiatedTransaction(merchInttxClone);
            }
        }catch(Exception ex){
            log.error("setMerchIntTx() >> order: {} error: ", serviceHelper.getJsonPayload(preauthRequest), ex);
        }
    }

    private void buildStoreCredentalsForSubscriptionPurchase(String cardBrandOriginalTransactionId, PreAuthRequest preauthRequest, String cardType) {
        MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsPurchaseSubscription.get(cardType);
        setMerchIntTx(cardBrandOriginalTransactionId, preauthRequest, merchantInitiatedTransaction);
        log.info("preAuthAndCapture() >> merchantInitiatedTransaction: {}", serviceHelper.getJsonPayload(merchantInitiatedTransaction));
        preauthRequest.getOrder().setIndustryType(INDUSTRY_TYPE_MREC);
    }

    public Mono<String> getTransactionIdFromTokenVault(String guid) {
        log.info("getTransactionIdFromTokenVault() >> guid: {}",guid);
        TenderDeclineRequest tenderReq = new TenderDeclineRequest();
        tenderReq.setType(TENDER_TYPE_CREDIT_CARD);
        tenderReq.setPrimaryPurpose(TENDER_PRIMARY_PURPOSES);
        List<String> customerId = new ArrayList<>();
        customerId.add(guid);
        tenderReq.setCustomerIds(customerId);
        Mono<String> originalTransactionId = fetchTenderFromTokenVault(tenderReq);
        return originalTransactionId;
    }

    private Mono<TransactionResponse> processPreAuthAndCapture(TransactionRequest request, PreAuthRequest preauthRequest) {
        return caller.callChaseService(preauthRequest, request.getStoreId(), request.getSellerId(), preauthChaseUrl)
                .bodyToMono(PreauthResponse.class)
                .map(resp ->{
                    log.info("processPreAuthAndCapture() >> AC Resp: {}",serviceHelper.getJsonPayload(resp));
                    return buildResponse(request, resp);
                })
                .doOnSuccess(result -> {
                    transactionsDAO.saveSuccessTransaction(request, result);
                    //Defect: OCM-61
                    if (result != null && result.getToken() != null && result.getToken().getTokenData() != null) {
                        result.getToken().getTokenData().setCvv(null);
                    }
                }).flatMap(response -> {
                    return Mono.just(response);
                }).onErrorResume(error -> {
                    return errorHandlingService.handlePurchaseErrors(error, request);
                });
    }

    private Mono<TransactionResponse> doAC(PreAuthRequest preauthRequest, TransactionRequest request){
    	
    	log.info("doAC() >> Doing AC");
    	return caller.callChaseService(preauthRequest, request.getStoreId(), request.getSellerId(), preauthChaseUrl)
				.bodyToMono(PreauthResponse.class)
				.map(resp ->{
					log.info("doAC() >> AC Resp: {}", serviceHelper.getJsonPayload(resp));
					return buildResponse(request, resp);
				})
				.doOnSuccess(result -> {
					transactionsDAO.saveSuccessTransaction(request, result);
		            if (result != null && result.getToken() != null && result.getToken().getTokenData() != null) {
		                result.getToken().getTokenData().setCvv(null);
		            }
				});
	}

    public Mono<TransactionDetails> getMitReceivedTranId(TransactionRequest request) {
       return transactionsDAO.fetchMitReceivedTranId(request);
    }


    public Mono<TransactionDetails> fetchMitReceivedTranIdByToken(TransactionRequest request) {
        return transactionsDAO.fetchMitReceivedTranIdByToken(request);
    }

    private Mono<String> fetchTenderFromTokenVault(TenderDeclineRequest tenderReq) {
        return tokenVaultCaller.callTokenVaultService(tenderReq, fetchBatchTokensUrl, null)
                .bodyToMono(new ParameterizedTypeReference<List<GetTenderResponse>>() {})
                .flatMap( res -> {
                	log.info("fetchTenderFromTokenVault() >> getTender response ");
                    return Mono.just(getMITValue(res));
                })
                .onErrorResume(error -> {
                	log.error("fetchTenderFromTokenVault() >> While processing preauth, failed to fetch token from tokenvault service with error: ", error);
                    return Mono.error(error);
                	//return Mono.just("");
                });
    }

    private String getMITValue(List<GetTenderResponse> res) {
        String originalTransactionId=null;
        if(!CollectionUtils.isEmpty(res)
                && res.get(0) != null
                &&  res.get(0).getTenders() != null
                &&  res.get(0).getTenders().get() != null
                && !((List<Tender>) res.get(0).getTenders().get()).isEmpty()
                && ((List<Tender>) res.get(0).getTenders().get()).get(0) != null) {
            originalTransactionId = ((List<Tender>) res.get(0).getTenders().get()).get(0).getOriginalTransactionId();
        }
       log.info("buildResponse() >> originalTransactionId: {}",originalTransactionId);
       return StringUtils.isEmpty(originalTransactionId) ? "" :  originalTransactionId;
    }

    public Mono<TransactionResponse> incrementalAuth(TransactionRequest request) {
        log.info("incrementalAuth() >> order id: {}  request: {} ", request.getOrderId(), serviceHelper.getJsonPayload(request));
        request.setTransactionType(Constants.AUTHORIZE);
        PreAuthRequest preAuthReq = buildChasePreAuthRequest(request, false);
        preAuthReq.setTransType(Constants.CHASE_AUTHORIZE);

        log.info("incrementalAuth() order id: {},  MitReceivedTransactionId: {}", request.getOrderId(), request.getMitReceivedTransactionId());
        if(StringUtils.hasText(request.getMitReceivedTransactionId())) {
            MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsIncrementalAuth.get("VI");
            setMerchIntTx(request.getMitReceivedTransactionId(), preAuthReq, merchantInitiatedTransaction);
            return callChaseService(preAuthReq, request);
        }else{
            return getTransactionIdFromTokenVaultIncrementalAuth(preAuthReq, request, request.getCustomerId());
        }
    }

    private Mono<TransactionResponse> callChase(TransactionRequest request) {
        log.info("callChase() >> orderId: {} , store id: {}" , request.getOrderId(),request.getStoreId());
        return caller.callChaseService(buildChasePreAuthRequest(request, true),
                request.getStoreId(), request.getSellerId(), preauthChaseUrl)
                .bodyToMono(PreauthResponse.class)
                .flatMap(resp -> {
                    return validateAndUpdateCvv(request, resp);
                   // return Mono.just(buildTransactionResponse(resp, request));
                })
                .onErrorResume(error -> {
                    return handlePreAuthErrors(error,request);
                }).doOnSuccess(result -> {
                    if(!Constants.DUMMY_TRANSACTION_ID.equalsIgnoreCase(result.getTransactionId())) {
                        transactionsDAO.saveSuccessTransaction(request, result);
                        if (result != null && result.getToken() != null && result.getToken().getTokenData() != null) {
                            result.getToken().getTokenData().setCvv(null);
                        }
                    }
                });
    }

    private Mono<TransactionResponse> handlePreAuthErrors(Throwable error, TransactionRequest request) {

        log.error("handlePreAuthErrors() >> Preauth failed with error response from Chase: {} for store id: {} , order id: {}", error.getMessage(), request.getStoreId(), request.getOrderId());
        OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.AUTHORIZE;
        if (error instanceof ResponseStatusException) {
            List<String> procStatusList= cacheUtils.getProcStatusCode(GatewayConstants.PROC_STATUS_CODE);
            ResponseStatusException responseStatusException = (ResponseStatusException) error;
            if (PaymentUtil.isChaseDownProcStatuses(procStatusList, responseStatusException, request)
                    || (responseStatusException.getStatus() != HttpStatus.BAD_REQUEST
                    && responseStatusException.getStatus() != HttpStatus.PRECONDITION_FAILED)) {
                log.error("handlePreAuthErrors() >> error for order id: "+request.getOrderId()+" , error status message: "+responseStatusException.getStatus().toString()+" , error: ", error);
                return errorHandlingService.sendAuthFailureToAccumulator(request, ospgTransactionCategory,errorHandlingService.getDummyAuthResponse(), error);
            } else {
                if (!StringUtils.isEmpty(request.getGuid())) {
                    log.error("handlePreAuthErrors() >> error for store id: {} , order id: {} , error message: {}", request.getStoreId(), request.getOrderId(), responseStatusException.getMessage());
                }
                return Mono.error(error);
            }
        }
        if (error instanceof PrematureCloseException) {
            PrematureCloseException prematureCloseException = (PrematureCloseException) error;
                log.error("handlePreAuthErrors() >> error for order id: "+request.getOrderId()+" , error status message: "+prematureCloseException.getMessage()+" , error: ", error);
                return errorHandlingService.sendAuthFailureToAccumulator(request, ospgTransactionCategory,errorHandlingService.getDummyAuthResponse(), error);
        }
        if (error instanceof SslHandshakeTimeoutException) {
            SslHandshakeTimeoutException sslException = (SslHandshakeTimeoutException) error;
            log.error("handlePreAuthErrors() >> error for order id: "+request.getOrderId()+" , error status message: "+sslException.getMessage()+" , error: ", error);
            return errorHandlingService.sendAuthFailureToAccumulator(request,ospgTransactionCategory,errorHandlingService.getDummyVoidResponse(),error);
        }
        if (error instanceof PreAuthFailureException) {
            throw new PreAuthFailureException(((PreAuthFailureException) error).getErrorResponse());
        }
        if (error instanceof WebClientResponseException) {
            try {
                WebClientResponseException webClientResponseException = (WebClientResponseException) error;
                log.error("handleAuthError() >> Resp Status : {}, Resp Status Mssg : {}", webClientResponseException.getStatusCode(), error.getMessage());

                if (webClientResponseException.getStatusCode() != HttpStatus.BAD_REQUEST) {
                    log.info("handleAuthError() >> Error Code : {}", webClientResponseException.getStatusCode());
                    return errorHandlingService.sendAuthFailureToAccumulator(request, ospgTransactionCategory,errorHandlingService.getDummyAuthResponse(), error);
                }
                ObjectMapper mapper = new ObjectMapper();
                ErrorResponse errorResponse = mapper.readValue(webClientResponseException.getResponseBodyAsString(),
                        ErrorResponse.class);
                throw new DataValidationException(errorResponse.getProcStatus(), errorResponse.getProcStatusMessage());
            } catch (JsonProcessingException jsonProcessingException) {
                return Mono.error(error);
            }
        } else if (error instanceof UserBlockedException || error instanceof DataValidationException) {
            return Mono.error(error);
        }
        if (error instanceof PreAuthFailureException) {
            throw new PreAuthFailureException(((PreAuthFailureException) error).getErrorResponse());
        }
        return Mono.error(error);
    }

    private PreAuthRequest buildChasePreAuthRequest(TransactionRequest request, boolean isSoftDec) {

        String transType = request.getTransactionType();

        String fourDigitccExp = request.getToken().getTokenData().getExpiryDate();
        String year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR)).substring(0,2)+fourDigitccExp.substring(2,4);
        String date = fourDigitccExp.substring(0,2);
        String ccExp = year+""+date;

        Card card = Card.builder().ccAccountNum(request.getToken().getTokenData().getValue()).ccExp(request.getToken().getTokenData().getExpiryDate()).
                    tokenTxnType(Constants.TOKEN_TXN_TYPE).cardBrand(CardBrand.getValueByKey(request.getToken().getTokenData().getType())).build();
        String amount = "";
        //check card brand to Identify DI
        if (CardBrand.DI.getKey().equals(card.getCardBrand())) {
            amount = PaymentUtil.preAuth0DollarCase(request.getAmount());
        } else {
            amount = PaymentUtil.convertDollarsToCents(request.getAmount());
        }
        Order order = Order.builder().orderID(request.getOrderId()).amount(amount).industryType(Constants.INDUSTRY_TYPE)
                .txRefNum(request.getTransactionId())
                .retryTrace(PaymentUtil.buildRetryTrace(request.getOrderId(),PREAUTH_RETRY_TRACE_CONSTANT)).build();
        CardholderVerification cardholderVerification = CardholderVerification.builder().ccCardVerifyNum(request.getToken().getTokenData().getCvv()).build();

        PaymentInstrument paymentInstrument = PaymentInstrument.builder().card(card).build();
        AvsBilling avsBilling=null;
        if (null != request.getBillingAddress()) {
            avsBilling = AvsBilling.builder().avsZip(request.getBillingAddress().getZipPostalCode()).build();
        }
        if (null != transType && transType.equalsIgnoreCase(Constants.AUTHORIZE)) {
            transType = Constants.CHASE_AUTHORIZE;
        }else if(transType == null && null != request.getSource() && request.getSource().equalsIgnoreCase(SOURCE_ERUMS)){
            transType = Constants.CHASE_AUTHORIZE;
            request.setTransactionType(Constants.AUTHORIZE);
        }
        PreAuthRequest preauthRequest = PreAuthRequest.builder()
                .version(Constants.VERSION)
                .transType(transType)
                .avsBilling(avsBilling)
                .merchant(PaymentUtil.buildMerchant())
                .order(order)
                .paymentInstrument(paymentInstrument)
                .cardholderVerification(cardholderVerification)
                .avsBilling(avsBilling).build();

        preauthRequest.getPaymentInstrument().getCard().setCcExp(ccExp);
        //Don't send softDec field for incremental auth
        if ((StringUtils.hasText(request.getSellerId()) || request.getSoftDescriptors() != null) && isSoftDec) {
            buildSoftDesc(request, preauthRequest);
        }
        //Build StoredCredential details
       // if (request.isStoredCardFlag()) {
            if (request.getStoreId().equals(Constants.SUBCRIPTION_STORE_ID)) { //If storeId is 9999 then it is subscription flow
                String cardType = request.getToken().getTokenData().getType();
                MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsSubscription.get(cardType);
                preauthRequest.setMerchantInitiatedTransaction(merchantInitiatedTransaction);
            } else {
                String cardType = request.getToken().getTokenData().getType();
                if (CardBrand.MC.getKey().equals(card.getCardBrand()) && amount.equalsIgnoreCase("0")) {
                    preauthRequest.setMerchantInitiatedTransaction(StoredCredentials.storedCredentialsShopMC.get(cardType));
                }else{
                    MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsShop.get(cardType);
                    preauthRequest.setMerchantInitiatedTransaction(merchantInitiatedTransaction);
                }
            }
      //  }
        log.info("buildChasePreAuthRequest() >> chase request : {}", serviceHelper.getJsonPayload(preauthRequest));
        return preauthRequest;
    }

    private TransactionResponse buildTransactionResponse(PreauthResponse chaseResponse, TransactionRequest transactionRequest) {
        log.info("buildTransactionResponse -> preAuth chase response : {} ", serviceHelper.getJsonPayload(chaseResponse));
        if(!checkResponseHasErrorCode(chaseResponse)){
            throw new PreAuthFailureException(chaseResponse);
        }
        String transactionStatus = Constants.NOT_PROCESSED;
        if (chaseResponse.getOrder() != null) {
            transactionStatus = ResponseCodeUtil.getTransactionStatus(chaseResponse.getOrder().getStatus());
        }

        TransactionResponse transactionResponse = TransactionResponse.builder()
                .method(transactionRequest.getMethod())
                .amount(transactionRequest.getAmount())
                .currency(transactionRequest.getCurrencyCode())
                .cvv2(chaseResponse.getCardholderVerification().getCvvRespCode())
                .token(transactionRequest.getToken())
                .transactionStatus(transactionStatus)
                .transactionType(transactionRequest.getTransactionType())
                .transactionTag(chaseResponse.getOrder().getStatus().getAuthorizationCode())
                .transactionId(chaseResponse.getOrder().getTxRefNum())
                .bankRespCode(chaseResponse.getOrder().getStatus().getHostRespCode())
                .bankMessage(chaseResponse.getOrder().getStatus().getProcStatusMessage())
                .avs(chaseResponse.getAvsBilling().getAvsRespCode())
                .validationStatus(chaseResponse.getOrder().getStatus().getProcStatus()
                        .equalsIgnoreCase(Constants.PROC_STATUS_CODE)
                        ? Constants.SUCCESS : Constants.FAILED)
                .gatewayRespCode(chaseResponse.getOrder().getStatus().getRespCode()).build();

        String indicator = "";
        if(transactionRequest.getCardBrandOriginalTransactionId() != null) {
            indicator = Constants.STORED_CRED_INDICATOR_SUBS;
        }else{
            indicator = Constants.STORED_CRED_INDICATOR;
        }
        StoredCredentialResponse storedCredentialResponse = StoredCredentialResponse.builder().
                indicator(indicator).initiator(Constants.STORED_CRED_INITIATOR)
                .schedule(Constants.STORED_CRED_SCHEDULE)
                .cardBrandOriginalTransactionId(chaseResponse.getOrder().getMitReceivedTransactionID())
                .cardBrandOriginalAmount(transactionRequest.getAmount()).build();
        transactionResponse.setStoredCredentials(storedCredentialResponse);

       log.info("buildTransactionResponse() >> preAuth client response: {}", serviceHelper.getJsonPayload(transactionResponse));
        return transactionResponse;
    }

    private boolean checkResponseHasErrorCode(PreauthResponse resp) {
        return resp != null &&
                resp.getOrder() != null &&
                resp.getOrder().getStatus() != null &&
                resp.getOrder().getStatus().getApprovalStatus() != null;
    }

    private TransactionResponse buildResponse(TransactionRequest transactionRequest, PreauthResponse chaseResponse){
    	 String transactionStatus = Constants.NOT_PROCESSED;
    	 String transactionTag=null;
       if (chaseResponse.getOrder() != null) {
            transactionStatus = ResponseCodeUtil.getTransactionStatus(chaseResponse.getOrder().getStatus());
            if (null==chaseResponse.getOrder().getStatus().getAuthorizationCode() &&
                    TransactionType.PURCHASE.name().equalsIgnoreCase(transactionRequest.getTransactionTag())) {
                transactionTag = transactionRequest.getTransactionTag();
            } else {
                transactionTag = chaseResponse.getOrder().getStatus().getAuthorizationCode();
            }
        }
        TransactionResponse transactionResponse = TransactionResponse.builder()
        .method(transactionRequest.getMethod())
        .amount(transactionRequest.getAmount())
        .currency(transactionRequest.getCurrencyCode())
        .cvv2(chaseResponse.getCardholderVerification().getCvvRespCode())
        .token(transactionRequest.getToken())
        .transactionStatus(transactionStatus)
        .validationStatus(PaymentUtil.responseStatus(chaseResponse.getOrder().getStatus().getRespCode()))
        .transactionType(transactionRequest.getTransactionType().toLowerCase())
        .transactionTag(chaseResponse.getOrder().getStatus().getAuthorizationCode())
        .transactionId(chaseResponse.getOrder().getTxRefNum())
        .bankRespCode(chaseResponse.getOrder().getStatus().getHostRespCode())
        .bankMessage(chaseResponse.getOrder().getStatus().getProcStatusMessage())
        .avs(chaseResponse.getAvsBilling().getAvsRespCode())
        .gatewayRespCode(chaseResponse.getOrder().getStatus().getRespCode()).build();

        log.info("buildResponse() >> client response for orderId: {}, preAuthAndCapture: {}",
                transactionRequest.getOrderId(), serviceHelper.getJsonPayload(transactionResponse));
        return transactionResponse;
    }

    private Mono<TransactionResponse> getTransactionIdFromTokenVaultIncrementalAuth(PreAuthRequest preAuthRequest, TransactionRequest request, String guid) {
        TenderDeclineRequest tenderReq = new TenderDeclineRequest();
        tenderReq.setType(TENDER_TYPE_CREDIT_CARD);
        tenderReq.setPrimaryPurpose(TENDER_PRIMARY_PURPOSE_SHOP);
        List<String> customerId = new ArrayList<>();
        customerId.add(guid);
        tenderReq.setCustomerIds(customerId);
        return fetchTenderFromTokenVaultIncrementalAuth(preAuthRequest, request, tenderReq);
    }

    private Mono<TransactionResponse> fetchTenderFromTokenVaultIncrementalAuth(PreAuthRequest preAuthReq, TransactionRequest request, TenderDeclineRequest tenderReq) {
        return tokenVaultCaller.callTokenVaultService(tenderReq, fetchBatchTokensUrl, null)
            .bodyToMono(new ParameterizedTypeReference<List<GetTenderResponse>>() {})
            .doOnSuccess(str -> {
                String originalTranId = getMITValue(str);
                if(StringUtils.hasText(originalTranId)){
                    MerchantInitiatedTransaction merchantInitiatedTransaction = StoredCredentials.storedCredentialsIncrementalAuth.get("VI");
                    setMerchIntTx(originalTranId, preAuthReq, merchantInitiatedTransaction);
                }
            })
            .flatMap(str -> {
                return callChaseService(preAuthReq, request);
            });
    }

    private Mono<TransactionResponse> callChaseService(PreAuthRequest preAuthReq, TransactionRequest request) {
        return caller.callChaseService(preAuthReq, request.getStoreId(),request.getSellerId(), preauthChaseUrl)
            .bodyToMono(PreauthResponse.class)
            .flatMap(resp -> {
                return Mono.just(buildTransactionResponse(resp, request));
            })
            .onErrorResume(error -> {
                return handlePreAuthErrors(error,request);
            }).doOnSuccess(result -> {
                transactionsDAO.saveSuccessTransaction(request, result);
                if (result != null && result.getToken() != null && result.getToken().getTokenData() != null) {
                    result.getToken().getTokenData().setCvv(null);
                }
            });
    }

    private void buildSoftDesc(TransactionRequest request, PreAuthRequest preauthRequest){
            String dbaName = request.getSoftDescriptors()!= null ? request.getSoftDescriptors().getDba_name() : "";
            if (SOFT_DESC_TRAIL_PERIOD_ENDED.equalsIgnoreCase(dbaName)) {
                SoftDesc.SoftDescBuilder softDesc = SoftDesc.builder();
                softDesc.softDescMercName(SOFT_DESC_TRAIL_ENDED)
                        .softDescProdDesc(SOFT_DESC_FP)
                        .softDescMercCity("")
                        .softDescMercPhone("")
                        .softDescMercURL("")
                        .softDescMercEmail("");
                preauthRequest.setSoftDesc(softDesc.build());
            } else {
                if(!StringUtils.hasText(request.getSellerId())){
                    String softDescMercName = request.getSoftDescriptors().getSoftDescMercName();
                    String softDescProdDesc = request.getSoftDescriptors().getSoftDescProdDesc();
                    if(null != softDescProdDesc && null != softDescMercName) {
                        int merchNameLen = softDescMercName.trim().length();
                        int prodDescLen = softDescProdDesc.trim().length();
                        //Merc name 3,7,8 & Prod Desc 18,14,9
                        if ((merchNameLen != 0 && prodDescLen != 0) && ((merchNameLen <= 3 && prodDescLen <= 18) ||
                                (merchNameLen > 3 && merchNameLen <= 7 && prodDescLen <= 14) ||
                                (merchNameLen > 7 && merchNameLen <= 12 && prodDescLen <= 9))) {
                            SoftDesc.SoftDescBuilder softDesc = SoftDesc.builder();
                            softDesc.softDescMercName(softDescMercName)
                                    .softDescProdDesc(softDescProdDesc)
                                    .softDescMercCity("")
                                    .softDescMercPhone("")
                                    .softDescMercURL("")
                                    .softDescMercEmail("");
                            preauthRequest.setSoftDesc(softDesc.build());
                        }else{
                            log.warn("buildSoftDesc() >> Check the softdescriptor in the request {}",serviceHelper.getJsonPayload(request));
                        }
                    }
                    else{
                        log.warn("buildSoftDesc() >> Check the softdescriptor in the request {}",serviceHelper.getJsonPayload(request));
                    }
                }else{
                    if(!request.getToken().getTokenData().getType().equalsIgnoreCase(CardBrand.AM.getKey())
                            && !request.getToken().getTokenData().getType().equalsIgnoreCase(CardBrand.AM.toString())) {

                        String softDescMercName = MARKET_PLACE + buildMerchRefDsc(request, commonService.getMerchRefDsc(request.getStoreId()));
                        log.info("buildSoftDesc() : Order: {}, softDescMercName: {}", request.getOrderId(), softDescMercName);

                        if(softDescMercName.length() <= 12 && request.getOrderId().length() <= 9) {
                            SoftDesc.SoftDescBuilder softDesc = SoftDesc.builder();
                            softDesc.softDescMercName(softDescMercName)
                                    .softDescProdDesc(request.getOrderId())
                                    .softDescMercCity("")
                                    .softDescMercPhone("")
                                    .softDescMercURL("")
                                    .softDescMercEmail("");
                            preauthRequest.setSoftDesc(softDesc.build());
                        }else{
                            log.error("buildSoftDesc() : Exceeded SoftDesc values length Order: {}, softDescMercName: {}", request.getOrderId(), softDescMercName);
                        }
                    }
                }
            }
        }

    private Mono<TransactionResponse> validateAndUpdateCvv(TransactionRequest request, PreauthResponse chaseResponse) {
        if (isCvvValidated(request, chaseResponse)) {
            return updateCvvDetails(request, chaseResponse);
        }else{
            return Mono.just(buildTransactionResponse(chaseResponse, request));
        }
    }

    private boolean isCvvValidated(TransactionRequest request, PreauthResponse chaseResponse) {
        if (!isARSource(request) && StringUtils.hasText(request.getToken().getTokenData().getCvv()) && StringUtils.hasText(request.getGuid())) {
            if (ResponseCodeUtil.getTransactionStatus(chaseResponse.getOrder().getStatus()).equalsIgnoreCase(Constants.APPROVED)) {
                if (null != chaseResponse.getAvsBilling() && null != chaseResponse.getCardholderVerification()) {
                    log.info("isCvvValidated() >> CvvRespCode() {} and AvsRespCode {} ",chaseResponse.getCardholderVerification().getCvvRespCode(),chaseResponse.getAvsBilling().getAvsRespCode());
                    if (!PaymentUtil.avsErrorValues.contains(chaseResponse.getAvsBilling().getAvsRespCode().trim())
                            && !PaymentUtil.cvsErrorValues.contains(chaseResponse.getCardholderVerification().getCvvRespCode().trim())) {
                        return true;
                    }
                }
            }
        }
        log.info("isCvvValidated() >> Not updated the CVV");
        return false;
    }

    private boolean isARSource(TransactionRequest request){
        return (null != request.getSource() && request.getSource().equalsIgnoreCase(SOURCE_AR));
    }

    private Mono<TransactionResponse> updateCvvDetails(TransactionRequest request, PreauthResponse chaseResponse) {
        return tokenVaultCaller.callTokenVaultCvvUpdate( request.getGuid(), request.getToken().getTokenData().getValue())
                .bodyToMono(String.class)
                .flatMap( res -> {
                    log.info("updateCvvDetails() >> cvvUpdated in the tokenvault and going to build client response");
                    return Mono.just(buildTransactionResponse(chaseResponse, request));
                }).switchIfEmpty(Mono.defer(() -> {
                    log.info("updateCvvDetails() >> cvvUpdated in the tokenvault and going to build client response");
                    return Mono.just(buildTransactionResponse(chaseResponse, request));
                }))
                .onErrorResume(error -> {
                    log.warn("updateCvvDetails() >> cvvUpdate response error but send the success response to the client",error);
                    return Mono.just(buildTransactionResponse(chaseResponse, request));
                });
    }

    private String buildMerchRefDsc(TransactionRequest request, String merchRefDsc) {
        log.info("buildMerchRefDsc() : Order: {}, merchRefDsc: {}, CardBrand: {}", request.getOrderId(), merchRefDsc,
                request.getToken().getTokenData().getType());

        return StringUtils.hasText(MerchRefDsc.getValueByKey(merchRefDsc.toUpperCase())) ?
                MerchRefDsc.getValueByKey(merchRefDsc.toUpperCase()) : merchRefDsc;
    }

    @Override
    public Mono<TransactionResponse> preAuthDummy(TransactionRequest request) {
        log.info("preAuthDummy() >> for order id : {} , client request : {}", request.getOrderId() , serviceHelper.getJsonPayload(request));
        try {
            return callChaseForDummyRequest(request);
        } catch (Exception e) {
            log.error("preAuthDummy() >> Preauth failed for order id: "+request.getOrderId()+" , store id: "+request.getStoreId()+", exception : ", e);
        }
        return null;
    }
    private Mono<TransactionResponse> callChaseForDummyRequest(TransactionRequest request) {
        log.info("callChaseForDummyRequest() >> orderId: {} , store id: {}" , request.getOrderId(),request.getStoreId());
        return caller.callChaseServiceForDummyRequest(buildChasePreAuthRequest(request, true),
                request.getStoreId(), request.getSellerId(), preauthChaseUrl)
                .bodyToMono(PreauthResponse.class)
                .flatMap(resp -> {
                    return Mono.just(buildTransactionResponse(resp, request));
                })
                .onErrorResume(error -> {
                    return handlePreAuthErrors(error,request);
                }).doOnSuccess(result -> {

                });
    }

}
