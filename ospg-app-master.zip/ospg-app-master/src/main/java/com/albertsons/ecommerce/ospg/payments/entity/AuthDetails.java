package com.albertsons.ecommerce.ospg.payments.entity;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class AuthDetails {

	private String transactionTag;
	private String providerTransactionId;
	private BigDecimal amount;
	private String cardHolderName;
	private String cardType;
	private String mitReceivedTransactionId;
}
