package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.enumerations.CardBrand;
import com.albertsons.ecommerce.ospg.payments.model.Merchant;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
public class PaymentUtil {

    public static final Map<String, String> creditCardTypMap;

    static {
        creditCardTypMap = new HashMap<String, String>();
        creditCardTypMap.put("VI", "Visa");
        creditCardTypMap.put("MC", "MasterCard");
        creditCardTypMap.put("AM", "American Express");
        creditCardTypMap.put("DI", "Discover");
        creditCardTypMap.put("JC", "Japan Credit Bureau");
        creditCardTypMap.put("DC", "Diners Club");
    }

    public static final Set<String> avsErrorValues;

    static {
        avsErrorValues = new HashSet<>();
        avsErrorValues.add("E");
        avsErrorValues.add("F");
        avsErrorValues.add("G");
        avsErrorValues.add("M8");
    }

    public static final Set<String> cvsErrorValues;

    static {
        cvsErrorValues = new HashSet<>();
        cvsErrorValues.add("N");
        cvsErrorValues.add("I");
    }

    public static String convertDollarsToCents(String amount) {
        if (StringUtils.isEmpty(amount)) {
            return amount;
        }
        try {
            BigDecimal dollars = new BigDecimal(amount);
            dollars.setScale(2, RoundingMode.DOWN);
            String cents = String.valueOf(dollars.multiply(new BigDecimal(100)).intValue());
            return cents;
        } catch (Exception e) {
            return amount;
        }
    }

    public static String preAuth0DollarCase(String amount) {
        return "0".equals(amount) ? "001" : convertDollarsToCents(amount);
    }

    public static Merchant buildMerchant() {
        return Merchant.builder().bin(Constants.BIN).terminalID(Constants.TERMINAL_ID).build();
    }

    public static String responseStatus(String respCode) {
        return Constants.SUCCESS_RESP_CODE.equalsIgnoreCase(respCode) ? Constants.SUCCESS : Constants.DECLINED;
    }

    public static TransactionRequest cloneTransactionRequest(TransactionRequest request) {

        ObjectMapper mapper = new ObjectMapper();
        TransactionRequest req = new TransactionRequest();
        try {
            String objStr = mapper.writeValueAsString(request);
            req = mapper.readValue(objStr, TransactionRequest.class);

        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return req;
    }


    public static String buildRetryTrace(String orderId, String constant) {
        //chase restriction: buildRetryTrance should not be more than 16 character.
        if(orderId.equals("0") || orderId.length() > 8){
            return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmSSS"));
        }else{
            return orderId + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddHHmmss"));
        }
    }

    public static String getCardTypeFromTokenNbr(String tokenNbr){
        if(tokenNbr.startsWith("4")){
            return CardBrand.VI.getKey();
        }else if(tokenNbr.startsWith("5") || tokenNbr.startsWith("2")){
            return CardBrand.MC.getKey();
        }else if(tokenNbr.startsWith("6")){
            return CardBrand.DI.getKey();
        }else if(tokenNbr.startsWith("34") || tokenNbr.startsWith("37")){
            return CardBrand.AM.getKey();
        }
        return "";
    }

    public static boolean isChaseDownProcStatuses(List<String> procStatusList, ResponseStatusException responseStatusException, TransactionRequest request) {
        String procStatus = "";
        String procStatustrim = "";
        try {
            String[] procStatusStr = StringUtils.isNotBlank(responseStatusException.getMessage()) ? responseStatusException.getMessage().split("procStatus\":") : null;
            if (null != procStatusStr && procStatusStr.length > 1) {
                procStatus = procStatusStr[1].split(",")[0];
            }
            procStatustrim = StringUtils.isNotBlank(procStatus) ? procStatus.replace("\"", "") : "";
            procStatustrim = getProcStatusFromXmlResponse(responseStatusException.getMessage(), procStatus, procStatustrim);
        } catch (Exception e) {
            log.error("isChaseDownProcStatuses() >> error for order id: {} , error status message: {} , error: ", request.getOrderId(), responseStatusException.getStatus().toString(),e);
        }
        return procStatusList.contains(procStatustrim);
    }

    private static String getProcStatusFromXmlResponse(String errorMessage, String procStatus, String procStatustrim) {
        String[] procStatusStr;
        if(StringUtils.isEmpty(procStatustrim)){
            procStatusStr = StringUtils.isNotBlank(errorMessage) ? errorMessage.split("<ProcStatus>") : null;
            if (null != procStatusStr && procStatusStr.length > 1) {
                procStatus = procStatusStr[1].split("<")[0];
            }
            procStatustrim = null!= procStatus ? procStatus.replace("\"", "") : "";
        }
        return procStatustrim;
    }
}
