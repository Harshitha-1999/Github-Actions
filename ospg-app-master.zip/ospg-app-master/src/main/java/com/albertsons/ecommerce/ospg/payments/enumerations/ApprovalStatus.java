package com.albertsons.ecommerce.ospg.payments.enumerations;

public enum ApprovalStatus {

    DECLINE("0"),
    APPROVED("1"),
    SYSTEM_ERROR("2");

    String name;

    private ApprovalStatus(String s) {
        name = s;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
