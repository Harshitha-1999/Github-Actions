package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardholderVerification implements Serializable {
    private CcCardVerifyPresenceInd ccCardVerifyPresenceInd;
    private String ccCardVerifyNum;
    private String cvvRespCode;
    private String hostCVVRespCode;
}
