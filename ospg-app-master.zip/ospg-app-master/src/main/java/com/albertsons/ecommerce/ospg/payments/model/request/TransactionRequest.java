package com.albertsons.ecommerce.ospg.payments.model.request;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.validation.OnAuthorize;
import com.albertsons.ecommerce.ospg.payments.validation.OnPurchase;
import com.albertsons.ecommerce.ospg.payments.validation.OnRefund;
import com.albertsons.ecommerce.ospg.payments.validation.OnVoid;
import com.albertsons.ecommerce.ospg.payments.validation.validator.*;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.validation.Valid;
import java.sql.Timestamp;

import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.TOKEN_DATA;

/**
 * JSON object which maps to Payment service request
 */
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.PUBLIC_ONLY, setterVisibility = JsonAutoDetect.Visibility.PUBLIC_ONLY)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class TransactionRequest {

    @JsonProperty("guid")
    private String guid;

    @JsonProperty("merchant_ref")
    private String merchantRef;

    @NotBlank(error = ValidationErrorCode.TRANSACTION_TYPE, groups = {OnVoid.class,OnPurchase.class,OnRefund.class})
    @JsonProperty("transaction_type")
    private String transactionType;

    @NotBlank(error = ValidationErrorCode.TRANSACTION_TAG, groups = {OnVoid.class})
    @JsonProperty("transaction_tag")
    private String transactionTag;

    @JsonProperty("currency_code")
    private String currencyCode;

    @Deprecated
    private String tenderId;

    @NotBlank(error = ValidationErrorCode.TRANSACTION_ID, groups = OnVoid.class)
    @JsonProperty("transaction_id")
    private String transactionId;

    @JsonProperty("token")
    @Valid
    @NotNull(error = TOKEN_DATA, groups = {OnAuthorize.class})
    private Token token;

    @JsonProperty("cardbrand_original_transaction_id")
    private String cardBrandOriginalTransactionId; // Give the transaction id sequence from a particular card, will be incremented each time card is used.

    @JsonProperty("cardbrand_original_amount")
    private String cardBrandOriginalAmount;

    @JsonProperty("stored_card_flag")
    private boolean storedCardFlag; // T or F on the basis of whether card is stored or not, if T, populate StoredCredentials attrbutes

    @JsonProperty("stored_credentials_amex")
    private String storedCredentialsAmex;

    @JsonProperty("stored_credentials")
    private StoredCredentialRequest storedCredentials;

    @JsonProperty("billing_address")
    private BillingAddress billingAddress;

    @JsonProperty("reversal_id")
    private String reversalId;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty("soft_descriptors")
    private SoftDescriptor softDescriptors;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty("subscription_plan_price")
    private String planPrice;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty("subscription_plan_tax")
    private String planTax;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty("subscription_plan_state")
    private String planState;

    private String method;


    @NotBlank(error = ValidationErrorCode.AMOUNT, groups =
            {OnPurchase.class, OnRefund.class, OnVoid.class,OnAuthorize.class})
    @Numeric(error = ValidationErrorCode.AMOUNT, groups =
            {OnPurchase.class, OnRefund.class, OnVoid.class,OnAuthorize.class})
    private String amount;

    @NotBlank(error = ValidationErrorCode.SOURCE, groups = {OnRefund.class, OnPurchase.class,OnVoid.class})
    private String source;

    private Timestamp requestedTimeStamp;

    @NotBlank(error = ValidationErrorCode.CLIENT_IP, groups = {OnRefund.class, OnPurchase.class,OnVoid.class})
    private String clientIP;

    @NotBlank(error = ValidationErrorCode.STORE_ID, groups = {OnRefund.class, OnPurchase.class,OnVoid.class, OnAuthorize.class})
    @Numeric(error = ValidationErrorCode.STORE_ID, groups = {OnRefund.class, OnVoid.class, OnPurchase.class, OnAuthorize.class})
    private String storeId;

    @NotBlank(error = ValidationErrorCode.ORDER_ID, groups = {OnVoid.class, OnRefund.class, OnPurchase.class,OnAuthorize.class})
    @Numeric(error = ValidationErrorCode.ORDER_ID, groups = {OnVoid.class, OnPurchase.class, OnAuthorize.class})
    private String orderId;

    private String customerId;

    private boolean skipCvvValidation;

    private boolean retry;

    private String txRefNum;

    @JsonIgnore
    private int failureCount;

    private String mitReceivedTransactionId;

    private boolean accumulatorRequest;

    private String sellerId;

}
