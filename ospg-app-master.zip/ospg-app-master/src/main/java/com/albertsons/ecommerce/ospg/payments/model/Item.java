package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Item implements Serializable {
    private String pCard3FreightAmt;
    private String pCard3DutyAmt;
    private String pCard3DestCountryCd;
    private String pCard3ShipFromZip;
    private String pCard3DiscAmt;
    private String pCard3VATtaxAmt;
    private String pCard3VATtaxRate;
    private String pCard3AltTaxInd;
    private String pCard3AltTaxAmt;
    private String pCard3LineItemCount;
    private List<Item> pCard3LineItems;
}
