package com.albertsons.ecommerce.ospg.payments.constants;

public class Constants {
    public static final String ORBITRAL_CONN_USER = "OrbitalConnectionUsername";
    public static final String ORBITRAL_CONN_PW = "OrbitalConnectionPassword";
    public static final String ORBITRAL_CONN_MERCHANT = "MerchantID";

    public static final String BIN = "000001";
    public static final String TERMINAL_ID = "001";

    public static final String CHASE_AUTHORIZE = "A";
    public static final String CHASE_CAPTURE = "C";
    public static final String CHASE_AUTHORIZE_CAPTURE = "AC";
    public static final String VERSION = "4.3";

    public static final String MERCHANT = "MERCHANT";

    public static final String SUCCESS = "success";
    public static final String FAILED = "failed";
    public static final String APPROVED = "approved";
    public static final String DECLINED = "declined";
    public static final String SUCCESS_RESP_CODE = "00";
    public static final String PROC_STATUS_CODE = "0";
    public static final String NOT_PROCESSED = "Not Processed";
    public static final String SUBCRIPTION_STORE_ID = "9999";

    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
    public static final String DUMMY_TRANSACTION_ID = "FDOWN99999";
    public static final String DUMMY_TRANSACTION_TAG = "9999999999";
    public static final String VOID = "void";
    public static final String DUMMY_GATEWAY_MESSAGE = "Transaction Normal";
    public static final String DUMMY_CORRELATION_ID = "999.9999999999999";

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_JSON = "application/vnd.safeway.v1+json";
    public static final String CONTENT_TYPE_JSON_PATCH = "application/vnd.safeway.v1.merge-patch+json";

    public static final String CLIENT_NAME = "x-swy-client-name";
    public static final String WEB_PORTAL = "web-portal";

    public static final String CORRELATION_ID = "x-swy-correlation-id";
    public static final String SUBSCRIPTION_KEY = "Ocp-Apim-Subscription-Key";

    public static final String AUTHORIZE = "authorize";
    public static final String INDUSTRY_TYPE = "EC";
    public static final String INDUSTRY_TYPE_MREC = "RC";
    public static final String TOKEN_TXN_TYPE = "UT";

    public static final String STORED_CRED_INITIATOR = "C";
    public static final String STORED_CRED_INDICATOR = "1";
    public static final String STORED_CRED_INDICATOR_SUBS = "S";
    public static final String STORED_CRED_SCHEDULE = "U";
    public static final String SOFT_DESC_TRAIL_ENDED = "Trial Ended";
    public static final String SOFT_DESC_TRAIL_PERIOD_ENDED = "Trial Period Ended";
    public static final String SOFT_DESC_FP = "FreshPass";

    public static final String TENDER_TYPE_CREDIT_CARD = "CREDIT_CARD";
    public static final String TENDER_PRIMARY_PURPOSES = "DELIVERY_SUBSCRIPTION";
    public static final String TENDER_PRIMARY_PURPOSE_SHOP = "SHOP";
    public static final String PREAUTH_RETRY_TRACE_CONSTANT = "10";
    public static final String CAPTURE_RETRY_TRACE_CONSTANT = "20";
    public static final String REFUND_RETRY_TRACE_CONSTANT = "30";
    public static final String VOID_RETRY_TRACE_CONSTANT = "40";
    public static final String PURCHASE_RETRY_TRACE_CONSTANT = "50";
    public static final String STORE_ID = "storeId";
    public static final String INVALID_CC_NUMBER = "Invalid CC Number";

    public static final String SOURCE_ERUMS = "erums";
    public static final String MARKET_PLACE = "MKTP ";
    public static final String SOURCE_AR = "AR";
    public static final String CHASE_OUTAGE_MESSAGE = "chase is down, sending the transaction to accumulator";
    public static final String DUMMY_ERROR_MESSAGE = "dummy request to check connection between OSPG payments and accumulator service";
}