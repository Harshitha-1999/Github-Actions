package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NotNullValidator implements ConstraintValidator<NotNull, Object> {
    private ValidationErrorCode error;

    @Override
    public void initialize(NotNull constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext constraintContext) {
        if (object == null) {
            throw new DataValidationException(error.getCode(), error.getMessage());
        }
        return true;
    }
}
