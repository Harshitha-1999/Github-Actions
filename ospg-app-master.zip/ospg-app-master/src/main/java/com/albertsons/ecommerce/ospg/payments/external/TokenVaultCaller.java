package com.albertsons.ecommerce.ospg.payments.external;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.request.CvvUpdateRequest;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Component
public class TokenVaultCaller {

    @Autowired
    @Qualifier("tokenVaultClient")
    private WebClient tokenVaultWebclient;

    @Value("${tokenVault.getToken.url}")
    private String getTokenUrl;
    @Value("${token.vault.apim.subscription.key}")
    private String subscriptionKey;
    @Autowired
    private ObjectMapper mapper;

    @Value("${token.vault.updateCvv.url:/updatecvv/customers/{customer_id}/token/{token}}")
    private String updateCvvUrl;

    @Loggable
    private SecurityLogger log;

    public ResponseSpec callTokenVaultService(TenderDeclineRequest request, String uri, String storeId) {
        log.info("callTokenVaultService() >> token vault uri: {} , store id: {} , Tender decline request: {}  ",uri, storeId,stringify(request));
        log.info("callTokenVaultService() >> headers: {}", stringify(getHttpHeaders(storeId)));
        ResponseSpec response= tokenVaultWebclient.post()
                .uri(uri)
                .headers(httpHeadersOnWebClientBeingBuilt -> {
                    httpHeadersOnWebClientBeingBuilt.addAll(getHttpHeaders(storeId));
                })
                .body(Mono.just(request), TenderDeclineRequest.class)
                .retrieve();
        return response;
    }

    private HttpHeaders getHttpHeaders(String storeId) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(Constants.CONTENT_TYPE, Constants.CONTENT_TYPE_JSON);
        headers.add(Constants.CLIENT_NAME, Constants.WEB_PORTAL);
        String uuid = UUID.randomUUID().toString();
        headers.add(Constants.CORRELATION_ID, uuid);
        headers.add(Constants.SUBSCRIPTION_KEY, subscriptionKey);
        if(!StringUtils.isEmpty(storeId)){
            headers.add(Constants.STORE_ID, storeId);
        }
        return headers;
    }

    /**
     * This method will log request in logger file.
     * @param object
     * @return String
     */
    private String stringify(Object object){
        String unmarshalled = StringUtils.EMPTY;
        try {
            unmarshalled = mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error("stringify() >> JsonProcessingException error message: {}",e.getMessage());
        }
        return unmarshalled;
    }

    public ResponseSpec callTokenVaultCvvUpdate(String guid, String token) {
        val  cvvCustomerUrl= updateCvvUrl.replace("{customer_id}", guid);
        val cvvUpdatedUrl = cvvCustomerUrl.replace("{token}", token);
        log.info("callTokenVaultCvvUpdate() >> token vault uri: {} ", cvvUpdatedUrl);
        CvvUpdateRequest cvvUpdateRequest = new CvvUpdateRequest();
        cvvUpdateRequest.setDisplayCvv(false);
        cvvUpdateRequest.setUpdateDate(true);

        ResponseSpec response = tokenVaultWebclient.patch()
                .uri(cvvUpdatedUrl)
                .headers(httpHeadersOnWebClientBeingBuilt -> {
                    httpHeadersOnWebClientBeingBuilt.addAll(getHttpHeadersForUpdateCvv());
                })
                .body(Mono.just(cvvUpdateRequest), CvvUpdateRequest.class)
                .retrieve();
        return response;
    }

    private HttpHeaders getHttpHeadersForUpdateCvv() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(Constants.CLIENT_NAME, Constants.WEB_PORTAL);
        headers.add(Constants.CONTENT_TYPE, Constants.CONTENT_TYPE_JSON_PATCH);
        headers.add(Constants.SUBSCRIPTION_KEY, subscriptionKey);
        return headers;
    }
}
