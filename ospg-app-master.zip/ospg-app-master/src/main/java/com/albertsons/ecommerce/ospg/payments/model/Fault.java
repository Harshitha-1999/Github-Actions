package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.Setter;

//import javax.xml.soap.Detail;

/**
 * JSON Object which holds an array of JSON objects with error codes and description.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Fault {

	private String faultstring;

	/*@JsonDeserialize(contentAs = Detail.class)
	private Detail detail;*/

}