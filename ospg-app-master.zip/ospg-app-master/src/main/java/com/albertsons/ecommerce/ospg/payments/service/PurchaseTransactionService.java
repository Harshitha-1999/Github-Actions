package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.enumerations.CardBrand;
import com.albertsons.ecommerce.ospg.payments.enumerations.MerchRefDsc;
import com.albertsons.ecommerce.ospg.payments.enumerations.OSPGTransactionCategory;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.exceptions.PaymentProviderDownException;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.SoftDesc;
import com.albertsons.ecommerce.ospg.payments.model.request.CaptureReq;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.CaptureResp;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.repositories.AuthDetailsRepo;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;
import com.albertsons.ecommerce.ospg.payments.util.ResponseCodeUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.HashMap;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.*;

@Service
public class PurchaseTransactionService implements IPurchaseTransactionService {

	@Autowired
	private ChaseCaller caller;

	@Autowired
	private AuthorizeTransactionService authService;

	@Value("${chase.capture.url}")
	private String captureUrl;

	@Autowired
	private AuthDetailsRepo repo;

	@Autowired
	private TransactionsDAO dao;

	@Autowired
	private PaymentGatewayServiceHelper serviceHelper;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	CommonService commonService;

	@Loggable
	private SecurityLogger log;
	
	static HashMap<String, String> cardTypeMap = new HashMap<>();
	static{
		
		cardTypeMap.put("Visa", "VI");
		cardTypeMap.put("MasterCard", "MC");
		cardTypeMap.put("American Express", "AM");
		cardTypeMap.put("Discover", "DI");
	}

	public Mono<TransactionResponse> purchase(TransactionRequest transactionRequest) {

		log.info("purchase() >> for order id : {} , switch chase outage flag {}", transactionRequest.getOrderId(), commonService.isChaseOutageEnabled());

		if(commonService.isChaseOutageEnabled()){
			OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.PURCHASE;
			Exception exception=new Exception(CHASE_OUTAGE_MESSAGE);
			throw new PaymentProviderDownException(exception.getMessage(), exception);
		}

		log.info("purchase() >> client request :  {} " , serviceHelper.getJsonPayload(transactionRequest));

		if(transactionRequest.getStoreId().equals(Constants.SUBCRIPTION_STORE_ID)){
			return subscriptionPurchase(transactionRequest);
		}

		TransactionRequest originalReq = PaymentUtil.cloneTransactionRequest(transactionRequest);

		Mono<TransactionResponse> resp = dao.getPrevAuthDetails(transactionRequest)
				.flatMap(result -> {
					log.info("purchase() >> "+result);
					if (result != null && !StringUtils.isEmpty(result.getProviderTransactionId())) {
						log.info("purchase() >> provided txn id: {} , transaction tag: {}, amount: {}",result.getProviderTransactionId(),result.getTransactionTag(),result.getAmount());
						transactionRequest.setAmount(result.getAmount().toString());
						transactionRequest.getToken().getTokenData().setType(cardTypeMap.get(result.getCardType()));
						transactionRequest.setTransactionId(result.getProviderTransactionId());
						transactionRequest.setMitReceivedTransactionId(result.getMitReceivedTransactionId());
						transactionRequest.setTransactionTag(result.getTransactionTag());
					}else if(StringUtils.isEmpty(transactionRequest.getToken().getTokenData().getType())){
						String cardType = PaymentUtil.getCardTypeFromTokenNbr(transactionRequest.getToken().getTokenData().getValue());
						log.info("purchase() >> cardType: {} " , cardType);
						transactionRequest.getToken().getTokenData().setType(cardType);
					}
					return processTxn(transactionRequest, originalReq);
				}).onErrorResume(error -> {
					log.error("purchase() >> Purchase failed with error for stored id: {} , order id: {} , error message: {}",transactionRequest.getStoreId(), transactionRequest.getOrderId(),error.getMessage());
					return errorHandlingService.handlePurchaseErrors(error, transactionRequest);
				});
		log.info("purchase() >> client response: {} " , serviceHelper.getJsonPayload(resp));
		return resp;
	}
	
	public Mono<TransactionResponse> subscriptionPurchase(TransactionRequest request){
		log.info("subscriptionPurchase() >> client request: {}",serviceHelper.getJsonPayload(request));
		return doAuthAndCapture(request);
	}

	private Mono<TransactionResponse> processTxn(TransactionRequest request, TransactionRequest originalReq) {
		
		return dao.checkIfDuplicatePurchase(request).flatMap(req -> {
			
			if (!StringUtils.isEmpty(request.getTransactionId())) {

				if (new BigDecimal(request.getAmount())
						.compareTo(new BigDecimal(originalReq.getAmount())) == -1) {

					log.info("processTxn() >> order id: {} amount mismatch",request.getOrderId());
					if (incrmentalAuthEligible(request)) {
						log.info("processTxn() >> order id: {} eligible for incremental auth",request.getOrderId());
						TransactionRequest trnReqClone = PaymentUtil.cloneTransactionRequest(request);
						return doIncrementalAuth(request, originalReq).flatMap(result -> {
							log.info("processTxn() >> inc auth result: {}",result.getTransactionTag());
							trnReqClone.setAmount(originalReq.getAmount());
							log.info("processTxn() >> Amt: {}",trnReqClone.getAmount());
							return doCaptureOrAuthAndCapture(trnReqClone);
						});
					} else {
						// voidPrevAuth
						TransactionRequest trnReqClone = PaymentUtil.cloneTransactionRequest(request);
						trnReqClone.setAmount(originalReq.getAmount());
						return doCaptureOrAuthAndCapture(trnReqClone);
						//return doAuthAndCapture(originalReq);
					}
				}else{
					request.setAmount(originalReq.getAmount());
					return doCaptureOrAuthAndCapture(request);
				}
			} else {
				return doAuthAndCapture(request);
			}
		});
		
	}

	private Mono<TransactionResponse> doCaptureOrAuthAndCapture(TransactionRequest transactionRequest) {
		transactionRequest.setTransactionType(TransactionType.CAPTURE.toString());
		log.info("doCaptureOrAuthAndCapture() >> calling doCaptureOrAuthAndCapture transactionRequest : {}" , serviceHelper.getJsonPayload(transactionRequest));
		return caller.callChaseService(buildChaseCaptureRequest(transactionRequest), transactionRequest.getStoreId(),
				transactionRequest.getSellerId(), captureUrl)
				.bodyToMono(CaptureResp.class)
				.flatMap(resp -> {
					log.info("doCaptureOrAuthAndCapture() >> Capture Success : ",resp.toString());
					if (!resp.getOrder().getStatus().getProcStatus().equals("0")) {
						return authService.preAuthAndCapture(transactionRequest);
					}
					return Mono.just(buildTransactionResponse(resp, transactionRequest));
				})
				.doOnError(error -> {
					authService.preAuthAndCapture(transactionRequest);
				})
				.doOnSuccess(result -> {
					if(!Constants.DUMMY_TRANSACTION_ID.equalsIgnoreCase(result.getTransactionId())) {
						dao.saveSuccessTransaction(transactionRequest, result);
					}
				});
	}

	private Mono<TransactionResponse> doIncrementalAuth(TransactionRequest transactionRequest, TransactionRequest originalReq) {
		log.info("doIncrementalAuth() >> initiating incremental auth for order id: {}",transactionRequest.getOrderId());
		transactionRequest.setAmount(new BigDecimal(originalReq.getAmount())
				.subtract(new BigDecimal(transactionRequest.getAmount())).toPlainString());
		log.info("doIncrementalAuth() >> incremental amt: {}",transactionRequest.getAmount());
		
		return authService.incrementalAuth(transactionRequest)
				.onErrorResume(error -> {
					return Mono.error(error);
				});
	}

	private Mono<TransactionResponse> doAuthAndCapture(TransactionRequest transactionRequest) {

		return authService.preAuthAndCapture(transactionRequest).onErrorResume(error -> {
			return errorHandlingService.handlePurchaseErrors(error, transactionRequest);
		});
	}

	private CaptureReq buildChaseCaptureRequest(TransactionRequest request) {
		CaptureReq captureReq = CaptureReq.builder().version(Constants.VERSION).merchant(PaymentUtil.buildMerchant())
				.order(buildOrder(request)).build();
		if (org.springframework.util.StringUtils.hasText(request.getSellerId()) || request.getSoftDescriptors() != null) {
			buildSoftDesc(request, captureReq);
		}
		log.info("buildChaseCaptureRequest() >> Chase capture request: {}" , serviceHelper.getJsonPayload(captureReq));
		return captureReq;
	}

	private Order buildOrder(TransactionRequest request) {
		return Order.builder().orderID(request.getOrderId()).txRefNum(request.getTransactionId())
				.amount(PaymentUtil.convertDollarsToCents(request.getAmount())).industryType(Constants.INDUSTRY_TYPE).build();
	}

	private TransactionResponse buildTransactionResponse(CaptureResp captureResp,
			TransactionRequest transactionRequest) {
		log.info("buildTransactionResponse() >> Chase capture response: {}" , serviceHelper.getJsonPayload(captureResp));
		String transactionStatus = Constants.NOT_PROCESSED;
        if (captureResp.getOrder() != null) {
            transactionStatus = ResponseCodeUtil
            		.getTxnStatusPurchase(captureResp.getOrder().getStatus());
        }
		TransactionResponse transactionResponse = TransactionResponse.builder().amount(transactionRequest.getAmount())
				.transactionId(captureResp.getOrder() == null ? "" : captureResp.getOrder().getTxRefNum())
				.transactionStatus(transactionStatus)
				.currency(transactionRequest.getCurrencyCode()).method(transactionRequest.getMethod())
				.token(transactionRequest.getToken()).transactionType(transactionRequest.getTransactionType())
				.validationStatus(captureResp.getOrder().getStatus().getProcStatus()
                        .equalsIgnoreCase(Constants.PROC_STATUS_CODE)
                        ? Constants.SUCCESS : Constants.FAILED)
				.transactionTag(transactionRequest.getTransactionTag())
				.build();
		log.info("buildTransactionResponse() >> client response for orderId: {}, purchase: {}",
				transactionRequest.getOrderId(), serviceHelper.getJsonPayload(transactionResponse));
		return transactionResponse;
	}

	private boolean incrmentalAuthEligible(TransactionRequest request) {

		String type = request.getToken().getTokenData().getType();
		if (type.equals("VI") || type.equals("MC")) {
			return true;
		} else {
			return false;
		}
	}

	private void buildSoftDesc(TransactionRequest request, CaptureReq captureReq){
		String dbaName = request.getSoftDescriptors()!= null ? request.getSoftDescriptors().getDba_name() : "";
		if (SOFT_DESC_TRAIL_PERIOD_ENDED.equalsIgnoreCase(dbaName)) {
			SoftDesc.SoftDescBuilder softDesc = SoftDesc.builder();
			softDesc.softDescMercName(SOFT_DESC_TRAIL_ENDED)
					.softDescProdDesc(SOFT_DESC_FP)
					.softDescMercCity("")
					.softDescMercPhone("")
					.softDescMercURL("")
					.softDescMercEmail("");
			captureReq.setSoftDesc(softDesc.build());
		} else {
			if(!org.springframework.util.StringUtils.hasText(request.getSellerId())){
				String softDescMercName = request.getSoftDescriptors().getSoftDescMercName();
				String softDescProdDesc = request.getSoftDescriptors().getSoftDescProdDesc();
				if(null != softDescProdDesc && null != softDescMercName) {
					int merchNameLen = softDescMercName.trim().length();
					int prodDescLen = softDescProdDesc.trim().length();
					//Merc name 3,7,8 & Prod Desc 18,14,9
					if ((merchNameLen != 0 && prodDescLen != 0) && ((merchNameLen <= 3 && prodDescLen <= 18) ||
							(merchNameLen > 3 && merchNameLen <= 7 && prodDescLen <= 14) ||
							(merchNameLen > 7 && merchNameLen <= 12 && prodDescLen <= 9))) {
						SoftDesc.SoftDescBuilder softDesc = SoftDesc.builder();
						softDesc.softDescMercName(softDescMercName)
								.softDescProdDesc(softDescProdDesc)
								.softDescMercCity("")
								.softDescMercPhone("")
								.softDescMercURL("")
								.softDescMercEmail("");
						captureReq.setSoftDesc(softDesc.build());
					}else{
						log.warn("buildSoftDesc() >> Check the softdescriptor in the request {}", serviceHelper.getJsonPayload(request));
					}
				}
				else{
					log.warn("buildSoftDesc() >> Check the softdescriptor in the request {}", serviceHelper.getJsonPayload(request));
				}
			}else{
				if(!request.getToken().getTokenData().getType().equalsIgnoreCase(CardBrand.AM.getKey())
						&& !request.getToken().getTokenData().getType().equalsIgnoreCase(CardBrand.AM.toString())) {

					String softDescMercName = MARKET_PLACE + buildMerchRefDsc(request, commonService.getMerchRefDsc(request.getStoreId()));
					log.info("buildSoftDesc() : Order: {}, softDescMercName: {}", request.getOrderId(), softDescMercName);

					if(softDescMercName.length() <= 12 && request.getOrderId().length() <= 9) {
						SoftDesc.SoftDescBuilder softDesc = SoftDesc.builder();
						softDesc.softDescMercName(softDescMercName)
								.softDescProdDesc(request.getOrderId())
								.softDescMercCity("")
								.softDescMercPhone("")
								.softDescMercURL("")
								.softDescMercEmail("");
						captureReq.setSoftDesc(softDesc.build());
					}else{
						log.error("buildSoftDesc() : Exceeded values length Order: {}, softDescMercName: {}", request.getOrderId(), softDescMercName);
					}
				}
			}
		}
	}

	private String buildMerchRefDsc(TransactionRequest request, String merchRefDsc) {
		log.info("buildMerchRefDsc() : Order: {}, merchRefDsc: {}, CardBrand: {}", request.getOrderId(), merchRefDsc,
				request.getToken().getTokenData().getType());

		return !StringUtils.isEmpty(MerchRefDsc.getValueByKey(merchRefDsc.toUpperCase())) ?
				MerchRefDsc.getValueByKey(merchRefDsc.toUpperCase()) : merchRefDsc;
	}

}
