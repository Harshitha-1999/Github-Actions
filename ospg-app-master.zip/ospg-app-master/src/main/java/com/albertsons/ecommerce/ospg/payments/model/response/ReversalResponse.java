package com.albertsons.ecommerce.ospg.payments.model.response;

import com.albertsons.ecommerce.ospg.payments.model.EmvInfo;
import com.albertsons.ecommerce.ospg.payments.model.Merchant;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReversalResponse {
    private String version;
    private Merchant merchant;
    private Order order;
    private EmvInfo emvInfo;
}
