package com.albertsons.ecommerce.ospg.payments.config;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionCacheLoaderDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
@EnableCaching
public class TransactionCacheConfig {

    private static final String[] CACHES = {
            GatewayConstants.CARD_TYP_CACHE,
            GatewayConstants.ERROR_TYP_CACHE,
            GatewayConstants.TOKEN_TYP_CACHE,
            GatewayConstants.TRANSACTION_TYP_CACHE,
            GatewayConstants.TRANSACTION_STATUS_TYP_CACHE,
            GatewayConstants.VALIDATION_STATUS_TYP_CACHE,
            GatewayConstants.MERCH_REF_TYP_CACHE,
            GatewayConstants.FULL_AUTH_STORE_CACHE,
            GatewayConstants.STORED_CRED_STORE_CACHE,
            GatewayConstants.FEATURE_FLAG_CACHE,
            GatewayConstants.CHASE_ORBITAL_URL,
            GatewayConstants.SWITCH_CHASE_OUTAGE,
            GatewayConstants.PROC_STATUS_CODE
    };

    @Autowired
    TransactionCacheLoaderDao transactionCacheLoaderDao;

    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager(CACHES);
        transactionCacheLoaderDao.loadCardTyp(cacheManager.getCache(GatewayConstants.CARD_TYP_CACHE));
        transactionCacheLoaderDao.loadErrorTyp(cacheManager.getCache(GatewayConstants.ERROR_TYP_CACHE));
        transactionCacheLoaderDao.loadTokenTyp(cacheManager.getCache(GatewayConstants.TOKEN_TYP_CACHE));
        transactionCacheLoaderDao.loadTransactionTyp(cacheManager.getCache(GatewayConstants.TRANSACTION_TYP_CACHE));
        transactionCacheLoaderDao.loadTransactionStatusTyp(cacheManager.getCache(GatewayConstants.TRANSACTION_STATUS_TYP_CACHE));
        transactionCacheLoaderDao.loadValidationStatusTyp(cacheManager.getCache(GatewayConstants.VALIDATION_STATUS_TYP_CACHE));
        transactionCacheLoaderDao.loadFullAuthStoreTyp(cacheManager.getCache(GatewayConstants.FULL_AUTH_STORE_CACHE));
        transactionCacheLoaderDao.loadStoredCredStoreTyp(cacheManager.getCache(GatewayConstants.STORED_CRED_STORE_CACHE));
        transactionCacheLoaderDao.loadMerchRefTyp(cacheManager.getCache(GatewayConstants.MERCH_REF_TYP_CACHE));
        transactionCacheLoaderDao.loadFeatureFlags(cacheManager.getCache(GatewayConstants.FEATURE_FLAG_CACHE));
        transactionCacheLoaderDao.loadChaseOrbitalUrlInfo(cacheManager.getCache(GatewayConstants.CHASE_ORBITAL_URL));
        transactionCacheLoaderDao.loadSwitchChaseOutage(cacheManager.getCache(GatewayConstants.SWITCH_CHASE_OUTAGE));
        transactionCacheLoaderDao.loadProcStatusCode(cacheManager.getCache(GatewayConstants.PROC_STATUS_CODE));
        return cacheManager;
    }
}
