package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;

import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.CARD_EXPIRED;
import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.CARD_EXPIRY_DATE_FORMAT;

public class PastValidator implements ConstraintValidator<Past, String> {
    private ValidationErrorCode error;

    @Override
    public void initialize(Past annotatedConstraint) {
        this.error = annotatedConstraint.error();
    }

    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        int month, year;
        try {
            if (null != s && !s.isEmpty() && s.length() == 4 && !s.contains("-")) {
                month = Integer.parseInt(s.substring(0,2));
                year = Integer.parseInt(s.substring(2,4));
            } else {
                throw new DataValidationException(CARD_EXPIRY_DATE_FORMAT.getCode(), CARD_EXPIRY_DATE_FORMAT.getMessage());
            }
        } catch (NumberFormatException nfe) {
            throw new DataValidationException(CARD_EXPIRY_DATE_FORMAT.getCode(), CARD_EXPIRY_DATE_FORMAT.getMessage());
        }
        if (month > 12 || month == 0)
            throw new DataValidationException(CARD_EXPIRY_DATE_FORMAT.getCode(), CARD_EXPIRY_DATE_FORMAT.getMessage());


        if (LocalDate.now().getYear() < Integer.parseInt("20" + s.substring(2, 4))){
            return Boolean.TRUE;
        }

        if (LocalDate.now().getYear() > Integer.parseInt("20" + s.substring(2, 4))){
            throw new DataValidationException(CARD_EXPIRED.getCode(), CARD_EXPIRED.getMessage());
        }

        if(LocalDate.now().getYear() == Integer.parseInt("20" + s.substring(2, 4))
                && LocalDate.now().getMonth().getValue() > Integer.parseInt(s.substring(0,2))){
            throw new DataValidationException(CARD_EXPIRED.getCode(), CARD_EXPIRED.getMessage());
        }

        return Boolean.TRUE;
    }
}