package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.enumerations.OSPGTransactionCategory;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.ErrorHandlingService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.DUMMY_ERROR_MESSAGE;

@RestController
public class TestController {
    public static final String DUMMY_STORE = "0000";
    @Autowired
    private ErrorHandlingService errorHandlingService;

    @PostMapping("/")
    public @ResponseBody
    String greeting() {
        return "Hello, World";
    }

    @Tag(name = "This is temporary end point to check the connection between ospg payments(aks prod env) and accumulator service. It will be removed later.")
    @RequestMapping(value = "/invokeaccumfromaks", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    Mono<TransactionResponse> preAuthTest(@RequestBody TransactionRequest request) {
        if (DUMMY_STORE.equalsIgnoreCase(request.getStoreId())) {
            OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.AUTHORIZE;
            return errorHandlingService.invokeSaveToAccumulator(ospgTransactionCategory,request, errorHandlingService.getDummyAuthResponse(), new Exception(DUMMY_ERROR_MESSAGE));
        }
        TransactionResponse response = TransactionResponse.builder()
                .errorMessage("can not proccess for other than 0000 store")
                .transactionStatus(Constants.NOT_PROCESSED)
                .build();
        return Mono.just(response);
    }
}
