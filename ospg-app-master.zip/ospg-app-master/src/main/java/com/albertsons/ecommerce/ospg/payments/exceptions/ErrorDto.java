package com.albertsons.ecommerce.ospg.payments.exceptions;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.util.Collection;
import java.util.Optional;

@Data
@NoArgsConstructor
@FieldDefaults(makeFinal = false, level = AccessLevel.PRIVATE)
public class ErrorDto {

    int status;
    String code;
    String message;
    String debugMessage;
    Collection<SubErrorDto> subErrorsList;
    Throwable rootCause;

    public Optional<String> getCode() {
        return Optional.ofNullable(code);
    }

    public Optional<String> getMessage() {
        return Optional.ofNullable(message);
    }

    public Optional<String> getDebugMessage() {
        return Optional.ofNullable(debugMessage);
    }

    public Optional<Collection<SubErrorDto>> getSubErrorsList() {
        return Optional.ofNullable(subErrorsList);
    }

    public Optional<Throwable> getRootCause() {
        return Optional.ofNullable(rootCause);
    }
}