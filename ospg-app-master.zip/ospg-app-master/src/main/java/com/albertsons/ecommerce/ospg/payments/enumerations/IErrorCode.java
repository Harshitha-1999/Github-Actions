package com.albertsons.ecommerce.ospg.payments.enumerations;

public interface IErrorCode {
	String getCode();
	String getMessage();
}
