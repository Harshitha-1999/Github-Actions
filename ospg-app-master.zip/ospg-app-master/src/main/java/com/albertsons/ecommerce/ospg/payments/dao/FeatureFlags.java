package com.albertsons.ecommerce.ospg.payments.dao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class FeatureFlags {
    private String name;
    private Boolean value;
}
