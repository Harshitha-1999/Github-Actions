package com.albertsons.ecommerce.ospg.payments.model.response;

import com.albertsons.ecommerce.ospg.payments.model.Error;
import com.albertsons.ecommerce.ospg.payments.model.Fault;
import com.albertsons.ecommerce.ospg.payments.model.request.Token;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class TransactionResponse {

    private boolean isResponseError;
    private boolean isResponseFault;
    private String method = StringUtils.EMPTY;
    private String amount = "0";
    private String currency = StringUtils.EMPTY;
    private String avs = StringUtils.EMPTY;
    private String cvv2 = StringUtils.EMPTY;
    private String errorMessage = StringUtils.EMPTY;
    private String errorCode = StringUtils.EMPTY;
    private String code = StringUtils.EMPTY;
    private String message = StringUtils.EMPTY;
    private Integer failureCount = 0;
    @JsonDeserialize(contentAs = Fault.class)
    private Fault fault;
    @JsonDeserialize(contentAs = com.albertsons.ecommerce.ospg.payments.model.Error.class)
    private Error Error;
    @JsonProperty("transaction_status")
    private String transactionStatus  = StringUtils.EMPTY;
    @JsonProperty("validation_status")
    private String validationStatus = StringUtils.EMPTY;

    @JsonProperty("transaction_type")
    private String transactionType = StringUtils.EMPTY;

    @JsonProperty("transaction_id")
    private String transactionId = StringUtils.EMPTY;

    @JsonProperty("transaction_tag")
    private String transactionTag = StringUtils.EMPTY;

    @JsonProperty("bank_resp_code")
    private String bankRespCode = StringUtils.EMPTY;

    @JsonProperty("bank_message")
    private String bankMessage = StringUtils.EMPTY;

    @JsonProperty("gateway_resp_code")
    private String gatewayRespCode = StringUtils.EMPTY;

    @JsonProperty("gateway_message")
    private String gatewayMessage = StringUtils.EMPTY;

    @JsonProperty("correlation_id")
    private String correlationId;

    private Token token;

    @JsonProperty("stored_credentials")
    private StoredCredentialResponse storedCredentials;

    @JsonProperty("stored_credentials_amex")
    private String storedCredentialsAmex = StringUtils.EMPTY;
    
    public String toString(TransactionResponse resp){
    	
    	try {
    		ObjectMapper mapper = new ObjectMapper();
			return  mapper.writeValueAsString(resp);
		} catch (Exception e) {
			log.error("toString() >> exception: ",e);
		}
    	return "{}";
    }

}
