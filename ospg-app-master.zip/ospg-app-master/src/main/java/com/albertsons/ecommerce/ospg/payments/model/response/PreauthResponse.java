package com.albertsons.ecommerce.ospg.payments.model.response;

import com.albertsons.ecommerce.ospg.payments.model.*;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class PreauthResponse {

        private String transType;

        private Merchant merchant;

        private PaymentInstrument paymentInstrument;

        public Order order;

        private EmvInfo emvInfo;

        private AvsBilling avsBilling;

        private CardholderVerification cardholderVerification;

        private Debit debit;

        private CardTypeIndicator cardTypeIndicator;

        private EarlyWarningSystem earlyWarningSystem;

        private ForeignExchange foreignExchange;

        private RealTimeAccountUpdater realTimeAccountUpdater;

        private GiftCard giftcard;

        private Profile profile;

        private ManagedBilling managedBilling;

}