package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Builder
@Setter
@Getter
@JsonAutoDetect
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FailedTransaction {
    private String orderId;
    private String pk;

    private String url;
    private String createTimeStamp;
    private Boolean processed;
    private Boolean discarded;

    private String genericId;

    private String type;

    private Object request;

    private Integer outageResponseCode;
    private Object outageResponseBody;
    private String outageMessage;

}