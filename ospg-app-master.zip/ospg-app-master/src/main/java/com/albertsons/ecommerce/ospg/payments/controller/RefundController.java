package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.IRefundTransactionService;
import com.albertsons.ecommerce.ospg.payments.validation.OnRefund;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * @author masood mohiuddin.
 */
@Slf4j
@RestController
public class RefundController implements IRefundTransactions {

    @Autowired
    private IRefundTransactionService chaseService;

    public Mono<ResponseEntity<TransactionResponse>> refund(@Validated({OnRefund.class}) TransactionRequest request) {
        //tokenTxRefNumClombinedValidation(request);  //Karthik: Commented this validation
       // validateTransactionType(request);
        Mono<TransactionResponse> response = chaseService.refund(request);
        return getResponseEntity(response);
    }

    public  Mono<ResponseEntity<TransactionResponse>> subscriptionRefund(TransactionRequest request) {
        //tokenTxRefNumClombinedValidation(request); //Karthik: Commented this validation
        Mono<TransactionResponse> response = chaseService.subscriptionRefund(request);
        return getResponseEntity(response);
    }

    private Mono<ResponseEntity<TransactionResponse>> getResponseEntity(Mono<TransactionResponse> response) {
        return response.map(res -> {
            if(res != null && res.getTransactionStatus() != null){
                String transactionStatus = res.getTransactionStatus();
                if(transactionStatus.equalsIgnoreCase(Constants.APPROVED)){
                    return new ResponseEntity<>(res, HttpStatus.CREATED);
                }else if(transactionStatus.equalsIgnoreCase(Constants.DECLINED)){
                    return new ResponseEntity<>(res, HttpStatus.PRECONDITION_FAILED);
                }
            }
            return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
        });
    }

    /**
     * TODO
     * This is temporary method unless we come up with custom static validations
     * for txRefNum & token
     * @param transReq
     * @return Boolean
     */
    private void tokenTxRefNumClombinedValidation(TransactionRequest transReq) {
        log.info("RefundController::tokenTxRefNumClombinedValidation -> Started");
        if (null == transReq.getToken() && StringUtils.isBlank(transReq.getTransactionId()))
            throw new DataValidationException(ValidationErrorCode.TOKEN_DATA_TRX_REF_NUM.getCode(),
                    ValidationErrorCode.TOKEN_DATA_TRX_REF_NUM.getMessage());
    }

    private void validateTransactionType(TransactionRequest request) {
        if (!request.getTransactionType().equalsIgnoreCase(TransactionType.REFUND.name())) {
            throw new DataValidationException(ValidationErrorCode.TRANSACTION_TYPE.getCode(),
                    ValidationErrorCode.TRANSACTION_TYPE.getMessage());
        }
    }
}