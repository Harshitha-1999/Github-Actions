package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import reactor.core.publisher.Mono;

@Controller
@RequestMapping(value = "/transaction")
public interface IAuthorizeTransactions {

    @RequestMapping(value = "/authorize", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    Mono<ResponseEntity<TransactionResponse>> preAuth(@RequestBody TransactionRequest request);

    @RequestMapping(value = "/dummyauthorize", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    Mono<ResponseEntity<TransactionResponse>> preAuthDummy(@RequestBody TransactionRequest request);

}
