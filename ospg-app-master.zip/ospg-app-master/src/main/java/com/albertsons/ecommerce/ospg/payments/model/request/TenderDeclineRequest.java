package com.albertsons.ecommerce.ospg.payments.model.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class TenderDeclineRequest {
	
	private String type;
	private String primaryPurpose;
	private List<String> customerIds;

}