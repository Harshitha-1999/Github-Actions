package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;

import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.CVV_NUMBER;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CVVValidator implements ConstraintValidator<CVV, String> {
    private ValidationErrorCode error;

    @Override
    public void initialize(CVV constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(String cvvStr, ConstraintValidatorContext constraintContext) {
        if (cvvStr == null) {
            return true;
        }
        if(cvvStr.trim().isEmpty()){
            throw new DataValidationException(error.getCode(), error.getMessage());
        }
        return true;
    }
}