package com.albertsons.ecommerce.ospg.payments.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class PurchaseTransactionDetails {
	private String providerTransactionId;
	private String transactionTag;
}
