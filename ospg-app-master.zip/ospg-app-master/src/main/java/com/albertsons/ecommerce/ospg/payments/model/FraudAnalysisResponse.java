package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@NoArgsConstructor
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class FraudAnalysisResponse implements Serializable {
    private String fraudScoreIndicator;
    private String fraudStatusCode;
    private String riskInquiryTransactionID;
    private String autoDecisionResponse;
    private String riskScore;
    private String kaptchaMatchFlag;
    private String worstCountry;
    private String customerRegion;
    private String paymentBrand;
    private String fourteenDayVelocity;
    private String sixHourVelocity;
    private String customerNetwork;
    private String numberOfDevices;
    private String numberOfCards;
    private String numberOfEmails;
    private String deviceLayers;
    private String deviceFingerprint;
    private String customerTimeZone;
    private String customerLocalDateTime;
    private String deviceRegion;
    private String deviceCountry;
    private String proxyStatus;
    private String javascriptStatus;
    private String flashStatus;
    private String cookiesStatus;
    private String browserCountry;
    private String browserLanguage;
    private String mobileDeviceIndicator;
    private String mobileDeviceType;
    private String mobileWirelessIndicator;
    private String voiceDevice;
    private String pcRemoteIndicator;
    private String rulesDataLength;
    private String rulesData;
}
