package com.albertsons.ecommerce.ospg.payments.repositories;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.albertsons.ecommerce.ospg.payments.entity.AuthDetails;

import reactor.core.publisher.Mono;

@Repository
public interface AuthDetailsRepo extends R2dbcRepository<AuthDetails, Long> {

	@Query("SELECT " +
			"top 1" +
			"t.TRANSACTION_TAG_TXT, t.PROVIDER_TRANSACTION_ID, " +
			"t.TRANSACTION_AMT, tt.CARD_HOLDER_NM, ct.CARD_NM, tt.MIT_RECEIVED_TRANSACTION_ID from " +
			"            [OSPGPAYTX].[TRANSACTION_TOKEN] tt join " +
			"            [OSPGPAYTX].[TRANSACTION] t on " +
			" tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
			" join [OSPGPAYTX].[CARD_TYP] ct on tt.CARD_TYP_CD = ct.CARD_TYP_CD " +
			" where tt.STORE_ID = :storeId and tt.ORDER_ID = :orderId " +
			" and t.TRANSACTION_TYP_CD = 3  and " +
			" t.TRANSACTION_STAT_TYP_CD = 1 and " +
			" tt.TOKEN_NBR = :tokenNmbr  and " +
			" t.TRANSACTION_AMT > 0.01 order by t.LAST_UPDATE_TS;")
	public Mono<AuthDetails> fetchAuthDetails(String orderId, 
			String storeId, String tokenNmbr);


	@Query("SELECT " +
			"top 1" +
			"t.TRANSACTION_TAG_TXT, t.PROVIDER_TRANSACTION_ID, " +
			"t.TRANSACTION_AMT, tt.CARD_HOLDER_NM, ct.CARD_NM, tt.MIT_RECEIVED_TRANSACTION_ID from " +
			"            [OSPGPAYTX].[TRANSACTION_TOKEN] tt join " +
			"            [OSPGPAYTX].[TRANSACTION] t on " +
			" tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
			" join [OSPGPAYTX].[CARD_TYP] ct on tt.CARD_TYP_CD = ct.CARD_TYP_CD " +
			" where tt.STORE_ID = :storeId and tt.ORDER_ID = :orderId " +
			" and t.TRANSACTION_TYP_CD = 3  and " +
			" t.TRANSACTION_STAT_TYP_CD = 1 and " +
			" tt.TOKEN_NBR = :tokenNmbr  and " +
			" t.TRANSACTION_AMT > 1 order by t.LAST_UPDATE_TS;")
	public Mono<AuthDetails> fetchOrderAheadAuthDetails(String orderId,
											  String storeId, String tokenNmbr);


	
	@Query("SELECT top 1 "
    		+ "t.TRANSACTION_TAG_TXT, t.PROVIDER_TRANSACTION_ID, "
    		+ "t.TRANSACTION_AMT, tt.CARD_HOLDER_NM, ct.CARD_NM, tt.MIT_RECEIVED_TRANSACTION_ID from "
    		+ "[OSPGPAYTX].[TRANSACTION_TOKEN] tt join "
    		+ "[OSPGPAYTX].[TRANSACTION] t on "
    		+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
    		+ "join [OSPGPAYTX].[CARD_TYP] ct on tt.CARD_TYP_CD = ct.CARD_TYP_CD "
    		+ "where tt.STORE_ID = :storeId and tt.ORDER_ID = :orderId "
    		+ "and t.TRANSACTION_TYP_CD in (1,5)  and "
    		+ "t.TRANSACTION_STAT_TYP_CD = 1  order by t.TRANSACTION_END_TS desc;")
	public Mono<AuthDetails> fetchPurchaseDetails(String orderId, 
			String storeId);
}