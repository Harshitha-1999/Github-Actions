package com.albertsons.ecommerce.ospg.payments.model.request;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;

/**
 * JSON object that holds the tokenized card information
 * 
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Token {

	@JsonProperty("token_type")
	private String tokenType = StringUtils.EMPTY;

	@Valid
	@JsonProperty("token_data")
	private TokenData tokenData;

}
