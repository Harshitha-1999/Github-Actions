package com.albertsons.ecommerce.ospg.payments.exceptions;

import lombok.Getter;
import lombok.Setter;

/**
 * @author masood mohiuddin.
 */
@Getter
@Setter
public class ChaseServerException extends RuntimeException {

    private String errorCode;

    public ChaseServerException(String message, Throwable cause) {
        super(message, cause);
    }

    public ChaseServerException(String message) {
        super(message);
    }

    public ChaseServerException(Throwable cause) {
        super(cause);
    }
}
