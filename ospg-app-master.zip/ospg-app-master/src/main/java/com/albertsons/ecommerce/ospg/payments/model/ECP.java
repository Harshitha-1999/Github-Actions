package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ECP {
    private String ecpCheckRT;
    private String ecpCheckDDA;
    private String ecpBankAcctType;
    private String ecpAuthMethod;
    private String ecpDelvMethod;
    private String ecpActionCode;
    private String ecpCheckSerialNumber;
    private String ecpTerminalCity;
    private String ecpTerminalState;
    private String ecpImageReferenceNumber;
    private String ecpSameDayInd;
    private String ecpReDepositFreq;
    private String ecpReDepositInd;
}
