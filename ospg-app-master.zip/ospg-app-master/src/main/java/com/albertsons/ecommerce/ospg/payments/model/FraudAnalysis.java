package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@NoArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class FraudAnalysis implements Serializable {
    private String fraudScoreIndicator;
    private String rulesTrigger;
    private String safetechMerchantID;
    private String kaptchaSessionID;
    private String websiteShortName;
    private String cashValueOfFencibleItems;
    private String customerDOB;
    private String customerGender;
    private String customerDriverLicense;
    private String customerID;
    private String customerIDCreationTime;
    private String kttVersionNumber;
    private String kttDataLength;
    private String kttDataString;
    private String fraudScoreProcStatus;
    private String fraudScoreProcMsg;
    private FraudAnalysisResponse fraudAnalysisResponse;
}
