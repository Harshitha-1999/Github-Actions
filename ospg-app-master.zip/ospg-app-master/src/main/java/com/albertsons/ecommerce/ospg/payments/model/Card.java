package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Card {
    private String cardBrand;
    private String ccAccountNum;
    private String magStripeTrack1;
    private String magStripeTrack2;
    private String dpanInd;
    private String tokenTxnType;
    private String ccExp;
    private String dpanAccountStatus;
    private String safetechToken;
    private String cardType;
    private String startAccountNum;
    private String healthBenefitCardInd;

    public static class CardBuilder {
        private String ccExp;
        public CardBuilder ccExp(String expDate) {
            this.ccExp = "20".concat(expDate.substring(2,4)).concat(expDate.substring(0,2));
            return this;
        }
    }
}
