package com.albertsons.ecommerce.ospg.payments.config;

import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

/**
 * @author masood mohiuddin.
 */
@Profile("!local")
@Configuration
public class ChaseConfig {
    @Value("${chase.url}")
    private String url;

    @Value("${chase.secondary.url}")
    private String chaseSecondaryUrl;

    @Value("${chase.username}")
    private String username;
    @Value("${chase.password}")
    private String password;
    @Value("${chase.merchantId}")
    private String merchantId;
    @Value("${chase.timeout}")
    private int timeout;

    @Loggable
    private SecurityLogger log;

    @Bean("chaseClient")
    public WebClient getChaseWebClient() {
    	log.info("getChaseWebClient() >> chase config ");
       
        return WebClient.builder()
        		.baseUrl(url)
                //.clientConnector(new ReactorClientHttpConnector(chaseClient))
                .filter(ExchangeFilterFunction.ofResponseProcessor(this::renderApiErrorResponse))
                //.defaultHeader(Constants.ORBITRAL_CONN_USER, username)
                //.defaultHeader(Constants.ORBITRAL_CONN_PASS, password)
                //.defaultHeader(Constants.ORBITRAL_CONN_MERCHANT, merchantId)
                .build();
    }

    @Bean("chaseSecondaryClient")
    public WebClient getChaseSecondaryWebClient() {
        log.info("getChaseSecondaryWebClient() >> chase config ");

        return WebClient.builder()
                .baseUrl(chaseSecondaryUrl)
                //.clientConnector(new ReactorClientHttpConnector(chaseClient))
                .filter(ExchangeFilterFunction.ofResponseProcessor(this::renderApiErrorResponse))
                //.defaultHeader(Constants.ORBITRAL_CONN_USER, username)
                //.defaultHeader(Constants.ORBITRAL_CONN_PASS, password)
                //.defaultHeader(Constants.ORBITRAL_CONN_MERCHANT, merchantId)
                .build();
    }
    
    private Mono<ClientResponse> renderApiErrorResponse(ClientResponse clientResponse) {
    	if(clientResponse.statusCode().isError()){
			log.info("renderApiErrorResponse() >> error response from chase ");
			return clientResponse.bodyToMono(String.class)
					.flatMap(apiErrorResponse -> Mono.error(new ResponseStatusException(
							clientResponse.statusCode(),
							apiErrorResponse
					)));
		}else{
			log.info("renderApiErrorResponse >> success Response from chase ");
			return  Mono.just(clientResponse);
		}
		
	}
}
