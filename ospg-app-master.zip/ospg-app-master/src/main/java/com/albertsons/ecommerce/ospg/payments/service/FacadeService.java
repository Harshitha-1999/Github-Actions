package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.external.TokenVaultCaller;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class FacadeService {

    @Autowired
    TokenVaultCaller tokenVaultCaller;

    private static final String WALLET_FETCH_TOKEN_BATCH_API = "/customers/tenders";

    public Mono<String> getPaymentToken(TenderDeclineRequest request, String storeId) {
        return tokenVaultCaller.callTokenVaultService(request, WALLET_FETCH_TOKEN_BATCH_API, storeId)
                .bodyToMono(String.class)
                .flatMap( r -> {
                    return Mono.just(r);
                })
                .onErrorResume(error -> {
                    return Mono.error(error);
                });
    }
}
