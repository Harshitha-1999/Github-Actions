package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NotBlankValidator implements ConstraintValidator<NotBlank, String> {

    private ValidationErrorCode error;

    @Override
    public void initialize(NotBlank constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        if (object == null || object.trim().isEmpty()) {
            throw new DataValidationException(error.getCode(), error.getMessage());
        }
        return true;
    }
}