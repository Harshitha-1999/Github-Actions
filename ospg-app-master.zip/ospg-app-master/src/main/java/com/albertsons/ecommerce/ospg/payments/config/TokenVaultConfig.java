package com.albertsons.ecommerce.ospg.payments.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

@Slf4j
//@Profile("!local")
@Configuration
public class TokenVaultConfig {

    @Value("${token.vault.service.url}")
    private String url;

    private HttpClient tokenVaultClient;

    @Bean("tokenVaultClient")
    public WebClient getTokenVaultWebclient() {
        log.info("getTokenVaultWebclient() >> Started");
        tokenVaultClient = HttpClient.create().baseUrl(url);
        return WebClient.builder()
                .baseUrl(url)
                .clientConnector(new ReactorClientHttpConnector(tokenVaultClient))
                .build();
    }

}
