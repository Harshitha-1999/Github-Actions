package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentInstrument {
    private Card card;
    //    private UserProfile userProfile;
    private Encrypted encrypted;
    private ECP ecp;
    private EUDD eudd;
    private String targetCardBrand;
    private String customerAccountType;
}
