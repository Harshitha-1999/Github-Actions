package com.albertsons.ecommerce.ospg.payments.dao;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.model.MerchRefTyp;
import io.r2dbc.spi.ConnectionFactory;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.stereotype.Component;

import com.albertsons.ecommerce.ospg.payments.entity.AuthDetails;

import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@NoArgsConstructor
public class TransactionCacheLoaderDao {

    @Autowired
    ConnectionFactory connectionFactory;

    @Autowired
    private R2dbcEntityTemplate template;

    private static final String FETCH_CARD_TYP_QUERY = "select CARD_NM, CARD_TYP_CD from "
            + "[OSPGPAYTX].[CARD_TYP]";

    private static final String FETCH_TOKEN_TYP_QUERY = "select TOKEN_NM, TOKEN_TYP_CD from "
            + "[OSPGPAYTX].[TOKEN_TYP]";

    private static final String FETCH_MERCH_REF_TYP_QUERY = "select MERCH_REF_TYP_CD, MERCH_REF_NM, STORE_ID, MARKET_PLACE_MID, MERCH_REF_DSC from "
            + "[OSPGPAYTX].[MERCH_REF_TYP] where STORE_STATUS_IND = :IND";

    private static final String FETCH_FULL_AUTH_STORE_QUERY = "select STORE_ID, IS_ENABLED from "
            + "[OSPGPAYTX].[FULL_AUTH_STORES]";

    private static final String FETCH_STORED_CRED_STORE_QUERY = "select STORE_ID, IS_ENABLED from "
            + "[OSPGPAYTX].[STORED_CRED_STORES]";

    private static final String FETCH_FEATURE_FLAGS_QUERY = "select NAME, VALUE from "
            + "[OSPGPAYTX].[FEATURE_FLAG]";

    private static final String FETCH_TRANSACTION_TYP_QUERY = "select TRANSACTION_NM, TRANSACTION_TYP_CD from "
            + "[OSPGPAYTX].[TRANSACTION_TYP]";

    private static final String FETCH_TRANSACTION_STATUS_TYP_QUERY = "select TRANSACTION_STATUS_NM, "
            + "TRANSACTION_STAT_TYP_CD from [OSPGPAYTX].[TRANSACTION_STATUS_TYP]";

    private static final String FETCH_VALIDATION_STATUS_TYP_QUERY = "select VALIDATION_STATUS_NM, "
            + "VALIDATION_STATUS_TYP_CD from [OSPGPAYTX].[VALIDATION_STATUS_TYP]";

    public static final String FETCH_ERROR_TYP_QUERY = "select ERROR_NM, ERROR_TYP_CD from "
            + "[OSPGPAYTX].[ERROR_TYP]";

    public static final String FETCH_PROC_STATUS_CODE_QUERY = "select PROC_STATUS_CODE from "
            + "[OSPGPAYTX].[OUTAGE_ERROR_CODE]";

    private static final String FETCH_SYNC_DATA_QUERY = "select TOKEN_TYP_CD, TOKEN_NBR, CARD_HOLDER_NM, " +
            "CARD_EXPIRY_DT, CARD_TYP_CD, ORDER_ID, tt.STORE_ID, tt.LAST_UPDATE_USER_ID, " +
            "MERCH_REF_TYP_CD, TRANSACTION_TYP_CD, TRANSACTION_STAT_TYP_CD, " +
            "TRANSACTION_AMT, PROVIDER_TRANSACTION_ID, TRANSACTION_TAG_TXT, CORRELATION_ID, AVS_RESPONSE_CD, " +
            "CLIENT_IP_TXT, ERROR_TYP_CD, BANK_RESPONSE_CD, BANK_RESPONSE_TXT, " +
            "GATEWAY_RESPONSE_CD, GATEWAY_RESPONSE_TXT from [OSPGPAYTX].[TRANSACTION_TOKEN] tt " +
            "join [OSPGPAYTX].[TRANSACTION] t on tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
            "join [OSPGPAYTX].[TRANSACTION_RESPONSE] tr on t.TRANSACTION_ID = tr.TRANSACTION_ID " +
            "where t.LAST_UPDATE_TS > :FROMDATE and t.TRANSACTION_TOKEN_ID = tr.TRANSACTION_TOKEN_ID " +
            "and tt.STORE_ID = :STOREID";

    private static final String FETCH_FAILED_CAPTURE_CALLS_INFO = "SELECT tt.TRANSACTION_TOKEN_ID " +
            "FROM [OSPGPAYTX].[TRANSACTION_TOKEN] tt " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION] t ON " +
            "	tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] tr ON " +
            "	t.TRANSACTION_ID = tr.TRANSACTION_ID " +
            "WHERE " +
            "tr.BANK_RESPONSE_CD IS NULL " +
            "AND t.TRANSACTION_TYP_CD = 5 " +
            "AND (t.TRANSACTION_STAT_TYP_CD = 2  OR t.TRANSACTION_STAT_TYP_CD = 3)" +
            "AND tr.LAST_UPDATE_TS > cast(getdate() - 1.0/24 as date)";

    private static final String FETCH_AUTH_FOR_FAILED_CAPTURES = "SELECT DISTINCT t.PROVIDER_TRANSACTION_ID, " +
            "t.TRANSACTION_AMT, t.TRANSACTION_TAG_TXT, tt.STORE_ID, tt.ORDER_ID " +
            "FROM [OSPGPAYTX].[TRANSACTION] t " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_TOKEN] tt " +
            "ON tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] tr " +
            "ON t.TRANSACTION_TOKEN_ID = tr.TRANSACTION_TOKEN_ID " +
            "WHERE t.TRANSACTION_STAT_TYP_CD = 1 " +
            "AND t.TRANSACTION_TYP_CD = 3 " +
            "AND tr.BANK_RESPONSE_CD = '100' " +
            "AND t.TRANSACTION_TOKEN_ID = :transactionTokenId";

    private static final String FETCH_DUPLICATE_AUTH_ORDERS = "SELECT TT.ORDER_ID FROM [OSPGPAYTX].[TRANSACTION_TOKEN] tt " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION] t ON " +
            "t.TRANSACTION_TOKEN_ID = tt.TRANSACTION_TOKEN_ID " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] tr ON " +
            "t.TRANSACTION_ID = tr.TRANSACTION_ID " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_TYP] typ ON " +
            "typ.TRANSACTION_TYP_CD = t.transaction_typ_cd " +
            "WHERE 1=1 " +
            "AND tr.LAST_UPDATE_TS > cast(getdate() - 1.0/24 as date) " +
            "AND t.transaction_typ_cd = 3 " +
            "AND t.transaction_stat_typ_cd = 1 " +
            "AND tr.BANK_RESPONSE_CD = '100' " +
            "AND tr.LAST_UPDATE_USER_ID LIKE 'ERUMS%' " +
            "AND tt.order_id IS NOT null " +
            "AND tt.store_id != 9999 " +
            "GROUP BY tt.TOKEN_NBR, tt.ORDER_ID " +
            "HAVING COUNT(*) > 1 ";

    private static final String FETCH_ORDER_FOR_VOID_TRANSACTION = "SELECT DISTINCT t.PROVIDER_TRANSACTION_ID, " +
            "t.TRANSACTION_AMT, t.TRANSACTION_TAG_TXT, tt.STORE_ID, tt.ORDER_ID " +
            "FROM [OSPGPAYTX].[TRANSACTION] t " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_TOKEN] tt " +
            "ON tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] tr " +
            "ON t.TRANSACTION_TOKEN_ID = tr.TRANSACTION_TOKEN_ID " +
            "WHERE t.TRANSACTION_STAT_TYP_CD = 1 " +
            "AND t.TRANSACTION_TYP_CD = 3 " +
            "AND tr.BANK_RESPONSE_CD = '100' " +
            "AND tt.ORDER_ID IS NOT NULL " +
            "and tt.ORDER_ID = :orderId " +
            "AND t.TRANSACTION_ID < ( " +
            "    SELECT " +
            "        MAX(t.TRANSACTION_ID) " +
            "    FROM [OSPGPAYTX].[TRANSACTION] t " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_TOKEN] tt " +
            "ON tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID " +
            "INNER JOIN [OSPGPAYTX].[TRANSACTION_RESPONSE] tr " +
            "ON t.TRANSACTION_TOKEN_ID = tr.TRANSACTION_TOKEN_ID " +
            "WHERE t.TRANSACTION_STAT_TYP_CD = 1 " +
            "AND t.TRANSACTION_TYP_CD = 3 " +
            "AND tr.BANK_RESPONSE_CD = '100' " +
            "AND tt.ORDER_ID IS NOT NULL " +
            "and tt.ORDER_ID = :orderId)";
    
    private static final String FETCH_AUTH_DETAILS = "SELECT "
    		+ "t.TRANSACTION_TAG_TXT, t.PROVIDER_TRANSACTION_ID, "
    		+ "t.TRANSACTION_AMT, tt.CARD_HOLDER_NM FROM "
    		+ "[OSPGPAYTX].[TRANSACTION_TOKEN] tt join "
    		+ "[OSPGPAYTX].[TRANSACTION] t on "
    		+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
    		+ "where tt.STORE_ID = :storeId and tt.ORDER_ID = :orderId "
    		+ "and t.TRANSACTION_TYP_CD = 3  and t.TRANSACTION_STAT_TYP_CD = 1;";

    public Mono<List<Map<String, Object>>> fetchOrderForVoidTransaction(BigDecimal orderId) {
        log.info("fetchOrderForVoidTransaction for orderId: {}",orderId);
        R2dbcEntityTemplate template = new R2dbcEntityTemplate(connectionFactory);

        return template.getDatabaseClient().sql(FETCH_ORDER_FOR_VOID_TRANSACTION)
                .bind("orderId", orderId)
                .fetch()
                .all()
                .collectList()
                .doOnError(e -> {
                    log.error("fetchOrderForVoidTransaction() >> error for order id: {} , error message: {}", orderId, e.getMessage());
                    e.printStackTrace();
                });
    }

    public Mono<List<BigDecimal>> fetchDuplicateAuthsOrders() {
        log.info("fetchDuplicateAuthsOrders fetching ");
        return template.getDatabaseClient().sql(FETCH_DUPLICATE_AUTH_ORDERS)
                .map((row, rowMetadata) -> {
                    return row.get("ORDER_ID", BigDecimal.class);
                })
                //.fetch()
                .all()
                .collectList()
                .doOnError(e -> {
                    log.error("fetchDuplicateAuthsOrders() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                });
    }

    public Mono<List<Map<String, Object>>> fetchAuthsForFailedCaptures(BigDecimal transactionTokenId) {
        log.info("fetchAuthsForFailedCaptures for transactionTokenId: {}",transactionTokenId);
        return template.getDatabaseClient().sql(FETCH_AUTH_FOR_FAILED_CAPTURES)
                .bind("transactionTokenId", transactionTokenId)
                .fetch()
                .all()
                .collectList()
                .doOnError(e -> {
                    log.error("fetchAuthsForFailedCaptures() >> error for transactionTokenId: {} , error message : {}" ,transactionTokenId, e.getMessage());
                    e.printStackTrace();
                });
    }

    public Mono<List<BigDecimal>> fetchFailedCaptureTokens() {
        log.info("fetchFailedCaptureTokens ...");
          return template.getDatabaseClient().sql(FETCH_FAILED_CAPTURE_CALLS_INFO)
                  .map((row, rowMetadata) -> {
                      return row.get("TRANSACTION_TOKEN_ID", BigDecimal.class);
                  })
                //.as(BigDecimal.class)
                //.fetch()
                .all()
                .collectList();

    }

    public Mono<List<Map<String, Object>>> fetchSyncData(String storeId, String fromDate) {
        log.info("Fetching sync data for storeId {} and fromDate {}", storeId, fromDate);
        return template.getDatabaseClient().sql(FETCH_SYNC_DATA_QUERY)
                .bind("FROMDATE", fromDate)
                .bind("STOREID", storeId)
                .fetch()
                .all()
                .collectList()
                .doOnError(e -> {
                    log.error("fetchSyncData() >> error for store id: {} , error message: {}",storeId, e.getMessage());
                    e.printStackTrace();
                });
    }

  /*  public Flux<MerchRefTyp> loadMerchRefTypReact() {
        log.info("Loading Merch Ref Type");
        //, MERCH_REF_TYP_CD, MERCH_REF_NM, STORE_ID
        return template.getDatabaseClient().sql(FETCH_MERCH_REF_TYP_QUERY)
                .bind("IND", "Y")
                .as(MerchRefTyp.class)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("Error loading MerchRefType " + e.getMessage());
                    e.printStackTrace();
                });
    }*/

   public void loadMerchRefTyp(Cache cache) {
        log.info("Loading Merch Ref Type");
        template.getDatabaseClient().sql(FETCH_MERCH_REF_TYP_QUERY)
                .bind("IND", "Y")
                .map(row -> new MerchRefTyp(row.get("MERCH_REF_TYP_CD",Long.class),
                                            row.get("MERCH_REF_NM",String.class),
                                            row.get("STORE_ID", Long.class),
                                            row.get("MARKET_PLACE_MID", String.class),
                                            row.get("MERCH_REF_DSC", String.class)))
                .all()
                .doOnError(e -> {
                    log.error("loadMerchRefTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Merch Ref Type" + result);
                    cache.put(result.getStoreId(), result);
                });
    }

    public void loadCardTyp(Cache cache) {
        log.info("Loading Card Typ");
        template.getDatabaseClient().sql(FETCH_CARD_TYP_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadCardTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Card Typ: " + result);
                    cache.put(result.get("CARD_NM"), result.get("CARD_TYP_CD"));
                });
    }

    public void loadTokenTyp(Cache cache) {
        log.info("Loading Token Typ");
        template.getDatabaseClient().sql(FETCH_TOKEN_TYP_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadTokenTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Token Typ: " + result);
                    cache.put(result.get("TOKEN_NM"), result.get("TOKEN_TYP_CD"));
                });
    }

    public void loadErrorTyp(Cache cache) {
        log.info("Loading Error Typ");
        template.getDatabaseClient().sql(FETCH_ERROR_TYP_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadErrorTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Error Typ: " + result);
                    cache.put(result.get("ERROR_NM"), result.get("ERROR_TYP_CD"));
                });
    }


    public void loadProcStatusCode(Cache cache) {
        log.info("loadProcStatusCode() >> Loading Proc status codes");
        getProcStatusListMono().subscribe(res -> {
            cache.put(GatewayConstants.PROC_STATUS_CODE, res);
        });
    }

    public Mono<List<String>> getProcStatusListMono() {
        return template.getDatabaseClient().sql(FETCH_PROC_STATUS_CODE_QUERY)
                .map((row, rowMetadata) -> {
                    return row.get(GatewayConstants.PROC_STATUS_CODE, String.class);
                })
                .all()
                .collectList()
                .doOnError(e -> log.error("getProcStatusListMono() >> error message: {}", e.getMessage()));
    }

    public void loadTransactionTyp(Cache cache) {
        log.info("Loading Transaction Typ");
        template.getDatabaseClient().sql(FETCH_TRANSACTION_TYP_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadTransactionTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Transaction Typ: " + result);
                    cache.put(result.get("TRANSACTION_NM"), result.get("TRANSACTION_TYP_CD"));
                });
    }

    public void loadTransactionStatusTyp(Cache cache) {
        log.info("Loading Transaction Status Typ");
        template.getDatabaseClient().sql(FETCH_TRANSACTION_STATUS_TYP_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadTransactionStatusTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Transaction Status Typ: " + result);
                    cache.put(result.get("TRANSACTION_STATUS_NM"), result.get("TRANSACTION_STAT_TYP_CD"));
                });
    }

    public void loadValidationStatusTyp(Cache cache) {
        log.info("Loading Validation Status Typ");
        template.getDatabaseClient().sql(FETCH_VALIDATION_STATUS_TYP_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadValidationStatusTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Validation Status Typ: " + result);
                    cache.put(result.get("VALIDATION_STATUS_NM"), result.get("VALIDATION_STATUS_TYP_CD"));
                });
    }

    public void loadFullAuthStoreTyp(Cache cache) {
        log.info("Loading Full Auth Store");
        template.getDatabaseClient().sql(FETCH_FULL_AUTH_STORE_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadFullAuthStoreTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Full Auth Store: " + result);
                    cache.put(result.get("STORE_ID"), result.get("IS_ENABLED"));
                });
    }

    public void loadStoredCredStoreTyp(Cache cache) {
        log.info("Loading Stored Cred Store");
        template.getDatabaseClient().sql(FETCH_STORED_CRED_STORE_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadStoredCredStoreTyp() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Store Cred Store: " + result);
                    cache.put(result.get("STORE_ID"), result.get("IS_ENABLED"));
                });
    }
    
    public Mono<AuthDetails> fetchAuthDetails(String orderId, String storeId){
    	
    	return template.getDatabaseClient()
    			.sql(FETCH_AUTH_DETAILS)
    			.bind("orderId", orderId)
    			.bind("storeId", storeId)
    			.fetch()
    			.first()
    			.cast(AuthDetails.class);
    }


    public void loadFeatureFlags(Cache cache) {
        log.info("Loading Feature Flags");
        template.getDatabaseClient().sql(FETCH_FEATURE_FLAGS_QUERY)
                .fetch()
                .all()
                .doOnError(e -> {
                    log.error("loadFeatureFlags() >> error message: {}",e.getMessage());
                    e.printStackTrace();
                })
                .subscribe(result -> {
                    log.debug("Processing Feature Flags: {}",   result);
                    cache.put(result.get("NAME"), result.get("VALUE"));
                });
    }

    public void loadChaseOrbitalUrlInfo(Cache cache) {
        log.info("Loading chase orbital url info cache");
        cache.put(GatewayConstants.PRIMARY_CHASE_ORBITAL_URL, true);
        cache.put(GatewayConstants.SECONDARY_CHASE_ORBITAL_URL, false);
    }
    public void loadSwitchChaseOutage(Cache cache) {
        log.info("Loading switch chase outage info cache");
        cache.put(GatewayConstants.ENABLE, false);
    }
}
