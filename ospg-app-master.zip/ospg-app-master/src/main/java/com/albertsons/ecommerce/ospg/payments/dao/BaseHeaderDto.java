package com.albertsons.ecommerce.ospg.payments.dao;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.validation.constraints.NotBlank;
import java.util.Optional;

@Data
@NoArgsConstructor
@FieldDefaults(makeFinal = false, level = AccessLevel.PRIVATE)
public class BaseHeaderDto {
    @NotBlank
    String aggregateId;
    @NotBlank
    String aggregateType;

    Long timestamp;

    String aggregateRevisionHash;

    Integer aggregateRevision;

    String customerId;
    Boolean forceUpdate;

    public Optional<Boolean> getForceUpdate() {
        return Optional.ofNullable(forceUpdate);
    }

    public Optional<Long> getTimestamp() {
        return Optional.ofNullable(timestamp);
    }

    public Optional<String> getAggregateId() {
        return Optional.ofNullable(aggregateId);
    }

    public Optional<String> getAggregateType() {
        return Optional.ofNullable(aggregateType);
    }

    public Optional<String> getAggregateRevisionHash() {
        return Optional.ofNullable(aggregateRevisionHash);
    }

    public Optional<Integer> getAggregateRevision() {
        return Optional.ofNullable(aggregateRevision);
    }

    public Optional<String> getCustomerId() {
        return Optional.ofNullable(customerId);
    }
}