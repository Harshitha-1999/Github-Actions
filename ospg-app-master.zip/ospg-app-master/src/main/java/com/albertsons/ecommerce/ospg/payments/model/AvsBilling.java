package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AvsBilling implements Serializable {
    private String avsZip;
    private String avsAddress1;
    private String avsAddress2;
    private String avsCity;
    private String avsState;
    private String avsPhone;
    private String avsPhoneType;
    private String avsName;
    private String avsCountryCode;
    private String avsRespCode;
    private String hostAVSRespCode;
}
