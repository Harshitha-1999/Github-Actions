package com.albertsons.ecommerce.ospg.payments.exceptions;

import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class DuplicateContentResponseException extends RuntimeException {


	private static final long serialVersionUID = 1L;
	
	private HttpStatus status;
	private TransactionResponse errorResponse;
	private String message;
	private String orderId;

	public DuplicateContentResponseException(HttpStatus conflict, TransactionResponse duplicateTransactionErrorResponse,String message,String orderId) {
		this.status=conflict;
		this.errorResponse=duplicateTransactionErrorResponse;
		this.message=message;
		this.orderId=orderId;
	}
}
