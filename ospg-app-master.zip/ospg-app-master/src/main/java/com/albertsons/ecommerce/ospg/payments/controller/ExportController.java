package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.model.request.ECHORequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ECHOResponse;
import com.albertsons.ecommerce.ospg.payments.service.ExportService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RequestMapping("/transaction")
@RestController
public class ExportController {
    @Autowired
    private ExportService exportService;

    @Operation(summary = "Validates the input and makes secure service call to Chase for authorizing transaction.")
    @PostMapping(value = "/echo-export")
    public   Mono<ECHOResponse> exportData(@RequestBody ECHORequest request) {
       return exportService.exportData(request);
    }
}
