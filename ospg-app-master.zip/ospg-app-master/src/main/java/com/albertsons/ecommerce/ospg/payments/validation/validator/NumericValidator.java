package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NumericValidator implements ConstraintValidator<Numeric, String> {

    private ValidationErrorCode error;

    @Override
    public void initialize(Numeric constraintAnnotation) {
        this.error = constraintAnnotation.error();
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        if (object == null || StringUtils.isEmpty(object)) {
            return true;
        }
        try {
            Double.parseDouble(object);
        } catch (Exception e) {
            throw new DataValidationException(error.getCode(), error.getMessage());
        }

        return true;
    }
}