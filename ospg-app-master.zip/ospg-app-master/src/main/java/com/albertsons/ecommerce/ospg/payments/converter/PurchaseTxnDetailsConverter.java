package com.albertsons.ecommerce.ospg.payments.converter;

import com.albertsons.ecommerce.ospg.payments.entity.PurchaseTransactionDetails;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class PurchaseTxnDetailsConverter implements Converter<Row, PurchaseTransactionDetails> {

    @Override
    public PurchaseTransactionDetails convert(Row row) {
        PurchaseTransactionDetails details = new PurchaseTransactionDetails();
        details.setTransactionTag(row.get("TRANSACTION_TAG_TXT", String.class));
        details.setProviderTransactionId(row.get("PROVIDER_TRANSACTION_ID", String.class));
        return details;
    }
}
