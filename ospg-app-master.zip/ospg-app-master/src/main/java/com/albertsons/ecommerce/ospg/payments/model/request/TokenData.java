package com.albertsons.ecommerce.ospg.payments.model.request;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.validation.OnAuthorize;
import com.albertsons.ecommerce.ospg.payments.validation.OnPurchase;
import com.albertsons.ecommerce.ospg.payments.validation.OnRefund;
import com.albertsons.ecommerce.ospg.payments.validation.validator.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import static com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode.*;

/**
 * Json Object which holds the value of the tokenized card info be it via the
 * FDToken tokenization process.
 * 
 */
@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TokenData {

	@NotBlank(error = ValidationErrorCode.TOKEN_DATA_VALUE, groups = {OnAuthorize.class, OnRefund.class})
	@Numeric(error = ValidationErrorCode.TOKEN_NUMBER, groups={OnAuthorize.class, OnRefund.class})
	private String value = StringUtils.EMPTY;

	@NotBlank(error = ValidationErrorCode.CARD_TYPE_INVALID_VALUE, groups={OnAuthorize.class})
	@CCType(error = ValidationErrorCode.CARD_TYPE_INVALID_VALUE, groups = {OnAuthorize.class})
	@RefundCCType(error = ValidationErrorCode.CARD_TYPE_INVALID_VALUE, groups = {OnRefund.class})
	private String type = StringUtils.EMPTY;

	@NotBlank(error = CARDHOLDER_NAME, groups={OnRefund.class, OnAuthorize.class,OnPurchase.class})
	//@Alphabet(error = CARDHOLDER_NAME, groups={OnRefund.class})
	@JsonProperty("cardholder_name")
	private String cardholderName = StringUtils.EMPTY;

	@Past(error = CARD_EXPIRY_DATE_FORMAT, groups={OnRefund.class, OnAuthorize.class, OnPurchase.class})
	@JsonProperty("exp_date")
	private String expiryDate = StringUtils.EMPTY;

	//@CVV(error = CVV_NUMBER, groups={OnAuthorize.class})
	@JsonProperty("cvv")
	@Numeric(error = CVV_NUMBER, groups={OnAuthorize.class})
	//@CVV(error = ValidationErrorCode.CVV, groups = {OnAuthorize.class})
	private String cvv = StringUtils.EMPTY;

}
