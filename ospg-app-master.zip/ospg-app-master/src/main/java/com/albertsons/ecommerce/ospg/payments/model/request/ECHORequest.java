package com.albertsons.ecommerce.ospg.payments.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ECHORequest {
    private String transactionNm;
    private int transactionTokenId;
    private String transactionStatNm;
    private String bankResponseCd;
    private String storeId;
    private String orderId;
    private String clientIpTxt;
    private String lastUpdateUserId;
}
