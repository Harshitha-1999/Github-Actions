package com.albertsons.ecommerce.ospg.payments.dao;

import com.albertsons.ecommerce.ospg.payments.entity.*;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.exceptions.DuplicateContentResponseException;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.CreditCardType;
import com.albertsons.ecommerce.ospg.payments.model.request.ECHORequest;
import com.albertsons.ecommerce.ospg.payments.model.request.Token;
import com.albertsons.ecommerce.ospg.payments.model.request.TokenData;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ECHOResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.repositories.*;
import com.albertsons.ecommerce.ospg.payments.service.PaymentGatewayServiceHelper;
import com.albertsons.ecommerce.ospg.payments.util.DateUtil;
import com.albertsons.ecommerce.ospg.payments.util.TransactionCacheUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;

@Component
public class TransactionsDAO {

	private static final String REGULAR_EXPRESSION = "[*0-9]";
	public static final String PURCHASE = "purchase";
	List<String> orderAheadStores= Arrays.asList("9997","9998");

	@Autowired
	private TransactionsRepository transactionsRepository;

	@Autowired
	private TransactionTokenRepository transactionTokenRepository;

	@Autowired
	private ExportRepo exportRepo;

	@Autowired
	private TransactionResponseRepository transactionResponseRepository;

	@Autowired
	private TransactionCacheUtils cacheUtils;

	@Autowired
	private PaymentGatewayServiceHelper serviceHelper;
	
	@Autowired
	private AuthDetailsRepo authDetailsRepo;

	@Loggable
	private SecurityLogger log;

	@Autowired
	private TransactionDetailsRepo transactionDetailsRepo;

	private static final String DUPLICATE_TRANSACTION_EXCEPTION = "Duplicate Transaction Exception";

	private static final String TRANSACTION_STATUS_APPROVED = "approved";

	public static final String SUCCESS_BANK_RESPONSE_CODE = "100";

	public static final String SUCCESS_GATEWAY_RESPONSE_CODE = "00";

	@Autowired
	private R2dbcEntityTemplate template;
	@Autowired
	private ObjectMapper objectMapper;

	private final String FETCH_TOKEN_NBR = "select top 1 TOKEN_NBR "
			+ "from [OSPGPAYTX].[TRANSACTION_TOKEN] "
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "where tt.ORDER_ID=:orderId and "
			+ "tt.STORE_ID=:storeId and "
			+ "t.transaction_typ_cd = 3 ";

	private final String FETCH_PROVIDER_ID = "select top 1 t.PROVIDER_TRANSACTION_ID "
			+ "from [OSPGPAYTX].[TRANSACTION_TOKEN] "
			+ "as tt inner "
			+ "join [OSPGPAYTX].[TRANSACTION] as t on "
			+ "tt.TRANSACTION_TOKEN_ID = t.TRANSACTION_TOKEN_ID "
			+ "where tt.ORDER_ID=:orderId and "
			+ "tt.STORE_ID=:storeId and "
			+ "t.transaction_typ_cd = 3 ";

	public void saveSuccessTransaction(TransactionRequest request, TransactionResponse response) {

		saveTransactionToken(request, response).flatMap(result -> {
			Transaction t = buildTransacation(request, response);
			t.setTransactionTokenId(result);
			return saveTransaction(t).doOnSuccess(r -> {
				TransactionResponseEntity resp = buildResponse(request, response);
				resp.setTransactionId(r);
				resp.setTransactionTokenId(result);
				saveTransactionResponse(resp).subscribe();
			}).doOnError(e -> log.error("saveSuccessTransaction() >> error message: {} , exception : ",e.getMessage(), e));
		}).doOnError(e -> {
			log.error("saveSuccessTransaction() >> error message: {} , exception : ",e.getMessage(), e);
		}).subscribe();

	}

	public Mono<String> getCardHolderNameFromAuth(TransactionRequest request) {

		Mono<String> cardHolderName = transactionsRepository.getCardHolderNameFromAuth(
				request.getToken().getTokenData().getValue(),
				new BigDecimal(request.getStoreId()));

		TokenData tokendata = request.getToken().getTokenData();
		return cardHolderName.flatMap(value -> {
			log.info("Name :"+value);
			tokendata.setCardholderName(value);
			return Mono.just(value);
		}).switchIfEmpty(Mono.defer(() -> {
			tokendata.setCardholderName(tokendata.getCardholderName().replaceAll(REGULAR_EXPRESSION, ""));
			return Mono.just("");
		}));

	}

	private Mono<BigDecimal> saveTransactionToken(TransactionRequest request, TransactionResponse response) {
		return checkIfTokenExists(request).flatMap(
				token -> Mono.just(token)
		)
				.switchIfEmpty(Mono.defer(() -> {
					TransactionToken token = buildTransacationToken(request, response);
					Mono<Long> transactionToken =  transactionTokenRepository.saveTransactionToken(token.getTokenTypCd(), token.getTokenNbr(),
							token.getCardHolderNm(), token.getCardExpiryDt(), token.getCardTyp(), token.getOrderId(),
							token.getStoreId(), token.getLastUpdateUserId(), token.getLastUpdateTs(), token.getLastUpdateTs(), token.getMitReceivedTranId());
					return transactionToken.map(val ->  {
						log.info("saveTransactionToken >> data saved in transactionToken : {} " , val);
						return new BigDecimal(val);
					});
				}));
	}

	private Mono<BigDecimal> saveTransaction(Transaction transaction) {
		Mono<Long> transactionTokenResponse =  transactionsRepository.saveTransactions(transaction.getTransactionTokenId(), transaction.getMerchRefTyp(),
				transaction.getTransactionTyp(), transaction.getTransactionStatusTyp(),
				transaction.getValidationStatusTyp(), transaction.getTransactionAmt(),
				transaction.getProviderTransactionId(), transaction.getTransactionTagTxt(),
				transaction.getCorrelationId(), transaction.getAvsResponseCd(), transaction.getTransactionStartTs(),
				transaction.getTransactionEndTs(), transaction.getClientIpTxt(), transaction.getLastUpdateUserId(),
				transaction.getLastUpdateTs(), transaction.getExpiryTs(), transaction.getSellerId());
		return transactionTokenResponse.map(val -> {
			log.info("saveTransaction() >> data saved in transaction : {}" , val);
			return new BigDecimal(val);
		});

	}

	private Mono<BigDecimal> saveTransactionResponse(TransactionResponseEntity resp) {
		Mono<Long> transactionResponse = transactionResponseRepository.saveTransactionResponse(resp.getTransactionId(), resp.getTransactionTokenId(),
				resp.getErrorTyp(), resp.getBankResponseCd(), resp.getBankResponseTxt(), resp.getGatewayResponseCd(),
				resp.getGatewayResponseTxt(), resp.getLastUpdateUserId(), resp.getLastUpdateTs(), resp.getExpiryTs());
		return transactionResponse.map(val -> {
			log.info("saveTransactionResponse() >> data saved in transaction response: {}" , val);
			return new BigDecimal(val);
		});
	}

	private TransactionToken buildTransacationToken(TransactionRequest request, TransactionResponse response) {

		BigDecimal orderId = request.getOrderId() != null ? new BigDecimal(request.getOrderId()) : null;
		TransactionToken token = TransactionToken.builder()
				.cardExpiryDt(request.getToken().getTokenData().getExpiryDate())
				.cardHolderNm(request.getToken().getTokenData().getCardholderName())
				.cardTyp(cacheUtils.getCardTyp(CreditCardType.getValueByKey(request.getToken().getTokenData().getType())))
				.orderId(orderId)
				.storeId(new BigDecimal(request.getStoreId())).tokenNbr(request.getToken().getTokenData().getValue())
				// .tokenTypCd(request.getToken().getTokenType())
				.tokenTypCd(1).lastUpdateTs(DateUtil.convertInstantToSqlDate(Instant.now()))
				.lastUpdateUserId(getLastUpdatedUser(request.getSource(), request.getStoreId()))
				.mitReceivedTranId(response.getStoredCredentials() != null ? response.getStoredCredentials().getCardBrandOriginalTransactionId() : null)
				.build();

		return token;
	}

	private Transaction buildTransacation(TransactionRequest request, TransactionResponse response) {
		String transactionTag = null;

		if (null!=request.getTransactionTag() && TransactionType.PURCHASE.name().equalsIgnoreCase(request.getTransactionType())
				|| TransactionType.CAPTURE.name().equalsIgnoreCase(request.getTransactionType())) {
			transactionTag = request.getTransactionTag();
		} else {
			transactionTag = response.getTransactionTag();
		}
		Transaction transaction = Transaction.builder().clientIpTxt(request.getClientIP())
				/*.correlationId(
						(response.getCorrelationId() == null) ? null : Double.valueOf(response.getCorrelationId()))*/
				.correlationId(
						(response.getCorrelationId() == null) ? Double.valueOf(0) : Double.valueOf(response.getCorrelationId()))
				.avsResponseCd(response.getAvs())
				.merchRefTyp(cacheUtils.getMerchRefType(request.getStoreId()).getMerchRefTypCd())
				.providerTransactionId(response.getTransactionId())
				.transactionAmt(new BigDecimal(response.getAmount()))
				.transactionStartTs(DateUtil.convertInstantToSqlDate(Instant.now()))
				.transactionEndTs(DateUtil.convertInstantToSqlDate(Instant.now()))
				.transactionStatusTyp(cacheUtils.getTransactionStatusTyp(response.getTransactionStatus()))
				.transactionTyp(cacheUtils.getTransactionTyp(
						!StringUtils.isEmpty(response.getTransactionType()) ? response.getTransactionType().toLowerCase() : ""))
				.validationStatusTyp(cacheUtils.getValidationStatusTyp(response.getValidationStatus()))
				.transactionTagTxt(transactionTag)
				.expiryTs(DateUtil.convertInstantToSqlDate(Instant.now()))
				.lastUpdateTs(DateUtil.convertInstantToSqlDate(Instant.now()))
				.lastUpdateUserId(getLastUpdatedUser(request.getSource(), request.getStoreId()))
				.sellerId(request.getSellerId()).build();
		return transaction;
	}

	private TransactionResponseEntity buildResponse(TransactionRequest request, TransactionResponse response) {

		TransactionResponseEntity token = TransactionResponseEntity.builder().bankResponseCd(response.getBankRespCode())
				.bankResponseTxt(response.getBankMessage()).gatewayResponseCd(response.getGatewayRespCode())
				.gatewayResponseTxt(response.getGatewayMessage())
				.lastUpdateTs(DateUtil.convertInstantToSqlDate(Instant.now()))
				.lastUpdateUserId(getLastUpdatedUser(request.getSource(), request.getStoreId())).build();
		return token;
	}

	public Mono<TransactionResponse> checkIfDuplicate(TransactionRequest request) {

		Mono<Integer> count = transactionsRepository.fetchRefundDuplicateTransaction(new BigDecimal(request.getAmount()),
				new BigDecimal(request.getOrderId()), new BigDecimal(request.getStoreId()),
				request.getToken().getTokenData().getValue(),
				cacheUtils.getTransactionStatusTyp("approved").toString());
		// count.subscribe();

		return count.flatMap(c -> {
			if (c > 0) {
				throw new DuplicateContentResponseException(HttpStatus.CONFLICT,
						getDuplicateTransactionErrorResponse(request,null,null),"duplicate transaction in purchase",request.getOrderId());
			} else {
				return Mono.just(new TransactionResponse());
			}
		});
	}

	public Mono<TransactionResponse> checkIfDuplicatePurchase(TransactionRequest request) {
		log.info("checkIfDuplicatePurchase() check for conflict purchase for order: "+request.getOrderId());
		Mono<PurchaseTransactionDetails> purchaseTransactionDetailsMono = transactionsRepository.fetchDuplicateTransactionPurchase(
				new BigDecimal(request.getOrderId()),
				new BigDecimal(request.getStoreId()),
				request.getToken().getTokenData().getValue(),
				//cacheUtils.getTransactionTyp(request.getTransactionType()).toString(),
				cacheUtils.getTransactionStatusTyp("approved").toString());
		return purchaseTransactionDetailsMono.flatMap(provTxnID -> {
			if (null!=provTxnID.getProviderTransactionId()) {
				log.info("checkIfDuplicatePurchase() conflict "+request.getOrderId());
				throw new DuplicateContentResponseException(HttpStatus.CONFLICT,
						getDuplicateTransactionErrorResponse(request,provTxnID.getProviderTransactionId(),provTxnID.getTransactionTag()),"duplicate transaction in purchase",request.getOrderId());
			} else {
				log.info("checkIfDuplicatePurchase() new purchase for order: "+request.getOrderId());
				return Mono.just(new TransactionResponse());
			}
		}).switchIfEmpty(Mono.defer(() -> {
			log.info("checkIfDuplicatePurchase() new purchase for order: "+request.getOrderId());
			return Mono.just(new TransactionResponse());
		}));
	}

	public Mono<TransactionResponse> checkIfRefundDuplicate(TransactionRequest request) {
		// This happens only when Vpos send retry flag - we need to check for
		// duplicate scenario.
		if (request.isRetry()) {
			return this.checkIfDuplicate(request);
		}
		return Mono.just(new TransactionResponse());
	}

	public Mono<String> fetchProviderTransactionId(String orderId, String storeId) {
		log.info("fetchProviderTransactionId() >> orderId: {} , store id: {}",orderId,storeId);
		Mono<String> res = transactionsRepository.fetchProviderTransactionId(orderId, storeId)
				.doOnError(error -> log.error("fetchProviderTransactionId() >> fetching provide id failed for order id: " +orderId+ " , store id: " +storeId+ " , error : ", error));
		
		return res.flatMap(r -> {
			log.info("providerId : "+r);
			return Mono.just(r);
		});
	}

	public Mono<String> fetchProviderTransactionIdAndTag(TransactionRequest request) {
		log.info("fetchProviderTransactionIdAndTag() >> order id: {} , store id: {}",request.getOrderId(),request.getStoreId());
		Mono<String> res = transactionsRepository.fetchProviderTransactionIdAndTag(new BigDecimal(request.getOrderId()),
				new BigDecimal(request.getStoreId()))
				.doOnError(e -> {
					log.error("fetchProviderTransactionIdAndTag() >> error for order id: "+request.getOrderId()+" , error message: "+e.getMessage()+" , exception: ", e);
				});

		return res.flatMap(r -> {
			log.info("fetchProviderTransactionIdAndTag() >> provider transaction id : " + r);
			return Mono.just(r);
		}).switchIfEmpty(Mono.just(""));
	}

	public Mono<String> fetchCardType(TransactionRequest request) {
		return transactionsRepository.fetchCardType(request.getStoreId(), request.getToken().getTokenData().getValue());
	}

	/*public Mono<List<ECHOResponse>> export(ECHORequest request) {
		return ospgExportRepository.export(request);
	}*/

	public Boolean isStoreLinkedAuthEnabled(String storeId) {
		return cacheUtils.getFullAuthStore(storeId);
	}

	private String getLastUpdatedUser(String source, String storeId) {
		StringBuilder lastUpdateUser = new StringBuilder();
		if (StringUtils.isBlank(source)) {
			lastUpdateUser.append(storeId);
		} else {
			lastUpdateUser.append(source).append(storeId);
		}
		return lastUpdateUser.toString();
	}

	private TransactionResponse getDuplicateTransactionErrorResponse(TransactionRequest transactionRequest,String provTransactionId,String transactionTag) {
		TransactionResponse transactionResponse;
		TokenData requestTokenData = transactionRequest.getToken().getTokenData();
		transactionResponse = new TransactionResponse();
		transactionResponse.setAmount(transactionRequest.getAmount());
		transactionResponse.setTransactionId(provTransactionId);
		transactionResponse.setTransactionType(transactionRequest.getTransactionType());
		transactionResponse.setTransactionTag(transactionTag);
		transactionResponse.setErrorMessage(DUPLICATE_TRANSACTION_EXCEPTION);
		TokenData tokenData = TokenData.builder()
				.type(requestTokenData.getType())
				.value(requestTokenData.getValue())
				.build();
		Token token = Token.builder()
				.tokenData(tokenData)
				.build();
		transactionResponse.setToken(token);
		transactionResponse.setTransactionStatus(TRANSACTION_STATUS_APPROVED);
		transactionResponse.setGatewayRespCode(SUCCESS_GATEWAY_RESPONSE_CODE);
		transactionResponse.setBankRespCode(SUCCESS_BANK_RESPONSE_CODE);
		return transactionResponse;
	}


	private Mono<BigDecimal> checkIfTokenExists(TransactionRequest request) {
		String tokenNbr = null;
		if (request.getToken() != null && request.getToken().getTokenData() != null) {
			tokenNbr = request.getToken().getTokenData().getValue();
		} else {
			log.warn("checkIfTokenExists(): Token is null!");
		}

		if (!StringUtils.isEmpty(request.getOrderId())) {
			Mono<Long> transactionToken = transactionTokenRepository.fetchTransactionToken(tokenNbr, Long.valueOf(request.getOrderId()),Long.valueOf(request.getStoreId()));
			return transactionToken.map(token -> {
				return new BigDecimal(token);
			});
		} else {
			return transactionTokenRepository.fetchTransactionTokenForAuthorize(tokenNbr,
					new BigDecimal(request.getStoreId()));
		}
	}

	public Mono<AuthDetails> getPrevAuthDetails(TransactionRequest request){

		if(null!=request.getToken().getTokenData()) {
			log.info("getPrevAuthDetails() >> token value: {}", request.getToken().getTokenData().getValue());
		}
		Mono<AuthDetails> auth;
		log.info("getPrevAuthDetails() >> order id: {} , store id: {}",request.getOrderId(),request.getStoreId());

		if (orderAheadStores.contains(request.getStoreId())) {
			auth = authDetailsRepo.fetchOrderAheadAuthDetails(request.getOrderId(),
					request.getStoreId(),
					request.getToken().getTokenData().getValue())
					.doOnError(e -> {
						log.error("getPrevAuthDetails() order Ahead details >> error message: {} , exception: ", e.getMessage(), e);
					});
		} else {
			auth = authDetailsRepo.fetchAuthDetails(request.getOrderId(),
					request.getStoreId(),
					request.getToken().getTokenData().getValue())
					.doOnError(e -> {
						log.error("getPrevAuthDetails() >> error message: {} , exception: ", e.getMessage(), e);
					});
		}

		return auth.flatMap(r -> {
			log.info("fetchProviderTransactionIdAndTag() >> provider transaction id : " + r);
			return Mono.just(r);
		}).switchIfEmpty(Mono.just(new AuthDetails()));

	}

	public Mono<AuthDetails> getPurchaseDetails(TransactionRequest request){

		//log.info("TransactionDAO >> getPurchaseDetails ->  token {} ",request.getToken().getTokenData().getValue());
    
		Mono<AuthDetails> auth = authDetailsRepo.fetchPurchaseDetails(request.getOrderId(),
				request.getStoreId())
				.doOnError(e -> {
					log.error("getPurchaseDetails() >> error message: {} , exception: ",e.getMessage(), e);
				});
		
		return auth.flatMap(r -> {
			return Mono.just(r);
		}).switchIfEmpty(Mono.just(new AuthDetails()));
		
	}


	/*private void errorOut() {
		throw new DuplicateContentResponseException("Duplicate Exception");
	}*/

	public Mono<List<String>> fetchTokenNumber(TransactionRequest request) {
		log.info("TransactionDAO >> fetchTokenID");
		return template.getDatabaseClient().sql(FETCH_TOKEN_NBR)
				.bind("orderId", request.getOrderId())
				.bind("storeId", request.getStoreId())
				.map((row, rowMetadata) -> {
					return row.get("TOKEN_NBR", String.class);
				})
				.all()
				.collectList().flatMap(value -> {
					return Mono.just(value);
				});
	}

	public Mono<List<String>> fetchProviderTransactionIdForTypeCode(TransactionRequest request) {
		log.info("TransactionDAO >> fetchProviderTransactionId");
		return template.getDatabaseClient().sql(FETCH_PROVIDER_ID)
				.bind("orderId", request.getOrderId())
				.bind("storeId", request.getStoreId())
				.map((row, rowMetadata) -> {
					return row.get("PROVIDER_TRANSACTION_ID", String.class);
				})
				.all()
				.collectList().flatMap(value -> {
					return Mono.just(value);
				});
	}

    public Mono<ECHOResponse> exportData(ECHORequest request) {
		try {
			log.info("exportData() >> echo export request: {}", objectMapper.writeValueAsString(request));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		Mono<ECHOResponse> auth = null;
		String transactionStatusName = null != request.getTransactionStatNm() ? request.getTransactionStatNm().toLowerCase() : null;
		if (StringUtils.isEmpty(request.getTransactionNm())) {
			auth = exportRepo.exportData(request.getBankResponseCd(), transactionStatusName, new BigDecimal(request.getStoreId()), request.getOrderId())
					.doOnError(e -> {
						log.error("exportData() >> error message: {} , exception: ", e.getMessage(), e);
					});
		} else if (PURCHASE.equalsIgnoreCase(request.getTransactionNm())) {
			auth = exportRepo.exportPurchaseOrCaptureData(request.getBankResponseCd(), transactionStatusName, new BigDecimal(request.getStoreId()), request.getOrderId())
					.doOnError(e -> {
						log.error("exportData() >> error message: {} , exception: ", e.getMessage(), e);
					});
		} else {
			auth = exportRepo.exportAuthorizeData(request.getTransactionNm(), request.getBankResponseCd(), transactionStatusName, new BigDecimal(request.getStoreId()), request.getOrderId())
					.doOnError(e -> {
						log.error("exportData() >> error message: {} , exception: ", e.getMessage(), e);
					});
		}

		return auth.flatMap(r -> {
			log.info("exportData() >> echo export response: {}",serviceHelper.getJsonPayload(r));
			return Mono.just(r);
		}).switchIfEmpty(Mono.just(new ECHOResponse()));
	}

	public Mono<TransactionDetails> fetchMitReceivedTranId(TransactionRequest request){
		return transactionDetailsRepo.fetchMitReceivedTranId(request.getToken().getTokenData().getValue(),
				request.getStoreId(), request.getOrderId());
	}

	public Mono<TransactionDetails> fetchMitReceivedTranIdByToken(TransactionRequest request){
		return transactionDetailsRepo.fetchMitReceivedTranId(request.getToken().getTokenData().getValue());
	}

}
