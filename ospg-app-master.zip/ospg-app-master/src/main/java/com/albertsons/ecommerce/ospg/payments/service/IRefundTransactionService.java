package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import reactor.core.publisher.Mono;

public interface IRefundTransactionService {
    Mono<TransactionResponse> refund(TransactionRequest refReq);

    Mono<TransactionResponse> subscriptionRefund(TransactionRequest refReq);
}
