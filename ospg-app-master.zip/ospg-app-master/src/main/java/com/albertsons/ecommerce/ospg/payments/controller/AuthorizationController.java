package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.IAuthorizeTransactionService;
import com.albertsons.ecommerce.ospg.payments.service.PaymentGatewayServiceHelper;
import com.albertsons.ecommerce.ospg.payments.validation.OnAuthorize;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * @author MSUND21
 */

@RestController
@Slf4j
public class AuthorizationController implements IAuthorizeTransactions {

    @Autowired
    private IAuthorizeTransactionService chaseService;

    private static final String STATUS_APPROVED = "approved";

    @Autowired
    private PaymentGatewayServiceHelper serviceHelper;

    public Mono<ResponseEntity<TransactionResponse>> preAuth(@Validated({OnAuthorize.class}) TransactionRequest request) {
       // validateTransactionType(request);
        Mono<TransactionResponse> response = chaseService.preauth(request);
        return getResponseEntityCore(response);
    }

    @Override
    public Mono<ResponseEntity<TransactionResponse>> preAuthDummy(@Validated({OnAuthorize.class}) TransactionRequest request) {
        Mono<TransactionResponse> response = chaseService.preAuthDummy(request);
        return getResponseEntityCore(response);
    }

    private Mono<ResponseEntity<TransactionResponse>> getResponseEntityCore(Mono<TransactionResponse> response) {
        return response.map(res -> {
            if (res != null && res.getToken() != null && res.getToken().getTokenData() != null) {
                res.getToken().getTokenData().setCvv(null);
            }
            if (res != null && res.getTransactionStatus() != null) {
                String transactionStatus = res.getTransactionStatus();
                if (transactionStatus.equalsIgnoreCase(Constants.APPROVED)) {
                    return new ResponseEntity<>(res, HttpStatus.CREATED);
                } else if (transactionStatus.equalsIgnoreCase(Constants.DECLINED)) {
                    log.info("getResponseEntityCore() preAuth client response: {}", serviceHelper.getJsonPayload(new ResponseEntity<>(res, HttpStatus.PRECONDITION_FAILED)));
                    return new ResponseEntity<>(res, HttpStatus.PRECONDITION_FAILED);
                }
            }
            return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
        });
    }

    private void validateTransactionType(TransactionRequest request) {
        if (!request.getTransactionType().equalsIgnoreCase(TransactionType.AUTHORIZE.name())) {
            throw  new DataValidationException(ValidationErrorCode.TRANSACTION_TYPE.getCode(),
                    ValidationErrorCode.TRANSACTION_TYPE.getMessage());
        }
    }
}
