package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.enumerations.OSPGTransactionCategory;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.exceptions.ChaseServerException;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import com.albertsons.ecommerce.ospg.payments.exceptions.VoidFailureExceptions;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.request.ReversalRequest;
import com.albertsons.ecommerce.ospg.payments.model.request.Token;
import com.albertsons.ecommerce.ospg.payments.model.request.TokenData;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ErrorResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.ReversalResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.util.PaymentUtil;
import com.albertsons.ecommerce.ospg.payments.util.ResponseCodeUtil;
import com.albertsons.ecommerce.ospg.payments.util.TransactionCacheUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.ssl.SslHandshakeTimeoutException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.PrematureCloseException;

import java.util.List;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.CHASE_OUTAGE_MESSAGE;
import static com.albertsons.ecommerce.ospg.payments.constants.Constants.VOID_RETRY_TRACE_CONSTANT;

/**
 * @author shiva chalamala.
 */

@Service
public class VoidTransactionService implements IVoidTransactionService {

    @Autowired
    private ChaseCaller caller;

    @Value("${chase.void.transaction.url}")
    private String voidPaymentUrl;

    private final String CREDIT_CARD = "credit_card";

    public static final String PO_DUMMY_TRANSACTION_ID = "FDOWN99999";

    @Autowired
    private CommonService commonService;

    @Autowired
    private TransactionsDAO dao;

    @Autowired
    ErrorHandlingService errorHandlingService;

    @Autowired
    private PaymentGatewayServiceHelper serviceHelper;

    @Autowired
    private TransactionCacheUtils cacheUtils;

    @Loggable
    private SecurityLogger log;

    public Mono<TransactionResponse> voidTransaction(TransactionRequest req) {

        log.info("voidTransaction() >> for order id : {} , switch chase outage flag {}", req.getOrderId(), commonService.isChaseOutageEnabled());

        if(commonService.isChaseOutageEnabled()){
            OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.VOID;
            return errorHandlingService.sendAuthFailureToAccumulator(req, ospgTransactionCategory,errorHandlingService.getDummyVoidResponse(), new Exception(CHASE_OUTAGE_MESSAGE));
        }
        log.info("voidTransaction() >> client request: {}",serviceHelper.getJsonPayload(req));

        //req.setMerchantRef(commonService.getMerchRefId(req.getStoreId()));
        req.setTransactionType(TransactionType.VOID.toString());
        req.setMethod(CREDIT_CARD);

        if (req.getTransactionId() != null
                && req.getTransactionId().equalsIgnoreCase(PO_DUMMY_TRANSACTION_ID)) {
            log.info("voidTransaction() >> calling void helper");
            return voidHelperWhenDummyTransId(req);
        } else {
            return fetchTokenID(req);
        }
    }

    private Mono<TransactionResponse> fetchTokenID(TransactionRequest request) {
        return dao.fetchTokenNumber(request)
                .doOnSuccess(str -> {
                    log.info("fetchTokenID() >> token id: {}",str);
                    if (!CollectionUtils.isEmpty(str) && StringUtils.isNotEmpty(str.get(0))) {
                        TokenData tokenData = new TokenData();
                        tokenData.setValue(str.get(0));
                        Token token = new Token();
                        token.setTokenData(tokenData);
                        request.setToken(token);
                        log.info("fetchTokenID() >> token number: {}",str.get(0));
                    }
                })
                .flatMap(str -> {
                    if (!request.getTransactionId().equals(PO_DUMMY_TRANSACTION_ID)) {
                        return callChase(request);
                    } else {
                        return  errorHandlingService.sendAuthFailureToAccumulator(request, OSPGTransactionCategory.VOID, errorHandlingService.getDummyVoidResponse(),null);
                    }
                });
    }

    private Mono<TransactionResponse> callChase(TransactionRequest request) {
        log.info("callChase() >> orderId: {}",request.getOrderId());
        return caller.callChaseService(buildReversalRequest(request), request.getStoreId(), request.getSellerId() ,voidPaymentUrl)
                .bodyToMono(ReversalResponse.class)
                .flatMap(resp -> {
                    return Mono.just(buildTransactionResponse(resp, request));
                })
                .onErrorResume(error -> {
                    return handleVoidErrors(error, request);
                }).doOnSuccess(r -> {
                    if(!Constants.DUMMY_TRANSACTION_ID.equalsIgnoreCase(r.getTransactionId())) {
                        dao.saveSuccessTransaction(request, r);
                    }
                });
    }

    private Mono<TransactionResponse> voidHelperWhenDummyTransId(TransactionRequest request) {

        return dao.fetchProviderTransactionIdForTypeCode(request)
                .filter(strings -> !CollectionUtils.isEmpty(strings))
                .doOnNext(provTranIds -> {
                    if (!CollectionUtils.isEmpty(provTranIds)) {
                        request.setTransactionId(provTranIds.get(0));
                    }
                })
                .flatMap(transIds -> {
                    log.info("fetchProviderTransactionIdForTypeCode() >> calling chase with request: {}",serviceHelper.getJsonPayload(request));
                    if (!request.getTransactionId().equals(PO_DUMMY_TRANSACTION_ID)) {
                        return fetchTokenID(request);
                    } else {
                        return Mono.empty();
                    }
                })
                .switchIfEmpty(Mono.defer(() -> {
                    return errorHandlingService.sendAuthFailureToAccumulator(request, OSPGTransactionCategory.VOID,errorHandlingService.getDummyVoidResponse(), null);
                }));
    }

    private Mono<TransactionResponse> handleVoidErrors(Throwable ex, TransactionRequest req) {
        log.error("handleVoidErrors() >> Void failed with error response from Chase: {} for store id: {} , order id: {}", ex.getMessage(), req.getStoreId(), req.getOrderId());
        OSPGTransactionCategory ospgTransactionCategory = OSPGTransactionCategory.VOID;
        List<String> procStatusList= cacheUtils.getProcStatusCode(GatewayConstants.PROC_STATUS_CODE);
        if (ex instanceof ResponseStatusException) {
            ResponseStatusException e = (ResponseStatusException) ex;
            if (PaymentUtil.isChaseDownProcStatuses(procStatusList, e, req) || e.getStatus() != HttpStatus.BAD_REQUEST) {
                log.info("handleVoidErrors() >> Error Code : {}", e.getStatus());
                return errorHandlingService.sendAuthFailureToAccumulator(req,ospgTransactionCategory,errorHandlingService.getDummyVoidResponse(),ex);
            }
            throw new ChaseServerException("Void Transaction failed with reason - " + ex.getMessage());
        }
        if (ex instanceof PrematureCloseException) {
            PrematureCloseException prematureCloseException = (PrematureCloseException) ex;
            log.error("handleVoidErrors() >> error for order id: "+req.getOrderId()+" , error status message: "+prematureCloseException.getMessage()+" , error: ", ex);
            return errorHandlingService.sendAuthFailureToAccumulator(req,ospgTransactionCategory,errorHandlingService.getDummyVoidResponse(),ex);
        }
        if (ex instanceof SslHandshakeTimeoutException) {
            SslHandshakeTimeoutException sslException = (SslHandshakeTimeoutException) ex;
            log.error("handleVoidErrors() >> error for order id: "+req.getOrderId()+" , error status message: "+sslException.getMessage()+" , error: ", ex);
            return errorHandlingService.sendAuthFailureToAccumulator(req,ospgTransactionCategory,errorHandlingService.getDummyVoidResponse(),ex);
        }
        if (ex instanceof VoidFailureExceptions) {
            throw new VoidFailureExceptions(((VoidFailureExceptions) ex).getErrorResponse());
        }
        if (ex instanceof WebClientResponseException) {
            try {
                WebClientResponseException webClientResponseException = (WebClientResponseException) ex;
                log.error("handleVoidErrors() >> Resp Status : {}, Resp Status Mssg : {}", webClientResponseException.getStatusCode(), ex.getMessage());

                if (webClientResponseException.getStatusCode() != HttpStatus.BAD_REQUEST) {
                    log.info("handleVoidErrors() >> Error Code : {}", webClientResponseException.getStatusCode());
                    return errorHandlingService.sendAuthFailureToAccumulator(req,ospgTransactionCategory,errorHandlingService.getDummyVoidResponse(),ex);
                }
                ObjectMapper mapper = new ObjectMapper();
                ErrorResponse errorResponse = mapper.readValue(webClientResponseException.getResponseBodyAsString(),
                        ErrorResponse.class);
                throw new DataValidationException(errorResponse.getProcStatus(), errorResponse.getProcStatusMessage());
            } catch (JsonProcessingException jsonProcessingException) {
                return Mono.error(ex);
            }
        }
        return Mono.error(ex);
    }

    private TransactionResponse buildTransactionResponse(ReversalResponse reversalResponse, TransactionRequest transactionRequest) {
        log.info("buildTransactionResponse() >> chase response for void transaction: {} ", serviceHelper.getJsonPayload(reversalResponse));
        String transactionStatus = Constants.NOT_PROCESSED;
        if (reversalResponse.getOrder() != null) {
            transactionStatus = ResponseCodeUtil.getTransactionStatus(reversalResponse.getOrder().getStatus());
        }

        TransactionResponse transactionResponse = TransactionResponse.builder()
                .amount(transactionRequest.getAmount())
                .transactionId(reversalResponse.getOrder().getTxRefNum())
                .transactionTag(reversalResponse.getOrder().getStatus().getAuthorizationCode())
                .transactionStatus(transactionStatus)
                .currency(transactionRequest.getCurrencyCode())
                .method(transactionRequest.getMethod())
                .token(transactionRequest.getToken())
                .transactionType(transactionRequest.getTransactionType())
                .bankRespCode(reversalResponse.getOrder().getStatus().getHostRespCode())
                .bankMessage(reversalResponse.getOrder().getStatus().getProcStatusMessage())
                .gatewayRespCode(reversalResponse.getOrder().getStatus().getRespCode())
                .validationStatus(reversalResponse.getOrder().getStatus().getProcStatus()
                        .equalsIgnoreCase(Constants.PROC_STATUS_CODE)
                        ? Constants.SUCCESS : Constants.FAILED)
                .build();

        if (!checkResponseHasErrorCode(reversalResponse)) {
            throw new VoidFailureExceptions(HttpStatus.PRECONDITION_FAILED, transactionResponse);
        }
        log.info("buildTransactionResponse() >> client response for void: {}", serviceHelper.getJsonPayload(transactionResponse));
        return transactionResponse;
    }

    private boolean checkResponseHasErrorCode(ReversalResponse reversalResponse) {
        return reversalResponse != null &&
                reversalResponse.getOrder() != null &&
                reversalResponse.getOrder().getStatus() != null &&
                reversalResponse.getOrder().getStatus().getApprovalStatus() != null;
    }

    private ReversalRequest buildReversalRequest(TransactionRequest transactionRequest) {
        ReversalRequest reversalRequest = ReversalRequest.builder()
                .merchant(PaymentUtil.buildMerchant())
                .order(getBuildOrder(transactionRequest))
                .version(Constants.VERSION)
                .build();
        log.info("buildReversalRequest() >> chase request for void: {}",serviceHelper.getJsonPayload(reversalRequest));
        return reversalRequest;
    }

    private Order getBuildOrder(TransactionRequest transactionRequest) {
        return Order.builder()
                .orderID(transactionRequest.getOrderId())
                .txRefNum(transactionRequest.getTransactionId())
                .industryType(Constants.INDUSTRY_TYPE)
                .retryTrace(PaymentUtil.buildRetryTrace(transactionRequest.getOrderId(),VOID_RETRY_TRACE_CONSTANT))
                .build();
    }
}
