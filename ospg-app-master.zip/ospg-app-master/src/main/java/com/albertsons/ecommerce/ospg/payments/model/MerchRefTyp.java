package com.albertsons.ecommerce.ospg.payments.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class MerchRefTyp {
    private Long merchRefTypCd;
    private String merchRefNm;
    private Long storeId;
    private String marketPlaceMid;
    private String merchRefDsc;
}
