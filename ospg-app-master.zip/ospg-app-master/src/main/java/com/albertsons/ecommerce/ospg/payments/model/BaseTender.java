package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.Optional;
import java.util.UUID;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseTender {

    @ApiModelProperty(value = "tender id. Unique for each tender", required = false)
    UUID id;

    @ApiModelProperty(value = "tender type. Eg: CREDIT_CARD", required = true)
    @NotNull
    Optional<String> type;

    @ApiModelProperty(value = "sub card type., placedholder for future ", required = false)
    String subType;

    @ApiModelProperty(value = "card holder name", required = false)
    String holderName;

    @ApiModelProperty(value = "card expiry date eg: 12/20", required = false)
    String expiryDate;

}
