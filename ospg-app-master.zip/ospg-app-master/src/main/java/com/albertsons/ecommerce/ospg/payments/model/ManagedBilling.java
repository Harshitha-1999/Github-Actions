package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ManagedBilling implements Serializable {
    private String mbType;
    private String mbOrderIdGenerationMethod;
    private String mbRecurringStartDate;
    private String mbRecurringEndDate;
    private String mbRecurringNoEndDateFlag;
    private String mbRecurringMaxBillings;
    private String mbRecurringFrequency;
    private String mbMicroPaymentMaxDollarValue;
    private String mbMicroPaymentMaxBillingDays;
    private String mbMicroPaymentMaxTransactions;
    private String mbDeferredBillDate;
    private String mbMicroPaymentDaysLeft;
    private String mbMicroPaymentDollarsLeft;
    private String mbStatus;
    private String mbCancelDate;
    private String mbRestoreDate;
    private String mbRemoveFlag;
}
