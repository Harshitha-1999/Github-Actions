package com.albertsons.ecommerce.ospg.payments.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@ConfigurationProperties("proxy")
@Getter
@Setter
public class ProxyProperties {
	
	private String user;
	private String password;
	private String host;
	private Integer port;
}

