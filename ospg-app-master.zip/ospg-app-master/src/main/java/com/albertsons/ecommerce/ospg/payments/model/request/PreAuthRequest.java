package com.albertsons.ecommerce.ospg.payments.model.request;

import com.albertsons.ecommerce.ospg.payments.model.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PreAuthRequest extends ChaseRequest {

    private String version;

    private String transType;

    private Merchant merchant;

    private Order order;

    private PaymentInstrument paymentInstrument;

    private CardholderVerification cardholderVerification;

    private AvsBilling avsBilling;

    private SoftDesc softDesc;

    private MerchantInitiatedTransaction merchantInitiatedTransaction;

}