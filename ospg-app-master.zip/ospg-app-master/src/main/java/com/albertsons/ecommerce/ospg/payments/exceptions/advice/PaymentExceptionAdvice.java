package com.albertsons.ecommerce.ospg.payments.exceptions.advice;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.exceptions.*;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@ControllerAdvice
public class PaymentExceptionAdvice {

    @Loggable
    private SecurityLogger log;

    @ExceptionHandler(ResponseStatusException.class)
    public Mono<ResponseEntity<TransactionResponse>> handleResponseStatusError(ResponseStatusException e)
            throws Exception {

        TransactionResponse tr = new TransactionResponse();
        tr.setErrorMessage(e.getMessage());
        tr.setTransactionStatus("Not Processed");
        return Mono.just(ResponseEntity.status(e.getStatus()).body(tr));

    }

    @ExceptionHandler(DataValidationException.class)
    public Mono<ResponseEntity<TransactionResponse>> handleDataValidationError(
            DataValidationException e) throws Exception {

        TransactionResponse response = TransactionResponse.builder()
                .errorMessage(e.getMessage())
                .errorCode(e.getErrorCode())
                .transactionStatus(Constants.NOT_PROCESSED)
                .build();

        log.info("handleDataValidationError() >> Response:  {}", response.toString(response));

        return Mono.just(ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(response));
    }

    @ExceptionHandler(VoidFailureExceptions.class)
    public Mono<ResponseEntity<TransactionResponse>> handleVoidFailureException(
            VoidFailureExceptions e) throws Exception {
        TransactionResponse response = e.getErrorResponse();
        return Mono.just(ResponseEntity
                .status(e.getStatus())
                .header("isSuccess", "false")
                .body(response));
    }

    @ExceptionHandler(ChaseServerException.class)
    public Mono<ResponseEntity<TransactionResponse>> handleChaseServerException(
            ChaseServerException e) throws Exception {
        TransactionResponse response = TransactionResponse.builder()
                .errorMessage(e.getMessage())
                .errorCode(e.getErrorCode())
                .transactionStatus(Constants.NOT_PROCESSED)
                .build();
        return Mono.just(ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(response));

    }

    @ExceptionHandler(RefundFailureExceptions.class)
    public Mono<ResponseEntity<TransactionResponse>> handleRefundFailureException(
            RefundFailureExceptions e) throws Exception {
        TransactionResponse response = TransactionResponse.builder()
                .errorMessage(e.getErrorResponse().getOrder().getStatus().getProcStatusMessage())
                .errorCode(e.getErrorResponse().getOrder().getStatus().getProcStatus())
                .code(e.getErrorResponse().getOrder().getStatus().getHostRespCode())
                .transactionStatus(Constants.NOT_PROCESSED)
                .build();
        return Mono.just(ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(response));
    }

    @ExceptionHandler(WebClientResponseException.class)
    public Mono<ResponseEntity<String>> handleWebClientResponseException(WebClientResponseException ex) {
        log.error("handleWebClientResponseException() >> error status code: "+ex.getRawStatusCode()+", error response: "+ex.getResponseBodyAsString()+" , exception: ", ex);
        return Mono.just(ResponseEntity.status(ex.getRawStatusCode()).body(ex.getResponseBodyAsString()));
    }

    @ExceptionHandler(MerchantLookupException.class)
    public Mono<ResponseEntity<TransactionResponse>> handleMerchantLookupException(
            MerchantLookupException e) throws Exception {
        TransactionResponse response = TransactionResponse.builder()
                .errorMessage(e.getMessage())
                .transactionStatus(Constants.NOT_PROCESSED)
                .build();
        return Mono.just(ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(response));
    }

    @ExceptionHandler(PaymentProviderDownException.class)
    public Mono<ResponseEntity<TransactionResponse>> handleUserPaymentProviderUnReachableException(
            PaymentProviderDownException e) throws Exception {

        TransactionResponse error = new TransactionResponse();
        error.setErrorMessage(e.getLocalizedMessage());
        error.setTransactionStatus(GatewayConstants.TRANSACTION_STATUS_NOT_PROCESSED);
        return Mono.just(ResponseEntity.status(HttpStatus.NOT_EXTENDED).body(error));
    }

    @ExceptionHandler(DuplicateContentResponseException.class)
    public Mono<ResponseEntity<TransactionResponse>> handleDuplicateContentResponseError(
            DuplicateContentResponseException e) throws Exception {
        log.error("handleWebClientResponseException() >> error status code: "+e.getStatus()+", error response: "+new ObjectMapper().writeValueAsString(e.getErrorResponse())+" , orderId: "+e.getOrderId()+" , exception: ", e);
        return Mono.just(new ResponseEntity<TransactionResponse>(e.getErrorResponse(), HttpStatus.CONFLICT));
    }

}
