package com.albertsons.ecommerce.ospg.payments.enumerations;

public enum ValidationErrorCode implements IErrorCode{
	
	CARD_EXPIRED("OSPG_ERR_001_CARD_EXPIRED", "The card has expired"),
	CARD_EXPIRY_DATE_FORMAT("OSPG_ERR_002_INVALID_EXP_DATE_FMT", "Invalid card expiry date format. Expected format : MMyy"),
	STORE_ID("OSPG_ERR_003_INVALID_STORE_ID", "Invalid input data sent in request : storeId"),
	ORDER_ID("OSPG_ERR_004_INVALID_ORDER_ID", "Invalid input data sent in request : orderId"),
	TOKEN_DATA_VALUE("OSPG_ERR_005_INVALID_TKN", "Invalid input data sent in request : token_data.value"),
	TOKEN_NUMBER("OSPG_ERR_006_INVALID_TKN_NBR", "The token number must be numeric"),
	TOKEN_DATA_EXPIRY_DATE("OSPG_ERR_007_INVALID_TKN_EXP_DATE", "Invalid input data sent in request : token_data.exp_date"),
	CVV("OSPG_ERR_008_INVALID_CVV", "Invalid input data sent in request : cvv"),
	CVV_NUMBER("OSPG_ERR_009_INVALID_CVV_NBR", "The cvv provided must be numeric"),
	AMOUNT("OSPG_ERR_010_INVALID_AMT", "Invalid input data sent in request : amount"),
	CARDHOLDER_NAME("OSPG_ERR_011_INVALID_CNAME", "Invalid input data sent in request : cardholder_name"),
	SOURCE("OSPG_ERR_012_INVALID_SRC", "Invalid input data sent in request : source"),
	CLIENT_IP("OSPG_ERR_013_INVALID_REQ_IP", "Invalid input data sent in request : clientIP"),
	TRANSACTION_ID("OSPG_ERR_014_INVALID_TXN_ID", "Invalid input data sent in request : transaction_id"),
	TRANSACTION_TAG("OSPG_ERR_015_INVALID_TXN_TAG", "Invalid input data sent in request : transaction_tag"),
	CARDBRAND_ORIGINAL_AMOUNT("OSPG_ERR_016_INVALID_ORIG_AMT", "Invalid input data sent in request : cardbrand_original_amount"),
	BILLING_ADDRESS("OSPG_ERR_017_INVALID_ADDR", "Invalid input data sent in request : billing_address"),
	ZIP_POSTAL_CODE("OSPG_ERR_018_INVALID_ZIPCODE", "Invalid input data sent in request : zip_postal_code"),
	TRANSACTION_TYPE("OSPG_ERR_019_INVALID_TXN_TYPE", "Invalid input data sent in request : transaction_type"),
	CARD_TYPE("OSPG_ERR_020_INVALID_CARD_TYPE", "Invalid input data sent in request : token_data.type"),
	CARD_TYPE_INVALID_VALUE("OSPG_ERR_021_INVALID_CARD_TYPE_VAL", "Invalid card type value. Valid values of token_data.type: [VI, MC, AM, DI]"),
	SOFT_DESCRIPTORS("OSPG_ERR_020_INVALID_SOFT_DESC", "Invalid input data sent in request : soft_descriptors"),
	TOKEN_DATA("OSPG_ERR_022_MISSING_TOKEN_DATA", "Invalid input data sent in request : token_data is null"),
	TOKEN_DATA_TRX_REF_NUM("OSPG_ERR_023_TOKEN_DATA_TRX_REF_NUM_MISSING", "Token Data and Transaction Ref Num : missing");

	private final String code;
	private final String message;
	
	private ValidationErrorCode(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

}
