package com.albertsons.ecommerce.ospg.payments.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serializable;
import java.math.BigDecimal;


@Table("[OSPGPAYTX].[TRANSACTION_TOKEN]")
//@Table("TRANSACTION_TOKEN")
@Builder
@Getter
@Setter
@ToString
public class TransactionToken implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id()
	@Column("TRANSACTION_TOKEN_ID")
	private BigDecimal transactionTokenId;

	@Column("CARD_EXPIRY_DT")
	private String cardExpiryDt;

	@Column("CARD_HOLDER_NM")
	private String cardHolderNm;

	/*@Column("EXPIRY_TS")
	private Timestamp expiryTs;*/

	@Column("LAST_UPDATE_TS")
	@LastModifiedDate
	private String lastUpdateTs;

	@Column("LAST_UPDATE_USER_ID")
	private String lastUpdateUserId;

	@Column("ORDER_ID")
	private BigDecimal orderId;

	@Column("TOKEN_NBR")
	private String tokenNbr;

	@Column("STORE_ID")
	private BigDecimal storeId;

	/*@Column("CARD_TYP_CD" )
	private CardTyp cardTyp;*/

	@Column("CARD_TYP_CD" )
	private Long cardTyp;

	/*//bi-directional many-to-one association to TokenTyp
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn("TOKEN_TYP_CD")
	private TokenTyp tokenTyp;*/

	@Column("TOKEN_TYP_CD" )
	private long tokenTypCd;

	@Column("MIT_RECEIVED_TRANSACTION_ID")
	private String mitReceivedTranId;
}