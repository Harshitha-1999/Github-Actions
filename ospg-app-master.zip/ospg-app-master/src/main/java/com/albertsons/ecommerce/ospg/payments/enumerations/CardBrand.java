package com.albertsons.ecommerce.ospg.payments.enumerations;

public enum CardBrand {

	VI("VI", "VI"), DI("DI", "DI"), AM("AM", "AX"),
	MC("MC", "MC"), JC("JC", "JC"), DC("DC", "DC");

	private String cardBrand;
	private String key;

	private CardBrand(String key, String cardBrand) {
		this.key = key;
		this.cardBrand = cardBrand;
	}

	public static String getValueByKey(String key) {
		CardBrand[] values = values();
		for(CardBrand cardBrand: values) {
			if(cardBrand.getKey().equalsIgnoreCase(key)) {
				return cardBrand.cardBrand;
			}
		}
		return null;
	}

	public String getKey() {
		return key;
	}

	@Override
	public String toString() {
		return this.cardBrand;
	}

}
