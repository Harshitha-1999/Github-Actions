package com.albertsons.ecommerce.ospg.payments.model.response;

import com.albertsons.ecommerce.ospg.payments.model.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundResp {
    private String version;
    private String transType;
    private Merchant merchant;
    private PaymentInstrument paymentInstrument;
    private Order order;
    private EmvInfo emvInfo;
    private AvsBilling avsBilling;
    private CardholderVerification cardholderVerification;
    private Debit debit;
    private FraudAnalysis fraudAnalysis;
    private CardTypeIndicator cardTypeIndicator;
    private EUDD eudd;
    private EarlyWarningSystem earlyWarningSystem;
    private ForeignExchange foreignExchange;
    private RealTimeAccountUpdater realTimeAccountUpdater;
    private GiftCard giftCard;
    private Profile profile;
    private ManagedBilling ManagedBillingObject;
}
