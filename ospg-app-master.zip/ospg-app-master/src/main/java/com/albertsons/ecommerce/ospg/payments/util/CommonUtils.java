package com.albertsons.ecommerce.ospg.payments.util;

import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Pattern;

public final class CommonUtils {

	private static final String STRING_UNDER_SCORE = "-";
	private static final Pattern CRLF_PATTERN = Pattern.compile("(\r|\n)");
	
	
	public static String replaceCRLF(String message) {
		try {
			if (StringUtils.isNotBlank(message))
				return CRLF_PATTERN.matcher(message).replaceAll(STRING_UNDER_SCORE);
		}catch(Exception exception) {}
		return message;
	}
	public static String replaceCRLF(String message, String replaceWith) {
		try {
			if (StringUtils.isNotBlank(message))
				return CRLF_PATTERN.matcher(message).replaceAll(replaceWith);
		}catch(Exception exception) {}
		return message;
	}
    /**
     * Removes newline characters from the provided String then encodes it for HTML before returning the 'clean' version
     * to the caller.
     * 
     * @param message
     *            Original message to clean.
     * @return Cleaned message.
     */
    public static String cleanMessage(String message) {
        // ensure no CRLF injection into logs for forging records
        String clean = replaceCRLF(message);
       /* if (ESAPI.securityConfiguration().getLogEncodingRequired()) {
            clean = ESAPI.encoder().encodeForHTML(message);
            if (!message.equals(clean)) {
                clean += " (Encoded)";
            }
        }*/
        return clean;
    }
    
    public static Integer multiply(BigDecimal bigDecimal, int value ) {
    	Integer integer=null;
    	try {
    		integer = Integer.valueOf(bigDecimal.multiply(new BigDecimal(value)).intValue());
    	}catch (Exception exception){
    	}
    	return integer;
    }
    
    public static double roundDouble(double d, int places) {
	    BigDecimal bigDecimal = new BigDecimal(Double.toString(d));
	    bigDecimal = bigDecimal.setScale(places, RoundingMode.HALF_UP);
	    return bigDecimal.doubleValue();
	}
}
