package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.config.SchedulerConfig;
import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.logging.Loggable;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.service.CommonService;
import com.albertsons.ecommerce.ospg.payments.service.PaymentGatewayServiceHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CacheRefreshController {

    @Autowired
    SchedulerConfig schedulerConfig;

    @Autowired
    CommonService commonService;

    @Autowired
    CacheManager cacheManager;

    @Loggable
    private SecurityLogger log;

    @Autowired
    private PaymentGatewayServiceHelper serviceHelper;

    @GetMapping(value = "/refreshFeatureFlagsCache")
    public @ResponseBody String refreshFeatureFlagsCache(){
        try {
            log.info("Start: refreshFeatureFlagsCache()");
            schedulerConfig.loadFeatureFlags();
            log.info("End: refreshFeatureFlagsCache()");
        }catch (Exception ex){
            log.error("refreshFeatureFlagsCache() Error: ", ex);
            return Constants.FAILED;
        }
        return Constants.SUCCESS;
    }

    @GetMapping(value = "getEntriesForCache/{cacheName}/{flagName}")
    public @ResponseBody String getEntriesForCache(@PathVariable(name = "cacheName") final String cacheName,
                                     @PathVariable(name = "flagName") final String flagName){
        Cache.ValueWrapper valueWrapper = cacheManager.getCache(cacheName).get(flagName);
        if (valueWrapper == null)
            return "Invalid Input";
        return String.valueOf(valueWrapper.get());
    }

    @GetMapping(value = "/switchchaseurl/{enableUrl}", produces = "application/json", consumes = "application/json")
    public @ResponseBody String switchChaseUrl(@PathVariable(name = "enableUrl") final String enableUrl){
        log.info("switchChaseUrl() >> enableUrl: {}", enableUrl);
        return loadChaseUrls(cacheManager.getCache(GatewayConstants.CHASE_ORBITAL_URL), enableUrl);
    }

    @GetMapping(value = "/switchchaseoutage/{enable}", produces = "application/json", consumes = "application/json")
    public @ResponseBody String switchChaseOutage(@PathVariable(name = "enable") final String enable){
        log.info("switchChaseOutage() >> enable: {}", enable);
        return loadChaseOutage(cacheManager.getCache(GatewayConstants.SWITCH_CHASE_OUTAGE), enable);
    }

    private String loadChaseUrls(Cache cache, String enableUrl) {
        if(GatewayConstants.PRIMARY_CHASE_ORBITAL_URL.equalsIgnoreCase(enableUrl)) {
            cache.put(GatewayConstants.PRIMARY_CHASE_ORBITAL_URL, true);
            cache.put(GatewayConstants.SECONDARY_CHASE_ORBITAL_URL, false);
        }else {
            if(GatewayConstants.SECONDARY_CHASE_ORBITAL_URL.equalsIgnoreCase(enableUrl)) {
                cache.put(GatewayConstants.PRIMARY_CHASE_ORBITAL_URL, false);
                cache.put(GatewayConstants.SECONDARY_CHASE_ORBITAL_URL, true);
            }else{
                return "Invalid Input " + enableUrl;
            }
        }
        return "Chase orbital url switched to " + enableUrl;
    }

    @GetMapping(value = "/refreshProcStatusCodeCache")
    public String refreshProcStatusCodeCache(){
        try {
            log.info("Start: refreshProcStatusCodeCache()");
            schedulerConfig.loadProcStatusCodes();
        }catch (Exception ex){
            log.error("refreshProcStatusCodeCache() Error: ", ex);
            return Constants.FAILED;
        }
        return Constants.SUCCESS;
    }

    private String loadChaseOutage(Cache cache, String enable) {
        if (GatewayConstants.ENABLE.equalsIgnoreCase(enable)) {
            cache.put(GatewayConstants.ENABLE, true);
        } else if (GatewayConstants.DISABLE.equalsIgnoreCase(enable)) {
            cache.put(GatewayConstants.ENABLE, false);
        } else {
            return "Invalid Input " + enable;
        }
        log.info("loadChaseOutage() >> chase outage flag: {}",enable);
        return "Chase outage switched " + enable;
    }

}
