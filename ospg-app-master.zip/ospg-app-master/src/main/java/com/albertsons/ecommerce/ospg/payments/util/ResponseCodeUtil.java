package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.enumerations.ApprovalStatus;
import com.albertsons.ecommerce.ospg.payments.model.Status;

public class ResponseCodeUtil {

    public static String getTransactionStatus(Status status) {
        if(status != null) {
            if (status.getApprovalStatus().equals(ApprovalStatus.DECLINE.toString())) {
                return Constants.DECLINED;
            } else if (status.getApprovalStatus().equals(ApprovalStatus.APPROVED.toString())) {
                return Constants.APPROVED;
            } else {
                return Constants.NOT_PROCESSED;
            }
        }
        return Constants.NOT_PROCESSED;
    }
    
    public static String getTxnStatusPurchase(Status status) {
    	
    	if(status != null) {
    		return status.getProcStatus()
    		        .equalsIgnoreCase(Constants.PROC_STATUS_CODE)
    		        ? Constants.APPROVED : Constants.NOT_PROCESSED;
    	}
    	
        return Constants.NOT_PROCESSED;
    }

}
