package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import static com.albertsons.ecommerce.ospg.payments.constants.Constants.STORE_ID;

@RequestMapping(value = "/facade")
public interface IFacadeController {

    @ApiOperation(value = "Request to get payment token.")
    @PostMapping(value = "/get-payment-token", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    Mono<String> getPaymentToken(@RequestBody(required = true) TenderDeclineRequest body,
                                 @RequestHeader(value = STORE_ID, required = false) String headerStoreId,
                                 @RequestParam(value = STORE_ID, required = false) String reqStoreId) throws Exception;

}
