package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString(includeFieldNames=true)
public class Order {
    private String orderID;
    private String comments;
    private String shippingRef;
    private String shippingMethod;
    private String industryType;
    private String amount;
    private String adjustedAmount;
    private String outstandingAmt;
    private String reversalRetryNumber;
    private String tipAmt;
    private String discountAmt;
    private String txnSurchargeAmt;
    private String retryTrace;
    private String txRefNum;
    private String priorAuthCd;
    private String retryAttempCount;
    private String lastRetryDate;
    private String txRefIdx;
    private String respDateTime;
    private String authNetwkID;
    private String isoCountryCode;
    private String mitReceivedTransactionID;
    private String splitTxRefIdx;
    private Status status;
    private String orderDefaultDescription;
    private String orderDefaultAmount;
    private String customerProfileFromOrderInd;
    private String customerProfileOrderOverideInd;
    private String inquiryRetryNumber;
    private String sequenceNumber;
    private String flexAcctBalance;
    private String flexAcctPriorBalance;
    private String flexRequestedAmount;
    private String flexRedeemedAmt;
    private String flexHostTrace;
    private String batchFailedAcctNum;
    private String flexAcctExpireDate;
    private String autoAuthTxRefIdx;
    private String autoAuthTxRefNum;
    private String autoAuthFlexRedeemedAmt;
    private String autoAuthFlexHostTrace;
    private String autoAuthRespTime;
    private String superBlockID;
    private String currencyCode;
    private String onlineReversalInd;
    private String remainingBalance;
    private String requestAmount;
    private String redeemedAmount;
}
