package com.albertsons.ecommerce.ospg.payments.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * This is a utility class which formats the date and returns current timestamp
 * 
 * @author APARV03
 *
 */
public class DateUtil {
	
	private static final String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	private static final String TIME_ZONE = "GMT";

	public static String getCurrentTimeStamp() {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(TIME_FORMAT);
		dateFormat.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
		//return Timestamp.valueOf(dateFormat.format(cal.getTime()));
	}

	public static Timestamp getFormattedTimeStamp(String time) {
		return Timestamp.valueOf(time);
	}
	
	public static Timestamp addSubtractMinutesFromTimeStamp	(int minutes){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(TIME_FORMAT);
		//dateFormat.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, minutes);
		//return Timestamp.valueOf(dateFormat.format(cal.getTime())).toString();
		return Timestamp.valueOf(dateFormat.format(cal.getTime()));
	}
	
	private Date getDate(int duration){
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MINUTE, duration);
		return cal.getTime();
	}
	
	public static String convertInstantToSqlDate(Instant input) {
		String sqlDate = null;
		
		if(null != input) {
			sqlDate = Instant.parse(input.toString()).atOffset( ZoneOffset.UTC )
						.format(DateTimeFormatter.ofPattern( "uuuu-MM-dd HH:mm:ss" ));
		}
	    return sqlDate;	
	}
	
}
