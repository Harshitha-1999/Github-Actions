package com.albertsons.ecommerce.ospg.payments.model.request;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.PUBLIC_ONLY, setterVisibility = JsonAutoDetect.Visibility.PUBLIC_ONLY)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
public class StoredCredentialRequest {

	@JsonProperty("sequence")
	private String sequence;

	@JsonProperty("initiator")
	private String initiator;

	@JsonProperty("is_scheduled")
	private String isScheduled;

	@JsonProperty("cardbrand_original_transaction_id")
	private String cardBrandOriginalTransactionId;

	@JsonProperty("cardbrand_original_amount")
	private String cardBrandOriginalAmount;

}
