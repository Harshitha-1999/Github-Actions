package com.albertsons.ecommerce.ospg.payments.model;

import com.albertsons.ecommerce.ospg.payments.dao.BaseHeaderDto;
import com.albertsons.ecommerce.ospg.payments.exceptions.ErrorDto;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.validation.Valid;
import java.util.Collection;
import java.util.Optional;

@Data
@NoArgsConstructor
@FieldDefaults(makeFinal = false,level = AccessLevel.PRIVATE)
public class GetTenderResponse {

    @Valid
    GetTendersResponseHeader header;
    @Valid
    Collection<Tender> tenders;

    Collection<ErrorDto> errors;


    public Optional<Collection<Tender>> getTenders() {
        return Optional.ofNullable(tenders);
    }

    public Optional<BaseHeaderDto> getHeader() {
        return Optional.ofNullable(header);
    }

    public Optional<Collection<ErrorDto>> getErrors() {
        return Optional.ofNullable(errors);
    }
}
