package com.albertsons.ecommerce.ospg.payments.validation;

public interface OnVoid {
}
