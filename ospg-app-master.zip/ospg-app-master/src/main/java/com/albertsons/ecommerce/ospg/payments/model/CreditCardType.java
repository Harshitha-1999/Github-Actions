package com.albertsons.ecommerce.ospg.payments.model;

/**
 * @author MSUND21
 */
public enum CreditCardType {

	VISA("VI", "Visa"), DISCOVER("DI", "Discover"), AMEX("AM", "American Express"),
	MASTERCARD("MC", "MasterCard"),  JCB ("JC", "Japan Credit Bureau"), DC ("DC", "Diners Club");

	private String creditCardType;
	private String key;

	private CreditCardType(String key, String creditCardType) {
		this.key = key;
		this.creditCardType = creditCardType;
	}
	
	public static String getValueByKey(String key) {
		CreditCardType[] values = values();
		for(CreditCardType creditCardType: values) {
			if(creditCardType.getKey().equalsIgnoreCase(key)) {
				return creditCardType.creditCardType;
			}
		}
		return null;
	}

	public String getKey() {
		return key;
	}
	
	@Override
	public String toString() {
		return this.creditCardType;
	}

}