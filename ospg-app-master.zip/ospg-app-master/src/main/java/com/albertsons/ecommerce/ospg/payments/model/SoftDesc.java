package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SoftDesc {
    private String softDescMercName;
    private String softDescProdDesc;
    private String softDescMercCity;
    private String softDescMercPhone;
    private String softDescMercURL;
    private String softDescMercEmail;
}
