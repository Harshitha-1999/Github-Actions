package com.albertsons.ecommerce.ospg.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Level3 {
	private String taxInd;
	private String taxAmount;
	private String pCardOrderID;
	private String pCardDestZip;
	private String pCardRequestorName;
	private String pCardLocalTaxRate;
	private String pCardNationalTax;
	private String pCardPstTaxRegNumber;
	private String pCardCustomerVatRegNumber;
	private String pCardMerchantVatRegNumber;
	private String pCardTotalTaxAmount;
	private String pCardDtlTaxAmount1Ind;
	private String pCardDtlTaxAmount1;
	private String pCardDtlTaxAmount2Ind;
	private String pCardDtlTaxAmount2;
	private String pCardNationalTaxRate;
	private String pCardLocalTaxAmount;
	private String amexTranAdvAddn1;
	private String amexTranAdvAddn2;
	private String amexTranAdvAddn3;
	private String amexTranAdvAddn4;
	private String pCardDestName;
	private String pCardDestAddress;
	private String pCardDestAddress2;
	private String pCardDestCity;
	private String pCardDestStateCd;
}
