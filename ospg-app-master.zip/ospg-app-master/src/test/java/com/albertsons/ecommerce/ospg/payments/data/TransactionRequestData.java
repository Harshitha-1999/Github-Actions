package com.albertsons.ecommerce.ospg.payments.data;

import com.albertsons.ecommerce.ospg.payments.model.request.BillingAddress;
import com.albertsons.ecommerce.ospg.payments.model.request.Token;
import com.albertsons.ecommerce.ospg.payments.model.request.TokenData;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import org.springframework.stereotype.Component;

@Component
public class TransactionRequestData {

    public TransactionRequest buildValidRequest(String transactionType) {
        TransactionRequest req = new TransactionRequest();
        req.setMethod("token");
        req.setAmount("300");
        req.setStoreId("3116");
        req.setOrderId("211178");
        req.setSource("ERUMS");
        req.setToken(buildValidToken());
        req.setClientIP("127.0.0.1");
        req.setTransactionType(transactionType);
        req.setTransactionId("123123123");
        req.setTransactionTag("TransactionTag");

        BillingAddress billingAddress = new BillingAddress();
        billingAddress.setZipPostalCode("11111");
        req.setBillingAddress(billingAddress);
        return req;
    }

    private Token buildValidToken() {
        return Token.builder().tokenType("FDToken")
                .tokenData(buildValidTokenData()).build();
    }

    private TokenData buildValidTokenData() {
        return TokenData.builder()
                .type("VI")
                .cardholderName("TEST name")
                .cvv("189")
                .expiryDate("1225")
                .value("4112344112344113")
                .build();
    }
}
