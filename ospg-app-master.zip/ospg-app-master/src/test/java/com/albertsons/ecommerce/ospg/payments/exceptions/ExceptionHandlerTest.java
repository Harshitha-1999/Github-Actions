package com.albertsons.ecommerce.ospg.payments.exceptions;

import com.albertsons.ecommerce.ospg.payments.model.response.PreauthResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.RefundResp;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.util.Optional;

import static org.junit.Assert.*;
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class ExceptionHandlerTest {

    ChaseServerException chaseServerException;
    DuplicateContentResponseException duplicateContentResponseException;
    ErrorDto errorDto ;
    PaymentDataAccessException paymentDataAccessException;
    PaymentProviderDownException paymentProviderDownException;
    PreAuthFailureException preAuthFailureException;
    RefundFailureExceptions refundFailureExceptions;
    SubErrorDto subErrorDto;
    MerchantLookupException merchantLookupException;
    UserBlockedException userBlockedException;
    VoidFailureExceptions voidFailureExceptions;
    DataValidationException dataValidationException;

    @Before
    public void init(){
        chaseServerException = new ChaseServerException("Page not Found");
        chaseServerException.setErrorCode("404");

        userBlockedException = new UserBlockedException(new TransactionResponse());
        voidFailureExceptions = new VoidFailureExceptions(HttpStatus.BAD_REQUEST,new TransactionResponse());
        refundFailureExceptions = new RefundFailureExceptions(new RefundResp());
        duplicateContentResponseException =new DuplicateContentResponseException(HttpStatus.BAD_REQUEST,null,"Bad Request","orderId");
        duplicateContentResponseException.setErrorResponse(new TransactionResponse());

        errorDto =new ErrorDto();
        errorDto.setCode("400");
        errorDto.setMessage("Bad Request");
        errorDto.setStatus(400);

        subErrorDto = new SubErrorDto();
        subErrorDto.setMessage("Message");
        subErrorDto.setField("field");
        subErrorDto.setObject("object");
        subErrorDto.setRejectedValue("rejected value");

        paymentDataAccessException = new PaymentDataAccessException("401");
        paymentProviderDownException =new PaymentProviderDownException("403");
       preAuthFailureException = new PreAuthFailureException(new PreauthResponse());
       preAuthFailureException.setErrorResponse(new PreauthResponse());
        refundFailureExceptions.setErrorResponse(new RefundResp());
        userBlockedException.setErrorResponse(new TransactionResponse());
        voidFailureExceptions.setErrorResponse(new TransactionResponse());
        merchantLookupException = new MerchantLookupException("message");

        dataValidationException = new DataValidationException(new Exception());
    }

    @Test
    public void exceptionsTest(){
        Assert.assertEquals("404",chaseServerException.getErrorCode());
        Assert.assertNotNull(refundFailureExceptions.getErrorResponse());
        Assert.assertNotNull(userBlockedException.getErrorResponse());
        Assert.assertNotNull(voidFailureExceptions.getErrorResponse());
    }

    @Test
    public void DataValidationExceptionTest() {
        dataValidationException = new DataValidationException("Error", new Exception());
        Assert.assertNotNull(dataValidationException.getMessage());
        dataValidationException = new DataValidationException("403", "Error", new Exception());
        Assert.assertNotNull(dataValidationException.getMessage());
        Assert.assertNotNull(dataValidationException.getErrorCode());
    }

    @Test
    public void ErrorDtoTest() {
        Assert.assertEquals(Optional.of("400"), errorDto.getCode());
        Assert.assertEquals(Optional.of("Bad Request"), errorDto.getMessage());
        Assert.assertEquals(Optional.empty(), errorDto.getDebugMessage());
        Assert.assertEquals(Optional.empty(),errorDto.getSubErrorsList());
        Assert.assertEquals(Optional.empty(),errorDto.getRootCause());

    }

    @Test
    public void subErrorDtoTest() {
        Assert.assertEquals(Optional.of("object"), subErrorDto.getObject());
        Assert.assertEquals(Optional.of("field"), subErrorDto.getField());
        Assert.assertEquals(Optional.of("rejected value"), subErrorDto.getRejectedValue());
        Assert.assertEquals(Optional.of("Message"), subErrorDto.getMessage());
    }

    @Test
    public void PaymentProviderDownExceptionTest() {
       paymentProviderDownException = new PaymentProviderDownException(new Exception());
       Assert.assertNotNull(paymentProviderDownException.getMessage());
       paymentProviderDownException = new PaymentProviderDownException("Error", new Exception());
        Assert.assertNotNull(paymentProviderDownException.getMessage());
    }

    @Test
    public void PaymentDataAccessExceptionTest() {
        paymentDataAccessException = new PaymentDataAccessException(new Exception());
        Assert.assertNotNull(paymentDataAccessException.getMessage());
        paymentDataAccessException = new PaymentDataAccessException("Error", new Exception());
        Assert.assertNotNull(paymentDataAccessException.getMessage());
    }

    @Test
    public void VoidFailureExceptionsTest() {
        TransactionResponse transactionResponse = new TransactionResponse();
        transactionResponse.setErrorCode("400");
        transactionResponse.setErrorMessage("Error");
        voidFailureExceptions = new VoidFailureExceptions(transactionResponse);
        Assert.assertEquals("400", transactionResponse.getErrorCode());
        Assert.assertEquals("Error", transactionResponse.getErrorMessage());
    }

}