package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.entity.AuthDetails;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.external.FiservCaller;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.Status;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.RefundResp;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

/**
 * mmohi05
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class RefundTransactionServiceTest {

    private TransactionRequestData requestData;
    @InjectMocks
    private RefundTransactionService refundMockedService;
    @Mock
    private TransactionsDAO dao;
    @Mock
    private ChaseCaller mockCaller;
    @Mock
    private ResponseSpec responseMock;
    @Mock
    private WebClient webClientMock;
    @Mock
    private RequestBodySpec requestBodyMock;
    @Mock
    private RequestBodyUriSpec requestBodyUriMock;
    @Mock
    private SecurityLogger log;
    @Mock
    private FiservCaller fiservCaller;
    @Mock
    private ResponseSpec responseSpec;

    @Mock
    private PaymentGatewayServiceHelper serviceHelper;

    @Test
    public void refundTest() {
        requestData = new TransactionRequestData();
        TransactionRequest request = requestData.buildValidRequest(TransactionType.REFUND.toString());
       when(dao.getPurchaseDetails(Mockito.any(TransactionRequest.class))).thenReturn(Mono.empty());
        responseMock.toEntity(RefundResp.class);
        ReflectionTestUtils.setField(refundMockedService,"dao",dao);
        Mono<TransactionResponse> response = refundMockedService.refund(request);
        response.subscribe(rsp -> assertEquals(rsp.getTransactionStatus(), "approved"));
    }

    @Test
    public void refundNoPurchaseTransactionFoundTest() {
        requestData = new TransactionRequestData();
        TransactionRequest request = requestData.buildValidRequest(TransactionType.REFUND.toString());
        AuthDetails authDetails = new AuthDetails();
        authDetails.setProviderTransactionId(null);
        authDetails.setAmount(new BigDecimal(100));
        Mono<AuthDetails> authDetailsMono = Mono.just(authDetails);
        when(dao.getPurchaseDetails(Mockito.any(TransactionRequest.class))).thenReturn(authDetailsMono);
        when(fiservCaller.refundCall(Mockito.any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(TransactionResponse.class)).thenReturn(Mono.just(getTransactionResponse()));
        responseMock.toEntity(RefundResp.class);
        ReflectionTestUtils.setField(refundMockedService,"dao",dao);
        Mono<TransactionResponse> response = refundMockedService.refund(request);
        response.subscribe(rsp -> assertEquals("", rsp.getTransactionId()));
    }

    @Test
    public void refundWithPurchaseTransactionFoundTest() {
        requestData = new TransactionRequestData();
        TransactionRequest request = requestData.buildValidRequest(TransactionType.REFUND.toString());
        AuthDetails authDetails = new AuthDetails();
        authDetails.setProviderTransactionId("TransactiondIDTest");
        authDetails.setAmount(new BigDecimal(100));
        Mono<AuthDetails> authDetailsMono = Mono.just(authDetails);
        when(dao.getPurchaseDetails(Mockito.any(TransactionRequest.class))).thenReturn(authDetailsMono);
        when(mockCaller.callChaseService(any(), any(), any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(RefundResp.class)).thenReturn(Mono.just(getRefundResp()));
        Mockito.doNothing().when(dao).saveSuccessTransaction(any(), any());
        responseMock.toEntity(RefundResp.class);
        ReflectionTestUtils.setField(refundMockedService,"dao",dao);
        ReflectionTestUtils.setField(refundMockedService, "refundUrl", "http://test/refund");
        Mono<TransactionResponse> response = refundMockedService.refund(request);
        response.subscribe(rsp -> assertNull(rsp.getTransactionId()));
        response.subscribe(rsp -> assertEquals("000", rsp.getTransactionTag()));
    }

    @Test
    public void refundHandleErrorTest() {
        requestData = new TransactionRequestData();
        TransactionRequest request = requestData.buildValidRequest(TransactionType.REFUND.toString());
        AuthDetails authDetails = new AuthDetails();
        authDetails.setProviderTransactionId("TransactiondIDTest");
        authDetails.setAmount(new BigDecimal(100));
        Mono<AuthDetails> authDetailsMono = Mono.just(authDetails);
        when(dao.getPurchaseDetails(Mockito.any(TransactionRequest.class))).thenReturn(authDetailsMono);
        when(mockCaller.callChaseService(any(), any(), any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(RefundResp.class)).thenReturn(Mono.just(getRefundRespWithNullStatus()));
        responseMock.toEntity(RefundResp.class);
        ReflectionTestUtils.setField(refundMockedService,"dao",dao);
        ReflectionTestUtils.setField(refundMockedService, "refundUrl", "http://test/refund");
        Mono<TransactionResponse> response = refundMockedService.refund(request);
        response.subscribe(rsp -> assertNull(rsp.getTransactionId()));
        response.subscribe(rsp -> assertEquals("000", rsp.getTransactionTag()));

    }

    private WebClientResponseException getWebClientResponseException() {
        WebClientResponseException exp = new WebClientResponseException(402, "Error", null, null, null);
        return exp;
    }

    private RefundResp getRefundResp() {
        RefundResp response = new RefundResp();
        response.setTransType("Refund");
        Order order = new Order();
        Status status = new Status();
        status.setApprovalStatus("Approved");
        status.setProcStatus("0");
        status.setAuthorizationCode("000");
        status.setHostRespCode("HostRespCode");
        status.setProcStatusMessage("ProcStatusMessage");
        status.setRespCode("respCode");
        order.setStatus(status);
        response.setOrder(order);

        return  response;
    }

    private RefundResp getRefundRespWithNullStatus() {
        RefundResp response = new RefundResp();
        response.setTransType("Refund");

        return  response;
    }

    private TransactionResponse getTransactionResponse() {
        TransactionResponse transactionResponse = new TransactionResponse();
        transactionResponse.setAmount("100");
        transactionResponse.setTransactionId("testTransactionId");
        return transactionResponse;
    }

    @Test
    public void subRefundTest() {
        requestData = new TransactionRequestData();
        TransactionRequest request = requestData.buildValidRequest(TransactionType.REFUND.toString());
        when(dao.getPurchaseDetails(Mockito.any(TransactionRequest.class))).thenReturn(Mono.empty());
        responseMock.toEntity(RefundResp.class);
        Mono<TransactionResponse> response = refundMockedService.subscriptionRefund(request);
        response.subscribe(rsp -> assertEquals(rsp.getTransactionStatus(), "approved"));
    }

    private RefundResp buildRefundResp(String preauthStatus, String respCode) {
        RefundResp response = new RefundResp();
        Order order = new Order();
        Status status = new Status();
        status.setProcStatusMessage(preauthStatus);
        status.setPymtBrandAuthResponseCode(respCode);
        order.setStatus(status);
        response.setOrder(order);
        return response;
    }
}
