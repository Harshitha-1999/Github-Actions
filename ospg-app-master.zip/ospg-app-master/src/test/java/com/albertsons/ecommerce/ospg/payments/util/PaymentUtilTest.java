package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.model.Merchant;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class PaymentUtilTest {


    @Test
    public void convertDollarsToCents() {
       String cents = PaymentUtil.convertDollarsToCents("100");
        Assert.assertEquals("10000",cents);

        String emptycents = PaymentUtil.convertDollarsToCents("");
        Assert.assertEquals("",emptycents);
        String invalid = PaymentUtil.convertDollarsToCents("sw");
        Assert.assertEquals("sw",invalid);
    }

    @Test
    public void preAuth0DollarCase() {
        String preAuth = PaymentUtil.preAuth0DollarCase("0");
        Assert.assertEquals("001",preAuth);
    }

    @Test
    public void buildMerchant() {
        Merchant merchant = PaymentUtil.buildMerchant();
        Assert.assertEquals("000001",merchant.getBin());
    }

    @Test
    public void responseStatus() {
        String resp = PaymentUtil.responseStatus("01");
        Assert.assertEquals(Constants.DECLINED,resp);
    }

    @Test
    public void cloneTransactionRequest() {
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setTransactionId("1224");
        TransactionRequest transactionRequest1= PaymentUtil.cloneTransactionRequest(transactionRequest);
        Assert.assertEquals("1224", transactionRequest1.getTransactionId());
    }

    @Test
    public void buildRetryTrace() {
       String format = PaymentUtil.buildRetryTrace("13134","342");
        Assert.assertTrue(format.startsWith("13134"));

        String retryTrace = PaymentUtil.buildRetryTrace("0","342");
        Assert.assertFalse(retryTrace.startsWith("13134"));
    }

    @Test
    public void getCardTypeFromTokenNbr() {
       String cardType = PaymentUtil.getCardTypeFromTokenNbr("3534");
       Assert.assertEquals("",cardType);

        String vi = PaymentUtil.getCardTypeFromTokenNbr("456");
        Assert.assertEquals("VI",vi);
        String mc = PaymentUtil.getCardTypeFromTokenNbr("56758");
        Assert.assertEquals("MC",mc);
        String di = PaymentUtil.getCardTypeFromTokenNbr("678");
        Assert.assertEquals("DI",di);
        String am = PaymentUtil.getCardTypeFromTokenNbr("37");
        Assert.assertEquals("AM",am);

    }
}