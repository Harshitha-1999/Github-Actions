package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.model.request.ECHORequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ECHOResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Mono;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class ExportServiceTest {

    @InjectMocks
    ExportService exportService;

    @Mock
    private TransactionsDAO dao;

    @Test
    public void exportDataTest() {
        ECHORequest request = new ECHORequest();
        request.setBankResponseCd("wer");

        ECHOResponse response = new ECHOResponse();
        response.setCardExpiryDt("2022/03/26");

        Mono<ECHOResponse> responseMono = Mono.<ECHOResponse>just(response);
        when(dao.exportData(request)).thenReturn(responseMono);

        assertEquals(exportService.exportData(request).block().getCardExpiryDt(), "2022/03/26");
    }
}