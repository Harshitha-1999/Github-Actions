package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.constants.GatewayConstants;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.MerchRefTyp;
import com.github.benmanes.caffeine.cache.AsyncLoadingCache;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import javax.validation.constraints.AssertTrue;
import java.math.BigDecimal;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class TransactionCacheUtilsTest {

    @InjectMocks
    TransactionCacheUtils transactionCacheUtils;

    @Mock
    CacheManager cacheManager;

    @Mock
    private SecurityLogger log;

    @Mock
    private Cache cache;

    @Mock
    private AsyncLoadingCache merchRefTypCache;

    @Test
    void getMerchRefType() {
        ReflectionTestUtils.setField(transactionCacheUtils,"log",log);
        MerchRefTyp resp =transactionCacheUtils.getMerchRefType("key");
        Assert.assertNull(resp);
    }

    @Test
    public void getMerchRefTypeTest() {
        Cache.ValueWrapper valueWrapper = getValueWrapper();
        Mockito.when(cacheManager.getCache("MERCH_REF_TYP_CACHE")).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        MerchRefTyp resp =transactionCacheUtils.getMerchRefType("1258");
        Assert.assertEquals(Optional.ofNullable(123L), Optional.ofNullable(resp.getStoreId()));

    }

    @Test
    public void getFullAuthStoreTest() {
        Cache.ValueWrapper valueWrapper = getValueWrapper();
        Mockito.when(cacheManager.getCache("FULL_AUTH_STORE_CACHE")).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.getFullAuthStore("1258");
        Assert.assertTrue(resp);
    }

    @Test
    public void getFullAuthStoreReturnFalseTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache("FULL_AUTH_STORE_CACHE")).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.getFullAuthStore("1258");
        Assert.assertFalse(resp);
    }

    @Test
    public void getStoredCredStoreTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(Boolean.TRUE);
        Mockito.when(cacheManager.getCache("STORED_CRED_STORE_CACHE")).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.getStoredCredStore("1258");
        Assert.assertTrue(resp);
    }

    @Test
    public void getStoredCredStoreReturnNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache("STORED_CRED_STORE_CACHE")).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.getStoredCredStore("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getCardTypTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(new BigDecimal("321"));
        Mockito.when(cacheManager.getCache(GatewayConstants.CARD_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getCardTyp("1258");
        Assert.assertEquals(Optional.ofNullable(321L), Optional.ofNullable(resp));
    }

    @Test
    public void getCardTypRetunNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.CARD_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getCardTyp("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getErrorTypTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(new BigDecimal("321"));
        Mockito.when(cacheManager.getCache(GatewayConstants.ERROR_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getErrorTyp("1258");
        Assert.assertEquals(Optional.ofNullable(321L), Optional.ofNullable(resp));
    }

    @Test
    public void getErrorTypReturnNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.ERROR_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getErrorTyp("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getTokenTypTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(new BigDecimal("321"));
        Mockito.when(cacheManager.getCache(GatewayConstants.TOKEN_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getTokenTyp("1258");
        Assert.assertEquals(Optional.ofNullable(321L), Optional.ofNullable(resp));
    }

    @Test
    public void getTokenTypReturnNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.TOKEN_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getTokenTyp("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getTransactionTypTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(new BigDecimal("321"));
        Mockito.when(cacheManager.getCache(GatewayConstants.TRANSACTION_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getTransactionTyp("1258");
        Assert.assertEquals(Optional.ofNullable(321L), Optional.ofNullable(resp));
    }

    @Test
    public void getTransactionTypReturnNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.TRANSACTION_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getTransactionTyp("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getTransactionStatusTypTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(new BigDecimal("321"));
        Mockito.when(cacheManager.getCache(GatewayConstants.TRANSACTION_STATUS_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getTransactionStatusTyp("1258");
        Assert.assertEquals(Optional.ofNullable(321L), Optional.ofNullable(resp));
    }

    @Test
    public void getTransactionStatusReturnNullTypTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.TRANSACTION_STATUS_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getTransactionStatusTyp("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getValidationStatusTypTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(new BigDecimal("321"));
        Mockito.when(cacheManager.getCache(GatewayConstants.VALIDATION_STATUS_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getValidationStatusTyp("1258");
        Assert.assertEquals(Optional.ofNullable(321L), Optional.ofNullable(resp));
    }

    @Test
    public void getValidationStatusTypReturnNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.VALIDATION_STATUS_TYP_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Long resp =transactionCacheUtils.getValidationStatusTyp("1258");
        Assert.assertNull(resp);
    }

    @Test
    public void getFeatureFlagValueTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(Boolean.TRUE);
        Mockito.when(cacheManager.getCache(GatewayConstants.FEATURE_FLAG_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.getFeatureFlagValue("1258");
        Assert.assertTrue(resp);
    }

    @Test
    public void getFeatureFlagValueReturnFalseTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.FEATURE_FLAG_CACHE)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.getFeatureFlagValue("1258");
        Assert.assertFalse(resp);
    }

    @Test
    public void isChaseOrbitalUrlEnabledTest() {
        Cache.ValueWrapper valueWrapper = getObjectValueWrapper(Boolean.TRUE);
        Mockito.when(cacheManager.getCache(GatewayConstants.CHASE_ORBITAL_URL)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.isChaseOrbitalUrlEnabled("1258");
        Assert.assertTrue(resp);
    }

    @Test
    public void isChaseOrbitalUrlEnabledIfNullTest() {
        Cache.ValueWrapper valueWrapper = null;
        Mockito.when(cacheManager.getCache(GatewayConstants.CHASE_ORBITAL_URL)).thenReturn(cache);
        Mockito.when(cache.get(Mockito.any())).thenReturn(valueWrapper);
        Boolean resp =transactionCacheUtils.isChaseOrbitalUrlEnabled("1258");
        Assert.assertTrue(resp);
    }

    @Test
    public void getMerchRefTypTest() {
    CompletableFuture<MerchRefTyp> future = new CompletableFuture<>();
    Mockito.when(merchRefTypCache.get(Mockito.any())).thenReturn(future);
    Mono<MerchRefTyp> resp =transactionCacheUtils.getMerchRefTyp("1258");
    Assert.assertNotNull(resp);
    }

    private Cache.ValueWrapper getValueWrapper() {
        Cache.ValueWrapper valueWrapper = new Cache.ValueWrapper() {
            @Override
            public Object get() {
                MerchRefTyp merchRefTyp = new MerchRefTyp();
                merchRefTyp.setStoreId(123L);
                return merchRefTyp;
            }
        };
        return valueWrapper;
    }

    private Cache.ValueWrapper getObjectValueWrapper(Object value) {
        Cache.ValueWrapper valueWrapper = new Cache.ValueWrapper() {
            @Override
            public Object get() {
                return value;
            }
        };
        return valueWrapper;
    }
}