package com.albertsons.ecommerce.ospg.payments.data;

import com.albertsons.ecommerce.ospg.payments.model.request.Token;
import com.albertsons.ecommerce.ospg.payments.model.request.TokenData;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.springframework.stereotype.Component;

@Component
public class TransactionResponseData {

    public TransactionResponse buildValidResponse(String transactionType) {
        TransactionResponse transactionResponse = new TransactionResponse();
        transactionResponse.setMethod("token");
        transactionResponse.setAmount("100");
        transactionResponse.setCurrency("USD");
        transactionResponse.setToken(buildValidToken());
        transactionResponse.setTransactionStatus("approved");
        transactionResponse.setValidationStatus("success");
        transactionResponse.setTransactionType(transactionType);
        transactionResponse.setTransactionId("610C624B0620C39A30CA2B8D44AA7DC7FE5A532C");
        transactionResponse.setTransactionTag("tst758");
        transactionResponse.setBankMessage("Approved");
        transactionResponse.setBankRespCode("100");
        transactionResponse.setCorrelationId("124.1316614570344");
        transactionResponse.setAvs("avs");

        return transactionResponse;
    }

    public TransactionResponse buildInValidResponse(String transactionType) {
        TransactionResponse response =  buildValidResponse(transactionType);
        response.setTransactionStatus("Not Processed");
        return response;
    }

    private Token buildValidToken() {
        return Token.builder().tokenType("FDToken")
                .tokenData(buildValidTokenData()).build();
    }

    private TokenData buildValidTokenData() {
        return TokenData.builder()
                .type("visa")
                .cardholderName("TEST name")
                .cvv("321")
                .expiryDate("1125")
                .value("7450448185593207")
                .build();
    }
}
