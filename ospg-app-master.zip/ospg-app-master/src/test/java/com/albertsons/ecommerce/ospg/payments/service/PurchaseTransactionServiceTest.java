package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.entity.AuthDetails;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.Status;
import com.albertsons.ecommerce.ospg.payments.model.request.*;
import com.albertsons.ecommerce.ospg.payments.model.response.CaptureResp;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class PurchaseTransactionServiceTest {

    @MockBean
    private PaymentGatewayServiceHelper serviceHelper;

    @Mock
    private TransactionsDAO dao;
    @MockBean
    ChaseCaller mockCaller;
    @MockBean
    private WebClient.ResponseSpec responseSpec;
    @MockBean
    CommonService commonService;

    @MockBean
    private AuthorizeTransactionService authService;

    @SpyBean
    private PurchaseTransactionService purchaseTransactionService;

    @Test
    public void testpurchase() {
        Mockito.when(authService.preAuthAndCapture(ArgumentMatchers.any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionResponse()));
        Mono<TransactionResponse> resp = purchaseTransactionService.purchase(getTransactionRequest());
        resp.subscribe( res -> Assert.assertNotNull(res));
    }

    @Test
    public void purchasetest() {
        Mockito.when(authService.preAuthAndCapture(ArgumentMatchers.any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionResponse()));
        dao = Mockito.mock(TransactionsDAO.class);
        List<AuthDetails> authDetails = new ArrayList<>();
        authDetails.add(getAuthDetails());
        TransactionRequest transactionRequest=Mockito.mock(TransactionRequest.class);
        Mockito.when(transactionRequest.getStoreId()).thenReturn("234");
        ReflectionTestUtils.setField(purchaseTransactionService,"dao",dao);
        Mockito.when(dao.getPrevAuthDetails(transactionRequest)).thenReturn(Mono.just(getAuthDetails()));
        Mono<TransactionResponse> resp = purchaseTransactionService.purchase(transactionRequest);
        resp.subscribe(res ->Assert.assertNotNull(res));
    }

    @Test
    public void purchaseWithTransactionIdTest() {
        Mockito.when(authService.preAuthAndCapture(ArgumentMatchers.any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionResponse()));
        dao = Mockito.mock(TransactionsDAO.class);
        List<AuthDetails> authDetails = new ArrayList<>();
        authDetails.add(getAuthDetails());
        TransactionRequest transactionRequest = getTransactionRequestWithAllPossibleData();
        ReflectionTestUtils.setField(purchaseTransactionService,"dao",dao);
        Mockito.when(dao.getPrevAuthDetails(transactionRequest)).thenReturn(Mono.just(getAuthDetails()));
        Mockito.when(dao.checkIfDuplicatePurchase(Mockito.any())).thenReturn(getTransactionResponse());
        Mockito.when(authService.incrementalAuth(Mockito.any())).thenReturn(getTransactionResponse());
        Mockito.when(mockCaller.callChaseService(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseSpec);
        Mockito.when(responseSpec.bodyToMono(CaptureResp.class)).thenReturn(Mono.just(getCaptureResp()));
        Mono<TransactionResponse> resp = purchaseTransactionService.purchase(transactionRequest);
        resp.subscribe(res ->Assert.assertNotNull(res));
    }

    @Test
    public void purchaseWithSoftDesDbaEmptyTest() {
        Mockito.when(authService.preAuthAndCapture(ArgumentMatchers.any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionResponse()));
        dao = Mockito.mock(TransactionsDAO.class);
        List<AuthDetails> authDetails = new ArrayList<>();
        authDetails.add(getAuthDetails());
        TransactionRequest transactionRequest = getTransactionRequestWithAllPossibleData();
        transactionRequest.getSoftDescriptors().setDba_name("");
        ReflectionTestUtils.setField(purchaseTransactionService,"dao",dao);
        Mockito.when(dao.getPrevAuthDetails(transactionRequest)).thenReturn(Mono.just(getAuthDetails()));
        Mockito.when(dao.checkIfDuplicatePurchase(Mockito.any())).thenReturn(getTransactionResponse());
        Mockito.when(authService.incrementalAuth(Mockito.any())).thenReturn(getTransactionResponse());
        Mockito.when(mockCaller.callChaseService(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseSpec);
        Mockito.when(responseSpec.bodyToMono(CaptureResp.class)).thenReturn(Mono.just(getCaptureResp()));
        Mockito.when(commonService.getMerchRefDsc(Mockito.any())).thenReturn("SAFEWAY.COM");
        Mono<TransactionResponse> resp = purchaseTransactionService.purchase(transactionRequest);
        resp.subscribe(res ->Assert.assertNotNull(res));
    }

    @Test
    public void purchaseWithSellerNullAndSoftDesDbaEmptyTest() {
        Mockito.when(authService.preAuthAndCapture(ArgumentMatchers.any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionResponse()));
        dao = Mockito.mock(TransactionsDAO.class);
        List<AuthDetails> authDetails = new ArrayList<>();
        authDetails.add(getAuthDetails());
        TransactionRequest transactionRequest = getTransactionRequestWithAllPossibleData();
        transactionRequest.setSellerId(null);
        transactionRequest.getSoftDescriptors().setDba_name("");
        ReflectionTestUtils.setField(purchaseTransactionService,"dao",dao);
        Mockito.when(dao.getPrevAuthDetails(transactionRequest)).thenReturn(Mono.just(getAuthDetails()));
        Mockito.when(dao.checkIfDuplicatePurchase(Mockito.any())).thenReturn(getTransactionResponse());
        Mockito.when(authService.incrementalAuth(Mockito.any())).thenReturn(getTransactionResponse());
        Mockito.when(mockCaller.callChaseService(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(responseSpec);
        Mockito.when(responseSpec.bodyToMono(CaptureResp.class)).thenReturn(Mono.just(getCaptureResp()));
        Mono<TransactionResponse> resp = purchaseTransactionService.purchase(transactionRequest);
        resp.subscribe(res ->Assert.assertNotNull(res));
    }

    private TransactionRequest getTransactionRequestWithAllPossibleData() {
        TransactionRequest transactionRequest= new TransactionRequest();
        transactionRequest.setAmount("100");
        transactionRequest.setTransactionId("tran123");
        transactionRequest.setStoreId("123");
        transactionRequest.setSellerId("1234");
        transactionRequest.setOrderId("12345");
        SoftDescriptor softDescriptor = new SoftDescriptor();
        softDescriptor.setSoftDescProdDesc("9");
        softDescriptor.setSoftDescMercName("8");
        softDescriptor.setDba_name("Trial Period Ended");
        transactionRequest.setSoftDescriptors(softDescriptor);
        Token token = new Token();
        TokenData tokenData = new TokenData();
        tokenData.setType("VI");
        token.setTokenData(tokenData);
        transactionRequest.setToken(token);
        return transactionRequest;
    }

    private CaptureResp getCaptureResp() {
        CaptureResp resp = new CaptureResp();
        Order order = new Order();
        Status status = new Status();
        status.setProcStatus("0");
        order.setStatus(status);
        resp.setTransType("TransType");
        resp.setOrder(order);

        return resp;
    }

    private Mono<TransactionResponse> getTransactionResponse() {
        TransactionResponse response = new TransactionResponse();
        response.setAmount("100");
        response.setTransactionId("tran123");

        return Mono.just(response);
    }

    private TransactionRequest getTransactionRequest1() {
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setStoreId(Constants.DUMMY_TRANSACTION_TAG);
        return transactionRequest;
    }

    private AuthDetails getAuthDetails() {
        AuthDetails authDetails = new AuthDetails();
        authDetails.setProviderTransactionId("test");
        authDetails.setAmount(new BigDecimal(1));
        authDetails.setCardType("Visa");
        authDetails.setProviderTransactionId("s");
        authDetails.setTransactionTag("tag");
        return authDetails;
    }

    private TransactionRequest getTransactionRequest() {
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        return transactionRequest;
    }

}
