package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.data.TransactionResponseData;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.IRefundTransactionService;
import com.albertsons.ecommerce.ospg.payments.service.RefundTransactionService;
import com.albertsons.ecommerce.ospg.payments.util.PaymentTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

/***
 *
 * @author mmohi05
 *
 */
@WebFluxTest(RefundController.class)
//@RunWith(MockitoJUnitRunner.class)
public class RefundControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private RefundTransactionService mockRefundService;

    @Test
    public void refundTest() {
        TransactionResponseData transactionResponseData = new TransactionResponseData();
        given(mockRefundService.refund(any(TransactionRequest.class)))
                .willReturn(Mono.just(transactionResponseData.buildValidResponse(TransactionType.REFUND.toString())));
        TransactionRequestData transactionRequestData = new TransactionRequestData();
        TransactionRequest transactionRequest = transactionRequestData.buildValidRequest(TransactionType.REFUND.toString());
        PaymentTestUtil.testValidationSuccess(webTestClient, "/transaction/refund", transactionRequest);
    }

    @Test
    public void refundDeclinedTest() {
        TransactionResponseData transactionResponseData = new TransactionResponseData();
        TransactionResponse transactionResponse = transactionResponseData.buildValidResponse(TransactionType.AUTHORIZE.toString());
        transactionResponse.setTransactionStatus("declined");
        given(mockRefundService.refund(any(TransactionRequest.class)))
                .willReturn(Mono.just(transactionResponse));
        TransactionRequestData transactionRequestData = new TransactionRequestData();
        TransactionRequest transactionRequest = transactionRequestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        PaymentTestUtil.testValidationPreconditionFailed(webTestClient, "/transaction/refund", transactionRequest);
    }

    @Test
    public void subRefundTest() {
        given(mockRefundService.refund(any(TransactionRequest.class)))
                .willReturn(Mono.just(new TransactionResponse()));
        TransactionRequestData transactionRequestData = new TransactionRequestData();
        TransactionRequest transactionRequest = transactionRequestData.buildValidRequest(TransactionType.REFUND.toString());
        PaymentTestUtil.testValidationInternalServerError(webTestClient, "/transaction/subscription-refund", transactionRequest);
    }
}
