package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.PurchaseTransactionService;
import com.albertsons.ecommerce.ospg.payments.util.PaymentTestUtil;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@WebFluxTest(PurchaseController.class)
public class PurchaseControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private PurchaseTransactionService service;

    @Test
    public void purchaseTransaction() {
        TransactionRequestData transactionRequestData = new TransactionRequestData();
        TransactionRequest transactionRequest = transactionRequestData.buildValidRequest(TransactionType.PURCHASE.toString());
        Mockito.when(service.purchase(ArgumentMatchers.any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionResponse()));
        PaymentTestUtil.testValidationSuccess(webTestClient, "/transaction/purchase", transactionRequest);
    }
}
