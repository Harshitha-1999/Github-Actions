package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.Status;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ReversalResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * SCHAL14
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class VoidTransactionServiceTest {
    @Autowired
    private TransactionRequestData requestData;
    @SpyBean
    private VoidTransactionService voidTransactionService;
    @MockBean
    private TransactionsDAO dao;
    @MockBean
    private ChaseCaller mockCaller;
    @Mock
    private ResponseSpec responseMock;
    @Mock
    private WebClient webClientMock;
    @Mock
    private RequestBodySpec requestBodyMock;
    @Mock
    private RequestBodyUriSpec requestBodyUriMock;

    @Test
    public void voidTransactionTest() {
        TransactionRequest request = requestData.buildValidRequest(TransactionType.VOID.toString());
        when(webClientMock.post()).thenReturn(requestBodyUriMock);
        when(requestBodyUriMock.uri(anyString())).thenReturn(requestBodyMock);
        when(requestBodyMock.header(any(), any())).thenReturn(requestBodyMock);
        when(requestBodyMock.accept(any())).thenReturn(requestBodyMock);
        when(requestBodyMock.retrieve()).thenReturn(responseMock);
        when(mockCaller.callChaseService(anyObject(), anyString(), anyString())).thenReturn(responseMock);
        Mono<List<String>>  monoList=Mono.just(Arrays.asList("2134323","2345423543","432532543","3425467765","7667586664"));
        when(dao.fetchTokenNumber(request)).thenReturn(monoList);
        when(responseMock.bodyToMono(ArgumentMatchers.<Class<ReversalResponse>>notNull())).thenReturn((Mono<ReversalResponse>) Mono.just(buidReversalResponse("approved", "00")));
        responseMock.toEntity(ReversalResponse.class);

        doNothing().when(dao).saveSuccessTransaction(request, new TransactionResponse());
        Mono<TransactionResponse> response = voidTransactionService.voidTransaction(request);
        response.subscribe(rsp -> assertEquals(rsp.getTransactionStatus(), "approved"));
    }

    private ReversalResponse buidReversalResponse(String preauthStatus, String respCode) {
        ReversalResponse response = new ReversalResponse();
        Order order = new Order();
        Status status = new Status();
        status.setProcStatusMessage(preauthStatus);
        status.setPymtBrandAuthResponseCode(respCode);
        order.setStatus(status);
        response.setOrder(order);
        return response;
    }
}
