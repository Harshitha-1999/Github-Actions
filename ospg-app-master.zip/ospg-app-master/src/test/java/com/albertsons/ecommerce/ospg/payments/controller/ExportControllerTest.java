package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.model.request.ECHORequest;
import com.albertsons.ecommerce.ospg.payments.model.response.ECHOResponse;
import com.albertsons.ecommerce.ospg.payments.service.ExportService;
import com.albertsons.ecommerce.ospg.payments.util.PaymentTestUtil;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@WebFluxTest(ExportController.class)
public class ExportControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private ExportService exportService;

    @Test
    public void exportDataTest() {
        ECHORequest echoRequest = new ECHORequest();
        Mockito.when(exportService.exportData(ArgumentMatchers.any(ECHORequest.class))).thenReturn(Mono.just(new ECHOResponse()));
        PaymentTestUtil.testValidationSuccess(webTestClient, "/transaction/echo-export", echoRequest);
    }

}
