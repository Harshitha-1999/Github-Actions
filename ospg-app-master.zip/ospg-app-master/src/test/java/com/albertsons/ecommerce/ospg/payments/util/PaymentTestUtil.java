package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.model.request.ECHORequest;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

public class PaymentTestUtil {
    public static void testValidationSuccess(WebTestClient webTestClient, String uri, TransactionRequest transactionRequest) {
        webTestClient.post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(Mono.just(transactionRequest), TransactionRequest.class)
                .exchange()
                .expectStatus().is2xxSuccessful();
    }

    public static void testValidationSuccess(WebTestClient webTestClient, String uri, TenderDeclineRequest transactionRequest) {
        webTestClient.post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(Mono.just(transactionRequest), TransactionRequest.class)
                .exchange()
                .expectStatus().is2xxSuccessful();
    }

    public static void testValidationSuccess(WebTestClient webTestClient, String uri, ECHORequest transactionRequest) {
        webTestClient.post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(Mono.just(transactionRequest), TransactionRequest.class)
                .exchange()
                .expectStatus().is2xxSuccessful();
    }

    public static void testValidationPreconditionFailed(WebTestClient webTestClient, String uri, TransactionRequest transactionRequest) {
        webTestClient.post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(Mono.just(transactionRequest), TransactionRequest.class)
                .exchange()
                .expectStatus().is4xxClientError();
    }

    public static void testValidationInternalServerError(WebTestClient webTestClient, String uri, TransactionRequest transactionRequest) {
        webTestClient.post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(Mono.just(transactionRequest), TransactionRequest.class)
                .exchange()
                .expectStatus().is5xxServerError();
    }
}
