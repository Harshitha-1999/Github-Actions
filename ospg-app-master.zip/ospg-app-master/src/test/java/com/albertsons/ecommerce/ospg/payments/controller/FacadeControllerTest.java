package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import com.albertsons.ecommerce.ospg.payments.service.FacadeService;
import com.albertsons.ecommerce.ospg.payments.util.PaymentTestUtil;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;

@WebFluxTest(FacadeController.class)
public class FacadeControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private FacadeService facadeService;

    @Mock
    private SecurityLogger log;

    @Autowired
    FacadeController fc;

    @Test
    public void getPaymentToken(){
        ReflectionTestUtils.setField(fc,"log",log);
        TenderDeclineRequest transactionRequest = new TenderDeclineRequest();
        Mockito.when(facadeService.getPaymentToken(any(TenderDeclineRequest.class), ArgumentMatchers.eq("storeid"))).thenReturn(Mono.just("String token"));
        PaymentTestUtil.testValidationSuccess(webTestClient, "/facade/get-payment-token?storeId=storeid", transactionRequest);
    }
}
