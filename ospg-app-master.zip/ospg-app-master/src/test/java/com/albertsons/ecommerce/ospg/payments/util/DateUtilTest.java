package com.albertsons.ecommerce.ospg.payments.util;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Timestamp;
import java.time.Instant;


@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class DateUtilTest {

    @InjectMocks
    DateUtil dateUtil;
    @Test
    public void getCurrentTimeStamp() {
        String currentTimeStamp = DateUtil.getCurrentTimeStamp();
        Assert.assertNotNull(currentTimeStamp);

    }

    @Test
    public void getFormattedTimeStamp() {
        Timestamp timestamp = DateUtil.getFormattedTimeStamp(DateUtil.getCurrentTimeStamp());
        Assert.assertNotNull(timestamp);
    }

    @Test
    public void addSubtractMinutesFromTimeStamp() {
        Timestamp timestamp = DateUtil.addSubtractMinutesFromTimeStamp(-10);
       Assert.assertTrue(timestamp.before(DateUtil.getFormattedTimeStamp(DateUtil.getCurrentTimeStamp())));
    }

    @Test
    public void convertInstantToSqlDate() {
       String time = DateUtil.convertInstantToSqlDate(Instant.now());
        Assert.assertNotNull(time);
    }
}