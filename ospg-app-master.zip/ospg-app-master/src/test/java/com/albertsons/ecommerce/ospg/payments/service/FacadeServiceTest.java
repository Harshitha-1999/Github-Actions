package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.external.TokenVaultCaller;
import com.albertsons.ecommerce.ospg.payments.model.request.TenderDeclineRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.PreauthResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Arrays;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class FacadeServiceTest {

    @InjectMocks
    FacadeService facadeService;
    @Mock
    TokenVaultCaller tokenVaultCaller;

    @Mock
    private WebClient.ResponseSpec responseMock;
    @Test
    public void getPaymentToken() {
        TenderDeclineRequest tenderDeclineRequest = new TenderDeclineRequest();
        tenderDeclineRequest.setPrimaryPurpose("regt");
        tenderDeclineRequest.setCustomerIds(Arrays.asList("234","23435"));
        Mockito.when(tokenVaultCaller.callTokenVaultService(tenderDeclineRequest, "/customers/tenders", "9845"))
                        .thenReturn(responseMock);
        when(responseMock.bodyToMono(ArgumentMatchers.<Class<String>>notNull())).thenReturn(Mono.just("approved"));
        Mono<String> response = facadeService.getPaymentToken(tenderDeclineRequest,"9845");
        response.subscribe(rsp -> assertEquals(rsp, "approved"));
    }
}