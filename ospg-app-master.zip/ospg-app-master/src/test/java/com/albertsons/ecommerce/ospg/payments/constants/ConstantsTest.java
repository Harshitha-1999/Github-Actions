package com.albertsons.ecommerce.ospg.payments.constants;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

/***
 *
 * @author MSUND21
 *
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class ConstantsTest {

    @Test
    public void testConstant() {
        Assert.assertNotNull(Constants.BIN);
        Assert.assertNotNull(Constants.CHASE_AUTHORIZE);
        Assert.assertNotNull(Constants.CHASE_CAPTURE);
        Assert.assertNotNull(Constants.NOT_PROCESSED);
        Assert.assertNotNull(Constants.MERCHANT);

        Assert.assertNotNull(Constants.ORBITRAL_CONN_MERCHANT);
        Assert.assertNotNull(Constants.ORBITRAL_CONN_USER);
        Assert.assertNotNull(Constants.ORBITRAL_CONN_PW);

        Assert.assertNotNull(Constants.TERMINAL_ID);
        Assert.assertNotNull(Constants.VERSION);

        Assert.assertNotNull(Constants.SUCCESS);
        Assert.assertNotNull(Constants.DECLINED);

        Assert.assertNotNull(Constants.SUCCESS_RESP_CODE);
        Assert.assertNotNull(Constants.SUBCRIPTION_STORE_ID);
    }

}