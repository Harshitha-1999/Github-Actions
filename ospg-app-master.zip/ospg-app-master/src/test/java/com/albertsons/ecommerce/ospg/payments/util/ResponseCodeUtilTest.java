package com.albertsons.ecommerce.ospg.payments.util;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import com.albertsons.ecommerce.ospg.payments.model.Status;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class ResponseCodeUtilTest {

    @Test
    public void getTransactionStatus() {
        Status status = new Status();
        status.setApprovalStatus("0");
        String declined =  ResponseCodeUtil.getTransactionStatus(status);
        Assert.assertEquals(Constants.DECLINED,declined);

        status.setApprovalStatus("1");
        String approved =  ResponseCodeUtil.getTransactionStatus(status);
        Assert.assertEquals(Constants.APPROVED,approved);

        String notProcessed =  ResponseCodeUtil.getTransactionStatus(null);
        Assert.assertEquals(Constants.NOT_PROCESSED,notProcessed);

        status.setApprovalStatus("2");
        String systemError =  ResponseCodeUtil.getTransactionStatus(status);
        Assert.assertEquals(Constants.NOT_PROCESSED,systemError);
    }

    @Test
    public void getTxnStatusPurchase() {
        Status status = new Status();
        status.setProcStatus("0");
        String approved = ResponseCodeUtil.getTxnStatusPurchase(status);
        Assert.assertEquals(Constants.APPROVED,approved);

        status.setProcStatus("2");
        String systemError =  ResponseCodeUtil.getTxnStatusPurchase(status);
        Assert.assertEquals(Constants.NOT_PROCESSED,systemError);

        String notProcessed =  ResponseCodeUtil.getTxnStatusPurchase(null);
        Assert.assertEquals(Constants.NOT_PROCESSED,notProcessed);
    }
}