package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.exceptions.PaymentDataAccessException;
import com.albertsons.ecommerce.ospg.payments.model.request.MerchantInitiatedTransaction;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import javax.crypto.Mac;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

@SpringBootTest
@PrepareForTest({Mac.class})
//@RunWith(PowerMockRunner.class)
@RunWith(MockitoJUnitRunner.class)
public class PaymentGatewayServiceHelperTest {

    @InjectMocks
    private PaymentGatewayServiceHelper serviceHelper;

    @Mock
    private ObjectMapper objectMapper;

//    @Rule
//    public PowerMockito rule = new PowerMockito();

    @Test
    public void getSecurityKeysTest() {

        Map<String, String> response = serviceHelper.getSecurityKeys("apiKey",  "securedSecret", "token", "payload");
        Assert.assertNotNull(response);
        Assert.assertEquals("apiKey", response.get("apikey"));
        Assert.assertEquals("payload", response.get("payload"));
        Assert.assertEquals("token", response.get("token"));
    }

   /* @Test(expected = PaymentDataAccessException.class)
    public void getSecurityKeysExceptionTest() throws NoSuchAlgorithmException {
        PowerMockito.mockStatic(Mac.class);
        PowerMockito.when(Mac.getInstance("HmacSHA256")).thenThrow(new NoSuchAlgorithmException("Error"){});
        serviceHelper.getSecurityKeys("apiKey",  "securedSecret", "token", "payload");
    }*/

    @Test(expected = PaymentDataAccessException.class)
    public void getJsonPayloadExceptionTest() throws JsonProcessingException {
        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenThrow(new JsonProcessingException("Error"){});
        serviceHelper.getJsonPayload("payload");
    }

    @Test
    public void getHttpHeaderTest() {
        HttpHeaders response = serviceHelper.getHttpHeader("appId", "securityKey", "token", "payload");
        Assert.assertNotNull(response);
        Assert.assertEquals("appId", response.get("apikey").get(0));
    }

    @Test(expected = PaymentDataAccessException.class)
    public void convertJsonToMerchIntTxExceptionTest() throws JsonProcessingException {
        Mockito.when(objectMapper.readValue("ObjectString", MerchantInitiatedTransaction.class)).thenThrow(new JsonProcessingException("Error"){});
        serviceHelper.convertJsonToMerchIntTx("ObjectString");
    }
}
