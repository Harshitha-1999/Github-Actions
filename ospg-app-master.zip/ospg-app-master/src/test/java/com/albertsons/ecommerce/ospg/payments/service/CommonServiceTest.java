package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.exceptions.MerchantLookupException;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.MerchRefTyp;
import com.albertsons.ecommerce.ospg.payments.model.request.Token;
import com.albertsons.ecommerce.ospg.payments.model.request.TokenData;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.util.TransactionCacheUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Mono;

import javax.validation.constraints.AssertFalse;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class CommonServiceTest {

    @InjectMocks
    CommonService commonService;

    @Mock
    private TransactionsDAO dao;

    @Mock
    TransactionCacheUtils cacheUtils;

    @Mock
    SecurityLogger log;

    @Test
    public void fetchCreditCardTypeTestCardType() {
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setTransactionType("Credit");
        transactionRequest.setTransactionId("123");
        Token token = new Token();
        TokenData tokenData = new TokenData();
        tokenData.setType("AM");
        token.setTokenData(tokenData);
        transactionRequest.setToken(token);

        Mono<String> result = commonService.fetchCreditCardType(transactionRequest);
        assertEquals("American Express", result.block());
    }

    @Test
    public void fetchCreditCardTypeTestFromDB() {
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setTransactionType("Credit");
        transactionRequest.setTransactionId("123");
        Token token = new Token();
        TokenData tokenData = new TokenData();
        tokenData.setType("");
        token.setTokenData(tokenData);
        transactionRequest.setToken(token);

        when(dao.fetchCardType(transactionRequest)).thenReturn(Mono.<String>just("Credit Card"));

        Mono<String> result = commonService.fetchCreditCardType(transactionRequest);
        assertEquals("Credit Card", result.block());
    }

    @Test(expected = MerchantLookupException.class)
    public void getMerchRefDscExecptionTest(){
      commonService.getMerchRefDsc("storeId");
    }
    @Test
    public void getMerchRefDscTest(){
        MerchRefTyp merchRefTyp = new MerchRefTyp();
        merchRefTyp.setMerchRefDsc("ref");
        Mockito.when(cacheUtils.getMerchRefType("storeId"))
                        .thenReturn(merchRefTyp);
      String merchRefDesc =  commonService.getMerchRefDsc("storeId");
        Assert.assertEquals("ref", merchRefDesc);
    }

    @Test
    public void getMerchRefIdTest(){
        MerchRefTyp merchRefTyp = new MerchRefTyp();
        merchRefTyp.setMerchRefDsc("ref");
        merchRefTyp.setMarketPlaceMid("marketplace");
        Mockito.when(cacheUtils.getMerchRefType("storeId"))
                .thenReturn(merchRefTyp);
       String id = commonService.getMerchRefId("storeId","sellerId");
        Assert.assertEquals(id,"marketplace");
    }

    @Test(expected = MerchantLookupException.class)
    public void getMerchRefIdExceptionTest(){
        commonService.getMerchRefId("storeId","sellerId");
    }

    @Test
    public void getFeatureFlagValueTest() {
        boolean result = commonService.getFeatureFlagValue("test");
        Assert.assertFalse(result);
    }

    @Test
    public void isChaseOrbitalUrlEnabledTest() {
        boolean result = commonService.isChaseOrbitalUrlEnabled("test");
        Assert.assertFalse(result);
    }

}