package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.data.TransactionResponseData;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.service.AuthorizeTransactionService;
import com.albertsons.ecommerce.ospg.payments.service.ErrorHandlingService;
import com.albertsons.ecommerce.ospg.payments.service.PaymentGatewayServiceHelper;
import com.albertsons.ecommerce.ospg.payments.util.PaymentTestUtil;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

/***
 *
 * @author MSUND21
 *
 */
@WebFluxTest(AuthorizationController.class)
@RunWith(MockitoJUnitRunner.class)
class AuthorizationControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private AuthorizeTransactionService authTransactionsService;

    @MockBean
    private ErrorHandlingService errorHandlingService;

    @MockBean
    private PaymentGatewayServiceHelper serviceHelper;

    @Test
    void authorizeTest() {
        TransactionResponseData transactionResponseData = new TransactionResponseData();
        given(authTransactionsService.preauth(any(TransactionRequest.class)))
                .willReturn(Mono.just(transactionResponseData.buildValidResponse(TransactionType.AUTHORIZE.toString())));
        TransactionRequestData transactionRequestData = new TransactionRequestData();
        TransactionRequest transactionRequest = transactionRequestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        PaymentTestUtil.testValidationSuccess(webTestClient, "/transaction/authorize", transactionRequest);
    }


}