package com.albertsons.ecommerce.ospg.payments.validation.validator;

import com.albertsons.ecommerce.ospg.payments.enumerations.ValidationErrorCode;
import com.albertsons.ecommerce.ospg.payments.exceptions.DataValidationException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class ValidatorTest {

    @InjectMocks
    AuthTypeValidator authTypeValidator;

    @InjectMocks
    CVVValidator cvvValidator;

    @InjectMocks
    AlphabetValidator alphabetValidator;

    @Test
    public void initialize() {
        authTypeValidator.initialize(Mockito.mock(AuthType.class));
        cvvValidator.initialize(Mockito.mock(CVV.class));
        alphabetValidator.initialize(Mockito.mock(Alphabet.class));
    }

    @Test
    public void isValid() {
        authTypeValidator.initialize(Mockito.mock(AuthType.class));
        boolean isValid = authTypeValidator.isValid("authorize",null);
        Assert.assertTrue(isValid);

        boolean isCvvValid =  cvvValidator.isValid("cvv",null);
        Assert.assertTrue(isCvvValid);

        boolean isCvvNull =  cvvValidator.isValid(null,null);
        Assert.assertTrue(isCvvNull);

        boolean alphabetValid =  alphabetValidator.isValid("alphabet",null);
        Assert.assertTrue(alphabetValid);

        boolean alphabetNull =  alphabetValidator.isValid(null,null);
        Assert.assertTrue(alphabetNull);
    }

    @Test(expected = DataValidationException.class)
    public void isValid_DataValidationException() {
        authTypeValidator.initialize(Mockito.mock(AuthType.class));
        authTypeValidator.isValid("authorized",null);

    }

    @Test(expected = DataValidationException.class)
    public void isValid_AuthTypeNull() {
        ValidationErrorCode error =ValidationErrorCode.CARD_TYPE_INVALID_VALUE;
        ReflectionTestUtils.setField(authTypeValidator,"error",error);
        authTypeValidator.isValid(null,null);

    }

    @Test(expected = DataValidationException.class)
    public void isValid_Cvv() {
        ValidationErrorCode error =ValidationErrorCode.CARD_TYPE_INVALID_VALUE;
        ReflectionTestUtils.setField(cvvValidator,"error",error);
         cvvValidator.isValid("",null);
    }

    @Test(expected = DataValidationException.class)
    public void isValidAlphabetValidatorErrorTest() {
        ValidationErrorCode error =ValidationErrorCode.CARD_TYPE_INVALID_VALUE;
        ReflectionTestUtils.setField(alphabetValidator,"error",error);
        alphabetValidator.isValid("%125%",null);

    }
}