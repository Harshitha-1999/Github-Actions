package com.albertsons.ecommerce.ospg.payments.controller;

import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.data.TransactionResponseData;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.model.request.TransactionRequest;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.service.VoidTransactionService;
import com.albertsons.ecommerce.ospg.payments.util.PaymentTestUtil;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

/***
 *
 * @author SCHAL14
 *
 */
@WebFluxTest(VoidController.class)
@RunWith(MockitoJUnitRunner.class)
class VoidControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private VoidTransactionService voidTransactionService;

    @Test
    void voidTransaction() {
        TransactionResponseData transactionResponseData = new TransactionResponseData();
        given(voidTransactionService.voidTransaction(any(TransactionRequest.class)))
                .willReturn(Mono.just(transactionResponseData.buildValidResponse(TransactionType.VOID.toString())));
        TransactionRequestData transactionRequestData = new TransactionRequestData();
        TransactionRequest transactionRequest = transactionRequestData.buildValidRequest(TransactionType.VOID.toString());
        PaymentTestUtil.testValidationSuccess(webTestClient,"/transaction/void", transactionRequest);
    }
}