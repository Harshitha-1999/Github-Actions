package com.albertsons.ecommerce.ospg.payments.entity;

import com.albertsons.ecommerce.ospg.payments.dao.BaseHeaderDto;
import com.albertsons.ecommerce.ospg.payments.enumerations.MerchRefDsc;
import com.albertsons.ecommerce.ospg.payments.enumerations.OSPGTransactionCategory;
import com.albertsons.ecommerce.ospg.payments.model.SoftDesc;
import com.albertsons.ecommerce.ospg.payments.model.request.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;

import java.math.BigDecimal;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class EntityTest {


    Transaction transaction;
    TransactionDetails transactionDetails;
    TransactionToken transactionToken;
    TransactionResponseEntity responseEntity;

    BaseHeaderDto baseHeaderDto;
    CaptureReq captureReq;
    CvvUpdateRequest cvvUpdateRequest;
    RefundReq refundReq;
    SoftDescriptor softDescriptor;
    StoredCredentialRequest storedCredentialRequest;
    @Before
    public void init(){
        transaction = Transaction.builder().build();
        transaction.setTransactionTokenId(new BigDecimal(100));
        transaction.setTransactionId(new BigDecimal(200));
        transaction.setTransactionTyp(12L);

        transactionDetails = new TransactionDetails();
        transactionDetails.setMitReceivedTransactionId("");
        transactionToken = TransactionToken.builder().build();
        transactionToken.setTokenNbr("24");
        responseEntity = TransactionResponseEntity.builder().build();
        responseEntity.setBankResponseCd("cd");
        baseHeaderDto = new BaseHeaderDto();
        baseHeaderDto.setAggregateId("23");
        captureReq = new CaptureReq();
        captureReq.setSoftDesc(new SoftDesc());
         cvvUpdateRequest = new CvvUpdateRequest();
        cvvUpdateRequest.setUpdateDate(true);
        refundReq = RefundReq.builder().build();
        softDescriptor = new SoftDescriptor();
        storedCredentialRequest = new StoredCredentialRequest();


    }

    @Test
    public void test(){
       Assert.assertEquals(19,MerchRefDsc.values().length);
       Assert.assertEquals(6, OSPGTransactionCategory.values().length);
       Assert.assertEquals(100L,transaction.getTransactionTokenId().longValue());
    }

}