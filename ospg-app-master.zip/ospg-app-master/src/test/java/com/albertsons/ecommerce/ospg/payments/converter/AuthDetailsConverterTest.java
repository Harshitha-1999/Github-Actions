package com.albertsons.ecommerce.ospg.payments.converter;

import com.albertsons.ecommerce.ospg.payments.entity.AuthDetails;
import io.r2dbc.spi.Row;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.*;
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class AuthDetailsConverterTest {

    @InjectMocks
    AuthDetailsConverter authDetailsConverter;
    @Test
    public void convert() {
        Row row = Mockito.mock(Row.class);
        Mockito.when(row.get("PROVIDER_TRANSACTION_ID", String.class)).thenReturn("12345");
        AuthDetails authDetails = authDetailsConverter.convert(row);
        Assert.assertEquals("12345",authDetails.getProviderTransactionId());
    }
}