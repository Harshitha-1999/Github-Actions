package com.albertsons.ecommerce.ospg.payments.util;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.Optional;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class CommonUtilsTest {

    @InjectMocks
    CommonUtils commonUtils;

    @Test
    public void replaceCRLFWithMsgAndReplaceWithTest() {
        String response = commonUtils.replaceCRLF("test", "replaced");
        Assert.assertNotNull(response);
        Assert.assertEquals("test", response);
    }

    @Test
    public void replaceCRLFWithMsgAndReplaceWithEmptyTest() {
        String response = commonUtils.replaceCRLF("", "replaced");
        Assert.assertNotNull(response);
        Assert.assertEquals("", response);
    }

    @Test
    public void cleanMessage() {
        String response = commonUtils.cleanMessage("test");
        Assert.assertNotNull(response);
        Assert.assertEquals("test", response);
    }

    @Test
    public void multiply() {
        Integer response = commonUtils.multiply(new BigDecimal(10), 10);
        Assert.assertNotNull(response);
        Assert.assertEquals(Optional.of(100), Optional.of(response));
    }

    @Test
    public void roundDouble() {
        double response = commonUtils.roundDouble(100.00, 2);
        Assert.assertNotNull(response);
        Assert.assertEquals(Optional.of(100.0), Optional.of(response));

    }

}
