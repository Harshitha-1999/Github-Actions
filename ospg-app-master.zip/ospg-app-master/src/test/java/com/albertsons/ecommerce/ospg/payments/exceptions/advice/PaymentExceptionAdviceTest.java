package com.albertsons.ecommerce.ospg.payments.exceptions.advice;

import com.albertsons.ecommerce.ospg.payments.exceptions.*;
import com.albertsons.ecommerce.ospg.payments.logging.SecurityLogger;
import com.albertsons.ecommerce.ospg.payments.model.Order;
import com.albertsons.ecommerce.ospg.payments.model.Status;
import com.albertsons.ecommerce.ospg.payments.model.response.RefundResp;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class PaymentExceptionAdviceTest {

    @InjectMocks
    public PaymentExceptionAdvice paymentExceptionAdvice;
    @Mock
    SecurityLogger log;

    @Test
    public void handleResponseStatusErrorTest() throws Exception {
        ResponseStatusException responseStatusException = new ResponseStatusException(HttpStatus.BAD_REQUEST);
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice
                .handleResponseStatusError(responseStatusException);
        Assert.assertNotNull(res);

    }

    @Test
    public void handleDataValidationErrorTest() throws Exception {
        DataValidationException dataValidationException = new DataValidationException("error");
        dataValidationException.setErrorCode("403");
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice.handleDataValidationError(dataValidationException);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleVoidFailureExceptionTest() throws Exception {
        TransactionResponse transactionResponse = new TransactionResponse();
        VoidFailureExceptions voidFailureExceptions = new VoidFailureExceptions(HttpStatus.BAD_REQUEST, transactionResponse);
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice
                .handleVoidFailureException(voidFailureExceptions);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleChaseServerExceptionTest() throws  Exception {
        ChaseServerException chaseServerException = new ChaseServerException("error");
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice.handleChaseServerException(chaseServerException);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleRefundFailureException() throws Exception {
        RefundResp refundResp = new RefundResp();
        Order order = new Order();
        Status status = new Status();
        status.setProcStatus("procStatus");
        status.setHostRespCode("HostRespCode");
        status.setProcStatusMessage("ProcStatusMessage");
        order.setStatus(status);
        refundResp.setOrder(order);
        RefundFailureExceptions refundFailureExceptions = new RefundFailureExceptions(refundResp);
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice
                .handleRefundFailureException(refundFailureExceptions);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleWebClientResponseExceptionTest() {
        WebClientResponseException webClientResponseException = new WebClientResponseException(403, "Error", null, null, null);
        Mono<ResponseEntity<String>> res = paymentExceptionAdvice.handleWebClientResponseException(webClientResponseException);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleMerchantLookupExceptionTest() throws Exception {
        MerchantLookupException merchantLookupException = new MerchantLookupException("Error");
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice.handleMerchantLookupException(merchantLookupException);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleUserPaymentProviderUnReachableExceptionTest() throws Exception {
        PaymentProviderDownException paymentProviderDownException = new PaymentProviderDownException("Error");
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice
                .handleUserPaymentProviderUnReachableException(paymentProviderDownException);
        Assert.assertNotNull(res);
    }

    @Test
    public void handleDuplicateContentResponseErrorTest() throws Exception {
        DuplicateContentResponseException duplicateContentResponseException =
                new DuplicateContentResponseException(HttpStatus.CONFLICT, new TransactionResponse(), "Error", "" );
        Mono<ResponseEntity<TransactionResponse>> res = paymentExceptionAdvice
                .handleDuplicateContentResponseError(duplicateContentResponseException);
        Assert.assertNotNull(res);
    }

}
