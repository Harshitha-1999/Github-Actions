package com.albertsons.ecommerce.ospg.payments.service;

import com.albertsons.ecommerce.ospg.payments.constants.Constants;
import com.albertsons.ecommerce.ospg.payments.dao.TransactionsDAO;
import com.albertsons.ecommerce.ospg.payments.data.TransactionRequestData;
import com.albertsons.ecommerce.ospg.payments.entity.TransactionDetails;
import com.albertsons.ecommerce.ospg.payments.enumerations.TransactionType;
import com.albertsons.ecommerce.ospg.payments.external.ChaseCaller;
import com.albertsons.ecommerce.ospg.payments.model.*;
import com.albertsons.ecommerce.ospg.payments.model.request.*;
import com.albertsons.ecommerce.ospg.payments.model.response.PreauthResponse;
import com.albertsons.ecommerce.ospg.payments.model.response.TransactionResponse;
import com.albertsons.ecommerce.ospg.payments.external.TokenVaultCaller;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.reactivestreams.Subscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.CoreSubscriber;
import reactor.core.publisher.Mono;

import javax.validation.constraints.Null;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/***
 *
 * @author MSUND21
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class AuthTransactionsServiceTest {

    @Autowired
    private TransactionRequestData requestData;

    @SpyBean
    private AuthorizeTransactionService authTransactionsService;

    @MockBean
    private TransactionsDAO dao;

    @MockBean
    private ChaseCaller caller;

    @Mock
    private WebClient.ResponseSpec responseMock;

    @Mock
    private WebClient webClientMock;

    @Mock
    private WebClient.RequestBodySpec requestBodyMock;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriMock;

    @Mock
    private TokenVaultCaller tokenVaultCaller;

    @Test
    public void authorizeTransactionApprovedTest() {
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        when(webClientMock.post()).thenReturn(requestBodyUriMock);
        when(requestBodyUriMock.uri(anyString())).thenReturn(requestBodyMock);
        when(requestBodyMock.header(any(), any())).thenReturn(requestBodyMock);
        when(requestBodyMock.accept(any())).thenReturn(requestBodyMock);
        when(requestBodyMock.retrieve()).thenReturn(responseMock);
        when(caller.callChaseService(anyObject(), anyString(), anyString())).thenReturn(responseMock);
        when(responseMock.bodyToMono(ArgumentMatchers.<Class<PreauthResponse>>notNull())).thenReturn(Mono.just(getPreAuthResponse("approved","00")));
        responseMock.toEntity(PreauthResponse.class);

        doNothing().when(dao).saveSuccessTransaction(request, new TransactionResponse());
        Mono<TransactionResponse> response = authTransactionsService.preauth(request);
        assertNull(response);
    }
    @Test(expected = Exception.class)
    public void authorizeTransactionApprovedTestExcpetion() {
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        when(caller.callChaseService(anyObject(), anyString(), anyString())).thenThrow(Exception.class);
       authTransactionsService.preauth(request);
    }


    @Test
    public void authorizeTransactionDeclinedTest() {
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        when(webClientMock.post()).thenReturn(requestBodyUriMock);
        when(requestBodyUriMock.uri(anyString())).thenReturn(requestBodyMock);
        when(requestBodyMock.header(any(), any())).thenReturn(requestBodyMock);
        when(requestBodyMock.accept(any())).thenReturn(requestBodyMock);
        when(requestBodyMock.retrieve()).thenReturn(responseMock);
        when(caller.callChaseService(anyObject(), anyString(), anyString())).thenReturn(responseMock);
        when(responseMock.bodyToMono(ArgumentMatchers.<Class<PreauthResponse>>notNull()))
                .thenReturn(Mono.just(getPreAuthResponse("declined","01")));
        responseMock.toEntity(PreauthResponse.class);

        doNothing().when(dao).saveSuccessTransaction(request, new TransactionResponse());
        Mono<TransactionResponse> response = authTransactionsService.preauth(request);
        Assert.assertNull(response);
    }

    @Test
    public void getMitReceivedTranIdTest() {
        when(dao.fetchMitReceivedTranId(any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionDetails()));
        when(dao.fetchMitReceivedTranIdByToken(any(TransactionRequest.class))).thenReturn(Mono.just(new TransactionDetails()));
        authTransactionsService.getMitReceivedTranId(new TransactionRequest());
        Mono<TransactionDetails> detailsMono = authTransactionsService.fetchMitReceivedTranIdByToken(new TransactionRequest());
        detailsMono.subscribe(details -> Assert.assertNotNull(details));
    }

    @Test
    public void preAuthAndCaptureTest(){
        TransactionDetails transactionDetails = new TransactionDetails();
        when(dao.fetchMitReceivedTranId(any(TransactionRequest.class))).thenReturn(Mono.just(transactionDetails));
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        Mono<TransactionResponse> resp = authTransactionsService.preAuthAndCapture(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test
    public void preAuthAndCaptureTest1(){
        TransactionDetails transactionDetails = new TransactionDetails();
        when(dao.fetchMitReceivedTranIdByToken(any(TransactionRequest.class))).thenReturn(Mono.just(transactionDetails));
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        Mono<TransactionResponse> resp = authTransactionsService.preAuthAndCapture(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test
    public void preAuthAndCaptureTest2(){
        TransactionDetails transactionDetails = new TransactionDetails();
        when(dao.fetchMitReceivedTranIdByToken(any(TransactionRequest.class))).thenReturn(Mono.just(transactionDetails));
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        request.setToken(buildValidToken());
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);
        when(responseSpec.bodyToMono(PreauthResponse.class)).thenReturn(Mono.just(new PreauthResponse()));
        when(caller.callChaseService(any(ChaseRequest.class), eq(Constants.SUBCRIPTION_STORE_ID), any(), any())).thenReturn(responseSpec);
        Mono<TransactionResponse> resp = authTransactionsService.preAuthAndCapture(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test
    public void preAuthAndCaptureTest3(){
        TransactionDetails transactionDetails = new TransactionDetails();
        when(dao.fetchMitReceivedTranIdByToken(any(TransactionRequest.class))).thenReturn(Mono.just(transactionDetails));
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setToken(buildValidToken());
        request.setTransactionId(null);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(responseSpec.bodyToMono(PreauthResponse.class)).thenReturn(Mono.just(new PreauthResponse()));
        when(caller.callChaseService(any(ChaseRequest.class), any(), any(), any())).thenReturn(responseSpec);
        Mono<TransactionResponse> resp = authTransactionsService.preAuthAndCapture(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test
    public void preAuthAndCaptureTest4(){
        TransactionDetails transactionDetails = new TransactionDetails();
        when(dao.fetchMitReceivedTranIdByToken(any(TransactionRequest.class))).thenReturn(Mono.just(transactionDetails));
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setToken(buildValidToken());
        request.setMitReceivedTransactionId("id");
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(responseSpec.bodyToMono(PreauthResponse.class)).thenReturn(Mono.just(new PreauthResponse()));
        when(caller.callChaseService(any(ChaseRequest.class), any(), any(), any())).thenReturn(responseSpec);
        Mono<TransactionResponse> resp = authTransactionsService.preAuthAndCapture(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test
    public void preAuthAndCaptureTest5(){
        TransactionDetails transactionDetails = new TransactionDetails();
        when(dao.fetchMitReceivedTranIdByToken(any(TransactionRequest.class))).thenReturn(Mono.just(transactionDetails));
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setCardBrandOriginalTransactionId("oid");
        request.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(responseSpec.bodyToMono(PreauthResponse.class)).thenReturn(Mono.just(new PreauthResponse()));
        when(caller.callChaseService(any(ChaseRequest.class), any(), any(), any())).thenReturn(responseSpec);
        Mono<TransactionResponse> resp = authTransactionsService.preAuthAndCapture(request);
        resp.subscribe(res -> Assert.assertNotNull(res));

    }

    @Test
    public void incrementalAuthTest(){
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setCardBrandOriginalTransactionId("oid");
        request.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        Mono<TransactionResponse>  resp =authTransactionsService.incrementalAuth(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test(expected = NullPointerException.class)
    public void incrementalAuth_MITTest(){
        TransactionRequest request = requestData.buildValidRequest(TransactionType.AUTHORIZE.toString());
        request.setCardBrandOriginalTransactionId("oid");
        request.setMitReceivedTransactionId("mit");
        request.setStoreId(Constants.SUBCRIPTION_STORE_ID);
        when(caller.callChaseService(any(PreAuthRequest.class), anyString(), anyString(), anyString())).thenReturn(responseMock);
        Mono<TransactionResponse>  resp =authTransactionsService.incrementalAuth(request);
        resp.subscribe(res -> Assert.assertNotNull(res));
    }

    @Test
    public void getTransactionIdFromTokenVaultTest() {
        // Todo: Replace dummy with something meaningful
        String guid = "dummy";

        Mono<String> results = Mono.<String>just("Test Results");

        when(authTransactionsService.getTransactionIdFromTokenVault(guid)).thenReturn(results);

        Mono<String> originalTransactionId = authTransactionsService.getTransactionIdFromTokenVault(guid);
        assertEquals(originalTransactionId.block(), "Test Results");
    }

    private Token buildValidToken() {
        return Token.builder().tokenType("FDToken")
                .tokenData(buildValidTokenData()).build();
    }

    private TokenData buildValidTokenData() {
        return TokenData.builder()
                .type("MC")
                .cardholderName("TEST name")
                .cvv("189")
                .expiryDate("1225")
                .value("4112344112344113")
                .build();
    }

    private PreauthResponse getPreAuthResponse(String preauthStatus, String respCode) {
        PreauthResponse preauthResponse = new PreauthResponse();
        AvsBilling avsBilling = new AvsBilling();
        avsBilling.setAvsZip("94797");
        avsBilling.setAvsRespCode("B");
        avsBilling.setHostAVSRespCode("I3");
        preauthResponse.setAvsBilling(avsBilling);

        Order order = new Order();
        order.setAmount("100");

        Status status = new Status();
        status.setProcStatusMessage(preauthStatus);
        status.setHostRespCode("100");
        status.setRespCode("00");
        status.setApprovalStatus("1");
        status.setAuthorizationCode("tst666");
        status.setPymtBrandAuthResponseCode(respCode);
        status.setPymtBrandAuthResponseCode("A");
        order.setStatus(status);
        preauthResponse.setOrder(order);

        CardholderVerification cardholderVerification = new CardholderVerification();
        cardholderVerification.setCvvRespCode("M");
        cardholderVerification.setHostCVVRespCode("M");
        preauthResponse.setCardholderVerification(cardholderVerification);

        return preauthResponse;
    }


}