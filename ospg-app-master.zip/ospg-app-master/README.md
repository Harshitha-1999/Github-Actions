# OSPG-Payments..

### Running SQL Server Database in Docker 
1. Make sure you installed the [Docker](https://docs.docker.com/get-docker/)
   
2. Run the command below on the `docker-compose.yml` root path

    ```docker-compose up -d```

     - If the port 1433 has already been used, you can change the ports in `docker-compose.yml` file.

3. Then you can connect `localhost:1433` with your local database
    - Username: SA
    - Password: Pass@word
    
4. Access to your local database
   There are two ways to connect: 1. Docker CLI 2. SSMS
    1. Docker CLI
        - Click the CLI button on the docker
        - Type ```/opt/mssql-tools/bin/sqlcmd -S localhost -U SA -P Pass@word``` command
        - Then you can access your database
    
    2. SSMS
        - Make sure you download the [SSMS](https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver15#download-ssms)
        - Server Type: Database Engine
        - Server name: `<your IP Address>,<port>`, eg: `11.11.111.11,1433`
        - Authentication: SQL Server Authentication
        - Login: `SA`
        - Password: `Pass@word`
    
5. The database you need is inside the `Databases.OSPGSS.Tables`, and the data will persist when you shut down your docker
