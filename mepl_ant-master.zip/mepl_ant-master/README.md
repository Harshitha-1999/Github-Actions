# MEPL INSTALLATION 

## Prerequisites
 1. Download the application.properties from the email to the C:\Users\LDAPID\Downloads\env folder.
 2. Copy your application.properties file to the corresponding place presentation\src\main\resources, and in the root directory.
 3. Download JDK 11 and set the environment variable and the path variable. 
 4. Download Apache maven and set the environment variable.
 5. Download and place the settings.xml in the .m2 folder.
 6. Download PropsUtil.java from the below location and and replace in the ``` %homedir%\%workingdir%\%appcode%_ant\presentation\src\main\java\com\safeway\util\PropsUtil.java ```
  [PropsUtil](https://confluence.safeway.com/download/attachments/177562050/PropsUtil.java?api=v2)
 8. Populate the values present in  ``` %homedir%\%workingdir%\%appcode%_ant\presentation\src\main\resources\application.properties ``` present with the values present in the helmcharts location below and contact devops for the client secret.
 [Helmchart](https://github.albertsons.com/albertsons/platform-devops-helmcharts/blob/master/application/mepl-ant/env/dev/mepl-ant/configmap.yaml)

### Installation
* ``` cd presentation\src\main\resources ```
* ``` copy %homedir%\Downloads\envs\application_%appcode%.properties application.properties  ```
* ``` copy %homedir%\Downloads\envs\PropsUtil.java %homedir%\%workingdir%\%appcode%_ant\presentation\src\main\java\com\safeway\util\PropsUtil.java ```
* ``` mvn clean install ```

#### Deploy the App on Tomcat
* ``` cd presentation\target ```
* ``` copy mepl.war %homedir%\apache-tomcat\webapps\mepl.war ```
* ``` cd %homedir%\apache-tomcat\bin ```
 * ``` startup ```
