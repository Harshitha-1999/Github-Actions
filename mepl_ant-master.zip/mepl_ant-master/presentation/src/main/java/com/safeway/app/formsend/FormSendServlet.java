package com.safeway.app.formsend;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.albertsons.sso.model.SSOModel;
import com.albertsons.sso.utils.HttpUtils;
import com.oreilly.servlet.MultipartRequest;
import com.safeway.util.PropsUtil;
import com.safeway.util.ResourceManager;
import com.safeway.util.exception.AppException;
import org.owasp.encoder.Encode;

public class FormSendServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	protected static Log log;
	protected static ResourceManager rMgr;
	private static ArrayList<String> supportedNames;
	private MessageBean mb;
	private MessageCenter mc;
	String adminToken;
	String userid;
	String password;

	static {
		FormSendServlet.log = LogFactory.getLog((Class)FormSendServlet.class);
		FormSendServlet.rMgr = ResourceManager.getInstance((Object)FormSendServlet.class);
	}

	public FormSendServlet() {
		this.adminToken = null;
		this.userid = null;
		this.password = null;
	}

	public void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	public static void doPrePost(final HttpServletRequest request) throws Exception {
		MessageBean mb1 = null;
		MessageCenter mc1 = null;
		try {
			FormSendServlet.log.debug((Object)"-----> Inside doPrePost");
			if (FormSendServlet.supportedNames == null) {
				FormSendServlet.supportedNames = new ArrayList<String>();
				FormSendServlet.log.debug((Object)"<-----supportedNames is null");
				final StringTokenizer st = new StringTokenizer(FormSendServlet.rMgr.get("supportedparameternames"), ",", false);
				FormSendServlet.log.debug((Object)"<-----StringTokenizer created");
				while (st.hasMoreTokens()) {
					final String supName = st.nextToken();
					FormSendServlet.log.debug((Object)("<----supName" + Encode.forJava(supName)));
					FormSendServlet.supportedNames.add(supName);
				}
			}
			MultipartRequest Mrequest = null;
			boolean multipart = false;
			boolean preview = false;
			if (request.getHeader("content-type") != null && request.getHeader("content-type").startsWith("multipart/form-data")) {
				FormSendServlet.log.debug((Object)"<-----Before checking tmp folder");
				Mrequest = new MultipartRequest(request, "/tmp");
				multipart = true;
				if (Mrequest.getParameter("previewPage") != null && Mrequest.getParameter("previewPage").equalsIgnoreCase("true")) {
					preview = true;
					FormSendServlet.log.debug((Object)("<-----Preview  " + preview));
				}
			}
			if (request.getParameter("previewPage") != null && request.getParameter("previewPage").equalsIgnoreCase("true")) {
				preview = true;
			}
			FormSendServlet.log.info((Object)("<-----Preview  " + preview));
			if (request.getParameter("SendForm") == null) {
				mb1 = new MessageBean();
				mc1 = new MessageCenter();
				setMessageBean(mb1, Mrequest, request, multipart);
				FormSendServlet.log.debug((Object)"Set confirmationBean in doPrePost");
				mc1.confirmMessage(mb1);
			}
			request.getSession().setAttribute("kga_mb", (Object)mb1);
			request.getSession().setAttribute("kga_mc", (Object)mc1);
			request.getSession().setAttribute("kga_preview", (Object)new Boolean(preview));
			request.getSession().setAttribute("kga_SendForm", (Object)request.getParameter("SendForm"));
			request.getSession().setAttribute("kga_loginWasMet", (Object)"true");
		}
		catch (Throwable e) {
			FormSendServlet.log.fatal((Object)e.getMessage(), e);
			throw new Exception(e);
		}
	}

	public void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		FormSendServlet.log.debug((Object)("Getting Test value from request: " + (String)request.getAttribute("testattribute")));
		FormSendServlet.log.debug((Object)("Getting Test value from session: " + request.getSession().getAttribute("testsession")));
		if (request.getSession().getAttribute("kga_referer") == null) {
			request.getSession().setAttribute("kga_referer", (Object)request.getHeader("Referer"));
		}
		boolean isLoginWasMet = false;
		if (request.getSession().getAttribute("kga_loginWasMet") != null && ((String)request.getSession().getAttribute("kga_loginWasMet")).equals("true")) {
			isLoginWasMet = true;
		}
		if (request.getSession().getAttribute("osso_token") != null) {
			this.adminToken = (String)request.getSession().getAttribute("osso_token");
		}
		SSOModel ssoModel = new HttpUtils().getSSOModel(request,PropsUtil.getKeysUrl());

		if(ssoModel != null){
			this.userid = ssoModel.getUserId();
			isLoginWasMet = true;
			FormSendServlet.log.info((Object)("Check if header is not null: " + this.userid));
		}
		FormSendServlet.log.info((Object)("Userid in: " + this.userid));

		FormSendServlet.log.info((Object)("Id added: "+this.userid));
		if (isLoginWasMet && this.userid == null) {
			this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.loginpage")).forward((ServletRequest)request, (ServletResponse)response);
			return;
		}
		FormSendServlet.log.debug((Object)("-->doPost : isLoginWasMet " + isLoginWasMet));
		try {
			MultipartRequest Mrequest = null;
			boolean multipart = false;
			boolean preview = true;
			FormSendServlet.log.debug((Object)("---- > IsLoginWasMet-- " + isLoginWasMet));
			if (!isLoginWasMet) {
				if (request.getHeader("content-type") != null && request.getHeader("content-type").startsWith("multipart/form-data")) {
					Mrequest = new MultipartRequest(request, "/tmp");
					multipart = true;
					if (Mrequest.getParameter("previewPage") != null && Mrequest.getParameter("previewPage").equalsIgnoreCase("true")) {
						preview = true;
					}
				}
				if (request.getParameter("previewPage") != null && request.getParameter("previewPage").equalsIgnoreCase("true")) {
					preview = true;
				}
				FormSendServlet.log.debug((Object)("-----> multipart--  " + multipart));
				FormSendServlet.log.debug((Object)("-----> preview--  " + preview));
				if (request.getParameter("SendForm") == null) {
					FormSendServlet.log.debug((Object)"request.getParameter(SendForm) is null");
					this.mb = new MessageBean();
					this.mc = new MessageCenter();
					setMessageBean(this.mb, Mrequest, request, multipart);
					this.mc.confirmMessage(this.mb);
					request.setAttribute("Confirmation", (Object)this.mc.getConfirmationBean());
					if (preview) {
						this.getServletConfig().getServletContext().getRequestDispatcher("preview.jsp").forward((ServletRequest)request, (ServletResponse)response);
					}
					else {
						this.mc.deliverMessage(this.mb);
						request.getSession().setAttribute("osso_token", (Object)null);
						this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.sent.page")).forward((ServletRequest)request, (ServletResponse)response);
					}
				}
				else {
					if (request.getSession() == null) {
						FormSendServlet.log.info((Object)("The Session before is" + request.getSession()));
						String endUrl = null;
						final StringBuffer sb = new StringBuffer();
						sb.append(request.getScheme());
						sb.append("://");
						sb.append(request.getServerName());
						sb.append(":");
						sb.append(request.getServerPort());
						sb.append(request.getContextPath());
						endUrl = sb.toString();
						response.sendRedirect(endUrl);
					}
					FormSendServlet.log.info((Object)("The Session after is" + request.getSession()));
					this.mc.deliverMessage(this.mb);
					request.getSession().setAttribute("osso_token", (Object)null);
					request.setAttribute("Confirmation", (Object)this.mc.getConfirmationBean());
					this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.sentpage")).forward((ServletRequest)request, (ServletResponse)response);
				}
			}
			else {
				this.mb = (MessageBean)request.getSession().getAttribute("kga_mb");
				this.mc = (MessageCenter)request.getSession().getAttribute("kga_mc");
				preview = (Boolean)request.getSession().getAttribute("kga_preview");
				FormSendServlet.log.debug((Object)("Second call Preview value: " + preview));
				FormSendServlet.log.info((Object)("Second call Preview value: " + preview));
				final String kga_SendForm = (String)request.getSession().getAttribute("kga_SendForm");

				if(ssoModel != null){
					this.mb.setUserID(ssoModel.getUserId());
					FormSendServlet.log.info((Object)("User id in else part is: " + this.userid));
				}
				request.getSession().removeAttribute("kga_mb");
				request.getSession().removeAttribute("kga_mc");
				request.getSession().removeAttribute("kga_preview");
				request.getSession().removeAttribute("kga_SendForm");
				request.getSession().removeAttribute("kga_loginWasMet");
				if (kga_SendForm == null) {
					FormSendServlet.log.debug((Object)"Second call SendForm is null");
					FormSendServlet.log.debug((Object)("confirmation Bean " + this.mc.getConfirmationBean()));
					request.setAttribute("Confirmation", (Object)this.mc.getConfirmationBean());
					if (preview) {
						this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.previewpage")).forward((ServletRequest)request, (ServletResponse)response);
					}
					else {
						this.mc.deliverMessage(this.mb);
						request.getSession().setAttribute("osso_token", (Object)null);
						this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.sentpage")).forward((ServletRequest)request, (ServletResponse)response);
					}
				}
				else {
					this.mc.deliverMessage(this.mb);
					request.getSession().setAttribute("osso_token", (Object)null);
					request.setAttribute("Confirmation", (Object)this.mc.getConfirmationBean());
					this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.sentpage")).forward((ServletRequest)request, (ServletResponse)response);
				}
			}
		}
		catch (Throwable e) {
			if (!e.getClass().getName().equals("com.safeway.util.exception.AppException")) {
				FormSendServlet.log.fatal((Object)e.getMessage(), e);
			}
			request.getSession().setAttribute("osso_token", (Object)null);
			request.setAttribute("javax.servlet.jsp.jspException", (Object)e);
			this.getServletConfig().getServletContext().getRequestDispatcher(FormSendServlet.rMgr.get("jsp.errorpage")).forward((ServletRequest)request, (ServletResponse)response);
		}
	}

	public void init() {
		FormSendServlet.log = LogFactory.getLog((Class)FormSendServlet.class);
		if (FormSendServlet.supportedNames == null) {
			FormSendServlet.supportedNames = new ArrayList<String>();
			final StringTokenizer st = new StringTokenizer(FormSendServlet.rMgr.get("supportedparameternames"), ",", false);
			while (st.hasMoreTokens()) {
				final String supName = st.nextToken();
				FormSendServlet.supportedNames.add(supName);
			}
		}
	}

	public static void setMessageBean(final MessageBean mb, final MultipartRequest Mrequest, final HttpServletRequest request, final boolean multipart) throws AppException {
		try {
			FormSendServlet.log.debug((Object)"Start setMessageBean");
			FormSendServlet.log.debug((Object)"<----before retrieving filedorder");
			FormSendServlet.log.debug((Object)("Query String --->" + Encode.forJava(request.getQueryString())));
			final String fieldOrder = URLDecoder.decode(request.getQueryString());
			FormSendServlet.log.debug((Object)("<----After retrieving filedorder" + Encode.forJava(fieldOrder)));
			final ArrayList<String> nameOrder = new ArrayList<String>();
			String delimSendOrder = "";
			if (FormSendServlet.rMgr.get("jsp.testmode").equalsIgnoreCase("true")) {
				mb.setFrom(String.valueOf(FormSendServlet.rMgr.get("test.from.userid")) + "@safeway.com");
			}
			else {
				SSOModel ssoModel = new HttpUtils().getSSOModel(request,PropsUtil.getKeysUrl());

				mb.setFrom(ssoModel.getEmailAddress());
			}
			FormSendServlet.log.debug((Object)("IP Address of request: " + request.getRemoteAddr()));
			FormSendServlet.log.info((Object)("IP Address of request :+" + request.getRemoteAddr()));
			final StringTokenizer st = new StringTokenizer(fieldOrder, "&", false);
			FormSendServlet.log.debug((Object)"---Request Parameters----");
			while (st.hasMoreTokens()) {
				String delimName;
				final String paramName = delimName = st.nextToken();
				nameOrder.add(paramName);
				if (!FormSendServlet.supportedNames.contains(paramName)) {
					if (delimName.startsWith("req_")) {
						delimName = delimName.substring(4);
					}
					FormSendServlet.log.debug((Object)(Encode.forJava(delimName)));
					delimSendOrder = String.valueOf(delimSendOrder) + delimName + ",";
				}
			}
			FormSendServlet.log.debug((Object)"---Request Parameters----");
			mb.setData((Map)splitRequest(Mrequest, request, nameOrder, multipart));
			mb.setDelimSendOrder(delimSendOrder);
			FormSendServlet.log.debug((Object)"End setMessageBean");
		}
		catch (Exception e) {
			FormSendServlet.log.fatal((Object)FormSendServlet.rMgr.get("e.exception.error"), (Throwable)e);
			final AppException ae = new AppException(FormSendServlet.rMgr.get("e.exception.error"), (Throwable)e);
			throw ae;
		}
	}

	public static Map<String, HashMap<String, Object>> splitRequest(final MultipartRequest Mrequest, final HttpServletRequest request, final ArrayList<String> nameOrder, final boolean multipart) {
		FormSendServlet.log.debug((Object)"-----> inside splitRequest method");
		final HashMap<String, Object> supFields = new HashMap<String, Object>(20);
		final HashMap<String, Object> dataFields = new HashMap<String, Object>();
		final HashMap<String, HashMap<String, Object>> allFields = new HashMap<String, HashMap<String, Object>>();
		FormSendServlet.log.debug((Object)"-----All Request Parameters----");
		for (int i = 0; i < nameOrder.size(); ++i) {
			String paramName = nameOrder.get(i);
			String[] paramValues;
			String paramValue;
			if (multipart) {
				paramValues = Mrequest.getParameterValues(paramName);
				paramValue = Mrequest.getParameter(paramName);
			}
			else {
				paramValues = request.getParameterValues(paramName);
				paramValue = request.getParameter(paramName);
			}
			if (paramName.startsWith("req_")) {
				paramName = paramName.substring(4);
			}
			if (FormSendServlet.supportedNames.contains(paramName)) {
				supFields.put(paramName, paramValue);
				FormSendServlet.log.debug((Object)(Encode.forJava(String.valueOf(paramName) + " : " + paramValue)));
			}
			else {
				dataFields.put(paramName, paramValues);
				final StringBuffer buf = new StringBuffer();
				if (paramValues != null) {
					for (int j = 0; j < paramValues.length; ++j) {
						if (paramValues[j] != null) {
							buf.append(paramValues[j]);
						}
					}
				}
				FormSendServlet.log.debug((Object)(Encode.forJava(String.valueOf(paramName) + " : " + buf.toString())));
			}
		}
		if (supFields.get("returnUrl") == null) {
			FormSendServlet.log.debug((Object)"supFields.get(returnUrl) is null");
			supFields.put("returnUrl", request.getHeader("referer"));
		}
		if (request.getHeader("referer") == null) {
			FormSendServlet.log.debug((Object)"request.getHeader(referer) is null");
			supFields.put("returnUrlVerbiage", "");
		}
		allFields.put("supFields", supFields);
		allFields.put("dataFields", dataFields);
		return allFields;
	}
}