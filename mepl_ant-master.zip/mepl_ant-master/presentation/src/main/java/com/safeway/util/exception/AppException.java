package com.safeway.util.exception;

import java.util.Vector;
import java.util.Iterator;
import org.apache.commons.logging.LogFactory;
import javax.servlet.ServletException;
import java.rmi.RemoteException;
import org.xml.sax.SAXException;
import java.sql.SQLException;
import com.safeway.util.ResourceManager;
import com.safeway.util.Util;

public class AppException extends Exception
{
    private static final long serialVersionUID = 1L;
    public static final int CRITICAL = 0;
    public static final int WARNING = 1;
    public static final int INFO = 2;
    protected static final int UNKNOWN_ERROR = 0;
    protected Throwable nestedException;
    protected int exceptionCode;
    protected int severityCode;
    public static final String LINE_BREAK = "\n\t";
    
    public AppException() {
        this.nestedException = null;
        this.exceptionCode = 0;
        this.severityCode = 0;
    }
    
    public AppException(final int code) {
        this.nestedException = null;
        this.exceptionCode = 0;
        this.severityCode = 0;
        this.setExceptionCode(code);
    }
    
    public AppException(final int code, final String message) {
        super(message);
        this.nestedException = null;
        this.exceptionCode = 0;
        this.severityCode = 0;
        this.setExceptionCode(code);
    }
    
    public AppException(final int code, final String message, final Throwable e) {
        super(message);
        this.nestedException = null;
        this.exceptionCode = 0;
        this.severityCode = 0;
        this.setExceptionCode(code);
        this.setNestedException(e);
    }
    
    public AppException(final String message) {
        super(message);
        this.nestedException = null;
        this.exceptionCode = 0;
        this.severityCode = 0;
    }
    
    public AppException(final Throwable e) {
        this();
        this.setNestedException(e);
    }
    
    public AppException(final int code, final Throwable e) {
        this(code);
        this.setNestedException(e);
    }
    
    public AppException(final String message, final Throwable e) {
        super(message);
        this.nestedException = null;
        this.exceptionCode = 0;
        this.severityCode = 0;
        this.setNestedException(e);
    }
    
    @Override
    public boolean equals(final Object arg) {
        boolean result = false;
        if (arg != null && arg instanceof AppException) {
            final AppException that = (AppException)arg;
            result = (Util.equals((Object)this.getMessage(), (Object)that.getMessage()) && this.getExceptionCode() == that.getExceptionCode() && this.getSeverity() == that.getSeverity() && Util.equals((Object)new StringBuilder().append(this.getNestedException()).toString(), (Object)new StringBuilder().append(that.getNestedException()).toString()));
        }
        return result;
    }
    
    @Override
    public int hashCode() {
        int result = this.getMessage().hashCode();
        result += this.getExceptionCode();
        result += this.getSeverity();
        if (this.getNestedException() != null) {
            result += this.getNestedException().hashCode();
        }
        return result;
    }
    
    public int getExceptionCode() {
        return this.exceptionCode;
    }
    
    public void setExceptionCode(final int code) {
        this.exceptionCode = code;
    }
    
    public String getDescription() {
        final ResourceManager rMgr = new ResourceManager((Object)this);
        String result = rMgr.get(new StringBuilder(String.valueOf(this.getExceptionCode())).toString());
        if (result == null) {
            final ResourceManager myMgr = new ResourceManager((Object)AppException.class);
            if (rMgr.getClientClass() != AppException.class.getName()) {
                result = myMgr.get(new StringBuilder(String.valueOf(this.getExceptionCode())).toString());
            }
            if (result == null) {
                result = myMgr.get("unknown.exception");
            }
        }
        return result;
    }
    
    public String getLineBreak() {
        return "\n\t";
    }
    
    @Override
    public String getMessage() {
        return (super.getMessage() != null) ? super.getMessage() : "";
    }
    
    public void setSeverity(final int severity) {
        this.severityCode = severity;
    }
    
    public int getSeverity() {
        return this.severityCode;
    }
    
    public String getSeverityString() {
        return (this.severityCode == 1) ? "WARNING" : ((this.severityCode == 2) ? "INFO" : "CRITICAL");
    }
    
    public void setNestedException(final Throwable ex) {
        this.nestedException = ex;
    }
    
    public Throwable getNestedException() {
        return this.nestedException;
    }
    
    public static Throwable getNextException(final Throwable exception) {
        Throwable result = null;
        try {
            if (exception instanceof AppException) {
                result = ((AppException)exception).getNestedException();
            }
            else if (exception instanceof SQLException) {
                result = ((SQLException)exception).getNextException();
            }
            else if (exception instanceof SAXException) {
                result = ((SAXException)exception).getException();
            }
            else if (exception instanceof RemoteException) {
                result = ((RemoteException)exception).detail;
            }
            else if (exception instanceof ServletException) {
                result = ((ServletException)exception).getRootCause();
            }
        }
        catch (NoClassDefFoundError ncdfe) {
            LogFactory.getLog((Class)AppException.class).error((Object)("getNextException caught a NoClassDefFoundError: " + ncdfe.getMessage()));
        }
        return result;
    }
    
    public Iterator getExceptionList() {
        Throwable exception = getNextException(this);
        if (exception == null) {
            return null;
        }
        final Vector result = new Vector();
        while (exception != null) {
            result.add(exception);
            exception = getNextException(exception);
        }
        return result.iterator();
    }
    
    @Override
    public String toString() {
        final StringBuffer message = new StringBuffer(String.valueOf(this.getClass().getName()) + " [" + this.getExceptionCode() + "] " + this.getSeverityString() + ": " + this.getMessage() + this.getLineBreak() + this.getDescription());
        final Iterator list = this.getExceptionList();
        while (list != null && list.hasNext()) {}
        return message.toString();
    }
}