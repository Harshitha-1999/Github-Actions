package com.safeway.app.formsend;

public class EmailBean
{
	private String sendTo;
	private String sendCc;
	private String sendBcc;
	private String from;
	private String sendSubject;
	private String body;
	private String delimSendTo;
	private String delimBody;

	public String getBody() {
		return this.body;
	}

	public String getDelimBody() {
		return this.delimBody;
	}

	public String getDelimSendTo() {
		return this.delimSendTo;
	}

	public String getFrom() {
		return this.from;
	}

	public String getSendBcc() {
		return this.sendBcc;
	}

	public String getSendCc() {
		return this.sendCc;
	}

	public String getSendSubject() {
		return this.sendSubject;
	}

	public String getSendTo() {
		return this.sendTo;
	}

	public void setBody(final String body) {
		this.body = body;
	}

	public void setDelimBody(final String delimBody) {
		this.delimBody = delimBody;
	}

	public void setDelimSendTo(final String delimSendTo) {
		this.delimSendTo = delimSendTo;
	}

	public void setFrom(final String from) {
		this.from = from;
	}

	public void setSendBcc(final String sendBcc) {
		this.sendBcc = sendBcc;
	}

	public void setSendCc(final String sendCc) {
		this.sendCc = sendCc;
	}

	public void setSendSubject(final String sendSubject) {
		this.sendSubject = sendSubject;
	}

	public void setSendTo(final String sendTo) {
		this.sendTo = sendTo;
	}
}