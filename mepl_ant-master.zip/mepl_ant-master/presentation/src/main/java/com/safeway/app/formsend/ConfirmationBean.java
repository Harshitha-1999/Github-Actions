package com.safeway.app.formsend;

import java.util.Collection;
import java.util.Map;
import org.apache.commons.logging.LogFactory;
import java.util.ArrayList;
import java.util.HashMap;
import com.safeway.util.TypecastResourceManager;
import org.apache.commons.logging.Log;

public class ConfirmationBean
{
    private String returnUrlVerbiage;
    private String returnUrl;
    protected Log log;
    protected TypecastResourceManager rMgr;
    private HashMap dataFields;
    private ArrayList delimSendOrder;
    
    public ConfirmationBean() {
        this.rMgr = new TypecastResourceManager((Object)this);
        this.log = LogFactory.getLog((Class)ConfirmationBean.class);
        this.dataFields = new HashMap();
        this.delimSendOrder = new ArrayList();
    }
    
    public String getConfirmMessage() {
        return this.rMgr.get("default.confirm.message");
    }
    
    public Map getDataFields() {
        return this.dataFields;
    }
    
    public Collection getDelimSendOrder() {
        return this.delimSendOrder;
    }
    
    public String getReturnUrl() {
        return this.returnUrl;
    }
    
    public String getReturnUrlVerbiage() {
        return this.returnUrlVerbiage;
    }
    
    public void setDataFields(final Map dataFields) {
        this.dataFields = (HashMap)dataFields;
    }
    
    public void setDelimSendOrder(final Collection delimSendOrder) {
        this.delimSendOrder = (ArrayList)delimSendOrder;
    }
    
    public void setReturnUrl(final String returnUrl) {
        this.returnUrl = returnUrl;
    }
    
    public void setReturnUrlVerbiage(final String returnUrlVerbiage) {
        if (returnUrlVerbiage != null) {
            this.returnUrlVerbiage = returnUrlVerbiage;
        }
        else {
            this.returnUrlVerbiage = this.rMgr.get("default.returnUrlVerbiage");
        }
    }
}