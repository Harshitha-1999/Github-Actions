package com.safeway.app.filter;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.albertsons.sso.model.SSOModel;
import com.albertsons.sso.service.ADAuthenticationService;
import com.albertsons.sso.service.ADAuthenticationServiceImpl;
import com.safeway.util.PropsUtil;
import org.owasp.encoder.Encode;


public class AuthenticationFilter implements Filter {

	private static final Log logger = LogFactory.getLog(AuthenticationFilter.class);

	private ADAuthenticationService adAuthService = null;

	@Override
	public void doFilter(
			ServletRequest request,
			ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;

		logger.debug("uri...: " + Encode.forUriComponent(httpServletRequest.getRequestURI()));

		adAuthService = getADAuthService();
		if (!isTokenValid(httpServletRequest)){
			String redirectUrl = PropsUtil.getRedirectUrl();
			if(httpServletRequest.getParameter("code") == null) {
				httpServletResponse.sendRedirect(redirectUrl);
				logger.info("REDIRECTING........ to login page");
			}
			else {
				setAccessToken(httpServletRequest.getParameter("code"),httpServletResponse);
				logger.info("token generated redirecting to redirectUrl........"+PropsUtil.getHomepageUrl()+"main.html");
				httpServletResponse.sendRedirect(PropsUtil.getHomepageUrl()+"main.html");
			}
		}
		else {
			logger.info("TOKEN is VALID");
			chain.doFilter(request, httpServletResponse);
		}
		logger.info("EXITING......................");
	}

	private ADAuthenticationService getADAuthService() {
		return new ADAuthenticationServiceImpl(PropsUtil.getAuthority(),PropsUtil.getClientId(),PropsUtil.getSecret(),PropsUtil.getKeysUrl());	 
	}

	private boolean isTokenValid(HttpServletRequest request) {
		logger.info("...checking isTokenValid");
		if(request.getCookies() !=null) {
			logger.info(".fetching token from cookie..length."+request.getCookies().length);
			for (Cookie cookiee:request.getCookies()){
				if(cookiee.getName().equals("idToken")) {
					logger.info("isTokenValid fetched from cookie:." + Encode.forJava(cookiee.getName()));
					return adAuthService.isTokenValid(cookiee.getValue());					
				}
			}
		}
		return false;
	}

	private void setAccessToken(String authorizationCode,HttpServletResponse httpServletResponse) {		
		SSOModel ssoModel = adAuthService.fetchSsoModel(authorizationCode, PropsUtil.getHomepageUrl());
		if(ssoModel !=null) {
			Cookie cookie1 = new Cookie("accessToken",ssoModel.getAccessToken());
			Cookie cookie2 = new Cookie("idToken",ssoModel.getIdToken());
			cookie1.setSecure(true);
			cookie2.setSecure(true);
			httpServletResponse.addCookie(cookie1);
			httpServletResponse.addCookie(cookie2);
		}
	}

	@Override
	public void destroy() {
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		PropsUtil.loadData();
	}

}