package com.safeway.app.formsend;

public class FileBean
{
	private String fileName;
	private String fileBody;

	public String getFileBody() {
		return this.fileBody;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileBody(final String fileBody) {
		this.fileBody = fileBody;
	}

	public void setFileName(final String fileName) {
		this.fileName = fileName;
	}
}