package com.safeway.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.core.io.ClassPathResource;

public class PropsUtil {

	final static Logger logger = Logger.getLogger(PropsUtil.class);

	private static String redirectUrl = null;

	private static String homepageUrl = null;

	private static String clientId = null;

	private static String secret = null;

	private static String authority = null;

	private static String keysUrl = null;

	public static void loadData() {
		try {
			InputStream inputStream = new ClassPathResource("application.properties").getInputStream();
			Properties appProps = new Properties();
			appProps.load(inputStream);
			inputStream.close();
//			clientId = appProps.getProperty("microsoft.auth.client_id");
//			secret = appProps.getProperty("microsoft.auth.secret");
//			authority = appProps.getProperty("microsoft.authority");
//			keysUrl = appProps.getProperty("microsoft.discovery.keys");
//			homepageUrl = appProps.getProperty("auth.redirectUrl");
//			redirectUrl = getRedirectUrl(appProps);

			clientId = System.getenv("MICROSOFT_AUTH_CLIENT_ID");
			secret = System.getenv("MICROSOFT_AUTH_SECRET");
			authority = System.getenv("MICROSOFT_AUTHORITY");
			keysUrl = System.getenv("MICROSOFT_AUTH_DISCOVERY_KEYS");
			homepageUrl = System.getenv("REDIRECT_URL");
			redirectUrl = loadRedirectUrl();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}

	private static String loadRedirectUrl() {
		StringBuilder builder = new StringBuilder();
		builder.append(System.getenv("MICROSOFT_AUTHORITY"));
		builder.append("/oauth2/v2.0/authorize");
		builder.append("?");
		builder.append("response_type=");
		builder.append("code");
		builder.append("&");
		builder.append("client_id=");
		builder.append(System.getenv("MICROSOFT_AUTH_CLIENT_ID"));
		builder.append("&");
		builder.append("scope=");
		builder.append("openid%20profile%20offline_access");
		builder.append("&");
		builder.append("redirect_uri=");
		builder.append(System.getenv("REDIRECT_URL"));
//		builder.append("https://mepl-dev.albertsons.com/mepl/");
		redirectUrl = builder.toString();
		logger.info("redirectUrl:" + redirectUrl);
		return redirectUrl;
	}

	//null/oauth2/v2.0/authorize?response_type=code&client_id=null&scope=openid%20profile%20offline_access&redirect_uri=null

//	private static String getRedirectUrl(Properties sdogProps) {
//		StringBuilder builder = new StringBuilder();
//		builder.append(sdogProps.getProperty("microsoft.auth.url"));
//		builder.append("?");
//		builder.append("response_type=");
//		builder.append(sdogProps.getProperty("microsoft.auth.response_type"));
//		builder.append("&");
//		builder.append("client_id=");
//		builder.append(sdogProps.getProperty("microsoft.auth.client_id"));
//		builder.append("&");
//		builder.append("scope=");
//		builder.append(sdogProps.getProperty("microsoft.auth.scope"));
//		builder.append("&");
//		builder.append("redirect_uri=");
//		builder.append(sdogProps.getProperty("auth.redirectUrl"));
//		redirectUrl = builder.toString();
//		logger.info("redirectUrl:"+redirectUrl);
//		return redirectUrl;
//	}

	public static String getHomepageUrl() {
		return homepageUrl;
	}

	public static String getClientId() {
		return clientId;
	}

	public static String getSecret() {
		return secret;
	}

	public static String getAuthority() {
		return authority;
	}

	public static String getKeysUrl() {
		return keysUrl;
	}

	public static String getRedirectUrl() {
		return redirectUrl;
	}



}
