package com.safeway.app.formsend;

import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.StringTokenizer;
import javax.mail.MessagingException;
import javax.mail.IllegalWriteException;
import javax.mail.SendFailedException;
import javax.mail.Transport;
import javax.mail.Message;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.Address;
import com.safeway.util.exception.AppException;
import java.util.Properties;
import javax.mail.Authenticator;
import org.apache.commons.logging.LogFactory;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import com.safeway.util.TypecastResourceManager;
import org.apache.commons.logging.Log;
import org.owasp.encoder.Encode;

public class SendMessageInterface
{
    protected Log log;
    protected TypecastResourceManager rMgr;
    private MimeMessage message;
    private Session mailSession;
    private String smtpHost;
    
    public SendMessageInterface() throws AppException {
        this.log = LogFactory.getLog((Class)SendMessageInterface.class);
        this.rMgr = new TypecastResourceManager((Object)this);
        if (this.smtpHost == null) {
            this.smtpHost = this.rMgr.get("mail.smtp.host");
        }
        else {
            this.smtpHost = this.smtpHost;
        }
        final Properties props = System.getProperties();
        props.put("mail.smtp.host", this.smtpHost);
        this.mailSession = Session.getDefaultInstance(props, (Authenticator)null);
        if (this.rMgr.get("mail.session.debug").equalsIgnoreCase("true")) {
            this.mailSession.setDebug(true);
        }
        this.message = new MimeMessage(this.mailSession);
    }
    
    public Address[] formatAddress(String recipients) throws AppException {
        try {
            recipients = recipients.replace(';', ',');
            return (Address[])InternetAddress.parse(recipients, false);
        }
        catch (AddressException e) {
            this.log.fatal((Object)this.rMgr.get("ae.exception.error"), (Throwable)e);
            final AppException ae = new AppException(this.rMgr.get("ae.exception.error"), (Throwable)e);
            throw ae;
        }
    }
    
    public void sendMail(final EmailBean eb, final boolean delimFlag) throws AppException {
        try {
            this.log.debug((Object)"Start sendMail");
            this.message.setFrom((Address)new InternetAddress(eb.getFrom()));
            String to = null;
            if (delimFlag) {
                to = eb.getDelimSendTo();
                this.message.setText(eb.getDelimBody());
            }
            else {
                to = eb.getSendTo();
                this.message.setContent((Object)eb.getBody(), "text/html");
            }
            this.message.setRecipients(Message.RecipientType.TO, this.formatAddress(to));
            if (eb.getSendCc() != null) {
                this.message.addRecipients(Message.RecipientType.CC, this.formatAddress(eb.getSendCc()));
            }
            if (eb.getSendBcc() != null) {
                this.message.addRecipients(Message.RecipientType.BCC, this.formatAddress(eb.getSendBcc()));
            }
            this.message.setSubject(eb.getSendSubject());
            Transport.send((Message)this.message);
            this.log.debug((Object)("To: " + Encode.forJava(to)));
            this.log.debug((Object)("From: " + Encode.forJava(eb.getFrom())));
            this.log.debug((Object)("Subject: " + Encode.forJava(eb.getSendSubject())));
            this.log.debug((Object)"End sendMail");
        }
        catch (SendFailedException e) {
            this.log.fatal((Object)this.rMgr.get("sfe.exception.error"), (Throwable)e);
            final AppException ae = new AppException(this.rMgr.get("sfe.exception.error"), (Throwable)e);
            throw ae;
        }
        catch (IllegalWriteException e2) {
            this.log.fatal((Object)this.rMgr.get("iw.exception.error"), (Throwable)e2);
            final AppException ae = new AppException(this.rMgr.get("ie.exception.error"), (Throwable)e2);
            throw ae;
        }
        catch (AddressException e3) {
            this.log.fatal((Object)this.rMgr.get("ae.exception.error"), (Throwable)e3);
            final AppException ae = new AppException(this.rMgr.get("ae.exception.error"), (Throwable)e3);
            throw ae;
        }
        catch (MessagingException e4) {
            this.log.fatal((Object)this.rMgr.get("me.exception.error"), (Throwable)e4);
            final AppException ae = new AppException(this.rMgr.get("me.exception.error"), (Throwable)e4);
            throw ae;
        }
    }
    
    public void writeFile(final FileBean fb) throws AppException {
        try {
            this.log.debug((Object)"Start writeFile");
            final StringTokenizer st = new StringTokenizer(this.rMgr.get("unwanted.header.names"), ",", false);
            final String[] headers = new String[st.countTokens()];
            for (int i = 0; i < headers.length; ++i) {
                headers[i] = st.nextToken();
            }
            this.message.setText(fb.getFileBody());
            final FileOutputStream fos = new FileOutputStream(fb.getFileName(), true);
            this.message.writeTo((OutputStream)fos, headers);
            this.log.debug((Object)("File updated: " + Encode.forJava(fb.getFileName())));
            this.log.debug((Object)"End writeFile");
        }
        catch (IOException e) {
            this.log.fatal((Object)this.rMgr.get("io.exception.error"), (Throwable)e);
            final AppException ae = new AppException(this.rMgr.get("io.exception.error"), (Throwable)e);
            throw ae;
        }
        catch (MessagingException e2) {
            this.log.fatal((Object)this.rMgr.get("me.exception.error"), (Throwable)e2);
            final AppException ae = new AppException(this.rMgr.get("me.exception.error"), (Throwable)e2);
            throw ae;
        }
    }
}