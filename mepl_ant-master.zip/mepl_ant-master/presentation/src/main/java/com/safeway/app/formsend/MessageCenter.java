package com.safeway.app.formsend;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.util.Set;

import com.safeway.util.exception.AppException;
import org.apache.commons.logging.LogFactory;
import com.safeway.util.TypecastResourceManager;
import org.apache.commons.logging.Log;


public class MessageCenter
{
	protected Log log;
    protected TypecastResourceManager rMgr;
    private EmailBean eb;
    private FileBean fb;
    private ConfirmationBean cb;
    
    public MessageCenter() {
        this.log = LogFactory.getLog((Class)MessageCenter.class);
        this.rMgr = new TypecastResourceManager((Object)this);
        this.cb = new ConfirmationBean();
        this.eb = new EmailBean();
        this.fb = new FileBean();
    }
    
    public void confirmMessage(final MessageBean mb) throws AppException {
        this.setConfirmationBean(mb);
    }
    
    public void deliverMessage(final MessageBean mb) throws AppException {
        this.log.debug((Object)"Start deliverMessage");
        boolean delimFlag = false;
        final SendMessageInterface smi = new SendMessageInterface();
        if (mb.getSendTo() != null) {
            this.setEmailBean(mb);
            smi.sendMail(this.eb, delimFlag);
        }
        if (mb.getDelimSendTo() != null) {
            if (mb.getDelimSendTo().startsWith("file:")) {
                this.setFileBean(mb);
                smi.writeFile(this.fb);
                this.setFilePermission(this.fb.getFileName());
            }
            else {
                this.setEmailBean(mb);
                delimFlag = true;
                smi.sendMail(this.eb, delimFlag);
            }
        }
        this.log.debug((Object)"End deliverMessage");
    }
    
    public ConfirmationBean getConfirmationBean() {
        return this.cb;
    }
    
    public void setConfirmationBean(final MessageBean mb) throws AppException {
        this.log.debug((Object)"Start setConfirmationBean");
        this.cb.setReturnUrl(mb.getReturnUrl());
        this.cb.setReturnUrlVerbiage(mb.getReturnUrlVerbiage());
        this.cb.setDataFields(mb.getDataFields());
        this.cb.setDelimSendOrder(mb.getDelimSendOrder());
        this.log.debug((Object)"End setConfirmationBean");
    }
    
    public void setEmailBean(final MessageBean mb) throws AppException {
        this.log.debug((Object)"Start setEmailBean");
        this.eb.setFrom(mb.getFrom());
        this.eb.setSendTo(mb.getSendTo());
        this.eb.setDelimSendTo(mb.getDelimSendTo());
        String cc = mb.getSendCc();
        if (cc == null || cc.trim().length() == 0) {
            cc = mb.getFrom();
        }
        else {
            cc = String.valueOf(cc) + ";" + mb.getFrom();
        }
        this.eb.setSendCc(cc);
        this.eb.setSendBcc(mb.getSendBcc());
        this.eb.setSendSubject(mb.getSendSubject());
        if (mb.getContentType() != null && mb.getContentType().equals("text")) {
            this.eb.setBody(mb.getRegText());
        }
        else {
            this.eb.setBody(mb.getHtmlText());
        }
        mb.getDelimSendTo();
        this.eb.setDelimBody(mb.getDelimText());
        this.log.debug((Object)"End setEmailBean");
    }
    
    public void setFileBean(final MessageBean mb) throws AppException {
        String fileName=String.valueOf(this.rMgr.get("file.path")) + mb.getDelimSendTo().substring(5);
        fileName=System.getProperty("user.home")+fileName;
        File file = new File(fileName);
        try {
              if(!file.exists()){
                  file.getParentFile().mkdirs();
                  file.createNewFile();
              }
        } catch (IOException e) {
        	this.log.error((Object)"Error while creating file");           
        }
        this.log.debug((Object)"Start setFileBean");
        this.fb.setFileName(System.getProperty("user.home")+String.valueOf(this.rMgr.get("file.path")) + mb.getDelimSendTo().substring(5));
        this.fb.setFileBody(String.valueOf(mb.getTimeStamp()) + mb.getUserID() + mb.getDelimText());
        this.log.debug((Object)"End setFileBean");
    }
    
    public void setFilePermission(final String fileName) throws AppException {
        this.log.debug((Object)"Start chmod command");
        try {
            if (!System.getProperty("os.name").toLowerCase().contains("windows")) {
                File file = new File(fileName);
                Set<PosixFilePermission> perms = new HashSet<>();
                //add owners permission (7)
                perms.add(PosixFilePermission.OWNER_READ);
                perms.add(PosixFilePermission.OWNER_WRITE);
                perms.add(PosixFilePermission.OWNER_EXECUTE);
                //add group permissions (7)
                perms.add(PosixFilePermission.GROUP_READ);
                perms.add(PosixFilePermission.GROUP_WRITE);
                perms.add(PosixFilePermission.GROUP_EXECUTE);
                //add others permissions (5)
                perms.add(PosixFilePermission.OTHERS_READ);
                perms.add(PosixFilePermission.OTHERS_EXECUTE);

                Files.setPosixFilePermissions(file.toPath(), perms);
            }
        }
        catch (IOException e) {
            this.log.fatal((Object)this.rMgr.get("io.exception.error"), (Throwable)e);
            final AppException ae = new AppException(this.rMgr.get("io.exception.error"), (Throwable)e);
            throw ae;
        }
    }
}