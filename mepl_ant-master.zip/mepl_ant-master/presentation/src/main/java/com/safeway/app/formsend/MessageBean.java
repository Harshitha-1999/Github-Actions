package com.safeway.app.formsend;

import java.util.StringTokenizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.safeway.util.exception.AppException;
import java.util.Collection;
import java.util.Map;
import org.apache.commons.logging.LogFactory;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.commons.logging.Log;
import com.safeway.util.TypecastResourceManager;

public class MessageBean
{
    protected TypecastResourceManager rMgr;
    protected Log log;
    private String from;
    private HashMap supFields;
    private HashMap dataFields;
    private ArrayList delimSendOrder;

    public MessageBean() {
        this.rMgr = new TypecastResourceManager((Object)this);
        this.log = LogFactory.getLog((Class)MessageBean.class);
        this.delimSendOrder = new ArrayList();
        this.dataFields = new HashMap();
    }

    public String getBodyHeader() {
        return (String)this.supFields.get("bodyHeader");
    }

    public String getContentType() {
        return (String) this.supFields.get("contentType");
    }

    public Map getDataFields() {
        return this.dataFields;
    }

    public String getDelimiter() {
        if (this.supFields.get("delimiter") != null) {
            return this.supFields.get("delimiter").toString();
        }
        return this.rMgr.get("default.delimiter.value");
    }

    public Collection getDelimSendOrder() {
        return this.delimSendOrder;
    }

    public String getDelimSendTo() {
        return (String)this.supFields.get("delimSendTo");
    }

    public String getDelimText() throws AppException {
        return this.toDelimText();
    }

    public String getFrom() {
        return this.from;
    }

    public String getHtmlText() throws AppException {
        return this.toHtmlText();
    }

    public String getRegText() throws AppException {
        return this.toRegText();
    }

    public String getReturnUrl() {
        return (String)this.supFields.get("returnUrl");
    }

    public String getReturnUrlVerbiage() {
        return (String)this.supFields.get("returnUrlVerbiage");
    }

    public String getSendBcc() {
        return (String) this.supFields.get("sendBcc");
    }

    public String getSendCc() {
        return (String)this.supFields.get("sendCc");
    }

    public String getSendSubject() {
        if (this.supFields.get("sendSubject") != null) {
            return this.supFields.get("sendSubject").toString();
        }
        return this.rMgr.get("default.mail.subject");
    }

    public String getSendTo() {
        return (String)this.supFields.get("sendTo");
    }

    public String getTimeStamp() {
        final Date date = new Date();
        final SimpleDateFormat formatter = new SimpleDateFormat(this.rMgr.get("simpleDateFormat.display"));
        final String timeStamp = formatter.format(date);
        if (this.supFields.get("timeStamp") != null && this.supFields.get("timeStamp").toString().equalsIgnoreCase("true")) {
            return String.valueOf(timeStamp) + this.getDelimiter();
        }
        return "";
    }

    public String getUserID() {
        if (this.supFields.get("userID") != null && this.supFields.get("userID").toString().equalsIgnoreCase("true")) {
            return String.valueOf(this.from.substring(0, this.from.indexOf("@"))) + this.getDelimiter();
        }
        return "";
    }

    public void setUserID(final String userID) {
        if (this.supFields == null) {
            this.supFields = new HashMap();
        }
        if (userID == null || userID.trim().length() == 0) {
            this.from = "null@safeway.com";
            this.supFields.put("userID", userID);
            return;
        }
        this.supFields.put("userID", userID);
        this.from = String.valueOf(userID) + "@safeway.com";
    }

    public String[] replaceEmptyValue(String[] paramValues) {
        if (paramValues == null || paramValues[0].equals("")) {
            final String[] noParamValues = paramValues = new String[] { this.rMgr.get("novalue.text.field") };
        }
        return paramValues;
    }

    public String replaceString(final String originalString, final String sep, final String rep) throws AppException {
        final StringBuffer retVal = new StringBuffer();
        int idx = 0;
        for (int jdx = originalString.indexOf(sep); jdx >= 0; jdx = originalString.indexOf(sep, idx)) {
            retVal.append(originalString.substring(idx, jdx));
            retVal.append(rep);
            idx = jdx + sep.length();
        }
        retVal.append(originalString.substring(idx));
        return retVal.toString();
    }

    public void setData(final Map allFields) {
        this.supFields = (HashMap) allFields.get("supFields");
        this.dataFields = (HashMap) allFields.get("dataFields");
    }

    public void setDelimSendOrder(final String fieldOrder) {
        StringTokenizer st = null;
        if (this.supFields.get("delimSendOrder") != null) {
            st = new StringTokenizer(this.supFields.get("delimSendOrder").toString(), ",", false);
        }
        else {
            st = new StringTokenizer(fieldOrder, ",", false);
        }
        while (st.hasMoreTokens()) {
            final String paramName = st.nextToken();
            this.delimSendOrder.add(paramName);
        }
    }

    public void setFrom(final String from) {
        this.from = from;
    }

    public String toDelimText() throws AppException {
        StringBuffer delimText = new StringBuffer(500);

        for(int n = 0; n < this.delimSendOrder.size(); ++n) {
            String paramName = (String)this.delimSendOrder.get(n);
            String[] paramValues = (String[])this.dataFields.get(paramName);
            if (paramValues == null) {
                paramValues = this.replaceEmptyValue(paramValues);
            }

            for(int i = 0; i < paramValues.length; ++i) {
                if (i == 0) {
                    delimText.append(paramValues[i]);
                } else {
                    delimText.append(" ").append(paramValues[i]);
                }
            }

            delimText.append(this.getDelimiter());
        }

        return this.replaceString(delimText.toString(), "\r\n", " ");
    }

    public String toHtmlText() throws AppException {
        StringBuffer htmlText = new StringBuffer(500);
        if (this.getBodyHeader() != null) {
            htmlText.append(this.getBodyHeader()).append("<br><br>");
        }

        htmlText.append(this.rMgr.get("html.begin.string"));

        for(int i = 0; i < this.delimSendOrder.size(); ++i) {
            String paramName = (String)this.delimSendOrder.get(i);
            String[] paramValues = (String[])this.dataFields.get(paramName);
            if (paramValues == null) {
                paramValues = this.replaceEmptyValue(paramValues);
            }

            htmlText.append("<tr>").append("<td>").append(paramName).append("</td>").append("<td>");

            for(int n = 0; n < paramValues.length; ++n) {
                htmlText.append(paramValues[n]).append("<br>");
            }

            htmlText.append("</td></tr>");
        }
        htmlText.append("</table>");
        return this.replaceString(htmlText.toString(), "\r\n", "<br>");
    }

    public String toRegText() throws AppException {
        StringBuffer regText = new StringBuffer(500);
        if (this.getBodyHeader() != null) {
            regText.append(this.getBodyHeader()).append("<br><br>");
        }

        for(int i = 0; i < this.delimSendOrder.size(); ++i) {
            String paramName = (String)this.delimSendOrder.get(i);
            String[] paramValues = (String[])this.dataFields.get(paramName);
            if (paramValues == null) {
                paramValues = this.replaceEmptyValue(paramValues);
            }

            regText.append("field:").append(paramName).append("<br>");

            for(int n = 0; n < paramValues.length; ++n) {
                regText.append("value:").append(paramValues[n]).append("<br>");
            }

            regText.append("<br>");
        }
        return this.replaceString(regText.toString(), "\r\n", "<br>");
    }
}