/*************************************************************************************************
Project Name			  	:SAFEWAY                 
Module Name	   		      	:ResolveCard
Relevant Spec				:ResolveCard_Spec100.rtf
Program Name				:ResolveCardValidate.js
Program Version				:1.0.0
Program Description			:Java Script for validation.
Called From				:ResolveCard.jsp	
Calling					:None       
Modification History 		        :       
--------------------------------------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		Modification Details     Change RequestReference in the code.	
--------------------------------------------------------------------------------------------------------------------------------------------------------------  
 Vamsi Kalyan Poondla	 10/07/2000			1.0.0		          NA	
--------------------------------------------------------------------------------------------------------------------------------------------------------------
*************************************************************************************************************************************************/

var cardStatusMsg="Select the contact status.";
var cardResultMsg="Select the contact results."
var callResultMsg="Select the call results."
var submittedDateMsg="Enter the date submitted.";
var cardSourceMsg="Select the contact source.";
var divisionMsg="Select the division.";
var facilityMsg="Enter the appropriate facility.";
var saveMsg="Click for saving the details.";
var cancelMsg="Click for cancelling the changes.";
var resetMsg="Click for resetting the changes.";
var resolutionWorkHistoryMsg="Enter the resolution work history.";
var remarksMsg="Enter the remarks.";

//Error messages
var cardStatusErrMsg="Please select the Contact Status.";
var cardResultErrMsg="Please select the Contact Result."
var callResultErrMsg="Please select the Call Result."
var submittedDateErrMsg="Please enter the Date Submitted.";
var submittedDateFormatErrMsg="Please enter the Date Submitted in mmddyy or mmddyyyy format.";
var divisionErrMsg="Please select the  Division.";
var facilityErrMsg="Please enter the Facility ID.";
var facilityErrMsg1="Invalid Facility ID. Please enter a valid Facility ID.";
var facilityEmptyErrMsg="Selected Division does not have any facility.";
var remarksErrMsg="Remarks should be less than 255 characters";
var commentErrMsg="Please do not enter { or }";
var resolveConfirmationMsg="Do you want to close and resolve the card"; //message if the card status is Closed - resolved or Closed - unresolved 
var statusErrMsg="To save the Comment Card state either change any of these - Contact Status, Contact Source, Contact Results, Call Results, Date Submitted, or Division or Facility \n\n\t\t\t or \n\n\t\t Enter the Resolution Work History."
var lastField;

//***************************getMessage*********************************** 
//This function is to display a help message in the status bar
//Parameters : currentField,HelpMessage
//Returns    : Void
//************************************************************************/
function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;
     lastField=lsf.name;
}


//***************************reFocus**************************************
//This function is to remove the focus from a read only field
//Parameters : currentField,previousField,NextField
//Returns    : void
//************************************************************************
function reFocus(thisField,prevField,nextField){
  if(lastField!=nextField.name)
  {
    nextField.focus();
  }
  else {
     if(lastField!=prevField.name)
        prevField.focus();   
    }
}

//***************************saveValidate************************************************************
//This function will be called to validate the form before saving the card details
//Parameters : actionValue,cardNumber
//Returns    : void
//***************************************************************************************************
function saveValidate(actionValue,cardNumber){
	
	submittedDate=document.resolveCard.submittedDate;
	submittedDateMM=document.resolveCard.submittedDateMM;
	submittedDateDD=document.resolveCard.submittedDateDD;
	submittedDateYY=document.resolveCard.submittedDateYY;
	cardStatus=document.resolveCard.cardStatus;
	tempResolutionWorkHistory=document.resolveCard.tempResolutionWorkHistory;
	
	
	
	if(!validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){ 
		allValid=false;
    		return false;
    	}
    	
    	if(document.resolveCard.submittedDate.value != ""){
    		var arrSubmittedDate=document.resolveCard.submittedDate.value.split("/");
		document.resolveCard.submittedDateMM.value=arrSubmittedDate[0];
		document.resolveCard.submittedDateDD.value=arrSubmittedDate[1];
		document.resolveCard.submittedDateYY.value=arrSubmittedDate[2];
	}
	
	//to make the year four digit
	var centuryMask="20" //a constant
	
	var tempYear=document.resolveCard.submittedDateYY.value;
	var tempMonth=document.resolveCard.submittedDateMM.value;
	var tempDay=document.resolveCard.submittedDateDD.value;
	
	if(tempYear.length==2){
		tempYear=centuryMask+tempYear;
	}
	
	var dateFromForm= tempMonth+"/"+tempDay+"/"+tempYear;
	
	//to check whether the resolve card screen has any changes after loading.   
	if((document.resolveCard.hdnCardSourceId.value==document.resolveCard.cardSource.options[document.resolveCard.cardSource.selectedIndex].value) &&
	   (document.resolveCard.hdnCardStatusId.value==document.resolveCard.cardStatus.options[document.resolveCard.cardStatus.selectedIndex].value) &&
	   (document.resolveCard.hdnDivisionId.value==document.resolveCard.division.options[document.resolveCard.division.selectedIndex].value)&&
	   (document.resolveCard.hdnFacilityId.value==document.resolveCard.facility.value) &&
	   (document.resolveCard.hdnCallResultId.value==document.resolveCard.callResults.options[document.resolveCard.callResults.selectedIndex].value) &&
	   (document.resolveCard.hdnCardResultId.value==document.resolveCard.cardResults.options[document.resolveCard.cardResults.selectedIndex].value) &&
	   (document.resolveCard.hdnSubmittedDt.value==dateFromForm) &&
	   (tempResolutionWorkHistory.value.length==0)){
	   	alert(statusErrMsg);
	   	return false;
	}
	
	var allValid=true;
	var custType=document.resolveCard.custType.value;
			
  	if(!validateFacility(form)){
  		allValid=false;
    		return false;
  	}
  	  		
  	strToChk=tempResolutionWorkHistory.value; //checking whether work history is a valid string or not
        if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)){
        	alert(commentErrMsg);
                tempResolutionWorkHistory.focus();
                tempResolutionWorkHistory.select();
                allValid=false;
                return false;
         } 
        
        //checking whether resolution work history is less than 255 characters or not
/*        if(tempResolutionWorkHistory.value.length > 255){  
		alert(remarksErrMsg);
		tempResolutionWorkHistory.focus();
		tempResolutionWorkHistory.select();
		allValid=false;
		return false;
	}
*/  	
  	var form=document.resolveCard;
	document.resolveCard.action.value=actionValue;
	document.resolveCard.cardId.value=cardNumber;
	replacingTheBlankLinesEncoding(document.resolveCard.tempResolutionWorkHistory,document.resolveCard.resolutionWorkHistory)
			
	tempCardStatus=document.resolveCard.cardStatus;
	var cardStatus=tempCardStatus[tempCardStatus.selectedIndex].value;
	//check whether the card status is "Closed-resolved" or "closed-unresolved". If it is,then then confirm the user whether to save or not
	if(cardStatus==document.resolveCard.closedResolvedIndex.value || cardStatus==document.resolveCard.closedUnresolvedIndex.value){//if statement level 1
		confirmFlag=window.confirm(resolveConfirmationMsg);
		if(confirmFlag){ //if statement level 2
			document.resolveCard.action.value=actionValue;
			document.resolveCard.submit();//submit of the jsp on save button
				
		}else{	//else statement level 2
			return false;
		}//end of if statement level 2
	} // end of if statement level 1
	
	document.resolveCard.action.value=actionValue;
	document.resolveCard.submit();	//submit the form
	
}

//*****************************validateDateSubmitted*****************************************
// This function validates for dates .
// It is called by validateotherields function.
//******************************************************************************************
function validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY) {

	 if(!isEmpty(submittedDate.value)){
 	 if(!dateValidating(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){
		allValid=false;
     		return false;
            }
	}
	else{
		alert(submittedDateErrMsg);
		submittedDate.focus();
		submittedDate.select();
		allValid=false;
		return false;  
	}
	
	if(!isDate(submittedDate,0001,2000,0,31,true)){    
		allValid=false;
		return false;
	}  	

	return true;
}


//*****************************validateFacility*****************************************
// This function validates for faclilty.

//******************************************************************************************	
function validateFacility(form){
		
	var lbx2=document.resolveCard.facility;
        var lbx1=document.resolveCard.division;
    	
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	if (arr2len==0){
    		alert(facilityEmptyErrMsg);
    		lbx2.value="";
    		lbx1.focus();
    		return false;
    	} 
    	if(lbx2.value.length==0){
    		alert(facilityErrMsg);
    		lbx2.focus();
    		return false;
    		
    	}  
    	for(var i=0;i<arr2len;i++){
		if(lbx2.value ==(listArr[ind1][i])){
			return true;
     		//listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    		}else if(i==(arr2len-1)){
    			alert(facilityErrMsg1);
    			lbx2.focus();
    			lbx2.select();
    			return false;    		
    		}//end of if
    	
	}//end of for
}  


//***************************listFill*****************************************
// This function is called on change of the division list box.
//************************************************************************
/*function listFill(){
	var lbx2=document.resolveCard.facility;
    	var lbx1=document.resolveCard.division;
    	var len=lbx2.options.length;
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	for(var k=0;k<len;k++)
		lbx2.options[k]=new Option();
	for(var i=0;i<arr2len;i++){
     		lbx2.options[i]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	lbx2.options.selectedIndex=0;
    	lbx2.options.length=arr2len;
}  
*/
 
function fieldFocus(){
	var custType=document.resolveCard.cardStatus.value;
}


//***************************onlySubmit*****************************************
// This function submits the Screen.
// Parameter :actionValue
//************************************************************************
function onlySubmit(actionValue){
	
	document.resolveCard.action.value=actionValue;
	document.resolveCard.submit();
	
}