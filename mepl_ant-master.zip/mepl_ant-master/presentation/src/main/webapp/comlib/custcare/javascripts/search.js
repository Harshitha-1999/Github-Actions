	numBag = '0123456789';
	safeCardLength = 11;
	vonsCardLength = 14;
	function checkCard(field) {
		field.value = stripCharsNotInBag(field.value, numBag);
		if (field.value.length == safeCardLength || field.value.length == vonsCardLength || isWhitespace(field.value)) {
			return true;
			}
		else {
			alert("The card number must be at least 11 or 14 numbers.");
			field.focus();
			return false;
			}
		}
	function checkName(form) {
		lastName = form.lastName;
		lastName.value = stripCharsInBag(lastName.value, '*% ');
		firstName = form.firstName;
		firstName.value = stripCharsInBag(firstName.value, '*% ');
		if (lastName.value.length > 1 || isWhitespace(lastName.value)) {
			return true;
			}
		else {
			alert("Last name must have at least 2 characters with no spaces.");
			lastName.focus();
			return false;
			}
		}
	function checkCampaign (field) {
		if (field.length > 2 || isWhitespace(field.value)) {
			return true;
			}
		else {
			alert("Campaign number must have at least 3 characters with no spaces.");
			}
		}

	function checkForm(form, hhSearch) {
		if (hhSearch == 'hhSearch') {
			cardNumber = form.hhCardNumber;
			}
		else {
			cardNumber = form.cardNumber;
			}
		if (isWhitespace(cardNumber.value) &&
			isWhitespace(form.lastName.value) &&
			isWhitespace(form.phoneNumber.value) &&
			isWhitespace(form.emailAddress.value) &&
			isWhitespace(form.campaignNbr.value)) {
			alert("You must enter a value in either the Card Number, Phone Number, Last Name, Email Address or Campaign fields.");
			cardNumber.focus();
			return false;
			}
		else {
			if (checkCard(cardNumber) &&
				(checkWorldPhoneNumber(form.phoneNumber) || isWhitespace(form.phoneNumber.value)) &&
				checkCampaign(form.campaignNbr) &&
				checkName(form) &&
				(checkStateProvCd(form.state) || isWhitespace(form.state.value)) &&
				(checkPostalCd(form.zipCode) || isWhitespace(form.zipCode.value)) &&
				(checkEmail(form.emailAddress) || isWhitespace(form.emailAddress.value))) {
				form.phoneNumber.value = stripCharsInBag(form.phoneNumber.value, ' ');
				return true;
				}
			else {
				return false;
				}
			}
		}
