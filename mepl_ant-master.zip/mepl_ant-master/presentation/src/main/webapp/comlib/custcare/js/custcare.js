function storeInfo(facility) {
	workHistory = window.open("store_info.jsp?facility=" + facility, "storeInfo", "height=500,width=650,left=200,top=100,scrollbars=yes,toolbar=no,status=yes,resizeable=no");
//	window.storeInfo.focus();
}
function updateLoc(currentCat, form) {
	// clear the location field
	locLength = form.loc.options.length;
	for (i=0; i < locLength; i++) {
		form.loc.options[0] = null;
	}
	// clear the comment field
	cmmtLength = form.cmmt.options.length;
	for (i=0; i < cmmtLength; i++) {
		form.cmmt.options[0] = null;
	}
	// repopulate the location field
	// cycle through the array to find the category index for the selected category
	for (i=0; i < aCatLocCmmt.length; i++) {
		if (aCatLocCmmt[i][0][0].cmmtCategoryId == currentCat) {
			form.cmmtCategoryId.value = aCatLocCmmt[i][0][0].cmmtCategoryId;
			form.newLocationDsc.value = "";
			form.newCommentDsc.value = "";
			// once the category index is found cycle through the array for that category and repopulate the locations
			for (j=1;j < aCatLocCmmt[i].length;j++) {
				form.loc.options[j] = new Option(aCatLocCmmt[i][j][0].locationDsc, aCatLocCmmt[i][j][0].locationId, false, false);
			}
		}
		form.loc.options[0] = new Option("------ Select Option ------", "", false, false);
	}
	form.loc.options.selectedIndex = 0;
	// repopulate the comment field
	form.cmmt.options[0] = new Option("------ Select Option ------", "", false, false);
}
function updateCmmt(currentCat, currentLoc, form) {
	// clear the comment field
	cmmtLength = form.cmmt.options.length;
	for (i=0; i < cmmtLength; i++) {
		form.cmmt.options[0] = null;
	}
	// repopulate the comment field
	// cycle through the array to find the category index for the selected category
	for (i=0; i < aCatLocCmmt.length; i++) {
		if (aCatLocCmmt[i][0][0].cmmtCategoryId == currentCat) {
			// cycle through the array to find the location index for the selected location
			for (j=0; j < aCatLocCmmt[i].length; j++) {
				if (aCatLocCmmt[i][j][0].locationId == currentLoc) {
					// set the newLocationDsc hidden field for the update/insert
					form.newLocationDsc.value = aCatLocCmmt[i][j][0].locationDsc;
					form.newCommentDsc.value = "";
					// once the location index is found cycle through the array for that location and repopulate the comments
					for (k=1; k < aCatLocCmmt[i][j].length; k++) {
						form.cmmt.options[k] = new Option(aCatLocCmmt[i][j][k].cmmtListDsc, aCatLocCmmt[i][j][k].cmmtListId, false, false);
					}
				}
			}
		}
	}
	form.cmmt.options.selectedIndex = 0;
	// repopulate the comment field
	form.cmmt.options[0] = new Option("------ Select Option ------", "", false, false);
}
function changeCmmt(currentCat, currentLoc, currentCmmt, form) {
	for (i=0; i < aCatLocCmmt.length; i++) {
		if (aCatLocCmmt[i][0][0].cmmtCategoryId == currentCat) {
			// cycle through the array to find the location index for the selected location
			for (j=0; j < aCatLocCmmt[i].length; j++) {
				if (aCatLocCmmt[i][j][0].locationId == currentLoc) {
					// once the location index is found cycle through the array for that location and repopulate the comments
					for (k=1; k < aCatLocCmmt[i][j].length; k++) {
						if (aCatLocCmmt[i][j][k].cmmtListId == currentCmmt) {
							// set the newLocationDsc hidden field for the update/insert
							form.newCommentDsc.value = aCatLocCmmt[i][j][k].cmmtListDsc;
						}
					}
				}
			}
		}
	}
}