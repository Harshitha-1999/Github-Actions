/*************************************************************************************************
Project Name			  	:	SAFEWAY                 
Module Name	   			:	Login
Relevant Spec				:	Login_Spec Ver 110.rtf
Program Name				:	Logon.js
Program Version				: 	1.1.0
Program Description			:	This program validates for all the fields
						      in the login screen
Screens Used				:	NA        
JavaScript files Used   		:	common.js
StyleSheet files Used			:	NA
Tables Used	  	  		:	NA
Templates Included			:	NA
Called From				:	login.jsp  
			
calling					:       none
Default Parameters			:	  
	Input  				:     All the field names
	Output				:     None
	Other Parameters			:     None      
  					            
Modification History 			:       
--------------------------------------------------------------------------------------------------------------------------------
Version Author		Date (MM/DD/CCYY)	Modification Details		Change Request Reference in the code.
--------------------------------------------------------------------------------------------------------------------------------
1.0.0	Vignesh         07/17/2000		NA                                   NA														      
1.1.0	Anupama		08/07/2000              Changed help/error messages	CHG-001.     
---------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************
*/

//Help messages
var loginNameMsg="Enter the login name.";
var passwordMsg="Enter the password.";
var loginMsg="Click for logging in.";
var resetMsg="Click for resetting the page.";

//Error messages
var loginNameErrMsg1="Please enter the Login Name.";
var loginNameErrMsg2="Login Name should be alphanumeric without spaces.";
var passwordErrMsg="Please enter the Password.";

//*********************************focusing()*****************************************************
//This function chjecks for focussing at the first field when the screen is loaded.
//parameters:formName,field
//returns boolean
//**************************************************************************************

function focusing(formName,field){
   formName.elements[field].focus();
}


/***************************getMessage***********************************
This function is to display a help messgae in the status bar
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/
function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;
     lastField=lsf.name;
}

// **********************************isEmpty()**************************************************
// This function checks whether the field value is null.
// parameter: variable s
// returns boolean
//***********************************************************************************************
 
function isEmpty(s){
   return (s.length == 0)?true:false;
  }

// **********************************isAlphaNumeric()**************************************************
// This function checks whether the field value is  globally(all the occurances)
// ignoring case.
// parameter: variable s
// returns boolean or the string itself.
//***********************************************************************************************

function isAlphaNumeric (s){
        return s.match(/^[a-z0-9_]+$/gi)?s:false;
}

//trims the trimSpec in the string s
function trim(s, trimSpec){
       var patt_all = /\s*/gi;
        var patt_lead = /^\s+/i;
        var patt_trail = /\s+$/i;

       /*if(trimSpec == "all")
                return s.replace(patt_all, "");*/
        if(trimSpec == "lead")
                return s.replace(patt_lead, "");
        if(trimSpec == "trail")
                return s.replace(patt_trail, "");

        s= s.replace(patt_lead, "");
        return s.replace(patt_trail, "");
}



//This function validates the login screen.
//parameters
//returns boolean
//**************************************************************************************
function validateLogin()
{
  var loginName=document.loginScreen.userId;
  var password=document.loginScreen.pwd;
  var allValid=true;

  if(isEmpty(loginName.value)){
    alert(loginNameErrMsg1);
    loginName.focus();
    loginName.select();
    allValid=false;
  } 
  else if(!isAlphaNumeric(loginName.value)){
    alert(loginNameErrMsg2);
    loginName.focus();
    loginName.select();
    allValid=false;
  }
  else if(isEmpty(password.value)){
    alert(passwordErrMsg);
    password.focus();
    password.select();
    allValid=false;
  }
  
  if(allValid){
    document.loginScreen.submit();
  }
}

//************************resetingForm******************************************
// This function resets the login page.
// The focus is set to user id.
//******************************************************************************
function resetingForm(form){
	form.userId.value="";
	form.pwd.value="";
	form.userId.focus();	
}


 