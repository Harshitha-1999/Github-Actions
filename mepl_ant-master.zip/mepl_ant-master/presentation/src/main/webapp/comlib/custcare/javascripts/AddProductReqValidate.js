/*************************************************************************************************
Project Name			  	:SAFEWAY                 
Module Name	   		      	:AddProductReqs
Relevant Spec				:AddProductReqs_Spec Ver 100.rtf	  	  	  
Program Name			      	:AddProductReqsValidate.js
Program Version				:1.0.0
Program Description			:js for validation.
Called From				:AddProductReqs.jsp	
Calling					:None       
Modification History 		        :         
------------------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		ModificatioDetails  				Change RequestReference in the code.	
  
  Nirmala Jayaprakash    09/27/2000			1.0.0		NA
------------------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************/
//Help messages
var cmmtStatusMsg="Select the product request status.";  
var cmmtTypeMsg="Select the comment type.";  
var categoryMsg="Select the category.";
var locationMsg="Select the location.";
var safewayCarryMsg="Select the safeway carry.";
var storeCarryMsg="Select the store carry.";
var supplierDiscMsg="Select the supplier disc.";
var availableDsdMsg="Select the available DSD.";
var availableWhrsMsg="Select the available whrs.";
var upcMsg="Enter the UPC.";
var orderNoMsg="Enter the order number.";
var substitutionMsg="Enter the substitution.";
var oldSubstitutionMsg="Edit the substitution.";
var commentMsg="Select the comment.";
var historyMsg="Enter the work history.";
var newCommentDescMsg="Enter the product request description.";  
var oldCommentDescMsg="Edit the product request description.";
var saveMsg="Click to save the product request.";
var saveCallMsg="Click this to save the product request and change the product request status to Ready for call.";
var cancelMsg="Click this to go back to the Edit Comment Card Screen.";
var resetMsg="Click this to reset the screen.";

//Error messages
var commentDescErrMsg="Please enter the Product Request Description." ;
var commentDescErrMsg1="Product Request Description should be less than 255.";
var safewayCarryErrMsg="Please select the Safeway Carry.";
var storeCarryErrMsg="Please select the Store Carry.";
var supplierDiscErrMsg="Please select the Supplier Disc.";
var availableDsdErrMsg="Please select the Available DSD.";  
var availableWhrsErrMsg="Please select the Available Whrs.";
var upcErrMsg="Please enter the UPC.";
var upcFormatErrMsg="Incorrect format. UPC should be decimal.";
var upcFormatLenErrMsg="Incorrect format. UPC should not have more than 4 decimal places.";
var upcLenErrMsg="Please enter UPC between 0 and 1000000000.";
var orderNoErrMsg="Please enter the Order Number.";
var orderNoFormatErrMsg="Incorrect format. Order Number should be alphanumeric.";
var substitutionErrMsg="Please enter the Substitution or select anything other than 'No' in Safeway Carry.";
var substitutionLenErrMsg="Substitution should be less than 255 characters.";
var historyErrMsg="History should be less than 255.";
var statusErrMsg="Change either - Product Request Information or Comment Description \n\n\t\t\t OR \n\n\t\t Enter the Work History."
var substitutionFormatErrMsg="Please do not enter { or } or ^ in Substitution.";
var commentFormatErrMsg="Please do not enter { or } or ^ in Product Request Description.";
var historyFormatErrMsg="Please do not enter { or } or ^ in Work History.";
/***************************getMessage*********************************** 
This function is to display a help message in the status bar.
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/

function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;  
     lastField=lsf.name;
}

/***************************saveScreen*********************************** 
This function validates the screen for save button.
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/
  
function saveScreen(actionValue){          
	var allValid=true;
	workHistory=document.AddProductReq.tempWorkHistory;
	tempSubstitution=document.AddProductReq.tempSubstitution;
	tempCommentDesc=document.AddProductReq.tempCommentDesc;
	cmmtDesc=document.AddProductReq.cmmtDesc;
	substitution=document.AddProductReq.tempSubstitution;
	noId=document.AddProductReq.hdnSafewayCarryDesc.value;
	safewayCarryId=document.AddProductReq.safewayCarryId;
	storeCarryId=document.AddProductReq.storeCarryId;
	supplierDiscId=document.AddProductReq.supplierDiscId;
	availableDsdId=document.AddProductReq.availableDsdId;
	availableWhrsId=document.AddProductReq.availableWhrsId;
	if (document.AddProductReq.upc.value.length!=0)
		tempUpc=parseFloat(document.AddProductReq.upc.value);
	else
		tempUpc=0;
	upc=document.AddProductReq.upc;
	orderNo=document.AddProductReq.orderNo;
	newProReqFlag=document.AddProductReq.newProReqFlag.value; 
	if(newProReqFlag=="false"){
		workHistory=document.AddProductReq.tempWorkHistory;		
		tempSubstitution=document.AddProductReq.tempSubstitution;		
		safewayCarryId=document.AddProductReq.safewayCarryId;
		subs=document.AddProductReq.oldSubstitution;
		//hisCount=document.AddProductReq.noOfHistory.value;
		hdnCmmtTypeId=document.AddProductReq.hdnCmmtTypeId.value;
		hdnCmmtStatusId=document.AddProductReq.hdnCmmtStatusId.value;  
		hdnCmmtCategoryId=document.AddProductReq.cmmt.options[document.AddProductReq.cmmt.selectedIndex].value;
		hdnLocationId=document.AddProductReq.hdnLocationId.value;  
		hdnCmmtListId=document.AddProductReq.hdnCmmtListId.value;
		hdnSafewayCarryId=document.AddProductReq.hdnSafewayCarryId.value;
		hdnStoreCarryId=document.AddProductReq.hdnStoreCarryId.value;
		hdnSupplierDiscId=document.AddProductReq.hdnSupplierDiscId.value;
		hdnAvailableDsdId=document.AddProductReq.hdnAvailableDsdId.value;
		hdnAvailableWhrsId=document.AddProductReq.hdnAvailableWhrsId.value;
		hdnUpc=parseFloat(document.AddProductReq.hdnUpc.value);
		hdnOrderNo=document.AddProductReq.hdnOrderNo.value;
		noId=document.AddProductReq.hdnSafewayCarryDesc.value;
		if((hdnCmmtCategoryId==document.AddProductReq.cat.options[document.AddProductReq.cat.selectedIndex].value)&&
			(hdnLocationId==document.AddProductReq.loc.options[document.AddProductReq.loc.selectedIndex].value)&&
			(hdnCmmtListId==document.AddProductReq.cmmt.options[document.AddProductReq.cmmt.selectedIndex].value)&&
			(hdnCmmtStatusId==document.AddProductReq.cmmtStatusId.options[document.AddProductReq.cmmtStatusId.selectedIndex].value)&&
			(hdnCmmtTypeId==document.AddProductReq.cmmtTypeId.options[document.AddProductReq.cmmtTypeId.selectedIndex].value)&&
			(tempCommentDesc.value==cmmtDesc.value)&&
			(hdnSafewayCarryId==document.AddProductReq.safewayCarryId.options[document.AddProductReq.safewayCarryId.selectedIndex].value)&&
			(hdnStoreCarryId==document.AddProductReq.storeCarryId.options[document.AddProductReq.storeCarryId.selectedIndex].value)&&
			(hdnSupplierDiscId==document.AddProductReq.supplierDiscId.options[document.AddProductReq.supplierDiscId.selectedIndex].value)&&
			(hdnAvailableDsdId==document.AddProductReq.availableDsdId.options[document.AddProductReq.availableDsdId.selectedIndex].value)&&
			(hdnAvailableWhrsId==document.AddProductReq.availableWhrsId.options[document.AddProductReq.availableWhrsId.selectedIndex].value)&&
			(hdnUpc==tempUpc)&&
			(hdnOrderNo==orderNo.value)&&
			(tempSubstitution.value==subs.value)&&
			(workHistory.value.length==0)){
				alert(statusErrMsg);
				document.AddProductReq.cmmtStatusId.focus();
				allValid=false;
				return false;
			}
		}// end of if.

		if(upc.value.length!=0){
			if(!isFloat(upc.value)){
				alert(upcFormatErrMsg);
				upc.focus();
				upc.select();
				allValid=false;
				return false;
			}// end of else if
			if(!validateUpc(upc)){
				allvalid=false;
				return false;
			}
		}
		
		if(orderNo.value.length!=0){
			if(!checkAlphaNumericSpace(orderNo,false)){
				alert(orderNoFormatErrMsg);
				orderNo.focus();
				orderNo.select();
				allValid=false;
				return false;
			}// end of else if
		}
		if((tempSubstitution.value.length==0)&&(safewayCarryId[safewayCarryId.selectedIndex].value==noId)){			
	 		alert(substitutionErrMsg);  
			document.AddProductReq.tempSubstitution.focus();
			document.AddProductReq.tempSubstitution.select();
			allValid=false;  
			return false;
		}//end of if.
		if(document.AddProductReq.tempSubstitution.value.length > 255){    
			alert(substitutionLenErrMsg);
			document.AddProductReq.tempSubstitution.focus();
			document.AddProductReq.tempSubstitution.select();
			allValid=false;
			return false;
		}//end of if.

		strToChk=tempSubstitution.value;
		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
			alert(substitutionFormatErrMsg);
			tempSubstitution.focus();
			tempSubstitution.select();
			return false;
		}//end of if.
		if(tempCommentDesc.value.length==0){			
	 		alert(commentDescErrMsg);  
			document.AddProductReq.tempCommentDesc.focus();
			document.AddProductReq.tempCommentDesc.select();
			allValid=false;
			return false;
		}//end of if.
		strToChk=tempCommentDesc.value;
		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
			alert(commentFormatErrMsg);
			tempCommentDesc.focus();
			tempCommentDesc.select();
			return false;
		}//end of if.
		strToChk=workHistory.value;
		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
			alert(historyFormatErrMsg);
			workHistory.focus();
			workHistory.select();
			return false;
		}//end of if.
	if (document.AddProductReq.cat.options[document.AddProductReq.cat.selectedIndex].value == "") {
		alert(categoryMsg);
		return false;
	}
	if (document.AddProductReq.loc.options[document.AddProductReq.loc.selectedIndex].value == "") {
		alert(locationMsg);
		return false;
	}
	if (document.AddProductReq.cmmt.options[document.AddProductReq.cmmt.selectedIndex].value == "") {
		alert(commentMsg);
		return false;
	}
	if(allValid){
		document.AddProductReq.cmmtCategoryId.value=document.AddProductReq.cat.options[document.AddProductReq.cat.selectedIndex].value;
		document.AddProductReq.locationDesc.value=document.AddProductReq.newLocationDsc.value;
		document.AddProductReq.commentListDesc.value=document.AddProductReq.newCommentDsc.value;
		document.AddProductReq.action.value=actionValue;
		replacingTheBlankLinesEncoding(document.AddProductReq.tempSubstitution,document.AddProductReq.substitution);
		replacingTheBlankLinesEncoding(document.AddProductReq.tempCommentDesc,document.AddProductReq.commentDesc);
		replacingTheBlankLinesEncoding(document.AddProductReq.tempWorkHistory,document.AddProductReq.workHistory);
		document.AddProductReq.submit();
	}// end of if    
		  
}

/***************************saveScreen*********************************** 
This function is to validate on save call button is pressed.
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/

function saveCallScreen(actionValue,selIndex){         
	var allValid=true;
	workHistory=document.AddProductReq.tempWorkHistory;
	tempSubstitution=document.AddProductReq.tempSubstitution;
	tempCommentDesc=document.AddProductReq.tempCommentDesc;
	cmmtDesc=document.AddProductReq.cmmtDesc;
	substitution=document.AddProductReq.tempSubstitution;
	noId=document.AddProductReq.hdnSafewayCarryDesc.value;
	cmmtStatusId=document.AddProductReq.cmmtStatusId;
	safewayCarryId=document.AddProductReq.safewayCarryId;
	storeCarryId=document.AddProductReq.storeCarryId;
	supplierDiscId=document.AddProductReq.supplierDiscId;
	availableDsdId=document.AddProductReq.availableDsdId;
	availableWhrsId=document.AddProductReq.availableWhrsId;
	if (document.AddProductReq.upc.value.length!=0)
		tempUpc=parseFloat(document.AddProductReq.upc.value);
	else
		tempUpc=0;
	upc=document.AddProductReq.upc;
	orderNo=document.AddProductReq.orderNo;
	newProReqFlag=document.AddProductReq.newProReqFlag.value; 
	if(newProReqFlag=="false"){
		workHistory=document.AddProductReq.tempWorkHistory;		
		tempSubstitution=document.AddProductReq.tempSubstitution;		
		safewayCarryId=document.AddProductReq.safewayCarryId;
		subs=document.AddProductReq.oldSubstitution;
		//hisCount=document.AddProductReq.noOfHistory.value;
		hdnCmmtTypeId=document.AddProductReq.hdnCmmtTypeId.value;
		hdnCmmtStatusId=document.AddProductReq.hdnCmmtStatusId.value;  
		hdnCmmtCategoryId=document.AddProductReq.cmmt.options[document.AddProductReq.cmmt.selectedIndex].value;
		hdnLocationId=document.AddProductReq.hdnLocationId.value;  
		hdnCmmtListDesc=document.AddProductReq.hdnCmmtListId.value;
		hdnSafewayCarryId=document.AddProductReq.hdnSafewayCarryId.value;
		hdnStoreCarryId=document.AddProductReq.hdnStoreCarryId.value;
		hdnSupplierDiscId=document.AddProductReq.hdnSupplierDiscId.value;
		hdnAvailableDsdId=document.AddProductReq.hdnAvailableDsdId.value;
		hdnAvailableWhrsId=document.AddProductReq.hdnAvailableWhrsId.value;
		hdnUpc=parseFloat(document.AddProductReq.hdnUpc.value);
		hdnOrderNo=document.AddProductReq.hdnOrderNo.value;
		noId=document.AddProductReq.hdnSafewayCarryDesc.value;
		
		if (document.AddProductReq.cmmtStatusId[selIndex].value==hdnCmmtStatusId){
			if((hdnCmmtCategoryId==document.AddProductReq.cat.options[document.AddProductReq.cat.selectedIndex].value)&&
				(hdnLocationDesc==document.AddProductReq.loc.options[document.AddProductReq.loc.selectedIndex].value)&&
				(hdnCmmtListDesc==document.AddProductReq.cmmt.options[document.AddProductReq.cmmt.selectedIndex].value)&&
				(hdnCmmtTypeId==document.AddProductReq.cmmtTypeId.options[document.AddProductReq.cmmtTypeId.selectedIndex].value)&&
				(tempCommentDesc.value==cmmtDesc.value)&&
				(hdnSafewayCarryId==document.AddProductReq.safewayCarryId.options[document.AddProductReq.safewayCarryId.selectedIndex].value)&&
				(hdnStoreCarryId==document.AddProductReq.storeCarryId.options[document.AddProductReq.storeCarryId.selectedIndex].value)&&
				(hdnSupplierDiscId==document.AddProductReq.supplierDiscId.options[document.AddProductReq.supplierDiscId.selectedIndex].value)&&
				(hdnAvailableDsdId==document.AddProductReq.availableDsdId.options[document.AddProductReq.availableDsdId.selectedIndex].value)&&
				(hdnAvailableWhrsId==document.AddProductReq.availableWhrsId.options[document.AddProductReq.availableWhrsId.selectedIndex].value)&&
				(hdnUpc==tempUpc)&&
				(hdnOrderNo==orderNo.value)&&
				(tempSubstitution.value==subs.value)&&
				(workHistory.value.length==0)){
					alert(statusErrMsg);
					document.AddProductReq.cmmtStatusId.focus();
					allValid=false;
					return false;  
			}
		}
	}// end of if.	

	if(upc.value.length!=0){
		if(!isFloat(upc.value)){
			alert(upcFormatErrMsg);
			upc.focus();
			upc.select();
			allValid=false;
			return false;
		}// end of else if
		if(!validateUpc(upc)){
			allvalid=false;
			return false;
		}
	}
	
	if(orderNo.value.length!=0){
		if(!checkAlphaNumericSpace(orderNo,false)){
			alert(orderNoFormatErrMsg);
			orderNo.focus();
			orderNo.select();
			allValid=false;
			return false;
		}// end of else if
	}
	if((tempSubstitution.value.length==0)&&(safewayCarryId[safewayCarryId.selectedIndex].value==noId)){			
 		alert(substitutionErrMsg);  
		document.AddProductReq.tempSubstitution.focus();
		document.AddProductReq.tempSubstitution.select();
		allValid=false;  
		return false;
	}//end of if.
	if(document.AddProductReq.tempSubstitution.value.length > 255){    
		alert(substitutionLenErrMsg);
		document.AddProductReq.tempSubstitution.focus();
		document.AddProductReq.tempSubstitution.select();
		allValid=false;
		return false;
	}//end of if.
	strToChk=tempSubstitution.value;
	if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
		alert(substitutionFormatErrMsg);
		tempSubstitution.focus();
		tempSubstitution.select();
		return false;
	}//end of if.
	if(tempCommentDesc.value.length==0){			
 		alert(commentDescErrMsg);  
		document.AddProductReq.tempCommentDesc.focus();
		document.AddProductReq.tempCommentDesc.select();
		allValid=false;
		return false;
	}//end of if.
	strToChk=tempCommentDesc.value;
	if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
		alert(commentFormatErrMsg);
		tempCommentDesc.focus();
		tempCommentDesc.select();
		return false;
	}//end of if.
	strToChk=workHistory.value;
	if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
		alert(historyFormatErrMsg);
		workHistory.focus();
		workHistory.select();
		return false;
	} //end of if.
	if (document.AddProductReq.cat.options[document.AddProductReq.cat.selectedIndex].value == "") {
		alert(categoryMsg);
		return false;
	}
	if (document.AddProductReq.loc.options[document.AddProductReq.loc.selectedIndex].value == "") {
		alert(locationMsg);
		return false;
	}
	if (document.AddProductReq.cmmt.options[document.AddProductReq.cmmt.selectedIndex].value == "") {
		alert(commentMsg);
		return false;
	}
	if(allValid){
		document.AddProductReq.cmmtCategoryId.value=document.AddProductReq.cat.options[document.AddProductReq.cat.selectedIndex].value;
		document.AddProductReq.locationDesc.value=document.AddProductReq.newLocationDsc.value;
		document.AddProductReq.commentListDesc.value=document.AddProductReq.newCommentDsc.value;
//document.AddProductReq.locationDesc.value=document.AddProductReq.location.options[document.AddProductReq.location.selectedIndex].value;
//document.AddProductReq.commentListDesc.value=document.AddProductReq.comment.options[document.AddProductReq.comment.selectedIndex].value;
		document.AddProductReq.cmmtStatusId.selectedIndex=selIndex;
		document.AddProductReq.action.value=actionValue;
		replacingTheBlankLinesEncoding(document.AddProductReq.tempSubstitution,document.AddProductReq.substitution);
		replacingTheBlankLinesEncoding(document.AddProductReq.tempCommentDesc,document.AddProductReq.commentDesc);
		replacingTheBlankLinesEncoding(document.AddProductReq.tempWorkHistory,document.AddProductReq.workHistory);
		document.AddProductReq.submit();
	}//end of if.  
		  
}

//***************************clearScreen*****************************************
//This function is to clear the screen on pressing the reset button.
//Parameter:form
//************************************************************************

function clearScreen(form)
{
	form.tempCommentDesc.value="";
	form.cmmtStatusId.selectedIndex=0;  
	form.cmmtTypeId.selectedIndex=0;
 	form.category.selectedIndex=0;
 	form.safewayCarryId.selectedIndex=0;  
 	form.storeCarryId.selectedIndex=0;  
 	form.supplierDiscId.selectedIndex=0;  
 	form.availableDsdId.selectedIndex=0;  
 	form.availableWhrsId.selectedIndex=0;  
 	form.upc.value="";
 	form.orderNo.value="";
 	form.tempWorkHistory.value="";
 	form.tempSubstitution.value="";
 	changeCat();
 	if(document.AddProductReq.newProReqFlag.value=="false")document.AddProductReq.tempWorkHistory.value="";		
 	form.cmmtStatusId.focus();
}

//***************************onlySubmit*****************************************
// This function submits the Screen.
// Parameter :actionValue
//************************************************************************
function onlySubmit(actionValue){
	document.AddProductReq.action.value=actionValue;
	document.AddProductReq.submit();
}

//*****************************replacingTheBlankLinesEncoding*****************************************
//This function is to replace the blank lines encoding.
//******************************************************************************************
function replacingTheBlankLinesEncoding(field1,field2){
var fieldValue=field1.value;
var fieldValueLength=fieldValue.length;
var tempString='';
for( i=0;i<fieldValueLength;i++){	 
	if((fieldValue.charCodeAt(i)==13)&&(fieldValue.charCodeAt(i+1)==10)){
		tempString=tempString+'^';
	}
	else{
		if(fieldValue.charCodeAt(i)==10){
	tempString=tempString; 
		}
		else{
		tempString=tempString+fieldValue.charAt(i);
		}
	}
	}// end of for 
	
// dhorn00 - something is wrong here.
//	if (field2) {
	field2.value=tempString;
//	}

}
  

function backCheck(){
	history[-1]='';
}

//*****************************checkResolve*****************************************
// This function validates whether the card status and comment status are 'Ready for call'
// It is called by Resolve Link.
//******************************************************************************************
function checkResolve(){
	var status=document.AddProductReq.resolveStatus.value;
	if(status=="false"){
	alert("Either 'Comment Status' or 'Product Request Status' are not 'Ready for Call'. The Contact cannot be resolved.");
	return false;
	}
	
return true;
}

function validateUpc(upc){  
	upc=upc.value;
	var upcVal=0;  
	var upcArr=upc.split(".");
	var upcArrLen=upcArr.length;      
	upcVal=parseFloat(document.AddProductReq.upc.value,0);    
	if(upcVal>9999999999999.999){
		alert(upcLenErrMsg);
		document.AddProductReq.upc.focus();
	  	document.AddProductReq.upc.select();
		return false;
	}
	if(upcArrLen>1){
		if(upcArr[1].length>4){
			alert(upcFormatLenErrMsg);
			document.AddProductReq.upc.focus();
		  	document.AddProductReq.upc.select();
			return false;
		}
	}
	return true;
}
	
	