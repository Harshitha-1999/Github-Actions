/*************************************************************************************************
Project Name			  	:SAFEWAY                 
Module Name	    		   	      :CommentCard
Relevant Spec				:NewCommentCard Ver 100.rtf	  	  	  
Program Name				:NewCommentCardValidate.js
Program Version				:1.0.0
Program Description			:js for validation.
Called From					:NewCommentCard.jsp	
Calling						:None       
Modification History 		        :       
------------------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		ModificatioDetails  				Change RequestReference in the code.	
  Sundeep Nahar          08/29/2000			1.0.0		Creation of Js				 		NA
  Cyril			 09/12/2000			1.1.0		done date formatting 	CHG-007												  																	
------------------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************/

//Help messages
var firstNameMsg="Enter the first name.";
var lastNameMsg="Enter the last name.";
var mIMsg="Enter the middle initial.";
var emailIDMsg="Enter the e-mail.";   
var addressMsg="Enter the address.";
var cityMsg="Enter the city.";
var stateMsg="Enter the state.";
var postalCodeMsg="Enter the zip code.";
var phoneMsg="Enter the phone number.";
var cardSourceMsg="Select the contact type.";
var submittedDateMsg="Enter the date submitted.";
var divisionMsg="Select the division.";
var facilityMsg="Select the appropriate facility.";
var answerMsg="Select the appropriate response.";
var remarksMsg="Enter the remarks.";
var needsUpdateMsg="Select if customer info needs update."  
var saveMsg="Click for saving the details.";
var saveEditMsg="Click for saving/editing the details.";
var cancelMsg="Click for cancelling card.";
var resetMsg="Click for resetting the page.";
   
//Error messages
var firstNameErrMsg="Please enter the First Name.";
var lastNameErrMsg="Please enter the Last Name.";
var phoneErrMsg="Please enter a ten digit Phone Number.";
var cardSourceErrMsg="Please select the Contact Type.";
var submittedDateErrMsg="Please enter the Date Submitted.";
var submittedDateFormatErrMsg="Please enter the Date Submitted in mmddyy or mmddyyyy format.";
var divisionErrMsg="Please select the  Division.";
var facilityErrMsg=" Please enter the Facility ID.";
var facilityErrMsg1="Invalid Facility ID. Please enter a valid ID.";
var facilityFormatErrMsg="Selected Division does not contain Facility.";
var questionErrMsg="Please select the appropriate Response.";
var remarksErrMsg="Remarks should be less than 255 characters";
var lastNameFormatErrMsg ='Incorrect format. Customer\'s Last Name should be alphabetic. ';
var firstNameFormatErrMsg ='Incorrect format. Customer\'s First Name should be alphabetic. ';
var mIErrMsg='Incorrect format.Customer\'s Middle Initial should be alphabetic.';
var phoneErrMsg='Incorrect format. Please enter a ten digit Phone Number.';
var emailIdErrMsg="Incorrect format. Email ID should be alphanumeric and the format should be 'yourMailID@yourmailserver.com'.";
var cityErrMsg="Incorrect format. City should be alphanumeric.";
var stateErrMsg="Incorrect format. State should be alphanumeric.";
var postalCodeErrMsg="Incorrect format. Zip Code should be alphanumeric.";
var remarksFormatErrMsg='Incorrect format.  Remarks should not contain ^ character.';
var remarksErrMsg2='Please enter the Remarks.';
var addressErrMsg = "Please do not enter { or }.";

//***************************storeInfo*****************************************
// This funstion gives info about store information.
//******************************************************************************
function storeInfo()
{
	alert("Requested page currently under development");
}
//***************************listfill*****************************************
// This function is called on change of the division list box.
//******************************************************************************
function listFill(){ 
	var lbx2=document.NewCommentCard.facility;
    	var lbx1=document.NewCommentCard.division;
    	var len=lbx2.options.length;
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	for(var k=0;k<len;k++)
		lbx2.options[k]=new Option();
	for(var i=0;i<arr2len;i++){
     		lbx2.options[i]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	lbx2.options.selectedIndex=0;
    	lbx2.options.length=arr2len;
}  

function clearScreen(form,dateString,noneIndex)
{	
	var c=dateString;
	
	form.firstName.value="";
	form.lastName.value="";
	form.mI.value="";
	form.emailId.value="";
	form.address.value="";
	form.addressExtn.value="";
	form.city.value="";
	form.state.value="";
	form.postalCode.value="";
	form.phone.value="";
	form.facility.value="";
	form.tempRemarks.value="";
	if(dateString.length!=8)
 	form.submittedDate.value="0"+dateString;
 	else
 	form.submittedDate.value=dateString;
 	
 	
 	form.cardSource.selectedIndex=1;
 	form.division.selectedIndex=0;
 	var i=form.noOfQuestions.value;
 	var strAnsNm="";
 	for (var j=0;j<i;j++)
 	{
 		strAnsNm=eval("form.answer"+(j+1));
 		strAnsNm.selectedIndex=noneIndex;
 	}
 	form.firstName.focus();
 }
 
 
 
function saveValidate(actionValue){
	var form=document.NewCommentCard;
	var firstName=form.firstName;
	var lastName=form.lastName;
	var mI=form.mI;
	var emailId=form.emailId;
	var address=form.address; 
	var addressExtn=form.addressExtn; 
	var city=form.city;
	var state=form.state;
	var postalCode=form.postalCode;
	//var areaCodes=form.areaCodes;
	var phone=form.phone;
	var submittedDate=form.submittedDate;
	var submittedDateMM=form.submittedDateMM;
	var submittedDateDD=form.submittedDateDD;
	var submittedDateYY=form.submittedDateYY;
	var tempRemarks=form.tempRemarks;
	var remarks=form.remarks;
  	
 
	if(
	validateFirstName(firstName,firstNameErrMsg,firstNameFormatErrMsg)&&
	validateLastName(lastName,lastNameErrMsg,lastNameFormatErrMsg)&&
	validateMI(mI,mIErrMsg)&&
	validateEmailId(emailId)&&
	validateAddress(address)&&
	validateAddress(addressExtn)&&
	validateCity(city,cityErrMsg)&&
	validateState(state)&&
	validateZip(postalCode)&&
	validatePhoneNumber(document.NewCommentCard,phone)&&
	phoneValidating(document.NewCommentCard,phone)&&
	validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)&&
	validateDivision(form)&&
	validateFacility(form)&&
	validateRemarks(tempRemarks)  
	){  
		
		form.action.value=actionValue;
		replacingTheBlankLinesEncoding(tempRemarks,remarks);
		if(form.submittedDate.value != ""){
			var arrSubDt=form.submittedDate.value.split("/");
			form.submittedDateMM.value=arrSubDt[0];
			form.submittedDateDD.value=arrSubDt[1];
			form.submittedDateYY.value=arrSubDt[2];
		}
		document.NewCommentCard.submit();
		return true;	
	}	
}

//*****************************validateName*************************************************
// This function validates for Names.
// It is called by validateotherields function.
//******************************************************************************************

function validateLastName(objField,errMsg1,errMsg2){
if(objField.value.length==0){
	//alert(errMsg1);
	//objField.focus();
	//return false;	
	objField.value="Customer";
	return true;
	}	
else if(checkAlphabeticSpaceQuote(objField,true)){
	return true;
}
else{
	alert(errMsg2);
	objField.focus();
	objField.select();
	return false;
	}
}

//*****************************validateName*************************************************
// This function validates for Names.
// It is called by validateotherields function.
//******************************************************************************************

function validateFirstName(objField,errMsg1,errMsg2){
if(objField.value.length==0){
	//alert(errMsg1);
	//objField.focus();
	//return false;	
	objField.value="Valued";
	return true;
	}	
else if(checkAlphabeticSpaceQuote(objField,true)){
	return true;
}
else{
	alert(errMsg2);
	objField.focus();
	objField.select();
	return false;
	}
}
//*****************************validateMI***************************************************
// This function validates for Middle Initial.
// It is called by validateotherields function.
//******************************************************************************************
function validateMI(objField,errMsg){
	if(objField.value.length==0){
		return true;
	}
	else if(checkAlphabeticSpaceQuote(objField,true)){
		return true;
	}
	else{
	alert(errMsg);
	objField.focus();
	objField.select();
	return false;
	}
}// end of method

//*****************************validateEmailId*********************************
//Description	:This function validates emailid for correct emailformat
//Parameters	:form,emailId
//returns	:boolean
//*****************************************************************************
function validateEmailId(objField){
	if (objField.value.length!=0){	
		if(validateEmail(objField)){
			return true;		
		} // end of if
		else {
			
			alert(emailIdErrMsg);
			objField.focus();
			objField.select();
			return false;
		} // end of else
	}
	return true;

}// end of validateEmailId

//******************validateCity***************************************
//Description	:This function validates the field for alphanumeric
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateCity(objField,errMsg){
	if (objField.value.length!=0){
		if(!isAlphaNumericSpace(objField.value,true)){  
			alert(errMsg);
			objField.focus();
			objField.select();
			return false;
		}// end of else
	}
	return true;
}// end of validatealphanumeric


//******************validateState***************************************
//Description	:This function validates the State for alphabetic
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateState(objField){
	if(!checkStateProvCd(objField,true)){
		return false;
	}
	else return true;
}

//******************validateZip***************************************
//Description	:This function validates the State for alphabetic
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateZip(objField){
	if(!checkPostalCd(objField,true)){
		return false;
		
	}
	else return true;	
	
}
//***************************validatephonenumber*****************************************
// This function is validates the phone number.
//**********************************************************************************
//*************************validatePhoneNumber****************************************
//Description	:This functions checks the validity of the phone number.
//Parameter	:form,phone,phone1,phone2
//Returns	:boolean
//*******************************************************************************

function validatePhoneNumber(form,phone){
	
	if(isEmpty(phone.value)){
		form.areaCode.value="111";
		form.phone1.value="111";
		form.phone2.value="1111";
	}//end of if 
	return true;
	
}  // end of validate phone 

//*****************************validateDateSubmitted*****************************************
// This function validates for dates .
// It is called by validateotherields function.
//******************************************************************************************

function validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY) {

	 if(!isEmpty(submittedDate.value)){
 	 	if(!dateValidating(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){
		//	alert(submittedDateFormatErrMsg);
	    	//	submittedDate.focus();
	    	//	submittedDate.select(); 
	    		allValid=false;
	    		return false;
	  	}
	}
	else{
		alert(submittedDateErrMsg);
		submittedDate.focus();
		submittedDate.select();
		allValid=false;
		return false;
	}
  	if(!isDate(submittedDate,0001,2000,0,31,true)){    
		allValid=false;
		return false;
	}
	return true;
}

//*****************************validateRemarks*****************************************
// This function validates for remarks.
// It is called by validateotherields function.
//******************************************************************************************

function validateRemarks(objField){
var objFieldLength=objField.value.length;
var tempChar;
if(objFieldLength==0){
  alert(remarksErrMsg2);
  objField.focus();	
  return false;
}  


for(i=0;i<objFieldLength;i++){
	tempChar=objField.value.charAt(i);
	if(tempChar=='^'){
		alert(remarksFormatErrMsg);
		objField.focus();
		objField.select();
		return false;
		}	
	}
/*
if(objFieldLength > 255){  
	alert(remarksErrMsg);       
	objField.focus();
	objField.select();
	return false;
} 
*/
strToChk=objField.value;
if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)){
    alert(addressErrMsg);
    objField.focus();
    objField.select();
    return false;
 }
 
return true;
}

//***************************onlySubmit*****************************************
// This function submits the Screen.
// Parameter :actionValue
//************************************************************************
function onlySubmit(actionValue){
	document.NewCommentCard.action.value=actionValue;
	document.NewCommentCard.submit();
}





function validateFacility(form){
	var lbx2=document.NewCommentCard.facility;
        var lbx1=document.NewCommentCard.division;
    	
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	if (ind1==0){
    		alert(divisionErrMsg);
    		lbx1.focus();
    		return false;
    	}
    	
    	var arr2len=listArr[ind1-1].length;
    	
    	if (arr2len==0){
    		alert(facilityFormatErrMsg);
    		lbx2.value="";
    		lbx1.focus();
    		return false;
    	}
    	
    	if(lbx2.value.length==0){
    		alert(facilityErrMsg);
    		lbx2.focus();
    		return false;
    		
    		}  
    	
    	for(var i=0;i<arr2len;i++){
		if(lbx2.value ==(listArr[ind1-1][i])){
			return true;
     		//listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	else if(i==(arr2len-1)){
    		alert(facilityErrMsg1);
    		lbx2.focus();
    		lbx2.select();
    		return false;    		
    		}
    	
	}
}  



function validateZip(objField){
	if(!checkPostalCd(objField,true)){
		return false;
		
	}
	else return true;	
	
}


function validateAddress(objField){
	strToChk=objField.value;
	if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)){
		alert(addressErrMsg);
		objField.focus();
		objField.select();
	return false;
}
	return true;
	
}

function validateDivision(form){
	if (form.division.selectedIndex==0){
		alert(divisionErrMsg);
		form.division.focus();
		return false;
	}
	return true;
}