/********************************************************************************************
Project Name				:Safeway  
Module Name	   			:SearchCustomer
Program Name				:SearchCustomerValidate.js	
Program Version				:1.1.0 	
Program Description			:This is the  java script file in which does all the 
	                                 validations of the SearchCustomer 
Called From				:SearchCustomer.jsp
Calling					:Common.js 	
Modification History 	      	:
------------------------------------------------------------------------------------------------------------
Author   Date(MM/DD/CCYY)	Version   Modification Details          ChangeRequestReferenceinthe code
-----------------------------------------------------------------------------------------------------------
venkat    07/25/2000  		1.0.0	    NA                                N.A
sundeep	  08/04/2000		1.1.0	    Changed the function validate1
					    and included new functions.		CHG-001.
NAHAR	    09/12/2000		1.1.1		done date formatting 	CHG-003.					    
***********************************************************************************************************/

var EMPTY_STRING="";
//declare the alertmessages
var searchEmptyAllAlrt="Please enter appropriate Customer details for the search (either Card Number or Phone Number or Last Name).";
var searchEmptyAlrt1="Please enter appropriate Customer details for the search (either Card Number or Phone Number or Last Name).";
var searchEmptyAlrt2="Please enter at least Last Name for the search.";

//help messages
var searchHelpCardNo="Enter the Club Card Number.";
var searchHelpPhoneNumber="Enter the phone number.";
var searchHelpCampaignNo="Enter the campaign number.";
var searchHelpEmailId="Enter the e-mail ID.";
var searchHelpLastName="Enter the customer's last name.";
var searchHelpFirstName="Enter the customer's first name.";
var searchHelpMi="Enter the customer's middle initial.";
var searchHelpCity="Enter the city.";
var searchHelpState="Enter the state.";
var searchHelpPostalCode="Enter the postal code.";
var searchHelpSearchMsg="Search the club card customer.";
var searchHelpNewCommentCardMsg="Click for creating  new comment card.";
var searchHelpResetMsg="Click for resetting the page.";
var searchHelpExactSearchMsg="Check this for the exact search.";
var searchLogOutHelpMsg=" Click here for logging out.";

// error message
var custCardIdErrMsg="Incorrect format. Club Card Number should be alphanumeric.";
var phoneErrMsg='Incorrect format. Please enter a ten digit Phone Number.';
var campaignNumberErrMsg="Incorrect format. Campaign Number should be alphanumeric.";
var emailIdErrMsg="Incorrect format. Email ID should be alphanumeric and the format should be 'yourMailId@yourmailserver.com'.";
var firstNameErrMsg="Incorrect format. Customer's First Name should be alphabetic.";
var lastNameErrMsg="Incorrect format. Customer's Last Name should be alphabetic.";
var mIErrMsg="Incorrect format. Customer's Middle Initial should be alphabetic.";
var cityErrMsg="Incorrect format. City should be alphanumeric.";
var stateErrMsg="Incorrect format. State should be alphabetic.";
var postalCodeErrMsg="Incorrect format. Zip Code should be alphanumeric.";


//***************************getMessage*************************************
//This function is to display a help messgae in the status bar
//Parameters : currentField,HelpMessage
//Returns    : Void
//**************************************************************************
function getMessage(fieldName,HelpMessage){
     window.status=HelpMessage;
    }
    
//*************************validate1*****************************************
// This function validates the field entered in the form and returns submits 
// the form if the conditions are satisfied.
// Parameter  : form,actionValue
// returns    :	boolean
//***************************************************************************
 
function validate1(form,actionValue){	
	
	form.action.value=actionValue;
	var clubCardId=form.clubCardId;
	var phoneNum=form.phone;
  	var campaignNumber=form.campaignNumber;
  	var emailId=form.emailId;
	var firstName=form.firstName;
	var lastName=form.lastName;
	var mI=form.mI;
	var city=form.city;
	var state=form.state;
	var zip=form.postalCode;
	var valid=true;
	form.action.value=actionValue;
  	
  		if(validateClubCardId(form,clubCardId)&& 
  		validateCampaignNumber(form,campaignNumber)&&
  		phoneValidating(form,phoneNum)&&
  		validateEmailId(form,emailId)&&
  		validateLastName(form,lastName)&&
  		validateOtherField(form))
  		{
   		form.submit();
		return true;
  		}// end of if
  }// end of validate1

//*************************validateClubCardId********************************
//Description	:This function validates clubcardId for alphanumeric value.
//Parameters	:form,clubCardId
//Returns	:boolean
//***************************************************************************

function validateClubCardId(form,clubCardId){
if(isEmpty(clubCardId.value)){
	return true;
	}
if(checkAlphaNumeric(clubCardId,true)){
	//form.submit();
	return true; 
}// end of if
else {
	alert(custCardIdErrMsg);
  	clubCardId.focus();
  	clubCardId.select();
	return false;
	}// end of else
}// end of validate club cardid

//***********************validateCampaignNumber*******************************
//Description	:This function validates campaign number for alphanumeric.
//Parameter	:form,campaignNumber
//Returns	:booloean
//*****************************************************************************

function validateCampaignNumber(form,campaignNumber){
	if(isEmpty(campaignNumber.value)){
		return true;
		}
	if(checkAlphaNumeric(campaignNumber,true)){
		//form.submit();
		return true;	
		
	} else {
		alert(campaignNumberErrMsg);
		campaignNumber.focus();
		campaignNumber.select();
		return false;
	}
}

//*****************************validateEmailId*********************************
//Description	:This function validates emailid for correct emailformat
//Parameters	:form,emailId
//returns	:boolean
//*****************************************************************************
function validateEmailId(form,emailId){
	if(isEmpty(emailId.value)){
		return true;
	}	
	if(validateEmail(emailId)){
		return true;		
	} // end of if
	else {
		alert(emailIdErrMsg);
		emailId.focus();
		emailId.select();
		return false;
	} // end of else
}// end of validateEmailId

//***********************validateLastName****************************************
//Description	:This function validates lastname for alphanumeric
//Parameters	:form,lastName
//Return Type	:boolean
//*******************************************************************************
function validateLastName(form,lastName){
	if(isEmpty(lastName.value)){
		return true;
		}	
		if(checkAlphabeticSpaceQuote(lastName,true)){
		return true;	
		}// end of if 
		else {
		alert(lastNameErrMsg);
		lastName.focus();
		lastName.select();
		return false;
	}// end of else
}// end of validateLastName

//*************************validateOtherField***************************************
//Description	:This function validates for the remailing fields in the screen
//Parameter	:form
//Return	:boolean
//**********************************************************************************

function validateOtherField(form){
	var clubCardId=form.clubCardId;
	var phone=form.phone;
	var campaignNumber=form.campaignNumber;
  	var emailId=form.emailId;
	var firstName=form.firstName;
	var lastName=form.lastName;
	var mI=form.mI;
	var city=form.city;
	var state=form.state;
	var zip=form.postalCode;
	 
	if(
	(clubCardId.value.length==0)&&
	(phone.value.length==0)&&
	(emailId.value.length==0)&&
	(firstName.value.length==0)&&
	(lastName.value.length==0)&&
	(mI.value.length==0)&&
	(city.value.length==0)&&
	(state.value.length==0)&&
	(zip.value.length==0)
	){
	 alert(searchEmptyAllAlrt);
	 clubCardId.focus();
	 return false;
	}// end of if
	
	if(
      (clubCardId.value.length==0)&&
	(phone.value.length==0)&&
	(emailId.value.length==0)&&
	(lastName.value.length==0)&&
	((firstName.value.length!=0)||
	(mI.value.length!=0)||
	(city.value.length!=0)||
	(state.value.length!=0)||
	(zip.value.length!=0))){
       alert(searchEmptyAlrt2);
	 lastName.focus();
	 return false;
	 valid=false;
	}//end of if

	if(
	(clubCardId.value.length==0 ) &&
	(phone.value.length==0 )      &&
	(emailId.value.length==0)    &&
	(lastName.value.length==0)
	){
	 alert(searchEmptyAlrt1);
	 clubCardId.focus();
	 return false;
	 valid=false;
	} //end of if
	
 if(validateName(firstName,firstNameErrMsg)&&validateAlphabetic(mI,mIErrMsg)&&validateAlphaNumericSpaceDot(city,cityErrMsg)&&validateState(form,state)&&validateZip(form,zip)){
 	return true;
 }// end of validate all fields
 return false;
//}
}// end of function


//******************validateAlphaNumeric***************************************
//Description	:This function validates the field for alphanumeric
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateAlphaNumeric(objField,errMsg){
	if(checkAlphaNumeric(objField,true)){
		return true;
	}// end of if 
	else {	
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
	}// end of else
}// end of validatealphanumeric

//******************validateAlphaNumericSpaceDot***************************************
//Description	:This function validates the field for alphanumeric
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateAlphaNumericSpaceDot(objField,errMsg){
	if(checkAlphaNumericSpaceDot(objField,true)){
		return true;
	}// end of if 
	else {	
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
	}// end of else
}// end of validatealphanumeric

//******************validateAlphabetic***************************************
//Description	:This function validates the field for alphanumeric
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateAlphabetic(objField,errMsg){
	if(checkAlphabetic(objField,true)){
		return true;
	}// end of if 
	else {	
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
	}// end of else
}// end of validatealphanumeric

//******************validateNumeric********************************************
//Description	:This function validates the field for numeric
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateNumeric(objField,errMsg){
	if(checkNumeric(objField,true)){
		return true;
	}// end of if 
	else {
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
	}// end of else
}// end of validate numeric

//******************validateName***********************************************
//Description	:This function validates the field for alphanumeric with quotes
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateName(Name,errMsg){
		if(checkAlphabeticSpaceQuote(Name,true)){
		return true;
	}// end of if 
	else {
		alert(errMsg);
		Name.focus();
		Name.select();
		return false;
	}// end of else
}// end of validateName

//******************resetingForm***********************************************
//Description	:This function resets the form
//Parameter	:form
//return	:boolean
//*****************************************************************************
function resetingForm(form){
	form.clubCardId.value="";
	form.phone.value="";
  	form.campaignNumber.value="";
  	form.emailId.value="";
	form.firstName.value="";
	form.lastName.value="";
	form.mI.value="";
	form.city.value="";
	form.state.value="";
	form.postalCode.value="";
	form.clubCardId.focus();
	form.exactSearch.checked=false;
	return true;
}// end of function
//******************exactSearch************************************************
//Description	:This function sets the  value  for checkbox
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************
function exactSearching(form){
	if(form.exactSearch.checked){
		form.exactSearch.value=true;
}else 
	form.exactSearch.value=false;
}// end of function

function loggingOut(form,actionValue){
form.action.value=actionValue;
form.submit();
return true;
}



function validateState(form,objField){
	if(!form.exactSearch.checked){
		if(!checkAlphabetic(objField,true)){
			alert(stateErrMsg);
			objField.focus();
			objField.select();
			return false;
			}else{		
				return true;
				}
	}
	if(!checkStateProvCd(objField,true)){
		return false;
	}
	else return true;
}

function validateZip(form,objField){
	
	if(!form.exactSearch.checked){
		
		if(!checkAlphaNumericSpace(objField,true)){
			alert(postalCodeErrMsg);
			objField.focus();
			objField.select();
			return false;
			}else{		
				return true;
				}
	}
	if(!checkPostalCd(objField,true)){
		return false;
		
	}
	else return true;	
	
}

//**************************************end of file*****************************