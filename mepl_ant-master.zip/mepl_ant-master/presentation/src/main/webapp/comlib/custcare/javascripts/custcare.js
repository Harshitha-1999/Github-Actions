function storeInfo(facility) {
	workHistory = window.open("store_info.jsp?facility=" + facility, "storeInfo", "height=500,width=650,left=200,top=100,scrollbars=yes,toolbar=no,status=no,resizeable=no");
	window.storeInfo.focus();
	}
