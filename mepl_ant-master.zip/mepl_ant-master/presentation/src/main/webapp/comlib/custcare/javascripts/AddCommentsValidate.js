/*************************************************************************************************
Project Name			  	:SAFEWAY                 
Module Name	   		      	:AddComments
Relevant Spec				:AddComments_Spec Ver 100.rtf	  	  	  
Program Name			      	:AddCommentsValidate.js
Program Version				:1.0.0
Program Description			:js for validation.
Called From					:AddComments.jsp	
Calling						:None       
Modification History 		        :         
------------------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		ModificatioDetails  				Change RequestReference in the code.	
  
  Nirmala Jeyaprakash    08/23/2000			1.0.0		NA
  Veena			 09/12/2000			1.1.0		done date formatting 	CHG-009
								
 			
------------------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************/
//Help messages
var cmmtStatusMsg="Select the comment status.";
var cmmtTypeMsg="Select the comment type.";
var categoryMsg="Select the category.";
var locationMsg="Select the location.";
var commentMsg="Select the comment.";
var historyMsg="Enter the work history.";
var newCommentDescMsg="Enter the comment description.";
var oldCommentDescMsg="Edit the comment description.";
var saveMsg="Click to save the comment";
var saveCallMsg="Click this to save the comment and change the comment status to call";
var cancelMsg="Click this to go back to the Edit Comment Card Screen";
var resetMsg="Click this to reset the screen";

//Error messages
var commentDescErrMsg="Please enter Comment description." ;
var commentDescErrMsg1="Comment Description should be less than 255.";
var historyErrMsg="History should be less than 255.";
var statusErrMsg="Either change any of these - Comment Status, Comment Type, Category, Location, Comment, or Comment Description \n\n\t\t\t or \n\n\t\t Enter the Work History."
var commentErrMsg="Please do not enter { or }";
/***************************getMessage*********************************** 
This function is to display a help message in the status bar
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/

function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;
     lastField=lsf.name;
}

function saveScreen(actionValue){          
		var allValid=true;
		workHistory=document.AddComment.tempWorkHistory;	
		tempCommentDesc=document.AddComment.tempCommentDesc;
		cmmtDesc=document.AddComment.cmmtDesc;
		newCommentFlag=document.AddComment.newComment.value; 
		if(newCommentFlag=="true"){
			if(tempCommentDesc.value.length==0){			
		 		alert(commentDescErrMsg);  
				document.AddComment.tempCommentDesc.focus();
				document.AddComment.tempCommentDesc.select();
				allValid=false;
				return false;
			}
			strToChk=tempCommentDesc.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       tempCommentDesc.focus();
                       tempCommentDesc.select();
                       return false;
                       }
			strToChk=workHistory.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       workHistory.focus();
                       workHistory.select();
                       return false;
                	} 
		}
		else if(newCommentFlag=="false"){
			workHistory=document.AddComment.tempWorkHistory;		
			//hisCount=document.AddComment.noOfHistory.value;
			hdnCmmtTypeId=document.AddComment.hdnCmmtTypeId.value;
			hdnCmmtStatusId=document.AddComment.hdnCmmtStatusId.value;  
			hdnCmmtCategoryId=document.AddComment.cmmt.options[document.AddComment.cmmt.selectedIndex].value;
			hdnLocationId=document.AddComment.hdnLocationId.value;  
			hdnCmmtListId=document.AddComment.hdnCmmtListId.value;
			if((hdnCmmtCategoryId==document.AddComment.cat.options[document.AddComment.cat.selectedIndex].value)&&
				(hdnLocationId==document.AddComment.loc.options[document.AddComment.loc.selectedIndex].value)&&
				(hdnCmmtListId==document.AddComment.cmmt.options[document.AddComment.cmmt.selectedIndex].value)&&
				(hdnCmmtStatusId==document.AddComment.cmmtStatusId.options[document.AddComment.cmmtStatusId.selectedIndex].value)&&
				(hdnCmmtTypeId==document.AddComment.cmmtTypeId.options[document.AddComment.cmmtTypeId.selectedIndex].value)&&
				(tempCommentDesc.value==cmmtDesc.value)&&
				(workHistory.value.length==0))
				{
				alert(statusErrMsg);
				document.AddComment.cmmtStatusId.focus();
				allValid=false;
			}
			strToChk=tempCommentDesc.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       tempCommentDesc.focus();
                       tempCommentDesc.select();
                       return false;
                       }
			strToChk=workHistory.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       workHistory.focus();
                       workHistory.select();
                       return false;
                       }  
		}
	if (document.AddComment.cmmtTypeId.options[document.AddComment.cmmtTypeId.selectedIndex].value == "") {
		alert(cmmtTypeMsg);
		document.AddComment.cmmtTypdId.focus();
		return false;
	}
	if (document.AddComment.cat.options[document.AddComment.cat.selectedIndex].value == "") {
		alert(categoryMsg);
		return false;
	}
	if (document.AddComment.loc.options[document.AddComment.loc.selectedIndex].value == "") {
		alert(locationMsg);
		return false;
	}
	if (document.AddComment.cmmt.options[document.AddComment.cmmt.selectedIndex].value == "") {
		alert(commentMsg);
		return false;
	}
	
	if(allValid){
	document.AddComment.cmmtCategoryId.value=document.AddComment.cat.options[document.AddComment.cat.selectedIndex].value;
	document.AddComment.locationDesc.value=document.AddComment.newLocationDsc.value;
	document.AddComment.commentListDesc.value=document.AddComment.newCommentDsc.value;
	document.AddComment.action.value=actionValue;
	replacingTheBlankLinesEncoding(document.AddComment.tempCommentDesc,document.AddComment.commentDesc);
	replacingTheBlankLinesEncoding(document.AddComment.tempWorkHistory,document.AddComment.workHistory);
	document.AddComment.submit();
	}  
		  
}

function saveCallScreen(actionValue,selCallIndex){          
		var allValid=true;
		workHistory=document.AddComment.tempWorkHistory;	
		commentDesc=document.AddComment.tempCommentDesc;
		newCommentFlag=document.AddComment.newComment.value; 
		if(newCommentFlag=="true"){
			if(commentDesc.value.length==0){			
		 		alert(commentDescErrMsg);  
				document.AddComment.tempCommentDesc.focus();
				document.AddComment.tempCommentDesc.select();
				allValid=false;
				return false;
			}
			strToChk=commentDesc.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       commentDesc.focus();
                       commentDesc.select();
                       return false;
                       }
			strToChk=workHistory.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       workHistory.focus();
                       workHistory.select();
                       return false;
                	} 
		}
		else if(newCommentFlag=="false"){
			
			workHistory=document.AddComment.tempWorkHistory;
			strToChk=commentDesc.value;
                       if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
                       alert(commentErrMsg);
                       commentDesc.focus();
                       commentDesc.select();
                       return false;
                	}
                	strToChk=workHistory.value;
						if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
							alert(commentErrMsg);
							workHistory.focus();
							workHistory.select();
							return false;
						}
		}    

	if (document.AddComment.cmmtTypeId.options[document.AddComment.cmmtTypeId.selectedIndex].value == "") {
		alert(cmmtTypeMsg);
		return false;
	}
	if (document.AddComment.cat.options[document.AddComment.cat.selectedIndex].value == "") {
		alert(categoryMsg);
		return false;
	}
	if (document.AddComment.loc.options[document.AddComment.loc.selectedIndex].value == "") {
		alert(locationMsg);
		return false;
	}
	if (document.AddComment.cmmt.options[document.AddComment.cmmt.selectedIndex].value == "") {
		alert(commentMsg);
		return false;
	}
	
	if (allValid){
		document.AddComment.cmmtCategoryId.value=document.AddComment.cat.options[document.AddComment.cat.selectedIndex].value;
		document.AddComment.locationDesc.value=document.AddComment.newLocationDsc.value;
		document.AddComment.commentListDesc.value=document.AddComment.newCommentDsc.value;
		document.AddComment.cmmtStatusId.selectedIndex=selCallIndex;
		document.AddComment.action.value=actionValue;
		replacingTheBlankLinesEncoding(document.AddComment.tempCommentDesc,document.AddComment.commentDesc);
		replacingTheBlankLinesEncoding(document.AddComment.tempWorkHistory,document.AddComment.workHistory);
		document.AddComment.submit();
	}  
		  
}

//This function is to clear the screen on reset.

function clearScreen(form) {
	form.tempCommentDesc.value="";
	form.cmmtStatusId.selectedIndex=0;  
 	form.cmmtTypeId.selectedIndex=0;
 	form.cat.selectedIndex=0;
 	form.tempWorkHistory.value="";
 	changeCat();
 	if (document.AddComment.newComment.value=="false")document.AddComment.tempWorkHistory.value="";		
	 	form.cmmtStatusId.focus();
}

//***************************onlySubmit*****************************************
// This function submits the Screen.
// Parameter :actionValue
//************************************************************************
function onlySubmit(actionValue){
	document.AddComment.action.value=actionValue;
	document.AddComment.submit();
}

//This function is to replace the blank lines encoding.
function replacingTheBlankLinesEncoding(field1,field2){
	var fieldValue=field1.value;
	var fieldValueLength=fieldValue.length;
	var tempString='';
	for( i=0;i<fieldValueLength;i++){	 
		if((fieldValue.charCodeAt(i)==13)&&(fieldValue.charCodeAt(i+1)==10)){
			tempString=tempString+'^';
		} else {
			if(fieldValue.charCodeAt(i)==10){
				tempString=tempString; 
			} else {
				tempString=tempString+fieldValue.charAt(i);
			}
		}
	}// end of for 

// dhorn00 - something is wrong here.
//	if (field2) {
		field2.value=tempString;
//	}
}

function backCheck(){
	history[-1]='';
}

//*****************************checkResolve*****************************************
// This function validates whether the card status and comment status are 'Ready for call'
// It is called by Resolve Link.
//******************************************************************************************
function checkResolve(){
	var status=document.AddComment.resolveStatus.value;
	if (status=="false"){
		alert("Either 'Comment Status' or 'Product Request Status' are not 'Ready for Call'. The Contact cannot be resolved.");
		return false;
	}
	return true;
}

