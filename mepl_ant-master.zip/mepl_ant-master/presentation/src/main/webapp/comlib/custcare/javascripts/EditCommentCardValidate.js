/*************************************************************************************************
Project Name			  	:SAFEWAY                 
Module Name	   		      	:EditComments
Relevant Spec				:EditCommentCard_Spec100.rtf	  	  	  
Program Name				:EditCommentCardValidate.js
Program Version				:1.0.0
Program Description			:js for validation.
Called From				:EditCommentCardNewCommentCard.jsp	
Calling					:None       
Modification History 		        :       
------------------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		ModificatioDetails  				Change RequestReference in the code.	
  
  Nirmala Jeyaprakash    08/18/2000			1.0.0		NA	
  Nirmala Jeyaprakash    09/12/2000			1.1.0		done date formatting 	CHG-008
  Cyril			 09/30/200			1.2.0		Added new method checkResolve()	
------------------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************/

//Help messages
var cardStatusMsg="Select the contact status";
var cardSourceMsg="Select the contact source.";
var submittedDateMsg="Enter the date submitted.";
var divisionMsg="Select the division.";
var facilityMsg="Select the appropriate facility.";
var questionMsg="Select the response.";
var remarksMsg="Enter the remarks.";
var emailIdMsg="Enter the email id.";
var addressMsg="Enter the address.";
var cityMsg="Enter the city.";
var stateMsg="Enter the state.";
var zipMsg="Enter the zip code.";
var areaCodeMsg="Enter the area code.";
var cardSource;  
var answerId;  
var phoneHelpMsg="Enter the phone number.";
//Error messages
var cardStatusErrMsg="Please select the Contact Status.";
var submittedDateErrMsg="Please enter the Date Submitted.";
var submittedDateFormatErrMsg="Please enter the Date Submitted in mmddyy or mmddyyyy format.";
var divisionErrMsg="Please select the  Division.";
var facilityErrMsg="Please enter the Facility ID.";
var facilityErrMsg1="Invalid Facility ID. Please enter a valid Facility ID.";
var facilityFormatErrMsg="Selected Division does not contain Facility.";
var questionErrMsg="Please select the Response.";
var remarksErrorMsg="Please enter the Remarks.";
var remarksErrMsg="Remarks should be less than 255 characters";
var emailIdErrMsg="Please enter the Email Id.";
var emailIdErrMsg1="Incorrect format. Email ID should be alphanumeric and the format should be 'yourMailID@yourmailserver.com'.";
var addressErrMsg="Please enter the Address.";
var cityErrMsg="Please enter the City.";
var stateErrMsg="Please enter the State.";
var zipErrMsg="Please enter the Zip Code.";
var zipErrMsg1="Zip Code should be alphanumeric.";
var phoneErrMsg='Incorrect format. Please enter a ten digit Phone Number.';
var cityErrMsg2="Incorrect format. City should be alphanumeric.";
var stateErrMsg2="Incorrect format. State should be alphanumeric.";
var lastField;
var remarksErrMsg2='Please enter the Remarks.';  
var commentErrMsg="Please do not enter { or } or ^ or ' or \"";
/***************************getMessage*********************************** 
This function is to display a help message in the status bar
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/

function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;
     lastField=lsf.name;
}


//***************************reFocus**************************************
//This function is to remove the focus from a read only field
//Parameters : currentField,previousField,NextField
//Returns    : Void
//************************************************************************
function reFocus(thisField,prevField,nextField){
  if(lastField!=nextField.name)
  {
    nextField.focus();
  }
  else {
     if(lastField!=prevField.name)
        prevField.focus();   
    }
}


//***************************check phone*****************************************
// This function is to check for the phone number validation
//********************************************************************************
function validatePhoneNumber(form,phone){
	/*if(( (isEmpty(phone.value)) && (isEmpty(phone1.value)) && (isEmpty(phone2.value)) )){
  			return true;
  		} 
  		*/
	if(isEmpty(phone.value)){
		return true;
	}//end of if 
	
	//check whether the phone number is numeric and length equals to 10 digits
	if(!isNumeric(phone.value) || phone.value.length != 10 ){
		alert(phoneErrMsg);
		phone.focus();
		phone.select();
		return false;
		
	}else{
		form.areaCode.value=phone.value.substring(0,3);
		form.phone1.value=phone.value.substring(3,6);
		form.phone2.value=phone.value.substring(6,10);
		return true;		
	}//end of if-else
	
}  // end of validate phone

//*****************************validateEmailId*********************************
//Description	:This function validates emailid for correct emailformat
//Parameters	:form,emailId
//returns	:boolean
//*****************************************************************************
function validateEmailId(form,emailId){
			
	if(validateEmail(emailId)){
		//form.submit();
		return true;		
	} // end of if
	else {
		
		alert(emailIdErrMsg1);
		emailId.focus();
		emailId.select();
		return false;
	} // end of else
}// end of validateEmailId

//***************************saveValidate*****************************************
// This funstion validates the CommentCard Screen.
// Parameter  :actionValue
// Returns   :boolean.
//************************************************************************
function saveValidate(actionValue,cardNumber)
{
	
	address=document.EditCommentCard.address;
	addressExtn=document.EditCommentCard.addressExtn;
	city=document.EditCommentCard.city;
	state=document.EditCommentCard.state;
	zip=document.EditCommentCard.postalCode;
	phone=document.EditCommentCard.phone;
	facility=document.EditCommentCard.facility;
	remarks=document.EditCommentCard.tempRemarks;
	tempRemarks=document.EditCommentCard.tempRemarks;
	submittedDate=document.EditCommentCard.submittedDate;
	submittedDateMM=document.EditCommentCard.submittedDateMM;
	submittedDateDD=document.EditCommentCard.submittedDateDD;
	submittedDateYY=document.EditCommentCard.submittedDateYY;
	
	cardStatus=document.EditCommentCard.cardStatus;
	var allValid=true;
	var custType=document.EditCommentCard.custType.value;
	var needsUpdt=document.EditCommentCard.needsUpdate.value;
	if ((custType=="C")&&(needsUpdt=="Y")) {
		emailId=document.EditCommentCard.emailId;
		if(isEmpty(emailId.value)){
	    	   alert(emailIdErrMsg);
	    	   emailId.focus();
	    	   emailId.select();
	    	   allValid=false;
	 	   return false;
		}
		if(!validateEmailId(document.EditCommentCard,emailId))
		{	emailId.focus();
	    		emailId.select();
	    		allValid=false;
	    		return false;
		}
		if(isEmpty(address.value)){
	    		alert(addressErrMsg);
	    		address.focus();
	    		address.select();
	    		allValid=false;
	    		return false;
		}
		strToChk=address.value;
  		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)||(strToChk.indexOf("\'",0) != -1)||(strToChk.indexOf("\"",0) != -1)){
            		alert(commentErrMsg);
            		address.focus();
        		address.select();
                	return false;
        	}
		strToChk=addressExtn.value;
		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)||(strToChk.indexOf("\'",0) != -1)||(strToChk.indexOf("\"",0) != -1)){
            		alert(commentErrMsg);
            		addressExtn.focus();
        		addressExtn.select();
                	return false;
        	}
		if(isEmpty(city.value)){
	    		alert(cityErrMsg);
	    		city.focus();
	    		city.select();
	    		allValid=false;
	    		return false;
		}
		
		
		if(!checkAlphaNumericSpace(city,false)){
		alert(cityErrMsg2);
		city.focus();
		city.select();
		allValid=false;
		return false;
		}// end of else
		
		if(isEmpty(state.value)){
	    		alert(stateErrMsg);
	    		state.focus();
	    		state.select();
	    		allValid=false;
	    		return false;
		}
		   
		if(!checkStateProvCd(state,true)){
			allValid=false;
			return false;
		}
		
		if(isEmpty(zip.value)){
	    		alert(zipErrMsg);
	    		zip.focus();
	    		zip.select();
	    		allValid=false;
	    		return false;
		}
		 
		if(!checkPostalCd(zip,true)){
			allValid=false;
			return false;		
		}
		
		if(!phoneValidating(document.EditCommentCard,phone)){
			allValid=false;
			return false;
		
		}
		/**if(!checkAlphaNumeric(zip,false)){
	    		alert(zipErrMsg1);
	    		zip.focus();
	    		zip.select();
	    		allValid=false;
	    		return false;
		}**/
			
		
	}
	
			
	
 	 if(!validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){
		allValid=false;
    		return false;
  	}
  	
  	
  	if(!validateFacility(form)){
  		allValid=false;
    		return false;
  	}
  		
  	
  	/**if(! checkFacility(form)){
    		allValid=false;
    		return false;
  	}
  	
  	if(remarks.value.length==0){
  		alert(remarksErrorMsg);
    		remarks.focus();
    		remarks.select();
    		allValid=false;
    		return false;
    		} */
  	
  	strToChk=tempRemarks.value;
  	if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
            	alert(commentErrMsg);
            	tempRemarks.focus();
        	tempRemarks.select();
                return false;
        }
/*	if(document.EditCommentCard.remarks.value.length > 255){  
		alert(remarksErrMsg);
		remarks.focus();
		remarks.select();
		allValid=false;
		return false;
	}      
*/
	if (!validateRemarks(tempRemarks)){
		allValid=false;
		return false;
	}
	
	var form=document.EditCommentCard;
	document.EditCommentCard.action.value=actionValue;
	document.EditCommentCard.cardId.value=cardNumber;
	replacingTheBlankLinesEncoding(document.EditCommentCard.tempRemarks,document.EditCommentCard.remarks)
		if(form.submittedDate.value != ""){
			var arrSubmittedDate=form.submittedDate.value.split("/");
			form.submittedDateMM.value=arrSubmittedDate[0];
			form.submittedDateDD.value=arrSubmittedDate[1];
			form.submittedDateYY.value=arrSubmittedDate[2];
		}
	
	document.EditCommentCard.submit();
}

//***************************saveResolveValidate*****************************************
// This funstion validates the CommentCard Screen.
// Parameter  :actionValue
// Returns   :boolean.
//************************************************************************
function saveResolveValidate(actionValue,cardNumber)
{
	if(window.confirm("Warning!! The card will be closed. Proceed with Resolve?")){
	//	emailId=document.EditCommentCard.emailId;
	address=document.EditCommentCard.address;
	addressExtn=document.EditCommentCard.addressExtn;
	city=document.EditCommentCard.city;
	state=document.EditCommentCard.state;
	zip=document.EditCommentCard.postalCode;
	phone=document.EditCommentCard.phone;
	facility=document.EditCommentCard.facility;
	remarks=document.EditCommentCard.tempRemarks;
	tempRemarks=document.EditCommentCard.tempRemarks;
	submittedDate=document.EditCommentCard.submittedDate;
	submittedDateMM=document.EditCommentCard.submittedDateMM;
	submittedDateDD=document.EditCommentCard.submittedDateDD;
	submittedDateYY=document.EditCommentCard.submittedDateYY;
	cardStatus=document.EditCommentCard.cardStatus;
	var allValid=true;
	var custType=document.EditCommentCard.custType.value;
	var needsUpdt=document.EditCommentCard.needsUpdate.value;
	if ((custType=="C")&&(needsUpdt=="Y")) {
		emailId=document.EditCommentCard.emailId;
		if(isEmpty(emailId.value)){
	    	   alert(emailIdErrMsg);
	    	   emailId.focus();
	    	   emailId.select();
	    	   allValid=false;
	 	   return false;
		}
		if(!validateEmailId(document.EditCommentCard,emailId))
		{	emailId.focus();
	    		emailId.select();
	    		allValid=false;
	    		return false;
		}
		
		if(isEmpty(address.value)){
	    		alert(addressErrMsg);
	    		address.focus();
	    		address.select();
	    		allValid=false;
	    		return false;
		}
		strToChk=address.value;
  		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
            		alert(commentErrMsg);
            		address.focus();
        		address.select();
                	return false;
        	}
		strToChk=addressExtn.value;
		if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
            		alert(commentErrMsg);
            		addressExtn.focus();
        		addressExtn.select();
                	return false;
        	}
		
		if(isEmpty(city.value)){
	    		alert(cityErrMsg);
	    		city.focus();
	    		city.select();
	    		allValid=false;
	    		return false;
		}
		
		
		if(!checkAlphaNumericSpace(city,false)){
		alert(cityErrMsg2);
		city.focus();
		city.select();
		allValid=false;
		return false;
		}// end of else
		
		
		if(isEmpty(state.value)){
	    		alert(stateErrMsg);
	    		state.focus();
	    		state.select();
	    		allValid=false;
	    		return false;
		}
		
		
		if(!checkStateProvCd(state,true)){
			allValid=false;
			return false;
		}
		
		if(isEmpty(zip.value)){
	    		alert(zipErrMsg);
	    		zip.focus();
	    		zip.select();
	    		allValid=false;
	    		return false;
		}
		if(!checkPostalCd(zip,true)){
			allValid=false;
			return false;
		
		}
		if(!phoneValidating(document.EditCommentCard,phone)){
			allValid=false;
			return false;
		
		}
			
		
	}
	
	
	if(!validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){
		allValid=false;
    		return false;
  	}		
	
 	 
  	
  	if(!validateFacility(form)){
  		allValid=false;
    		return false;
  	}
  	
  	/*if(isEmpty(facility.value)){
  		alert(facilityErrMsg);
    		facility.focus();
    		allValid=false;  
    		return false;
    		}*/
  		
  	
  	/**if(! checkFacility(form)){
    		allValid=false;
    		return false;
  	}
  	
  	if(remarks.value.length==0){
  		alert(remarksErrorMsg);
    		remarks.focus();
    		remarks.select();
    		allValid=false;
    		return false;
    		} */
  	
  	strToChk=tempRemarks.value;
  	if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
            	alert(commentErrMsg);
            	tempRemarks.focus();
        	tempRemarks.select();
                return false;
        }
/*	if(document.EditCommentCard.remarks.value.length > 255){  
		alert(remarksErrMsg);
		remarks.focus();
		remarks.select();
		allValid=false;
		return false;
	}
*/      
	if (!validateRemarks(tempRemarks)){
		allValid=false;
		return false;
	}
	
	var form=document.EditCommentCard;
	document.EditCommentCard.action.value=actionValue;
	document.EditCommentCard.cardId.value=cardNumber;
	replacingTheBlankLinesEncoding(document.EditCommentCard.tempRemarks,document.EditCommentCard.remarks)
		if(form.submittedDate.value != ""){
			var arrSubmittedDate=form.submittedDate.value.split("/");
			form.submittedDateMM.value=arrSubmittedDate[0];
			form.submittedDateDD.value=arrSubmittedDate[1];
			form.submittedDateYY.value=arrSubmittedDate[2];
		}
	
	document.EditCommentCard.submit();
	}
}
//***************************onlySubmit*****************************************
// This function submits the Screen.
// Parameter :actionValue
//************************************************************************
function onlySubmit(actionValue){
	document.EditCommentCard.action.value=actionValue;
	document.EditCommentCard.submit();
}
//***************************onlySubmit*****************************************
// This funstion gives info about store information.
//************************************************************************
function storeInfo()
{
	alert("Requested page currently under development");
}
//***************************listFill*****************************************
// This function is called on change of the division list box.
//************************************************************************
function listFill(){
	var lbx2=document.EditCommentCard.facility;
    	var lbx1=document.EditCommentCard.division;
    	var len=lbx2.options.length;
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	for(var k=0;k<len;k++)
		lbx2.options[k]=new Option();
	for(var i=0;i<arr2len;i++){
     		lbx2.options[i]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	lbx2.options.selectedIndex=0;
    	lbx2.options.length=arr2len;
}  

//***************************clearScreen*****************************************
// This function clears all the fields on reset.
//************************************************************************

function clearScreen(form,noneIndex)  
{
	if(form.needsUpdate.value!=null)
	{	var custType=form.custType.value;
		var needUpdt=form.needsUpdate.value;
			if(((needUpdt=="y")||(needUpdt=="Y"))&&((custType=="C")||(custType=="c"))){
			form.emailId.value="";				
			form.address.value="";
			form.addressExtn.value="";
			form.city.value="";
			form.state.value="";
			form.postalCode.value="";
			form.areaCode.value="";
			form.phone1.value="";
			form.phone2.value="";
			form.facility.value="";
			form.emailId.focus();
			form.remarks.value="";
		 	form.submittedDate.value="";
		 	form.cardStatus.selectedIndex=0;
		 	form.cardSource.selectedIndex=0;
		 	form.division.selectedIndex=0;
		 	var i=form.noOfQuestions.value;
		 	var strAnsNm="";
 			for (var j=0;j<i;j++)
 			{
 				strAnsNm=eval("form.answer"+(j+1));
 				strAnsNm.selectedIndex=noneIndex;
 			}

		 	
			}
		}
		form.tempRemarks.value="";
	 	form.submittedDate.value="";
	 	form.cardStatus.selectedIndex=0;
	 	form.cardSource.selectedIndex=0;
	 	form.division.selectedIndex=0;
	 	form.facility.value="";
	 	var i=form.noOfQuestions.value;
		var strAnsNm="";
 		for (var j=0;j<i;j++)
 		{
 			strAnsNm=eval("form.answer"+(j+1));
 			strAnsNm.selectedIndex=noneIndex;
 		}
	 	form.cardStatus.focus();
	 	

}

function isAlphaNumeric (s){
        return s.match(/^[a-z0-9]+$/gi)?s:false;
}

//*****************************validateRemarks*****************************************
// This function validates for remarks.
// It is called by validateotherields function.
//******************************************************************************************

function validateRemarks(objField){
var objFieldLength=objField.value.length;
var tempChar;
/*
if(objFieldLength > 255){  
	alert(remarksErrMsg);
	objField.focus();
	objField.select();
	return false;
}
*/  
return true;
}

function fieldFocus(){
	var custType=document.EditCommentCard.custType.value;
	if(document.EditCommentCard.needsUpdate.value!=null)
	{
		var needUpdt=document.EditCommentCard.needsUpdate.value;
		if(((needUpdt=="y") || (needUpdt=="Y"))&&(custType=="C"))
			document.EditCommentCard.emailId.focus();
		else
			document.EditCommentCard.cardStatus.focus();
	
	}
}


//******************validateAlphaNumericSpaceDot***************************************
//Description	:This function validates the field for alphanumeric
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validateAlphaNumericSpaceDot(objField,errMsg){
	if(checkAlphaNumericSpaceDot(objField,true)){
		return true;
	}// end of if 
	else {	
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
	}// end of else
}// end of validatealphanumeric

//*****************************validateDateSubmitted*****************************************
// This function validates for dates .
// It is called by validateotherields function.
//******************************************************************************************

function validateDateSubmitted(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY) {

	 if(!isEmpty(submittedDate.value)){    
	 	 if(!dateValidating(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){
		//	alert(submittedDateFormatErrMsg);
	    	//	submittedDate.focus();
	    	//	submittedDate.select(); 
	    		allValid=false;
	    		return false;
	  	}
	}
	else{
		alert(submittedDateErrMsg);  
		submittedDate.focus();
		submittedDate.select();
		allValid=false;  
		return false;
	}
	if(!isDate(submittedDate,0001,2000,0,31,true)){    
		allValid=false;
		return false;
	}
	return true;
		
}

/*
function checkFacility(form){
	var listBox2=document.EditCommentCard.facility;
    	var listBox1=document.EditCommentCard.division;
    	var ind1=0;
    	ind1=listBox1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	for(var i=0;i<arr2len;i++){
     		if(listBox2.value ==(listArr[ind1][i])){
     		return true;
     		}
     		else if(i==(arr2len-1)){
    		  return false;    		
    		}	
     	}
}  
****/

function validateFacility(form){
	var lbx2=document.EditCommentCard.facility;
        var lbx1=document.EditCommentCard.division;
    	
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	
    	if (arr2len==0){
    		alert(facilityFormatErrMsg);
    		lbx2.value="";
    		lbx1.focus();
    		return false;
    	}
    	if(lbx2.value.length==0){
    		alert(facilityErrMsg);
    		lbx2.focus();
    		return false;
    		
    		}  
    	
    	for(var i=0;i<arr2len;i++){
		if(lbx2.value ==(listArr[ind1][i])){
			return true;
     		//listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	else if(i==(arr2len-1)){
    		alert(facilityErrMsg1);
    		lbx2.focus();
    		lbx2.select();
    		return false;    		
    		}
    	
	}
}  

//*****************************validateRemarks*****************************************
// This function validates for remarks.
// It is called by validateotherields function.
//******************************************************************************************

function validateRemarks(objField){
var objFieldLength=objField.value.length;
var tempChar;
if(objFieldLength==0){
  alert(remarksErrMsg2);
  objField.focus();	
  return false;
}  
/*
if(objFieldLength > 255){  
	alert(remarksErrMsg);       
	objField.focus();
	objField.select();
	return false;
}
*/  
return true;
}

//*****************************checkResolve*****************************************
// This function validates whether the card status and comment status are 'Ready for call'
// It is called by Resolve Link.
//******************************************************************************************
function checkResolve(){
	var status=document.EditCommentCard.resolveStatus.value;
	if(status=="false"){
	alert("Either 'Comment Status' or 'Product Request Status' are not 'Ready for Call'. The Contact cannot be resolved.");
	return false;
	}
	
return true;
}
