/*************************************************************************************************
Project Name			  	:SAFEWAY                 
Module Name	   		      	:CommentCard
Relevant Spec				:ClubCustNewCommentCard Ver 110.rtf	  	  	  
Program Name				:CommentCardDetails.js
Program Version				:1.1.0
Program Description			:js for validation.
Called From				:ClubCustNewCommentCard.jsp	
Calling					:None       
Modification History 		        :       
------------------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		ModificatioDetails  				Change RequestReference in the code.	
------------------------------------------------------------------------------------------------------------------------------------------
  Nirmala               07/25/2000			1.0.0		NA				 		NA
  Nirmala		08/08/2000			1.1.0		The script function for the 			
  									dynamic population of list box 
  									is included
  									The Id 's for all the fields are included.	CHG-001
  Nirmala		09/12/2000			1.1.1		done date formatting 				CHG-006												  																	
------------------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************/

//Help messages
var cardSourceMsg="Select the contact type.";
var submittedDateMsg="Enter the date submitted.";
var divisionMsg="Select the division.";
var facilityMsg="Select the appropriate facility.";
var questionMsg="Select the response.";
var answerMsg="Select the answer.";
var remarksMsg="Enter the remarks.";
var needsUpdateMsg="Select if customer info needs update."  
var saveMsg="Click for saving the details.";
var saveEditMsg="Click for saving/editing the details.";
var cancelMsg="Click for cancelling card.";
var resetMsg="Click for resetting the page.";
var cardSource;  
var answerId;   
//Error messages
var cardSourceErrMsg="Please select the Contact Type.";
var submittedDateErrMsg1="Please enter the Date Submitted.";
var submittedDateErrMsg2="Please enter the Date Submitted in mmddyy or mmddyyyy format.";
var divisionErrMsg="Please select the  Division.";
var facilityErrMsg=" Please enter the Facility ID.";
var facilityErrMsg1="Invalid Facility ID. Please enter a valid ID.";
var facilityFormatErrMsg="Selected Division does not contain Facility.";
var questionErrMsg="Please select the Response.";
var remarksErrMsg="Remarks should be populated";
var remarksErrMsg1="Please enter Remarks.";
var commentErrMsg="Please do not enter { or } or ^ ";

/***************************getMessage***********************************
This function is to display a help message in the status bar
Parameters : currentField,HelpMessage
Returns    : Void
************************************************************************/

function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;
}

// **********************************isEmpty()**************************************************
// This function checks whether the field value is null.
// parameter: variable s
// returns boolean
//***********************************************************************************************
 
function isEmpty(s){
   return ((s == null) || (s.length == 0))?true:false;

}

//// **********************************isWhitespace()**************************************************
// This function checks whether the field value has any leading and trailing white spaces.
// parameter: variable s
// returns boolean
//***********************************************************************************************

function isWhitespace(s){
        return s.match(/^\s*$/)?true:false;
}

function trim(s, trimSpec){
       var patt_all = /\s*/gi;
        var patt_lead = /^\s+/i;
        var patt_trail = /\s+$/i;

       if(trimSpec == "all")
                return s.replace(patt_all,"");
        if(trimSpec == "lead")
                return s.replace(patt_lead,"");
        if(trimSpec == "trail")
                return s.replace(patt_trail,"");
        //s= s.replace(patt_lead,"");
        //return s.replace(patt_trail,"");
}

//***************************trimZeroes*****************************************
//This function will trim the extra zeros
//Returns    : boolean 
//******************************************************************************/
function trimZeroes(Str){
      StrVal=Str.value; 
	if((StrVal != "") && (StrVal.indexOf("0",0)!=-1)){
		var iMax = StrVal.length;
		var end = StrVal.length;
		var c;
		for(i=0;i<iMax;i++){
                if(StrVal.substring(i,i+1)!= "0")
                   break
            }//for   
            if(end!=i){
                iMax = StrVal.length;
                end = StrVal.length;
                for(i=0;1<iMax;i++){
                    c = StrVal.substring(0,1);
      			if (c == "0"){
                           StrVal=StrVal.substring(1,end);
	                     end = StrVal.length;

      			}//if
	      		else
		               break;
                }//for
                Str.value=StrVal;
            }//if
            else 
                Str.value="0";
       }//if
 return;
}//funn
//***************************trimZeroes*****************************************
//Integer function (by passing values) will trim the extra zeros
//Returns    : boolean 
//******************************************************************************/
function trimZeroesValue(StrVal){
	if((StrVal != "") && (StrVal.indexOf("0",0)!=-1)){
		var iMax = StrVal.length;
		var end = StrVal.length;
		var c;
		for(i=0;i<iMax;i++){
                if(StrVal.substring(i,i+1)!= "0")
                   break
            }//for   
            if(end!=i){
                iMax = StrVal.length;
                end = StrVal.length;
                for(var i=0;1<iMax;i++){
                    c = StrVal.substring(0,1);
      			if (c == "0"){
                           StrVal=StrVal.substring(1,end);
	                     end = StrVal.length;
       			}//if
	      		else
				   break;
                }//for
            }//if
            else 
                StrVal="0";
       }//if
return StrVal;
}//end of fn
//***************************validateDateMsg********************************
//This function is to check if the date passed is valid.
//Parameters : formName,Monthfield,dayField,YearField
//Returns    : boolean
//************************************************************************
function validateDateMsg(formName,inMonth,inDay,inYear,errMsg){
	   
	   if((inMonth.value.length==0)&&
         (inDay.value.length==0)&&
         (inYear.value.length==0)){
//         The control has come that means it is a non mandatory blank        
//         date field.So just return back without validating;
           return true;
      }//end of if 
      else if((inMonth.value.length==0)||
      			(inDay.value.length==0)||
      			(inYear.value.length==0))   
      {
      
        alert(submittedDateErrMsg2);
       inMonth.focus();
       inMonth.select();
       return false;
       }
	//Trimming the leading zeroes in the values entered in the date field
      var month = trimZeroesValue(inMonth.value);
    	var day = trimZeroesValue(inDay.value);
  	if (inYear.value.length == 4){
		if (parseInt(inYear.value) == 0){
           alert(submittedDateErrMsg2);
        inYear.focus();
 	     inYear.select();
 	     return false;
		}
	}
	var year = trimZeroesValue(inYear.value);
      if(!validMonth(parseInt(month))){
       alert(submittedDateErrMsg2);
       inMonth.focus();
       inMonth.select();
       return false;
      } 
      if(!validYear((year))){
       alert(submittedDateErrMsg2);
       inYear.focus();
       inYear.select();
       return false;
      }
      if(!validDay(parseInt(day),parseInt(month),parseInt(year))){
        alert(submittedDateErrMsg2);
        inDay.focus();
        inDay.select();
        return false;
      }
      return true;
}//end of the function checkDate
function validMonth(MM){
      if(MM<1||MM>12){
      return false;
      }
      else{
        return true   
      }
}
function validYear(YY){
 if ( YY.length == 4 )YY = YY.substring(2,4);
 if(parseInt(YY)<0||parseInt(YY)>99)
      return false;
 else 
        return true;
}
function validDay(dd,mm,yy){
      if(dd<1||dd>31){
       return false;
}
      if((mm==1||mm==3||mm==5||mm==7||mm==8||mm==10||mm==12)&&(dd>31)){
      return false;
}
      if((mm==4||mm==6||mm==9||mm==11)&&(dd>30)){
        return false;
}
      if((mm==2)&&!(leapYear(yy))&&(dd>28)){
      return false;
}
      if((mm==2)&&(leapYear(yy))&&(dd>29)){
      return false;
}
      return true
}
function leapYear(yy){
//y2k not compliant!!!!!!!!Take care of century later
      if(!(yy%4==0)){
          return false;
}
      if((yy%100==0) && (yy%400!=0)){
          return false;
}
      return true;
}
//***************************isNum*****************************************
// Check whether the value is a number.
// Parameter :The form field.
// Returns   :Boolean.
//************************************************************************
function isNum(formField){
  lenField=formField.value.length;
  if(lenField != 0){
       for(i=0;i<lenField;i++){
        x=formField.value.charAt(i);
        if((x<'0') || (x>'9')) return false;
     }//end of for
  }//end of if
  //window.status=''; 
  return true;
}//end of checkNum
//***************************date2DigitFormat*****************************************
// Check whether the field is in the required format.
// Parameter :The form field.
// Returns   :Boolean.
//************************************************************************
function date2DigitFormat(formField) {
	var trimmedField = '';	
	//trim(formField);
	if (isNum(formField)&&(formField.value.length == 1) ) {
			trimmedField = '0' + formField.value;
			formField.value = trimmedField;
						
	}
}  
//***************************date4DigitFormat*****************************************
// Check whether the field is in the required format.
// Parameter :The form field.
// Returns   :Boolean.
//************************************************************************
function date4DigitFormat(formField) {
	var trimmedField = '';
	trim(formField);
	if ( isNum(formField) && formField.value.length <= 4 ) {
		if ( formField.value.length == 1 ) {
			trimmedField = '200' + formField.value;
			formField.value = trimmedField;
		}
		else if ( formField.value.length == 2 ) {
			trimmedField = '20' + formField.value;
			formField.value = trimmedField;
		}
	}
}
//***************************saveValidate*****************************************
// This funstion validates the CommentCard Screen.
// Parameter  :actionValue
// Returns   :boolean.
//************************************************************************
function saveValidate(actionValue)
{
	
	division=document.ClubCust.division;
	//facility=document.ClubCust.facility;
	//cardSource=document.ClubCust.cardSource;
	tempRemarks=document.ClubCust.tempRemarks;
	remarks=document.ClubCust.remarks;
	submittedDate=document.ClubCust.submittedDate;
	submittedDateMM=document.ClubCust.submittedDateMM;
	submittedDateDD=document.ClubCust.submittedDateDD;
	submittedDateYY=document.ClubCust.submittedDateYY;
	facility=document.ClubCust.facility;
	var allValid=true;
	/**
	if(isEmpty(cardSource)){
    		alert(cardSourceErrMsg);
    		cardSource.focus();
    		cardSource.select();
    		allValid=false;
    		return false;
  	}
	else*/
	
	 if(isEmpty(submittedDate.value)){
    		alert(submittedDateErrMsg1);
    		submittedDate.focus();
    		submittedDate.select();
    		allValid=false;
    		return false;
	}
 	 if(!dateValidating(submittedDate,submittedDateMM,submittedDateDD,submittedDateYY)){
		//    alert(submittedDateErrMsg2);
    		//submittedDate.focus();
    		//submittedDate.select(); 
    		allValid=false;
    		return false;
  	}
  	if(!isDate(submittedDate,0001,2000,0,31,true)){    
		allValid=false;
		return false;
	}
	if (division.selectedIndex==0){
		alert(divisionErrMsg);
		division.focus();
		allValid=false;
		return false;
	}
	
	/**if(! checkFacility(document.ClubCust)){
  		alert(facilityErrMsg);
    		facility.focus();
    		facility.select();  		
  		allValid=false;
    		return false;
  		}**/
  	if (!validateFacility()){
  		allValid=false;
  		return false;
  	}
  	strToChk=tempRemarks.value;
        if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)||(strToChk.indexOf("^",0) != -1)){
              alert(commentErrMsg);
              tempRemarks.focus();
              tempRemarks.select();
              allValid=false;
              return false;
        } 
/*	
	if(document.ClubCust.remarks.value.length > 255){
	alert(remarksErrMsg);
	remarks.focus();
	remarks.select();
	allValid=false;
	return false;
	}
*/
	if(document.ClubCust.needsUpdate.checked){
		document.ClubCust.needsUpdate.value=true;
	}else
		document.ClubCust.needsUpdate.value=false;
	
	if (!validateRemarks(tempRemarks)){
		allValid=false;
		return false;
	}
		
	if(allValid){
		var form=document.ClubCust;
		document.ClubCust.action.value=actionValue;
		replacingTheBlankLinesEncoding(document.ClubCust.tempRemarks,document.ClubCust.remarks)
		if(form.submittedDate.value != ""){
			var arrSubDt=form.submittedDate.value.split("/");
			form.submittedDateMM.value=arrSubDt[0];
			form.submittedDateDD.value=arrSubDt[1];
			form.submittedDateYY.value=arrSubDt[2];
		}
		document.ClubCust.submit();
  	}
}
//***************************onlySubmit*****************************************
// This function submits the Screen.
// Parameter :actionValue
//************************************************************************
function onlySubmit(actionValue){
	document.ClubCust.action.value=actionValue;
	document.ClubCust.submit();
}
//***************************onlySubmit*****************************************
// This funstion gives info about store information.
//************************************************************************
function storeInfo()
{
	alert("Requested page currently under development");
}
//***************************onlySubmit*****************************************
// This function is called on change of the division list box.
//************************************************************************
function listFill(){
	var lbx2=document.ClubCust.facility;
    	var lbx1=document.ClubCust.division;
    	var len=lbx2.options.length;
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	for(var k=0;k<len;k++)
		lbx2.options[k]=new Option();
	for(var i=0;i<arr2len;i++){
     		lbx2.options[i]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	lbx2.options.selectedIndex=0;
    	lbx2.options.length=arr2len;
}   

function clearScreen(form,dateStr,noneIndex)            
{
	form.tempRemarks.value="";
	//form.submittedDate.value="0"+dateStr;
	form.submittedDate.value=dateStr;
 	form.cardSource.selectedIndex=1;
 	form.division.selectedIndex=0;
 	form.facility.value='';
 	form.needsUpdate.checked=false;
 	var i=form.noOfQuestions.value;
 	var strAnsNm="";
 	for (var j=0;j<i;j++)
 	{
 		strAnsNm=eval("form.answer"+(j+1));
 		strAnsNm.selectedIndex=noneIndex;  
 	}
 	form.cardSource.focus();
 	
}

//*****************************validateRemarks*****************************************
// This function validates for remarks.
// It is called by validateotherields function.
//******************************************************************************************

function validateRemarks(objField){
var objFieldLength=objField.value.length;
var tempChar;

if(objFieldLength==0){
	alert(remarksErrMsg1);
	objField.focus();
	return false;	
	}
/*
if(objFieldLength > 255){  
	alert(remarksErrMsg);
	objField.focus();
	objField.select();
	return false;
}  
*/
return true;
}


function validateFacility(form){
	var lbx2=document.ClubCust.facility;
        var lbx1=document.ClubCust.division;
    	
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	if (ind1==0){
    		alert(divisionErrMsg);
    		lbx1.focus();
    		return false;
    	}
    	
    	var arr2len=listArr[ind1-1].length;
    	
    	if (arr2len==0){
    		alert(facilityFormatErrMsg);
    		lbx2.value="";
    		lbx1.focus();
    		return false;
    	}
    	
    	if(lbx2.value.length==0){
    		alert(facilityErrMsg);
    		lbx2.focus();
    		return false;
    		
    		}  
    	
    	for(var i=0;i<arr2len;i++){
		if(lbx2.value ==(listArr[ind1-1][i])){
			return true;
     		//listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	else if(i==(arr2len-1)){
    		alert(facilityErrMsg1);
    		lbx2.focus();
    		lbx2.select();
    		return false;    		
    		}
    	
	}
}  


function checkFacility(form){
	var lbx2=document.ClubCust.facility;
    	var lbx1=document.ClubCust.division;
    	
    	var ind1=0;
    	ind1=lbx1.selectedIndex;
    	var arr2len=listArr[ind1].length;
    	
    	for(var i=0;i<arr2len;i++){
		if(lbx2.value ==(listArr[ind1][i])){
			return true;
     		//listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	else if(i==(arr2len-1)){
    		return false;    		
    		}
    	
}
}  