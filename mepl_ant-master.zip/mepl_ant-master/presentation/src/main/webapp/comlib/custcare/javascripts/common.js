/*************************************************************************************************
Project Name			  	:	SAFEWAY                 
Module Name	   			:	Common
Relevant Spec				:	  
Program Name				:	common.js
Program Version				: 	1.0.0
Program Description			:	This program validates for all the fields
						in the newcommentcard screen
Screens Used				:       newcommentcard.jsp 
JavaScript files Used   		:	NA
StyleSheet files Used			:	NA

Tables Used	  	  		:	NA
Templates Included			:	NA
Called From				:	All JSPs
						
calling					:       None
Default Parameters			:	  
	Input  				:     All the field names
	Output				:     None
	Other Parameters		:     None      
  					            
Modification History 		:       
--------------------------------------------------------------------------------------------------------------------------------
  Author		Date (MM/DD/CCYY)		Version		Modification Details			Change Request Reference
--------------------------------------------------------------------------------------------------------------------------------
Dharanidharan           07/6/2000			1.0.0		NA					NA
Sundeep Nahar		07/28/2000			1.1.1		Added the function getMessage()
									in the code.				CHG-001	
Vamsi Kalyan Poondla    09/05/2000                      1.1.2           Added status message string variables 
                                                                        for menus (GIFs) in all the JSP screens
Sundeep Nahar		09/12/2000			1.1.3		added new date, phone, state, zip formatting 	CHG-001..009
---------------------------------------------------------------------------------------------------------------------------------
********************************************************************************************************************
*/

//declaration of variables
var s;
var glsPrefix = "You did not enter a value into the";
var glsSuffix = "\nfields.\nThis is a required field. Please enter it now.";
var glsSuffixPlu = "\nfields.\nThese are required fields. Please enter now.";
var glsInvalid= "Incorrect format ";
var glsPrompt = "should be ";
var glsStates = "\nAlabama = AL; Alaska = AK;  Arizona = AZ; Arkansas = AR;"+
				"\nCalifornia = CA, Colorado = CO; Connecticut = CT;"+
				"\nDelaware = DE; District of Colombia = DC;"+
				"\nFlorida = FL; Georgia = GA;"+
				"\nHawaii = HI; Idaho = ID; Illinois = IL; Indiana = IN; Iowa = IA;"+
				"\nKansas = KS; Kentucky = KY; Lousiana = LA;"+
				"\nMaine = ME; Maryland = MD; Massachusetts = MA; Michigan = MI;\nMinnesota = MN; Mississippi = MS; Missouri = MO; Montana = MT;"+
				"\nNebraska = NE; Nevada = NV; New Hampshire = NH; New Jersey = NJ\nNew Mexico = NM; New York = NY; North Carolina = NC; North Dakota = ND;"+
				"\nOhio = OH; Oklahoma = OK; Oregon = OR; "+
				"\nPennsylvania = PA; Rhode Island = RI;" +
				"\nSouth Carolina = SC; South Dakota = SD;"+
				"\nTennessee = TN; Texas = TX; Utah = UT;"+
				"\nVermont = VT; Virginia = VA;"+
				"\nWashington = WA; West Virginia = WV; Wisconsin = WI; Wyoming = WY;";
var glsProvs  = "\nAlberta = AB;\nBritish Columbia = BC;\nManitoba = MB;\nNew Brunswick = NB;\nNewfoundland = NF;"+
                "\nNorthwest Territories and Nunavut = NT;\nNova Scotia = NS;"+
				"\nOntario=ON;\nPrince Edward Island = PE;\nQuebec =QC;\nSaskatchewan = SK;\nYukon = YK;";
var glsMonths = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
var glsDays = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

//variables for the GIF menu bar on all the screens.
var noNameCardMsg="Click to create a new Comment Card for a non-Club Card customer";
var searchCustomerMsg="Click to search Club Card customer";
var searchCommentCardMsg="Click to search comment card";
var searchStoreMsg="Click to search store";
var addCommentMsg="Click to add a new comment from this comment card";
var phoneErrMsg='Incorrect format. Please enter a ten digit Phone Number.';
var date0000ErrMsg='Please enter a valid Date.';

// **********************************isEmpty()**************************************************
// This function checks whether the field value is null.
// parameter: variable s
// returns boolean
//***********************************************************************************************
 
function isEmpty(s){
   return ((s == null) || (s.length == 0))?true:false;
;
  }
//// **********************************isWhitespace()**************************************************
// This function checks whether the field value has any leading and trailing white spaces.
// parameter: variable s
// returns boolean
//***********************************************************************************************

function isWhitespace(s){
        return s.match(/^\s*$/)?true:false;
}
// **********************************isLetter()**************************************************
// This function checks whether the field value(character) matches with alphabets 
//at beginning and at the end  ignporing the case.
// parameter: variable c
// returns boolean
//***********************************************************************************************

function isLetter (c){
        return c.match(/^[a-z]$/i)?c:false;
}
// **********************************isDigit()**************************************************
// This function checks whether the field value is a digit at start till the end.
// parameter: variable c
// returns boolean or the string itself
//***********************************************************************************************

function isDigit (c){
        return c.match(/^\d$/)?c:false;
}
// **********************************isLetterOrDigit()**************************************************
// This function checks whether the field value is letter or a digit at the start till 
//the end ignoring the case.
// parameter: variable c
// returns boolean or the string itself.
//***********************************************************************************************

function isLetterOrDigit (c){
        return c.match(/^([a-z]|\d)$/i)?c:false;
}
// **********************************isAlphabaetic()**************************************************
// This function checks whether the field value is an alphabet.if yes it returns a string.
// parameter: variable s
// returns boolean or the string itself.
//***********************************************************************************************

function isAlphabetic (s){
        return s.match(/^[a-z]+$/gi)?s:false;
}
// **********************************isNumeric()**************************************************
// This function checks whether the field value is a digit(numeric)
// parameter: variable s
// returns boolean or the string itself.
//***********************************************************************************************

function isNumeric(s){
        return s.match(/^\d+$/)?s:false;
}

// **********************************isAlphaNumeric()**************************************************
// This function checks whether the field value is  globally(all the occurances)
// ignoring case.
// parameter: variable s
// returns boolean or the string itself.
//***********************************************************************************************

function isAlphaNumeric (s){
        return s.match(/^[a-z0-9]+$/gi)?s:false;
}

function isAlphaNumericQuote (s){
        return s.match(/^[a-z0-9\']+$/gi)?s:false;
}
function isAlphaNumericSpaceDot (s){
        return s.match(/^[a-z0-9\s\.]+$/gi)?s:false;
}
function isAlphaNumericSpaceDotQuote (s){
        return s.match(/^[a-z0-9\s\.\']+$/gi)?s:false;
}
function isAlphaNumericSpace(s){
        return s.match(/^[a-z0-9\s]+$/gi)?s:false;
}
function isAlphaNumericSpaceBlank(s){
        return s.match(/^[a-z0-9\'\s]+$/gi)?s:false;
}
function isAlphaNumericSpaceDotUnderScore (s){
        return s.match(/^[a-z0-9\s\.\_]+$/gi)?s:false;
}


// **********************************isInt()**************************************************
// This function checks whether the field value is a positive or negative number.
// parameter: variable s
// returns false(if not an integer) or the string itself.
//***********************************************************************************************

function isInt (s){
   return s.toString().match(/^(\+|\-)?\d+$/)?s:false;
}
// **********************************isPosInt()**************************************************
// This function checks whether the field value  is a positive int by parsing it
// and checks > 0 and then calling isInt() function.
// parameter: variable s
// returns boolean or the string itself.
//***********************************************************************************************

function isPosInt (s){
 return isInt(s)?((parseInt(s,10) >= 0)?s:false):false;
}
// **********************************isNegInt()**************************************************
// This function checks whether the field value  is a negative int by parsing it
// and checks < 0 and then calling isInt() function.
// parameter: variable s
// returns boolean or the string itself.
//***********************************************************************************************

function isNegInt (s){
 return isInt(s)?((parseInt(s,10) < 0)?s:false):false;
}
// **********************************isNegInt()**************************************************
// This function checks whether the field value  is numeric or not 
// parameter: variable s
// returns false or the string itself.
//***********************************************************************************************

function isFloat (s){
        return s.toString().match(/^[\+|-]?\d*\.?\d+$/)?s:false;
}
// **********************************isPosFloat()**************************************************
// This function converts the string to a float and checks whether the field value  is numeric or not 
// parameter: variable s
// returns false or the string itself.
//***********************************************************************************************

function isPosFloat (s){
  return isFloat(s)?((parseFloat(s,10) >= 0)?s:false):false;
}
// **********************************isNegFloat()**************************************************
// This function ocnverts the string to a float and checks whether the field value  is numeric or not 
// parameter: variable s
// returns false or the string itself.
//***********************************************************************************************

function isNegFloat (s){
  return isFloat(s)?((parseFloat(s,10) < 0)?s:false):false;
}
// **********************************isIntInRange()**************************************************
// This function checks whether the passed value is an integer within the range
// parameter: variable s,imin,imax
// returns false(if it is not in range) or the number itself.
//***********************************************************************************************

function isIntInRange (s, imin, imax){
    var testStr = s.toString();
    if (!isInt(testStr)) return false;
        var num = parseInt(testStr,10);
        return ((num >= imin) && (num <= imax))?num:false;
}
// **********************************isSSN()**************************************************
// This function checks for the occurence of a pattern and then stores the first, second, and third
//occurences in three variables and chekcs whether the value lies wihtin the range.
//parameter: variable s
// returns false(if it doesnot lie within the range) or the string itself.
//***********************************************************************************************

function isSSN(s){
        var SSNpattern = /^(\d{3})(\d{2})(\d{4})$/;
        var SSNdelim = /[\-\s]/gi;
        temp = s.toString().replace(SSNdelim, "");
		if(temp.match(SSNpattern)){
			part1 = parseInt(RegExp.$1, 10);
			part2 = parseInt(RegExp.$2, 10);
			part3 = parseInt(RegExp.$3, 10);
			return ( part1 !=0 && part1 < 800 && part2!=0 && part3!=0)?temp.replace(SSNpattern, "$1\-$2\-$3"):false;
		}
}
// **********************************isSSN()**************************************************
// This function checks for the occurence of a pattern and then stores the first, second, and third
//occurences in three variables and chekcs whether the value lies wihtin the range.
//parameter: variable s
// returns false(if it doesnot lie within the range) or the string itself.
//***********************************************************************************************
function isSIN(s){
        var SINpattern = /^(\d{3})(\d{3})(\d{3})$/;
        var check_pattern = /^(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)$/;
        var SINdelim = /[\-\s]/gi;
        temp = s.toString().replace(SINdelim, "");
        if( temp.match(check_pattern)){
            chsum = 0;
            for (i=1; i<10; i++){
               if(i%2)
                   isum =parseInt(eval('RegExp.$'+i), 10);
               else
                   isum =parseInt((eval('RegExp.$'+i)), 10) *2;
               if (isum >9) chsum+=Math.floor(isum/10) +isum%10;
               else chsum+=isum;
            }
            return (chsum%10 == 0)? temp.replace(SINpattern, "$1\-$2\-$3"):false;
        }
        return false;
}
// **********************************isPhoneNumber()**************************************************
// This function replaces the space with the predefined delimiter
//parameter: variable s
// returns false(ifthe pased value doesnot match the pattern) or the string itself.
//***********************************************************************************************

function isPhoneNumber(s){
        var phoneNumDelim=/[()\-\s]/gi;
        var phoneNumPattern = /^(\d{3})(\d{3})(\d{4})$/;
        temp = s.toString().replace(phoneNumDelim, "");
        return temp.match(phoneNumPattern)?temp.replace(phoneNumPattern, "($1) $2\-$3"):false;
}
// **********************************isWorldPhoneNumber()**************************************************
// This function replaces the space with the predefined delimiter
//parameter: variable s
// returns false(ifthe pased value doesnot match the pattern) or the string itself.
//***********************************************************************************************

//function isWorldPhoneNumber(s){
 //       var WphoneNumDelim=/[()\-\s]/gi ;
   //     var WphoneNumPattern =/^(+?\d{3})(\d{3})(\d*)$/;
     //   temp=s.toString().replace(WphoneNumDelim, "");
       // return temp.match(WphoneNumPattern)?s.replace(WphoneNumPattern, "$1 $2 $3"):false;
//}
// **********************************isZipCd()**************************************************
// This function replaces the space with the predefined delimiter
//parameter: variable s
// returns false(ifthe pased value doesnot match the pattern) or the string itself.
//***********************************************************************************************
function isZipCd(s){
        var ZipDelim = /[()\-\s]/gi;;
        var ZIP1=/^(\d{5})$/;
        var ZIP2=/^(\d{5})(\d{4})$/;

        temp = s.toString().replace(ZipDelim, "");
        if(temp.match(ZIP2))
                return temp.replace(ZIP2, "$1\-$2");
        else if (temp.match(ZIP1))
                return temp;
        else return false;
}
//************************************isCanPostCd()**************************************************
//This function checks for the pattern 
//parameter s
//returns the string inupeer case if a match is found else returns false
//**************************************************************************************************
function isCanPostCd(s){
	    var canPostPattern = /^[a-ceghj-npr-tvxy]\d[a-ceghj-npr-tv-z]\s\d[a-ceghj-npr-tv-z]\d$/i
        var testStr = s.toString();
        return testStr.match(canPostPattern)?s.toUpperCase():false;
}
//************************************isStateCd()**************************************************
//This function checks for the valid two letter pattern
//parameter s
//returns the string in uppercase if true else returns false
//**************************************************************************************************
function isStateCd(s){
        var USStatePattern = /^(AL|AK|AS|AZ|AR|CA|CO|CT|DE|DC|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY)$/
         
        var testStr = s.toString().toUpperCase();
        return testStr.match(USStatePattern)?testStr:false;
}
//************************************isProvCd()**************************************************
//This function checks for the valid two letter pattern
//parameter s
//returns the string in uppercase if true else returns false
//**************************************************************************************************
function isProvCd(s){
        var CanCdsPattern = /^(AB|BC|MB|NB|NF|NT|NS|ON|PE|QC|SK|YK)$/;
        var s = s.toUpperCase();
        return s.match(CanCdsPattern)?s:false;
}  
//************************************isEmail()**************************************************
//This function checks for the valid EmailId
//parameter s
//returns the mailId if true else returns false
//*************************************************************************************************

function isEmail(s){
   var EmailPatrn =  /\b^(\w+)(\.?\w+)*@{1}(\w+)(\.?\w+)*(\.com|\.net|\.edu|\.mil|\.gov|\.org|\.[A-Za-z]{2})$\b/gi;
   return s.match(EmailPatrn)?s:false;
}
//**********************************************************************************************
//This function returns whether the value for money entered is a valid input
//parameter number
//returns money value if it mathces with the specified format else it returns false
//**********************************************************************************************
function isMoney(number){
	var number= "" + number;
	var moneyPatrn=/^\d*\.?\d{0,2}$/;
	number = stripCharsInBag(number, "$,")
	return (number.match(moneyPatrn))?formatDollar(number):false;
}
//****************************************************************************************************
//This function checks whther the input for month is a valid one
//parameters are mm,dd,yyyy,alerts
//returns a message if invalid and returns false  else returns true
//**********************************************************************************************
function isMonthLength(mm,dd,yyyy,alerts) {
         var months = new Array("","January","February","March","April","May","June","July","August","September","October","November","December");
         if ((mm == 4 || mm == 6 || mm == 9 || mm == 11) && dd > 30) {
		 	if(alerts) alert(months[mm] + " has only 30 days.");
             return false ;
         }
         else if(mm==2){
                 return isLeapMonth(dd,yyyy,alerts);
         }
         else if (dd > 31) {
		 	if(alerts)
                 alert(months[mm] + " has only 31 days.");
                 return false ;
         }
         return true ;
}
//********************************isLeapMonth()***********************************************************
//This function checks whther the year is a leap year and validates the days in february
//parameters are mm,dd,yyyy,alerts
//returns a message if invalid and returns false else returns true
//**********************************************************************************************

function isLeapMonth(dd,yyyy,alerts) {
        if ( (!(yyyy % 4) && yyyy % 100 || !(yyyy % 400)) && dd > 29) {
			if(alerts)
                alert("February of " + yyyy + " has only 29 days.");
                return false;
        }
        else if ( yyyy%4 && dd > 28) {
			if(alerts)
                alert("February of " + yyyy + " has only 28 days.");
                return false;
        }
        return true ;
}
//**********************************isDate()*****************************************************
//This function checks for the specified pattern of the date
//parameter: gfield,minYearOffset,maxyearOffset,minDaysOffset,maxDaysOffset,alerts
//returns false(ifthe pased value doesnot match the pattern) or true itself.
//***********************************************************************************************

function isDate(gField,minYearOffset,maxYearOffset,minDaysOffset,maxDaysOffset,alerts) {
    var inputStr = gField.value;
    var datePattern = /^(\d\/|\d\d\/?|\d\d-?|\d-)(\d\/|\d\d\/?|\d\d-?|\d-)(\d{1}|\d{4}|\d{2})$/;
    var yearBot = 70;
    var yearTop = 29;

	//inputStr = trim(inputStr);
   if(!inputStr.match(datePattern)){
  	if(alerts){
          alert("The date entry is not in an acceptable format.\n\nYou can enter dates in the following formats: mmddyyyy, mm/dd/yyyy, or mm-dd-yyyy.");
          gField.focus();gField.select();
	}
    return false ;
  }
  else {
    var mm = RegExp.$1;
    var dd = RegExp.$2;
    var yy = RegExp.$3;
	  	if( (mm+dd+yy).length == 6 && (mm==11 || mm==12)){
		if(alerts){
	 	    alert("The date you entered is ambiguous.\n\nPlease enter 2 digit month, 2 digit date and 4 digit year");
	    	gField.focus();gField.select();
		}
		return false;
 	}
    var mm =parseInt(mm.replace(/\/|\-/, ""), 10);
    var dd =parseInt(dd.replace(/\/|\-/, ""), 10);
    var yy =parseInt(yy, 10);
  }
  if (mm < 1 || mm > 12) {
  	if(alerts){
	     alert("Months must be entered between the range of 01 (January) and 12 (December).");
	     gField.focus();gField.select();

	}
	return false;
  }
  if (dd < 1 || dd > 31) {
  	if(alerts){
	     alert("Days must be entered between the range of 01 and a maximum of 31 (depending on the month and year).");
	     gField.focus();
	     gField.select();
	}
	return false;
  }
  var today = new Date();
  var todayYear = today.getFullYear();
	
  if (yy < 100)	
  	yyyy=todayYear+yy;
  else if(yy > 1000)
  	yyyy = yy;
  else if((yy>99)&&(yy<1000))
  	yyyy="0" + yy;
    
  	
   /* minWindow = todayYear - yearBot;
    maxWindow = todayYear + yearTop;
    mincc = Math.floor(minWindow/100);
    minyy = minWindow%100;
    maxcc = Math.floor(maxWindow/100);
    if (yy >= minyy) yyyy = yy + mincc * 100;
    else yyyy =yy+ maxcc * 100;
  }
  else
	yyyy = yy;

   if (minYearOffset || minDaysOffset) {
       var testDate = new Date(mm + "/" + dd + "/" + yyyy);
	   testTime = testDate.getTime();
	   var minOffsetTime = 0;
	   var maxOffsetTime = 0;
	   minYearLmt = todayYear;
	   maxYearLmt = todayYear;

	   if(minDaysOffset!= "undefined"){
	   		minOffsetTime += minDaysOffset*24*60*60*1000;
	   		maxOffsetTime += maxDaysOffset*24*60*60*1000;
	   }
	   if(minYearOffset!=  "undefined"){
	   		minYearLmt += minYearOffset;
	   		maxYearLmt += maxYearOffset;
	   }
	   if( minOffsetTime || maxOffsetTime){
		   minDaysLmt = today.getTime() + minOffsetTime;
		   minDateLmt = new Date(minDaysLmt);
	   	   maxDaysLmt = today.getTime() + maxOffsetTime;
		   maxDateLmt = new Date(maxDaysLmt);
	   }
	   else{
	   		minDateLmt = new Date("01/01/"+ todayYear)
			maxDateLmt = new Date("12/31/"+ todayYear)
	   }
	   minDateLmt = new Date(minDateLmt.getMonth()+1+"/"+ minDateLmt.getDate() + "/" + minYearLmt);
   	   sminLmt = minDateLmt.getMonth()+1+"/"+ minDateLmt.getDate() + "/"+ minDateLmt.getFullYear();
	   maxDateLmt = new Date (maxDateLmt.getMonth()+1+"/"+ maxDateLmt.getDate() + "/"+ maxYearLmt);
	   smaxLmt = maxDateLmt.getMonth()+1+"/"+ maxDateLmt.getDate() + "/"+ maxDateLmt.getFullYear();

      if (testTime < minDateLmt.getTime() || testTime > maxDateLmt.getTime()) {
		  	if(alerts){
    	      alert("The range for this entry is between " + sminLmt + " and " + smaxLmt)
              gField.focus();
			}
          	return false;
      }
   }*/
   if (!isMonthLength(mm,dd,yyyy,alerts)) {
         gField.focus();
         return false;
   }
   /*if(mm < 10) mm = "0" + mm;
   if(dd < 10) dd = "0" + dd;
   gField.value = mm + "/" + dd + "/" + yyyy;  */
   return true;
}
// **********************************isTextAreaInLimit()**************************************************
// This function checks whether the argument lies in the given value
//parameters oField,iMaxlen
//returns false(ifthe pased value doesnot lie in the limit) or true itself.
//***********************************************************************************************

function isTextAreaInLimit(oField,iMaxLen) {
 var iTextLen = oField.value.length;
 if (iTextLen > iMaxLen) 	return false;
  else return true;
}
  var flag=true; // to be discussed                                                                                                          
function doCheck(objField,funcName,strAlert, emptyOK){
               var strToChk = objField.value.toString();
        if (isWhitespace(strToChk))
                return((!emptyOK)?false:true);//strToChk);

		strToChk = trim(strToChk,"all");
// to be discussed
if(strToChk.indexOf("\\",0) != -1){
	return false;
}
if((strToChk.indexOf("\{",0) != -1)||(strToChk.indexOf("\}",0) != -1)){
	return false;
}

                                                                                                       
if(strToChk.indexOf("\"",0) != -1){
//alert("Please do not enter \" in the text box.");
//objField.focus();objField.select();
//flag=false;
return false;
}
// to be discussed
		temp = eval(funcName + "(\"" + strToChk + "\")")
       if (!temp){
		 //   alert(strAlert);
             //   objField.focus();
		//	objField.select();
		    return false;               
        }
		else{
			objField.value=temp;
                 return true;

                 		}
 }
//checks whther the field has only alphabets
function checkAlphabetic(objField, emptyOK){
        var alertStr = "Incorrect format " +objField.name+ "  should be alphabetic" ;
        return doCheck(objField, "isAlphabetic", alertStr,emptyOK);
}
//checks whether the field has only numeric characters 
function checkNumeric(objField, emptyOK){
        var alertStr = "InCorrect format " +objField.name+ " should be numeric";
        return doCheck(objField, "isNumeric",  alertStr, emptyOK);
}
//checks whether the field has only alphanumeric characters
function checkAlphaNumeric(objField, emptyOK){
        var alertStr ="InCorrect format " +objField.name+ " should be alphaNumeric" ;
        return doCheck(objField, "isAlphaNumeric",  alertStr, emptyOK);
}

function checkAlphaNumericQuote(objField,emptyOK){
	//alert("entering"); 
	var alertStr = "Incorrect format " + objField.name + " should be alphanumeric ";
        return doCheck(objField, "isAlphaNumericQuote",  alertStr, emptyOK);

}

function checkAlphaNumericQuoteUnderScore(objField,emptyOK){
	//alert("entering"); 
	var alertStr = "Incorrect format " + objField.name + " should be alphanumeric ";
        return doCheck(objField, "isAlphaNumericSpaceDotUnderScore",  alertStr, emptyOK);
}


function checkAlphabeticSpaceQuote(objField,emptyOK){
	//alert("entering"); 
	var alertStr = "Incorrect format " + objField.name + " should be alphabetic ";
        return doCheck(objField, "isAlphabeticSpaceQuote",  alertStr, emptyOK);

}
function checkAlphaNumericSpaceDot(objField,emptyOK){
	//alert("entering"); 
	var alertStr = "Incorrect format " + objField.name + " should be alphanumeric ";
        return doCheck(objField, "isAlphaNumericSpaceDot",  alertStr, emptyOK);

}

function checkAlphaNumericSpaceDotQuote(objField,emptyOK){
	//alert("entering"); 
	var alertStr = "Incorrect format " + objField.name + " should be alphanumeric ";
        return doCheck(objField, "isAlphaNumericSpaceDotQuote",  alertStr, emptyOK);

}

function isAlphabeticSpaceQuote(s){
	return s.match(/^[a-z\s\']+$/gi)?s:false;
}

function checkAlphaNumericSpace(objField,emptyOK){
	//alert("entering"); 
	var alertStr = "Incorrect format " + objField.name + " should be alphanumeric ";
        return doCheck(objField, "isAlphaNumericSpace",  alertStr, emptyOK);

}

//check whether the are
function checkTextAreaLimit(oField,iMaxLen) {
		if( !isTextAreaInLimit(oField,iMaxLen)){
		oField.focus();
		var bTruncate = confirm ("The maximum characters for this\ntext box is " + iMaxLen + " characters.\nThe rest will be truncated.");
	  	if (bTruncate)
		   oField.value = oField.value.substr(0,iMaxLen);
	  	return false;
	}
    return true;  
}
function checkSSN(objField, emptyOK){
        var alertStr = glsInvalid+"Social Security Number\n"+glsPrompt+ "a 9 digit U.S. SSN ( i.e. 123456789)."
         return doCheck(objField, "isSSN", alertStr, emptyOK);
}
function checkSIN(objField, emptyOK){
        var alertStr = glsInvalid+"Canadian Social Security Id\n"+glsPrompt+ "a 9 digit SIN (i.e 123456789).";
        return doCheck(objField, "isSIN", alertStr, emptyOK);
}
function checkPhoneNumber(objField, emptyOK){
        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "a 10 digit phone number.";
        return doCheck(objField, "isPhoneNumber", alertStr, emptyOK);
}
function checkWorldPhoneNumber(objField, emptyOK){
        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "an international phone number.";
        return doCheck(objField, "isWorldPhoneNumber", alertStr, emptyOK);
}
function checkZipCd(objField, emptyOK){
        var alertStr = glsInvalid+"ZIP Code\n"+glsPrompt+ "a 5 or 9 digit U.S. ZIP Code (i.e. 94043).";
        return doCheck(objField, "isZipCd", alertStr, emptyOK);
}
function checkCanPostCd(objField, emptyOK){
        var alertStr = glsInvalid+"Canadian Postal Code"+glsPrompt+ "a 7 characters Postal Code (like K3L 4M2)";
        return doCheck(objField, "isCanPostCd", alertStr, emptyOK);
}
function checkPostalCd(objField, emptyOK){
 var alertStr = glsInvalid+"US or Canadian Postal Code\n"+glsPrompt+ "a 5 or 9 digits ZIP or 7 characters Canadian Postal code.";
  var testStr = objField.value.toString();
  if (isWhitespace(testStr))
         return (!emptyOK)?false:emptyOK;
	testStr = trim(testStr,"all");
	
	if(	((str = isZipCd(testStr))!=false) || ((str = isCanPostCd(testStr))!=false)){
	  objField.value=str;
      return true;
	}
	else{
	 alert(alertStr);
	 objField.focus();objField.select();
	 return false;
	}
}

function checkStateCd(objField, emptyOK){
        var alertStr = glsInvalid+"State Code\n"+glsPrompt+ " a 2 character code (like CA)." + glsStates;
        return doCheck(objField, "isStateCd", alertStr, emptyOK);
}
function checkProvCd(objField, emptyOK){
        var alertStr = glsInvalid+"Canadian Province\n"+glsPrompt+ "a 2 character code (like YK)." +glsProvs;
        return doCheck(objField, "isProvCd", alertStr, emptyOK);
}
function checkStateProvCd(objField, emptyOK){
  var alertStr = glsInvalid+"US State or Canadian Province\n"+glsPrompt+ "a 2 character code (like AB).\n\n" +
  					glsStates + "\n\n" + glsProvs;
  
  					var testStr = objField.value.toString();
  					

  if (isWhitespace(testStr))
         return (!emptyOK)?false:emptyOK;
  testStr = trim(testStr,"all");
  
	if(	((str = isStateCd(testStr))!=false) || ((str = isProvCd(testStr))!=false)){
	  objField.value=str;
      return true;
	}
	else{
	 alert(alertStr);
	 objField.focus();objField.select();
	 return false;
	}
}
function checkEmail(objField, emptyOK) {
        var alertStr = glsInvalid+"Email address\n"+glsPrompt+ "a valid email address (like name@company.com).";
        return  doCheck(objField, "isEmail", alertStr, emptyOK);
}
function checkMoney(objField, emptyOK) {
    var alertStr = glsInvalid+"number.\n"+glsPrompt+ "a valid amount in dollars (e.i. 245 or 113.26 ).";
   return doCheck(objField, "isMoney", alertStr, emptyOK);
}
function checkDate(objField,emptyOK,minYearOffset,maxYearOffset,minDaysOffset,maxDaysOffset) {
	var testStr = objField.value.toString();
	if (isWhitespace(testStr))
		return (!emptyOK)?false:emptyOK;
	return	isDate(objField, minYearOffset, maxYearOffset, minDaysOffset, maxDaysOffset,true);
}
function checkReqTextFields(form,arrNmeMsg){
		return checkForm(form,"text", arrNmeMsg);
}
function checkReqFields(form, arrNmeMsg){
		return checkForm(form,"req",arrNmeMsg);
}
function checkForm(form,typeSpec,arrNmeMsg){
        var alertStr=glsPrefix;
        var intMissed = 0;
        var radioName = "";
        var args = 0;

  if (arrNmeMsg) args = 1;
	for(i=0; i<form.elements.length; i++){
		with(form.elements[i]){
			if((typeSpec =="req" && name.substring(0,4) == "req_" ) || typeSpec =="all" || typeSpec == "text"){
				j = radioLength = 0;
				msg = "";
				if(type == "radio" && typeSpec!="text"){
				   	if (radioName.indexOf(name)==-1){
					   radioName += name;
	    	           var name = name;
	   	    	       var radioLength = eval('form.'+name +'.length');
	       	    	   for(j=0; j < radioLength; j++){
	           	    	    if(eval('form.'+name+'[j].checked')){
	                                   break;
	               	    	}
	              		}
					}
				}
				if( (j == radioLength && radioLength != 0) ||
					((type == "text" || type == "textarea" || type=="password") && isWhitespace(value)) ||
					(type=="select-one" && (!selectedIndex||(selectedIndex && !options[selectedIndex].value)) && typeSpec != "text") ||
					(type=="select-multiple" && (selectedIndex < 0 || !options[selectedIndex].value)&& typeSpec != "text")){
					 if(args) msg = eval("arrNmeMsg['" + name + "']");
			         if(typeSpec =="req"){
						  alertStr+=(!msg.length)?"\n" + name.substring(4):"\n" + msg;
				
					}
			   		 else
		  			   alertStr+=(!msg)?"\n" + name:"\n" + msg;
		          	 if(!intMissed){
			         	intMissed=1;
						if(type == "radio")
		     				eval('form.'+name+'[0].focus()');
						else focus();
		        	 }
			         intMissed++;
				}
	        }
		}
	}
	if(intMissed) {
		
    	 (intMissed == 2)?alert(alertStr+="\n" + glsSuffix):alert(alertStr+="\n" + glsSuffixPlu);
   		 return false;
  	}
	else
	   return true;
}
//
function format (s){
    var arg;
    var sPos = 0;
    var resultString = "";

    for (var i = 1; i < format.arguments.length; i++) {
       if (i % 2 == 1) resultString += format.arguments[i];
       else {
           resultString += s.substring(sPos, sPos + format.arguments[i]);
           sPos += format.arguments[i];
       }
    }
    return resultString;
}
function formatDate(objDate){
		var curdate = objDate;
		var temp_year = curdate.getFullYear();
		var arrDate = new Array();

		arrDate["day"]=glsDays[curdate.getDay()];
		arrDate["month"]=glsMonths[curdate.getMonth()];
		arrDate["date"]= curdate.getDate();
		arrDate["year"]=temp_year;

		return arrDate;
}
	function formatShortDate(objDate){
			var month = objDate.getMonth() +1;
			var date = objDate.getDate();

			if( month <10) month = "0" + month;
			if(date < 10) date = "0" + date;
			return  month +"/" + date + "/" + objDate.getFullYear();
	}
//This functioin formats the given number in to western money style
function formatInt(n){
	res ="";
	n = "" + n;
	for( i = n.length; i > 3; i-=3){
		res = "," + n.substr(i-3, 3) + res;
	}
	return n.substring(0,i) + res;
}
function formatDollar(s){
        var temp=("" + s).split(".");
        var cents = ".";
	    (!isEmpty(temp[0]))?dolr= formatInt(temp[0]):dolr="0";
        if(temp[1]){
            if(temp[1].length == 1)  cents+=temp[1] + "0";
			else if(temp[1].length == 2)  cents+=temp[1];
            else if(temp[1].length > 2){
	            str_cents = "" + Math.round(temp[1]/ Math.pow(10, temp[1].length-2 ));
				if(temp[1][0] == "0" && str_cents < 10) cents+="0";
			 	cents +=str_cents.substring(0,2);
            }
        }
        else
           cents += "00";
        return  (dolr + cents);
}
function formatPenny(s){
		s=''+s;
        var dolr= formatInt(s.substring(0,s.length-2));
		var cents = '.'+s.substring(s.length-2, s.length);
        return (dolr + cents);
}
function formatPercent(data, numDec){
    var temp=("" + data).split(".");
    var fraction = ".";
    var done = false;
    (!isEmpty(temp[0]))?whole= formatInt(temp[0]):whole="0";

    if(temp[1]){
        len = temp[1].length;
        if(len < numDec){
              fraction += temp[1];
              for(i=len; i<numDec; i++)
                    fraction+="0";
        }
        else if(len == numDec)
               fraction+= temp[1];
        else{
           str_fraction = "" + Math.round(temp[1]/Math.pow(10, temp[1].length-numDec));

           for(i=0; i<numDec;i++){
                 if(temp[1][i] == "0" && fraction.length == i && done == true){
                     fraction+="0";
                     done =true;
                 }
                else done = false;
           }
           if(str_fraction != "0")
             fraction += str_fraction.substring(0, numDec);
       }
   }
   else
       for(i=0; i<numDec;i++) fraction+="0";

       return (whole + fraction + " %");
}
//checks whether the letters in s are in bag
//if  it is not there does nothing else stores in other string

function stripCharsInBag (s, bag){
    var i;
    var returnString = "";
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}
//checks whether the letters in s are in bag
//if  it is there does nothing else stores in other string
function stripCharsNotInBag (s, bag){
   var i;
   var returnString = "";
    for (i = 0; i < s.length; i++)  {
        var c = s.charAt(i);
        if (bag.indexOf(c) != -1) returnString += c;
    }
    return returnString;
}
//replaces the the pattern which is got as an argument with the other 
//pattern got as another argument
function strReplace(s, charOut, charIn){
	patt = new RegExp(charOut, "gi");
	return s.replace(patt, charIn);
}
//trims in the string "all"
function trimAll (s){
        return trim(s, "all");
}
//trims in the string "lead"
function trimLead (s) {
        return trim(s,"lead");
}
//trims in the string "trail"
function trimTrail(s) {
        return trim(s,"trail");
}
//*****************************************trim()*****************************************************
//This function removes the initial zeros.
//parameterss,trimSpec
//trims the leading and trailing spaces.
//********************************************************************************************************
function trim(s, trimSpec){
       var patt_all = /\s*/gi;
        var patt_lead = /^\s+/i;
        var patt_trail = /\s+$/i;

       if(trimSpec == "all"){
       		var retStr=s.replace(patt_lead, "");
       		var retStr=retStr.replace(patt_trail, "");
                //return s.replace(patt_all, "");
                return retStr;
       }
        if(trimSpec == "lead")
                return s.replace(patt_lead, "");
        if(trimSpec == "trail")
                return s.replace(patt_trail, "");

        s= s.replace(patt_lead, "");
        return s.replace(patt_trail, "");
}
//*****************************************stripInitialZeros ()*****************************************************
//This function removes the initial zeros.
//No parameters
//returns the repalced pattern.
//********************************************************************************************************

function stripInitialZeros (s) {
		var pattern=/^(0+)(.*)$/i
        return s.replace(pattern, "$2");
}
//**********************************************************************************************
//This function returns the current date.
//No parameters
//returns the date object
//********************************************************************************************************
function displayDate(){
	curdate = new Date();
	var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

	date = months[curdate.getMonth()] + " " + curdate.getDate() + ", " + curdate.getFullYear();
	return(date);
}
//**********************************************************************************************
//This function checks which radio button is checked
//Parameters getRadioButtonValue
//returns the value of the buttons which are checked
//********************************************************************************************************

function getRadioButtonValue (radio){
   for (var i = 0; i < radio.length; i++) {
      if (radio[i].checked)
		return radio[i].value;
    }
   return false;
}

//****************************************Validate()**************************************************
//This function calls other functions to check all the fields in the newcommentcard screen.

//************************************************************************************************
function validate()
{      
  firstName=document.sfm.firstName;
  lastName=document.sfm.lastName
  mI=document.sfm.mI;
  emailId=document.sfm.emailID;
  address=document.sfm.address;
  city=document.sfm.city;
  State=document.sfm.state;
  zip=document.sfm.postalCode;
  phone=document.sfm.phone;
  dateSubmitted=document.sfm.dateSubmitted;
  remarks=document.sfm.remarks;

checkReqTextFields(document.sfm,document);
if ( 
(checkFirstName(firstName,false)) &&
(checkLastName(lastName,false))&&
(checkMi(mI,false))&&
(checkEmailId(emailId,false))&&
(checkAddress(address,false))&&
(checkCityName(city,false)) &&
(checkStateProvince(State,false)) && 
(checkZip(zip,false)) &&
(checkPhoneNo(phone,false))&&
(checkDateSubmitted(dateSubmitted,false,0,1000,01,31))&&
(checkRemarks(remarks,255))
	
)
{
document.sfm.submit();
}
else{
    //alert("mandatory");
return false;
} 

}
    

//*********************************checkLastName()*****************************************************
//This function validates the first name.
//It checks for alphabetic values.
//parameters:firstName,false
//returns boolean
//**************************************************************************************
function checkFirstName(firstName,state)
{
var temp=checkAlphabetic(firstName,state);
if(temp)
	{
	return true;
	}
else 
	{
firstName.focus();
firstName.select();
return false;
	}
}
//*********************************checkLastName()*****************************************************
//This function validates the last name.
//It checks for alphabetic values.
//parameters:lastName,false
//returns boolean
//**************************************************************************************
function checkLastName(lastName,state)
{
temp=checkAlphabetic(lastName,state)
if(temp)
	{
	return true;
	}
//alert("enter a valid last name");
lastName.focus();
lastName.select();
return false;

}
//*********************************checkMi()*****************************************************
//This function validates the middle initial.
//It checks for alphabetic values.
//parameters:mi,false
//returns boolean
//**************************************************************************************
 
function checkMi(mI,state)
{
temp=checkAlphabetic(mI,state);
if(temp)
{
return true;
}
//alert("enter a valid mi");
mI.focus();
mI.select();
return false;

}
//*********************************checkEmailId()*****************************************************
//This function validates the emailid.
//parameters:State,false
//returns boolean
//**************************************************************************************

function checkEmailId(emailId,state)
{
temp=checkEmail(emailId,state);	
if(temp)
{
return true;
}
//alert("enter a valid email");
emailId.focus();
emailId.select();
return false;
}

//*********************************checkAddress(()*****************************************************
//This function validates the state/province.
//It checks for state/province values.
//parameters:State,false
//returns boolean
//**************************************************************************************

function checkAddress(address,state)
{
temp=checkTextAreaLimit(address,40);
if(temp)
{
return true;
}
//alert("enter a valid address");
address.focus();
address.select();
return false;
}

 //*********************************checkCityName()*****************************************************
//This function validates the city name.
//It checks for alphabetic values.
//parameters:city,false
//returns boolean
//**************************************************************************************


function checkCityName(city,state)
{
temp=checkAlphabetic(city,state)	
if(temp)
{
return true;
}
//alert("enter a valid city name");
city.focus();
city.select();
return false;
}

//*********************************checkStateProvince()*****************************************************
//This function validates the state/province.
//It checks for state/province values.
//parameters:State,false
//returns boolean
//**************************************************************************************

function checkStateProvince(State,state)
{
temp=checkStateProvCd(State,state);
if(temp)
{
return true;
}
//alert("enter a valid state province");
State.focus();
State.select();
return false;
}

//*********************************checkZip()*****************************************************
//This function validates the zip code.
//It checks for zip code values.
//parameters:zip,false
//returns boolean
//**************************************************************************************
function checkZip(zip,state)
{
temp=checkZipCd(zip,state);	
if(temp)
{
return true;
}
//alert("enter a valid zip");
zip.focus();
zip.select();
return false;
}

//*********************************checkPhoneNo()*****************************************************
//This function validates the state/province.
//It checks for state/province values.
//parameters:State,false
//returns boolean
//**************************************************************************************

function checkPhoneNo(phone,state)
{
temp=checkPhoneNumber(phone,state);
if(temp)
{
return true;
}
//alert("enter a valid phone number ");
phone.focus();
phone.select();
return false;
}

function checkDateSubmitted(dateSubmitted,state,minyr,maxyr,mindy,maxdy){
temp=checkDate(dateSubmitted,state,minyr,maxyr,mindy,maxdy);
if(temp){
return true;
}
dateSubmitted.focus();
dateSubmitted.select();
return false;
}
//*********************************checkRemarks()*****************************************************
//This function validates the reamrks.
//parameters:remarks,state
//returns boolean
//**************************************************************************************
function checkRemarks(remarks,state)
{
temp=checkTextAreaLimit(remarks,255);
if(temp)
{
return true;
}
//alert("enter remarks less than 255 letters");
remarks.focus();
remarks.select();
return false;
}
//*********************************focusing()*****************************************************
//This function chjecks for focussing at the first field when the screen is loaded.
//parameters:formName,field
//returns boolean
//**************************************************************************************

function focusing(formName,field){
   formName.elements[field].focus();
}
function checkLoginName(loginName,state){
 temp=(checkAlphaNumeric(loginName,state)&&checkTextAreaLimit(loginName,12));
 if(temp){
return true;}
loginName.focus();
loginName.select();
return false;
}

//*********************************checkPassword()*****************************************************
//This function validates the password fied of the login screen.
//parameters:password,state
//returns boolean
//**************************************************************************************
function checkPassword(password,state)
{
temp=(checkAlphaNumeric(password,state) && checkTextAreaLimit(password,12));
if(temp){
return true;}
password.focus();
password.select();
return false;
}
//*********************************checkPassword()*****************************************************
//This function validates the login screen.
//parameters
//returns boolean
//**************************************************************************************
function loginValidate()
{
  	
	loginName=document.loginScreen.loginName;
	password=document.loginScreen.password;
	checkReqTextFields(document.loginScreen,document);
	temp=(checkLoginName(loginName,false)&&checkPassword(password,false));
if(temp){
document.loginScreen.submit();}
else return false;
}
//*********************************isPhone()*****************************************************
//This function validates the phone number.
//parameters s
//returns boolean
//**************************************************************************************
function isPhone(s){
        var phoneNumDelim=/[()\-\s]/gi;
        var phoneNumPattern = /^(\d{3})$/;
        temp = s.toString().replace(phoneNumDelim, "");
        return temp.match(phoneNumPattern)?temp:false;
}
//*********************************isPhone1()*****************************************************
//This function validates the phone number.
//parameters s
//returns boolean
//**************************************************************************************

function isPhone1(s){
        var phoneNumDelim=/[()\-\s]/gi;
        var phoneNumPattern = /^(\d{3})$/;
        temp = s.toString().replace(phoneNumDelim,"");
        return temp.match(phoneNumPattern)?temp:false;
}
//*********************************isPhone2()*****************************************************
//This function validates the phone number.
//parameters s
//returns boolean
//**************************************************************************************
function isPhone2(s){
        var phoneNumDelim=/[()\-\s]/gi;
        var phoneNumPattern = /^(\d{4})$/;
        temp = s.toString().replace(phoneNumDelim, "");
        return temp.match(phoneNumPattern)?temp:false;
}
//*********************************checkPhone()*****************************************************
//This function validates the phone number.
//parameters areaCode,true
//returns boolean
//**************************************************************************************

function checkPhone(objField, emptyOK){
        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "a 3 digit area code.";
        return doCheck(objField, "isPhone", alertStr, emptyOK);
}
//*********************************checkPhone1()*****************************************************
//This function validates the phone number.
//parameters phone1,true
//returns boolean
//**************************************************************************************

function checkPhone1(objField, emptyOK){
        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "a 3 digit phone number.";
        return doCheck(objField, "isPhone1", alertStr, emptyOK);
}

//*********************************checkPhone2()*****************************************************
//This function validates the phone number.
//parameters phone2,true
//returns boolean
//**************************************************************************************

function checkPhone2(objField, emptyOK){
        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "a 4 digit phone number.";
        return doCheck(objField, "isPhone2", alertStr, emptyOK);
}

//***************************getMessage***********************************
//This function is to display a help messgae in the status bar
//Parameters : currentField,HelpMessage
//Returns    : Void
//************************************************************************
function getMessage(lsf,HelpMessage){
     window.status=HelpMessage;
}





//*************************latest addition*********************************


//***************************compareDates********************************
//This function is to compare two dates
//Parameter:formName,Monthfield1,dayField1,YearField1,Monthfield2,
//dayField2,YearField2
//Returns    : boolean - true if date1<date2 false if date1>date2
//************************************************************************
/*function compareDates(formName,inMonth1,inDay1,inYear1,inMonth2,inDay2,inYear2,errorMsg){
if(! Msg(formName,inMonth1,inDay1,inYear1)){
   return false;
}
if(!validateDateMsg(formName,inMonth2,inDay2,inYear2)) {
   return false;
}
      var inMonth11 = trimZeroesValue(inMonth1.value);
    	var inDay11 = trimZeroesValue(inDay1.value);
      var inYear11= trimZeroesValue(inYear1.value);
      var inMonth21 = trimZeroesValue(inMonth2.value);
    	var inDay21 = trimZeroesValue(inDay2.value);
      var inYear21= trimZeroesValue(inYear2.value);

    if(parseInt(inYear11)<parseInt(inYear21))
     return true; 
   if(parseInt(inYear11)>parseInt(inYear21)){
   	 alert(errorMsg);
    inYear2.focus();
     inYear2.select();
   
     return false; 
  }
   if(parseInt(inMonth11)<parseInt(inMonth21))
     return true; 
   if(parseInt(inMonth11)>parseInt(inMonth21)){
   	      alert(errorMsg);
     inMonth2.focus();
     inMonth2.select();

     return false; 
   }
   if(parseInt(inDay11)<parseInt(inDay21))
     return true; 
   if(parseInt(inDay11)>parseInt(inDay21)){
   	     alert(errorMsg);
     inDay2.focus();
     inDay2.select();

     return false; 
   }
return true;
}//end of the function compareDates
*/


//***************************trimZeroes*****************************************
//This function will trim the extra zeros
//Returns    : boolean 
//******************************************************************************/
function trimZeroes(Str){
      StrVal=Str.value; 
	if((StrVal != "") && (StrVal.indexOf("0",0)!=-1)){
		var iMax = StrVal.length;
		var end = StrVal.length;
		var c;
		for(i=0;i<iMax;i++){
                if(StrVal.substring(i,i+1)!= "0")
                   break
            }//for   
            if(end!=i){
                iMax = StrVal.length;
                end = StrVal.length;
                for(i=0;1<iMax;i++){
                    c = StrVal.substring(0,1);
      			if (c == "0"){
                           StrVal=StrVal.substring(1,end);
	                     end = StrVal.length;

      			}//if
	      		else
		               break;
                }//for
                Str.value=StrVal;
            }//if
            else 
                Str.value="0";
       }//if
 return;
}//funn


//***************************trimZeroes*****************************************
//Integer function (by passing values) will trim the extra zeros
//Returns    : boolean 
//******************************************************************************/
function trimZeroesValue(StrVal){
	if((StrVal != "") && (StrVal.indexOf("0",0)!=-1)){
		var iMax = StrVal.length;
		var end = StrVal.length;
		var c;
		for(i=0;i<iMax;i++){
                if(StrVal.substring(i,i+1)!= "0")
                   break
            }//for   
            if(end!=i){
                iMax = StrVal.length;
                end = StrVal.length;
                for(var i=0;1<iMax;i++){
                    c = StrVal.substring(0,1);
      			if (c == "0"){
                           StrVal=StrVal.substring(1,end);
	                     end = StrVal.length;
       			}//if
	      		else
				   break;
                }//for
            }//if
            else 
                StrVal="0";
       }//if
return StrVal;
}//end of fn



//***************************validateDateMsg********************************
//This function is to check if the date passed is valid.
//Parameters : formName,Monthfield,dayField,YearField
//Returns    : boolean
//************************************************************************
function validateDateMsg(formName,inMonth,inDay,inYear,errMsg){
	   
	   if((inMonth.value.length==0)&&
         (inDay.value.length==0)&&
         (inYear.value.length==0)){
//         The control has come that means it is a non mandatory blank        
//         date field.So just return back without validating;
           return true;
      }//end of if 
      else if((inMonth.value.length==0)||
      			(inDay.value.length==0)||
      			(inYear.value.length==0))   
      {
      
        alert(errMsg);
       inMonth.focus();
       inMonth.select();
       return false;
       }
	//Trimming the leading zeroes in the values entered in the date field
      var month = trimZeroesValue(inMonth.value);
    	var day = trimZeroesValue(inDay.value);
  	if (inYear.value.length == 4){
		if (parseInt(inYear.value) == 0){
           alert(errMsg);
        inYear.focus();
 	     inYear.select();
 	     return false;
		}
	}
	var year = trimZeroesValue(inYear.value);
      if(!validMonth(parseInt(month))){
       alert(errMsg);
       inMonth.focus();
       inMonth.select();
       return false;
      } 
      if(!validYear((year))){
       alert(errMsg);
       inYear.focus();
       inYear.select();
       return false;
      }
      if(!validDay(parseInt(day),parseInt(month),parseInt(year))){
        alert(errMsg);
        inDay.focus();
        inDay.select();
        return false;
      }
      return true;
}//end of the function checkDate
function validMonth(MM){
      if(MM<1||MM>12){
      return false;
      }
      else{
        return true   
      }
}
function validYear(YY){
 if ( YY.length == 4 )YY = YY.substring(2,4);
 if(parseInt(YY)<0||parseInt(YY)>99)
      return false;
 else 
        return true;
}
function validDay(dd,mm,yy){
      if(dd<1||dd>31){
       return false;
}
      if((mm==1||mm==3||mm==5||mm==7||mm==8||mm==10||mm==12)&&(dd>31)){
      return false;
}
      if((mm==4||mm==6||mm==9||mm==11)&&(dd>30)){
        return false;
}
      if((mm==2)&&!(leapYear(yy))&&(dd>28)){
      return false;
}
      if((mm==2)&&(leapYear(yy))&&(dd>29)){
      return false;
}
      return true
}
function leapYear(yy){
//y2k not compliant!!!!!!!!Take care of century later
      if(!(yy%4==0)){
          return false;
}
      if((yy%100==0) && (yy%400!=0)){
          return false;
}
      return true;
}

function date2DigitFormat(formField) {
	var trimmedField = '';
	trimming(formField);
	
	if ( isNum(formField)&& formField.value.length == 1 ) {
			trimmedField = '0' + formField.value;
			formField.value = trimmedField;

}
}

function date4DigitFormat(formField) {
	var trimmedField = '';
	trimming(formField);
	if ( isNum(formField) && formField.value.length <= 4 ) {
		if ( formField.value.length == 1 ) {
			trimmedField = '200' + formField.value;
			formField.value = trimmedField;
		}
		else if ( formField.value.length == 2 ) {
			trimmedField = '20' + formField.value;
			formField.value = trimmedField;
		}
	}
}

function isNum(formField){
  lenField=formField.value.length;
  if(lenField != 0){
       for(i=0;i<lenField;i++){
        x=formField.value.charAt(i);
        if((x<'0') || (x>'9')) return false;
     }//end of for
  }//end of if
  window.status=''; 
  return true;
}//end of checkNum


function trimming(Str)
	{
   StrVal=Str.value; 
	if((StrVal != "") && (StrVal.indexOf(" ",0)!=-1))
		{
		var iMax = StrVal.length;
		var end = StrVal.length;
		var c;
		for(i=0;1<iMax;i++)
			{
			c = StrVal.substring(0,1);
			if (c == " ")
				{
				StrVal=StrVal.substring(1,end);
				end = StrVal.length;
				}
			else
				break;
			}
		iMax = StrVal.length;
		end = StrVal.length;
		for(var i=iMax;i>0;i--)
			{
		c = StrVal.substring(end-1,end)
		if (c == " ")
				{				
				StrVal=StrVal.substring(0,end-1);
				end = StrVal.length;
				}
			else
				break;
			}
		}
      Str.value=StrVal;
}//end of trim

//**************replacingTheBlankLinesEncoding(field1,field2)*****************
//This function is used by textarea field for multiple lines.
//It replaces the blank line in first field with "^" and sets this value 
//to the second field.
//****************************************************************************

function replacingTheBlankLinesEncoding(field1,field2){
var fieldValue=field1.value;
var fieldValueLength=fieldValue.length;
var tempString='';
for( i=0;i<fieldValueLength;i++){	 
	if((fieldValue.charCodeAt(i)==13)&&(fieldValue.charCodeAt(i+1)==10)){
		tempString=tempString+'^';
	}
	else{
		if(fieldValue.charCodeAt(i)==10){
		tempString=tempString; 
		}
		else{
		tempString=tempString+fieldValue.charAt(i);
		}
	}
	}// end of for 
	field2.value=tempString;		
}


//***************replacingTheBlankLinesEncoding(fieldValue,field)************
//This function is used to decode the  textarea fields values where the blank lines are 
//replaced with "^". 
function replacingTheBlankLinesDecoding(fieldValue,field){
var fieldValueLength=fieldValue.length; 
var tempString='';

for( i=0;i<fieldValueLength;i++){	
	if((fieldValue.charAt(i)=='^')){
		tempString=tempString+'\n';
		}	
		else{
			tempString=tempString+fieldValue.charAt(i);
		}
	
	}// end of for 
	field.value= tempString;
	//return tempString;
}

//********************************validateDate(dateField)******************************
//This function will get a date field object as parameter and validate it.
//It returns a boolean value.
function validateDate123(dateFld){
	var tempVal=dateFld.value.replace(/[1234567890\/]/g,"");
	if(tempVal.length>0)
		allValid=false;
	else{
		var dateVal=dateFld.value;
		if(dateVal.length!=6 && dateVal.length!=8)
			allValid=false;
		else{
			var mm=dateVal.substring(0,2);
			var dd=dateVal.substring(2,4);
			var yy=0;
			if(dateVal.length==6)
				yy=dateVal.substring(4,6);
			else
				yy=dateVal.substring(4,8);
			var allValid=true;
			var leapYr="F";
		
			if(yy=="0000")
				allValid=false;
			else if(yy%4==0)
				leapYr="T";
			if(dd<1 || dd>31 || mm<1 || mm>12)
				allValid=false;
			else if(dd>30 && (mm==4 || mm==6 || mm==9 || mm==11))
				allValid=false;
			else if(leapYr=="F" && mm==2 && dd>28)
				allValid=false;
			else if(leapYr=="T" && mm==2 && dd>29)
				allValid=false;
		}
	}
	return allValid;
}

//********************************compareDates(dateField1,dateField2)******************************
//This function gets two Date fields as arguments and checks whether the
//date in second date field is earlier than date in first date field.
//If so returns false else returns true
function compareDates123(startDate,endDate){
	var mm=startDate.value.substring(0,2);
	var dd=startDate.value.substring(2,4);
	var yy=0;
	if(startDate.value.length==6)
		yy=startDate.value.substring(4,6);
	else
		yy=startDate.value.substring(4,8);
	startDateObj=new Date(yy,mm,dd);
	mm=endDate.value.substring(0,2);
	dd=endDate.value.substring(2,4);
	if(endDate.value.length==6)
		yy=endDate.value.substring(4,6);
	else
		yy=endDate.value.substring(4,8);
	endDateObj=new Date(yy,mm,dd);
	
	if(endDateObj < startDateObj)
		return false;
	else
		return true;
}


/********************************validateEmail******************************
//This function checks if the given text is a valid email or not
//If not returns false else returns true
//Inputs:- any text.
// Check if given text is a valid email or not.
*/

function validateEmail(a)
{

lcl_s_spe_char= /[^$A-Za-z0-9_@\.]|\.$/
if(lcl_s_spe_char.test(a.value))
return false;
lcl_n_i=a.value.indexOf('@');
lcl_n_j=a.value.indexOf('.');
if( lcl_n_i != a.value.lastIndexOf('@'))	
return false;
if(lcl_n_i <=0 || lcl_n_i == a.value.length-1 || a.value.charAt(lcl_n_i+1) =='.' || lcl_n_j <=0 || lcl_n_j == a.value.length-1)
return false;
for (lcl_n_i=0;lcl_n_i< a.value.length;lcl_n_i++)
	if(a.value.charAt(lcl_n_i)==a.value.charAt(lcl_n_i+1) &&a.value.charAt(lcl_n_i)=='.')
	return false;
return true;
}
	
function validateDate(dateVal){
var tempVal=dateVal.value.replace(/[1234567890\/]/g,"");
var dateArr=dateVal.value.split("/");
var mm=dateArr[0];
var dd=dateArr[1];
var yy=dateArr[2];
var allValid=true;
var leapYr="F";

if(tempVal.length>0)
	allValid=false;
else if(dateArr.length<3)
	allValid=false;
else if(dateArr.length>3)
	allValid=false;
else if(mm.length==0 || dd.length==0 || yy.length==0)
	allValid=false;
else if(mm.length>2 || dd.length>2 || yy.length>4)
	allValid=false;
else if(dateArr.length==3){
	if(yy%4==0)
		leapYr="T";
	if(dd<1 || dd>31 || mm<1 || mm>12)
		allValid=false;
	else if(dd>30 && (mm==4 || mm==6 || mm==9 || mm==11))
		allValid=false;
	else if(leapYr=="F" && mm==2 && dd>28)
		allValid=false;
	else if(leapYr=="T" && mm==2 && dd>29)
		allValid=false;
}
return allValid;
}

//********************************compareDates(dateField1,dateField2)******************************
//This function gets two Date fields as arguments and checks whether the
//date in second date field is earlier than date in first date field.
//If so returns false else returns true
function compareDates(startDate,endDate){
dateArr1=startDate.value.split("/");
dateArr2=endDate.value.split("/");
startDateObj=new Date(dateArr1[2],dateArr1[1],dateArr1[0]);
endDateObj=new Date(dateArr2[2],dateArr2[1],dateArr2[0]);

if(endDateObj < startDateObj)
	return false;
else
	return true;
}



function dateCheck(objField,dateMM,dateDD,dateYY){		
var datePattern = /^(\d\d)(\/?)(\d\d)(\/?)(\d{1}|\d{4}|\d{2})$/;
var dateValue=objField.value;
var mm;
var dd;
var yy;

inputStr = trim(dateValue,'all');
if(dateValue.length==0){
	return true;
	}
   if(!inputStr.match(datePattern)){
  	return false ;
  }
  
    mm = RegExp.$1;
    dd = RegExp.$3;
    yy = RegExp.$5;
    if(dd=="00"){
    	alert(date0000ErrMsg);
    	objField.focus();
    	objField.select();
    	return false;
    }
    if(mm=="00"){
    	alert(date0000ErrMsg);
    	objField.focus();
    	objField.select();
    	return false;
    }
    if(yy=="0000"){
    	alert(date0000ErrMsg);
    	objField.focus();
    	objField.select();
    	return false;
    }

    dateValue=mm+"/"+dd+"/"+yy;
    objField.value=dateValue;
   dateMM.value=mm;
   dateDD.value=dd;
   dateYY.value=yy;
    
   
return true;
        
}


function dateValidating(objField,dateMM,dateDD,dateYY){		
var datePattern = /^(\d\d)(\/?|\-?)(\d\d)(\/?|\-?)(\d{1}|\d{4}|\d{2})$/;
var dateValue=objField.value;
var mm;
var dd;
var yy;  

inputStr = trim(dateValue,'all');
   if(!inputStr.match(datePattern)){
  	  alert("The date entry is not in an acceptable format.\n\nYou can enter dates in the following formats: mmddyyyy, mm/dd/yyyy, or mm-dd-yyyy.");
          objField.focus();objField.select();
	  return false ;
  }
    mm = RegExp.$1;
     dd = RegExp.$3;
     yy = RegExp.$5;
    dateValue=mm+"/"+dd+"/"+yy;
    objField.value=dateValue;
    dateMM.value=mm;
   dateDD.value=dd;
   dateYY.value=yy;
  //alert(dateYY);
return true;
        
}



function phoneFormatting(form,objField){
	
	var phone= objField.value;
	if(!checkPhoneNumber(objField, true)){
		return false;		
	}
	
}


function phoneValidating(form,objField){ 
	var phone= objField.value;
	if(!checkPhoneNumber(objField, true)){
		alert(phoneErrMsg);
		objField.focus();
		objField.select();
		return false;		
	}
	else{
	     if(phone.length !=0){
		phone=isPhoneNumber(phone);
		form.areaCode.value=phone.substring(1,4);
		form.phone1.value=phone.substring(6,9);
		form.phone2.value=phone.substring(10,14);
		}
		return true;
	}
}