/********************************************************************************************
Project Name				:Safeway  
Module Name	   			:SearchCommentCard
Program Name				:SearchCommentCardValidate.js	
Program Version				:1.0.0 	
Program Description			:This is the  java script file in which does all the 
	                                 validations of the SearchCommentCard 
Called From				:SearchCommentCard.jsp
Calling					:Common.js 	
Modification History 	      		:
------------------------------------------------------------------------------------------------------------
Author   Date(MM/DD/CCYY)	Version   Modification Details          ChangeRequestReferenceinthe code
-----------------------------------------------------------------------------------------------------------
Sundeep     08/17/2000  		1.0.0	    NA                                N.A
nahar
NAHAR	    09/12/2000		1.1.0		done date formatting 	CHG-004
cyril	    10/02/2000		1.1.1		added the validation and messages for comment type
***********************************************************************************************************/

//declare the help messages

var commentCardIdMsg='Enter the contact Id.';
var cardSourceMsg ='Select the contact source.';
var cardStatusMsg ='Select the contact status.';
var divisionMsg ='Select the  division.';
var storeMsg ='Select the store.';
var clubCardIdMsg ='Enter the club card Id.';
var phoneMsg ='Enter the  phone number.';
var lastNameMsg ='Enter the last name.';
var firstNameMsg ='Enter the first name.';
var submittedStartDateMsg ='Enter the submitted start date.';
var submittedEndDateMsg ='Enter the submitted end date.';
var openStartDateMsg ='Enter the open start date.';
var openEndDateMsg ='Enter the open end date.';
var lastUpdatedStartDateMsg ='Enter the last updated start date.';
var lastUpdatedEndDateMsg ='Enter the last updated end date.';
var openedByMsg ='Enter the User Id of the user who opened the comment card.';
var lastUpdatedByMsg ='Enter the User Id of the user who updated the comment card recently.';
var searchMsg='Click for searching the Comment Card.';
var resetMsg='Click for resetting the page.';
var cmmtTypeMsg='Select the comment type.';
// declare the error message
  
var commentCardIdErrMsg ='Incorrect format. Contact ID should be numeric.';
var cardSourceErrMsg='Incorrect format. Contact source should be alphanumeric.';
var cardStatusErrMsg='Incorrect format. Contact Status should be alphabetic.';
var clubCardIdErrMsg='Incorrect format. Club Card Number should be alphanumeric.';
var phoneErrMsg='Incorrect format. Please enter a ten digit Phone Number.';
var lastNameErrMsg ='Incorrect format. Customer\'s Last Name should be alphabetic. ';
var lastNameErrMsg2 ='Please enter at least Last Name for the search.';
var firstNameErrMsg ='Incorrect format. Customer\'s First Name should be alphabetic.';
var submittedStartDateErrMsg ='Please enter the Submitted Start Date  in mmddyy or mmddyyyy format.';
var submittedEndDateErrMsg ='Please enter the Submitted End Date in mmddyy or mmddyyyy format.';
var openStartDateErrMsg ='Please enter the Open Start Date in mmddyy or mmddyyyy format.';
var openEndDateErrMsg ='Please enter the Open End Date in mmddyy or mmddyyyy format.';
var lastUpdatedStartDateErrMsg ='Please enter the Last Updated Start Date in mmddyy or mmddyyyy format.';
var lastUpdatedEndDateErrMsg ='Please enter the Last Updated End Date in mmddyy or mmddyyyy format.';
var openedByErrMsg ='Incorrect format. User Id of the user who opened the comment card, should be alphanumeric.';
var lastUpdatedByErrMsg ='Incorrect format. User Id of the user who updated the comment card, recently should be alphanumeric.';
var dateErrMsg="Please enter a valid date in mm/dd/yy format.";
var mmErrMsg='Incorrect format. Month should be numeric.';
var ddErrMsg='Incorrect format. Date should be numeric.';
var yyErrMsg='Incorrect format. Year should be numeric.';
var submittedDateErrMsg1='Please enter Submitted Start Date or leave Submitted End Date blank.';
var submittedDateErrMsg2='Submitted End Date should not be earlier than Submitted Start Date.';
var openDateErrMsg1='Please enter Open Start Date or leave Open End Date blank.';
var openDateErrMsg2='Open End Date should not be earlier than Open Start Date.';
var lastUpdatedDateErrMsg1='Please enter Last Updated Start Date or leave Last Updated End Date blank.';
var lastUpdatedDateErrMsg2='Last Updated  End Date should not be earlier than Last Updated  Start Date.';
var storeErrorMsg='Invalid Store ID. Store ID not found in the list.';

//***************************validateForm*****************************************
// This function is called on clicking the submit button
// It validates all the fields in the form, and after validations submits the form.
//********************************************************************************
function validateForm(form,actionValue){
form.action.value=actionValue;
	var phoneNum=form.phone;
	if( validateCardId(form)
	//&& validatePhoneNumber(form) 
	&& validateLastName(form)
	&& validateClubCardId(form)
	&&phoneValidating(form,phoneNum)
	&&validateOtherFields(form)
	){
	form.submit();
	return true;
	}// end of if
}// end of validate form

//***************************validateCardId*****************************************
// This function is validates the card id.
//********************************************************************************
function validateCardId(form){
	cardId=(form.elements['commentCardId']);
	if(cardId.value.length ==0)
	return true;
	if(checkNumeric(cardId,true)){
		return true;
		}	// end of check alpha numeric if
		else {
			alert(commentCardIdErrMsg);
			cardId.focus();
			cardId.select();
			return false;
			}
	}// end of validateCardId

//***************************validateCardId*****************************************
// This function is validates the phone number.
//**********************************************************************************
function validatePhoneNumber(form){
var phone=form.elements['phone'];
var checker=1;
var lastName = form.elements['lastName'];
// check if the phone fields are empty. if they are empty then return true.
if(phone.value.length ==0){
return true;
//return false;
}// end of if
// if the phone is not empty then start validating.
if(phone.value.length !=0){
	if(!isNumeric(phone.value) || phone.value.length!=10){
		alert(phoneErrMsg);
		phone.focus();
		phone.select();
		return false;
	}
	else{
		form.areaCode.value=phone.value.substring(0,3);
		form.phone1.value=phone.value.substring(3,6);
		form.phone2.value=phone.value.substring(6,10);
		return true;		
	}
	
}  // end of first if
return true;
}  // end of validate phone

//***************************validateCardId*****************************************
// This function is validates the Last Name.
//**********************************************************************************

function validateLastName(form){
var lastName = form.elements['lastName'];
	if(lastName.value.length ==0){
	return true;	
	}// end of if
	
	if(checkAlphabeticSpaceQuote(lastName,true)){
	return true;
		}// end of if
	else {
		alert(lastNameErrMsg);
		lastName.focus();
		lastName.select();
		return false;
		}// end of else
}// end of validateLastName

//***************************validateCardId*****************************************
// This function is validates the Club Card Id.
//**********************************************************************************
function validateClubCardId(form){
var clubCardId = form.elements['clubCardId'];
	if(clubCardId.value.length ==0)
	return true;
	if(checkAlphaNumeric(clubCardId,true)){
		return true;
	}//end of if
	else {
		alert(clubCardIdErrMsg);
		clubCardId.focus();
		clubCardId.select();
		return false;
		} // end of eelse
} // end of function

//***************************validateCardId************************************************************
// This function is validates the remaining fields (ie) commentCardId.dates,firstname,lastupdatedby etc.
//*****************************************************************************************************
function validateOtherFields(form){
var commentCardId = form.elements['commentCardId'];
var cardSource = form.elements['cardSource'].options[form.elements['cardSource'].selectedIndex];
var cardStatus=  form.elements['cardStatus'].options[form.elements['cardStatus'].selectedIndex];
var cmmtTypeId=  form.elements['cmmtTypeId'].options[form.elements['cmmtTypeId'].selectedIndex];
var division = form.elements['division'].options[form.elements['division'].selectedIndex];
var store=form.elements['store'];
//var store = form.elements['store'].options[form.elements['store'].selectedIndex];
var clubCardId = form.elements['clubCardId'];
var phone= form.elements['phone'];
var lastName = form.elements['lastName'];
var firstName = form.elements['firstName'];
var submittedStartDate = form.elements['submittedStartDate'];
var submittedEndDate = form.elements['submittedEndDate'];
var openStartDate = form.elements['openStartDate'];
var openEndDate = form.elements['openEndDate'];
var lastUpdatedStartDate = form.elements['lastUpdatedStartDate'];
var lastUpdatedEndDate = form.elements['lastUpdatedEndDate'];
var openedBy = form.elements['openedBy'];
var lastUpdatedBy = form.elements['lastUpdatedBy'];
var submittedStartDateMM = form.elements['submittedStartDateMM'];
var submittedStartDateDD = form.elements['submittedStartDateDD'];
var submittedStartDateYY = form.elements['submittedStartDateYY'];

var submittedEndDateMM = form.elements['submittedEndDateMM'];
var submittedEndDateDD = form.elements['submittedEndDateDD'];
var submittedEndDateYY = form.elements['submittedEndDateYY'];

var openEndDateMM = form.elements['openEndDateMM'];
var openEndDateDD = form.elements['openEndDateDD'];
var openEndDateYY = form.elements['openEndDateYY'];

var openStartDateMM = form.elements['openStartDateMM'];
var openStartDateDD = form.elements['openStartDateDD'];
var openStartDateYY = form.elements['openStartDateYY'];

var lastUpdatedStartDateMM = form.elements['lastUpdatedStartDateMM'];
var lastUpdatedStartDateDD = form.elements['lastUpdatedStartDateDD'];
var lastUpdatedStartDateYY = form.elements['lastUpdatedStartDateYY'];

var lastUpdatedEndDateMM = form.elements['lastUpdatedEndDateMM'];
var lastUpdatedEndDateDD = form.elements['lastUpdatedEndDateDD'];
var lastUpdatedEndDateYY = form.elements['lastUpdatedEndDateYY'];


// check if any of the fields is entered. if nothing is entered throw an alert.

if(
(commentCardId.value.length == 0)
&&(cardSource.value.length == 0)&&
(cardStatus.value.length == 0)&&
(division.value.length == 0)&&
(store.value.length == 0)&&
(clubCardId.value.length == 0)&&
(phone.value.length == 0)&&
(lastName.value.length == 0)&&
(firstName.value.length == 0)&&
(submittedStartDate.value.length == 0)&&
(submittedEndDate.value.length == 0)&&
(openStartDate.value.length == 0)&&
(openEndDate.value.length == 0)&&
(lastUpdatedStartDate.value.length == 0)&&
(lastUpdatedEndDate.value.length == 0)&&
(openedBy.value.length == 0)&&
(lastUpdatedBy.value.length == 0)&&
(cmmtTypeId.value.length==0)
){
alert(lastNameErrMsg2);
lastName.focus();
return false;
}// end of if



if((firstName.value.length != 0)){
	if(!validateNames(form,firstName,firstNameErrMsg)){
		return false;
		}
		
	}// end of if


if(
checkStore(form)&&
validateStartDate(submittedStartDate,submittedStartDateMM,submittedStartDateDD,submittedStartDateYY,submittedStartDateErrMsg) &&
validateStartDate(submittedEndDate,submittedEndDateMM,submittedEndDateDD,submittedEndDateYY,submittedEndDateErrMsg) &&
validateEndDate(form,submittedEndDate,submittedStartDate,submittedDateErrMsg1,submittedDateErrMsg2)&&
validateStartDate(openStartDate,openStartDateMM,openStartDateDD,openStartDateYY,openStartDateErrMsg)&&
validateStartDate(openEndDate,openEndDateMM,openEndDateDD,openEndDateYY,openEndDateErrMsg)&&
validateEndDate(form,openEndDate,openStartDate,openDateErrMsg1,openDateErrMsg2) &&  
validateStartDate(lastUpdatedStartDate,lastUpdatedStartDateMM,lastUpdatedStartDateDD,lastUpdatedStartDateYY,lastUpdatedStartDateErrMsg) &&
validateStartDate(lastUpdatedEndDate,lastUpdatedEndDateMM,lastUpdatedEndDateDD,lastUpdatedEndDateYY,lastUpdatedEndDateErrMsg) &&
validateEndDate(form,lastUpdatedEndDate,lastUpdatedStartDate,lastUpdatedDateErrMsg1,lastUpdatedDateErrMsg2) &&
validateUserId(form,openedBy,openedByErrMsg) &&
validateUserId(form,lastUpdatedBy,lastUpdatedByErrMsg)
)
{return true;}
}// end of validateOtherFields

//*****************************validateAlphaNumeric*****************************************
// This function validates for alphanumeric value.
// It is called by validateotherields function.
//******************************************************************************************

function validateAlphaNumeric(form,objField,errMsg){
if(checkAlphaNumericQuote(objField,true)){
	return true;
	}	// end of check alpha numeric if
	else {
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
		}
	}
//*****************************validateName*****************************************
// This function validates for Names.
// It is called by validateotherields function.
//******************************************************************************************

function validateNames(form,objField,errMsg){
if(checkAlphabeticSpaceQuote(objField,true)){
	return true;
}
else{  
	alert(errMsg);
	objField.focus();
	objField.select();
	return false;
	}
}
//*****************************validateDateFld*****************************************
// This function validates for dates .
// It is called by validateotherields function.
//******************************************************************************************

function validateStartDate(StartDate,StartDateMM,StartDateDD,StartDateYY,ErrMsg) {
		if(StartDate.value.length==0) 
			return true;
		if(!dateValidating(StartDate,StartDateMM,StartDateDD,StartDateYY)){
			//alert(ErrMsg);
			//StartDate.focus();
			//StartDate.select();
			return false;
		} 
		if((StartDate.value=="00/00/00")||(StartDate.value=="00/00/0000")){
			alert("Start Date should not be in 00/00/00 or 00/00/0000 format.");
			StartDate.focus();
			return false;  
		}
		if(!isDate(StartDate,0001,2000,0,31,true)){    
			allValid=false;
			return false;
		}
	return true;
}


function validateUserId(form,objField,errMsg){

	if(checkAlphaNumericQuoteUnderScore(objField,true)){
		return true;
	}
	else{  
		alert(errMsg);
		objField.focus();
		objField.select();
		return false;
	}
}
//*****************************validateEndDate*****************************************
// This function validates for dates .
// It is called by validateotherields function.
//******************************************************************************************

function validateEndDate(form,EndDate,StartDate,errorMessage1,errorMessage2) {

var commentCardId = form.elements['commentCardId'];
var phone1 = form.elements['areaCode'];
var phone2 = form.elements['phone1'];
var phone3= form.elements['phone2'];
var lastName = form.elements['lastName'];

	if(EndDate.value.length==0)
		return true;
	
	
	if(
	(commentCardId.value.length == 0)&&
	(phone1.value.length == 0)&&
	(phone2.value.length == 0)&&
	(phone3.value.length == 0)&&
	(lastName.value.length == 0)){
		if(StartDate.value.length==0){
				alert(errorMessage1);
				StartDate.focus();
				return false;
			}
	}
	if(!compareDates(StartDate,EndDate)){  
				alert(errorMessage2);
				StartDate.focus();
			return false;
	}

	return true;
}
//***************************onlySubmit*****************************************
// This function is called on change of the division list box.
//******************************************************************************
function listFill(form){
	var listBox2=document.searchCommentCardForm.store;
    	var listBox1=document.searchCommentCardForm.division;
    	var len=listBox2.length;
    	var ind1=0;
    	ind1=listBox1.selectedIndex;
    	var arr2len=listArr[ind1].length;
	for(var k=0;k<len;k++)
		listBox2.options[k]=new Option();
	for(var i=0;i<arr2len;i++){
     		listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	listBox2.options.length=arr2len+1;
    	listBox2.options.selectedIndex=0;
}





function resetingForm(form){
form.elements['commentCardId'].value="";
form.elements['cardSource'].selectedIndex=0;
form.elements['cardStatus'].selectedIndex=0;
form.elements['division'].selectedIndex=0;
form.elements['clubCardId'].value="";
form.elements['phone'].value="";
form.elements['lastName'].value="";
form.elements['firstName'].value="";
form.elements['store'].value="";
form.elements['submittedStartDate'].value="";
form.elements['submittedEndDate'].value="";
form.elements['openStartDate'].value="";
form.elements['openEndDate'].value="";
form.elements['lastUpdatedStartDate'].value="";
form.elements['lastUpdatedEndDate'].value="";
form.elements['openedBy'].value="";
form.elements['lastUpdatedBy'].value="";
form.elements['cmmtTypeId'].value="";
form.elements['commentCardId'].focus();	


}// end of function





//***************************onlySubmit*****************************************
// This function is called on change of the division list box.
//******************************************************************************
function checkStore(form){
	var listBox2=document.searchCommentCardForm.store;
    	var listBox1=document.searchCommentCardForm.division;
    	var ind1=0;
    	ind1=listBox1.selectedIndex;
    	
    	/**if(ind1==0){
    		return true;
    		}*/
    	
    	
    	var arr2len=listArr[ind1].length;
	//var storeArray= new Array([arr2Len]);	
	if(listBox2.value.length==0){
		return true;	
		}
	
	for(var i=0;i<arr2len;i++){
		if(listBox2.value ==(listArr[ind1][i])){
			return true;
     		//listBox2.options[i+1]=new Option(listArr[ind1][i],listArr[ind1][i],false,false);
    	}
    	else if(i==(arr2len-1)){
    		alert(storeErrorMsg);
    		listBox2.focus();
    		listBox2.select();
    		return false;    		
    		}
    	
}

}








//****************************end of file *****************************************