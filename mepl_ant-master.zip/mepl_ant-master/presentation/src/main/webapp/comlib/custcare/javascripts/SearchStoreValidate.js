/********************************************************************************************
Project Name				:Safeway  
Module Name	   			:Search
Program Name				:SearchStoreValidate.js	
Program Version				:1.0.0 	
Program Description			:This is the  java script file in which does all the 
	                                 validations of the SearchStore
Called From				:SearchStore.jsp
Calling					:Common.js 	
Modification History 	      		:
------------------------------------------------------------------------------------------------------------
Author   Date(MM/DD/CCYY)	Version   Modification Details          ChangeRequestReferenceinthe code
-----------------------------------------------------------------------------------------------------------
Nirmala     09/02/2000  		1.0.0	    NA                                N.A
Jeyaprakash
NAHAR	    09/12/2000			1.1.0		done date formatting 	CHG-005
***********************************************************************************************************/

//declare the help messages
var EMPTY_STRING="";
var storeNumberMsg='Enter the store number.';
var cityMsg='Enter the city.';
var stateOrProvMsg='Enter the state or province.';
var postalCodeMsg='Enter the postal code.';
var searchMsg='Click this to search the store.';
var resetMsg='Click this to reset the form.';
var exactSearchMsg='Check this for the exact search.';

//declare the error messages.

var storeNumberErrMsg='Incorrect format. Store Number should be numeric.';
var cityErrMsg='Incorrect format. City should be alphanumeric.';
var stateErrMsg='Incorrect format. State should be alphabetic.';
var postalCodeErrMsg='Incorrect format. Zip Code should be alphanumeric.';
var errMsg='Please enter at least State for the Store Search.';

//***************************validateForm*****************************************
// This function is called on clicking the submit button
// It validates all the fields in the form, and after validations submits the form.
//********************************************************************************
function validateForm(form,actionValue){
	if(form.isExactSearch.checked){
		form.isExactSearch.value=true;
	}else {
		form.isExactSearch.value=false;
	}
	
	form.action.value=actionValue;
	city=form.city;
	zip=form.postalCode;
	submitForm="T";
	state=form.state;
	if(!validateFields(form))
		submitForm="F";
	else if(!validateFacilityId(form))
		submitForm="F";
	else if(!validateCity(form))
		submitForm="F";
	else if(!validateState(form,state))
		submitForm="F";
	else if(!validatePostalCode(form,zip))
		submitForm="F";
	
	if(submitForm=="T")
		form.submit();
}// end of validate form


//***************************validatefacilityId*****************************************
// This function is validates the store no.
//********************************************************************************
function validateFacilityId(form){
	facilityId=form.facilityId;
	if(facilityId.value.length ==0)
	return true;
	if(checkNumeric(facilityId,true)){
		return true;
		}	// end of check alpha numeric if
		else {
			alert(storeNumberErrMsg);
			facilityId.focus();
			facilityId.select();
			return false;
			}
	}// end of validatefacilityId
	
//***************************validateFields*****************************************
// This function is validates all the fields.
//********************************************************************************
	
function validateFields(form){
	if((form.facilityId.value.length==0)&&(form.city.value.length==0)&&(form.state.value.length==0)&&(form.postalCode.value.length==0)){
		alert(errMsg);
		form.state.focus();
		form.state.select();
		return false;
	}//end of if
	else{
		return true;
	}
	
}


//***************************validateCity*****************************************
// This function is validates City.
//********************************************************************************

function validateCity(form){	
	city=form.city;
	if(city.value.length ==0)
	return true;
	if(checkAlphaNumericSpaceDotQuote(city,true)){
			return true;
			
		}
		else{
			alert(cityErrMsg);
			city.focus();
			city.select();
			return false;
		}
	}	

//***************************validateState*****************************************
// This function is validates state.
//********************************************************************************

function validateState(form,objField){
	if(!form.isExactSearch.checked){
		if(!checkAlphabetic(objField,true)){
			alert(stateErrMsg);
			objField.focus();
			objField.select();
			return false;
			}else{		
				return true;
				}
	}
	if(!checkStateProvCd(objField,true)){
		return false;
	}
	else return true;
}
	
//******************validateZip***************************************
//Description	:This function validates the State for alphabetic
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************

function validatePostalCode(form,objField){
	if(!form.isExactSearch.checked){
		
		if(!checkAlphaNumericSpace(objField,true)){
			alert(postalCodeErrMsg);
			objField.focus();
			objField.select();
			return false;
			}else{		
				return true;
				}
	}
	if(!checkPostalCd(objField,true)){
		return false;
		
	}
	else return true;	
	
}

//***************************clearScreen*****************************************
// This function clears the screen on reset.
//********************************************************************************

function clearScreen(form){
	form.facilityId.value="";
	form.city.value="";
	form.state.value="";
	form.postalCode.value="";
	form.isExactSearch.checked=false;
	form.facilityId.focus();
	}

//******************exactSearch************************************************
//Description	:This function sets the  value  for checkbox
//Parameter	:objField,errorMessage
//return	:boolean
//*****************************************************************************
/*function exactSearching(form){
	if(form.isExactSearch.checked){
		form.isExactSearch.value=true;
	}else {
		form.isExactSearch.value=false;
	}
	

}*/// end of function

/*function checkCityName(city,state)
{
temp=checkAlphabetic(city,state)	
if(temp)
{
return true;
}
alert(cityErrMsg);
city.focus();
city.select();
return false;
}*/
//****************************end of file *****************************************

//***************************showDialog********************************************
// This function shows a new window with the store details on clicking a hyperlink
//********************************************************************************
var xyz="";
function showDialog(storeNo,division,phNo,dist,mngrId,fx,hr,prkSpc,sqFt,address,city,state,zip){
	if(xyz.name=="StoreInformationWindow")
		xyz.close();
	var href=location.href.substring(0,location.href.lastIndexOf("/")+1);
	/*replacing # character with ^ and space with ~ in 
	all the parameters to the query string */
	address=address.replace("#","^");
	var addrArr=address.split(" ");
	var addr="";
	var addrArrLen=addrArr.length;      
	for(var j=0;j<addrArrLen;j++)
	  if(addrArr[j].length>0)
	    addr=addr+addrArr[j]+"~";
	
	var cityArr=city.split(" ");
	var city="";
	var cityArrLen=cityArr.length;      
	for(var j=0;j<cityArrLen;j++)
	  if(cityArr[j].length>0)
	    city=city+cityArr[j]+"~";
	    
	var zipArr=zip.split(" ");
	var zip="";
	var zipArrLen=zipArr.length;      
	for(var j=0;j<zipArrLen;j++)
	  if(zipArr[j].length>0)
	    zip=zip+zipArr[j]+"~";
	    
	var fxArr=fx.split(" ");
	var fx="";
	var fxArrLen=fxArr.length;      
	for(var j=0;j<fxArrLen;j++)
	  if(fxArr[j].length>0)
	    fx=fx+fxArr[j]+"~";	    
	    
	var phoneArr=phNo.split(" ");
	var phNo="";
	var phoneArrLen=phoneArr.length;      
	for(var j=0;j<phoneArrLen;j++)
	  if(phoneArr[j].length>0)
	    phNo=phNo+phoneArr[j]+"~";	    
	
	var hrArr=hr.split(" ");
	var hr="";
	var hrArrLen=hrArr.length;      
	for(var j=0;j<hrArrLen;j++)
	  if(hrArr[j].length>0)
	    hr=hr+hrArr[j]+"~";	    
	    
	var parkSpcArr=prkSpc.split(" ");
	var prkSpc="";
	var parkSpcLen=parkSpcArr.length;      
	for(var j=0;j<parkSpcLen;j++)
	  if(parkSpcArr[j].length>0)
	    prkSpc=prkSpc+parkSpcArr[j]+"~";	    
	    
	var sqFeetArr=sqFt.split(" ");
	var sqFt="";
	var sqFeetArrLen=sqFeetArr.length;      
	for(var j=0;j<sqFeetArrLen;j++)
	  if(sqFeetArr[j].length>0)
	    sqFt=sqFt+sqFeetArr[j]+"~";	    
	
	    
	var url=href+"StoreInfo.jsp?storeId="+storeNo+"&division="+division+"&phoneNo="+phNo+"&district="+dist+"&managerId="+mngrId+"&fax="+fx+"&hours="+hr+"&parkingSpaces="+prkSpc+"&squareFeet="+sqFt+"&addr="+addr+"&city="+city+"&state="+state+"&zipCode="+zip;
	xyz=window.open(url,"StoreInformationWindow","copyhistory=no,height=300,width=500,menubar=no,toolbar=no,scrollbar=no,resizable=yes");
	return false;
}
  