/**
 * resize.js 0.3 970811
 * by gary smith
 * js component for "reloading page onResize"


// original Reload page only once
	if(!window.saveInnerWidth) {
	  window.onresize = resizeIt;
	  window.saveInnerWidth = window.innerWidth;
	  window.saveInnerHeight = window.innerHeight;
	}
*/

// Changed By FN 12/18/1998 to Reload page on every Resize
  window.onResize = resizeIt;
  window.saveInnerWidth = window.innerWidth;
  window.saveInnerHeight = window.innerHeight;


function resizeIt() {
    if ((saveInnerWidth != window.innerWidth) || (saveInnerHeight != window.innerHeight )) 
           window.history.go(0);
}

 
