function openDivisionalSite(div){
var noSiteMsg = "No divisional site currently active.";
switch (div){
	case "CAN":
		top.location.href = "/canada/index.htm";
		break;
    case "DEN":
		alert(noSiteMsg);
		break;
    case "SEA":
		top.location.href = "/seattle/forms/index.htm";
		break;		
	case "DOM":
		top.location.href = "/dominicks/forms/index.htm";	
		break;
	case "EAS":
		top.location.href = "/eastern/forms/index.htm";
		break;
	case "GEN":
		alert(noSiteMsg);	
		break;
	case "NOR":
		top.location.href = "/norcal/forms/index.htm";	
		break;
	case "PHO":
		top.location.href = "/corpcom/special_projects/phx/";	
		break;
	case "POR":
		alert(noSiteMsg);	
		break;
	case "HOU":
		top.location.href = "/tex/";		
		break;
	case "VON":
		top.location.href = "/vons/";		
		break;
}
}

function news(form) {
	var myindex=form.NewsChange.selectedIndex;
	if (form.NewsChange.options[myindex].value != 0) {
	location=form.NewsChange.options[myindex].value;}
}

function openCoDir(){
	popUpWindow("/corpcom/codir/index.htm", 100, 100, 675, 500);
}

var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height){
  if(popUpWin){
    if(!popUpWin.closed) popUpWin.close();
  }
  popUpWin = open(URLStr, 'popUpWin', 'toolbar=yes,location=no,directories=no,status=no,menubar=no,scrollbar=yes,resizable=no,copyhistory=yes,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}