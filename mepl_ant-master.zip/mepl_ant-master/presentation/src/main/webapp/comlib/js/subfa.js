//make sure size is as big as menu
var size = 1;
		
window.subFaGoTo = new Array(size);
window.subFaTopic = new Array(size);

window.subFaTopic[0] = "" ;
window.subFaGoTo[0] = "";

