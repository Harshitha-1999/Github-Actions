var sContact = "web.communications@safeway.com"

aTopicMenu = new Array();

var sMenuIndex = -1;



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Accounting";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/acct/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Communications";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/corpcom/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Customer Care";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/customer_care/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Facilities";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/facility/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Finance";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/finance/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Gov't Relations";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "http://www.vocusgr.com/gr/WebPublish/controller.aspx?SiteName=Safeway&Definition=Home&SV_Section=Home";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Human Resources";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/hr/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Privacy/InfoSecurity";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/info_privacy/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Info Technology";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/it/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Investor Relations";

aTopicMenu[sMenuIndex].target = "vertcontent";

aTopicMenu[sMenuIndex].linkto = "http://phx.corporate-ir.net/phoenix.zhtml?c=64607&p=irol-irhome";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Marketing";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/mktg/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Real Estate";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/real_estate/index.htm";



sMenuIndex++;

aTopicMenu[sMenuIndex] = new Object();

aTopicMenu[sMenuIndex].title = true;

aTopicMenu[sMenuIndex].alt    = "Risk Management";

aTopicMenu[sMenuIndex].target = "_top";

aTopicMenu[sMenuIndex].linkto = "/riskmgmt/index.htm";





