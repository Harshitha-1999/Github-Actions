

function makeDistributionList(check_value) {

document.mncproductalert.ModifyList.checked = false;

if (document.all)
		var xMax = screen.width, yMax = screen.height;
	    else
		if (document.layers)
		    var xMax = window.outerWidth, yMax = window.outerHeight;
		else
		    var xMax = 640, yMax=480;

	    var xOffset = (xMax)/2;
	    var yOffset = (yMax)/2;
	var loading='width='+xMax+',height='+yMax+',top=0,left=0,';
	popwin=window.open("","mywindow",loading);
	popwin.document.open();
	popwin.document.write("<title>Product Alert - Distribution List</title>");
	popwin.document.write("<head>");
	popwin.document.write("<script LANGUAGE='JavaScript'>");

	popwin.document.write("function AddMakeDistributionList() {");

	popwin.document.write("self.opener.document.mncproductalert.DistributionList.value = ''");
	popwin.document.write(";");

		popwin.document.write("for (i=0");
		popwin.document.write(";");
		popwin.document.write("i<");
		popwin.document.write("document.prodrecall2.length-1");
		popwin.document.write(";");
		popwin.document.write("i++){");

			popwin.document.write("if (document.prodrecall2.elements[i].value.length != 0){");
				popwin.document.write("self.opener.document.mncproductalert.DistributionList.value = self.opener.document.mncproductalert.DistributionList.value");
				popwin.document.write("+");
				popwin.document.write("'; '");
				popwin.document.write("+ ");
				popwin.document.write("document.prodrecall2.elements[i].value");
			popwin.document.write("}");

		popwin.document.write("}");

	popwin.document.write(";");
	popwin.document.write("self.opener.document.mncproductalert.DistributionList.value = self.opener.document.mncproductalert.DistributionList.value.substr(2,self.opener.document.mncproductalert.DistributionList.value.length)");
	popwin.document.write(";");
	popwin.document.write("self.opener.focus()");
	popwin.document.write(";");
	popwin.document.write("}");

	popwin.document.write("</script>");

	popwin.document.write("</head>");
	popwin.document.write("<body bgcolor=White>");
	popwin.document.write("<form name='prodrecall2' enctype='multipart/form-data'>");

	popwin.document.write("<table>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Division");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("Director of Retail Services");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("Director of Sales");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("Distribution Center Manager");
	popwin.document.write("</td>");
	popwin.document.write("</tr>");

	if (document.mncproductalert.Canada.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Canada");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='CanadaRetail' value='' size=30>");
		popwin.document.write("</td>");
		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='CanadaSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='CanadaManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Dominicks.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Dominicks");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='DominicksRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='DominicksSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='DominicksManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Denver.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Denver");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='DenverRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='DenverSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='DenverManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Eastern.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Eastern");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='EasternRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='EasternSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='EasternManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Genuardis.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Genuardis");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='GenuardisRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='GenuardisSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='GenuardisManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Norcal.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("NorCal");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='NorCalRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='NorCalSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='NorCalManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Phoenix.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Phoenix");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='PhoenixRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='PhoenixSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='PhoenixManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Portland.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Portland");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='PortlandRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='PortlandSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='PortlandManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Seattle.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Seattle");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='SeattleRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='SeattleSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='SeattleManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Vons.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Vons");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='VonsRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='VonsSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='VonsManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}
	if (document.mncproductalert.Texas.checked)
	{
		popwin.document.write("<tr>");

		popwin.document.write("<td>");
		popwin.document.write("Texas");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='TexasRetail' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='TexasSales' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("<td>");
		popwin.document.write("<input type='text' name='TexasManager' value='' size=30>");
		popwin.document.write("</td>");

		popwin.document.write("</tr>");
	}


	popwin.document.write("</table>");



	popwin.document.write("<table>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Procurement Specialist");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='Procurement' value='' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("VP Public Affairs");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='VP_Public_Affairs' value='brian.dowling@safeway.com' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Senior Corporate Counsel");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='Senior_Corporate_Counsel' value='valerie.lewis@safeway.com' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Corporate Director Food Safety");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='Corporate_Director_Food_Safety' value='chuck.stoffers@safeway.com' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("VP Consumer Demand");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='VP_Consumer_Demand' value='' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Corporate PRC Manager");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='Corporate_PRC_Manager' value='bruce.hayworth@safeway.com' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Corporate Brands QA Manager");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='Corporate_Brands_QA_Manager' value='david.lawrence1@safeway.com' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("<tr>");
	popwin.document.write("<td>");
	popwin.document.write("Corporate Brands Admin");
	popwin.document.write("</td>");
	popwin.document.write("<td>");
	popwin.document.write("<input type='text' name='Corporate_Brands_Admin' value='kathi.dodson@safeway.com' size=30>");
	popwin.document.write("</td>");
	popwin.document.write("<tr>");

	popwin.document.write("</table>");

	popwin.document.write("<input type='checkBox' name='AddModifyList' onclick='AddMakeDistributionList(this)'>Add Names to Distribution List");

	popwin.document.write("</form>");
	popwin.document.write("</body>");
	popwin.document.close();
	popwin.focus();
}

