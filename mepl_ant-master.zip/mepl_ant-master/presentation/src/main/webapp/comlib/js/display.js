// by FN 7/1/99
// returns array (weekDay, month, date, year)
// write to the page whichever part(s) is needed

function TodayDate(){
		var curdate = new Date();
		var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
		var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

		var temp_year = curdate.getFullYear();
		var date = new Array();
		date["day"]=days[curdate.getDay()];
		date["month"]=months[curdate.getMonth()];
		date["date"]= curdate.getDate();
		date["year"]=temp_year;
		
		return date;
}

function displayDate(){
	curdate = new Date();
	var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

	date = months[curdate.getMonth()] + " " + curdate.getDate() + ", " + curdate.getFullYear();
	return(date);
}


function displayShortDate(){
	curdate = new Date();
	var months = new Array("01","02","03","04","05","06","07","08","09","10","11","12");
	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

	date = months[curdate.getMonth()] + "/" + curdate.getDate() + "/" + curdate.getFullYear();
	return(date);
}
