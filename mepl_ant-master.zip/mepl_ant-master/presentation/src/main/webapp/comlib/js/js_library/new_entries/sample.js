/*
Author...............: Jason Parks
Contact Number.......: 1-403-730-3599
File Name............: foo_bar.js
Description..........: This function or group of functions will perform what operation.
Date Submitted.......: 01/01/2004
*/

/*
Function Name....: standardDeviation
Description......: Calculates the standard deviation from an arrays of numbers.
Parameters.......: arg1 - first array of numeric values
				   arg2 - second array of numeric value
				   arg3 - third array of numeric value
Returns..........: Standard Deviation
*/
function standardDeviation(arg1,arg2,arg3){
	var retVal = "Here is the standard deviation. Well Maybe.";
	
	//calculate here
	return retVal;
}
      