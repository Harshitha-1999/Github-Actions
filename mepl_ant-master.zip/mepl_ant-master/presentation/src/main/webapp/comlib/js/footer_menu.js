function showMenu(){
	if (sCore == 'store' || 
			sServer == 'http://store.safeway.com:81' || 
			sServer == 'http://store:81') {
		document.write('<a href="/store" target="_top">Home</a> | <a href="/search">Search</a> | <a href="/storemenu/index.htm?lnk_menu_id=12&lnk_sub_menu_id=0" target="_top">Help</a>');
		}
	else {
		document.write('<a href="/acct" target="_top">Accounting</a> | <a href="/corpcom" target="_top">Communications</a> | <a href="/customer_care" target="_top">Customer Care</a> | <a href="/dist" target="_top">Distribution</a> | <a href="/facility" target="_top">Facilities</a> | <a href="/finance" target="_top">Finance</a>', 
						'<br>',
						'<a href="/hr" target="_top">Human Resources</a> | <a href="/info_privacy" target="_top">Info Privacy</a> | <a href="/it" target="_top">Information Technology</a> | <a href="http://phx.corporate-ir.net/phoenix.zhtml?c=64607&p=irol-irhome">Investor Relations</a> | <a href="/mktg" target="_top">Marketing</a>',
						'<br>',
						'<a href="/real_estate" target="_top">Real Estate</a> | <a href="/riskmgmt" target="_top">Risk Management</a> | <a href="/supply" target="_top">Supply</a> | <a href="/help" target="_top">Help</a> | <a href="/mepl/main.html" target="_top">Home</a>');
		}
}
showMenu();