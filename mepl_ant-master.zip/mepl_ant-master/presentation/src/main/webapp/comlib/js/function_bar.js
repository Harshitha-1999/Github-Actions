//
//Author........: Jaspal Sandhu
//File Name.....: function_bar.js
//Web Site......: 
//Description...: Build application/page specific horizontal bar.
// 
// DO NOT EDIT!!

var totalGraphics =0;
var graphic = new Array();
var curStatus = "";
var picked=-1;	//Picked graphic - set initial value.
var highlighted = -1; //highlighted - set initial value.

//Create Graphic object
function HTBarGraphic(appname,width,height,name,link,statusText) {
	this.appname	= appname; 	//Graphic name prefix used for searching
	this.height 	= height;
	this.width 		= width;
	this.name 		= name; 	//Graphic name prefix used for searching
	this.link 		= link; 	//HREF URL - page to which graphic links
	this.off 		= new Image(width,height);	//Plain version of 
	this.off.src	= imageSubDir + imagePrefix + name + offSuffix;
	this.offname	= imageSubDir + imagePrefix + name + offSuffix;
	if (link != "") {
		//Highlighted (Mouse Over) -"On"
		this.on 	= new Image(width,height);	//Plain version of
		this.on.src = imageSubDir + imagePrefix + name + onSuffix;
		//Selected (Mouse Click) -"Pick"
		this.pick 	= new Image(width,height);	//Plain version of
		this.pick.src = imageSubDir + imagePrefix + name + pickSuffix;
	
		this.statusText = statusText;
	}
	
}


//Build Array of graphic objects
function createHTBarGraphic(appname,width,height,name,link,statusText) {
	graphic[totalGraphics] = new HTBarGraphic(appname,width,height,name,link,statusText);
	totalGraphics++;
}

//Change graphic to 'Picked' position
function doClick(num) {
	document.images[graphic[num].name].src = graphic[num].pick.src;
	if (num != picked && picked > 0) {
		 document.images[graphic[picked].name].src = graphic[picked].off.src;
	}
	picked = num;
}
//OnMouseOver
function doMouseOver(num) {
	curStatus = window.status;
	if (num != picked) {
		document.images[graphic[num].name].src = graphic[num].on.src;
		
	}
	if (highlighted != picked && highlighted != num && highlighted >0) {
			document.images[graphic[highlighted].name].src = graphic[highlighted].off.src;
	}
	highlighted = num;
	self.status = graphic[num].statusText;
}

//OnMouseOut
function doMouseOut(num) {
	if (highlighted != picked) {
			document.images[graphic[highlighted].name].src = graphic[highlighted].off.src;
	}
	self.status = curStatus;
}

function doOnLoad(num) {
	currentPage = document.location.href;
//	alert(currentPage);

	for (i=0; i < totalGraphics; i++) {
		if (currentPage.indexOf(graphic[i].name) > 0) {
			doClick(i);
			return(1);
		}
	}
	if ( i >= totalGraphics) {
		doClick(num);
	}
	return (-1);
}

//Size of the toolbar images you created.
var imageWidth =80;
var imageHeight=20;
//Location of images directory.
imageSubDir = "lib/images/";
//Define prefix for your images
imagePrefix = "htbar_";
//Define off suffix
offSuffix = "_off.gif";
//Define on suffix
onSuffix = "_on.gif";
//Define pick suffix
//pickSuffix = "_pick.gif";
pickSuffix = "_on.gif";



function HTBarApp(sAppName,sLinks,sStatusText) {
var	shtml = "";
	if( sLinks.length == 0 ){
//		shtml = '<div align="right">';
		shtml = '<table width="460" border="0" cellspacing="0" cellpadding="0"><tr bgcolor="#ffffff" >'
		shtml += '<td width="1" height="4"  bgcolor="white"></td>';  
		shtml += '<td height="4">';  
		shtml += '   <div align="left"><b><font face="Arial, Helvetica, sans-serif" size="2">' + sAppName + '</font></b></div> ';
		shtml += '</td></tr></table>';
		
		document.write(shtml);
	}
	
	else {
		var arrLinks = sLinks.split(",");
		var itemCount = arrLinks.length;
		var arrStatusText = sStatusText.split(",");
		//var itemCount = arrStatusText.length;
		
		for (var i=0; i < itemCount; i++) {
			createHTBarGraphic(sAppName,imageWidth,imageHeight,arrLinks[i],arrLinks[i] + ".htm",arrStatusText[i]);
		}
i = 0;
if( totalGraphics < 5)
	num_of_imgs = totalGraphics;
else
	num_of_imgs = 5;
while( i < totalGraphics){
		shtml += '<table width="600" border="0" valign="top" cellspacing="0" cellpadding="0" >\n'; 
	    shtml += '<tr bgcolor=#ffffff>';  
		for ( var j = 0; j < num_of_imgs; j++, i++) {
			if( i <	totalGraphics){
				//	FN 3/18/99 NS3 not supported	if ((sLinks.search(graphic[i].name) != -1) || (sLinks.search("All") != -1)) {
				if ((sLinks.indexOf(graphic[i].name) != -1) || (sLinks.indexOf("All") != -1))
				{
					shtml += '<td  valign="top" height="4" width = "' + imageWidth + '">';
					shtml += '<div align="center">';
					shtml += '<a href="' + graphic[i].link + '" TARGET="_parent"';
					shtml += ' onMouseOver="doMouseOver(' + i + '); return true"';
					shtml += ' onMouseOut="doMouseOut(' + i + ')"';
					shtml += ' onClick="doClick(' + i + ')">';
					shtml += '<img name="' + graphic[i].name + '" src="'+ graphic[i].offname + '" width= ' + graphic[i].width + ' height= ' + graphic[i].height + ' border=0 alt="' + graphic[i].name + '">';
					shtml += '</a></div>';
					shtml += '</td>\n'; 
				}
				else {
					shtml += '<td width="' + imageWidth + '">&nbsp;</td>';
				}
			}
			else
				break;			
		}
		if( i < totalGraphics)
			shtml += '</tr><tr><td colspan="' + j +'"><div align="left"><img  src="/' + path[3] +'/corelib/images/bar.gif" width="460" height="1"></div></td></tr></table>';
}
if(j==5){
	shtml += '</tr></table><table width="460" border="0" valign="top" cellspacing="0" cellpadding="0">'; 	
    shtml += '<tr bgcolor=#ffffff>';  
}
shtml += '<td height="4" bgcolor="#ffffff">';  
shtml += '   <div align="center"><b><font face="Arial, Helvetica, sans-serif" size="2">' + sAppName + '</font></b></div>';
//shtml += '   <div align="right" ><font face="Arial, Helvetica, sans-serif" size="2"><b>' + graphic[0].appname + '</b></font></div> ';

if(totalGraphics>5){
	shtml += '</td><tr><td colspan="' + ((totalGraphics%5)+1) +'"><div align="left"><img  src="/' + path[3] +'/corelib/images/bar.gif" width="600" height="1"></div></td></tr>';
}
else{
	shtml += '</td><tr><td colspan="' + ((j%5)+1) +'"><div align="left"><img  src="/' + path[3] +'/corelib/images/bar.gif" width="600" height="1"></div></td></tr>';
}
shtml += '</table></form>';

		

		document.write(shtml); 		
	}
	window.status = window.document.title;
	return true;
}

