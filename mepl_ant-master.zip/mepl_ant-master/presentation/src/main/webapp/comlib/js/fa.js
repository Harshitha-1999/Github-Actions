// make sure size is as big as menu
var size = 1;
var sCoreSite = ""

window.faTopic = new Array(size);
window.faGoTo = new Array(size);
					
window.faTopic[0] = "" ;
window.faGoTo[0] = "";

window.faTopic[1] = "" ;
window.faGoTo[1] = "";

window.faTopic[2] = "" ;
window.faGoTo[2] = "";

