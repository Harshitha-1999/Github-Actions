MenuImages = new Array();

MenuImages[0] = new Array("/comlib/images/menu_buttons/init_off.gif",
							"/comlib/images/menu_buttons/init_off.gif",
							"init",
							"",
							"",
							"",
							"");


MenuImages[1] = new Array("/comlib/images/menu_buttons/it_butn_on.gif",
							"/comlib/images/menu_buttons/it_butn_off.gif",
							"it",
							"alt",
							"/it/index.htm",
							"/comlib/images/Core_elements/it/Corepginsert.gif",
							"<map name='it'>" +
							//"	  <area shape='rect' coords='375,123,468,141' href='devnet' target='_top' alt='devnet'>"+
							//"	  <area shape='rect' coords='361,100,468,118' href='socit' target='_top' alt='socit'>"+
							//"	  <area shape='rect' coords='388,75,468,97' href='dba' target='_top' alt='Data Base Admin'>"+
							//"	  <area shape='rect' coords='384,50,469,71' href='spot' target='_top' alt='S.P.O.T.'>"+
							//"	  <area shape='rect' coords='339,26,469,47' href='tech support' target='_top' alt='Tech Support'>"+
							//"	  <area shape='rect' coords='373,0,469,23' href='resources' target='_top' alt='Resources'>"+
							"	  <area shape='rect' coords='1,92,93,110' href='intranet' target='_top' alt='Intranet Infrastructure'>"+
							//"	  <area shape='rect' coords='0,68,117,90' href='archit' target='_top' alt='Enterprise Architecture'>"+
							//"	  <area shape='rect' coords='0,44,125,65' href='prod supp' target='_top' alt='Production Support'>"+
							//"	  <area shape='rect' coords='0,24,55,42' href='ssc' target='_top' alt='Safeway Software Company'>"+
							//"	  <area shape='rect' coords='0,15,-4,23'>"+
							//"	  <area shape='rect' coords='0,0,174,22' href='sys tech' target='_top' alt='System Technology'>"+
							"</map>");

MenuImages[2] = new Array("/comlib/images/menu_buttons/div_butn_on.gif",
							"/comlib/images/menu_buttons/div_butn_off.gif",
							"divisions",
							"alt",
							"/divisions/index.htm",
							"/comlib/images/Core_elements/divisions/divmapblur.jpg",
							"<MAP name='divisions'>" +
//					      	"	<AREA SHAPE='RECT' ALT='Portland' COORDS='212,47,223,63' HREF='portland'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Seattle' COORDS='218,27,229,42' HREF='seattle'>"+
//					      	"	<AREA SHAPE='RECT' ALT='NorCal' COORDS='214,65,225,78' HREF='norcal'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Vons' COORDS='217,85,259,98' HREF='vons'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Phoenix' COORDS='263,96,274,109' HREF='phoenix'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Denver' COORDS='258,57,270,73' HREF='denver'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Canada' COORDS='272,27,282,42' HREF='canada'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Dominicks' COORDS='289,63,361,75' HREF='dominicks'>"+
//					      	"	<AREA SHAPE='RECT' ALT='Eastern' COORDS='372,77,383,92' HREF='eastern'>"+
							"</MAP>");
MenuImages[3] = new Array("/comlib/images/menu_buttons/makt_butn_on.gif",
							"/comlib/images/menu_buttons/makt_butn_off.gif",
							"mark",
							"alt",
							"/humanResources/index.htm",
							"/comlib/images/Core_elements/backstage/Corepginsert.gif");

MenuImages[4] = new Array("/comlib/images/menu_buttons/hr_butn_on.gif",
							"/comlib/images/menu_buttons/hr_butn_off.gif",
							"hr",
							"alt",
							"",
							"/comlib/images/Core_elements/it/Corepginsert.gif");


MenuImages[5] = new Array("/comlib/images/menu_buttons/finance_butn_on.gif",
							"/comlib/images/menu_buttons/finance_butn_off.gif",
							"fiance",
							"alt",
							"",
							"/comlib/images/Core_elements/it/Corepginsert.gif");

MenuImages[6] = new Array("/comlib/images/menu_buttons/secur_butn_on.gif",
							"/comlib/images/menu_buttons/secur_butn_off.gif",
							"legal",
							"alt",
							"",
							"/comlib/images/Core_elements/it/Corepginsert.gif");


MenuImages[7] = new Array("/comlib/images/menu_buttons/other_butn_on.gif",
							"/comlib/images/menu_buttons/other_butn_off.gif",
							"addbus3",
							"alt",
							"",
							"/comlib/images/Core_elements/it/Corepginsert.gif");

function getBrowserVersion()
	{
	return version = (navigator.appVersion).substring(0,3);
	}

function build_MenuImages(MenuImageSelected)
	{
	window.MenuImageSelected = MenuImageSelected;
	for (i=0;i<MenuImages.length;i++)
		{
		if (MenuImages[i][2] == MenuImageSelected)
			{
			window.MenuImageSelectedIndex = i;
			}
		}
		
	for (i=0;i<MenuImages.length;i++)
		{
		if (MenuImages[i][2] == MenuImageSelected)
			{
			// selected menu item, on image
			document.write(
				"<a href='javascript://' target='_top'",
				"onclick='href = \"" + MenuImages[i][4] + "\";'",
				"onmouseover='ImgMouseOver(\"" + MenuImages[i][2] + "\", \"" + i + "\");'",
				"onmouseout='ImgMouseOut(\"" + MenuImages[i][2] + "\", \"" + i + "\", \"" + MenuImageSelectedIndex + "\");'",
				">",
					"<img src='" + MenuImages[i][0] + "'",
					" name='" + MenuImages[i][2] + "'",
					" alt='" + MenuImages[i][3] + "'",
					" width='120' height='20' border='0' align='top'",
					">",
				"</a>");
			}
		else
			{
			// nonselected menu items, off images
			document.write(
				"<a href='javascript://' target='_top'",
				"onclick='href = \"" + MenuImages[i][4] + "\";'",
				"onmouseover='ImgMouseOver(\"" + MenuImages[i][2] + "\", \"" + i + "\");'",
				"onmouseout='ImgMouseOut(\"" + MenuImages[i][2] + "\", \"" + i + "\", \"" + window.MenuImageSelectedIndex + "\");'",
				">",
					"<img src='" + MenuImages[i][1] + "'",
					" name='" + MenuImages[i][2] + "'",
					" alt='" + MenuImages[i][3] + "'",
					" width='120' height='20' border='0' align='top'",
					">",
				"</a>");
			}
		}

	if (MenuImages[window.MenuImageSelectedIndex][6])
		{
		document.write(MenuImages[window.MenuImageSelectedIndex][6]);
		}
	}

function ImgMouseClick(MenuImageClickedIndex, MenuImageClicked, MenuImageSelected)
	{
	this.href = MenuImages[MenuImageClickedIndex][4];
	}
	
function ImgMouseOver(MenuImageOver, MenuImageOverIndex)
	{
	// If the mouse over menu item is not the selected menu item,
	// the mouse over menu item is turned on and the mouse over menu item core page insert is displayed
	if (MenuImageOver != window.MenuImageSelected)
		{
		eval('document.' + MenuImageOver + '.src = "' + MenuImages[MenuImageOverIndex][0] + '"');
		eval('document.Corepginsert.src = "' + MenuImages[MenuImageOverIndex][5] + '"');
		}
	}

function ImgMouseOut(MenuImageOut, MenuImageOutIndex, MenuImageSelectedIndex)
	{
	// If the mouse out menu item is not the selected menu item,
	// the mouse out menu item is turned off and the selected menu item core page insert is displayed
	if (MenuImageOut != window.MenuImageSelected)
		{
		eval('document.' + MenuImageOut + '.src = "' + MenuImages[MenuImageOutIndex][1] + '"');
		eval('document.Corepginsert.src = "' + MenuImages[window.MenuImageSelectedIndex][5] + '"');
		}
	}

function navIcons(left, top)
	{
	if (getBrowserVersion().substring(0,1) > 3)
		{
		document.write('<layer id="navIcons" left="' + left + '" top="' + top + '" width="85" height="40" z-index="1">',
							'<img src="/comlib/images/Header_elements/3icons&Text.gif" border="0" usemap="#HHSmap">',
							'<MAP name="HHSmap">',
								'<AREA shape="rect"',
									'coords="85,0,120,47"',
									'href="/search" target="_parent" alt="search">',
								'<AREA shape="rect"',
									'coords="50,0,75,47"',
									'href="/help" alt="help">',
								'<AREA shape="rect"',
									'coords="0,0,35,47"',
									'href="/index.htm" alt="index">',
							'</MAP>',
						'</layer>');
		}
	else
		{
		document.write('<center>',
						'<img src="../comlib/images/Header_elements/3icons&Text.gif" border="0" usemap="#HHSmap">',
							'<MAP name="HHSmap">',
								'<AREA shape="rect"',
									'coords="85,0,120,47"',
									'href="/search" target="_parent" alt="search">',
								'<AREA shape="rect"',
									'coords="50,0,75,47"',
									'href="/help" alt="help">',
								'<AREA shape="rect"',
									'coords="0,0,35,47"',
									'href="/" alt="index">',
							'</MAP>',
						'</center>');
		}
	}


function displayDate(){
	curdate = new Date();
	var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

	date = months[curdate.getMonth()] + " " + curdate.getDate() + ", " + curdate.getFullYear();
	return(date);
}