//Author:               Scott Marshall
//Modified By:          Jason Parks 05/23/2003
//Name:                 checkandsend.js
//Description:  used to format and send a form to emailsend application
//Dependencies: none
//Requirements: must be inserted into html page as first thing after <body> tag

//
//  Makes sure to reload script on reload and to capture all click events
//
if (window.captureEvents){            /* Netscape */
    window.captureEvents(Event.CLICK);
    window.onclick = checkSubmit;}
else{                                 /* Explorer */
    document.onclick = checkSubmitIE;}

//  Function: Checks to see if a Click was on a submit Button in Netscape.  If so, then it will
//                      insure the form is complete,  and then call submitForm
//      Input: Click event object
//      Returns: If submit button, calls submitForm , else returns true
//      Globals : functions - isFormComplete,submitForm
//

function checkSubmit(e) { /* Netscape Only*/
	if (e.target.type == 'submit') {
		var bFound = false;
		for (var i=0 ; i < document.forms.length ; i++) {
			var oForm = eval("document.forms[" + i + "]");
			for (var j=0; j < oForm.length ; j++) {
				var oTestField = eval("document.forms[" + i + "]" + 
										".elements[" + j + "]");
				if (e.target == oTestField) {
					bFound = true;
					break;
				}
			}
			if (bFound) { break; }
		}
		if (!oForm) {
			alert("Error!  No Form Defined for this Submission");
			return false;
		}
		if ( isFormComplete(oForm) ) {
			submitForm(oForm);
			return false;
		}	
		else {
			return false;	
		}
	} 
	else {	
	  return true;
	}
}

//  Function: Checks to see if a Click was on a submit Button in IE.  If so, then it will
//                      insure the form is complete,  and then call submitForm
//      Input: Click event object
//      Returns: If submit button, calls submitForm , else returns true
//      Globals : functions - isFormComplete,submitForm
//

function checkSubmitIE(){ /* Explorer Only*/
 if (window.event.srcElement.type == 'submit') {
		var bFound = false;
		for (var i=0 ; i < document.forms.length ; i++) {
			var oForm = eval("document.forms[" + i + "]");
			for (var j=0; j < oForm.length ; j++) {
				var oTestField = eval("document.forms[" + i + "]" + 
										".elements[" + j + "]");
				if (window.event.srcElement == oTestField) {
					bFound = true;
					break;
				}
			}
			if (bFound) { break; }
		}
		if (!oForm) {
			alert("Error!  No Form Defined for this Submission");
			return false;
		}
		if ( isFormComplete(oForm) ) {
			submitForm(oForm);
			return false;
		}	
		else {
			return false;	
		}
	} 
	else {	
	  return true;
	}
}

// Function: establishes URL for sending form data to formsend application, and submits form.
// Input: none
// Returns: Submits forms
// Globals: document.forms[0] and location object from browser
//
function submitForm(oForm) {
	sProdIEPort = ':85';
	sProdNetscapePort1 = ':85';
	sProdNetscapePort2 = ':85';
//	sProdNetscapePort3 = ':90';
	
	sTestIEPort = ':85';
	sTestNetscapePort = ':85';
	
	strHostNme = location.hostname;
	intPerLoc = (strHostNme.indexOf('.') == -1)?strHostNme.length + 1:strHostNme.indexOf('.');
	strHostNme = strHostNme.substring(0,intPerLoc);
	strHostNme = strHostNme.toLowerCase();
	
	var onTest = false;
	
	if (window.captureEvents)
		isIE = false;
	else
		isIE = true;
		
	switch (strHostNme) {
		case 'walnte01' : onTest = true; break;
		case 'cosmo'	: onTest = true; break;
		//case 'panama'	: onTest = true; break;
		//case 'slsupr25'	: onTest = true; break;
		case 'home'		: break;
		case 'it'		: break;
		case 'store'	: break;
		case 'slsupr23' : break;
		//case 'store_t'	: onTest = true; break;
		default			: strHostNme = 'home';
	}
	
	if (onTest)
		if (isIE)
			strPort = sTestIEPort;
		else
			strPort = sTestNetscapePort;
	else
		if (isIE)
			strPort = sProdIEPort;
		else
			strPort = eval("sProdNetscapePort" + (Math.round(Math.random() * 1) + 1).toString());
//alert("starting action location");
	var strActionLocation = 'http://' + strHostNme + '.safeway.com' + strPort + '/formsend/sendmail.htm';
	//var strActionLocation = 'http://slsupr23.safeway.com' + strPort + '/formsend/sendmail.htm';
//alert(strActionLocation);
	oForm.action = strActionLocation;
	oForm.enctype = 'multipart/form-data';
	oForm.method = 'POST';
	modReturnURL(oForm);
//alert("starting to submit");
	oForm.submit();
//alert("submitted");
}


//  Function:  1) Checks if user has submit function, and if applicable runs it.
//			2) Verifies all required fields are not empty
//			3) Verifies there is a sendTo or delimSendTo
//  Input: The Form Object
//  Returns: returns true is all is well or false if not
//	Globals: functions - runOnSubmit(optional),chkReqFields,isBlank,getFieldNameValue
function isFormComplete(objUserForm) {
	for (var i=0; i < objUserForm.length; i++) {
		if (objUserForm[i].name == 'submitFunction') {
			if (!runOnSubmit()) {
				return false;
			}
		}
	}
	if (!chkReqFields(objUserForm)) {
		return false;
	}
	var booAddressFound = false;
	for (var i=0; i < objUserForm.length; i++) {
		if (objUserForm[i].name == 'sendTo' || objUserForm[i].name == 'delimSendTo') {
			objSendField = getFieldNameValue(objUserForm[i],objUserForm);
			if (!isBlank(objSendField.value)) {
				booAddressFound = true;
			}			
		}
	}
	if (booAddressFound) {
		return true;
	}
	else {
		alert ('A Destination Address (sendTo or delimSendTo)\n must be provided!');
		return false;
	}
}


//  Function:  Returns name,value, and type of a field
//  Input: Field object, Form Object
//  Returns: object with name,value, and type
//	Globals: none
function getFieldNameValue(objX, objFormX )  {
	objReturn = new Object();
	objReturn.name = 'unnamed field';
	for (var i in objX) {
		if (i == 'name') {
			objReturn.name = objX.name;
			objReturn.type = objX.type;
			break;
		}
	}
	objReturn.value = '';
	switch(objX.type) {
		case 'text': objReturn.value = objX.value; break;
		case 'textarea': objReturn.value = objX.value; break;
		case 'select-one':	var idx = objX.selectedIndex;
							var theValue = objX.options[idx].value;
							objReturn.value = theValue;
							break;
		case 'hidden': 		objReturn.value = objX.value;	break;
		case 'select-multiple': var j = 0;
								strValues = new Array();
								for (var idx=0; idx < objX.options.length; idx++) {
									if (objX.options[idx].selected) {
										strValues[j] = objX.options[idx].value;
										j++;
									}
								}
								objReturn.value = strValues.join(',');
								break;
		case 'checkbox':	if (objX.checked) { objReturn.value = objX.value};
							break;
		case 'radio':
			for (var i=0; i < objFormX.length; i++) {
				if (objFormX[i].name == objX.name && objFormX[i].type == objX.type && objFormX[i].checked){
				objReturn.value = objFormX[i].value
				}
			}
			break;
		case 'submit': 
			break;
		case 'reset':
			break;
		case 'button':
			break;
	  }
	 return objReturn;
}
		

//  Function:  Checks to see if a field is blank
//  Input: value
//  Returns: true or false
//  Globals: none
function isBlank(strValue) {
	if (strValue == null || strValue == '') {
		return true;
	}
	else {
		for (var i=0; i < strValue.length; i++) {
			if 	(strValue.charAt(i) == ' ') { continue; }
			else							{return false;}
		}
		return true;
	}
}


//  Function:  Checks to see if a required field is blank
//  Input: form object
//  Returns: true if all is well, false and alert box of all items if not
//  Globals: functions - isBlank, getFieldNameValue
function chkReqFields(form){
	var alertStr="You did not enter a value into the ";
	var bMissed = false;
	var strRadioName = '';
    for (var i = 0; i < form.elements.length ; i++ ) {
		if (form.elements[i].name.substring(0,4) == 'req_') {
			objField = getFieldNameValue(form.elements[i], form)
			if (isBlank(objField.value) ) {
					if (objField.name != strRadioName) {
						alertStr+= "\n" + objField.name.substring(4);
						if (objField.type == 'radio') { strRadioName = objField.name;}
					}
					if(!bMissed) {
						 bMissed=true;
						 form.elements[i].focus();
					}
			}
		}
	}
    if(bMissed){
		alert(alertStr+="\n\nfield(s).\nThis is a required field. Please enter it now.");
		return false;
	}
	else 
		return(true);
};


function modReturnURL(form){
	var strHostNme = location.hostname;
	var strPort = (location.port) ? ':' + location.port : '';
	var strModReturnURL = 'http://' + strHostNme + strPort;
    for (var i = 0; i < form.elements.length ; i++ ) {
		if (	(form.elements[i].name.substring(0,9) == "returnUrl") 
			&& (form.elements[i].value.substring(0,1) == "/"))	{
			form.elements[i].value = strModReturnURL + form.elements[i].value;
			break;
		}
	}
};

