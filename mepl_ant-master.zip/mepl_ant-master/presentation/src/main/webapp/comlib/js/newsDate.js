
function displayDate(){
		imgpath= "/images/news/";
		curdate = new Date();
		var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
		var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
		var bkgd = new Array("sunday2.jpg","monday2.jpg","tuesday2.jpg","wednesday2.jpg","thursday2.jpg","friday2.jpg", "saturday2.jpg");
		date = months[curdate.getMonth()] + " " + curdate.getDate() + ", ";
		year = curdate.getFullYear();
		date +=  year;
		var tble = '<TABLE WIDTH="130" BORDER="0" CELLSPACING="2" CELLPADDING="0" HEIGHT="34">';
		tble += '  <TR> <TD WIDTH="125" HEIGHT="34"ALIGN="center" VALIGN="bottom" BACKGROUND="'+ imgpath + bkgd[curdate.getDay()];
		tble += '"><CENTER><FONT COLOR="#000000" FACE="Arial" SIZE="-1">' + date + '</FONT></CENTER></TD></TR></TABLE>';
	
		return(tble);
	}
