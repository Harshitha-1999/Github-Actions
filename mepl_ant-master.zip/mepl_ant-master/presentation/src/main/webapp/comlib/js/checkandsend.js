//Author:		Scott Marshall
//Name:			checkandsend.js
//Description:	used to format and send a form to emailsend application
//Dependencies:	none
//Requirements: must be inserted into html page as first thing after <body> tag

//
//  Makes sure to reload script on reload and to capture all click events



window.onResize = window.reload;

//window.releaseEvents()
//window.captureEvents(Event.CLICK)
//window.onclick = checkSubmit;

if (window.captureEvents){ // Netscape
	window.captureEvents(Event.CLICK);
    window.onclick = checkSubmit;
}
else{ // Explorer
	
   	document.onclick = checkSubmitIE;
}

//  Function: Checks to see if a Click was on a submit Button.  If so, then it will
//			insure the form is complete,  and then call submitForm
//	Input: Click event object
//	Returns: If submit button, calls submitForm , else returns true
//	Globals : functions - isFormComplete,submitForm
//

function checkSubmit(e) // Netscape
{
	if (e.target.type == 'submit') {
		if (isFormComplete(document.forms[0]) ) {
			submitForm()
			return false;
		}	
		else {
			return false;	
		}
	} 
	else {	
	  return true;
	}
}

function checkSubmitIE() // IE
{
	if (window.event.srcElement.type == 'submit') {
		if (isFormComplete(document.forms[0]) ) {
			submitForm()
	
			return false;
		}	
		else {
			return false;	
		}
	} 
	else {	
	  return true;
	}
}

// Function: establishes URL for sending form data to formsend application, and submits form.
// Input: none
// Returns: Submits forms
// Globals: document.forms[0] and location object from browser
//
function submitForm() {
	strHostNme = location.hostname

	var fields;
	if (document.forms[0].elements[0].type != 'submit' && document.forms[0].elements[0].type !='reset')
	{
		fields = document.forms[0].elements[0].name ;
	}
	
	for (var i=1; i < document.forms[0].elements.length; i++)
	{	
		if (document.forms[0].elements[i].name != document.forms[0].elements[i-1].name && document.forms[0].elements[i].type != 'submit' && document.forms[0].elements[i].type != 'reset')
		{
			fields = fields + '&' + document.forms[0].elements[i].name;
		}	
	}

	strActionLocation=location.protocol+'//'+location.host+'/mepl/FormSend.jsp?' + escape(fields);	
	document.forms[0].action = strActionLocation;	
	document.forms[0].method = 'POST';
	document.forms[0].enctype = 'multipart/form-data';
	document.forms[0].submit();
}


//  Function:  1) Checks if user has submit function, and if applicable runs it.
//			2) Verifies all required fields are not empty
//			3) Verifies there is a sendTo or delimSendTo
//  Input: The Form Object
//  Returns: returns true is all is well or false if not
//	Globals: functions - runOnSubmit(optional),chkReqFields,isBlank,getFieldNameValue
function isFormComplete(objUserForm) {
	for (var i=0; i < objUserForm.length; i++) {
		if (objUserForm[i].name == 'submitFunction') {
			if (!runOnSubmit()) {
				return false
			}
		}
	}
	if (!chkReqFields(objUserForm)) {
		return false
	}
	var booAddressFound = false;
	for (var i=0; i < objUserForm.length; i++) {
		if (objUserForm[i].name == 'sendTo' || objUserForm[i].name == 'delimSendTo' || objUserForm[i].name == 'fileName') {
			objSendField = getFieldNameValue(objUserForm[i],objUserForm);
			if (!isBlank(objSendField.value)) {
				booAddressFound = true;
			}			
		}
	}
	if (booAddressFound) {
		return true
	}
	else {
		alert ('A Destination Address (sendTo or delimSendTo)\n must be provided!');
		return false;
	}
}

//  Function:  Returns name,value, and type of a field
//  Input: Field object, Form Object
//  Returns: object with name,value, and type
//	Globals: none
function getFieldNameValue(objX, objFormX )  {
	objReturn = new Object();
	objReturn.name = 'unnamed field'
	for (var i in objX) {
		if (i == 'name') {
			objReturn.name = objX.name
			objReturn.type = objX.type
			break;
		}
	}
	objReturn.value = ''
	switch(objX.type) {
		case 'text': objReturn.value = objX.value; break;
		case 'textarea': objReturn.value = objX.value; break;
		case 'select-one':	var idx = objX.selectedIndex;
							var theValue = objX.options[idx].value;
							objReturn.value = theValue;
							break
		case 'hidden': 		objReturn.value = objX.value;	break;
		case 'select-multiple': var j = 0;
								strValues = new Array();
								for (var idx=0; idx < objX.options.length; idx++) {
									if (objX.options[idx].selected) {
										strValues[j] = objX.options[idx].value;
										j++;
									}
								}
								objReturn.value = strValues.join(',');
								break;
		case 'checkbox':	if (objX.checked) { objReturn.value = objX.value};
							break;
		case 'radio':
			for (var i=0; i < objFormX.length; i++) {
			if (objFormX[i].name == objX.name && objFormX[i].type == objX.type && objFormX[i].checked)
				{objReturn.value = objFormX[i].value}
			}
			break
		case 'submit': 
			break;
		case 'reset':
			break;
		case 'button':
			break;
	  }
	 return objReturn
};
		
//  Function:  Checks to see if a field is blank
//  Input: value
//  Returns: true or false
//  Globals: none
function isBlank(strValue) {
	if (strValue == null || strValue == '') {
		return true
	}
	else {
		for (var i=0; i < strValue.length; i++) {
			if 	(strValue.charAt(i) == ' ') { continue }
			else							{return false}
		}
		return true
	}
}

//  Function:  Checks to see if a required field is blank
//  Input: form object
//  Returns: true if all is well, false and alert box of all items if not
//  Globals: functions - isBlank, getFieldNameValue
function chkReqFields(form){
	var alertStr="You did not enter a value into the ";
	var bMissed = false;
	var strRadioName = '';
    for (var i = 0; i < form.elements.length ; i++ ) {
		if (form.elements[i].name.substring(0,4) == 'req_') {
			objField = getFieldNameValue(form.elements[i], form)
			if (isBlank(objField.value) ) {
					if (objField.name != strRadioName) {
						alertStr+= "\n" + objField.name.substring(4);
						if (objField.type == 'radio') { strRadioName = objField.name;}
					}
					if(!bMissed) {
						 bMissed=true;
						 form.elements[i].focus();
					}
			}
		}
	}
    if(bMissed){
		alert(alertStr+="\n\nfield(s).\nThis is a required field. Please enter it now.");
		return false;
	}
	else 
		return(true);
};
