//Author........: Scott Marshall

//File Name.....: header.js

//Description...: Creates header for Store Request Forms

//

function htmHeader(name,page_typ){

	//images_home2 = "http://store.safeway.com/store/images/buttons/"

	images_home = "http://store.safeway.com/store/images/"

	help_page = "http://store.safeway.com/store/help";

	if (checkForCookie("store_id")) {	

		home_page = "/storemenu";

		bHelpButton = true;

	}

	else {

		home_page = "http://apps.safeway.com/";

		bHelpButton = false;

	};	

	

	var  header = " ";

	if (page_typ == "main"){

		var misc_button  = "<img src='omniformsh.gif'" ;

		misc_button += " width='80' height='15' border='0'>";

	}

	else {

		var misc_button  = "<A href='/forms/omni'>";

		misc_button += "<img src='omniformsu.gif'";

		misc_button += " width='80' height='15' border='0' ALT='Go to the Misc Forms Menu'></a>";

     }

   header  = "<table border='0' width='90%' cellspacing='0' cellpadding='0'>";

   header += "<tr>";

   header += "<td align='RIGHT' width='201'>";

   header += "<div align='LEFT'>";

   header += "<a href='" + home_page + "'><img src='" + images_home + "buttons/selectnet.gif' width='201' height='42' border='0'  ALT='Go to the Home Menu'></a>";

   header += "</div>";

   header += "</td>  <td  width='511' valign='center'>";

   header += "<table border='0' width='100%' cellspacing='0' cellpadding='0'>";

   header += "<tr> <td height='15'>";

   header += "<table border='0' width='100%' cellspacing='0' cellpadding='0' COLS=7>";

   header += "<tr> <td width='73'>";

   header += "<a HREF='" + home_page + "'><img src='" + images_home + "menubar/homeu.gif' width='60' height='15' border=0 ALT='Go to the Home Menu'></A>";

   header += "</td>";

   header += "<td width='73'></td>";

   header += "<td width='73'></td>";

   header += "<td width='73'></td>";

   header += "<td width='73'></td>";

   header += "<td width='73'></td>";

	if (bHelpButton) {

	   header += "<td width='73'><A HREF='" + help_page + "'><img src='" + images_home + "menubar/helpu.gif' width='60' height='15' border=0 ALT='Go to help information'></A></td>";

	}

	else {

		header += "<td width='73'></td>";

	};

   header += "  </tr>";

   header += "</table>";

   header += "  </td>";

   header += "  </tr>";

   header += "  <tr>";

   header += "     <td bgcolor='#000000' height='1'><img src='" + images_home + "buttons/blckdot.gif' width='1' height='2'></td>";

   header += "  </tr>";

   header += "  <tr>";

   header += "    <td  bgcolor='#000000'>" + misc_button + "</td>";

   header += "  </tr>";

   header += "</table>";

   header += "  </td>";

   header += "  </tr>";

   header += "</table>"

   header += "<h1 align='CENTER'> <b>" + name + "</b></h1>";

   header += "<hr> <br>";

   return header;

}



function checkForCookie(strLabel) {

	var iLabelLen = strLabel.length;

	var iLen = document.cookie.length;

	var i = 0;

	var iEnd

	while ( i < iLen) {

		var j = i + iLabelLen;

		if (document.cookie.substring(i,j) == strLabel) {

			return true

		}

		i++;

	}

	return false;

}	



function sGetCookie(strLabel) {

	var iLabelLen = strLabel.length;

	var iLen = document.cookie.length;

	var i = 0;

	var iEnd

	while ( i < iLen) {

		var j = i + iLabelLen;

		if (document.cookie.substring(i,j) == strLabel) {

			iEnd = document.cookie.indexOf(";",j);

			if (iEnd == -1) {

				iEnd = document.cookie.length;

			}

			return unescape(document.cookie.substring(j+1,iEnd))

		}

		i++;

	}

	return "";

}	

	