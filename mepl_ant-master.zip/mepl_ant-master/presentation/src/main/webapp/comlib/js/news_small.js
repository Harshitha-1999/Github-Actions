	var ar = new Array(); 
	ar[0] = "<font size='-2' FACE='Arial, Helvetica, sans-serif'><A HREF='http://cosmo.safeway.com/estm'>News 1 akdjfkla <br>dfkjd fklajdf klajdf </A></font>";
	ar[1] = "<font size='-2' FACE='Arial, Helvetica, sans-serif'>News 2 akdjfkla <br>dfkjd fklajdf klajdf </A></font>";
	ar[2] = "<font size='-2' FACE='Arial, Helvetica, sans-serif'>News 3</font>";
	ar[3] = "<font size='-2' FACE='Arial, Helvetica, sans-serif'><A HREF='http://cosmo.safeway.com/eip'>News 4 akdjfkla <br>dfkjd fklajdf klajdf </A></font>";
	ar[4] = "<font size='-2' FACE='Arial, Helvetica, sans-serif'>News 5</font></A>";
	ar[5] = "<font size='-2' FACE='Arial, Helvetica, sans-serif'>News 6 akdjfkla <br>dfkjd fklajdf klajdf </font></A>";
	ar[6] = "<img src='/comlib/images/news/newsSampleSmall.gif' border='0'>";

	function build_News(left, top, business)
		{
		document.write('<layer id="news" left="' + left + '" top="' + top + '" width="127" height="150" z-index="1">',
							'<img src="/comlib/images/news/news_console_small.gif" width="116" height="130" border="0" usemap="#newsConsole">',
							'<layer id="banner0" left="23" top="20" width="85" height="10" z-index="1">',
								'<center>',
									'<font size="-3" face="Arial, Helvetica, sans-serif">');
		document.write(					displayDate());
		document.write(				'</font>',
								'</center>',
							'</layer>',
							'<layer id="banner1" left="23" top="35" width="85" height="40" z-index="1"></layer>',
							'<layer id="banner2" left="23" top="70" width="85" height="40" z-index="1"></layer>',
							'<layer id="banner3" left="23" top="100" width="85" height="40" z-index="1"></layer>',
							'<map name="newsConsole">',
								'<area shape="POLYGON" alt="Up"',
									'coords="7,57,10,60,12,63,9,63,6,63,3,63,0,62,3,60',
									'"HREF="javascript://"target="_top"onclick="forward();">',
								'<area shape="RECT" alt="Stop"',
									'coords="2,71,5,80',
									'"HREF="javascript://"target="_top"onclick="stop();">',
								'<area shape="POLYGON" alt="Down"',
									'coords="3,88,6,88,9,88,12,88,11,90,8,93,6,94,3,91',
									'"HREF="javascript://"target="_top"onclick="back();">',
							'</map>',
						'</layer>');
		}
	
	var num = 0;
	lastClicked = "none";
	function update()
		{
		display("banner1", ar[num]);
		display("banner2", ar[(num+1)%(ar.length)]);
		display("banner3", ar[(num+2)%(ar.length)]);
		num++;
		if (num == ar.length) num = 0;
		}

	function forward()
		{
		if (lastClicked == "none") stop();
		if (lastClicked == "back")
			{
			num = num+2;
			if (num >= ar.length) num = 0;
			}
		display("banner1", ar[num]);
		display("banner2", ar[(num+1)%(ar.length)]);
		display("banner3", ar[(num+2)%(ar.length)]);
		num++;
		if (num == ar.length) num = 0;
		lastClicked = "forward";
		}

	function back()
		{
		if (lastClicked == "none" || lastClicked == "forward")
			{
			stop();
			num = num-2;
			if (num < 0) num = (ar.length-1);
			}
		display("banner1", ar[num]);
		display("banner2", ar[(num+1)%(ar.length)]);
		display("banner3", ar[(num+2)%(ar.length)]);
		num--;
		if (num < 0) num = ar.length-1;
		lastClicked = "back";
		}

	function display(id, str)
		{
		with (document['news'].document[id].document)
			{
			open();
			write(str);
			close();
			}
		}

	function start()
		{
		update();
		startInterval = setInterval("update()", 4000);
		}
	
	function stop()
		{
		clearInterval(startInterval);
		}


function displayDate(){
	curdate = new Date();
	var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

	date = months[curdate.getMonth()] + " " + curdate.getDate() + ", " + curdate.getFullYear();
	return(date);
}