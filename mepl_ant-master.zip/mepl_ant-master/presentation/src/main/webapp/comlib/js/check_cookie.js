//Author........: Scott Marshall

//File Name.....: check_cookie.js

//Description...: Checks Store Cookie - Taken from old store header script 

//Updated.......: Ryan Prindiville 6/28/2000

//

function checkForCookie(strLabel) {

	var iLabelLen = strLabel.length;

	var iLen = document.cookie.length;

	var i = 0;

	var iEnd

	while ( i < iLen) {

		var j = i + iLabelLen;

		if (document.cookie.substring(i,j) == strLabel) {

			return true

		}

		i++;

	}

	return false;

}	



function sGetCookie(strLabel) {

	var iLabelLen = strLabel.length;

	var iLen = document.cookie.length;

	var i = 0;

	var iEnd

	while ( i < iLen) {

		var j = i + iLabelLen;

		if (document.cookie.substring(i,j) == strLabel) {

			iEnd = document.cookie.indexOf(";",j);

			if (iEnd == -1) {

				iEnd = document.cookie.length;

			}

			return unescape(document.cookie.substring(j+1,iEnd))

		}

		i++;

	}

	return "";

}	

	