// Author: Ryan Prindiville
// Created: 6/27/2000
// Name: maintenance_form.js
// Function: JavaScript dealing with Return to Maintenance Form
// Used on: Client

function isWhitespace(s){
        return s.match(/^\s*$/)?true:false;
}

function aReturnDivMaintArray() {
	var q = 0;
	var aDivMaint = new Array();
	aDivMaint[q++] = new Array("Phoenix","17","phx.retail.maint@safeway.com");
	aDivMaint[q++] = new Array("Portland","19","por.construction@safeway.com");
	aDivMaint[q++] = new Array("Seattle","27","sea.retail.maint@safeway.com");
	aDivMaint[q++] = new Array("Vons","29","von.retail.maint@safeway.com");
	return aDivMaint;
}

function sReturnDivMaintEmail (sDivId) {
	var aDivMaint = aReturnDivMaintArray();
	if (!sDivId) {
		return '';
	}
	else {
		for (var i = 0; i < aDivMaint.length; i++) {
			if (aDivMaint[i][0] == sDivId) {
				return aDivMaint[i][2];
			}
		}
	}
	return '';
};	
			
function sMakeDivSelectBox(sDivId) {
	var aDivMaint = aReturnDivMaintArray();
	var strHtml = '<select name="Division" size="1" onChange="sGetDivMaintEmail(this)">' +
				'\n<option value=""> </option>';
	for (var i=0; i < aDivMaint.length; i++) {
		strHtml += '\n<option value="' + aDivMaint[i][0] + '"';
		if (aDivMaint[i][0] == sDivId) { 
			strHtml += ' selected';
		}
		strHtml += '>' + aDivMaint[i][0] +	'</option>';
	}
	strHtml += '\n</select>';
	return strHtml
};	


function sGetDivMaintEmail(oSelectField) {
	for (var i=0; i < oSelectField.length; i++) {
		if (oSelectField[i].selected) {
			sDivId = oSelectField[i].value;
		}
	}
	document.forms[0].req_sendTo.value = sReturnDivMaintEmail(sDivId);
}

function runOnSubmit() {
	if (isWhitespace(document.forms[0].req_sendTo.value)) {
		document.forms[0].req_sendTo.value = '';
		document.forms[0].req_sendTo.focus()
		alert ("Please Select your Division.")
		return false;
	}
	return true;
}

