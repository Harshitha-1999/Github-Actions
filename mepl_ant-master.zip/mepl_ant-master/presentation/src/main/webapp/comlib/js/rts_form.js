// Author: Scott Marshall

// Created: 10/03/1999

// Name: rts_form.js

// Function: JavaScript dealing with Return to Stock Form

// Used on: Client



function aReturnDistMgrArray() {

	var q = 0;

	var aDistMgrs = new Array();

	aDistMgrs[q++] = new Array("41","Terry Richardson","terry.richardson1@safeway.com");

	aDistMgrs[q++] = new Array("42","Bill Tarter","bill.tarter@safeway.com");

	aDistMgrs[q++] = new Array("43","Dean Little","dean.little@safeway.com");

	aDistMgrs[q++] = new Array("44","Jon Fredin","jon.fredin@safeway.com");

	aDistMgrs[q++] = new Array("45"," Lori Marcy","lori.marcy@safeway.com");

	aDistMgrs[q++] = new Array("46","John Piva","john.piva@safeway.com");

	aDistMgrs[q++] = new Array("47","Phil Tucker","phil.tucker@safeway.com");

	aDistMgrs[q++] = new Array("48","Mike Young","mike.young@safeway.com");

	aDistMgrs[q++] = new Array("49","Phil Tucker","phil.tucker@safeway.com");

	aDistMgrs[q++] = new Array("50","Bernard Hardy","bernard.hardy@safeway.com");

	aDistMgrs[q++] = new Array("51","Duane Enslow","duane.enslow@safeway.com");

	aDistMgrs[q++] = new Array("52","Rich Winters","rich.winters@safeway.com");

	aDistMgrs[q++] = new Array("53","Donna Young","donna.young@safeway.com");

	aDistMgrs[q++] = new Array("54","Joe Lemire","joe.lemire@safeway.com");

	aDistMgrs[q++] = new Array("55","Andy Smith","andy.smith2@safeway.com");

	aDistMgrs[q++] = new Array("56","Gary posey","gary.posey@safeway.com");

	aDistMgrs[q++] = new Array("57","Lori Smith","lori.smith@safeway.com");

	aDistMgrs[q++] = new Array("58","Mark Wright","mark.wright@safeway.com");

	return aDistMgrs;

}



function sReturnDistMgrEmail (sDistId) {

	var aDistMgrs = aReturnDistMgrArray();

	if (!sDistId) {

		return '';

	}

	else {

		for (var i = 0; i < aDistMgrs.length; i++) {

			if (aDistMgrs[i][0] == sDistId) {

				return aDistMgrs[i][2];

			}

		}

	}

	return '';

};	

			

function sMakeDistSelectBox(sDistId) {

	var aDistMgrs = aReturnDistMgrArray();

	var strHtml = '<select name="District" size="1" onChange="sGetDistMgrEmail(this)">' +

				'\n<option value=""> </option>';

	for (var i=0; i < aDistMgrs.length; i++) {

		strHtml += '\n<option value="' + aDistMgrs[i][0] + '"';

		if (aDistMgrs[i][0] == sDistId) { 

			strHtml += ' selected';

		}

		strHtml += '>' + aDistMgrs[i][0] +	'</option>';

	}

	strHtml += '\n</select>';

	return strHtml

};	





function sGetDistMgrEmail(oSelectField) {

	for (var i=0; i < oSelectField.length; i++) {

		if (oSelectField[i].selected) {

			sDistId = oSelectField[i].value;

		}

	}

	document.forms[0].req_sendTo.value = sReturnDistMgrEmail(sDistId);

}



function runOnSubmit() {

	if (isWhitespace(document.forms[0].req_sendTo.value)) {

		document.forms[0].req_sendTo.value = '';

		document.forms[0].req_sendTo.focus()

		alert ("Please Enter the Full Name or Emaill Address of your District Manager.")

		return false;

	}

	return true;

}



