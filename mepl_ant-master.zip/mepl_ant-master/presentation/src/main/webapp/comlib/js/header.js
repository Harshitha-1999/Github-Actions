//
//Author........: Florida Nulman
//File Name.....: header.js
//Web Site......: 
//Description...: builds header for intranet pages
//Last Update...: 01/28/1999
//
//This file can be edited by Webmaster ONLY//

//**** !! DO NOT EDIT !!
function displayDate(){
	curdate = new Date();
	var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

	date = months[curdate.getMonth()] + " " + curdate.getDate() + ", " + curdate.getFullYear();
	return(date);
}

//**** !! DO NOT EDIT !!  generates page header
function CRheader(bar, v_frame){

isNS3 =(navigator.appName == "Netscape" && parseInt(navigator.appVersion) < 4.0);
 var str="";
//main table
	str += '<FORM NAME = "menuNS3">';
	if( v_frame)
		str += '<table border="0" width="480" height="58" cellspacing="0" cellpadding="0" >';
	else
		str += '<table border="0" width="600" height="58" cellspacing="1" cellpadding="0" >';
	str += '<tr valign="top">';
	str += '<td valign="top" width="60" align="center"><a href="http://home.safeway.com/" target="_parent"><img src="/comlib/images/Header_elements/sf_std_S.gif" width="56" height="55" border="0" align="top" alt="Back to Home"></a></td>';
	str += '<td valign="top" width="115" align="center" ><img src="/comlib/images/Header_elements/3icons&Text.gif" width="114" usemap="#HDRarchMap" height="48" align="top" border="0"></td>';
	if(v_frame){
		str += '<td valign="top" width="240" height="49" align="center">';
		str += '<table  height="40" width="240" border="0"valign="TOP" cellpadding="0" cellspacing="2" ><tr><td colspan="2" valign="bottom" align="left">&nbsp;&nbsp;';	
	}
	else {
		str += '<td valign="top" width="330" height="49" align="center">';
		str += '<table  height="40" width="330" border="0" align="left" valign="TOP" cellpadding="0" cellspacing="3" ><tr><td colspan="2" valign="bottom" align="left">&nbsp;&nbsp;';
	}
	str += makeCoreNS3menu();
	str += '</td><td width="0"></td></tr><tr>';
	if(v_frame)
		str += '<td align="center" height="8" width="60" >&nbsp;</td>';
	else
		str += '<td align="center" height="8" width="135">&nbsp;</td>';
	str += '<td align="right" height="8" valign="top">';
	str += '<a href="/news/index.htm" target="_parent"><img src="/comlib/images/whats.gif" border=0 alt="" align="left"></a>';

	if(path[5]){
		str += makeDivNS3menu();
	}
	str += '</td></tr></table></td>';
	str += '<td valign="top" width="75" align="right">';
	str += '<a href="/' + path[3]+ '/index.htm" target="_top"><img src="/' + path[3] +'/corelib/images/Logo.gif" border="0" align="center" ></a></td>';
	if(v_frame){
		str += '</tr><tr ><td colspan="4" align="left" valign="bottom"><img src="/'+ path[3] +'/corelib/images/bar.gif"  height="1" width="480"></td>';
	}
	else{
		str += '</tr><tr ><td colspan="4" align="left" valign="top"><img src="/' + path[3] +'/corelib/images/bar.gif"  height="1" width="600"></td>';
	}
	if(!bar)
		str += '<td width="114"></td><td width="350"></td><td width="50"></td></tr></table></form>';
	else
		str += '<td width="114"></td><td width="350"></td><td width="50"></td></tr></table>';


	//3icons map
	str += '<map name="HDRarchMap"> ';
	str += '  <area shape="rect" coords="80,0,115,47" href="/search" alt="Click here to Search" target="_top"> ';
	str += '  <area shape="rect" coords="50,0,75,47" href="/help"  alt="Click here for Help" target="_top"> ';
	str += '  <area shape="rect" coords="10,0,40,47" href="/' + path[3] + '/index.htm" alt="Click here to go back Home" target="_top">';
	str += '</map>';
	document.write(str);

}

// if path[5] is true your page is on division's subsite level or below
// path[4] can be a dir name or page name in the corelevel directory
// if dir name show subdirectory menu
//**** !! DO NOT EDIT !!
function write_header(bar,v_frame){
	core_build_menu_images();
	if(path[5])
		div_build_menu_images();
	CRheader(bar, v_frame);
}


//**** !! DO NOT EDIT !!
function CR_footer(v_frame,str_contact){
 var str = "";
	if(v_frame){
	 	str += '<table border="0" height="2" width="480" cellspacing="0" cellpadding="0"><tr> ';
		str += '<td height="2">&nbsp;<img src="/' + path[3] +'/corelib/images/bar.gif" width="480" height="1"></td> ';
	}
	 else{
	 	str += '<table border="0" height="2" width="600" cellspacing="0" cellpadding="0"><tr> ';
		str += '<td height="2">&nbsp;<img src="/'+ path[3] +'/corelib/images/bar.gif" width="596" height="1"></td> ';
	}

//	str += '<tr><td align="center"><a href="/' + 'resources/index.htm" target="_parent">[Resources]&nbsp;&nbsp;</a>';
//	str += '<a href="/' + 'it/index.htm" target="_parent">[Information Technology]&nbsp;&nbsp;</a>';
//	str += '<a href="/' + 'it/index.htm" target="_parent">[Divisions]&nbsp;&nbsp;</a></td>';
//	str += '</tr>'
	str += '</table> ';

	if(v_frame)
		str += '<BR><table width = "480" cellspacing ="0" cellpadding="0" border="0"> ';	
	else
		str += '<BR><table width = "600" cellspacing ="0" cellpadding="0" border="0"> ';
	str += '<tr ALIGN="left" VALIGN="TOP"> ';
	str += '<td width="236" height="60" align="center" valign="top">';
//  str += '<p align="left"><a href="/it/index.htm" target="_parent"><img src="/comlib/images/Header_elements/sf_std_S.gif"  alt = "Back to Home" width="60" height="55" border="0" align="top"></a></p>';
   	str += '<p align="left"><img src="/comlib/images/Header_elements/sf_std_S.gif" width="60" height="55" border="0" align="top"></p>';
	str += '</td><td width="117" align="center" height="60">';
//	str += '<img src="/comlib/images/Header_elements/3icons&Text.gif" width="114" height="48" border="0" align="middle" usemap = "#HDRarchMap">';
	str += '</td><td width ="235" align="right" height="60">';
//  str += '<p><a href="/it/index.htm" target="_parent"><img src="/' + path[3] +'/corelib/images/Logo.gif" alt="Back to IT Page" border=0 height=58 width=63 align=top></a></p>';
    str += '<p><a href="/' + path[3] + '/index.htm" target="_parent"><img src="/' + path[3] +'/corelib/images/Logo.gif" alt="Back to Home Page" border=0 align=top></a></p>';
   	str += '</td><td width ="12" align="right" height="60"><a href="#top" target="_self"><img src="/comlib/images/up.gif" width=12 height=18 border=0 alt="Back to the top" align="top"></a> ';
   	str += '</td></tr>';
  	str += '<tr align="left" valign="TOP"> ';
   	str += '<td width="236" height="35" align="center" valign="top"> ';
   	str += '<p align="left"><a href="/it/index.htm" target="_parent"></a> ';
   	str += '<font size="-1" face="Arial, Helvetica, sans-serif"> Last update ' + document.lastModified + '</font>';
   	str += '<br><font size="-1" face="Arial, Helvetica, sans-serif">Questions ? ';
	if(str_contact > "")
       	str += '<a href="mailto:' + str_contact + '">'+ str_contact +'</a></font>';
	else
		str += '<a href="mailto:intranet@safeway.com">intranet@safeway.com</a></font>';
   	str += '</td><td width="117" height="35" align="center" valign="top">&nbsp;</td>';
   	str += '<td width="235" height="35" align="right" valign="top">';
	str += '<font size="-1" face="Arial, Helvetica, sans-serif">Copyright &copy; 1999 Safeway Inc.<br> All rights reserved.</font></td>';
   	str += '<td width ="12" align="right" height="35">&nbsp;</td>';
  	str += '</tr>';
	str += '</table>';


document.write(str);
}

//**** !! DO NOT EDIT !!
//links for high level menus NS3


function coreGotoPage(index){
	if(!index){
		window.location.reload();
		return;
	}
	url = coreGoTo[index];
	window.top.location.href = url;
}

//**** !! DO NOT EDIT !!
//high level NS3 menu
function makeCoreNS3menu(){
		//location from the page vars path[3]
		//find topic to highlight
		var light = 0;
		for( var i=0; i < window.coreMenuTopics.length; i++){
			var temp = window.coreGoTo[i].split("/");
			for( var j=0; j< temp.length; j++){
				if((path[4]== temp[j])){
					light = i; 
					break;
				}
			}
			if(light)	break;
		}
		if(!light){
			 light = 1;
			 navigator.clicked = 0;
		}

		htmlStr ='<SELECT NAME = "coremenu3"';
		htmlStr +='onFocus = "theSelectedIndex = this.selectedIndex; this.selectedIndex = 0;" ';
		htmlStr +='onBlur = "if(this.selectedIndex == 0) this.selectedIndex = theSelectedIndex;" ';
		htmlStr +='onChange = "coreGotoPage(this.selectedIndex)">';
		for (var i = 0; i < window.coreMenuTopics.length; i++)
			if( i == light)
				htmlStr +='<OPTION selected>' +window.coreMenuTopics[i] + '</OPTION>';			
			else
				htmlStr +='<OPTION>' +window.coreMenuTopics[i] + '</OPTION>';
		htmlStr +='</SELECT>';
	return htmlStr;
}


//**** !! DO NOT EDIT !!
//links for business menus NS3
function divGotoPage(index){
	if(!index){
		window.location.reload();
		return;
	}
	url = sGoTo[index];
//	navigator.sec = index;
	window.top.location.href = url;
}

//**** !! DO NOT EDIT !!
function makeDivNS3menu(){
		//location from the page vars path[3]; path[4]
		//find topic to highlight
		var sec = 0;
		for( var i=0; i < window.aMenuTopics.length; i++){
			var temp = window.sGoTo[i].split("/");
			for( var j=0; j< temp.length; j++){
				if((path[4]== temp[j])&&(path[5]== temp[j+1])){
					sec = i;
					break;
				}
			}
			if(sec)	break;
		}
	//	alert( "4: " + path[4]+ " 5: " + path[5] + " sec= " + sec + "\nGoto= " + sGoTo[sec]);
	//		alert(sec +"\n" + navigator.sec);
		if(sec == null){
			 sec = 0;
	 		 navigator.clicked = 1;
		}
		if( sec != navigator.sec){
			navigator.sec = sec;
			navigator.clicked = 1;
		}
	//		alert(sec +"\n" + navigator.sec);		
		//alert( "sec=" + sec + " clicked=" + navigator.clicked);
		htmlStr ='<SELECT  NAME = "divmenu3"';
		htmlStr +='onFocus = "theSelectedIndex = this.selectedIndex; this.selectedIndex = 0;" ';
		htmlStr +='onBlur = "if(this.selectedIndex == 0) this.selectedIndex = theSelectedIndex;" ';
		htmlStr +='onChange = "divGotoPage(this.selectedIndex)">';
		for ( i = 0; i < window.aMenuTopics.length; i++)
			if( i == sec)
				htmlStr +='<OPTION selected>' +window.aMenuTopics[i] + '</OPTION>';			
			else
				htmlStr +='<OPTION>' +window.aMenuTopics[i] + '</OPTION>';
		htmlStr +='</SELECT>';
	return htmlStr;
}


//VERTICAL MENU
//vertical navigation
function site_name(store){
str = '<br>&nbsp;';	
for( i =0; i < 8; i++)
	str += '<br>&nbsp;';
	str_html = 	'<center><b><font face="Arial,san-serif" size="3" color="Black">\n';
	str_html +=	(store) ? '<a href="index.htm" target="content" class="siteName">' + str_name + '</a></font></b></center><br>\n' :
							'<a href="index.htm" target="" class="siteName">' + str_name + '</a></font></b></center><br>\n';
		
		
	return(str_html);
}


function menu(frames, store){
 var img = 0;
 bar_hight = 400;
 est = 100 + local_menu_imgs.length * 35;
 var str_out = "";

 if(est > bar_hight) bar_hight = est;
 
//site name 
if(str_name.length > 1)
	str_out += site_name(store);

//images
if( local_menu_imgs[0].on != "")
	var img = 1;

if(img){
	 for (i =0; i < local_menu_imgs.length; i++){
		if( i == navigator.clicked){
			str_out += '<a href="' + local_menu_imgs[i].linkto + '"; ' +
			  ' onClick = "doMouseClickMenu('+i+')"';						   
			if(frames)
				str_out += ' target="'+ local_menu_imgs[i].target + '">';
			else
				str_out += '">';

			str_out += '<img src="' + local_menu_imgs[i].on + '" name = "' + local_menu_imgs[i].nme+
						   '"width=110 height=20 border=0 alt="' + local_menu_imgs[i].alt +'" ></a>';

		}
		else{
			if(local_menu_imgs[i].linkto.length > 0){
				str_out += '<a href="' + local_menu_imgs[i].linkto + '"; ' +
				  ' onMouseover = "' + local_menu_imgs[i].nme + '.src = \'' + local_menu_imgs[i].on + '\'"' +
				  ' onMouseOut = "' +  local_menu_imgs[i].nme + '.src = \''+ local_menu_imgs[i].src + '\'"'+
				  ' onClick = "doMouseClickMenu1('+i+')"';						   

				if(frames)
					str_out += ' target="'+ local_menu_imgs[i].target + '">';
				else
					str_out += '">';
			}
			str_out += '<img src="' + local_menu_imgs[i].src + '" name = "' + local_menu_imgs[i].nme +
						   '" width=110 height=20 border=0 alt="' + local_menu_imgs[i].alt+'" ></a>';

		}
		
	 }
}//end if gif
else{
 	str_out += '<img src="/' + 'comlib/images/clearpixel.gif" width="120" height="1" border=0 alt=""><br>';
	 for (i =0; i < local_menu_imgs.length; i++){
 		if(local_menu_imgs[i].linkto.length > 0){
			str_out += '<a href="' + local_menu_imgs[i].linkto ;
	 		(frames)? str_out += '" target=" ' + local_menu_imgs[i].target + '">' : str_out += '">';
			str_out += '<font face="Arial,san-serif" color="blue" size="-1">' + local_menu_imgs[i].alt+'</font></a><br>';
		}
		else		
			str_out += '<font face="Arial,san-serif" color="red" size="+1">' + local_menu_imgs[i].alt+'</font><br>';
	 }

}
//vertical bar
	str_out += '</td><td width="10">&nbsp;&nbsp;&nbsp;</td><td width="4"  align="center" valign="top" >' +
					'<img src="/' + path[3] + '/corelib/images/bar.gif" width="1" height="' + bar_hight+'" border=0 alt="">'+
		  			'</td>';
					
document.write(str_out);

}							   


function doMouseClickMenu1(j){
	navigator.clicked = j;
}











/*

//vertical navigation
function site_name(){
str = '<br>&nbsp;';	
for( i =0; i < 8; i++)
	str += '<br>&nbsp;';	
	str_html = 	'<center><b><font face="Arial,san-serif" size="3" color="Black">\n'+
				'<a href="index.htm" class="siteName">' + str_name + '</a></font></b></center><br>\n';
	return(str_html);
}



function menu(frames){
 var img = 0;
 bar_hight = 400;
 est = 50 + local_menu_imgs.length * 20;
 var str_out = "";
  
 if(est > bar_hight) bar_hight = est;
 
//site name 
if(str_name.length > 1)
	str_out += site_name();

//images
if( local_menu_imgs[1][0]!="")
	var img = 1;

if(img){
	 for (i =0; i < local_menu_imgs.length; i++){
		if( i == navigator.clicked){
			str_out += '<a href="' + local_menu_imgs[i][3]+ '"; ' +
			  ' onMouseover = "' + local_menu_imgs[i][2] + '.src = \''+ local_menu_imgs[i][1] + '\'"'+
			  ' onClick = "doMouseClickMenu('+i+')"';						   
			if(frames)
				str_out += ' target="'+ local_menu_imgs[i][6] + '">';
			else
				str_out += '">';

			str_out += '<img src="' + local_menu_imgs[i][1] + '" name = "' + local_menu_imgs[i][2]+
						   '"width=110 height=20 border=0 alt="' + local_menu_imgs[i][5]+'" ></a>';

		}
		else{
			if(local_menu_imgs[i][3].length > 0){
				str_out += '<a href="' + local_menu_imgs[i][3]+ '"; ' +
				  ' onMouseover = "' + local_menu_imgs[i][2] + '.src = \''+ local_menu_imgs[i][1] + '\'"'+
				  ' onMouseOut = "' +  local_menu_imgs[i][2] + '.src = \''+ local_menu_imgs[i][0] + '\'"'+
				  ' onClick = "doMouseClickMenu('+i+')"';						   

				if(frames)
					str_out += ' target="'+ local_menu_imgs[i][6] + '">';
				else
					str_out += '">';
			}
			str_out += '<img src="' + local_menu_imgs[i][0] + '" name = "' + local_menu_imgs[i][2] +
						   '" width=110 height=20 border=0 alt="' + local_menu_imgs[i][5]+'" ></a>';
//			local_menu_imgs[i][4] = 0;
		}
		
	 }
}//end if gif
else{
 	str_out += '<img src="/' + 'comlib/images/clearpixel.gif" width="120" height="1" border=0 alt=""><br>';
	 for (i =0; i < local_menu_imgs.length; i++){
 		if(local_menu_imgs[i][3].length > 0){
			str_out += '<a href="' + local_menu_imgs[i][3] ;
	 		(frames)? str_out += '" target="body">' : str_out += '">';
			str_out += '<font face="Arial,san-serif" color="blue" size="-1">' + local_menu_imgs[i][5]+'</font></a><br>';
		}
		else		
			str_out += '<font face="Arial,san-serif" color="red" size="+1">' + local_menu_imgs[i][5]+'</font><br>';
	 }

}
//vertical bar
	str_out += '</td><td width="10">&nbsp;&nbsp;&nbsp;</td><td width="4"  align="center" valign="top" >' +
					'<img src="/' + path[3] + '/corelib/images/bar.gif" width="1" height="' + bar_hight+'" border=0 alt="">'+
		  			'</td>';
					
document.write(str_out);
}							   


function doMouseOverMenu(obj,i){
		eval('document.images["'+ obj +'"].src = "' + local_menu_imgs[i][1] + '"');
}

function doMouseOutMenu(obj,i){
	if(local_menu_imgs[i][4] == 0)
		eval('document.images["'+ obj +'"].src = "' + local_menu_imgs[i][0] + '"');
}

function doMouseClickMenu(j){
	for( i =0; i < local_menu_imgs.length; i++){
		if( i == j){
			eval('document.images["'+ local_menu_imgs[i][2] +'"].src = "' + local_menu_imgs[i][1] + '"');		
//			local_menu_imgs[i][4] = 1;
		}
		else{
			eval('document.images["'+ local_menu_imgs[i][2] +'"].src = "' + local_menu_imgs[i][0] + '"');		
//			local_menu_imgs[i][4] = 0;
		}
	}
	if( local_menu_imgs[1][0]!="")
		navigator.clicked = j;
}

*/