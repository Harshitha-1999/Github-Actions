// For instructions read form_check_doc.txt
var digits = "0123456789";
var whitespace = " \t\n\r";
var SSNDelimiters = "- ";

var mPrefix = "You did not enter a value into the "
var mSuffix = "\nfields.\nThis is a required field. Please enter it now."
var mInvalid= "You have entered invalid ";
var pEntryPrompt = "Please enter a ";

var defaultEmptyOK = false;


function isEmpty(s){
   return ((s == null) || (s.length == 0));
}

function isWhitespace (s){
   var i;
   if ((s == null) || (s.length == 0)) return true;
   for (i = 0; i < s.length; i++) {   
		if( whitespace.indexOf( s.charAt(i)) == -1) return false;
   }
    return true;
}

function isLetter (c){
	var result = false;
	var lowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
	var uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for(i = 0; i < lowercaseLetters.length; i++){
		if( c == lowercaseLetters[i] || c==uppercaseLetters[i]){
			return result = true;
		}
	}
	return result;
}


function isDigit (c){
   return ((c >= "0") && (c <= "9"))
}

function isLetterOrDigit (c){
	var lowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
	var uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for(i = 0; i < lowercaseLetters.length; i++){
		if( c == lowercaseLetters[i] || c==uppercaseLetters[i]){
			return result = true;
		}
	}
   return ((c >= "0") && (c <= "9"));
}

function isAlphabetic (s){
   var i;
   var testStr = s.toString();
 
    if (isWhitespace(testStr)) 
       if (isAlphabetic.arguments.length == 1) return defaultEmptyOK;
       else return (isAlphabetic.arguments[1]);
    for (i = 0; i < testStr.length; i++) {   
        if (!isLetter(s.charAt(i)))
        return false;
    }
    return true;
}

function isAlphanumeric (s){
   var i;

    if (isWhitespace(s)) 
       if (isAlphanumeric.arguments.length == 1) return defaultEmptyOK;
       else   return (isAlphanumeric.arguments[1]);

	for (i = 0; i < s.length; i++) {   
        var c = s.charAt(i);
        if (!(isLetterOrDigit(c) ) )
        return false;
    }
    return true;
}

function isInt (s){
   var i=0;
   var testStr = s.toString();
    if (isWhitespace(testStr))
       if (isInt.arguments.length == 1) return defaultEmptyOK;
       else return (isInt.arguments[1]);

	if((testStr[0] == "+") || (testStr[0] =="-"))
		i=1;
    for (i; i < testStr.length; i++) {
		testChar = testStr.charAt(i);
		if(testChar < "0" || testChar > "9") return false;
    }
    return true;
}


function isSignedInt (s){
    var testStr = s.toString();
    var startPos = 0;    	
	
    if (isWhitespace(testStr)) 
       if (isSignedInteger.arguments.length == 1) return defaultEmptyOK;
       else return (isSignedInteger.arguments[1]);

	if ( (testStr[0] == "-") || (testStr[0] == "+") ) {
	   startPos = 1;    
       for (i = startPos; i < testStr.length; i++) {
			testChar = testStr.charAt(i);
			if(testChar < "0" || testChar > "9") return false;
	   }
	   return true;
   	}
	else return false;
}

function isPostvInt (s){
    var testStr = s.toString();
    var startPos = 0;    	

    if (isWhitespace(testStr)) 
       if (isPostvInt.arguments.length == 1) return defaultEmptyOK;
       else return (isPostvInt.arguments[1]);

    if ( (testStr[0] == "+") ) 
	   startPos = 1;    
    for (i = startPos; i < testStr.length; i++) {
		testChar = testStr.charAt(i);
		if(testChar < "0" || testChar > "9") return false;
    }
	return(( parseInt(testStr.substring(startPos))) > 0);
}

function isNonNegtvInt (s){
    var testStr = s.toString();
    var startPos = 0;    	

    if (isWhitespace(testStr)) 
       if (isNonNegtvInt.arguments.length == 1) return defaultEmptyOK;
       else return (isNonNegtvInt.arguments[1]);

    if ( (testStr[0] == "+") ) 
	   startPos = 1;    
    for (i = startPos; i < testStr.length; i++) {
		testChar = testStr.charAt(i);
		if(testChar < "0" || testChar > "9") return false;
     }

	return(parseInt(testStr.substring(startPos))>=0);

}

function isNegtvInt (s){
    var testStr = s.toString();
    var startPos = 0;    	

    if (isWhitespace(testStr)) 
       if (isNegtvInt.arguments.length == 1) return defaultEmptyOK;
       else return (isNegtvInt.arguments[1]);

    if ( (testStr[0] == "-") ) {
	   startPos = 1;    
	    for (i = startPos; i < testStr.length; i++) {

			testChar = testStr.charAt(i);

			if(testChar < "0" || testChar > "9") return false;

	     }

		 return (parseInt(testStr) < 0);

	}

	else return false;

}





function isNonPostvInt (s){

    var testStr = s.toString();

    var startPos = 0;    	

	

    if (isWhitespace(testStr)) 

       if (isNonPostvInt.arguments.length == 1) return defaultEmptyOK;

       else return (isNonPostvInt.arguments[1]);



    if ( (testStr[0] == "-") ) 

	   startPos = 1;    

    for (i = startPos; i < testStr.length; i++) {

		testChar = testStr.charAt(i);

		if(testChar < "0" || testChar > "9") return false;

    }

	return (parseInt(testStr) <= 0);



}





function isFloat (s){

   var seenDecimalPoint = false;

   var testStr = s.toString();

   var startPos = 0;    	   

   

    if (isWhitespace(testStr)) 

       if (isFloat.arguments.length == 1) return defaultEmptyOK;

       else return (isFloat.arguments[1] == true);



    if (testStr == ".") return false;

    if ( (testStr[0] == "-") ) 

	   startPos = 1;    

	   

    for (i = startPos; i < testStr.length; i++) {   

        var c = testStr.charAt(i);

   		if( c == "."){

			if(!seenDecimalPoint) seenDecimalPoint = true;

			else return false; 

			continue;

		}

		if(c < "0" || c > "9") return false;

    }

    return true;

}





function isSignedFloat (s){ 

	 var seenDecimalPoint = false;

	 var testStr = s.toString();

	 var startPos = 0;    	   



    if (isWhitespace(testStr)) 

       if (isSignedFloat.arguments.length == 1) return defaultEmptyOK;

       else return (isSignedFloat.arguments[1] == true);



    if (testStr == ".") return false;



    if ((testStr[0] == "-") || (testStr[0] == "+")) {

	   startPos = 1;    



	    for (i = startPos; i < testStr.length; i++) {   

	        var c = testStr.charAt(i);

	   		if( c == "."){

				if(!seenDecimalPoint) seenDecimalPoint = true;

				else return false; 

				continue;

			}

			if(c < "0" || c > "9") return false;

	    }

	    return true;

	}

    return false;

}





function isIntegerInRange (s, a, b){

    var testStr = s.toString();

	

    if (isWhitespace(testStr)) 

       if (isIntegerInRange.arguments.length == 1) return defaultEmptyOK;

       else return (isIntegerInRange.arguments[1] == true);



    if (!isInt(s, false)) return false;

	var num = parseInt (s,10);

	return ((num >= a) && (num <= b));

}





function stripCharsInBag (s, bag){

    var i;

    var returnString = "";

    for (i = 0; i < s.length; i++) {   

        var c = s.charAt(i);

        if (bag.indexOf(c) == -1) returnString += c;

    }

    return returnString;

}





function stripCharsNotInBag (s, bag){

   var i;

   var returnString = "";

    for (i = 0; i < s.length; i++)  {   

        var c = s.charAt(i);

        if (bag.indexOf(c) != -1) returnString += c;

    }

    return returnString;

}





function stripWhitespace (s){

	var i;

    var returnString = "";

    for (i = 0; i < s.length; i++) {   

        var c = s.charAt(i);

        if (whitespace.indexOf(c) == -1) returnString += c;

    }

    return returnString;

}



function stripInitialWhitespace (s) {

    var i = 0;

	while ((i < s.length) && (whitespace.indexOf(s.charAt(i)) != -1))

       i++;

    return s.substring (i, s.length);

}



function stripInitialZeros (s) {

    var i = 0;

    while ((i < s.length) && s.charAt(i) == "0")

       i++;

    return s.substring (i, s.length);

}



function stripTrailWhitespace (s) {

	for (i=s.length; i >0 && (whitespace.indexOf(s.charAt(i)) != -1);i--);

	strTemp = s.substring (0, i+1);

	return strTemp;

}





function isSSN (objField){

   var testStr = (objField.value).toString();

   var digitsInSocialSecurityNumber = 9;

   var normalizedSSN = "";



	if (isWhitespace(testStr))

		if(isSSN.arguments.length >1) return isSSN.arguments[1];

  

  normSSN = stripCharsNotInBag(stripCharsInBag(testStr, SSNDelimiters), digits);

  

  if (!(isPostvInt(normSSN) && normSSN.length == digitsInSocialSecurityNumber)) {

  	alert(mInvalid+"Social Security Number\n"+pEntryPrompt+ "9 digit U.S. social security number (like 123 45 6789)." );

	objField.focus();

	objField.select();

	return false;

  }

  else{

  	objField.value=reformat(normSSN, "", 3, "-", 2, "-", 4);

    return true;

  }

}



/*

function isSSNCanada (s){

   var digitsInSSNCanada = 6;

   

   if (isWhitespace(s)) 

       if (isSSN.arguments.length == 1) return defaultEmptyOK;

       else return (isSSN.arguments[1] == true);

	

	str = stripCharsNotInBag(s, digits);

    return ( isInteger(str) && 	str.length == digitsInSSNCanada );



}





function checkSSNCanada (theField, emptyOK)

{   if (checkSSNCanada.arguments.length == 1) emptyOK = defaultEmptyOK;

    if ((emptyOK == true) && (isEmpty(theField.value))) return true;

    else

    {  var normalizedSSN = stripCharsInBag(theField.value, SSNDelimiters)

       if (!isSSNCanada(normalizedSSN, false)) 

          return warnInvalid (theField, iSSNCanada);

       else return true;

    }

}





*/



function isPhoneNumber(objField){

	var dgtsInPhoneNumb = 10;

	var phoneNumDelim="()- ";

	

	var normPhone ="";

	var testStr = (objField.value).toString();

	

	if (isWhitespace(testStr))

		if(isPhoneNumber.arguments.length >1) return isPhoneNumber.arguments[1];



	

	normPhone = stripCharsNotInBag(stripCharsInBag(testStr, phoneNumDelim), digits);

	

	if(!(isPostvInt(normPhone) && normPhone.length == dgtsInPhoneNumb)){

		alert(mInvalid+"Phone Number\n"+pEntryPrompt+ "10 digit U.S. phone number (like 415 555 1212).");

		objField.focus();

		objField.select();

		return false;

	}

	else{

	  	objField.value=reformat(normPhone, "(", 3,") ", 3, "-", 4);

    	return true;

	}

}







function isWorldPhoneNumber (objField){

	var dgtsInPhoneNumb = 10;

	var WphoneNumDelim="()-+ ";

	

	var normPhone ="";

	var testStr = (objField.value).toString();

	

	if (isWhitespace(testStr))

		if(isWorldPhoneNumber.arguments.length >1) return isWorldPhoneNumber.arguments[1];



	normPhone = stripCharsNotInBag(stripCharsInBag(testStr, WphoneNumDelim), digits);

	

	if(!(isPostvInt(normPhone) && normPhone.length == dgtsInPhoneNumb)){

		alert(mInvalid+"Phone Number\n"+pEntryPrompt+ "international phone number.");

		objField.focus();

		objField.select();

		return false;

	}

	else{

	  	objField.value=reformat(normPhone, "+(", 3,")-", 3, "-", 4);

    	return true;

	}

}





function isZipCode (objField){

	var digitsInZIPCode1 = 5;

	var digitsInZIPCode2 = 9;

	var ZipDelim = "-";

	var normZIP="";

	var testStr = (objField.value).toString();

	

	if (isWhitespace(testStr))

		if(isZipCode.arguments.length >1) return isZIPCode.arguments[1];



	   

	normZip = stripCharsNotInBag(stripCharsInBag(objField.value, ZipDelim),digits);   

    if( isPostvInt(normZip) && normZip.length == digitsInZIPCode1 ){

	  	objField.value=reformat(normZip, "", 5);

    	return true;

	}

	else if( isPostvInt(normZip) && normZip.length == digitsInZIPCode2 ){

	  	objField.value=reformat(normZip, "", 5,"-", 4);

    	return true;

	}

	else{

		alert(mInvalid+"ZIP Code\n"+pEntryPrompt+ "5 or 9 digit U.S. ZIP Code (like 94043).");

		objField.focus();

		objField.select();

		return false;

	}

}





function isCanadaPostCode(objField){

	

	var charNotInCanadaPostCodes ="DdFfIiOoQqUu";

	var charNotInPartCanadaPostCodes="WZwz";

	var i;

	var invalid = 0	;

	var testStr = (objField.value).toString();



	if (isWhitespace(testStr))

		if(isCanadaPostCode.arguments.length >1) return isCanadaPostCode.arguments[1];

	

	if( testStr.length != 7) invalid=1;

	if(!invalid){

		for(i=0; i<testStr.length; i++){

			ch = testStr[i];

			if( ((i==0) || (i==2) || (i==5) ) && isLetter(ch)){

				if((charNotInCanadaPostCodes.indexOf(ch) != -1) || ((i<3) && (charNotInPartCanadaPostCodes.indexOf(ch)!=-1)))

				{

				  invalid =1; break;

				}

			}

			else if(i==3 && ch !=" ")  { invalid =1;break;}

			else if( ( i == 1 || i == 4 || i == 6) && !isDigit(ch)) { invalid =1; break;}

		}

	}

 	switch(invalid){

		case 0:

			objField.value = testStr.toUpperCase();

			return true;

		case 1:

			alert(mInvalid+"Canada Postal Code\n"+pEntryPrompt+ "7 characters Canada Postal Code (like K3L 4M2)");

			objField.focus();

			objField.select();

			return false;		

	}

}



function isStateCode(objField){

	var USStateCds = "AL|AK|AS|AZ|AR|CA|CO|CT|DE|DC|FM|FL|GA|GU|HI|ID|IL|IN|IA|KS|KY|LA|ME|MH|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|MP|OH|OK|OR|PW|PA|PR|RI|SC|SD|TN|TX|UT|VT|VI|VA|WA|WV|WI|WY|AE|AA|AE|AE|AP";

	var USStateCdDelim = "|";	

	var empty = false;	

	var testStr = (objField.value).toString();

	var help = "";

	

	if (isWhitespace(testStr)){

		if(isStateCode.arguments.length >1) return isStateCode.arguments[1];

		empty =true;

	}

	

	testStr =testStr.toUpperCase();

	if( (USStateCds.indexOf(testStr) != -1) && (testStr.indexOf(USStateCdDelim) == -1) && !empty && testStr.length == 2){

		objField.value = testStr;

		return true;

	}

	else{

		switch(testStr[0]){

			case "A":

				help = "\n(Alabama = AL; Alaska = AK; Arizona = AZ; Arkansas = AR;)";

				break;

			case "C":

				help = "\n(California = CA, Colorado = CO; Connecticut = CT;)";

				break;

			case "D":

				help = "\n(Delaware = DE; District of Colombia = DC;)";

				break;

			case "I":

				help = "\n(Idaho = ID; Illinois = IL; Indiana = IN; Iowa = IA)";

				break;

			case "K":

				help = "\n(Kansas = KS; Kentucky = KY;)";

				break;				

			case "M":

				help = "\n(Maine = ME; Maryland = MD; Massachusetts = MA; Michigan = MI;\nMinnesota = MN; Mississippi = MS; Missouri = MO; Montana = MT;\n)";

				break;	

			case "N":

				help = "\n(Nebraska = NE; Nevada = NV; New Hampshire = NH; New Jersey = NJ\nNew Mexico = NM; New York = NY; North Carolina = NC; North Dakota = ND)";

				break;				

			case "O":

				help = "\n(Ohio = OH; Oklahoma = OK; Oregon = OR; )";

				break;

			case "S":

				help = "\n(South Carolina = SC; South Dakota = SD;)";

				break;				

			case "T":

				help = "\n(Tennessee = TN; Texas = TX; )";

				break;

			case "V":

				help = "\n(Vermont = VT; Virginia = VA;)";

				break;

			case "W":

				help = "\n(Washington = WA; West Virginia = WV; Wisconsin = WI; Wyoming = WY)";

				break;				

			default:

				help = "";

		}

		alert(mInvalid+"State Code\n"+pEntryPrompt+ "2 character code (like CA)." + help);

		objField.focus();

		objField.select();

		return false;		

	}

}

function checkCanSSI(objField, emptyOK){
    var testStr = (objField.value).toString();

	if (isWhitespace(testStr))
		if(checkSSN.arguments.length < 2) return  false;
		else return checkSSN.arguments[1];

	var SSIpattern = /^(\d{6})$/;
	var SSIdelim = /[\-\s]/gi;

	testStr= testStr.replace(SSIdelim, "");
    if (!testStr.match(SSIpattern)) {
	  	alert(mInvalid+"Canada Social Security Id\n"+pEntryPrompt+ "6 digit SSI (i.e 123456 )." );
		objField.focus();
		objField.value = "";
		return false;
    }
	else{
  		objField.value=testStr;
	    return true;
  	}
}

function checkAlphaField(objField, emptyOK){

	var testStr = objField.value.toString();
	if (isWhitespace(testStr))
		if(checkAlphaField.arguments.length < 2) return  false;
		else return checkAlphaField.arguments[1];
	
	 if( !isAlphabetic(objField.value)){
		  alert( "You must enter alphbetic characters only!");
		  objField.focus();
		  objField.value = "";
		  return false;
	 }
 return true;
}





function isCanadaCode(objField){

	var CanadaCodes = "AB|BC|MB|NB|NF|NT|NS|ON|PE|QC|SK|YK";

	var CanadaCdsDelim = "|";	

	var empty = false;	

	var testStr = (objField.value).toString();

	var help = "";

	

	if (isWhitespace(testStr)){

		if(isCanadaCode.arguments.length >1) return isCanadaCode.arguments[1];

		empty =true;

	}

		

	testStr =testStr.toUpperCase();

	if( (CanadaCodes.indexOf(testStr) != -1) && (testStr.indexOf(CanadaCdsDelim) == -1) && !empty && testStr.length == 2){

		objField.value = testStr;

		return true;

	}

	else{

		switch(testStr[0]){

			case "N":

				help = "\n(New Brunswick = NB;\nNewfoundland = NF;\nNorthwest Territories and Nunavut = NT;\nNova Scotia = NS;)";

				break;		

			default:

				help = "\n(Alberta = AB;\nBritish Columbia = BC;\nManitoba = MB;\nNew Brunswick = NB;\nNewfoundland = NF;\nNorthwest Territories and Nunavut = NT;\nNova Scotia = NS;\nOntario=ON;\nPrince Edward Island = PE; Quebec =QC;\nSaskatchewan = SK;\nYukon = YK;)";



		}

		alert(mInvalid+"Canada Province\n"+pEntryPrompt+ "2 character code (like YK)." + help);

		objField.focus();

		objField.select();

		return false;		

	}

}







function isEmail(objField){

	var testStr = (objField.value).toString();

	invalid = false;

	

	if (isWhitespace(testStr))

		if(isEmail.arguments.length >1) return isEmail.arguments[1];



	var i= j= k= seenAT= seenDOT= count = 0;



	for(n=1; n< testStr.length; n++){

		c = testStr.charAt(n);

		switch(c){

			case ".":

				if(seenAT) seenDOT=1;

				break;

			case "@":

				if(!seenDOT && !seenAT) seenAT=1;

				else invalid=true;

				break;

			default:

				if(isLetterOrDigit(c))

					if( !seenAT && !seenDOT) i++;

					else if(seenAT && !seenDOT ) j++;

					else if(seenAT && seenDOT ) k++;

				else invalid=true;

		}		

	}

	if( (i > 0) && (j >0) && (k>0) && !invalid ){

		return true;

	}

	else{

		alert(mInvalid+"Email\n"+pEntryPrompt+ "valid email address (like foo@bar.com).");

		objField.focus();

		objField.select();

		return false;		

	}

}



function isM70_P20Date(objField) { 

	var testStr = (objField.value).toString();

	if (isWhitespace(testStr))

		if(isM90_M20Date.arguments.length >1) return isM90_M20Date.arguments[1];



	 var thisYear = (new Date()).getFullYear();

	return isDate(objField,(thisYear - 70),(thisYear + 20));

}





 function  isM70_0Date(objField) {

	var testStr = (objField.value).toString();

	if (isWhitespace(testStr))

		if(isM70_0Date.arguments.length >1) return isM70_0Date.arguments[1];



	 var thisYear = (new Date()).getFullYear();

	 return isDate(objField,(thisYear - 70),(thisYear))

 }



 

 function isM5_P10Date() {

	var testStr = (objField.value).toString();

	if (isWhitespace(testStr))

		if(isM5_P10Date.arguments.length >1) return isM5_P10Date.arguments[1];



	 var thisYear = getFullYear();

	 return isDate((thisYear - 5),(thisYear + 10)) 

 }





function isDate(gField,minYear,maxYear,minDays,maxDays) {
	 var inputStr = gField.value;
	 var invalid = 0;
	 var yearsBack = 90;
	 var yearsForw = 9;
	 while (inputStr.indexOf("-") != -1) {
		inputStr = inputStr.replace("-", "/");
	 }

	 var delim1 = inputStr.indexOf("/");
	 var delim2 = inputStr.lastIndexOf("/");
	 if (delim1 != -1 && delim1 == delim2) {
		alert("The date entry is not in an acceptable format.\n\nYou can enter dates in the following formats: mmddyyyy, mm/dd/yyyy, or mm-dd-yyyy. (If the month or date data is not available, enter \'01\' in the appropriate location.)"); 
		gField.focus();
		gField.select();
		return false 
	 } 
	 if (delim1 != -1) { 
		 var mm = parseInt(inputStr.substring(0,delim1),10);
		 var dd = parseInt(inputStr.substring(delim1 + 1,delim2),10);
		 var yyyy = parseInt(inputStr.substring(delim2 + 1, inputStr.length),10) 
	 }

	 else {
		 var mm = parseInt(inputStr.substring(0,2),10);
		 var dd = parseInt(inputStr.substring(2,4),10);
		 var yyyy = parseInt(inputStr.substring(4,inputStr.length),10);
	 }

	 if (isNaN(mm) || isNaN(dd) || isNaN(yyyy))  {
	 	alert("The date entry is not in an acceptable format.\n\nYou can enter dates in the following formats: mmddyyyy, mm/dd/yyyy, or mm-dd-yyyy.");
		gField.focus();
		gField.select();
		return false;
	 }

	 if (mm < 1 || mm > 12) {
	  alert("Months must be entered between the range of 01 (January) and 12 (December).");
	  gField.focus();
	  gField.select();
	  return false;
	 }
	 if (dd < 1 || dd > 31) {
	  alert("Days must be entered between the range of 01 and a maximum of 31 (depending on the month and year).");
	  gField.focus();
	  gField.select();
	  return false;
	 }
	 var today = new Date();
	 if (yyyy < 100) {
		  var todayYear = today.getFullYear();
		  if(!minYear){
			   minWindow = todayYear - yearsBack;
			   maxWindow = todayYear + yearsForw;
		  }
		  else{
			  minWindow = minYear;
			  maxWindow = maxYear;
	      }
		  mincc = Math.floor(minWindow/100);
    	  minyy = minWindow%100;
	      maxcc = Math.floor(maxWindow/100);
		  if (yyyy >= minyy)
    		 	 yyyy += mincc * 100;
		  else yyyy += maxcc * 100;
  }
	  if (!minYear) { 
	 	var dateStr = new String(mm + "/" + dd + "/" + yyyy);
		var testDate = new Date(dateStr);
		if (testDate.getTime() < (today.getTime() - (minDays * 24 * 60 * 60 * 1000))) {
			 alert("The most likely range for this entry begins " + minDays + " days from today.") 
			gField.focus();
			gField.select();
			return false;
		}
		if (testDate.getTime() > (today.getTime() + (maxDays * 24 * 60 * 60 * 1000))) {
			 alert("The most likely range for this entry ends " + maxDays + " days from today.");
			gField.focus();
			gField.select();
			return false;
		}
	}
	else if (minYear && maxYear) {  
		if (yyyy < minYear || yyyy > maxYear) {
		 alert("The most likely range for this entry is between the years " + minYear + " and " + maxYear + ". If your source data indicates a date outside this range, then enter that date.") 
		 gField.focus();
		 gField.select();
		 return false;
		}
	}
	else {
		var thisYear = today.getFullYear();
		if (yyyy < minYear || yyyy > maxYear) {
			 alert("It is unusual for a date entry to be before " + minYear + " or after " + maxYear + ". Please verify this entry.");
			 gField.focus();
			 gField.select();
		 	 return false;
		}
	}
	if (!checkMonthLength(mm,dd)) {
	 	 gField.focus();
		 gField.select();
		 return false;
	}
	if (mm == 2) {
	 	 if (!checkLeapMonth(dd,yyyy)) {
			 gField.focus();
			 gField.select();
			 return false;
		 }
	}
	if( mm < 10) mm = "0" + mm;
	if( dd < 10) dd = "0" + dd;
	gField.value = mm + "/" + dd + "/" + yyyy;
	return true;
} 



function checkMonthLength(mm,dd) {

	 var months = new Array("","January","February","March","April","May","June","July","August","September","October","November","December");

	 if ((mm == 4 || mm == 6 || mm == 9 || mm == 11) && dd > 30) {

	 	 alert(months[mm] + " has only 30 days.");

		 return false 

	 }

	 else if (dd > 31) {

	 	 alert(months[mm] + " has only 31 days.");

		 return false 

	 }

	 return true 

} 





function checkLeapMonth(dd,yyyy) {

  	if ( (!(yyyy % 4) && yyyy % 100 || !(yyyy % 400)) && dd > 29) {

		alert("February of " + yyyy + " has only 29 days.");

		return false;

	}

	else if ( yyyy%4 && dd > 28) {

		alert("February of " + yyyy + " has only 28 days.");

		return false;

	}

	return true 

} 





function checkForQuotes(checkString){

    var newString = ""; 

    var count = 0;      



    i = checkString.indexOf("'");

    if (i>0) {

		newString = checkString.substring(0, i);

        for (i; i < checkString.length; i++) {

			ch=checkString[i];

            if( ch == "'") newString += ch + "'";

            else 

              if (ch >= " " && ch <= "~") newString += ch;

        }

    }

    if (newString!="") {

      if (confirm("The value you have entered\ncontains single-quote characters,\nthe database requires these to be in pairs.\nIs it okay to alter them?")) 

        return newString;

	  else

	  	return checkString;

    }

    return checkString;

}



function checkReqTextFields(form){

	var alertStr= mPrefix;

	var intMissed = 0;

	for ( i =0; i<form.elements.length; i++){

		if((form.elements[i].type=="text" || form.elements[i].type=="textarea") && form.elements[i].name.substring(0,3) == "req")

			if(isWhitespace(form.elements[i].value)){

				alertStr+= "\n" +form.elements[i].name.substring(3);

				if(!intMissed){

				 intMissed = 1;

				 form.elements[i].focus();

				}

			}

	}

	if(intMissed) {

		alert(alertStr+="\n" + mSuffix);

		return false;

	}

	else 

		return(true);

}



function checkReqFields(form){

	var alertStr=mPrefix;

	var intMissed = 0;

	var check = 0;

	var radioName = "";



    for ( i =0; i<form.elements.length; i++){

	 if(form.elements[i].name.substring(0,3) == "req"){

	   if(form.elements[i].type=="text" || form.elements[i].type=="textarea"){

				if(isWhitespace(form.elements[i].value)){

					alertStr+= "\n" +form.elements[i].name.substring(3);

					if(!intMissed){

						 intMissed=1;

						 form.elements[i].focus();

					}

				}

		}

		else if( form.elements[i].type=="select-one"){

			if(!form.elements[i].selectedIndex){

				alertStr+="\n" + form.elements[i].name.substring(3);

				if(!intMissed){

					 intMissed=1;

					 form.elements[i].focus();

				}

			}

		}

		else if(form.elements[i].type == "radio"){

			var name = form.elements[i].name;

			if (name == radioName) continue;

			var length = eval('form.'+name +'.length');

			for(j=0; j < length; j++){

				if(eval('form.'+name+'[j].checked')){

					check = 1;	break;

				}

			}

			if( j == length){

				radioName = form.elements[i].name;

				alertStr+="\n" + radioName.substring(3);

				if(!intMissed){

					 intMissed=1;

					form.elements[i].focus();

				}

			}

		}

	  }

	}

    if(intMissed){

		alert(alertStr+="\n" + mSuffix);

		return false;

	}

	else 

		return(true);

}



function checkAllFields(form){

	var alertStr=mPrefix;

	var intMissed = 0;

	var check = 0;

	var radioName = "";

	

  for ( i =0; i<form.elements.length; i++){

	if(form.elements[i].type=="text" || form.elements[i].type=="textarea"){

			if(isWhitespace(form.elements[i].value)){

				alertStr+= "\n" +form.elements[i].name;

				if(!intMissed){

				 intMissed=1;

				 form.elements[i].focus();

				}

			}

	}

	else if( form.elements[i].type=="select-one"){

		if(!form.elements[i].selectedIndex){

			alertStr+="\n" + form.elements[i].name;

			if(!intMissed){

				 intMissed=1;

				 form.elements[i].focus();

			}

		}

	}

	else if(form.elements[i].type == "radio"){

		var name = form.elements[i].name;

		if (name == radioName) continue;

		var length = eval('form.'+name +'.length');

		for(j=0; j < length; j++){

			if(eval('form.'+name+'[j].checked')){

				check = 1;	break;

			}

		}

		if( j == length){

			radioName = form.elements[i].name;

			alertStr+="\n" + radioName;

			if(!intMissed) intMissed=1;

		}

	}

  }

  if(intMissed) {

		alert(alertStr+="\n" + mSuffix);

		return false;

	}

	else 

		return(true);

}



function reformat (s){

    var arg;

    var sPos = 0;

    var resultString = "";



    for (var i = 1; i < reformat.arguments.length; i++) {

       if (i % 2 == 1) resultString += reformat.arguments[i];

       else {

           resultString += s.substring(sPos, sPos + reformat.arguments[i]);

           sPos += reformat.arguments[i];

       }

    }

    return resultString;

}





function format_int(number){

        var len = number.length;      

        if (len < 4)

                return number;

        var start = len % 3;

        var end = start + 3;

        result = "";

        if(start)

                result = number.substring(0, start) + ',';

        

        for(i = start, j = end; j< len; i = j, j+=3){

                result += number.substring(i, j) + ",";

        }

        result += number.substring(i, j);

        return result;

}



function format_$_currency(theField){

	if(theField.value == null) return("&nbsp;");

	

	if(!isInt(stripCharsInBag(theField.value, "."))){

		alert("Invalid Data: must use digits only");

		theField.focus();

		theField.select();

		return false; 

	}

	var data="" + theField.value;

	var temp = data.split(".");

	var dolr= format_int(temp[0]);

	var cents = ".";

	if(temp[1]){

		if(temp[1].length == 1){

			cents+=temp[1] + "0";

		}

		else{

			str_cents = "" + Math.round(temp[1]/ Math.pow(10, temp[1].length-2 ));

			cents +=str_cents.substring(0,2);

		}

	}

	else

		cents += "00";

	theField.value = "$" + dolr + cents;	

	return true;

}



function format_c_currency(theField){

	var data = theField.value;

	

	if(data == null) return("&nbsp;");

	if(!isInt(data)){
		alert("Invalid Data: must use only digits\nand no decimal point");
		theField.focus();
		theField.select();
		return false; 
	}
	var dolr= format_int(data.substring(0,data.length-2));
	var cents = '.'+data.substring(data.length-2, data.length);
	theField.value = "$" + dolr + cents;
	return true;
}


function percentit(innum, decplaces) {
	var precision = Math.pow(10,decplaces);
	return ( Math.round(innum*100*precision) / precision + "%");
}


function roundit(innum, decplaces) {
	var precision = Math.pow(10,decplaces);
	return ( Math.round(innum*precision)/precision);
}



