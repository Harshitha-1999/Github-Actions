// by Ilya Yankov
// returns percentage of two numbers

function calc2(form) {
a = form.c.value;
b = form.d.value;
c = a/b;
d = c*100;
form.total2.value = d;
}
