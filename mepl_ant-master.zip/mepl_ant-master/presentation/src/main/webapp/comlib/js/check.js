/* 	userid	date	description

	jarqu00	04/2003	isMoney - added positve/negative pattern.

					formatDate - checked results of getFullYear() to make sure that it is returning the correct century.

					formatInt - added stripping of non-numeric and all leading zeros.

					formatDollar - added checking of negative values.

					formatPercent - added 2 decimal places when numDec is zero or undefined.

*/

var glsPrefix = "You did not enter a value into the";

var glsSuffix = "\nfields.\nThis is a required field. Please enter it now.";

var glsSuffixPlu = "\nfields.\nThese are required fields. Please enter now.";

var glsInvalid= "You have entered an invalid ";

var glsPrompt = "Please enter ";

var glsStates = "\nAlabama = AL; Alaska = AK;  Arizona = AZ; Arkansas = AR;"+

				"\nCalifornia = CA, Colorado = CO; Connecticut = CT;"+

				"\nDelaware = DE; District of Colombia = DC;"+

				"\nFlorida = FL; Georgia = GA;"+

				"\nHawaii = HI; Idaho = ID; Illinois = IL; Indiana = IN; Iowa = IA;"+

				"\nKansas = KS; Kentucky = KY; Lousiana = LA;"+

				"\nMaine = ME; Maryland = MD; Massachusetts = MA; Michigan = MI;\nMinnesota = MN; Mississippi = MS; Missouri = MO; Montana = MT;"+

				"\nNebraska = NE; Nevada = NV; New Hampshire = NH; New Jersey = NJ\nNew Mexico = NM; New York = NY; North Carolina = NC; North Dakota = ND;"+

				"\nOhio = OH; Oklahoma = OK; Oregon = OR; "+

				"\nPennsylvania = PA; Rhode Island = RI;" +

				"\nSouth Carolina = SC; South Dakota = SD;"+

				"\nTennessee = TN; Texas = TX; Utah = UT;"+

				"\nVermont = VT; Virginia = VA;"+

				"\nWashington = WA; West Virginia = WV; Wisconsin = WI; Wyoming = WY;";

var glsProvs  = "\nAlberta = AB;\nBritish Columbia = BC;\nManitoba = MB;\nNew Brunswick = NB;\nNewfoundland = NF;"+

                "\nNorthwest Territories and Nunavut = NT;\nNova Scotia = NS;"+

				"\nOntario=ON;\nPrince Edward Island = PE;\nQuebec =QC;\nSaskatchewan = SK;\nYukon = YK;";

var glsMonths = new Array("January","February","March","April","May","June","July","August","September","October","November","December");

var glsDays = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

function isEmpty(s){

   return ((s == null) || (s.length == 0))?true:false;

}

function isWhitespace(s){

        return s.match(/^\s*$/)?true:false;

}

function isLetter (c){

        return c.match(/^[a-z]$/i)?c:false;

}

function isDigit (c){

        return c.match(/^\d$/)?c:false;

}

function isLetterOrDigit (c){

        return c.match(/^([a-z]|\d)$/i)?c:false;

}

function isAlphabetic (s){

        return s.match(/^[a-z]+$/gi)?s:false;

}

function isNumeric(s){

        return s.match(/^\d+$/)?s:false;

}

function isAlphaNumeric (s){

        return s.match(/^[a-z0-9]+$/gi)?s:false;

}

function isInt (s){

   return s.toString().match(/^(\+|\-)?\d+$/)?s:false;

}

function isPosInt (s){

 return isInt(s)?((parseInt(s,10) >= 0)?s:false):false;

}

function isNegInt (s){

 return isInt(s)?((parseInt(s,10) < 0)?s:false):false;

}

function isFloat (s){

        return s.toString().match(/^[\+|-]?\d*\.?\d+$/)?s:false;

}

function isPosFloat (s){

  return isFloat(s)?((parseFloat(s,10) >= 0)?s:false):false;

}

function isNegFloat (s){

  return isFloat(s)?((parseFloat(s,10) < 0)?s:false):false;

}

function isIntInRange (s, imin, imax){

    var testStr = s.toString();

    if (!isInt(testStr)) return false;

        var num = parseInt(testStr,10);

        return ((num >= imin) && (num <= imax))?num:false;

}

function isSSN(s){

        var SSNpattern = /^(\d{3})(\d{2})(\d{4})$/;

        var SSNdelim = /[\-\s]/gi;

        temp = s.toString().replace(SSNdelim, "");

		if (isAlphabetic(temp))

			return false;

		if(temp.match(SSNpattern)){

			part1 = parseInt(RegExp.$1, 10);

			part2 = parseInt(RegExp.$2, 10);

			part3 = parseInt(RegExp.$3, 10);

			return ( part1 !=0 && part1 < 800 && part2!=0 && part3!=0)?temp.replace(SSNpattern, "$1\-$2\-$3"):false;

		}

}

function isSIN(s){

        var SINpattern = /^(\d{3})(\d{3})(\d{3})$/;

        var check_pattern = /^(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)$/;

        var SINdelim = /[\-\s]/gi;

        temp = s.toString().replace(SINdelim, "");

        if( temp.match(check_pattern)){

            chsum = 0;

            for (i=1; i<10; i++){

               if(i%2)

                   isum =parseInt(eval('RegExp.$'+i), 10);

               else

                   isum =parseInt((eval('RegExp.$'+i)), 10) *2;

               if (isum >9) chsum+=Math.floor(isum/10) +isum%10;

               else chsum+=isum;

            }

            return (chsum%10 == 0)? temp.replace(SINpattern, "$1\-$2\-$3"):false;

        }

        return false;

}

function isPhoneNumber(s){

        var phoneNumDelim=/[()\-\s]/gi;

        var phoneNumPattern = /^(\d{3})(\d{3})(\d{4})$/;

        temp = s.toString().replace(phoneNumDelim, "");

        return temp.match(phoneNumPattern)?temp.replace(phoneNumPattern, "($1)$2\-$3"):false;

}

function isWorldPhoneNumber(s){

        var WphoneNumDelim=/[()\-\s]/gi ;

        var WphoneNumPattern =/^(\+?\d{3})(\d{3})(\d*)$/;

        temp = s.toString().replace(WphoneNumDelim, "");

        return temp.match(WphoneNumPattern)?s.replace(WphoneNumPattern, "$1$2$3"):false;

}

function isZipCd(s){

        var ZipDelim = /[()\-\s]/gi;;

        var ZIP1=/^(\d{5})$/;

        var ZIP2=/^(\d{5})(\d{4})$/;



        temp = s.toString().replace(ZipDelim, "");

        if(temp.match(ZIP2))

                return temp.replace(ZIP2, "$1\-$2");

        else if (temp.match(ZIP1))

                return temp;

        else return false;

}

function isCanPostCd(s){

	    var canPostPattern = /^[a-ceghj-npr-tvxy]\d[a-ceghj-npr-tv-z]\s\d[a-ceghj-npr-tv-z]\d$/i

        var testStr = s.toString();

        return testStr.match(canPostPattern)?s.toUpperCase():false;

}

function isStateCd(s){

        var USStatePattern = /^(AL|AK|AS|AZ|AR|CA|CO|CT|DE|DC|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY)$/

        var testStr = s.toString().toUpperCase();

        return testStr.match(USStatePattern)?testStr:false;

}

function isProvCd(s){

        var CanCdsPattern = /^(AB|BC|MB|NB|NF|NT|NS|ON|PE|QC|SK|YK)$/;

        var s = s.toUpperCase();

        return s.match(CanCdsPattern)?s:false;

}

function isEmail(s){

	var EmailPatrn =  /\b^(\w+)(\.?\-?\w+)*@{1}(\w+)(\.?\-?\w+)*(\.aero|\.biz|\.com|\.coop|\.edu|\.gov|\.info|\.int|\.mil|\.museum|.\name|\.net|\.org|.\pro|\.[A-Za-z]{2})$\b/gi;

	return s.match(EmailPatrn)?s:false;

}

function isMoney(number){

	var number= "" + number;

	

	var moneyPatrnPos=/^\d*\.?\d{0,2}$/;	//jarqu00

	var moneyPatrnNeg=/^\-\d*.?\d{0,2}$/;	//jarqu00

	number = stripCharsInBag(number, "$,")

	if(isNegInt(number) || isNegFloat(number))

		return (number.match(moneyPatrnNeg))?formatDollar(number):false;	//jarqu00

	else

		return (number.match(moneyPatrnPos))?formatDollar(number):false;	//jarqu00

		

	//return (number.match(moneyPatrn))?formatDollar(number):false;

}



function isMonthLength(mm,dd,yyyy,alerts) {

         var months = new Array("","January","February","March","April","May","June","July","August","September","October","November","December");

         if ((mm == 4 || mm == 6 || mm == 9 || mm == 11) && dd > 30) {

		 	if(alerts) alert(months[mm] + " has only 30 days.");

             return false ;

         }

         else if(mm==2){

                 return isLeapMonth(dd,yyyy,alerts);

         }

         else if (dd > 31) {

		 	if(alerts)

                 alert(months[mm] + " has only 31 days.");

                 return false ;

         }

         return true ;

}

function isLeapMonth(dd,yyyy,alerts) {

	// if !(yyyy % n) means if !(non-zero)

        if ( (!(yyyy % 4) && yyyy % 100 || !(yyyy % 400)) && dd > 29) {

			if(alerts)

                alert("February of " + yyyy + " has only 29 days.");

                return false;

        }

        else if ( yyyy%4 && dd > 28) {

			if(alerts)

                alert("February of " + yyyy + " has only 28 days.");

                return false;

        }

        return true ;

}

function isDate(gField,minYearOffset,maxYearOffset,minDaysOffset,maxDaysOffset,alerts) {

    var inputStr = gField.value;

    var datePattern = /^(\d\/|\d\d\/?|\d\d-?|\d-)(\d\/|\d\d\/?|\d\d-?|\d-)(\d{1}|\d{4}|\d{2})$/;

    var yearBot = 70;

    var yearTop = 29;



	inputStr = trim(inputStr);

   if(!inputStr.match(datePattern)){

  	if(alerts){

          alert("The date entry is not in an acceptable format.\n\nYou can enter dates in the following formats: mmddyyyy, mm/dd/yyyy, or mm-dd-yyyy.");

          gField.focus();

	}

    return false ;

  }

  else {

    var mm = RegExp.$1;

    var dd = RegExp.$2;

    var yy = RegExp.$3;



  	if( (mm+dd+yy).length == 6 && (mm==11 || mm==12)){

		if(alerts){

	 	    alert("The date you entered is ambiguous.\n\nPlease enter 2 digit month, 2 digit date and 4 digit year");

	    	gField.focus();

		}

		return false;

 	}

    var mm =parseInt(mm.replace(/\/|\-/, ""), 10);

    var dd =parseInt(dd.replace(/\/|\-/, ""), 10);

    var yy =parseInt(yy, 10);

  }

  if (mm < 1 || mm > 12) {

  	if(alerts){

	     alert("Months must be entered between the range of 01 (January) and 12 (December).");

	     gField.focus();

	}

	return false;

  }

  if (dd < 1 || dd > 31) {

  	if(alerts){

	     alert("Days must be entered between the range of 01 and a maximum of 31 (depending on the month and year).");

	     gField.focus();

	}

	return false;

  }

  var today = new Date();

  var todayYear = today.getFullYear();



  if (yy < 100) {

    minWindow = todayYear - yearBot;

    maxWindow = todayYear + yearTop;

    mincc = Math.floor(minWindow/100);

    minyy = minWindow%100;

    maxcc = Math.floor(maxWindow/100);

    if (yy >= minyy) yyyy = yy + mincc * 100;

    else yyyy =yy+ maxcc * 100;

  }

  else

	yyyy = yy;



   if (minYearOffset || minDaysOffset) {

       var testDate = new Date(mm + "/" + dd + "/" + yyyy);

	   testTime = testDate.getTime();

	   var minOffsetTime = 0;

	   var maxOffsetTime = 0;

	   minYearLmt = todayYear;

	   maxYearLmt = todayYear;



	   if(minDaysOffset!= "undefined"){

	   		minOffsetTime += minDaysOffset*24*60*60*1000;

	   		maxOffsetTime += maxDaysOffset*24*60*60*1000;

	   }

	   if(minYearOffset!=  "undefined"){

	   		minYearLmt += minYearOffset;

	   		maxYearLmt += maxYearOffset;

	   }

	   if( minOffsetTime || maxOffsetTime){

		   minDaysLmt = today.getTime() + minOffsetTime;

		   minDateLmt = new Date(minDaysLmt);

	   	   maxDaysLmt = today.getTime() + maxOffsetTime;

		   maxDateLmt = new Date(maxDaysLmt);

	   }

	   else{

	   		minDateLmt = new Date("01/01/"+ todayYear)

			maxDateLmt = new Date("12/31/"+ todayYear)

	   }

	   minDateLmt = new Date(minDateLmt.getMonth()+1+"/"+ minDateLmt.getDate() + "/" + minYearLmt);

   	   sminLmt = minDateLmt.getMonth()+1+"/"+ minDateLmt.getDate() + "/"+ minDateLmt.getFullYear();

	   maxDateLmt = new Date (maxDateLmt.getMonth()+1+"/"+ maxDateLmt.getDate() + "/"+ maxYearLmt);

	   smaxLmt = maxDateLmt.getMonth()+1+"/"+ maxDateLmt.getDate() + "/"+ maxDateLmt.getFullYear();



      if (testTime < minDateLmt.getTime() || testTime > maxDateLmt.getTime()) {

		  	if(alerts){

    	      alert("The range for this entry is between " + sminLmt + " and " + smaxLmt)

              gField.focus();

			}

          	return false;

      }

   }

   if (!isMonthLength(mm,dd,yyyy,alerts)) {

         gField.focus();

         return false;

   }

   if(mm < 10) mm = "0" + mm;

   if(dd < 10) dd = "0" + dd;

   gField.value = mm + "/" + dd + "/" + yyyy;

   return true;

}

function isTextAreaInLimit(oField,iMaxLen) {

 var iTextLen = oField.value.length;

 if (iTextLen > iMaxLen) 	return false;

 else return true;

}

function doCheck(objField,funcName,strAlert, emptyOK){

        var strToChk = objField.value.toString();

        if (isWhitespace(strToChk))

                return (!emptyOK)?false:strToChk;

		strToChk = trim(strToChk);

		temp = eval(funcName + "(\"" + strToChk + "\")")

        if (!temp){

                alert(strAlert);

                objField.focus();

                return false;

        }

		else{

                objField.value=temp;

                 return true;

 		}

 }

function checkAlphabetic(objField, emptyOK){

        var alertStr = "You must enter alphabetic characters only!";

        return doCheck(objField, "isAlphabetic", alertStr,emptyOK);

}

function checkNumeric(objField, emptyOK){

        var alertStr = "You must enter numeric characters only!"

        return doCheck(objField, "isNumeric",  alertStr, emptyOK);

}

function checkAlphaNumeric(objField, emptyOK){

        var alertStr = "You must enter numeric characters only!"

        return doCheck(objField, "isAlphaNumeric",  alertStr, emptyOK);

}

function checkTextAreaLimit(oField,iMaxLen) {

	if( !isTextAreaInLimit(oField,iMaxLen)){

		oField.focus();

		var bTruncate = confirm ("The maximum characters for this\ntext box is " + iMaxLen + " characters.\nThe rest will be truncated.");

	  	if (bTruncate)

		   oField.value = oField.value.substr(0,iMaxLen);

	  	return false;

	}

    return true;

}

function checkSSN(objField, emptyOK){

        var alertStr = glsInvalid+"Social Security Number\n"+glsPrompt+ "a 9 digit U.S. SSN ( i.e. 123456789)."

         return doCheck(objField, "isSSN", alertStr, emptyOK);

}

function checkSIN(objField, emptyOK){

        var alertStr = glsInvalid+"Canadian Social Security Id\n"+glsPrompt+ "a 9 digit SIN (i.e 123456789).";

        return doCheck(objField, "isSIN", alertStr, emptyOK);

}

function checkPhoneNumber(objField, emptyOK){

        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "a 10 digit phone number.";

        return doCheck(objField, "isPhoneNumber", alertStr, emptyOK);

}

function checkWorldPhoneNumber(objField, emptyOK){

        var alertStr = glsInvalid+"Phone Number\n"+glsPrompt+ "an international phone number.";

        return doCheck(objField, "isWorldPhoneNumber", alertStr, emptyOK);

}

function checkZipCd(objField, emptyOK){

        var alertStr = glsInvalid+"ZIP Code\n"+glsPrompt+ "a 5 or 9 digit U.S. ZIP Code (i.e. 94043).";

        return doCheck(objField, "isZipCd", alertStr, emptyOK);

}

function checkCanPostCd(objField, emptyOK){

        var alertStr = glsInvalid+"Canadian Postal Code\n"+glsPrompt+ "a 7 characters Postal Code (like K3L 4M2)";

        return doCheck(objField, "isCanPostCd", alertStr, emptyOK);

}

function checkPostalCd(objField, emptyOK){

  var alertStr = glsInvalid+"US or Canadian Postal Code\n"+glsPrompt+ "a 5 or 9 digits ZIP or 7 characters Canadian Postal code.";

  var testStr = objField.value.toString();

  if (isWhitespace(testStr))

         return (!emptyOK)?false:emptyOK;

	testStr = trim(testStr);

	if(	((str = isZipCd(testStr))!=false) || ((str = isCanPostCd(testStr))!=false)){

	  objField.value=str;

      return true;

	}

	else{

	 alert(alertStr);

	 objField.focus();

	 return false;

	}

}



function checkStateCd(objField, emptyOK){

        var alertStr = glsInvalid+"State Code\n"+glsPrompt+ " a 2 character code (like CA)." + glsStates;

        return doCheck(objField, "isStateCd", alertStr, emptyOK);

}

function checkProvCd(objField, emptyOK){

        var alertStr = glsInvalid+"Canadian Province\n"+glsPrompt+ "a 2 character code (like YK)." +glsProvs;

        return doCheck(objField, "isProvCd", alertStr, emptyOK);

}

function checkStateProvCd(objField, emptyOK){

  var alertStr = glsInvalid+"US State or Canadian Province\n"+glsPrompt+ "a 2 character code (like AB).\n\n" +

  					glsStates + "\n\n" + glsProvs;

  var testStr = objField.value.toString();



  if (isWhitespace(testStr))

         return (!emptyOK)?false:emptyOK;

  testStr = trim(testStr);

	if(	((str = isStateCd(testStr))!=false) || ((str = isProvCd(testStr))!=false)){

	  objField.value=str;

      return true;

	}

	else{

	 alert(alertStr);

	 objField.focus();

	 return false;

	}

}

function checkEmail(objField, emptyOK) {

        var alertStr = glsInvalid+"Email address\n"+glsPrompt+ "a valid email address (like name@company.com).";

        return  doCheck(objField, "isEmail", alertStr, emptyOK);

}

function checkMoney(objField, emptyOK) {

    var alertStr = glsInvalid+"number.\n"+glsPrompt+ "a valid amount in dollars (e.i. 245 or 113.26 ).";

   return doCheck(objField, "isMoney", alertStr, emptyOK);

}

function checkDate(objField,emptyOK,minYearOffset,maxYearOffset,minDaysOffset,maxDaysOffset) {

	var testStr = objField.value.toString();

	if (isWhitespace(testStr))

		return (!emptyOK)?false:emptyOK;

	return	isDate(objField, minYearOffset, maxYearOffset, minDaysOffset, maxDaysOffset,true);

}

function checkReqTextFields(form,arrNmeMsg){

		return checkForm(form,  "text", arrNmeMsg);

}

function checkReqFields(form, arrNmeMsg){

		return checkForm(form,"req",arrNmeMsg);

}

function checkForm(form,typeSpec,arrNmeMsg){

        var alertStr=glsPrefix;

        var intMissed = 0;

        var radioName = "";

        var args = 0;



  if (arrNmeMsg) args = 1;

	for(i=0; i<form.elements.length; i++){

		with(form.elements[i]){

			if(	(typeSpec =="req" && name.substring(0,4) == "req_" ) || typeSpec =="all" || typeSpec == "text"){

				j = radioLength = 0;

				msg = "";

				if(type == "radio" && typeSpec!="text"){

				   	if (radioName.indexOf(name)==-1){

					   radioName += name;

	    	           var name = name;

	   	    	       var radioLength = eval('form.'+name +'.length');

	       	    	   for(j=0; j < radioLength; j++){

	           	    	    if(eval('form.'+name+'[j].checked')){

	                                   break;

	               	    	}

	              		}

					}

				}

				if( (j == radioLength && radioLength != 0) ||

					((type == "text" || type == "textarea" || type == "password") && isWhitespace(value)) ||

					(type=="select-one" && (!selectedIndex||(selectedIndex && !options[selectedIndex].value)) && typeSpec != "text") ||

					(type=="select-multiple" && (selectedIndex < 0 || !options[selectedIndex].value)&& typeSpec != "text")){



					 if(args) msg = eval("arrNmeMsg['" + name + "']");

			         if(typeSpec =="req"){

						  alertStr+=(!msg.length)?"\n" + name.substring(4):"\n" + msg;

					}

			   		 else

		  			   alertStr+=(!msg)?"\n" + name:"\n" + msg;

		          	 if(!intMissed){

			         	intMissed=1;

						if(type == "radio")

		     				eval('form.'+name+'[0].focus()');

						else focus();

		        	 }

			         intMissed++;

				}

	        }

		}

	}

	if(intMissed) {

    	 (intMissed == 2)?alert(alertStr+="\n" + glsSuffix):alert(alertStr+="\n" + glsSuffixPlu);

   		 return false;

  	}

	else

	   return true;

}

function format (s){

    var arg;

    var sPos = 0;

    var resultString = "";



    for (var i = 1; i < format.arguments.length; i++) {

       if (i % 2 == 1) resultString += format.arguments[i];

       else {

           resultString += s.substring(sPos, sPos + format.arguments[i]);

           sPos += format.arguments[i];

       }

    }

    return resultString;

}

function formatDate(objDate){

		var curdate = objDate;

		var temp_year = curdate.getFullYear();

		var arrDate = new Array();

		

		//added by jarqu00

		if(temp_year < 2000) {

			curdate.setYear(curdate.getFullYear()+100);

			temp_year=curdate.getFullYear();

		}

		//end add

		arrDate["day"]=glsDays[curdate.getDay()];

		arrDate["month"]=glsMonths[curdate.getMonth()];

		arrDate["date"]= curdate.getDate();

		arrDate["year"]=temp_year;



		return arrDate;

}

	function formatShortDate(objDate){

			var month = objDate.getMonth() +1;

			var date = objDate.getDate();



			if(objDate.getFullYear() < 2000)

				objDate.setYear(objDate.getFullYear()+100);

			

			if( month <10) month = "0" + month;

			if(date < 10) date = "0" + date;

			return  month +"/" + date + "/" + objDate.getFullYear();

	}

function formatInt(n){

	//var i=0;

	res ="";

	n=stripCharsNotInBag (n, "1234567890")	//added by jarqu00

	n = "" + n;

	//added by jarqu00, this will strip all leading zeros

	for(x=0; n.substr(x,1)=="0";x++)

		;

	//checked if x has been incremented, if not then no need to substr

	if(x > 0)

		n=n.substr(x,n.length-1);

	//end add

	for( i = n.length; i > 3; i-=3){

		res = "," + n.substr(i-3, 3) + res;

	}

	return n.substring(0,i) + res;

}

function formatDollar(s){

		var temp=("" + s).split(".");

        var cents = ".";

		

	    (!isEmpty(temp[0]))?dolr= formatInt(temp[0]):dolr="0";

		(isEmpty(dolr))?dolr="0":"";

		

        if(temp[1]){

            if(temp[1].length == 1)  cents+=temp[1] + "0";

			else if(temp[1].length == 2)  cents+=temp[1];

            else if(temp[1].length > 2){

	            str_cents = "" + Math.round(temp[1]/ Math.pow(10, temp[1].length-2 ));

				if(temp[1][0] == "0" && str_cents < 10) cents+="0";

			 	cents +=str_cents.substring(0,2);

            }

        }

        else

           cents += "00";

		//changed by Jaime to test for negative float.

        return  (isNegFloat(s))?("-"+dolr + cents):(dolr + cents);

}

function formatPenny(s){

		s=''+s;

        var dolr= formatInt(s.substring(0,s.length-2));

		var cents = '.'+s.substring(s.length-2, s.length);

        return (dolr + cents);

}

function formatPercent(data, numDec){

    var temp=("" + data).split(".");

    var fraction = ".";

    var done = false;

	

    (!isEmpty(temp[0]))?whole= formatInt(temp[0]):whole="0";

	//added by jarqu00

	if(isEmpty(numDec))

		numDec = 2;

	//end add

	

    if(temp[1]){

        len = temp[1].length;

        if(len < numDec){

              fraction += temp[1];

              for(i=len; i<numDec; i++)

                    fraction+="0";

        }

        else if(len == numDec)

               fraction+= temp[1];

        else{

           str_fraction = "" + Math.round(temp[1]/Math.pow(10, temp[1].length-numDec));



           for(i=0; i<numDec;i++){

                 if(temp[1][i] == "0" && fraction.length == i && done == true){

                     fraction+="0";

                     done =true;

                 }

                else done = false;

           }

           if(str_fraction != "0")

             fraction += str_fraction.substring(0, numDec);

       }

   }

   else

       for(i=0; i<numDec;i++) fraction+="0";



       return (whole + fraction + " %");

}

function stripCharsInBag (s, bag){

    var i;

    var returnString = "";

    for (i = 0; i < s.length; i++) {

        var c = s.charAt(i);

        if (bag.indexOf(c) == -1) returnString += c;

    }

    return returnString;

}

function stripCharsNotInBag (s, bag){

   var i;

   var returnString = "";

    for (i = 0; i < s.length; i++)  {

        var c = s.charAt(i);

        if (bag.indexOf(c) != -1) returnString += c;

    }

    return returnString;

}

function strReplace(s, charOut, charIn){

	patt = new RegExp(charOut, "gi");

	return s.replace(patt, charIn);

}

function trimAll (s){

        return trim(s, "all");

}

function trimLead (s) {

        return trim(s,"lead");

}

function trimTrail(s) {

        return trim(s,"trail");

}

function trim(s, trimSpec){

       var patt_all = /\s*/gi;

        var patt_lead = /^\s+/i;

        var patt_trail = /\s+$/i;



       if(trimSpec == "all")

                return s.replace(patt_all, "");

        if(trimSpec == "lead")

                return s.replace(patt_lead, "");

        if(trimSpec == "trail")

                return s.replace(patt_trail, "");



        s= s.replace(patt_lead, "");

        return s.replace(patt_trail, "");

}

function stripInitialZeros (s) {

		var pattern=/^(0+)(.*)$/i

        return s.replace(pattern, "$2");

}

function displayDate(){

	curdate = new Date();

	var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");

	var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");



	date = months[curdate.getMonth()] + " " + curdate.getDate() + ", " + curdate.getFullYear();

	return(date);

}

function getRadioButtonValue (radio){

   for (var i = 0; i < radio.length; i++) {

      if (radio[i].checked)

		return radio[i].value;

    }

   return false;

}

