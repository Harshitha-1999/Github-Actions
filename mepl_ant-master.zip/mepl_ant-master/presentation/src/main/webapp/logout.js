const CONTEXT_PATH = "/mepl"
// Function to logout a user
function logout() {
    let cookies = document.cookie ? document.cookie.split(";") : null;
    let cookie = cookies.filter((cookie) => cookie.includes("accessToken"));
    let cookieTwo = cookies.filter((cookie) => cookie.includes("idToken"));

    sessionStorage.clear();
    localStorage.clear();
    document.cookie = cookie + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path="+CONTEXT_PATH;
    document.cookie = cookieTwo + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path="+CONTEXT_PATH;
    //    const redirectUrl = "http://localhost:8080/mepl/";

    const strHostNme = location.host;
    const protocol = location.protocol;

    const redirectUrl = protocol + "//" + strHostNme + "/mepl";
    window.location.replace("https://login.microsoftonline.com/common/oauth2/v2.0/logout?post_logout_redirect_uri=" + redirectUrl)
}