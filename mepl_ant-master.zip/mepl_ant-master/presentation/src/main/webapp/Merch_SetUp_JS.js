var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1;//January is 0!
var yyyy = today.getFullYear();
if(dd<10){dd='0'+dd}
if(mm<10){mm='0'+mm}
onload = function(){
document.myform.Date_Requested.value = mm+'/'+dd+'/'+yyyy;
}

//format requestor phone number
function mask1(f){
var temp1; 
temp1 = document.myform.req_Requestor_PhoneNumber.value;
temp1 =  temp1.replace(/[^a-zA-Z 0-9]+/g,'');
document.myform.req_Requestor_PhoneNumber.value = temp1;
tel=''; 
var val =f.value.split(''); 
for(var i=0;i<val.length;i++){ 
if(i==2){val[i]=val[i]+'-'}
if(i==5){val[i]=val[i]+'-'} 
if(i==10){val[i]=''}
if(i==11){val[i]=''}
tel=tel+val[i] 
} 
f.value=tel; 
} 

function price2(){ 
	for (i=1; i < 14; i++){
	if(document.getElementById(i).checked == true && document.getElementById("division").checked == true){
		if(document.getElementById('Price' + i).value != ""){
		var Price = (document.getElementById('Price' + i).value * 1)
		document.getElementById('Price' + i).value = Price.toFixed(2);
		}
	}
	}
}

function popup(mylink, windowname)
{
if (! window.focus)return true;
var href;
if (typeof(mylink) == 'string')
   href=mylink;
else
   href=mylink.href;
window.open(href, windowname, 'width=500,height=200');
return false;
}


//add decimal for price
function price(){
	if (document.getElementById("Not_Req").checked == true && document.getElementById("division_no").checked == true){
	var Price = (document.myform.PLU_Value.value * 1)
	document.myform.PLU_Value.value = Price.toFixed(2);
	}
}

function runOnSubmit(){

var boolSubmit = true;

//check if user id is 7 characters
if(document.myform.req_Requestor_UserId.value.length != 7) {

		alert("You did not enter a valid User ID. ( 7 characters )");
		boolSubmit = false;

	}
	
//check if PLU Start date has passed
	if (document.myform.req_PLU_Start.value.length == 10){
		var date1 = document.myform.req_PLU_Start.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 <= date2){
			alert ("PLU Start Date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	//check if PLU End date has passed		
	if (document.myform.req_PLU_End.value.length == 10){
		var date1 = document.myform.req_PLU_End.value;
		var date2 = document.myform.req_PLU_Start.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 <= date2){
			alert ("PLU End Date must be after start date");
			  		boolSubmit = false;		
		}
	}
	

//check requestor phone
if(document.myform.req_Requestor_PhoneNumber.value.length != 12) {

		alert("You did not enter a 10 digit phone number");
		boolSubmit = false;

	}

//check plu value over 100
if (document.getElementById("Not_Req").checked == true && document.getElementById("division_no").checked == true){
	if(document.myform.PLU_Value.value > 99.99) {
		alert("PLU Value cannot exceed $100");
		boolSubmit = false;
	}

}

//check if they selected a division		
		if(document.getElementById("1").checked == false && document.getElementById("2").checked == false && document.getElementById("3").checked == false && document.getElementById("4").checked == false && document.getElementById("5").checked == false && document.getElementById("6").checked == false && document.getElementById("7").checked == false && document.getElementById("8").checked == false && document.getElementById("9").checked == false && document.getElementById("10").checked == false && document.getElementById("11").checked == false && document.getElementById("12").checked == false && document.getElementById("13").checked == false){

		alert("You did not select a Division");
  		boolSubmit = false;		
		}

//check if non cash account is 3 digits
if (document.getElementById("NCA_Yes").checked == true){
for (var i=1; i < 14; i++){
if (document.getElementById(i).value.length == 2) document.getElementById(i).value = "0" + document.getElementById(i).value
if (document.getElementById(i).value.length == 1) document.getElementById(i).value = "00" + document.getElementById(i).value
}
}
	

//check if a valid email address entered for alternate contact	
 var testresults
 var str=document.myform.Requestor_AlternateEmail.value
 var filter=/^.+@.+\..{2,3}$/

if (document.myform.Requestor_AlternateEmail.value != ""){
 if (filter.test(str))
    testresults=true;
 else {
    alert("You did not enter a valid email address for an alternate contact")
    testresults=false;
	boolSubmit = false;
}
}

if (document.getElementById("Not_Req").checked == true && document.getElementById("division_no").checked == true && document.myform.PLU_Value.value == ""){
alert ("You must enter a PLU Value");
boolSubmit = false;
}




	if(boolSubmit == true){
		document.myform.sendSubject.value = "Merch PLU Set Up Request: " + document.myform.req_PLU_Description.value;

		document.myform.sendCc.value = document.myform.Requestor_AlternateEmail.value;

		return true;
	}

	else

		return false;


}

function addQuestionBox() {

	var element = document.getElementById('price');
	
	if (document.getElementById("Not_Req").checked == true && document.getElementById("division_no").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="PLU_Value" size="5" maxlength="5" onchange="price();"><br>';
	}
	
	else{

	element.innerHTML = '';
	}

}

// jteta01(3/2/2017) - Add intermountain division and rearranged divisions
// ecome03(3/15/2022) - Remove Houston and Eastern, Add Haggen,Jewel,Shaws,Mid-Atlantic divisions and rearranged divisions
function addAll() {

	var element = document.getElementById('AllDiv');
	
	if (document.getElementById("1").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price1" id="Price1" size="5" onchange="price2();"><br>';
	document.getElementById('Den').innerHTML = '';
	document.getElementById('SW').innerHTML = '';
	document.getElementById('Por').innerHTML = '';
	document.getElementById('Srn').innerHTML = '';
	document.getElementById('Hag').innerHTML = '';
	document.getElementById('NoC').innerHTML = '';
	document.getElementById('Sea').innerHTML = '';
	document.getElementById('SoC').innerHTML = '';
	document.getElementById('Imt').innerHTML = '';
	document.getElementById('Jew').innerHTML = '';
	document.getElementById('Sha').innerHTML = '';
	document.getElementById('Mid').innerHTML = '';
	}
	
	else{

	document.getElementById('AllDiv').innerHTML = '';
	}
	
	if (document.getElementById("1").checked == true){
	for (var i=2; i < 14; i++){
	document.getElementById(i).disabled = true;
	document.getElementById(i).checked = false
	}
	}

	if (document.getElementById("1").checked == false){
	for (var i=2; i < 14; i++){
	document.getElementById(i).disabled = false;
	}
}


}

function addDen() {

	var element = document.getElementById('Den');
	
	if (document.getElementById("2").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price2" id="Price2" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addSW() {

	var element = document.getElementById('SW');
	
	if (document.getElementById("3").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price3" id="Price3" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addPor() {

	var element = document.getElementById('Por');
	
	if (document.getElementById("4").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price4" id="Price4" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addSrn() {

	var element = document.getElementById('Srn');
	
	if (document.getElementById("5").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price5" id="Price5" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addHag() {

	var element = document.getElementById('Hag');
	
	if (document.getElementById("6").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price6" id="Price6" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addNoC() {

	var element = document.getElementById('NoC');
	
	if (document.getElementById("7").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price7" id="Price7" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addSea() {

	var element = document.getElementById('Sea');
	
	if (document.getElementById("8").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price8" id="Price8" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addSoC() {

	var element = document.getElementById('SoC');
	
	if (document.getElementById("9").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price9" id="Price9" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addImt() {

	var element = document.getElementById('Imt');
	
	if (document.getElementById("10").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price10" id="Price10" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addJew() {

	var element = document.getElementById('Jew');
	
	if (document.getElementById("11").checked == true && document.getElementById("division").checked == true){
		
	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price11" id="Price10" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addSha() {

	var element = document.getElementById('Sha');
	
	if (document.getElementById("12").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price12" id="Price10" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}

function addMid() {

	var element = document.getElementById('Mid');
	
	if (document.getElementById("13").checked == true && document.getElementById("division").checked == true){

	element.innerHTML = 'PLU Value: $ <input type="text" name="req_All_Price13" id="Price11" size="5" onchange="price2();">';
	}
	
	else{

	element.innerHTML = '';
	}

}


// maxlength for comments
function ismaxlength(obj){
var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
if (obj.getAttribute && obj.value.length>mlength)
obj.value=obj.value.substring(0,mlength)
}


function toggleMe(a){
  var e=document.getElementById(a);
  if(!e)return true;
  if(e.style.display=="none"){
    e.style.display="block"
  } else {
    e.style.display="none"
  }
  return true;
}



