<!DOCTYPE HTML>  
<html>
<head></head>
<body>
<?php
if($_POST){
    $name = $_POST['form_name'];
    $email = $_POST['form_email'];
    $message = $_POST['form_msg'];

//send email
    mail("edmun.valenciano@safeway.com", "51 Deep comment from" .$email, $message);
}
?>
</body>
</html>
