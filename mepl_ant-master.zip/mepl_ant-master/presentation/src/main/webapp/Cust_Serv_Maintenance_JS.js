var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1;//January is 0!
var yyyy = today.getFullYear();
if(dd<10){dd='0'+dd}
if(mm<10){mm='0'+mm}
onload = function(){
document.myform.Date_Requested.value = mm+'/'+dd+'/'+yyyy;
}

//format requestor phone number
function mask1(f){
var temp1; 
temp1 = document.myform.req_Requestor_PhoneNumber.value;
temp1 =  temp1.replace(/[^a-zA-Z 0-9]+/g,'');
document.myform.req_Requestor_PhoneNumber.value = temp1;
tel=''; 
var val =f.value.split(''); 
for(var i=0;i<val.length;i++){ 
if(i==2){val[i]=val[i]+'-'}
if(i==5){val[i]=val[i]+'-'} 
if(i==10){val[i]=''}
if(i==11){val[i]=''}
tel=tel+val[i] 
} 
f.value=tel; 
} 

//disable divisions if US is selected
function divisions(){
if (document.getElementById("1_Exp_Date").checked == true){
	for (var i=2; i < 14; i++){
	document.getElementById(i + '_Exp_Date').disabled = true;
	document.getElementById(i + '_Exp_Date').checked = false
	}
}

if (document.getElementById("1_Exp_Date").checked == false){
	for (var i=2; i < 14; i++){
	document.getElementById(i + '_Exp_Date').disabled = false;
	}
}

if (document.getElementById("price_1").checked == true){
	for (var i=2; i < 14; i++){
	document.getElementById('price_' + i).disabled = true;
	if (document.getElementById('price_' + i).checked == true){
		document.getElementById('price_' + i).checked = false
		toggleMe('para' + i)
	}
	}
}

if (document.getElementById("price_1").checked == false){
	for (var i=2; i < 14; i++){
	document.getElementById('price_' + i).disabled = false;
	}
}

if (document.getElementById("Div_1").checked == true){
	for (var i=2; i < 14; i++){
	document.getElementById('Div_' + i).disabled = true;
	document.getElementById('Div_' + i).checked = false
	}
}

if (document.getElementById("Div_1").checked == false){
	for (var i=2; i < 14; i++){
	document.getElementById('Div_' + i).disabled = false;
	}
}

if (document.getElementById("NCA_1").checked == true){
	for (var i=2; i < 14; i++){
	document.getElementById('NCA_' + i).disabled = true;
	document.getElementById('NCA_' + i).checked = false
	}
}

if (document.getElementById("NCA_1").checked == false){
	for (var i=2; i < 14; i++){
	document.getElementById('NCA_' + i).disabled = false;
	}
}
}

//add decimal to change price
function price(){ 
	for (i=1; i < 14; i++){
	if(document.getElementById('price_' + i).checked == true){
		var spot = (i + 13) * 1;
		if(document.getElementById('price_' + spot).value != ""){
		var Price = (document.getElementById('price_' + spot).value * 1)
		document.getElementById('price_' + spot).value = Price.toFixed(2);
		}
	}
	}
}

function runOnSubmit(){

var boolSubmit = true;

//check if user id is 7 characters
if(document.myform.req_Requestor_UserId.value.length != 7) {

		alert("You did not enter a valid User ID. ( 7 characters )");
		boolSubmit = false;

	}
	
//check requestor phone
if(document.myform.req_Requestor_PhoneNumber.value.length != 12) {

		alert("You did not enter a 10 digit phone number");
		boolSubmit = false;

	}
	
//check if CIC and PLU are numeric
if (document.myform.req_Existing_PLU_Number.value != parseInt(document.myform.req_Existing_PLU_Number.value)){
alert("You did not enter a valid existing PLU");
boolSubmit = false;
}

if (document.myform.Existing_CIC.value != ""){
if (document.myform.Existing_CIC.value != parseInt(document.myform.Existing_CIC.value)){
alert("You did not enter a valid existing CIC");
boolSubmit = false;
}
}

//check if they chose an item to change
if (document.getElementById("Expiration_Date").checked == false && document.getElementById("Change_Price").checked == false && document.getElementById("Description").checked == false && document.getElementById("Change_NCA").checked == false && document.getElementById("Add_Division").checked == false){
	alert ("You did not select an item to change");
	boolSubmit = false;
}
// check division and expire date entered and check expiration date
if (document.getElementById("Expiration_Date").checked == true){
	if (document.getElementById("1_Exp_Date").checked == false && document.getElementById("2_Exp_Date").checked == false && document.getElementById("3_Exp_Date").checked == false && document.getElementById("4_Exp_Date").checked == false && document.getElementById("5_Exp_Date").checked == false && document.getElementById("6_Exp_Date").checked == false && document.getElementById("7_Exp_Date").checked == false && document.getElementById("8_Exp_Date").checked == false && document.getElementById("9_Exp_Date").checked == false && document.getElementById("10_Exp_Date").checked == false && document.getElementById("11_Exp_Date").checked == false && document.getElementById("12_Exp_Date").checked == false && document.getElementById("13_Exp_Date").checked == false ){
	alert ("You did not select a division");
	boolSubmit = false;
	}
	if (document.myform.New_Exp_Date.value == ""){
	alert ("You did not enter a new expire date");
	boolSubmit = false;
	}
	
	if (document.myform.New_Exp_Date.value.length == 10){
		var date1 = document.myform.New_Exp_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("New expire date must be a future date");
			  		boolSubmit = false;		
		}
	}
}

//clear value if unchecked
if (document.getElementById("Expiration_Date").checked == false){
	document.getElementById("1_Exp_Date").value = "" 
	document.getElementById("2_Exp_Date").value = "" 
	document.getElementById("3_Exp_Date").value = "" 
	document.getElementById("4_Exp_Date").value = "" 
	document.getElementById("5_Exp_Date").value = "" 
	document.getElementById("6_Exp_Date").value = "" 
	document.getElementById("7_Exp_Date").value = "" 
	document.getElementById("8_Exp_Date").value = "" 
	document.getElementById("9_Exp_Date").value = "" 
	document.getElementById("10_Exp_Date").value = "" 
	document.getElementById("11_Exp_Date").value = ""
	document.getElementById("12_Exp_Date").value = ""
	document.getElementById("13_Exp_Date").value = ""	
	document.myform.New_Exp_Date.value = ""
}

//check division and price entered and check expiration dates
// jteta01(3/2/2017) - Add intermountain division and rearranged divisions
// ecome03(3/15/2022) - Remove Houston and Eastern, Add Haggen,Jewel,Shaws,Mid-Atlantic divisions and rearranged divisions
if (document.getElementById("Change_Price").checked == true){

	if (document.getElementById("price_1").checked == false && document.getElementById("price_2").checked == false && document.getElementById("price_3").checked == false && document.getElementById("price_4").checked == false && document.getElementById("price_5").checked == false && document.getElementById("price_6").checked == false && document.getElementById("price_7").checked == false && document.getElementById("price_8").checked == false && document.getElementById("price_9").checked == false && document.getElementById("price_10").checked == false && document.getElementById("price_11").checked == false && document.getElementById("price_12").checked == false && document.getElementById("price_13").checked == false ){
	alert ("You did not select a division");
	boolSubmit = false;
	}
	
	for (i=1; i < 14; i++){
	var spot = (i + 13) * 1;
	var spot2 = (i + 26) * 1;
	if(document.getElementById("price_" + i).checked == true){
		if(document.getElementById("price_" + spot).value == "" || document.getElementById("price_" + spot2).value == ""){
		alert ("You did not enter a new price or start date");
		boolSubmit = false;
		}
	}
	}
	
		if (document.myform.New_Exp_Date.value.length == 10){
		var date1 = document.myform.New_Exp_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("New expire date must be a future date");
			  		boolSubmit = false;		
		}
	}

	if (document.myform.USA_Start_Date.value.length == 10){
		var date1 = document.myform.USA_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Den_Start_Date.value.length == 10){
		var date1 = document.myform.Den_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.SW_Start_Date.value.length == 10){
		var date1 = document.myform.SW_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Por_Start_Date.value.length == 10){
		var date1 = document.myform.Por_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Srn_Start_Date.value.length == 10){
		var date1 = document.myform.Srn_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Hag_Start_Date.value.length == 10){
		var date1 = document.myform.Hag_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.NoC_Start_Date.value.length == 10){
		var date1 = document.myform.NoC_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Sea_Start_Date.value.length == 10){
		var date1 = document.myform.Sea_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.SoC_Start_Date.value.length == 10){
		var date1 = document.myform.SoC_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Imt_Start_Date.value.length == 10){
		var date1 = document.myform.Imt_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Jew_Start_Date.value.length == 10){
		var date1 = document.myform.Jew_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Sha_Start_Date.value.length == 10){
		var date1 = document.myform.Sha_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
	if (document.myform.Mid_Start_Date.value.length == 10){
		var date1 = document.myform.Mid_Start_Date.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 < date2){
			alert ("Effective start date must be a future date");
			  		boolSubmit = false;		
		}
	}

}
//clear values if unchecked
if (document.getElementById("Change_Price").checked == false){
	for (i=1; i < 14; i++){
		var spot = (i + 13) * 1;
		var spot2 = (i + 26) * 1;
		document.getElementById("price_" + i).value = ""
		document.getElementById("price_" + spot).value = ""
		document.getElementById("price_" + spot2).value = ""
	}
}

//check division and non cash account
if (document.getElementById("Add_Division").checked == true){

	if (document.getElementById("Div_1").checked == false && document.getElementById("Div_2").checked == false && document.getElementById("Div_3").checked == false && document.getElementById("Div_4").checked == false && document.getElementById("Div_5").checked == false && document.getElementById("Div_6").checked == false && document.getElementById("Div_7").checked == false && document.getElementById("Div_8").checked == false && document.getElementById("Div_9").checked == false && document.getElementById("Div_10").checked == false && document.getElementById("Div_11").checked == false && document.getElementById("Div_12").checked == false && document.getElementById("Div_13").checked == false ){
	alert ("You did not select a division");
	boolSubmit = false;
	}
	
	if (document.getElementById("New_NCA_Yes").checked == false && document.getElementById("New_NCA_No").checked == false){
	alert ("You did not answer if there is a Non-Cash Account # for at least one division");
	boolSubmit = false;
	
	}
	

}


//check division and non cash account
if (document.getElementById("Change_NCA").checked == true){

	if (document.getElementById("NCA_1").checked == false && document.getElementById("NCA_2").checked == false && document.getElementById("NCA_3").checked == false && document.getElementById("NCA_4").checked == false && document.getElementById("NCA_5").checked == false && document.getElementById("NCA_6").checked == false && document.getElementById("NCA_7").checked == false && document.getElementById("NCA_8").checked == false && document.getElementById("NCA_9").checked == false && document.getElementById("NCA_10").checked == false && document.getElementById("NCA_11").checked == false && document.getElementById("NCA_12").checked == false && document.getElementById("NCA_13").checked == false ){
	alert ("You did not select a division");
	boolSubmit = false;
	}
	
	if (document.getElementById("Change_NCA_Yes").checked == false && document.getElementById("Change_NCA_No").checked == false){
	alert ("You did not answer if there is a Non-Cash Account # for at least one division");
	boolSubmit = false;
	
	}

}

//check if non cash account is 3 digits
if (document.getElementById("New_NCA_Yes").checked == true){
	if (document.getElementById("New").value.length == 2) document.getElementById("New").value = "0" + document.getElementById("New").value
	if (document.getElementById("New").value.length == 1) document.getElementById("New").value = "00" + document.getElementById("New").value
}


if (document.getElementById("Change_NCA_Yes").checked == true){
	if (document.getElementById("Change").value.length == 2) document.getElementById("Change").value = "0" + document.getElementById("Change").value
	if (document.getElementById("Change").value.length == 1) document.getElementById("Change").value = "00" + document.getElementById("Change").value
}

//check non cash account is numerical

if (document.getElementById("New_NCA_Yes").checked == true){
	if (document.myform.NewNonCashAccount.value != ""){
		if (isNaN(document.myform.NewNonCashAccount.value)== true){
		alert("You did not enter a valid non cash account");
		boolSubmit = false;
		}
	}
}


if (document.getElementById("Change_NCA_Yes").checked == true){
	if (document.myform.ChangeNonCashAccount.value != ""){
		if (isNaN(document.myform.ChangeNonCashAccount.value)== true){
		alert("You did not enter a valid non cash account");
		boolSubmit = false;
		}
	}
}

//check if a valid email address entered for alternate contact	
 var testresults
 var str=document.myform.Requestor_AlternateEmail.value
 var filter=/^.+@.+\..{2,3}$/

if (document.myform.Requestor_AlternateEmail.value != ""){
 if (filter.test(str))
    testresults=true;
 else {
    alert("You did not enter a valid email address for an alternate contact")
    testresults=false;
	boolSubmit = false;
}
}



	if(boolSubmit == true){
		document.myform.sendSubject.value = "Customer Service PLU Maintenance Request: " + document.myform.req_Existing_PLU_Number.value + " " + document.myform.req_Existing_PLU_Description.value;

		document.myform.sendCc.value = document.myform.Requestor_AlternateEmail.value;

		return true;
	}

	else

		return false;


}


// maxlength for comments
function ismaxlength(obj){
var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
if (obj.getAttribute && obj.value.length>mlength)
obj.value=obj.value.substring(0,mlength)
}


function toggleMe(a){
  var e=document.getElementById(a);
  if(!e)return true;
  if(e.style.display=="none"){
    e.style.display="block"
  } else {
    e.style.display="none"
  }
  return true;
}


function NewDesc() {
	if (document.getElementById("Description").checked == true){
	document.getElementById('Desc').innerHTML = 'New PLU Description: <input type="text" name="req_New_PLU_Description" size="40" maxlength="120">';
	}
	if (document.getElementById("Description").checked == false){
		document.getElementById('Desc').innerHTML = '';
	}
}

function addNewNCA() {

	var element = document.getElementById('NewNCA');
	
	if (document.getElementById("New_NCA_Yes").checked == true){

	element.innerHTML = 'Non-Cash Account #, if applicable: <input type="text" name="NewNonCashAccount" id="New" size="5" maxlength="3">';
	}
	
	if (document.getElementById("New_NCA_Yes").checked == false){

	element.innerHTML = '';
	}

}

function addChangeNCA() {

	var element = document.getElementById('ChangeNCA');
	
	if (document.getElementById("Change_NCA_Yes").checked == true){

	element.innerHTML = 'Non-Cash Account #, if applicable: <input type="text" name="ChangeNonCashAccount" id="Change" size="5" maxlength="3">';
	}
	
	if (document.getElementById("Change_NCA_Yes").checked == false){

	element.innerHTML = '';
	}

}
