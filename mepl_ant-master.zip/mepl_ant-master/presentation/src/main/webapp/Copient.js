var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1;//January is 0!
var yyyy = today.getFullYear();
if(dd<10){dd='0'+dd}
if(mm<10){mm='0'+mm}
onload = function(){
document.myform.Date_Requested.value = mm+'/'+dd+'/'+yyyy;
}

//format requestor phone number
function mask1(f){
var temp1; 
temp1 = document.myform.req_Requestor_PhoneNumber.value;
temp1 =  temp1.replace(/[^a-zA-Z 0-9]+/g,'');
document.myform.req_Requestor_PhoneNumber.value = temp1;
tel=''; 
var val =f.value.split(''); 
for(var i=0;i<val.length;i++){ 
if(i==2){val[i]=val[i]+'-'}
if(i==5){val[i]=val[i]+'-'} 
if(i==10){val[i]=''}
if(i==11){val[i]=''}
tel=tel+val[i] 
} 
f.value=tel; 
} 

/*function price(){
	var Price = (document.myform.req_Total_Savings_Amount.value * 1)
	document.myform.req_Total_Savings_Amount.value = Price.toFixed(2);
}*/

function divisions(){
if (document.getElementById("1").checked == true){
	for (var i=2; i < 16; i++){
	document.getElementById(i).disabled = true;
	document.getElementById(i).checked = false;
	}
}

if (document.getElementById("1").checked == false){
	for (var i=2; i < 15; i++){
	document.getElementById(i).disabled = false;
	}
}
}


function runOnSubmit(){

var boolSubmit = true;


//check if user id is 7 characters
if(document.myform.req_Requestor_UserId.value.length != 7) {

		alert("You did not enter a valid User ID. ( 7 characters )");
		boolSubmit = false;
	}
	

//check requestor phone
if(document.myform.req_Requestor_PhoneNumber.value.length != 12) {

		alert("You did not enter a 10 digit phone number");
		boolSubmit = false;

	}
	
//check if they selected a division		
		if(document.getElementById("1").checked == false && document.getElementById("2").checked == false && document.getElementById("3").checked == false && document.getElementById("4").checked == false && document.getElementById("5").checked == false && document.getElementById("6").checked == false && document.getElementById("7").checked == false && document.getElementById("8").checked == false && document.getElementById("9").checked == false && document.getElementById("10").checked == false && document.getElementById("11").checked == false && document.getElementById("12").checked == false && document.getElementById("13").checked == false){

		alert("You did not select a Division");
  		boolSubmit = false;		
		}

//check if PLU Start date has passed		
	if (document.myform.req_PLU_Start.value.length == 10){
		var date1 = document.myform.req_PLU_Start.value;
		var date2 = document.myform.Date_Requested.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 <= date2){
			alert ("PLU Start Date must be a future date");
			  		boolSubmit = false;		
		}
	}
	
//check if PLU End date has passed		
	if (document.myform.req_PLU_End.value.length == 10){
		var date1 = document.myform.req_PLU_End.value;
		var date2 = document.myform.req_PLU_Start.value;
		tmp1 = date1.split("/");
		tmp2 = date2.split("/");
		date1 = tmp1[2] + tmp1[0] + tmp1[1];
		date2 = tmp2[2] + tmp2[0] + tmp2[1];
		if (date1 <= date2){
			alert ("PLU End Date must be after the start date");
			  		boolSubmit = false;		
		}
	}

//check if a valid email address entered for alternate contact	
 var testresults
 var str=document.myform.Requestor_AlternateEmail.value
 var filter=/^.+@.+\..{2,3}$/

if (document.myform.Requestor_AlternateEmail.value != ""){
 if (filter.test(str))
    testresults=true;
 else {
    alert("You did not enter a valid email address for an alternate contact")
    testresults=false;
	boolSubmit = false;
}
}



	if(boolSubmit == true){
		document.myform.sendSubject.value = document.myform.sendSubject.value + document.myform.req_Promotion_Name.value;

		document.myform.sendCc.value = document.myform.Requestor_AlternateEmail.value;

		return true;
	}

	else

		return false;


}


// maxlength for comments
function ismaxlength(obj){
var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
if (obj.getAttribute && obj.value.length>mlength)
obj.value=obj.value.substring(0,mlength)
}


function toggleMe(a){
  var e=document.getElementById(a);
  if(!e)return true;
  if(e.style.display=="none"){
    e.style.display="block"
  } else {
    e.style.display="none"
  }
  return true;
}



