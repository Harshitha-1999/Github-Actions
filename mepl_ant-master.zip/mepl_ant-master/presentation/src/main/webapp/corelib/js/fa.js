var size = 18;

var sCoreSite = "Marketing"



window.faTopic = new Array(size);

window.faGoTo = new Array(size);				

window.faTopic[0] = "Corporate - Home";

window.faGoTo[0] = "../../../index.htm";

window.faTopic[1] = "Marketing - Home";

window.faGoTo[1] = "/mktg/index.htm";

window.faTopic[2] = "Finance";

window.faGoTo[2] = "/mktg/fpa/";

window.faTopic[3] = "Business Processes";

window.faGoTo[3] = "/mktg/mbp";

window.faTopic[4] = "Advertising";

window.faGoTo[4] = "/mktg/advertising";

window.faTopic[5] = "EDS";

window.faGoTo[5] = "/mktg/eds/";

window.faTopic[6] = "IDS";

window.faGoTo[6] = "/mktg/ids/";

window.faTopic[7] = "Consumer Demand";

window.faGoTo[7] = "/mktg/ctgry";

window.faTopic[8] = "Pricing";

window.faGoTo[8] = "/mktg/pricing";

window.faTopic[9] = "Supply Chain";

window.faGoTo[9] = "/mktg/supply";

window.faTopic[10] = "Card Based Business/Telecom";

window.faGoTo[10] = "/mktg/sms/";

window.faTopic[11] = "Procurement";

window.faGoTo[11] = "/mktg/procurement";

window.faTopic[12] = "Bakery";

window.faGoTo[12] = "/mktg/bakery/";

window.faTopic[13] = "Food Service";

window.faGoTo[13] = "/mktg/deli/";

window.faTopic[14] = "Floral";

window.faGoTo[14] = "/mktg/floral/";

window.faTopic[15] = "Meat & Seafood";

window.faGoTo[15] = "/mktg/meat/";

window.faTopic[16] = "Pharmacy";

window.faGoTo[16] = "/mktg/pharmacy/";

window.faTopic[17] = "Produce";

window.faGoTo[17] = "/mktg/produce/";

window.faTopic[17] = "Quality Assurance &amp; Consumer Protection";

window.faGoTo[17] = "/mktg/foodsafety/";

window.faTopic[18] = "Transformation";

window.faGoTo[18] = "/mktg/foodsafety/";