JAVA_OPTS="-Djava.protocol.handler.pkgs=org.apache.catalina.webresources -Dsecurity.disable=true -Drmgr.env=dv -Dcc.env=dv"
