java -Xms128m -Xmx256m -XX:+UseG1GC -jar /app/memi-web-2.1.11-SNAPSHOT.jar --server.port=8080 &
java -Xms128m -Xmx256m -XX:+UseG1GC -jar /app/memi-web-2.1.11-SNAPSHOT.jar --server.port=8081 &
java -Xms128m -Xmx256m -XX:+UseG1GC -jar /app/memi-web-2.1.11-SNAPSHOT.jar --server.port=8082 
