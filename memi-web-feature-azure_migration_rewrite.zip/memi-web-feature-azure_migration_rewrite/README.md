# memi-web - Test

Local Setup Steps:
1. Clone Application in STS or any IDE.
2. Update Database username and password in src/main/resources/application.yml file in Local Profile.
3. Maven Build: Right click on project -> Run As -> Maven Build -> Goals : clean install -> Run.
4. Run Application: Right click on project -> Run As -> Spring Boot App.
5. Test URL : http://localhost:8080/memi-web/services/company/list
