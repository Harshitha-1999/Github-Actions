package com.safeway.app.memi.domain.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;

@Component
public class BakeryActionValidations {
	private static final Logger LOG = LoggerFactory.getLogger(BakeryActionValidations.class);
	
	public List<String> validateActions(List<BakeryMappingRequest> bakeryMappingRequestsBuyer, List<BakeryMappingRequest> bakeryMappingRequestsSeller) {
		LOG.info("Execution started for validate Actions");
		List<String> errorMsges = new ArrayList();
		if (null != bakeryMappingRequestsBuyer && !bakeryMappingRequestsBuyer.isEmpty()) {
			
				
			if (!validateLetAutoMatch(bakeryMappingRequestsBuyer)) {
				errorMsges.add("Please avoid automatch and other mapping actions together!");

			}
			
				errorMsges.addAll(validateMappingObjectList(bakeryMappingRequestsBuyer));
					
			if(bakeryMappingRequestsSeller!=null && !bakeryMappingRequestsSeller.isEmpty())
			{
				errorMsges.addAll(validateMappingObjectList(bakeryMappingRequestsSeller));
				errorMsges.addAll(validateSellerBuyerObject(bakeryMappingRequestsBuyer.get(0),bakeryMappingRequestsSeller.get(0)));			
				
			}
			

		}
		LOG.info("Execution completed for validate Actions");

		return errorMsges;

	}
	
	
	private boolean validateLetAutoMatch(List<BakeryMappingRequest> bakeryMappingRequests) {
		LOG.debug("Execution started for validate Let AutoMatch");

        boolean checkAutoMatch =true;
        String primeMAtchType =null;
		for(BakeryMappingRequest bakeryMappingRequest : bakeryMappingRequests  )
		{
			if(primeMAtchType==null)
			{
				primeMAtchType=bakeryMappingRequest.getMappingType();
			}
		  if( primeMAtchType!=null &&primeMAtchType.equals(PerishableConstants.LET_AUTO_MATCH) &&
				  !bakeryMappingRequest.getMappingType().equals(primeMAtchType))
		  {
			  checkAutoMatch= false;
		  }
			  
		}
		LOG.debug("Execution completed for validate Let AutoMatch");

		return checkAutoMatch;
	}

	private Set<String> validateMappingObjectList(List<BakeryMappingRequest> bakeryMappingRequests)
	{
		LOG.debug("Execution started for validate Mapping Object List");

		BakeryMappingRequest bakeryMappingRequest1 =null; 
		Set<String> errorMsges = new HashSet<>();
		
		for (BakeryMappingRequest bakeryMappingRequest : bakeryMappingRequests) {
			
			if (bakeryMappingRequest1 == null && (bakeryMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
					|| bakeryMappingRequest.getMappingType().equals(PerishableConstants.INHERIT_MAP))) {
									bakeryMappingRequest1 = bakeryMappingRequest;
									
			}

			if ((bakeryMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
					|| bakeryMappingRequest.getMappingType().equals(PerishableConstants.INHERIT_MAP))
					&& bakeryMappingRequest.getCic() == null) {
				errorMsges.add("You are not selected a CIC for mapping");
			}

			if (bakeryMappingRequest.getMappingType().equals(PerishableConstants.MARK_AS_DEAD)
					&& bakeryMappingRequest.getCic() != null) {
				errorMsges.add("For marking as dead don't select a CIC from right side");
			}	
		
	/*		if (bakeryMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
					|| bakeryMappingRequest.getMappingType().equals(PerishableConstants.INHERIT_MAP)) {
				
				if(bakeryMappingRequest1.getSku().equals(bakeryMappingRequest.getSku()) &&
						bakeryMappingRequest1.getTargetTypeIndicator().equals(bakeryMappingRequest.getTargetTypeIndicator()) &&
						!bakeryMappingRequest1.getCic().equals(bakeryMappingRequest.getCic())
						)
				{
					errorMsges.add("You can't select more than one CIC for a seller or buyer mapping");
				}
			
			}*/
						
			if (bakeryMappingRequest.getMappingType().equals(PerishableConstants.RESERVED)
					&& 
					!(bakeryMappingRequest.getMappingstatus().equals(PerishableConstants.AWAITING_CIC)||	
					bakeryMappingRequest.getMappingstatus().equals(PerishableConstants.OTHER)||
					bakeryMappingRequest.getMappingstatus().equals(PerishableConstants.AWAITING_DIVISION)
					)
					) {
				errorMsges.add("Status given for RESERVED category is wrong");
			}
						

			
			if(bakeryMappingRequest.isTargetEdited())
			{
				String singleCharRegExp ="[a-bA-Z0-9]{1}";
				String singleDigRegExp ="[0-9]{1}";
				String costValueRegExp ="[0-9]{1,9}+[.]?[0-9]{0,4}";
				String daysCountExp ="[0-9]{1,16}";
				
				if(bakeryMappingRequest.getDcPackDesc() !=null &&bakeryMappingRequest.getDcPackDesc().trim().length()>3)
					errorMsges.add("DC Pack desc maximum three characters allowed");
				if(bakeryMappingRequest.getDcSizeDsc() !=null &&bakeryMappingRequest.getDcSizeDsc().trim().length()>7)
					errorMsges.add("DC Size desc maximum seven characters allowed");
				if(bakeryMappingRequest.getRetailUnitPack() !=null &&!bakeryMappingRequest.getRetailUnitPack().trim().matches("[0-9]{1,7}+[.]?[0-9]{0,2}"))
					errorMsges.add("RUP is not a number in the prescribed format");
				if(bakeryMappingRequest.getRing() !=null &&!bakeryMappingRequest.getRing().trim().matches("[0-5]{1}"))
					errorMsges.add("Ring value should be from 0 to 5 ");
				if(bakeryMappingRequest.getHicone() !=null &&!bakeryMappingRequest.getHicone().trim().matches("[0-2]{1}"))
					errorMsges.add("Hicone value should be 0,1 or 2 ");
				
				if(bakeryMappingRequest. getProdwght()!=null &&!bakeryMappingRequest.getProdwght().trim().matches("[0-9]{1,7}+[.]?[0-9]{0,4}"))
					errorMsges.add("Prod Weight is not a number in the prescribed format ");
				if(bakeryMappingRequest.getHandlingCode() !=null &&!bakeryMappingRequest.getHandlingCode().trim().matches("[0-9]{1,3}"))
					errorMsges.add("Handling code should be a number with maximum 3 digits ");					
				if(bakeryMappingRequest.getBuyerNum() !=null &&!bakeryMappingRequest.getBuyerNum().trim().matches("[a-bA-Z0-9]{1,2}"))
					errorMsges.add("Buyer num should not exceed two characters ");
				if(bakeryMappingRequest.getRandomWtCd() !=null  && !bakeryMappingRequest.getRandomWtCd().trim().equals("")
						&&	!bakeryMappingRequest.getRandomWtCd().trim().matches("[R]{0,1}"))
						errorMsges.add("Random weight code should be R or a empty  ");					
				if(bakeryMappingRequest.getAutoCostInv() !=null &&!bakeryMappingRequest.getAutoCostInv().trim().matches("[A,C,I]{1}"))
					errorMsges.add("Auto const inv should be A,C or I ");					
				if(bakeryMappingRequest.getBillingType() !=null && !bakeryMappingRequest.getBillingType().trim().equals("")
						&&	!bakeryMappingRequest.getBillingType().trim().matches("[A]{0,1}"))
					errorMsges.add("Billing type should be A or empty ");					
				if(bakeryMappingRequest.getFdStmp() !=null &&!bakeryMappingRequest.getFdStmp().trim().matches("[0-1]{0,1}"))
					errorMsges.add("Food stamp should be 0 or 1 ");
				if(bakeryMappingRequest.getTareCd() !=null &&!bakeryMappingRequest.getTareCd().trim().matches("[0-9]{1,38}"))
					errorMsges.add("Tare code should be a number ");
				if(bakeryMappingRequest.getLabelSize() !=null &&!bakeryMappingRequest.getLabelSize().trim().matches("[M,N,S]{1}"))
					errorMsges.add("Tag size type should be M,N or S character ");
				if(bakeryMappingRequest.getLabelNumbers() !=null &&!bakeryMappingRequest.getLabelNumbers().trim().matches(singleDigRegExp))
					errorMsges.add("Tag number type should be single digit ");					
				if(bakeryMappingRequest.getSgnCount1() !=null &&!bakeryMappingRequest.getSgnCount1().trim().matches(singleDigRegExp))
					errorMsges.add("Sign count1 type should be single digit ");
				if(bakeryMappingRequest.getSgnCount2() !=null &&!bakeryMappingRequest.getSgnCount2().trim().matches(singleDigRegExp))
					errorMsges.add("Sign count2 type should be single digit ");
				if(bakeryMappingRequest.getSgnCount3() !=null &&!bakeryMappingRequest.getSgnCount3().trim().matches(singleDigRegExp))
					errorMsges.add("Sign count3 type should be single digit ");
				if(bakeryMappingRequest.getPrcTypeCd() !=null &&!bakeryMappingRequest.getPrcTypeCd().trim().matches("[a-bA-Z0-9]{1,2}"))
					errorMsges.add("Tag number type should be single digit ");
				
				
				if(bakeryMappingRequest.getCostAllow() !=null &&!bakeryMappingRequest.getCostAllow().trim().matches(costValueRegExp))
					errorMsges.add("Cost allow should be decimal number ");
				if(bakeryMappingRequest.getCostInv() !=null &&!bakeryMappingRequest.getCostInv().trim().matches(costValueRegExp))
					errorMsges.add("Cost INV should be decimal number ");
				if(bakeryMappingRequest.getCostIb() !=null &&!bakeryMappingRequest.getCostIb().trim().matches(costValueRegExp))
					errorMsges.add("Cost IB should be decimal number ");
				if(bakeryMappingRequest.getCostVend() !=null &&!bakeryMappingRequest.getCostVend().trim().matches(costValueRegExp))
					errorMsges.add("Cost Vendor should be decimal number ");
				
				if(bakeryMappingRequest.getSellByDays() !=null &&!bakeryMappingRequest.getSellByDays().trim().matches(daysCountExp))
					errorMsges.add("Sell by days should be decimal number ");
				if(bakeryMappingRequest.getUseByDays() !=null &&!bakeryMappingRequest.getUseByDays().trim().matches(daysCountExp))
					errorMsges.add("Use by days should be decimal number ");
				if(bakeryMappingRequest.getPullBydays() !=null &&!bakeryMappingRequest.getPullBydays().trim().matches(daysCountExp))
					errorMsges.add("Pull by days should be decimal number ");
			}
		}
		LOG.debug("Execution completed for validate Mapping Object List");

		return errorMsges;
	}
	
	private List<String> validateSellerBuyerObject(BakeryMappingRequest bakeryMappingRequestsBuyer,BakeryMappingRequest bakeryMappingRequestsSeller)
	{
		LOG.debug("Execution started for validate Seller BuyerObject");

		List<String> errorMsges = new ArrayList();
		
		if(!bakeryMappingRequestsBuyer.getSku().equals(bakeryMappingRequestsSeller.getSku()))
		{
			errorMsges.add("You are selected more than one SKU for mapping");
		}
		if(bakeryMappingRequestsBuyer.getTargetTypeIndicator().equals(bakeryMappingRequestsSeller.getTargetTypeIndicator()))
		{
			errorMsges.add("You are selected more than one Seller/Buyer for mapping");
		}
		
		LOG.debug("Execution completed for validate Seller BuyerObject");

		return errorMsges;
	}
	
	

}
