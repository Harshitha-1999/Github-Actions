package com.safeway.app.memi.data.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Embedded key class for Database table COMPANY.
 * 
 */
@Embeddable
public class ItemAggregateCorpPk implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "COMPANY_ID")
	private String companyId;

	@Column(name = "DIVISION_ID")
	private String divisionId;

	@Column(name = "PRODUCT_SKU")
	private String productSKU;

	@Column(name = "UPC")
	private String upc;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSKU() {
		return productSKU;
	}

	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

}
