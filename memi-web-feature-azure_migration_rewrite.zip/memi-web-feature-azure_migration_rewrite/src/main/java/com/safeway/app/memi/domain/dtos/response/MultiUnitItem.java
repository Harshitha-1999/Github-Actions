package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Set;

public class MultiUnitItem {

	private String companyId;
	private String divisionId;
	private String productSku;
	private String convProductSku;
	private String srcItemDesc;
	private BigDecimal srcPackWhse;
	private BigDecimal srcVendConvFctr;
	private String srcSize;
	private String srcUpc;
	private String prodSourceCd;
	private String srcCaseUpc;
	private BigDecimal srcCost;
	private BigDecimal srcVendNum;
	private String srcVendName;
	private Set<String> srcUpcList;
	private Set<String> srcDeptNameList;
	private BigDecimal maxRetail;
	private String srcDeptName;
	private String srcProductHierarchy;
	private String convStatusCode;

	private BigDecimal tarCorpItemCd;
	private String tarItemDesc;
	private BigDecimal tarPackWhse;
	private BigDecimal tarVendConvFctr;
	private String tarUpc;
	private String tarSize;
	private String tarDeptName;
	private String tarSmicCode;
	private String tarItemTypeWhseDsd;
	private BigDecimal tarCost;
	private String tarVendorName;
	private BigDecimal tarUnitType;
	private String tarCaseUpc;
	private String tarRetailSection;
	private String tarCorpStatus;
	private BigDecimal tarInnerPack;
	private String tarVendorNumber;
	private BigDecimal tarUpcCountry;
	private BigDecimal tarUpcSystem;
	private BigDecimal tarUpcManuf;
	private BigDecimal tarUpcSales;
	private String tarFinalUpc;
	private BigDecimal tarFinalUnitType;

	public BigDecimal getTarFinalUnitType() {
		return tarFinalUnitType;
	}

	public void setTarFinalUnitType(BigDecimal tarFinalUnitType) {
		this.tarFinalUnitType = tarFinalUnitType;
	}

	private Set<String> tarUpcList;
	private Set<String> tarDeptNameList;

	public String getTarFinalUpc() {
		return tarFinalUpc;
	}

	public void setTarFinalUpc(String tarFinalUpc) {
		this.tarFinalUpc = tarFinalUpc;
	}

	public String getConvStatusCode() {
		return convStatusCode;
	}

	public void setConvStatusCode(String convStatusCode) {
		this.convStatusCode = convStatusCode;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSku() {
		return productSku;
	}

	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}

	public String getConvProductSku() {
		return convProductSku;
	}

	public void setConvProductSku(String convProductSku) {
		this.convProductSku = convProductSku;
	}

	public String getSrcItemDesc() {
		return srcItemDesc;
	}

	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}

	public BigDecimal getSrcPackWhse() {
		return srcPackWhse;
	}

	public void setSrcPackWhse(BigDecimal srcPackWhse) {
		this.srcPackWhse = srcPackWhse;
	}

	public BigDecimal getSrcVendConvFctr() {
		return srcVendConvFctr;
	}

	public void setSrcVendConvFctr(BigDecimal srcVendConvFctr) {
		this.srcVendConvFctr = srcVendConvFctr;
	}

	public String getSrcSize() {
		return srcSize;
	}

	public void setSrcSize(String srcSize) {
		this.srcSize = srcSize;
	}

	public String getSrcUpc() {
		return srcUpc;
	}

	public void setSrcUpc(String srcUpc) {
		this.srcUpc = srcUpc;
	}

	public String getProdSourceCd() {
		return prodSourceCd;
	}

	public void setProdSourceCd(String prodSourceCd) {
		this.prodSourceCd = prodSourceCd;
	}

	public String getSrcCaseUpc() {
		return srcCaseUpc;
	}

	public void setSrcCaseUpc(String srcCaseUpc) {
		this.srcCaseUpc = srcCaseUpc;
	}

	public BigDecimal getSrcCost() {
		return srcCost;
	}

	public void setSrcCost(BigDecimal srcCost) {
		this.srcCost = srcCost;
	}

	public BigDecimal getSrcVendNum() {
		return srcVendNum;
	}

	public void setSrcVendNum(BigDecimal srcVendNum) {
		this.srcVendNum = srcVendNum;
	}

	public String getSrcVendName() {
		return srcVendName;
	}

	public void setSrcVendName(String srcVendName) {
		this.srcVendName = srcVendName;
	}

	public Set<String> getSrcUpcList() {
		return srcUpcList;
	}

	public void setSrcUpcList(Set<String> srcUpcList) {
		this.srcUpcList = srcUpcList;
	}

	public Set<String> getSrcDeptNameList() {
		return srcDeptNameList;
	}

	public void setSrcDeptNameList(Set<String> srcDeptNameList) {
		this.srcDeptNameList = srcDeptNameList;
	}

	public BigDecimal getMaxRetail() {
		return maxRetail;
	}

	public void setMaxRetail(BigDecimal maxRetail) {
		this.maxRetail = maxRetail;
	}

	public String getSrcDeptName() {
		return srcDeptName;
	}

	public void setSrcDeptName(String srcDeptName) {
		this.srcDeptName = srcDeptName;
	}

	public String getSrcProductHierarchy() {
		return srcProductHierarchy;
	}

	public void setSrcProductHierarchy(String srcProductHierarchy) {
		this.srcProductHierarchy = srcProductHierarchy;
	}

	public BigDecimal getTarCorpItemCd() {
		return tarCorpItemCd;
	}

	public void setTarCorpItemCd(BigDecimal tarCorpItemCd) {
		this.tarCorpItemCd = tarCorpItemCd;
	}

	public String getTarItemDesc() {
		return tarItemDesc;
	}

	public void setTarItemDesc(String tarItemDesc) {
		this.tarItemDesc = tarItemDesc;
	}

	public BigDecimal getTarPackWhse() {
		return tarPackWhse;
	}

	public void setTarPackWhse(BigDecimal tarPackWhse) {
		this.tarPackWhse = tarPackWhse;
	}

	public BigDecimal getTarVendConvFctr() {
		return tarVendConvFctr;
	}

	public void setTarVendConvFctr(BigDecimal tarVendConvFctr) {
		this.tarVendConvFctr = tarVendConvFctr;
	}

	public String getTarUpc() {
		return tarUpc;
	}

	public void setTarUpc(String tarUpc) {
		this.tarUpc = tarUpc;
	}

	public String getTarSize() {
		return tarSize;
	}

	public void setTarSize(String tarSize) {
		this.tarSize = tarSize;
	}

	public String getTarDeptName() {
		return tarDeptName;
	}

	public void setTarDeptName(String tarDeptName) {
		this.tarDeptName = tarDeptName;
	}

	public String getTarSmicCode() {
		return tarSmicCode;
	}

	public void setTarSmicCode(String tarSmicCode) {
		this.tarSmicCode = tarSmicCode;
	}

	public String getTarItemTypeWhseDsd() {
		return tarItemTypeWhseDsd;
	}

	public void setTarItemTypeWhseDsd(String tarItemTypeWhseDsd) {
		this.tarItemTypeWhseDsd = tarItemTypeWhseDsd;
	}

	public BigDecimal getTarCost() {
		return tarCost;
	}

	public void setTarCost(BigDecimal tarCost) {
		this.tarCost = tarCost;
	}

	public String getTarVendorName() {
		return tarVendorName;
	}

	public void setTarVendorName(String tarVendorName) {
		this.tarVendorName = tarVendorName;
	}

	public BigDecimal getTarUnitType() {
		return tarUnitType;
	}

	public void setTarUnitType(BigDecimal tarUnitType) {
		this.tarUnitType = tarUnitType;
	}

	public String getTarCaseUpc() {
		return tarCaseUpc;
	}

	public void setTarCaseUpc(String tarCaseUpc) {
		this.tarCaseUpc = tarCaseUpc;
	}

	public String getTarRetailSection() {
		return tarRetailSection;
	}

	public void setTarRetailSection(String tarRetailSection) {
		this.tarRetailSection = tarRetailSection;
	}

	public String getTarCorpStatus() {
		return tarCorpStatus;
	}

	public void setTarCorpStatus(String tarCorpStatus) {
		this.tarCorpStatus = tarCorpStatus;
	}

	public BigDecimal getTarInnerPack() {
		return tarInnerPack;
	}

	public void setTarInnerPack(BigDecimal tarInnerPack) {
		this.tarInnerPack = tarInnerPack;
	}

	public String getTarVendorNumber() {
		return tarVendorNumber;
	}

	public void setTarVendorNumber(String tarVendorNumber) {
		this.tarVendorNumber = tarVendorNumber;
	}

	public BigDecimal getTarUpcCountry() {
		return tarUpcCountry;
	}

	public void setTarUpcCountry(BigDecimal tarUpcCountry) {
		this.tarUpcCountry = tarUpcCountry;
	}

	public BigDecimal getTarUpcSystem() {
		return tarUpcSystem;
	}

	public void setTarUpcSystem(BigDecimal tarUpcSystem) {
		this.tarUpcSystem = tarUpcSystem;
	}

	public BigDecimal getTarUpcManuf() {
		return tarUpcManuf;
	}

	public void setTarUpcManuf(BigDecimal tarUpcManuf) {
		this.tarUpcManuf = tarUpcManuf;
	}

	public BigDecimal getTarUpcSales() {
		return tarUpcSales;
	}

	public void setTarUpcSales(BigDecimal tarUpcSales) {
		this.tarUpcSales = tarUpcSales;
	}

	public Set<String> getTarUpcList() {
		return tarUpcList;
	}

	public void setTarUpcList(Set<String> tarUpcList) {
		this.tarUpcList = tarUpcList;
	}

	public Set<String> getTarDeptNameList() {
		return tarDeptNameList;
	}

	public void setTarDeptNameList(Set<String> tarDeptNameList) {
		this.tarDeptNameList = tarDeptNameList;
	}

	@Override
	public String toString() {
		return "MultiUnitItem [companyId=" + companyId + ", divisionId="
				+ divisionId + ", productSku=" + productSku
				+ ", convProductSku=" + convProductSku + ", srcItemDesc="
				+ srcItemDesc + ", srcPackWhse=" + srcPackWhse
				+ ", srcVendConvFctr=" + srcVendConvFctr + ", srcSize="
				+ srcSize + ", srcUpc=" + srcUpc + ", prodSourceCd="
				+ prodSourceCd + ", srcCaseUpc=" + srcCaseUpc + ", srcCost="
				+ srcCost + ", srcVendNum=" + srcVendNum + ", srcVendName="
				+ srcVendName + ", srcUpcList=" + srcUpcList
				+ ", srcDeptNameList=" + srcDeptNameList + ", maxRetail="
				+ maxRetail + ", srcDeptName=" + srcDeptName
				+ ", srcProductHierarchy=" + srcProductHierarchy
				+ ", convStatusCode=" + convStatusCode + ", tarCorpItemCd="
				+ tarCorpItemCd + ", tarItemDesc=" + tarItemDesc
				+ ", tarPackWhse=" + tarPackWhse + ", tarVendConvFctr="
				+ tarVendConvFctr + ", tarUpc=" + tarUpc + ", tarSize="
				+ tarSize + ", tarDeptName=" + tarDeptName + ", tarSmicCode="
				+ tarSmicCode + ", tarItemTypeWhseDsd=" + tarItemTypeWhseDsd
				+ ", tarCost=" + tarCost + ", tarVendorName=" + tarVendorName
				+ ", tarUnitType=" + tarUnitType + ", tarCaseUpc=" + tarCaseUpc
				+ ", tarRetailSection=" + tarRetailSection + ", tarCorpStatus="
				+ tarCorpStatus + ", tarInnerPack=" + tarInnerPack
				+ ", tarVendorNumber=" + tarVendorNumber + ", tarUpcCountry="
				+ tarUpcCountry + ", tarUpcSystem=" + tarUpcSystem
				+ ", tarUpcManuf=" + tarUpcManuf + ", tarUpcSales="
				+ tarUpcSales + ", tarFinalUpc=" + tarFinalUpc
				+ ", tarFinalUnitType=" + tarFinalUnitType + ", tarUpcList="
				+ tarUpcList + ", tarDeptNameList=" + tarDeptNameList + "]";
	}

}
