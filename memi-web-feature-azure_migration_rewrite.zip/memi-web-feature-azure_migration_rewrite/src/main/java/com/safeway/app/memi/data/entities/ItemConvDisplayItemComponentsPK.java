package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class ItemConvDisplayItemComponentsPK implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column(name ="COMPANY_ID", nullable =false)
	private String companyid ;
	
	@Column(name ="DIVISION_ID", nullable =false)
	private String divisonId;
	
	@Column(name ="PRODUCT_SKU", nullable =false)
	private String productSku;
		
	@Column(name ="UPC_COUNTRY", nullable =false)
	private BigDecimal upcCountry;
	
	@Column(name ="UPC_SYSTEM", nullable =false)
	private BigDecimal upcSystem;
	
	@Column(name ="UPC_MANUF", nullable =false)
	private BigDecimal upcManuf;
	
	@Column(name ="UPC_SALES", nullable =false)
	private BigDecimal upcSales;
	
	
	
	public String getCompanyid() {
		return companyid;
	}

	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}

	public String getDivisonId() {
		return divisonId;
	}

	public void setDivisonId(String divisonId) {
		this.divisonId = divisonId;
	}

	public String getProductSku() {
		return productSku;
	}

	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}
	
	public BigDecimal getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(BigDecimal upcCountry) {
		this.upcCountry = upcCountry;
	}

	public BigDecimal getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(BigDecimal upcSystem) {
		this.upcSystem = upcSystem;
	}

	public BigDecimal getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(BigDecimal upcManuf) {
		this.upcManuf = upcManuf;
	}

	public BigDecimal getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(BigDecimal upcSales) {
		this.upcSales = upcSales;
	}

}
