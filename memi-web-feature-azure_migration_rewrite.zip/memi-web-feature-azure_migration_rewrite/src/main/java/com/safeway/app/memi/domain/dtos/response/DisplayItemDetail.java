package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class DisplayItemDetail {

	private String companyId;
	private String divisionId;
	private String deptCode;
	private String productSku;
	private String itemDesc;
	private BigDecimal shippingPackNumber;
	private BigDecimal masterCasePackNumber;
	private BigDecimal sizeNumber;
	private String multiComponentItemInd;
	private String caseUpc;
	private BigDecimal onHandQty;
	private BigDecimal onOrderQty;
	private String slot;
	private String itemCreateDate;
	private String lastShipDate;
	private BigDecimal cost;
	private String markAsDeadReason;
	private String createId;
	private String updatedUserID;
	private Character itemType;
	private String oneTimeBuyFlag;
	private String productSourceCode;

	public String getProductSourceCode() {
		return productSourceCode;
	}

	public void setProductSourceCode(String productSourceCode) {
		this.productSourceCode = productSourceCode;
	}

	public String getOneTimeBuyFlag() {
		return oneTimeBuyFlag;
	}

	public void setOneTimeBuyFlag(String oneTimeBuyFlag) {
		this.oneTimeBuyFlag = oneTimeBuyFlag;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getProductSku() {
		return productSku;
	}

	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public BigDecimal getShippingPackNumber() {
		return shippingPackNumber;
	}

	public void setShippingPackNumber(BigDecimal shippingPackNumber) {
		this.shippingPackNumber = shippingPackNumber;
	}

	public BigDecimal getMasterCasePackNumber() {
		return masterCasePackNumber;
	}

	public void setMasterCasePackNumber(BigDecimal masterCasePackNumber) {
		this.masterCasePackNumber = masterCasePackNumber;
	}

	public BigDecimal getSizeNumber() {
		return sizeNumber;
	}

	public void setSizeNumber(BigDecimal sizeNumber) {
		this.sizeNumber = sizeNumber;
	}

	public String getMultiComponentItemInd() {
		return multiComponentItemInd;
	}

	public void setMultiComponentItemInd(String multiComponentItemInd) {
		this.multiComponentItemInd = multiComponentItemInd;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public BigDecimal getOnHandQty() {
		return onHandQty;
	}

	public void setOnHandQty(BigDecimal onHandQty) {
		this.onHandQty = onHandQty;
	}

	public BigDecimal getOnOrderQty() {
		return onOrderQty;
	}

	public void setOnOrderQty(BigDecimal onOrderQty) {
		this.onOrderQty = onOrderQty;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

	public String getItemCreateDate() {
		return itemCreateDate;
	}

	public void setItemCreateDate(String itemCreateDate) {
		this.itemCreateDate = itemCreateDate;
	}

	public String getLastShipDate() {
		return lastShipDate;
	}

	public void setLastShipDate(String lastShipDate) {
		this.lastShipDate = lastShipDate;
	}

	public BigDecimal getCost() {
		return cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getMarkAsDeadReason() {
		return markAsDeadReason;
	}

	public void setMarkAsDeadReason(String markAsDeadReason) {
		this.markAsDeadReason = markAsDeadReason;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public String getUpdatedUserID() {
		return updatedUserID;
	}

	public void setUpdatedUserID(String updatedUserID) {
		this.updatedUserID = updatedUserID;
	}

	public Character getItemType() {
		return itemType;
	}

	public void setItemType(Character itemType) {
		this.itemType = itemType;
	}

	@Override
	public String toString() {
		return "DisplayItemDetail [companyId=" + companyId + ", divisionId="
				+ divisionId + ", deptCode=" + deptCode + ", productSku="
				+ productSku + ", itemDesc=" + itemDesc
				+ ", shippingPackNumber=" + shippingPackNumber
				+ ", masterCasePackNumber=" + masterCasePackNumber
				+ ", sizeNumber=" + sizeNumber + ", multiComponentItemInd="
				+ multiComponentItemInd + ", caseUpc=" + caseUpc
				+ ", onHandQty=" + onHandQty + ", onOrderQty=" + onOrderQty
				+ ", slot=" + slot + ", itemCreateDate=" + itemCreateDate
				+ ", lastShipDate=" + lastShipDate + ", cost=" + cost
				+ ", markAsDeadReason=" + markAsDeadReason + ", createId="
				+ createId + ", updatedUserID=" + updatedUserID + ", itemType="
				+ itemType + ", oneTimeBuyFlag=" + oneTimeBuyFlag
				+ ", productSourceCode=" + productSourceCode + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((productSku == null) ? 0 : productSku.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DisplayItemDetail other = (DisplayItemDetail) obj;
		if (productSku == null) {
			if (other.productSku != null)
				return false;
		} else if (!productSku.equals(other.productSku))
			return false;
		return true;
	}
	

}