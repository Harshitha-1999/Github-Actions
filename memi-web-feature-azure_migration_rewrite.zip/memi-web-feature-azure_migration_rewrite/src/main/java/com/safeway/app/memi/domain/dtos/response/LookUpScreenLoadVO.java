package com.safeway.app.memi.domain.dtos.response;

import java.util.ArrayList;
import java.util.List;

public class LookUpScreenLoadVO {
	
	private List<ItemSet> itemSets;
	private List<ConversionStatusCode> conversionStatus;
	private List<ConvDepartment> departmentList;
	private LookUpCustomizationVO customVO;
	
	public List<ItemSet> getItemSets() {
		return itemSets;
	}
	public void setItemSets(List<ItemSet> itemSets) {
		this.itemSets = itemSets;
	}
	public List<ConversionStatusCode> getConversionStatus() {
		return conversionStatus;
	}
	public void setConversionStatus(List<ConversionStatusCode> conversionStatus) {
		this.conversionStatus = conversionStatus;
	}
	public List<ConvDepartment> getDepartmentList() {
		return departmentList;
	}
	public void setDepartmentList(List<ConvDepartment> departmentList) {
		this.departmentList = departmentList;
	}
	public LookUpCustomizationVO getCustomVO() {
		return customVO;
	}
	public void setCustomVO(LookUpCustomizationVO customVO) {
		this.customVO = customVO;
	}
	
	public List<ConvDepartment> addAllConvDepartment(List<Object[]> departments)
	{  
		if(this.departmentList ==null)
		{
		   this.departmentList =new ArrayList();
		}
	
		for(Object[] obj:departments)
		{
			ConvDepartment convD=new ConvDepartment();
			convD.setConvGrpCode(obj[0].toString());
			convD.setConvGrpName(obj[1].toString());
			this.departmentList.add(convD);
		}		
		
		return this.departmentList;
	}
	public List<ItemSet> addAllItemSets()
	{
		if(this.itemSets ==null)
		{
		   this.itemSets =new ArrayList();
		}
			
		this.itemSets.add(new ItemSet("DIT","Displayer Items"));
		this.itemSets.add(new ItemSet("PLU","PLU"));
		this.itemSets.add(new ItemSet("SYS2","System2"));
		this.itemSets.add(new ItemSet("SYS4","System4"));
		this.itemSets.add(new ItemSet("EXP","Expense Items"));
		this.itemSets.add(new ItemSet("MTE","Material Items"));
		this.itemSets.add(new ItemSet("MUT","Multi-Unit Type Items"));
		this.itemSets.add(new ItemSet("REG","Regular UPC"));
		this.itemSets.add(new ItemSet("MUL","Multiple UPC"));
	
		
		return this.itemSets;
	}
	
	public List<ConversionStatusCode> addAllConversionStatus()
	{
		if(this.conversionStatus ==null)
		{
		   this.conversionStatus =new ArrayList();
		}
		
		this.conversionStatus.add(new ConversionStatusCode("C=D","Pending Conversion"));	
		this.conversionStatus.add(new ConversionStatusCode("C","Completed"));	
		
		this.conversionStatus.add(new ConversionStatusCode("N","New"));
		this.conversionStatus.add(new ConversionStatusCode("V-A","Valid"));	
		
		
		this.conversionStatus.add(new ConversionStatusCode("D-B","Dead-User assigned"));
		this.conversionStatus.add(new ConversionStatusCode("D-S","Dead-System assigned"));
		/*this.conversionStatus.add(new ConversionStatusCode("D-U","Dead-User"));
		this.conversionStatus.add(new ConversionStatusCode("D","Dead Item"));
		*/
		
		this.conversionStatus.add(new ConversionStatusCode("E-A","Pending Augmentation"));
		this.conversionStatus.add(new ConversionStatusCode("E-O","Pending Override"));	
		this.conversionStatus.add(new ConversionStatusCode("E-N-R-D","Pending Manual Matching of Display Item"));
		this.conversionStatus.add(new ConversionStatusCode("E-M","Pending Manual Matching of Multi Unit Type Items "));
		this.conversionStatus.add(new ConversionStatusCode("E-F","Pending Facility Assignment"));
		this.conversionStatus.add(new ConversionStatusCode("E-I","Identical CIC Exception"));
		this.conversionStatus.add(new ConversionStatusCode("E-S","Data Quality Exception"));
		this.conversionStatus.add(new ConversionStatusCode("E-P-Q","Conversion Exception"));
		
		this.conversionStatus.add(new ConversionStatusCode("R","Ready for Conversion"));
		this.conversionStatus.add(new ConversionStatusCode("S","Selected for QA"));
		this.conversionStatus.add(new ConversionStatusCode("Q","Pending Approval"));		
		this.conversionStatus.add(new ConversionStatusCode("A","Approved Items"));
		
		/*this.conversionStatus.add(new ConversionStatusCode("E-C","Critical Attribute Exception"));
		this.conversionStatus.add(new ConversionStatusCode("E-D","Pending Display Exception"));
		
		this.conversionStatus.add(new ConversionStatusCode("E-R","Display Exception"));
		this.conversionStatus.add(new ConversionStatusCode("E-U","Manual Match"));
		this.conversionStatus.add(new ConversionStatusCode("E-W","Missing sub_vend Exception"));
		
		
		this.conversionStatus.add(new ConversionStatusCode("O-B","Out of Scope-No scan"));
		this.conversionStatus.add(new ConversionStatusCode("O-S","Out of Scope- Ship Or Sell Only "));
		this.conversionStatus.add(new ConversionStatusCode("O-A","Out of Scope-No Authorization"));
		this.conversionStatus.add(new ConversionStatusCode("O-A","Out of Scope-Old conversion Process"));*/
		
		
		
		return this.conversionStatus;
		
	}
	

}
class ItemSet {
	
	private String itemTypeCode;
	private String itemTypeName;
	public ItemSet(String itemTypeCode, String itemTypeName) {
       this.itemTypeCode =itemTypeCode;
       this.itemTypeName=itemTypeName;
	}
	public String getItemTypeCode() {
		return itemTypeCode;
	}
	public void setItemTypeCode(String itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}
	public String getItemTypeName() {
		return itemTypeName;
	}
	public void setItemTypeName(String itemTypeName) {
		this.itemTypeName = itemTypeName;
	}
	
}
class ConversionStatusCode
{
	private String convStatCode;
	private String convStatName;
	public ConversionStatusCode(String convStatCode, String convStatName) {
		this.convStatCode=convStatCode;
		this.convStatName=convStatName;
		
	}
	public String getConvStatCode() {
		return convStatCode;
	}
	public void setConvStatCode(String convStatCode) {
		this.convStatCode = convStatCode;
	}
	public String getConvStatName() {
		return convStatName;
	}
	public void setConvStatName(String convStatName) {
		this.convStatName = convStatName;
	}
	
}
class  ConvDepartment 
{
	private String convGrpCode;
	private String convGrpName;
	public String getConvGrpCode() {
		return convGrpCode;
	}
	public void setConvGrpCode(String convGrpCode) {
		this.convGrpCode = convGrpCode;
	}
	public String getConvGrpName() {
		return convGrpName;
	}
	public void setConvGrpName(String convGrpName) {
		this.convGrpName = convGrpName;
	}
	
}