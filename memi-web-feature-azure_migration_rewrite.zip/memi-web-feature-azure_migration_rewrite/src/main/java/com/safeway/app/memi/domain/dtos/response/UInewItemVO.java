package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class UInewItemVO {
    private String companyId;
    private String divisionId;
    private String productSku;
    private String prmyUpc;
    private BigDecimal updPack;
    private BigDecimal updVcf;
    private String updSizeDesc;
    private BigDecimal updSizeNum;
    private String updSizeUoM;
    private char updItemUsageInd;
    private char updItemUsageTypInd;
    private char updDispItemCheck;
    private String upditemDesc;
    private String updWhseDesc;
    private String updSysDesc;
    private String updinternetDesc;
    private String updPosDesc;
    private String updDeptDetails;
    private String updProdSrcCd;
    private int updCost;
    private String upcUpdated;
    private int grpCd;
    private int ctgryCd;
    private int classCd;
    private int sbClassCd;
    private int sbSubClassCd;
    private String smicDesc;
    private char privateLabel;
    private String conVTeamCmnt;
    private char augCompletionInd;
    private String convTeamCmnt;
    public String getCompanyId() {
        return companyId;
    }
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }
    public String getDivisionId() {
        return divisionId;
    }
    public void setDivisionId(String divisionId) {
        this.divisionId = divisionId;
    }
    public String getPrmyUpc() {
        return prmyUpc;
    }
    public void setPrmyUpc(String prmyUpc) {
        this.prmyUpc = prmyUpc;
    }
   
    public BigDecimal getUpdPack() {
        return updPack;
    }
    public void setUpdPack(BigDecimal updPack) {
        this.updPack = updPack;
    }
 
    public BigDecimal getUpdVcf() {
        return updVcf;
    }
    public void setUpdVcf(BigDecimal updVcf) {
        this.updVcf = updVcf;
    }
    public String getUpdSizeDesc() {
        return updSizeDesc;
    }
    public void setUpdSizeDesc(String updSizeDesc) {
        this.updSizeDesc = updSizeDesc;
    }
   
    public BigDecimal getUpdSizeNum() {
        return updSizeNum;
    }
    public void setUpdSizeNum(BigDecimal updSizeNum) {
        this.updSizeNum = updSizeNum;
    }
    public char getUpdItemUsageInd() {
        return updItemUsageInd;
    }
    public void setUpdItemUsageInd(char updItemUsageInd) {
        this.updItemUsageInd = updItemUsageInd;
    }
    public char getUpdItemUsageTypInd() {
        return updItemUsageTypInd;
    }
    public void setUpdItemUsageTypInd(char updItemUsageTypInd) {
        this.updItemUsageTypInd = updItemUsageTypInd;
    }

    public char getUpdDispItemCheck() {
        return updDispItemCheck;
    }
    public void setUpdDispItemCheck(char updDispItemCheck) {
        this.updDispItemCheck = updDispItemCheck;
    }
    public String getUpditemDesc() {
        return upditemDesc;
    }
    public void setUpditemDesc(String upditemDesc) {
        this.upditemDesc = upditemDesc;
    }
    public String getUpdWhseDesc() {
        return updWhseDesc;
    }
    public void setUpdWhseDesc(String updWhseDesc) {
        this.updWhseDesc = updWhseDesc;
    }
    public String getUpdSysDesc() {
        return updSysDesc;
    }
    public void setUpdSysDesc(String updSysDesc) {
        this.updSysDesc = updSysDesc;
    }
    public String getUpdinternetDesc() {
        return updinternetDesc;
    }
    public void setUpdinternetDesc(String updinternetDesc) {
        this.updinternetDesc = updinternetDesc;
    }
    public String getUpdPosDesc() {
        return updPosDesc;
    }
    public void setUpdPosDesc(String updPosDesc) {
        this.updPosDesc = updPosDesc;
    }
    public String getUpdDeptDetails() {
        return updDeptDetails;
    }
    public void setUpdDeptDetails(String updDeptDetails) {
        this.updDeptDetails = updDeptDetails;
    }
    public String getUpdProdSrcCd() {
        return updProdSrcCd;
    }
    public void setUpdProdSrcCd(String updProdSrcCd) {
        this.updProdSrcCd = updProdSrcCd;
    }
 
    public int getUpdCost() {
        return updCost;
    }
    public void setUpdCost(int updCost) {
        this.updCost = updCost;
    }
    public String getUpcUpdated() {
        return upcUpdated;
    }
    public void setUpcUpdated(String upcUpdated) {
        this.upcUpdated = upcUpdated;
    }
    public int getGrpCd() {
        return grpCd;
    }
    public void setGrpCd(int grpCd) {
        this.grpCd = grpCd;
    }
    public int getCtgryCd() {
        return ctgryCd;
    }
    public void setCtgryCd(int ctgryCd) {
        this.ctgryCd = ctgryCd;
    }
    public int getClassCd() {
        return classCd;
    }
    public void setClassCd(int classCd) {
        this.classCd = classCd;
    }
    public int getSbClassCd() {
        return sbClassCd;
    }
    public void setSbClassCd(int sbClassCd) {
        this.sbClassCd = sbClassCd;
    }
    public int getSbSubClassCd() {
        return sbSubClassCd;
    }
    public void setSbSubClassCd(int sbSubClassCd) {
        this.sbSubClassCd = sbSubClassCd;
    }
    public String getSmicDesc() {
        return smicDesc;
    }
    public void setSmicDesc(String smicDesc) {
        this.smicDesc = smicDesc;
    }


    public char getPrivateLabel() {
        return privateLabel;
    }
    public void setPrivateLabel(char privateLabel) {
        this.privateLabel = privateLabel;
    }
    public String getConVTeamCmnt() {
        return conVTeamCmnt;
    }
    public void setConVTeamCmnt(String conVTeamCmnt) {
        this.conVTeamCmnt = conVTeamCmnt;
    }
    
    public char getAugCompletionInd() {
        return augCompletionInd;
    }
    public void setAugCompletionInd(char augCompletionInd) {
        this.augCompletionInd = augCompletionInd;
    }

    public String getConvTeamCmnt() {
        return convTeamCmnt;
    }
    public void setConvTeamCmnt(String convTeamCmnt) {
        this.convTeamCmnt = convTeamCmnt;
    }
    

    public String getUpdSizeUoM() {
        return updSizeUoM;
    }
    public void setUpdSizeUoM(String updSizeUoM) {
        this.updSizeUoM = updSizeUoM;
    }
    @Override
    public String toString() {
        return "UInewItemVO [companyId=" + companyId + ", divisionId=" + divisionId + ", productSku=" + productSku
            + ", prmyUpc=" + prmyUpc + ", updPack=" + updPack + ", updVcf=" + updVcf + ", updSizeDesc=" + updSizeDesc
            + ", updSizeNum=" + updSizeNum + ", updSizeUoM=" + updSizeUoM + ", updItemUsageInd=" + updItemUsageInd
            + ", updItemUsageTypInd=" + updItemUsageTypInd + ", updDispItemCheck=" + updDispItemCheck
            + ", upditemDesc=" + upditemDesc + ", updWhseDesc=" + updWhseDesc + ", updSysDesc=" + updSysDesc
            + ", updinternetDesc=" + updinternetDesc + ", updPosDesc=" + updPosDesc + ", updDeptDetails="
            + updDeptDetails + ", updProdSrcCd=" + updProdSrcCd + ", updCost=" + updCost + ", upcUpdated=" + upcUpdated
            + ", grpCd=" + grpCd + ", ctgryCd=" + ctgryCd + ", classCd=" + classCd + ", sbClassCd=" + sbClassCd
            + ", sbSubClassCd=" + sbSubClassCd + ", smicDesc=" + smicDesc + ", privateLabel=" + privateLabel
            + ", conVTeamCmnt=" + conVTeamCmnt + ", augCompletionInd=" + augCompletionInd + ", convTeamCmnt="
            + convTeamCmnt + "]";
    }
    public String getProductSku() {
        // TODO Auto-generated method stub
        return null;
    }
    public void setProductSku(String productSku) {
        this.productSku = productSku;
    }
   }
