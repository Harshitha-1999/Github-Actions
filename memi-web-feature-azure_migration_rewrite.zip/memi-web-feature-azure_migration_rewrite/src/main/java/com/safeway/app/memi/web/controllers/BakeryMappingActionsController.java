package com.safeway.app.memi.web.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryResponseVO;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.services.BakeryMappingServices;
import com.safeway.app.memi.domain.util.BakeryActionValidations;



/**
 ****************************************************************************
 * NAME			: BakeryMappingActionsController 
 * 
 * DESCRIPTION	: BakeryMappingActionsController is the controller class for performing 
 * 				  different actions in bakery mapping screen.
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U47849
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Mar 07, 2018  - Initial Creation
 * *************************************************************************
 */

@Controller
@RequestMapping("/bakery")
public class BakeryMappingActionsController {
	private static final Logger LOG = LoggerFactory.getLogger(BakeryMappingActionsController.class);

    @Autowired
    private BakeryMappingServices bakeryMappingServices;
    
    @Autowired
    private BakeryActionValidations bakeryActionValidations;

    
    /**
    * Method for bakery actions
 * @param BakerySearchRequestVO 
     * @throws Exception 
    */
    
    @RequestMapping(value = "/bakeryactions", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody BakeryMappingRequestWrapper bakeryAction(@RequestBody BakeryMappingRequestWrapper mappingRequest) throws Exception {
    	LOG.info("Started Fetching BAkERy Actions");

    	String actionSuccess ="0";
 			List<String> validateActionsResult = bakeryActionValidations.
 					validateActions( mappingRequest.getMappingrequestBuyer(),mappingRequest.getMappingrequestSeller());
 			LOG.debug("Completed Fetching all the " +validateActionsResult.size()+"validate Actions Results");
 			List<String> duplicateList = bakeryMappingServices.duplicateCheckOnMappedItems(mappingRequest.getMappingrequestBuyer());
 			LOG.debug("Completed mapping all the " +duplicateList.size()+"duplicate Lists");

 			/* validates the mapping request objects */
 			if (duplicateList!=null && !duplicateList.isEmpty()) {
 				validateActionsResult.add("Already mapped sources or targets are selected");
 				validateActionsResult.addAll(duplicateList );
 				mappingRequest.setErrorMessages(validateActionsResult);
 			} else if (validateActionsResult == null || validateActionsResult.isEmpty()) {
 				
 				bakeryMappingServices.performAction(mappingRequest);
 				validateActionsResult=new ArrayList<>();
 				validateActionsResult.add("Mapped succesfully");
 				actionSuccess ="1";
 				mappingRequest.setErrorMessages(validateActionsResult);
 			} 
 			else
 			{
 				mappingRequest.setErrorMessages(validateActionsResult);
 			}
 			

 			/* Loads source and target data based on existing search inputs */
 			if (mappingRequest.getSourceSearchRequest() != null && actionSuccess.equalsIgnoreCase("1") ) {
 				BakeryResponseVO bakeryResponseVO  = bakeryMappingServices
 						.listBakerySKUItems(mappingRequest.getSourceSearchRequest());
 				mappingRequest.setBakerySKUSearchResults(bakeryResponseVO.getBakerySkuSearchResults());
 				if(bakeryResponseVO.getSourceCount()!=null){
 	 				mappingRequest.setSourceCount(bakeryResponseVO.getSourceCount()); 					
 				}
 			}
 			/* Restrict target loading in case of add or inherit map performed*/
 			boolean targetLoad =false; 
			for(int i=0; i<  mappingRequest.getMappingrequestBuyer().size() && !targetLoad ; i++ )
			{  
				if( mappingRequest.getMappingrequestBuyer().get(i).getMappingType().equals("ADD_MAP")||
						 mappingRequest.getMappingrequestBuyer().get(i).getMappingType().equals("INHERIT_MAP"))
				{
					targetLoad=true;
					break;
				}
				
			}
 			if (mappingRequest.getTargetBuyerSearchRequest() != null && targetLoad && actionSuccess.equalsIgnoreCase("1")) {
 				BakeryResponseVO bakeryResponseBuyerCICVO  = bakeryMappingServices
 						.listBakeryCICItems(mappingRequest.getTargetBuyerSearchRequest());
 				mappingRequest.setBakeryBuyerCICSearchResults(bakeryResponseBuyerCICVO.getBakeryCicSearchResults());
 				mappingRequest.setTargetBuyerCount(bakeryResponseBuyerCICVO.getTargetCount());
 				LOG.debug("Completed mapping bakery Response Buyer ");

 				
 			}
 			if (mappingRequest.getTargetSellerSearchRequest() != null && targetLoad && actionSuccess.equalsIgnoreCase("1")) {
 				BakeryResponseVO bakeryResponseSellerCICVO  = bakeryMappingServices
 						.listBakeryCICItems(mappingRequest.getTargetSellerSearchRequest());
 				mappingRequest.setBakerySellerCICSearchResults(bakeryResponseSellerCICVO.getBakeryCicSearchResults());
 				mappingRequest.setTargetSellerCount(bakeryResponseSellerCICVO.getTargetCount());
 				LOG.debug("Completed mapping bakery Response Seller ");

 				
 			}
 		
 		mappingRequest.setActionSuccessStatus(Integer.parseInt(actionSuccess));
 		LOG.info("Completed Fetching  the Bakery actions");
 		return mappingRequest;
 	   
    }

    @RequestMapping(value = "/forcenew",  method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody Map<String,String> perishableActionForceNew(@RequestBody List<BakeryMappingRequest> bakeryMappingRequests) {
 		LOG.info("Started Execution for perishable Action Force New");

    	Map<String,String> result =new HashMap<>();
    	String message = bakeryMappingServices.saveForceNewInPerishableMapping(bakeryMappingRequests);
    	result.put("actionresult", message);
 		LOG.info("Completed Execution for"+result.size()+" perishable Action Force New");

    	return result;
    }
    
    @RequestMapping(value = "/createNewCic", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody Map<String, String> createCic(
    		@RequestBody List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
 	   return  bakeryMappingServices.createNewCic(displayItemCreateMatchCicDto);
    }

    @RequestMapping(value = "/forcenewupdate",  method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String perishableActionForceNewUpdate(@RequestBody BakeryMappingRequest bakeryMappingRequest) {
 	   return bakeryMappingServices.updateForceNewInPerishableMapping(bakeryMappingRequest);
    }

    
    
}
