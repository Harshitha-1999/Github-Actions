/* **************************************************************************
 * Copyright 2017 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.domain.dtos.response;
/* ***************************************************************************
 * NAME         : DivisionDto
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Safeway IT
 *
 * REVISION HISTORY
 *
 * Initial creation for MEMD
 *
 ***************************************************************************/
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value = { "createTsForSort", "lastUpdateTsForSort" })
public class DivisionDto {

    private String divisionID;
    private String divisionNm;
    private String divisionLglNm;
    private String companyID;


    @Override
    public String toString() {
        return "Division [divisionID=" + divisionID + ", divisionNm=" + divisionNm + "]";
    }


	public String getDivisionID() {
		return divisionID;
	}


	public void setDivisionID(String divisionID) {
		this.divisionID = divisionID;
	}


	public String getDivisionNm() {
		return divisionNm;
	}


	public void setDivisionNm(String divisionNm) {
		this.divisionNm = divisionNm;
	}


	public String getDivisionLglNm() {
		return divisionLglNm;
	}


	public void setDivisionLglNm(String divisionLglNm) {
		this.divisionLglNm = divisionLglNm;
	}


	public String getCompanyID() {
		return companyID;
	}


	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}
}