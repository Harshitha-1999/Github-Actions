package com.safeway.app.memi.domain.dtos.response;

public class MultiUnitSourceTargetSearchRequest {

	private String companyId;
	private String divisionId;

	private String srcItemDesc;
	private String srcVendName;
	private String srcprodHierarchyLvl1Cd;
	private String srcprodHierarchyLvl2Cd;
	private String srcprodHierarchyLvl3Cd;
	private Character srcMultiUnitFlag;

	private String tarItemDesc;
	private String tarVendorName;
	private String tarGrpCd;
	private String tarCtgryCd;
	private String tarClsCd;
	private String tarSbClsCd;
	private String tarSubSbClass;

	private Character itemDescFlag;
	private Character venderNameFlag;
	private Character hierarchyOrSmicFlag;
	private String matchIndicator;
	
	private String srcProductSKU;
	private Character productSKUsearchFlag;
	
	private String targetCIC;
	private Character targetCICsearchFlag;
	
	

	public String getMatchIndicator() {
		return matchIndicator;
	}

	public void setMatchIndicator(String matchIndicator) {
		this.matchIndicator = matchIndicator;
	}

	public Character getItemDescFlag() {
		return itemDescFlag;
	}

	public void setItemDescFlag(Character itemDescFlag) {
		this.itemDescFlag = itemDescFlag;
	}

	public Character getVenderNameFlag() {
		return venderNameFlag;
	}

	public void setVenderNameFlag(Character venderNameFlag) {
		this.venderNameFlag = venderNameFlag;
	}

	public Character getHierarchyOrSmicFlag() {
		return hierarchyOrSmicFlag;
	}

	public void setHierarchyOrSmicFlag(Character hierarchyOrSmicFlag) {
		this.hierarchyOrSmicFlag = hierarchyOrSmicFlag;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getSrcItemDesc() {
		return srcItemDesc;
	}

	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}

	public String getSrcVendName() {
		return srcVendName;
	}

	public void setSrcVendName(String srcVendName) {
		this.srcVendName = srcVendName;
	}

	public String getSrcprodHierarchyLvl1Cd() {
		return srcprodHierarchyLvl1Cd;
	}

	public void setSrcprodHierarchyLvl1Cd(String srcprodHierarchyLvl1Cd) {
		this.srcprodHierarchyLvl1Cd = srcprodHierarchyLvl1Cd;
	}

	public String getSrcprodHierarchyLvl2Cd() {
		return srcprodHierarchyLvl2Cd;
	}

	public void setSrcprodHierarchyLvl2Cd(String srcprodHierarchyLvl2Cd) {
		this.srcprodHierarchyLvl2Cd = srcprodHierarchyLvl2Cd;
	}

	public String getSrcprodHierarchyLvl3Cd() {
		return srcprodHierarchyLvl3Cd;
	}

	public void setSrcprodHierarchyLvl3Cd(String srcprodHierarchyLvl3Cd) {
		this.srcprodHierarchyLvl3Cd = srcprodHierarchyLvl3Cd;
	}

	public Character getSrcMultiUnitFlag() {
		return srcMultiUnitFlag;
	}

	public void setSrcMultiUnitFlag(Character srcMultiUnitFlag) {
		this.srcMultiUnitFlag = srcMultiUnitFlag;
	}

	public String getTarItemDesc() {
		return tarItemDesc;
	}

	public void setTarItemDesc(String tarItemDesc) {
		this.tarItemDesc = tarItemDesc;
	}

	public String getTarVendorName() {
		return tarVendorName;
	}

	public void setTarVendorName(String tarVendorName) {
		this.tarVendorName = tarVendorName;
	}

	public String getTarGrpCd() {
		return tarGrpCd;
	}

	public void setTarGrpCd(String tarGrpCd) {
		this.tarGrpCd = tarGrpCd;
	}

	public String getTarCtgryCd() {
		return tarCtgryCd;
	}

	public void setTarCtgryCd(String tarCtgryCd) {
		this.tarCtgryCd = tarCtgryCd;
	}

	public String getTarClsCd() {
		return tarClsCd;
	}

	public void setTarClsCd(String tarClsCd) {
		this.tarClsCd = tarClsCd;
	}

	public String getTarSbClsCd() {
		return tarSbClsCd;
	}

	public void setTarSbClsCd(String tarSbClsCd) {
		this.tarSbClsCd = tarSbClsCd;
	}

	public String getTarSubSbClass() {
		return tarSubSbClass;
	}

	public void setTarSubSbClass(String tarSubSbClass) {
		this.tarSubSbClass = tarSubSbClass;
	}

	@Override
	public String toString() {
		return "MultiUnitSourceTargetSearchRequest [companyId=" + companyId
				+ ", divisionId=" + divisionId + ", srcItemDesc=" + srcItemDesc
				+ ", srcVendName=" + srcVendName + ", srcprodHierarchyLvl1Cd="
				+ srcprodHierarchyLvl1Cd + ", srcprodHierarchyLvl2Cd="
				+ srcprodHierarchyLvl2Cd + ", srcprodHierarchyLvl3Cd="
				+ srcprodHierarchyLvl3Cd + ", srcMultiUnitFlag="
				+ srcMultiUnitFlag + ", tarItemDesc=" + tarItemDesc
				+ ", tarVendorName=" + tarVendorName + ", tarGrpCd=" + tarGrpCd
				+ ", tarCtgryCd=" + tarCtgryCd + ", tarClsCd=" + tarClsCd
				+ ", tarSbClsCd=" + tarSbClsCd + ", tarSubSbClass="
				+ tarSubSbClass + ", itemDescFlag=" + itemDescFlag
				+ ", venderNameFlag=" + venderNameFlag
				+ ", hierarchyOrSmicFlag=" + hierarchyOrSmicFlag
				+ ", matchIndicator=" + matchIndicator + "]";
	}

	public String getSrcProductSKU() {
		return srcProductSKU;
	}

	public void setSrcProductSKU(String srcProductSKU) {
		this.srcProductSKU = srcProductSKU;
	}

	public Character getProductSKUsearchFlag() {
		return productSKUsearchFlag;
	}

	public void setProductSKUsearchFlag(Character productSKUsearch) {
		this.productSKUsearchFlag = productSKUsearch;
	}

	public String getTargetCIC() {
		return targetCIC;
	}

	public void setTargetCIC(String targetCIC) {
		this.targetCIC = targetCIC;
	}

	public Character getTargetCICsearchFlag() {
		return targetCICsearchFlag;
	}

	public void setTargetCICsearchFlag(Character targetCICsearchFlag) {
		this.targetCICsearchFlag = targetCICsearchFlag;
	}

}
