package com.safeway.app.memi.domain.dtos.response;

public class DepartmentDto {
	private String departmentName;
	private String departmentCode;
	private String prodHierarchyLvl1;
	private String prodHierarchyLvl2;
	private String prodHierarchyLvl3;
	private String hierarchyLvlName;
	private String hierarchyLvlDesc;
	
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentCode() {
		return departmentCode;
	}
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}
	public String getProdHierarchyLvl1() {
		return prodHierarchyLvl1;
	}
	public void setProdHierarchyLvl1(String prodHierarchyLvl1) {
		this.prodHierarchyLvl1 = prodHierarchyLvl1;
	}
	public String getProdHierarchyLvl2() {
		return prodHierarchyLvl2;
	}
	public void setProdHierarchyLvl2(String prodHierarchyLvl2) {
		this.prodHierarchyLvl2 = prodHierarchyLvl2;
	}
	public String getProdHierarchyLvl3() {
		return prodHierarchyLvl3;
	}
	public void setProdHierarchyLvl3(String prodHierarchyLvl3) {
		this.prodHierarchyLvl3 = prodHierarchyLvl3;
	}
	public String getHierarchyLvlName() {
		return hierarchyLvlName;
	}
	public void setHierarchyLvlName(String hierarchyLvlName) {
		this.hierarchyLvlName = hierarchyLvlName;
	}
	public String getHierarchyLvlDesc() {
		return hierarchyLvlDesc;
	}
	public void setHierarchyLvlDesc(String hierarchyLvlDesc) {
		this.hierarchyLvlDesc = hierarchyLvlDesc;
	}

}
