/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

/**
 ****************************************************************************
 * NAME : PerishableCICSearchResults 
 * 
 * DESCRIPTION :PerishableCICSearchResults is the class to store the search data of target item
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */
public class PerishableCICSearchResults {
	
	private BigDecimal cic;
	private String itemDesc;
	private BigDecimal vcf;
	private BigDecimal pack;
	private String size;
	private char usage;
	private char display;
	private String size_Uom;
	private String [] upc;
	private BigDecimal salesValue;
	private String rog;
	private String createdOn;
	private Calendar lastSalesDate;
	private Calendar lastShipDate;
	private String mappingStatus;
	private BigDecimal packWhse;
	private String ethnicCode;	
	private BigDecimal upcCountry;
	private BigDecimal upcSystem;
	private BigDecimal upcManuf;
	private char productSourceInd;
	private char statusCorp;
	private String smic;
	private String deptName;
	private BigDecimal plu;
	private String whseDsd;
	private BigDecimal ring;
	private char itemUSageInd;
	private char farmOrWild;
	
	private String[] vendor_detail;
	private String voc;
	private String sign_scale;
	
	
	/**
	 * @return the cic
	 */
	public BigDecimal getCic() {
		return cic;
	}
	/**
	 * @param cic the cic to set
	 */
	public void setCic(BigDecimal cic) {
		this.cic = cic;
	}
	/**
	 * @return the itemDesc
	 */
	public String getItemDesc() {
		return itemDesc;
	}
	/**
	 * @param itemDesc the itemDesc to set
	 */
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	/**
	 * @return the vcf
	 */
	public BigDecimal getVcf() {
		return vcf;
	}
	/**
	 * @param vcf the vcf to set
	 */
	public void setVcf(BigDecimal vcf) {
		this.vcf = vcf;
	}
	/**
	 * @return the pack
	 */
	public BigDecimal getPack() {
		return pack;
	}
	/**
	 * @param pack the pack to set
	 */
	public void setPack(BigDecimal pack) {
		this.pack = pack;
	}
	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}
	/**
	 * @return the usage
	 */
	public char getUsage() {
		return usage;
	}
	/**
	 * @param usage the usage to set
	 */
	public void setUsage(char usage) {
		this.usage = usage;
	}

	/**
	 * @return the display
	 */
	public char getDisplay() {
		return display;
	}
	/**
	 * @param display the display to set
	 */
	public void setDisplay(char display) {
		this.display = display;
	}
	/**
	 * @return the decSize
	 */
	

	/**
	 * @return the salesValue
	 */
	public BigDecimal getSalesValue() {
		return salesValue;
	}
	/**
	 * @param salesValue the salesValue to set
	 */
	public void setSalesValue(BigDecimal salesValue) {
		this.salesValue = salesValue;
	}
	/**
	 * @return the createdOn
	 */
	public String getCreatedOn() {
		return createdOn;
	}
	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the rog
	 */
	public String getRog() {
		return rog;
	}
	/**
	 * @param rog the rog to set
	 */
	public void setRog(String rog) {
		this.rog = rog;
	}
	/**
	 * @return the lastSalesDate
	 */
	public Calendar getLastSalesDate() {
		return lastSalesDate;
	}
	/**
	 * @param lastSalesDate the lastSalesDate to set
	 */
	public void setLastSalesDate(Calendar lastSalesDate) {
		this.lastSalesDate = lastSalesDate;
	}
	/**
	 * @return the lastShipDate
	 */
	public Calendar getLastShipDate() {
		return lastShipDate;
	}
	/**
	 * @param lastShipDate the lastShipDate to set
	 */
	public void setLastShipDate(Calendar lastShipDate) {
		this.lastShipDate = lastShipDate;
	}
	/**
	 * @return the mappingStatus
	 */
	public String getMappingStatus() {
		return mappingStatus;
	}
	/**
	 * @param mappingStatus the mappingStatus to set
	 */
	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}
	/**
	 * @return the packWhse
	 */
	public BigDecimal getPackWhse() {
		return packWhse;
	}
	/**
	 * @param packWhse the packWhse to set
	 */
	public void setPackWhse(BigDecimal packWhse) {
		this.packWhse = packWhse;
	}
	/**
	 * @return the ethnicCode
	 */
	public String getEthnicCode() {
		return ethnicCode;
	}
	/**
	 * @param ethnicCode the ethnicCode to set
	 */
	public void setEthnicCode(String ethnicCode) {
		this.ethnicCode = ethnicCode;
	}
	
	/**
	 * @return the upcCountry
	 */
	public BigDecimal getUpcCountry() {
		return upcCountry;
	}
	/**
	 * @param upcCountry the upcCountry to set
	 */
	public void setUpcCountry(BigDecimal upcCountry) {
		this.upcCountry = upcCountry;
	}
	/**
	 * @return the upcSystem
	 */
	public BigDecimal getUpcSystem() {
		return upcSystem;
	}
	/**
	 * @param upcSystem the upcSystem to set
	 */
	public void setUpcSystem(BigDecimal upcSystem) {
		this.upcSystem = upcSystem;
	}
	/**
	 * @return the upcManuf
	 */
	public BigDecimal getUpcManuf() {
		return upcManuf;
	}
	/**
	 * @param upcManuf the upcManuf to set
	 */
	public void setUpcManuf(BigDecimal upcManuf) {
		this.upcManuf = upcManuf;
	}
	/**
	 * @return the productSourceInd
	 */
	public char getProductSourceInd() {
		return productSourceInd;
	}
	/**
	 * @param productSourceInd the productSourceInd to set
	 */
	public void setProductSourceInd(char productSourceInd) {
		this.productSourceInd = productSourceInd;
	}

	/**
	 * @return the statusCorp
	 */
	public char getStatusCorp() {
		return statusCorp;
	}
	/**
	 * @param statusCorp the statusCorp to set
	 */
	public void setStatusCorp(char statusCorp) {
		this.statusCorp = statusCorp;
	}
	/**
	 * @return the smic
	 */
	public String getSmic() {
		return smic;
	}
	/**
	 * @param smic the smic to set
	 */
	public void setSmic(String smic) {
		this.smic = smic;
	}
	/**
	 * @return the deptName
	 */
	public String getDeptName() {
		return deptName;
	}
	/**
	 * @param deptName the deptName to set
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	/**
	 * @return the plu
	 */
	public BigDecimal getPlu() {
		return plu;
	}
	/**
	 * @param plu the plu to set
	 */
	public void setPlu(BigDecimal plu) {
		this.plu = plu;
	}
	/**
	 * @return the upc
	 */
	public String[] getUpc() {
		return upc;
	}
	/**
	 * @param upc the upc to set
	 */
	public void setUpc(String[] upc) {
		this.upc = upc;
	}
	public String getWhseDsd() {
		return whseDsd;
	}
	public void setWhseDsd(String whseDsd) {
		this.whseDsd = whseDsd;
	}

	/**
	 * @return the ring
	 */
	public BigDecimal getRing() {
		return ring;
	}
	/**
	 * @param ring the ring to set
	 */
	public void setRing(BigDecimal ring) {
		this.ring = ring;
	}
	public char getItemUSageInd() {
		return itemUSageInd;
	}
	public void setItemUSageInd(char itemUSageInd) {
		this.itemUSageInd = itemUSageInd;
	}
	public char getFarmOrWild() {
		return farmOrWild;
	}
	public void setFarmOrWild(char farmOrWild) {
		this.farmOrWild = farmOrWild;
	}
	public String[] getVendor_detail() {
		return vendor_detail;
	}
	public void setVendor_detail(String[] vendor_detail) {
		this.vendor_detail = vendor_detail;
	}
	public String getVoc() {
		return voc;
	}
	public void setVoc(String voc) {
		this.voc = voc;
	}
	public String getSign_scale() {
		return sign_scale;
	}
	public void setSign_scale(String sign_scale) {
		this.sign_scale = sign_scale;
	}
	public String getSize_Uom() {
		return size_Uom;
	}
	public void setSize_Uom(String size_Uom) {
		this.size_Uom = size_Uom;
	}
	
	
	
	
}
