/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;


import java.util.List;
import java.util.Map;

import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakeryMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryResponseVO;
import com.safeway.app.memi.domain.dtos.response.BakerySKUSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakerySearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
/**
 ****************************************************************************
 * NAME			: BakeryMappingServices 
 * 
 * DESCRIPTION	: BakeryMappingServices is the service  class for performing 
 * 				  search and filter operations for mapping screen and mapped screen
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Mar 05, 2018  - Initial Creation
 * *************************************************************************
 */

public interface BakeryMappingServices {
	
	/**
	 * Method to search bakery source SKU data
	 * @param bakerySearchRequestVO
	 * @return
	 * @throws Exception 
	 */
	public BakeryResponseVO listBakerySKUItems(BakerySearchRequestVO bakerySearchRequestVO) throws Exception;


	
	/**
	 * Method to search  seller bakery target CIC items
	 * @param bakerySearchRequestVO
	 * @return
	 * @throws Exception 
	 */

	public BakeryResponseVO listBakeryCICItems(BakerySearchRequestVO bakerySearchRequestVO) throws Exception;

	/**
	 * Method to search target CIC data
	 * @param searchRequestVO
	 * @return
	 */
	public void performAction(BakeryMappingRequestWrapper mappingRequest);




	public List<String> duplicateCheckOnMappedItems(
			List<BakeryMappingRequest> bakeryMappingRequest);


	public String saveForceNewInPerishableMapping(
			List<BakeryMappingRequest> bakeryMappingRequests);


	public Map<String, String> createNewCic(
			List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto);


	public List<BakeryMappedResultWrapper> listMappedData(
			BakerySearchRequestVO mappedSearchRequest);

	public String updateForceNewInPerishableMapping(BakeryMappingRequest bakeryMappingRequest);



	public List<BakeryCICSearchResults> getSuggestedTargetList(
			PerishableMatchingTargetInputVO upcDetails);



	public PerishableAdditionalDetailsDto getadditionalRetailscanDetails(String corpItemCd);



	public Map fetchTargetEditITems(ManualMatchAdtnlFieldLoadInputVo inputVo);



	
	
}
