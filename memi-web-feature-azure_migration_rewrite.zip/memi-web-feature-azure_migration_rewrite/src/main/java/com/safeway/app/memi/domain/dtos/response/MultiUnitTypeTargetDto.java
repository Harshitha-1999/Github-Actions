package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Set;

public class MultiUnitTypeTargetDto {

	private String companyId;
	private String divisionId;
	private BigDecimal corpItemCd;
	private String itemDesc;
	private BigDecimal packWhse;
	private BigDecimal vendConvFctr;
	private String size;
	private String targetDepartment;
	private String smicCode;
	private String itemTypeWhseDsd;
	private BigDecimal cost;
	private String vendorName;
	private Set<BigDecimal> unitType;
	private String caseUpc;
	private String retailSection;
	private String corpStatus;
	private BigDecimal innerPack;
	private String vendorNumber;
	private BigDecimal upcCountry;
	private BigDecimal upcSystem;
	private BigDecimal upcManuf;
	private BigDecimal upcSales;
	private String upc;
	private Set<String> upcList;
	private Set<String> deptNameList;
	private Set<String> upcWithUnitType;
	private String matchIndicator;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public BigDecimal getCorpItemCd() {
		return corpItemCd;
	}

	public void setCorpItemCd(BigDecimal corpItemCd) {
		this.corpItemCd = corpItemCd;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public BigDecimal getPackWhse() {
		return packWhse;
	}

	public void setPackWhse(BigDecimal packWhse) {
		this.packWhse = packWhse;
	}

	public BigDecimal getVendConvFctr() {
		return vendConvFctr;
	}

	public void setVendConvFctr(BigDecimal vendConvFctr) {
		this.vendConvFctr = vendConvFctr;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getTargetDepartment() {
		return targetDepartment;
	}

	public void setTargetDepartment(String targetDepartment) {
		this.targetDepartment = targetDepartment;
	}

	public String getSmicCode() {
		return smicCode;
	}

	public void setSmicCode(String smicCode) {
		this.smicCode = smicCode;
	}

	public String getItemTypeWhseDsd() {
		return itemTypeWhseDsd;
	}

	public void setItemTypeWhseDsd(String itemTypeWhseDsd) {
		this.itemTypeWhseDsd = itemTypeWhseDsd;
	}

	public BigDecimal getCost() {
		return cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Set<BigDecimal> getUnitType() {
		return unitType;
	}

	public void setUnitType(Set<BigDecimal> unitType) {
		this.unitType = unitType;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public String getRetailSection() {
		return retailSection;
	}

	public void setRetailSection(String retailSection) {
		this.retailSection = retailSection;
	}

	public String getCorpStatus() {
		return corpStatus;
	}

	public void setCorpStatus(String corpStatus) {
		this.corpStatus = corpStatus;
	}

	public BigDecimal getInnerPack() {
		return innerPack;
	}

	public void setInnerPack(BigDecimal innerPack) {
		this.innerPack = innerPack;
	}

	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	public BigDecimal getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(BigDecimal upcCountry) {
		this.upcCountry = upcCountry;
	}

	public BigDecimal getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(BigDecimal upcSystem) {
		this.upcSystem = upcSystem;
	}

	public BigDecimal getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(BigDecimal upcManuf) {
		this.upcManuf = upcManuf;
	}

	public BigDecimal getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(BigDecimal upcSales) {
		this.upcSales = upcSales;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public Set<String> getUpcList() {
		return upcList;
	}

	public void setUpcList(Set<String> upcList) {
		this.upcList = upcList;
	}

	public Set<String> getDeptNameList() {
		return deptNameList;
	}

	public void setDeptNameList(Set<String> deptNameList) {
		this.deptNameList = deptNameList;
	}

	public Set<String> getUpcWithUnitType() {
		return upcWithUnitType;
	}

	public void setUpcWithUnitType(Set<String> upcWithUnitType) {
		this.upcWithUnitType = upcWithUnitType;
	}

	public String getMatchIndicator() {
		return matchIndicator;
	}

	public void setMatchIndicator(String matchIndicator) {
		this.matchIndicator = matchIndicator;
	}

	@Override
	public String toString() {
		return "MultiUnitTypeTargetDto [companyId=" + companyId
				+ ", divisionId=" + divisionId + ", corpItemCd=" + corpItemCd
				+ ", itemDesc=" + itemDesc + ", packWhse=" + packWhse
				+ ", vendConvFctr=" + vendConvFctr + ", size=" + size
				+ ", targetDepartment=" + targetDepartment + ", smicCode="
				+ smicCode + ", itemTypeWhseDsd=" + itemTypeWhseDsd + ", cost="
				+ cost + ", vendorName=" + vendorName + ", unitType="
				+ unitType + ", caseUpc=" + caseUpc + ", retailSection="
				+ retailSection + ", corpStatus=" + corpStatus + ", innerPack="
				+ innerPack + ", vendorNumber=" + vendorNumber
				+ ", upcCountry=" + upcCountry + ", upcSystem=" + upcSystem
				+ ", upcManuf=" + upcManuf + ", upcSales=" + upcSales
				+ ", upc=" + upc + ", upcList=" + upcList + ", deptNameList="
				+ deptNameList + ", upcWithUnitType=" + upcWithUnitType
				+ ", matchIndicator=" + matchIndicator + "]";
	}

}