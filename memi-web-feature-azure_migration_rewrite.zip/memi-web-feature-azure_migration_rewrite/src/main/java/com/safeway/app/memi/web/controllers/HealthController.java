package com.safeway.app.memi.web.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {
	private static final Logger LOGGER = LoggerFactory.getLogger(HealthController.class);

	@RequestMapping(value = "/healthCheck", method = RequestMethod.GET)
	public String health() {
		LOGGER.info("Request recieved for health check, Application is UP");
		return "MEMI App is up.";
	}
}