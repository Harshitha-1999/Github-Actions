package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : SizeUOMDetail 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Safeway IT  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  June 8, 2017 - Initial Creation
 * ************************************************************************/

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity class for Database table SQLDAT3_COUOMCDS.
 * 
 */
@Entity
@Table(name = "SQLDAT3_COUOMCDS", schema="SSIMSLAND")
public class SizeUOMDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "UOM_CODE")
	private String uomCode;

	@Column(name = "US_SIZE_UOM")
	private String uomCodeUS;

	public String getUomCode() {
		return uomCode;
	}

	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}

	public String getUomCodeUS() {
		return uomCodeUS;
	}

	public void setUomCodeUS(String uomCodeUS) {
		this.uomCodeUS = uomCodeUS;
	}

}
