package com.safeway.app.memi.domain.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultVOS;

@Component
public class LookUpExcelWriter {
	private static final Logger LOG = LoggerFactory
			.getLogger(LookUpExcelWriter.class);

	public static String[] headerRowColumnsSorceSide = { "Department","Item Description","Product SKU","UPC","VCF",
		"NumSize","Desc Size","UOM","PLU","Pack","Hier1 Name","Hier2 Name","Hier3 Name","ROG","Prod Src",
		"Supplier No","Exc CIC","Conv.Status Code","Conv.Status Sub Code"};
	
	public static String[] headerRowColumnsTargetSide={
		"CIC","Item Description","UPC","UPCInd","UnitType","DSTCentre","SizeDesc","DescSize","Division",
		"DescPack","SizeNum","Facility","SizeUOM","VCF","Size","PLU","PackWhse","PackRetail"		
	};
	
	Workbook wb;
	Sheet dataSheet;
	

	CellStyle fcHeaderSource,fcHeaderTarget;
	CellStyle fcEvenRow;
	CellStyle fcOddRow;
	
	public String writeIntoExcel(List<LookUpSearchResultVOS> searchResults,String filepath) {
		LOG.info("Execution started for writeIntoExcel");
		long start = System.currentTimeMillis();
		wb = new XSSFWorkbook();
		
		wb.setMissingCellPolicy(MissingCellPolicy.CREATE_NULL_AS_BLANK);
		fcHeaderSource = null;
		fcHeaderTarget = null;
		fcOddRow = null;
		fcEvenRow = null;
		
		dataSheet = wb.getSheet("SearchResults");
		if (dataSheet == null)
			dataSheet = wb.createSheet("SearchResults");

		int rowIndex = 0;
		Row header = dataSheet.createRow(rowIndex);
		int colIndex = 0;
		
		
		for (String headerString : headerRowColumnsSorceSide) {
			Cell cell = header.createCell(colIndex++);
			cell.setCellStyle(getSourceHeaderStyle());
			cell.setCellValue(headerString);
		}
		
		for (String headerString : headerRowColumnsTargetSide) {
			Cell cell = header.createCell(colIndex++);
			cell.setCellStyle(getTargetHeaderStyle());
			cell.setCellValue(headerString);
		}
		
		if(!searchResults.isEmpty())
		{
			for(LookUpSearchResultVOS resoultVo:searchResults)
			{
				colIndex = 0;
				Row row = dataSheet.createRow(++rowIndex);
				
				
				CellStyle rowStyle = getRowStyle(rowIndex);
				rowStyle.setWrapText(false);				
				
				/*source side*/
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_dept_name());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_item_description());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_prod_sku());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_upc());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getSrc_vcf()!=null ?resoultVo.getSrc_vcf().doubleValue(): Double.parseDouble("0") ));
				 createCell(row, colIndex++, rowStyle,(resoultVo.getSrc_numeric_size() != null ? resoultVo.getSrc_numeric_size().doubleValue(): Double.parseDouble("0") ));
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_desc_size());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_uom());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_plu());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getSrc_pack()!=null ?resoultVo.getSrc_pack().doubleValue(): Double.parseDouble("0") ));
				 createCell(row, colIndex++, rowStyle,resoultVo.getHier1_lvl_name());
				 createCell(row, colIndex++, rowStyle,resoultVo.getHier2_lvl_name());
				 createCell(row, colIndex++, rowStyle,resoultVo.getHier3_lvl_name());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_rog());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_whse_dsd());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_suplier_no()+"-"+resoultVo.getSrc_supplier_name());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getSrc_exc_cic()!=null ? resoultVo.getSrc_exc_cic().doubleValue() :Double.parseDouble("0")));
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_conv_st_cd());
				 createCell(row, colIndex++, rowStyle,resoultVo.getSrc_conv_st_sb_cd());
				 
				 /*target side*/
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_corp_item_cd()!=null ? resoultVo.getTgt_corp_item_cd().doubleValue() :Double.parseDouble("0") ) );
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_item_desc());
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_upc());
				 createCell(row, colIndex++, rowStyle, resoultVo.getTgt_item_usage_ind());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_unit_type()!=null ? resoultVo.getTgt_unit_type().doubleValue(): Double.parseDouble("0")));
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_dst_cntr());
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_urx_Size_desc());
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_wds_size_desc());
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_division());
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_wds_pack_desc());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_size_num()!=null ? resoultVo.getTgt_size_num().doubleValue(): Double.parseDouble("0") ));
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_facility());
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_uom());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_vcf() !=null ? resoultVo.getTgt_vcf().doubleValue(): Double.parseDouble("0")  ));
				 createCell(row, colIndex++, rowStyle,resoultVo.getTgt_cds_size());
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_plu_cd()!=null ? resoultVo.getTgt_plu_cd().doubleValue(): Double.parseDouble("0") ));
				 
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_pack_whse()!=null ? resoultVo.getTgt_pack_whse().doubleValue(): Double.parseDouble("0") ));
				 createCell(row, colIndex++, rowStyle,(resoultVo.getTgt_pack_Retail() !=null ?resoultVo.getTgt_pack_Retail().doubleValue(): Double.parseDouble("0") ));			
				
			}
			for (int ii = 0; ii < 39; ii++) {
				dataSheet.autoSizeColumn(ii);
			}
			
			
			
		}
		Date timesTamp =new Date();
		String fileName = "LookUpDownLoad"+timesTamp.getDate()+"-"+timesTamp.getMonth()+"-"+timesTamp.getYear()+".xlsx";
		File file = new File(filepath,fileName);
		
		// Write the output to a file
		
		try (FileOutputStream fileOut = new FileOutputStream(file)) {
			wb.write(fileOut);			
			fileOut.flush();
		
		} catch (IOException e) {
			LOG.error("Exception in generating the export to excel file"
					+ e.getMessage());
			System.exit(-1);
		}
		long end = System.currentTimeMillis();
		float sec = (end - start) / 1000F;
		LOG.info("Execution completed for writeIntoExcel {}",sec);
		
		return fileName;
		
	}
	
	
	private CellStyle getSourceHeaderStyle() {
		LOG.debug("Execution started for getSourceHeaderStyle");
		if (fcHeaderSource == null) {

			fcHeaderSource = wb.createCellStyle();

			XSSFCellStyle cs = (XSSFCellStyle) fcHeaderSource;
			cs.setFillForegroundColor(new XSSFColor(new Color(192, 192, 192)));

			Font f = wb.createFont();
			f.setColor(IndexedColors.BLUE.getIndex());
			f.setFontName("Calibri");
			//f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			f.setBold(true);
			fcHeaderSource.setFont(f);
			fcHeaderSource.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			fcHeaderSource.setBorderRight(BorderStyle.THIN);
			fcHeaderSource.setRightBorderColor(IndexedColors.BLACK.getIndex());
			fcHeaderSource.setBorderLeft(BorderStyle.THIN);
			fcHeaderSource.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			fcHeaderSource.setBorderTop(BorderStyle.THIN);
			fcHeaderSource.setTopBorderColor(IndexedColors.BLACK.getIndex());
			fcHeaderSource.setBorderBottom(BorderStyle.THIN);
			fcHeaderSource.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			
			
		}
		LOG.debug("Execution completed for getSourceHeaderStyle");
		return fcHeaderSource;
	}


	private CellStyle getTargetHeaderStyle() {
		LOG.debug("Execution started for getTargetHeaderStyle");
		if (fcHeaderTarget == null) {

			fcHeaderTarget = wb.createCellStyle();

			XSSFCellStyle cs = (XSSFCellStyle) fcHeaderTarget;
			cs.setFillForegroundColor(new XSSFColor(new Color(192, 192, 192)));

			Font f = wb.createFont();
			f.setColor(IndexedColors.BROWN.getIndex());
			f.setFontName("Calibri");
			//f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			f.setBold(true);
			
			fcHeaderTarget.setFont(f);
			fcHeaderTarget.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			fcHeaderTarget.setBorderRight(BorderStyle.THIN);
			fcHeaderTarget.setRightBorderColor(IndexedColors.BLACK.getIndex());
			fcHeaderTarget.setBorderLeft(BorderStyle.THIN);
			fcHeaderTarget.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			fcHeaderTarget.setBorderTop(BorderStyle.THIN);
			fcHeaderTarget.setTopBorderColor(IndexedColors.BLACK.getIndex());
			fcHeaderTarget.setBorderBottom(BorderStyle.THIN);
			fcHeaderTarget.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			
			
		}
		LOG.debug("Execution completed for getTargetHeaderStyle");
		return fcHeaderTarget;
	}
	private CellStyle getRowStyle(int rowIndex) {
		LOG.debug("Execution started for getRowStyle");
		if (fcOddRow == null) {
			fcOddRow = getRowStyleTemplate();
			XSSFCellStyle cs = (XSSFCellStyle) fcOddRow;
			cs.setFillForegroundColor(new XSSFColor(new Color(220, 230, 241)));
			fcOddRow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}
		if (fcEvenRow == null) {
			fcEvenRow = getRowStyleTemplate();
			XSSFCellStyle cs = (XSSFCellStyle) fcEvenRow;
			cs.setFillForegroundColor(new XSSFColor(new Color(255, 255, 255)));
			fcEvenRow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}

		if (rowIndex % 2 == 0) {
			LOG.debug("Execution completed for fcEvenRow");
			return fcEvenRow;
		}
		else
		{
			LOG.debug("Execution completed for fcOddRow");
			return fcOddRow;
		}
	}
	private CellStyle getRowStyleTemplate() {
		LOG.debug("Execution started for  CellStyle getRowStyleTemplate");
		CellStyle template = wb.createCellStyle();
		
	
		Font f = wb.createFont();
		f.setFontName("Calibri");
		//f.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		f.setBold(false);
		template.setFont(f);

		template.setBorderRight(BorderStyle.THIN);
		template.setRightBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderLeft(BorderStyle.THIN);
		template.setLeftBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderTop(BorderStyle.THIN);
		template.setTopBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderBottom(BorderStyle.THIN);
		template.setBottomBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setWrapText(true);
		LOG.debug("Execution completed for  CellStyle getRowStyleTemplate");
		
		return template;
	}
	public Cell createCell(Row row, int index, CellStyle cs, String value) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cs);
		cell.setCellValue(value);
		return cell;
	}
	public Cell createCell(Row row, int index, CellStyle cs, Double value) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cs);
		cell.setCellValue(value);
		return cell;
	}
	
}