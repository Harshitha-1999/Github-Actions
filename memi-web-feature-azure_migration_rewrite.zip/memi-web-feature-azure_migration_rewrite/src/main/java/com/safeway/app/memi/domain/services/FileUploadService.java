package com.safeway.app.memi.domain.services;

import com.safeway.app.memi.domain.dtos.response.ExcelFileRequest;

public interface FileUploadService {
	
	public String uploadExcel(ExcelFileRequest excelFileRequest) throws Exception;

}
