package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Date;



public class SalesData {
    
    private String newDate;
    
    private String lastShipDate;
    
    private String lastSaleDate;
    
    private BigDecimal totalSales;
    
    private BigDecimal casesOrdered;

	public String getNewDate() {
		return newDate;
	}

	public void setNewDate(String newDate) {
		this.newDate = newDate;
	}

	public String getLastShipDate() {
		return lastShipDate;
	}

	public void setLastShipDate(String lastShipDate) {
		this.lastShipDate = lastShipDate;
	}

	public String getLastSaleDate() {
		return lastSaleDate;
	}

	public void setLastSaleDate(String lastSaleDate) {
		this.lastSaleDate = lastSaleDate;
	}

	public BigDecimal getTotalSales() {
		return totalSales;
	}

	public void setTotalSales(BigDecimal totalSales) {
		this.totalSales = totalSales;
	}

	public BigDecimal getCasesOrdered() {
		return casesOrdered;
	}

	public void setCasesOrdered(BigDecimal casesOrdered) {
		this.casesOrdered = casesOrdered;
	}

	@Override
	public String toString() {
		return "SalesData [newDate=" + newDate + ", lastShipDate="
				+ lastShipDate + ", lastSaleDate=" + lastSaleDate
				+ ", totalSales=" + totalSales + ", casesOrdered="
				+ casesOrdered + "]";
	}

	
    
    

}