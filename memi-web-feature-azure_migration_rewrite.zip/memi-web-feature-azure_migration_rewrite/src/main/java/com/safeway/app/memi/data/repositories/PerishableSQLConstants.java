package com.safeway.app.memi.data.repositories;

public class PerishableSQLConstants {

	
	
	
	private PerishableSQLConstants() {
	
	}
	
	
	/*Filter query*/
	public static final String DEPARTMENT = "department";
	public static final String ITEM_DESCRIPTION = "itemDescription";
	public static final String PLU = "plu";
	public static final String PLU_CAPS = "PLU";
	public static final String SLU = "slu";
	public static final String ITEM_TYPE = "itemType";
	public static final String UPC = "upc";
	public static final String MAPPING_STATUS = "mappingStatus";
	public static final String SEARCH_TYPE= "searchType";
	public static final String SEARCH_VALUE = "searchValue";
	public static final String  AND  = " AND ";
	public static final String DIVISION_ID = "DIVISION_ID";
	public static final String SYSTEM2  = "System2";
	public static final String SYSTEM4 = "System4";
	public static final String MAPPING_TYPE = "MappingType";
	public static final String COMPANY_ID = "companyID";
	public static final String FETCH_SIZE="org.hibernate.fetchSize";
	public static final String LIKE_UPPER=" like UPPER('";
	public static final String TO_BE_MAPPED="TO_BE_MAPPED";
	public static final String SHOW_ALL="SHOW_ALL";
	public static final String IS_NULL=" is null "; 
	public static final String DIVISION_ID_SMALL_CASE="divisionID";
	public static final String AND_P_MACHING_STATUS_CD=" AND (P.MATCHING_STATUS_CD ";
	public static final String OPERATOR="OPERATOR";
	public static final String HIERARCHY_LEVEL_NM = "HIERARCHY_LEVEL_NM";
	public static final String COMPANY_ID_EQUALITY =" WHERE TO_NUMBER(COMPANY_ID) =  ";
	public static final String DIVISION_ID_EQUALITY =" AND TO_NUMBER(DIVISION_ID) = ";
	public static final String QUERY_TIMEOUT="javax.persistence.query.timeout";
	public static final String MARK_AS_DEAD ="MARK_AS_DEAD";
	public static final String MAPPED ="MAPPED";
	public static final String CONVERTED ="CONVERTED";
	
	/*reserve action type and status*/
	public static final String RESERVED = "RESERVED";
	public static final String AWAITING_CIC = "AWAITING_NEW_CIC";
	public static final String AWAITING_DIVISION = "AWAITING_DIVISION_INPUT";
	public static final String OTHER = "OTHERS";
	
	
	
}
