package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : SourceItemCIC 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 9, 2017 sgang06 - Initial Creation
 * ************************************************************************/


import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Entity class for Database table ITEM_CONV_NEW_CIC_DATA_MGMT.
 * 
 */
@Entity
@Table(name = "ITEM_CONV_NEW_CIC_DATA_MGMT", schema="ECFLAND")
@NamedQuery(name = "SourceItemCIC.findAll", query = "SELECT s FROM SourceItemCIC s")
public class SourceItemCIC implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SourceItemCICPk sourceItemCICPk;

	public SourceItemCICPk getSourceItemCICPk() {
		return sourceItemCICPk;
	}

	public void setSourceItemCICPk(SourceItemCICPk sourceItemCICPk) {
		this.sourceItemCICPk = sourceItemCICPk;
	}
	
	

}