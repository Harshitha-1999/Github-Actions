package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Set;

public class PerishableMappingRetailScanDetails {

	private BigDecimal ringType;
	private char dstStatus;
	private BigDecimal vendCost;
	private String dstCntr;
	private Set rogs; 
	private String vProd;
	
	public BigDecimal getRingType() {
		return ringType;
	}
	public void setRingType(BigDecimal ringType) {
		this.ringType = ringType;
	}
	public char getDstStatus() {
		return dstStatus;
	}
	public void setDstStatus(char dstStatus) {
		this.dstStatus = dstStatus;
	}
	public BigDecimal getVendCost() {
		return vendCost;
	}
	public void setVendCost(BigDecimal vendCost) {
		this.vendCost = vendCost;
	}
	public String getDstCntr() {
		return dstCntr;
	}
	public void setDstCntr(String dstCntr) {
		this.dstCntr = dstCntr;
	}
	public Set getRogs() {
		return rogs;
	}
	public void setRogs(Set rogs) {
		this.rogs = rogs;
	}
	public String getvProd() {
		return vProd;
	}
	public void setvProd(String vProd) {
		this.vProd = vProd;
	}
	

}
