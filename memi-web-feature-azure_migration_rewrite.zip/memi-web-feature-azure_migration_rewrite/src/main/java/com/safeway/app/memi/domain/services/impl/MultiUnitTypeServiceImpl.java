package com.safeway.app.memi.domain.services.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.ItemConvMultiUnitType;
import com.safeway.app.memi.data.entities.ItemConvMultiUnitTypePk;
import com.safeway.app.memi.data.repositories.ItemConvMultiUnitTypeRepository;
import com.safeway.app.memi.data.repositories.MultiUnitSQLRepository;
import com.safeway.app.memi.domain.adapters.MultiUnitAdapter;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceTargetSearchRequest;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSrcTargetDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitTypeTargetDto;
import com.safeway.app.memi.domain.services.MultiUnitTypeService;

@Service("MultiUnitTypeService")
public class MultiUnitTypeServiceImpl implements MultiUnitTypeService {
	private static final Logger LOG  = LoggerFactory.getLogger(MultiUnitTypeServiceImpl.class);
	
	 @Autowired
	 private ItemConvMultiUnitTypeRepository multiUnitTypeRepo;
	 
	 @Autowired
	 private MultiUnitSQLRepository multiunitSQLRepo;
	 private MultiUnitAdapter multiUnitAdapter = new MultiUnitAdapter();
	 
			
	@Override
	public MultiUnitSrcTargetDto fetchMultiUnitData(String companyId,String divisionId,String matchIndicator) {
		LOG.info("Execution started to fetch Multi Unit Data ");

		List<MultiUnitSourceDto> multiUnitSource;
		List<MultiUnitTypeTargetDto> multiUnitTarget;
		MultiUnitSrcTargetDto multiUnitData= new MultiUnitSrcTargetDto();
		List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchMultiUnitTypeSrcItemOnload(companyId,divisionId,matchIndicator);
		 LOG.debug("Completed fetching for"+multiUnitSrcList.size()+"multi Unit Src List " );
		if(!multiUnitSrcList.isEmpty()){
			multiUnitSource= multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
			multiUnitData.setMultiUnitSource(multiUnitSource);
		}
		List<Object[]> multiUnitTargetList = multiunitSQLRepo.fetchMultiUnitTypeTargetItemOnload(companyId,divisionId,matchIndicator);
		 LOG.debug("Completed fetching for"+multiUnitTargetList.size()+"multi Unit Target List " );

		if(!multiUnitTargetList.isEmpty()){
			multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(multiUnitTargetList);
			multiUnitData.setMultiUnitTarget(multiUnitTarget);
		}
		LOG.info("Execution completed to fetch Multi Unit Data ");

		return multiUnitData;
	}
	
	@Override
	public List<MultiUnitTypeTargetDto> getMultiUnitTypeTargetDataList(
			List<MultiUnitSourceDto> multiUnitSource) {
		LOG.info("Execution started to fetch Multi Unit Type Target Data List ");

		List<MultiUnitTypeTargetDto> multiUnitTarget=new ArrayList<>();
		Set<String> targetUpcs=new HashSet<>();
		if(!multiUnitSource.isEmpty()){
			for (MultiUnitSourceDto srcObj : multiUnitSource) {
				targetUpcs.addAll(srcObj.getUpcs());
			}
			String target = StringUtils.join(targetUpcs.toArray(), ",");
			List<Object[]> targetData = multiunitSQLRepo.fetchMultiUnitTypeTargetBasedOnSourceSelection(multiUnitSource.get(0).getCompanyId(),multiUnitSource.get(0).getDivisionId(),target,multiUnitSource.get(0).getMatchIndicator());
			if(!targetData.isEmpty()){
				multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(targetData);
			}	
		}
		LOG.info("Execution completed to fetch"+multiUnitTarget+" Multi Unit  Type Target Data List ");

		return multiUnitTarget;
	}
	
	@Override
	public List<MultiUnitSourceDto> getMultiUnitTypeSourceDataList(
			List<MultiUnitTypeTargetDto> multiUnitTarget) {
		LOG.info("Execution started to fetch Multi Unit Type Source Data List ");

		List<MultiUnitSourceDto> multiUnitSource=new ArrayList<>();
		Set<String> sourceUpcs=new HashSet<>();
		if(!multiUnitTarget.isEmpty()){
			for (MultiUnitTypeTargetDto tarObj : multiUnitTarget) {
				sourceUpcs.addAll(tarObj.getUpcList());
			}
			String sourceUpcString = StringUtils.join(sourceUpcs.toArray(), ",");
			List<Object[]> sourceData = multiunitSQLRepo.fetchMultiUnitTypeSourceBasedOnTargetSelection(multiUnitTarget.get(0).getCompanyId(),multiUnitTarget.get(0).getDivisionId(),sourceUpcString,multiUnitTarget.get(0).getMatchIndicator());
			if(!sourceData.isEmpty()){
				multiUnitSource= multiUnitAdapter.buildMultiUnitSourceItem(sourceData);
			}	
		}
		LOG.info("Execution completed to fetch"+multiUnitSource.size()+" Multi Unit Type Source Data List ");

		return multiUnitSource;
	}
	
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}

	@Override
	public Map<String, String> updateSourceBasedOnTarget(
			MultiUnitSrcTargetDto multiUnitSrcTargetDto) {
		LOG.info("Execution started to update Source Based On Target ");

		List<MultiUnitSourceDto> multiUnitSource=multiUnitSrcTargetDto.getMultiUnitSource();
		MultiUnitTypeTargetDto multiUnitTarget=multiUnitSrcTargetDto.getMultiUnitTarget().get(0);
		Map<String, String> response=new HashMap<>();
		if(!multiUnitSource.isEmpty()){
			if(multiUnitSrcTargetDto.getSrcMultiUnitFlag().equals("Y")){
				boolean isUpdated=false;
					for (MultiUnitSourceDto srcObj : multiUnitSource) {
						List<String> upcString=new ArrayList<>(srcObj.getUpcs());
						List<ItemConvMultiUnitType>  multiUnitSrcList=multiUnitTypeRepo.findMultiUnitTypeSrcItemByProductSkuUpcList(srcObj.getCompanyId(),srcObj.getDivisionId(),srcObj.getConvProductSku(),upcString);
						if(!multiUnitSrcList.isEmpty()){
							for (ItemConvMultiUnitType item : multiUnitSrcList) {
								item.setCorpItemCode(getBigDecimalValue(multiUnitTarget.getCorpItemCd()));
								item.setUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
								item.setUpdatedUserId(srcObj.getUpdatedUserId());
								item.setStatus("C");
								item.setAutoManualInd("M");
								multiUnitTypeRepo.save(item);
								isUpdated=true;
							}
						}
					}
					if(isUpdated){
						response.put("Result" , " Multi Unit type item mapped successfully");
					}
					
			}else{
				boolean isInserted=false;
				for (MultiUnitSourceDto srcObj : multiUnitSource) {
					List<String> productSkuList=null;
					if(srcObj.getProdSourceCd().equalsIgnoreCase("DSD")){
						productSkuList=multiunitSQLRepo.findProductSkuBasedOnConvProductSku(srcObj.getCompanyId(),srcObj.getDivisionId(),srcObj.getConvProductSku());
					}else{
						productSkuList=multiunitSQLRepo.findProductSkuBasedOnProductSku(srcObj.getCompanyId(),srcObj.getDivisionId(),srcObj.getConvProductSku());
					}
					for (String productSku : productSkuList) {
						if (!srcObj.getUpcs().isEmpty()) {
							for (String upc : srcObj.getUpcs()) {
								ItemConvMultiUnitType item = new ItemConvMultiUnitType();
								ItemConvMultiUnitTypePk itemPk = new ItemConvMultiUnitTypePk();
								itemPk.setCompanyId(srcObj.getCompanyId());
								itemPk.setDivisionId(srcObj.getDivisionId());
								itemPk.setProductSku(productSku);
								itemPk.setSrcUpc(upc);
								item.setMultiUnitPk(itemPk);
								item.setSrcItemDesc(srcObj.getSrcItemDesc());
								item.setSrcPackWhse(srcObj.getSrcPackWhse());
								item.setSrcVendConvFctr(srcObj.getSrcVendConvFctr());
								item.setSrcSize(srcObj.getSrcSize());
								item.setProdSourceCd(srcObj.getProdSourceCd());
								item.setSrcprodHierarchyLvl5Cd(srcObj.getDeptName());
								item.setConvProductSku(srcObj.getConvProductSku());
								String[] hierarchy = srcObj.getProductHierarchy().split("-");
								if (hierarchy.length == 3) {
									item.setSrcprodHierarchyLvl1Cd(hierarchy[0]);
									item.setSrcprodHierarchyLvl2Cd(hierarchy[1]);
									item.setSrcprodHierarchyLvl3Cd(hierarchy[2]);
								}
								item.setCorpItemCode(getBigDecimalValue(multiUnitTarget.getCorpItemCd()));
								item.setUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
								item.setUpdatedUserId(srcObj.getUpdatedUserId());
								item.setStatus("C");
								item.setAutoManualInd("M");
								multiUnitTypeRepo.save(item);
								isInserted = true;
							}
						}
					}
					
				}
				if(isInserted){
					response.put("Result", " Multi Unit type item inserted successfully");
				}
				
			}
		}
		LOG.info("Execution completed to update Source Based On Target ");

		return response;
	}

	@Override
	public Map<String, List<String>> markMultiUnitItemsAsDead(
			List<MultiUnitSourceDto> multiUnitSource) {
		LOG.info("Execution started to mark MultiUnitItems As Dead ");

		Map<String,List<String>> response=new HashMap<>();
		List<String> productSkuSuccess = new ArrayList<>();
		List<String> productSkuFailure = new ArrayList<>();
		for (MultiUnitSourceDto item : multiUnitSource) {
			List<String> productSkuList=null;
			if(item.getProdSourceCd().equalsIgnoreCase("DSD")){
				productSkuList=multiunitSQLRepo.findProductSkuBasedOnConvProductSku(item.getCompanyId(),item.getDivisionId(),item.getConvProductSku());
			}else{
				productSkuList=multiunitSQLRepo.findProductSkuBasedOnProductSku(item.getCompanyId(),item.getDivisionId(),item.getConvProductSku());
			}
			String productSkuString = StringUtils.join(productSkuList.toArray(), "','");
		int result=	multiunitSQLRepo.markItemsAsDead(item.getCompanyId(), item.getDivisionId(), productSkuString, item.getMarkAsDeadReason(),item.getUpdatedUserId());
			if (result >0) {
				productSkuSuccess.add(item.getConvProductSku());
			} else {
				productSkuFailure.add(item.getConvProductSku());
			}
		}
		response.put("Success", productSkuSuccess);
		response.put("Failure", productSkuFailure);
		LOG.info("Execution completed to mark MultiUnitItems As Dead ");

		return response;
	}

	@Override
	public Map<String, List<String>> markNotAMultiUnitItem(
			List<MultiUnitSourceDto> multiUnitSource) {
		LOG.info("Execution started to mark Not A MultiUnitItem ");

		Map<String,List<String>> response=new HashMap<>();
		List<String> productSkuSuccess = new ArrayList<>();
		List<String> productSkuFailure = new ArrayList<>();
		for (MultiUnitSourceDto item : multiUnitSource) {
		int result=	multiunitSQLRepo.markNotAMultiUnit(item.getCompanyId(), item.getDivisionId(), item.getConvProductSku(), item.getUpdatedUserId());
			if (result > 0) {
				productSkuSuccess.add(item.getConvProductSku());
			} else {
				productSkuFailure.add(item.getConvProductSku());
			}
		}
		response.put("Success", productSkuSuccess);
		response.put("Failure", productSkuFailure);
		LOG.info("Execution completed to mark Not A MultiUnitItem ");

		return response;
	}

	@Override
	public List<MultiUnitSourceDto> getMultiUnitSourceDetail(
			List<MultiUnitSourceTargetSearchRequest> sourceRequest) {
		LOG.info("Execution started to get MultiUnit Source Detail ");

		
		List<MultiUnitSourceDto> multiUnitSrc=null;
		if(sourceRequest.get(0).getSrcMultiUnitFlag()=='N'){
			if(sourceRequest.get(0).getMatchIndicator().equals("P")){
				if(sourceRequest.get(0).getItemDescFlag()=='Y' && sourceRequest.get(0).getSrcItemDesc()!=null){
					
					List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchSrcItemBasedOnItemDesc(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),escapeMetaCharacters(sourceRequest.get(0).getSrcItemDesc()));
					if(!multiUnitSrcList.isEmpty()){
						multiUnitSrc= multiUnitAdapter.buildNonMultiUnitSourceItem(multiUnitSrcList);
					}
				}
				else if(sourceRequest.get(0).getVenderNameFlag()=='Y' && sourceRequest.get(0).getSrcVendName()!=null){
					List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchSrcItemBasedOnVendorName(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),escapeMetaCharacters(sourceRequest.get(0).getSrcVendName()));
					if(!multiUnitSrcList.isEmpty()){
						multiUnitSrc= multiUnitAdapter.buildNonMultiUnitSourceItem(multiUnitSrcList);
					}
				}
				else if(sourceRequest.get(0).getHierarchyOrSmicFlag()=='Y' && (sourceRequest.get(0).getSrcprodHierarchyLvl1Cd()!=null && sourceRequest.get(0).getSrcprodHierarchyLvl2Cd()!=null && sourceRequest.get(0).getSrcprodHierarchyLvl3Cd()!=null)){
					List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchSrcItemBasedOnProductHierarchy(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),sourceRequest.get(0).getSrcprodHierarchyLvl1Cd(),sourceRequest.get(0).getSrcprodHierarchyLvl2Cd(),sourceRequest.get(0).getSrcprodHierarchyLvl3Cd());
					if(!multiUnitSrcList.isEmpty()){
						multiUnitSrc= multiUnitAdapter.buildNonMultiUnitSourceItem(multiUnitSrcList);
					}
				}
				else if(sourceRequest.get(0).getProductSKUsearchFlag() != null && sourceRequest.get(0).getProductSKUsearchFlag()=='Y' && sourceRequest.get(0).getSrcProductSKU()!=null){
					
					List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchSrcItemBasedOnProductSKU(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),sourceRequest.get(0).getSrcProductSKU().trim());
					if(!multiUnitSrcList.isEmpty()){
						multiUnitSrc= multiUnitAdapter.buildNonMultiUnitSourceItem(multiUnitSrcList);
					}
				}
			}
			
		}else{
			if(sourceRequest.get(0).getItemDescFlag()=='Y' && sourceRequest.get(0).getSrcItemDesc()!=null){
				List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnItemDesc(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),escapeMetaCharacters(sourceRequest.get(0).getSrcItemDesc()),sourceRequest.get(0).getMatchIndicator());
				if(!multiUnitSrcList.isEmpty()){
					multiUnitSrc= multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
				}
			}
			else if(sourceRequest.get(0).getVenderNameFlag()=='Y' && sourceRequest.get(0).getSrcVendName()!=null){
				List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnVendorName(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),escapeMetaCharacters(sourceRequest.get(0).getSrcVendName()),sourceRequest.get(0).getMatchIndicator());
				if(!multiUnitSrcList.isEmpty()){
					multiUnitSrc= multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
				}
			}
			else if(sourceRequest.get(0).getHierarchyOrSmicFlag()=='Y' && (sourceRequest.get(0).getSrcprodHierarchyLvl1Cd()!=null && sourceRequest.get(0).getSrcprodHierarchyLvl2Cd()!=null && sourceRequest.get(0).getSrcprodHierarchyLvl3Cd()!=null)){
				List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnProductHierarchy(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),sourceRequest.get(0).getSrcprodHierarchyLvl1Cd(),sourceRequest.get(0).getSrcprodHierarchyLvl2Cd(),sourceRequest.get(0).getSrcprodHierarchyLvl3Cd(),sourceRequest.get(0).getMatchIndicator());
				if(!multiUnitSrcList.isEmpty()){
					multiUnitSrc= multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
				}
			}
			else if(sourceRequest.get(0).getProductSKUsearchFlag() != null && sourceRequest.get(0).getProductSKUsearchFlag()=='Y' && sourceRequest.get(0).getSrcProductSKU()!=null){
				List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnProductSKU(sourceRequest.get(0).getCompanyId(),sourceRequest.get(0).getDivisionId(),sourceRequest.get(0).getSrcProductSKU().trim(),sourceRequest.get(0).getMatchIndicator());
				if(!multiUnitSrcList.isEmpty()){
					multiUnitSrc= multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
				}
			}
			
			
		}
		LOG.info("Execution completed to get MultiUnit Source Detail ");

		return multiUnitSrc;
	}

	@Override
	public List<MultiUnitTypeTargetDto> getMultiUnitTargetDetail(
			List<MultiUnitSourceTargetSearchRequest> targetRequest) {
		LOG.info("Execution started to get MultiUnit Target Detail ");
		List<MultiUnitTypeTargetDto> multiUnitTarget=null;
		if(targetRequest.get(0).getItemDescFlag()=='Y' && targetRequest.get(0).getTarItemDesc()!=null){
			List<Object[]> multiUnitTargetList = multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnItemDesc(targetRequest.get(0).getCompanyId(),targetRequest.get(0).getDivisionId(),escapeMetaCharacters(targetRequest.get(0).getTarItemDesc()),targetRequest.get(0).getMatchIndicator());
			if(!multiUnitTargetList.isEmpty()){
				multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(multiUnitTargetList);
			}
		}else if(targetRequest.get(0).getVenderNameFlag()=='Y' && targetRequest.get(0).getTarVendorName()!=null){
			List<Object[]> multiUnitTargetList = multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnVendorName(targetRequest.get(0).getCompanyId(),targetRequest.get(0).getDivisionId(),escapeMetaCharacters(targetRequest.get(0).getTarVendorName()),targetRequest.get(0).getMatchIndicator());
			if(!multiUnitTargetList.isEmpty()){
				multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(multiUnitTargetList);
			}
		}else if(targetRequest.get(0).getHierarchyOrSmicFlag()=='Y' && (targetRequest.get(0).getTarGrpCd()!=null && targetRequest.get(0).getTarCtgryCd()!=null && targetRequest.get(0).getTarClsCd()!=null && targetRequest.get(0).getTarSbClsCd()!=null && targetRequest.get(0).getTarSubSbClass()!=null)){
			List<Object[]> multiUnitTargetList = multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnSmicCode(targetRequest.get(0).getCompanyId(),targetRequest.get(0).getDivisionId(),targetRequest.get(0).getTarGrpCd(),targetRequest.get(0).getTarCtgryCd(),targetRequest.get(0).getTarClsCd(),targetRequest.get(0).getTarSbClsCd(),targetRequest.get(0).getTarSubSbClass(),targetRequest.get(0).getMatchIndicator());
			if(!multiUnitTargetList.isEmpty()){
				multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(multiUnitTargetList);
			}
		}
		else if(null != targetRequest.get(0).getTargetCICsearchFlag() && targetRequest.get(0).getTargetCICsearchFlag()=='Y' && targetRequest.get(0).getTargetCIC()!=null){
			List<Object[]> multiUnitTargetList = multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnCIC(targetRequest.get(0).getCompanyId(),targetRequest.get(0).getDivisionId(),targetRequest.get(0).getTargetCIC().trim(),targetRequest.get(0).getMatchIndicator());
			if(!multiUnitTargetList.isEmpty()){
				multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(multiUnitTargetList);
			}
		}
		LOG.info("Execution completed to get  MultiUnit Target Detail ");

		return multiUnitTarget;
	}

	@Override
	public Map<String, String> updateSourceBasedOnTargetUnMap(
			MultiUnitSrcTargetDto multiUnitSrcTargetDto) {
		LOG.info("Execution started to get update Source Based On Target UnMap ");

		List<MultiUnitSourceDto> multiUnitSource=multiUnitSrcTargetDto.getMultiUnitSource();
		MultiUnitTypeTargetDto multiUnitTarget=multiUnitSrcTargetDto.getMultiUnitTarget().get(0);
		Map<String, String> response=new HashMap<>();
		boolean isUpdated=false;
		if(!multiUnitSource.isEmpty()){
			for (MultiUnitSourceDto srcObj : multiUnitSource) {
				List<String> upcString=new ArrayList<>(srcObj.getUpcs());
				List<ItemConvMultiUnitType>  multiUnitSrcList=multiUnitTypeRepo.findMultiUnitTypeSrcItemByProductSkuUpcList(srcObj.getCompanyId(),srcObj.getDivisionId(),srcObj.getConvProductSku(),upcString);
				for (ItemConvMultiUnitType item : multiUnitSrcList) {
					if(multiUnitTarget.getMatchIndicator().equals("M")){
						item.setStatus("P");
						item.setAutoManualInd("P");
						item.setUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
						item.setUpdatedUserId(srcObj.getUpdatedUserId());
					}else if(multiUnitTarget.getMatchIndicator().equals("A")){
						item.setStatus("U");
						item.setAutoManualInd("P");
						item.setUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
						item.setUpdatedUserId(srcObj.getUpdatedUserId());
					}
					multiUnitTypeRepo.save(item);
					isUpdated=true;
				}
			}
		}
		if(isUpdated){
			response.put("Result", " Multi Unit type item un mapped successfully");
		}
		LOG.info("Execution completed to get update Source Based On Target UnMap ");

		return response;
	
	}

	public String escapeMetaCharacters(String inputString) {
		LOG.info("Execution started to escape MetaCharacters ");


		if (inputString.contains("'")) {
			inputString = StringUtils.replace(inputString, "'", "''");
		}
		if (inputString.contains("&")) {
			inputString = StringUtils.replace(inputString, "&", "&");
		}
		if (inputString.contains("%")) {
			inputString = StringUtils.replace(inputString, "%", "|%");
		}
		if (inputString.contains("_")) {
			inputString = StringUtils.replace(inputString, "_", "|_");
		}
		LOG.info("Execution completed to escape MetaCharacters ");

		return StringUtils.strip(inputString.toUpperCase());
	}

	@Override
	public Map<String, String> markItemAsMultiUnit(
			List<MultiUnitSourceDto> multiUnitSource) {
		LOG.info("Execution started to mark Item As MultiUnit ");

		HashMap<String, String> response=new HashMap<>();
		if(!multiUnitSource.isEmpty()){
			boolean isInserted=false;
			for (MultiUnitSourceDto srcObj : multiUnitSource) {
				List<String> productSkuList=null;
				if(srcObj.getProdSourceCd().equalsIgnoreCase("DSD")){
					productSkuList=multiunitSQLRepo.findProductSkuBasedOnConvProductSku(srcObj.getCompanyId(),srcObj.getDivisionId(),srcObj.getConvProductSku());
				}else{
					productSkuList=multiunitSQLRepo.findProductSkuBasedOnProductSku(srcObj.getCompanyId(),srcObj.getDivisionId(),srcObj.getConvProductSku());
				}
				for (String productSku : productSkuList) {
				if(!srcObj.getUpcs().isEmpty()){
					for (String upc : srcObj.getUpcs()) {
						ItemConvMultiUnitType item=new ItemConvMultiUnitType();
						ItemConvMultiUnitTypePk itemPk=new ItemConvMultiUnitTypePk();
						itemPk.setCompanyId(srcObj.getCompanyId());
						itemPk.setDivisionId(srcObj.getDivisionId());
						itemPk.setProductSku(productSku);
						itemPk.setSrcUpc(upc);
						item.setMultiUnitPk(itemPk);
						item.setConvProductSku(srcObj.getConvProductSku());
						item.setSrcItemDesc(srcObj.getSrcItemDesc());
						item.setSrcPackWhse(srcObj.getSrcPackWhse());
						item.setSrcVendConvFctr(srcObj.getSrcVendConvFctr());
						item.setSrcSize(srcObj.getSrcSize());
						item.setProdSourceCd(srcObj.getProdSourceCd());
						if(srcObj.getProdSourceCd().equals("DSD")){
							item.setCaseUpc("0");
						}
						else{
							item.setCaseUpc(srcObj.getCaseUpc());
						}
						item.setSrcprodHierarchyLvl5Cd(srcObj.getDeptName());
						String[] hierarchy= srcObj.getProductHierarchy().split("-");
						if(hierarchy.length==3){
							item.setSrcprodHierarchyLvl1Cd(hierarchy[0]);
							item.setSrcprodHierarchyLvl2Cd(hierarchy[1]);
							item.setSrcprodHierarchyLvl3Cd(hierarchy[2]);
						}
						item.setStatus("P");
						item.setAutoManualInd("P");
						item.setUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
						item.setUpdatedUserId(srcObj.getUpdatedUserId());
						item.setBatchId(new BigDecimal(99999));
						item.setSrcMaxRetail(srcObj.getMaxRetail());
						item.setSrcCost(srcObj.getSrcCost());
						item.setSrcVendNum(srcObj.getSrcVendNum());
						item.setSrcVendorName(srcObj.getSrcVendName());						
						multiUnitTypeRepo.save(item);
						isInserted=true;
					}
				}
			}
			}
			if(isInserted){
				response.put("Result", " Multi Unit type item inserted successfully");
			}
		}
		LOG.info("Execution completed to mark Item As MultiUnit ");

		return response;
	}

	@Override
	public MultiUnitSrcTargetDto fetchMultiUnitSourceData(String companyId,
			String divisionId, String matchIndicator) {
		LOG.info("Execution started to fetch Multi Unit Source Data ");

		List<MultiUnitSourceDto> multiUnitSource;
		
		MultiUnitSrcTargetDto multiUnitData= new MultiUnitSrcTargetDto();
		List<Object[]> multiUnitSrcList = multiunitSQLRepo.fetchMultiUnitTypeSrcItemOnload(companyId,divisionId,matchIndicator);
		if(!multiUnitSrcList.isEmpty()){
			multiUnitSource= multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
			multiUnitData.setMultiUnitSource(multiUnitSource);
		}
		LOG.info("Execution completed to fetch Multi Unit Source Data ");

		return multiUnitData;
	}

	@Override
	public MultiUnitSrcTargetDto fetchMultiUnitTargetData(String companyId,
			String divisionId, String matchIndicator) {
		LOG.info("Execution started to fetch Multi Unit Target Data ");

		
		List<MultiUnitTypeTargetDto> multiUnitTarget;
		MultiUnitSrcTargetDto multiUnitData= new MultiUnitSrcTargetDto();
		List<Object[]> multiUnitTargetList = multiunitSQLRepo.fetchMultiUnitTypeTargetItemOnload(companyId,divisionId,matchIndicator);
		if(!multiUnitTargetList.isEmpty()){
			multiUnitTarget= multiUnitAdapter.buildMultiUnitTargetItem(multiUnitTargetList);
			multiUnitData.setMultiUnitTarget(multiUnitTarget);
		}
		LOG.info("Execution completed to fetch Multi Unit Target Data ");

		return multiUnitData;
	}

	@Override
	public List<Object[]> fetchMuTTargetUpcPopUpData(String corpItemCd) {
		LOG.info("Execution started to fetch MuT Target Upc PopUp Data ");

		
		List<Object[]> upcListDetails=multiunitSQLRepo.fetchMultiUnitUPCPopUpDetals(corpItemCd);
		
		LOG.info("Execution completed for"+upcListDetails.size()+" fetch MuT Target Upc PopUp Data ");

		return multiUnitAdapter.buildPopUpData(upcListDetails);
		
	}

	
	

	
}