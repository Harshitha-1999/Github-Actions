package com.safeway.app.memi.domain.dtos.response;

public class ExcelFileKey {
	private String productSku;
	private String upc;
	public ExcelFileKey(String productSku, String upc) {
		super();
		this.productSku = productSku;
		this.upc = upc;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((productSku == null) ? 0 : productSku.hashCode());
		result = prime * result + ((upc == null) ? 0 : upc.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExcelFileKey other = (ExcelFileKey) obj;
		if (productSku == null) {
			if (other.productSku != null)
				return false;
		} else if (!productSku.equals(other.productSku))
			return false;
		if (upc == null) {
			if (other.upc != null)
				return false;
		} else if (!upc.equals(other.upc))
			return false;
		return true;
	}
	public String getProductSku() {
		return productSku;
	}
	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	@Override
	public String toString() {
		return "ExcelFileKey [productSku=" + productSku + ", upc=" + upc + "]";
	}

}
