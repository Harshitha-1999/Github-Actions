package com.safeway.app.memi.data.repositories;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ItemConvDisplayItemComponents;


public interface ItemConvDisplayItemComponentRepository  extends JpaRepository<ItemConvDisplayItemComponents, Long> {
	 
	 @Query
	    List<ItemConvDisplayItemComponents> findByItemConvDisplayItemComponentsPkCompanyidAndItemConvDisplayItemComponentsPkDivisonIdAndItemConvDisplayItemComponentsPkProductSkuAndItemConvDisplayItemComponentsPkUpcCountryAndItemConvDisplayItemComponentsPkUpcSystemAndItemConvDisplayItemComponentsPkUpcManufAndItemConvDisplayItemComponentsPkUpcSales
	    		(String companyid,String divisonId,String productSku,BigDecimal upcCountry,BigDecimal upcSystem,BigDecimal upcManuf,BigDecimal upcSales);
}
