package com.safeway.app.memi.domain.adapters;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultVOS;

@Component
public class LookUpScreenAdapter {
	
	
	public List<LookUpSearchResultVOS> buildLookUpSearchResultDto(List<Object[]> resultList)
	{   
		 List<LookUpSearchResultVOS> resultSet =new ArrayList();
		for(Object[] lkpObj:resultList)
		{
			LookUpSearchResultVOS lkpDto=new LookUpSearchResultVOS();
			
			lkpDto.setSrc_conv_gp_cd(getStringValue (lkpObj[1] != null ? lkpObj[1] : null));
			lkpDto.setSrc_dept_code(getStringValue (lkpObj[2] != null ? lkpObj[2] : null));
			lkpDto.setSrc_dept_name(getStringValue (lkpObj[3] != null ? lkpObj[3] : null));
			lkpDto.setHier1_lvl_cd(getStringValue (lkpObj[4] != null ? lkpObj[4] : null)) ;
			lkpDto.setHier2_lvl_cd(getStringValue (lkpObj[5] != null ? lkpObj[5] : null));
			lkpDto.setHier3_lvl_cd(getStringValue (lkpObj[6] != null ? lkpObj[6] : null));
			lkpDto.setHier4_cd(getStringValue (lkpObj[7] != null ? lkpObj[7] : null));
			lkpDto.setHier5_name(getStringValue (lkpObj[8] != null ? lkpObj[8] : null));
			lkpDto.setHier1_lvl_name(getStringValue (lkpObj[9] != null ? lkpObj[9] : null));
			lkpDto.setHier2_lvl_name(getStringValue (lkpObj[10] != null ? lkpObj[10] : null));
			lkpDto.setHier3_lvl_name(getStringValue (lkpObj[11] != null ? lkpObj[11] : null));
			lkpDto.setSrc_suplier_no(getStringValue (lkpObj[12] != null ? lkpObj[12] : null));
			lkpDto.setSrc_prod_sku(getStringValue (lkpObj[13] != null ? lkpObj[13] : null));
			lkpDto.setSrc_item_description(getStringValue (lkpObj[14] != null ? lkpObj[14] : null));
			lkpDto.setSrc_pack((BigDecimal) (lkpObj[15] != null ? lkpObj[15] : null));
			lkpDto.setSrc_vcf((BigDecimal)  (lkpObj[16] != null ? lkpObj[16] : null));
			lkpDto.setSrc_desc_size(getStringValue (lkpObj[17] != null ? lkpObj[17] : null));
			lkpDto.setSrc_numeric_size((BigDecimal) (lkpObj[18] != null ? lkpObj[18] : null));
			lkpDto.setSrc_uom(getStringValue (lkpObj[19] != null ? lkpObj[19] : null)) ;
			lkpDto.setSrc_upc(getUPCFormatted (lkpObj[20] != null ? lkpObj[20] : null)) ;
			lkpDto.setSrc_upc_country((BigDecimal) (lkpObj[21] != null ? lkpObj[21] : null));
			lkpDto.setSrc_upc_system((BigDecimal) (lkpObj[22] != null ? lkpObj[22] : null));
			lkpDto.setSrc_upc_manuf((BigDecimal) (lkpObj[23] != null ? lkpObj[23] : null)) ;
			lkpDto.setSrc_upc_sales((BigDecimal) (lkpObj[24] != null ? lkpObj[24] : null)) ;
			lkpDto.setSrc_whse_dsd(getStringValue (lkpObj[25] != null ? lkpObj[25] : null)) ;
			lkpDto.setSrc_rog(getStringValue (lkpObj[26] != null ? lkpObj[26] : null));
			lkpDto.setSrc_conv_st_cd(getStringValue (lkpObj[27] != null ? lkpObj[27] : null)) ;
			lkpDto.setSrc_conv_st_sb_cd(getStringValue (lkpObj[28] != null ? lkpObj[28] : null));
			lkpDto.setXrf_cic((BigDecimal) (lkpObj[29] != null ? lkpObj[29] : null));
			lkpDto.setSrc_exc_cic((BigDecimal) (lkpObj[30] != null ? lkpObj[30] : null));
			lkpDto.setSrc_supplier_name(getStringValue (lkpObj[31] != null ? lkpObj[31] : null));
				
			lkpDto.setTgt_corp_item_cd((BigDecimal) (lkpObj[32] != null ? lkpObj[32] : null)) ;
			lkpDto.setTgt_item_desc(getStringValue (lkpObj[33] != null ? lkpObj[33] : null));
			lkpDto.setTgt_pack_whse((BigDecimal) (lkpObj[34] != null ? lkpObj[34] : null));
			lkpDto.setTgt_vcf((BigDecimal) (lkpObj[35] != null ? lkpObj[35] : null));
			lkpDto.setTgt_cds_size(getStringValue (lkpObj[36] != null ? lkpObj[36] : null));
			lkpDto.setTgt_size_num((BigDecimal) (lkpObj[37] != null ? lkpObj[37] : null));			
			lkpDto.setTgt_uom(getStringValue (lkpObj[38] != null ? lkpObj[38] : null)) ;
			lkpDto.setTgt_item_usage_Type(convertToChar (lkpObj[39] != null ? lkpObj[39] : null)) ;			
			lkpDto.setTgt_item_usage_ind(getStringValue (lkpObj[40] != null ? lkpObj[40] : null)) ;			
			lkpDto.setTgt_dipslay_flag(convertToChar (lkpObj[41] != null ? lkpObj[41] : null));
			lkpDto.setTgt_group_cd((BigDecimal) (lkpObj[42] != null ? lkpObj[42] : null));
			lkpDto.setTgt_category_cd((BigDecimal) (lkpObj[43] != null ? lkpObj[43] : null));
			lkpDto.setTgt_class_cd((BigDecimal) (lkpObj[44] != null ? lkpObj[44] : null));
			lkpDto.setTgt_sub_class_Cd((BigDecimal) (lkpObj[45] != null ? lkpObj[45] : null)) ;
			lkpDto.setTgt_sub_sub_class_cd((BigDecimal) (lkpObj[46] != null ? lkpObj[46] : null));			
			lkpDto.setTgt_upc_country((BigDecimal) (lkpObj[47] != null ? lkpObj[47] : null)) ;
			lkpDto.setTgt_upc_system((BigDecimal) (lkpObj[48] != null ? lkpObj[48] : null));
			lkpDto.setTgt_upc_manuf((BigDecimal) (lkpObj[49] != null ? lkpObj[49] : null));
			lkpDto.setTgt_upc_sales((BigDecimal) (lkpObj[50] != null ? lkpObj[50] : null));
			lkpDto.setTgt_unit_type((BigDecimal) (lkpObj[51] != null ? lkpObj[51] : null));	
			
			lkpDto.setTgt_division(getStringValue(lkpObj[52] != null ? lkpObj[52] : null)) ;
			lkpDto.setTgt_dst_cntr(getStringValue (lkpObj[53] != null ? lkpObj[53] : null)) ;
			lkpDto.setTgt_facility(getStringValue (lkpObj[54] != null ? lkpObj[54] : null)) ;
			lkpDto.setTgt_wds_pack_desc(getStringValue (lkpObj[55] != null ? lkpObj[55] : null));			
			lkpDto.setTgt_wds_size_desc(getStringValue (lkpObj[56] != null ? lkpObj[56] : null));			
			lkpDto.setTgt_pack_Retail((BigDecimal) (lkpObj[57] != null ? lkpObj[57] : null));
			lkpDto.setTgt_urx_pack_desc(getStringValue (lkpObj[59] != null ? lkpObj[58] : null));			
			lkpDto.setTgt_urx_Size_desc(getStringValue (lkpObj[59] != null ? lkpObj[59] : null));			
			lkpDto.setTgt_primary_upc_sw(convertToChar (lkpObj[60] != null ? lkpObj[60] : null)) ;			
			lkpDto.setTgt_plu_cd((BigDecimal) (lkpObj[61] != null ? lkpObj[61] : null)) ;			
			lkpDto.setTgt_ring((BigDecimal) (lkpObj[62] != null ? lkpObj[62] : null)) ;
			lkpDto.setTgt_hicon((BigDecimal) (lkpObj[63] != null ? lkpObj[63] : null)) ;
			lkpDto.setTgt_gift_card_ind(convertToChar (lkpObj[64] != null ? lkpObj[64] : null));
			lkpDto.setTgt_upc(getStringValue (lkpObj[65] != null ? lkpObj[65] : null));
			
			
			resultSet.add(lkpDto);
		}
		
		return resultSet;
	}
	
	private String getStringValue(Object obj) {
		if (obj == null)
		{
			return "";
		}
		String str =  obj.toString();
		return str.trim();
		
	}
	
	private char convertToChar(Object obj){
		if(obj !=null && obj.toString().length() == 1)
		{
			return obj.toString().charAt(0);
		}
		else
		{
			return Character.MIN_VALUE;
			}
	
	}
	private String getUPCFormatted(Object upc)
	{
		String formattedUpc="";
		String upctemp ="";
		if(upc!=null && upc.toString().length()<12)
		{
			upctemp = StringUtils.leftPad(upc.toString(),12,"0");
			
		}
		else if(upc!=null && upc.toString().length()==12)
		{
			upctemp = upc.toString();
			
		}
		
		
		if(!upctemp.equals(""))
		{
			formattedUpc =upctemp.substring(0, 1)+"-"+upctemp.substring(1, 2)+"-"+upctemp.substring(2, 7)+"-"+upctemp.substring(7, 12);
		}
		
		if(!formattedUpc.equals(""))
		{
			return formattedUpc;
		}
		else
		{
			return null;
		}
		
	    
	}
	

}
