/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.List;

/**
 ****************************************************************************
 * NAME : BakeryResponseVO 
 * 
 * DESCRIPTION :BakeryResponseVO is the class for holding search/filter response in
 * 			     mapping process
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Mar 5, 2018  - Initial Creation
 * *************************************************************************
 */

public class BakeryResponseVO {
	
	/**
	 * Attribute to hold the bakery source SKU search results
	 */
	private List<BakerySKUSearchResults> bakerySkuSearchResults;
	
	/**
	 * Attribute to hold the bakery target cic search results
	 */
	private List<BakeryCICSearchResults> bakeryCicSearchResults;
	
	/**
	 * Attribute to hold the error messages.
	 */
	private List<String> errorMessages;

	private BigDecimal sourceCount;	
	private BigDecimal targetCount;	
	
	/**
	 * @return the bakerySkuSearchResults
	 */
	public List<BakerySKUSearchResults> getBakerySkuSearchResults() {
		return bakerySkuSearchResults;
	}

	/**
	 * @param bakerySkuSearchResults the bakerySkuSearchResults to set
	 */
	public void setBakerySkuSearchResults(List<BakerySKUSearchResults> bakerySkuSearchResults) {
		this.bakerySkuSearchResults = bakerySkuSearchResults;
	}

	/**
	 * @return the bakeryCicSearchResults
	 */
	public List<BakeryCICSearchResults> getBakeryCicSearchResults() {
		return bakeryCicSearchResults;
	}

	/**
	 * @param bakeryCicSearchResults the bakeryCicSearchResults to set
	 */
	public void setBakeryCicSearchResults(List<BakeryCICSearchResults> bakeryCicSearchResults) {
		this.bakeryCicSearchResults = bakeryCicSearchResults;
	}

	/**
	 * @return the errorMessages
	 */
	public List<String> getErrorMessages() {
		return errorMessages;
	}

	/**
	 * @param errorMessages the errorMessages to set
	 */
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}

	public BigDecimal getSourceCount() {
		return sourceCount;
	}

	public void setSourceCount(BigDecimal sourceCount) {
		this.sourceCount = sourceCount;
	}

	public BigDecimal getTargetCount() {
		return targetCount;
	}

	public void setTargetCount(BigDecimal targetCount) {
		this.targetCount = targetCount;
	}
	
	
	
	
}
