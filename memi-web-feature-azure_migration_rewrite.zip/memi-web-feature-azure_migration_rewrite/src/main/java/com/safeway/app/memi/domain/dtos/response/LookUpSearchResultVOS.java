package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class LookUpSearchResultVOS {
	
	private String src_conv_gp_cd;
	private String src_dept_code;
	private String src_dept_name;
	private String hier1_lvl_cd;
	private String hier2_lvl_cd;
	private String hier3_lvl_cd;
	private String hier4_cd;
	private String hier5_name;
	
	private String hier1_lvl_name;
	private String hier2_lvl_name;
	private String hier3_lvl_name;
	
	
	private String src_suplier_no;
	private String src_supplier_name;
	private String src_prod_sku;
	private String src_item_description;
	private BigDecimal src_pack;
	private BigDecimal src_vcf;
	private String src_desc_size;
	private BigDecimal src_numeric_size;
	private String src_uom;
	private String src_upc;
	
	private BigDecimal src_upc_country;
	private BigDecimal src_upc_system;
	private BigDecimal src_upc_manuf;
	private BigDecimal src_upc_sales;
	
	private String src_whse_dsd;
	private String src_rog;
	private String src_conv_st_cd;
	private String src_conv_st_sb_cd;
	
/*	private BigDecimal upc_country;
	private BigDecimal upc_system;
	private BigDecimal upc_manuf;
	private BigDecimal upc_sales; */
	
	private String src_plu;
	private BigDecimal xrf_cic;
	private BigDecimal src_exc_cic;
	
	
	/**Target side data*/
	
	
	private BigDecimal tgt_corp_item_cd;
	private String tgt_item_desc;
	private BigDecimal tgt_pack_whse;
	private BigDecimal tgt_vcf;
	private String tgt_cds_size;
	private BigDecimal tgt_size_num;
	private String tgt_uom;
	private char tgt_item_usage_Type;
	private String tgt_item_usage_ind;
	private char tgt_dipslay_flag;
	private BigDecimal tgt_group_cd;
	private BigDecimal tgt_category_cd;
	private BigDecimal tgt_class_cd;
	private BigDecimal tgt_sub_class_Cd;
	private BigDecimal tgt_sub_sub_class_cd;
	private BigDecimal tgt_upc_country;
	private BigDecimal tgt_upc_system;
	private BigDecimal tgt_upc_manuf;
	private BigDecimal tgt_upc_sales;
	private BigDecimal tgt_unit_type;
	private String tgt_division;
	private String tgt_dst_cntr;
	private String tgt_facility;
	private String tgt_wds_pack_desc;
	private String tgt_wds_size_desc;
	private BigDecimal tgt_pack_Retail;
	private String tgt_urx_pack_desc;
	private String tgt_urx_Size_desc;
	private char tgt_primary_upc_sw;
	private BigDecimal tgt_plu_cd;
	private BigDecimal tgt_ring;
	private BigDecimal tgt_hicon;
	private char tgt_gift_card_ind;	
	private String tgt_upc;
	
	
	public String getSrc_conv_gp_cd() {
		return src_conv_gp_cd;
	}
	public void setSrc_conv_gp_cd(String src_conv_gp_cd) {
		this.src_conv_gp_cd = src_conv_gp_cd;
	}
	public String getSrc_dept_code() {
		return src_dept_code;
	}
	public void setSrc_dept_code(String src_dept_code) {
		this.src_dept_code = src_dept_code;
	}
	public String getSrc_dept_name() {
		return src_dept_name;
	}
	public void setSrc_dept_name(String src_dept_name) {
		this.src_dept_name = src_dept_name;
	}
	public String getHier1_lvl_cd() {
		return hier1_lvl_cd;
	}
	public void setHier1_lvl_cd(String hier1_lvl_cd) {
		this.hier1_lvl_cd = hier1_lvl_cd;
	}
	public String getHier2_lvl_cd() {
		return hier2_lvl_cd;
	}
	public void setHier2_lvl_cd(String hier2_lvl_cd) {
		this.hier2_lvl_cd = hier2_lvl_cd;
	}
	public String getHier3_lvl_cd() {
		return hier3_lvl_cd;
	}
	public void setHier3_lvl_cd(String hier3_lvl_cd) {
		this.hier3_lvl_cd = hier3_lvl_cd;
	}
	public String getHier4_cd() {
		return hier4_cd;
	}
	public void setHier4_cd(String hier4_cd) {
		this.hier4_cd = hier4_cd;
	}
	public String getHier5_name() {
		return hier5_name;
	}
	public void setHier5_name(String hier5_name) {
		this.hier5_name = hier5_name;
	}
	public String getHier1_lvl_name() {
		return hier1_lvl_name;
	}
	public void setHier1_lvl_name(String hier1_lvl_name) {
		this.hier1_lvl_name = hier1_lvl_name;
	}
	public String getHier2_lvl_name() {
		return hier2_lvl_name;
	}
	public void setHier2_lvl_name(String hier2_lvl_name) {
		this.hier2_lvl_name = hier2_lvl_name;
	}
	public String getHier3_lvl_name() {
		return hier3_lvl_name;
	}
	public void setHier3_lvl_name(String hier3_lvl_name) {
		this.hier3_lvl_name = hier3_lvl_name;
	}
	public String getSrc_suplier_no() {
		return src_suplier_no;
	}
	public void setSrc_suplier_no(String src_suplier_no) {
		this.src_suplier_no = src_suplier_no;
	}
	public String getSrc_supplier_name() {
		return src_supplier_name;
	}
	public void setSrc_supplier_name(String src_supplier_name) {
		this.src_supplier_name = src_supplier_name;
	}
	public String getSrc_prod_sku() {
		return src_prod_sku;
	}
	public void setSrc_prod_sku(String src_prod_sku) {
		this.src_prod_sku = src_prod_sku;
	}
	public String getSrc_item_description() {
		return src_item_description;
	}
	public void setSrc_item_description(String src_item_description) {
		this.src_item_description = src_item_description;
	}
	public BigDecimal getSrc_pack() {
		return src_pack;
	}
	public void setSrc_pack(BigDecimal src_pack) {
		this.src_pack = src_pack;
	}
	public BigDecimal getSrc_vcf() {
		return src_vcf;
	}
	public void setSrc_vcf(BigDecimal src_vcf) {
		this.src_vcf = src_vcf;
	}
	public String getSrc_desc_size() {
		return src_desc_size;
	}
	public void setSrc_desc_size(String src_desc_size) {
		this.src_desc_size = src_desc_size;
	}
	public BigDecimal getSrc_numeric_size() {
		return src_numeric_size;
	}
	public void setSrc_numeric_size(BigDecimal src_numeric_size) {
		this.src_numeric_size = src_numeric_size;
	}
	public String getSrc_uom() {
		return src_uom;
	}
	public void setSrc_uom(String src_uom) {
		this.src_uom = src_uom;
	}
	public String getSrc_upc() {
		return src_upc;
	}
	public void setSrc_upc(String src_upc) {
		this.src_upc = src_upc;
	}
	public BigDecimal getSrc_upc_country() {
		return src_upc_country;
	}
	public void setSrc_upc_country(BigDecimal src_upc_country) {
		this.src_upc_country = src_upc_country;
	}
	public BigDecimal getSrc_upc_system() {
		return src_upc_system;
	}
	public void setSrc_upc_system(BigDecimal src_upc_system) {
		this.src_upc_system = src_upc_system;
	}
	public BigDecimal getSrc_upc_manuf() {
		return src_upc_manuf;
	}
	public void setSrc_upc_manuf(BigDecimal src_upc_manuf) {
		this.src_upc_manuf = src_upc_manuf;
	}
	public BigDecimal getSrc_upc_sales() {
		return src_upc_sales;
	}
	public void setSrc_upc_sales(BigDecimal src_upc_sales) {
		this.src_upc_sales = src_upc_sales;
	}
	public String getSrc_whse_dsd() {
		return src_whse_dsd;
	}
	public void setSrc_whse_dsd(String src_whse_dsd) {
		this.src_whse_dsd = src_whse_dsd;
	}
	public String getSrc_rog() {
		return src_rog;
	}
	public void setSrc_rog(String src_rog) {
		this.src_rog = src_rog;
	}
	public String getSrc_conv_st_cd() {
		return src_conv_st_cd;
	}
	public void setSrc_conv_st_cd(String src_conv_st_cd) {
		this.src_conv_st_cd = src_conv_st_cd;
	}
	public String getSrc_conv_st_sb_cd() {
		return src_conv_st_sb_cd;
	}
	public void setSrc_conv_st_sb_cd(String src_conv_st_sb_cd) {
		this.src_conv_st_sb_cd = src_conv_st_sb_cd;
	}
	
	public String getSrc_plu() {
		return src_plu;
	}
	public void setSrc_plu(String src_plu) {
		this.src_plu = src_plu;
	}
	public BigDecimal getXrf_cic() {
		return xrf_cic;
	}
	public void setXrf_cic(BigDecimal xrf_cic) {
		this.xrf_cic = xrf_cic;
	}
	public BigDecimal getSrc_exc_cic() {
		return src_exc_cic;
	}
	public void setSrc_exc_cic(BigDecimal src_exc_cic) {
		this.src_exc_cic = src_exc_cic;
	}
	public BigDecimal getTgt_corp_item_cd() {
		return tgt_corp_item_cd;
	}
	public void setTgt_corp_item_cd(BigDecimal tgt_corp_item_cd) {
		this.tgt_corp_item_cd = tgt_corp_item_cd;
	}
	public String getTgt_item_desc() {
		return tgt_item_desc;
	}
	public void setTgt_item_desc(String tgt_item_desc) {
		this.tgt_item_desc = tgt_item_desc;
	}
	public BigDecimal getTgt_pack_whse() {
		return tgt_pack_whse;
	}
	public void setTgt_pack_whse(BigDecimal tgt_pack_whse) {
		this.tgt_pack_whse = tgt_pack_whse;
	}
	public BigDecimal getTgt_vcf() {
		return tgt_vcf;
	}
	public void setTgt_vcf(BigDecimal tgt_vcf) {
		this.tgt_vcf = tgt_vcf;
	}
	public String getTgt_cds_size() {
		return tgt_cds_size;
	}
	public void setTgt_cds_size(String tgt_cds_size) {
		this.tgt_cds_size = tgt_cds_size;
	}
	public BigDecimal getTgt_size_num() {
		return tgt_size_num;
	}
	public void setTgt_size_num(BigDecimal tgt_size_num) {
		this.tgt_size_num = tgt_size_num;
	}
	public String getTgt_uom() {
		return tgt_uom;
	}
	public void setTgt_uom(String tgt_uom) {
		this.tgt_uom = tgt_uom;
	}
	public char getTgt_item_usage_Type() {
		return tgt_item_usage_Type;
	}
	public void setTgt_item_usage_Type(char tgt_item_usage_Type) {
		this.tgt_item_usage_Type = tgt_item_usage_Type;
	}
	public String getTgt_item_usage_ind() {
		return tgt_item_usage_ind;
	}
	public void setTgt_item_usage_ind(String tgt_item_usage_ind) {
		this.tgt_item_usage_ind = tgt_item_usage_ind;
	}
	public char getTgt_dipslay_flag() {
		return tgt_dipslay_flag;
	}
	public void setTgt_dipslay_flag(char tgt_dipslay_flag) {
		this.tgt_dipslay_flag = tgt_dipslay_flag;
	}
	public BigDecimal getTgt_group_cd() {
		return tgt_group_cd;
	}
	public void setTgt_group_cd(BigDecimal tgt_group_cd) {
		this.tgt_group_cd = tgt_group_cd;
	}
	public BigDecimal getTgt_category_cd() {
		return tgt_category_cd;
	}
	public void setTgt_category_cd(BigDecimal tgt_category_cd) {
		this.tgt_category_cd = tgt_category_cd;
	}
	public BigDecimal getTgt_class_cd() {
		return tgt_class_cd;
	}
	public void setTgt_class_cd(BigDecimal tgt_class_cd) {
		this.tgt_class_cd = tgt_class_cd;
	}
	public BigDecimal getTgt_sub_class_Cd() {
		return tgt_sub_class_Cd;
	}
	public void setTgt_sub_class_Cd(BigDecimal tgt_sub_class_Cd) {
		this.tgt_sub_class_Cd = tgt_sub_class_Cd;
	}
	public BigDecimal getTgt_sub_sub_class_cd() {
		return tgt_sub_sub_class_cd;
	}
	public void setTgt_sub_sub_class_cd(BigDecimal tgt_sub_sub_class_cd) {
		this.tgt_sub_sub_class_cd = tgt_sub_sub_class_cd;
	}
	public BigDecimal getTgt_upc_country() {
		return tgt_upc_country;
	}
	public void setTgt_upc_country(BigDecimal tgt_upc_country) {
		this.tgt_upc_country = tgt_upc_country;
	}
	public BigDecimal getTgt_upc_system() {
		return tgt_upc_system;
	}
	public void setTgt_upc_system(BigDecimal tgt_upc_system) {
		this.tgt_upc_system = tgt_upc_system;
	}
	public BigDecimal getTgt_upc_manuf() {
		return tgt_upc_manuf;
	}
	public void setTgt_upc_manuf(BigDecimal tgt_upc_manuf) {
		this.tgt_upc_manuf = tgt_upc_manuf;
	}
	public BigDecimal getTgt_upc_sales() {
		return tgt_upc_sales;
	}
	public void setTgt_upc_sales(BigDecimal tgt_upc_sales) {
		this.tgt_upc_sales = tgt_upc_sales;
	}
	public BigDecimal getTgt_unit_type() {
		return tgt_unit_type;
	}
	public void setTgt_unit_type(BigDecimal tgt_unit_type) {
		this.tgt_unit_type = tgt_unit_type;
	}
	public String getTgt_division() {
		return tgt_division;
	}
	public void setTgt_division(String tgt_division) {
		this.tgt_division = tgt_division;
	}
	public String getTgt_dst_cntr() {
		return tgt_dst_cntr;
	}
	public void setTgt_dst_cntr(String tgt_dst_cntr) {
		this.tgt_dst_cntr = tgt_dst_cntr;
	}
	public String getTgt_facility() {
		return tgt_facility;
	}
	public void setTgt_facility(String tgt_facility) {
		this.tgt_facility = tgt_facility;
	}
	public String getTgt_wds_pack_desc() {
		return tgt_wds_pack_desc;
	}
	public void setTgt_wds_pack_desc(String tgt_wds_pack_desc) {
		this.tgt_wds_pack_desc = tgt_wds_pack_desc;
	}
	public String getTgt_wds_size_desc() {
		return tgt_wds_size_desc;
	}
	public void setTgt_wds_size_desc(String tgt_wds_size_desc) {
		this.tgt_wds_size_desc = tgt_wds_size_desc;
	}
	public BigDecimal getTgt_pack_Retail() {
		return tgt_pack_Retail;
	}
	public void setTgt_pack_Retail(BigDecimal tgt_pack_Retail) {
		this.tgt_pack_Retail = tgt_pack_Retail;
	}
	public String getTgt_urx_pack_desc() {
		return tgt_urx_pack_desc;
	}
	public void setTgt_urx_pack_desc(String tgt_urx_pack_desc) {
		this.tgt_urx_pack_desc = tgt_urx_pack_desc;
	}
	public String getTgt_urx_Size_desc() {
		return tgt_urx_Size_desc;
	}
	public void setTgt_urx_Size_desc(String tgt_urx_Size_desc) {
		this.tgt_urx_Size_desc = tgt_urx_Size_desc;
	}
	public char getTgt_primary_upc_sw() {
		return tgt_primary_upc_sw;
	}
	public void setTgt_primary_upc_sw(char tgt_primary_upc_sw) {
		this.tgt_primary_upc_sw = tgt_primary_upc_sw;
	}
	public BigDecimal getTgt_plu_cd() {
		return tgt_plu_cd;
	}
	public void setTgt_plu_cd(BigDecimal tgt_plu_cd) {
		this.tgt_plu_cd = tgt_plu_cd;
	}
	public BigDecimal getTgt_ring() {
		return tgt_ring;
	}
	public void setTgt_ring(BigDecimal tgt_ring) {
		this.tgt_ring = tgt_ring;
	}
	public BigDecimal getTgt_hicon() {
		return tgt_hicon;
	}
	public void setTgt_hicon(BigDecimal tgt_hicon) {
		this.tgt_hicon = tgt_hicon;
	}
	public char getTgt_gift_card_ind() {
		return tgt_gift_card_ind;
	}
	public void setTgt_gift_card_ind(char tgt_gift_card_ind) {
		this.tgt_gift_card_ind = tgt_gift_card_ind;
	}
	public String getTgt_upc() {
		return tgt_upc;
	}
	public void setTgt_upc(String tgt_upc) {
		this.tgt_upc = tgt_upc;
	}
	
	
}
