package com.safeway.app.memi.web.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

public class UIObjectBuilder {
	
	private static final Logger LOG = LoggerFactory.getLogger(UIObjectBuilder.class);
    
    public List<UIDataVO> buildAugDataObject(List<UIExceptionSrcDto> exceptionList,List<NewItemDetailDto> reviewItemList)
    {
    	LOG.info("Started execution to build Aug Data Object" );
        List<UIDataVO> AugDataList=new ArrayList<UIDataVO>();
        UIDataVO overrideRec = null;
        
        Set<String> DeptSet = new TreeSet<String>();
        for(UIExceptionSrcDto obj : exceptionList)
        {
            if(null !=obj.getDeptName())
            {
            	LOG.info("obj.getDeptName  --->" + obj.getDeptName());   
                String deptName=obj.getDeptName();
                DeptSet.add(deptName);
            }
                
        }
        for(NewItemDetailDto obj : reviewItemList)
        {
            if(null !=obj.getDeptName())
            {
            	LOG.info("obj.getDeptName-->" + obj.getDeptName());   
                String deptName=obj.getDeptName();
                DeptSet.add(deptName);
            }
        }
        
        for(String st:DeptSet)
        {
            overrideRec=new UIDataVO();
            int noOfrec=0;
            int noOfReviewRecords=0;
            Set<String> prdskulist=new TreeSet<String>();
            Set<String> prdskuReview=new TreeSet<String>();
            for(UIExceptionSrcDto obj : exceptionList)
            {
                if(obj.getDeptName().equals(st))
                {
                    noOfrec++;
                    //String upcCode=obj.getUpcCountry()+obj.getUpcManufacturer()+obj.getUpcSales()+obj.getUpcSystem();
                    String prdSku=obj.getProductSKU();
                    overrideRec.setDeptName(st);
                    prdskulist.add(prdSku);
                }
            }
            overrideRec.setPrdskuSet(prdskulist);
            overrideRec.setTotalRecord(noOfrec);
            for(NewItemDetailDto obj : reviewItemList)
            {
                if(obj.getDeptName().equals(st))
                {
                    noOfReviewRecords++;
                    //String upcCode=obj.getUpcCountry()+obj.getUpcManufacturer()+obj.getUpcSales()+obj.getUpcSystem();
                    String prdSku=obj.getProductSKU();
                    overrideRec.setDeptName(st);
                    prdskuReview.add(prdSku);
                    
                    
                }
            }
            overrideRec.setReviewItmCnt(noOfReviewRecords);
            overrideRec.setReviewItemUPC(prdskuReview);
            
            AugDataList.add(overrideRec);
        }       
        LOG.info("Completed  execution to build Aug Data Object" );
        return AugDataList;
    }
}
