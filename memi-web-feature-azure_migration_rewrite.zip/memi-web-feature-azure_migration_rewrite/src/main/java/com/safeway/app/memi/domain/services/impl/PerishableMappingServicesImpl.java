/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlan;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlanPK;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ItemConvManualMatchingPlanRepository;
import com.safeway.app.memi.data.repositories.PerishableAdditonalSQLRepository;
import com.safeway.app.memi.data.repositories.PerishableSQLRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.adapters.PerishablesAdapter;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceUPC;
import com.safeway.app.memi.domain.dtos.response.ManualExpeseTypeChangeRequest;
import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequest;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.dtos.response.PerishableSKUSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableSearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.PerishableUPCwisedDetails;
import com.safeway.app.memi.domain.services.PerishableMappingServices;
import com.safeway.app.memi.domain.util.PerishableConstants;
import com.safeway.app.memi.domain.util.SortColumns;

/**
 **************************************************************************** 
 * NAME : PerishableMappingServicesImpl
 * 
 * DESCRIPTION : PerishableMappingServicesImpl is the implementation class for
 * performing search and filter operations for mapping screen and mapped screen
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 06, 2018 - Initial Creation
 * *************************************************************************
 */
@Service("PerishableMappingServices")
public class PerishableMappingServicesImpl implements PerishableMappingServices {

	private static final Logger LOG = LoggerFactory
			.getLogger(PerishableMappingServicesImpl.class);

	@Autowired
	private PerishableSQLRepository perishableSQLRepository;

	@Autowired
	private ItemConvManualMatchingPlanRepository itemConvManualMatchingPlanRepository;
	
	 @Autowired
	 private ItemAggregateCorpRepository itemAggregateRepo;
	 
	 @Autowired
	 private UIExceptionSrcRepository exSrcRepo;
	 
	 @Autowired
	 private PerishableAdditonalSQLRepository perishableAdditonalSQLRepository;
	

	private PerishablesAdapter perishablesAdapter = new PerishablesAdapter();

	/**
	 * Method to retrieve the perishable SKU search results
	 * 
	 * @param searchRequestVO
	 * @return
	 * @throws Exception 
	 */
	@Override
	public PerishableSearchRequestVO listSKUPerishableItems(
			PerishableSearchRequestVO searchRequestVO) throws Exception {
		LOG.info("Execution started to retrieve the perishable SKU search results");

		final Map<String, String> searchCriteria = createSearchCriteriaMap(searchRequestVO);
		final Map<String, String> filterCriteria = createFilterCriteriaMap(searchRequestVO);
 				
		ExecutorService executorService = Executors.newFixedThreadPool(10);		
		try
		{ 
					
		Future<BigDecimal> future1 =executorService.submit(new Callable<BigDecimal>() {
		    public BigDecimal call() throws Exception {
		    	 return perishableSQLRepository.countPerishablesSourceList(searchCriteria, filterCriteria);
		        
		    }
		});
		Future<List<PerishableSKUSearchResults>> future2 =executorService.submit(new Callable<List<PerishableSKUSearchResults>>() {
		    public List<PerishableSKUSearchResults> call() throws Exception {
		    	List<Object[]> perishableSKUSearchResults = perishableSQLRepository
						.fetchPerishablesSourceList(searchCriteria, filterCriteria);
				return perishablesAdapter
						.mapSourceItem(perishableSKUSearchResults);
		        
		    }
		});
						
		BigDecimal count =future1.get();
		if(count!=null)
		 {searchRequestVO.setSourceCount(count);}	
			
			if(null!=future2.get() && ! future2.get().isEmpty()){
				
				searchRequestVO.setSkuSearchResults(future2.get());
			}
	       		
		}
		catch(InterruptedException | ExecutionException e)
		{
			LOG.error(e.getMessage());
			throw e;
		}
		finally{
		executorService.shutdown();
		}
		List<PerishableSKUSearchResults> skuSearchResults = searchRequestVO.getSkuSearchResults();
    	String[] sortItems = searchRequestVO.getSortItems();
		if (searchRequestVO.getSortOrder() != null && !(searchRequestVO.getSortOrder().isEmpty())) {
			if (searchRequestVO.getSortOrder().equals("D")) {
				for (String str : sortItems) {
					if (str.equalsIgnoreCase("DEPT")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getDeptName).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("HIER1")) {
						skuSearchResults = skuSearchResults.stream().sorted(
								Comparator.comparing(PerishableSKUSearchResults::getHierarchyLevelOne).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("HIER2")) {
						skuSearchResults = skuSearchResults.stream().sorted(
								Comparator.comparing(PerishableSKUSearchResults::getHierarchyLevelTwo).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("HIER3")) {
						skuSearchResults = skuSearchResults
								.stream().sorted(Comparator
										.comparing(PerishableSKUSearchResults::getHierarchyLevelThree).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("SUPPL")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getSupplierNam).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("PSKU")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getSku).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("ITDS")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getItemDesc).reversed())
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("LKPSUPNO")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getSupplierNm).reversed())
								.collect(Collectors.toList());
					}

				}

			} else {
				for (String str : searchRequestVO.getSortItems()) {
					if (str.equalsIgnoreCase("DEPT")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getDeptName))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("HIER1")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getHierarchyLevelOne))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("HIER2")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getHierarchyLevelTwo))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("HIER3")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getHierarchyLevelThree))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("SUPPL")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getSupplierNam))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("PSKU")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getSku))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("ITDS")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getItemDesc))
								.collect(Collectors.toList());
					}
					if (str.equalsIgnoreCase("LKPSUPNO")) {
						skuSearchResults = skuSearchResults.stream()
								.sorted(Comparator.comparing(PerishableSKUSearchResults::getSupplierNm))
								.collect(Collectors.toList());
					}

				}
			}
		}
    	
    	searchRequestVO.setSkuSearchResults(skuSearchResults);
		LOG.info("Execution completed to retrieve the perishable SKU search results");

		return searchRequestVO;
	}

	/**
	 * Method to map the filter criteria details to a filter Criteria map
	 * 
	 * @param searchRequestVO
	 * @return
	 */
	private Map<String, String> createFilterCriteriaMap(
			PerishableSearchRequestVO searchRequestVO) {
		LOG.debug("Execution started to map the filter criteria details to a filter Criteria map");
		HashMap<String, String> filterCriteria = new HashMap<String, String>();
		setItemType(searchRequestVO, filterCriteria);
		if (null != searchRequestVO.getFilter() && searchRequestVO.isFilterAvail()) {
			if (null != searchRequestVO.getFilter().getCorpItemCD() && ! searchRequestVO.getFilter()
					.getCorpItemCD().isEmpty()) {
				filterCriteria.put("corpItemCD", searchRequestVO.getFilter()
						.getCorpItemCD());
			}
			if (null != searchRequestVO.getFilter().getDepartment() && ! searchRequestVO.getFilter()
					.getDepartment().isEmpty()) {
				filterCriteria.put("department", searchRequestVO.getFilter()
						.getDepartment());
			}

			setOtherCriterias(searchRequestVO, filterCriteria);
			if (null != searchRequestVO.getFilter().getPlu() && ! searchRequestVO.getFilter()
					.getPlu().isEmpty()) {
				filterCriteria.put("plu", searchRequestVO.getFilter().getPlu());
			}

			if (null != searchRequestVO.getFilter().getSlu() && ! searchRequestVO.getFilter()
					.getSlu().isEmpty()) {
				filterCriteria.put("slu", searchRequestVO.getFilter().getSlu());
			}
			if (null != searchRequestVO.getFilter().getVendorCode() && ! searchRequestVO.getFilter()
					.getVendorCode().isEmpty()) {
				filterCriteria.put("vendorCode", searchRequestVO.getFilter().getVendorCode());
			}
			if (null != searchRequestVO.getFilter().getVendorName() && ! searchRequestVO.getFilter()
					.getVendorName().isEmpty()) {
				filterCriteria.put("vendorName", searchRequestVO.getFilter().getVendorName());
			}
			if(searchRequestVO.getFilter().isUsageFilter())
			{
				filterCriteria.put("usageType", searchRequestVO.getFilter().getUsageType());
			}
			setSMICAndUpcFilter(searchRequestVO, filterCriteria);
			setProdHierarcyFilter(searchRequestVO, filterCriteria);
			setExpenseFilters(searchRequestVO, filterCriteria);
			setVendorOrderFilter(searchRequestVO, filterCriteria);

		}
		LOG.debug("Execution completed to map the filter criteria details to a filter Criteria map");

		return filterCriteria;
	}

	/**
	 * @param searchRequestVO
	 * @param filterCriteria
	 */
	private void setOtherCriterias(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> filterCriteria) {
		if (null != searchRequestVO.getFilter().getDivisionNum() && ! searchRequestVO.getFilter()
				.getDivisionNum().isEmpty()) {
			filterCriteria.put("divisionNum", searchRequestVO.getFilter()
					.getDivisionNum());
		}
		if (null != searchRequestVO.getFilter().getHierarchy() && ! searchRequestVO.getFilter()
				.getHierarchy().isEmpty()) {
			filterCriteria.put("hierarchy", searchRequestVO.getFilter()
					.getHierarchy());
		}
		if (null != searchRequestVO.getFilter().getItemNum() && ! searchRequestVO.getFilter()
				.getItemNum().isEmpty()) {
			filterCriteria.put("itemNum", searchRequestVO.getFilter()
					.getItemNum());
		}
		if (null != searchRequestVO.getFilter().getItemDescription() && ! searchRequestVO
				.getFilter().getItemDescription().isEmpty()) {
			filterCriteria.put("itemDescription", searchRequestVO
					.getFilter().getItemDescription());
		}
		if (null != searchRequestVO.getFilter().getProductSKU()  && ! searchRequestVO
				.getFilter().getProductSKU().isEmpty()) {
			filterCriteria.put("productSKU", searchRequestVO.getFilter()
					.getProductSKU());
		}
		if (null != searchRequestVO.getFilter().getSupplierName() && ! searchRequestVO.getFilter()
				.getSupplierName().isEmpty()) {
			filterCriteria.put("supplierName", searchRequestVO.getFilter()
					.getSupplierName());
		}
		if (null != searchRequestVO.getFilter().getSupplierNum() && ! searchRequestVO.getFilter()
				.getSupplierNum().isEmpty()) {
			filterCriteria.put("supplierNum", searchRequestVO.getFilter()
					.getSupplierNum());
		}
	}

	/**
	 * @param searchRequestVO
	 * @param filterCriteria
	 */
	private void setSMICAndUpcFilter(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> filterCriteria) {
		if (null != searchRequestVO.getFilter().getSmicGroupCd() && ! searchRequestVO.getFilter().getSmicGroupCd().isEmpty()) {
			filterCriteria.put("groupCd", searchRequestVO.getFilter().getSmicGroupCd());
		}
		if (null != searchRequestVO.getFilter().getSmicCtgryCd() && ! searchRequestVO.getFilter()
				.getSmicCtgryCd().isEmpty()) {
			filterCriteria.put("catgryCd", searchRequestVO.getFilter().getSmicCtgryCd());
		}

		if (null != searchRequestVO.getFilter().getSmicClassCd() && ! searchRequestVO.getFilter()
				.getSmicClassCd().isEmpty()) {
			filterCriteria.put("classCd", searchRequestVO.getFilter().getSmicClassCd());
		}

		if (null != searchRequestVO.getFilter().getSmicSubClassCd() && ! searchRequestVO.getFilter()
				.getSmicSubClassCd().isEmpty()) {
			filterCriteria.put("subClassCd", searchRequestVO.getFilter().getSmicSubClassCd());
		}

		if (null != searchRequestVO.getFilter().getSmicSubSubClassCd() && ! searchRequestVO.getFilter()
				.getSmicSubSubClassCd().isEmpty()) {
			filterCriteria.put("subSubClassCd", searchRequestVO.getFilter().getSmicSubSubClassCd());
		}
		if (null != searchRequestVO.getFilter().getUpc() && ! searchRequestVO.getFilter()
				.getUpc().isEmpty()) {
			filterCriteria.put("upc", searchRequestVO.getFilter().getUpc().replaceAll("-", ""));
		}

	}

	/**
	 * @param searchRequestVO
	 * @param filterCriteria
	 */
	private void setProdHierarcyFilter(
			PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> filterCriteria) {
		if (null != searchRequestVO.getFilter().getProdhierarchyLevel1() && ! searchRequestVO.getFilter()
				.getProdhierarchyLevel1().isEmpty()) {
			filterCriteria.put("prodhierarchyLevel1", searchRequestVO.getFilter().getProdhierarchyLevel1());
		}

		if (null != searchRequestVO.getFilter().getProdhierarchyLevel2() && ! searchRequestVO.getFilter()
				.getProdhierarchyLevel2().isEmpty()) {
			filterCriteria.put("prodhierarchyLevel2", searchRequestVO.getFilter().getProdhierarchyLevel2());
		}

		if (null != searchRequestVO.getFilter().getProdhierarchyLevel3() && ! searchRequestVO.getFilter()
				.getProdhierarchyLevel3().isEmpty()) {
			filterCriteria.put("prodhierarchyLevel3", searchRequestVO.getFilter().getProdhierarchyLevel3());
		}
	}

	/* expese searches*/
	private void setExpenseFilters(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> filterCriteria) {
		if(searchRequestVO.isFilterAvail())
		{
			if(searchRequestVO.getFilter().isUsageTypeIndFilter())
			{
				filterCriteria.put("expenseType", searchRequestVO.getFilter().getUsageTypeInd());
			}
			
			if(searchRequestVO.getFilter().isTotalSalesFilter())
			{
				filterCriteria.put("TOTAL_SALES_SEARCH_VALUE", searchRequestVO.getFilter().getTotalSalesvalue());
				filterCriteria.put("TOTAL_SALES_OPERATOR", searchRequestVO.getFilter().getTotalSalesOperator());
			}
			if(searchRequestVO.getFilter().isShipped())
			{
				if(searchRequestVO.getFilter().getShipSearchValue().equals("Y"))
				filterCriteria.put("shipmentSearch", "Y");
				else if(searchRequestVO.getFilter().getShipSearchValue().equals("N"))
				filterCriteria.put("shipmentSearch", "N");	
			}
			
		}
	}
	/**Vendor order Code Filter**/
	private void setVendorOrderFilter(
			PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> filterCriteria) {
		if(searchRequestVO.isFilterAvail() && searchRequestVO.getFilter().isVendorOrderFilter())
		{
			StringBuilder vendorOrder =new StringBuilder(""); 
			vendorOrder.append(searchRequestVO.getFilter().getVendUpcPackInd() !=null && !searchRequestVO.getFilter().getVendUpcPackInd().trim().equals("")
					?  searchRequestVO.getFilter().getVendUpcPackInd() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(searchRequestVO.getFilter().getVendUpcCountry() !=null && !searchRequestVO.getFilter().getVendUpcCountry().trim().equals("")
					?  searchRequestVO.getFilter().getVendUpcCountry() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(searchRequestVO.getFilter().getVendUpcNumSys() !=null && !searchRequestVO.getFilter().getVendUpcNumSys().trim().equals("")
					?  searchRequestVO.getFilter().getVendUpcNumSys() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(searchRequestVO.getFilter().getVendUpcManuf() !=null && !searchRequestVO.getFilter().getVendUpcManuf().trim().equals("")
					?  searchRequestVO.getFilter().getVendUpcManuf() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(searchRequestVO.getFilter().getVendUpcItem() !=null && !searchRequestVO.getFilter().getVendUpcItem().trim().equals("")
					?  searchRequestVO.getFilter().getVendUpcItem() : "NA");
			
			filterCriteria.put("vendorOrderFilter", vendorOrder.toString());
			
		}
		
	}

	/**
	 * Method to map the search criteria details to a search Criteria map
	 * 
	 * @param searchRequestVO
	 * @return
	 */
	private HashMap<String, String> createSearchCriteriaMap(
			PerishableSearchRequestVO searchRequestVO) {
		LOG.debug("Execution started to create Search Criteria map");

		HashMap<String, String> searchCriteria = new HashMap<String, String>();
		if(searchRequestVO.getStartIndex()!=null && searchRequestVO.getEndIndex()!=null
			&& !searchRequestVO.getStartIndex().trim().equals("") && !searchRequestVO.getEndIndex().trim().equals("")	
				)
		{
		searchCriteria.put("startIndex", searchRequestVO.getStartIndex());
		searchCriteria.put("endIndex", searchRequestVO.getEndIndex()); 
		}
		else
		{
		searchCriteria.put("startIndex", "1");
		searchCriteria.put("endIndex", "1000"); 	
		}
		if (null != searchRequestVO.getCompanyID()
				&& !searchRequestVO.getCompanyID().isEmpty()) {
			searchCriteria.put("companyID", searchRequestVO.getCompanyID());
		}
		if (null != searchRequestVO.getDivisionID()
				&& !searchRequestVO.getDivisionID().isEmpty()) {
			searchCriteria.put("divisionID", searchRequestVO.getDivisionID());
		}
		if (null != searchRequestVO.getMappingStatus()
				&& !searchRequestVO.getMappingStatus().isEmpty()) {
				searchCriteria.put("mappingStatus",
						searchRequestVO.getMappingStatus());
		}
		setItemType(searchRequestVO, searchCriteria);
		setSearchType(searchRequestVO, searchCriteria);
			if (null != searchRequestVO.getSearchCriteriaValue()
					&& !searchRequestVO.getSearchCriteriaValue().isEmpty()){
				if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.PLU_VAL)){
				 searchCriteria.put(PerishableConstants.SEARCH_VAL,"%"+searchRequestVO.getSearchCriteriaValue().trim());
				}
				else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL))
				{
					 searchCriteria.put(PerishableConstants.SEARCH_VAL,searchRequestVO.getSearchCriteriaValue().trim().replaceAll("-", ""));
				}
				else{
					searchCriteria.put(PerishableConstants.SEARCH_VAL,searchRequestVO.getSearchCriteriaValue().trim());	
				}
			}
		 setSortParams(searchRequestVO, searchCriteria);
			LOG.debug("Execution completed to create Search Criteria map");

		return searchCriteria;
	}

	private void setSortParams(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> searchCriteria) {
		LOG.info("Execution started to set Sort Params");

		StringBuilder sortColumns = new StringBuilder("");
		
		 if(searchRequestVO.getSortItems()!=null)
		 {
			 for (String key :searchRequestVO.getSortItems())
			 {
				 if(!sortColumns.toString().equals(""))
				 {
					 sortColumns.append(",");
				 }
				 SortColumns sc=SortColumns.valueOf( key);
				 sortColumns.append(sc.getColumns());
				 
			 }
		 }
		 
		 /* in case of no choice default codtion*/
		 if(sortColumns.toString().equals(""))
		 {
			 sortColumns.append(SortColumns.PSKU.getColumns());			 
		 }
		 /***/
		 searchCriteria.put("sortColumns", sortColumns.toString());
		 if(searchRequestVO.getSortOrder() !=null && searchRequestVO.getSortOrder().equals("D")){
			 searchCriteria.put("sortOrder", " DESC ");
		 }
		 else
		 {
			 searchCriteria.put("sortOrder", " ASC "); 
		 }
			LOG.debug("Execution completed to set Sort Params");

	}

	private void setItemType(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> searchCriteria) {
		if (null != searchRequestVO.getItemType()) {
			if (searchRequestVO.getItemType().isAll()) {
				searchCriteria.put(PerishableConstants.itemType, "All");
			}
			if (searchRequestVO.getItemType().isPlu()) {
				searchCriteria.put(PerishableConstants.itemType, "PLU");
			}
			if (searchRequestVO.getItemType().isSystem2()) {
				searchCriteria.put(PerishableConstants.itemType, "System2");
			}
			if (searchRequestVO.getItemType().isSystem4()) {
				searchCriteria.put(PerishableConstants.itemType, "System4");
			}
		}
	}

	private void setSearchType(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> searchCriteria){
		if (null != searchRequestVO.getSearchCriteria()
				&& !searchRequestVO.getSearchCriteria().isEmpty()) {
			if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)) {
				searchCriteria.put(PerishableConstants.searchType, "upper(C.PROD_HIERARCHY_LVL_4_CD)");
			}
			if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.SKU_VAL)) {
				searchCriteria.put(PerishableConstants.searchType, "upper(C.product_sku)");
			}
			if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)) {
				searchCriteria.put(PerishableConstants.searchType, "DESC_ITEM");
			}
			if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL)) {
				searchCriteria.put(PerishableConstants.searchType, PerishableConstants.UPC_VAL);
			}
			if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.PLU_VAL)) {
				searchCriteria.put(PerishableConstants.searchType, "  X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND upper( X.SRC_UPC_SALES ) ");
			}
			if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.USAGE_TYPE)){
				
				searchCriteria.put(PerishableConstants.searchType, PerishableConstants.USAGE_TYPE);
			}
			
			setOtherSearchTypes(searchRequestVO, searchCriteria);
	   }
	}

	/**
	 * @param searchRequestVO
	 * @param searchCriteria
	 */
	private void setOtherSearchTypes(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> searchCriteria) {
		if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.WHSE_DSD)) {
			searchCriteria.put(PerishableConstants.searchType, PerishableConstants.WHSE_DSD);
		}
		if (searchRequestVO.getSearchCriteria().endsWith("DISP")) {
			searchCriteria.put(PerishableConstants.searchType, "C.MULTI_COMP_ITEM_IND");
		}
		if (searchRequestVO.getSearchCriteria().endsWith("TOTAL_SALES")) {
			searchCriteria.put(PerishableConstants.searchType, "TOTAL_SALES");
			if(null!=searchRequestVO.getTotalSalesOperator()){
				searchCriteria.put("OPERATOR", searchRequestVO.getTotalSalesOperator());
			}
		}
		
	}
	/**
	 * Method to retrieve the perishable CIC search results
	 * 
	 * @param searchRequestVO
	 * @return
	 * @throws Exception 
	 */
	@Override
	public PerishableSearchRequestVO listCICPerishableItems(
			PerishableSearchRequestVO searchRequestVO) throws Exception {
		LOG.info("Execution started to retrieve the perishable CIC search results");


		final Map<String, String> searchCriteria = createTargetSearchCriteriaMap(searchRequestVO);
		final Map<String, String> filterCriteria = createFilterCriteriaMap(searchRequestVO);
	
		
		ExecutorService executorService = Executors.newFixedThreadPool(10);		
		try
		{ 
					
		Future<BigDecimal> future1 =executorService.submit(new Callable<BigDecimal>() {
		    public BigDecimal call() throws Exception {
		    	 return perishableSQLRepository.countPerishablesTargetList(searchCriteria, filterCriteria);
		        
		    }
		});
		Future<List<PerishableCICSearchResults>> future2 =executorService.submit(new Callable<List<PerishableCICSearchResults>>() {
		    public List<PerishableCICSearchResults> call() throws Exception {
		    	List<Object[]> perishableCICSearchResults = perishableSQLRepository
						.fetchPerishablesTargetList(searchCriteria, filterCriteria);
		    	LOG.debug("Completed fetching for"+perishableCICSearchResults.size()+"perishable CIC Search Results" );
		    	return perishablesAdapter.mapTargetItem(perishableCICSearchResults);
		        
		    }
		});
						
		BigDecimal count =future1.get();
		if(count!=null)
		 {searchRequestVO.setTargetCount(count);
		
		 }	
			
			if(null!=future2.get() && ! future2.get().isEmpty()){
				
				searchRequestVO.setCicSearchResults(future2.get());
				  
			}
			
		}
		catch(InterruptedException | ExecutionException e)
		{
			e.getMessage();
			LOG.error(e.getMessage());
			throw e;
		}
		finally{
		executorService.shutdown();
		
		}
		LOG.info("Execution completed to retrieve the perishable CIC search results");

		return searchRequestVO;
		

	}

	/**
	 * Method to retrieve the perishable CIC search results
	 * 
	 * @param searchRequestVO
	 * @return
	 */
	private Map<String, String> createTargetSearchCriteriaMap(
			PerishableSearchRequestVO searchRequestVO) {
		LOG.debug("Execution started for creating Target Search Criteria Map");

		HashMap<String, String> searchCriteria = new HashMap<String, String>();

		if (null != searchRequestVO.getMappingStatus()
				&& !searchRequestVO.getMappingStatus().isEmpty() && !"SHOW_ALL".equals(searchRequestVO.getMappingStatus())) {
			searchCriteria.put("mappingStatus",
					searchRequestVO.getMappingStatus());
		}
		setItemType(searchRequestVO, searchCriteria);
		if (null != searchRequestVO.getSearchCriteria()&& !searchRequestVO.getSearchCriteria().isEmpty()) {
	          if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
                setDeptNameFilter(searchRequestVO, searchCriteria);
          }else{
				setOtherFilters(searchRequestVO, searchCriteria);
					if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.WHSE_DSD)){
					
						searchCriteria.put(PerishableConstants.SEARCH_VAL,searchRequestVO.getSearchCriteriaValue().substring(0,1));
					}else
					{
						searchCriteria.put(PerishableConstants.SEARCH_VAL,searchRequestVO.getSearchCriteriaValue());
					}
				}
		}
		LOG.debug("Execution completed for creating Target Search Criteria Map");

		return searchCriteria;
	}

	/**
	 * @param searchRequestVO
	 * @param searchCriteria
	 */
	private void setOtherFilters(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> searchCriteria) {
		if (searchRequestVO.getSearchCriteria().endsWith("CIC_VAL")) {
			searchCriteria.put(PerishableConstants.searchType, "CIC_VAL");
		}
		if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)) {
			searchCriteria.put(PerishableConstants.searchType, "DESC_ITEM");
		}
		if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL)) {
			searchCriteria.put(PerishableConstants.searchType, "UPC_VAL");
		}
		
		if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
			searchCriteria.put(PerishableConstants.searchType, "OMDEPT.DEPT_NAME");
		}
		if(searchRequestVO.getSearchCriteria().endsWith("ITEM_USAGE")){
			searchCriteria.put(PerishableConstants.searchType, "CDS.ITEM_USAGE_TYPE");
		}
		if(searchRequestVO.getSearchCriteria().endsWith("DISPLAY")){
			searchCriteria.put(PerishableConstants.searchType, PerishableConstants.CDS_DISP_FLAG);
		}
		if(searchRequestVO.getSearchCriteria().endsWith("SMIC")){
			searchCriteria.put(PerishableConstants.searchType, "SMIC");
		}
		if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.PLU_VAL)){
			searchCriteria.put(PerishableConstants.searchType, "POS.PLU_CD");
		}
		if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.WHSE_DSD)){
			searchCriteria.put(PerishableConstants.searchType, "WDS.DST_CNTR");
			
		}
		if(searchRequestVO.getSearchCriteria().endsWith("DISP")){
			searchCriteria.put(PerishableConstants.searchType, PerishableConstants.CDS_DISP_FLAG);
		}
		if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.USAGE_TYPE)){

			searchCriteria.put(PerishableConstants.searchType, PerishableConstants.USAGE_TYPE);
		}
	}

	/**
	 * @param searchRequestVO
	 * @param searchCriteria
	 */
	private void setDeptNameFilter(PerishableSearchRequestVO searchRequestVO,
			HashMap<String, String> searchCriteria) {
		LOG.debug("Execution started for set Dept Name Filter");

		searchCriteria.put(PerishableConstants.searchType, PerishableConstants.DEPT_NAME);
		if (!searchRequestVO.getSearchCriteriaValue().isEmpty()) {
		       String[] searchValueList = searchRequestVO
		                     .getSearchCriteriaValue().split(",");
		       StringBuilder searchValue = new StringBuilder();
		       for (String value : searchValueList) {
		              if (searchValue.length() > 0) {
		                     searchValue.append(",");
		              }
		              searchValue.append("'");
		              searchValue.append(value);
		              searchValue.append("'");
		       }
		       searchCriteria.put(PerishableConstants.SEARCH_VAL, searchValue.toString());
		}
		LOG.debug("Execution completed for set Dept Name Filter");

	}
    /**
     * Method to perform mapping action based on mapping option selected
     * 
     *  @param mappingRequest
	 *  @return
     */
    @Override
	public void performAction(PerishableMappingRequestWrapper mappingRequest) {
		LOG.info("Execution started for perform mapping action based on mapping option selected");

		if (null != mappingRequest.getMappingrequest()
				&& !mappingRequest.getMappingrequest().isEmpty()) {
			List<PerishableMappingRequest> perishableMappingRequest = mappingRequest
					.getMappingrequest();
			if(mappingRequest.isFromMappedScreen()){
				performMappedAction(perishableMappingRequest);
			}else{
				performMappingAction(perishableMappingRequest);
			}
			
		}
		LOG.info("Execution completed for perform mapping action based on mapping option selected");

	}
    
    /**
	 * @param perishableMappingRequest
	 */
	private void performMappingAction(List<PerishableMappingRequest> perishableMappingRequest) {
		LOG.debug("Execution started for perform Mapping Action");

		       updateMatchedItemTypeCd(perishableMappingRequest);
		for (PerishableMappingRequest pm : perishableMappingRequest) {
			if (!PerishableConstants.FORCE_NEW.equals(pm.getMappingType()) && !PerishableConstants.RESERVED.equals(pm.getMappingType())) {
				removeFromReservedList(pm);
				updateStatusForAction(pm,false);
				ItemConvManualMatchingPlan entity = buildEntity(pm);
				itemConvManualMatchingPlanRepository.saveAndFlush(entity);

			}
			else if(PerishableConstants.RESERVED.equals(pm.getMappingType()))
			{
				
				ItemConvManualMatchingPlan  entity =itemConvManualMatchingPlanRepository.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndItemConvManualMatchingPlanPkMatchedItemTypeCdAndMappingTypeAndMappingStatus
						(pm.getCompanyID(), pm.getDivisionID(), pm.getSku(), pm.getUpc().replaceAll("-", ""), "E", "ETL_AUTO_MATCH", "UN_MAPPED");
				if(entity!=null)
				{	entity.setMappingStatus(pm.getMappingstatus().trim().toUpperCase());
					entity.setMappingComments(pm.getComments());	
					entity.setUpdateTs(new Date());
					entity.setTargetPlu(null);
				}
				else
				{
					 entity = buildEntity(pm);
				}
				itemConvManualMatchingPlanRepository.saveAndFlush(entity);
			}
		}
		LOG.debug("Execution completed for perform Mapping Action");

	}
	
	private void removeFromReservedList(PerishableMappingRequest pm) {
		LOG.debug("Execution started for remove item From Reserved List");

		
		ItemConvManualMatchingPlan  entity =itemConvManualMatchingPlanRepository.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndMappingType
				(pm.getCompanyID(), pm.getDivisionID(), pm.getSku(), pm.getUpc().replaceAll("-", ""), "RESERVED");
		if(entity!=null)
		{
			itemConvManualMatchingPlanRepository.delete(entity);
		}
		LOG.debug("Execution completed for remove item From Reserved List");

	}
   private void updateFromETLReservedList(PerishableMappingRequest pm) {
		LOG.debug("Execution started for update item From ETL ReservedList");

		
		ItemConvManualMatchingPlan  entity =itemConvManualMatchingPlanRepository.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndMappingType
				(pm.getCompanyID(), pm.getDivisionID(), pm.getSku(), pm.getUpc().replaceAll("-", ""), "ETL_AUTO_MATCH");
		if(entity!=null)
		{   entity.setMappingStatus("CORRECTED");
			entity.setUpdateTs(new Date());
			itemConvManualMatchingPlanRepository.saveAndFlush(entity);
		}
		LOG.debug("Execution completed for update item From ETL ReservedList");

	}

	private void updateMatchedItemTypeCd(List<PerishableMappingRequest> perishableMappingRequest) {
		LOG.debug("Execution started for update Matched Item TypeCd");

		HashMap<String, String> productSkuMap=createMapBasedOnProductSku(perishableMappingRequest);
		for (PerishableMappingRequest pm : perishableMappingRequest) {
			String productSku=pm.getSku();
			if( (pm.getMappingType().equals(PerishableConstants.ADD_MAP) || pm.getMappingType().equals(PerishableConstants.INHERIT_MAP))					
					&& productSkuMap.containsKey(productSku)){
				pm.setMatchedItemTypeCd(productSkuMap.get(pm.getSku()));
			}
			else if(pm.getMatchedItemTypeCd() !=null && !pm.getMatchedItemTypeCd().equals("") && pm.getMatchedItemTypeCd().equals("E"))
			{
				pm.setMatchedItemTypeCd("E");
			}
			else if(productSkuMap.containsKey(productSku))
			{
				pm.setMatchedItemTypeCd(productSkuMap.get(productSku));
			}
			else
			{
				pm.setMatchedItemTypeCd("Y");
			}
		}
		LOG.debug("Execution completed for update Matched Item TypeCd");

	}
	
	
	
	private HashMap<String, String> createMapBasedOnProductSku(List<PerishableMappingRequest> perishableMappingRequest) {
		LOG.debug("Execution started for create Map Based On ProductSku");

		HashMap<String, String> map = new HashMap<>();
		for (PerishableMappingRequest pm : perishableMappingRequest) {
			String productSku = pm.getSku();
			String upc = StringUtils.leftPad(pm.getUpc().replaceAll("-", ""),12, "0");
			if(pm.getMatchedItemTypeCd() !=null && !pm.getMatchedItemTypeCd().equals("")){	
				
			
					if(!map.containsKey(productSku)){
						if(
							(pm.getMappingType().equals(PerishableConstants.ADD_MAP) || pm.getMappingType().equals(PerishableConstants.INHERIT_MAP)
							||pm.getMappingType().equals(PerishableConstants.FORCE_NEW))	
							&&								
							(Float.parseFloat(upc) < 100000)
								)
						{
							map.put(productSku, "P");								
						}
						else if (pm.getMatchedItemTypeCd().equals("E")) {
							map.put(productSku, "E");
						}
						else{
							map.put(productSku, "Y");
						}
						
					}else{
						 if (
								(pm.getMappingType().equals(PerishableConstants.ADD_MAP) || pm.getMappingType().equals(PerishableConstants.INHERIT_MAP)
										||pm.getMappingType().equals(PerishableConstants.FORCE_NEW))	
										&&								
										(Float.parseFloat(upc) < 100000)
											)
						{
							map.put(productSku, "P");	
						}
						else if(pm.getMatchedItemTypeCd().equals("E") && !map.get(productSku).equals("P"))
						{
							map.put(productSku, "E");
						}
						else if(!map.get(productSku).equals("P") && !map.get(productSku).equals("E") )
						{
							map.put(productSku, "Y");
						}
						
					}		
				 
				 
				 
				 
			}
		}
		LOG.debug("Execution completed for create Map Based On ProductSku");

		return map;
	}
	
	/**
	 * Service Method to update conversion status in  XREFLAND.SRC_ITEM_XRF table
	 * @param pm
	 */
	private void updateStatusForAction(PerishableMappingRequest perishableMappingRequest,boolean isUnmap) {
		LOG.debug("Execution started for update Status For Action");

		
		Object[] inputs =new Object[8];
		
		inputs[0]=perishableMappingRequest.getCompanyID();
		inputs[1]=perishableMappingRequest.getDivisionID();
		inputs[2]=perishableMappingRequest.getSku();
		
		String upc =perishableMappingRequest.getUpc().replaceAll("-", "");
		if(upc.length() <12)
		{
			upc=StringUtils.leftPad(upc, 12, '0');
		}
		
      
        	inputs[3]=upc.substring(0,1);
            inputs[4]=upc.substring(1,2);
            inputs[5]=upc.substring(2,7);
            inputs[6]=upc.substring(7,12);
            
            inputs[7]=perishableMappingRequest.getComments();
		
        
        if(!isUnmap){
        	if (PerishableConstants.MARK_AS_DEAD.equals(perishableMappingRequest
    				.getMappingType())) {        
    	        if(!perishableSQLRepository.checkMarkAsDead(inputs)){
    	        	if(perishableSQLRepository.markAsDead(inputs)){
    	        		LOG.info("Sucessfully updated marks dead ");
    	        	}else{
    	        		LOG.info("Mark as dead update failed");
    	        	}
    	        }
            }
            
            else if (PerishableConstants.ADD_MAP.equals(perishableMappingRequest.getMappingType())
    				|| PerishableConstants.INHERIT_MAP.equals(perishableMappingRequest.getMappingType()) ||
    				PerishableConstants.FORCE_NEW.equals(perishableMappingRequest.getMappingType()) || 
    				PerishableConstants.LET_AUTO_MATCH.equals(perishableMappingRequest.getMappingType())) {
        		if(perishableSQLRepository.updateStatusForMappingAction(inputs)){
            		LOG.info("Sucessfully updated in DB");
            	}else{
            		LOG.info("Database update action failed");
            	}
        		
        	}
        	
        }
        else{
    		if(perishableSQLRepository.updateStatusForUnMapAction(inputs)){
        		LOG.info("Sucessfully updated");
        	}else{
        		LOG.info("Action failed");
        	}
    	}
    	
		LOG.debug("Execution completed for update Status For Action");

	}

	/**
	 * Method to perform unmap action in the mapped screen.
	 * Current mapping status will be updated to "UN_MAPPED"
	 * @param perishableMappingRequest
	 */
	private void performMappedAction(List<PerishableMappingRequest> perishableMappingRequest) {
		for (PerishableMappingRequest mappingRequest : perishableMappingRequest) {
			    updateStatusForAction(mappingRequest,true);
				boolean isUpdated = perishableSQLRepository.updateMappingStatus(
						mappingRequest.getCompanyID(), mappingRequest.getDivisionID(), mappingRequest.getSku(),
						mappingRequest.getCic(), mappingRequest.getUpc(), mappingRequest.getMappingType(),PerishableConstants.UN_MAPPED);
				if(isUpdated){
					LOG.info("mapping status updated to Unmapped Sucessfully..!! ");
	        	}else{
	        		LOG.info("Unmapped Action failed..!!");
	        	}
			
		}
	}


	/**
	 * @param pm
	 * @return
	 */
	private ItemConvManualMatchingPlan buildEntity(PerishableMappingRequest pm) {
		LOG.debug("Execution started for Item Conv Manual Matching Plan");

		ItemConvManualMatchingPlan entity = new ItemConvManualMatchingPlan();
		ItemConvManualMatchingPlanPK entityPk = new ItemConvManualMatchingPlanPK();
		entityPk.setCompanyId(pm.getCompanyID());
		entityPk.setDivisionId(pm.getDivisionID());
		entityPk.setProductSKU(pm.getSku());
		entityPk.setUpc(pm.getUpc());
			entityPk.setMatchedItemTypeCd(pm.getMatchedItemTypeCd());	
		
		entity.setItemConvManualMatchingPlanPK(entityPk);
		 
		if(pm.getTargetPLU()!=null && !pm.getTargetPLU().isEmpty() &&  pm.getTargetPLU().length()<=5 
				&& Float.parseFloat(pm.getUpc()) < 100000
				&& (pm.getMappingType().equals(PerishableConstants.ADD_MAP) || pm.getMappingType().equals(PerishableConstants.INHERIT_MAP))
				){
			entity.setTargetPlu(pm.getTargetPLU());
		}
		else
		{
			entity.setTargetPlu(null);
		}
		
		entity.setCorpItemCd((pm.getCic() != null && !pm.getCic()
				.equals("")) ? new BigDecimal(pm.getCic())
				: new BigDecimal("0"));
		if (PerishableConstants.MARK_AS_DEAD.equals(pm
				.getMappingType())) {
			entity.setMappingStatus(PerishableConstants.MARK_AS_DEAD);
		} 
		else if(PerishableConstants.LET_AUTO_MATCH.equals(pm.getMappingType())){
			entity.setMappingStatus(PerishableConstants.LET_AUTO_MATCH);	
		}
		else if(PerishableConstants.FORCE_NEW.equals(pm.getMappingType())){
			entity.setMappingStatus(PerishableConstants.FORCE_NEW);	
			entity.setCorpItemCd(new BigDecimal("0"));
		}
		else if(PerishableConstants.RESERVED.equals(pm.getMappingType())){
			entity.setMappingType(PerishableConstants.RESERVED);
			entity.setMappingStatus(pm.getMappingstatus());	
			entity.setCorpItemCd(new BigDecimal("0"));
			entity.setTargetPlu(null);
		}		
		else {
			entity.setMappingStatus(PerishableConstants.MAPPED);
		}
		entity.setMappingType(pm.getMappingType());
		entity.setMappingComments(pm.getComments());
		entity.setUpdateTs(new Date());
		entity.setUpdateUserId(pm.getUpdatedUserId());	
		
		
		if(pm.isTargetEdited())
		{
			entity.setPackDesc(getStringValue(pm.getDcPackDesc()));
			entity.setSizeDesc(getStringValue(pm.getDcSizeDsc()));
			entity.setRetailUnitPack(getStringValue(pm.getRetailUnitPack()));
			entity.setRing(getStringValue(pm.getRing()));
			entity.setHicone(getStringValue(pm.getHicone()));
			
			/**/
			
			entity.setProdwght(getStringValue(pm.getProdwght()));
			entity.setHandlingCode(getStringValue(pm.getHandlingCode()));
			entity.setBuyerNum(getStringValue(pm.getBuyerNum()));
			entity.setRandomWtCd(getStringValue(pm.getRandomWtCd()));
			entity.setAutoCostInv(getStringValue(pm.getAutoCostInv()));
			entity.setBillingType(getStringValue(pm.getBillingType()));
			entity.setFdStmp(getStringValue(pm.getFdStmp()));
			entity.setTareCd(getStringValue(pm.getTareCd()));
			entity.setLabelSize(getStringValue(pm.getLabelSize()));
			entity.setLabelNumbers(getStringValue(pm.getLabelNumbers()));
			entity.setPrcTypeCd(getStringValue(pm.getPrcTypeCd()));
			entity.setSgnCount1(getStringValue(pm.getSgnCount1()));
			entity.setSgnCount2(getStringValue(pm.getSgnCount2()));
			entity.setSgnCount3(getStringValue(pm.getSgnCount3()));
			entity.setCostAllow(getStringValue(pm.getCostAllow()));
			entity.setCostIb(getStringValue(pm.getCostIb()));
			entity.setCostInv(getStringValue(pm.getCostInv()));
			entity.setCostVend(getStringValue(pm.getCostVend()));
			entity.setSellByDays(getStringValue(pm.getSellByDays()));
			entity.setEatByDays(getStringValue(pm.getUseByDays()));
			entity.setPullByDays(getStringValue(pm.getPullBydays()));
			
		}
		LOG.debug("Execution completed for Item Conv Manual Matching Plan");

		return entity;
	}

	private String getStringValue(Object obj) {
		if (obj == null)
		{
			return "";
		}
		String str =  obj.toString();
		return str.trim();
		
	}
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return  new BigDecimal(obj.toString());
	}
	private Integer getIntegerValue(Object obj){
		if(obj == null)
			return Integer.valueOf(0);
		return Integer.parseInt(obj.toString());
	}
	@Override
	public boolean duplicateCheckOnMappedItems(List<PerishableMappingRequest> perishableMappingRequests) {	
		LOG.info("Execution started for duplicate Check On MappedItems");

		
		boolean duplicate= false;
		
		for (PerishableMappingRequest pm : perishableMappingRequests) {
				Object[] inputs =new Object[4];
					
				inputs[0]=pm.getCompanyID();
				inputs[1]=pm.getDivisionID();
				inputs[2]=pm.getSku();
				inputs[3]=pm.getUpc();
				if(!duplicate)
				{duplicate=	perishableSQLRepository.checkDuplicateExistence(inputs);}
				
			}
		LOG.info("Execution completed for duplicate Check On MappedItems");

		return duplicate;
			}
	/**
	 * Method to perform mapping action when Mark as Dead option is chosen
	 * 
	 * @param request
	 */
	private void performMarkAsDeadAction(PerishableMappingRequest request){
		
		Object[] inputs =new Object[8];
		
		inputs[0]=request.getCompanyID();
		inputs[1]=request.getDivisionID();
		inputs[2]=request.getSku();
		inputs[3]=request.getUpc().substring(0,1);
        inputs[4]=request.getUpc().substring(1,2);
        inputs[5]=request.getUpc().substring(2,7);
        inputs[6]=request.getUpc().substring(7,12);
        
        inputs[7]=request.getComments();
        
        if(!perishableSQLRepository.checkMarkAsDead(inputs)){
        	if(perishableSQLRepository.markAsDead(inputs)){
        		LOG.info("Sucessfully updated");
        	}else{
        		LOG.info("Action failed");
        	}
        }
	}

	@Override
	public String saveForceNewInPerishableMapping(
			List<PerishableMappingRequest> perishableMappingRequests) {
		LOG.info("Execution started for save Force New In Perishable Mapping");

		
	
		if(perishableMappingRequests!=null && !perishableMappingRequests.isEmpty())
		{
			/*PRODUCE PLU CALL*/
			HashMap<String, String> productSkuMap=createMapBasedOnProductSku(perishableMappingRequests);
			/**/
			for(PerishableMappingRequest perishableMappingRequest : perishableMappingRequests)
			{
				/*Reserve action changes*/
				removeFromReservedList(perishableMappingRequest);
				updateFromETLReservedList(perishableMappingRequest);
				updateForceNewInPerishableMapping(perishableMappingRequest);
				ItemConvManualMatchingPlan entity = new ItemConvManualMatchingPlan();
				ItemConvManualMatchingPlanPK entityPk = new ItemConvManualMatchingPlanPK();
				entityPk.setCompanyId(perishableMappingRequest.getCompanyID());
				entityPk.setDivisionId(perishableMappingRequest.getDivisionID());
				entityPk.setProductSKU(perishableMappingRequest.getSku());
				entityPk.setUpc(perishableMappingRequest.getUpc().replaceAll("-", ""));
				
				entityPk.setMatchedItemTypeCd(productSkuMap.get(perishableMappingRequest.getSku()));
				
				
				entity.setItemConvManualMatchingPlanPK(entityPk);
				
				entity.setMappingStatus(PerishableConstants.FORCE_NEW);
				entity.setMappingType(PerishableConstants.FORCE_NEW);
				entity.setMappingComments(perishableMappingRequest.getComments());
				entity.setUpdateTs(new Date());
				entity.setCorpItemCd(new BigDecimal("0"));
				entity.setUpdateUserId(perishableMappingRequest.getUpdatedUserId());	
				entity.setTargetPlu(null);
				itemConvManualMatchingPlanRepository.saveAndFlush(entity);
			}
		}
		LOG.info("Execution completed for save Force New In Perishable Mapping");

		return "Successfully inserted";
	}

	
	public void createNewCic(PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto, String forceNewType) {
		insertRecordToUIExceptionSrc(perishableItemCreateMatchCicDto, forceNewType);
	}
	
	
	
	/**
	 * Method to insert source data To UIExceptionSrc table
	 * @param perishableItemCreateMatchCicDto
	 * @param forceNewType
	 */
	private void insertRecordToUIExceptionSrc(PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto,String forceNewType) {
		LOG.debug("Execution started for insert Record To UI Exception Src");

		if (perishableItemCreateMatchCicDto != null) {
	
					List<String> costCorp =perishableSQLRepository.addtionalDetailsForDto(perishableItemCreateMatchCicDto.getCompanyId(), perishableItemCreateMatchCicDto.getDivisionId(),
							perishableItemCreateMatchCicDto.getProductSku());
					if(costCorp!=null && !costCorp.isEmpty())
					{
						perishableItemCreateMatchCicDto.setCaseUpc(costCorp.get(0));
											}
					else
					{
						perishableItemCreateMatchCicDto.setCaseUpc("0000000000000");
					}
					boolean isInserted = false;
					
					if (!perishableItemCreateMatchCicDto.getSourceComponentUpc().isEmpty()) {
						for (DisplayItemSourceUPC corpUpcObject : perishableItemCreateMatchCicDto.getSourceComponentUpc()) {
							String corpUpc = corpUpcObject.getUpc();
							List<ItemAggregateCorp> sourceObjs = itemAggregateRepo
										.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
												perishableItemCreateMatchCicDto.getProductSku(),perishableItemCreateMatchCicDto.getDivisionId(),perishableItemCreateMatchCicDto.getCompanyId(),corpUpc);
												
									UIExceptionSrc excSrc = new UIExceptionSrc();
									UiExceptionSrcPk excSrcPk = new UiExceptionSrcPk();
									buildExcSrc(perishableItemCreateMatchCicDto, corpUpc, excSrc,excSrcPk,forceNewType);
									for (ItemAggregateCorp itemAggregateCorp : sourceObjs) {
										setItemAggregateCorpData(excSrc,itemAggregateCorp,excSrcPk);
									}
									excSrc.setUiSrcPk(excSrcPk);
									exSrcRepo.save(excSrc);
									
						}
					}				
		}
		LOG.debug("Execution completed for insert Record To UI Exception Src");

	}

	/**
	 * @param excSrc
	 * @param itemAggregateCorp
	 */
	private void setItemAggregateCorpData(UIExceptionSrc excSrc,
			ItemAggregateCorp itemAggregateCorp,UiExceptionSrcPk excSrcPk) {
		LOG.debug("Execution started for set Item Aggregate CorpData");

		excSrc.setPrdHierLevel1((itemAggregateCorp.getPrdHierLevel1()));
		excSrc.setPrdHierLevel2((itemAggregateCorp.getPrdHierLevel2()));
		excSrc.setPrdHierLevel3((itemAggregateCorp.getPrdHierLevel3()));
		excSrc.setPrdHierLevel4((itemAggregateCorp.getPrdHierLevel4()));
		excSrc.setPrdHierLevel5((itemAggregateCorp.getPrdHierLevel5()));

		excSrc.setSizeNmbr(itemAggregateCorp.getSizeNmbr());
		excSrc.setSizeUom(itemAggregateCorp.getSizeUom());
		excSrc.setSizeDesc(itemAggregateCorp.getSizeDesc());
		excSrc.setItmDesc(itemAggregateCorp.getItemDesc());
		excSrc.setPrmyUpcInd(itemAggregateCorp.getPrimaryUpcInd());
		
		excSrc.setPtLabelInd(itemAggregateCorp.getPrivateLevelInd());
		excSrc.setLogicalInd(itemAggregateCorp.getLogicalDelInd());
		excSrc.setBatchId(itemAggregateCorp.getBatchId().intValue());
		excSrc.setIntenetItemDesc(itemAggregateCorp.getInternetDesc());
		excSrc.setWhseItmDesc(itemAggregateCorp.getWhseItemDesc());
		
		if (itemAggregateCorp.getSrcByDsd().equals("Y")) {
			excSrcPk.setProductSrcCd("DSD");
		}
		if (itemAggregateCorp.getSrcByWhse().equals("Y")) {
			excSrcPk.setProductSrcCd("WHSE");
		}
		
		if(itemAggregateCorp.getMaterialItemInd().equals('Y') &&
				itemAggregateCorp.getExpenseItemInd().equals('N')	
				)
		{
			excSrc.setItemUsgeInd('M');
			excSrc.setItemUsageTypInd('M');
		}
		else if(itemAggregateCorp.getMaterialItemInd().equals('N') &&
				itemAggregateCorp.getExpenseItemInd().equals('Y')	
				)
		{
			excSrc.setItemUsgeInd('E');
		}
		else if(itemAggregateCorp.getMaterialItemInd().equals('N') &&
				itemAggregateCorp.getExpenseItemInd().equals('N')
				)
		{
			excSrc.setItemUsgeInd('R');
			excSrc.setItemUsageTypInd('R');
		}
		LOG.debug("Execution completed for set Item Aggregate CorpData");

	}

	/**
	 * @param header
	 * @param corpUpc
	 * @param excSrc
	 * @param excSrcPk
	 */
	private void buildExcSrc(DisplayItemCreateMatchCicDto header,
			String corpUpc, UIExceptionSrc excSrc, UiExceptionSrcPk excSrcPk,String forceNewType) {
		LOG.debug("Execution started for build Exc Src");

		excSrcPk.setCompanyId(header.getCompanyId());
		excSrcPk.setDivisionId(header
				.getDivisionId());
		excSrcPk.setProductSKU(header
				.getProductSku());
		excSrcPk.setUpcCountry(corpUpc.substring(0,1));
		excSrcPk.setUpcSystem(corpUpc.substring(1,2));
		excSrcPk.setUpcManufacturer(corpUpc.substring(2,7));
		excSrcPk.setUpcSales(corpUpc.substring(7,12));
		excSrc.setCaseUPC(header.getCaseUpc());
		if(forceNewType.equals("A")){
			excSrc.setExcptnTypeCd('A');
			excSrc.setExcptionDesc(PerishableConstants.AUGMENTATION_DESC);
		}else if(forceNewType.equals("O")){
			excSrc.setExcptnTypeCd('O');
			excSrc.setExcptionDesc(PerishableConstants.OVERRIDE_DESC);
		}
		
		excSrc.setExcptnProcessdInd('N');
		excSrc.setDispFlag(header.getDisplayFlag());
		excSrc.setUpdatedUserID(header
				.getUpdatedUserId());
		excSrc.setCost(header.getCost().floatValue());
		excSrc.setPackwhse(header.getPack());
		excSrc.setVendConvFactor(header.getVendorConvFactor());
		//excSrc.setItemUsgeInd('R');
		//excSrc.setItemUsageTypInd('R');
		LOG.debug("Execution completed for build Exc Src");

	}
	public List<PerishableMappedResultWrapper> listMappedData(PerishableSearchRequestVO searchRequestVO){
		LOG.info("Execution started to list Mapped Data");
		List<PerishableMappedResultWrapper> maddedItems=new ArrayList<>();
		String searchCriteria=null;
	     if(null!=searchRequestVO.getSearchCriteria() && !searchRequestVO.getSearchCriteria().isEmpty() && searchRequestVO.getSearchIndicator().equals(PerishableConstants.SOURCE_INDICATOR)){
	    	 searchCriteria = sourceFilterForMappedList(searchRequestVO,searchCriteria);
	     }
	     
	     else if(null!=searchRequestVO.getSearchCriteria() && !searchRequestVO.getSearchCriteria().isEmpty() && searchRequestVO.getSearchIndicator().equals(PerishableConstants.TARGET_INDICATOR))   {
	    	 searchCriteria = targetFilterForMapedList(searchRequestVO,searchCriteria);
	    	 
	    	 if(searchRequestVO.getSearchCriteria().endsWith("WHSE") || searchRequestVO.getSearchCriteria().endsWith("DSD") ){
		    	 searchRequestVO.setSearchCriteriaValue(searchRequestVO.getSearchCriteria().substring(0, 1));
			 }
	     }
	     
	   
		List<Object[]> mappedObjects= perishableSQLRepository.fetchMappedList(searchRequestVO.getCompanyID(), searchRequestVO.getDivisionID(), searchCriteria, searchRequestVO.getSearchCriteriaValue(),searchRequestVO.getMappingStatus());
		LOG.debug("Completed fetching for"+mappedObjects.size()+"mapped Objects" );
		if(null!=mappedObjects && ! mappedObjects.isEmpty()){
			 maddedItems=perishablesAdapter.setMappedItems(mappedObjects);
		}
		LOG.info("Execution completed to list Mapped Data");

		return maddedItems;
	}

	/**
	 * @param searchRequestVO
	 * @param searchCriteria
	 * @return
	 */
	private String targetFilterForMapedList(
			PerishableSearchRequestVO searchRequestVO, String searchCriteria) {
		LOG.debug("Execution started to target Filter For MapedList");

		if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.CIC_VAL)) {
			 searchCriteria="M.CORP_ITEM_CD" ;
		 }
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)){
			searchCriteria="CDS.DESC_ITEM"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DISP)){
			searchCriteria=PerishableConstants.CDS_DISP_FLAG; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith("WHSE") || searchRequestVO.getSearchCriteria().endsWith("DSD") ){
			searchCriteria="WDS.DST_CNTR"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
			searchCriteria="CDS.RETAIL_SECT"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.USAGE_TYPE))
		{
			searchCriteria="TARGET_USAGE_TYPE"; 
		}
		LOG.debug("Execution completed to target Filter For MapedList");
		return searchCriteria;
	}

	/**
	 * @param searchRequestVO
	 * @param searchCriteria
	 * @return
	 */
	private String sourceFilterForMappedList(
			PerishableSearchRequestVO searchRequestVO, String searchCriteria) {
		LOG.debug("Execution started to source Filter For Mapped List");
		if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.SKU_VAL)) {
			 searchCriteria="M.PRODUCT_SKU";
		 }    	 
		 else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)){
		    	searchCriteria="C.ITEM_DESC"; 
		 }
		 else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL)){
			 searchCriteria="M.UPC"; 
		 }
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DISP)){
			searchCriteria="C.MULTI_COMP_ITEM_IND"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.WHSE)){
			searchCriteria="C.SOURCE_BY_WHSE"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DSD)){
			searchCriteria="C.SOURCE_BY_DSD"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
			searchCriteria="C.PROD_HIERARCHY_LVL_4_CD"; 
		}
		else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.USAGE_TYPE))
		{
			searchCriteria="SOURCE_USAGE_TYPE"; 
		}
		LOG.debug("Execution completed to source Filter For Mapped List");

		return searchCriteria;
	}

	@Override
	public String updateForceNewInPerishableMapping(
			PerishableMappingRequest perishableMappingRequest) {
		LOG.info("Execution started to update Force New In Perishable Mapping");


		boolean update= perishableSQLRepository.updateForceNewMappingStatus(perishableMappingRequest.getCompanyID(), perishableMappingRequest.getDivisionID(),
				perishableMappingRequest.getSku(), PerishableConstants.FORCE_NEW, PerishableConstants.FORCE_NEW);
				
		if(update)
		{	
			LOG.info("Execution completed to update Force New In Perishable Mapping");

			return "Successfully updated";
}
		else
		{
			return "updation failed";	
		}
	}
	
	public List<Object[]> getSouceDepartmentDetails(String company,String division){

			return perishableSQLRepository.getDepartmentForSource(company, division);
	}
	public List<Object[]> getTargetDepartmentDetails(String company,String division){
			return perishableSQLRepository.getDepartmentForTarget();
	}
	
	public List<PerishableUPCwisedDetails> getUpcListDetails(Object[] searchDetails){
		LOG.info("Execution started to get UpcList Details");

		List<Object[]> upcList=perishableSQLRepository.getUpcListDetails(searchDetails[0].toString(), searchDetails[1].toString(), searchDetails[2].toString(), searchDetails[3].toString(),searchDetails[4].toString());
		List<PerishableUPCwisedDetails> upcDetailsList =null;
		if(null!=upcList && !upcList.isEmpty()){
			upcDetailsList= perishablesAdapter.setUPCwiseDetails(upcList);
				}
		if (upcDetailsList != null) {
			LOG.info("Execution completed to get " + upcDetailsList.size() + " UpcList Details");
		}
		return upcDetailsList;
	}

	/**
	 * Method to test whether source upc has match on target side
	 * @param perishableItemCreateMatchCicDto
	 * @return
	 */
	@Override
	public boolean checkMatchingUPCInTarget(PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto) {
		LOG.info("Execution started to check Matching UPC In Target");
		boolean isUPCMatchAvail= false;		
		for (DisplayItemSourceUPC sourceUPC : perishableItemCreateMatchCicDto.getSourceComponentUpc()) {
				
					Object[] inputs =new Object[4];
					String upc =sourceUPC.getUpc().replaceAll("-", "");
					if(upc.length() <12)
					{
						upc=StringUtils.leftPad(upc, 12, '0');
					}
						
						inputs[0]=upc.substring(0,1);
				        inputs[1]=upc.substring(1,2);
				        inputs[2]=upc.substring(2,7);
				        inputs[3]=upc.substring(7,12);
					
					if( Integer.parseInt(inputs[0].toString()) ==0 && 
						( Integer.parseInt(inputs[1].toString()) ==2 || Integer.parseInt(inputs[1].toString())==4 
							|| Float.parseFloat(upc)< 100000
						)
					  )
					{
						isUPCMatchAvail =false;
						break;
					}
					else if(!isUPCMatchAvail)
					{
					isUPCMatchAvail=perishableSQLRepository.isUPCMatchAvailableInTarget(inputs);
				}
				
			}
		LOG.info("Execution completed to check Matching UPC In Target");

		return isUPCMatchAvail;
	}
    /**
     * method to fetch the target list suggested on basis of upc match
     * @param upcDetails
     * @return 
     */
	@Override
	public List<PerishableCICSearchResults> getSuggestedTargetList(
			PerishableMatchingTargetInputVO upcDetails) {
		LOG.info("Execution started to fetch the target list suggested on basis of upc match");

				
		List<Object[]> cicList = perishableAdditonalSQLRepository.loadCICSuggestions(upcDetails.getUpcs());
		if(null != cicList &&!cicList.isEmpty())
		{
		List<Object[]> perishableCICSearchResults =perishableAdditonalSQLRepository.fetchMatchingCICdetails(cicList);
		List<Object[]> sortedPerishableCICSearchResults = sortedList(cicList,perishableCICSearchResults);
		LOG.info("Execution completed to fetch the target list suggested on basis of upc match");		
		return perishablesAdapter.mapTargetItem(sortedPerishableCICSearchResults);
		}
		else
			return null;
	}

	private List<Object[]> sortedList(List<Object[]> cicList,
			List<Object[]> perishableCICSearchResults) {
		LOG.debug("Execution started to fetch the sorted Perishable CIC SearchResults");
		List<Object[]> sortedPerishableCICSearchResults = new ArrayList<>();
		
		if(null != perishableCICSearchResults && !perishableCICSearchResults.isEmpty()) {
			for (Object[] cicObj : cicList) {
				for (Object[] cicListObj : perishableCICSearchResults) {
					if (cicObj[0].equals(cicListObj[0])) {
						sortedPerishableCICSearchResults.add(cicListObj);
						break;
					}

				}
			}
				
		}
		LOG.debug("Execution completed for"+sortedPerishableCICSearchResults.size()+" fetch the sorted Perishable CIC SearchResults");

		return sortedPerishableCICSearchResults;
		
	}

	@Override
	public PerishableAdditionalDetailsDto getadditionalRetailscanDetails(
			String corpItemCd) {
		LOG.info("Execution started to fetch the additional Retail scan Details");
		
		Map resultMap =perishableAdditonalSQLRepository.fetchAdditonalRetailScandetails(corpItemCd);
		
		LOG.info("Execution completed to fetch the additional Retail scan Details");

		return perishablesAdapter.setAddtionalDetailsForRetail(resultMap);
		
	}

	@Override
	public List<PerishableUPCwisedDetails> getMappedUpcListDetails(
			Object[] searchDetails) {
		LOG.info("Execution started to fetch the Mapped Upc List Details");

		List<Object[]> upcList=perishableAdditonalSQLRepository.getMappedUpcListDetails(searchDetails[0].toString(), searchDetails[1].toString(), searchDetails[2].toString(), searchDetails[3].toString(),searchDetails[4].toString());
		List<PerishableUPCwisedDetails> upcDetailsList =null;
		if(null!=upcList && !upcList.isEmpty()){
			upcDetailsList= perishablesAdapter.setUPCwiseDetails(upcList);
				}
		LOG.info("Execution completed to fetch the Mapped Upc List Details");

		return upcDetailsList;
	}

	@Override
	public boolean changeExpenseType(List<ManualExpeseTypeChangeRequest> changeRequests) {
		LOG.info("Execution started to change Expense Type");

		List<Object[]> changeRequestObjects =new ArrayList<>(); 
		for(ManualExpeseTypeChangeRequest expenseObj :changeRequests)
		{  
				Object[] obj =new Object[5];
				obj[0]=expenseObj.getCompanyID();
				obj[1]=expenseObj.getDivisionID();
				obj[2]=expenseObj.getSku();
				obj[3]=expenseObj.getExpeseTypeChange();
				obj[4]=expenseObj.getUpdatedbyUser();			
				changeRequestObjects.add(obj);
		}
		LOG.info("Execution completed to change Expense Type");

		return perishableAdditonalSQLRepository.updateExpeseType(changeRequestObjects);
		
	}
	
	@Override
	public ManualMapAdditionalLoadDto fetchTargetEditITems(ManualMatchAdtnlFieldLoadInputVo inputVo)
	{
		LOG.info("Execution started to fetch Target Edit ITems");

		List  targetFieldResult=perishableAdditonalSQLRepository.loadTargetFieldsForMapEdit(inputVo.getBuyingCic(),inputVo.getCompanyId(), inputVo.getDivisionId());
		List<Object[]> skuWeightList = new ArrayList();
		if(inputVo.getWhseDsd()!=null && inputVo.getWhseDsd().trim().equalsIgnoreCase("WHSE"))
		{
			skuWeightList =perishableAdditonalSQLRepository.loadSourceItemForEdit(inputVo.getCompanyId(), inputVo.getDivisionId(), inputVo.getProductSKUs());
					
		}
		else
		{
			for(String sku:inputVo.getProductSKUs())
	{
				Object[] obj= new Object[2];
				obj[0] =sku;
				obj[1]="0.01";
				skuWeightList.add(obj);
			}
		}
		LOG.info("Execution completed to fetch Target Edit ITems");

		return perishablesAdapter.setOnMatchEditDto(targetFieldResult,skuWeightList);
		
	}
}