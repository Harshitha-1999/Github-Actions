package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

public class DisplaySimsLikeItems {

	private BigDecimal cic;
	private String itemDesc;
	private String caseUpc;
	private Character displayItem;
	private BigDecimal cost;

	private Character upcMatch;
	private Character qtyMatch;
	private Character costMatch;
	private Character caseUpcMatch;
	private List<DisplayItemSimsUPC> displayItemUPC;
	private Character cicAlreadyProcessed;

	public Character getCaseUpcMatch() {
		return caseUpcMatch;
	}

	public void setCaseUpcMatch(Character caseUpcMatch) {
		this.caseUpcMatch = caseUpcMatch;
	}

	public BigDecimal getCic() {
		return cic;
	}

	public void setCic(BigDecimal cic) {
		this.cic = cic;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public Character getDisplayItem() {
		return displayItem;
	}

	public void setDisplayItem(Character displayItem) {
		this.displayItem = displayItem;
	}

	public BigDecimal getCost() {
		return cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public Character getUpcMatch() {
		return upcMatch;
	}

	public void setUpcMatch(Character upcMatch) {
		this.upcMatch = upcMatch;
	}

	public Character getQtyMatch() {
		return qtyMatch;
	}

	public void setQtyMatch(Character qtyMatch) {
		this.qtyMatch = qtyMatch;
	}

	public Character getCostMatch() {
		return costMatch;
	}

	public void setCostMatch(Character costMatch) {
		this.costMatch = costMatch;
	}

	public List<DisplayItemSimsUPC> getDisplayItemUPC() {
		return getSortedDisplayItemSimsUpc();
	}

	public void setDisplayItemUPC(List<DisplayItemSimsUPC> displayItemUPC) {
		this.displayItemUPC = displayItemUPC;
	}

	public Character getCicAlreadyProcessed() {
		return cicAlreadyProcessed;
	}

	public void setCicAlreadyProcessed(Character cicAlreadyProcessed) {
		this.cicAlreadyProcessed = cicAlreadyProcessed;
	}

	public List<DisplayItemSimsUPC> getSortedDisplayItemSimsUpc() {
		Collections.sort(displayItemUPC, DisplayItemSimsUPC.upcComparator);
		return displayItemUPC;
	}

	@Override
	public String toString() {
		return "DisplaySimsLikeItems [cic=" + cic + ", itemDesc=" + itemDesc
				+ ", caseUpc=" + caseUpc + ", displayItem=" + displayItem
				+ ", cost=" + cost + ", upcMatch=" + upcMatch + ", qtyMatch="
				+ qtyMatch + ", costMatch=" + costMatch + ", displayItemUPC="
				+ displayItemUPC + ", cicAlreadyProcessed="
				+ cicAlreadyProcessed + "]";
	}
}
