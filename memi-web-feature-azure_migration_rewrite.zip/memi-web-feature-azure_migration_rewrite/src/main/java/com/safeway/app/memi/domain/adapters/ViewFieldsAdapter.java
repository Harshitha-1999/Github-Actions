/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.adapters;

/* ***************************************************************************
 * NAME : ViewFieldsAdapter SYSTEM : MEMI AUTHOR : Subhash G REVISION HISTORY
 * Revision 0.0.0.1 March 09, 2016 - Initial Creation
 * *************************************************************************
 */
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import com.safeway.app.memi.data.entities.Company;
import com.safeway.app.memi.data.entities.Division;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.SMICDetail;
import com.safeway.app.memi.data.entities.SalesShip;
import com.safeway.app.memi.data.entities.SourceItemCIC;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.domain.dtos.response.CompanyDto;
import com.safeway.app.memi.domain.dtos.response.DCDetailsVo;
import com.safeway.app.memi.domain.dtos.response.DepartmentDto;
import com.safeway.app.memi.domain.dtos.response.DivisionDto;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.ProductionCodeDetailDto;
import com.safeway.app.memi.domain.dtos.response.SMICDetailDto;
import com.safeway.app.memi.domain.dtos.response.SalesData;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.dtos.response.SourceItem;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UInewItemVO;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.util.LikeItemUtils;

/**
 * 
 * Adapter class. Mainly responsible for object creation and conversion
 * 
 */
public class ViewFieldsAdapter {

	/**
	 * Converts a SourceItemCIC List to SourceItem Dto List
	 * 
	 * @param sourceItemCICList
	 * @return
	 */
	LikeItemUtils likeItemUtils ;
	
	public List<SourceItem> mapToSourceItemDtoList(
			List<SourceItemCIC> sourceItemCICList) {

		List<SourceItem> itemList = new ArrayList<>();
		for (SourceItemCIC srcItemCICObj : sourceItemCICList) {
			SourceItem sourceItem = new SourceItem();
			sourceItem.setCompanyID(srcItemCICObj.getSourceItemCICPk().getCompanyId());
			sourceItem.setDivisionID(srcItemCICObj.getSourceItemCICPk().getDivisionId());
			sourceItem.setProductSKU(srcItemCICObj.getSourceItemCICPk().getProductKSU());
			itemList.add(sourceItem);
		}
		return itemList;
	}

	/**
	 * Converts a Company List to Company Dto List
	 * 
	 * @param CompanyList
	 * @return
	 */
	public List<CompanyDto> mapToCompanyDtoList(List<Company> companyLst) {

		List<CompanyDto> companyList = new ArrayList<>();
		for (Company company : companyLst) {
			CompanyDto companyDto = new CompanyDto();
			companyDto.setCompanyID(company.getCompanyId());
			companyDto.setCompanyLglNm(company.getCompanyLegalNM());
			companyList.add(companyDto);
		}
		return companyList;
	}

	/**
	 * Converts a SourceItemCIC List to SourceItem Dto List
	 * 
	 * @param sourceItemCICList
	 * @return
	 */
	public List<DivisionDto> mapToDivisionDtoList(List<Division> divisionList) {

		List<DivisionDto> divList = new ArrayList<>();
		for (Division divObj : divisionList) {
			DivisionDto divDto = new DivisionDto();
			divDto.setDivisionID(divObj.getDivisionId());
			divDto.setDivisionNm(divObj.getDivisionNM());
			divDto.setDivisionLglNm(divObj.getDivisionLegalNM());
			divDto.setCompanyID(divObj.getCompanyid());
			divList.add(divDto);
		}
		return divList;
	}

	/**
	 * Converts a SourceItemCIC List to SourceItem Dto List
	 * 
	 * @param sourceItemCICList
	 * @return
	 */
	public List<UIExceptionSrcDto> mapToExceptionSrcDtoList(
			List<UIExceptionSrc> exceptionSrcList) {

		List<UIExceptionSrcDto> srcList = new ArrayList<>();
		for (UIExceptionSrc srcObj : exceptionSrcList) {
			UIExceptionSrcDto srcDto = new UIExceptionSrcDto();
			srcDto.setBtId(srcObj.getBatchId());
			srcDto.setCompanyId(srcObj.getUiSrcPk().getCompanyId());
			DecimalFormat formatter = new DecimalFormat("#0.00");
			srcDto.setCostItm(formatter.format(srcObj.getCost()));
			srcDto.setDeptName(srcObj.getDeptDtl() != null ? srcObj
					.getDeptDtl().getDeptName() : "");
			srcDto.setHierarchyLvlNm(srcObj.getDeptDtl() != null ? srcObj.getDeptDtl()
					.getHierLevelName() : "");
			srcDto.setHierarchyLvlDesc(srcObj.getDeptDtl() != null ? srcObj.getDeptDtl()
					.getHierLevelDesc() : "");
			srcDto.setDivisionId(srcObj.getUiSrcPk().getDivisionId());
			srcDto.setDspFlag(srcObj.getDispFlag());
			srcDto.setExcptnProInd(srcObj.getExcptnProcessdInd());
			srcDto.setExptnDesc(srcObj.getExcptionDesc());
			srcDto.setExptnTypCd(srcObj.getExcptnTypeCd());
			srcDto.setHierLevel1(srcObj.getPrdHierLevel1());
			srcDto.setHierLevel2(srcObj.getPrdHierLevel2());
			srcDto.setHierLevel3(srcObj.getPrdHierLevel3());
			srcDto.setHierLevel4(srcObj.getPrdHierLevel4());
			srcDto.setHierLevel5(srcObj.getPrdHierLevel5());
			srcDto.setIntenetItemDescrbtn(srcObj.getIntenetItemDesc());
			srcDto.setItmDescrbtn(srcObj.getItmDesc());
			srcDto.setItmUsgeInd(srcObj.getItemUsgeInd());
			srcDto.setItmUsgeTypInd(srcObj.getItemUsageTypInd());
			srcDto.setLoglInd(srcObj.getLogicalInd());
			srcDto.setPackWhse(srcObj.getPackwhse());
			srcDto.setPLUcd(srcObj.getPluCd());
			srcDto.setPosDescrbtn(srcObj.getPosDesc());
			srcDto.setPrimryUpcInd(srcObj.getPrmyUpcInd());
			srcDto.setProductSKU(srcObj.getUiSrcPk().getProductSKU());
			srcDto.setProductSrcCd(srcObj.getUiSrcPk().getProductSrcCd());
			srcDto.setPtLblInd(srcObj.getPtLabelInd());
			srcDto.setRtlItmDescrbtn(srcObj.getRtlItmDesc());
			srcDto.setSizeNbr(srcObj.getSizeNmbr());
			srcDto.setSzDesc(srcObj.getSizeDesc());
			srcDto.setSzUom(srcObj.getSizeUom());
			srcDto.setUpcCountry(srcObj.getUiSrcPk().getUpcCountry());
			srcDto.setUpcManufacturer(srcObj.getUiSrcPk().getUpcManufacturer());
			srcDto.setUpcSales(srcObj.getUiSrcPk().getUpcSales());
			srcDto.setUpcSystem(srcObj.getUiSrcPk().getUpcSystem());
			srcDto.setVdCnvFactor(srcObj.getVendConvFactor());
			srcDto.setWhseItmDescrbtn(srcObj.getWhseItmDesc());
			srcDto.setCaseUPC(srcObj.getCaseUPC());
			srcDto.setUpdatedUserID(srcObj.getUpdatedUserID());
			srcList.add(srcDto);
		}
		return srcList;
	}

	/**
	 * @param srcObj
	 * @return
	 */
	public UIExceptionSrcDto mapToUIExceptionSrcDto(UIExceptionSrc srcObj) {
		if (srcObj == null)
			return null;
		UIExceptionSrcDto srcDto = new UIExceptionSrcDto();
		likeItemUtils = new LikeItemUtils();
		srcDto.setBtId(srcObj.getBatchId());
		srcDto.setCompanyId(srcObj.getUiSrcPk().getCompanyId());
		DecimalFormat formatter = new DecimalFormat("#0.00");
		srcDto.setCostItm(formatter.format(srcObj.getCost()));
		srcDto.setDeptName(srcObj.getDeptDtl() != null ? srcObj.getDeptDtl()
				.getDeptName() : "");
		srcDto.setDeptCd(srcObj.getDeptDtl().getDeptCd());
		srcDto.setHierarchyLvlNm(srcObj.getDeptDtl() != null ? srcObj.getDeptDtl()
				.getHierLevelName() : "");
		srcDto.setHierarchyLvlDesc(srcObj.getDeptDtl() != null ? srcObj.getDeptDtl()
				.getHierLevelDesc() : "");
		srcDto.setDivisionId(srcObj.getUiSrcPk().getDivisionId());
		srcDto.setDspFlag(srcObj.getDispFlag());
		srcDto.setExcptnProInd(srcObj.getExcptnProcessdInd());
		srcDto.setExptnDesc(srcObj.getExcptionDesc());
		srcDto.setExptnTypCd(srcObj.getExcptnTypeCd());
		srcDto.setHierLevel1(srcObj.getPrdHierLevel1());
		srcDto.setHierLevel2(srcObj.getPrdHierLevel2());
		srcDto.setHierLevel3(srcObj.getPrdHierLevel3());
		srcDto.setHierLevel4(srcObj.getPrdHierLevel4());
		srcDto.setHierLevel5(srcObj.getPrdHierLevel5());
		srcDto.setIntenetItemDescrbtn(srcObj.getIntenetItemDesc());
		srcDto.setItmDescrbtn(srcObj.getItmDesc());
		srcDto.setItmUsgeInd(srcObj.getItemUsgeInd());
		srcDto.setItmUsgeTypInd(srcObj.getItemUsageTypInd());
		srcDto.setLoglInd(srcObj.getLogicalInd());
		srcDto.setPackWhse(srcObj.getPackwhse());
		srcDto.setPLUcd(srcObj.getPluCd());
		srcDto.setPosDescrbtn(srcObj.getPosDesc());
		srcDto.setPrimryUpcInd(srcObj.getPrmyUpcInd());
		srcDto.setProductSKU(srcObj.getUiSrcPk().getProductSKU());
		srcDto.setProductSrcCd(srcObj.getUiSrcPk().getProductSrcCd());
		if(srcObj.getPtLabelInd() == null) {
			char pvtLabel = ' ';
			srcDto.setPtLblInd(pvtLabel);
		}
		else {
			char pvtLabel = srcObj.getPtLabelInd();
			if(pvtLabel == 'Y'){
				pvtLabel = 'H';
				srcDto.setPtLblInd(pvtLabel);
			}
			else{
				srcDto.setPtLblInd(pvtLabel);
			}
		}
		srcDto.setRtlItmDescrbtn(srcObj.getRtlItmDesc());
		srcDto.setSizeNbr(srcObj.getSizeNmbr());
		srcDto.setSzDesc(srcObj.getSizeDesc());
		srcDto.setSzUom(srcObj.getSizeUom());
		srcDto.setUpcCountry(srcObj.getUiSrcPk().getUpcCountry());
		srcDto.setUpcManufacturer(srcObj.getUiSrcPk().getUpcManufacturer());
		srcDto.setUpcSales(srcObj.getUiSrcPk().getUpcSales());
		srcDto.setUpcSystem(srcObj.getUiSrcPk().getUpcSystem());
		srcDto.setVdCnvFactor(srcObj.getVendConvFactor());
		srcDto.setWhseItmDescrbtn(srcObj.getWhseItmDesc());
		String upc = srcObj.getUiSrcPk().getUpcCountry() + "-"
				+ srcObj.getUiSrcPk().getUpcSystem() + "-"
				+ srcObj.getUiSrcPk().getUpcManufacturer() + "-"
				+ srcObj.getUiSrcPk().getUpcSales();
		srcDto.setPrimaryUPC(upc);
		srcDto.setCaseUPC(likeItemUtils.formatCaseUpc(srcObj.getCaseUPC()));
		srcDto.setUpdatedUserID(srcObj.getUpdatedUserID());

		srcDto.setPullBydays(null);
		srcDto.setSellByDays("0");
		srcDto.setUseByDays("0");

		return srcDto;
	}

	/**
	 * @param newItemDetailList
	 * @return
	 */
	public List<NewItemDetailDto> mapToNewItemDetailDtoList(
			List<NewItemDetail> newItemDetailList) {
		List<NewItemDetailDto> srcList = new ArrayList<>();
		for (NewItemDetail srcObj : newItemDetailList) {
			NewItemDetailDto newItemDto = new NewItemDetailDto();
			newItemDto.setAugOverCmplnInd(srcObj.getAugOverCmplnInd());
			newItemDto.setBatchId(srcObj.getBatchId());
			newItemDto.setClsCd(srcObj.getClsCd());
			newItemDto.setCompanyId(srcObj.getNewItemPk().getCompanyId());
			DecimalFormat formatter = new DecimalFormat("#0.00");
			newItemDto.setCost(formatter.format(srcObj.getCost()));
			newItemDto.setCovTeamComment(srcObj.getCovTeamComment());
			newItemDto.setCtgryCd(srcObj.getCtgryCd());
			newItemDto.setDeptName(srcObj.getDeptDtl().getDeptName());
			newItemDto.setDispFlag(srcObj.getDispFlag());
			newItemDto.setDivisionId(srcObj.getNewItemPk().getDivisionId());
			newItemDto.setDtaOverCic(srcObj.getDtaOverCic());
			newItemDto.setDtaSrcDesc(srcObj.getDtaSrcDesc());
			newItemDto.setDtaSrcInd(srcObj.getDtaSrcInd());
			newItemDto.setExcptionDesc(srcObj.getExcptionDesc());
			newItemDto.setExcptnTypeCd(srcObj.getExcptnTypeCd());
			newItemDto.setGrpCd(srcObj.getGrpCd());
			newItemDto.setItemUsageTypInd(srcObj.getItemUsageTypInd());
			newItemDto.setItemUsgeInd(srcObj.getItemUsgeInd());
			newItemDto.setLogicalInd(srcObj.getLogicalInd());
			newItemDto.setPackwhse(srcObj.getPackwhse());
			newItemDto.setPluCd(srcObj.getPluCd());
			newItemDto.setPrdHierLevel1(srcObj.getPrdHierLevel1());
			newItemDto.setPrdHierLevel2(srcObj.getPrdHierLevel2());
			newItemDto.setPrdHierLevel3(srcObj.getPrdHierLevel3());
			newItemDto.setPrdHierLevel4(srcObj.getPrdHierLevel4());
			newItemDto.setPrdHierLevel5(srcObj.getPrdHierLevel5());
			newItemDto.setPrmyUpcInd(srcObj.getPrmyUpcInd());
			newItemDto.setProductSKU(srcObj.getNewItemPk().getProductSKU());
			newItemDto.setProductSrcCd(srcObj.getNewItemPk().getProductSrcCd());
			newItemDto.setPtLabelInd(srcObj.getPtLabelInd());
			newItemDto.setSbClsCd(srcObj.getSbClsCd());
			newItemDto.setSize(srcObj.getSize());
			newItemDto.setSrcIntenetItemDesc(srcObj.getSrcIntenetItemDesc());
			newItemDto.setSrcItmDesc(srcObj.getSrcItmDesc());
			newItemDto.setSrcPosDesc(srcObj.getSrcPosDesc());
			newItemDto.setSrcRtlItmDesc(srcObj.getSrcRtlItmDesc());
			newItemDto.setSrcSizeNmbr(srcObj.getSrcSizeNmbr());
			newItemDto.setSrcSizeUom(srcObj.getSrcSizeUom());
			newItemDto.setSrcWhseItmDesc(srcObj.getSrcWhseItmDesc());
			newItemDto.setSubSbClass(srcObj.getSubSbClass());
			newItemDto.setUpcCountry(srcObj.getNewItemPk().getUpcCountry());
			newItemDto.setUpcManufacturer(srcObj.getNewItemPk()
					.getUpcManufacturer());
			newItemDto.setUpcSales(srcObj.getNewItemPk().getUpcSales());
			newItemDto.setUpcSystem(srcObj.getNewItemPk().getUpcSystem());
			newItemDto.setUpdDispFlag(srcObj.getUpdDispFlag());
			newItemDto.setUpdIntenetItemDesc(srcObj.getUpdIntenetItemDesc());
			newItemDto.setUpdItmDesc(srcObj.getUpdItmDesc());
			newItemDto.setUpdPosDesc(srcObj.getUpdPosDesc());
			newItemDto.setUpdPtLabelInd(srcObj.getUpdPtLabelInd());
			newItemDto.setUpdRtlItmDesc(srcObj.getUpdRtlItmDesc());

			newItemDto.setUpdUsageTypInd(srcObj.getUpdUsageTypInd());
			newItemDto.setUpdUsgeInd(srcObj.getUpdUsgeInd());
			newItemDto.setUpdWhseItmDesc(srcObj.getUpdWhseItmDesc());
			newItemDto.setVendConvFactor(srcObj.getVendConvFactor());
			srcList.add(newItemDto);
		}
		return srcList;
	}

	/**
	 * @param likeItemObjList
	 * @param excSrcDto
	 * @return
	 */
	public List<NewItemDetailDto> buildLikeItemDetailDtoList(
			List<Object[]> likeItemObjList, UIExceptionSrcDto excSrcDto) {
		List<NewItemDetailDto> srcList = new ArrayList<>();
		for (Object[] srcObj : likeItemObjList) {
			NewItemDetailDto newItemDto = new NewItemDetailDto();
			newItemDto.setLikeItem(true);
			newItemDto.setDtaOverCic(getBigDecimalValue(srcObj[0]));
			if (!srcList.contains(newItemDto)) {
				newItemDto.setUpdItmDesc(getStringValue(srcObj[1]));
				newItemDto.setUpdWhseItmDesc(getStringValue(srcObj[2]));
				newItemDto.setUpdRtlItmDesc(getStringValue(srcObj[3]));
				newItemDto.setUpdIntenetItemDesc(getStringValue(srcObj[4]));
				newItemDto.setUpdPosDesc(getStringValue(srcObj[5]));
				newItemDto.setPackwhse(getBigDecimalValue(srcObj[6]));
				newItemDto.setVendConvFactor(getBigDecimalValue(srcObj[7]));
				newItemDto.setUpdUsgeInd(getCharacterValue(srcObj[8]));
				newItemDto.setUpdUsageTypInd(getCharacterValue(srcObj[9]));
				newItemDto.setUpdDispFlag((Character) (srcObj[10] != null && ((Character) srcObj[10] != ' ') ? (srcObj[10]): 'N'));

				newItemDto.setGrpCd(getBigDecimalValue(srcObj[11]).intValue());
				newItemDto.setCtgryCd(getBigDecimalValue(srcObj[12]).intValue());
				newItemDto.setClsCd(getBigDecimalValue(srcObj[13]).intValue());
				newItemDto.setSbClsCd(getBigDecimalValue(srcObj[14]).intValue());
				newItemDto.setSubSbClass(getBigDecimalValue(srcObj[15]).intValue());
				newItemDto.addDC(getStringValue(srcObj[16]));
				
				String rog = getStringValue(srcObj[17]);
				BigDecimal cost = getBigDecimalValue(srcObj[19]);
				
				String dc = getStringValue(srcObj[16]);
				if(dc != null && dc.trim().length() > 0){
					DCDetailsVo dcDetailsVo = new DCDetailsVo();
					dcDetailsVo.setDc(dc);
					dcDetailsVo.setCost(cost);
					//checking rog is null or not.
					if(rog != null && rog.trim().length() > 0){
					dcDetailsVo.addRog(rog);
					}
					dcDetailsVo.setDcStatus(getCharacterValue(srcObj[33]));
					newItemDto.addDCDetails(dcDetailsVo);
				}
				newItemDto.setPrimayUpcString(getStringValue(srcObj[20]));
				UPCVo upcVo = new UPCVo();
				upcVo.setUpc(getStringValue(srcObj[20]));
				upcVo.setPrimaryUPCInd((Character) (srcObj[18] != null ? (srcObj[18]): 'N'));
				newItemDto.addUpcVo(upcVo);
				newItemDto.addUpc(getStringValue(srcObj[20]));
				newItemDto.setTrueDSDFlag((Character) (srcObj[21] != null && ((Character) srcObj[21] != ' ') ? (srcObj[21]): 'N'));
				newItemDto.setUpdSize(getStringValue(srcObj[22]));

				newItemDto.setUpdSizeNmbr(getBigDecimalValue(srcObj[23]));
				newItemDto.setUpdSizeUom(getStringValue(srcObj[24]));
				newItemDto.setProductSrcCd(getStringValue(srcObj[25]));
				newItemDto.setUpdPtLabelInd(getCharacterValue(srcObj[27]));
				
				newItemDto.setCaseUPC(getStringValue(srcObj[28]));
				
				newItemDto.setStatusCorp(getCharacterValue(srcObj[29]));
				
				newItemDto.setCicCreateDate((Date) (srcObj[30] != null ? (srcObj[30]): null));
				
				newItemDto.setDeptName(getStringValue(srcObj[31]));
				
				newItemDto.setDeptCd(getStringValue(srcObj[32]));
				
				//Added for new columns inOverride screen
				newItemDto.setProductClsCd(getBigDecimalValue(srcObj[36]).intValue());
				newItemDto.setProductionGrpCd(getBigDecimalValue(srcObj[37]).intValue());
				newItemDto.setProductionCtgryCd(getBigDecimalValue(srcObj[38]).intValue());
				newItemDto.setProductionClsCd(getBigDecimalValue(srcObj[39]).intValue());
				
                newItemDto.setUpcCountry(excSrcDto.getUpcCountry());
				newItemDto.setUpcManufacturer(excSrcDto.getUpcManufacturer());
				newItemDto.setUpcSales(excSrcDto.getUpcSales());
				newItemDto.setUpcSystem(excSrcDto.getUpcSystem());

				//need to revisit after ETL changes
//				newItemDto.setCaseUPC(excSrcDto.getPrimaryUPC());
				srcList.add(newItemDto);
			} else {
				NewItemDetailDto existingItemDto = srcList.get(srcList.indexOf(newItemDto));
				existingItemDto.addUpc(getStringValue(srcObj[20]));
				UPCVo upcVo = new UPCVo();
				upcVo.setUpc(getStringValue(srcObj[20]));
				upcVo.setPrimaryUPCInd((Character) (srcObj[18] != null ? (srcObj[18]): 'N'));
				existingItemDto.addUpcVo(upcVo);
				String dc = getStringValue(srcObj[16]);
				if(dc != null && dc.trim().length() > 0){
					existingItemDto.addDC(getStringValue(srcObj[16]));
					
					DCDetailsVo dcDetailsVo = new DCDetailsVo();
					dcDetailsVo.setDc(getStringValue(srcObj[16]));
					if(existingItemDto.getDcDetails().contains(dcDetailsVo))
					{
						dcDetailsVo = existingItemDto.getDcDetails().get(existingItemDto.getDcDetails().indexOf(dcDetailsVo));
						String rog = getStringValue((srcObj[17]));
						//checking if rog is null or not
						if(rog != null && rog.trim().length() > 0){
						dcDetailsVo.addRog(rog);
						}
					}
					else
					{
						String rog = getStringValue((srcObj[17]));
						BigDecimal cost = getBigDecimalValue(srcObj[19]);
						dcDetailsVo.setCost(cost);
						//checking if rog is null or not
						if(rog != null && rog.trim().length() > 0){
						dcDetailsVo.addRog(rog);
						}
						dcDetailsVo.setDcStatus(getCharacterValue(srcObj[33]));
						existingItemDto.addDCDetails(dcDetailsVo);
					}
				}
			}

		}
		return srcList;
	}
	
	/**
	 * @param obj
	 * @return
	 */
	private String getStringValue(Object obj){
		if(obj == null)
			return "";
		return ( obj.toString()).trim();
	}

	/**
	 * @param updObj
	 * @param srcObj
	 * @return
	 */
	public NewItemDetailDto UInewItemObjtoDto(UInewItemVO updObj,
			UIExceptionSrc srcObj) {

		NewItemDetailDto newItemDto = new NewItemDetailDto();

		newItemDto.setCtgryCd(updObj.getCtgryCd());
		newItemDto.setUpdUsageTypInd(updObj.getUpdItemUsageTypInd());
		newItemDto.setCompanyId(updObj.getCompanyId());
		newItemDto.setDivisionId(updObj.getDivisionId());
		newItemDto.setGrpCd(updObj.getGrpCd());
		newItemDto.setUpdUsageTypInd(updObj.getUpdItemUsageInd());
		newItemDto.setSbClsCd(updObj.getSbClassCd());
		newItemDto.setClsCd(updObj.getClassCd());
		newItemDto.setSubSbClass(updObj.getSbSubClassCd());
		newItemDto.setCovTeamComment(updObj.getConVTeamCmnt());
		newItemDto.setPackwhse(updObj.getUpdPack());
		newItemDto.setVendConvFactor(updObj.getUpdVcf());
		newItemDto.setAugOverCmplnInd(updObj.getAugCompletionInd());
		newItemDto.setCovTeamComment(updObj.getConvTeamCmnt());
		newItemDto.setUpdIntenetItemDesc(updObj.getUpdinternetDesc());
		newItemDto.setUpdItmDesc(updObj.getUpditemDesc());
		newItemDto.setUpdPosDesc(updObj.getUpdPosDesc());
		newItemDto.setUpdPtLabelInd(updObj.getPrivateLabel());
		newItemDto.setUpdDispFlag(updObj.getUpdDispItemCheck());
		newItemDto.setUpdRtlItmDesc(updObj.getUpdSysDesc());
		newItemDto.setUpdSize(updObj.getUpdSizeDesc());
		newItemDto.setUpdSizeNmbr(updObj.getUpdSizeNum());
		newItemDto.setUpdSizeUom(updObj.getUpdSizeUoM());
		newItemDto.setBatchId(srcObj.getBatchId());
		newItemDto.setDispFlag(srcObj.getDispFlag());
		newItemDto.setExcptionDesc(srcObj.getExcptionDesc());
		newItemDto.setExcptnTypeCd(srcObj.getExcptnTypeCd());
		newItemDto.setLogicalInd(srcObj.getLogicalInd());
		newItemDto.setPluCd(srcObj.getPluCd());
		newItemDto.setPrdHierLevel1(srcObj.getPrdHierLevel1());
		newItemDto.setPrdHierLevel2(srcObj.getPrdHierLevel2());
		newItemDto.setPrdHierLevel3(srcObj.getPrdHierLevel3());
		newItemDto.setPrdHierLevel4(srcObj.getPrdHierLevel4());
		newItemDto.setPrdHierLevel5(srcObj.getPrdHierLevel5());
		newItemDto.setPrmyUpcInd(srcObj.getPrmyUpcInd());
		newItemDto.setProductSKU(srcObj.getUiSrcPk().getProductSKU());
		newItemDto.setProductSrcCd(srcObj.getUiSrcPk().getProductSrcCd());
		newItemDto.setPtLabelInd(srcObj.getPtLabelInd());
		newItemDto.setSrcIntenetItemDesc(srcObj.getIntenetItemDesc());
		newItemDto.setSrcItmDesc(srcObj.getItmDesc());
		newItemDto.setSrcPosDesc(srcObj.getPosDesc());
		newItemDto.setSrcRtlItmDesc(srcObj.getRtlItmDesc());
		newItemDto.setSrcSizeNmbr(srcObj.getSizeNmbr());
		newItemDto.setSrcSizeUom(srcObj.getSizeUom());
		newItemDto.setSrcWhseItmDesc(srcObj.getSizeDesc());
		newItemDto.setUpcCountry(srcObj.getUiSrcPk().getUpcCountry());
		newItemDto.setUpcManufacturer(srcObj.getUiSrcPk().getUpcManufacturer());
		newItemDto.setUpcSales(srcObj.getUiSrcPk().getUpcSales());
		newItemDto.setUpcSystem(srcObj.getUiSrcPk().getUpcSystem());
		return newItemDto;
	}

	/**
	 * @param uiExceptionSrcDto
	 * @return
	 */
	public NewItemDetailDto setNewItemforView(UIExceptionSrcDto uiExceptionSrcDto) {
		NewItemDetailDto newObj = new NewItemDetailDto();
		newObj.setPackwhse(uiExceptionSrcDto.getPackWhse());
		newObj.setVendConvFactor(uiExceptionSrcDto.getVdCnvFactor());
		newObj.setUpdSize(uiExceptionSrcDto.getSzDesc());
		newObj.setUpdSizeNmbr(uiExceptionSrcDto.getSizeNbr());
		newObj.setUpdSizeUom(uiExceptionSrcDto.getSzUom());
		newObj.setItemUsageTypInd(uiExceptionSrcDto.getItmUsgeTypInd());
		newObj.setItemUsgeInd(uiExceptionSrcDto.getItmUsgeInd());
		newObj.setUpdDispFlag(uiExceptionSrcDto.getDspFlag());

		String avlbleItemDesc;
		String srcItemDescription = uiExceptionSrcDto.getItmDescrbtn();
		avlbleItemDesc = uiExceptionSrcDto.getItmDescrbtn();
		if(avlbleItemDesc.length() > 40)
			avlbleItemDesc = avlbleItemDesc.substring(0, 39);
		newObj.setUpdItmDesc(avlbleItemDesc);
		if (uiExceptionSrcDto.getRtlItmDescrbtn() == null || uiExceptionSrcDto.getRtlItmDescrbtn().trim().length() == 0) {
			avlbleItemDesc = srcItemDescription.length() > 64 ? srcItemDescription.substring(0, 63) : srcItemDescription;
			newObj.setUpdRtlItmDesc(avlbleItemDesc);
		} else {
			newObj.setUpdRtlItmDesc(uiExceptionSrcDto.getRtlItmDescrbtn());
		}

		if (uiExceptionSrcDto.getWhseItmDescrbtn() == null || uiExceptionSrcDto.getWhseItmDescrbtn().trim().length() == 0) {
			avlbleItemDesc = srcItemDescription.length() > 30 ? srcItemDescription.substring(0, 29) : srcItemDescription;
			newObj.setUpdWhseItmDesc(avlbleItemDesc);
		} else {
			newObj.setUpdWhseItmDesc(uiExceptionSrcDto.getWhseItmDescrbtn());
		}
		if (uiExceptionSrcDto.getPosDescrbtn() == null || uiExceptionSrcDto.getPosDescrbtn().trim().length() == 0) {
			avlbleItemDesc = srcItemDescription.length() > 18 ? srcItemDescription.substring(0, 17) : srcItemDescription;
			newObj.setUpdPosDesc(avlbleItemDesc);
		} else {
			newObj.setUpdPosDesc(uiExceptionSrcDto.getPosDescrbtn());
		}

		if (uiExceptionSrcDto.getIntenetItemDescrbtn() == null || uiExceptionSrcDto.getIntenetItemDescrbtn().trim().length() == 0) {
			avlbleItemDesc = srcItemDescription.length() > 75 ? srcItemDescription.substring(0, 74) : srcItemDescription;
			newObj.setUpdIntenetItemDesc(avlbleItemDesc);
		} else {
			newObj.setUpdIntenetItemDesc(uiExceptionSrcDto.getIntenetItemDescrbtn());
		}

		newObj.setDeptCd(uiExceptionSrcDto.getDeptCd());
		newObj.setProductSrcCd(uiExceptionSrcDto.getProductSrcCd());

		newObj.setCost(uiExceptionSrcDto.getCostItm());
		newObj.setUpdPtLabelInd(uiExceptionSrcDto.getPtLblInd());
		newObj.setCompanyId(uiExceptionSrcDto.getCompanyId());
		newObj.setDivisionId(uiExceptionSrcDto.getDivisionId());
		newObj.setProductSKU(uiExceptionSrcDto.getProductSKU());
		newObj.setUpcCountry(uiExceptionSrcDto.getUpcCountry());
		newObj.setUpcManufacturer(uiExceptionSrcDto.getUpcManufacturer());
		newObj.setUpcSales(uiExceptionSrcDto.getUpcSales());
		newObj.setUpcSystem(uiExceptionSrcDto.getUpcSystem());
		newObj.setAssocUpc(uiExceptionSrcDto.getUpcLIst());
		newObj.setUpdUsgeInd(uiExceptionSrcDto.getItmUsgeInd());
		newObj.setUpdUsageTypInd(uiExceptionSrcDto.getItmUsgeTypInd());
		newObj.setUpdSize(uiExceptionSrcDto.getSzDesc());
		newObj.setUpdSizeNmbr(uiExceptionSrcDto.getSizeNbr());
		newObj.setUpdSizeUom(uiExceptionSrcDto.getSzUom());
		newObj.setUpdDispFlag(uiExceptionSrcDto.getDspFlag());
		newObj.setCaseUPC(uiExceptionSrcDto.getPrimaryUPC());

		String prmyUpcVal = newObj.getUpcCountry() + "-"
				+ newObj.getUpcSystem() + "-" + newObj.getUpcManufacturer()
				+ "-" + newObj.getUpcSales();
		newObj.setPrimayUpcString(prmyUpcVal);
		newObj.setCaseUPC(uiExceptionSrcDto.getCaseUPC());
		if(uiExceptionSrcDto.getUpcLIst() != null && uiExceptionSrcDto.getUpcLIst().size() > 0)
			newObj.setUpcs(new HashSet<String>(uiExceptionSrcDto.getUpcLIst()));
		return newObj;
	}

	/**
	 * @param srcObj
	 * @return
	 */
	public NewItemDetailDto mapNewItemCICDto(NewItemDetail srcObj) {
		NewItemDetailDto newItemDto = new NewItemDetailDto();
		newItemDto.setAugOverCmplnInd(srcObj.getAugOverCmplnInd());
		newItemDto.setBatchId(srcObj.getBatchId());
		newItemDto.setClsCd(srcObj.getClsCd());
		newItemDto.setCompanyId(srcObj.getNewItemPk().getCompanyId());
		DecimalFormat formatter = new DecimalFormat("#0.00");
		newItemDto.setCost(formatter.format(srcObj.getCost()));
		newItemDto.setCovTeamComment(srcObj.getCovTeamComment());
		newItemDto.setCtgryCd(srcObj.getCtgryCd());
		newItemDto.setDeptName(srcObj.getDeptDtl().getDeptName());
		newItemDto.setDispFlag(srcObj.getDispFlag());
		newItemDto.setDivisionId(srcObj.getNewItemPk().getDivisionId());
		newItemDto.setDtaOverCic(srcObj.getDtaOverCic());
		newItemDto.setDtaSrcDesc(srcObj.getDtaSrcDesc());
		newItemDto.setDtaSrcInd(srcObj.getDtaSrcInd());
		newItemDto.setExcptionDesc(srcObj.getExcptionDesc());
		newItemDto.setExcptnTypeCd(srcObj.getExcptnTypeCd());
		newItemDto.setGrpCd(srcObj.getGrpCd());
		newItemDto.setItemUsageTypInd(srcObj.getItemUsageTypInd());
		newItemDto.setItemUsgeInd(srcObj.getItemUsgeInd());
		newItemDto.setLogicalInd(srcObj.getLogicalInd());
		newItemDto.setPackwhse(srcObj.getPackwhse());
		newItemDto.setPluCd(srcObj.getPluCd());
		newItemDto.setPrdHierLevel1(srcObj.getPrdHierLevel1());
		newItemDto.setPrdHierLevel2(srcObj.getPrdHierLevel2());
		newItemDto.setPrdHierLevel3(srcObj.getPrdHierLevel3());
		newItemDto.setPrdHierLevel4(srcObj.getPrdHierLevel4());
		newItemDto.setPrdHierLevel5(srcObj.getPrdHierLevel5());
		newItemDto.setPrmyUpcInd(srcObj.getPrmyUpcInd());
		newItemDto.setProductSKU(srcObj.getNewItemPk().getProductSKU());
		newItemDto.setProductSrcCd(srcObj.getNewItemPk().getProductSrcCd());
		newItemDto.setPtLabelInd(srcObj.getPtLabelInd());
		newItemDto.setSize(srcObj.getSize());
		newItemDto.setSrcIntenetItemDesc(srcObj.getSrcIntenetItemDesc());
		newItemDto.setSrcItmDesc(srcObj.getSrcItmDesc());
		newItemDto.setSrcPosDesc(srcObj.getSrcPosDesc());
		newItemDto.setSrcRtlItmDesc(srcObj.getSrcRtlItmDesc());
		newItemDto.setSrcSizeNmbr(srcObj.getSrcSizeNmbr());
		newItemDto.setSrcSizeUom(srcObj.getSrcSizeUom());
		newItemDto.setSrcWhseItmDesc(srcObj.getSrcWhseItmDesc());
		newItemDto.setSubSbClass(srcObj.getSubSbClass());
		newItemDto.setUpcCountry(srcObj.getNewItemPk().getUpcCountry());
		newItemDto.setUpcManufacturer(srcObj.getNewItemPk()
				.getUpcManufacturer());
		newItemDto.setUpcSales(srcObj.getNewItemPk().getUpcSales());
		newItemDto.setUpcSystem(srcObj.getNewItemPk().getUpcSystem());
		newItemDto.setUpdDispFlag(srcObj.getUpdDispFlag());
		newItemDto.setUpdIntenetItemDesc(srcObj.getUpdIntenetItemDesc());
		newItemDto.setUpdItmDesc(srcObj.getUpdItmDesc());
		newItemDto.setUpdPosDesc(srcObj.getUpdPosDesc());
		newItemDto.setUpdPtLabelInd(srcObj.getUpdPtLabelInd());
		newItemDto.setUpdRtlItmDesc(srcObj.getUpdRtlItmDesc());
		newItemDto.setUpdUsageTypInd(srcObj.getUpdUsageTypInd());
		newItemDto.setUpdUsgeInd(srcObj.getUpdUsgeInd());
		newItemDto.setUpdWhseItmDesc(srcObj.getUpdWhseItmDesc());
		newItemDto.setVendConvFactor(srcObj.getVendConvFactor());
		newItemDto.setGrpCd(srcObj.getGrpCd());
		newItemDto.setCtgryCd(srcObj.getCtgryCd());
		newItemDto.setClsCd(srcObj.getClsCd());
		newItemDto.setSbClsCd(srcObj.getSbClsCd());
		newItemDto.setUpdSize(srcObj.getUpdSize());
		newItemDto.setUpdSizeNmbr(srcObj.getUpdSizeNmbr());
		newItemDto.setUpdSizeUom(srcObj.getUpdSizeUom());
		newItemDto.setDeptCd(srcObj.getDeptDtl().getDeptCd());
		newItemDto.setUpdUsageTypInd(srcObj.getUpdUsageTypInd());
		String upc = srcObj.getNewItemPk().getUpcCountry()
				+ "-" + srcObj.getNewItemPk().getUpcSystem() + "-"
				+ srcObj.getNewItemPk().getUpcManufacturer() + "-"
				+ srcObj.getNewItemPk().getUpcSales();
		newItemDto.setPrimayUpcString(upc);
		UPCVo upcVo = new UPCVo();
		upcVo.setUpc(upc);
		if(srcObj.getPrmyUpcInd() != null)
			upcVo.setPrimaryUPCInd(srcObj.getPrmyUpcInd());
		newItemDto.addUpcVo(upcVo);
		newItemDto.setCscDsc(srcObj.getCscDsc());
		
		//Added for new enhancement

		newItemDto.setProductionGrpCd(getIntegerValue(srcObj.getProductionGrpCd()));
		newItemDto.setProductionCtgryCd(getIntegerValue(srcObj.getProductionCtgryCd()));
		newItemDto.setProductionClsCd(getIntegerValue(srcObj.getProductionClsCd()));
		newItemDto.setEthnicTypeCd(getStringValue(srcObj.getEthnicTypeCd()));
		newItemDto.setPckTypeId(getBigDecimalValue(srcObj.getPckTypeId()));
		newItemDto.setProductClsCd(getIntegerValue(srcObj.getProductClsCd()));
		newItemDto.setInnerPack(getIntegerValue(srcObj.getInnerPack()));
		newItemDto.setRetailUnitPack(getIntegerValue(srcObj.getRetailUnitPack()));


		/*Produce PLU additional fields*/
		
		newItemDto.setDcPackDesc(srcObj.getPackDesc());
		newItemDto.setDcSizeDsc(srcObj.getSizeDesc());
		newItemDto.setRing(getStringValue(srcObj.getRing()));
		newItemDto.setHicone(getStringValue(srcObj.getHicone()));
		
		newItemDto.setProdwght(srcObj.getProdwght());
		newItemDto.setHandlingCode(srcObj.getHandlingCode());
		newItemDto.setBuyerNum(srcObj.getBuyerNum());
		newItemDto.setRandomWtCd(srcObj.getRandomWtCd());
		newItemDto.setAutoCostInv(srcObj.getAutoCostInv());
		newItemDto.setBillingType(srcObj.getBillingType());
		newItemDto.setFdStmp(srcObj.getFdStmp());
		newItemDto.setLabelSize(srcObj.getLabelSize());
		newItemDto.setLabelNumbers(srcObj.getLabelNumbers());
		newItemDto.setSgnCount1(srcObj.getSgnCount1());
		newItemDto.setSgnCount2(srcObj.getSgnCount2());
		newItemDto.setSgnCount3(srcObj.getSgnCount3());
		newItemDto.setSellByDays(srcObj.getSellByDays());
		newItemDto.setUseByDays(srcObj.getEatByDays());
		newItemDto.setPullBydays(srcObj.getPullByDays());
		newItemDto.setTareCd(srcObj.getTareCd());
		
		/**/
		


		return newItemDto;
	}

	/**
	 * Converts a SMICDetail List to SMICDetail Dto List
	 * 
	 * @param smicDtlList
	 * @return
	 */
	public List<SMICDetailDto> mapToSMICDetailDtoList(
			List<SMICDetail> smicDtlList) {

		List<SMICDetailDto> smicList = new ArrayList<>();
		for (SMICDetail rec : smicDtlList) {
			SMICDetailDto smicDto = new SMICDetailDto();
			smicDto.setGrpCode(rec.getSMICDetailPK().getGrpCd());
			smicDto.setCtgryCode(rec.getSMICDetailPK().getClsCd());
			smicDto.setSubClsCode(rec.getSMICDetailPK().getSbClsCd());
			smicDto.setSubSubClass(rec.getSMICDetailPK().getSubSbClass());
			smicDto.setSMICDesc(rec.getSMICDesc());
			smicList.add(smicDto);
		}
		return smicList;
	}
	
	public List<ProductionCodeDetailDto> mapToProductionCodeDetailDtoList(
			List<Object[]> prdctnCdDtlList) {

		List<ProductionCodeDetailDto> productionCodeList = new ArrayList<>();
		if(prdctnCdDtlList!=null && !prdctnCdDtlList.isEmpty()){
		for (Object[] srcObj : prdctnCdDtlList) {
			ProductionCodeDetailDto prdctnCdDto = new ProductionCodeDetailDto();
			prdctnCdDto.setPrdctnGrpCd(getIntegerValue(srcObj[0]));
			prdctnCdDto.setPrdctnCtgryCode(getIntegerValue(srcObj[1]));
			prdctnCdDto.setPrdctnClsCode(getIntegerValue(srcObj[2]));
			prdctnCdDto.setProductionCodeDesc(getStringValue(srcObj[3]));
			productionCodeList.add(prdctnCdDto);
		}
		}
		return productionCodeList;
	}
	
	
	public List<SmicCodeDescWrapper> mapCodeWithDesc(List<Object[]> record) {
		List<SmicCodeDescWrapper> codeWithDescList=new ArrayList<>();
		if(!record.isEmpty()){
			for (Object[] srcObj : record) {
				SmicCodeDescWrapper codeWithDesc =new SmicCodeDescWrapper();
				codeWithDesc.setCode(getBigDecimalValue(srcObj[0]));
				codeWithDesc.setCodeDesc(getStringValue(srcObj[1]));
				codeWithDescList.add(codeWithDesc);
			}
		}
		return codeWithDescList;
	}
	/**
	 * @param departments
	 * @return
	 */
	public List<DepartmentDto> buildDepartmentDtoList(
			List<Object[]> departments) {
		List<DepartmentDto> deptList = new ArrayList<>();
		for (Object[] srcObj : departments) {
			DepartmentDto deptDto = new DepartmentDto();
			deptDto.setDepartmentName(getStringValue(srcObj[0]));
			deptDto.setDepartmentCode(getStringValue(srcObj[1]));
			deptList.add(deptDto);
		}
		return deptList;
	}

	
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}
	

	public SalesData mapToSalesData(SalesShip salesShip) {
		SalesData salesDataDto = new SalesData();
		salesDataDto.setNewDate(getDate(salesShip.getItemSetupDate()));
		salesDataDto.setLastShipDate(getDate(salesShip.getLastShipDate()));
		salesDataDto.setLastSaleDate(getDate(salesShip.getLastSaleDate()));
		salesDataDto.setTotalSales(getBigDecimalValue(salesShip.getTotalSales()));
		salesDataDto.setCasesOrdered(getBigDecimalValue(salesShip.getCasesOrdrd()));
		return salesDataDto;
	}
	
	private String getDate(Object obj){
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		if(obj == null){
			return "";
		}
		else{
			return formatter.format((Date) obj);
		}
	}
	
	private Character getCharacterValue(Object obj){
		String empty=" ";
		if(obj == null)
			return Character.valueOf(empty.charAt(0));
		return (Character) obj;
	}
	
	private Integer getIntegerValue(Object obj){
		if(obj == null)
			return Integer.valueOf(0);
		return (Integer) obj;
	}

	/**For Addnl details bakery deli **/
	public NewItemDetailDto mapAddnlDetailsOnDto(NewItemDetailDto newItemDto,
			UIExceptionSrcDto uiExceptionSrcDto,
			List<Object[]> addtionDetailsObj) {
		
		newItemDto.setPullBydays(newItemDto.getPullBydays()!=null ?newItemDto.getPullBydays() :null);
		newItemDto.setSellByDays(newItemDto.getSellByDays()!=null ?newItemDto.getSellByDays() :"0");
		newItemDto.setUseByDays(newItemDto.getUseByDays()!=null ?newItemDto.getUseByDays() :"0");
		newItemDto.setTareCd(newItemDto.getTareCd() !=null ? newItemDto.getTareCd() : "0");
		
		for(Object[] obj :addtionDetailsObj)
		{			
		
			if(uiExceptionSrcDto.getDspFlag().equals('Y') )
				{
				newItemDto.setProdwght(newItemDto.getProdwght()!=null ? newItemDto.getProdwght() :"0");
				newItemDto.setRandomWtCd(newItemDto.getRandomWtCd()!=null ? newItemDto.getRandomWtCd() :" ");
				newItemDto.setAutoCostInv(newItemDto.getAutoCostInv()!=null ? newItemDto.getAutoCostInv() :"A" );
				newItemDto.setLabelSize(newItemDto.getLabelSize()!=null ? newItemDto.getLabelSize() : "N");
				newItemDto.setLabelNumbers(newItemDto.getLabelNumbers()!=null ? newItemDto.getLabelNumbers() : "0");
				newItemDto.setSgnCount1(newItemDto.getSgnCount1()!=null ? newItemDto.getSgnCount1() : "0");
				newItemDto.setSgnCount2(newItemDto.getSgnCount2()!=null ? newItemDto.getSgnCount2() : "0");
				newItemDto.setSgnCount3(newItemDto.getSgnCount3()!=null ? newItemDto.getSgnCount3() : "0");
				newItemDto.setRing(newItemDto.getRing()!=null ? newItemDto.getRing() : "0");
				
				}
			else if( uiExceptionSrcDto.getProductSrcCd().equalsIgnoreCase("D"))
			{

				newItemDto.setProdwght(newItemDto.getProdwght()!=null ? newItemDto.getProdwght() :"0");
				newItemDto.setRandomWtCd(newItemDto.getRandomWtCd()!=null ? newItemDto.getRandomWtCd() :" ");
				newItemDto.setAutoCostInv(newItemDto.getAutoCostInv()!=null ? newItemDto.getAutoCostInv() :"I" );
					
			}
			else if(uiExceptionSrcDto.getProductSrcCd().equalsIgnoreCase("W"))
			{
				newItemDto.setProdwght(newItemDto.getProdwght()!=null ? newItemDto.getProdwght(): getStringValue(obj[0]));
				 if(getStringValue(obj[1]).equalsIgnoreCase("Y"))
				 {
					 newItemDto.setRandomWtCd(newItemDto.getRandomWtCd()!=null ? newItemDto.getRandomWtCd() : "R"); 
					 newItemDto.setAutoCostInv(newItemDto.getAutoCostInv()!=null ? newItemDto.getAutoCostInv() :"I" );
					 newItemDto.setBillingType(newItemDto.getBillingType()!=null ?newItemDto.getBillingType() : "A");
				 }
				 else if(getStringValue(obj[1]).equalsIgnoreCase("N"))
				 {
					 newItemDto.setRandomWtCd(newItemDto.getRandomWtCd()!=null ? newItemDto.getRandomWtCd() : " ");
					 newItemDto.setAutoCostInv(newItemDto.getAutoCostInv()!=null ? newItemDto.getAutoCostInv() :"A" );
					 
				 }
				 else
				 {
					 newItemDto.setRandomWtCd(newItemDto.getRandomWtCd()!=null ? newItemDto.getRandomWtCd() : null); 
					 newItemDto.setAutoCostInv(newItemDto.getAutoCostInv()!=null ? newItemDto.getAutoCostInv() :"A" );
					 
				 }
			}
			
			newItemDto.setBillingType(newItemDto.getBillingType()!=null ?newItemDto.getBillingType() : " "); 
			
			// For label size
			if(getStringValue(obj[2]).equalsIgnoreCase("S"))
			{
				newItemDto.setLabelSize(newItemDto.getLabelSize()!=null ? newItemDto.getLabelSize() : getStringValue(obj[3]));	
			}
			else
			{
				newItemDto.setLabelSize(newItemDto.getLabelSize()!=null ? newItemDto.getLabelSize() : null);
			}
			// For lable number
			if(getStringValue(obj[4]).equalsIgnoreCase("S"))
			{
				newItemDto.setLabelNumbers(newItemDto.getLabelNumbers()!=null ? newItemDto.getLabelNumbers() : getStringValue(obj[5]));	
			}
			else
			{
				newItemDto.setLabelNumbers(newItemDto.getLabelNumbers()!=null ? newItemDto.getLabelNumbers() : null);
			}
			
			
			newItemDto.setSgnCount1(newItemDto.getSgnCount1()!=null ? newItemDto.getSgnCount1() : getStringValue(obj[7]));
			newItemDto.setSgnCount2(newItemDto.getSgnCount2()!=null ? newItemDto.getSgnCount2() : getStringValue(obj[7]));
			newItemDto.setSgnCount3(newItemDto.getSgnCount3()!=null ? newItemDto.getSgnCount3() : getStringValue(obj[7]));
			
			newItemDto.setSgnCount1(newItemDto.getSgnCount1().equalsIgnoreCase("") ? "0" : newItemDto.getSgnCount1() );
			newItemDto.setSgnCount2(newItemDto.getSgnCount2().equalsIgnoreCase("") ? "0" : newItemDto.getSgnCount2() );
			newItemDto.setSgnCount3(newItemDto.getSgnCount3().equalsIgnoreCase("") ? "0" : newItemDto.getSgnCount3() );
			
			/*For food Stamp*/
			if( getStringValue(obj[8]).equalsIgnoreCase("I") || getStringValue(obj[8]).equalsIgnoreCase("D"))
			{
				newItemDto.setFdStmp(newItemDto.getFdStmp() !=null ? newItemDto.getFdStmp() :null);
			}
			else if ( getStringValue(obj[8]).equalsIgnoreCase("S") && getStringValue(obj[9]).equalsIgnoreCase("Y"))
			{
				newItemDto.setFdStmp(newItemDto.getFdStmp() !=null ? newItemDto.getFdStmp() :"1");
			}
			else if ( getStringValue(obj[8]).equalsIgnoreCase("S") && getStringValue(obj[9]).equalsIgnoreCase("N"))
			{
				newItemDto.setFdStmp(newItemDto.getFdStmp() !=null ? newItemDto.getFdStmp() :"0");
			}
			
			/*RING setting*/
			boolean plu =false;
			for(String upc :uiExceptionSrcDto.getUpcLIst())
			{
				if(Float.parseFloat(upc.replaceAll("-", "")) <100000)
				{
					plu =true;
					break;
				}
			}
			
			if(getStringValue(obj[10]).equalsIgnoreCase("S") && uiExceptionSrcDto.getSelling_method_cd() != null && (uiExceptionSrcDto.getSelling_method_cd().equals("W") || uiExceptionSrcDto.getSelling_method_cd().equals("POUND"))
					&& uiExceptionSrcDto.getUpcSystem().equals("2")	&&	uiExceptionSrcDto.getUpcCountry().equals("0"))
			{
				newItemDto.setRing(newItemDto.getRing()!=null ? newItemDto.getRing():"1");
			}
			else if(getStringValue(obj[10]).equalsIgnoreCase("S") && uiExceptionSrcDto.getSelling_method_cd() != null && (uiExceptionSrcDto.getSelling_method_cd().equals("E") || uiExceptionSrcDto.getSelling_method_cd().equals("EACH"))
					 &&	uiExceptionSrcDto.getUpcSystem().equals("2")	&&	uiExceptionSrcDto.getUpcCountry().equals("0")
						)
			{
					newItemDto.setRing(newItemDto.getRing()!=null ? newItemDto.getRing():"5");
			}
			else if(getStringValue(obj[10]).equalsIgnoreCase("S") && uiExceptionSrcDto.getSelling_method_cd() != null && (uiExceptionSrcDto.getSelling_method_cd().equals("W") || uiExceptionSrcDto.getSelling_method_cd().equals("POUND"))
					 && plu
						)
			{
					newItemDto.setRing(newItemDto.getRing()!=null ? newItemDto.getRing():"2");
			}else
			{
				newItemDto.setRing(newItemDto.getRing()!=null ? newItemDto.getRing():"0");
			}
			
			/*Hicone default setting*/
			if(getStringValue(obj[11]).equalsIgnoreCase("S") && getStringValue(obj[12]).equalsIgnoreCase("Y") )
				{
					newItemDto.setHicone(newItemDto.getHicone()!=null ? newItemDto.getHicone():"1");
				}
				else if(getStringValue(obj[11]).equalsIgnoreCase("S") && getStringValue(obj[12]).equalsIgnoreCase("N") )
				{
					newItemDto.setHicone(newItemDto.getHicone()!=null ? newItemDto.getHicone():"0");
				}				
				else
				{
					newItemDto.setHicone(newItemDto.getHicone()!=null ? newItemDto.getHicone():"0");
				}
				
			uiExceptionSrcDto.setCost(uiExceptionSrcDto.getCost()!=null ? uiExceptionSrcDto.getCost() :getStringValue(obj[13]));
		}
		
		
		return newItemDto;
	}

}
