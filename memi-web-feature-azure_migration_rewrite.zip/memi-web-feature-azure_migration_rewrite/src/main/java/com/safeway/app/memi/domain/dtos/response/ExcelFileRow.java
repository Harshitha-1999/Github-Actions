package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.List;

public class ExcelFileRow {
	private String action;
	private String companyId;
	private String divisionId;
	private String productSku;
	private String productSrcCd;
	private String upc;
	private String pluCode;
	private Character primaryUpcInd;
	private BigDecimal vendConvFactor;
	private BigDecimal packWhse;
	private BigDecimal vendorCost;

	private String srcItemDesc;
	private String srcWhseItemDesc;
	private String srcRtlItemDesc;
	private String srcInternetDesc;
	private String srcPosDesc;
	private Character srcItemUsgeInd;
	private Character srcItemUsgeTypeInd;
	private Character srcPrivateLabelInd;

	private String srcSize;
	private BigDecimal srcSizeNum;
	private String srcSizeUom;
	private Character srcDspFlag;

	private String updItemDesc;
	private String updWhseItemDesc;
	private String updRtlItemDesc;
	private String updInternetItemDesc;
	private String updPosDesc;
	private Character updItemUsageInd;
	private Character updItemUsageTypInd;
	private Character updPrivateLabelInd;
	private Character updDispFlag;
	private String updSize;
	private BigDecimal updSizeNmbr;
	private String updSizeUom;

	private String hierLevel1;
	private String hierLevel2;
	private String hierLevel3;
	private String hierLevel4;
	private String hierLevel5;

	private Integer grpCd;
	private Integer ctgryCd;
	private Integer clsCd;
	private Integer sbClsCd;
	private Integer subSbClassCd;

	private BigDecimal batchId;
	private Integer productionGrpCd;
	private Integer productionCtgryCd;
	private Integer productionClsCd;
	private String ethnicTypeCd;
	private BigDecimal pckTypeId;
	private Integer productClsCd;
	private Integer innerPack;
	private Integer retailUnitPack;
	private String convTeamComments;

	/*Produce PLU*/
	private String updUpc;
  	private String updPlu; 
    private String dcPackDesc;
	private String dcSizeDsc;
	private String ring;
	private String hicone;

	private String prodwght;
	private String handlingCode;
	private String buyerNum;
	private String randomWtCd;	
	private String autoCostInv; 
	private String billingType;
	private String fdStmp;
	private String labelSize;
	private String labelNumbers;
	private String sgnCount1;
	private String sgnCount2;
	private String sgnCount3;
	private String sellByDays;
	private String useByDays;
	private String pullBydays;
	private String tareCd;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSku() {
		return productSku;
	}

	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}

	public String getProductSrcCd() {
		return productSrcCd;
	}

	public void setProductSrcCd(String productSrcCd) {
		this.productSrcCd = productSrcCd;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getPluCode() {
		return pluCode;
	}

	public void setPluCode(String pluCode) {
		this.pluCode = pluCode;
	}

	public Character getPrimaryUpcInd() {
		return primaryUpcInd;
	}

	public void setPrimaryUpcInd(Character primaryUpcInd) {
		this.primaryUpcInd = primaryUpcInd;
	}

	public BigDecimal getVendConvFactor() {
		return vendConvFactor;
	}

	public void setVendConvFactor(BigDecimal vendConvFactor) {
		this.vendConvFactor = vendConvFactor;
	}

	public BigDecimal getPackWhse() {
		return packWhse;
	}

	public void setPackWhse(BigDecimal packWhse) {
		this.packWhse = packWhse;
	}

	public BigDecimal getVendorCost() {
		return vendorCost;
	}

	public void setVendorCost(BigDecimal vendorCost) {
		this.vendorCost = vendorCost;
	}

	public String getSrcItemDesc() {
		return srcItemDesc;
	}

	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}

	public String getSrcWhseItemDesc() {
		return srcWhseItemDesc;
	}

	public void setSrcWhseItemDesc(String srcWhseItemDesc) {
		this.srcWhseItemDesc = srcWhseItemDesc;
	}

	public String getSrcRtlItemDesc() {
		return srcRtlItemDesc;
	}

	public void setSrcRtlItemDesc(String srcRtlItemDesc) {
		this.srcRtlItemDesc = srcRtlItemDesc;
	}

	public String getSrcInternetDesc() {
		return srcInternetDesc;
	}

	public void setSrcInternetDesc(String srcInternetDesc) {
		this.srcInternetDesc = srcInternetDesc;
	}

	public String getSrcPosDesc() {
		return srcPosDesc;
	}

	public void setSrcPosDesc(String srcPosDesc) {
		this.srcPosDesc = srcPosDesc;
	}

	public Character getSrcItemUsgeInd() {
		return srcItemUsgeInd;
	}

	public void setSrcItemUsgeInd(Character srcItemUsgeInd) {
		this.srcItemUsgeInd = srcItemUsgeInd;
	}

	public Character getSrcItemUsgeTypeInd() {
		return srcItemUsgeTypeInd;
	}

	public void setSrcItemUsgeTypeInd(Character srcItemUsgeTypeInd) {
		this.srcItemUsgeTypeInd = srcItemUsgeTypeInd;
	}

	public Character getSrcPrivateLabelInd() {
		return srcPrivateLabelInd;
	}

	public void setSrcPrivateLabelInd(Character srcPrivateLabelInd) {
		this.srcPrivateLabelInd = srcPrivateLabelInd;
	}

	public String getSrcSize() {
		return srcSize;
	}

	public void setSrcSize(String srcSize) {
		this.srcSize = srcSize;
	}

	public BigDecimal getSrcSizeNum() {
		return srcSizeNum;
	}

	public void setSrcSizeNum(BigDecimal srcSizeNum) {
		this.srcSizeNum = srcSizeNum;
	}

	public String getSrcSizeUom() {
		return srcSizeUom;
	}

	public void setSrcSizeUom(String srcSizeUom) {
		this.srcSizeUom = srcSizeUom;
	}

	public Character getSrcDspFlag() {
		return srcDspFlag;
	}

	public void setSrcDspFlag(Character srcDspFlag) {
		this.srcDspFlag = srcDspFlag;
	}

	public String getUpdItemDesc() {
		return updItemDesc;
	}

	public void setUpdItemDesc(String updItemDesc) {
		this.updItemDesc = updItemDesc;
	}

	public String getUpdWhseItemDesc() {
		return updWhseItemDesc;
	}

	public void setUpdWhseItemDesc(String updWhseItemDesc) {
		this.updWhseItemDesc = updWhseItemDesc;
	}

	public String getUpdRtlItemDesc() {
		return updRtlItemDesc;
	}

	public void setUpdRtlItemDesc(String updRtlItemDesc) {
		this.updRtlItemDesc = updRtlItemDesc;
	}

	public String getUpdInternetItemDesc() {
		return updInternetItemDesc;
	}

	public void setUpdInternetItemDesc(String updInternetItemDesc) {
		this.updInternetItemDesc = updInternetItemDesc;
	}

	public String getUpdPosDesc() {
		return updPosDesc;
	}

	public void setUpdPosDesc(String updPosDesc) {
		this.updPosDesc = updPosDesc;
	}

	public Character getUpdItemUsageInd() {
		return updItemUsageInd;
	}

	public void setUpdItemUsageInd(Character updItemUsageInd) {
		this.updItemUsageInd = updItemUsageInd;
	}

	public Character getUpdItemUsageTypInd() {
		return updItemUsageTypInd;
	}

	public void setUpdItemUsageTypInd(Character updItemUsageTypInd) {
		this.updItemUsageTypInd = updItemUsageTypInd;
	}

	public Character getUpdPrivateLabelInd() {
		return updPrivateLabelInd;
	}

	public void setUpdPrivateLabelInd(Character updPrivateLabelInd) {
		this.updPrivateLabelInd = updPrivateLabelInd;
	}

	public Character getUpdDispFlag() {
		return updDispFlag;
	}

	public void setUpdDispFlag(Character updDispFlag) {
		this.updDispFlag = updDispFlag;
	}

	public String getUpdSize() {
		return updSize;
	}

	public void setUpdSize(String updSize) {
		this.updSize = updSize;
	}

	public BigDecimal getUpdSizeNmbr() {
		return updSizeNmbr;
	}

	public void setUpdSizeNmbr(BigDecimal updSizeNmbr) {
		this.updSizeNmbr = updSizeNmbr;
	}

	public String getUpdSizeUom() {
		return updSizeUom;
	}

	public void setUpdSizeUom(String updSizeUom) {
		this.updSizeUom = updSizeUom;
	}

	public String getHierLevel1() {
		return hierLevel1;
	}

	public void setHierLevel1(String hierLevel1) {
		this.hierLevel1 = hierLevel1;
	}

	public String getHierLevel2() {
		return hierLevel2;
	}

	public void setHierLevel2(String hierLevel2) {
		this.hierLevel2 = hierLevel2;
	}

	public String getHierLevel3() {
		return hierLevel3;
	}

	public void setHierLevel3(String hierLevel3) {
		this.hierLevel3 = hierLevel3;
	}

	public String getHierLevel4() {
		return hierLevel4;
	}

	public void setHierLevel4(String hierLevel4) {
		this.hierLevel4 = hierLevel4;
	}

	public String getHierLevel5() {
		return hierLevel5;
	}

	public void setHierLevel5(String hierLevel5) {
		this.hierLevel5 = hierLevel5;
	}

	public Integer getGrpCd() {
		return grpCd;
	}

	public void setGrpCd(Integer grpCd) {
		this.grpCd = grpCd;
	}

	public Integer getCtgryCd() {
		return ctgryCd;
	}

	public void setCtgryCd(Integer ctgryCd) {
		this.ctgryCd = ctgryCd;
	}

	public Integer getClsCd() {
		return clsCd;
	}

	public void setClsCd(Integer clsCd) {
		this.clsCd = clsCd;
	}

	public Integer getSbClsCd() {
		return sbClsCd;
	}

	public void setSbClsCd(Integer sbClsCd) {
		this.sbClsCd = sbClsCd;
	}

	public Integer getSubSbClassCd() {
		return subSbClassCd;
	}

	public void setSubSbClassCd(Integer subSbClassCd) {
		this.subSbClassCd = subSbClassCd;
	}

	public BigDecimal getBatchId() {
		return batchId;
	}

	public void setBatchId(BigDecimal batchId) {
		this.batchId = batchId;
	}

	public Integer getProductionGrpCd() {
		return productionGrpCd;
	}

	public void setProductionGrpCd(Integer productionGrpCd) {
		this.productionGrpCd = productionGrpCd;
	}

	public Integer getProductionCtgryCd() {
		return productionCtgryCd;
	}

	public void setProductionCtgryCd(Integer productionCtgryCd) {
		this.productionCtgryCd = productionCtgryCd;
	}

	public Integer getProductionClsCd() {
		return productionClsCd;
	}

	public void setProductionClsCd(Integer productionClsCd) {
		this.productionClsCd = productionClsCd;
	}

	public String getEthnicTypeCd() {
		return ethnicTypeCd;
	}

	public void setEthnicTypeCd(String ethnicTypeCd) {
		this.ethnicTypeCd = ethnicTypeCd;
	}

	public BigDecimal getPckTypeId() {
		return pckTypeId;
	}

	public void setPckTypeId(BigDecimal pckTypeId) {
		this.pckTypeId = pckTypeId;
	}

	public Integer getProductClsCd() {
		return productClsCd;
	}

	public void setProductClsCd(Integer productClsCd) {
		this.productClsCd = productClsCd;
	}

	public Integer getInnerPack() {
		return innerPack;
	}

	public void setInnerPack(Integer innerPack) {
		this.innerPack = innerPack;
	}

	public Integer getRetailUnitPack() {
		return retailUnitPack;
	}

	public void setRetailUnitPack(Integer retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}

	public String getConvTeamComments() {
		return convTeamComments;
	}

	public void setConvTeamComments(String convTeamComments) {
		this.convTeamComments = convTeamComments;
	}

	@Override
	public String toString() {
		return "ExcelFileRow [action=" + action + ", companyId=" + companyId
				+ ", divisionId=" + divisionId + ", productSku=" + productSku
				+ ", productSrcCd=" + productSrcCd + ", upc=" + upc
				+ ", pluCode=" + pluCode + ", primaryUpcInd=" + primaryUpcInd
				+ ", vendConvFactor=" + vendConvFactor + ", packWhse="
				+ packWhse + ", vendorCost=" + vendorCost + ", srcItemDesc="
				+ srcItemDesc + ", srcWhseItemDesc=" + srcWhseItemDesc
				+ ", srcRtlItemDesc=" + srcRtlItemDesc + ", srcInternetDesc="
				+ srcInternetDesc + ", srcPosDesc=" + srcPosDesc
				+ ", srcItemUsgeInd=" + srcItemUsgeInd
				+ ", srcItemUsgeTypeInd=" + srcItemUsgeTypeInd
				+ ", srcPrivateLabelInd=" + srcPrivateLabelInd + ", srcSize="
				+ srcSize + ", srcSizeNum=" + srcSizeNum + ", srcSizeUom="
				+ srcSizeUom + ", srcDspFlag=" + srcDspFlag + ", updItemDesc="
				+ updItemDesc + ", updWhseItemDesc=" + updWhseItemDesc
				+ ", updRtlItemDesc=" + updRtlItemDesc
				+ ", updInternetItemDesc=" + updInternetItemDesc
				+ ", updPosDesc=" + updPosDesc + ", updItemUsageInd="
				+ updItemUsageInd + ", updItemUsageTypInd="
				+ updItemUsageTypInd + ", updPrivateLabelInd="
				+ updPrivateLabelInd + ", updDispFlag=" + updDispFlag
				+ ", updSize=" + updSize + ", updSizeNmbr=" + updSizeNmbr
				+ ", updSizeUom=" + updSizeUom + ", hierLevel1=" + hierLevel1
				+ ", hierLevel2=" + hierLevel2 + ", hierLevel3=" + hierLevel3
				+ ", hierLevel4=" + hierLevel4 + ", hierLevel5=" + hierLevel5
				+ ", grpCd=" + grpCd + ", ctgryCd=" + ctgryCd + ", clsCd="
				+ clsCd + ", sbClsCd=" + sbClsCd + ", subSbClassCd="
				+ subSbClassCd + ", batchId=" + batchId + ", productionGrpCd="
				+ productionGrpCd + ", productionCtgryCd=" + productionCtgryCd
				+ ", productionClsCd=" + productionClsCd + ", ethnicTypeCd="
				+ ethnicTypeCd + ", pckTypeId=" + pckTypeId + ", productClsCd="
				+ productClsCd + ", innerPack=" + innerPack
				+ ", retailUnitPack=" + retailUnitPack + ", convTeamComments="
				+ convTeamComments + "]";
	}

	public String getUpdUpc() {
		return updUpc;
	}

	public void setUpdUpc(String updUpc) {
		this.updUpc = updUpc;
	}

	public String getDcPackDesc() {
		return dcPackDesc;
	}

	public void setDcPackDesc(String dcPackDesc) {
		this.dcPackDesc = dcPackDesc;
	}

	public String getDcSizeDsc() {
		return dcSizeDsc;
	}

	public void setDcSizeDsc(String dcSizeDsc) {
		this.dcSizeDsc = dcSizeDsc;
	}

	public String getUpdPlu() {
		return updPlu;
	}

	public void setUpdPlu(String updPlu) {
		this.updPlu = updPlu;
	}

	public String getRing() {
		return ring;
	}

	public void setRing(String ring) {
		this.ring = ring;
	}

	public String getHicone() {
		return hicone;
	}

	public void setHicone(String hicone) {
		this.hicone = hicone;
	}

	public String getProdwght() {
		return prodwght;
	}

	public void setProdwght(String prodwght) {
		this.prodwght = prodwght;
	}

	public String getHandlingCode() {
		return handlingCode;
	}

	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}

	public String getBuyerNum() {
		return buyerNum;
	}

	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}

	public String getRandomWtCd() {
		return randomWtCd;
	}

	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}

	public String getAutoCostInv() {
		return autoCostInv;
	}

	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getFdStmp() {
		return fdStmp;
	}

	public void setFdStmp(String fdStmp) {
		this.fdStmp = fdStmp;
	}

	public String getLabelSize() {
		return labelSize;
	}

	public void setLabelSize(String labelSize) {
		this.labelSize = labelSize;
	}

	public String getLabelNumbers() {
		return labelNumbers;
	}

	public void setLabelNumbers(String labelNumbers) {
		this.labelNumbers = labelNumbers;
	}

	public String getSgnCount1() {
		return sgnCount1;
	}

	public void setSgnCount1(String sgnCount1) {
		this.sgnCount1 = sgnCount1;
	}

	public String getSgnCount2() {
		return sgnCount2;
	}

	public void setSgnCount2(String sgnCount2) {
		this.sgnCount2 = sgnCount2;
	}

	public String getSgnCount3() {
		return sgnCount3;
	}

	public void setSgnCount3(String sgnCount3) {
		this.sgnCount3 = sgnCount3;
	}

	public String getSellByDays() {
		return sellByDays;
	}

	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}

	public String getUseByDays() {
		return useByDays;
	}

	public void setUseByDays(String useByDays) {
		this.useByDays = useByDays;
	}

	public String getPullBydays() {
		return pullBydays;
	}

	public void setPullBydays(String pullBydays) {
		this.pullBydays = pullBydays;
	}

	public String getTareCd() {
		return tareCd;
	}

	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}

	

}
