/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

/**
 ****************************************************************************
 * NAME : BakeryCICSearchResults 
 * 
 * DESCRIPTION :BakeryCICSearchResults is the class to store the bakery search data of target item
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 mar 05, 2018  - Initial Creation
 * *************************************************************************
 */
public class BakeryCICSearchResults extends PerishableCICSearchResults {
	
	private BigDecimal tareCode;
	private char scale;
	private BigDecimal shelfLife;
	private BigDecimal bakeryIngredients;
	private BigDecimal scaleSellByDays;
	private BigDecimal scaleEatByDays;
	private BigDecimal scaleNetWeight;
	private String scaleNetWeightUnit;
	//NIMS-info-switch - need to review if needed.
	//Scale-package - 4 fields - need to evaluate if needed. 
	
	/**
	 * @return the tareCode
	 */
	public BigDecimal getTareCode() {
		return tareCode;
	}
	/**
	 * @param tareCode the tareCode to set
	 */
	public void setTareCode(BigDecimal tareCode) {
		this.tareCode = tareCode;
	}
	/**
	 * @return the scale
	 */
	public char getScale() {
		return scale;
	}
	/**
	 * @param scale the scale to set
	 */
	public void setScale(char scale) {
		this.scale = scale;
	}
	/**
	 * @return the shelfLife
	 */
	public BigDecimal getShelfLife() {
		return shelfLife;
	}
	/**
	 * @param shelfLife the shelfLife to set
	 */
	public void setShelfLife(BigDecimal shelfLife) {
		this.shelfLife = shelfLife;
	}
	/**
	 * @return the bakeryIngredients
	 */
	public BigDecimal getBakeryIngredients() {
		return bakeryIngredients;
	}
	/**
	 * @param bakeryIngredients the bakeryIngredients to set
	 */
	public void setBakeryIngredients(BigDecimal bakeryIngredients) {
		this.bakeryIngredients = bakeryIngredients;
	}
	/**
	 * @return the scaleSellByDays
	 */
	public BigDecimal getScaleSellByDays() {
		return scaleSellByDays;
	}
	/**
	 * @param scaleSellByDays the scaleSellByDays to set
	 */
	public void setScaleSellByDays(BigDecimal scaleSellByDays) {
		this.scaleSellByDays = scaleSellByDays;
	}
	/**
	 * @return the scaleEatByDays
	 */
	public BigDecimal getScaleEatByDays() {
		return scaleEatByDays;
	}
	/**
	 * @param scaleEatByDays the scaleEatByDays to set
	 */
	public void setScaleEatByDays(BigDecimal scaleEatByDays) {
		this.scaleEatByDays = scaleEatByDays;
	}
	/**
	 * @return the scaleNetWeight
	 */
	public BigDecimal getScaleNetWeight() {
		return scaleNetWeight;
	}
	/**
	 * @param scaleNetWeight the scaleNetWeight to set
	 */
	public void setScaleNetWeight(BigDecimal scaleNetWeight) {
		this.scaleNetWeight = scaleNetWeight;
	}
	/**
	 * @return the scaleNetWeightUnit
	 */
	public String getScaleNetWeightUnit() {
		return scaleNetWeightUnit;
	}
	/**
	 * @param scaleNetWeightUnit the scaleNetWeightUnit to set
	 */
	public void setScaleNetWeightUnit(String scaleNetWeightUnit) {
		this.scaleNetWeightUnit = scaleNetWeightUnit;
	}
	
	
	
}
