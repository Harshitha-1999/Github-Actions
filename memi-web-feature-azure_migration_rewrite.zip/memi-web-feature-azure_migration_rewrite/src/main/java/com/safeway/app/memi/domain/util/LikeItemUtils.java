package com.safeway.app.memi.domain.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

/* ***************************************************************************
 * NAME         : LikeItemUtils
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Safeway IT
 *
  REVISION HISTORY
 * 
 * Revision 0.0.0.0  June 11, 2017 sgang06 - Initial Creation
 *
 ***************************************************************************/
public class LikeItemUtils {
	private static final Logger LOG = LoggerFactory.getLogger(LikeItemUtils.class);

	
	public static int INDEX_UPC_MATCH = 2;
	
	private Hashtable<String, String> rogRankingTable = new Hashtable<String, String>(); 
	
	/**
	 * 
	 * Method to rank like items
	 * @param likeItems
	 * @param excSrcItem
	 */
	public static void orderLikeItemsOriginal(List<NewItemDetailDto> likeItems, UIExceptionSrcDto excSrcItem)
	{
		LOG.info("Execution started for order Like ItemsOriginal");
		if(likeItems == null || likeItems.size() == 0 || excSrcItem == null)
			return;
		for(NewItemDetailDto likeItem : likeItems)
		{
			// pending discussion on multi upc
			if(likeItem.getPrimayUpcString().equalsIgnoreCase(excSrcItem.getPrimaryUPCforDisplay())){
				likeItem.setPeckingOrder(1);
				continue;
			}
			if(likeItem.getDispFlag().equals(excSrcItem.getDspFlag())){
				likeItem.setPeckingOrder(2);
				continue;
			}
			if(likeItem.getItemUsageTypInd().equals(excSrcItem.getItmUsgeTypInd())){
				likeItem.setPeckingOrder(3);
				continue;
			}
			
			// Order 4 reserved for master case match

			if(likeItem.getUpdSizeNmbr() == excSrcItem.getSizeNbr() && likeItem.getUpdSizeUom().equalsIgnoreCase(excSrcItem.getSzUom())){
				likeItem.setPeckingOrder(5);
				continue;
			}
			
			if(likeItem.getUpdSizeNmbr() == excSrcItem.getSizeNbr()){
				likeItem.setPeckingOrder(6);
				continue;
			}
		}
		
		Collections.sort(likeItems, new Comparator<NewItemDetailDto>() {
		      public int compare(NewItemDetailDto item1, NewItemDetailDto item2) {
		          return Integer.valueOf(item1.getPeckingOrder()).compareTo(Integer.valueOf(item2.getPeckingOrder()));
		        }
		        });
		likeItems.get(0).setMostRecommendedItem(true);
		LOG.info("Execution completed for order Like ItemsOriginal");

		return;
	}
	
	
	/**
	 * 
	 * Method to rank like items
	 * @param likeItems
	 * @param excSrcItem
	 */
	public List<NewItemDetailDto> orderLikeItems(List<NewItemDetailDto> likeItems, UIExceptionSrcDto excSrcItem, List<Object[]> rogRankings)
	{
		LOG.info("Execution started for order Like Items");

		if(likeItems == null || likeItems.size() == 0 || excSrcItem == null)
			return likeItems;
		loadRogRankingTable(rogRankings);
		List<NewItemDetailDto> processedlikeItems = processLikeItemRanking(likeItems, excSrcItem, 0);
		if(processedlikeItems.size() > 0 ) 
			processedlikeItems.get(0).setMostRecommendedItem(true);
		LOG.info("Execution completed for order Like Items");

		return processedlikeItems;
	}
	
	/**
	 * 
	 * Method to rank like items
	 * @param likeItems
	 * @param excSrcItem
	 */
	public List<NewItemDetailDto> processLikeItemRanking(List<NewItemDetailDto> likeItems, UIExceptionSrcDto excSrcItem, int startingRank)
	{
		LOG.info("Execution started for process Like Item Ranking");

		if(likeItems == null || likeItems.size() == 0 || excSrcItem == null)
			return likeItems;
		Hashtable<Integer, List<NewItemDetailDto>> likeItemRankingTable = new Hashtable<Integer, List<NewItemDetailDto>>();
		int highestDCCount = 0;
		int highestROGRank = 0;
		for(NewItemDetailDto likeItem : likeItems)
		{
			//UPC Set - Full match
			if(startingRank < 1 && checkFullUPCMatch(likeItem.getUpcs(),  new TreeSet<String>(excSrcItem.getUpcLIst()))){
				addToItemRankingTable(likeItemRankingTable, likeItem, 1);
				continue;
			}
			//UPC Set - Partial match
			if(startingRank < 2){
				int partialMatchCount = checkPartialUPCMatch(likeItem.getUpcs(),  new TreeSet<String>(excSrcItem.getUpcLIst()));
				if(partialMatchCount > 0){
					likeItem.setUpcMatchCount(partialMatchCount);
					addToItemRankingTable(likeItemRankingTable, likeItem, 2);
					continue;
				}
			}
			//Primary UPC match
			if(startingRank < 3 && likeItem.getPrimayUpcString().equalsIgnoreCase(excSrcItem.getPrimaryUPCforDisplay())){
				addToItemRankingTable(likeItemRankingTable, likeItem, 3);
				continue;
			}
			//Display Flag match 
			if(startingRank < 4 && likeItem.getUpdDispFlag() !=null && likeItem.getUpdDispFlag().equals(excSrcItem.getDspFlag())){
				addToItemRankingTable(likeItemRankingTable, likeItem, 4);
				continue;
			}
			//Usage Type match
			if(startingRank < 5 && likeItem.getItemUsageTypInd() != null && likeItem.getItemUsageTypInd().equals(excSrcItem.getItmUsgeTypInd())){
				addToItemRankingTable(likeItemRankingTable, likeItem, 5);
				continue;
			}			
			// Master case match
			if(startingRank < 6){
				BigDecimal excPack = excSrcItem.getPackWhse();
				BigDecimal excVCF = excSrcItem.getVdCnvFactor();
				BigDecimal likeItemPack = likeItem.getVendConvFactor();
				BigDecimal likeItemVCF = likeItem.getPackwhse();
				BigDecimal excMasterCase = excPack.multiply(excVCF);
				BigDecimal likeItemMasterCase = likeItemPack.multiply(likeItemVCF);
				if(excMasterCase.equals(likeItemMasterCase)){
					addToItemRankingTable(likeItemRankingTable, likeItem, 6);
					continue;
				}
			}
			//Size Num & Size UOM match
			if(startingRank < 7 && likeItem.getUpdSizeNmbr() == excSrcItem.getSizeNbr() && likeItem.getUpdSizeUom().equalsIgnoreCase(excSrcItem.getSzUom())){
				addToItemRankingTable(likeItemRankingTable, likeItem, 7);
				continue;
			}
			//Size Num only match
			if(startingRank < 8 && likeItem.getUpdSizeNmbr() == excSrcItem.getSizeNbr()){
				addToItemRankingTable(likeItemRankingTable, likeItem, 8);
				continue;
			}
			//WHSE or DSD match
			if(startingRank < 9 && likeItem.getProductSrcCd().equalsIgnoreCase(excSrcItem.getProductSrcCd())){
				addToItemRankingTable(likeItemRankingTable, likeItem, 9);
				continue;
			}
			//Case UPC match
			if(startingRank < 10 && likeItem.getCaseUPC().equalsIgnoreCase(excSrcItem.getCaseUPC())){
				addToItemRankingTable(likeItemRankingTable, likeItem, 10);
				continue;
			}
			//Order by Highest DC Count
			if(startingRank < 11 && likeItem.getDcList() != null && likeItem.getDcList().size() >= highestDCCount){
				if(likeItem.getDcList().size() == highestDCCount)
					addToItemRankingTable(likeItemRankingTable, likeItem, 11);
				else
				{
					if(likeItemRankingTable.get(11) != null && likeItemRankingTable.get(11).size() > 0)
						addToItemsRankingTable(likeItemRankingTable, likeItemRankingTable.get(11), 12);
					likeItemRankingTable.remove(11);
					addToItemRankingTable(likeItemRankingTable, likeItem, 11);
					highestDCCount = likeItem.getDcList().size();
				}
				continue;
			}
			//Order by ROG Ranking
			if (startingRank < 13 && likeItem.getDcDetails() != null && likeItem.getDcDetails().get(0) != null && likeItem.getDcDetails().get(0)
					.getRogs()!= null && likeItem.getDcDetails().get(0).getRogs().size()>0) {
				Iterator<String> ROGIter = likeItem.getDcDetails().get(0)
						.getRogs().iterator();
				String ROG = null;
				String rank = null;
				int ROGRank = 0;
				if (ROGIter.hasNext())
					ROG = ROGIter.next();
				if (ROG != null)
					rank = rogRankingTable.get(ROG);
				if (rank != null)
					ROGRank = Integer.parseInt(rank);
				if (ROGRank >= highestROGRank) {
					if (ROGRank == highestROGRank)
						addToItemRankingTable(likeItemRankingTable, likeItem,
								13);
					else {
						if(likeItemRankingTable.get(13) != null && likeItemRankingTable.get(13).size() > 0)
							addToItemsRankingTable(likeItemRankingTable, likeItemRankingTable.get(13), 100);
						likeItemRankingTable.remove(13);
						addToItemRankingTable(likeItemRankingTable, likeItem,
								13);
						highestROGRank = ROGRank;
					}
					continue;
				}
			}
			// Adding unranked items
			addToItemRankingTable(likeItemRankingTable, likeItem, 100);
		}
		
		if(likeItemRankingTable.size() == 0)
			return likeItems;
		TreeSet<Integer> ranks = new TreeSet<Integer>(likeItemRankingTable.keySet());
		Iterator<Integer> rankIter = ranks.iterator();
		int rank = 0;
		List<NewItemDetailDto> orderedItems = new ArrayList<NewItemDetailDto>();
		while(rankIter.hasNext())
		{
			rank = rankIter.next();
			if(rank == 2)
			{
				Collections.sort(likeItemRankingTable.get(rank), new Comparator<NewItemDetailDto>() {
				      public int compare(NewItemDetailDto item1, NewItemDetailDto item2) {
				          return Integer.valueOf(item2.getUpcMatchCount()).compareTo(Integer.valueOf(item1.getUpcMatchCount()));
				        }
				        });
			}
			if(rank != 100 && likeItemRankingTable.get(rank) != null && likeItemRankingTable.get(rank).size() > 1)
				orderedItems.addAll(processLikeItemRanking(likeItemRankingTable.get(rank), excSrcItem, rank));
			else
				orderedItems.addAll(likeItemRankingTable.get(rank));
		}
		LOG.info("Execution completed for process Like Item Ranking");

		return orderedItems;
	}
	
	public boolean checkFullUPCMatch(Set<String> srcUPCs, Set<String> likeUPCs)
	{
		if(srcUPCs == null || srcUPCs.size() == 0 || likeUPCs == null || likeUPCs.size() == 0 || srcUPCs.size() != likeUPCs.size())
			return false;
		return srcUPCs.containsAll(likeUPCs);
	}
	
	public int checkPartialUPCMatch(Set<String> srcUPCs, Set<String> likeUPCs)
	{
		LOG.info("Execution started for check Partial UPCMatch");

		if(srcUPCs == null || likeUPCs == null)
			return 0;
		Iterator<String> iter = srcUPCs.iterator();
		int matchingCount = 0;
		while(iter.hasNext())
		{
			if(likeUPCs.contains(iter.next()))
				matchingCount ++;
		}
		LOG.info("Execution completed for check Partial UPCMatch");

		return matchingCount;
	}
	
	public void addToItemRankingTable(Hashtable<Integer, List<NewItemDetailDto>> likeItemRankingTable, NewItemDetailDto item, int rank)
	{
		List<NewItemDetailDto> itemList = likeItemRankingTable.get(rank);
		if(itemList != null)
			itemList.add(item);
		else
		{
			itemList = new ArrayList<NewItemDetailDto>();
			itemList.add(item);
			likeItemRankingTable.put(rank, itemList);
		}
	}

	public void addToItemsRankingTable(Hashtable<Integer, List<NewItemDetailDto>> likeItemRankingTable,  List<NewItemDetailDto> items, int rank)
	{
		LOG.info("Execution started for add To Items RankingTable");

		List<NewItemDetailDto> itemList = likeItemRankingTable.get(rank);
		if(itemList != null)
			itemList.addAll(items);
		else
		{
			itemList = new ArrayList<NewItemDetailDto>();
			itemList.addAll(items);
			likeItemRankingTable.put(rank, itemList);
		}
		LOG.info("Execution completed for add To Items RankingTable");

	}
	
	private void loadRogRankingTable(List<Object[]> rogRankings)
	{
		LOG.debug("Execution started for load Rog RankingTable");

		for (Object[] srcObj : rogRankings) {
			String rank = (String) (srcObj[0] != null ? (srcObj[0]): null);
			String rogs = (String) (srcObj[1] != null ? (srcObj[1]): null);
			if(rank != null && rogs != null){
				String[] rogArray = rogs.split(",");
				for(int i = 0 ; i < rogArray.length; i++){
					rogRankingTable.put(rogArray[i], rank);
				}
			}
				
		}
		LOG.debug("Execution completed for load Rog RankingTable");

	}
public String formatCaseUpc(String caseUpc){

		String formatedUpc="";
		
		if(caseUpc != null && !caseUpc.trim().isEmpty()){
			
			if (caseUpc.trim().length()==13){
				formatedUpc= caseUpc.subSequence(0, 1)+"-"+caseUpc.subSequence(1, 2)+"-"+caseUpc.subSequence(2, 3)+"-"+caseUpc.subSequence(3, 8)+"-"+caseUpc.subSequence(8, 13);
			}
			else
				formatedUpc= caseUpc.trim();
		}

		return  formatedUpc;
	}
}
