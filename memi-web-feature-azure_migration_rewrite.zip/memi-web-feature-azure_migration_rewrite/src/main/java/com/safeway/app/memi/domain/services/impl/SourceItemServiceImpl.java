/* Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

/* ***************************************************************************
 * NAME : ReportServiceImpl 
 * 
 * SYSTEM : PRMS 
 * 
 * AUTHOR : Keerthana 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 March 09, 2016 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.SourceItemCIC;
import com.safeway.app.memi.data.repositories.SourceItemRepository;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.SourceItem;
import com.safeway.app.memi.domain.services.SourceItemService;

/**
 * 
 * Implementation class for Source Item Services
 *
 */
@Service("sourceItemService")
public class SourceItemServiceImpl implements SourceItemService {

    private static final Logger LOG = LoggerFactory.getLogger(SourceItemServiceImpl.class);

    
    @Autowired
    private SourceItemRepository srcItemRepo;


    private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.SourceItemService#getAllItems(java.lang.String)
	 */
	@Override
	public List<SourceItem> getAllItems(String type) {
		LOG.info("Execution started for getting all items list");
		
		List<SourceItemCIC> srcItemList = srcItemRepo.findAll();
		
		LOG.info("Execution completed for getting "+srcItemList.size()+" items list");

		return viewAdapter.mapToSourceItemDtoList(srcItemList);
	}

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.SourceItemService#getItem(java.lang.String)
	 */
	@Override
	public SourceItem getItem(String productSKU) {
		return null;
	}

}
