package com.safeway.app.memi.domain.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequest;
@Component
public class ActionValidations {
	private static final Logger LOG = LoggerFactory.getLogger(ActionValidations.class);
	
	public List<String> validateActions(List<PerishableMappingRequest> perishableMappingRequests) {
		LOG.info("Execution started for validate Actions");
		List<String> errorMsges = new ArrayList<>();
		if (null != perishableMappingRequests && !perishableMappingRequests.isEmpty()) {
			String productSku = null;
			if (!validateLetAutoMatch(perishableMappingRequests)) {
				errorMsges.add("Please avoid automatch and other mapping actions together!");

			}

			for (PerishableMappingRequest perishableMappingRequest : perishableMappingRequests) {
			
				if (productSku == null && (perishableMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
						|| perishableMappingRequest.getMappingType().equals(PerishableConstants.INHERIT_MAP))) {
					productSku = perishableMappingRequest.getSku();
				}

		/*	if ((perishableMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
						|| perishableMappingRequest.getMappingType().equals(PerishableConstants.INHERIT_MAP))
						&& !productSku.equals(perishableMappingRequest.getSku())) {
					errorMsges.add("Multiple SKU to one CIC mapping is not possible");
					return errorMsges;
				}  */

				if ((perishableMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
						|| perishableMappingRequest.getMappingType().equals(PerishableConstants.INHERIT_MAP))
						&& perishableMappingRequest.getCic() == null) {
					errorMsges.add("You are not selected a CIC for mapping");

				}

				if (perishableMappingRequest.getMappingType().equals(PerishableConstants.MARK_AS_DEAD)
						&& perishableMappingRequest.getCic() != null) {
					errorMsges.add("For marking as dead don't select a CIC from right side");
				}				
				
				if (perishableMappingRequest.getMappingType().equals(PerishableConstants.ADD_MAP)
						&& 
						(Float.parseFloat(StringUtils.leftPad(perishableMappingRequest.getUpc().replaceAll("-", ""), 12, "0")) < 100000 && 
						!perishableMappingRequest.getTargetPLU().isEmpty() && !perishableMappingRequest.getTargetPLU().matches("[0-9]{1,5}"))) {
					errorMsges.add("PLU value should be numeric with maximum 5 digits ");
			}

				if (perishableMappingRequest.getMappingType().equals(PerishableConstants.RESERVED)
						&& 
						!(perishableMappingRequest.getMappingstatus().equals(PerishableConstants.AWAITING_CIC)||	
								perishableMappingRequest.getMappingstatus().equals(PerishableConstants.OTHER)||
								perishableMappingRequest.getMappingstatus().equals(PerishableConstants.AWAITING_DIVISION)
						)
						) {
					errorMsges.add("Status given for RESERVED category is wrong");
				}
				
				
				if(perishableMappingRequest.isTargetEdited())
				{
					String singleCharRegExp ="[a-bA-Z0-9]{1}";
					String singleDigRegExp ="[0-9]{1}";
					String costValueRegExp ="[0-9]{1,9}+[.]?[0-9]{0,4}";
					String daysCountExp ="[0-9]{1,16}";
					
					
					if(perishableMappingRequest.getDcPackDesc() !=null &&perishableMappingRequest.getDcPackDesc().trim().length()>3)
						errorMsges.add("DC Pack desc maximum three characters allowed");
					if(perishableMappingRequest.getDcSizeDsc() !=null &&perishableMappingRequest.getDcSizeDsc().trim().length()>7)
						errorMsges.add("DC Size desc maximum seven characters allowed");
					if(perishableMappingRequest.getRetailUnitPack() !=null &&!perishableMappingRequest.getRetailUnitPack().trim().matches("[0-9]{1,7}+[.]?[0-9]{0,2}"))
						errorMsges.add("RUP is not a number in the prescribed format");
					if(perishableMappingRequest.getRing() !=null &&!perishableMappingRequest.getRing().trim().matches("[0-5]{1}"))
						errorMsges.add("Ring value should be from 0 to 5 ");
					if(perishableMappingRequest.getHicone() !=null &&!perishableMappingRequest.getHicone().trim().matches("[0-2]{1}"))
						errorMsges.add("Hicone value should be 0,1 or 2 ");
					
					if(perishableMappingRequest.getProdwght() !=null &&!perishableMappingRequest.getProdwght().trim().matches("[0-9]{1,7}+[.]?[0-9]{0,4}"))
						errorMsges.add("Prod Weight is not a number in the prescribed format ");
					if(perishableMappingRequest.getHandlingCode() !=null &&!perishableMappingRequest.getHandlingCode().trim().matches("[0-9]{1,3}"))
						errorMsges.add("Handling code should be a number with maximum 3 digits ");					
					if(perishableMappingRequest.getBuyerNum() !=null &&!perishableMappingRequest.getBuyerNum().trim().matches("[a-bA-Z0-9]{1,2}"))
						errorMsges.add("Buyer num should not exceed two characters ");
					if(perishableMappingRequest.getRandomWtCd() !=null  && !perishableMappingRequest.getRandomWtCd().trim().equals("")
						&&	!perishableMappingRequest.getRandomWtCd().trim().matches("[R]{0,1}"))
						errorMsges.add("Random weight code should be R or a empty  ");					
					if(perishableMappingRequest.getAutoCostInv() !=null &&!perishableMappingRequest.getAutoCostInv().trim().matches("[A,C,I]{1}"))
						errorMsges.add("Auto const inv should be A,C or I character ");					
					if(perishableMappingRequest.getBillingType() !=null && !perishableMappingRequest.getBillingType().trim().equals("")
						&&	!perishableMappingRequest.getBillingType().trim().matches("[A]{0,1}"))
						errorMsges.add("Billing type should be A or empty ");					
					if(perishableMappingRequest.getFdStmp() !=null &&!perishableMappingRequest.getFdStmp().trim().matches("[0-1]{1}"))
						errorMsges.add("Food stamp should be 0 or 1 ");
					if(perishableMappingRequest.getTareCd() !=null &&!perishableMappingRequest.getTareCd().trim().matches("[0-9]{1,38}"))
						errorMsges.add("Tare code should be a number ");
					if(perishableMappingRequest.getLabelSize() !=null &&!perishableMappingRequest.getLabelSize().trim().matches("[M,N,S]{1}"))
						errorMsges.add("Tag size type should be M,N or S character ");
					if(perishableMappingRequest.getLabelNumbers() !=null &&!perishableMappingRequest.getLabelNumbers().trim().matches(singleDigRegExp))
						errorMsges.add("Tag number type should be single digit ");					
					if(perishableMappingRequest.getSgnCount1() !=null &&!perishableMappingRequest.getSgnCount1().trim().matches(singleDigRegExp))
						errorMsges.add("Sign count1 type should be single digit ");
					if(perishableMappingRequest.getSgnCount2() !=null &&!perishableMappingRequest.getSgnCount2().trim().matches(singleDigRegExp))
						errorMsges.add("Sign count2 type should be single digit ");
					if(perishableMappingRequest.getSgnCount3() !=null &&!perishableMappingRequest.getSgnCount3().trim().matches(singleDigRegExp))
						errorMsges.add("Sign count3 type should be single digit ");
					if(perishableMappingRequest.getPrcTypeCd() !=null &&!perishableMappingRequest.getPrcTypeCd().trim().matches("[a-bA-Z0-9]{1,2}"))
						errorMsges.add("Tag number type should be maximum two characters ");					
					if(perishableMappingRequest.getCostAllow() !=null &&!perishableMappingRequest.getCostAllow().trim().matches(costValueRegExp))
						errorMsges.add("Cost allow should be decimal number ");
					if(perishableMappingRequest.getCostInv() !=null &&!perishableMappingRequest.getCostInv().trim().matches(costValueRegExp))
						errorMsges.add("Cost INV should be decimal number ");
					if(perishableMappingRequest.getCostIb() !=null &&!perishableMappingRequest.getCostIb().trim().matches(costValueRegExp))
						errorMsges.add("Cost IB should be decimal number ");
					if(perishableMappingRequest.getCostVend() !=null &&!perishableMappingRequest.getCostVend().trim().matches(costValueRegExp))
						errorMsges.add("Cost Vendor should be decimal number ");					
					if(perishableMappingRequest.getSellByDays() !=null &&!perishableMappingRequest.getSellByDays().trim().matches(daysCountExp))
						errorMsges.add("Sell by days should be decimal number ");
					if(perishableMappingRequest.getUseByDays() !=null &&!perishableMappingRequest.getUseByDays().trim().matches(daysCountExp))
						errorMsges.add("Use by days should be decimal number ");
					if(perishableMappingRequest.getPullBydays() !=null &&!perishableMappingRequest.getPullBydays().trim().matches(daysCountExp))
						errorMsges.add("Pull by days should be decimal number ");
					
						
						
			    }
		}
		}
		LOG.info("Execution completed for validate Actions");

		return errorMsges;

	}
	
	
	private boolean validateLetAutoMatch(List<PerishableMappingRequest> perishableMappingRequests) {
		LOG.debug("Execution started for validate Let Auto Match");

        boolean checkAutoMatch =true;
        String primeMAtchType =null;
		for(PerishableMappingRequest perishableMappingRequest : perishableMappingRequests  )
		{
			if(primeMAtchType==null)
			{
				primeMAtchType=perishableMappingRequest.getMappingType();
			}
		  if( primeMAtchType!=null &&primeMAtchType.equals(PerishableConstants.LET_AUTO_MATCH) &&
				  !perishableMappingRequest.getMappingType().equals(primeMAtchType))
		  {
			  checkAutoMatch= false;
		  }
			  
		}
		LOG.debug("Execution completed for validate Let Auto Match");

		return checkAutoMatch;
	}


	/**
	 * Method to validate Unmap request
	 * @param perishableMappingRequest
	 * @return
	 */
	public List<String> validateUnmapActions(List<PerishableMappingRequest> perishableMappingRequests) {
		LOG.info("Execution started for validate Unmap Actions");

		List<String> errorMsges = new ArrayList<String>();
		String primeMappingType = null;
		if (null != perishableMappingRequests && !perishableMappingRequests.isEmpty()) {
			for (PerishableMappingRequest perishableMappingRequest : perishableMappingRequests) {				
				if(perishableMappingRequest.getMappingType() != null){
					primeMappingType =perishableMappingRequest.getMappingType();
					if (primeMappingType.equals(PerishableConstants.MARK_AS_DEAD)
							|| primeMappingType.equals(PerishableConstants.FORCE_NEW)
							|| primeMappingType.equals(PerishableConstants.LET_AUTO_MATCH)) {
						errorMsges.add(PerishableConstants.VALIDATION_MESSAGE_ITEM_MAPPING_TYPE);
					}
				}
				
				if (null == perishableMappingRequest.getCic() && null == perishableMappingRequest.getSku()
						&& null == perishableMappingRequest.getUpc()) {
					errorMsges.add(PerishableConstants.VALIDATION_MESSAGE_UNMAP_ITEM_SELECTION);
				}
			}
		}
		LOG.info("Execution completed for validate Unmap Actions");

		return errorMsges;
	}
   }
