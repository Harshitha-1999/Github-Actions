/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.web.controllers;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.dtos.response.PerishableSearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.PerishableUPCwisedDetails;
import com.safeway.app.memi.domain.services.PerishableMappingServices;
import com.safeway.app.memi.domain.util.PerishableConstants;
/**
 ****************************************************************************
 * NAME			: PerishableMappingLoadController 
 * 
 * DESCRIPTION	: PerishableMappingLoadController is the controller class for performing 
 * 				  search and filter operations for mapping screen and mapped screen
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 02, 2018  - Initial Creation
 * *************************************************************************
 */

@Controller
@RequestMapping("/perishable")
public class PerishableMappingLoadController {
    private static final Logger LOG = LoggerFactory.getLogger(PerishableMappingLoadController.class);

    @Autowired
    private PerishableMappingServices perishableMappingServices;
    
    /**
     * Method to fetch source data 
     * @param searchRequestVO
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/sourceList", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody PerishableSearchRequestVO listSourceData(@RequestBody PerishableSearchRequestVO searchRequestVO) throws Exception {
    	LOG.info("Execution started for list Source Data");
    	List <String> errors =new ArrayList<>();
      	if(searchRequestVO.getCompanyID()!=null && searchRequestVO.getDivisionID()!=null)
    	{
    		if(searchRequestVO.getItemType().isAll() ||searchRequestVO.getItemType().isPlu() ||
    				searchRequestVO.getItemType().isSystem2()||searchRequestVO.getItemType().isSystem4())
    		{
    			searchRequestVO=perishableMappingServices.listSKUPerishableItems(searchRequestVO);

    		}
    		else
    		{
    			errors.add(PerishableConstants.VALIDATION_MESSAGE_ITEM);
    		}
    	}
    	else
    	{
    		errors.add(PerishableConstants.VALIDATION_MESSAGE_COMPANY);
    	}    	
    
     	if(!errors.isEmpty())
    	{
    		searchRequestVO.setErrorMessages(errors);
    	}
    	LOG.info("Execution completed for list Source Data");

		return searchRequestVO;
    }
   
    /**
     * Method to fetch target data 
     * @param searchRequestVO
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/targetList", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody PerishableSearchRequestVO listTargetData(@RequestBody PerishableSearchRequestVO searchRequestVO) throws Exception {
		LOG.info("Fetching CIC Perishable Items records.");
		List <String> errors =new ArrayList<>();
	 	
		if (searchRequestVO.getItemType().isAll() || searchRequestVO.getItemType().isPlu()
				|| searchRequestVO.getItemType().isSystem2() || searchRequestVO.getItemType().isSystem4()) {
			searchRequestVO = perishableMappingServices.listCICPerishableItems(searchRequestVO);

		}else
		{
			errors.add(PerishableConstants.VALIDATION_MESSAGE_ITEM);
		}
				
    	if(!errors.isEmpty())
    	{
    		searchRequestVO.setErrorMessages(errors);
    	}
		LOG.info("Completed Fetching all the CIC Perishable Items records.");
		return searchRequestVO;
    }
    
   /**
    * Method to fetch mapped data 
    * @param searchRequestVO
    * @return
    */
    @RequestMapping(value = "/mappedList",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody PerishableSearchRequestVO listMappedData(@RequestBody PerishableSearchRequestVO searchRequestVO) {
    	LOG.info("Execution started for  list Mapped Data");

    	List <String> errors =new ArrayList<>();
     	if(searchRequestVO.getCompanyID()!=null && searchRequestVO.getDivisionID()!=null){
     	List<PerishableMappedResultWrapper> mappedList=perishableMappingServices.listMappedData(searchRequestVO);
    	if(null!=mappedList && !mappedList.isEmpty()){
    		searchRequestVO.setMappedResultWrapper(mappedList);
    	 }
    	}else{
    		errors.add(PerishableConstants.VALIDATION_MESSAGE_COMPANY);
    	}
    	if(!errors.isEmpty()){
    		searchRequestVO.setErrorMessages(errors);
    	}
    	LOG.info("Execution completed for  list Mapped Data");

    	return searchRequestVO;
    }
    
	@RequestMapping(value = "/listDepartmentSource/{company}/{division}", method = RequestMethod.GET)
    public @ResponseBody List<Object[]> getDepartmentDetailsForSource(@PathVariable("company") String company,
			@PathVariable("division") String division){
    	return perishableMappingServices.getSouceDepartmentDetails(company,division);
    }
    
	@RequestMapping(value = "/listDepartmentTarget/{company}/{division}", method = RequestMethod.GET)
    public @ResponseBody List<Object[]> getDepartmentDetailsForTarget(@PathVariable("company") String company,
			@PathVariable("division") String division){
    	return perishableMappingServices.getTargetDepartmentDetails(company,division);
     
    }

    @RequestMapping(value = "/upcList",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public@ResponseBody List<PerishableUPCwisedDetails> getUpcListDetails(@RequestBody Object[] searchDetails) {
    	return perishableMappingServices.getUpcListDetails(searchDetails);    			
    }
    
    @RequestMapping(value = "/matchingTargetList",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public@ResponseBody PerishableSearchRequestVO getMatchingTargetList(@RequestBody PerishableMatchingTargetInputVO upcDetails) {
    	LOG.info("Execution started for  get Matching TargetList");

    	List<String> errors = new ArrayList<>();
    	List<PerishableCICSearchResults> perishableCICSearchResults= perishableMappingServices.getSuggestedTargetList(upcDetails); 

    	PerishableSearchRequestVO searchRequestVO =new PerishableSearchRequestVO();
    	if(null!= perishableCICSearchResults && !perishableCICSearchResults.isEmpty()){
    		searchRequestVO.setCicSearchResults(perishableCICSearchResults);
    	}else
    	{
    		errors.add("NO MATCH FOUNd..!");
    		searchRequestVO.setErrorMessages(errors);
    	}
    	LOG.info("Execution completed for  get Matching TargetList");

    	return searchRequestVO;
    	
    }
 
    @RequestMapping(value = "/additionalTargetRetailsScanList",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public@ResponseBody PerishableAdditionalDetailsDto getadditionalRetailscanDetails(@RequestBody String corpItemCd) {
    	return perishableMappingServices.getadditionalRetailscanDetails(corpItemCd);    			
    }
    
    @RequestMapping(value = "/mappedUpcListDetails",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public@ResponseBody List<PerishableUPCwisedDetails> getMappedUpcListDetails(@RequestBody Object[] searchDetails) {
    	return perishableMappingServices.getMappedUpcListDetails(searchDetails);    			
    }
    
    @RequestMapping(value = "/loadOnMapEditFields", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ManualMapAdditionalLoadDto loadOnMapEditFields(@RequestBody ManualMatchAdtnlFieldLoadInputVo inputVo){
    	return perishableMappingServices.fetchTargetEditITems(inputVo);
    }
    
}
