/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

/**
 **************************************************************************** 
 * NAME : PerishableMappingServicesImpl
 * 
 * DESCRIPTION : PerishableItemCreateMatchCicDto is class to receive the input parameters to identify 
 * whether the force new is augmentation/override
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 May 07, 2018 - Initial Creation
 * *************************************************************************
 */
public class PerishableItemCreateMatchCicDto extends DisplayItemCreateMatchCicDto {	
	
	
	/**
	 * Element to indicate whether category of force new is 
	 * either augmentation or override
	 */
	private String forceNewCategory;
	
	
	/**
	 * @return the forceNewCategory
	 */
	public String getForceNewCategory() {
		return forceNewCategory;
	}

	/**
	 * @param forceNewCategory the forceNewCategory to set
	 */
	public void setForceNewCategory(String forceNewCategory) {
		this.forceNewCategory = forceNewCategory;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PerishableItemCreateMatchCicDto [forceNewCategory=" + forceNewCategory + "]";
	}
	
	
	
	
	
	
}