/* Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

/* ***************************************************************************
 * NAME : ReportServiceImpl 
 * 
 * SYSTEM : MEMD 
 * 
 * AUTHOR : SafewayIT 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 March 09, 2016 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.Division;
import com.safeway.app.memi.data.repositories.DivisionRepository;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.DivisionDto;
import com.safeway.app.memi.domain.services.DivisionService;

/**
 * 
 * Implementation class for Division Services
 *
 */
@Service("divisionService")
public class DivisionServiceImpl implements DivisionService {

    private static final Logger LOG = LoggerFactory.getLogger(DivisionServiceImpl.class);

    
    @Autowired
    private DivisionRepository divisionRepo;

    private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.DivisionService#getAllItems()
	 */
	@Override
	public List<DivisionDto> getAllItems() {
		LOG.info("Fetching all divisionLists");
		List<Division> divisionList = divisionRepo.findAll();
		LOG.info("Completed fetching all"+divisionList.size()+"divisionList");
		return viewAdapter.mapToDivisionDtoList(divisionList);
	}

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.DivisionService#findByCompanyId(java.lang.String)
	 */
	@Override
	public List<DivisionDto> findByCompanyId(String companyID) {
		LOG.info("Fetching all company records");
		List<Division> divisionList = divisionRepo.findByCompanyid(companyID);
		LOG.info("Completed fetching all"+divisionList.size()+"Company records");
		return viewAdapter.mapToDivisionDtoList(divisionList);
		
	}

}
