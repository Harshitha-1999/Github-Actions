package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

public class DCDetailsVo {
	private String dc;
	private Character dcStatus;
	private BigDecimal cost;
	private Set<String> rogs;

	public String getDc() {
		return dc;
	}

	public void setDc(String dc) {
		this.dc = dc;
	}

	public BigDecimal getCost() {
		return cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	public Set<String> getRogs() {
		return rogs;
	}

	public void setRogs(Set<String> rog) {
		this.rogs = rog;
	}

	public void addRog(String rog) {
		if (rogs == null)
			rogs = new HashSet<String>();
		rogs.add(rog);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj == this)
			return true;
		if (this.getClass() != obj.getClass())
		    return false;
		if (!DCDetailsVo.class.isAssignableFrom(obj.getClass())) {
			return false;
		}
		final DCDetailsVo other = (DCDetailsVo) obj;
		if ((this.dc == null) ? (other.dc != null) : !this.dc.equals(other.dc)) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		int hash = 3;
		hash = 53 * hash + (this.dc != null ? this.dc.hashCode() : 0);
		return hash;
	}

	public Character getDcStatus() {
		return dcStatus;
	}

	public void setDcStatus(Character dcStatus) {
		this.dcStatus = dcStatus;
	}

}
