package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

public class PerishableMatchingTargetInputVO {
	private String whseDsd;
	private Object[] upcs;
	private String dept; 
	public String getWhseDsd() {
		return whseDsd;
	}
	public void setWhseDsd(String whseDsd) {
		this.whseDsd = whseDsd;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Object[] getUpcs() {
		return upcs;
	}
	public void setUpcs(Object[] upcs) {
		this.upcs = upcs;
	}

}
