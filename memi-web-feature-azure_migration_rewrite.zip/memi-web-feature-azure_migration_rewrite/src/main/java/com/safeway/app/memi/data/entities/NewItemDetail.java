package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : NewItemDetail 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Varada Nellayikunnath  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 9, 2017 vnell00 - Initial Creation
 * ************************************************************************/

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entity class for Database table ITEM_CONV_NEW_CIC_DATA_MGMT.
 * 
 */
@Entity
@Table(name = "ITEM_CONV_NEW_CIC_DATA_MGMT", schema="ECFLAND")
public class NewItemDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private NewItemDetailPk newItemPk;

	@Column(name = "PLU_CD")
	private String pluCd;

	@Column(name = "PRIMARY_UPC_IND")
	private Character prmyUpcInd;

	@Column(name = "VEND_CONV_FCTR")
	private BigDecimal vendConvFactor;

	@Column(name = "PACK_WHSE")
	private BigDecimal packwhse;

	@Column(name = "COST")
	private Float cost;

	@Column(name = "SRC_ITEM_DESC")
	private String srcItmDesc;

	@Column(name = "SRC_WHSE_ITEM_DESC")
	private String srcWhseItmDesc;

	@Column(name = "SRC_RTL_ITEM_DESC")
	private String srcRtlItmDesc;

	@Column(name = "SRC_INTERNET_ITEM_DESC")
	private String srcIntenetItemDesc;

	@Column(name = "SRC_POS_DESC")
	private String srcPosDesc;

	@Column(name = "SRC_ITEM_USAGE_IND")
	private Character itemUsgeInd;

	@Column(name = "SRC_ITEM_USAGE_TYPE_IND")
	private Character itemUsageTypInd;

	@Column(name = "SRC_PRIVATE_LABEL_IND")
	private Character ptLabelInd;

	@Column(name = "SRC_DISP_FLAG")
	private Character dispFlag;

	@Column(name = "SRC_SIZE")
	private String size;

	@Column(name = "SRC_SIZE_UOM")
	private String srcSizeUom;

	@Column(name = "SRC_SIZE_NUM")
	private BigDecimal srcSizeNmbr;

	@Column(name = "UPD_ITEM_DESC")
	private String updItmDesc;

	@Column(name = "UPD_WHSE_ITEM_DESC")
	private String updWhseItmDesc;

	@Column(name = "UPD_RTL_ITEM_DESC")
	private String updRtlItmDesc;

	@Column(name = "UPD_INTERNET_ITEM_DESC")
	private String updIntenetItemDesc;

	@Column(name = "UPD_POS_DESC")
	private String updPosDesc;

	@Column(name = "UPD_ITEM_USAGE_IND")
	private Character updUsgeInd;

	@Column(name = "UPD_ITEM_USAGE_TYPE_IND")
	private Character updUsageTypInd;

	@Column(name = "UPD_PRIVATE_LABEL_IND")
	private Character updPtLabelInd;

	@Column(name = "UPD_DISP_FLAG")
	private Character updDispFlag;

	@Column(name = "UPD_SIZE")
	private String updSize;

	@Column(name = "UPD_SIZE_UOM")
	private String updSizeUom;

	@Column(name = "UPD_SIZE_NUM")
	private BigDecimal updSizeNmbr;

	@Column(name = "PROD_HIERARCHY_LVL_1_CD")
	private String prdHierLevel1;

	@Column(name = "PROD_HIERARCHY_LVL_2_CD")
	private String prdHierLevel2;

	@Column(name = "PROD_HIERARCHY_LVL_3_CD")
	private String prdHierLevel3;

	@Column(name = "PROD_HIERARCHY_LVL_4_CD")
	private String prdHierLevel4;

	@Column(name = "PROD_HIERARCHY_LVL_5_CD")
	private String prdHierLevel5;

	@Column(name = "GROUP_CD")
	private Integer grpCd;

	@Column(name = "CATEGORY_CD")
	private Integer ctgryCd;

	@Column(name = "CLASS_CD")
	private Integer clsCd;

	@Column(name = "SUB_CLASS_CD")
	private Integer sbClsCd;

	@Column(name = "SUB_SUB_CLASS_CD")
	private Integer subSbClass;

	@Column(name = "DATA_SOURCE_IND")
	private String dtaSrcInd;

	@Column(name = "DATA_SOURCE_DESC")
	private String dtaSrcDesc;

	@Column(name = "AUG_OVERRIDE_COMPLETION_IND")
	private Character augOverCmplnInd;

	@Column(name = "DATA_OVERRIDE_CIC")
	private BigDecimal dtaOverCic;

	@Column(name = "COV_TEAM_COMMENTS_TXT")
	private String covTeamComment;

	@Column(name = "EXCEPTION_TYPE_CD")
	private Character excptnTypeCd;

	@Column(name = "EXCEPTION_DESC")
	private String excptionDesc;

	@Column(name = "CREATE_UPDATE_USER_ID")
	private String createUser;
	
	@Column(name = "CREATE_UPDATE_TS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date  createUpdateTimestamp;

	@Column(name = "BATCH_ID")
	private Integer batchId;

	@Column(name = "LOGICAL_DEL_IND")
	private Character logicalInd;
	
	@Column(name = "CSC_DSC")
	private String cscDsc;  
	
	@Column(name = "PRODUCTION_GROUP_CD")
	private Integer productionGrpCd;
	
	@Column(name = "PRODUCTION_CATEGORY_CD")
	private Integer productionCtgryCd;
	
	@Column(name = "PRODUCTION_CLASS_CD")
	private Integer productionClsCd;
	
	@Column(name = "ETHNIC_TYPE_CD")
	private String ethnicTypeCd;
	
	@Column(name = "PACKAGE_TYPE_ID")
	private BigDecimal pckTypeId;
	
	@Column(name = "PRODUCT_CLASS_CD")
	private Integer productClsCd;
	
	@Column(name = "INNER_PACK")
	private Integer innerPack;
	
	@Column(name = "RETAIL_UNIT_PACK")
	private Integer retailUnitPack;

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "PROD_HIERARCHY_LVL_1_CD", referencedColumnName = "PROD_HIERARCHY_LVL_1_CD", insertable = false, updatable = false),
			@JoinColumn(name = "PROD_HIERARCHY_LVL_2_CD", referencedColumnName = "PROD_HIERARCHY_LVL_2_CD", insertable = false, updatable = false),
			@JoinColumn(name = "PROD_HIERARCHY_LVL_3_CD", referencedColumnName = "PROD_HIERARCHY_LVL_3_CD", insertable = false, updatable = false),
			@JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID", insertable = false, updatable = false),
			@JoinColumn(name = "DIVISION_ID", referencedColumnName = "DIVISION_ID", insertable = false, updatable = false) })
	
	private DepartmentDetail deptDtl;

	/**Produce plu**/
	
	@Column(name="UPD_UPC")
	private String updUpc;
	
	
	@Column(name="UPD_PLU_CD",nullable =true)
	private String updPluCd;
	
	
	@Column(name ="DC_PACK_DESC")
	private String packDesc;
	
	@Column(name ="DC_SIZE_DESC")
	private String sizeDesc;
		
	@Column(name ="RING",nullable =true)
	private String ring;
	
	@Column(name ="HICONE",nullable =true)
	private String hicone;
	


	
	@Column(name="PROD_WGHT")
	private String prodwght;
	
	@Column(name="HANDLING_CODE")
	private String handlingCode;
	
	@Column(name="DC_BUYER_NUM")
	private String buyerNum;
	
	@Column(name="RANDOM_WT_CD")
	private String randomWtCd;	
	
	@Column(name="AUTO_COST_INV")
	private String autoCostInv; 
	
	@Column(name="BILLING_TYPE")
	private String billingType;
	
	@Column(name="FD_STMP")
	private String fdStmp;
			
	@Column(name="label_size")
	private String labelSize;
	
	@Column(name="label_numbers")
	private String labelNumbers;
	
	@Column(name="SGN_COUNT1")
	private String sgnCount1;
	
	@Column(name="SGN_COUNT2")
	private String sgnCount2;
	
	@Column(name="SGN_COUNT3")
	private String sgnCount3;
	
	@Column(name="SELL_BY_DAYS")
	private String sellByDays;
	
	@Column(name="EAT_BY_DAYS")
	private String eatByDays;
	
	@Column(name="PULL_BY_DAYS")
	private String pullByDays;
	
	@Column(name="UPD_PACK")
	private String updPack;
	

	@Column(name="TARE")
	private String tareCd;
		
	

	public NewItemDetailPk getNewItemPk() {
		return newItemPk;
	}

	public void setNewItemPk(NewItemDetailPk newItemPk) {
		this.newItemPk = newItemPk;
	}
	
	public DepartmentDetail getDeptDtl() {
		return deptDtl;
	}

	public void setDeptDtl(DepartmentDetail deptDtl) {
		this.deptDtl = deptDtl;
	}

	
	public String getPluCd() {
		return pluCd;
	}

	public void setPluCd(String pluCd) {
		this.pluCd = pluCd;
	}

	public Character getPrmyUpcInd() {
		return prmyUpcInd;
	}

	public void setPrmyUpcInd(Character prmyUpcInd) {
		this.prmyUpcInd = prmyUpcInd;
	}

	public BigDecimal getVendConvFactor() {
		return vendConvFactor;
	}

	public void setVendConvFactor(BigDecimal vendConvFactor) {
		this.vendConvFactor = vendConvFactor;
	}

	public BigDecimal getPackwhse() {
		return packwhse;
	}

	public void setPackwhse(BigDecimal packwhse) {
		this.packwhse = packwhse;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}

	public String getSrcItmDesc() {
		return srcItmDesc;
	}

	public void setSrcItmDesc(String srcItmDesc) {
		this.srcItmDesc = srcItmDesc;
	}

	public String getSrcWhseItmDesc() {
		return srcWhseItmDesc;
	}

	public void setSrcWhseItmDesc(String srcWhseItmDesc) {
		this.srcWhseItmDesc = srcWhseItmDesc;
	}

	public String getSrcRtlItmDesc() {
		return srcRtlItmDesc;
	}

	public void setSrcRtlItmDesc(String srcRtlItmDesc) {
		this.srcRtlItmDesc = srcRtlItmDesc;
	}

	public String getSrcIntenetItemDesc() {
		return srcIntenetItemDesc;
	}

	public void setSrcIntenetItemDesc(String srcIntenetItemDesc) {
		this.srcIntenetItemDesc = srcIntenetItemDesc;
	}

	public String getSrcPosDesc() {
		return srcPosDesc;
	}

	public void setSrcPosDesc(String srcPosDesc) {
		this.srcPosDesc = srcPosDesc;
	}

	public Character getItemUsgeInd() {
		return itemUsgeInd;
	}

	public void setItemUsgeInd(Character itemUsgeInd) {
		this.itemUsgeInd = itemUsgeInd;
	}

	public Character getItemUsageTypInd() {
		return itemUsageTypInd;
	}

	public void setItemUsageTypInd(Character itemUsageTypInd) {
		this.itemUsageTypInd = itemUsageTypInd;
	}

	public Character getPtLabelInd() {
		return ptLabelInd;
	}

	public void setPtLabelInd(Character ptLabelInd) {
		this.ptLabelInd = ptLabelInd;
	}

	public Character getDispFlag() {
		return dispFlag;
	}

	public void setDispFlag(Character dispFlag) {
		this.dispFlag = dispFlag;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSrcSizeUom() {
		return srcSizeUom;
	}

	public void setSrcSizeUom(String srcSizeUom) {
		this.srcSizeUom = srcSizeUom;
	}

	public BigDecimal getSrcSizeNmbr() {
		return srcSizeNmbr;
	}

	public void setSrcSizeNmbr(BigDecimal srcSizeNmbr) {
		this.srcSizeNmbr = srcSizeNmbr;
	}

	public String getUpdItmDesc() {
		return updItmDesc;
	}

	public void setUpdItmDesc(String updItmDesc) {
		this.updItmDesc = updItmDesc;
	}

	public String getUpdWhseItmDesc() {
		return updWhseItmDesc;
	}

	public void setUpdWhseItmDesc(String updWhseItmDesc) {
		this.updWhseItmDesc = updWhseItmDesc;
	}

	public String getUpdRtlItmDesc() {
		return updRtlItmDesc;
	}

	public void setUpdRtlItmDesc(String updRtlItmDesc) {
		this.updRtlItmDesc = updRtlItmDesc;
	}

	public String getUpdIntenetItemDesc() {
		return updIntenetItemDesc;
	}

	public void setUpdIntenetItemDesc(String updIntenetItemDesc) {
		this.updIntenetItemDesc = updIntenetItemDesc;
	}

	public String getUpdPosDesc() {
		return updPosDesc;
	}

	public void setUpdPosDesc(String updPosDesc) {
		this.updPosDesc = updPosDesc;
	}

	public Character getUpdUsgeInd() {
		return updUsgeInd;
	}

	public void setUpdUsgeInd(Character updUsgeInd) {
		this.updUsgeInd = updUsgeInd;
	}

	public Character getUpdUsageTypInd() {
		return updUsageTypInd;
	}

	public void setUpdUsageTypInd(Character updUsageTypInd) {
		this.updUsageTypInd = updUsageTypInd;
	}

	public Character getUpdPtLabelInd() {
		return updPtLabelInd;
	}

	public void setUpdPtLabelInd(Character updPtLabelInd) {
		this.updPtLabelInd = updPtLabelInd;
	}

	public Character getUpdDispFlag() {
		return updDispFlag;
	}

	public void setUpdDispFlag(Character updDispFlag) {
		this.updDispFlag = updDispFlag;
	}

	public String getUpdSize() {
		return updSize;
	}

	public void setUpdSize(String updSize) {
		this.updSize = updSize;
	}

	public String getUpdSizeUom() {
		return updSizeUom;
	}

	public void setUpdSizeUom(String updSizeUom) {
		this.updSizeUom = updSizeUom;
	}

	public BigDecimal getUpdSizeNmbr() {
		return updSizeNmbr;
	}

	public void setUpdSizeNmbr(BigDecimal updSizeNmbr) {
		this.updSizeNmbr = updSizeNmbr;
	}

	public String getPrdHierLevel1() {
		return prdHierLevel1;
	}

	public void setPrdHierLevel1(String prdHierLevel1) {
		this.prdHierLevel1 = prdHierLevel1;
	}

	public String getPrdHierLevel2() {
		return prdHierLevel2;
	}

	public void setPrdHierLevel2(String prdHierLevel2) {
		this.prdHierLevel2 = prdHierLevel2;
	}

	public String getPrdHierLevel3() {
		return prdHierLevel3;
	}

	public void setPrdHierLevel3(String prdHierLevel3) {
		this.prdHierLevel3 = prdHierLevel3;
	}

	public String getPrdHierLevel4() {
		return prdHierLevel4;
	}

	public void setPrdHierLevel4(String prdHierLevel4) {
		this.prdHierLevel4 = prdHierLevel4;
	}

	public String getPrdHierLevel5() {
		return prdHierLevel5;
	}

	public void setPrdHierLevel5(String prdHierLevel5) {
		this.prdHierLevel5 = prdHierLevel5;
	}

	public Integer getClsCd() {
		return clsCd;
	}

	public void setClsCd(Integer clsCd) {
		this.clsCd = clsCd;
	}

	public Integer getGrpCd() {
		return grpCd;
	}

	public void setGrpCd(Integer grpCd) {
		this.grpCd = grpCd;
	}

	public Integer getCtgryCd() {
		return ctgryCd;
	}

	public void setCtgryCd(Integer ctgryCd) {
		this.ctgryCd = ctgryCd;
	}

	public Integer getSbClsCd() {
		return sbClsCd;
	}

	public void setSbClsCd(Integer sbClsCd) {
		this.sbClsCd = sbClsCd;
	}

	public Integer getSubSbClass() {
		return subSbClass;
	}

	public void setSubSbClass(Integer subSbClass) {
		this.subSbClass = subSbClass;
	}

	public String getDtaSrcInd() {
		return dtaSrcInd;
	}

	public void setDtaSrcInd(String dtaSrcInd) {
		this.dtaSrcInd = dtaSrcInd;
	}

	public String getDtaSrcDesc() {
		return dtaSrcDesc;
	}

	public void setDtaSrcDesc(String dtaSrcDesc) {
		this.dtaSrcDesc = dtaSrcDesc;
	}

	public Character getAugOverCmplnInd() {
		return augOverCmplnInd;
	}

	public void setAugOverCmplnInd(Character augOverCmplnInd) {
		this.augOverCmplnInd = augOverCmplnInd;
	}

	public BigDecimal getDtaOverCic() {
		return dtaOverCic;
	}

	public void setDtaOverCic(BigDecimal dtaOverCic) {
		this.dtaOverCic = dtaOverCic;
	}

	public String getCovTeamComment() {
		return covTeamComment;
	}

	public void setCovTeamComment(String covTeamComment) {
		this.covTeamComment = covTeamComment;
	}

	public Character getExcptnTypeCd() {
		return excptnTypeCd;
	}

	public void setExcptnTypeCd(Character excptnTypeCd) {
		this.excptnTypeCd = excptnTypeCd;
	}

	public String getExcptionDesc() {
		return excptionDesc;
	}

	public void setExcptionDesc(String excptionDesc) {
		this.excptionDesc = excptionDesc;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	
	public Date getCreateUpdateTimestamp() {
		return createUpdateTimestamp;
	}

	public void setCreateUpdateTimestamp(Date createUpdateTimestamp) {
		this.createUpdateTimestamp = createUpdateTimestamp;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public Character getLogicalInd() {
		return logicalInd;
	}

	public void setLogicalInd(Character logicalInd) {
		this.logicalInd = logicalInd;
	}

	public String getCscDsc() {
		return cscDsc;
	}

	public void setCscDsc(String cscDsc) {
		this.cscDsc = cscDsc;
	}

	public Integer getProductionGrpCd() {
		return productionGrpCd;
	}

	public void setProductionGrpCd(Integer productionGrpCd) {
		this.productionGrpCd = productionGrpCd;
	}

	public Integer getProductionCtgryCd() {
		return productionCtgryCd;
	}

	public void setProductionCtgryCd(Integer productionCtgryCd) {
		this.productionCtgryCd = productionCtgryCd;
	}

	public Integer getProductionClsCd() {
		return productionClsCd;
	}

	public void setProductionClsCd(Integer productionClsCd) {
		this.productionClsCd = productionClsCd;
	}

	public String getEthnicTypeCd() {
		return ethnicTypeCd;
	}

	public void setEthnicTypeCd(String ethnicTypeCd) {
		this.ethnicTypeCd = ethnicTypeCd;
	}

	public BigDecimal getPckTypeId() {
		return pckTypeId;
	}

	public void setPckTypeId(BigDecimal pckTypeId) {
		this.pckTypeId = pckTypeId;
	}

	public Integer getProductClsCd() {
		return productClsCd;
	}

	public void setProductClsCd(Integer productClsCd) {
		this.productClsCd = productClsCd;
	}

	public Integer getInnerPack() {
		return innerPack;
	}

	public void setInnerPack(Integer innerPack) {
		this.innerPack = innerPack;
	}

	public Integer getRetailUnitPack() {
		return retailUnitPack;
	}

	public void setRetailUnitPack(Integer retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}
/*Produce PLU */
	
	public String getUpdUpc() {
		return updUpc;
	}

	public void setUpdUpc(String updUpc) {
		this.updUpc = updUpc;
	}

	public String getUpdPluCd() {
		return updPluCd;
	}

	public void setUpdPluCd(String updPluCd) {
		this.updPluCd = updPluCd;
	}
	
	
	public String getPackDesc() {
		return packDesc;
	}

	public void setPackDesc(String packDesc) {
		this.packDesc = packDesc;
	}

	public String getSizeDesc() {
		return sizeDesc;
	}

	public void setSizeDesc(String sizeDesc) {
		this.sizeDesc = sizeDesc;
	}

	public String getRing() {
		return ring;
	}

	public void setRing(String ring) {
		this.ring = ring;
	}

	public String getHicone() {
		return hicone;
	}

	public void setHicone(String hicone) {
		this.hicone = hicone;
	}
	public String getProdwght() {
		return prodwght;
	}

	public void setProdwght(String prodwght) {
		this.prodwght = prodwght;
	}

	public String getHandlingCode() {
		return handlingCode;
	}

	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}

	public String getBuyerNum() {
		return buyerNum;
	}

	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}

	public String getRandomWtCd() {
		return randomWtCd;
	}

	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}

	public String getAutoCostInv() {
		return autoCostInv;
	}

	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getFdStmp() {
		return fdStmp;
	}

	public void setFdStmp(String fdStmp) {
		this.fdStmp = fdStmp;
	}

	public String getLabelSize() {
		return labelSize;
	}

	public void setLabelSize(String labelSize) {
		this.labelSize = labelSize;
	}

	public String getLabelNumbers() {
		return labelNumbers;
	}

	public void setLabelNumbers(String labelNumbers) {
		this.labelNumbers = labelNumbers;
	}

	
	public String getSgnCount1() {
		return sgnCount1;
	}

	public void setSgnCount1(String sgnCount1) {
		this.sgnCount1 = sgnCount1;
	}

	public String getSgnCount2() {
		return sgnCount2;
	}

	public void setSgnCount2(String sgnCount2) {
		this.sgnCount2 = sgnCount2;
	}

	public String getSgnCount3() {
		return sgnCount3;
	}

	public void setSgnCount3(String sgnCount3) {
		this.sgnCount3 = sgnCount3;
	}

	public String getSellByDays() {
		return sellByDays;
	}

	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}

	public String getEatByDays() {
		return eatByDays;
	}

	public void setEatByDays(String eatByDays) {
		this.eatByDays = eatByDays;
	}

	public String getPullByDays() {
		return pullByDays;
	}

	public void setPullByDays(String pullByDays) {
		this.pullByDays = pullByDays;
	}

	public String getUpdPack() {
		return updPack;
	}

	public void setUpdPack(String updPack) {
		this.updPack = updPack;
	}

	public String getTareCd() {
		return tareCd;
	}

	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}

	
	
}
