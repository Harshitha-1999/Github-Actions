package com.safeway.app.memi.domain.adapters;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.safeway.app.memi.domain.dtos.response.MultiUnitItem;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitTypeTargetDto;

/**
 ****************************************************************************
 * NAME : MultiUnitAdapter
 * 
 * DESCRIPTION : MultiUnitAdapter is the class for mapping values fetched from
 * DB to corresponding VO object
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : u51095
 * *************************************************************************
 */

public class MultiUnitAdapter {

	public List<MultiUnitSourceDto> buildNonMultiUnitSourceItem(
			List<Object[]> multiUnitSrcList) {
		Map<String, List<MultiUnitItem>> sourceDataMap = new HashMap<>();
		Set<MultiUnitSourceDto> multiUnitSourceList = new HashSet<>();
		MultiUnitItem srcDetail = null;
		List<MultiUnitItem> srcMatchList;
		for (Object[] obj : multiUnitSrcList) {
			String key = getStringValue((obj[17] != null && !obj[17].toString().equals("") ) ? obj[17] : obj[2]);
			if (sourceDataMap.containsKey(key)) {
				srcMatchList = sourceDataMap.get(key);
				srcDetail = new MultiUnitItem();
				srcDetail.setCompanyId(getStringValue(obj[0]));
				srcDetail.setDivisionId(getStringValue(obj[1]));
				srcDetail.setProductSku(getStringValue(obj[2]));
				srcDetail.setSrcItemDesc(getStringValue(obj[3]));
				srcDetail.setSrcPackWhse(getBigDecimalValue(obj[4]));
				srcDetail.setSrcVendConvFctr(getBigDecimalValue(obj[5]));
				srcDetail.setSrcSize(getStringValue(obj[6]));
				srcDetail.setSrcUpc(getStringValue(obj[7]));
				srcDetail.setSrcDeptName(getStringValue(obj[8]));
				srcDetail.setSrcProductHierarchy(getStringValue(obj[9]));
				if (getStringValue(obj[10]).equals("Y")) {
					srcDetail.setProdSourceCd("DSD");
					srcDetail.setSrcCost(getBigDecimalValue(obj[12]));
				}
				if (getStringValue(obj[11]).equals("Y")) {
					srcDetail.setProdSourceCd("WHSE");
					srcDetail.setSrcCost(getBigDecimalValue(obj[13]));
				}
				srcDetail.setConvStatusCode(getStringValue(obj[14]));
				srcDetail.setMaxRetail(getBigDecimalValue(obj[15]));
				srcDetail.setSrcVendName(getStringValue(obj[16]));
				srcDetail.setConvProductSku(getStringValue(obj[17]));
				srcDetail.setSrcCaseUpc(getStringValue(obj[18]));
				srcDetail.setSrcVendNum(getBigDecimalValue(new BigDecimal(getStringValue(obj[19]))));
				srcMatchList.add(srcDetail);
				sourceDataMap.put(srcDetail.getConvProductSku(), srcMatchList);

			} else {
				srcMatchList = new ArrayList<>();
				srcDetail = new MultiUnitItem();
				srcDetail.setCompanyId(getStringValue(obj[0]));
				srcDetail.setDivisionId(getStringValue(obj[1]));
				srcDetail.setProductSku(getStringValue(obj[2]));
				srcDetail.setSrcItemDesc(getStringValue(obj[3]));
				srcDetail.setSrcPackWhse(getBigDecimalValue(obj[4]));
				srcDetail.setSrcVendConvFctr(getBigDecimalValue(obj[5]));
				srcDetail.setSrcSize(getStringValue(obj[6]));
				srcDetail.setSrcUpc(getStringValue(obj[7]));
				srcDetail.setSrcDeptName(getStringValue(obj[8]));
				srcDetail.setSrcProductHierarchy(getStringValue(obj[9]));
				if (getStringValue(obj[10]).equals("Y")) {
					srcDetail.setProdSourceCd("DSD");
					srcDetail.setSrcCost(getBigDecimalValue(obj[12]));
					srcDetail.setConvProductSku(getStringValue(obj[17]));
				}
				if (getStringValue(obj[11]).equals("Y")) {
					srcDetail.setProdSourceCd("WHSE");
					srcDetail.setSrcCost(getBigDecimalValue(obj[13]));
					srcDetail.setConvProductSku(getStringValue(obj[2]));
				}
				srcDetail.setConvStatusCode(getStringValue(obj[14]));
				srcDetail.setMaxRetail(getBigDecimalValue(obj[15]));
				srcDetail.setSrcVendName(getStringValue(obj[16]));
				
				srcDetail.setSrcCaseUpc(getStringValue(obj[18]));
				srcDetail.setSrcVendNum(getBigDecimalValue(new BigDecimal(getStringValue(obj[19]))));
				srcMatchList.add(srcDetail);
				sourceDataMap.put(srcDetail.getConvProductSku(), srcMatchList);

			}

		}
		List<String> sortedKeys = new ArrayList<>(sourceDataMap.keySet());
		Collections.sort(sortedKeys);
		Set<String> deptList = new HashSet<>();
		for (String convProductSku : sortedKeys) {
			List<MultiUnitItem> srcItemMatchList = sourceDataMap.get(convProductSku);
			BigDecimal max_retail =new BigDecimal("0");
			Set<String> upcList = new HashSet<>();
			Set<String> productSkuSet=new HashSet<>();
			for (MultiUnitItem multiUnitItem : srcItemMatchList) {
				upcList.add(multiUnitItem.getSrcUpc());
				deptList.add(multiUnitItem.getSrcDeptName());
				productSkuSet.add(multiUnitItem.getProductSku());
				if(multiUnitItem.getMaxRetail().compareTo(max_retail) >= 0)
				{
					max_retail=multiUnitItem.getMaxRetail();
				}
			}
			MultiUnitSourceDto multiUnitSrc = new MultiUnitSourceDto();
			MultiUnitItem item = srcItemMatchList.get(0);
			multiUnitSrc.setCompanyId(item.getCompanyId());
			multiUnitSrc.setDivisionId(item.getDivisionId());
			multiUnitSrc.setProductSku(item.getProductSku());
			if(item.getProdSourceCd().equals("DSD")){
				multiUnitSrc.setConvProductSku(item.getConvProductSku());
			}else{
				multiUnitSrc.setConvProductSku(item.getProductSku());
			}
			multiUnitSrc.setSrcItemDesc(item.getSrcItemDesc());
			multiUnitSrc.setSrcPackWhse(item.getSrcPackWhse());
			multiUnitSrc.setSrcVendConvFctr(item.getSrcVendConvFctr());
			multiUnitSrc.setSrcSize(item.getSrcSize());
			multiUnitSrc.setUpcs(upcList);
			multiUnitSrc.setDeptName(item.getSrcDeptName());
			multiUnitSrc.setProductHierarchy(item.getSrcProductHierarchy());
			multiUnitSrc.setProdSourceCd(item.getProdSourceCd());
			multiUnitSrc.setSrcCost(item.getSrcCost());
			multiUnitSrc.setConvStatusCode(item.getConvStatusCode());
			multiUnitSrc.setMaxRetail(max_retail);
			multiUnitSrc.setSrcVendName(item.getSrcVendName());
			multiUnitSrc.setDeptNames(deptList);
			multiUnitSrc.setProductSkuSet(productSkuSet);
			multiUnitSrc.setCaseUpc(item.getSrcCaseUpc());
			multiUnitSrc.setSrcVendNum(item.getSrcVendNum());
			multiUnitSourceList.add(multiUnitSrc);
		}
		return new ArrayList<>(multiUnitSourceList);
	}
	
	public List<MultiUnitSourceDto> buildMultiUnitSourceItem(
			List<Object[]> multiUnitSrcList) {
		Map<String,List<MultiUnitItem>> sourceDataMap=new HashMap<>();
		Set<MultiUnitSourceDto> multiUnitSourceList = new HashSet<>();
		MultiUnitItem srcDetail = null;
		List<MultiUnitItem> srcMatchList;
		for (Object[] obj : multiUnitSrcList) {
			String key = getStringValue(obj[17]);
			if(sourceDataMap.containsKey(key)){
				srcMatchList =sourceDataMap.get(key);
				srcDetail = new MultiUnitItem();
				srcDetail.setCompanyId(getStringValue(obj[0]));
				srcDetail.setDivisionId(getStringValue(obj[1]));
				srcDetail.setProductSku(getStringValue(obj[2]));
				srcDetail.setSrcItemDesc(getStringValue(obj[3]));
				srcDetail.setSrcPackWhse(getBigDecimalValue(obj[4]));
				srcDetail.setSrcVendConvFctr(getBigDecimalValue(obj[5]));
				srcDetail.setSrcSize(getStringValue(obj[6]));
				srcDetail.setProdSourceCd(getStringValue(obj[7]));
				srcDetail.setSrcCost(getBigDecimalValue(obj[8]));
				srcDetail.setSrcDeptName(getStringValue(obj[9]));
				srcDetail.setSrcProductHierarchy((new StringBuilder().append(getStringValue(obj[10])).append("-")
						.append(getStringValue(obj[11])).append("-").append(getStringValue(obj[12]))).toString());
				srcDetail.setSrcUpc(getStringValue(obj[13]));
				srcDetail.setConvStatusCode(getStringValue(obj[14]));
				srcDetail.setMaxRetail(getBigDecimalValue(obj[15]));
				srcDetail.setSrcVendName(getStringValue(obj[16]));
				srcDetail.setConvProductSku(getStringValue(obj[17]));
				srcMatchList.add(srcDetail);
				sourceDataMap.put(srcDetail.getConvProductSku(), srcMatchList);
				
			}else{
				srcMatchList= new ArrayList<>();
				srcDetail = new MultiUnitItem();
				srcDetail.setCompanyId(getStringValue(obj[0]));
				srcDetail.setDivisionId(getStringValue(obj[1]));
				srcDetail.setProductSku(getStringValue(obj[2]));
				srcDetail.setSrcItemDesc(getStringValue(obj[3]));
				srcDetail.setSrcPackWhse(getBigDecimalValue(obj[4]));
				srcDetail.setSrcVendConvFctr(getBigDecimalValue(obj[5]));
				srcDetail.setSrcSize(getStringValue(obj[6]));
				srcDetail.setProdSourceCd(getStringValue(obj[7]));
				srcDetail.setSrcCost(getBigDecimalValue(obj[8]));
				srcDetail.setSrcDeptName(getStringValue(obj[9]));
				srcDetail.setSrcProductHierarchy((new StringBuilder().append(getStringValue(obj[10])).append("-")
						.append(getStringValue(obj[11])).append("-").append(getStringValue(obj[12]))).toString());
				srcDetail.setSrcUpc(getStringValue(obj[13]));
				srcDetail.setConvStatusCode(getStringValue(obj[14]));
				srcDetail.setMaxRetail(getBigDecimalValue(obj[15]));
				srcDetail.setSrcVendName(getStringValue(obj[16]));
				srcDetail.setConvProductSku(getStringValue(obj[17]));
				srcMatchList.add(srcDetail);
				sourceDataMap.put(srcDetail.getConvProductSku(), srcMatchList);
				
			}
			
		}
		List<String> sortedKeys =new ArrayList<>(sourceDataMap.keySet());
		Collections.sort(sortedKeys); 
		Set<String> deptList= new HashSet<>();
		for(String convProductSku : sortedKeys){
			List<MultiUnitItem> srcItemMatchList = sourceDataMap.get(convProductSku);
			Set<String> upcList= new HashSet<>();
			Set<String> productSkuSet=new HashSet<>();
			BigDecimal max_retail =new BigDecimal("0");
			for (MultiUnitItem multiUnitItem : srcItemMatchList) {
				upcList.add(multiUnitItem.getSrcUpc());
				deptList.add(multiUnitItem.getSrcDeptName());
				productSkuSet.add(multiUnitItem.getProductSku());
				if(multiUnitItem.getMaxRetail().compareTo(max_retail) >= 0)
				{
					max_retail=multiUnitItem.getMaxRetail();
				}
			}
			MultiUnitSourceDto multiUnitSrc = new MultiUnitSourceDto();
			MultiUnitItem item = srcItemMatchList.get(0);
			multiUnitSrc.setCompanyId(item.getCompanyId());
			multiUnitSrc.setDivisionId(item.getDivisionId());
			multiUnitSrc.setProductSku(item.getProductSku());
			if(item.getProdSourceCd().equals("DSD")){
				multiUnitSrc.setConvProductSku(item.getConvProductSku());
			}else{
				multiUnitSrc.setConvProductSku(item.getProductSku());
			}
			multiUnitSrc.setSrcItemDesc(item.getSrcItemDesc());
			multiUnitSrc.setSrcPackWhse(item.getSrcPackWhse());
			multiUnitSrc.setSrcVendConvFctr(item.getSrcVendConvFctr());
			multiUnitSrc.setSrcSize(item.getSrcSize());
			multiUnitSrc.setDeptName(item.getSrcDeptName());
			multiUnitSrc.setProductHierarchy(item.getSrcProductHierarchy());
			multiUnitSrc.setProdSourceCd(item.getProdSourceCd());
			multiUnitSrc.setSrcCost(item.getSrcCost());
			multiUnitSrc.setConvStatusCode(item.getConvStatusCode());
			multiUnitSrc.setMaxRetail(max_retail);
			multiUnitSrc.setSrcVendName(item.getSrcVendName());
			multiUnitSrc.setUpcs(upcList);
			multiUnitSrc.setDeptNames(deptList);
			multiUnitSrc.setProductSkuSet(productSkuSet);
			multiUnitSourceList.add(multiUnitSrc);
		}
		return new ArrayList<>(multiUnitSourceList);
	}
	
	public List<MultiUnitTypeTargetDto> buildMultiUnitTargetItem(
			List<Object[]> multiUnitTarList) {
		Map<String,List<MultiUnitItem>> targetDataMap=new HashMap<>();
		List<MultiUnitTypeTargetDto> multiUnitTargetList = new ArrayList<>();
		MultiUnitItem targetDetail = null;
		List<MultiUnitItem> tarMatchList;
		for (Object[] obj : multiUnitTarList) {
			String key = getBigDecimalValue(obj[0]).toString();
			if(targetDataMap.containsKey(key)){
				tarMatchList =targetDataMap.get(key);
				targetDetail = new MultiUnitItem();
				targetDetail.setTarCorpItemCd(getBigDecimalValue(obj[0]));
				targetDetail.setTarItemDesc(getStringValue(obj[1]));
				targetDetail.setTarPackWhse(getBigDecimalValue(obj[2]));
				targetDetail.setTarVendConvFctr((getBigDecimalValue(obj[3])));
				targetDetail.setTarUpc(getStringValue(obj[4]));
				targetDetail.setTarUnitType(getBigDecimalValue(obj[5]));
				targetDetail.setTarSmicCode(getStringValue(obj[6]));
				targetDetail.setTarSize(getStringValue(obj[7]));
				targetDetail.setTarCaseUpc(getStringValue(obj[8]));
				targetDetail.setTarInnerPack(getBigDecimalValue(obj[9]));
				targetDetail.setTarRetailSection(getStringValue(obj[10]));
				targetDetail.setTarCorpStatus(getStringValue(obj[11].toString()));
				targetDetail.setTarDeptName(getStringValue(obj[12]));
				targetDetail.setTarCost(getBigDecimalValue(obj[13]));
				targetDetail.setTarItemTypeWhseDsd(getStringValue(obj[14]));
				targetDetail.setTarVendorNumber(getStringValue(obj[15]));
				targetDetail.setTarVendorName(getStringValue(obj[16]));
				targetDetail.setTarFinalUpc(getStringValue(obj[17]));
				targetDetail.setTarFinalUnitType(getBigDecimalValue(obj[18]));
				tarMatchList.add(targetDetail);
				targetDataMap.put(key, tarMatchList);
				
			}else{
				tarMatchList= new ArrayList<>();
				targetDetail = new MultiUnitItem();
				targetDetail.setTarCorpItemCd(getBigDecimalValue(obj[0]));
				targetDetail.setTarItemDesc(getStringValue(obj[1]));
				targetDetail.setTarPackWhse(getBigDecimalValue(obj[2]));
				targetDetail.setTarVendConvFctr((getBigDecimalValue(obj[3])));
				targetDetail.setTarUpc(getStringValue(obj[4]));
				targetDetail.setTarUnitType(getBigDecimalValue(obj[5]));
				targetDetail.setTarSmicCode(getStringValue(obj[6]));
				targetDetail.setTarSize(getStringValue(obj[7]));
				targetDetail.setTarCaseUpc(getStringValue(obj[8]));
				targetDetail.setTarInnerPack(getBigDecimalValue(obj[9]));
				targetDetail.setTarRetailSection(getStringValue(obj[10]));
				targetDetail.setTarCorpStatus(getStringValue(obj[11].toString()));
				targetDetail.setTarDeptName(getStringValue(obj[12]));
				targetDetail.setTarCost(getBigDecimalValue(obj[13]));
				targetDetail.setTarItemTypeWhseDsd(getStringValue(obj[14]));
				targetDetail.setTarVendorNumber(getStringValue(obj[15]));
				targetDetail.setTarVendorName(getStringValue(obj[16]));
				targetDetail.setTarFinalUpc(getStringValue(obj[17]));
				targetDetail.setTarFinalUnitType(getBigDecimalValue(obj[18]));
				tarMatchList.add(targetDetail);
				targetDataMap.put(key, tarMatchList);
			}
		}
		List<String> sortedKeys =new ArrayList<>(targetDataMap.keySet());
		Collections.sort(sortedKeys); 
		String whseOrDsd=null;
		Set<String> deptList= new HashSet<>();
		for(String cic : sortedKeys){
			List<MultiUnitItem> targetItemMatchList = targetDataMap.get(cic);
			Set<String> upcList= new HashSet<>();
			Set<BigDecimal> unitType= new HashSet<>();
			Set<String> upcListWithUnitType=new HashSet<>();
			for (MultiUnitItem multiUnitItem : targetItemMatchList) {
					upcListWithUnitType.add(new StringBuilder().append(multiUnitItem.getTarFinalUpc()).append("-").append(multiUnitItem.getTarFinalUnitType()).toString());
					upcList.add(multiUnitItem.getTarFinalUpc());
					unitType.add(multiUnitItem.getTarFinalUnitType());
					deptList.add(multiUnitItem.getTarDeptName());
			}
			MultiUnitTypeTargetDto multiUnitTar;
			MultiUnitItem item = targetItemMatchList.get(0);
			
			multiUnitTar = new MultiUnitTypeTargetDto();
			multiUnitTar.setCorpItemCd(item.getTarCorpItemCd());
			multiUnitTar.setItemDesc(item.getTarItemDesc());
			multiUnitTar.setPackWhse(item.getTarPackWhse());
			multiUnitTar.setVendConvFctr(item.getTarVendConvFctr());
			multiUnitTar.setUpcList(upcList);
			multiUnitTar.setUnitType(unitType);
			multiUnitTar.setUpcWithUnitType(upcListWithUnitType);
			multiUnitTar.setSmicCode(item.getTarSmicCode());
			multiUnitTar.setSize(item.getTarSize());
			multiUnitTar.setCaseUpc(item.getTarCaseUpc());
			multiUnitTar.setInnerPack(item.getTarInnerPack());
			multiUnitTar.setRetailSection(item.getTarRetailSection());
			multiUnitTar.setCorpStatus(item.getTarCorpStatus());
			multiUnitTar.setTargetDepartment(item.getTarDeptName());
			multiUnitTar.setCost(item.getTarCost());
			if(item.getTarItemTypeWhseDsd().equalsIgnoreCase("D")){
				whseOrDsd="DSD";
			}
			if(item.getTarItemTypeWhseDsd().equalsIgnoreCase("W")){
				whseOrDsd="WHSE";
			}
			multiUnitTar.setItemTypeWhseDsd(whseOrDsd);
			multiUnitTar.setVendorName(item.getTarVendorName());
			multiUnitTar.setVendorNumber(item.getTarVendorNumber());
			multiUnitTar.setDeptNameList(deptList);
			multiUnitTar.setUnitType(unitType);
			multiUnitTargetList.add(multiUnitTar);
		}
		return multiUnitTargetList;
	}
	/**
	 * @param obj
	 * @return
	 */
	private BigDecimal getBigDecimalValue(Object obj) {
		if (obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}

	/**
	 * @param obj
	 * @return
	 */
	private String getStringValue(Object obj) {
		if (obj == null)
			return "";
		return ((String) obj).trim();
	}

	public List<Object[]> buildPopUpData(List<Object[]> upcListDetails) {
		
		
		Map<String,StringBuilder> packretails =new HashMap();
		Map<String,StringBuilder> unitType =new HashMap();
		for(Object[] obj :upcListDetails)
		{
			
			if(packretails.containsKey(obj[0])){
				StringBuilder retail =packretails.get(obj[0]);
				retail.append(",").append(obj[2].toString());	
				packretails.put(obj[0].toString(), retail);
			}
			else if(obj[2]!=null && !obj[2].toString().trim().equals(""))
			{
				packretails.put(obj[0].toString(), new StringBuilder(obj[2].toString()));
			}
			else
			{
				packretails.put(obj[0].toString(), new StringBuilder(""));
			}
			
			if(unitType.containsKey(obj[0])){
				StringBuilder unit =unitType.get(obj[0].toString());
				unit.append(",").append(obj[1].toString());	
				unitType.put(obj[0].toString(), unit);
			}
			else if(obj[1]!=null && !obj[1].toString().trim().equals(""))
			{
				unitType.put(obj[0].toString(), new StringBuilder(obj[1].toString()));
			}
			else
			{
				unitType.put(obj[0].toString(), new StringBuilder(obj[1].toString()));
			}			
			
		}
		
		List modifiedList =new ArrayList();
		Iterator upcIterator =unitType.keySet().iterator();
		while(upcIterator.hasNext())
		{	String key =upcIterator.next().toString();
			Object[] obj =new Object[3];
			obj[0]=key;
			obj[1]=unitType.get(key);
			obj[2]=packretails.get(key);
			modifiedList.add(obj);
		}
		
		return modifiedList;
	}
}
