package com.safeway.app.memi.web.controllers;




//@Controller
//@RequestMapping("/likeItems")
public class SsimsLikeItemController {
    
/*    private static final Log LOG = LogFactory.getLog(SsimsLikeItemController.class);

    
    @Autowired
    private SsimsLikeItemService ssimsLikeItemService;
    
    
    /**
     * Method to list Companies
     */
/*    @RequestMapping(value = "/{upc}", method = RequestMethod.GET)
    public ResponseEntity<UiLikeItemVO> getLikeItemList(@PathVariable("upc") String upc) {

        LOG.info("Fetching Division records.");

        UiLikeItemVO response = ssimsLikeItemService.getlikeItemList();

        LOG.info("Completed fetching Division records.");

        return new ResponseEntity<UiLikeItemVO>(response, HttpStatus.OK);

    }*/
    

}
