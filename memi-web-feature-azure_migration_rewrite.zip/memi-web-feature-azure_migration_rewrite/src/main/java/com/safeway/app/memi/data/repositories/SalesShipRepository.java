package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : UIExceptionSrcRepository
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.SalesShip;

/**
 * Repository class for all DB operations for ITEM_CONV_UI_EXCEPTION_SRC table
 */
@Repository
public interface SalesShipRepository extends JpaRepository<SalesShip, Long> {

    
	@Query
	List<SalesShip> findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKU(
			String division, String company, String productsku);

	@Query
	List<SalesShip> findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKUAndSalesShipPkUpcCountryAndSalesShipPkUpcSystemAndSalesShipPkUpcManufacturerAndSalesShipPkUpcSales(
			String division, String company, String productsku,
			String upcCountry, String upcSystem, String upcManuf,
			String upcSales);
    
}
