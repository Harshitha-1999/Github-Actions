package com.safeway.app.memi.data.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ItemConvDisplayItem;
/**
 * Repository class for all DB operations for ITEM_CONV_DISPLAY_ITEMS table
 */
@Repository
public interface ItemConvDisplayItemRepository extends JpaRepository<ItemConvDisplayItem , Long > {

	@Query
	List<ItemConvDisplayItem> findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
			String companyId, String divisionId, String productSku);


}
