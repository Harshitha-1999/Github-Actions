package com.safeway.app.memi.domain.services;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceSimsItems;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UndoCreateNewCicDto;

public interface DisplayService {
	/**
	 * @param company
	 * @param division
	 * @return
	 */
	public List<UIDataVO> getDepartmentWiseDisplayItemData(String company,
			String division);

	/**
	 * @param company
	 * @param division
	 * @param department
	 * @param exceptionType
	 *            ->MULTI_COMP_ITEM_IND=Y/N
	 * @param status
	 *            ->N(un-reviewed) & C(Completed)
	 * @param type
	 *            -D-DSD/W-WHSE/A-Both DSD & WHSE
	 * @return
	 */
	public List<DisplayItemDetail> loadDepartmentWiseDisplayItemList(
			String company, String division, String department,
			char exceptionType, char status, char type);

	public Map<String, List<String>> updateMultiCompItemInd(
			List<DisplayItemDetail> displayItemDetail, char multiCompInd);
	
	public Map<String, List<String>> markItemsAsDead(
            List<DisplayItemDetail> displayItemDetail);
	
	public Map<String, String> updateCicMatch(
			List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto);

	public Map<String, String> createNewCic(
			List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto);
	
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnItemDesc(
			List<DisplayItemDetail> displayItemDetail);
	
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnProductSku(
			List<DisplayItemDetail> displayItemDetail);

	public DisplayItemSourceSimsItems fetchSourceAndSimsDetails(
			DisplayItemDetail displayItemDetail);

	public Map<String, String> undoCreateNewCic(
			UndoCreateNewCicDto displayItemCreateMatchCicDto);

	public Map<String, String> undoDisplayersCompleted(
			UndoCreateNewCicDto displayItemCreateMatchCicDto);

	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnOneTimeBuyFlag(
			List<DisplayItemDetail> displayItemDetail);

	public String uploadExcel(String dataDirectory, String companyId, String divisionId,
			String deptCode, String displayType, String userId,
			MultipartFile uploadedExcelfile) throws Exception;
	
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedItemDesc(List<DisplayItemDetail> displayItem);
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedProductSku(List<DisplayItemDetail> displayItem);
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(List<DisplayItemDetail> displayItem);

}
