package com.safeway.app.memi.domain.adapters;
/* ***************************************************************************
 * NAME :DtoFieldsAdapter 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Varada Nellayikunnath  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 12, 2017 vnell00 - Initial Creation
 * *************************************************************************
 */

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.ItemXrefPk;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.NewItemDetailPk;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

/**
 * Util class to convert VO objects to DO objects
 */
public class DtoFieldsAdapter {

	/**
	 * @param srcObj
	 * @return
	 */
	public NewItemDetail mapToNewItemDetail(NewItemDetailDto srcObj) {
		NewItemDetail newItemDto = new NewItemDetail();
		newItemDto.setNewItemPk(new NewItemDetailPk());
		newItemDto.setAugOverCmplnInd(srcObj.getAugOverCmplnInd());
		newItemDto.setBatchId(srcObj.getBatchId());
		newItemDto.setClsCd(srcObj.getClsCd());
		newItemDto.getNewItemPk().setCompanyId((srcObj.getCompanyId()));
		newItemDto.setCost(Float.valueOf(srcObj.getCost()));
		newItemDto.setCovTeamComment(srcObj.getCovTeamComment());
		newItemDto.setCtgryCd(srcObj.getCtgryCd());
		newItemDto.setDispFlag(srcObj.getDispFlag());
		newItemDto.getNewItemPk().setDivisionId(srcObj.getDivisionId());
		newItemDto.setDtaOverCic(srcObj.getDtaOverCic());
		newItemDto.setDtaSrcDesc(srcObj.getDtaSrcDesc());
		newItemDto.setDtaSrcInd(srcObj.getDtaSrcInd());
		newItemDto.setExcptionDesc(srcObj.getExcptionDesc());
		newItemDto.setExcptnTypeCd(srcObj.getExcptnTypeCd());
		newItemDto.setGrpCd(srcObj.getGrpCd());
		newItemDto.setItemUsageTypInd(srcObj.getItemUsageTypInd());
		newItemDto.setItemUsgeInd(srcObj.getItemUsgeInd());
		newItemDto.setLogicalInd(srcObj.getLogicalInd());
		newItemDto.setPackwhse(srcObj.getPackwhse());
		newItemDto.setPluCd(srcObj.getPluCd());
		newItemDto.setPrdHierLevel1(srcObj.getPrdHierLevel1());
		newItemDto.setPrdHierLevel2(srcObj.getPrdHierLevel2());
		newItemDto.setPrdHierLevel3(srcObj.getPrdHierLevel3());
		newItemDto.setPrdHierLevel4(srcObj.getPrdHierLevel4());
		newItemDto.setPrdHierLevel5(srcObj.getPrdHierLevel5());
		newItemDto.setPrmyUpcInd(srcObj.getPrmyUpcInd());
		newItemDto.getNewItemPk().setProductSKU(srcObj.getProductSKU());
		newItemDto.getNewItemPk().setProductSrcCd(srcObj.getProductSrcCd());
		newItemDto.setPtLabelInd(srcObj.getPtLabelInd());
		newItemDto.setSbClsCd(srcObj.getSbClsCd());
		newItemDto.setSize(srcObj.getSize());
		newItemDto.setSrcIntenetItemDesc(srcObj.getSrcIntenetItemDesc());
		newItemDto.setSrcItmDesc(srcObj.getSrcItmDesc());
		newItemDto.setSrcPosDesc(srcObj.getSrcPosDesc());
		newItemDto.setSrcRtlItmDesc(srcObj.getSrcRtlItmDesc());
		newItemDto.setSrcSizeNmbr(srcObj.getSrcSizeNmbr());
		newItemDto.setSrcSizeUom(srcObj.getSrcSizeUom());
		newItemDto.setSrcWhseItmDesc(srcObj.getSrcWhseItmDesc());
		newItemDto.setSubSbClass(srcObj.getSubSbClass());
		newItemDto.getNewItemPk().setUpcCountry(srcObj.getUpcCountry());
		newItemDto.getNewItemPk().setUpcManufacturer(srcObj.getUpcManufacturer());
		newItemDto.getNewItemPk().setUpcSales(srcObj.getUpcSales());
		newItemDto.getNewItemPk().setUpcSystem(srcObj.getUpcSystem());
		newItemDto.setUpdDispFlag(srcObj.getUpdDispFlag());
		newItemDto.setUpdIntenetItemDesc(srcObj.getUpdIntenetItemDesc());
		newItemDto.setUpdItmDesc(srcObj.getUpdItmDesc());
		newItemDto.setUpdPosDesc(srcObj.getUpdPosDesc());
		newItemDto.setUpdPtLabelInd(srcObj.getUpdPtLabelInd());
		newItemDto.setUpdRtlItmDesc(srcObj.getUpdRtlItmDesc());
		newItemDto.setUpdSize(srcObj.getUpdSize());
		newItemDto.setUpdSizeNmbr(srcObj.getUpdSizeNmbr());
		newItemDto.setUpdSizeUom(srcObj.getUpdSizeUom());
		newItemDto.setUpdUsageTypInd(srcObj.getUpdUsageTypInd());
		newItemDto.setUpdUsgeInd(srcObj.getUpdUsgeInd());
		newItemDto.setUpdWhseItmDesc(srcObj.getUpdWhseItmDesc());
		newItemDto.setVendConvFactor(srcObj.getVendConvFactor());
		newItemDto.setCscDsc(srcObj.getCscDsc());
		return newItemDto;
	}

	/**
	 * @param sourceObj
	 * @param uiSaveObj
	 * @return
	 */
	public NewItemDetail mapToNewItemDetailtoSave(UIExceptionSrc sourceObj,
			NewItemDetailDto uiSaveObj) {
		NewItemDetailPk newPk = new NewItemDetailPk();
		newPk.setCompanyId(sourceObj.getUiSrcPk().getCompanyId());
		newPk.setDivisionId(sourceObj.getUiSrcPk().getDivisionId());
		newPk.setProductSKU(sourceObj.getUiSrcPk().getProductSKU());
		newPk.setProductSrcCd(sourceObj.getUiSrcPk().getProductSrcCd());
		newPk.setUpcCountry(sourceObj.getUiSrcPk().getUpcCountry());
		newPk.setUpcManufacturer(sourceObj.getUiSrcPk().getUpcManufacturer());
		newPk.setUpcSales(sourceObj.getUiSrcPk().getUpcSales());
		newPk.setUpcSystem(sourceObj.getUiSrcPk().getUpcSystem());

		NewItemDetail newItemDtl = new NewItemDetail();
		newItemDtl.setNewItemPk(newPk);
		newItemDtl.setAugOverCmplnInd(uiSaveObj.getAugOverCmplnInd());
		newItemDtl.setBatchId(sourceObj.getBatchId());
		newItemDtl.setClsCd(uiSaveObj.getClsCd() != null ? uiSaveObj.getClsCd() : 0);
		newItemDtl.setCost(sourceObj.getCost());
		newItemDtl.setCovTeamComment(uiSaveObj.getCovTeamComment());
		newItemDtl.setCtgryCd(uiSaveObj.getCtgryCd());
		newItemDtl.setDispFlag(uiSaveObj.getDispFlag());
		newItemDtl.setExcptionDesc(sourceObj.getExcptionDesc());
		newItemDtl.setExcptnTypeCd(sourceObj.getExcptnTypeCd());
		newItemDtl.setGrpCd(uiSaveObj.getGrpCd());
		newItemDtl.setItemUsageTypInd(sourceObj.getItemUsageTypInd());
		newItemDtl.setItemUsgeInd(sourceObj.getItemUsgeInd());
		newItemDtl.setLogicalInd(sourceObj.getLogicalInd());
		newItemDtl.setPackwhse(uiSaveObj.getPackwhse());
		newItemDtl.setPluCd(uiSaveObj.getPluCd());
		newItemDtl.setPrdHierLevel1(sourceObj.getPrdHierLevel1());
		newItemDtl.setPrdHierLevel2(sourceObj.getPrdHierLevel2());
		newItemDtl.setPrdHierLevel3(sourceObj.getPrdHierLevel3());
		newItemDtl.setPrdHierLevel4(sourceObj.getPrdHierLevel4());
		newItemDtl.setPrdHierLevel5(sourceObj.getPrdHierLevel5());
		newItemDtl.setPrmyUpcInd(uiSaveObj.getPrmyUpcInd());
		newItemDtl.setPtLabelInd(sourceObj.getPtLabelInd());
		newItemDtl.setSbClsCd(uiSaveObj.getSbClsCd() != null ? uiSaveObj.getSbClsCd() : 0);
		newItemDtl.setSize(uiSaveObj.getSize());
		newItemDtl.setSrcIntenetItemDesc(sourceObj.getIntenetItemDesc());
		newItemDtl.setSrcItmDesc(sourceObj.getItmDesc());
		newItemDtl.setSrcPosDesc(sourceObj.getPosDesc());
		newItemDtl.setSrcRtlItmDesc(sourceObj.getRtlItmDesc());
		newItemDtl.setSrcSizeNmbr(sourceObj.getSizeNmbr());
		newItemDtl.setSrcSizeUom(sourceObj.getSizeUom());
		newItemDtl.setSrcWhseItmDesc(sourceObj.getWhseItmDesc());
		newItemDtl.setSubSbClass(uiSaveObj.getSubSbClass() != null ? uiSaveObj.getSubSbClass() : 0);
		uiSaveObj.getAugOverCmplnInd();
		newItemDtl.setUpdDispFlag(uiSaveObj.getUpdDispFlag());
		newItemDtl.setUpdIntenetItemDesc(uiSaveObj.getUpdIntenetItemDesc());
		newItemDtl.setUpdItmDesc(uiSaveObj.getUpdItmDesc());
		newItemDtl.setUpdPosDesc(uiSaveObj.getUpdPosDesc());
		newItemDtl.setUpdPtLabelInd(uiSaveObj.getUpdPtLabelInd());
		newItemDtl.setUpdRtlItmDesc(uiSaveObj.getUpdRtlItmDesc());
		newItemDtl.setUpdSize(uiSaveObj.getUpdSize());
		newItemDtl.setUpdSizeNmbr(uiSaveObj.getUpdSizeNmbr());
		newItemDtl.setUpdSizeUom(uiSaveObj.getUpdSizeUom());
		newItemDtl.setUpdUsageTypInd(uiSaveObj.getUpdUsageTypInd());
		newItemDtl.setUpdUsgeInd(uiSaveObj.getUpdUsgeInd());
		newItemDtl.setUpdWhseItmDesc(uiSaveObj.getUpdWhseItmDesc());
		newItemDtl.setVendConvFactor(uiSaveObj.getVendConvFactor());
		newItemDtl.setCreateUser(uiSaveObj.getCreateId());
		newItemDtl.setCscDsc(uiSaveObj.getCscDsc());
		newItemDtl.setPrmyUpcInd(sourceObj.getPrmyUpcInd());
		
		//New Field Update for production code
		newItemDtl.setProductionGrpCd(getIntegerValue(uiSaveObj.getProductionGrpCd()));
		newItemDtl.setProductionCtgryCd(getIntegerValue(uiSaveObj.getProductionCtgryCd()));
		newItemDtl.setProductionClsCd(getIntegerValue(uiSaveObj.getProductionClsCd()));
		newItemDtl.setEthnicTypeCd(getStringValue(uiSaveObj.getEthnicTypeCd()));
		newItemDtl.setPckTypeId(getBigDecimalValue(uiSaveObj.getPckTypeId()));
		newItemDtl.setProductClsCd(getIntegerValue(uiSaveObj.getProductClsCd()));
		newItemDtl.setInnerPack(getIntegerValue(uiSaveObj.getInnerPack()));
		newItemDtl.setRetailUnitPack(getIntegerValue(uiSaveObj.getRetailUnitPack()));
		
		// Produce PLU changes
		String srcUpc=sourceObj.getUiSrcPk().getUpcCountry()+sourceObj.getUiSrcPk().getUpcSystem()+
				StringUtils.leftPad(sourceObj.getUiSrcPk().getUpcManufacturer(),5,"0")+
				StringUtils.leftPad(sourceObj.getUiSrcPk().getUpcSales(),5,"0");
		newItemDtl.setUpdUpc(srcUpc);
		if(sourceObj.getExcptnTypeCd()!=null && !sourceObj.getExcptnTypeCd().equals('O'))
		{
				
		
				if(Float.parseFloat(srcUpc)>=10000 && uiSaveObj.getEditedUpc(srcUpc) != null && !uiSaveObj.getEditedUpc(srcUpc).trim().equals("") )
				{
					newItemDtl.setUpdUpc(uiSaveObj.getEditedUpc(srcUpc));
					
				}
				else if(uiSaveObj.getEditedPLU(srcUpc) != 0 )
				{
					newItemDtl.setUpdPluCd(Integer.toString(uiSaveObj.getEditedPLU(srcUpc)));
				}
		
		newItemDtl.setPackDesc(uiSaveObj.getDcPackDesc() != null ? uiSaveObj.getDcPackDesc().trim() :null);
		newItemDtl.setSizeDesc(uiSaveObj.getDcSizeDsc() !=null ? uiSaveObj.getDcSizeDsc().trim():null);
		newItemDtl.setRing(uiSaveObj.getRing());
		newItemDtl.setHicone(uiSaveObj.getHicone());	
		
		newItemDtl.setProdwght(uiSaveObj.getProdwght());
		newItemDtl.setHandlingCode(uiSaveObj.getHandlingCode());
		newItemDtl.setBuyerNum(uiSaveObj.getBuyerNum());
		newItemDtl.setRandomWtCd(uiSaveObj.getRandomWtCd());
		newItemDtl.setAutoCostInv(uiSaveObj.getAutoCostInv());
		newItemDtl.setBillingType(uiSaveObj.getBillingType());
		newItemDtl.setFdStmp(uiSaveObj.getFdStmp());
		newItemDtl.setLabelSize(uiSaveObj.getLabelSize());
		newItemDtl.setLabelNumbers(uiSaveObj.getLabelNumbers());
		newItemDtl.setSgnCount1(uiSaveObj.getSgnCount1());
		newItemDtl.setSgnCount2(uiSaveObj.getSgnCount2());
		newItemDtl.setSgnCount3(uiSaveObj.getSgnCount3());
		newItemDtl.setSellByDays(uiSaveObj.getSellByDays());
		newItemDtl.setEatByDays(uiSaveObj.getUseByDays());
		newItemDtl.setPullByDays(uiSaveObj.getPullBydays());
		newItemDtl.setUpdPack(uiSaveObj.getUpdpackwhse());
		newItemDtl.setTareCd(uiSaveObj.getTareCd());
		
		}
		newItemDtl.setCreateUpdateTimestamp(new Date());
		
		return newItemDtl;
	}

	
	/**
	 * @param srcDto
	 * @return
	 */
	public ItemXrefData getMasterData(UIExceptionSrcDto srcDto) {
		ItemXrefData masterData = new ItemXrefData();
		ItemXrefPk itempk = new ItemXrefPk();
		itempk.setCompanyId(srcDto.getCompanyId());
		itempk.setDivisionId(srcDto.getDivisionId());
		itempk.setProdSku(srcDto.getProductSKU());
		itempk.setUpcCountry(Integer.parseInt(srcDto.getUpcCountry()));
		itempk.setUpcManu(Integer.parseInt(srcDto.getUpcManufacturer()));
		itempk.setUpcSales(Integer.parseInt(srcDto.getUpcSales()));
		itempk.setUpcSystem(Integer.parseInt(srcDto.getUpcSystem()));
		masterData.setItemPk(itempk);
		masterData.setConvStatusCode("D");
		masterData.setConvStatusSubCode("B");
		masterData.setConvStatusDesc("Dead Item - Business assigned status.");	
		masterData.setUpdatedUserId(srcDto.getUpdatedUserID());
		return masterData;
	}
	
	private String getStringValue(Object obj){
		if(obj == null)
			return "";
		return ((String) obj).trim();
	}

	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return  new BigDecimal(obj.toString());
	}
	private Integer getIntegerValue(Object obj){
		if(obj == null)
			return Integer.valueOf(0);
		return (Integer) obj;
	}
}
