/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

/* ***************************************************************************
 * NAME         : ReportController 
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Varada Nellayikunnath
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 May 9, 2017  -  Initial Creation
 *
 ***************************************************************************/

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.services.ExceptionSrcService;
import com.safeway.app.memi.domain.services.MasterItemService;
import com.safeway.app.memi.domain.services.NewItemDetailService;


/**
 * 
 * REST service controller class for New CIC Data Management
 * 
 */
@Controller
@RequestMapping("/newitem")
public class NewItemDetailsController {
    private static final Logger LOG = LoggerFactory.getLogger(NewItemDetailsController.class);

    
    @Autowired
    private NewItemDetailService newItemDetailService;
    
    @Autowired
    private MasterItemService masterItemService;
    
    @Autowired
    private ExceptionSrcService exceptionSrcService;
    
    
    /**
     * Method to list New CIC Records
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseEntity<List<NewItemDetailDto>> getExceptionSrcList() {
        LOG.info("Fetching new item records.");

        List<NewItemDetailDto> response = newItemDetailService.getAllItems();

        LOG.info("Completed fetching new item records.");

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Method to Save New CIC Records for Augmentation Screen
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public  ResponseEntity<AugDataVo> saveItemDetails(HttpServletRequest request, @RequestBody String itemDetails) {
        LOG.debug("Request Received, JSON String to save ");
        AugDataVo newItemToDB=new AugDataVo();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            newItemToDB = (AugDataVo) mapper.readValue(itemDetails,AugDataVo.class);
        }
        catch (IOException e) {
        	LOG.error("Failed to parse JSON.");
        	LOG.error(e.getMessage());
        }
        LOG.info("Saving new item records.");
        if(newItemToDB.isKillProdSku())
        {
           boolean isdead  = masterItemService.killItem(newItemToDB.getUiEceptionSrcDto(), newItemToDB.getMarkAsDeadReason());
           boolean iscomplete= exceptionSrcService.markItemComplete(newItemToDB.getUiEceptionSrcDto(), 'A');
           boolean removedNewCICRecord= exceptionSrcService.removeCICRecord(newItemToDB.getUiEceptionSrcDto(), 'A');
            if(isdead && iscomplete && removedNewCICRecord)
            {
            	newItemToDB.setStatus(1);
            }
            else
            {
            	newItemToDB.setStatus(0);
            }
            
            LOG.info("Item details saved and Marked as dead");
        }
        else if (newItemToDB.isManualMap())
        {
            boolean isManualmap  = masterItemService.updateItemStatusXRF(newItemToDB.getUiEceptionSrcDto(), "O");
            boolean iscomplete= exceptionSrcService.markItemComplete(newItemToDB.getUiEceptionSrcDto(), 'A');
            boolean removedNewCICRecord= exceptionSrcService.removeCICRecord(newItemToDB.getUiEceptionSrcDto(), 'A');
            if(isManualmap && iscomplete && removedNewCICRecord)
            {
            	newItemToDB.setStatus(1);
            }
            else
            {
            	newItemToDB.setStatus(0);
            }
            
            LOG.info("Item details saved and moved out of automated converiosn process");
        	
        } else 
        {
        	newItemDetailService.saveItem(newItemToDB);
        	// Updating ITEM_XRF status  to pick the item for the auto conversion process.
        	if (newItemToDB.getNewItemDto().getAugOverCmplnInd() != 'N'){
        		masterItemService.updateItemStatusXRF(newItemToDB.getUiEceptionSrcDto(), "A");
        	}
        	LOG.info("Item details saved and updated XRF table");
        }
       
        LOG.info("Completed saving item records.");
        
        return new ResponseEntity<>(newItemToDB, HttpStatus.OK);
     
    }
    
    /**
     * Method to Save New CIC Records for Override Screen
     */
    @RequestMapping(value = "/override/save", method = RequestMethod.POST)
    public  ResponseEntity<OverrideDataVo> saveOverrideItemDetails(HttpServletRequest request, @RequestBody String itemDetails) {
        LOG.debug("Request receieved, String to save ");
        OverrideDataVo newItemToDB=new OverrideDataVo();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        
        try {
            newItemToDB = (OverrideDataVo) mapper.readValue(itemDetails,OverrideDataVo.class);
        }
        catch (IOException e) {
        	LOG.error("Failed to parse JSON.");
        	LOG.error(e.getMessage());
        }
        LOG.info("Saving new item records.");
        if(newItemToDB.isKillProdSku())
        {
           boolean isdead  = masterItemService.killItem(newItemToDB.getUiEceptionSrcDto(), newItemToDB.getMarkAsDeadReason());
           boolean iscomplete= exceptionSrcService.markItemComplete(newItemToDB.getUiEceptionSrcDto(), 'O');
           boolean removedNewCICRecord= exceptionSrcService.removeCICRecord(newItemToDB.getUiEceptionSrcDto(), 'O');
            if(isdead && iscomplete && removedNewCICRecord)
            {
            	newItemToDB.setStatus(1);
            }
            else
            {
            	newItemToDB.setStatus(0);
            }
            LOG.info("Item details saved and Marked as dead");
        } else if (newItemToDB.isManualMap())
        {
            boolean isManualmap  = masterItemService.updateItemStatusXRF(newItemToDB.getUiEceptionSrcDto(), "O");
            boolean iscomplete= exceptionSrcService.markItemComplete(newItemToDB.getUiEceptionSrcDto(), 'O');
            boolean removedNewCICRecord= exceptionSrcService.removeCICRecord(newItemToDB.getUiEceptionSrcDto(), 'O');
            if(isManualmap && iscomplete && removedNewCICRecord)
            {
            	newItemToDB.setStatus(1);
            }
            else
            {
            	newItemToDB.setStatus(0);
            }
            
            LOG.info("Item details saved and moved out of automated converiosn process");
        	
        }else if(newItemToDB.isMoveToManualMap())
        {
            boolean iscomplete= exceptionSrcService.markItemComplete(newItemToDB.getUiEceptionSrcDto(), 'O');
            boolean removedNewCICRecord= exceptionSrcService.removeCICRecord(newItemToDB.getUiEceptionSrcDto(), 'O');
            exceptionSrcService.insertManualMappingRecord(newItemToDB.getUiEceptionSrcDto(), newItemToDB.getNewItemDto().getDtaOverCic());
            if(iscomplete && removedNewCICRecord)
            {
            	newItemToDB.setStatus(1);
            }
            else
            {
            	newItemToDB.setStatus(0);
            }
            
            LOG.info("Item details saved nad marked for Manual Mapping and moved out of automated converiosn process");
        	
        }
        else
        {
        	newItemDetailService.saveItem(newItemToDB);
        	// updating ITEM_XRF status to pick the item for the auto conversion process.
        	masterItemService.updateItemStatusXRF(newItemToDB.getUiEceptionSrcDto(), "A");
        }
       
        LOG.info("Completed saving item records.");
        
        return new ResponseEntity<>(newItemToDB, HttpStatus.OK);
    }
    @RequestMapping(value = "/targetProdValidate/{prodClass}/{groupCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody boolean getTargetProdClassValidate(
			@PathVariable("prodClass") String prodClass,@PathVariable("groupCode") String groupCode) {
		
		LOG.info("Check target prod class");
		
		boolean resonse = exceptionSrcService.checkTargetProdClass(prodClass,groupCode);
		
		LOG.info("Checked target prod class");
		return resonse;
	}
}
