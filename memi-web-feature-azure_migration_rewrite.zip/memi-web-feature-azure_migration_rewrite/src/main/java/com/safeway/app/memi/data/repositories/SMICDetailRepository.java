package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : SMICDetailRepository
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.SMICDetail;
import com.safeway.app.memi.data.entities.SMICDetailPK;

@Repository
public interface SMICDetailRepository extends JpaRepository<SMICDetail, SMICDetailPK> {

	
	/**
	 * @param grpCd
	 * @param ctgryCd
	 * @param clsCd
	 * @param sbClsCd
	 * @param subSbClass
	 * @return
	 */
	@Query
    List<SMICDetail> findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(String grpCd, String ctgryCd, String clsCd, String sbClsCd, String subSbClass);

}
