/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;


import java.util.List;
import java.util.Map;

import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceUPC;
import com.safeway.app.memi.domain.dtos.response.ManualExpeseTypeChangeRequest;
import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequest;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.dtos.response.PerishableSKUSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableSearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.PerishableUPCwisedDetails;

/**
 ****************************************************************************
 * NAME			: PerishableMappingServices 
 * 
 * DESCRIPTION	: PerishableMappingServices is the service  class for performing 
 * 				  search and filter operations for mapping screen and mapped screen
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 05, 2018  - Initial Creation
 * *************************************************************************
 */

public interface PerishableMappingServices {
	
	/**
	 * Method to search source SKU data
	 * @param searchRequestVO
	 * @return
	 * @throws Exception 
	 */
	public PerishableSearchRequestVO listSKUPerishableItems(PerishableSearchRequestVO searchRequestVO) throws Exception;


	/**
	 * Method to search target CIC data
	 * @param searchRequestVO
	 * @return
	 * @throws Exception 
	 */
	public PerishableSearchRequestVO listCICPerishableItems(PerishableSearchRequestVO searchRequestVO) throws Exception;
	
	
	/**
	 * Method to search target CIC data
	 * @param searchRequestVO
	 * @return
	 */
	public void performAction(PerishableMappingRequestWrapper mappingRequest);
	
	
	/**
	 * 
	 * @param perishableMappingRequests
	 * @return
	 */
	public boolean duplicateCheckOnMappedItems( List<PerishableMappingRequest> perishableMappingRequests);
	
	/**
	 * 
	 * @param perishableMappingRequest
	 * @return
	 */
	public String saveForceNewInPerishableMapping(List<PerishableMappingRequest> perishableMappingRequests);


	public void createNewCic(PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto, String forceNewType);
	
	/**
	 * 
	 * @param searchRequestVO
	 * @return
	 */
	public List<PerishableMappedResultWrapper> listMappedData(PerishableSearchRequestVO searchRequestVO);


	public String updateForceNewInPerishableMapping(PerishableMappingRequest perishableMappingRequest);
	
	/**
	 * Method to fetch department details for source
	 * @return
	 */
	public List<Object[]> getSouceDepartmentDetails(String company,String division);
	/**
	 *  Method to fetch department details for target
	 * @return
	 */
	public List<Object[]> getTargetDepartmentDetails(String company,String division);
	/**
	 * Method to fetch upc,totalSales and saleDate details for target
	 * @param searchDetails
	 * @return
	 */
	public List<PerishableUPCwisedDetails> getUpcListDetails(Object[] searchDetails);


	/**
	 * 
	 * @param list
	 * @return
	 */
	public boolean checkMatchingUPCInTarget(PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto);


	public List<PerishableCICSearchResults> getSuggestedTargetList(PerishableMatchingTargetInputVO upcDetails);


	public PerishableAdditionalDetailsDto getadditionalRetailscanDetails(
			String corpItemCd);


	public List<PerishableUPCwisedDetails> getMappedUpcListDetails(
			Object[] searchDetails);


	public boolean changeExpenseType(
			List<ManualExpeseTypeChangeRequest> changeRequests);
	
	public ManualMapAdditionalLoadDto fetchTargetEditITems(ManualMatchAdtnlFieldLoadInputVo inputVo);
}
