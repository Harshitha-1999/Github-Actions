package com.safeway.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
public class MemiWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemiWebApplication.class, args);
	}
	
}
