/* **************************************************************************
* Copyright 2017 Safeway, Inc.
*
* This document/file contains proprietary data that is the property of Safeway, Inc. 
* Information contained herein may not be used,copied or disclosed in whole or in part
* except as permitted by a written agreement signed by an officer of Safeway.
*
* Unauthorized use, copying or other reproduction of this document/file
* is prohibited by law.
*
***************************************************************************/
package com.safeway.app.memi.domain.util;
/* ***************************************************************************
 * NAME         : EmailFacilitator 
 *
 * SYSTEM       : MIDAS
 *
 * AUTHOR       : U51095
 *
 ***************************************************************************/
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

/**
* Includes all the email related methods which creates the Message with the
* parameters sent to the method and facilitates in sending the mail.
*/
@Component("emailFacilitator")
public class EmailFacilitator extends JavaMailSenderImpl {

	@Value("${memi.mail.host}")
	private String host;
	@Value("${memi.mail.port}")
	private Integer port;
    /**
     * Method to send email, specifying different types of recipient list
     * 
     * @param from
     * @param to
     * @param cc
     * @param bcc
     * @param subject
     * @param body
     */
    public void sendEmailMessage(InternetAddress from, InternetAddress[] to, String subject, String body) {
        MimeMessagePreparator msgPreparator = new EmailPreparator(from, to, subject, body);

        this.setHost(host);
        this.setPort(port);
        this.send(msgPreparator);

    }

    /**
     * Email preparator class
     * 
     */
    private static class EmailPreparator implements MimeMessagePreparator {
        private final InternetAddress from;
        private final InternetAddress[] addresses;
        private final javax.mail.Message.RecipientType type;
        private final InternetAddress[] to;
        private final String subject;
        private final String body;

        public EmailPreparator(InternetAddress pFrom, InternetAddress[] pTo, String pSubject, String pBody) {
            from = pFrom;
            to = pTo;
            subject = pSubject;
            body = pBody;
            type = null;
            addresses = null;
        }

        /**
         * Method prepares the message to be sent
         * 
         * @param mimeMessage
         */
        public void prepare(MimeMessage mimeMessage) throws MessagingException {

            mimeMessage.setFrom(from);
            if (type != null) {
                mimeMessage.addRecipients(type, addresses);
            }
            else {
                mimeMessage.addRecipients(javax.mail.Message.RecipientType.TO, to);

            }
            mimeMessage.setSubject(subject, "UTF-8");
            mimeMessage.setContent(body, "text/html; charset=\"utf-8\"");
            mimeMessage.setHeader("Content-Type", "text/html; charset=\"utf-8\"");
            mimeMessage.setHeader("Content-Transfer-Encoding", "quoted-printable");

        }

        public String toString() {
            return getClass().getName()
                + " [ from: "
                + from
                + (type == null ? ", tos: " + java.util.Arrays.asList(to) : ", addresses: "
                    + java.util.Arrays.asList(addresses)) + ", type: " + type + ", subject: " + subject + ", body: "
                + body + " ]";
        }
    }
}