package com.safeway.app.memi.data.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite key class for Database table SRC_ITEM_XRF.
 * 
 */
@Embeddable
public class ItemXrefPk implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "COMPANY_ID")
	private String companyId;

	@Column(name = "DIVISION_ID")
	private String divisionId;

	@Column(name = "SRC_PRODUCT_SKU")
	private String prodSku;
	
	@Column(name = "SRC_UPC_MANUF")
	private Integer upcManu;

	@Column(name = "SRC_UPC_SALES")
	private Integer upcSales;

	@Column(name = "SRC_UPC_COUNTRY")
	private Integer upcCountry;

	@Column(name = "SRC_UPC_SYSTEM")
	private Integer upcSystem;

	@Column(name = "ROG")
	private String rog;
	
	@Column(name = "SRC_SUPPLIER_NUM")
	private String srcSupplierNum;
	
	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProdSku() {
		return prodSku;
	}

	public void setProdSku(String prodSku) {
		this.prodSku = prodSku;
	}

	public Integer getUpcManu() {
		return upcManu;
	}

	public void setUpcManu(Integer upcManu) {
		this.upcManu = upcManu;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public String getRog() {
		return rog;
	}

	public void setRog(String rog) {
		this.rog = rog;
	}
	
	public String getSrcSupplierNum() {
		return srcSupplierNum;
	}

	public void setSrcSupplierNum(String srcSupplierNum) {
		this.srcSupplierNum = srcSupplierNum;
	}
	
}
