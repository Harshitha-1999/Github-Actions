/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;


/**
 ****************************************************************************
 * NAME : PerishableMappedItemVO 
 * 
 * DESCRIPTION :PerishableMappedItemVO is the class to store the search data of Mapped item
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */
public class PerishableMappedItemVO {
	
	private String sourceSKU;
	private BigDecimal targetCIC;
	private String itemDesc;
	private BigDecimal pack;
	private BigDecimal size;
	private char usage;
	private char display;	
	private BigDecimal salesValue;
	private String createdOn;
	private String lastSalesDate;
	private String lastShipDate;
	private String mappedStatus;
	private BigDecimal vcf;
	private String upc;
	private String [] upcList;
	/**
	 * @return the sourceSKU
	 */
	public String getSourceSKU() {
		return sourceSKU;
	}
	/**
	 * @param sourceSKU the sourceSKU to set
	 */
	public void setSourceSKU(String sourceSKU) {
		this.sourceSKU = sourceSKU;
	}
	/**
	 * @return the targetCIC
	 */
	
	/**
	 * @return the itemDesc
	 */
	public String getItemDesc() {
		return itemDesc;
	}
	public BigDecimal getTargetCIC() {
		return targetCIC;
	}
	public void setTargetCIC(BigDecimal targetCIC) {
		this.targetCIC = targetCIC;
	}
	/**
	 * @param itemDesc the itemDesc to set
	 */
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public BigDecimal getPack() {
		return pack;
	}
	public void setPack(BigDecimal pack) {
		this.pack = pack;
	}
	public BigDecimal getSize() {
		return size;
	}
	public void setSize(BigDecimal size) {
		this.size = size;
	}
	/**
	 * @param usage the usage to set
	 */
	
	/**
	 * @return the display
	 */
	public char getUsage() {
		return usage;
	}
	public void setUsage(char usage) {
		this.usage = usage;
	}
	
	public char getDisplay() {
		return display;
	}
	public void setDisplay(char display) {
		this.display = display;
	}
	/**
	 * @return the salesValue
	 */
	public BigDecimal getSalesValue() {
		return salesValue;
	}
	/**
	 * @param salesValue the salesValue to set
	 */
	public void setSalesValue(BigDecimal salesValue) {
		this.salesValue = salesValue;
	}
	/**
	 * @return the mappedStatus
	 */
	public String getMappedStatus() {
		return mappedStatus;
	}
	/**
	 * @param mappedStatus the mappedStatus to set
	 */
	public void setMappedStatus(String mappedStatus) {
		this.mappedStatus = mappedStatus;
	}
	/**
	 * @return the vcf
	 */
	
	/**
	 * @return the upc
	 */
	public BigDecimal getVcf() {
		return vcf;
	}
	public void setVcf(BigDecimal vcf) {
		this.vcf = vcf;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getLastSalesDate() {
		return lastSalesDate;
	}
	public void setLastSalesDate(String lastSalesDate) {
		this.lastSalesDate = lastSalesDate;
	}
	public String getLastShipDate() {
		return lastShipDate;
	}
	public void setLastShipDate(String lastShipDate) {
		this.lastShipDate = lastShipDate;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String[] getUpcList() {
		return upcList;
	}
	public void setUpcList(String[] upcList) {
		this.upcList = upcList;
	}
	

}
