/* **************************************************************************
 /* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

/* ***************************************************************************
 * NAME         : ReportController 
 *
 * SYSTEM       : MEMD
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 March 09, 2016  -  Initial Creation
 *
 ***************************************************************************/

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.safeway.app.memi.domain.dtos.response.DivisionDto;
import com.safeway.app.memi.domain.services.DivisionService;

/**
 * 
 * REST service controller class for Division
 * 
 */
@Controller
@RequestMapping("/division")
public class DivisionListController {
    private static final Logger LOG = LoggerFactory.getLogger(DivisionListController.class);

    @Autowired
    private DivisionService divisionService;
    
    /**
     * Method to list Companies
     */
    @RequestMapping(value = "/company/{companyId}", method = RequestMethod.GET)
    public ResponseEntity<List<DivisionDto>> getDivisionsList(@PathVariable("companyId") String companyId) {

        LOG.info("Fetching Division records.");

        List<DivisionDto> response = divisionService.findByCompanyId(companyId);
        LOG.debug("Completed fetching for"+response.size()+" Division records.");

        LOG.info("Completed fetching for"+response.size()+" Division records.");

        return new ResponseEntity<>(response, HttpStatus.OK);

    }

}
