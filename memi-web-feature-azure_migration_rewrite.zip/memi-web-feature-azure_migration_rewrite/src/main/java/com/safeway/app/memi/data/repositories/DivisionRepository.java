package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : DivisionRepository 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.Division;

/**
 * Repository class for all DB operations for Division table
 */
@Repository
public interface DivisionRepository extends JpaRepository<Division, Long> {

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#findAll()
     */
    @Query
    List<Division> findAll();

    /**
     * @param companyID
     * @return
     */
    @Query
    List<Division> findByCompanyid(String companyID);

}
