package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class BulkUploadTrackingDto {

	private BigDecimal bulkUploadId;

	private String companyId;

	private String divisionId;

	private String divisionName;

	private String deptName;

	private String fileName;

	private String filePath;

	private String statusCode;

	private BigDecimal recordCount;

	private BigDecimal validRecordCount;

	private String createUserId;

	private Timestamp createUpdateTimestamp;

	public BigDecimal getBulkUploadId() {
		return bulkUploadId;
	}

	public void setBulkUploadId(BigDecimal bulkUploadId) {
		this.bulkUploadId = bulkUploadId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getDivisionName() {
		return divisionName;
	}

	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public BigDecimal getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(BigDecimal recordCount) {
		this.recordCount = recordCount;
	}

	public BigDecimal getValidRecordCount() {
		return validRecordCount;
	}

	public void setValidRecordCount(BigDecimal validRecordCount) {
		this.validRecordCount = validRecordCount;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getCreateUpdateTimestamp() {
		return createUpdateTimestamp;
	}

	public void setCreateUpdateTimestamp(Timestamp createUpdateTimestamp) {
		this.createUpdateTimestamp = createUpdateTimestamp;
	}

	@Override
	public String toString() {
		return "BulkUploadTrackingDto [bulkUploadId=" + bulkUploadId
				+ ", companyId=" + companyId + ", divisionId=" + divisionId
				+ ", divisionName=" + divisionName + ", deptName=" + deptName
				+ ", fileName=" + fileName + ", filePath=" + filePath
				+ ", statusCode=" + statusCode + ", recordCount=" + recordCount
				+ ", validRecordCount=" + validRecordCount + ", createUserId="
				+ createUserId + ", createUpdateTimestamp="
				+ createUpdateTimestamp + "]";
	}

}
