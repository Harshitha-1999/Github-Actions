package com.safeway.app.memi.data.repositories;

/* ***************************************************************************
 * NAME : NewItemDetailRepository SYSTEM : MEMI AUTHOR : Subhash G REVISION
 * HISTORY Revision 0.0.0.0 May 9, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.NewItemDetail;

/**
 * Repository class for all DB operations for ITEM_CONV_NEW_CIC_DATA_MGMT table
 */
@Repository
public interface NewItemDetailRepository extends JpaRepository<NewItemDetail, Long> {


   /**
 * @param companyId
 * @param divisionId
 * @param exceptionType
 * @return
 */
@Query
    List<NewItemDetail> findByNewItemPkCompanyIdAndNewItemPkDivisionIdAndExcptnTypeCd(String companyId, String divisionId,
        String exceptionType);

    /**
     * @param divisionId
     * @param companyId
     * @param augOverCmplnInd
     * @return
     */
    @Query
    List<NewItemDetail> findByNewItemPkDivisionIdAndNewItemPkCompanyIdAndAugOverCmplnInd(String divisionId, String companyId,
        char augOverCmplnInd);

    /**
     * @param division
     * @param company
     * @param productsku
     * @return
     */
    @Query
    NewItemDetail findByNewItemPkCompanyIdAndNewItemPkDivisionIdAndNewItemPkProductSKU(String division, String company, String productsku);

    /**
     * @param division
     * @param company
     * @param productsku
     * @return
     */
    @Query
    NewItemDetail findByNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkProductSKU(String division, String company, String productsku);

    /**
     * @param productsku
     * @param proSrcCd
     * @param division
     * @param company
     * @param upcContry
     * @param upcSys
     * @param upcManuf
     * @param upcSales
     * @return
     */
    NewItemDetail findByNewItemPkProductSKUAndNewItemPkProductSrcCdAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkUpcCountryAndNewItemPkUpcSystemAndNewItemPkUpcManufacturerAndNewItemPkUpcSales(
        String productsku, String proSrcCd, String division, String company, String upcContry, String upcSys,
        String upcManuf, String upcSales);
    
    /**
     * @param productsku
     * @param division
     * @param company
     * @param excptnTypeCd
     * @return
     */
    List<NewItemDetail> findByNewItemPkProductSKUAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndExcptnTypeCdOrderByPrmyUpcIndDesc(
            String productsku, String division, String company, char excptnTypeCd);
}
