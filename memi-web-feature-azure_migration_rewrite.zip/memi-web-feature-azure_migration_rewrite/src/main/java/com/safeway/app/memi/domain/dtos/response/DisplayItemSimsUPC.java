package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Comparator;

public class DisplayItemSimsUPC {

	private String upc;
	private String upcDesc;
	private BigDecimal quantity;
	private BigDecimal memoCost;

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getUpcDesc() {
		return upcDesc;
	}

	public void setUpcDesc(String upcDesc) {
		this.upcDesc = upcDesc;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getMemoCost() {
		return memoCost;
	}

	public void setMemoCost(BigDecimal memoCost) {
		this.memoCost = memoCost;
	}

	@Override
	public String toString() {
		return "DisplayItemSourceUPC [upc=" + upc + ", upcDesc=" + upcDesc
				+ ", quantity=" + quantity + ", memoCost=" + memoCost + "]";
	}
	

	

	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((upc == null) ? 0 : upc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DisplayItemSimsUPC other = (DisplayItemSimsUPC) obj;
		if (upc == null) {
			if (other.upc != null)
				return false;
		} else if (!upc.equals(other.upc))
			return false;
		return true;
	}


	public static Comparator<DisplayItemSimsUPC> upcComparator = new Comparator<DisplayItemSimsUPC>() {
		@Override
		public int compare(DisplayItemSimsUPC upc1, DisplayItemSimsUPC upc2) {
			return (int) (upc1.getUpc().compareTo(upc2.getUpc()));
		}
	};

}
