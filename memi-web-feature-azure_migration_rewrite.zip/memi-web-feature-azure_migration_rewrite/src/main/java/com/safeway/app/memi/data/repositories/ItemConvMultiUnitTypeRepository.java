package com.safeway.app.memi.data.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ItemConvMultiUnitType;

@Repository
public interface ItemConvMultiUnitTypeRepository extends JpaRepository<ItemConvMultiUnitType, Long> {
	
	
	@Query("SELECT p FROM ItemConvMultiUnitType p WHERE p.multiUnitPk.companyId = :companyId and p.multiUnitPk.divisionId =:divisionId and p.convProductSku =:convProductSku and p.multiUnitPk.srcUpc IN(:upcs)")
	public List<ItemConvMultiUnitType> findMultiUnitTypeSrcItemByProductSkuUpcList(
			@Param("companyId")String companyId, @Param("divisionId")String divisionId, @Param("convProductSku")String convProductSku,
			@Param("upcs")List<String> upcs);
}
