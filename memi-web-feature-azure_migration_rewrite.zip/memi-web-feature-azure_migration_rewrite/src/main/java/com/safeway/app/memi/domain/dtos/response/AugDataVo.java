package com.safeway.app.memi.domain.dtos.response;

import java.util.ArrayList;
import java.util.List;

public class AugDataVo {
    
	
	public static final int STATUS_SUCCESS = 0;
	public static final int STATUS_DEAD = 1;
	public static final int STATUS_VALIDATION_ERROR = 2;
	
    private UIExceptionSrcDto uiEceptionSrcDto;
    private SalesData salesData;
    private NewItemDetailDto newItemDto;
    boolean killProdSku;
    boolean manualMap;
    private List<String> errorMessages;
    private int status = 0;
    private String markAsDeadReason;
    
    public UIExceptionSrcDto getUiEceptionSrcDto() {
        return uiEceptionSrcDto;
    }
    public void setUiEceptionSrcDto(UIExceptionSrcDto uiEceptionSrcDto) {
        this.uiEceptionSrcDto = uiEceptionSrcDto;
    }
    public SalesData getSalesData() {
		return salesData;
	}
	public void setSalesData(SalesData salesData) {
		this.salesData = salesData;
	}
	public NewItemDetailDto getNewItemDto() {
        return newItemDto;
    }
    public void setNewItemDto(NewItemDetailDto newItemDto) {
        this.newItemDto = newItemDto;
    }
    public boolean isKillProdSku() {
        return killProdSku;
    }
    public void setKillProdSku(boolean killProdSku) {
        this.killProdSku = killProdSku;
    }
	public List<String> getErrorMessages() {
		return errorMessages;
	}
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	public void addErrorMessages(String errorMessage) {
		if(errorMessages == null)
			errorMessages = new ArrayList<>();
		errorMessages.add(errorMessage);
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMarkAsDeadReason() {
		return markAsDeadReason;
	}
	public void setMarkAsDeadReason(String markAsDeadReason) {
		this.markAsDeadReason = markAsDeadReason;
	}
	public boolean isManualMap() {
		return manualMap;
	}
	public void setManualMap(boolean manualMap) {
		this.manualMap = manualMap;
	}

}
