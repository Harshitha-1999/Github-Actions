package com.safeway.app.memi.data.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Entity class for Database table SRC_ITEM_XRF.
 * 
 */
@Entity
@Table(name = "SRC_ITEM_XRF", schema="XREFLAND")
public class ItemXrefData implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ItemXrefPk itemPk;

	@Column(name = "CONV_STATUS_CD")
	private String convStatusCode;
	
	@Column(name = "CONV_STATUS_SUB_CD")
	private String convStatusSubCode;
	
	@Column(name = "CONV_STATUS_DSC")
	private String convStatusDesc;
	
	@Column(name = "STATUS_REASON_TXT")
	private String statusReasonText;
	
	@Column(name = "CREATE_UPDATE_USER_ID")
	private String updatedUserId;

	public ItemXrefPk getItemPk() {
		return itemPk;
	}

	public void setItemPk(ItemXrefPk itemPk) {
		this.itemPk = itemPk;
	}

	public String getConvStatusCode() {
		return convStatusCode;
	}

	public void setConvStatusCode(String convStatusCode) {
		this.convStatusCode = convStatusCode;
	}

	/**
	 * @return the convStatusSubCode
	 */
	public String getConvStatusSubCode() {
		return convStatusSubCode;
	}

	/**
	 * @param convStatusSubCode the convStatusSubCode to set
	 */
	public void setConvStatusSubCode(String convStatusSubCode) {
		this.convStatusSubCode = convStatusSubCode;
	}

	/**
	 * @return the convStatusDesc
	 */
	public String getConvStatusDesc() {
		return convStatusDesc;
	}

	/**
	 * @param convStatusDesc the convStatusDesc to set
	 */
	public void setConvStatusDesc(String convStatusDesc) {
		this.convStatusDesc = convStatusDesc;
	}

	public String getStatusReasonText() {
		return statusReasonText;
	}

	public void setStatusReasonText(String statusReasonText) {
		this.statusReasonText = statusReasonText;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updateUserId) {
		this.updatedUserId = updateUserId;
	}
}