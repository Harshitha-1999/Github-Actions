package com.safeway.app.memi.domain.dtos.response;

import java.util.Date;

public class LookUpActionRequest {
	
	private String companyId;
	private String divisionId;
	private String productSKU;
	private String upc;	
	private String currentStatusCd;
	private String currentStatusSubCd;
	private String changestatusCd;
	private String statusReasonComments;
	
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getProductSKU() {
		return productSKU;
	}
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getCurrentStatusCd() {
		return currentStatusCd;
	}
	public void setCurrentStatusCd(String currentStatusCd) {
		this.currentStatusCd = currentStatusCd;
	}
	public String getChangestatusCd() {
		return changestatusCd;
	}
	public void setChangestatusCd(String changestatusCd) {
		this.changestatusCd = changestatusCd;
	}
	public String getCurrentStatusSubCd() {
		return currentStatusSubCd;
	}
	public void setCurrentStatusSubCd(String currentStatusSubCd) {
		this.currentStatusSubCd = currentStatusSubCd;
	}
	public String getStatusReasonComments() {
		return statusReasonComments;
	}
	public void setStatusReasonComments(String statusReasonComments) {
		this.statusReasonComments = statusReasonComments;
	}

}
