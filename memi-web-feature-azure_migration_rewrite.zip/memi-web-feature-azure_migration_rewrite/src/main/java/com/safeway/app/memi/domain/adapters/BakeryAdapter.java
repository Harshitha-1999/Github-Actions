/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.adapters;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakeryMappedItemVO;
import com.safeway.app.memi.domain.dtos.response.BakeryMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.BakerySKUSearchResults;
import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRetailScanDetails;
import com.safeway.app.memi.domain.util.PerishableConstants;


/**
 ****************************************************************************
 * NAME			: BakeryAdapter 
 * 
 * DESCRIPTION	: BakeryAdapter is the class for 
 * 				  mapping values fetched from DB to corresponding VO object
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 mar 05, 2018  - Initial Creation
 * *************************************************************************
 */

public class BakeryAdapter {
   
	/**
	 * 
	 * @param bakerySKUSearchResults
	 * @return
	 */
	public List<BakerySKUSearchResults> mapBakerySourceItem(List<Object[]> bakerySKUSearchResults) {
		List<BakerySKUSearchResults> skuSearchResults = new ArrayList<>();

		for (Object[] skuObj : bakerySKUSearchResults) {
			BakerySKUSearchResults skuResult = new BakerySKUSearchResults();
			
			String[] upcArray = parseUpc((skuObj[3] != null ? skuObj[3] : null));
			String pluList =appendPlus(upcArray);

			skuResult.setSku(getStringValue((skuObj[0] != null ? skuObj[0] : null)));
			skuResult.setItemDesc(getStringValue((skuObj[1] != null ? skuObj[1] : null)));
			skuResult.setSize(getStringValue((skuObj[2] != null ? skuObj[2] : null)));
			skuResult.setUpc(parseUpc((skuObj[3] != null ? skuObj[3] : null)));
			skuResult.setAbsUPCNo(upcArray!= null && upcArray.length>0 ? upcArray[0] : null);
			skuResult.setDisplay(getStringValue((skuObj[4] != null ? skuObj[4] : null)));
			skuResult.setAbsDSDWhse(getStringValue((skuObj[5] != null ? skuObj[5] : null)));
			skuResult.setDeptName(getStringValue((skuObj[6] != null ? skuObj[6] : null)));
			skuResult.setUpdateUser(getStringValue((skuObj[7] != null ? skuObj[7] : null)));
	    	skuResult.setVcf((BigDecimal) (skuObj[8] != null ? skuObj[8] : null));
			if((skuObj[9]) == null || ("UN_MAPPED").equals(skuObj[9])){
				skuResult.setMappingStatus(PerishableConstants.TO_BE_MAPPED);
			}else{
				skuResult.setMappingStatus(getStringValue(skuObj[9]));
			}
	    	skuResult.setSizeNumber((BigDecimal) (skuObj[10] != null ? skuObj[10] : null));
	    	skuResult.setCreatedOn(parseDate((Timestamp)(skuObj[11] != null ? skuObj[11] : null)));
	    	skuResult.setPackNum((BigDecimal) (skuObj[12] != null ? skuObj[12] : null));
	    	skuResult.setUsage(convertToChar((skuObj[13] != null ? skuObj[13] : null)));	    	
	    	skuResult.setHierarchyLevelOne(getStringValue((skuObj[14] != null ? skuObj[14] : null)));	 
	    	skuResult.setHierarchyLevelTwo(getStringValue((skuObj[15] != null ? skuObj[15] : null)));	
	    	skuResult.setHierarchyLevelThree(getStringValue((skuObj[16] != null ? skuObj[16] : null)));	
        	skuResult.setLastShipdate(parseDate((Timestamp)(skuObj[17] != null ? skuObj[17] : null)));
        	
	    	skuResult.setOnHand(  BigDecimal.valueOf ((Double)(skuObj[18] != null ? skuObj[18] : 0.0)));
	    	
	    	skuResult.setOnOrder( BigDecimal.valueOf ((Double)(skuObj[19] != null ? skuObj[19] : 0.0)));
	    	
	    	skuResult.setSlot(getStringValue((skuObj[20] != null ? skuObj[20] : null)));
	    	
	    	if(skuObj[21]!=null && getStringValue(skuObj[21]).equalsIgnoreCase("W") )
	    		skuResult.setSellingMethodCd("POUND");	
			else if(skuObj[21]!=null && getStringValue(skuObj[21]).equalsIgnoreCase("E") )
				skuResult.setSellingMethodCd("EACH");
	    	
	    	if(skuObj[22]!=null && getStringValue(skuObj[22]).equalsIgnoreCase("N") )
	    		skuResult.setRecievingRandomInd("CASE");	
			else if(skuObj[22]!=null && getStringValue(skuObj[22]).equalsIgnoreCase("Y") )
				skuResult.setRecievingRandomInd("POUND");  	
	    	
	    	skuResult.setSupplierNm(getStringValue (skuObj[23] != null ? skuObj[23] : null));
	    	skuResult.setSupplierNam(getStringValue((skuObj[24] != null ? skuObj[24] : null)));
	    	
	    	skuResult.setPlu(pluList);
	    	
	    	skuSearchResults.add(skuResult);
		}

		return skuSearchResults;

	
	}

	/**
	 * 
	 * @param bakeryCICSearchResults
	 * @return
	 */
	public List<BakeryCICSearchResults> mapBakeryTargetItem(List<Object[]> bakeryCICSearchResults) {
		List<BakeryCICSearchResults> cicSearchResults = new ArrayList<>();
		for (Object[] cicObj : bakeryCICSearchResults) {
			BakeryCICSearchResults bakeryCicResult = new BakeryCICSearchResults();
			bakeryCicResult.setCic((BigDecimal)(cicObj[0] != null ? cicObj[0] : null));
			bakeryCicResult.setItemDesc(getStringValue(cicObj[1] != null ? cicObj[1] : null));
			bakeryCicResult.setVcf((BigDecimal)(cicObj[2] != null ? cicObj[2] : null));
			bakeryCicResult.setPack((BigDecimal)(cicObj[3] != null ? cicObj[3] : null));
			bakeryCicResult.setSize(getStringValue (cicObj[4] != null ? cicObj[4] : null));
			bakeryCicResult.setUsage(convertToChar(cicObj[5] != null ? cicObj[5] : null));
			bakeryCicResult.setUpc(parseUpc((cicObj[6] != null ? cicObj[6] : null)));
			bakeryCicResult.setPlu((BigDecimal)(cicObj[7] != null ? cicObj[7] : null));
			bakeryCicResult.setDisplay(convertToChar(cicObj[8] != null ? cicObj[8] : null));
			bakeryCicResult.setStatusCorp(convertToChar(cicObj[9] != null ? cicObj[9] : null));
			bakeryCicResult.setSmic(getStringValue(cicObj[10] != null ? cicObj[10] : null));
			bakeryCicResult.setDeptName(getStringValue(cicObj[11] != null ? cicObj[11] : null));
			if((cicObj[12]) == null || ("UN_MAPPED").equals(cicObj[12])){
				bakeryCicResult.setMappingStatus(PerishableConstants.TO_BE_MAPPED);
			}else{
				bakeryCicResult.setMappingStatus(getStringValue(cicObj[12] != null ? (cicObj[12]) : null));
			}
			bakeryCicResult.setRing((BigDecimal)(cicObj[13] != null ? cicObj[13] : null));
			bakeryCicResult.setTareCode((BigDecimal)(cicObj[14] != null ? cicObj[14] : null));
			bakeryCicResult.setScale(convertToChar(cicObj[15] != null ? cicObj[15] : null));
			bakeryCicResult.setShelfLife((BigDecimal)(cicObj[16] != null ? cicObj[16] : null));
			bakeryCicResult.setScaleNetWeight((BigDecimal)(cicObj[17] != null ? cicObj[17] : null));
			bakeryCicResult.setScaleNetWeightUnit(getStringValue(cicObj[18] != null ? cicObj[18] : null));
			bakeryCicResult.setBakeryIngredients((BigDecimal)(cicObj[19] != null ? cicObj[19] : null));
			bakeryCicResult.setScaleSellByDays((BigDecimal)(cicObj[20] != null ? cicObj[20] : null));
			bakeryCicResult.setScaleEatByDays((BigDecimal)(cicObj[21] != null ? cicObj[21] : null));
			bakeryCicResult.setWhseDsd(getStringValue(cicObj[22] != null ? cicObj[22] : null));
			bakeryCicResult.setItemUSageInd(convertToChar(cicObj[23] != null ? cicObj[23] : null));
			bakeryCicResult.setFarmOrWild(convertToChar(cicObj[24] != null ? cicObj[24] : null));			
			bakeryCicResult.setVendor_detail(parseUpc((!cicObj[25].equals("VENDOR_DETAIL")  ? cicObj[25] : null)));	
			bakeryCicResult.setSize_Uom(getStringValue(cicObj[26] != null ? cicObj[26] : null));
			bakeryCicResult.setVoc(getStringValue(cicObj[27] != null ? cicObj[27] : null));
			
			cicSearchResults.add(bakeryCicResult);
		}

		return cicSearchResults;

	}
	
	/**
	 * @param obj
	 * @return string
	 */
	private String getStringValue(Object obj) {
		if (obj == null)
		{
			return "";
		}
		String str = (String) obj;
		return str.trim();
		
	}
	
	/**
	 * @param obj
	 * @return string[]
	 */
	private String[] parseUpc(Object obj) {
		String[] str=null;
		if (obj == null){
			return str;
		}
		else
		{
			List<String> list = Arrays.asList(obj.toString().split(";"));
		    Set<String> set = new HashSet<>(list);
		    String[] result = new String[set.size()];
		    set.toArray(result);
		    return result;
		}
		
		
	}
	
	private String parseDate(Timestamp dt)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
        if(dt!=null){
	    return dateFormat.format(dt);
        }
        else{
        return null;
        }
	    
	}
	
	private char convertToChar(Object obj){
		if(obj !=null && obj.toString().length() == 1)
		{
			return obj.toString().charAt(0);
		}
		else
		{
			return Character.MIN_VALUE;
			}
	
	}
	
public List<BakeryMappedResultWrapper> setMappedItems(List<Object[]> mappedItems){
		
		List<BakeryMappedResultWrapper> maddedItems=new ArrayList<>();
		
		for(Object[] mappedObj:mappedItems){
			
			BakeryMappedResultWrapper wrapperVO=new BakeryMappedResultWrapper();
			BakeryMappedItemVO sourceItemVO=new BakeryMappedItemVO();
			BakeryMappedItemVO targetItemVO=new BakeryMappedItemVO();
			
			createMappedSource(mappedObj, sourceItemVO);
		
		    createMapppedTarget(mappedObj, targetItemVO);
		    
		    wrapperVO.setSource(sourceItemVO);
		    wrapperVO.setTarget(targetItemVO);
		    wrapperVO.setMappingType(getStringValue((mappedObj[18] != null ? (mappedObj[18]) : null)));
		    maddedItems.add(wrapperVO);
		}
		
		return maddedItems;
	}

	private void createMapppedTarget(Object[] mappedObj,
			BakeryMappedItemVO targetItemVO) {
		targetItemVO.setTargetCIC((BigDecimal)(mappedObj[10] != null ? (mappedObj[10]) : null));
		targetItemVO.setItemDesc(getStringValue((mappedObj[11] != null ? (mappedObj[11]) : null)));
		targetItemVO.setVcf((BigDecimal)(mappedObj[12] != null ? (mappedObj[12]) : null));
		targetItemVO.setPack((BigDecimal)(mappedObj[13] != null ? (mappedObj[13]) : null));
		targetItemVO.setSize((BigDecimal)(mappedObj[14] != null ? (mappedObj[14]) : null));
		targetItemVO.setUsage(convertToChar((mappedObj[15] != null ? (mappedObj[15]) : null)));
		targetItemVO.setDisplay(convertToChar((mappedObj[16] != null ? (mappedObj[16]) : null)));
		targetItemVO.setCreatedOn(parseDate((Timestamp)(mappedObj[17] != null ? (mappedObj[17]) : null)));
	}

	private void createMappedSource(Object[] mappedObj,
			BakeryMappedItemVO sourceItemVO) {
		sourceItemVO.setSourceSKU(getStringValue((mappedObj[0] != null ? (mappedObj[0]) : null)));
		sourceItemVO.setItemDesc(getStringValue((mappedObj[1] != null ? (mappedObj[1]) : null)));
		sourceItemVO.setVcf((BigDecimal)(mappedObj[2] != null ? (mappedObj[2]) : null));
		sourceItemVO.setPack((BigDecimal)(mappedObj[3] != null ? (mappedObj[3]) : null));
		sourceItemVO.setSize((BigDecimal)(mappedObj[4] != null ? (mappedObj[4]) : null));
		sourceItemVO.setDisplay(convertToChar((mappedObj[5] != null ? (mappedObj[5]) : null)));
		sourceItemVO.setUpc(getStringValue((mappedObj[6] != null ? (mappedObj[6]) : null)));
		sourceItemVO.setCreatedOn(parseDate((Timestamp)(mappedObj[7] != null ? (mappedObj[7]) : null)));
		sourceItemVO.setLastSalesDate(parseDate((Timestamp)(mappedObj[8] != null ? (mappedObj[8]) : null)));
		sourceItemVO.setLastShipDate(parseDate((Timestamp)(mappedObj[9] != null ? (mappedObj[9]) : null)));
	}
	/**
	 * 
	 * @param upcArray
	 * @return
	 */
	private String appendPlus(String[] upcArray) {
		StringBuilder upcList = new StringBuilder("");
		if(upcArray!=null){
		for(int i =0;i< upcArray.length;i++)
		{
			if(Long.parseLong(upcArray[i])<100000)
				{
					 upcList.append(Long.parseLong(upcArray[i]));			    	
					 if(i< upcArray.length-1 ){
						 upcList.append(","); 
		    		 }
			 
				}
		}
		}
		return upcList.toString();
	}

	public PerishableAdditionalDetailsDto setAddtionalDetailsForRetail(
			Map resultMap) {
		PerishableAdditionalDetailsDto perishableAdditionalDetailsDto =new PerishableAdditionalDetailsDto();		
		
		Object count = resultMap.get("ROG_COUNT");
		List<Object[]> detailsList = (List<Object[]>) resultMap.get("RETAIL_SCAN_DETAIL");
		
		PerishableMappingRetailScanDetails additionalDetail =new PerishableMappingRetailScanDetails();
		
		Set rogSet= new HashSet();
		for(Object[] detailObj : detailsList)
		{
			String dstCntr=getStringValue((detailObj[0] != null ? (detailObj[0]) : null));
			BigDecimal vendCost =(BigDecimal)(detailObj[1] != null ? (detailObj[1]) : null);
			char dstStatus =convertToChar((detailObj[2] != null ? (detailObj[2]) : null));
			if(additionalDetail.getDstCntr()==null)
			{
				additionalDetail.setDstCntr(dstCntr);
				additionalDetail.setVendCost(vendCost);
				additionalDetail.setDstStatus(dstStatus);
				rogSet.add(detailObj[3] != null ? (detailObj[3]) : null);
			}
			else if(additionalDetail.getDstCntr().equals(dstCntr) &&
					additionalDetail.getVendCost().equals(vendCost)&&
					additionalDetail.getDstStatus()==dstStatus			
					
					)
			{
				rogSet.add(detailObj[3] != null ? (detailObj[3]) : null);
			}
			else
			{
				additionalDetail.setRogs(rogSet);					
				perishableAdditionalDetailsDto.addAdditonaldetais(additionalDetail);
				/* new set addition*/
				additionalDetail =new PerishableMappingRetailScanDetails();
				additionalDetail.setDstCntr(dstCntr);
				additionalDetail.setVendCost(vendCost);
				additionalDetail.setDstStatus(dstStatus);
				rogSet=new HashSet();
				rogSet.add(detailObj[3] != null ? (detailObj[3]) : null);		
				
			}		
						
			
		}
		additionalDetail.setRogs(rogSet);	
		perishableAdditionalDetailsDto.addAdditonaldetais(additionalDetail);
				
		perishableAdditionalDetailsDto.setRogCount((BigDecimal) count);
	
		return perishableAdditionalDetailsDto;
	}
	private Set convertToDistinctList(Object object) {
		Set distinctAppend =new HashSet();
		if(object!=null)
		{
			String[] items =object.toString().split(",");
			
			for(String item: items)
			{distinctAppend.add(item);				
			}			
					
		}
		return distinctAppend;
	}

	public ManualMapAdditionalLoadDto setOnMatchEditDto(List result,List<Object[]> skuWeightList) {

		ManualMapAdditionalLoadDto onMatchEditDto =null;
		boolean mUFlag =false;
			if(result.get(2)!=null )
			{
				List<Object[]> muchek =(List<Object[]>) result.get(2);
				Object[] mucountObj =muchek.get(0);
				if(Integer.parseInt(mucountObj[1].toString()) ==2)
				{
					mUFlag=true;	
				}
												
			}
			if(!result.isEmpty())
			{		
				onMatchEditDto =new ManualMapAdditionalLoadDto();
				/**Size details**/
					onMatchEditDto.addSizeDetails((List<Object[]>) result.get(0));
				/***/
					/*Rog details*/
					onMatchEditDto.addRogDetails((List<Object[]>) result.get(1),(List<Object[]>) result.get(3));	
					onMatchEditDto.setMultiUnitFlag(mUFlag);
				
			}
			if(onMatchEditDto!=null && skuWeightList!=null)
			{
				/*Prod Wt details*/
				for(Object[] obje : skuWeightList)
				{
					onMatchEditDto.addProdWtDetails(obje);
					onMatchEditDto.overrideWithSourceCost(obje);
				}
			}	
		
		return onMatchEditDto;
		
	}

}
