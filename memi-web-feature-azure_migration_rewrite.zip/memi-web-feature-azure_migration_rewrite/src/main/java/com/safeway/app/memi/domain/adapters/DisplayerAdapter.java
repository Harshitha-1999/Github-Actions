package com.safeway.app.memi.domain.adapters;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemUnMapDto;
/**
 ****************************************************************************
 * NAME			: DisplayerAdapter 
 * 
 * DESCRIPTION	: DisplayerAdapter is the class for 
 * 				  mapping values fetched from DB to corresponding VO object
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: u51095
 * *************************************************************************
 */

public class DisplayerAdapter {
	
	public List<DisplayItemDetail> mapToDisplayItemDetail(
			List<Object[]> displayitemdetail) {
		Set<DisplayItemDetail> displayItemDetailList = new LinkedHashSet<>();
		for (Object[] obj : displayitemdetail){
			DisplayItemDetail disp = new DisplayItemDetail();
			disp.setProductSku(getStringValue(obj[0]));
			disp.setItemDesc(getStringValue(obj[1]));
			disp.setShippingPackNumber(getBigDecimalValue(obj[2]));
			disp.setMasterCasePackNumber(getBigDecimalValue(obj[3]));
			disp.setSizeNumber(getBigDecimalValue(obj[4]));
			disp.setMultiComponentItemInd(getStringValue(obj[5]));
			disp.setCaseUpc(getStringValue(obj[6]));
			disp.setOnHandQty(BigDecimal.valueOf(getDoubleValue(obj[7])));
			disp.setOnOrderQty(BigDecimal.valueOf(getDoubleValue(obj[8])));
			disp.setSlot(getStringValue(obj[9]));
			disp.setItemCreateDate(getDate(obj[10]));
			//whse
			if(getStringValue(obj[16]).equals("Y")){
				disp.setCost(getBigDecimalValue(obj[14]));
				disp.setLastShipDate(getDate (obj[12]));
			}
			//dsd
			if(getStringValue(obj[17]).equals("Y")){
				disp.setCost(getBigDecimalValue(obj[13]));
				disp.setLastShipDate(getDate (obj[11]));
			}
			disp.setOneTimeBuyFlag(getStringValue(obj[15]));
			disp.setProductSourceCode(updateSourceBasedOnDsdAndWhse(getStringValue(obj[16]),getStringValue(obj[17])));
			displayItemDetailList.add(disp);
		}
		
		return new ArrayList<>(displayItemDetailList);
	}
	
	public List<DisplayItemUnMapDto> mapToDisplayItemUnmapDto(
			List<Object[]> objList) {
		List<DisplayItemUnMapDto> itemList = new ArrayList<>();
		Set<String> convStatusCode=new HashSet<>();
		DisplayItemUnMapDto item = null;
		for (Object[] obj : objList) {
			item=new DisplayItemUnMapDto();
			item.setCompanyId(getStringValue(obj[0]));
			item.setDivisionId(getStringValue(obj[1]));
			item.setProductSku(getStringValue(obj[2]));
			item.setUpcCountry(getBigDecimalValue(obj[3]));
			item.setUpcSystem(getBigDecimalValue(obj[4]));
			item.setUpcManuf(getBigDecimalValue(obj[5]));
			item.setUpcSales(getBigDecimalValue(obj[6]));
			item.setConvStatusCode(getStringValue(obj[7]));
			convStatusCode.add(getStringValue(obj[7]));
			item.setConvStatusCodeSet(convStatusCode);
			itemList.add(item);
		}
		return itemList;
	}

	

	private String updateSourceBasedOnDsdAndWhse(String whse, String dsd) {
		String dsdOrWhse=null;
		if(whse.equals("Y")){
			dsdOrWhse="WHSE";
		}
		if(dsd.equals("Y")){
			dsdOrWhse="DSD";
		}
		return dsdOrWhse;
	}
	
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}
	private Double getDoubleValue(Object obj){
		if(obj == null)
			return new Double(0);
		return (Double) obj;
	}
	/**
	 * @param obj
	 * @return
	 */
	private String getStringValue(Object obj){
		if(obj == null)
			return "";
		return ((String) obj).trim();
	}
	
	private String getDate(Object obj){
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		if(obj == null){
			return "";
		}
		else{
			return formatter.format((Date) obj);
		}
	}
}
