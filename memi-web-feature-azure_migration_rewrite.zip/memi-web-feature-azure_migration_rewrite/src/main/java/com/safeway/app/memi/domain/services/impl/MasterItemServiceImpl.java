package com.safeway.app.memi.domain.services.impl;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.repositories.MasterDataRepository;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.services.MasterItemService;

/**
 * 
 * Implementation class for Master Item Services
 *
 */
@Service("masterItemService")
public class MasterItemServiceImpl implements MasterItemService {
	private static final Logger LOG  = LoggerFactory.getLogger(MasterItemServiceImpl.class);

    @Autowired
    private MasterDataRepository masterDataRepo;
    
    /* (non-Javadoc)
     * @see com.safeway.app.memi.domain.services.MasterItemService#killItem(com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto)
     */
    @Override
	public boolean killItem(UIExceptionSrcDto srcDto, String reason) {
    	LOG.info("Execution started to kill Item ");
    	
    	List<UPCVo> volist=srcDto.getUpcVoList();
    	boolean saveSuccess = true;
    	for (UPCVo upcVo : volist) {
    		String[] upc=upcVo.getUpc().split("-");
    		List<ItemXrefData> records = masterDataRepo.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionIdAndItemPkUpcCountryAndItemPkUpcSystemAndItemPkUpcManuAndItemPkUpcSales(srcDto.getProductSKU(), srcDto.getCompanyId(), srcDto.getDivisionId(), Integer.valueOf(StringUtils.leftPad(upc[0], 0, "0")), Integer.valueOf(StringUtils.leftPad(upc[1], 0, "0")), Integer.valueOf(StringUtils.leftPad(upc[2], 5, "0")),Integer.valueOf(StringUtils.leftPad(upc[3], 5, "0")));
   		 

    		if(records == null)
			return true;
    	LOG.debug("Completed fetching for"+records.size()+"Item Xref Data records " );
    	Iterator<ItemXrefData> recordsIter = records.iterator();
		ItemXrefData xrefRec = null;
		ItemXrefData savedData = null;
		while(recordsIter.hasNext()){
			xrefRec = recordsIter.next();
			if(!(xrefRec.getConvStatusCode().equals("D") || xrefRec.getConvStatusCode().equals("O"))){
				xrefRec.setConvStatusCode("D");
				xrefRec.setConvStatusSubCode("B");
				xrefRec.setConvStatusDesc("Dead Item - Business assigned status.");	
				xrefRec.setUpdatedUserId(srcDto.getUpdatedUserID());
				xrefRec.setStatusReasonText(reason);
				savedData = masterDataRepo.save(xrefRec);
			}
			if(savedData == null)
				saveSuccess = false;
		}
    	}
    	LOG.info("Execution completed to kill Item ");

		return saveSuccess;
	}
    
    @Override
   	public boolean updateItemStatusXRF(UIExceptionSrcDto srcDto, String reason) {
    	LOG.info("Execution started to update Item Status XRF ");

    	List<UPCVo> volist=srcDto.getUpcVoList();
    	boolean saveSuccess = true;
    	for (UPCVo upcVo : volist) {
    		String[] upc=upcVo.getUpc().split("-");
    		List<ItemXrefData> records = masterDataRepo.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionIdAndItemPkUpcCountryAndItemPkUpcSystemAndItemPkUpcManuAndItemPkUpcSales(srcDto.getProductSKU(), srcDto.getCompanyId(), srcDto.getDivisionId(), Integer.valueOf(StringUtils.leftPad(upc[0], 0, "0")), Integer.valueOf(StringUtils.leftPad(upc[1], 0, "0")), Integer.valueOf(StringUtils.leftPad(upc[2], 5, "0")),Integer.valueOf(StringUtils.leftPad(upc[3], 5, "0")));
    		 LOG.debug("Completed fetching for"+records.size()+"Item Xref Data records " );
    		if(records == null)
       			return true;
       		Iterator<ItemXrefData> recordsIter = records.iterator();
       		ItemXrefData xrefRec = null;
       		ItemXrefData savedData = null;
       		
       		String statusCode = null;
       		String statusSubCode = null;
       		String statusDesc = null;
       		String statusReasonText = null;
       		// updating ITEM_XRF status to convert through auto conversion process (through MIDAS)
       		if (reason.equals("A")){
       			statusCode="R";
       			statusSubCode="A";
       			statusDesc="Ready for Auto Conversion";
       			statusReasonText="Ready for Auto Conversion";
       		}
       	// Updating item out of conversion to the auto conversion process (For Manual mapping process)
       		if (reason.equals("O")){
       			statusCode="O";
       			statusSubCode="U";
       			statusDesc="Old Conversion";
       			statusReasonText="Old Conversion";
       		}
       		while(recordsIter.hasNext()){
       				xrefRec = recordsIter.next();
       				if(!(xrefRec.getConvStatusCode().equals("D") || xrefRec.getConvStatusCode().equals("O"))){
       					xrefRec.setConvStatusCode(statusCode);
       					xrefRec.setConvStatusSubCode(statusSubCode);
       					xrefRec.setConvStatusDesc(statusDesc);	
       					xrefRec.setUpdatedUserId(srcDto.getUpdatedUserID());
       					xrefRec.setStatusReasonText(statusReasonText);
       					savedData = masterDataRepo.save(xrefRec);
       				}
       				
       			if(savedData == null)
       				saveSuccess = false;
       		}
		}
    	
    	LOG.info("Execution completed to update Item Status XRF ");

   		return saveSuccess;

   	}
       

}