package com.safeway.app.memi.domain.services.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.memi.data.entities.ItemConvBulkUploadTracking;
import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.ItemXrefPk;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.NewItemDetailPk;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.ItemConvBulkUploadRepository;
import com.safeway.app.memi.data.repositories.MasterDataRepository;
import com.safeway.app.memi.data.repositories.NewItemDetailRepository;
import com.safeway.app.memi.data.repositories.SMICDetailRepository;
import com.safeway.app.memi.data.repositories.SizeUOMDetailRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.dtos.response.BulkUploadTrackingDto;
import com.safeway.app.memi.domain.dtos.response.ExcelFileDto;
import com.safeway.app.memi.domain.dtos.response.ExcelFileKey;
import com.safeway.app.memi.domain.dtos.response.ExcelFileRequest;
import com.safeway.app.memi.domain.dtos.response.ExcelFileRow;
import com.safeway.app.memi.domain.services.FileUploadService;
import com.safeway.app.memi.domain.util.EmailFacilitator;

@Service("FileUploadService")
public class FileUploadServiceImpl implements FileUploadService {
	
	private static final Logger logger = LoggerFactory.getLogger(FileUploadServiceImpl.class);
	
	@Autowired
	private ItemConvBulkUploadRepository itemConvBulkUploadRepository;
	
	@Autowired
	private NewItemDetailRepository newItemRepo;
	 
	@Autowired
	private EmailFacilitator email;
	
	@Autowired
	private CommonSQLRepository commonSQLRepo;
	
	@Autowired
	private UIExceptionSrcRepository exceptionRepo;
	
	@Autowired
    private MasterDataRepository masterDataRepo;
	
	@Autowired
	private SMICDetailRepository smicDetailnRepo;

	@Autowired
	private SizeUOMDetailRepository sizeUOMDetailnRepo;

	@Value("${memi.mail.fromAddress}")
    private String fromAddress;
	
	@Value("${file.path}")
    private String file;

	/* 
	 * U -Upload Started 
	 * V -Validation Started 
	 * D -Database Transaction Started 
	 * M -Mailing Started 
	 * C -Transaction Complete
	 */
private void processExcelFileWithoutSave(ExcelFileRequest fReq,ItemConvBulkUploadTracking obj) throws AddressException {

logger.debug("Execution started for process Excel File Without Save");
	
	try {
			Map<ExcelFileKey, ExcelFileDto> excelMap = readRecordFromExcelFilePutInMap(fReq);
			Set<String> validProductSkuSet = new HashSet<>();
			Set<String> invalidProductSkuSet = new HashSet<>();
			Map<String,List<String>> invalidProductSkuMap=new HashMap<>();
			if (!excelMap.isEmpty() && excelMap.size() > 0) {
				updateStatusToDatabase(obj, "V", new BigDecimal(0), new BigDecimal(0),"File read method execution completed");
				excelMap=buildValidMapAfterMarkDead(excelMap,fReq);
				updateStatusToDatabase(obj, "V", new BigDecimal(0), new BigDecimal(0),"Mark dead method execution completed");
				validatedProductSkusFromExcel(excelMap,validProductSkuSet,invalidProductSkuSet,invalidProductSkuMap);
				updateStatusToDatabase(obj, "V", new BigDecimal(validProductSkuSet.size()).add(new BigDecimal(invalidProductSkuSet.size())), new BigDecimal(validProductSkuSet.size()),"Validation completed");
				Map<ExcelFileKey, ExcelFileDto> validExcelMap = findValidRecorFromExcelBasedOnValidProductSku(excelMap,validProductSkuSet);
				logger.debug("Completed fetching all"+validExcelMap.size()+"find Valid Record From Excel");
				if ((!validExcelMap.isEmpty() && validExcelMap.size() > 0)) {
					updateStatusToDatabase(obj, "V", new BigDecimal(validProductSkuSet.size()).add(new BigDecimal(invalidProductSkuSet.size())), new BigDecimal(validProductSkuSet.size()),"Validation map created");
					List<Object[]> dbRecord = commonSQLRepo.fetchRecordBasedOnCompanyIdDivisionIdProductSkuSetFromUiExceptionSource(fReq.getCompanyId(), fReq.getDivisionId(),validProductSkuSet);
					logger.debug("Completed fetching all"+dbRecord.size()+"Record Based On CompanyId DivisionId ProductSkuSet");
					if (!dbRecord.isEmpty()) {
						Map<ExcelFileKey, ExcelFileRow> dbMap = buildLikeItemDetailDtoListAsMap(dbRecord);
						logger.debug("Completed fetching all"+dbMap.size()+"buil dLike Item Detail Dto ListAsMap");
						updateStatusToDatabase(obj, "V", new BigDecimal(validProductSkuSet.size()).add(new BigDecimal(invalidProductSkuSet.size())), new BigDecimal(validProductSkuSet.size()),"Final record creation for db transaction started");
						Map<ExcelFileKey, ExcelFileRow> finalMapForValidation = buildFinalMapForValidation(validExcelMap, dbMap,validProductSkuSet,invalidProductSkuSet,invalidProductSkuMap);
						logger.debug("Completed fetching all"+finalMapForValidation.size()+"final Map For Validation");
						updateStatusToDatabase(obj, "D", new BigDecimal(validProductSkuSet.size()).add(new BigDecimal(invalidProductSkuSet.size())), new BigDecimal(validProductSkuSet.size()),"Database transaction started");
						saveExcelDataToDatabase(finalMapForValidation, obj,validProductSkuSet,invalidProductSkuSet,invalidProductSkuMap);
						updateStatusToDatabase(obj, "M", new BigDecimal(validProductSkuSet.size()).add(new BigDecimal(invalidProductSkuSet.size())), new BigDecimal(validProductSkuSet.size()),"Mailing started");
						sendEmail(fReq.getUserId(),obj.getFileName(),invalidProductSkuSet,invalidProductSkuMap);
						updateStatusToDatabase(obj, "C", new BigDecimal(validProductSkuSet.size()).add(new BigDecimal(invalidProductSkuSet.size())), new BigDecimal(validProductSkuSet.size()),"Transaction completed");
					}else{
						sendEmail(fReq.getUserId(),obj.getFileName(),invalidProductSkuSet,invalidProductSkuMap);
					}
				}else{
					sendEmail(fReq.getUserId(),obj.getFileName(),invalidProductSkuSet,invalidProductSkuMap);
				}
			}
		} catch (IOException e) {
			e.getStackTrace();
			logger.error(e.getMessage());
		}
	
	logger.debug("Execution Completed for process Excel File Without Save");
	}

	private Map<ExcelFileKey, ExcelFileDto> buildValidMapAfterMarkDead(Map<ExcelFileKey, ExcelFileDto> excelMap,ExcelFileRequest fReq) {

         logger.debug("Execution started for build Valid Map After Mark Dead"); 
		
		Map<ExcelFileKey, ExcelFileDto> validMap= new HashMap<>();
		Map<ExcelFileKey, ExcelFileDto> markDeadMap= new HashMap<>();
		Set<String> productSkuSet= new HashSet<>();
		if(!excelMap.isEmpty()){
			Collection<ExcelFileDto> excelFileDto = excelMap.values();
		    Iterator<ExcelFileDto> itrExcelFileDto = excelFileDto.iterator();
		    while (itrExcelFileDto.hasNext()) {			
		    	ExcelFileDto exlObj= itrExcelFileDto.next();
		    	ExcelFileKey excelFileKey=new ExcelFileKey(exlObj.getProductSku(),exlObj.getUpc());
		    	if(!markDeadMap.containsKey(excelFileKey)){
		    		if(!exlObj.getAction().equalsIgnoreCase("D"))
					{
						validMap.put(excelFileKey, exlObj);
					}else{
						productSkuSet.add(exlObj.getProductSku());
						markDeadMap.put(excelFileKey, exlObj);
					}
				}
			}
		}
		if(!markDeadMap.isEmpty()){
			markMultipleItemAsDead(markDeadMap,fReq,productSkuSet);
		}
		logger.debug("Execution Completed for "+validMap.size()+" build Valid Map After Mark Dead");
		return validMap;
	}
	

	private void markMultipleItemAsDead(Map<ExcelFileKey, ExcelFileDto> markDeadMap,ExcelFileRequest fReq,Set<String> productSkuSet) {
		logger.debug("Started eXEcUtInG to mark Multiple Item As Dead");
		List<Object[]> dbRecord= commonSQLRepo.fetchRecordBasedOnCompanyIdDivisionIdProductSkuSet(productSkuSet,fReq.getCompanyId(),fReq.getDivisionId());
		List<ItemXrefData> xrefList=mapDbRecordToItemXrefData(dbRecord);
		Map<ExcelFileKey, ItemXrefData> finalMap=buildMapFromItemXrefDataList(xrefList);
		List<ItemXrefData> itemXrefList=new ArrayList<>();
		for (Map.Entry<ExcelFileKey, ItemXrefData> entry : finalMap.entrySet()) {
			ExcelFileKey excelFileKey=entry.getKey();
			ItemXrefData entryValue=entry.getValue();
			if (markDeadMap.containsKey(excelFileKey)) {
				entryValue.setUpdatedUserId(fReq.getUserId());
				String statusReasonText="Item marked as dead via excel import";
				String excelComment=markDeadMap.get(excelFileKey).getConvTeamComments();
				if(excelComment.equals("") || excelComment.isEmpty()){
					entryValue.setStatusReasonText(statusReasonText);
				}else{
					entryValue.setStatusReasonText(excelComment);
				}
				itemXrefList.add(entryValue);
			}
		}
		logger.debug("completed eXEcUtInG to mark Multiple Item As Dead");
		commonSQLRepo.markExcelItemAsDead(itemXrefList);
	}
	

	private Map<ExcelFileKey, ItemXrefData> buildMapFromItemXrefDataList(List<ItemXrefData> itemXrefDataList) {

             logger.debug("Execution started for final Item Xref DataMap");
		Map<ExcelFileKey, ItemXrefData> finalItemXrefDataMap=new HashMap<>();
		for (ItemXrefData itemXrefData : itemXrefDataList) {
			String upcCountry=StringUtils.leftPad(itemXrefData.getItemPk().getUpcCountry().toString(), 1, "0");
			String upcSystem=StringUtils.leftPad(itemXrefData.getItemPk().getUpcSystem().toString(), 1, "0");
			String upcManuf=StringUtils.leftPad(itemXrefData.getItemPk().getUpcManu().toString(), 5, "0");
			String upcSales=StringUtils.leftPad(itemXrefData.getItemPk().getUpcSales().toString(), 5, "0");
			String upc=new StringBuilder().append(upcCountry+"-").append(upcSystem+"-").append(upcManuf+"-").append(upcSales).toString();
			ExcelFileKey key=new ExcelFileKey(itemXrefData.getItemPk().getProdSku(),upc);
			finalItemXrefDataMap.put(key, itemXrefData);
		}

         logger.debug("Execution completed for "+finalItemXrefDataMap.size()+" for undo Create NewCic");
		return finalItemXrefDataMap;
	}

	private List<ItemXrefData>  mapDbRecordToItemXrefData(List<Object[]> dbRecord) {

         logger.debug("Execution started for map Db Record To Item XrefData");
		List<ItemXrefData> xrefList=new ArrayList<>();
		for (Object[] xrefObj : dbRecord) {
			ItemXrefData xref=new ItemXrefData();
			ItemXrefPk xrefPk=new ItemXrefPk();
			xrefPk.setCompanyId(getStringValue(xrefObj[0]));
			xrefPk.setDivisionId(getStringValue(xrefObj[1]));
			xrefPk.setProdSku(getStringValue(xrefObj[2]));
			xrefPk.setRog(getStringValue(xrefObj[10]));
			xrefPk.setSrcSupplierNum(getStringValue(xrefObj[9]));
			xrefPk.setUpcCountry(getBigDecimalValue(xrefObj[5]).intValue());
			xrefPk.setUpcSystem(getBigDecimalValue(xrefObj[6]).intValue());
			xrefPk.setUpcManu(getBigDecimalValue(xrefObj[7]).intValue());
			xrefPk.setUpcSales(getBigDecimalValue(xrefObj[8]).intValue());
			xref.setItemPk(xrefPk);
			xref.setConvStatusCode(getStringValue(xrefObj[3]));
			xref.setConvStatusSubCode(getStringValue(xrefObj[4]));
			xrefList.add(xref);
		}

        logger.debug("Execution Completed for "+xrefList.size()+" map Db Record To  ItemXrefData");
		return xrefList;
	}

	public String uploadExcel(final ExcelFileRequest excelFileRequest) {
		logger.info("Execution started for uploadExcel()");
		String message = null;
		MultipartFile uploadedExcelFile=excelFileRequest.getFile();
		String timeStamp=new SimpleDateFormat("yyyyMMddHHmmss").format(new java.sql.Timestamp(System.currentTimeMillis()));
		String fileName = uploadedExcelFile.getOriginalFilename();
		StringBuilder excelFileName=new StringBuilder("");
		if (!uploadedExcelFile.isEmpty() && fileName!= null) {
			excelFileName.append(fileName.replaceAll(".xlsx", "-")).append(timeStamp).append(".xlsx");
			try {
				String comment="Upload Started";
				BulkUploadTrackingDto bulkDto= mapFieldToBulkUploadTrackingDto(excelFileRequest,excelFileName.toString(),comment,"U",new BigDecimal(0),new BigDecimal(0));
				final ItemConvBulkUploadTracking obj=saveStatusToDatabase(bulkDto);
				ExecutorService executorService = Executors.newSingleThreadExecutor();
				executorService.execute(new Runnable() {
				    public void run() {
				    	logger.info("Execution started for ExecutorService execute() method");
				    	try {
							processExcelFileWithoutSave(excelFileRequest,obj);
						} catch (AddressException e) {
							e.getStackTrace();
							logger.error("Error occured inside processExcelFileWithoutSave() method"+e.getMessage());
						}
				    	logger.info("Execution completed for ExecutorService execute() method");
				    }
				    
				});
				executorService.shutdown();
				logger.info("ExecutorService executorService.shutdown() method called");
				message = "SUCCESS";
				logger.info("You successfully uploaded file="+ excelFileName);
			} catch (Exception e) {
				message = "FAILURE";
				logger.error("You failed to upload " + excelFileName + " => "+ e.getMessage());
			}
		} else {
			message = "EMPTY";
			logger.info("You failed to upload " + excelFileName+ " because the file was empty OR filename is null.");
		}
		logger.info("Execution completed for uploadExcel().");
		return message;
	}
	
	public File multipartToFile(MultipartFile multipart) throws  IOException, IllegalStateException
	{
		logger.info("Exectution started for  multipart To File()");
	    File convFile = new File(file+"tmp.xlsx");
	    multipart.transferTo(convFile);
	    logger.info("File copy completed");
	    return convFile;
	}
	
	private Map<ExcelFileKey, ExcelFileDto> readRecordFromExcelFilePutInMap(ExcelFileRequest fReq) throws IOException, IllegalStateException {
		logger.debug("Execution started for read Record From Excel File PutInMap()");
		Map<ExcelFileKey, ExcelFileDto> listRecords = new HashMap<>();
		File file=multipartToFile(fReq.getFile());
		// Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();
		try (FileInputStream inputStream = new FileInputStream(file)) {
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet sheetName = workbook.getSheetAt(0);
			Iterator<Row> rowIterartor = sheetName.iterator();
			while (rowIterartor.hasNext()) {
				Row row = rowIterartor.next();
				//just skip the rows if row number is 0
				if(row.getRowNum()==0){
					   continue; 
				}
				Iterator<Cell> cellIterator = row.cellIterator();
				List<String> cellValue=new ArrayList<>();
		         while (cellIterator.hasNext()) {
		             Cell cell = cellIterator.next();
		             cellValue.add(dataFormatter.formatCellValue(cell));
		         }
		        ExcelFileDto record=mapToExcelFileRow(cellValue,fReq);
		        if(record.getProductSku() != null && !record.getProductSku().equals("") &&
		        		record.getUpc() != null && !record.getUpc().equals("")		
		        		)
		        {
				listRecords.put(new ExcelFileKey(record.getProductSku(), record.getUpc()),record);
			}
				
			}
		}
		catch (Exception e) {
			e.getStackTrace();
			logger.error("Error occurred while reading file "+ e.getMessage());
		}
		 logger.debug("Execution completed for read Record From Excel File PutInMap().");
		return listRecords;
	}
	
	private boolean validateExcelFileColumn(ExcelFileDto saveItem,Map<String,List<String>> updIndTypeHm,Map<String,Set<String>> productionCodeMap,Map<String,List<String>> validationHashMap,Map<String,List<String>> invalidProductSkuMap)
	{
		logger.debug("Execution started for validate Excel FileColumn");
		boolean dataValid = true;
		List<String> exceptionColumnName=validationHashMap.get("exceptionColumnList");
		
		List<String> rejectedColumnList=new ArrayList<>();
		if (saveItem == null) {
			return false;
		}else{
			if (saveItem.getUpdItemDesc() == null || saveItem.getUpdItemDesc().isEmpty()) {
				if(!rejectedColumnList.contains(exceptionColumnName.get(0))){
					rejectedColumnList.add(exceptionColumnName.get(0));
				}
				dataValid= false;
			}
			if(saveItem.getUpdWhseItemDesc() == null || saveItem.getUpdWhseItemDesc().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(1))){
					rejectedColumnList.add(exceptionColumnName.get(1));
				}
				dataValid= false;
			}
			if(saveItem.getUpdRtlItemDesc() == null || saveItem.getUpdRtlItemDesc().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(2))){
					rejectedColumnList.add(exceptionColumnName.get(2));
				}
				dataValid= false;
			}
			if(saveItem.getUpdInternetItemDesc() == null || saveItem.getUpdInternetItemDesc().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(3))){
					rejectedColumnList.add(exceptionColumnName.get(3));
				}
				dataValid= false;
			}
			if(saveItem.getUpdPosDesc() == null || saveItem.getUpdPosDesc().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(4))){
					rejectedColumnList.add(exceptionColumnName.get(4));
				}
				dataValid= false;
			}
			if(saveItem.getUpdSize() == null || saveItem.getUpdSize().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(14))){
					rejectedColumnList.add(exceptionColumnName.get(14));
				}
				dataValid= false;
			}
			if(saveItem.getUpdSizeNmbr() == null || saveItem.getUpdSizeNmbr().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(15))){
					rejectedColumnList.add(exceptionColumnName.get(15));
				}
				dataValid= false;
			}
			if(saveItem.getUpdSizeUom() == null || saveItem.getUpdSizeUom().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(16))){
				rejectedColumnList.add(exceptionColumnName.get(16));
				}
				dataValid= false;
			}
			if(saveItem.getRetailUnitPack() == null || saveItem.getRetailUnitPack().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(18))){
					rejectedColumnList.add(exceptionColumnName.get(18));
					}
				dataValid= false;
			}else{
				if(!saveItem.getRetailUnitPack().matches("[0-9]*")){
					if(!rejectedColumnList.contains(exceptionColumnName.get(18))){
						rejectedColumnList.add(exceptionColumnName.get(18));
						}
					dataValid= false;
				}
				if(saveItem.getRetailUnitPack().equals("0")){
					if(!rejectedColumnList.contains(exceptionColumnName.get(18))){
						rejectedColumnList.add(exceptionColumnName.get(18));
						}
					dataValid= false;
				}
			}
			if(saveItem.getInnerPack() == null || saveItem.getInnerPack().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(17))){
					rejectedColumnList.add(exceptionColumnName.get(17));
					}
				dataValid= false;
			}else{
				if(!saveItem.getInnerPack().matches("[0-9]*")){
					if(!rejectedColumnList.contains(exceptionColumnName.get(17))){
						rejectedColumnList.add(exceptionColumnName.get(17));
						}
					dataValid= false;
				}
			}
			if(saveItem.getGrpCd() == null || saveItem.getGrpCd().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(5))){
					rejectedColumnList.add(exceptionColumnName.get(5));
					}
				dataValid= false;
			}
			if(saveItem.getCtgryCd() == null || saveItem.getCtgryCd().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(6))){
					rejectedColumnList.add(exceptionColumnName.get(6));
					}
				dataValid= false;
			}
			if(saveItem.getClsCd() == null || saveItem.getClsCd().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(7))){
					rejectedColumnList.add(exceptionColumnName.get(7));
					}
				dataValid= false;
			}
		   if(saveItem.getSbClsCd() == null || saveItem.getSbClsCd().isEmpty()){
			   if(!rejectedColumnList.contains(exceptionColumnName.get(8))){
					rejectedColumnList.add(exceptionColumnName.get(8));
					}
				dataValid= false;
			}
			if(saveItem.getSubSbClassCd() == null || saveItem.getSubSbClassCd().isEmpty()){
				if(!rejectedColumnList.contains(exceptionColumnName.get(9))){
					rejectedColumnList.add(exceptionColumnName.get(9));
					}
				dataValid= false;
			}
			if (saveItem.getPckTypeId()==null || saveItem.getPckTypeId().isEmpty()) {
				if(!rejectedColumnList.contains(exceptionColumnName.get(24))){
					rejectedColumnList.add(exceptionColumnName.get(24));
					}
				dataValid = false;
			}
			if (saveItem.getUpdSize()==null || saveItem.getUpdSize().isEmpty()) {
				if(!rejectedColumnList.contains(exceptionColumnName.get(14))){
					rejectedColumnList.add(exceptionColumnName.get(14));
					}
				dataValid = false;
			}
				String[] upcDetails=saveItem.getUpc().split("-");
				String upcSystem=upcDetails[1];
				String singleCharacterMatch = "[a-zA-Z]{1}";
				String codePattern = "[0-9]{1,2}";
				List<String> productionGroupCodeList=new ArrayList<>(productionCodeMap.get("productionGroupCode"));
				List<String> productionCategoryCodeList=new ArrayList<>(productionCodeMap.get("productionCategoryCode"));
				List<String> productionClassCodeList=new ArrayList<>(productionCodeMap.get("productionClassCode"));
				
				List<String> uomCodeList=validationHashMap.get("uomCodeList");
				List<String> smicCodeList=validationHashMap.get("smicCodeList");
				List<String> productClassCodeList=validationHashMap.get("productClassCodeList");
				List<String> updPrivateLabelList=validationHashMap.get("updPrivateLabelList");
				List<String> updDispflagList=validationHashMap.get("updDispflagList");
				List<String> updIndList=validationHashMap.get("updIndList");
				
				if ((null != saveItem.getUpdItemUsageInd() && !saveItem.getUpdItemUsageInd().isEmpty())) {
					if(saveItem.getUpdItemUsageInd().matches(singleCharacterMatch)){
						if(updIndList.contains(saveItem.getUpdItemUsageInd())){
							List<String> updIndTypeList = updIndTypeHm.get(saveItem.getUpdItemUsageInd());
							if (updIndTypeHm.containsKey(saveItem.getUpdItemUsageInd())) {
								if(!saveItem.getUpdItemUsageInd().equals("Q")){
									if (saveItem.getUpdItemUsageTypInd() != null && !saveItem.getUpdItemUsageTypInd().isEmpty()) {
										if(saveItem.getUpdItemUsageTypInd().matches(singleCharacterMatch)){
											if(!updIndTypeList.isEmpty() && !updIndTypeList.contains(saveItem.getUpdItemUsageTypInd())){
												if(!rejectedColumnList.contains(exceptionColumnName.get(20))){
													rejectedColumnList.add(exceptionColumnName.get(20));
													}
												dataValid = false;
											}
										}else{
											if(!rejectedColumnList.contains(exceptionColumnName.get(20))){
												rejectedColumnList.add(exceptionColumnName.get(20));
												}
											dataValid = false;
										}
									}
								}else{
									if (!saveItem.getUpdItemUsageTypInd().isEmpty()) {
										if(!rejectedColumnList.contains(exceptionColumnName.get(20))){
											rejectedColumnList.add(exceptionColumnName.get(20));
											}
										dataValid = false;
									}
								}
							}
						}else{
							if(!rejectedColumnList.contains(exceptionColumnName.get(19))){
								rejectedColumnList.add(exceptionColumnName.get(19));
							}
							dataValid = false;
						}
					}else{
						if(!rejectedColumnList.contains(exceptionColumnName.get(19))) {
							rejectedColumnList.add(exceptionColumnName.get(19));
						}
						dataValid = false;
					}
				}
				
				if ((null != saveItem.getUpdPrivateLabelInd() && !saveItem.getUpdPrivateLabelInd().isEmpty())) {
					if (saveItem.getUpdPrivateLabelInd().matches(singleCharacterMatch)) {
						if (!updPrivateLabelList.isEmpty() && !updPrivateLabelList.contains(saveItem.getUpdPrivateLabelInd())) {
							if(!rejectedColumnList.contains(exceptionColumnName.get(21))){
								rejectedColumnList.add(exceptionColumnName.get(21));
								}
							dataValid = false;
						}
					} else {
						if(!rejectedColumnList.contains(exceptionColumnName.get(21))){
							rejectedColumnList.add(exceptionColumnName.get(21));
							}
						dataValid = false;
					}
				}
				
				if ((null != saveItem.getUpdDispFlag() && !saveItem.getUpdDispFlag().isEmpty())) {
					if (saveItem.getUpdDispFlag().matches(singleCharacterMatch)) {
						if (!updDispflagList.isEmpty() && !updDispflagList.contains(saveItem.getUpdDispFlag())) {
							if(!rejectedColumnList.contains(exceptionColumnName.get(22))){
								rejectedColumnList.add(exceptionColumnName.get(22));
								}
							dataValid = false;
						}
					} else {
						if(!rejectedColumnList.contains(exceptionColumnName.get(22))){
							rejectedColumnList.add(exceptionColumnName.get(22));
							}
						dataValid = false;

					}
				}
				
				if ((null != saveItem.getUpdSizeNmbr() && !saveItem.getUpdSizeNmbr().isEmpty()) && !saveItem.getUpdSizeNmbr().matches("[0-9]*[.]{0,1}[0-9]*")) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(15))){
						rejectedColumnList.add(exceptionColumnName.get(15));
						}
					dataValid = false;
				}
				if ((null != saveItem.getEthnicTypeCd() && !saveItem.getEthnicTypeCd().isEmpty()) && (saveItem.getEthnicTypeCd().length()>2)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(23))){
						rejectedColumnList.add(exceptionColumnName.get(23));
						}
					dataValid = false;
				}
				if ((null != saveItem.getPckTypeId() && !saveItem.getPckTypeId().isEmpty()) && (!saveItem.getPckTypeId().matches("[0-9]{0,6}"))) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(24))){
						rejectedColumnList.add(exceptionColumnName.get(24));
						}
					dataValid = false;
				}
				if ((null != saveItem.getUpdSizeUom()  && !saveItem.getUpdSizeUom().isEmpty())) {
					if (saveItem.getUpdSizeUom().matches("[a-zA-Z]*")) {
						if (!uomCodeList.isEmpty() && !uomCodeList.contains(saveItem.getUpdSizeUom())) {
							if(!rejectedColumnList.contains(exceptionColumnName.get(16))){
								rejectedColumnList.add(exceptionColumnName.get(16));
								}
							dataValid = false;
						}
					} else {
						if(!rejectedColumnList.contains(exceptionColumnName.get(16))){
							rejectedColumnList.add(exceptionColumnName.get(16));
							}
						dataValid = false;
					}
				}
				
				if ((null != saveItem.getProductClsCd() && !saveItem.getProductClsCd().isEmpty()) 
						&& ((saveItem.getGrpCd() != null && !saveItem.getGrpCd().isEmpty()) && saveItem.getGrpCd().equals("84")) 
						&& (!productClassCodeList.isEmpty() && !productClassCodeList.contains(saveItem.getProductClsCd()))) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(13))){
						rejectedColumnList.add(exceptionColumnName.get(13));
						}
					dataValid = false;
				}
				
				StringBuilder smicCode=new StringBuilder().append(StringUtils.leftPad(saveItem.getGrpCd(), 2, "0")).append("-")
						.append(StringUtils.leftPad(saveItem.getCtgryCd(), 2, "0")).append("-").append(StringUtils.leftPad(saveItem.getClsCd(), 2, "0"))
						.append("-").append(StringUtils.leftPad(saveItem.getSbClsCd(), 2, "0")).append("-").append(StringUtils.leftPad(saveItem.getSubSbClassCd(), 2, "0"));
				
				if ((saveItem.getGrpCd() != null && !saveItem.getGrpCd().isEmpty()) 
						&& (saveItem.getCtgryCd()!=null && !saveItem.getCtgryCd().isEmpty())
						&& (saveItem.getClsCd()!=null && !saveItem.getClsCd().isEmpty()) 
						&& (saveItem.getSbClsCd()!=null && !saveItem.getSbClsCd().isEmpty())
						&& (saveItem.getSubSbClassCd()!=null && !saveItem.getSubSbClassCd().isEmpty())) {
					if(saveItem.getGrpCd().matches(codePattern) && saveItem.getCtgryCd().matches(codePattern) && saveItem.getClsCd().matches(codePattern)
							&& saveItem.getSbClsCd().matches(codePattern) && saveItem.getSubSbClassCd().matches(codePattern)){
						if(!smicCodeList.isEmpty() && !smicCodeList.contains(smicCode.toString())){
							if(!rejectedColumnList.contains(exceptionColumnName.get(26))){
								rejectedColumnList.add(exceptionColumnName.get(26));
								}
							dataValid = false;
						}
					}else{
						if(!rejectedColumnList.contains(exceptionColumnName.get(26))){
							rejectedColumnList.add(exceptionColumnName.get(26));
						}
						dataValid = false;
					}
				}else{
					if(!rejectedColumnList.contains(exceptionColumnName.get(26))){
						rejectedColumnList.add(exceptionColumnName.get(26));
					}
					dataValid = false;
				}
				
				if ((null != saveItem.getProductionGrpCd() && !saveItem.getProductionGrpCd().isEmpty()) && (!productionGroupCodeList.isEmpty() && !productionGroupCodeList.contains(saveItem.getProductionGrpCd()))) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(10))){
						rejectedColumnList.add(exceptionColumnName.get(10));
						}	
					dataValid = false;
				}
				
				if ((null != saveItem.getProductionCtgryCd() && !saveItem.getProductionCtgryCd().isEmpty()) && (!productionCategoryCodeList.isEmpty() && !productionCategoryCodeList.contains(saveItem.getProductionCtgryCd()))) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(11))){
						rejectedColumnList.add(exceptionColumnName.get(11));
						}	
					dataValid = false;
				}
				
				if ((null != saveItem.getProductionClsCd() && !saveItem.getProductionClsCd().isEmpty()) && (!productionClassCodeList.isEmpty() && !productionClassCodeList.contains(saveItem.getProductionClsCd()))) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(12))){
						rejectedColumnList.add(exceptionColumnName.get(12));
						}	
					dataValid = false;
				}
				
				String validSpecialChars = " .-/%&)";
				if (saveItem.getUpdItemDesc() != null && !isValidString(saveItem.getUpdItemDesc(), validSpecialChars)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(0))){
						rejectedColumnList.add(exceptionColumnName.get(0));
						}	
					dataValid = false;
				}

				if (saveItem.getUpdWhseItemDesc() != null && !isValidString(saveItem.getUpdWhseItemDesc(), validSpecialChars)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(1))){
						rejectedColumnList.add(exceptionColumnName.get(1));
						}	
					dataValid = false;
				}

				if (saveItem.getUpdRtlItemDesc() != null && !isValidString(saveItem.getUpdRtlItemDesc(), validSpecialChars)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(2))){
						rejectedColumnList.add(exceptionColumnName.get(2));
						}	
					dataValid = false;
				}

				if (upcSystem.equalsIgnoreCase("2") && saveItem.getUpdRtlItemDesc().length() > 32) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(2))){
						rejectedColumnList.add(exceptionColumnName.get(2));
						}
					dataValid = false;
				}

				if (saveItem.getUpdInternetItemDesc() != null && !isValidString(saveItem.getUpdInternetItemDesc(), validSpecialChars)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(3))){
						rejectedColumnList.add(exceptionColumnName.get(3));
						}
					dataValid = false;
				}

				String validSpecialCharsForPOS = " .-/%&)#";
				if (saveItem.getUpdPosDesc() != null && !isValidString(saveItem.getUpdPosDesc(), validSpecialCharsForPOS)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(4))){
						rejectedColumnList.add(exceptionColumnName.get(4));
						}
					dataValid = false;
				}
			/*	String validSpecialCharsForComments = ",.-/_#$%&)(";
				if (saveItem.getConvTeamComments() != null && !isValidString(saveItem.getConvTeamComments(), validSpecialCharsForComments)) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(25))){
						rejectedColumnList.add(exceptionColumnName.get(25));
						}
					dataValid = false;
				} */
				/*
				String regex = "^[a-zA-Z.,/' \")(-]+[0-9]*";
				if (saveItem.getConvTeamComments() != null && !saveItem.getConvTeamComments().trim().matches(regex) ) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(25))){
						rejectedColumnList.add(exceptionColumnName.get(25));
						}
					dataValid = false;
				}
				*/ 
				String updUpc ="";
				if(saveItem.getUpdUpc() != null && !saveItem.getUpdUpc().trim().equals(""))
				{
					updUpc =StringUtils.leftPad(saveItem.getUpdUpc().trim().replaceAll("-", ""), 12, "0");
				}
				
				if(Double.parseDouble(saveItem.getUpc().replaceAll("-", "")) >=100000 && updUpc.equals("") )
				{
					if(!rejectedColumnList.contains(exceptionColumnName.get(27)))
					{
					rejectedColumnList.add(exceptionColumnName.get(27));
					}
				dataValid = false;
				}
				else if (Double.parseDouble(saveItem.getUpc().replaceAll("-", "")) >= 100000 && !updUpc.matches("[0-9]{12}") ) {
					
					if( !rejectedColumnList.contains(exceptionColumnName.get(27)))
						{
						rejectedColumnList.add(exceptionColumnName.get(27));
						}
					dataValid = false;
				}
				
				if(Double.parseDouble(saveItem.getUpc().replaceAll("-", "")) <100000  &&  
					 (saveItem.getUpdPlu() == null || saveItem.getUpdPlu().trim().equals(""))						
						)
				{
					if(!rejectedColumnList.contains(exceptionColumnName.get(28))){
						rejectedColumnList.add(exceptionColumnName.get(28));
						}
					dataValid = false;
									
				}
				else if (saveItem.getUpdPlu() != null && !saveItem.getUpdPlu().trim().matches("[0-9]{1,5}") &&
						Double.parseDouble(saveItem.getUpc().replaceAll("-", "")) <100000 
						 ) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(28))){
						rejectedColumnList.add(exceptionColumnName.get(28));
						}
					dataValid = false;
				}
				
				
				
				if (saveItem.getDcPackDesc() != null && saveItem.getDcPackDesc().trim().length()>3 ) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(29))){
						rejectedColumnList.add(exceptionColumnName.get(29));
						}
					dataValid = false;
				}
				if (saveItem.getDcSizeDsc() != null && saveItem.getDcSizeDsc().trim().length()>7 ) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(30))){
						rejectedColumnList.add(exceptionColumnName.get(30));
						}
					dataValid = false;
				}
				if (saveItem.getRing() != null && !saveItem.getRing().trim().matches("[0-5]{1}") ) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(31))){
						rejectedColumnList.add(exceptionColumnName.get(31));
						}
					dataValid = false;
				}
				if (saveItem.getHicone() != null && !saveItem.getHicone().trim().matches("[0-2]{1}") ) {
					if(!rejectedColumnList.contains(exceptionColumnName.get(32))){
						rejectedColumnList.add(exceptionColumnName.get(32));
						}
					dataValid = false;
				}
				
				String singleCharRegExp ="[a-bA-Z0-9]{1}";
				String singleDigRegExp ="[0-9]{1}";
				String daysCountExp ="[0-9]{1,16}";
				
				if(saveItem.getProdwght()!=null && !saveItem.getProdwght().trim().equals("") && !saveItem.getProdwght().trim().matches("[0-9]{1,7}+[.]?[0-9]{0,4}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(33))){
						rejectedColumnList.add(exceptionColumnName.get(33));
						}
					dataValid = false;
					}
				if(saveItem.getHandlingCode()!=null && !saveItem.getHandlingCode().trim().equals("") && !saveItem.getHandlingCode().trim().matches("[0-9]{1,3}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(34))){
						rejectedColumnList.add(exceptionColumnName.get(34));
						}	
					dataValid = false;
					}
				if(saveItem.getBuyerNum()!=null && !saveItem.getBuyerNum().trim().equals("") && !saveItem.getBuyerNum().trim().matches("[a-bA-Z0-9]{1,2}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(35))){
						rejectedColumnList.add(exceptionColumnName.get(35));
						}
					dataValid = false;
					}
				if(saveItem.getRandomWtCd()!=null  && !saveItem.getRandomWtCd().trim().equals("") && !saveItem.getRandomWtCd().trim().matches("[R]{0,1}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(36))){
						rejectedColumnList.add(exceptionColumnName.get(36));
						}	
					dataValid = false;
					}
				if(saveItem.getAutoCostInv()!=null && !saveItem.getAutoCostInv().trim().equals("") && !saveItem.getAutoCostInv().trim().matches("[A,C,I]{1}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(37))){
						rejectedColumnList.add(exceptionColumnName.get(37));
						}
					dataValid = false;
					}
				if(saveItem.getBillingType()!=null  && !saveItem.getBillingType().trim().equals("") && !saveItem.getBillingType().trim().matches("[A]{0,1}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(38))){
						rejectedColumnList.add(exceptionColumnName.get(38));
						}
					dataValid = false;
					}
				if(saveItem.getFdStmp()!=null && !saveItem.getFdStmp().trim().equals("") && !saveItem.getFdStmp().trim().matches(singleDigRegExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(39))){
						rejectedColumnList.add(exceptionColumnName.get(39));
						}
					dataValid = false;
					}
				if(saveItem.getLabelSize()!=null && !saveItem.getLabelSize().trim().equals("") && !saveItem.getLabelSize().trim().matches("[M,N,S]{1}"))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(40))){
						rejectedColumnList.add(exceptionColumnName.get(40));
						}
					dataValid = false;
					}
				if(saveItem.getLabelNumbers()!=null && !saveItem.getLabelNumbers().trim().equals("") && !saveItem.getLabelNumbers().trim().matches(singleDigRegExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(41))){
						rejectedColumnList.add(exceptionColumnName.get(41));
						}
					dataValid = false;
					}
				if(saveItem.getSgnCount1()!=null && !saveItem.getSgnCount1().trim().equals("") && !saveItem.getSgnCount1().trim().matches(singleDigRegExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(42))){
						rejectedColumnList.add(exceptionColumnName.get(42));
						}
					dataValid = false;
					}
				if(saveItem.getSgnCount2()!=null && !saveItem.getSgnCount2().trim().equals("") && !saveItem.getSgnCount2().trim().matches(singleDigRegExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(43))){
						rejectedColumnList.add(exceptionColumnName.get(43));
						}
					dataValid = false;
					}
				if(saveItem.getSgnCount3()!=null && !saveItem.getSgnCount3().trim().equals("") && !saveItem.getSgnCount3().trim().matches(singleDigRegExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(44))){
						rejectedColumnList.add(exceptionColumnName.get(44));
						}
					dataValid = false;
					}
				if(saveItem.getSellByDays()!=null && !saveItem.getSellByDays().trim().equals("") && !saveItem.getSellByDays().trim().matches(daysCountExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(45))){
						rejectedColumnList.add(exceptionColumnName.get(45));
						}
					dataValid = false;
					}
				if(saveItem.getUseByDays()!=null && !saveItem.getUseByDays().trim().equals("") && !saveItem.getUseByDays().trim().matches(daysCountExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(46))){
						rejectedColumnList.add(exceptionColumnName.get(46));
						}
					dataValid = false;
					}
				if(saveItem.getPullBydays()!=null && !saveItem.getPullBydays().trim().equals("") && !saveItem.getPullBydays().trim().matches(daysCountExp))
					{
					if(!rejectedColumnList.contains(exceptionColumnName.get(47))){
						rejectedColumnList.add(exceptionColumnName.get(47));
						}
					dataValid = false;
					}
				if(saveItem.getTareCd()!=null && !saveItem.getTareCd().trim().equals("") && !saveItem.getTareCd().trim().matches("[0-9]{1,16}"))
				{
				if(!rejectedColumnList.contains(exceptionColumnName.get(48))){
					rejectedColumnList.add(exceptionColumnName.get(48));
					}
				dataValid = false;
				}
				
			
		}
		if(null !=saveItem.getProductSku() && !saveItem.getProductSku().isEmpty() && !rejectedColumnList.isEmpty()){
			if(!invalidProductSkuMap.containsKey(saveItem.getProductSku())){
				invalidProductSkuMap.put(saveItem.getProductSku(),rejectedColumnList);
			}else{
				Set<String> appendToExistingList=new HashSet<>();
				appendToExistingList.addAll(invalidProductSkuMap.get(saveItem.getProductSku()));
				appendToExistingList.addAll(rejectedColumnList);
				invalidProductSkuMap.put(saveItem.getProductSku(), new ArrayList<String>(appendToExistingList));
			}
		}
		logger.debug("Execution completed  for  validate Excel File Column");
		return dataValid;
	}
	
	private Boolean validateExcelFileRecord(ExcelFileDto excelFileDto,Map<String,List<String>> updIndTypeHm,Map<String,Set<String>> productionCodeMap,Map<String,List<String>> validationHashMap,Map<String,List<String>> invalidProductSkuMap) {

       logger.debug("Execution started for validate Excel File Record");
		Boolean status=false;
		if (!validateExcelFileColumn(excelFileDto,updIndTypeHm,productionCodeMap,validationHashMap,invalidProductSkuMap)) {
			status=false;
		}else{
			status=true;
		}
		logger.debug("Execution completed  for  validate Excel File Record");
		return status;
	}
	
	private void validatedProductSkusFromExcel(Map<ExcelFileKey, ExcelFileDto> excelDataMap,Set<String> validProductSkuSet,
	Set<String> invalidProductSkuSet ,Map<String,List<String>> invalidProductSkuMap) {
		logger.debug("Execution started  for  validated Product Skus From Excel");
		if(!excelDataMap.isEmpty()){
			
			List<Object[]> productionCodeList=commonSQLRepo.fetchProductionCode();
			Map<String,List<String>> validationHashMap=createValidationHashMap();
			Map<String,List<String>> updIndTypeHm= createUpdIndicatorTypeMap();
			Map<String,Set<String>> productionCodeMap= createProductionCodeMap(productionCodeList);
			
			for (Map.Entry<ExcelFileKey, ExcelFileDto> entry : excelDataMap.entrySet()) {
				ExcelFileDto excelFileDto = entry.getValue();
					Boolean valid = validateExcelFileRecord(excelFileDto,updIndTypeHm,productionCodeMap,validationHashMap,invalidProductSkuMap);
					if (valid) {
						validProductSkuSet.add(excelFileDto.getProductSku());
					} else {
						if(!validProductSkuSet.isEmpty() && validProductSkuSet.contains(excelFileDto.getProductSku())){
							validProductSkuSet.remove(excelFileDto.getProductSku());
						}
						invalidProductSkuSet.add(excelFileDto.getProductSku());
					}
			}
		}
		logger.debug("Execution completed  for  validated ProductSkus From Excel");
	} 
	
	private Map<String, List<String>> createValidationHashMap() {
		logger.debug("Execution started  for  create Validation HashMap");
		
		List<String> exceptionColumnList=new ArrayList<>(Arrays.asList("Upd Item Desc ","Upd Whse Item Desc ","Upd Rtl Item Desc ",
				"Upd Internet Item Desc ","Upd Pos Desc ","Group Code ","Category Code ","Class Code ",
				"Sub Class Code ","Sub Sub Class Code ","Production Group Code ","Production Category Code ",
				"Production Class Code ","Product Class Code ","Upd Size ","Upd Size Num ","Upd Size Uom ",
				"Inner Pack ","Retail Unit Pack ","Upd Item Usage Ind ","Upd Item Usage Type Ind ",
				"Upd Private Label Ind ","Upd Display Flag ","Ethnic Type Code ","Package Type Code ",
				"Conv Team Comments Txt ","Smic Code ","Upd UPC","Upd PLU Cd","Dc Pack Desc","Dc Size desc","Ring","Hicone",
				
				"Prod Weight","Handling Code","Buyer Num","Random Wt Cd","AutoCostInv", 
				"Billing Type","Food Stamp","Label Size","Label Numbers","Sgn Count1",
				"Sgn Count2","Sgn Count3","Sell By Days","Use By Days","Pull By Days","Tare"
				
				));
		
		List<String> uomCodeList=commonSQLRepo.fetchUomCode();
		List<String> smicCodeList=commonSQLRepo.fetchSmicCode();
		List<String> productClassCodeList=commonSQLRepo.fetchProductClassCode();
		List<String> updPrivateLabelList=new ArrayList<>(Arrays.asList("H","N","G"));
		List<String> updDispflagList= new ArrayList<>(Arrays.asList("Y","N"));
		List<String> updIndList= new ArrayList<>(Arrays.asList("R","Q","M","E"));
		Map<String,List<String>> validationHashMap= new HashMap<>();
		validationHashMap.put("uomCodeList", uomCodeList);
		validationHashMap.put("smicCodeList", smicCodeList);
		validationHashMap.put("productClassCodeList", productClassCodeList);
		validationHashMap.put("updPrivateLabelList", updPrivateLabelList);
		validationHashMap.put("updDispflagList", updDispflagList);
		validationHashMap.put("updIndList", updIndList);
		validationHashMap.put("exceptionColumnList", exceptionColumnList);
		logger.debug("Execution completed  for "+validationHashMap.size()+" create Validation Hash Map");
		return validationHashMap;
	}
	
	private Map<String, List<String>> createUpdIndicatorTypeMap() {
		logger.debug("Execution started for create UpdIndicator TypeMap");
		Map<String,List<String>> updIndTypeHm= new HashMap<>();
		updIndTypeHm.put("R", new ArrayList<>(Arrays.asList("R","C","S")));
		updIndTypeHm.put("Q", new ArrayList<>(Arrays.asList("")));
		updIndTypeHm.put("M", new ArrayList<>(Arrays.asList("M")));
		updIndTypeHm.put("E", new ArrayList<>(Arrays.asList("L","O","W")));
		logger.debug("Execution completed for "+updIndTypeHm.size()+" create UpdIndicator TypeMap");
		return updIndTypeHm;
	}
	
	private Map<String, Set<String>> createProductionCodeMap(
			List<Object[]> productionCodeList) {
		logger.debug("Execution started for create Production CodeMap");
		Map<String,Set<String>> productionCodeMap= new HashMap<>();
		Set<String> productionGroupCode= new HashSet<>();
		Set<String> productionCategoryCode= new HashSet<>();
		Set<String> productionClassCode= new HashSet<>();
		productionGroupCode.add("00");
		productionCategoryCode.add("00");
		productionClassCode.add("00");
		for (Object[] productionCodeArray : productionCodeList) {
			productionGroupCode.add(productionCodeArray[0].toString());
			productionCategoryCode.add(productionCodeArray[1].toString());
			productionClassCode.add(productionCodeArray[2].toString());
		}
		productionCodeMap.put("productionGroupCode", productionGroupCode);
		productionCodeMap.put("productionCategoryCode", productionCategoryCode);
		productionCodeMap.put("productionClassCode", productionClassCode);
		logger.debug("Execution completed for "+productionCodeMap.size()+" create Production CodeMap");
		return productionCodeMap;
	}
	private Map<ExcelFileKey, ExcelFileDto> findValidRecorFromExcelBasedOnValidProductSku(Map<ExcelFileKey, ExcelFileDto> excelMap, Set<String> validProductSkuSet) {
		
		Map<ExcelFileKey, ExcelFileDto> validMap= new HashMap<>();
		if(!validProductSkuSet.isEmpty()){
			Collection<ExcelFileDto> excelFileDto = excelMap.values();
		    Iterator<ExcelFileDto> itrExcelFileDto = excelFileDto.iterator();
		    while (itrExcelFileDto.hasNext()) {			
		    	ExcelFileDto exlObj= itrExcelFileDto.next();
				if(validProductSkuSet.contains(exlObj.getProductSku()))
				{
					validMap.put(new ExcelFileKey(exlObj.getProductSku(),exlObj.getUpc()), exlObj);
				}
			}
		}
		return validMap;
	}
	
	private void saveExcelDataToDatabase(Map<ExcelFileKey, ExcelFileRow> finalMapForValidation,ItemConvBulkUploadTracking obj, Set<String> validProductSkuSet, Set<String> invalidProductSkuSet,Map<String,List<String>> invalidProductSkuMap) {
		
		if(!validProductSkuSet.isEmpty()){
			
			List<String> dbRecord = commonSQLRepo.fetchRecordBasedOnCompanyIdDivisionIdProductSku(obj.getCompanyId(), obj.getDivisionId(), validProductSkuSet);
			
			if (!dbRecord.isEmpty()) {
				for (String key : dbRecord) {
					if (validProductSkuSet.contains(key)) {
						invalidProductSkuSet.add(key);
						validProductSkuSet.remove(key);
						if(!invalidProductSkuMap.containsKey(key)){
							List<String> rejectReason=new ArrayList<>();
							rejectReason.add("Product SKU already processed");
							invalidProductSkuMap.put(key, rejectReason);
						}
					}
				}
			}
			saveValidExcelObject(finalMapForValidation, obj,validProductSkuSet,invalidProductSkuSet,invalidProductSkuMap);
		}
	}

	private void saveValidExcelObject(Map<ExcelFileKey, ExcelFileRow> finalMapForValidation, ItemConvBulkUploadTracking obj, Set<String> validProductSkuSet, Set<String> invalidProductSkuSet,Map<String,List<String>> invalidProductSkuMap) 
	{
		logger.debug("Execution started for save Valid Excel Object");
		if (!validProductSkuSet.isEmpty()) {
			Collection<ExcelFileRow> excelFileRow = finalMapForValidation.values();
			Iterator<ExcelFileRow> itrExcelFileRow = excelFileRow.iterator();
			List<NewItemDetail> newItemList= new ArrayList<>();
			
			while (itrExcelFileRow.hasNext()) {
				ExcelFileRow exlObj = itrExcelFileRow.next();
				if (validProductSkuSet.contains(exlObj.getProductSku())) {
					try {
						
						String[] upc = exlObj.getUpc().split("-");
						String companyId = exlObj.getCompanyId().trim();
						String divisionId = exlObj.getDivisionId().trim();
						String productSku = exlObj.getProductSku().trim();
						String productSrcCode = exlObj.getProductSrcCd().trim();
						String upcCountry = upc[0];
						String upcSystem = upc[1];
						String upcManuf = upc[2];
						String upcSales = upc[3];
						NewItemDetailPk newItmPk = new NewItemDetailPk();
						newItmPk.setCompanyId(companyId);
						newItmPk.setDivisionId(divisionId);
						newItmPk.setProductSKU(productSku);
						newItmPk.setProductSrcCd(productSrcCode);
						newItmPk.setUpcCountry(upcCountry);
						newItmPk.setUpcSystem(upcSystem);
						newItmPk.setUpcManufacturer(upcManuf);
						newItmPk.setUpcSales(upcSales);
						NewItemDetail newItem = new NewItemDetail();
						newItem.setNewItemPk(newItmPk);
						newItem.setPluCd(exlObj.getPluCode());
						newItem.setPrmyUpcInd(exlObj.getPrimaryUpcInd());
						newItem.setVendConvFactor(exlObj.getVendConvFactor());
						newItem.setPackwhse(exlObj.getPackWhse());
						newItem.setCost(exlObj.getVendorCost().floatValue());
						newItem.setSrcItmDesc(exlObj.getSrcItemDesc());
						newItem.setSrcWhseItmDesc(exlObj.getSrcWhseItemDesc());
						newItem.setSrcRtlItmDesc(exlObj.getSrcRtlItemDesc());
						newItem.setSrcIntenetItemDesc(exlObj.getSrcInternetDesc());
						newItem.setSrcPosDesc(exlObj.getSrcPosDesc());
						newItem.setItemUsgeInd(exlObj.getSrcItemUsgeInd());
						newItem.setItemUsageTypInd(exlObj.getSrcItemUsgeTypeInd());
						newItem.setPtLabelInd(exlObj.getSrcPrivateLabelInd());
						newItem.setDispFlag(exlObj.getSrcDspFlag());
						newItem.setSize(exlObj.getSrcSize());
						newItem.setSrcSizeNmbr(exlObj.getSrcSizeNum());
						newItem.setSrcSizeUom(exlObj.getSrcSizeUom());
						newItem.setUpdItmDesc(exlObj.getUpdItemDesc());
						newItem.setUpdWhseItmDesc(exlObj.getUpdWhseItemDesc());
						newItem.setUpdRtlItmDesc(exlObj.getUpdRtlItemDesc());
						newItem.setUpdIntenetItemDesc(exlObj.getUpdInternetItemDesc());
						newItem.setUpdPosDesc(exlObj.getUpdPosDesc());
						newItem.setUpdUsgeInd(exlObj.getUpdItemUsageInd());
						newItem.setUpdUsageTypInd(exlObj.getUpdItemUsageTypInd());
						newItem.setUpdPtLabelInd(exlObj.getUpdPrivateLabelInd());
						newItem.setUpdDispFlag(exlObj.getUpdDispFlag());
						newItem.setUpdSize(exlObj.getUpdSize());
						newItem.setUpdSizeNmbr(exlObj.getUpdSizeNmbr());
						newItem.setUpdSizeUom(exlObj.getUpdSizeUom());
						newItem.setPrdHierLevel1(exlObj.getHierLevel1());
						newItem.setPrdHierLevel2(exlObj.getHierLevel2());
						newItem.setPrdHierLevel3(exlObj.getHierLevel3());
						newItem.setPrdHierLevel4(exlObj.getHierLevel4());
						newItem.setPrdHierLevel5(exlObj.getHierLevel5());
						newItem.setGrpCd(exlObj.getGrpCd());
						newItem.setCtgryCd(exlObj.getCtgryCd());
						newItem.setClsCd(exlObj.getClsCd());
						newItem.setSbClsCd(exlObj.getSbClsCd());
						newItem.setSubSbClass(exlObj.getSubSbClassCd());
						
						newItem.setInnerPack(exlObj.getInnerPack());
						newItem.setRetailUnitPack(exlObj.getRetailUnitPack());
						newItem.setEthnicTypeCd(exlObj.getEthnicTypeCd());
						newItem.setPckTypeId(exlObj.getPckTypeId());
						newItem.setProductClsCd(exlObj.getProductClsCd());
						newItem.setProductionGrpCd(exlObj.getProductionGrpCd());
						newItem.setProductionCtgryCd(exlObj.getProductionCtgryCd());
						newItem.setProductionClsCd(exlObj.getProductionClsCd());
						
						newItem.setBatchId(exlObj.getBatchId().intValue());
						newItem.setCreateUser(obj.getCreateUserId().trim());
						newItem.setCreateUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
						newItem.setAugOverCmplnInd('Y');
						newItem.setCovTeamComment(exlObj.getConvTeamComments());
						newItem.setExcptnTypeCd('A');
						newItem.setExcptionDesc("Augmentation");
						newItem.setLogicalInd('N');
						
						if( exlObj.getUpdUpc() != null && !exlObj.getUpdUpc().trim().equals("")&& Float.parseFloat(exlObj.getUpdUpc().replaceAll("-", ""))>=100000  )
						{
							newItem.setUpdUpc(exlObj.getUpdUpc().replaceAll("-", "").trim());

						}
						else if( exlObj.getUpdUpc() != null && !exlObj.getUpdUpc().trim().equals("")&& Float.parseFloat(exlObj.getUpdUpc().replaceAll("-", ""))<100000  )
						{
							
							newItem.setUpdPluCd(exlObj.getUpdPlu().replaceAll("-", "").trim());
						}
						else
						{
							newItem.setUpdUpc(exlObj.getUpdUpc().replaceAll("-", "").trim());
						}
						
						newItem.setPackDesc(exlObj.getDcPackDesc().trim());
						newItem.setSizeDesc(exlObj.getDcSizeDsc().trim());
					
						
						newItem.setRing(exlObj.getRing());
						newItem.setHicone(exlObj.getHicone());	
						
						newItem.setProdwght(exlObj.getProdwght());
						newItem.setHandlingCode(exlObj.getHandlingCode());
						newItem.setBuyerNum(exlObj.getBuyerNum());
						newItem.setRandomWtCd(exlObj.getRandomWtCd());
						newItem.setAutoCostInv(exlObj.getAutoCostInv());
						newItem.setBillingType(exlObj.getBillingType());
						newItem.setFdStmp(exlObj.getFdStmp());
						newItem.setLabelSize(exlObj.getLabelSize());
						newItem.setLabelNumbers(exlObj.getLabelNumbers());
						newItem.setSgnCount1(exlObj.getSgnCount1());
						newItem.setSgnCount2(exlObj.getSgnCount2());
						newItem.setSgnCount3(exlObj.getSgnCount3());
						newItem.setSellByDays(exlObj.getSellByDays());
						newItem.setEatByDays(exlObj.getUseByDays());
						newItem.setPullByDays(exlObj.getPullBydays());	
						newItem.setTareCd(exlObj.getTareCd());
						newItem.setUpdPack(exlObj.getPackWhse().toString());
						
						newItemList.add(newItem);
					} catch (Exception e) {
						logger.error(e.getMessage());
						ExcelFileRow excelObj = exlObj;
						String productSku = excelObj.getProductSku();
						if (validProductSkuSet.contains(productSku)) {
							validProductSkuSet.remove(productSku);
							invalidProductSkuSet.add(productSku);
							if(!invalidProductSkuMap.containsKey(productSku)){
								List<String> rejectReason=new ArrayList<>();
								rejectReason.add("Unable to process");
								invalidProductSkuMap.put(productSku, rejectReason);
							}
						}
					}
				}
			}
			if(!newItemList.isEmpty()){
				newItemRepo.saveAll(newItemList);
				commonSQLRepo.updateXrefAndUiException(newItemList);
			}
		}
		logger.debug("Execution completed for save Valid Excel Object");
	}

	public static boolean isValidString(String str, String allowedSplChars) {
		char[] chars = str.toCharArray();
		for (char c : chars) {
			if (!Character.isLetterOrDigit(c)) {
				if (allowedSplChars != null && allowedSplChars.length() > 0) {
					if (allowedSplChars.indexOf(c) == -1)
						return false;
				} else
					return false;
			}
		}
		return true;
	}
	
	private Map<ExcelFileKey, ExcelFileRow> buildFinalMapForValidation(Map<ExcelFileKey, ExcelFileDto> excelMap, Map<ExcelFileKey, ExcelFileRow> dbMap, Set<String> validProductSkuSet, Set<String> invalidProductSkuSet,Map<String,List<String>> invalidProductSkuMap) 
	{
		logger.debug("Execution started for build Final Map For Validation");
		Map<ExcelFileKey, ExcelFileRow> finalMap = new HashMap<>();
		if(!excelMap.isEmpty() && !dbMap.isEmpty()){
			for (Map.Entry<ExcelFileKey, ExcelFileDto> entry : excelMap.entrySet()) {
				ExcelFileKey key = entry.getKey();
				if (excelMap.containsKey(key) && dbMap.containsKey(key)) {
					try {
						ExcelFileRow row = buildFinalDtoForValidation(excelMap.get(key), dbMap.get(key));
						finalMap.put(key, row);	
					} catch (Exception e) {
						logger.error(e.getMessage());
						ExcelFileDto excelFileDto=excelMap.get(key);
						String productSku=excelFileDto.getProductSku();
						if(validProductSkuSet.contains(productSku)){
							validProductSkuSet.remove(productSku);
							invalidProductSkuSet.add(productSku);
							if(!invalidProductSkuMap.containsKey(productSku)){
								List<String> rejectReason=new ArrayList<>();
								rejectReason.add(e.getMessage());
								invalidProductSkuMap.put(productSku, rejectReason);
							}
						}
					}
					
				}
			}
		}
		logger.debug("Execution completed for "+finalMap.size()+" build Final Map For Validation");
		return finalMap;
	}
	
	private ExcelFileRow buildFinalDtoForValidation(ExcelFileDto excelFileDto, ExcelFileRow excelFileRow) {
		logger.debug("Execution started for ExcelFileRow build Final Dto For Validation");
		ExcelFileRow record = new ExcelFileRow();
		String innerPack=StringUtils.trim(excelFileDto.getInnerPack());
		String packWhse = StringUtils.trim(excelFileDto.getPack());
		String retailUnitPack = StringUtils.trim(excelFileDto.getRetailUnitPack());
		String ethynicTypeCode = StringUtils.trim(excelFileDto.getEthnicTypeCd());
		String groupCode = StringUtils.trim(excelFileDto.getGrpCd());
		String categoryCode = StringUtils.trim(excelFileDto.getCtgryCd());
		
		record.setCompanyId(getStringValue(excelFileDto.getCompanyId()));
		record.setDivisionId((excelFileDto.getDivisionId()));
		record.setProductSku(getStringValue(excelFileDto.getProductSku()));
		record.setProductSrcCd(getStringValue(excelFileDto.getProductSrcCd()));
		record.setUpc(getStringValue(excelFileDto.getUpc()));
		record.setPluCode(excelFileRow.getPluCode());
		record.setPrimaryUpcInd(excelFileRow.getPrimaryUpcInd());
		record.setVendConvFactor(convertStringToBigDecimal(excelFileDto.getVendConvFactor()));
		record.setPackWhse(convertStringToBigDecimal(packWhse));
		record.setVendorCost(convertStringToBigDecimal(excelFileDto.getVendorCost()));
		record.setSrcItemDesc(getStringValue(excelFileDto.getItemDesc()));
		record.setSrcWhseItemDesc(excelFileRow.getSrcWhseItemDesc());
		record.setSrcRtlItemDesc(excelFileRow.getSrcRtlItemDesc());
		record.setSrcInternetDesc(excelFileRow.getSrcInternetDesc());
		record.setSrcPosDesc(excelFileRow.getSrcPosDesc());
		record.setSrcItemUsgeInd(excelFileRow.getSrcItemUsgeInd());
		record.setSrcItemUsgeTypeInd(excelFileRow.getSrcItemUsgeTypeInd());
		record.setSrcPrivateLabelInd(excelFileRow.getSrcPrivateLabelInd());
		record.setSrcDspFlag(convertStringToCharacter(excelFileDto.getDspFlag()));
		record.setSrcSize(getStringValue(excelFileDto.getNumSize()));
		record.setSrcSizeNum(excelFileRow.getSrcSizeNum());
		record.setSrcSizeUom(excelFileRow.getSrcSizeUom());
		record.setUpdItemDesc(getStringValue(excelFileDto.getUpdItemDesc()));
		record.setUpdWhseItemDesc(getStringValue(excelFileDto.getUpdWhseItemDesc()));
		record.setUpdRtlItemDesc(getStringValue(excelFileDto.getUpdRtlItemDesc()));
		record.setUpdInternetItemDesc(getStringValue(excelFileDto.getUpdInternetItemDesc()));
		record.setUpdPosDesc(getStringValue(excelFileDto.getUpdPosDesc()));
		record.setUpdItemUsageInd(convertStringToCharacter(excelFileDto.getUpdItemUsageInd()));
		record.setUpdItemUsageTypInd(convertStringToCharacter(excelFileDto.getUpdItemUsageTypInd()));
		record.setUpdPrivateLabelInd(convertStringToCharacter(excelFileDto.getUpdPrivateLabelInd()));
		record.setUpdDispFlag(convertStringToCharacter(excelFileDto.getUpdDispFlag()));
		record.setUpdSize(getStringValue(excelFileDto.getUpdSize()));
		record.setUpdSizeNmbr(convertStringToBigDecimal(excelFileDto.getUpdSizeNmbr()));
		record.setUpdSizeUom(getStringValue(excelFileDto.getUpdSizeUom()));
		record.setHierLevel1(getStringValue(excelFileRow.getHierLevel1()));
		record.setHierLevel2(getStringValue(excelFileRow.getHierLevel2()));
		record.setHierLevel3(getStringValue(excelFileRow.getHierLevel3()));
		record.setHierLevel4(getStringValue(excelFileRow.getHierLevel4()));
		record.setHierLevel5(getStringValue(excelFileRow.getHierLevel5()));
		record.setGrpCd(convertStringToBigDecimal(excelFileDto.getGrpCd()).intValue());
		record.setCtgryCd(convertStringToBigDecimal(excelFileDto.getCtgryCd()).intValue());
		record.setClsCd(convertStringToBigDecimal(excelFileDto.getClsCd()).intValue());
		record.setSbClsCd(convertStringToBigDecimal(excelFileDto.getSbClsCd()).intValue());
		record.setSubSbClassCd(convertStringToBigDecimal(excelFileDto.getSubSbClassCd()).intValue());
		record.setBatchId(convertStringToBigDecimal(excelFileDto.getBatchId()));
		record.setConvTeamComments(getStringValue(excelFileDto.getConvTeamComments()));
		String productClassCode= StringUtils.trim(excelFileDto.getProductClsCd());
		
		if(ethynicTypeCode.equals("")){
			record.setEthnicTypeCd(" ");
		}else{
			record.setEthnicTypeCd(ethynicTypeCode);
		}
		if(innerPack.equals("0")){
			record.setInnerPack(Integer.valueOf("1"));
		}else{
			record.setInnerPack(Integer.valueOf(innerPack));
		}
		if(retailUnitPack.equals("0")){
			record.setRetailUnitPack(Integer.valueOf(packWhse));
		}else{
			record.setRetailUnitPack(Integer.valueOf(retailUnitPack));
		}
		if(!groupCode.equals("84")){
			record.setProductClsCd(Integer.valueOf(new StringBuilder().append(StringUtils.leftPad(groupCode, 2, "0")).append(StringUtils.leftPad(categoryCode, 2, "0")).toString()));
		}else{
			if(productClassCode!=null && !productClassCode.isEmpty() && !productClassCode.equals("0")){
				record.setProductClsCd(Integer.valueOf(StringUtils.trim(excelFileDto.getProductClsCd())));
			}else{
				record.setProductClsCd(Integer.valueOf(new StringBuilder().append(StringUtils.leftPad(groupCode, 2, "0")).append(StringUtils.leftPad(categoryCode, 2, "0")).toString()));
			}
		}
		record.setPckTypeId(convertStringToBigDecimal(excelFileDto.getPckTypeId()));
		record.setProductionGrpCd(Integer.valueOf(excelFileDto.getProductionGrpCd()));
		record.setProductionCtgryCd(Integer.valueOf(excelFileDto.getProductionCtgryCd()));
		record.setProductionClsCd(Integer.valueOf(excelFileDto.getProductionClsCd()));
		
		/*Produce PLU*/
		record.setUpdUpc(excelFileDto.getUpdUpc().trim());
		record.setUpdPlu(excelFileDto.getUpdPlu().trim());
		record.setDcPackDesc(excelFileDto.getDcPackDesc().trim());
		record.setDcSizeDsc(excelFileDto.getDcSizeDsc().trim());
		record.setRing(excelFileDto.getRing().trim());
		record.setHicone(excelFileDto.getHicone().trim());
		
		record.setProdwght(excelFileDto.getProdwght());
		record.setHandlingCode(excelFileDto.getHandlingCode());
		record.setBuyerNum(excelFileDto.getBuyerNum());
		record.setRandomWtCd(excelFileDto.getRandomWtCd());
		record.setAutoCostInv(excelFileDto.getAutoCostInv());
		record.setBillingType(excelFileDto.getBillingType());
		record.setFdStmp(excelFileDto.getFdStmp());
		record.setLabelSize(excelFileDto.getLabelSize());
		record.setLabelNumbers(excelFileDto.getLabelNumbers());
		record.setSgnCount1(excelFileDto.getSgnCount1());
		record.setSgnCount2(excelFileDto.getSgnCount2());
		record.setSgnCount3(excelFileDto.getSgnCount3());
		record.setSellByDays(excelFileDto.getSellByDays());
		record.setUseByDays(excelFileDto.getUseByDays());
		record.setPullBydays(excelFileDto.getPullBydays());	
		record.setTareCd(excelFileDto.getTareCd());
		/*Aditonal fields*/
		logger.debug("Execution completed for ExcelFileRow build Final Dto For Validation");
		return record;
	}

	public Map<ExcelFileKey,ExcelFileRow> buildLikeItemDetailDtoListAsMap(
			List<Object[]> likeItemObjList) {
		
		logger.info("Execution started for build Like ItemDetail Dto List As Map");
		Map<ExcelFileKey,ExcelFileRow> exceptionList = new HashMap<>();
		if(!likeItemObjList.isEmpty()){
			for (Object[] srcObj : likeItemObjList) {
				ExcelFileRow excSrcDto = new ExcelFileRow();
				excSrcDto.setCompanyId(getStringValue(srcObj[0]));
				excSrcDto.setDivisionId(getStringValue(srcObj[1]));
				excSrcDto.setProductSku(getStringValue(srcObj[2]));
				excSrcDto.setUpc(getStringValue(srcObj[3]));
				excSrcDto.setPluCode(getBigDecimalValue(srcObj[4]).toString());
				excSrcDto.setPrimaryUpcInd(getCharacterValue(srcObj[5]));
				excSrcDto.setSrcWhseItemDesc(getStringValue(srcObj[6]));
				excSrcDto.setSrcRtlItemDesc(getStringValue(srcObj[7]));
				excSrcDto.setSrcInternetDesc(getStringValue(srcObj[8]));
				excSrcDto.setSrcPosDesc(getStringValue(srcObj[9]));
				excSrcDto.setSrcItemUsgeInd(getCharacterValue(srcObj[10]));
				excSrcDto.setSrcItemUsgeTypeInd(getCharacterValue(srcObj[11]));
				excSrcDto.setSrcPrivateLabelInd(getCharacterValue(srcObj[12]));
				excSrcDto.setHierLevel1(getStringValue(srcObj[13]));
				excSrcDto.setHierLevel2(getStringValue(srcObj[14]));
				excSrcDto.setHierLevel3(getStringValue(srcObj[15]));
				excSrcDto.setHierLevel4(getStringValue(srcObj[16]));
				excSrcDto.setHierLevel5(getStringValue(srcObj[17]));
				excSrcDto.setBatchId(getBigDecimalValue(srcObj[18]));
				excSrcDto.setSrcSizeNum(getBigDecimalValue(srcObj[19]));
				excSrcDto.setSrcSizeUom(getStringValue(srcObj[20]));
				exceptionList.put(new ExcelFileKey(excSrcDto.getProductSku(), excSrcDto.getUpc()), excSrcDto);
			}	
		}
		logger.info("Execution Completed for build Like ItemDetail Dto List As Map");
		return exceptionList;
	}

	private ItemConvBulkUploadTracking updateStatusToDatabase(ItemConvBulkUploadTracking obj,String statusCode,BigDecimal recordCount,BigDecimal validRecordCount,String filePath) {
		obj.setStatusCode(getStringValue(statusCode));
		obj.setRecordCount(getBigDecimalValue(recordCount));
		obj.setValidRecordCount(getBigDecimalValue(validRecordCount));
		obj.setCreateUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
		obj.setFilePath(getStringValue(filePath));
		return itemConvBulkUploadRepository.save(obj);
	}

	private BulkUploadTrackingDto mapFieldToBulkUploadTrackingDto(ExcelFileRequest excelFileRequest,String fileName, String filePath, String statusCode, BigDecimal recordCount, BigDecimal validRecordCount) {
		BulkUploadTrackingDto bulkDto=new BulkUploadTrackingDto();
		bulkDto.setCompanyId(getStringValue(excelFileRequest.getCompanyId()));
		bulkDto.setDivisionId(getStringValue(excelFileRequest.getDivisionId()));
		bulkDto.setDeptName(getStringValue(excelFileRequest.getDeptName()));
		bulkDto.setFileName(getStringValue(fileName));
		bulkDto.setFilePath(getStringValue(filePath));
		bulkDto.setStatusCode(getStringValue(statusCode));
		bulkDto.setRecordCount(getBigDecimalValue(recordCount));
		bulkDto.setValidRecordCount(getBigDecimalValue(validRecordCount));
		bulkDto.setCreateUserId(getStringValue(excelFileRequest.getUserId()));
		return bulkDto;
	}
	
	private ItemConvBulkUploadTracking saveStatusToDatabase(BulkUploadTrackingDto bulkDto) {
		ItemConvBulkUploadTracking record=new ItemConvBulkUploadTracking();
		record.setCompanyId(bulkDto.getCompanyId());
		record.setDivisionId(bulkDto.getDivisionId());
		record.setDeptName(bulkDto.getDeptName());
		record.setFileName(bulkDto.getFileName());
		record.setFilePath(bulkDto.getFilePath());
		record.setStatusCode(bulkDto.getStatusCode());
		record.setRecordCount(bulkDto.getRecordCount());
		record.setValidRecordCount(bulkDto.getValidRecordCount());
		record.setCreateUserId(bulkDto.getCreateUserId());
		record.setCreateUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
		Random rand = null;
		try {
			rand = SecureRandom.getInstanceStrong();
		} catch (NoSuchAlgorithmException e) {
			logger.error("Error creating the rand object");
		}
		if(rand != null) {
		record.setBulkUploadId(new BigDecimal(rand.nextInt()));
		}
		return itemConvBulkUploadRepository.save(record);
	}

	private ExcelFileDto mapToExcelFileRow(List<String> column,ExcelFileRequest fReq) {
		logger.debug("Execution started for Excel FileDto map To ExcelFileRow");
		ExcelFileDto excelColumnDetails = new ExcelFileDto();
		excelColumnDetails.setCompanyId(StringUtils.trim(fReq.getCompanyId()));
		excelColumnDetails.setDivisionId(StringUtils.trim(fReq.getDivisionId()));
		excelColumnDetails.setAction(getStringValue(column.get(0)));
		excelColumnDetails.setProductSku(getStringValue(column.get(1)));
		excelColumnDetails.setUpc(getStringValue(column.get(2)));
		excelColumnDetails.setItemDesc(getStringValue(column.get(3)));
		excelColumnDetails.setInternetDesc(getStringValue(column.get(4)));
		
		excelColumnDetails.setSrcWhseitemDesc(getStringValue(column.get(5)));
		excelColumnDetails.setSrcRtlInternetDesc(getStringValue(column.get(6)));
		excelColumnDetails.setSrcPosDesc(getStringValue(column.get(7)));
		
		excelColumnDetails.setPack(getStringValue(column.get(8)));
		excelColumnDetails.setVendConvFactor(getStringValue(column.get(9)));
		excelColumnDetails.setNumSize(getStringValue(column.get(10)));
		excelColumnDetails.setCaseUpc(getStringValue(column.get(11)));
		excelColumnDetails.setItmUsgeInd(getStringValue(column.get(12)));
		String displayFlag=null;
		if((column.get(13)).equals("")){
			displayFlag=null;
		}else{
			displayFlag=StringUtils.trim(column.get(13));
		}
		excelColumnDetails.setDspFlag(displayFlag);
		excelColumnDetails.setProductSrcCd(StringUtils.trim(column.get(14)));

		excelColumnDetails.setVendorCost(StringUtils.trim(column.get(15)).replace("$", ""));
		excelColumnDetails.setSlotId(StringUtils.trim(column.get(16)));
		excelColumnDetails.setOnhandNbr(StringUtils.trim(column.get(17)));
		excelColumnDetails.setCategoryDesc(StringUtils.trim(column.get(18)));
		excelColumnDetails.setSubCategoryDesc(StringUtils.trim(column.get(19)));
		excelColumnDetails.setGroupDesc(StringUtils.trim(column.get(20)));
		
		excelColumnDetails.setNewDate(StringUtils.trim(column.get(21)));
		excelColumnDetails.setLastShipDate(StringUtils.trim(column.get(22)));
		excelColumnDetails.setLastSaleDate(StringUtils.trim(column.get(23)));
		excelColumnDetails.setTotalSales(StringUtils.trim(column.get(24)));
		excelColumnDetails.setCasesOrdered(StringUtils.trim(column.get(25)));
		
		excelColumnDetails.setUpdItemDesc(StringUtils.trim(column.get(26)));
		excelColumnDetails.setUpdWhseItemDesc(StringUtils.trim(column.get(27)));
		excelColumnDetails.setUpdRtlItemDesc(StringUtils.trim(column.get(28)));
		excelColumnDetails.setUpdInternetItemDesc(StringUtils.trim(column.get(29)));
		excelColumnDetails.setUpdPosDesc(StringUtils.trim(column.get(30)));
		
		excelColumnDetails.setGrpCd(StringUtils.trim(column.get(31)));
		excelColumnDetails.setCtgryCd(StringUtils.trim(column.get(32)));
		excelColumnDetails.setClsCd(StringUtils.trim(column.get(33)));
		excelColumnDetails.setSbClsCd(StringUtils.trim(column.get(34)));
		excelColumnDetails.setSubSbClassCd(StringUtils.trim(column.get(35)));
		
		String productionGrpCd=StringUtils.trim(column.get(36));
		String productionCtgryCd=StringUtils.trim(column.get(37));
		String productionClsCd=StringUtils.trim(column.get(38));
		excelColumnDetails.setProductionGrpCd(StringUtils.leftPad(productionGrpCd, 2, "0"));
		excelColumnDetails.setProductionCtgryCd(StringUtils.leftPad(productionCtgryCd, 2, "0"));
		excelColumnDetails.setProductionClsCd(StringUtils.leftPad(productionClsCd, 2, "0"));
		if(StringUtils.trim(column.get(39)).equals("0") || StringUtils.trim(column.get(39)).equals("")){
			excelColumnDetails.setProductClsCd(new StringBuilder().append(StringUtils.leftPad(StringUtils.trim(column.get(31)), 2, "0")).append(StringUtils.leftPad(StringUtils.trim(column.get(32)), 2, "0")).toString());
		}else{
			excelColumnDetails.setProductClsCd(StringUtils.trim(column.get(39)));
		}
		excelColumnDetails.setUpdSize(StringUtils.trim(column.get(40)));
		excelColumnDetails.setUpdSizeNmbr(StringUtils.trim(column.get(41)));
		excelColumnDetails.setUpdSizeUom(StringUtils.trim(column.get(42)));
		excelColumnDetails.setInnerPack(StringUtils.trim(column.get(43)));
		excelColumnDetails.setRetailUnitPack(StringUtils.trim(column.get(44)));
		excelColumnDetails.setUpdItemUsageInd(StringUtils.trim(column.get(45)));
		excelColumnDetails.setUpdItemUsageTypInd(StringUtils.trim(column.get(46)));
		excelColumnDetails.setUpdPrivateLabelInd(StringUtils.trim(column.get(47)));
		excelColumnDetails.setUpdDispFlag(StringUtils.trim(column.get(48)));
		excelColumnDetails.setEthnicTypeCd(StringUtils.trim(column.get(49)));
		excelColumnDetails.setPckTypeId(StringUtils.trim(column.get(50)));
		
		
		/*PRoducePLU*/
		String updUpc =StringUtils.trim(column.get(51));
		if(updUpc !=null && !updUpc.equals(""))
		{
			excelColumnDetails.setUpdUpc(StringUtils.leftPad(updUpc.replaceAll("-", ""), 12, "0"));	
		}
		else
		{
			excelColumnDetails.setUpdUpc(updUpc);
		}
		excelColumnDetails.setUpdPlu(StringUtils.trim(column.get(52)) );
		excelColumnDetails.setDcPackDesc(StringUtils.trim(column.get(53)));
		excelColumnDetails.setDcSizeDsc(StringUtils.trim(column.get(54)));
		excelColumnDetails.setRing(StringUtils.trim(column.get(55)) );
		excelColumnDetails.setHicone(StringUtils.trim(column.get(56)) );
		
		excelColumnDetails.setProdwght(StringUtils.trim(column.get(57)));
		excelColumnDetails.setHandlingCode(StringUtils.trim(column.get(58)));
		excelColumnDetails.setBuyerNum(StringUtils.trim(column.get(59)));
		excelColumnDetails.setRandomWtCd(StringUtils.trim(column.get(60).toUpperCase()));
		excelColumnDetails.setAutoCostInv(StringUtils.trim(column.get(61).toUpperCase()));
		excelColumnDetails.setBillingType(StringUtils.trim(column.get(62).toUpperCase()));
		excelColumnDetails.setFdStmp(StringUtils.trim(column.get(63)));
		excelColumnDetails.setLabelSize(StringUtils.trim(column.get(64).toUpperCase()));
		excelColumnDetails.setLabelNumbers(StringUtils.trim(column.get(65)));
		excelColumnDetails.setSgnCount1(StringUtils.trim(column.get(66)));
		excelColumnDetails.setSgnCount2(StringUtils.trim(column.get(67)));
		excelColumnDetails.setSgnCount3(StringUtils.trim(column.get(68)));
		excelColumnDetails.setSellByDays(StringUtils.trim(column.get(69)));
		excelColumnDetails.setUseByDays(StringUtils.trim(column.get(70)));
		excelColumnDetails.setPullBydays(StringUtils.trim(column.get(71)));	
		excelColumnDetails.setTareCd(StringUtils.trim(column.get(72)));
		
		excelColumnDetails.setConvTeamComments(StringUtils.trim(column.get(73)));
		logger.debug("Execution completed  for Excel File Dto map To Excel FileRow");
		
		return excelColumnDetails;
	}
	
	private void sendEmail(String userId, String excelFileName, Set<String> invalidProductSkuSet,Map<String,List<String>> invalidProductSkuMap) throws AddressException {
		
		InternetAddress fromAddr =new InternetAddress(new StringBuilder().append(fromAddress).append("@safeway.com").toString());
		InternetAddress[] toAddr =InternetAddress.parse(new StringBuilder().append(userId+"@safeway.com").toString());
		logger.debug("Execution started for sendEmail");
		String fileName = excelFileName.substring(0, excelFileName.lastIndexOf("-"));
		// email subject
		String subject = "File Upload Status";
		// email body
		StringBuilder finalRejectReasonBuilder=new StringBuilder().append("<table style='width:100%;border: 1px solid black;border-collapse: collapse;'><tr><th style='width:22%;border: 1px solid black;'>Product SKU</th> <th style='width:75%;border: 1px solid black;'>Column Failing Validation</th></tr>");
		for (Map.Entry<String,List<String>> entry : invalidProductSkuMap.entrySet()) {
			String rejectReasons = StringUtils.join(entry.getValue(), ",");
			finalRejectReasonBuilder.append(new StringBuilder().append("<tr><td style='border: 1px solid black'>"+entry.getKey()+"</td>").append("<td style='border: 1px solid black'>"+rejectReasons+" </td></tr>"));
		}
		String body=null;
		if(invalidProductSkuSet.isEmpty()){
			body="<html>" +
	                "<body>" +
					"<i><p>Hi "+userId+",</p>"+
	                "<p>Thanks for using MIDAS. The file uploaded with the name "+fileName+".xlsx has been successfully processed.</p>"+
	                "<p>In case of any queries, please reach out to Midas.Support@albertsons.com.</p>"+
	                "<p>Thanks & Regards<br>"+
	                "MIDAS</p></i>"+
	                "</body>" +
	                "</html>";
		}else{
			body="<html>" +
	                "<body>" +
	                "<i><p>Hi "+userId+",</p>"+
	                "<p>Thanks for using MIDAS. The file uploaded with the name "+fileName+".xlsx has been processed.</p>"+
	                "<p>We would like to bring to your notice that we were "+"<b>NOT</b>"+" able to process the undermentioned items, as these failed item conversion validations. </p></i>"+
	                "<p> "+finalRejectReasonBuilder+" </table> </p>"+
	                "<i><p>If you need further assistance please reach out to Midas.Support@albertsons.com.</p>"+
	                "<p>Thanks & Regards<br>"+
	                "MIDAS</p></i>"+
	                "</body>" +
	                "</html>";
		}
		email.sendEmailMessage(fromAddr,toAddr, subject, body);
		logger.debug("mail sent successfully!");
	}
	
	private Character getCharacterValue(Object obj){
		String empty=" ";
		if(obj == null)
			return Character.valueOf(empty.charAt(0));
		return (Character) obj;
	}
	private Character convertStringToCharacter(String obj){
		String empty=" ";
		if(obj == null)
			return Character.valueOf(empty.charAt(0));
		return obj.charAt(0);
	}
	
	private BigDecimal convertStringToBigDecimal(String obj){
		if(obj == null)
			return new BigDecimal(0);
		return new BigDecimal(obj);
	}
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}
	
	private String getStringValue(Object obj){
		if(obj == null)
			return " ";
		return ((String) obj).trim();
	}
}
