package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name ="DISPLAY_ITEM_COMPONENTS", schema="ECFLAND")
public class ItemConvDisplayItemComponents implements Serializable{
	
	/*
	COMPANY_ID         NOT NULL VARCHAR2(20) 
	DIVISION_ID        NOT NULL VARCHAR2(20) 
	PRODUCT_SKU        NOT NULL VARCHAR2(20) 
	CASE_UPC           NOT NULL VARCHAR2(14) 
	ITEM_DSC           NOT NULL VARCHAR2(40) 
	SHIP_CASE_PACK_QTY NOT NULL NUMBER(5)    
	SHIP_SIZE_DSC      NOT NULL VARCHAR2(20) 
	MEMO_COST          NOT NULL NUMBER(38,2) 
	UPC_COUNTRY        NOT NULL NUMBER(1)    
	UPC_SYSTEM         NOT NULL NUMBER(1)    
	UPC_MANUF          NOT NULL NUMBER(5)    
	UPC_SALES          NOT NULL NUMBER(5)    
	COMP_ITEM_DSC      NOT NULL VARCHAR2(40) 
	COMP_SIZE_DSC      NOT NULL VARCHAR2(20) 
	COMP_SHELF_UNIT    NOT NULL NUMBER(6)    
	UNIT_COST          NOT NULL NUMBER(9,3)  
	CREATE_USER_ID     NOT NULL VARCHAR2(20) 
	CREATE_TS          NOT NULL TIMESTAMP(6) 
	*/
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@EmbeddedId
	ItemConvDisplayItemComponentsPK itemConvDisplayItemComponentsPk;
	
	
	@Column(name ="CASE_UPC", nullable =false)
	private String caseUpc;
	
	@Column(name ="ITEM_DSC", nullable =false)
	private String itemmDesc;
	
	@Column(name ="SHIP_CASE_PACK_QTY", nullable =false)
	private BigDecimal shipCaseQty;
	
	@Column(name ="SHIP_SIZE_DSC", nullable =false)
	private String shipSizeDesc;
	
	@Column(name ="MEMO_COST", nullable =false)
	private BigDecimal memoCost;
	
	
	@Column(name ="COMP_ITEM_DSC", nullable =false)
	private String compItemDesc;
	
	@Column(name ="COMP_SIZE_DSC", nullable =false)
	private String compSizeDesc;
	
	@Column(name ="COMP_SHELF_UNIT", nullable =false)
	private BigDecimal compShelfUnit;
	
	@Column(name ="UNIT_COST", nullable =false)
	private BigDecimal  unitCost;
	
	@Column(name ="CREATE_USER_ID", nullable =false)
	private String creatUserId;
	
	@Column(name ="CREATE_TS", nullable =false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateTs;

	

	public ItemConvDisplayItemComponentsPK getItemConvDisplayItemComponentsPk() {
		return itemConvDisplayItemComponentsPk;
	}

	public void setItemConvDisplayItemComponentsPk(
			ItemConvDisplayItemComponentsPK itemConvDisplayItemComponentsPk) {
		this.itemConvDisplayItemComponentsPk = itemConvDisplayItemComponentsPk;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public String getItemmDesc() {
		return itemmDesc;
	}

	public void setItemmDesc(String itemmDesc) {
		this.itemmDesc = itemmDesc;
	}

	public BigDecimal getShipCaseQty() {
		return shipCaseQty;
	}

	public void setShipCaseQty(BigDecimal shipCaseQty) {
		this.shipCaseQty = shipCaseQty;
	}

	public String getShipSizeDesc() {
		return shipSizeDesc;
	}

	public void setShipSizeDesc(String shipSizeDesc) {
		this.shipSizeDesc = shipSizeDesc;
	}

	public BigDecimal getMemoCost() {
		return memoCost;
	}

	public void setMemoCost(BigDecimal memoCost) {
		this.memoCost = memoCost;
	}

	

	public String getCompItemDesc() {
		return compItemDesc;
	}

	public void setCompItemDesc(String compItemDesc) {
		this.compItemDesc = compItemDesc;
	}

	public String getCompSizeDesc() {
		return compSizeDesc;
	}

	public void setCompSizeDesc(String compSizeDesc) {
		this.compSizeDesc = compSizeDesc;
	}

	public BigDecimal getCompShelfUnit() {
		return compShelfUnit;
	}

	public void setCompShelfUnit(BigDecimal compShelfUnit) {
		this.compShelfUnit = compShelfUnit;
	}

	public BigDecimal getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(BigDecimal unitCost) {
		this.unitCost = unitCost;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Date getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}


}
