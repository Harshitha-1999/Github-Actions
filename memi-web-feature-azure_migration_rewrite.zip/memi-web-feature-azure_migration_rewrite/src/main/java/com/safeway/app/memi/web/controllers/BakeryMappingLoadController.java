/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.web.controllers;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakeryResponseVO;
import com.safeway.app.memi.domain.dtos.response.BakerySearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.services.BakeryMappingServices;
import com.safeway.app.memi.domain.util.BakeryConstants;
import com.safeway.app.memi.domain.util.PerishableConstants;
/**
 ****************************************************************************
 * NAME			: BakeryMappingLoadController 
 * 
 * DESCRIPTION	: BakeryMappingLoadController is the controller class for performing 
 * 				  search and filter operations for bakery mapping screen and bakery mapped screen
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision     0.0.0.1     March 05, 2018  - Initial Creation
 * *************************************************************************
 */

@Controller
@RequestMapping("/mapping")
public class BakeryMappingLoadController {
    private static final Logger LOG = LoggerFactory.getLogger(BakeryMappingLoadController.class);

    @Autowired
    private BakeryMappingServices bakeryMappingServices;
    
    /**
     * Method to fetch bakery source data 
     * @param searchRequestVO
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/bakerySourceList", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody BakeryResponseVO listBakerySourceData(@RequestBody BakerySearchRequestVO bakerySearchRequestVO) throws Exception {
    	LOG.info("Fetching all the Bakery Source Data.");
    	List <String> errors =new ArrayList<>();
    
    	BakeryResponseVO bakeryResponseVO = new BakeryResponseVO();
     	if(bakerySearchRequestVO.getCompanyID()!=null && bakerySearchRequestVO.getDivisionID()!=null)
    	{
    		if(bakerySearchRequestVO.getItemType().isAll() ||bakerySearchRequestVO.getItemType().isPlu() ||
    				bakerySearchRequestVO.getItemType().isSystem2()||bakerySearchRequestVO.getItemType().isSystem4())
    		{
    			 bakeryResponseVO=bakeryMappingServices.listBakerySKUItems(bakerySearchRequestVO);
    		}
    		else
    		{
    			errors.add(PerishableConstants.VALIDATION_MESSAGE_ITEM);
    		}
    	}
    	else
    	{
    		errors.add(PerishableConstants.VALIDATION_MESSAGE_COMPANY);
    	}    	
    
    	if(!errors.isEmpty())
    	{
    		bakeryResponseVO.setErrorMessages(errors);
    	}
    	LOG.info("Completed Fetching all the Bakery Source Data.");
		return bakeryResponseVO;
    }
   
    /**
     * Method to fetch bakery target data 
     * @param searchRequestVO
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/bakeryTargetList", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody BakeryResponseVO listBakeryTargetData(@RequestBody BakerySearchRequestVO bakerySearchRequestVO) throws Exception {
		LOG.info("Fetching CIC Bakery Items records.");
		List<String> errors = new ArrayList<>();
		BakeryResponseVO bakeryResponseVO = new BakeryResponseVO();
		
		if (null != bakerySearchRequestVO.getItemType() && bakerySearchRequestVO.getItemType().isAll()
				|| bakerySearchRequestVO.getItemType().isPlu() || bakerySearchRequestVO.getItemType().isSystem2()
				|| bakerySearchRequestVO.getItemType().isSystem4()) {
			if (null != bakerySearchRequestVO.getTargetTypeIndicator() &&(bakerySearchRequestVO.getTargetTypeIndicator().equals(BakeryConstants.BUYER)
					|| (bakerySearchRequestVO.getTargetTypeIndicator().equals(BakeryConstants.SELLER)))) {
				bakeryResponseVO = bakeryMappingServices.listBakeryCICItems(bakerySearchRequestVO);
			} else {
				errors.add(BakeryConstants.INVALID_TARGET_SEARCH);
			}

		} else {
			errors.add(BakeryConstants.VALIDATION_ITEM_TYPE);
		}

		if (!errors.isEmpty()) {
			bakeryResponseVO.setErrorMessages(errors);
		}
		
		LOG.info("Completed Fetching all the CIC Bakery Items records.");
		return bakeryResponseVO;
	}
     
    @RequestMapping(value = "/matchingBakeryTargetList",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public@ResponseBody BakeryResponseVO getMatchingTargetList(@RequestBody PerishableMatchingTargetInputVO upcDetails) {
    	List<String> errors = new ArrayList<>();
    	LOG.info("Fetching all the Matching Target List.");
    	
    	List<BakeryCICSearchResults> bakeryCICSearchResults= bakeryMappingServices.getSuggestedTargetList(upcDetails);  
    	
    	BakeryResponseVO bakeryResponseVO = new BakeryResponseVO();
    	if (null!= bakeryCICSearchResults && !bakeryCICSearchResults.isEmpty()) {
    		bakeryResponseVO.setBakeryCicSearchResults(bakeryCICSearchResults);
		}
    	else
    	{	errors.add("NO MATCH FOUND..!");
    		bakeryResponseVO.setErrorMessages(errors);
    	}
    	LOG.info("Completed Fetching all the Matching Target List.");
    	return bakeryResponseVO;
    	
    }
    @RequestMapping(value = "/additionalTargetRetailsScanBakeryList",method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public@ResponseBody PerishableAdditionalDetailsDto getadditionalRetailscanDetails(@RequestBody String corpItemCd) {
    	return bakeryMappingServices.getadditionalRetailscanDetails(corpItemCd);    			
    }

    @RequestMapping(value = "/loadOnMapEditFields", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody Map loadOnMapEditFields(@RequestBody ManualMatchAdtnlFieldLoadInputVo inputVo){
    	return bakeryMappingServices.fetchTargetEditITems(inputVo);
    }

}