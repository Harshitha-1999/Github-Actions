
package com.safeway.app.memi.filters;	

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OssoFilter implements Filter {
	
	public static String swyOssoCookie = "swyEntDirectoryPro";
	
	@Override
	public void destroy(){}
	
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException{
		
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		
		if(servletRequest instanceof HttpServletRequest){
			Enumeration<String> en = request.getHeaderNames();
			
			while(en.hasMoreElements()){
				String string = (String) en.nextElement();
				
				Enumeration<String> en1 = request.getHeaders(string);
				while(en1.hasMoreElements()){
					String string1 = (String) en1.nextElement();
				}
			}
			
			GetServerStatusResponse statusResponse = new GetServerStatusResponse((HttpServletResponse) servletResponse);
			AlterServletRequest alterServletRequest = new AlterServletRequest(request);
		
			try {
				filterChain.doFilter(alterServletRequest, statusResponse);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}else{
			filterChain.doFilter(servletRequest, servletResponse);
		}
	}
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	} 
}
