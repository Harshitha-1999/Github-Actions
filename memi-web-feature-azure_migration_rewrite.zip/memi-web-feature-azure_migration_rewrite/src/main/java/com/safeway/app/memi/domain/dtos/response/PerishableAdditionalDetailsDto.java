package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PerishableAdditionalDetailsDto {
	
	private BigDecimal rogCount;	
	private List<PerishableMappingRetailScanDetails> addtionalDetailsList =new ArrayList();

	public BigDecimal getRogCount() {
		return rogCount;
	}

	public void setRogCount(BigDecimal rogCount) {
		this.rogCount = rogCount;
	}

	public List<PerishableMappingRetailScanDetails> getAddtionalDetails() {
		return addtionalDetailsList;
	}

	public void setAddtionalDetails(List<PerishableMappingRetailScanDetails> addtionalDetailsList) {
		this.addtionalDetailsList = addtionalDetailsList;
	}
	public void addAdditonaldetais(PerishableMappingRetailScanDetails additonaldetail)
	{
		addtionalDetailsList.add(additonaldetail);
	}

}

