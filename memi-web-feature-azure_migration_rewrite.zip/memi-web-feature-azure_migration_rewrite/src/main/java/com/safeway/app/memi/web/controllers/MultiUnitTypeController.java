package com.safeway.app.memi.web.controllers;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceTargetSearchRequest;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSrcTargetDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitTypeTargetDto;
import com.safeway.app.memi.domain.services.MultiUnitTypeService;

/**
 * 
 * REST service controller class for Multi-unit type  Item
 * 
 */
@Controller
@RequestMapping("/multiUnitType")
public class MultiUnitTypeController {
	private static final Logger LOG = LoggerFactory.getLogger(MultiUnitTypeController.class);
	
	@Autowired
	private MultiUnitTypeService multiUnitTypeService;
	
	@RequestMapping(value = "/loadMultiUnit/{company}/{division}/{matchIndicator}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody MultiUnitSrcTargetDto getSourceTargetData(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("matchIndicator") String matchIndicator) {
		
		LOG.info("Started fetching source & target multi-unit records.");
		
		MultiUnitSrcTargetDto resonse = multiUnitTypeService.fetchMultiUnitData(company,division,matchIndicator);
		
		LOG.info("Completed fetching source & target multi-unit records.");
		return resonse;
	}
	
	@RequestMapping(value = "/listSrcOnTarSel", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MultiUnitSourceDto> getMultiUnitTypeSourceDataBasedOnTarget(@RequestBody List<MultiUnitTypeTargetDto> multiUnitTarget) {

           LOG.info("Fetching source records based on target selection");

           List<MultiUnitSourceDto> response = multiUnitTypeService.getMultiUnitTypeSourceDataList(multiUnitTarget);

           LOG.info("Completed fetching source records based on target selection");

           return response;

    }
	
	
	@RequestMapping(value = "/listTargetOnSrcSel", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MultiUnitTypeTargetDto> getMultiUnitTypeTargetDataBasedOnSource(@RequestBody List<MultiUnitSourceDto> multiUnitSource) {

           LOG.info("Fetching target records based on source selection");

           List<MultiUnitTypeTargetDto> response = multiUnitTypeService.getMultiUnitTypeTargetDataList(multiUnitSource);

           LOG.info("Completed fetching target records based on source selection");

           return response;

    }
	
	@RequestMapping(value = "/mapMultiUnitItem", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody  Map<String, String> updateSouceBasedOnTarget(@RequestBody MultiUnitSrcTargetDto multiUnitSrcTargetDto) {
			
			LOG.info("updateSouceBasedOnTarget() execution started for multiunit");
		
    	   	Map<String, String> resonse = multiUnitTypeService.updateSourceBasedOnTarget(multiUnitSrcTargetDto);
    	   	
    	   	LOG.info("updateSouceBasedOnTarget() execution completed for multiunit ");
    	   	
           return resonse;
    }
	
	@RequestMapping(value = "/markMultiUnitDead", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody Map<String, List<String>> markMultiUnitItemDead(
                  @RequestBody List<MultiUnitSourceDto> multiUnitSource) {
		    LOG.info("markMultiUnitItemDead() execution started for multiunit");
		    
		    Map<String, List<String>> resonse = multiUnitTypeService.markMultiUnitItemsAsDead(multiUnitSource);
            
            LOG.info("markMultiUnitItemDead() execution completed for multiunit");
            
           return resonse;
    }
	
	@RequestMapping(value = "/markNotAMultiUnit", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody Map<String, List<String>> unMarkMultiUnit(
                  @RequestBody List<MultiUnitSourceDto> multiUnitSource) {
		
		    LOG.info("unMarkMultiUnit() execution started for multiunit");
		    
		    Map<String, List<String>> resonse = multiUnitTypeService.markNotAMultiUnitItem(multiUnitSource);
            
            LOG.info("unMarkMultiUnit() execution completed for multiunit");
           
            return resonse;

    }
	
	 @RequestMapping(value = "/multiUnitSourceSearch", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	    public @ResponseBody List<MultiUnitSourceDto> getMultiUnitSourceDetail(@RequestBody List<MultiUnitSourceTargetSearchRequest> sourceRequest) {

		 	   LOG.info("getMultiUnitSourceDetail() execution started for multiunit");

	           List<MultiUnitSourceDto> response = multiUnitTypeService.getMultiUnitSourceDetail(sourceRequest);

	           LOG.info("getMultiUnitSourceDetail() execution completed for multiunit");

	           return response;

	    }
	 
	 @RequestMapping(value = "/multiUnitTargetSearch", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	    public @ResponseBody List<MultiUnitTypeTargetDto> getMultiUnitTargetDetail(@RequestBody List<MultiUnitSourceTargetSearchRequest> targetRequest) {

	           LOG.info("getMultiUnitTargetDetail() execution started for multiunit");

	           List<MultiUnitTypeTargetDto> response = multiUnitTypeService.getMultiUnitTargetDetail(targetRequest);

	           LOG.info("getMultiUnitTargetDetail() execution completed for multiunit");

	           return response;

	    }
	 
	 @RequestMapping(value = "/unMapMultiUnitItem", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	    public @ResponseBody  Map<String, String> updateSouceBasedOnTargetUnmap(@RequestBody MultiUnitSrcTargetDto multiUnitSrcTargetDto) {
				
				LOG.info("updateSouceBasedOnTargetUnmap() execution started for multiunit");
			
				Map<String, String> resonse = multiUnitTypeService.updateSourceBasedOnTargetUnMap(multiUnitSrcTargetDto);
	    	   	
	    	   	LOG.info("updateSouceBasedOnTargetUnmap() execution completed for multiunit");
	    	   	
	           return resonse;
	    }
	 
	 @RequestMapping(value = "/markItemAsMultiUnit", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	    public @ResponseBody  Map<String, String> markItemAsMultiUnit(@RequestBody List<MultiUnitSourceDto> multiUnitSourceDto) {
				
				LOG.info("markItemAsMultiUnit() execution started for multiunit");
			
				Map<String, String> resonse = multiUnitTypeService.markItemAsMultiUnit(multiUnitSourceDto);
	    	   	
	    	   	LOG.info("markItemAsMultiUnit() execution completed for multiunit");
	    	   	
	           return resonse;
	    }
	 @RequestMapping(value = "/loadMultiUnitSourceRefresh/{company}/{division}/{matchIndicator}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public @ResponseBody MultiUnitSrcTargetDto getSourceDataRefresh(
				@PathVariable("company") String company,
				@PathVariable("division") String division,
				@PathVariable("matchIndicator") String matchIndicator) {
			
			LOG.info("Fetching multi-unit source records on data refresh");
			
			MultiUnitSrcTargetDto resonse = multiUnitTypeService.fetchMultiUnitSourceData(company,division,matchIndicator);
			
			LOG.info("Completed fetching multi-unit source records on data refresh");
			return resonse;
		}
	 @RequestMapping(value = "/loadMultiUnitTargetRefresh/{company}/{division}/{matchIndicator}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public @ResponseBody MultiUnitSrcTargetDto getTargetDataRefresh(
				@PathVariable("company") String company,
				@PathVariable("division") String division,
				@PathVariable("matchIndicator") String matchIndicator) {
			
			LOG.info("Fetching multi-unit target records on data refresh");
			
			MultiUnitSrcTargetDto resonse = multiUnitTypeService.fetchMultiUnitTargetData(company,division,matchIndicator);
			
			LOG.info("Completed fetching multi-unit target records on data refresh");
			return resonse;
		}
	 
	 @RequestMapping(value = "/loadMultiUnitTargetUpcPopUp/{corpItemCd}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public @ResponseBody List<Object[]> getTargetUPCPopUpDetails(@PathVariable("corpItemCd") String corpItemCd) {
			
			LOG.info("Fetching multi-unit target upc pop-up details");			
			
			List<Object[]> response=multiUnitTypeService.fetchMuTTargetUpcPopUpData(corpItemCd);
			
			LOG.info("Completed fetching multi-unit target records on data refresh");
			return response;
		}
	 
}
