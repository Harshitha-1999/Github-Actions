/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

/* ***************************************************************************
 * NAME : CompanyServiceImpl 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 May 03, 2017 - sgang06 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.SMICDetail;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.SMICDetailRepository;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.SMICDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.services.SMICDetailService;

/**
 * 
 * Implementation class for SMIC Detail Services
 *
 */
@Service("smicDetailService")
public class SMICDetailServiceImpl implements SMICDetailService {

    private static final Logger LOG = LoggerFactory.getLogger(SMICDetailServiceImpl.class);

    
    @Autowired
    private SMICDetailRepository smicRepo;
    
    @Autowired
    private CommonSQLRepository commonSQLRepo;

    private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.SMICDetailService#getAllItems()
	 */
	@Override
	public List<SMICDetailDto> getAllItems() {
		LOG.info("Execution started for getting all SMIC items list");
		List<SMICDetail> smicList = smicRepo.findAll();
		LOG.info("Execution completed for getting all"+smicList.size()+" SMIC items list");

		return viewAdapter.mapToSMICDetailDtoList(smicList);
	}

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.SMICDetailService#findByGrpCdAndCtgryCdAndClsCdAndSbClsCdAndSubSbClass(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<SMICDetailDto> findByGrpCdAndCtgryCdAndClsCdAndSbClsCdAndSubSbClass(
			String grpCd, String ctgryCd, String clsCd, String sbClsCd,
			String subSbClass) {
		LOG.info("Execution started for getting all SMIC items list based on GrpCd And CtgryCd And ClsCd And SbClsCd And SubSbClass");

		List<SMICDetail> smicList = smicRepo.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(grpCd, ctgryCd, clsCd, sbClsCd, subSbClass);
		LOG.info("Execution completed for getting all "+smicList.size()+ " SMIC items list based on GrpCd And CtgryCd And ClsCd And SbClsCd And SubSbClass");

		return viewAdapter.mapToSMICDetailDtoList(smicList);
	}

	@Override
	public List<SmicCodeDescWrapper> getGroupCode() {
		LOG.info("Execution started for getting groupCode And DescList");

		List<Object[]> groupCodeAndDescList = commonSQLRepo.fetchGroupCodeWithDesc();
		LOG.info("Execution completed for getting"+groupCodeAndDescList.size()+"  groupCode And DescList");

		return viewAdapter.mapCodeWithDesc(groupCodeAndDescList);
	}

	@Override
	public List<SmicCodeDescWrapper> getCategoryCode(String groupCode) {
		LOG.info("Execution started for getting categoryCode And DescList");

		List<Object[]> categoryCodeAndDescList = commonSQLRepo.fetchCategoryCodeWithDesc(groupCode);
		LOG.info("Execution completed for getting"+categoryCodeAndDescList.size()+"  categoryCode And DescList");

		return viewAdapter.mapCodeWithDesc(categoryCodeAndDescList);
	}

	@Override
	public List<SmicCodeDescWrapper> getClassCode(String groupCode,
			String categoryCode) {
		LOG.info("Execution started for getting classCode And DescList");

		List<Object[]> classCodeAndDescList = commonSQLRepo.fetchClassCodeWithDesc(groupCode,categoryCode);
		LOG.info("Execution completed for getting"+classCodeAndDescList.size()+"  classCode And DescList");

		return viewAdapter.mapCodeWithDesc(classCodeAndDescList);
	}

	@Override
	public List<SmicCodeDescWrapper> getSubClassCode(String groupCode,
			String categoryCode, String classCode) {
		LOG.info("Execution started for getting sub Class Code And DescList");

		List<Object[]> subClassCodeAndDescList = commonSQLRepo.fetchSubClassCodeWithDesc(groupCode,categoryCode,classCode);
		LOG.info("Execution completed for getting"+subClassCodeAndDescList.size()+"  sub Class Code And DescList");

		return viewAdapter.mapCodeWithDesc(subClassCodeAndDescList);
	}

	@Override
	public List<SmicCodeDescWrapper> getSubSubClassCode(String groupCode,
			String categoryCode, String classCode, String subClassCode) {
		LOG.info("Execution started for getting subSubClassCode And DescList");

		List<Object[]> subSubClassCodeAndDescList = commonSQLRepo.fetchSubSubClassCodeWithDesc(groupCode,categoryCode,classCode,subClassCode);
		LOG.info("Execution completed for getting"+subSubClassCodeAndDescList.size()+"  subSubClassCode And DescList");

		return viewAdapter.mapCodeWithDesc(subSubClassCodeAndDescList);
	}
	

}