package com.safeway.app.memi.domain.services.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.LookUpSearchObjectTemplate;
import com.safeway.app.memi.data.repositories.LookUpSearchRepository;
import com.safeway.app.memi.data.repositories.LookUpSearchTemplateRepository;
import com.safeway.app.memi.domain.adapters.LookUpScreenAdapter;
import com.safeway.app.memi.domain.dtos.response.LookUpActionRequest;
import com.safeway.app.memi.domain.dtos.response.LookUpCustomizationVO;
import com.safeway.app.memi.domain.dtos.response.LookUpScreenLoadVO;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchInputs;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultVOS;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultWrapper;
import com.safeway.app.memi.domain.services.LookUpService;
import com.safeway.app.memi.domain.util.LookUpConstants;
import com.safeway.app.memi.domain.util.SortColumns;

@Service("LookUpService")
public class LookUpServiceImpl implements LookUpService {

	private static final Logger LOG  = LoggerFactory.getLogger(LookUpServiceImpl.class);
	@Autowired
	LookUpSearchRepository lookUpSearchRepo;
	@Autowired
	LookUpSearchTemplateRepository templateRepo;
	
	@Autowired
	LookUpScreenAdapter lookUpAdapter;
	
	@Override
	public LookUpScreenLoadVO lookUpScreenLoad(String companyId,
			String divisionId, String userId) {
		LOG.info("Execution started to Load look Up Screen ");
		LookUpScreenLoadVO loadVO =new LookUpScreenLoadVO();
		
		List<Object[]> departments = lookUpSearchRepo.fetchAllConvGroups(companyId,divisionId);
		
			loadVO.addAllConvDepartment(departments);
			loadVO.addAllConversionStatus();
			loadVO.addAllItemSets();	
		
		List<LookUpSearchObjectTemplate> template =templateRepo.findByUserId(userId);
		if(template !=null && !template.isEmpty())
		{
			LookUpSearchObjectTemplate temlateObj=template.get(0);
			byte [] custColumn=temlateObj.getCustColumn();
			
			
			try {
			   ByteArrayInputStream bais =new ByteArrayInputStream(custColumn);			
				ObjectInputStream ois =new ObjectInputStream(bais);
				LookUpCustomizationVO customVO = (LookUpCustomizationVO) ois.readObject();
				loadVO.setCustomVO(customVO);
				
			} catch (Exception e) {
				LOG.error(e.getMessage(),e);
			} 
		}
		LOG.info("Execution completed to Load look Up Screen ");

		return loadVO;
	}

	@Override
	public Map saveLookUpCostomization(LookUpCustomizationVO customVO) {
		LOG.info("Execution started to save LookUp Costomization ");
		 byte[] custColumn = null;
		    // ObjectOutputStream is used to convert a Java object into OutputStream
		    try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
		            ObjectOutputStream oos = new ObjectOutputStream(baos);) {
		        oos.writeObject(customVO);
		        custColumn = baos.toByteArray();
		        
		        LookUpSearchObjectTemplate template=new LookUpSearchObjectTemplate();
				template.setUserId(customVO.getUserId());
				template.setCustColumn(custColumn);
				template.setUpdateTs(new Date());
				templateRepo.saveAndFlush(template);
				
		    } catch (IOException e) {

		        LOG.error(e.getMessage(),e);

		    }
		
			LOG.info("Execution completed to save LookUp Costomization ");

		return null;
		
	}

	@Override
	public LookUpSearchResultWrapper fetchLookUpResult(
			LookUpSearchInputs searchInput) {
		LOG.info("Execution started to fetch LookUp Result ");
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder conditonalJoins =buildConditonalJoins(searchInput);
		StringBuilder filterSearchConditons =buildSearchConditions(searchInput,baseParams);
		StringBuilder sortColumns =buildSortConditions(searchInput);
		LOG.info("sortColumns Result {} ",sortColumns.toString());
		
		baseParams.put("companyId", searchInput.getCompanyId());
		baseParams.put("divisionId", searchInput.getDivisionId());
		baseParams.put("prodHierarchyLvl4Cd", searchInput.getProdHierarchyLvl4Cd());
		baseParams.put("start_index", searchInput.getStartIndex());
		baseParams.put("end_index", searchInput.getEndIndex());
		baseParams.put("convgroupcd", searchInput.getConversionGroupCd());
		if(searchInput.getConversionStatus().contains("-")) {
			baseParams.put("convStatusSuBCDStrList", searchInput.getConversionStatus());
			baseParams.put("convStatusSuBCD", searchInput.getConversionStatus());
		}
		
	 List<Object[]> resultList =lookUpSearchRepo.fetchLookUpSearchResult(filterSearchConditons.toString(),conditonalJoins.toString(),baseParams,sortColumns);
	 List<LookUpSearchResultVOS> resultRows=lookUpAdapter.buildLookUpSearchResultDto(resultList);
	 LookUpSearchResultWrapper resultwrapper =new LookUpSearchResultWrapper();
	 resultwrapper.setSerchResults(resultRows);
	 resultwrapper.setCount( resultRows.isEmpty() ? new BigDecimal("0") : new BigDecimal(resultRows.size()));
	 resultwrapper.setStart_index(new BigDecimal(searchInput.getStartIndex()));
	 resultwrapper.setEnd_index(new BigDecimal(searchInput.getEndIndex()));
		LOG.info("Execution completed to fetch LookUp Result ");

		return resultwrapper;
	}

	private StringBuilder buildConditonalJoins(LookUpSearchInputs searchInput) {
		LOG.debug("Execution started to build Conditonal Joins ");

		StringBuilder joinConditon = new StringBuilder("");
		if(searchInput.getItemType() !=null && !searchInput.getItemType().trim().equals("") 	)
		{
			String itemType=searchInput.getItemType().trim().toUpperCase();
			if (itemType.equalsIgnoreCase("MUT") ||itemType.equalsIgnoreCase("REG"))
			{			
				joinConditon.append(" LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU "
			              + " ON  XRF.COMPANY_ID = MU.COMPANY_ID "
			              + " AND XRF.DIVISION_ID = MU.DIVISION_ID "
			              + " AND XRF.SRC_PRODUCT_SKU = MU.PRODUCT_SKU " );
			
			}
		}

		LOG.debug("Execution completed to build Conditonal Joins ");

		return joinConditon;
	}

	private StringBuilder buildSearchConditions(LookUpSearchInputs searchInput,Map<String, Object> baseParams) {
		LOG.debug("Execution started to build Search Conditions ");

		StringBuilder queryConditon =new StringBuilder("");
		if(searchInput.getProductSKU() !=null && !searchInput.getProductSKU().trim().equals(""))
		{
			queryConditon.append(" AND D.PRODUCT_SKU ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :productSku");
			baseParams.put("productSku", searchInput.getProductSKU().trim());
			
		}
		
		if(searchInput.getItemDescription() !=null && !searchInput.getItemDescription().trim().equals(""))
		{
			queryConditon.append(" AND D.ITEM_DESC ");
			queryConditon.append(LookUpConstants.LIKE);
			queryConditon.append(" :itemDesc ");
			queryConditon.append(LookUpConstants.LIKE_END);
			baseParams.put("itemDesc", "%"+searchInput.getItemDescription().trim()+"%");
		}
		hierarchyLevelsConditon(searchInput.getProdHierarchyLvl1Cd(),searchInput.getProdHierarchyLvl2Cd(),searchInput.getProdHierarchyLvl3Cd(),queryConditon,baseParams);
		
		
		
		if(searchInput.getConversionGroupCd() !=null && !searchInput.getConversionGroupCd().trim().equals(""))
		{
			queryConditon.append(" AND D.CONV_GROUP_CD ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :convgroupcd");
			baseParams.put("convgroupcd", searchInput.getConversionGroupCd().trim());
			
		}
		
		if(searchInput.getProdHierarchyLvl5Cd() !=null && !searchInput.getProdHierarchyLvl5Cd().trim().equals(""))
		{
			queryConditon.append(" AND UPPER (D.PROD_HIERARCHY_LVL_5_CD) ");
			queryConditon.append(LookUpConstants.LIKE);
			queryConditon.append(" :prodhierarchylvl5cd");
			queryConditon.append(LookUpConstants.LIKE_END);
			baseParams.put("prodhierarchylvl5cd","%"+ searchInput.getProdHierarchyLvl5Cd().trim().toUpperCase()+"%");
			
		}
		
		
		if(searchInput.getSupplierNum() !=null && !searchInput.getSupplierNum().trim().equals(""))
		{
			queryConditon.append(" AND XRF.SRC_SUPPLIER_NUM");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :srcsuppliernum ");
			baseParams.put("srcsuppliernum", searchInput.getSupplierNum().trim());
		}
		
		if(searchInput.getSupplierName() !=null && !searchInput.getSupplierName().trim().equals(""))
		{
			queryConditon.append(" AND UPPER (IV.VENDOR_NM )");
			queryConditon.append(LookUpConstants.LIKE);
			queryConditon.append(" :vendornm");
			queryConditon.append(LookUpConstants.LIKE_END);
			baseParams.put("vendornm", "%"+searchInput.getSupplierName().trim()+"%");
		}
		
		if(searchInput.getCorpItemCd() !=null && !searchInput.getCorpItemCd().trim().equals(""))
		{
			queryConditon.append(" AND XRF.CORP_ITEM_CD ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :corpitemcd");
			baseParams.put("corpitemcd", searchInput.getCorpItemCd().trim());
		}
		pluAndSearchUPCCondition(searchInput.getPlu(),searchInput.getUpc(),queryConditon,baseParams);
		
		if(searchInput.getItemType() !=null && !searchInput.getItemType().trim().equals(""))
		{
			addItemTypeConditions(searchInput.getItemType().trim(),queryConditon)	;
		}
		
		if(searchInput.getConversionStatus() !=null && !searchInput.getConversionStatus().trim().equals(""))
		{
			conversionStatusSearchConditon(searchInput.getConversionStatus().trim(),queryConditon,baseParams);
			
		}
		if(searchInput.getSupplyType() !=null && !searchInput.getSupplyType().trim().equals(""))
		{
			supplyTypeSearchConditon(searchInput.getSupplyType().trim(),queryConditon);
			
		}
		
		searchWithProdHierarchyNameConditon(searchInput.getProducthierarchyName(),queryConditon,baseParams);
		
		LOG.debug("Execution completed to build Search Conditions ");

		return queryConditon;
	}


	private void hierarchyLevelsConditon(String prodHierarchyLvl1Cd,
			String prodHierarchyLvl2Cd, String prodHierarchyLvl3Cd,
			StringBuilder queryConditon,Map<String, Object> baseParams) {
		LOG.debug("Execution started to hierarchy Levels Conditon ");

		if(prodHierarchyLvl1Cd !=null && !prodHierarchyLvl1Cd.trim().equals(""))
		{
			queryConditon.append(" AND D.PROD_HIERARCHY_LVL_1_CD ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(":prodhierarchylvl1cd");
			baseParams.put("prodhierarchylvl1cd", prodHierarchyLvl1Cd.trim());
			
			
		}
		if(prodHierarchyLvl2Cd !=null && !prodHierarchyLvl2Cd.trim().equals(""))
		{
			queryConditon.append(" AND D.PROD_HIERARCHY_LVL_2_CD ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(":prodhierarchylvl2cd");
			baseParams.put("prodhierarchylvl2cd", prodHierarchyLvl2Cd);
			
		}
		if(prodHierarchyLvl3Cd !=null && !prodHierarchyLvl3Cd.trim().equals(""))
		{
			queryConditon.append(" AND D.PROD_HIERARCHY_LVL_3_CD ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(":prodhierarchylvl3cd");
			baseParams.put("prodhierarchylvl3cd", prodHierarchyLvl3Cd.trim());
			
		}
		LOG.debug("Execution completed to hierarchy Levels Conditon ");

	}

	private void pluAndSearchUPCCondition(String plu, String upc,
			StringBuilder queryConditon,Map<String, Object> baseParams) {
		LOG.debug("Execution started to plu And Search UPCCondition ");

		
		if(plu !=null && !plu.trim().equals(""))
		{
			queryConditon.append(" AND  XRF.SRC_UPC_COUNTRY =0 AND XRF.SRC_UPC_SYSTEM =0 AND XRF.SRC_UPC_MANUF = 0 AND upper( XRF.SRC_UPC_SALES ) ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :srcupcsales");
			queryConditon.append(" AND CAST (D.UPC AS numeric(38, 10))  ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :upc");
			baseParams.put("srcupcsales", plu.trim());
			baseParams.put("upc", plu.trim());
		}
		
		if(upc !=null && !upc.trim().equals(""))
		{
			queryConditon.append(" AND CAST (D.UPC AS numeric(38, 10)) ");
			queryConditon.append(LookUpConstants.EQUALS);
			queryConditon.append(" :upcreplaced");
			baseParams.put("upcreplaced", upc.trim().replaceAll("-", ""));
			
						
		}
		LOG.debug("Execution completed to plu And Search UPCCondition ");

	}
	
	private void addItemTypeConditions(String itemType, StringBuilder queryConditon) {
		
		switch (itemType.toUpperCase())
		{
		case "DIT" : 
			queryConditon.append(" AND D.MULTI_COMP_ITEM_IND = 'Y' ");
			break;
		case "PLU" :
			queryConditon.append(" AND XRF.SRC_UPC_COUNTRY =0 AND XRF.SRC_UPC_SYSTEM =0 AND XRF.SRC_UPC_MANUF = 0 AND XRF.SRC_UPC_SALES > 0 ");
			break;
		case "SYS2" :
			queryConditon.append(" AND xrf.SRC_UPC_COUNTRY = 0  and XRF.SRC_UPC_SYSTEM =2 ");
			break;
		case "SYS4" :
			queryConditon.append(" AND xrf.SRC_UPC_COUNTRY = 0  and XRF.SRC_UPC_SYSTEM =4 ");
			break;
		case "EXP" :
			queryConditon.append(" AND ( D.EXPENSE_ITEM_IND = 'Y' AND D.MATERIAL_ITEM_IND <> 'Y' AND D.COUPON_IND <> 'Y' ) ");
			break;
		case "MTE" :
			queryConditon.append(" AND ( D.EXPENSE_ITEM_IND <> 'Y' AND D.MATERIAL_ITEM_IND = 'Y' AND D.COUPON_IND <> 'Y' ) ");
			break;
		case "MUT" :
			queryConditon.append(" AND ( MU.COMPANY_ID IS NOT NULL AND MU.AUTO_MANUAL_IND <> 'N' ) ");
			break;
		case "MUL" :
			queryConditon.append(" AND D.UPC_CT > 1 ");
			break;
		case "REG" :
			queryConditon.append(" AND D.MULTI_COMP_ITEM_IND <> 'Y' ");
			queryConditon.append(" AND ( D.EXPENSE_ITEM_IND <> 'Y' AND D.MATERIAL_ITEM_IND <> 'Y' AND D.COUPON_IND <> 'Y' ) ");
			queryConditon.append(" AND ( MU.PRODUCT_SKU IS NULL or (MU.PRODUCT_SKU IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' ) ) ");
			queryConditon.append(" AND NOT ( XRF.SRC_UPC_COUNTRY =0 AND XRF.SRC_UPC_SYSTEM  in (0,2,4) AND XRF.SRC_UPC_MANUF = 0 ) ");
			break;	
		default :
			queryConditon.append("");
			break;
			
		}
		
		
	}
	
	private void conversionStatusSearchConditon(String convertionStatusCd,StringBuilder queryConditon,Map<String, Object> baseParams) {
	 
		LOG.debug("Execution started to conversion Status Search Conditon ");
		
		 pendingConversionCheck(convertionStatusCd,queryConditon,baseParams);
		 if(!convertionStatusCd.contains("="))
		{
			String[] convStatusSuBCD =convertionStatusCd.split("-");
			
		queryConditon.append(" AND XRF.CONV_STATUS_CD ");
		queryConditon.append(LookUpConstants.EQUALS);
		queryConditon.append(" :convStatusSuBCD");
		baseParams.put("convStatusSuBCD", convStatusSuBCD[0].toUpperCase());
		
		if(convStatusSuBCD.length>1){
				queryConditon.append(" AND XRF.CONV_STATUS_SUB_CD IN (:convStatusSuBCDStrList");
				queryConditon.append(")");
				baseParams.put("convStatusSuBCDStrList", convertionStatusCd);
			}
		}
		
		 	
			LOG.debug("Execution completed to conversion Status Search Conditon ");

		
	}
	
	

	private void pendingConversionCheck(String convertionStatusCd,StringBuilder queryConditon,Map<String, Object> baseParams) {
		
		LOG.debug("Execution started to pending ConversionCheck ");

		if(convertionStatusCd.contains("="))
		{
			String[] convStatusCD =convertionStatusCd.split("=");
			if(convStatusCD.length>0)
			{
				queryConditon.append(" AND XRF.CONV_STATUS_CD NOT IN (");
				queryConditon.append(" :cnvstatus");
				queryConditon.append(")");
				baseParams.put("cnvstatus", convertionStatusCd);
			}
			
		}
		LOG.debug("Execution completed to pending ConversionCheck ");

	}

	private void supplyTypeSearchConditon(String supplytype,
			StringBuilder queryConditon) {

		if(supplytype.equalsIgnoreCase("W"))
		{
			queryConditon.append(" AND D.SOURCE_BY_WHSE  ='Y' ");
		}
		else if(supplytype.equalsIgnoreCase("D"))
		{
			queryConditon.append(" AND D.SOURCE_BY_DSD  ='Y' ");
		}
		else if(supplytype.equalsIgnoreCase("P"))
		{		
			queryConditon.append(" AND D.SOURCE_BY_PLANT ='Y' ");
		}
		
	}

	private void searchWithProdHierarchyNameConditon(String prodHierarchyName,
			StringBuilder queryConditon,Map<String, Object> baseParams) {
		LOG.debug("Execution started for search With Prod Hierarchy Name Conditon ");

		if(prodHierarchyName!=null && !prodHierarchyName.trim().equals(""))
		{
					 
			    queryConditon.append(" AND ( UPPER (PH1.HIERARCHY_LEVEL_DESC)  ");
				queryConditon.append(LookUpConstants.LIKE);
				queryConditon.append(" :hierarchylvldsc1");
				queryConditon.append(LookUpConstants.LIKE_END);
				baseParams.put("hierarchylvldsc1", "%"+prodHierarchyName.toUpperCase()+"%");
				
				queryConditon.append(" OR UPPER( PH2.HIERARCHY_LEVEL_DESC ) ");
				queryConditon.append(LookUpConstants.LIKE);
				queryConditon.append(" :hierarchylvlds2");
				queryConditon.append(LookUpConstants.LIKE_END);
				baseParams.put("hierarchylvlds2", "%"+prodHierarchyName.toUpperCase()+"%");
				
				queryConditon.append(" OR upper( PH3.HIERARCHY_LEVEL_DESC )  ");
				queryConditon.append(LookUpConstants.LIKE);
				queryConditon.append(" :hierarchylvlds3");
				queryConditon.append(LookUpConstants.LIKE_END);
				baseParams.put("hierarchylvlds3", "%"+prodHierarchyName.toUpperCase()+"%");
				
				queryConditon.append(" ) ");
			  
			  
			
		}
		
		LOG.debug("Execution completed for search With Prod Hierarchy Name Conditon ");

	}
	private StringBuilder buildSortConditions(LookUpSearchInputs searchInput) {
		StringBuilder columns =new StringBuilder("");
		
		 if(searchInput.getSortItems()!=null)
		 {
			 for (String key :searchInput.getSortItems())
			 {
				 if(!columns.toString().equals(""))
				 {
					 columns.append(",");
				 }
				 
				 SortColumns sc=SortColumns.valueOf( key);
				 if(sc.getColumns().equalsIgnoreCase("SRC.SRC_SUPPLIER_NUM")) {
					 columns.append("SRC_SUPPLIER_NUM");
				 }else {
					 columns.append(sc.getColumns());
				 }
			 }
			 
		 }
			/*
			 * if(columns.toString().equals("")) {
			 * columns.append(SortColumns.LKPSKU.getColumns()); }
			 */
		 
		 if( !columns.toString().equals("") && searchInput.getSortOrder() !=null && searchInput.getSortOrder().equals("D")){
			 columns.append(" DESC "); 
		 }
		 else if(!columns.toString().equals(""))
		 {
			 columns.append(" ASC ");
		 }
		 
		return  columns;
	}

	@Override
	public List<String> performStatusChanges(List<LookUpActionRequest> actionsRequests,String user) {
		LOG.info("Execution started to perform Status Changes ");


		List<String> errors=validateObjects(actionsRequests);
		if(errors.isEmpty())
		{
			boolean executionresult =true;
		for(LookUpActionRequest actionsRequest:actionsRequests)
		{
			if(executionresult)
			{	String updateStatus=actionsRequest.getChangestatusCd();
			executionresult =	lookUpSearchRepo.updateProductStatus(actionsRequest.getCompanyId(),actionsRequest.getDivisionId(),actionsRequest.getProductSKU(),
				actionsRequest.getUpc().replaceAll("-", ""),updateStatus,user,actionsRequest.getStatusReasonComments());
			}
			else
			{	
				errors.add(" Exception occured");
				break;
			}
		}
		
		}
				
		LOG.info("Execution completed to perform Status Changes ");

		return errors;
		
	}

	private List<String> validateObjects(
			List<LookUpActionRequest> actionsRequests) {
		LOG.debug("Execution started to validate Objects ");

		List<String> errors = new ArrayList();
		String changeStatus =actionsRequests.get(0).getChangestatusCd();
		
		for(LookUpActionRequest actionsRequest:actionsRequests)
		{
		  if(!changeStatus.equals(actionsRequest.getChangestatusCd()))
		  {
			  errors.add("Conflict in action reuests : Not in same category");  
		  }
		  if(actionsRequest.getChangestatusCd().equals("READY") && 
				  !actionsRequest.getCurrentStatusCd().equalsIgnoreCase("C") )
		  {
			  errors.add("Product SKu ="+actionsRequest.getProductSKU()+" upc "+actionsRequest.getUpc()+ " is not suitable to convert to ready state"); 
		  }
		  else if(actionsRequest.getChangestatusCd().equals("DEAD")&& 
				    actionsRequest.getCurrentStatusCd().equalsIgnoreCase("D")  )
		  {
			  errors.add("Product SKu ="+actionsRequest.getProductSKU()+" upc "+actionsRequest.getUpc()+ " is already in dead state"); 
		  }
		
		}
		LOG.debug("Execution completed to validate Objects ");

		return errors;
	}

	
}


