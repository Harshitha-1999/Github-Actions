/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */

package com.safeway.app.memi.domain.dtos.response;


import java.util.List;
/**
 ****************************************************************************
 * NAME : PerishableMappingResponseVO 
 * 
 * DESCRIPTION :PerishableMappingResponseVO is the class to store the the mapping response of mapping action such as Add map, 
 * inherit map, let auto match, mark as dead,force new, unmap,convert
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */
public class PerishableMappingResponseVO {
	private List<PerishableMappedItemVO> mappedItems; 
	private PerishableSearchRequestVO sourceSearchResponse;
	private PerishableSearchRequestVO targetSearchResponse;
	/**
	 * @return the mappedItems
	 */
	public List<PerishableMappedItemVO> getMappedItems() {
		return mappedItems;
	}
	/**
	 * @param mappedItems the mappedItems to set
	 */
	public void setMappedItems(List<PerishableMappedItemVO> mappedItems) {
		this.mappedItems = mappedItems;
	}
	/**
	 * @return the sourceSearchResponse
	 */
	public PerishableSearchRequestVO getSourceSearchResponse() {
		return sourceSearchResponse;
	}
	/**
	 * @param sourceSearchResponse the sourceSearchResponse to set
	 */
	public void setSourceSearchResponse(PerishableSearchRequestVO sourceSearchResponse) {
		this.sourceSearchResponse = sourceSearchResponse;
	}
	/**
	 * @return the targetSearchResponse
	 */
	public PerishableSearchRequestVO getTargetSearchResponse() {
		return targetSearchResponse;
	}
	/**
	 * @param targetSearchResponse the targetSearchResponse to set
	 */
	public void setTargetSearchResponse(PerishableSearchRequestVO targetSearchResponse) {
		this.targetSearchResponse = targetSearchResponse;
	}
	
		

}



