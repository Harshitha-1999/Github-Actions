package com.safeway.app.memi.domain.dtos.response;


public class ExcelFileDto {
	private String action;
	private String companyId;
	private String divisionId;
	private String productSku;
	private String productSrcCd;
	private String upc;
	private String itemDesc;
	private String internetDesc;
	private String srcWhseitemDesc;
	private String srcRtlInternetDesc;
	private String srcPosDesc;
	private String pack;
	private String vendConvFactor;
	private String numSize;
	private String caseUpc;
	private String itmUsgeInd;
	private String itmUsgeTypeInd;
	private String dspFlag;
	private String primaryUpcInd;
	
	private String vendorCost;
	private String slotId;
	private String onhandNbr;
	private String categoryDesc;
	private String subCategoryDesc;
	private String groupDesc;
	private String newDate;
	private String lastShipDate;
	private String lastSaleDate;
	private String totalSales;
	private String casesOrdered;
	private String productionGrpCd;
	private String productionCtgryCd;
	private String productionClsCd;
	private String ethnicTypeCd;
	private String pckTypeId;
	private String productClsCd;
	private String innerPack;
	private String retailUnitPack;
	private String updItemDesc;
	private String updWhseItemDesc;	
	private String updRtlItemDesc;
	private String updInternetItemDesc;
	private String updPosDesc;
	private String updItemUsageInd;
	private String updItemUsageTypInd;
	private String updPrivateLabelInd;
	private String updDispFlag;
	private String updSize;
	private String updSizeNmbr;
	private String updSizeUom;	
	private String srcSizeUom;
	private String grpCd;
	private String ctgryCd;
	private String clsCd;
	private String sbClsCd;
	private String subSbClassCd;
	
	private String hierLevel1;
    private String hierLevel2;
    private String hierLevel3;
    private String hierLevel4;
    private String hierLevel5;
    private String batchId;
    private String exceptionTypeCode;
    private String exceptionDesc;
    private String convTeamComments;
    
    /*Produce PLU*/
  	private String updUpc;
  	private String updPlu; 
    private String dcPackDesc;
	private String dcSizeDsc;
	private String ring;
	private String hicone;
	/*additional fields*/
	private String prodwght;
	private String handlingCode;
	private String buyerNum;
	private String randomWtCd;	
	private String autoCostInv; 
	private String billingType;
	private String fdStmp;
	private String labelSize;
	private String labelNumbers;
	private String sgnCount1;
	private String sgnCount2;
	private String sgnCount3;
	private String sellByDays;
	private String useByDays;
	private String pullBydays;
	private String tareCd;
    
    public String getUpdPlu() {
		return updPlu;
	}
	public void setUpdPlu(String updPlu) {
		this.updPlu = updPlu;
	}
	public String getRing() {
		return ring;
	}
	public void setRing(String ring) {
		this.ring = ring;
	}
	public String getHicone() {
		return hicone;
	}
	public void setHicone(String hicone) {
		this.hicone = hicone;
	}
    public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
    
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getProductSku() {
		return productSku;
	}
	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}
	public String getProductSrcCd() {
		return productSrcCd;
	}
	public void setProductSrcCd(String productSrcCd) {
		this.productSrcCd = productSrcCd;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public String getInternetDesc() {
		return internetDesc;
	}
	public void setInternetDesc(String internetDesc) {
		this.internetDesc = internetDesc;
	}
	public String getSrcWhseitemDesc() {
		return srcWhseitemDesc;
	}
	public void setSrcWhseitemDesc(String srcWhseitemDesc) {
		this.srcWhseitemDesc = srcWhseitemDesc;
	}
	public String getSrcRtlInternetDesc() {
		return srcRtlInternetDesc;
	}
	public void setSrcRtlInternetDesc(String srcRtlInternetDesc) {
		this.srcRtlInternetDesc = srcRtlInternetDesc;
	}
	public String getSrcPosDesc() {
		return srcPosDesc;
	}
	public void setSrcPosDesc(String srcPosDesc) {
		this.srcPosDesc = srcPosDesc;
	}
	public String getPack() {
		return pack;
	}
	public void setPack(String pack) {
		this.pack = pack;
	}
	public String getVendConvFactor() {
		return vendConvFactor;
	}
	public void setVendConvFactor(String vendConvFactor) {
		this.vendConvFactor = vendConvFactor;
	}
	public String getNumSize() {
		return numSize;
	}
	public void setNumSize(String numSize) {
		this.numSize = numSize;
	}
	public String getCaseUpc() {
		return caseUpc;
	}
	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}
	public String getItmUsgeInd() {
		return itmUsgeInd;
	}
	public void setItmUsgeInd(String itmUsgeInd) {
		this.itmUsgeInd = itmUsgeInd;
	}
	public String getItmUsgeTypeInd() {
		return itmUsgeTypeInd;
	}
	public void setItmUsgeTypeInd(String itmUsgeTypeInd) {
		this.itmUsgeTypeInd = itmUsgeTypeInd;
	}
	public String getDspFlag() {
		return dspFlag;
	}
	public void setDspFlag(String dspFlag) {
		this.dspFlag = dspFlag;
	}
	public String getPrimaryUpcInd() {
		return primaryUpcInd;
	}
	public void setPrimaryUpcInd(String primaryUpcInd) {
		this.primaryUpcInd = primaryUpcInd;
	}
	public String getVendorCost() {
		return vendorCost;
	}
	public void setVendorCost(String vendorCost) {
		this.vendorCost = vendorCost;
	}
	public String getSlotId() {
		return slotId;
	}
	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}
	public String getOnhandNbr() {
		return onhandNbr;
	}
	public void setOnhandNbr(String onhandNbr) {
		this.onhandNbr = onhandNbr;
	}
	public String getCategoryDesc() {
		return categoryDesc;
	}
	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}
	public String getSubCategoryDesc() {
		return subCategoryDesc;
	}
	public void setSubCategoryDesc(String subCategoryDesc) {
		this.subCategoryDesc = subCategoryDesc;
	}
	public String getGroupDesc() {
		return groupDesc;
	}
	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}
	public String getNewDate() {
		return newDate;
	}
	public void setNewDate(String newDate) {
		this.newDate = newDate;
	}
	public String getLastShipDate() {
		return lastShipDate;
	}
	public void setLastShipDate(String lastShipDate) {
		this.lastShipDate = lastShipDate;
	}
	public String getLastSaleDate() {
		return lastSaleDate;
	}
	public void setLastSaleDate(String lastSaleDate) {
		this.lastSaleDate = lastSaleDate;
	}
	public String getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(String totalSales) {
		this.totalSales = totalSales;
	}
	public String getCasesOrdered() {
		return casesOrdered;
	}
	public void setCasesOrdered(String casesOrdered) {
		this.casesOrdered = casesOrdered;
	}
	public String getProductionGrpCd() {
		return productionGrpCd;
	}
	public void setProductionGrpCd(String productionGrpCd) {
		this.productionGrpCd = productionGrpCd;
	}
	public String getProductionCtgryCd() {
		return productionCtgryCd;
	}
	public void setProductionCtgryCd(String productionCtgryCd) {
		this.productionCtgryCd = productionCtgryCd;
	}
	public String getProductionClsCd() {
		return productionClsCd;
	}
	public void setProductionClsCd(String productionClsCd) {
		this.productionClsCd = productionClsCd;
	}
	public String getEthnicTypeCd() {
		return ethnicTypeCd;
	}
	public void setEthnicTypeCd(String ethnicTypeCd) {
		this.ethnicTypeCd = ethnicTypeCd;
	}
	public String getPckTypeId() {
		return pckTypeId;
	}
	public void setPckTypeId(String pckTypeId) {
		this.pckTypeId = pckTypeId;
	}
	public String getProductClsCd() {
		return productClsCd;
	}
	public void setProductClsCd(String productClsCd) {
		this.productClsCd = productClsCd;
	}
	public String getInnerPack() {
		return innerPack;
	}
	public void setInnerPack(String innerPack) {
		this.innerPack = innerPack;
	}
	public String getRetailUnitPack() {
		return retailUnitPack;
	}
	public void setRetailUnitPack(String retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}
	public String getUpdItemDesc() {
		return updItemDesc;
	}
	public void setUpdItemDesc(String updItemDesc) {
		this.updItemDesc = updItemDesc;
	}
	public String getUpdWhseItemDesc() {
		return updWhseItemDesc;
	}
	public void setUpdWhseItemDesc(String updWhseItemDesc) {
		this.updWhseItemDesc = updWhseItemDesc;
	}
	public String getUpdRtlItemDesc() {
		return updRtlItemDesc;
	}
	public void setUpdRtlItemDesc(String updRtlItemDesc) {
		this.updRtlItemDesc = updRtlItemDesc;
	}
	public String getUpdInternetItemDesc() {
		return updInternetItemDesc;
	}
	public void setUpdInternetItemDesc(String updInternetItemDesc) {
		this.updInternetItemDesc = updInternetItemDesc;
	}
	public String getUpdPosDesc() {
		return updPosDesc;
	}
	public void setUpdPosDesc(String updPosDesc) {
		this.updPosDesc = updPosDesc;
	}
	public String getUpdItemUsageInd() {
		return updItemUsageInd;
	}
	public void setUpdItemUsageInd(String updItemUsageInd) {
		this.updItemUsageInd = updItemUsageInd;
	}
	public String getUpdItemUsageTypInd() {
		return updItemUsageTypInd;
	}
	public void setUpdItemUsageTypInd(String updItemUsageTypInd) {
		this.updItemUsageTypInd = updItemUsageTypInd;
	}
	public String getUpdPrivateLabelInd() {
		return updPrivateLabelInd;
	}
	public void setUpdPrivateLabelInd(String updPrivateLabelInd) {
		this.updPrivateLabelInd = updPrivateLabelInd;
	}
	public String getUpdDispFlag() {
		return updDispFlag;
	}
	public void setUpdDispFlag(String updDispFlag) {
		this.updDispFlag = updDispFlag;
	}
	public String getUpdSize() {
		return updSize;
	}
	public void setUpdSize(String updSize) {
		this.updSize = updSize;
	}
	public String getUpdSizeNmbr() {
		return updSizeNmbr;
	}
	public void setUpdSizeNmbr(String updSizeNmbr) {
		this.updSizeNmbr = updSizeNmbr;
	}
	public String getUpdSizeUom() {
		return updSizeUom;
	}
	public void setUpdSizeUom(String updSizeUom) {
		this.updSizeUom = updSizeUom;
	}
	public String getSrcSizeUom() {
		return srcSizeUom;
	}
	public void setSrcSizeUom(String srcSizeUom) {
		this.srcSizeUom = srcSizeUom;
	}
	public String getGrpCd() {
		return grpCd;
	}
	public void setGrpCd(String grpCd) {
		this.grpCd = grpCd;
	}
	public String getCtgryCd() {
		return ctgryCd;
	}
	public void setCtgryCd(String ctgryCd) {
		this.ctgryCd = ctgryCd;
	}
	public String getClsCd() {
		return clsCd;
	}
	public void setClsCd(String clsCd) {
		this.clsCd = clsCd;
	}
	public String getSbClsCd() {
		return sbClsCd;
	}
	public void setSbClsCd(String sbClsCd) {
		this.sbClsCd = sbClsCd;
	}
	public String getSubSbClassCd() {
		return subSbClassCd;
	}
	public void setSubSbClassCd(String subSbClassCd) {
		this.subSbClassCd = subSbClassCd;
	}
	public String getHierLevel1() {
		return hierLevel1;
	}
	public void setHierLevel1(String hierLevel1) {
		this.hierLevel1 = hierLevel1;
	}
	public String getHierLevel2() {
		return hierLevel2;
	}
	public void setHierLevel2(String hierLevel2) {
		this.hierLevel2 = hierLevel2;
	}
	public String getHierLevel3() {
		return hierLevel3;
	}
	public void setHierLevel3(String hierLevel3) {
		this.hierLevel3 = hierLevel3;
	}
	public String getHierLevel4() {
		return hierLevel4;
	}
	public void setHierLevel4(String hierLevel4) {
		this.hierLevel4 = hierLevel4;
	}
	public String getHierLevel5() {
		return hierLevel5;
	}
	public void setHierLevel5(String hierLevel5) {
		this.hierLevel5 = hierLevel5;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public String getExceptionTypeCode() {
		return exceptionTypeCode;
	}
	public void setExceptionTypeCode(String exceptionTypeCode) {
		this.exceptionTypeCode = exceptionTypeCode;
	}
	public String getExceptionDesc() {
		return exceptionDesc;
	}
	public void setExceptionDesc(String exceptionDesc) {
		this.exceptionDesc = exceptionDesc;
	}
	
	public String getConvTeamComments() {
		return convTeamComments;
	}
	public void setConvTeamComments(String convTeamComments) {
		this.convTeamComments = convTeamComments;
	}
	
	@Override
	public String toString() {
		return "ExcelFileDto [action=" + action + ", companyId=" + companyId
				+ ", divisionId=" + divisionId + ", productSku=" + productSku
				+ ", productSrcCd=" + productSrcCd + ", upc=" + upc
				+ ", itemDesc=" + itemDesc + ", internetDesc=" + internetDesc
				+ ", srcWhseitemDesc=" + srcWhseitemDesc
				+ ", srcRtlInternetDesc=" + srcRtlInternetDesc
				+ ", srcPosDesc=" + srcPosDesc + ", pack=" + pack
				+ ", vendConvFactor=" + vendConvFactor + ", numSize=" + numSize
				+ ", caseUpc=" + caseUpc + ", itmUsgeInd=" + itmUsgeInd
				+ ", itmUsgeTypeInd=" + itmUsgeTypeInd + ", dspFlag=" + dspFlag
				+ ", primaryUpcInd=" + primaryUpcInd + ", vendorCost="
				+ vendorCost + ", slotId=" + slotId + ", onhandNbr="
				+ onhandNbr + ", categoryDesc=" + categoryDesc
				+ ", subCategoryDesc=" + subCategoryDesc + ", groupDesc="
				+ groupDesc + ", newDate=" + newDate + ", lastShipDate="
				+ lastShipDate + ", lastSaleDate=" + lastSaleDate
				+ ", totalSales=" + totalSales + ", casesOrdered="
				+ casesOrdered + ", productionGrpCd=" + productionGrpCd
				+ ", productionCtgryCd=" + productionCtgryCd
				+ ", productionClsCd=" + productionClsCd + ", ethnicTypeCd="
				+ ethnicTypeCd + ", pckTypeId=" + pckTypeId + ", productClsCd="
				+ productClsCd + ", innerPack=" + innerPack
				+ ", retailUnitPack=" + retailUnitPack + ", updItemDesc="
				+ updItemDesc + ", updWhseItemDesc=" + updWhseItemDesc
				+ ", updRtlItemDesc=" + updRtlItemDesc
				+ ", updInternetItemDesc=" + updInternetItemDesc
				+ ", updPosDesc=" + updPosDesc + ", updItemUsageInd="
				+ updItemUsageInd + ", updItemUsageTypInd="
				+ updItemUsageTypInd + ", updPrivateLabelInd="
				+ updPrivateLabelInd + ", updDispFlag=" + updDispFlag
				+ ", updSize=" + updSize + ", updSizeNmbr=" + updSizeNmbr
				+ ", updSizeUom=" + updSizeUom + ", srcSizeUom=" + srcSizeUom
				+ ", grpCd=" + grpCd + ", ctgryCd=" + ctgryCd + ", clsCd="
				+ clsCd + ", sbClsCd=" + sbClsCd + ", subSbClassCd="
				+ subSbClassCd + ", hierLevel1=" + hierLevel1 + ", hierLevel2="
				+ hierLevel2 + ", hierLevel3=" + hierLevel3 + ", hierLevel4="
				+ hierLevel4 + ", hierLevel5=" + hierLevel5 + ", batchId="
				+ batchId + ", exceptionTypeCode=" + exceptionTypeCode
				+ ", exceptionDesc=" + exceptionDesc + ", convTeamComments="
				+ convTeamComments + "]";
	}
	
	
	public String getUpdUpc() {
		return updUpc;
	}

	public void setUpdUpc(String updUpc) {
		this.updUpc = updUpc;
	}
	
	public String getDcPackDesc() {
		return dcPackDesc;
	}

	public void setDcPackDesc(String dcPackDesc) {
		this.dcPackDesc = dcPackDesc;
	}

	public String getDcSizeDsc() {
		return dcSizeDsc;
	}

	public void setDcSizeDsc(String dcSizeDsc) {
		this.dcSizeDsc = dcSizeDsc;
	}
	public String getProdwght() {
		return prodwght;
	}
	public void setProdwght(String prodwght) {
		this.prodwght = prodwght;
	}
	public String getHandlingCode() {
		return handlingCode;
	}
	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}
	public String getBuyerNum() {
		return buyerNum;
	}
	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}
	public String getRandomWtCd() {
		return randomWtCd;
	}
	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}
	public String getAutoCostInv() {
		return autoCostInv;
	}
	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getFdStmp() {
		return fdStmp;
	}
	public void setFdStmp(String fdStmp) {
		this.fdStmp = fdStmp;
	}
	public String getLabelSize() {
		return labelSize;
	}
	public void setLabelSize(String labelSize) {
		this.labelSize = labelSize;
	}
	public String getLabelNumbers() {
		return labelNumbers;
	}
	public void setLabelNumbers(String labelNumbers) {
		this.labelNumbers = labelNumbers;
	}
	public String getSgnCount1() {
		return sgnCount1;
	}
	public void setSgnCount1(String sgnCount1) {
		this.sgnCount1 = sgnCount1;
	}
	public String getSgnCount2() {
		return sgnCount2;
	}
	public void setSgnCount2(String sgnCount2) {
		this.sgnCount2 = sgnCount2;
	}
	public String getSgnCount3() {
		return sgnCount3;
	}
	public void setSgnCount3(String sgnCount3) {
		this.sgnCount3 = sgnCount3;
	}
	public String getSellByDays() {
		return sellByDays;
	}
	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}
	public String getUseByDays() {
		return useByDays;
	}
	public void setUseByDays(String useByDays) {
		this.useByDays = useByDays;
	}
	public String getPullBydays() {
		return pullBydays;
	}
	public void setPullBydays(String pullBydays) {
		this.pullBydays = pullBydays;
	}
	public String getTareCd() {
		return tareCd;
	}
	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}
	

	

}
