package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : CompanyRepository 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ManualMapping;

/**
 * Repository class for all DB operations for Company table
 */
@Repository
public interface ManualMappingRepository extends JpaRepository<ManualMapping, Long> {


}
