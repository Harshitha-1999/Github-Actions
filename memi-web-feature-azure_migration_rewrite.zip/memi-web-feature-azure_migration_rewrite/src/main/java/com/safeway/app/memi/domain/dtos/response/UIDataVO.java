package com.safeway.app.memi.domain.dtos.response;
/* ***************************************************************************
 * NAME         : UIDataVO
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Varada Nellayikunnath
 *
  REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 8, 2017 vnell00 - Initial Creation
 *
 ***************************************************************************/
import java.util.Set;

public class UIDataVO {

    private String deptName;
    private int totalRecord;
    private int totalDSDRecords;
    private int totalWHSERecords;
    private Set<String> prdskuSet;
    private int reviewItmCnt;
    private int reviewDSDItmCnt;
    private int reviewWHSEItmCnt;
    private Set<String> reviewItemUPC;
    private int completedItmCnt;
    private int completedDSDItmCnt;
    private int completedWHSEItmCnt;
    private Set<String> completedItemUPC;
    private String deptCode;

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public int getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord) {
        this.totalRecord = totalRecord;
    }

    
    public Set<String> getPrdskuSet() {
        return prdskuSet;
    }

    public void setPrdskuSet(Set<String> prdskuSet) {
        this.prdskuSet = prdskuSet;
    }
  


    public int getReviewItmCnt() {
        return reviewItmCnt;
    }

    public void setReviewItmCnt(int reviewItmCnt) {
        this.reviewItmCnt = reviewItmCnt;
    }

    public Set<String> getReviewItemUPC() {
        return reviewItemUPC;
    }

    public void setReviewItemUPC(Set<String> reviewItemUPC) {
        this.reviewItemUPC = reviewItemUPC;
    }

    @Override
    public String toString() {
        return "UIDataVO [deptName=" + deptName + ", totalRecord=" + totalRecord + ", prdskuSet=" + prdskuSet
            + ", reviewItmCnt=" + reviewItmCnt + ", reviewItemUPC=" + reviewItemUPC + "]";
    }

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	@Override
	public boolean equals(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    if(obj == this)
	    	return true;
	    if (this.getClass() != obj.getClass())
	        return false;
	    if (!UIDataVO.class.isAssignableFrom(obj.getClass())) {
	        return false;
	    }
	    final UIDataVO other = (UIDataVO) obj;
	    if ((this.deptCode == null) ? (other.deptCode != null) : !this.deptCode.equals(other.deptCode)) {
	        return false;
	    }
	    return true;
	}
	
	@Override
	public int hashCode() {
	    int hash = 3;
	    hash = 53 * hash + (this.deptCode != null ? this.deptCode.hashCode() : 0);
	    return hash;
	}

	public int getCompletedItmCnt() {
		return completedItmCnt;
	}

	public void setCompletedItmCnt(int completedItmCnt) {
		this.completedItmCnt = completedItmCnt;
	}

	public Set<String> getCompletedItemUPC() {
		return completedItemUPC;
	}

	public void setCompletedItemUPC(Set<String> completedItemUPC) {
		this.completedItemUPC = completedItemUPC;
	}

	public int getTotalDSDRecords() {
		return totalDSDRecords;
	}

	public void setTotalDSDRecords(int totalDSDRecords) {
		this.totalDSDRecords = totalDSDRecords;
	}

	public int getTotalWHSERecords() {
		return totalWHSERecords;
	}

	public void setTotalWHSERecords(int totalWHSERecords) {
		this.totalWHSERecords = totalWHSERecords;
	}

	public int getReviewDSDItmCnt() {
		return reviewDSDItmCnt;
	}

	public void setReviewDSDItmCnt(int reviewDSDItmCnt) {
		this.reviewDSDItmCnt = reviewDSDItmCnt;
	}

	public int getReviewWHSEItmCnt() {
		return reviewWHSEItmCnt;
	}

	public void setReviewWHSEItmCnt(int reviewWHSEItmCnt) {
		this.reviewWHSEItmCnt = reviewWHSEItmCnt;
	}

	public int getCompletedDSDItmCnt() {
		return completedDSDItmCnt;
	}

	public void setCompletedDSDItmCnt(int completedDSDItmCnt) {
		this.completedDSDItmCnt = completedDSDItmCnt;
	}

	public int getCompletedWHSEItmCnt() {
		return completedWHSEItmCnt;
	}

	public void setCompletedWHSEItmCnt(int completedWHSEItmCnt) {
		this.completedWHSEItmCnt = completedWHSEItmCnt;
	}
   

}
