package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/* ***************************************************************************
 * NAME         : UIExceptionSrcDto
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Subhash G
 *
  REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 2, 2017 sgang06 - Initial Creation
 *
 ***************************************************************************/
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value = { "createTsForSort", "lastUpdateTsForSort" })
public class UIExceptionSrcDto {

    private String companyId;

    private String divisionId;

    private String productSKU;

    private String productSrcCd;

    private String upcCountry;

    private String upcSystem;

    private String upcManufacturer;

    private String upcSales;

    private String PLUcd;

    private Character primryUpcInd;

    private Character itmUsgeInd;

    private Character itmUsgeTypInd;

    private Character ptLblInd;

    private Character dspFlag;

    private String itmDescrbtn;

    private String whseItmDescrbtn;

    private String rtlItmDescrbtn;

    private String intenetItemDescrbtn;

    private String posDescrbtn;

    private BigDecimal vdCnvFactor;

    private BigDecimal packWhse;

    private BigDecimal sizeNbr;

    private String szUom;

    private String szDesc;

    private String costItm;

    private String hierLevel1;

    private String hierLevel2;

    private String hierLevel3;

    private String hierLevel4;

    private String hierLevel5;

    private Character exptnTypCd;

    private String exptnDesc;

    private Character excptnProInd;

    private Integer btId;

    private Character loglInd;

    private String deptName;
    
    private String deptCd;
    
    private List<String>  upcLIst;
    
    private String primaryUPC;
    
    private UPCVo primaryUPCVo;

    private String caseUPC;

    private String updatedUserID;
    
    private List<UPCVo> upcVoList;
    
    private boolean manualMapped = false;
    
    private boolean markedAsDead = false;
    
    private String slotId;
    
    private BigDecimal onhandNbr;
    
    private String hierarchyLvlNm;
    
    private String hierarchyLvlDesc;
    
    private String categoryDesc;
    
    private String subCategoryDesc;
    
    private String groupDesc;
    
    private String newDate;
    
    private String lastShipDate;
    
    private String lastSaleDate;
    
    private BigDecimal totalSales;
    
    private BigDecimal casesOrdered;
    
    private boolean markedForManualMapping = false;
    
    private Integer productionGrpCd;
    
    private Integer productionCtgryCd;
    
    private Integer productionClsCd;
    
    private String ethnicTypeCd;
    
    private BigDecimal pckTypeId;
    
    private Integer productClsCd;
    
    private Integer innerPack;
    
    private Integer retailUnitPack;
    private String upc;
    
	private String updItemDesc;
	private String updWhseItemDesc;
	private String updRtlItemDesc;
	private String updInternetItemDesc;
	private String updPosDesc;
	private Integer grpCd;
	private Integer ctgryCd;
	private Integer clsCd;
	private Integer sbClsCd;
	private Integer subSbClassCd;
	private String updSize;
	private BigDecimal updSizeNmbr;
	private String updSizeUom;
	private Character updItemUsageInd;
	private Character updItemUsageTypInd;
	private Character updPrivateLabelInd;
	private Character updDispFlag;
	private String convTeamComments;
	
	/**PRODUCE related**/
	private String selling_method_cd;
	private String receiving_cd;
	/***/
	/****/
	/**addtional fields**/
	private String srcRing;
	private String srcHicone;
	private String srcProdwght;
	private String srcHandlingCode;
	private String srcBuyerNum;
	private String srcRandomWtCd;	
	private String srcAutoCostInv; 
	private String srcBillingType;
	private String srcFdStmp;
	private String srcLabelSize;
	private String srcLabelNumbers;
	private String srcSgnCount1;
	private String srcSgnCount2;
	private String srcSgnCount3;
	private String tareCd;
	
	/*Display on UI*/
	private String sellByDays;
	private String useByDays;
	private String pullBydays;
	private String cost;
	/***/
	 private String convGroupCd;
	    
	 private String convGroupNm;
	
	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getUpdItemDesc() {
		return updItemDesc;
	}

	public void setUpdItemDesc(String updItemDesc) {
		this.updItemDesc = updItemDesc;
	}

	public String getUpdWhseItemDesc() {
		return updWhseItemDesc;
	}

	public void setUpdWhseItemDesc(String updWhseItemDesc) {
		this.updWhseItemDesc = updWhseItemDesc;
	}

	public String getUpdRtlItemDesc() {
		return updRtlItemDesc;
	}

	public void setUpdRtlItemDesc(String updRtlItemDesc) {
		this.updRtlItemDesc = updRtlItemDesc;
	}

	public String getUpdInternetItemDesc() {
		return updInternetItemDesc;
	}

	public void setUpdInternetItemDesc(String updInternetItemDesc) {
		this.updInternetItemDesc = updInternetItemDesc;
	}

	public String getUpdPosDesc() {
		return updPosDesc;
	}

	public void setUpdPosDesc(String updPosDesc) {
		this.updPosDesc = updPosDesc;
	}

	public Integer getGrpCd() {
		return grpCd;
	}

	public void setGrpCd(Integer grpCd) {
		this.grpCd = grpCd;
	}

	public Integer getCtgryCd() {
		return ctgryCd;
	}

	public void setCtgryCd(Integer ctgryCd) {
		this.ctgryCd = ctgryCd;
	}

	public Integer getClsCd() {
		return clsCd;
	}

	public void setClsCd(Integer clsCd) {
		this.clsCd = clsCd;
	}

	public Integer getSbClsCd() {
		return sbClsCd;
	}

	public void setSbClsCd(Integer sbClsCd) {
		this.sbClsCd = sbClsCd;
	}

	public Integer getSubSbClassCd() {
		return subSbClassCd;
	}

	public void setSubSbClassCd(Integer subSbClassCd) {
		this.subSbClassCd = subSbClassCd;
	}

	public String getUpdSize() {
		return updSize;
	}

	public void setUpdSize(String updSize) {
		this.updSize = updSize;
	}

	public BigDecimal getUpdSizeNmbr() {
		return updSizeNmbr;
	}

	public void setUpdSizeNmbr(BigDecimal updSizeNmbr) {
		this.updSizeNmbr = updSizeNmbr;
	}

	public String getUpdSizeUom() {
		return updSizeUom;
	}

	public void setUpdSizeUom(String updSizeUom) {
		this.updSizeUom = updSizeUom;
	}

	public Character getUpdItemUsageInd() {
		return updItemUsageInd;
	}

	public void setUpdItemUsageInd(Character updItemUsageInd) {
		this.updItemUsageInd = updItemUsageInd;
	}

	public Character getUpdItemUsageTypInd() {
		return updItemUsageTypInd;
	}

	public void setUpdItemUsageTypInd(Character updItemUsageTypInd) {
		this.updItemUsageTypInd = updItemUsageTypInd;
	}

	public Character getUpdPrivateLabelInd() {
		return updPrivateLabelInd;
	}

	public void setUpdPrivateLabelInd(Character updPrivateLabelInd) {
		this.updPrivateLabelInd = updPrivateLabelInd;
	}

	public Character getUpdDispFlag() {
		return updDispFlag;
	}

	public void setUpdDispFlag(Character updDispFlag) {
		this.updDispFlag = updDispFlag;
	}

	public String getConvTeamComments() {
		return convTeamComments;
	}

	public void setConvTeamComments(String convTeamComments) {
		this.convTeamComments = convTeamComments;
	}

	public Integer getProductionGrpCd() {
		return productionGrpCd;
	}

	public void setProductionGrpCd(Integer productionGrpCd) {
		this.productionGrpCd = productionGrpCd;
	}

	public Integer getProductionCtgryCd() {
		return productionCtgryCd;
	}

	public void setProductionCtgryCd(Integer productionCtgryCd) {
		this.productionCtgryCd = productionCtgryCd;
	}

	public Integer getProductionClsCd() {
		return productionClsCd;
	}

	public void setProductionClsCd(Integer productionClsCd) {
		this.productionClsCd = productionClsCd;
	}

	public String getEthnicTypeCd() {
		return ethnicTypeCd;
	}

	public void setEthnicTypeCd(String ethnicTypeCd) {
		this.ethnicTypeCd = ethnicTypeCd;
	}

	public BigDecimal getPckTypeId() {
		return pckTypeId;
	}

	public void setPckTypeId(BigDecimal pckTypeId) {
		this.pckTypeId = pckTypeId;
	}

	public Integer getProductClsCd() {
		return productClsCd;
	}

	public void setProductClsCd(Integer productClsCd) {
		this.productClsCd = productClsCd;
	}

	public Integer getInnerPack() {
		return innerPack;
	}

	public void setInnerPack(Integer innerPack) {
		this.innerPack = innerPack;
	}

	public Integer getRetailUnitPack() {
		return retailUnitPack;
	}

	public void setRetailUnitPack(Integer retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}

	public String getNewDate() {
		return newDate;
	}

	public void setNewDate(String newDate) {
		this.newDate = newDate;
	}

	public String getLastShipDate() {
		return lastShipDate;
	}

	public void setLastShipDate(String lastShipDate) {
		this.lastShipDate = lastShipDate;
	}

	public String getLastSaleDate() {
		return lastSaleDate;
	}

	public void setLastSaleDate(String lastSaleDate) {
		this.lastSaleDate = lastSaleDate;
	}

	public BigDecimal getTotalSales() {
		return totalSales;
	}

	public void setTotalSales(BigDecimal totalSales) {
		this.totalSales = totalSales;
	}

	public BigDecimal getCasesOrdered() {
		return casesOrdered;
	}

	public void setCasesOrdered(BigDecimal casesOrdered) {
		this.casesOrdered = casesOrdered;
	}

	@Override
    public String toString() {
        return "Company [companyId=" + companyId + ", divisionId=" + divisionId + "]";
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(String divisionId) {
        this.divisionId = divisionId;
    }

    public String getProductSKU() {
        return productSKU;
    }

    public void setProductSKU(String productSKU) {
        this.productSKU = productSKU;
    }

    public String getProductSrcCd() {
        return productSrcCd;
    }

    public void setProductSrcCd(String productSrcCd) {
        this.productSrcCd = productSrcCd;
    }

    public String getUpcCountry() {
        return upcCountry;
    }

    public void setUpcCountry(String upcCountry) {
        this.upcCountry = upcCountry;
    }

    public String getSellByDays() {
		return sellByDays;
	}

	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}

	public String getUseByDays() {
		return useByDays;
	}

	public void setUseByDays(String useByDays) {
		this.useByDays = useByDays;
	}

	public String getPullBydays() {
		return pullBydays;
	}

	public void setPullBydays(String pullBydays) {
		this.pullBydays = pullBydays;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

    public String getUpcSystem() {
        return upcSystem;
    }

    public void setUpcSystem(String upcSystem) {
        this.upcSystem = upcSystem;
    }

    public String getUpcManufacturer() {
        return upcManufacturer;
    }

    public void setUpcManufacturer(String upcManufacturer) {
        this.upcManufacturer = upcManufacturer;
    }

    public String getUpcSales() {
        return upcSales;
    }

    public void setUpcSales(String upcSales) {
        this.upcSales = upcSales;
    }

    public String getPLUcd() {
        return PLUcd;
    }

    public void setPLUcd(String pLUcd) {
        PLUcd = pLUcd;
    }

    public Character getPrimryUpcInd() {
        return primryUpcInd;
    }

    public void setPrimryUpcInd(Character primryUpcInd) {
        this.primryUpcInd = primryUpcInd;
    }

    public Character getItmUsgeInd() {
        return itmUsgeInd;
    }

    public void setItmUsgeInd(Character itmUsgeInd) {
        this.itmUsgeInd = itmUsgeInd;
    }

    public Character getItmUsgeTypInd() {
        return itmUsgeTypInd;
    }

    public void setItmUsgeTypInd(Character itmUsgeTypInd) {
        this.itmUsgeTypInd = itmUsgeTypInd;
    }

    public Character getPtLblInd() {
        return ptLblInd;
    }

    public void setPtLblInd(Character ptLblInd) {
        this.ptLblInd = ptLblInd;
    }

    public Character getDspFlag() {
        return dspFlag;
    }

    public void setDspFlag(Character dspFlag) {
        this.dspFlag = dspFlag;
    }

    public String getItmDescrbtn() {
        return itmDescrbtn;
    }

    public void setItmDescrbtn(String itmDescrbtn) {
        this.itmDescrbtn = itmDescrbtn;
    }

    public String getWhseItmDescrbtn() {
        return whseItmDescrbtn;
    }

    public void setWhseItmDescrbtn(String whseItmDescrbtn) {
        this.whseItmDescrbtn = whseItmDescrbtn;
    }

    public String getRtlItmDescrbtn() {
        return rtlItmDescrbtn;
    }

    public void setRtlItmDescrbtn(String rtlItmDescrbtn) {
        this.rtlItmDescrbtn = rtlItmDescrbtn;
    }

    public String getIntenetItemDescrbtn() {
        return intenetItemDescrbtn;
    }

    public void setIntenetItemDescrbtn(String intenetItemDescrbtn) {
        this.intenetItemDescrbtn = intenetItemDescrbtn;
    }

    public String getPosDescrbtn() {
        return posDescrbtn;
    }

    public void setPosDescrbtn(String posDescrbtn) {
        this.posDescrbtn = posDescrbtn;
    }

    public BigDecimal getVdCnvFactor() {
        return vdCnvFactor;
    }

    public void setVdCnvFactor(BigDecimal vdCnvFactor) {
        this.vdCnvFactor = vdCnvFactor;
    }

    public BigDecimal getPackWhse() {
        return packWhse;
    }

    public void setPackWhse(BigDecimal packWhse) {
        this.packWhse = packWhse;
    }

    public BigDecimal getSizeNbr() {
        return sizeNbr;
    }

    public void setSizeNbr(BigDecimal sizeNbr) {
        this.sizeNbr = sizeNbr;
    }

    public String getSzUom() {
        return szUom;
    }

    public void setSzUom(String szUom) {
        this.szUom = szUom;
    }

    public String getSzDesc() {
        return szDesc;
    }

    public void setSzDesc(String szDesc) {
        this.szDesc = szDesc;
    }

    public String getCostItm() {
        return costItm;
    }

    public void setCostItm(String string) {
        this.costItm = string;
    }

    public String getHierLevel1() {
        return hierLevel1;
    }

    public void setHierLevel1(String hierLevel1) {
        this.hierLevel1 = hierLevel1;
    }

    public String getHierLevel2() {
        return hierLevel2;
    }

    public void setHierLevel2(String hierLevel2) {
        this.hierLevel2 = hierLevel2;
    }

    public String getHierLevel3() {
        return hierLevel3;
    }

    public void setHierLevel3(String hierLevel3) {
        this.hierLevel3 = hierLevel3;
    }

    public String getHierLevel4() {
        return hierLevel4;
    }

    public void setHierLevel4(String hierLevel4) {
        this.hierLevel4 = hierLevel4;
    }

    public String getHierLevel5() {
        return hierLevel5;
    }

    public void setHierLevel5(String hierLevel5) {
        this.hierLevel5 = hierLevel5;
    }

    public Character getExptnTypCd() {
        return exptnTypCd;
    }

    public void setExptnTypCd(Character exptnTypCd) {
        this.exptnTypCd = exptnTypCd;
    }

    public String getExptnDesc() {
        return exptnDesc;
    }

    public void setExptnDesc(String exptnDesc) {
        this.exptnDesc = exptnDesc;
    }

    public Character getExcptnProInd() {
        return excptnProInd;
    }

    public void setExcptnProInd(Character excptnProInd) {
        this.excptnProInd = excptnProInd;
    }

    public Integer getBtId() {
        return btId;
    }

    public void setBtId(Integer btId) {
        this.btId = btId;
    }

    public Character getLoglInd() {
        return loglInd;
    }

    public void setLoglInd(Character loglInd) {
        this.loglInd = loglInd;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
    
    public String getPrimaryUPC()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(upcCountry);
        sb.append(upcSystem);
        sb.append(upcManufacturer);
        sb.append(upcSales);
        return sb.toString();
    }
    
    public String getPrimaryUPCforDisplay()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(upcCountry);
        sb.append("-");
        sb.append(upcSystem);
        sb.append("-");
        sb.append(upcManufacturer);
        sb.append("-");
        sb.append(upcSales);
        return sb.toString();
    }

    public List<String> getUpcLIst() {
        return upcLIst;
    }

    public void setUpcLIst(List<String> upcLIst) {
        this.upcLIst = upcLIst;
    }
    
    public void addToUpcLIst(String upc) {
    	if(this.upcLIst == null)
    		this.upcLIst = new ArrayList<String>();
        this.upcLIst.add(upc);
    }


    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public void setPrimaryUPC(String primaryUPC) {
        this.primaryUPC = primaryUPC;
    }

	public String getCaseUPC() {
		//No need to display Case UPC for DSD Items
		if(productSrcCd != null && productSrcCd.startsWith("D"))
			return "";
		return caseUPC;
	}

	public void setCaseUPC(String caseUPC) {
		this.caseUPC = caseUPC;
	}

	public String getUpdatedUserID() {
		return updatedUserID;
	}

	public void setUpdatedUserID(String updatedUserID) {
		this.updatedUserID = updatedUserID;
	}

	public List<UPCVo> getUpcVoList() {
		return upcVoList;
	}

	public void setUpcVoList(List<UPCVo> upcVoList) {
		this.upcVoList = upcVoList;
	}

	public UPCVo getPrimaryUPCVo() {
		primaryUPCVo = new UPCVo();
		primaryUPCVo.setUpc(getPrimaryUPCforDisplay());
		return primaryUPCVo;
	}

	public void setPrimaryUPCVo(UPCVo primaryUPCVo) {
		this.primaryUPCVo = primaryUPCVo;
	}

	public boolean isManualMapped() {
		return manualMapped;
	}

	public void setManualMapped(boolean manualMapped) {
		this.manualMapped = manualMapped;
	}

	public boolean isMarkedAsDead() {
		return markedAsDead;
	}

	public void setMarkedAsDead(boolean markedAsDead) {
		this.markedAsDead = markedAsDead;
	}

	public String getSlotId() {
		return slotId;
	}

	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}

	public BigDecimal getOnhandNbr() {
		return onhandNbr;
	}

	public void setOnhandNbr(BigDecimal onhandNbr) {
		this.onhandNbr = onhandNbr;
	}

	public String getHierarchyLvlNm() {
		return hierarchyLvlNm;
	}

	public void setHierarchyLvlNm(String hierarchyLvlNm) {
		this.hierarchyLvlNm = hierarchyLvlNm;
	}

	public String getHierarchyLvlDesc() {
		return hierarchyLvlDesc;
	}

	public void setHierarchyLvlDesc(String hierarchyLvlDesc) {
		this.hierarchyLvlDesc = hierarchyLvlDesc;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public String getSubCategoryDesc() {
		return subCategoryDesc;
	}

	public void setSubCategoryDesc(String subCategoryDesc) {
		this.subCategoryDesc = subCategoryDesc;
	}

	public String getGroupDesc() {
		return groupDesc;
	}

	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}

	public boolean isMarkedForManualMapping() {
		return markedForManualMapping;
	}

	public void setMarkedForManualMapping(boolean markedForManualMapping) {
		this.markedForManualMapping = markedForManualMapping;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((productSKU == null) ? 0 : productSKU.hashCode());
		result = prime * result
				+ ((upcCountry == null) ? 0 : upcCountry.hashCode());
		result = prime * result
				+ ((upcManufacturer == null) ? 0 : upcManufacturer.hashCode());
		result = prime * result
				+ ((upcSales == null) ? 0 : upcSales.hashCode());
		result = prime * result
				+ ((upcSystem == null) ? 0 : upcSystem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    if(obj == this)
	    	return true;
	    if (this.getClass() != obj.getClass())
	        return false;
	    if (!UIExceptionSrcDto.class.isAssignableFrom(obj.getClass())) {
	        return false;
	    }
	    final UIExceptionSrcDto other = (UIExceptionSrcDto) obj;
	    if (!this.getProductSKU().equals(other.getProductSKU()) || !this.getUpcManufacturer().equals(other.getUpcManufacturer()) || !this.getUpcSales().equals(other.getUpcSales()) 
	    		|| !this.getUpcCountry().equals(other.getUpcCountry()) || !this.getUpcSystem().equals(other.getUpcSystem()) 
	    		 ) {
	        return false;
	    }
	    return true;
	}

	public String getConvGroupCd() {
		return convGroupCd;
	}

	public void setConvGroupCd(String convGroupCd) {
		this.convGroupCd = convGroupCd;
	}

	public String getConvGroupNm() {
		return convGroupNm;
	}
	
	public void setConvGroupNm(String convGroupNm) {
		this.convGroupNm = convGroupNm;
	}

	public String getSelling_method_cd() {
		return selling_method_cd;
	}

	public void setSelling_method_cd(String selling_method_cd) {
		this.selling_method_cd = selling_method_cd;
	}

	public String getReceiving_cd() {
		return receiving_cd;
	}

	public void setReceiving_cd(String receiving_cd) {
		this.receiving_cd = receiving_cd;
	}

	public String getSrcProdwght() {
		return srcProdwght;
	}

	public void setSrcProdwght(String srcProdwght) {
		this.srcProdwght = srcProdwght;
	}

	public String getSrcHandlingCode() {
		return srcHandlingCode;
	}

	public void setSrcHandlingCode(String srcHandlingCode) {
		this.srcHandlingCode = srcHandlingCode;
	}

	public String getSrcBuyerNum() {
		return srcBuyerNum;
	}

	public void setSrcBuyerNum(String srcBuyerNum) {
		this.srcBuyerNum = srcBuyerNum;
	}

	public String getSrcRandomWtCd() {
		return srcRandomWtCd;
	}

	public void setSrcRandomWtCd(String srcRandomWtCd) {
		this.srcRandomWtCd = srcRandomWtCd;
	}

	public String getSrcAutoCostInv() {
		return srcAutoCostInv;
	}

	public void setSrcAutoCostInv(String srcAutoCostInv) {
		this.srcAutoCostInv = srcAutoCostInv;
	}

	public String getSrcBillingType() {
		return srcBillingType;
	}

	public void setSrcBillingType(String srcBillingType) {
		this.srcBillingType = srcBillingType;
	}

	public String getSrcFdStmp() {
		return srcFdStmp;
	}

	public void setSrcFdStmp(String srcFdStmp) {
		this.srcFdStmp = srcFdStmp;
	}

	public String getSrcLabelSize() {
		return srcLabelSize;
	}

	public void setSrcLabelSize(String srcLabelSize) {
		this.srcLabelSize = srcLabelSize;
	}

	public String getSrcLabelNumbers() {
		return srcLabelNumbers;
	}

	public void setSrcLabelNumbers(String srcLabelNumbers) {
		this.srcLabelNumbers = srcLabelNumbers;
	}

	public String getSrcSgnCount1() {
		return srcSgnCount1;
	}

	public void setSrcSgnCount1(String srcSgnCount1) {
		this.srcSgnCount1 = srcSgnCount1;
	}

	public String getSrcSgnCount2() {
		return srcSgnCount2;
	}

	public void setSrcSgnCount2(String srcSgnCount2) {
		this.srcSgnCount2 = srcSgnCount2;
	}

	public String getSrcSgnCount3() {
		return srcSgnCount3;
	}

	public void setSrcSgnCount3(String srcSgnCount3) {
		this.srcSgnCount3 = srcSgnCount3;
	}

	public String getTareCd() {
		return tareCd;
	}

	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}

	public String getSrcRing() {
		return srcRing;
	}

	public void setSrcRing(String srcRing) {
		this.srcRing = srcRing;
	}

	public String getSrcHicone() {
		return srcHicone;
	}

	public void setSrcHicone(String srcHicone) {
		this.srcHicone = srcHicone;
	}

}