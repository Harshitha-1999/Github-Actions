/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.domain.services;

/* ***************************************************************************
 * NAME         : CompanyService 
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 May 31, 2017  -  Initial Creation
 *
 ***************************************************************************/

import java.util.HashMap;
import java.util.List;

import com.safeway.app.memi.domain.dtos.response.SMICDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;

/**
 * 
 * Interface definition for SMIC Detail Services
 *
 */
public interface SMICDetailService {

    /**
     * Method to fetch SMICDetails List
     */
    public List<SMICDetailDto> getAllItems();
    
    /**
     * @param grpCd
     * @param ctgryCd
     * @param clsCd
     * @param sbClsCd
     * @param subSbClass
     * @return
     */
    public List<SMICDetailDto> findByGrpCdAndCtgryCdAndClsCdAndSbClsCdAndSubSbClass(String grpCd, String ctgryCd, String clsCd, String sbClsCd, String subSbClass);

    public List<SmicCodeDescWrapper> getGroupCode();
    public List<SmicCodeDescWrapper> getCategoryCode(String groupCode);
    public List<SmicCodeDescWrapper> getClassCode(String groupCode,String categoryCode);
    public List<SmicCodeDescWrapper> getSubClassCode(String groupCode,String categoryCode,String classCode);
    public List<SmicCodeDescWrapper> getSubSubClassCode(String groupCode,String categoryCode,String classCode,String subClassCode);
}
