package com.safeway.app.memi.data.repositories;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;

/**
 ****************************************************************************
 * NAME			: DisplaySQLRepository 
 * 
 * DESCRIPTION	: DisplaySQLRepository is the repository class for performing 
 * 				  Displayer DB operations
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U51095
 * 
 * 
 * 
 * *************************************************************************
 */

/**
 * Repository class for Displayer DB operations
 */
@Repository
@SuppressWarnings("unchecked")
public class DisplaySQLRepository {
	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;

	private static final Logger LOG = LoggerFactory
			.getLogger(DisplaySQLRepository.class);

	/**
	 * This method fetches Department wise exception details from the Database
	 */

	public List<Object[]> fetchDepartmentWiseDisplayItemData(String companyId,
			String divisionId) {

		LOG.info("Fetching department wise Display item un-reviewed details.");

		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
		.append("SELECT COUNT(*) AS TOTAL_COUNT, DEPARTMENT_NM, DEPARTMENT_CD, SUM(DSD_ITEM) AS DSD_COUNT, SUM(WHSE_ITEM) AS WHSE_COUNT FROM (SELECT DISTINCT D.PRODUCT_SKU, REPLACE(D.PROD_HIERARCHY_LVL_5_CD, '/', '') AS DEPARTMENT_NM, D.PROD_HIERARCHY_LVL_4_CD AS DEPARTMENT_CD, CASE WHEN UPPER(D.SOURCE_BY_DSD) = 'Y' THEN 1 ELSE 0 END AS DSD_ITEM, CASE WHEN UPPER(D.SOURCE_BY_WHSE) = 'Y' THEN 1 ELSE 0 END AS WHSE_ITEM FROM ECFLAND.ITEM_AGGREGATE_CORP D ")
		.append("LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA B ON D.COMPANY_ID = B.COMPANY_ID AND D.DIVISION_ID = B.DIVISION_ID AND D.PRODUCT_SKU = B.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID   = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID   = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF P ON D.COMPANY_ID = P.COMPANY_ID AND D.DIVISION_ID = P.DIVISION_ID AND D.PRODUCT_SKU = P.SRC_PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.COMPANY_ID =")
		.append( " :cmpId AND D.DIVISION_ID = :dvsnID")
		.append( " AND D.MULTI_COMP_ITEM_IND = 'Y' AND P.CONV_STATUS_CD NOT IN('D','O','C') AND (B.SLOT IS NOT NULL OR B.ON_HAND IS NOT NULL OR B.ON_ORDER_QTY IS NOT NULL OR B.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE())) AND DI.PRODUCT_SKU IS NULL)a GROUP BY DEPARTMENT_NM, DEPARTMENT_CD");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("cmpId", companyId);
		q.setParameter("dvsnID", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department details.");
		em.close();
		return results;
	}

	public List<Object[]> fetchDepartmentWiseCompletedDisplayItem(
			String companyId, String divisionId) {

		LOG.info("Fetching department wise Display item completed details.");
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT SUM(COMPLETED_COUNT) AS TOTAL_COUNT,DEPARTMENT_NM, DEPARTMENT_CD, SUM(DSD_ITEM) AS DSD_COUNT,SUM(WHSE_ITEM) AS WHSE_COUNT FROM (SELECT DISTINCT D.PRODUCT_SKU, REPLACE(D.PROD_HIERARCHY_LVL_5_CD, '/', '') AS DEPARTMENT_NM, D.PROD_HIERARCHY_LVL_4_CD AS DEPARTMENT_CD, CASE WHEN UPPER(D.SOURCE_BY_DSD) = 'Y' THEN 1 ELSE 0 END AS DSD_ITEM, CASE WHEN UPPER(D.SOURCE_BY_WHSE) = 'Y' THEN 1 ELSE 0 END AS WHSE_ITEM, CASE WHEN UPPER(P.DISPLAY_ITEM_PROCESSED_IND) = 'Y' THEN 1 ELSE 0 END AS COMPLETED_COUNT")
		.append(" FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID   = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID   = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS P ON D.COMPANY_ID = P.COMPANY_ID AND D.DIVISION_ID = P.DIVISION_ID AND D.PRODUCT_SKU = P.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.COMPANY_ID =")
		.append( " :cmpId AND D.DIVISION_ID = :dvsnID")
		.append( " AND D.MULTI_COMP_ITEM_IND = 'Y' AND P.DISPLAY_ITEM_PROCESSED_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >DATEADD(MM,-9,GETDATE())) ) a GROUP BY DEPARTMENT_NM,DEPARTMENT_CD ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("cmpId", companyId);
		q.setParameter("dvsnID", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed department wise Display item completed details.");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchDepartmentWiseDisplayItemDetails(
			String companyId, String divisionId, String departmentCode,
			char status, char type) {

		LOG.info("Fetching department wise Displayer item details.");
		StringBuilder query = new StringBuilder();

		if (status == 'N') {
			StringBuilder unReviewedBaseQuery = new StringBuilder("");
			unReviewedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
			.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
			.append(" :departmentcode AND D.COMPANY_ID = ").append( " :cmpId   AND D.DIVISION_ID =").append( " :dvsnId AND D.MULTI_COMP_ITEM_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O','C') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >    DATEADD(MONTH,-9,SYSDATETIME())) AND DI.PRODUCT_SKU IS NULL ");
			if (type == 'D') {
				query = new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_DSD= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
			}
			if (type == 'W') {
				query =  new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_WHSE= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
			}
			if (type == 'A') {
				query =  new StringBuilder().append(unReviewedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
			}
		}

		if (status == 'C') {
			StringBuilder completedBaseQuery = new StringBuilder("");
			completedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
			.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID ")
			.append("AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
			.append(" :departmentcode AND D.COMPANY_ID = ").append( " :cmpId    AND D.DIVISION_ID =").append( " :dvsnId  AND D.MULTI_COMP_ITEM_IND = 'Y' AND DI.DISPLAY_ITEM_PROCESSED_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >    DATEADD(MONTH,-9,SYSDATETIME())) ");
			
			if (type == 'D') {
				query = new StringBuilder().append(completedBaseQuery).append(" AND D.SOURCE_BY_DSD= 'Y'  ORDER BY S.ITEM_SETUP_DT DESC ");
			}
			if (type == 'W') {
				query = new StringBuilder().append(completedBaseQuery).append(" AND D.SOURCE_BY_WHSE= 'Y'  ORDER BY S.ITEM_SETUP_DT DESC ");
			}
			if (type == 'A') {
				query = new StringBuilder().append(completedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
			}
		}

		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("departmentcode", departmentCode);
		q.setParameter("cmpId", companyId);
		q.setParameter("dvsnId", divisionId);
		q.setHint("org.hibernate.fetchSize", "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details.");
		em.close();
		return results;
	}

	public int updateMultiCompItemInd(String company, String division,
			String productsku, String deptCode, String caseUpc,
			char multiCompInd) {
		LOG.info("Updating ITEM_AGGREGATE_CORP records.");
		String multiCompIndValue = null;
		if (multiCompInd == 'M') {
			multiCompIndValue = "Y";

		}
		if (multiCompInd == 'U') {
			multiCompIndValue = "N";
		}
		String query = "UPDATE ECFLAND.ITEM_AGGREGATE_CORP SET MULTI_COMP_ITEM_IND= :multiCompIndValue"
				+ " WHERE COMPANY_ID = :companyId   AND DIVISION_ID = :divisionId  AND PRODUCT_SKU = :productSku"
				+ " AND PROD_HIERARCHY_LVL_4_CD = :deptCode  AND CASE_UPC = :caseUpc";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
        q.setParameter("multiCompIndValue", multiCompIndValue);
		q.setParameter("companyId", company);
	    q.setParameter("divisionId", division);
	    q.setParameter("productSku", productsku);
	    q.setParameter("deptCode", deptCode);
	    q.setParameter("caseUpc", caseUpc);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed Updating ITEM_AGGREGATE_CORP records.");
		em.close();
		return result;
	}

	public List<Object[]> checkForDsdWhse(String companyId, String divisionId,
			String productSku) {
		LOG.info("Fetching checkForDsdWhse Details.");
		String query = "SELECT DISTINCT SOURCE_BY_DSD, SOURCE_BY_WHSE FROM ECFLAND.ITEM_AGGREGATE_CORP "
				+ "WHERE COMPANY_ID = :cmpId"
				+ "  AND DIVISION_ID = :dvsnId"
				+"  AND PRODUCT_SKU = :productSku ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter("cmpId", companyId);
	    q.setParameter("dvsnId", divisionId);
	    q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching checkForDsdWhse details.");
		em.close();
		return results;

	}

	public List<Object[]> checkForRecordItemConSrcDataReplace(String companyId,
			String divisionId, String productSku) {
		LOG.info("Fetching checkForDsdWhse Details.");
		String query = "SELECT PRODUCT_SKU FROM ECFLAND.ITEM_CONV_SRC_DATA_REPLACE "
				+ "WHERE COMPANY_ID = :companyId"
				+ "  AND DIVISION_ID = :divisionId"
				+ "  AND PRODUCT_SKU =  :productSku "
				+ " AND TABLE_NAME_ITM_DSC_TXT in ('DSD_LEVEL_ITEM','WAREHOUSE_LEVEL_ITEM') "
				+ " AND COLUMN_NAME_ITM_DSC_TXT = 'MULTI_COMP_ITEM_IND' ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter("companyId", companyId);
	    q.setParameter("divisionId", divisionId);
	    q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching checkForDsdWhse details.");
		em.close();
		return results;
	}

	public int insertRecordToItemConSrcDataReplace(String companyId,
			String divisionId, String productSku, String tableName,
			String configValue, String userId) {
		LOG.info("Inserting ITEM_CONV_SRC_DATA_REPLACE record.");
		String query = "INSERT INTO ECFLAND.ITEM_CONV_SRC_DATA_REPLACE (COMPANY_ID, DIVISION_ID, PRODUCT_SKU, REPLACE_LEVEL_CD, TABLE_NAME_ITM_DSC_TXT,COLUMN_NAME_ITM_DSC_TXT,CONFIG_VAL,CREATE_UPDATE_USER_ID,LOGICAL_DEL_IND) VALUES ("
				+ "? , ? , ? ,'I',?,'MULTI_COMP_ITEM_IND',?, ?, 'N')";
				
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter(1, companyId);
		q.setParameter(2, divisionId);
		q.setParameter(3, productSku);
		q.setParameter(4, tableName);
		q.setParameter(5, configValue);
		q.setParameter(6, userId);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed inserting ITEM_CONV_SRC_DATA_REPLACE records.");
		em.close();
		return result;
	}

	public int updateRecordToItemConSrcDataReplace(String companyId,
			String divisionId, String productSku, String configValue,
			String updatedUserID) {
		LOG.info("Updating ITEM_CONV_SRC_DATA_REPLACE record.");
		String query = "UPDATE ECFLAND.ITEM_CONV_SRC_DATA_REPLACE SET CONFIG_VAL=:configValue,CREATE_UPDATE_USER_ID=:updatedUserID WHERE COMPANY_ID = :companyId"
				+ " AND DIVISION_ID = :divisionId AND PRODUCT_SKU = :productSku AND TABLE_NAME_ITM_DSC_TXT in ('DSD_LEVEL_ITEM','WAREHOUSE_LEVEL_ITEM') AND COLUMN_NAME_ITM_DSC_TXT = 'MULTI_COMP_ITEM_IND' ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter("configValue", configValue);
		q.setParameter("updatedUserID", updatedUserID);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed updating ITEM_CONV_SRC_DATA_REPLACE records.");
		em.close();
		return result;
	}

	public int markItemsAsDead(String company, String division,
			String productsku, String markAsDeadReason, String updatedUserID) {
		LOG.info("Updating SRC_ITEM_XRF records.");

		String convStatusDesc = "Dead Item - Business assigned status.";

		String query = "UPDATE XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD='D', CONV_STATUS_SUB_CD='B', CONV_STATUS_DSC=:convStatusDesc ,STATUS_REASON_TXT=:markAsDeadReason"
				+ ",CREATE_UPDATE_USER_ID=:updatedUserID WHERE COMPANY_ID = :company AND DIVISION_ID = :division  AND SRC_PRODUCT_SKU = :productsku";

		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter("convStatusDesc", convStatusDesc);
		q.setParameter("markAsDeadReason", markAsDeadReason);
		q.setParameter("updatedUserID", updatedUserID);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("productsku", productsku);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed Updating SRC_ITEM_XRF records.");
		em.close();
		return result;
	}

	public List<Object[]> fetchDeptWiseItemDetailsBasedOnItemDesc(
			String company, String division, String department,
			String itemDesc, char itemtype) {
		LOG.info("Started fetching department wise item details based on Item Desc");
		StringBuilder query = new StringBuilder();

		StringBuilder itemDescription = null;
		if (itemDesc.contains("|")) {
			itemDescription = new StringBuilder()
					.append(" AND D.ITEM_DESC LIKE :itemDesc   ESCAPE '|'");
		} else {
			itemDescription = new StringBuilder()
					.append(" AND D.ITEM_DESC LIKE :itemDesc ");
		}
		StringBuilder unReviewedBaseQuery = new StringBuilder("");
		unReviewedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
		.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
		.append(" :department  AND D.COMPANY_ID =").append(" :company  AND D.DIVISION_ID =").append(":division "+ itemDescription+ " AND X.CONV_STATUS_CD NOT IN('D','O','C') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >  DATEADD(MM,-9,GETDATE())) AND DI.PRODUCT_SKU IS NULL ");
		if (itemtype == 'D') {
			query = new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_DSD= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		if (itemtype == 'W') {
			query =  new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_WHSE= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		if (itemtype == 'A') {
			query =  new StringBuilder().append(unReviewedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		q.setParameter("itemDesc", "%"+itemDesc+"%");
		q.setParameter("department", department);
		q.setParameter("company", company);
		q.setParameter("division", division);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details based on Item Desc.");
		em.close();
		return results;
	}

	public List<Object[]> fetchDeptWiseItemDetailsBasedOnProductSku(
			String company, String division, String department,
			String productSku, char itemtype) {
		LOG.info("Started fetching department wise item details based on product sku");
		StringBuilder query = new StringBuilder();
		StringBuilder unReviewedBaseQuery = new StringBuilder("");
		unReviewedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
		.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
		.append(":department  AND D.COMPANY_ID =").append(" :company  AND D.DIVISION_ID =").append(":division AND D.PRODUCT_SKU = :productSku AND X.CONV_STATUS_CD NOT IN('D','O','C') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >  DATEADD(MM,-9,GETDATE())) AND DI.PRODUCT_SKU IS NULL ");
		if (itemtype == 'D') {
			query = new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_DSD= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		if (itemtype == 'W') {
			query =  new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_WHSE= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		if (itemtype == 'A') {
			query =  new StringBuilder().append(unReviewedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("department", department);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("productSku", productSku);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details  on product sku.");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchDeptWiseItemDetailsBasedOndisplayitemdetailBasedonOneTimeBuyFlag(
			String company, String division, String department,
			String oneTimeBuyFlag, char itemType) {
		LOG.info("Started fetching department wise item details based on OneTimeBuyFlag");
		StringBuilder query = new StringBuilder();
		StringBuilder unReviewedBaseQuery = new StringBuilder("");
		unReviewedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
		.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
		.append(" :department  AND D.COMPANY_ID =").append(" :company AND D.DIVISION_ID =").append(" :division AND D.ONE_TIME_BUY_ITEM_IND = :oneTimeBuyFlag  AND D.MULTI_COMP_ITEM_IND='N' AND X.CONV_STATUS_CD NOT IN('D','O','C') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >  DATEADD(MM,-9,GETDATE()))  AND DI.PRODUCT_SKU IS NULL ");
		if (itemType == 'D') {
			query = new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_DSD= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		if (itemType == 'W') {
			query =  new StringBuilder().append(unReviewedBaseQuery).append(" AND D.SOURCE_BY_WHSE= 'Y' ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		if (itemType == 'A') {
			query =  new StringBuilder().append(unReviewedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
		}
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("department", department);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("oneTimeBuyFlag", oneTimeBuyFlag);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details  on OneTimeBuyFlag.");
		em.close();
		return results;
	}
	
	public List<String> fetchUpcList(String companyId, String divisionId,
			String productSku) {
		LOG.info("Fetching UPC From ITEM_AGGREGATE_CORP.");
		String query = "select top 1* from (SELECT DISTINCT D.UPC FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.DISPLAY_ITEM_COMPONENTS S ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND D.UPC =CONCAT(X.SRC_UPC_COUNTRY,X.SRC_UPC_SYSTEM,right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5),right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5)) WHERE D.PRODUCT_SKU = "
				+ " :productSku AND D.COMPANY_ID = :companyId"
				+ "  AND D.DIVISION_ID = :divisionId"
				+ " AND X.CONV_STATUS_CD NOT IN('D','O','C') ) INNER_TABLE";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		q.setParameter("productSku", productSku);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		List<String> results = q.getResultList();
		LOG.info("Completed fetching UPC From ITEM_AGGREGATE_CORP.");
		em.close();
		return results;
	}

	public int deleteRecordFromItemConvDisplayItem(String companyId,
			String divisionId, String productSku) {
		LOG.info("Started deleting records from  ITEM_CONV_DISPLAY_ITEMS");
		String query = "DELETE FROM ECFLAND.ITEM_CONV_DISPLAY_ITEMS WHERE COMPANY_ID = ?  AND DIVISION_ID = ? AND PRODUCT_SKU = ?";

		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter(1, companyId);
		q.setParameter(2, divisionId);
		q.setParameter(3, productSku);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed deleting records from ITEM_CONV_DISPLAY_ITEMS");
		em.close();
		return result;

	}

	public int deleteRecordFromUIExceptionSrc(String companyId,
			String divisionId, String productSku) {
		LOG.info("Started deleting records from  ITEM_CONV_UI_EXCEPTION_SRC");
		String query = "DELETE FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC WHERE COMPANY_ID = ?  AND DIVISION_ID = ? AND PRODUCT_SKU = ?";

		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter(1, companyId);
		q.setParameter(2, divisionId);
		q.setParameter(3, productSku);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed deleting records from ITEM_CONV_UI_EXCEPTION_SRC");
		em.close();
		return result;

	}

	public List<Object[]> checkNewItemAlreadyConverted(String companyId,
			String divisionId, String productSku) {
		LOG.info("Fetching record for checking item not converted");
		String query = "SELECT S.COMPANY_ID, S.DIVISION_ID, S.SRC_PRODUCT_SKU, S.SRC_UPC_COUNTRY, S.SRC_UPC_SYSTEM, S.SRC_UPC_MANUF, S.SRC_UPC_SALES, S.CONV_STATUS_CD FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC I JOIN XREFLAND.SRC_ITEM_XRF S "
				+ "ON S.COMPANY_ID = I.COMPANY_ID AND S.DIVISION_ID = I.DIVISION_ID AND S.SRC_PRODUCT_SKU = I.PRODUCT_SKU AND S.SRC_UPC_COUNTRY = I.UPC_COUNTRY AND S.SRC_UPC_SYSTEM = I.UPC_SYSTEM AND S.SRC_UPC_MANUF = I.UPC_MANUF AND S.SRC_UPC_SALES = I.UPC_SALES "
				+ "WHERE S.COMPANY_ID = :companyId"
				+ "  AND S.DIVISION_ID = :divisionId"
				+ " AND S.SRC_PRODUCT_SKU = :productSku"
				+ " AND S.CONV_STATUS_CD != 'D' ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching record for checking item not converted");
		em.close();
		return results;
	}

	public int deleteRecordFromNewItemDetail(String companyId,
			String divisionId, String productSku) {
		LOG.info("Started deleting records from  ITEM_CONV_NEW_CIC_DATA_MGMT");
		String query = "DELETE FROM ECFLAND.ITEM_CONV_NEW_CIC_DATA_MGMT WHERE COMPANY_ID = ?  AND DIVISION_ID = ? AND PRODUCT_SKU = ?";

		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter(1, companyId);
		q.setParameter(2, divisionId);
		q.setParameter(3, productSku);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed deleting records from ITEM_CONV_NEW_CIC_DATA_MGMT");
		em.close();
		return result;
	}

	public int updateItemXref(String companyId, String divisionId,
			String productSku, BigDecimal upcCountry, BigDecimal upcSystem,
			BigDecimal upcManufacturer, BigDecimal upcSales,
			String updatedUserId) {
		LOG.info("Updating XREFLAND.SRC_ITEM_XRF record.");
		String query = "UPDATE XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD='E' , CONV_STATUS_SUB_CD='D', CONV_STATUS_DSC='Display Item', STATUS_REASON_TXT='Display Item Exception', CREATE_UPDATE_USER_ID="
				+ ":updatedUserId CREATE_UPDATE_TS=SYSDATETIMEOFFSET()  WHERE COMPANY_ID = :companyId "
				+ "AND DIVISION_ID = :divisionId AND SRC_PRODUCT_SKU = :productSku AND SRC_UPC_COUNTRY = :upcCountry AND SRC_UPC_SYSTEM =:upcSystem AND SRC_UPC_MANUF = :upcManufacturer AND SRC_UPC_SALES = :upcSales ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query);
		q.setParameter("updatedUserId", updatedUserId);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		q.setParameter("upcCountry", upcCountry);
		q.setParameter("upcSystem", upcSystem);
		q.setParameter("upcManufacturer", upcManufacturer);
		q.setParameter("upcSales", upcSales);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed updating XREFLAND.SRC_ITEM_XRF records.");
		em.close();
		return result;

	}

	public List<String> checkMatchedItemAlreadyConverted(String companyId,
			String divisionId, String productSku) {
		LOG.info("Fetching record for checking item not converted");
		String query = "SELECT DISTINCT S.CONV_STATUS_CD FROM XREFLAND.SRC_ITEM_XRF S "
				+ "WHERE S.COMPANY_ID = :companyId"
				+ "  AND S.DIVISION_ID = :divisionId"
				+ " AND S.SRC_PRODUCT_SKU = :productSku"
				+ " AND S.CONV_STATUS_CD != 'D' ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<String> results = q.getResultList();
		LOG.info("Completed fFetching record for checking item not converted");
		em.close();
		return results;
	}

	public List<Object[]> fetchSourceComponentDetails(String companyId,
			String divisionId, String productSKU) {
		LOG.info("Fetching Source Details.");
		String query = "SELECT CONCAT(right(replicate('0',1) + cast(UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(UPC_SYSTEM as varchar),1),'-', right(replicate('0',5) + cast(UPC_MANUF as varchar),5),'-',right(replicate('0',5) + cast(UPC_SALES as varchar),5)) AS UPC , COMP_ITEM_DSC, COMP_SHELF_UNIT, MEMO_COST FROM ECFLAND.DISPLAY_ITEM_COMPONENTS "
				+ "WHERE COMPANY_ID = :companyId"
				+ "  AND DIVISION_ID = :divisionId"
				+ "  AND PRODUCT_SKU = :productSKU ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSKU", productSKU);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching Source details.");
		em.close();
		return results;
	}

	public List<Object[]> fetchSrcSimsDetails(String venUpcPackInd,
			String venUpcCountry, String venUpcNumSys, String venUpcManuf,
			String venUpcItem, String productSourceCode) {
		LOG.info("Fetching Sims header Details.");
		String query = "SELECT DISTINCT S.CORP_ITEM_CD, Concat(right(replicate('0',1) + cast(S.VEN_UPC_PACK_IND as varchar),1),'-',right(replicate('0',1) + cast(S.VEN_UPC_COUNTRY as varchar),1) , '-',right(replicate('0',1) + cast(S.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',5) + cast(S.VEN_UPC_MANUF as varchar),5) ,'-', right(replicate('0',5) + cast(S.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC,  S.DESC_ITEM AS SSITMCDS_DESC, S.DISP_FLAG,Concat(right(replicate('0',1) + cast(P.UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(P.UPC_SYSTEM as varchar),1) ,'-', right(replicate('0',5) + cast(P.UPC_MANUF as varchar),5) ,'-' ,right(replicate('0',5) + cast(P.UPC_SALES as varchar),5)) AS UPC, P.DESC_ITEM AS SSITMCDS_DGP, P.INC_SHELF_UNIT, P.COST_MEMO, Z.COST_VEND FROM SSIMSLAND.SQLDAT3_SSITMCDS S JOIN SSIMSLAND.SQLDAT3_SSITMDGP P ON S.CORP_ITEM_CD=P.CORP_ITEM_CD JOIN SSIMSLAND.SQLDAT3_SSITMWDS W ON S.CORP_ITEM_CD=W.CORP_ITEM_CD LEFT OUTER JOIN SSIMSLAND.SQLDAT3_SSITMVCC Z ON S.CORP_ITEM_CD=Z.CORP_ITEM_CD JOIN SSIMSLAND.SQLDAT3_SSITMXRF X ON P.CORP_ITEM_CD=X.CORP_ITEM_CD AND P.UPC_COUNTRY = X.UPC_COUNTRY AND P.UPC_SYSTEM = X.UPC_SYSTEM AND P.UPC_MANUF = X.UPC_MANUF AND P.UPC_SALES = X.UPC_SALES  "
				+ "WHERE S.VEN_UPC_PACK_IND = :venUpcPackInd"
				+ "  AND S.VEN_UPC_COUNTRY = :venUpcCountry"
				+ " AND S.VEN_UPC_NUM_SYS = :venUpcNumSys"
				+ "  AND S.VEN_UPC_MANUF = :venUpcManuf"
				+ " AND S.VEN_UPC_ITEM = :venUpcItem"
				+ " AND X.STATUS_UPC NOT IN('D','X') AND S.DISP_FLAG = 'Y' AND W.DST_CNTR LIKE  :productSourceCode";
				
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter("venUpcPackInd", venUpcPackInd);
		q.setParameter("venUpcCountry", venUpcCountry);
		q.setParameter("venUpcNumSys", venUpcNumSys);
		q.setParameter("venUpcManuf", venUpcManuf);
		q.setParameter("venUpcItem", venUpcItem);
		q.setParameter("productSourceCode", productSourceCode+"%");
		
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching Sims header details.");
		em.close();
		return results;
	}

	public List<Object[]> fetchSimsDetailsBasedonSourceUpcSet(
			String upcCountry, String upcSystem, String upcManuf,
			String upcSales, String productSourceCode) {
		LOG.info("Fetching Sims Details Based on Source Upcset.");
		String query = "SELECT DISTINCT S.CORP_ITEM_CD, concat(right(replicate('0',1) + cast(S.VEN_UPC_PACK_IND as varchar),1),'-', right(replicate('0',1) + cast(S.VEN_UPC_COUNTRY as varchar),1) ,'-', right(replicate('0',1) + cast(S.VEN_UPC_NUM_SYS as varchar),1)  ,'-', right(replicate('0',5) + cast(S.VEN_UPC_MANUF as varchar),5) ,'-', right(replicate('0',5) + cast(S.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC, S.DESC_ITEM AS SSITMCDS_DESC, S.DISP_FLAG, concat(right(replicate('0',1) + cast(P.UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(P.UPC_SYSTEM as varchar),1) ,'-', right(replicate('0',5) + cast(P.UPC_MANUF as varchar),5) ,'-', right(replicate('0',5) + cast(P.UPC_SALES as varchar),5)) AS UPC,  P.DESC_ITEM AS SSITMCDS_DGP, P.INC_SHELF_UNIT, P.COST_MEMO, Z.COST_VEND FROM SSIMSLAND.SQLDAT3_SSITMCDS S JOIN SSIMSLAND.SQLDAT3_SSITMDGP P ON S.CORP_ITEM_CD=P.CORP_ITEM_CD JOIN SSIMSLAND.SQLDAT3_SSITMWDS W ON S.CORP_ITEM_CD=W.CORP_ITEM_CD LEFT OUTER JOIN SSIMSLAND.SQLDAT3_SSITMVCC Z ON S.CORP_ITEM_CD=Z.CORP_ITEM_CD JOIN SSIMSLAND.SQLDAT3_SSITMXRF X ON P.CORP_ITEM_CD=X.CORP_ITEM_CD AND P.UPC_COUNTRY = X.UPC_COUNTRY AND P.UPC_SYSTEM = X.UPC_SYSTEM AND P.UPC_MANUF = X.UPC_MANUF AND P.UPC_SALES = X.UPC_SALES "
				+ "WHERE P.UPC_COUNTRY IN ( :upcCountry) "
				+ " AND P.UPC_SYSTEM IN ( :upcSystem) "
				+ " AND P.UPC_MANUF IN ( :upcManuf) "
				+ " AND P.UPC_SALES IN ( :upcSales) " 
				+ " AND X.STATUS_UPC NOT IN ('D','X') AND S.DISP_FLAG = 'Y' AND W.DST_CNTR LIKE :productSourceCode ";
		EntityManager em = entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query);
		
		List<String> upcCountryList = Arrays.asList(upcCountry.split(","));
		q.setParameter("upcCountry", upcCountryList);
		
		List<String> upcSystemList = Arrays.asList(upcSystem.split(","));
		q.setParameter("upcSystem", upcSystemList);
		
		List<String> upcManufList = Arrays.asList(upcManuf.split(","));
		q.setParameter("upcManuf", upcManufList);
		
		List<String> upcSalesList = Arrays.asList(upcSales.split(","));
		q.setParameter("upcSales", upcSalesList);
		
		q.setParameter("productSourceCode", productSourceCode+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Sims Details Based on Source Upcset.");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchDeptWiseDisplayItemForExport(String companyId, String divisionId,String departmentCode, char status) {

	     LOG.info("Fetching department wise item details for export.");
	     StringBuilder query = new StringBuilder();
	     if (status == 'N') {
				StringBuilder unReviewedBaseQuery = new StringBuilder("");
				unReviewedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
				.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
				.append(" :departmentCode AND D.COMPANY_ID =").append(" :companyId  AND D.DIVISION_ID =").append(" :divisionId AND D.MULTI_COMP_ITEM_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O','C') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT >  DATEADD(MM,-9,GETDATE())) AND DI.PRODUCT_SKU IS NULL ");
				query =  new StringBuilder().append(unReviewedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
				
			}

			if (status == 'C') {
				StringBuilder completedBaseQuery = new StringBuilder("");
				completedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
				.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID ")
				.append("AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
				.append(" :departmentCode  AND D.COMPANY_ID =").append(" :companyId  AND D.DIVISION_ID =").append(" :divisionId AND D.MULTI_COMP_ITEM_IND = 'Y' AND DI.DISPLAY_ITEM_PROCESSED_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE())) ");
				query = new StringBuilder().append(completedBaseQuery).append(" ORDER BY S.ITEM_SETUP_DT DESC ");
			}
	    
	     EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
	     Query q = em.createNativeQuery(query.toString());
	     q.setParameter("departmentCode", departmentCode);
	     q.setParameter("companyId", companyId);
	     q.setParameter("divisionId", divisionId);
	     q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
	     q.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
	     List<Object[]> results = q.getResultList();
	     LOG.info("Completed fetching department wise item for export.");
	     em.close();
	     return results;

	}

	public List<Object[]> fetchDeptWiseDisplayComponentExceptionListExport(String companyId, String divisionId,String departmentCode, String whsedsd ) {

	     LOG.info("Fetching department wise item details for export.");
	     final String baseQuery1 =new StringBuilder("")
	    		 .append("  SELECT         DISTINCT D.PRODUCT_SKU,PH.DEPARTMENT_NM,D.ITEM_DESC, D.SHIPPING_PACK_NBR,D.SIZE_NBR,D.SIZE_DESC,"
	    		 +" case when D.SOURCE_BY_DSD = 'Y'  then E.VENDOR_LIST_COST_NBR  ELSE  W.VENDOR_LIST_COST_NBR    end \"DISPLAY_ITEM_COST\", "        
	    		 +" D.CASE_UPC, DC.UPC_COUNTRY,DC.UPC_SYSTEM,DC.UPC_MANUF,DC.UPC_SALES, DC.COMP_ITEM_DSC,DC.COMP_SHELF_UNIT,DC.COMP_SIZE_DSC,DC.UNIT_COST, ").toString();
	     
	     final String baseQuery2 =new StringBuilder("")
	    		 .append(" FROM  ECFLAND.ITEM_AGGREGATE_CORP D "
	    		 +" LEFT JOIN    ECFLAND.ITEM_CONV_SALES_SHIP_DATA S " 
		         +" ON D.COMPANY_ID = S.COMPANY_ID "
		         +" AND D.DIVISION_ID = S.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = S.PRODUCT_SKU "
		         +" JOIN  XREFLAND.SRC_ITEM_XRF X " 
		         +" ON D.COMPANY_ID = X.COMPANY_ID " 
		         +" AND D.DIVISION_ID = X.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU " 
		         +" LEFT JOIN     ECFLAND.ITEM_AGGREGATE_DSD E " 
		         +" ON D.COMPANY_ID = E.COMPANY_ID " 
		         +" AND D.DIVISION_ID = E.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = E.PRODUCT_SKU " 
		         +" LEFT JOIN     ECFLAND.ITEM_AGGREGATE_WHSE W " 
		         +" ON D.COMPANY_ID = W.COMPANY_ID " 
		         +" AND D.DIVISION_ID = W.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = W.PRODUCT_SKU " 
		         +" LEFT JOIN "
		         +" ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI " 
		         +" ON D.COMPANY_ID = DI.COMPANY_ID " 
		         +" AND D.DIVISION_ID = DI.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = DI.PRODUCT_SKU " 
            
    			 +" LEFT JOIN ECFLAND.DISPLAY_ITEM_COMPONENTS DC "
    			 +" ON D.COMPANY_ID = DC.COMPANY_ID "
    			 +" AND D.DIVISION_ID = DC.DIVISION_ID " 
                 +"  AND D.PRODUCT_SKU = DC.PRODUCT_SKU  "
                 +" LEFT JOIN ECFLAND.PRODUCT_HIERARCHY  PH "
                 +" ON D.COMPANY_ID = PH.COMPANY_ID " 
                 +" AND D.DIVISION_ID = PH.DIVISION_ID " 
                 +" AND D.PROD_HIERARCHY_LVL_1_CD =PH.PROD_HIERARCHY_LVL_1_CD "
                 +" AND D.PROD_HIERARCHY_LVL_2_CD =PH.PROD_HIERARCHY_LVL_2_CD  "
                 +" AND D.PROD_HIERARCHY_LVL_3_CD =PH.PROD_HIERARCHY_LVL_3_CD  "
                 +" AND D.PROD_HIERARCHY_LVL_4_CD =PH.PROD_HIERARCHY_LVL_4_CD   "  
                 +" WHERE "
                 +" D.MULTI_COMP_ITEM_IND = 'Y' "
                 +" AND X.CONV_STATUS_CD NOT IN(  'D','O','C' ) "
                 +" AND (   S.SLOT IS NOT NULL " 
                 +" OR S.ON_HAND IS NOT NULL "
                 +" OR S.ON_ORDER_QTY IS NOT NULL " 
                 +" OR S.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE()) ) " 
                 +" AND D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL "
                 +" AND DI.PRODUCT_SKU IS NULL ").toString();
	     
	     
	     
	     StringBuilder generalConditionsBuilder = new StringBuilder("");
	     generalConditionsBuilder.append("  AND D.PROD_HIERARCHY_LVL_4_CD =? AND D.COMPANY_ID = ? AND D.DIVISION_ID = ? ");
	     if (whsedsd .equals("W")) {
	    	 generalConditionsBuilder.append(" AND D.SOURCE_BY_WHSE= 'Y'  ");	
			}
	     else  if (whsedsd .equals("A")) {
	    	 generalConditionsBuilder.append(" AND ( D.SOURCE_BY_WHSE= 'Y' OR D.SOURCE_BY_DSD= 'Y' ) ");	
		 }
	     else if (whsedsd .equals("D"))
	     {
	    	 generalConditionsBuilder.append(" AND D.SOURCE_BY_DSD= 'Y' ");	
	    	 	    	 
	     }
	     final String generalConditions = generalConditionsBuilder.toString();
	   	     
	     final String missingExceptionConditions = new StringBuilder(" AND DC.PRODUCT_SKU IS  NULL ").toString();
	     final String costExceptionConditions = new StringBuilder("  AND D.PRODUCT_SKU in ( select distinct PRODUCT_SKU from ECFLAND.DISPLAY_ITEM_COMPONENTS where COMPANY_ID = ?   AND DIVISION_ID = ?   And  UNIT_COST =0   )").toString();
	     final String quantityExceptionConditions = new StringBuilder("  AND D.PRODUCT_SKU in ( select distinct PRODUCT_SKU from ECFLAND.DISPLAY_ITEM_COMPONENTS where COMPANY_ID = ?   AND DIVISION_ID = ?   And   COMP_SHELF_UNIT = 0  And  UNIT_COST > 0  ) ").toString();
	     
	     //StringBuilder orderBy =new StringBuilder(" order by PH.DEPARTMENT_NM asc  ");
	    // StringBuilder selectAll =new StringBuilder("select * from ( ");
	     //StringBuilder subQueryEnd = new StringBuilder(" ) ");
	     
	     final String exception_type =" 'MISSING COMPONENT EXCEPTION' ";
	     final StringBuilder noCompnentquery = new StringBuilder().append(baseQuery1).append(exception_type).append(baseQuery2).append(generalConditions).append(missingExceptionConditions).append("");
	     final String exception_type1 =" case when (DC.UNIT_COST = 0 AND DC.COMP_SHELF_UNIT = 0) then 'MISSING COST AND QUANTITY EXCEPTION' when (DC.UNIT_COST = 0 AND DC.COMP_SHELF_UNIT > 0) then 'MISSING COST EXCEPTION' ELSE  'No_EXCEPTION' end \"Exception_category\" ";
	     final StringBuilder noCostquery = new StringBuilder().append(baseQuery1).append(exception_type1).append(baseQuery2).append(generalConditions).append(costExceptionConditions).append("");
	     final String exception_type2 =" case when DC.COMP_SHELF_UNIT = 0 then 'MISSING QUANTITY EXCEPTION'   ELSE  'No_EXCEPTION' end \"Exception_category\" ";
	     final StringBuilder noQuantityquery = new StringBuilder().append(baseQuery1).append(exception_type2).append(baseQuery2).append(generalConditions).append(quantityExceptionConditions).append("");
	         
	     
		
	     List<Object[]> fullExceptionresults = new ArrayList<>();
	    
	     EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
	    /* 	     
	     Query q1 = em.createNativeQuery(noCompnentquery.toString());
	     q1.setParameter(1, departmentCode);
	     q1.setParameter(2, companyId);
	     q1.setParameter(3, divisionId);
	     q1.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
	     q1.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
	     fullExceptionresults.addAll(q1.getResultList());
	     LOG.info("Completed component missing exception list added");
	     
	     
	   
	     Query q2 = em.createNativeQuery(noCostquery.toString());
	     q2.setParameter(1, departmentCode);
	     q2.setParameter(2, companyId);
	     q2.setParameter(3, divisionId);
	     q2.setParameter(4, companyId);
	     q2.setParameter(5, divisionId);
	     q2.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
	     q2.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
	     fullExceptionresults.addAll(q2.getResultList());
	     LOG.info("Completed cost missing exception list added");
	     
	     
	    
	     Query q3 = em.createNativeQuery(noQuantityquery.toString());
	     q3.setParameter(1, departmentCode);
	     q3.setParameter(2, companyId);
	     q3.setParameter(3, divisionId);
	     q3.setParameter(4, companyId);
	     q3.setParameter(5, divisionId);
	     q3.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
	     q3.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
	     fullExceptionresults.addAll(q3.getResultList());
	     LOG.info("Completed quantity missing exception list added");     
	    */
	     
	     /**SINGLE UNION QUERY**/
	     final StringBuilder fullUnionQuery = noCompnentquery.append(" UNION ALL ")
	    		 .append(noCostquery).append(" UNION ALL ").
	    		 append(noQuantityquery);
	     Query q1 = em.createNativeQuery(fullUnionQuery.toString());
	     q1.setParameter(1, departmentCode);
	     q1.setParameter(2, companyId);
	     q1.setParameter(3, divisionId);
	     
	     q1.setParameter(4, departmentCode);
	     q1.setParameter(5, companyId);
	     q1.setParameter(6, divisionId);
	     q1.setParameter(7, companyId);
	     q1.setParameter(8, divisionId);
	     
	     q1.setParameter(9, departmentCode);
	     q1.setParameter(10, companyId);
	     q1.setParameter(11, divisionId);
	     q1.setParameter(12, companyId);
	     q1.setParameter(13, divisionId);
	     
	     fullExceptionresults.addAll(q1.getResultList());
	     /**SINGLE UNION QUERY**/
	     em.close();
	     return fullExceptionresults;

	}
	public List<Object[]> validDisplayEntry(String companyId, String divisionId,String prodcutSKU, String upc )
	{
		StringBuilder query =new StringBuilder("SELECT  DISTINCT D.PRODUCT_SKU ,D.UPC FROM  ECFLAND.ITEM_AGGREGATE_CORP D "); 
		query.append("   JOIN  XREFLAND.SRC_ITEM_XRF X " 
		         +" ON D.COMPANY_ID = X.COMPANY_ID " 
		         +" AND D.DIVISION_ID = X.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU "
		       	         
		         +" LEFT JOIN "
		         +" ECFLAND.ITEM_CONV_SALES_SHIP_DATA S " 
		         +" ON D.COMPANY_ID = S.COMPANY_ID "
		         +" AND D.DIVISION_ID = S.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = S.PRODUCT_SKU "
		         +" LEFT JOIN "
		         +" ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI " 
		         +" ON D.COMPANY_ID = DI.COMPANY_ID " 
		         +" AND D.DIVISION_ID = DI.DIVISION_ID " 
		         +" AND D.PRODUCT_SKU = DI.PRODUCT_SKU ");
		
		query.append(" WHERE "
                +" D.MULTI_COMP_ITEM_IND = 'Y' "
                +" AND X.CONV_STATUS_CD NOT IN(  'D','O','C' ) "
                +" AND (   S.SLOT IS NOT NULL " 
                +" OR S.ON_HAND IS NOT NULL "
                +" OR S.ON_ORDER_QTY IS NOT NULL " 
                +" OR S.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE()) ) " 
                +" AND D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL "
                +" AND DI.PRODUCT_SKU IS NULL ");
		query.append("AND D.company_id = ?");
		query.append("AND D.division_id = ?");
		query.append("AND D.PRODUCT_SKU = ?");
		
		String queryfinal=query.toString();
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		 Query q1 = em.createNativeQuery(queryfinal);
	     q1.setParameter(1, companyId);
	     q1.setParameter(2, divisionId);
	     q1.setParameter(3, prodcutSKU);	     
	    
	     List<Object[]> result= q1.getResultList();
	     em.close();
	     return result;
		
		
	}

	/*Reviewed category search implementation new feature*/
	
	public List<Object[]> fetchDeptWiseItemDetailsBasedOnReviewedItemDesc(
			String company, String division, String department,
			String itemDesc, char itemtype) {
		LOG.info("Started fetching department wise item details based on Item Desc");
		

		StringBuilder itemDescription = null;
		if (itemDesc.contains("|")) {
			itemDescription = new StringBuilder()
					.append("AND D.ITEM_DESC LIKE :itemDesc   ESCAPE '|' ");
		} else {
			itemDescription = new StringBuilder()
					.append(" AND D.ITEM_DESC LIKE :itemDesc ");
		}

		StringBuilder completedBaseQuery = new StringBuilder("");
		completedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
		.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID ")
		.append("AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
		.append(" :department  AND D.COMPANY_ID = ").append( " :company AND D.DIVISION_ID = :division").append(  " AND D.MULTI_COMP_ITEM_IND = 'Y' AND DI.DISPLAY_ITEM_PROCESSED_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE())) ");
		
		completedBaseQuery.append(itemDescription.toString());
		
	if (itemtype == 'D') {
			completedBaseQuery.append(" AND D.SOURCE_BY_DSD= 'Y' ");
		}
		if (itemtype == 'W') {
			completedBaseQuery.append(" AND D.SOURCE_BY_WHSE= 'Y' ");
		}
		completedBaseQuery.append(" ORDER BY S.ITEM_SETUP_DT DESC ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(completedBaseQuery.toString());
		q.setParameter("itemDesc", "%"+itemDesc+"%");
		q.setParameter("department", department);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details based on Item Desc.");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchDeptWiseItemDetailsBasedOnReviewedProductSku(
			String company, String division, String department,
			String productSku, char itemtype) {
		LOG.info("Started fetching department wise item details based on product sku");
		
		StringBuilder completedBaseQuery = new StringBuilder("");
		completedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
		.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID ")
		.append("AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
		.append(":department AND D.COMPANY_ID = ").append( " :company AND D.DIVISION_ID =").append( ":division AND D.MULTI_COMP_ITEM_IND = 'Y' AND DI.DISPLAY_ITEM_PROCESSED_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE())) ");
		completedBaseQuery.append(" AND D.PRODUCT_SKU = :productSku");
		completedBaseQuery.append("");
		
		if (itemtype == 'D') {
			completedBaseQuery.append(" AND D.SOURCE_BY_DSD= 'Y' ");
		}
		if (itemtype == 'W') {
			completedBaseQuery.append(" AND D.SOURCE_BY_WHSE= 'Y' ");
		}
		
			completedBaseQuery.append(" ORDER BY S.ITEM_SETUP_DT DESC ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(completedBaseQuery.toString());
		q.setParameter("department", department);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("productSku", productSku.trim());
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details  on product sku.");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(
			String company, String division, String department,
			String oneTimeBuyFlag, char itemType) {
		LOG.info("Started fetching department wise item details based on OneTimeBuyFlag");
		StringBuilder completedBaseQuery = new StringBuilder("");
		completedBaseQuery.append("SELECT DISTINCT D.PRODUCT_SKU, D.ITEM_DESC, D.SHIPPING_PACK_NBR, (D.MASTER_CASE_PACK_NBR / NULLIF(D.SHIPPING_PACK_NBR,0)) AS VCF, D.SIZE_NBR, D.MULTI_COMP_ITEM_IND, D.CASE_UPC, S.ON_HAND, S.ON_ORDER_QTY, S.SLOT, S.ITEM_SETUP_DT, S.LAST_RECV_DT, S.LAST_SHIP_DT, E.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, D.ONE_TIME_BUY_ITEM_IND, D.SOURCE_BY_WHSE, D.SOURCE_BY_DSD FROM ECFLAND.ITEM_AGGREGATE_CORP D LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA S ")
		.append("ON D.COMPANY_ID = S.COMPANY_ID AND D.DIVISION_ID = S.DIVISION_ID AND D.PRODUCT_SKU = S.PRODUCT_SKU JOIN XREFLAND.SRC_ITEM_XRF X ON D.COMPANY_ID = X.COMPANY_ID AND D.DIVISION_ID = X.DIVISION_ID AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_DSD E ON D.COMPANY_ID = E.COMPANY_ID AND D.DIVISION_ID = E.DIVISION_ID ")
		.append("AND D.PRODUCT_SKU = E.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON D.COMPANY_ID = W.COMPANY_ID AND D.DIVISION_ID = W.DIVISION_ID AND D.PRODUCT_SKU = W.PRODUCT_SKU JOIN ECFLAND.ITEM_CONV_DISPLAY_ITEMS DI ON D.COMPANY_ID = DI.COMPANY_ID AND D.DIVISION_ID = DI.DIVISION_ID AND D.PRODUCT_SKU = DI.PRODUCT_SKU WHERE D.PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND D.PROD_HIERARCHY_LVL_4_CD =")
		.append(" :department  AND D.COMPANY_ID = ").append( ":company  AND D.DIVISION_ID =").append( " :division  AND D.MULTI_COMP_ITEM_IND = 'Y' AND DI.DISPLAY_ITEM_PROCESSED_IND = 'Y' AND X.CONV_STATUS_CD NOT IN('D','O') AND (S.SLOT IS NOT NULL OR S.ON_HAND IS NOT NULL OR S.ON_ORDER_QTY IS NOT NULL OR S.ITEM_SETUP_DT > DATEADD(MM,-9,GETDATE())) ");
		
		completedBaseQuery.append(" AND D.ONE_TIME_BUY_ITEM_IND =  :oneTimeBuyFlag " );
		if (itemType == 'D') {
			completedBaseQuery.append(" AND D.SOURCE_BY_DSD= 'Y' ");
		}
		if (itemType == 'W') {
			completedBaseQuery.append(" AND D.SOURCE_BY_WHSE= 'Y' ");
		}
		
			completedBaseQuery.append(" ORDER BY S.ITEM_SETUP_DT DESC ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(completedBaseQuery.toString());
		q.setParameter("department", department);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("oneTimeBuyFlag", oneTimeBuyFlag);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department wise item details  on OneTimeBuyFlag.");
		em.close();
		return results;
	}
}
