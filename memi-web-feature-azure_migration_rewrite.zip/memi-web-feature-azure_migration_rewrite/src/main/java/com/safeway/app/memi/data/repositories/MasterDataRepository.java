package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : MasterDataRepository
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 9, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ItemXrefData;

/**
 * Repository class for all DB operations for SRC_ITEM_XRF table
 */
@Repository
public interface MasterDataRepository extends JpaRepository<ItemXrefData, Long> {

    /**
     * @param productSKU
     * @param companyID
     * @param divisionID
     * @return
     */
    @Query
    List<ItemXrefData> findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId(String productSKU, String companyID, String divisionID);
    
    @Query
	List<ItemXrefData> findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionIdAndItemPkUpcCountryAndItemPkUpcSystemAndItemPkUpcManuAndItemPkUpcSales(
			String productSKU, String companyId, String divisionId,
			Integer upcCountry, Integer upcSystem, Integer upcManufacturer,
			Integer upcSales);
    
}
