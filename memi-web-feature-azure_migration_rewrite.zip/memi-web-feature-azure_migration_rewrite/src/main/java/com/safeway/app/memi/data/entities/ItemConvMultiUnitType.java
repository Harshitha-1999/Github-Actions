package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Entity class for Database table ITEM_CONV_MULTI_UNIT_TYPE.
 * 
 */

@Entity
@Table(name = "ITEM_CONV_MULTI_UNIT_TYPE", schema="ECFLAND")
public class ItemConvMultiUnitType implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ItemConvMultiUnitTypePk multiUnitPk;
	
	@Column(name = "CONV_PRODUCT_SKU")
	private String convProductSku;
	
	@Column(name = "SRC_ITEM_DESC")
	private String srcItemDesc;
	
	@Column(name = "SRC_PACK_WHSE")
	private BigDecimal srcPackWhse;
	
	@Column(name = "SRC_VEND_CONV_FCTR")
	private BigDecimal srcVendConvFctr;
	
	@Column(name = "SRC_SIZE")
	private String srcSize;
	
	@Column(name = "PROD_SOURCE_CD")
	private String prodSourceCd;
	
	@Column(name = "SRC_PROD_HIERARCHY_LVL_1_CD")
	private String srcprodHierarchyLvl1Cd;
	
	@Column(name = "SRC_PROD_HIERARCHY_LVL_2_CD")
	private String srcprodHierarchyLvl2Cd;
	
	@Column(name = "SRC_PROD_HIERARCHY_LVL_3_CD")
	private String srcprodHierarchyLvl3Cd;
	
	@Column(name = "SRC_PROD_HIERARCHY_LVL_4_CD")
	private String srcprodHierarchyLvl4Cd;
	
	@Column(name = "SRC_PROD_HIERARCHY_LVL_5_CD")
	private String srcprodHierarchyLvl5Cd;
	
	@Column(name = "CASE_UPC")
	private String caseUpc;
	
	@Column(name = "SRC_MAX_RETAIL")
	private BigDecimal srcMaxRetail;
	
	@Column(name = "SRC_VEND_NUM")
	private BigDecimal srcVendNum;
	
	@Column(name = "CORP_ITEM_CD")
	private BigDecimal corpItemCode;
	
	@Column(name = "AUTO_MANUAL_IND")
	private String autoManualInd;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "SRC_COST")
	private BigDecimal srcCost;
	
	@Column(name = "CREATE_UPDATE_USER_ID")
	private String updatedUserId;
	
	@Column(name = "CREATE_UPDATE_TS", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Timestamp  updatedTimestamp;
	
	@Column(name = "BATCH_ID")
	private BigDecimal batchId;
	
	@Column(name = "SRC_VEND_NAME")
	private String srcVendorName; 
	
	
	public String getSrcVendorName() {
		return srcVendorName;
	}

	public void setSrcVendorName(String srcVendorName) {
		this.srcVendorName = srcVendorName;
	}

	public String getConvProductSku() {
		return convProductSku;
	}

	public void setConvProductSku(String convProductSku) {
		this.convProductSku = convProductSku;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}

	public Timestamp getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(Timestamp updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	public ItemConvMultiUnitTypePk getMultiUnitPk() {
		return multiUnitPk;
	}

	public void setMultiUnitPk(ItemConvMultiUnitTypePk multiUnitPk) {
		this.multiUnitPk = multiUnitPk;
	}

	public String getSrcItemDesc() {
		return srcItemDesc;
	}

	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}

	public BigDecimal getSrcPackWhse() {
		return srcPackWhse;
	}

	public void setSrcPackWhse(BigDecimal srcPackWhse) {
		this.srcPackWhse = srcPackWhse;
	}

	public BigDecimal getSrcVendConvFctr() {
		return srcVendConvFctr;
	}

	public void setSrcVendConvFctr(BigDecimal srcVendConvFctr) {
		this.srcVendConvFctr = srcVendConvFctr;
	}

	public String getSrcSize() {
		return srcSize;
	}

	public void setSrcSize(String srcSize) {
		this.srcSize = srcSize;
	}

	public String getProdSourceCd() {
		return prodSourceCd;
	}

	public void setProdSourceCd(String prodSourceCd) {
		this.prodSourceCd = prodSourceCd;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public BigDecimal getSrcCost() {
		return srcCost;
	}

	public void setSrcCost(BigDecimal srcCost) {
		this.srcCost = srcCost;
	}

	public BigDecimal getSrcVendNum() {
		return srcVendNum;
	}

	public void setSrcVendNum(BigDecimal srcVendNum) {
		this.srcVendNum = srcVendNum;
	}

	public BigDecimal getCorpItemCode() {
		return corpItemCode;
	}

	public void setCorpItemCode(BigDecimal corpItemCode) {
		this.corpItemCode = corpItemCode;
	}

	public String getAutoManualInd() {
		return autoManualInd;
	}

	public void setAutoManualInd(String autoManualInd) {
		this.autoManualInd = autoManualInd;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public BigDecimal getSrcMaxRetail() {
		return srcMaxRetail;
	}

	public void setSrcMaxRetail(BigDecimal srcMaxRetail) {
		this.srcMaxRetail = srcMaxRetail;
	}

	public String getSrcprodHierarchyLvl1Cd() {
		return srcprodHierarchyLvl1Cd;
	}

	public void setSrcprodHierarchyLvl1Cd(String srcprodHierarchyLvl1Cd) {
		this.srcprodHierarchyLvl1Cd = srcprodHierarchyLvl1Cd;
	}

	public String getSrcprodHierarchyLvl2Cd() {
		return srcprodHierarchyLvl2Cd;
	}

	public void setSrcprodHierarchyLvl2Cd(String srcprodHierarchyLvl2Cd) {
		this.srcprodHierarchyLvl2Cd = srcprodHierarchyLvl2Cd;
	}

	public String getSrcprodHierarchyLvl3Cd() {
		return srcprodHierarchyLvl3Cd;
	}

	public void setSrcprodHierarchyLvl3Cd(String srcprodHierarchyLvl3Cd) {
		this.srcprodHierarchyLvl3Cd = srcprodHierarchyLvl3Cd;
	}

	public String getSrcprodHierarchyLvl4Cd() {
		return srcprodHierarchyLvl4Cd;
	}

	public void setSrcprodHierarchyLvl4Cd(String srcprodHierarchyLvl4Cd) {
		this.srcprodHierarchyLvl4Cd = srcprodHierarchyLvl4Cd;
	}

	public String getSrcprodHierarchyLvl5Cd() {
		return srcprodHierarchyLvl5Cd;
	}

	public void setSrcprodHierarchyLvl5Cd(String srcprodHierarchyLvl5Cd) {
		this.srcprodHierarchyLvl5Cd = srcprodHierarchyLvl5Cd;
	}

	public BigDecimal getBatchId() {
		return batchId;
	}

	public void setBatchId(BigDecimal batchId) {
		this.batchId = batchId;
	}
}