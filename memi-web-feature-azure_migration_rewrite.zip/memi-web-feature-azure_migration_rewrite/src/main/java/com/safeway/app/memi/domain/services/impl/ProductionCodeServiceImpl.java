package com.safeway.app.memi.domain.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.ProductionCodeDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.services.ProductionCodeService;

@Service("ProductionCodeService")
public class ProductionCodeServiceImpl implements ProductionCodeService {
	private static final Logger LOG  = LoggerFactory.getLogger(ProductionCodeServiceImpl.class);

	@Autowired
	private CommonSQLRepository commonSQLRepo;

	private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();

	@Override
	public List<ProductionCodeDetailDto> getProductionCode(String grpCd,
			String ctgryCd, String clsCd, String sbClsCd, String subSbClass) {
		LOG.info("Execution started to fetch production Code List ");
		List<Object[]> productionCodeList = commonSQLRepo.fetchProductionCode(
				grpCd, ctgryCd, clsCd, sbClsCd, subSbClass);
		LOG.info("Execution completed to fetch "+productionCodeList.size()+" production Code List ");

		return viewAdapter.mapToProductionCodeDetailDtoList(productionCodeList);
	}

	@Override
	public List<SmicCodeDescWrapper> getProductionGroupCode() {
		LOG.info("Execution started to fetch production Group Code List ");

		List<Object[]> groupCodeAndDescList = commonSQLRepo
				.fetchProductionGroupCodeWithDesc();
		LOG.info("Execution completed to fetch "+groupCodeAndDescList.size()+" production Group Code List ");

		return viewAdapter.mapCodeWithDesc(groupCodeAndDescList);
	}

	@Override
	public List<SmicCodeDescWrapper> getProductionCategoryCode(String groupCode) {
		LOG.info("Execution started to fetch production Category Code  List ");

		List<Object[]> categoryCodeAndDescList = commonSQLRepo.fetchProductionCategoryCodeWithDesc(groupCode);
		
		LOG.info("Execution completed to fetch "+categoryCodeAndDescList.size()+" production Category Code List ");

		return viewAdapter.mapCodeWithDesc(categoryCodeAndDescList);
	}

	@Override
	public List<SmicCodeDescWrapper> getProductionClassCode(String groupCode,
			String categoryCode) {
		LOG.info("Execution started to fetch production Class Code List ");

		List<Object[]> classCodeAndDescList = commonSQLRepo
				.fetchProductionClassCodeWithDesc(groupCode, categoryCode);
		LOG.info("Execution completed to fetch "+classCodeAndDescList.size()+" production Class Code List ");

		return viewAdapter.mapCodeWithDesc(classCodeAndDescList);
	}

}