package com.safeway.app.memi.domain.dtos.response;
/* ***************************************************************************
 * NAME         : CompanyDto
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Varada Nellayikunnath
 *
 * REVISION HISTORY
 *
 * Initial creation for MEMI - 15/05/2017- vnell00
 *
 ***************************************************************************/
public class SimsLikeItemDto {
    
    private String prmyUpc;
    private String ssimsItemDesc;
    private String ssimsWhseDesc;
    private String ssimsInternetDesc;
    private String ssismsSysDesc;
    private String ssismsPOSDesc;
    private int ssismPackNo;
    private int ssimsVcf;
    private char ssimsItemUsageInd;
    private char ssimsItemUsageTypeInd;
    private char itemSmicCode;
    private String smicCode;
    private String ssimsDeptName;
   // private DcDetail dcDetail;
    private String ssimsDsdCd;
    private String ssimsCaseUpc;
    private String ssimsDescSize;
    private String ssismsNumSize;
    private String prdSrc;
    private String ssimsSmicDesc;
    private int ssimsDeptNum;
    private char ssimsprivatelabel;
    private String ConvTeamCmnt;
    private boolean aptItemFromSims;
    private boolean isprodSrcItem;
    public String getPrmyUpc() {
        return prmyUpc;
    }
    public void setPrmyUpc(String prmyUpc) {
        this.prmyUpc = prmyUpc;
    }
    public String getSsimsItemDesc() {
        return ssimsItemDesc;
    }
    public void setSsimsItemDesc(String ssimsItemDesc) {
        this.ssimsItemDesc = ssimsItemDesc;
    }
    public String getSsimsWhseDesc() {
        return ssimsWhseDesc;
    }
    public void setSsimsWhseDesc(String ssimsWhseDesc) {
        this.ssimsWhseDesc = ssimsWhseDesc;
    }
    public String getSsimsInternetDesc() {
        return ssimsInternetDesc;
    }
    public void setSsimsInternetDesc(String ssimsInternetDesc) {
        this.ssimsInternetDesc = ssimsInternetDesc;
    }
    public String getSsismsSysDesc() {
        return ssismsSysDesc;
    }
    public void setSsismsSysDesc(String ssismsSysDesc) {
        this.ssismsSysDesc = ssismsSysDesc;
    }
    public String getSsismsPOSDesc() {
        return ssismsPOSDesc;
    }
    public void setSsismsPOSDesc(String ssismsPOSDesc) {
        this.ssismsPOSDesc = ssismsPOSDesc;
    }
    public int getSsismPackNo() {
        return ssismPackNo;
    }
    public void setSsismPackNo(int ssismPackNo) {
        this.ssismPackNo = ssismPackNo;
    }
    public int getSsimsVcf() {
        return ssimsVcf;
    }
    public void setSsimsVcf(int ssimsVcf) {
        this.ssimsVcf = ssimsVcf;
    }
    public char getSsimsItemUsageInd() {
        return ssimsItemUsageInd;
    }
    public void setSsimsItemUsageInd(char ssimsItemUsageInd) {
        this.ssimsItemUsageInd = ssimsItemUsageInd;
    }
    public char getSsimsItemUsageTypeInd() {
        return ssimsItemUsageTypeInd;
    }
    public void setSsimsItemUsageTypeInd(char ssimsItemUsageTypeInd) {
        this.ssimsItemUsageTypeInd = ssimsItemUsageTypeInd;
    }
    public char getItemSmicCode() {
        return itemSmicCode;
    }
    public void setItemSmicCode(char itemSmicCode) {
        this.itemSmicCode = itemSmicCode;
    }
    public String getSmicCode() {
        return smicCode;
    }
    public void setSmicCode(String smicCode) {
        this.smicCode = smicCode;
    }
    public String getSsimsDeptName() {
        return ssimsDeptName;
    }
    public void setSsimsDeptName(String ssimsDeptName) {
        this.ssimsDeptName = ssimsDeptName;
    }
  /*  public DcDetail getDcDetail() {
        return dcDetail;
    }
    public void setDcDetail(DcDetail dcDetail) {
        this.dcDetail = dcDetail;
    }*/
    public String getSsimsDsdCd() {
        return ssimsDsdCd;
    }
    public void setSsimsDsdCd(String ssimsDsdCd) {
        this.ssimsDsdCd = ssimsDsdCd;
    }
    public String getSsimsCaseUpc() {
        return ssimsCaseUpc;
    }
    public void setSsimsCaseUpc(String ssimsCaseUpc) {
        this.ssimsCaseUpc = ssimsCaseUpc;
    }
    public String getSsimsDescSize() {
        return ssimsDescSize;
    }
    public void setSsimsDescSize(String ssimsDescSize) {
        this.ssimsDescSize = ssimsDescSize;
    }
    public String getSsismsNumSize() {
        return ssismsNumSize;
    }
    public void setSsismsNumSize(String ssismsNumSize) {
        this.ssismsNumSize = ssismsNumSize;
    }
    public String getPrdSrc() {
        return prdSrc;
    }
    public void setPrdSrc(String prdSrc) {
        this.prdSrc = prdSrc;
    }
    public String getSsimsSmicDesc() {
        return ssimsSmicDesc;
    }
    public void setSsimsSmicDesc(String ssimsSmicDesc) {
        this.ssimsSmicDesc = ssimsSmicDesc;
    }
    public int getSsimsDeptNum() {
        return ssimsDeptNum;
    }
    public void setSsimsDeptNum(int ssimsDeptNum) {
        this.ssimsDeptNum = ssimsDeptNum;
    }
    public char getSsimsprivatelabel() {
        return ssimsprivatelabel;
    }
    public void setSsimsprivatelabel(char ssimsprivatelabel) {
        this.ssimsprivatelabel = ssimsprivatelabel;
    }
    public String getConvTeamCmnt() {
        return ConvTeamCmnt;
    }
    public void setConvTeamCmnt(String convTeamCmnt) {
        ConvTeamCmnt = convTeamCmnt;
    }
    public boolean isAptItemFromSims() {
        return aptItemFromSims;
    }
    public void setAptItemFromSims(boolean aptItemFromSims) {
        this.aptItemFromSims = aptItemFromSims;
    }
    public boolean isIsprodSrcItem() {
        return isprodSrcItem;
    }
    public void setIsprodSrcItem(boolean isprodSrcItem) {
        this.isprodSrcItem = isprodSrcItem;
    }
    
    
    

}
