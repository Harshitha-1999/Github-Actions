/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

/**
 ****************************************************************************
 * NAME : PerishableFilterVO 
 *
 *DESCRIPTION :PerishableFilterVO is the class to map the filtering data fields
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */

public class PerishableFilterVO {
	
	private String corpItemCD;
	private String department;
	private String divisionNum;
	private String hierarchy;
	private String itemNum;
	private String itemDescription;
	private String productSKU;
	private String plu;
	private String supplierName;
	private String supplierNum;
	private String slu;
	private String upc;
	private String smicGroupCd;
	private String smicCtgryCd;
	private String smicClassCd;
	private String smicSubClassCd;
	private String smicSubSubClassCd;
	private String prodhierarchyLevel1;
	private String prodhierarchyLevel2;
	private String prodhierarchyLevel3;
	private String vendorName;
	private String vendorCode;
	
	/*total sales based search*/
	private boolean totalSalesFilter;
	private String totalSalesOperator;
	private String totalSalesvalue;	
	
	/*usage type value*/
	private boolean usageFilter;
	private String usageType;	
	
	/*shipment filer*/
	private boolean isShipped ;
	private String shipSearchValue ;
	
	private boolean usageTypeIndFilter;
	private String usageTypeInd;	
	
	private boolean vendorOrderFilter;
	private String vendUpcPackInd;
	private String vendUpcCountry;
	private String vendUpcNumSys;
	private String vendUpcManuf;
	private String vendUpcItem;
	
	
	
	
		
	public String getUsageTypeInd() {
		return usageTypeInd;
	}
	public void setUsageTypeInd(String usageTypeInd) {
		this.usageTypeInd = usageTypeInd;
	}
	/**
	 * @return the corpItemCD
	 */
	public String getCorpItemCD() {
		return corpItemCD;
	}
	/**
	 * @param corpItemCD the corpItemCD to set
	 */
	public void setCorpItemCD(String corpItemCD) {
		this.corpItemCD = corpItemCD;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
	/**
	 * @return the divisionNum
	 */
	public String getDivisionNum() {
		return divisionNum;
	}
	/**
	 * @param divisionNum the divisionNum to set
	 */
	public void setDivisionNum(String divisionNum) {
		this.divisionNum = divisionNum;
	}
	/**
	 * @return the hierarchy
	 */
	public String getHierarchy() {
		return hierarchy;
	}
	/**
	 * @param hierarchy the hierarchy to set
	 */
	public void setHierarchy(String hierarchy) {
		this.hierarchy = hierarchy;
	}
	/**
	 * @return the itemNum
	 */
	public String getItemNum() {
		return itemNum;
	}
	/**
	 * @param itemNum the itemNum to set
	 */
	public void setItemNum(String itemNum) {
		this.itemNum = itemNum;
	}
	/**
	 * @return the itemDescription
	 */
	public String getItemDescription() {
		return itemDescription;
	}
	/**
	 * @param itemDescription the itemDescription to set
	 */
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	/**
	 * @return the productSKU
	 */
	public String getProductSKU() {
		return productSKU;
	}
	/**
	 * @param productSKU the productSKU to set
	 */
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	/**
	 * @return the plu
	 */
	public String getPlu() {
		return plu;
	}
	/**
	 * @param plu the plu to set
	 */
	public void setPlu(String plu) {
		this.plu = plu;
	}
	/**
	 * @return the supplierName
	 */
	public String getSupplierName() {
		return supplierName;
	}
	/**
	 * @param supplierName the supplierName to set
	 */
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	/**
	 * @return the supplierNum
	 */
	public String getSupplierNum() {
		return supplierNum;
	}
	/**
	 * @param supplierNum the supplierNum to set
	 */
	public void setSupplierNum(String supplierNum) {
		this.supplierNum = supplierNum;
	}
	/**
	 * @return the slu
	 */
	public String getSlu() {
		return slu;
	}
	/**
	 * @param slu the slu to set
	 */
	public void setSlu(String slu) {
		this.slu = slu;
	}
	/**
	 * @return the upc
	 */
	public String getUpc() {
		return upc;
	}
	/**
	 * @param upc the upc to set
	 */
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getProdhierarchyLevel1() {
		return prodhierarchyLevel1;
	}
	public void setProdhierarchyLevel1(String prodhierarchyLevel1) {
		this.prodhierarchyLevel1 = prodhierarchyLevel1;
	}
	public String getProdhierarchyLevel2() {
		return prodhierarchyLevel2;
	}
	public void setProdhierarchyLevel2(String prodhierarchyLevel2) {
		this.prodhierarchyLevel2 = prodhierarchyLevel2;
	}
	public String getProdhierarchyLevel3() {
		return prodhierarchyLevel3;
	}
	public void setProdhierarchyLevel3(String prodhierarchyLevel3) {
		this.prodhierarchyLevel3 = prodhierarchyLevel3;
	}
	public String getSmicGroupCd() {
		return smicGroupCd;
	}
	public void setSmicGroupCd(String smicGroupCd) {
		this.smicGroupCd = smicGroupCd;
	}
	public String getSmicCtgryCd() {
		return smicCtgryCd;
	}
	public void setSmicCtgryCd(String smicCtgryCd) {
		this.smicCtgryCd = smicCtgryCd;
	}
	public String getSmicClassCd() {
		return smicClassCd;
	}
	public void setSmicClassCd(String smicClassCd) {
		this.smicClassCd = smicClassCd;
	}
	public String getSmicSubClassCd() {
		return smicSubClassCd;
	}
	public void setSmicSubClassCd(String smicSubClassCd) {
		this.smicSubClassCd = smicSubClassCd;
	}
	public String getSmicSubSubClassCd() {
		return smicSubSubClassCd;
	}
	public void setSmicSubSubClassCd(String smicSubSubClassCd) {
		this.smicSubSubClassCd = smicSubSubClassCd;
	}
	public boolean isTotalSalesFilter() {
		return totalSalesFilter;
	}
	public void setTotalSalesFilter(boolean totalSalesFilter) {
		this.totalSalesFilter = totalSalesFilter;
	}
	public String getTotalSalesOperator() {
		return totalSalesOperator;
	}
	public void setTotalSalesOperator(String totalSalesOperator) {
		this.totalSalesOperator = totalSalesOperator;
	}
	public String getTotalSalesvalue() {
		return totalSalesvalue;
	}
	public void setTotalSalesvalue(String totalSalesvalue) {
		this.totalSalesvalue = totalSalesvalue;
	}
	public boolean isUsageFilter() {
		return usageFilter;
	}
	public void setUsageFilter(boolean usageFilter) {
		this.usageFilter = usageFilter;
	}
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	public boolean isShipped() {
		return isShipped;
	}
	public void setShipped(boolean isShipped) {
		this.isShipped = isShipped;
	}
	public String getShipSearchValue() {
		return shipSearchValue;
	}
	public void setShipSearchValue(String shipSearchValue) {
		this.shipSearchValue = shipSearchValue;
	}
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}
	public boolean isUsageTypeIndFilter() {
		return usageTypeIndFilter;
	}
	public void setUsageTypeIndFilter(boolean usageTypeIndFilter) {
		this.usageTypeIndFilter = usageTypeIndFilter;
	}
	public String getVendUpcPackInd() {
		return vendUpcPackInd;
	}
	public void setVendUpcPackInd(String vendUpcPackInd) {
		this.vendUpcPackInd = vendUpcPackInd;
	}
	public String getVendUpcCountry() {
		return vendUpcCountry;
	}
	public void setVendUpcCountry(String vendUpcCountry) {
		this.vendUpcCountry = vendUpcCountry;
	}
	public String getVendUpcNumSys() {
		return vendUpcNumSys;
	}
	public void setVendUpcNumSys(String vendUpcNumSys) {
		this.vendUpcNumSys = vendUpcNumSys;
	}
	public String getVendUpcManuf() {
		return vendUpcManuf;
	}
	public void setVendUpcManuf(String vendUpcManuf) {
		this.vendUpcManuf = vendUpcManuf;
	}
	public String getVendUpcItem() {
		return vendUpcItem;
	}
	public void setVendUpcItem(String vendUpcItem) {
		this.vendUpcItem = vendUpcItem;
	}
	public boolean isVendorOrderFilter() {
		return vendorOrderFilter;
	}
	public void setVendorOrderFilter(boolean vendorOrderFilter) {
		this.vendorOrderFilter = vendorOrderFilter;
	}
	
	

}
