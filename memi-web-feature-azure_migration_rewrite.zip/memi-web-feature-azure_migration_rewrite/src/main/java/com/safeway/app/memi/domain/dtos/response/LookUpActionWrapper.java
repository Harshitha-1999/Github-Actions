package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.List;

public class LookUpActionWrapper {
	
	private LookUpSearchInputs searchInputs;
	private List<LookUpActionRequest> actionsRequests;	
	private String updatedByUser;
	public LookUpSearchInputs getSearchInputs() {
		return searchInputs;
	}
	public void setSearchInputs(LookUpSearchInputs searchInputs) {
		this.searchInputs = searchInputs;
	}
	public List<LookUpActionRequest> getActionsRequests() {
		return actionsRequests;
	}
	public void setActionsRequests(List<LookUpActionRequest> actionsRequests) {
		this.actionsRequests = actionsRequests;
	}
	public LookUpSearchResultWrapper getLookUpSearchResultWrapper() {
		return lookUpSearchResultWrapper;
	}
	public void setLookUpSearchResultWrapper(
			LookUpSearchResultWrapper lookUpSearchResultWrapper) {
		this.lookUpSearchResultWrapper = lookUpSearchResultWrapper;
	}
	private LookUpSearchResultWrapper lookUpSearchResultWrapper;
	public String getUpdatedByUser() {
		return updatedByUser;
	}
	public void setUpdatedByUser(String updatedByUser) {
		this.updatedByUser = updatedByUser;
	}

}
