package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

public class MultiUnitSrcTargetDto {
	private List<MultiUnitSourceDto> multiUnitSource;
	private List<MultiUnitTypeTargetDto> multiUnitTarget;
	private String srcMultiUnitFlag;

	public String getSrcMultiUnitFlag() {
		return srcMultiUnitFlag;
	}

	public void setSrcMultiUnitFlag(String srcMultiUnitFlag) {
		this.srcMultiUnitFlag = srcMultiUnitFlag;
	}

	public List<MultiUnitSourceDto> getMultiUnitSource() {
		return multiUnitSource;
	}

	public void setMultiUnitSource(List<MultiUnitSourceDto> multiUnitSource) {
		this.multiUnitSource = multiUnitSource;
	}

	public List<MultiUnitTypeTargetDto> getMultiUnitTarget() {
		return multiUnitTarget;
	}

	public void setMultiUnitTarget(List<MultiUnitTypeTargetDto> multiUnitTarget) {
		this.multiUnitTarget = multiUnitTarget;
	}

	@Override
	public String toString() {
		return "MultiUnitSrcTargetDto [multiUnitSource=" + multiUnitSource
				+ ", multiUnitTarget=" + multiUnitTarget
				+ ", srcMultiUnitFlag=" + srcMultiUnitFlag + "]";
	}

}
