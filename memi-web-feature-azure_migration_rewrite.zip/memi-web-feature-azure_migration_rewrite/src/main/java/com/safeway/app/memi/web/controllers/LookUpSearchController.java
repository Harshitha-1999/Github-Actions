package com.safeway.app.memi.web.controllers;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.safeway.app.memi.domain.dtos.response.LookUpActionWrapper;
import com.safeway.app.memi.domain.dtos.response.LookUpCustomizationVO;
import com.safeway.app.memi.domain.dtos.response.LookUpScreenLoadVO;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchInputs;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultWrapper;
import com.safeway.app.memi.domain.services.LookUpService;
import com.safeway.app.memi.domain.util.LookUpExcelWriter;

@Controller
@RequestMapping("/lookUp")
public class LookUpSearchController {
	
	private static final Logger LOG = LoggerFactory.getLogger(LookUpSearchController.class);
	
	@Autowired
	private LookUpService lookUpService; 
	
	@Autowired
	private LookUpExcelWriter excelWriter;
	
	@Autowired
	ServletContext context;
	
	@RequestMapping(value="/loadScreen/{company}/{division}/{userId}",method=RequestMethod.POST,produces =MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody public LookUpScreenLoadVO loadLookUpScreen(@PathVariable("company") String companyId,@PathVariable("division") String divisionId,@PathVariable("userId") String userId)
	{
		return lookUpService.lookUpScreenLoad(companyId,divisionId,userId);		
	}
	
	@RequestMapping(value="/saveColumnCustomization" ,method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces =MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody public Map saveCustomizedColumns(@RequestBody LookUpCustomizationVO customVO)
	{
		return lookUpService.saveLookUpCostomization(customVO);		
	}
	
	@RequestMapping(value="/loadSearchData", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces =MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody public LookUpSearchResultWrapper loadSearchResults(@RequestBody LookUpSearchInputs searchInput)
	{	
		LOG.info("Execution started for load Search Data");
		List errorList =new ArrayList();
		LookUpSearchResultWrapper serchresults =new LookUpSearchResultWrapper();
		if(searchInput.getCompanyId() ==null || searchInput.getCompanyId().trim().equals(""))
		{
			errorList.add("Please choose company id");
		}
		else if(searchInput.getDivisionId() ==null || searchInput.getDivisionId().trim().equals(""))
		{
			errorList.add("Please choose division id");
		}
		else if(searchInput.getProdHierarchyLvl4Cd() ==null || searchInput.getProdHierarchyLvl4Cd().trim().equals(""))
		{
			errorList.add("Please choose department ");
		}
	
		 if(errorList!=null && !errorList.isEmpty())
		 {
			 serchresults.setErrorList(errorList);
			 LOG.info("Execution completed for load Search Data"); 
			 return serchresults;
			 
		 }
		 else
		 {
			 return lookUpService.fetchLookUpResult(searchInput); 
		 }
		
		 
	}
	@RequestMapping(value="/performButtonAction",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces =MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody public LookUpSearchResultWrapper lookUpStatusChange(@RequestBody LookUpActionWrapper requestWrapper)
	{
		 LOG.info("Execution started for perform Button Action");
		List errors =lookUpService.performStatusChanges(requestWrapper.getActionsRequests(),requestWrapper.getUpdatedByUser());
		
		LookUpSearchResultWrapper searchResultWrapper =lookUpService.fetchLookUpResult(requestWrapper.getSearchInputs()); 
		searchResultWrapper.setErrorList(errors);
		 LOG.info("Execution completed for perform Button Action");
		return searchResultWrapper;
	}
	
	@PostMapping(value="/exportIntoExcel",consumes=MediaType.APPLICATION_JSON_VALUE)
	public void downloadexcelReport(@RequestBody LookUpSearchInputs searchInput,HttpServletRequest request,HttpServletResponse response)
	{
		LOG.info("Downloading Display Item excel sheet : ");
		String dataDirectory = context.getRealPath("/");
		
		searchInput.setStartIndex("1");
		searchInput.setEndIndex("20000");
		LookUpSearchResultWrapper fullResultWrapper=lookUpService.fetchLookUpResult(searchInput);
		String fileName =excelWriter.writeIntoExcel(fullResultWrapper.getSerchResults(),dataDirectory);
		
		Path file = Paths.get(dataDirectory, fileName);
		if (Files.exists(file)) {
			response.setContentType("application/vnd.ms-excel");
			response.addHeader("Content-Disposition", "attachment; filename="
					+ "DownloadExcel.xlsx");
			try {
				Files.copy(file, response.getOutputStream());
				response.getOutputStream().flush();
				try {
					Files.delete(file);
				} catch (NoSuchFileException x) {
					LOG.error("No such file.");
				} catch (DirectoryNotEmptyException x) {
					LOG.error("No such directory.");
				} catch (IOException x) {
					LOG.error(x.getMessage());
				}
			} catch (IOException ex) {
				LOG.error(ex.getMessage());
			}
		}
		LOG.info("Completed Downloading Display Item excel sheet : ");
	}


}
