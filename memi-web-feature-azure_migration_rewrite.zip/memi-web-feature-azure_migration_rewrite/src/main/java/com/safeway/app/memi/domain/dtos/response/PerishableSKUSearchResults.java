/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;


import java.math.BigDecimal;



/**
 ****************************************************************************
 * NAME : PerishableSKUSearchResults 
 * 
 * DESCRIPTION :PerishableSKUSearchResults is the class to store the search data of source item
 * 			    
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */
public class PerishableSKUSearchResults {
	private String sku;
	private String itemDesc;
	private BigDecimal vcf;
	/**
	 * Variable to hold size description
	 */
	private String size;
	private char usage;
	private String display;
	private String productSrc;
	private String [] upc;
	private BigDecimal salesValue;
	private String createdOn;
	private String lastSaledate;
	private BigDecimal ItemNo;
	private String status;
	private String deptName;
	private BigDecimal categNo;
	private String absUPCNo;
	private BigDecimal upcCountry;
	private BigDecimal upcSystem;
	private BigDecimal absUPCManuf;
	private BigDecimal upsSales;
	private String plu;
	private String absDSDWhse;
	private String corpItemCd;
	private String packWhse;
	private String comments;
	private String updateUser;
	private String lastLoad;
	private String ethnicCode;
	private String mappingStatus;
	private String mappingtype;
	private BigDecimal sizeNumber;
	private BigDecimal totalSales;
	private BigDecimal packNum;
	private String lastShipdate;
	private BigDecimal onHand;
	private BigDecimal onOrder;
	private String usage_Modification_Status;
	
	private String supplierNam;
	private String supplierNm;
	
	private String shippedDetail;
	private String caseUpc;
	private String sizeUomCd;
	private String sellingMethodCd;
	private String recievingRandomInd;
	
	
	public String getHierarchyLevelOne() {
		return hierarchyLevelOne;
	}
	public void setHierarchyLevelOne(String hierarchyLevelOne) {
		this.hierarchyLevelOne = hierarchyLevelOne;
	}
	public String getHierarchyLevelTwo() {
		return hierarchyLevelTwo;
	}
	public void setHierarchyLevelTwo(String hierarchyLevelTwo) {
		this.hierarchyLevelTwo = hierarchyLevelTwo;
	}
	public String getHierarchyLevelThree() {
		return hierarchyLevelThree;
	}
	public void setHierarchyLevelThree(String hierarchyLevelThree) {
		this.hierarchyLevelThree = hierarchyLevelThree;
	}
	private String slot;
	private String hierarchyLevelOne;
	private String hierarchyLevelTwo;
	private String hierarchyLevelThree;
	public String getLastShipdate() {
		return lastShipdate;
	}
	public void setLastShipdate(String lastShipdate) {
		this.lastShipdate = lastShipdate;
	}
	public BigDecimal getOnHand() {
		return onHand;
	}
	public void setOnHand(BigDecimal onHand) {
		this.onHand = onHand;
	}
	public BigDecimal getOnOrder() {
		return onOrder;
	}
	public void setOnOrder(BigDecimal onOrder) {
		this.onOrder = onOrder;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}	
	/**
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}
	/**
	 * @param sku the sku to set
	 */
	public void setSku(String sku) {
		this.sku = sku;
	}
	/**
	 * @return the itemDesc
	 */
	public String getItemDesc() {
		return itemDesc;
	}
	/**
	 * @param itemDesc the itemDesc to set
	 */
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	/**
	 * @return the vcf
	 */
	public BigDecimal getVcf() {
		return vcf;
	}
	/**
	 * @param vcf the vcf to set
	 */
	public void setVcf(BigDecimal vcf) {
		this.vcf = vcf;
	}
	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}
	
	/**
	 * @return the display
	 */
	public String getDisplay() {
		return display;
	}
	/**
	 * @param c the display to set
	 */
	public void setDisplay(String c) {
		this.display = c;
	}

	/**
	 * @return the productSrc
	 */
	public String getProductSrc() {
		return productSrc;
	}
	/**
	 * @param productSrc the productSrc to set
	 */
	public void setProductSrc(String productSrc) {
		this.productSrc = productSrc;
	}
		
	/**
	 * @return the salesValue
	 */
	public BigDecimal getSalesValue() {
		return salesValue;
	}
	/**
	 * @param salesValue the salesValue to set
	 */
	public void setSalesValue(BigDecimal salesValue) {
		this.salesValue = salesValue;
	}
	/**
	 * @return the createdOn
	 */
	
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getLastSaledate() {
		return lastSaledate;
	}
	public void setLastSaledate(String lastShipdate) {
		this.lastSaledate = lastShipdate;
	}
	/**
	 * @param absDivisionNo the absDivisionNo to set
	 */
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the deptName
	 */
	public String getDeptName() {
		return deptName;
	}
	/**
	 * @param deptName the deptName to set
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	/**
	 * @return the upcCountry
	 */
	public BigDecimal getUpcCountry() {
		return upcCountry;
	}
	/**
	 * @param upcCountry the upcCountry to set
	 */
	public void setUpcCountry(BigDecimal upcCountry) {
		this.upcCountry = upcCountry;
	}
	/**
	 * @return the absUPCManuf
	 */
	public BigDecimal getAbsUPCManuf() {
		return absUPCManuf;
	}
	/**
	 * @param absUPCManuf the absUPCManuf to set
	 */
	public void setAbsUPCManuf(BigDecimal absUPCManuf) {
		this.absUPCManuf = absUPCManuf;
	}
	/**
	 * @return the upsSales
	 */
	public BigDecimal getUpsSales() {
		return upsSales;
	}
	/**
	 * @param upsSales the upsSales to set
	 */
	public void setUpsSales(BigDecimal upsSales) {
		this.upsSales = upsSales;
	}
	/**
	 * @return the plu
	 */
	public String getPlu() {
		return plu;
	}
	/**
	 * @param plu the plu to set
	 */
	public void setPlu(String plu) {
		this.plu = plu;
	}
	/**
	 * @return the absDSDWhse
	 */
	public String getAbsDSDWhse() {
		return absDSDWhse;
	}
	/**
	 * @param absDSDWhse the absDSDWhse to set
	 */
	public void setAbsDSDWhse(String absDSDWhse) {
		this.absDSDWhse = absDSDWhse;
	}
	/**
	 * @return the corpItemCd
	 */
	public String getCorpItemCd() {
		return corpItemCd;
	}
	/**
	 * @param corpItemCd the corpItemCd to set
	 */
	public void setCorpItemCd(String corpItemCd) {
		this.corpItemCd = corpItemCd;
	}
	/**
	 * @return the packWhse
	 */
	public String getPackWhse() {
		return packWhse;
	}
	/**
	 * @param packWhse the packWhse to set
	 */
	public void setPackWhse(String packWhse) {
		this.packWhse = packWhse;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the updateUser
	 */
	public String getUpdateUser() {
		return updateUser;
	}
	/**
	 * @param updateUser the updateUser to set
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * @return the lastLoad
	 */
	public String getLastLoad() {
		return lastLoad;
	}
	/**
	 * @param lastLoad the lastLoad to set
	 */
	public void setLastLoad(String lastLoad) {
		this.lastLoad = lastLoad;
	}
	/**
	 * @return the ethnicCode
	 */
	public String getEthnicCode() {
		return ethnicCode;
	}
	/**
	 * @param ethnicCode the ethnicCode to set
	 */
	public void setEthnicCode(String ethnicCode) {
		this.ethnicCode = ethnicCode;
	}
	/**
	 * @return the mappingStatus
	 */
	public String getMappingStatus() {
		return mappingStatus;
	}
	/**
	 * @param mappingStatus the mappingStatus to set
	 */
	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}
	public BigDecimal getUpcSystem() {
		return upcSystem;
	}
	public void setUpcSystem(BigDecimal upcSystem) {
		this.upcSystem = upcSystem;
	}
	public BigDecimal getItemNo() {
		return ItemNo;
	}
	public void setItemNo(BigDecimal itemNo) {
		ItemNo = itemNo;
	}
	public BigDecimal getCategNo() {
		return categNo;
	}
	public void setCategNo(BigDecimal categNo) {
		this.categNo = categNo;
	}
	public String getAbsUPCNo() {
		return absUPCNo;
	}
	public void setAbsUPCNo(String absUPCNo) {
		this.absUPCNo = absUPCNo;
	}
	public String [] getUpc() {
		return upc;
	}
	public void setUpc(String [] upc) {
		this.upc = upc;
	}
	public String getMappingtype() {
		return mappingtype;
	}
	public void setMappingtype(String mappingtype) {
		this.mappingtype = mappingtype;
	}
	public BigDecimal getSizeNumber() {
		return sizeNumber;
	}
	public void setSizeNumber(BigDecimal sizeNumber) {
		this.sizeNumber = sizeNumber;
	}
	public BigDecimal getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(BigDecimal totalSales) {
		this.totalSales = totalSales;
	}
	public BigDecimal getPackNum() {
		return packNum;
	}
	public void setPackNum(BigDecimal packNum) {
		this.packNum = packNum;
	}
	/**
	 * @return the usage
	 */
	public char getUsage() {
		return usage;
	}
	/**
	 * @param usage the usage to set
	 */
	public void setUsage(char usage) {
		this.usage = usage;
	}
	public String getUsage_Modification_Status() {
		return usage_Modification_Status;
	}
	public void setUsage_Modification_Status(String usage_Modification_Status) {
		this.usage_Modification_Status = usage_Modification_Status;
	}
	public String getSupplierNam() {
		return supplierNam;
	}
	public void setSupplierNam(String supplierNam) {
		this.supplierNam = supplierNam;
	}
	public String getSupplierNm() {
		return supplierNm;
	}
	public void setSupplierNm(String supplierNm) {
		this.supplierNm = supplierNm;
	}
	public String getShippedDetail() {
		return shippedDetail;
	}
	public void setShippedDetail(String shippedDetail) {
		this.shippedDetail = shippedDetail;
	}
	public String getCaseUpc() {
		return caseUpc;
	}
	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}
	public String getSizeUomCd() {
		return sizeUomCd;
	}
	public void setSizeUomCd(String sizeUomCd) {
		this.sizeUomCd = sizeUomCd;
	}
	public String getSellingMethodCd() {
		return sellingMethodCd;
	}
	public void setSellingMethodCd(String sellingMethodCd) {
		this.sellingMethodCd = sellingMethodCd;
	}
	public String getRecievingRandomInd() {
		return recievingRandomInd;
	}
	public void setRecievingRandomInd(String recievingRandomInd) {
		this.recievingRandomInd = recievingRandomInd;
	}
	
}
