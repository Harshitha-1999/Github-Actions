package com.safeway.app.memi.domain.dtos.response;

/* ***************************************************************************
 * NAME : SMICDetailDto 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Safeway IT 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 30, 2017 - Initial Creation
 * ************************************************************************/

import java.io.Serializable;

public class SMICDetailDto implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String grpCode;

    private String ctgryCode;

    private String subClsCode;

    private String subSubClass;

    private String SMICDesc;

	public String getGrpCode() {
		return grpCode;
	}

	public void setGrpCode(String grpCode) {
		this.grpCode = grpCode;
	}

	public String getCtgryCode() {
		return ctgryCode;
	}

	public void setCtgryCode(String ctgryCode) {
		this.ctgryCode = ctgryCode;
	}

	public String getSubClsCode() {
		return subClsCode;
	}

	public void setSubClsCode(String subClsCode) {
		this.subClsCode = subClsCode;
	}

	public String getSubSubClass() {
		return subSubClass;
	}

	public void setSubSubClass(String subSubClass) {
		this.subSubClass = subSubClass;
	}

	public String getSMICDesc() {
		return SMICDesc;
	}

	public void setSMICDesc(String sMICDesc) {
		SMICDesc = sMICDesc;
	}


}
