/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.data.repositories;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;

/**
 ****************************************************************************
 * NAME			: PerishableSQLRepository 
 * 
 * DESCRIPTION	: PerishableSQLRepository is the repository class for performing 
 * 				  perishable DB operations
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 05, 2018  - Initial Creation
 * Revision 0.0.0.2 Feb 08, 2018  - Added target search query
 * *************************************************************************
 */

/**
 * Repository class for perishable DB operations
 */
@Repository
@SuppressWarnings("unchecked")
public class PerishableSQLRepository{

	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;
	@Value("${spring.datasource.hikari.schema}")
	private String defaultSchema;

	private static final Logger LOG = LoggerFactory.getLogger(PerishableSQLRepository.class);
	
	
	
	
   
    public  List<Object[]> fetchPerishablesSourceList(Map<String,String> searchCriteria,Map<String,String> filterCriteria)
    {
    	StringBuilder baseQuery=new StringBuilder("");
    	Map<String, Object> queryParameters = new HashMap<>();
    	List<Object[]> newresults=null;
    	Integer companyId =Integer.valueOf(0);
    	Integer divisionId =Integer.valueOf(0);
		if (searchCriteria != null && searchCriteria.size() > 0) {
			if (searchCriteria.containsKey(PerishableSQLConstants.COMPANY_ID)) {
				companyId =Integer.valueOf(searchCriteria.get(PerishableSQLConstants.COMPANY_ID));
			}
			if (searchCriteria.containsKey(PerishableSQLConstants.DIVISION_ID_SMALL_CASE)) {
				divisionId = Integer.valueOf(searchCriteria.get(PerishableSQLConstants.DIVISION_ID_SMALL_CASE));
			}
		}
		baseQuery.append(" SELECT     TMP1.* FROM (  SELECT TMP.* FROM  ( ");
		baseQuery.append("SELECT "+
					"PRODUCT_SKU " + 
					",ITEM_DESC " + 
					",SIZE_DESC " + 
					",NULL AS 'NULL' " + 
					",MULTI_COMP_ITEM_IND " + 
					",WHSE_DSD " + 
					",PROD_HIERARCHY_LVL_4_CD " + 
					",LAST_UPD_USR_ID " + 
					",VCF " + 
					",MATCHING_STATUS_CD " + 
					",SIZE_NBR " + 
					",ITEM_SETUP_DT " + 
					",SHIPPING_PACK_NBR " + 
					",USAGE1 " + 
					",PROD_HIERARCHY_LVL_1_NM " + 
					",PROD_HIERARCHY_LVL_2_NM " + 
					",PROD_HIERARCHY_LVL_3_NM " + 
					",LAST_SHIP_DT " + 
					",ON_HAND " + 
					",ON_ORDER_QTY " + 
					",SLOT " + 
					",MOD_STATUS " + 
					",VENDOR_ID " + 
					",VENDOR_NM " + 
					",CASE_UPC " + 
					",SIZE_UOM_CD " + 
					",'SELLING_METHOD_CD' AS SELLING_METHOD_CD " + 
					",'RECIEVE_METHOD_CD' AS RECIEVE_METHOD_CD " + 
					", ROW_NUMBER() OVER(ORDER BY PRODUCT_SKU ASC) AS RNUM FROM (");
    	
			baseQuery.append( " SELECT /*+ PARALLEL(4) FIRST_ROWS(1000) */ DISTINCT "
    			          + " c.product_sku,c.item_desc,c.size_desc,"
    			          + " null AS DUMMY,"
    			          + " C.MULTI_COMP_ITEM_IND, case when C.SOURCE_BY_WHSE ='Y' then 'WHSE' when C.SOURCE_BY_DSD ='Y' then 'DSD' end \"WHSE_DSD\" ,"
    			          + " C.PROD_HIERARCHY_LVL_4_CD,"
    			          + " C.LAST_UPD_USR_ID, "
    			          + " (C.MASTER_CASE_PACK_NBR / NULLIF(C.SHIPPING_PACK_NBR,0)) AS VCF ,"
						  + " case when X.CONV_STATUS_CD ='D'   then 'MARK_AS_DEAD' ELSE  P.MATCHING_STATUS_CD  end \"MATCHING_STATUS_CD\", "
    			          + " C.SIZE_NBR,C.ITEM_SETUP_DT,"
    			          + "C.SHIPPING_PACK_NBR,"
    			          +" CASE WHEN C.EXPENSE_ITEM_IND ='N' AND C.MATERIAL_ITEM_IND ='N' AND (C.STORE_CREATED_ITEM_IND='N' OR C.COUPON_IND ='N' )  THEN 'R' "           
                          +" WHEN C.EXPENSE_ITEM_IND ='Y' THEN 'E'"
                          +" WHEN C.MATERIAL_ITEM_IND ='Y' THEN 'M' END \"USAGE1\"," 
                          +" PH1.HIERARCHY_LEVEL_DESC PROD_HIERARCHY_LVL_1_NM, "
                          +" PH2.HIERARCHY_LEVEL_DESC PROD_HIERARCHY_LVL_2_NM, "
                          +" PH3.HIERARCHY_LEVEL_DESC PROD_HIERARCHY_LVL_3_NM, "
                          +" SD.LAST_SHIP_DT,SD.ON_HAND,SD.ON_ORDER_QTY,SD.SLOT, "   
                          +" case  when ITR.COLUMN_NAME_ITM_DSC_TXT is null then 'ORIGINAL'    else 'MODIFIED' end \"MOD_STATUS\" ,"
                          +"  Case when C.SOURCE_BY_WHSE  ='Y' then  WVX.VENDOR_ID collate Latin1_General_CS_AS" 
                          +"  when C.SOURCE_BY_DSD  ='Y' then DVX.VENDOR_ID collate Latin1_General_CS_AS end \"VENDOR_ID\", "
                       
                          +"  Case when C.SOURCE_BY_WHSE  ='Y' then  WVX.VENDOR_NM " 
                          +"  when C.SOURCE_BY_DSD  ='Y' then DVX.VENDOR_NM end \"VENDOR_NM\", "
                          + "C.CASE_UPC ,C.SIZE_UOM_CD "
    			          + " FROM  ECFLAND.ITEM_AGGREGATE_CORP  C "
                          +" JOIN XREFLAND.SRC_ITEM_XRF X "
                          +" ON  C.COMPANY_ID = X.COMPANY_ID "
                          +" AND C.DIVISION_ID = X.DIVISION_ID "
                          +" AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU "
                          +" and C.UPC= X.SRC_UPC  "
						  +" AND X.CONV_STATUS_CD NOT IN('O','C')  "	
                        
						  +" LEFT JOIN "
						  +"(SELECT COMPANY_ID,DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD,PROD_HIERARCHY_LVL_3_CD, HIERARCHY_LEVEL_DESC "
						  +" FROM ECFLAND.PRODUCT_HIERARCHY "
						  +" WHERE COMPANY_ID = :companyId " 
						  +" AND DIVISION_ID   = :divisionId "
						  + "AND HIERARCHY_LEVEL_NM = 'CATGRY_NUM' "                           
						  +" GROUP BY "
						  + "COMPANY_ID, DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,"
				          +"PROD_HIERARCHY_LVL_2_CD,PROD_HIERARCHY_LVL_3_CD,HIERARCHY_LEVEL_DESC)PH1 "
						  +"ON C.COMPANY_ID = PH1.COMPANY_ID "
						  +"AND C.DIVISION_ID  = PH1.DIVISION_ID "
						  +"AND C.PROD_HIERARCHY_LVL_1_CD = PH1.PROD_HIERARCHY_LVL_1_CD "
						  +"AND PH1.PROD_HIERARCHY_LVL_2_CD = '000' "
						  +"AND PH1.PROD_HIERARCHY_LVL_3_CD = '000' "                      
					        					  
						  +" LEFT JOIN "
						  +"(SELECT COMPANY_ID,"
						  +" DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD,PROD_HIERARCHY_LVL_3_CD, "
						  +" HIERARCHY_LEVEL_DESC "
						  +" FROM "
						  +" ECFLAND.PRODUCT_HIERARCHY "
						  +" WHERE COMPANY_ID = :companyId " 
						  +" AND DIVISION_ID = :divisionId "
						  +" AND HIERARCHY_LEVEL_NM = 'SUB_CATGRY_NUM' " 
						  +" GROUP BY "
						  +" COMPANY_ID,DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD, "
						  +" PROD_HIERARCHY_LVL_3_CD,HIERARCHY_LEVEL_DESC)PH2 "
						  +" ON C.COMPANY_ID  = PH2.COMPANY_ID "
						  +" AND C.DIVISION_ID = PH2.DIVISION_ID "
						  +" AND C.PROD_HIERARCHY_LVL_1_CD = PH2.PROD_HIERARCHY_LVL_1_CD "
						  +" AND C.PROD_HIERARCHY_LVL_2_CD = PH2.PROD_HIERARCHY_LVL_2_CD "
						  +" AND PH2.PROD_HIERARCHY_LVL_3_CD = '000' "   					  
						      					  
						  +" LEFT JOIN"
						  + "(SELECT COMPANY_ID,"
						  + "DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD,PROD_HIERARCHY_LVL_3_CD,"
						  + "HIERARCHY_LEVEL_DESC "
						  + "FROM "
						  + "ECFLAND.PRODUCT_HIERARCHY "
						  + "WHERE COMPANY_ID  = :companyId " 
						  + "AND DIVISION_ID = :divisionId "
						  + "AND HIERARCHY_LEVEL_NM = 'GRP_ID' " 
						  
						  +"GROUP BY "
						  + "COMPANY_ID, DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD,"
						  + "PROD_HIERARCHY_LVL_3_CD,HIERARCHY_LEVEL_DESC)PH3 "
						  +	"ON C.COMPANY_ID= PH3.COMPANY_ID "
						  +	"AND C.DIVISION_ID = PH3.DIVISION_ID "
						  +	"AND C.PROD_HIERARCHY_LVL_1_CD = PH3.PROD_HIERARCHY_LVL_1_CD "
						  + "AND C.PROD_HIERARCHY_LVL_2_CD = PH3.PROD_HIERARCHY_LVL_2_CD "
						  + "AND C.PROD_HIERARCHY_LVL_3_CD = PH3.PROD_HIERARCHY_LVL_3_CD"
					       
    					  + " LEFT  JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD "
    				      + " ON C.COMPANY_ID = SD.COMPANY_ID  "
    		              + " AND C.DIVISION_ID = SD.DIVISION_ID  "
    		              + " AND C.PRODUCT_SKU = SD.PRODUCT_SKU"
    		              + " AND C.UPC = SD.UPC "
    		              
    		              + " LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU "
    		              + " ON C.COMPANY_ID = MU.COMPANY_ID "
    		              + " AND C.DIVISION_ID = MU.DIVISION_ID "
    		              + " AND C.PRODUCT_SKU = MU.PRODUCT_SKU "
    		              + " AND C.UPC =  MU.SRC_UPC "    		              
    		            
    		              /*te vendor id and vendor name**/
 				
                          + "LEFT JOIN "
                          + " XREFLAND.DSD_VENDOR_XREF DVX " 
                          + "ON X.COMPANY_ID      = DVX.COMPANY_ID "  
                          + "AND X.DIVISION_ID    = DVX.DIVISION_ID  " 
                          + "AND X.SRC_SUPPLIER_NUM     collate Latin1_General_CS_AS  = DVX.VENDOR_ID "                                                                 
             
                          + "LEFT JOIN "
                          + "XREFLAND.WHSE_VENDOR_XREF WVX "  
                          + "ON X.COMPANY_ID      = WVX.COMPANY_ID "  
                          + "AND X.DIVISION_ID    = WVX.DIVISION_ID  " 
                          + "AND X.SRC_SUPPLIER_NUM  collate Latin1_General_CS_AS = WVX.VENDOR_ID  "
                          /** vendor id end***/
    		            
   		                  + " LEFT OUTER JOIN  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P"  
		                  + " ON C.COMPANY_ID = P.COMPANY_ID "  
		                  + " AND C.DIVISION_ID = P.DIVISION_ID "  
		                  + " AND C.UPC = P.UPC "
		                  + " AND C.PRODUCT_SKU = P.PRODUCT_SKU "
		                  
 						  +" LEFT JOIN ECFLAND.item_conv_Src_Data_replace ITR "
 						  +" ON C.COMPANY_ID = ITR.COMPANY_ID  "
 						  +" AND C.DIVISION_ID = ITR.DIVISION_ID " 
 						  +" AND C.PRODUCT_SKU = ITR.PRODUCT_SKU " 
 						  +" AND ITR.COLUMN_NAME_ITM_DSC_TXT in ('EXPENSE_ITEM_IND','MATERIAL_ITEM_IND') " 
		                  
 		                  + " WHERE "
		                  + " C.MULTI_COMP_ITEM_IND <> 'Y' "
 		                  + " AND ( MU.PRODUCT_SKU IS NULL or(MU.PRODUCT_SKU IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) ") ;
		String searchcriteria = createBaseSearchQuery(searchCriteria,queryParameters);
		String filtercriteria = createfilterQuery(filterCriteria,queryParameters);
		
		baseQuery.append(searchcriteria + filtercriteria + ") AS INNER_QUERY");
		
		String baseQueryWrapper = " GROUP BY PRODUCT_SKU,ITEM_DESC,SIZE_DESC,MULTI_COMP_ITEM_IND,WHSE_DSD,"
				+ "PROD_HIERARCHY_LVL_4_CD,LAST_UPD_USR_ID,VCF,MATCHING_STATUS_CD,SIZE_NBR,"
				+ "ITEM_SETUP_DT,SHIPPING_PACK_NBR,USAGE1,PROD_HIERARCHY_LVL_1_NM,"
				+ "PROD_HIERARCHY_LVL_2_NM,PROD_HIERARCHY_LVL_3_NM,"
				+ "LAST_SHIP_DT,ON_HAND,ON_ORDER_QTY,SLOT,MOD_STATUS,VENDOR_ID ,VENDOR_NM,CASE_UPC,SIZE_UOM_CD  ";
		
		baseQuery.append( baseQueryWrapper);
		/* Custom order by changes*/
		
		baseQuery.append( " )  TMP )TMP1  where TMP1.rnum >= :startIndex  and   TMP1.rnum <= :endIndex "); 
		
		/*baseQuery.append(" ORDER BY " ); 
		if(searchCriteria != null) {
			baseQuery.append(searchCriteria.get("sortColumns") );
			baseQuery.append(searchCriteria.get("sortOrder") );
		}*/
		/****/
    	
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		if(searchCriteria != null) {
			q.setParameter("startIndex", searchCriteria.get("startIndex"));
			q.setParameter("endIndex", searchCriteria.get("endIndex"));
		}
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		
		for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		
		List<Object[]> results = q.getResultList();	    
		
		em.close();
		if (null != searchCriteria) {
			newresults = getUpcAggregateList(results, searchCriteria.get(PerishableSQLConstants.COMPANY_ID),
					searchCriteria.get(PerishableSQLConstants.DIVISION_ID_SMALL_CASE),
					searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS),
					searchCriteria.get(PerishableSQLConstants.ITEM_TYPE));
			
			
		}
		
		return newresults;
    	
    }

	private String createfilterQuery(Map<String, String> filterCriteria, Map<String, Object> queryParameters) {
		
		StringBuilder queryFilter=new StringBuilder("");
		if(null!=filterCriteria.keySet() && ! filterCriteria.keySet().isEmpty() ){
			if(filterCriteria.containsKey(PerishableSQLConstants.DEPARTMENT)){
				queryFilter.append("AND upper( C.PROD_HIERARCHY_LVL_4_CD ) = upper ( :"+PerishableSQLConstants.DEPARTMENT+" )");
				queryParameters.put(PerishableSQLConstants.DEPARTMENT, filterCriteria.get(PerishableSQLConstants.DEPARTMENT));
			}
			if(filterCriteria.containsKey("divisionNum")){
				queryFilter.append(" AND cast(C.DIVISION_ID as numeric)= "+ ":divisionNum ");
				queryParameters.put("divisionNum", filterCriteria.get("divisionNum"));
				}
			
			if(filterCriteria.containsKey(PerishableSQLConstants.ITEM_DESCRIPTION)){
	               queryFilter.append(" AND C.ITEM_DESC  like UPPER" + "(:");
	               queryFilter.append(PerishableSQLConstants.ITEM_DESCRIPTION );
	               queryFilter.append( ")" );
					queryParameters.put(PerishableSQLConstants.ITEM_DESCRIPTION, "%" + filterCriteria.get(PerishableSQLConstants.ITEM_DESCRIPTION).replaceAll("'", "''") + "%");
			        
				}
			if(filterCriteria.containsKey("productSKU")){
				queryFilter.append(" AND C.PRODUCT_SKU= :productSKU ");
				queryParameters.put("productSKU", filterCriteria.get("productSKU"));
			}
			if(filterCriteria.containsKey(PerishableSQLConstants.PLU)){
				queryFilter.append(" AND  X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND  X.SRC_UPC_SALES  = :");
				queryFilter.append(PerishableSQLConstants.PLU);
				queryParameters.put(PerishableSQLConstants.PLU, filterCriteria.get(PerishableSQLConstants.PLU));
			}
			if(filterCriteria.containsKey("supplierName")){
				//queryFilter.append(" AND upper(SD.SRC_SUPPLIER_NM)= '"+filterCriteria.get("supplierName")+"'");
				queryFilter.append("  AND ( trim( upper(WVX.VENDOR_NM)) =  :supplierName ");
				queryFilter.append(" OR trim( upper(DVX.VENDOR_NM)) = :supplierName)");
				queryParameters.put("supplierName", filterCriteria.get("supplierName"));
			}
			if(filterCriteria.containsKey("supplierNum")){
				//queryFilter.append(" AND upper(X.SRC_SUPPLIER_NUM)= '"+filterCriteria.get("supplierNum")+ "'");
				queryFilter.append("  AND ( upper(WVX.VENDOR_ID) =  :supplierNum ");
				queryFilter.append(" OR  upper(DVX.VENDOR_ID) = :supplierNum ) ");
				queryParameters.put("supplierName", filterCriteria.get("supplierName"));
				 
			}
			buildCriteriaForSLUAndUPC(filterCriteria, queryFilter, queryParameters);
			if (filterCriteria.containsKey("prodhierarchyLevel1")) {
				queryFilter.append(" AND C.PROD_HIERARCHY_LVL_1_CD = :prodhierarchyLevel1 " );
				queryParameters.put("prodhierarchyLevel1", filterCriteria.get("prodhierarchyLevel1"));
			}
			if (filterCriteria.containsKey("prodhierarchyLevel2")) {
				queryFilter.append(" AND C.PROD_HIERARCHY_LVL_2_CD = :prodhierarchyLevel2 " );
				queryParameters.put("prodhierarchyLevel2", filterCriteria.get("prodhierarchyLevel2"));
			}
			if (filterCriteria.containsKey("prodhierarchyLevel3")) {
				queryFilter	.append(" AND C.PROD_HIERARCHY_LVL_3_CD = :prodhierarchyLevel3 " );
				queryParameters.put("prodhierarchyLevel3", filterCriteria.get("prodhierarchyLevel3"));
			}
			buildCriteriaForExpensSearch(filterCriteria, queryFilter, queryParameters);
		}
		return queryFilter.toString();
	}
	private void buildCriteriaForExpensSearch(Map<String, String> filterCriteria, StringBuilder queryFilter, Map<String,Object> queryParameters) {
		if(filterCriteria.containsKey("expenseType"))
		{
			if(filterCriteria.get("expenseType").equals("R"))
			{
				queryFilter.append(" AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
			}
			else if(filterCriteria.get("expenseType").equals("E"))
			{ 
				queryFilter.append(" AND ( C.EXPENSE_ITEM_IND = 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
			}
			else if(filterCriteria.get("expenseType").equals("M"))
			{
				queryFilter.append(" AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND = 'Y' AND C.COUPON_IND <> 'Y' ) ");
			}
		}	
		
		 if(filterCriteria.containsKey("TOTAL_SALES_SEARCH_VALUE")){
		    	queryFilter.append(" AND SD.TOTAL_SALES ");
		    	if(null!=filterCriteria.get("TOTAL_SALES_OPERATOR")){
		    	if(filterCriteria.get("TOTAL_SALES_OPERATOR").equals("GREATER_THAN")){
		    		queryFilter.append(">");
		    	}else if(filterCriteria.get("TOTAL_SALES_OPERATOR").equals("LESS_THAN")){
		    		queryFilter.append("<");	
		    	}else if(filterCriteria.get("TOTAL_SALES_OPERATOR").equals("EQUALS")){
		    		queryFilter.append("=");	
		    	 }
		    	}
		    	queryFilter.append(" :TOTAL_SALES_SEARCH_VALUE").append("  ");
		    	queryParameters.put("TOTAL_SALES_SEARCH_VALUE", filterCriteria.get("TOTAL_SALES_SEARCH_VALUE"));
		}
		if(filterCriteria.containsKey("shipmentSearch"))
		{
			if(filterCriteria.get("shipmentSearch").equals("Y"))
			{
				queryFilter.append(" AND SD.LAST_SHIP_DT is NOT NULL ");
			}
			if(filterCriteria.get("shipmentSearch").equals("N"))
			{
				queryFilter.append(" AND SD.LAST_SHIP_DT is  NULL ");
			}
		}
	}
	/**
	 * @param filterCriteria
	 * @param queryFilter
	 */
	private void buildCriteriaForSLUAndUPC(Map filterCriteria,StringBuilder queryFilter, Map<String, Object> queryParameters) {
		if(filterCriteria.containsKey(PerishableSQLConstants.SLU)){
			if(PerishableSQLConstants.SYSTEM2.equals(filterCriteria.get(PerishableSQLConstants.ITEM_TYPE))){
				queryFilter.append(" AND X.SRC_UPC_COUNTRY=0 AND X.SRC_UPC_SALES=0 AND X.SRC_UPC_MANUF= :");
				queryFilter.append(PerishableSQLConstants.SLU);
				queryParameters.put(PerishableSQLConstants.SLU, filterCriteria.get(PerishableSQLConstants.SLU));
			}else if("System0".equals(filterCriteria.get(PerishableSQLConstants.ITEM_TYPE))){
				queryFilter.append(" AND X.SRC_UPC_MANUF=41144 AND X.SRC_UPC_SALES= :");
				queryFilter.append(PerishableSQLConstants.SLU);
				queryParameters.put(PerishableSQLConstants.SLU, filterCriteria.get(PerishableSQLConstants.SLU));
			}else if("All".equals(filterCriteria.get(PerishableSQLConstants.ITEM_TYPE))){
				queryFilter.append(" AND((X.SRC_UPC_SYSTEM=2 AND X.SRC_UPC_COUNTRY=0 AND X.SRC_UPC_SALES=0 AND X.SRC_UPC_MANUF= :");
				queryFilter.append(PerishableSQLConstants.SLU+")");
				queryFilter.append(" OR(X.SRC_UPC_SYSTEM=0 AND X.SRC_UPC_MANUF=41144 AND X.SRC_UPC_SALES= :");
				queryFilter.append(PerishableSQLConstants.SLU+"))");
				queryParameters.put(PerishableSQLConstants.SLU, filterCriteria.get(PerishableSQLConstants.SLU));
			}
		}
		if(filterCriteria.containsKey(PerishableSQLConstants.UPC)){
			Float upcVal =  Float.parseFloat((String) filterCriteria.get("upc"));
			if(upcVal< 100000 ){
				queryFilter.append(" AND C.UPC like :C.UPC");	
				queryParameters.put("C.UPC", "%0000000"+filterCriteria.get("upc"));
			}else{
				queryFilter.append(" AND C.UPC= :C.UPC");		
				queryParameters.put("C.UPC", filterCriteria.get("upc"));
			}
			
		}
 	 }

	private String createBaseSearchQuery(Map searchCriteria, Map<String, Object> queryParameters) {
		
		StringBuilder queryFilter=new StringBuilder("");
		if(searchCriteria!=null && searchCriteria.size()>0)
		{
			if(searchCriteria.containsKey(PerishableSQLConstants.COMPANY_ID))
			  { 
				queryFilter.append(" AND cast(C.COMPANY_ID  as numeric)= :");
			    queryFilter.append(PerishableSQLConstants.COMPANY_ID);
			    queryParameters.put(PerishableSQLConstants.COMPANY_ID, searchCriteria.get(PerishableSQLConstants.COMPANY_ID));
			  }
		    
			if(searchCriteria.containsKey(PerishableSQLConstants.DIVISION_ID_SMALL_CASE))
			  {
				queryFilter.append(" AND cast(C.DIVISION_ID  as numeric)= :");
			    queryFilter.append(PerishableSQLConstants.DIVISION_ID_SMALL_CASE);
			    queryParameters.put(PerishableSQLConstants.DIVISION_ID_SMALL_CASE, searchCriteria.get(PerishableSQLConstants.DIVISION_ID_SMALL_CASE));
			  }
			if(searchCriteria.containsKey(PerishableSQLConstants.MAPPING_STATUS))
			  {
				 if(!(PerishableSQLConstants.MARK_AS_DEAD.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS)) ||
			    		PerishableSQLConstants.SHOW_ALL.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS)))){
			    	queryFilter.append(" AND X.CONV_STATUS_CD NOT IN('D') ");
				 }
				
			    if(PerishableSQLConstants.TO_BE_MAPPED.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	queryFilter.append(PerishableSQLConstants.AND_P_MACHING_STATUS_CD);
			    	queryFilter.append(PerishableSQLConstants.IS_NULL);	
			    	queryFilter.append(" OR P.MATCHING_STATUS_CD ='UN_MAPPED' ");
			    	queryFilter.append("  ) ");
			    	
			    }else if(PerishableSQLConstants.MARK_AS_DEAD.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	queryFilter.append(" AND X.CONV_STATUS_CD IN('D') ");
			    	queryFilter.append("AND (P.MATCHING_STATUS_CD = 'MARK_AS_DEAD')");
			    }
			    else if(PerishableSQLConstants.SHOW_ALL.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	queryFilter.append("  AND ( P.MATCHED_ITEM_TYPE_CD in('Y','E','P')  or P.MATCHED_ITEM_TYPE_CD IS NULL ) ");
			    	queryFilter.append(" AND (P.MATCHING_STATUS_CD IS  NULL OR  P.MATCHING_STATUS_CD NOT IN ( 'CORRECTED') ) ");
			    				    	
			    }
			    else if(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS).equals("MAPPED"))
			    {

			    	queryFilter.append(" AND P.MATCHING_STATUS_CD");
			    	queryFilter.append(" = :"+PerishableSQLConstants.MAPPING_STATUS);
			    	queryFilter.append(" AND P.MATCHED_ITEM_TYPE_CD in ('Y','E','P') ");
			    	queryFilter.append(" AND X.CONV_STATUS_CD  IN('R','S','Q','A' ) ");
				    queryParameters.put(PerishableSQLConstants.MAPPING_STATUS, searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS));
			    	
			    
			    }
			    else if(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS).equals(PerishableSQLConstants.RESERVED))
			    {

			    	queryFilter.append(" AND P.MATCHING_STATUS_CD");
			    	queryFilter.append(" IN ( '"+PerishableSQLConstants.AWAITING_CIC+"',");
			    	queryFilter.append(" '"+PerishableSQLConstants.AWAITING_DIVISION+"',");
			    	queryFilter.append(" '"+PerishableSQLConstants.OTHER+"' )");
			    	queryFilter.append(" AND P.MATCHED_ITEM_TYPE_CD in ('Y','E','P') ");
			    
			    }
			    else{
			    	queryFilter.append(" AND P.MATCHING_STATUS_CD ");
			    	queryFilter.append("= :"+PerishableSQLConstants.MAPPING_STATUS);
			    	queryFilter.append(" AND P.MATCHED_ITEM_TYPE_CD  in('Y','E','P')");
				    queryParameters.put(PerishableSQLConstants.MAPPING_STATUS, searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS));
			    }
			  }
			buildItemTypeForBaseSearch(searchCriteria, queryFilter);
						
			buildSearchCriteria(searchCriteria, queryFilter, queryParameters);			
		}
		
		return queryFilter.toString();
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void buildSearchCriteria(Map<String, String> searchCriteria,StringBuilder queryFilter, Map<String,Object> queryParameters) {
		
		if(searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) && 
				searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE)!=null && !searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("") ){/* dropdown list*/
			if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("WHSE_DSD")){
				if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("WHSE") ){
					queryFilter.append(" AND C.SOURCE_BY_WHSE  ='Y'");
				}
               if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("DSD") ){
					queryFilter.append(" AND C.SOURCE_BY_DSD  ='Y'");
				}
			} else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("DESC_ITEM")){
		        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
		               queryFilter.append(" AND C.ITEM_DESC LIKE UPPER" + "(:");
		               queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "1)");
		               queryParameters.put(PerishableSQLConstants.SEARCH_VALUE+"1", "%" + searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).replaceAll("'", "''")+ "%");
		        } 		      
		    } 
			else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("UPC_VAL")){
		        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
		               queryFilter.append(" AND C.UPC LIKE UPPER" + "(:");
		               queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "2)");
		               queryParameters.put(PerishableSQLConstants.SEARCH_VALUE+"2", "%" + searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE) + "%");
		        } 		      
		    } 
			else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("TOTAL_SALES")){
		    	queryFilter.append("AND SD.TOTAL_SALES ");
		    	if(null!=searchCriteria.get(PerishableSQLConstants.OPERATOR)){
		    	if(searchCriteria.get(PerishableSQLConstants.OPERATOR).equals("GREATER_THAN")){
		    		queryFilter.append(">");
		    	}else if(searchCriteria.get(PerishableSQLConstants.OPERATOR).equals("LESS_THAN")){
		    		queryFilter.append("<");	
		    	}else if(searchCriteria.get(PerishableSQLConstants.OPERATOR).equals("EQUALS")){
		    		queryFilter.append("=");	
		    	 }
		    	}
		    	queryFilter.append(" :" + PerishableSQLConstants.SEARCH_VALUE);
	            queryParameters.put(PerishableSQLConstants.SEARCH_VALUE, searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
		    }
			else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("USAGE_TYPE"))
			{
				if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("R"))
				{
					queryFilter.append("AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
				}
				else if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("E"))
				{
					queryFilter.append("AND ( C.EXPENSE_ITEM_IND = 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
				}
				else if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("M"))
				{
					queryFilter.append("AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND = 'Y' AND C.COUPON_IND <> 'Y' ) ");
				}
			}			
			else{
				if(!searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("WHSE_DSD")){
					queryFilter.append(
							//TODO
							PerishableSQLConstants.AND + /* ":"+PerishableSQLConstants.SEARCH_TYPE */ searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE) + " like UPPER(" );
//		             queryParameters.put(PerishableSQLConstants.SEARCH_TYPE, searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE));
						if(searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){/* dropdown list*/
							 queryFilter.append(":" +PerishableSQLConstants.SEARCH_VALUE+ "2)" );
				             queryParameters.put(PerishableSQLConstants.SEARCH_VALUE+"2", "%" + searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE) + "%");
						}
				}
				
			}
		}
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void buildItemTypeForBaseSearch(Map searchCriteria,
			StringBuilder queryFilter) {
		if(searchCriteria.containsKey(PerishableSQLConstants.ITEM_TYPE))
		{
			
			 
			 if(searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals(PerishableSQLConstants.SYSTEM2))
			{					
				 queryFilter.append(" AND X.SRC_UPC_COUNTRY =0 and X.SRC_UPC_SYSTEM =2 ");
			}
			else if(searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals(PerishableSQLConstants.SYSTEM4))
			{
				 
				 queryFilter.append(" AND X.SRC_UPC_COUNTRY =0 and X.SRC_UPC_SYSTEM =4 ");
			}
			else if(searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("PLU"))
			{		
				 queryFilter.append(" AND X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND X.SRC_UPC_SALES > 0 ");
				
			}
		}
	}
	
	/**
	 * Method to fetch the perishable CIC item list
	 * @param searchCriteriaMap
	 * @param filterMap
	 * @return
	 */
	public List<Object[]> fetchPerishablesTargetList(Map<String, String> searchCriteria,
			Map<String, String> filterCriteria) {
		Map<String, Object> queryParameters = new HashMap<>();
		List<Object[]> newresults=null;
		StringBuilder baseQueryJoin1 =new StringBuilder("");
		String pluConst ="'PLU'";
		String pluJoin ="" ;
		
		if(filterCriteria.containsKey(PerishableSQLConstants.PLU) ||searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("PLU") ||
				(filterCriteria.containsKey("expenseType") &&
				(filterCriteria.get("expenseType").equalsIgnoreCase("M")||filterCriteria.get("expenseType").equalsIgnoreCase("R"))
				)||		
				(searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) &&searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).endsWith("PLU_CD"))||		
				(searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) && searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("USAGE_TYPE") &&
				(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("M")||searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("R") )
        		)
				)
		{
			pluConst ="POS.PLU_CD";
			pluJoin =" LEFT OUTER JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS " /* Expense related so that using outer join */
			+"ON POS.UPC_MANUF = XRF.UPC_MANUF "
			+" AND POS.UPC_SALES = XRF.UPC_SALES "
			+" AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY "
			+" AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  " ;
		}
		
		baseQueryJoin1.append ("SELECT /*+ PARALLEL(4) FIRST_ROWS(1000) */ DISTINCT "
				+ "CDS.CORP_ITEM_CD,CDS.DESC_ITEM,"
				+ "CDS.VEND_CONV_FCTR,CDS.PACK_WHSE,CDS.CDS_SIZE,CDS.ITEM_USAGE_TYPE,"
				+ " NULL,"
				+ pluConst+ " as PLU,CDS.DISP_FLAG,CDS.STATUS_CORP,"
				+ "concat(CDS.GROUP_CD ,'-', CDS.CTGRY_CD ,'-', CDS.CLASS_CD ,'-', CDS.SUB_CLASS_CD ,'-',  CDS.SUBSB_CLASS_CD) AS SMIC,"
				+ "OMDEPT.DEPT_NAME,P.MATCHING_STATUS_CD,'productsource' as productsource,CDS.ITEM_USAGE_IND,CDS.SCALE_PRETEXT_IND "
				+ ",'VENDOR_DETAIL' as VENDOR_DETAIL"
				+ ", concat(CDS.VEN_UPC_PACK_IND,'-', CDS.VEN_UPC_COUNTRY,'-', CDS.VEN_UPC_NUM_SYS,'-', CDS.VEN_UPC_MANUF,'-', CDS.VEN_UPC_ITEM) AS VOC "
				+", DSR.RTL_ITEM_DESC "
				+"  ,CDS.SIZE_UOM "
				+ "FROM SSIMSLAND.SQLDAT3_SSITMCDS CDS "
				+"JOIN SSIMSLAND.SQLDAT3_SSITMXRF XRF "
				+ "ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD "
						
				+"JOIN SSIMSLAND.SQLDAT3_OMSTRDS RDS "
				+"ON CDS.RETAIL_SECT = RDS.SECT "
				
				+"JOIN  SSIMSLAND.SQLDAT3_OMDEPT OMDEPT "
				+"ON OMDEPT.DEPT = RDS.DEPT " 
				
				+" LEFT JOIN "+defaultSchema+".ITEM_CONV_ITEM_VENDOR_XRF VRF "
				+"ON CDS.CORP_ITEM_CD = VRF.CORP_ITEM_CD "   
				
				+"JOIN SSIMSLAND.SQLDAT3_SSITMDSR DSR "
				+"ON CDS.CORP_ITEM_CD = DSR.CORP_ITEM_CD ");
				
		/*		+" JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS "
				+" ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD ";*/
				
			baseQueryJoin1.append(pluJoin);
						
			String baseQueryJoin2 ="LEFT OUTER JOIN  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
				+"ON CDS.CORP_ITEM_CD = P.CORP_ITEM_CD "
				
				+"WHERE CDS.STATUS_CORP <> 'D' ";		
			
		
		
 		String conditonalJoin ="" ;
		String searchcriteria = createTargetSearchQuery(searchCriteria,queryParameters);
		String filtercriteria = createTargetFilterQuery(filterCriteria,queryParameters);
		if(null!=searchCriteria && searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) &&
				searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("WDS.DST_CNTR"))
		{
			conditonalJoin =" LEFT JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS "
					+" ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD ";
		}		
		
    
		StringBuilder query = baseQueryJoin1.append(conditonalJoin).append(baseQueryJoin2).append(searchcriteria).append( filtercriteria);
    	
		    	
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		q.setMaxResults(200);
		List<Object[]> results = q.getResultList();
		em.close();
		if (null != searchCriteria) {
			newresults = getTargetUpcAggregateList(results,searchCriteria.get(PerishableSQLConstants.ITEM_TYPE));
			
		}
		
		
		return newresults;
	}

					
	/**
	 * Method the get upc aggregate for the given cic list
	 * @param resultlist
	 * @return
	 */
	private List<Object[]> getTargetUpcAggregateList(List<Object[]> resultlist, String itemType) {
		if(resultlist!=null && !resultlist.isEmpty() ){
			String conditonalJoin ="" ;
		   /* if (null != itemType && !itemType.equals("") && itemType.equals("PLU") ) {
				 conditonalJoin=" JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS ON POS.UPC_MANUF = XRF.UPC_MANUF "
								+"AND POS.UPC_SALES = XRF.UPC_SALES "
								+"AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY "
								+"AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  "
								+"  AND POS.PLU_CD>0 ";
	 			}*/
			
	    	StringBuilder query=new StringBuilder("");
	    	query.append( "SELECT /*+ PARALLEL(4) */ DISTINCT CDS.CORP_ITEM_CD,"
             +"STRING_AGG( CAST(XRF.UPC_COUNTRY AS CHAR(1)) + CAST(XRF.UPC_SYSTEM AS CHAR(1))+ ssma_oracle.lpad_varchar(XRF.UPC_MANUF,5,'0')+ "
             + "ssma_oracle.lpad_varchar(XRF.UPC_SALES,5,'0'), ';')"
             + "as UPC_LIST "
             +" FROM "
             +" SSIMSLAND.SQLDAT3_SSITMCDS CDS"
             +" JOIN"
             +" SSIMSLAND.SQLDAT3_SSITMXRF XRF" 
             +" ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD" 
             +conditonalJoin
             +" WHERE");
	    		query.append(" CDS.CORP_ITEM_CD IN ( :resultlist)"
	    				+ " GROUP BY CDS.CORP_ITEM_CD" + 
	    				  " ORDER BY CDS.CORP_ITEM_CD");
	    	 
	    	/* if (null != itemType && !itemType.equals("")) {
	 			final String system_2 = "2";
	 			final String system_4 = "4";
	 			 if (itemType.equals("System2")) {
	 				query.append(" AND XRF.UPC_SYSTEM= " + system_2);
	 			} else if (itemType.equals("System4")) {
	 				query.append(" AND XRF.UPC_SYSTEM= " + system_4);
	 			} else if (itemType.equals("PLU")) {
	 				query.append(" AND POS.PLU_CD>0 ");
	 			}
	 		}*/
	      	EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
			Query q = em.createNativeQuery(query.toString());
			
			q.setParameter("resultlist", resultlist.stream().map(result -> result[0]).collect(Collectors.toList()));
			
			q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
			
			List<Object[]> results = q.getResultList();
			em.close();
			appendTargetResultListWithUPC(resultlist, results);
			
			 getTargetWhseDsd(resultlist);
			 getTargetVendorDetails(resultlist);
			 getTargetPluCd(resultlist);
			
	    	}
			return resultlist;  
	}

	/**
	 * Method to append upc with the primary query result object
	 * @param resultlist
	 * @param results
	 */
	private void appendTargetResultListWithUPC(List<Object[]> resultlist, List<Object[]> results) {
			for (Object[] skuObjO : resultlist) {
				for (Object[] skuObj : results) {
					if (skuObjO[0].equals(skuObj[0])) {
							skuObjO[6] = skuObj[1];						
							break;		
					}

				}
			}
		}

	private void getTargetWhseDsd(List<Object[]> newresults) {
		if(newresults!=null && !newresults.isEmpty() ){
			StringBuilder query=new StringBuilder("");
			
			query.append("SELECT DISTINCT CORP_ITEM_CD,STRING_AGG(SUBSTRING(DST_CNTR,1,1),'')"
					+ " WHSE_DSD FROM SSIMSLAND.SQLDAT3_SSITMWDS ");
			query.append("WHERE CORP_ITEM_CD IN (:newresults)"
					+ " GROUP BY CORP_ITEM_CD"
					+ " ORDER BY CORP_ITEM_CD");
	    	 
	    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
				Query q = em.createNativeQuery(query.toString());
				q.setParameter("newresults", newresults.stream().map(result -> result[0]).collect(Collectors.toList()));
				q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
				List<Object[]> results = q.getResultList();
				em.close();
			appendWhseDsdResult(newresults,results);
		}
		
	}

	private void appendWhseDsdResult(List<Object[]> newresults,
			List<Object[]> results) {
		for (Object[] skuObjO : newresults) {
			for (Object[] skuObj : results) {
				if (skuObjO[0].equals(skuObj[0])) {	
					
					if(skuObj[1].toString().contains("DW") || skuObj[1].toString().contains("WD"))
					{
						skuObjO[13] = "WHSE-DSD";
					}
					else if(!skuObj[1].toString().contains("W"))
					{
						skuObjO[13] = "DSD";
					}
					else if(!skuObj[1].toString().contains("D"))
					{
						skuObjO[13] = "WHSE";
					}
						
											
				}

			}
		}
		
	}
	private void getTargetVendorDetails(List<Object[]> newresults) {
		if(newresults!=null && !newresults.isEmpty() ){
			StringBuilder query=new StringBuilder("");
			query.append(" SELECT DISTINCT CORP_ITEM_CD, vend_num,name "
					+ "from "+defaultSchema+".ITEM_CONV_ITEM_VENDOR_XRF  ");
			query.append(" WHERE CORP_ITEM_CD IN (:newresults)");
	    	 
	    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
				Query q = em.createNativeQuery(query.toString());
				q.setParameter("newresults", newresults.stream().map(result -> result[0]).collect(Collectors.toList()));
				q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
				List<Object[]> results = q.getResultList();
				em.close();
			appendTargetVendor(newresults,results);
		}
		
	}


	private void appendTargetVendor(List<Object[]> newresults,
			List<Object[]> results) {
		for (Object[] skuObjO : newresults) {
			for (Object[] skuObj : results) {
				if (skuObjO[0].equals(skuObj[0])) {					
					
					if(skuObjO[16].equals("VENDOR_DETAIL"))
					{
						skuObjO[16] = skuObj[1]+"-"+skuObj[2]+";";	
					}
					else
					{
						skuObjO[16] = skuObjO[16]+""+skuObj[1]+"-"+skuObj[2]+";";	
					}
							
																
				}
					
			}
		}
		
	}
	
	private void getTargetPluCd(List<Object[]> resultlist) {
		if(resultlist!=null && !resultlist.isEmpty() ){
		StringBuilder query=new StringBuilder("");
		 query.append("select distinct XRF.corp_item_Cd ,POs.PLU_CD from   SSIMSLAND.SQLDAT3_SSITMPOS POS"
		 		+" JOIN  SSIMSLAND.SQLDAT3_SSITMXRF XRF" 
                +" ON POS.UPC_MANUF = XRF.UPC_MANUF "  
                +" AND POS.UPC_SALES = XRF.UPC_SALES "
                +" AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY "  
                +" AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM "
                +"  AND POS.PLU_CD >0 ");
		
		
		 query.append("AND XRF.CORP_ITEM_CD IN ( :resultlist)");
    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
			Query q = em.createNativeQuery(query.toString());
			q.setParameter("resultlist", resultlist.stream().map(result -> result[0]).collect(Collectors.toList()));
			q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
			List<Object[]> results = q.getResultList();
			em.close();
			appendPLUCd(resultlist,results);
		}
	}
											
	private void appendPLUCd(List<Object[]> resultlist, List<Object[]> results) {
		for (Object[] cicObjSource : resultlist) {
			for (Object[] cicObjAppend : results) {
				if (cicObjSource[0].equals(cicObjAppend[0])) {	
					if(cicObjSource[7].toString().equals("PLU"))
					 {cicObjSource[7] = cicObjAppend[1];}
					break;
				}

			}
		}
		
	}

	/**
	 * 
	 * @param filterCriteria
	 * @return
	 */
	private String createTargetFilterQuery(Map<String, String> filterCriteria,Map<String,Object> parameters) {
		StringBuilder queryFilter=new StringBuilder("");
		
		if(null!=filterCriteria.keySet() && ! filterCriteria.keySet().isEmpty() )	{
			
			buildDepartmentSearch(filterCriteria, queryFilter, parameters);
			if(filterCriteria.containsKey(PerishableSQLConstants.ITEM_DESCRIPTION)){
               queryFilter.append(" AND CDS.DESC_ITEM LIKE UPPER" + "(:");
               queryFilter.append(PerishableSQLConstants.ITEM_DESCRIPTION );
               queryFilter.append(")");
               parameters.put(PerishableSQLConstants.ITEM_DESCRIPTION, "%" + filterCriteria.get(PerishableSQLConstants.ITEM_DESCRIPTION).replaceAll("'", "''") + "%");
			}
			if(filterCriteria.containsKey("corpItemCD")){
				queryFilter.append(" AND CDS.CORP_ITEM_CD= :");
				queryFilter.append("corpItemCD ");
	            parameters.put("corpItemCD", filterCriteria.get("corpItemCD"));
			}
			if(filterCriteria.containsKey(PerishableSQLConstants.PLU)){
				queryFilter.append(" AND POS.PLU_CD=:");
				queryFilter.append(PerishableSQLConstants.PLU+" ");
	            parameters.put(PerishableSQLConstants.PLU, filterCriteria.get(PerishableSQLConstants.PLU));
			}			
			
			if(filterCriteria.containsKey("upc")){
				queryFilter.append(" AND  concat(xrf.upc_country ,  xrf.upc_system , right(replicate('0',5) + cast(xrf.upc_manuf as varchar),5) ,  right(replicate('0',5) + cast(xrf.upc_sales as varchar),5)  ) =");
				queryFilter.append(":upc ");
	            parameters.put("upc", filterCriteria.get("upc"));
			}
            if(filterCriteria.containsKey("groupCd")){
            	queryFilter.append(" AND CDS.GROUP_CD=");
            	queryFilter.append(":groupCd ");
	            parameters.put("groupCd", filterCriteria.get("groupCd"));
            }
            if(filterCriteria.containsKey("catgryCd")){
            	queryFilter.append(" AND CDS.CTGRY_CD=");
            	queryFilter.append(":catgryCd ");
	            parameters.put("catgryCd", filterCriteria.get("catgryCd"));
            }

            if(filterCriteria.containsKey("classCd")){
            	queryFilter.append(" AND CDS.CLASS_CD=");
            	queryFilter.append(":classCd ");
	            parameters.put("classCd", filterCriteria.get("classCd"));
            }

            if(filterCriteria.containsKey("subClassCd")){
            	queryFilter.append(" AND CDS.SUB_CLASS_CD=");
            	queryFilter.append(":subClassCd ");
	            parameters.put("subClassCd", filterCriteria.get("subClassCd"));
            }

            if(filterCriteria.containsKey("subSubClassCd")){
            	queryFilter.append(" AND CDS.SUBSB_CLASS_CD=");
            	queryFilter.append(":subSubClassCd ");
	            parameters.put("subSubClassCd", filterCriteria.get("subSubClassCd"));
            }
            if(filterCriteria.containsKey("vendorName")){
            	queryFilter.append(" AND VRF.NAME LIKE UPPER" + "(:");
                queryFilter.append("vendorName ");
                queryFilter.append(")");
	            parameters.put("vendorName", "%" + filterCriteria.get("vendorName").replaceAll("'", "''") + "%");
            }
            if(filterCriteria.containsKey("vendorCode")){
            	queryFilter.append(" AND VRF.VEND_NUM=");
            	queryFilter.append(":vendorCode ");
	            parameters.put("vendorCode", filterCriteria.get("vendorCode"));
		}
            if(filterCriteria.containsKey("expenseType")){
            	queryFilter.append("  AND CDS.ITEM_USAGE_IND  = ");
            	queryFilter.append(":expenseType ");
	            parameters.put("expenseType", filterCriteria.get("expenseType"));
            	
            	if(filterCriteria.get("expenseType").equals("M")||
            			filterCriteria.get("expenseType").equals("R"))
                {
                	queryFilter.append(" AND( POS.UPC_MANUF is not null  AND POS.UPC_SALES is not null AND POS.UPC_COUNTRY is not null AND POS.UPC_SYSTEM is not null ) ");
            }
            }
            
            if(filterCriteria.containsKey("usageType")){
            	queryFilter.append("  AND CDS.ITEM_USAGE_TYPE  = ");
            	queryFilter.append(":usageType ");
	            parameters.put("usageType", filterCriteria.get("usageType"));
            }
            
            if(filterCriteria.containsKey("vendorOrderFilter")){
            	String[] vendorObject=filterCriteria.get("vendorOrderFilter").split("-");
            	if(!vendorObject[0].equals("NA"))
            	{queryFilter.append("  AND CDS.VEN_UPC_PACK_IND  = :vendorObject[0]");
	            parameters.put("vendorObject[0]",vendorObject[0]);}
            	if(!vendorObject[1].equals("NA"))
            	{queryFilter.append("  AND CDS.VEN_UPC_COUNTRY  = :vendorObject[1]");
	            parameters.put("vendorObject[1]",vendorObject[1]);}
            	if(!vendorObject[2].equals("NA"))
            	{queryFilter.append("  AND CDS.VEN_UPC_NUM_SYS  = :vendorObject[2]");
	            parameters.put("vendorObject[2]",vendorObject[2]);}
            	if(!vendorObject[3].equals("NA"))
            	{queryFilter.append("  AND CDS.VEN_UPC_MANUF  = :vendorObject[3]");
	            parameters.put("vendorObject[3]",vendorObject[3]);}
            	if(!vendorObject[4].equals("NA"))
            	{queryFilter.append("  AND CDS.VEN_UPC_ITEM  = :vendorObject[4]");
	            parameters.put("vendorObject[4]",vendorObject[4]);}
            	
            	
            	
            }
            
		}
		queryFilter.append(" ORDER BY CDS.CORP_ITEM_CD");
		return queryFilter.toString();
	}

	/**
	 * @param filterCriteria
	 * @param queryFilter
	 */
	private void buildDepartmentSearch(Map<String, String> filterCriteria,
			StringBuilder queryFilter, Map<String,Object> parameters) {
		if(filterCriteria.containsKey(PerishableSQLConstants.DEPARTMENT)){
			queryFilter.append(" AND CDS.RETAIL_SECT IN" + "( :");
			queryFilter.append("CDS.RETAIL_SECT)");
			parameters.put("CDS.RETAIL_SECT", Arrays.asList(filterCriteria.get(PerishableSQLConstants.DEPARTMENT).split(",")));
		}
	}

	/**
	 * 
	 * @param searchCriteria
	 * @return
	 */
	private String createTargetSearchQuery(Map<String, String> searchCriteria,Map<String,Object> parameters) {
		StringBuilder queryFilter = new StringBuilder("");
		if (searchCriteria != null && searchCriteria.size() > 0) {
			setMappingTypeAndItenTypeCriteria(searchCriteria, queryFilter, parameters);
			if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE)){
				if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("UPC_VAL")){	
					if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){ 
						queryFilter.append(" AND concat( xrf.upc_country ,  xrf.upc_system ,  right(replicate('0',5) + cast(xrf.upc_manuf as varchar),5) ,  right(replicate('0',5) + cast(xrf.upc_sales as varchar),5) )" + " LIKE ( :");
						queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "1) ");
						parameters.put(PerishableSQLConstants.SEARCH_VALUE + "1", "%" + searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).replaceAll("-", "")  + "%");
					}
				
				}else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("SMIC")){					
					if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
						queryFilter.append(" AND ( concat( cds.group_cd ,  cds.ctgry_cd ,  cds.class_cd ,  cds.sub_class_cd ,  cds.subsb_class_cd ) )= :");
						queryFilter.append(PerishableSQLConstants.SEARCH_VALUE + " ");
						parameters.put(PerishableSQLConstants.SEARCH_VALUE, searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
					}					
				}
                else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("CIC_VAL")){
                    if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE) ){
                           queryFilter.append(" AND CDS.CORP_ITEM_CD LIKE" + "(:");
                           queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "2)");
                           parameters.put(PerishableSQLConstants.SEARCH_VALUE + "2", "%" + searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE) + "%");
                    }      
                }
            else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("DESC_ITEM")){
		        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE) &&  null!=searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE)) {
		               queryFilter.append(" AND CDS.DESC_ITEM LIKE UPPER" + "( :");
		               queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "3) ");
		               parameters.put(PerishableSQLConstants.SEARCH_VALUE + "3", "%" + searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).replaceAll("'", "''") + "%");
		        }      
		    }
             else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("DEPT_NAME")){
                    if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
                           queryFilter.append(" AND CDS.RETAIL_SECT IN" + "( :");
                           queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "5)");
    		               parameters.put(PerishableSQLConstants.SEARCH_VALUE + "5", Arrays.asList(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).split(",")));
                    }      
               }
             else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("USAGE_TYPE")){
                 if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
                        queryFilter.append(" AND CDS.ITEM_USAGE_IND  = :" );
                        queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + " ");
                        parameters.put(PerishableSQLConstants.SEARCH_VALUE, searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
                        if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("M")||
                        		searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("R"))
                        {
                        	queryFilter.append(" AND( POS.UPC_MANUF is not null  AND POS.UPC_SALES is not null AND POS.UPC_COUNTRY is not null AND POS.UPC_SYSTEM is not null ) ");
                        }
                        
                 }      
            }
             else{
                   if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
                            queryFilter.append(" AND UPPER(" + searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE) + ") like UPPER(:");
                           queryFilter.append( PerishableSQLConstants.SEARCH_VALUE + "4)");
    		               parameters.put(PerishableSQLConstants.SEARCH_VALUE + "4", searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE) + "%");
                    }
				}
			}
		}

		return queryFilter.toString();
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void setMappingTypeAndItenTypeCriteria(
			Map<String, String> searchCriteria, StringBuilder queryFilter,Map<String,Object> parameters) {
		if(searchCriteria.containsKey(PerishableSQLConstants.MAPPING_STATUS))
		  {
		    if(PerishableSQLConstants.TO_BE_MAPPED.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
		    	queryFilter.append(PerishableSQLConstants.AND_P_MACHING_STATUS_CD);
		    	queryFilter.append(PerishableSQLConstants.IS_NULL);	
		    	queryFilter.append(" OR P.MATCHING_STATUS_CD ='UN_MAPPED' ");
		    	queryFilter.append(" ) ");
		    }else{
				queryFilter.append(" AND P.MATCHING_STATUS_CD ");
		    	queryFilter.append("= :P.MATCHING_STATUS_CD ");		    	
		    	queryFilter.append(" AND  P.MATCHED_ITEM_TYPE_CD in('Y','B','S','E','P' ) ");
		    	parameters.put("P.MATCHING_STATUS_CD", searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS));
		    }
		  }
		
		if (searchCriteria.containsKey(PerishableSQLConstants.ITEM_TYPE)) {
			final String system_2 = "2";
			final String system_4 = "4";
			 if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("System2")) {
				queryFilter.append(" AND XRF.UPC_COUNTRY =0 AND XRF.UPC_SYSTEM= :system_2 ");
				parameters.put("system_2", system_2);
			} else if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("System4")) {
				queryFilter.append(" AND XRF.UPC_COUNTRY =0 AND XRF.UPC_SYSTEM= :system_4 ");
				parameters.put("system_4", system_4);
			} else if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("PLU")) {
				queryFilter.append(" AND POS.PLU_CD>0 ");
			}
		}
	}
	
	public boolean checkDuplicateExistence(Object[] inputs)
	{  
		boolean hasResult=false;
			String query ="Select * from ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  WHERE MATCHING_STATUS_CD NOT IN ('UN_MAPPED','AWAITING_DIVISION_INPUT','OTHERS','AWAITING_NEW_CIC') and "
				+"COMPANY_ID = ? AND "  
				+"DIVISION_ID = ? AND "
				+"PRODUCT_SKU = ? AND "
				+"UPC = ?";
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		
		Query q = em.createNativeQuery(query);
		q.setParameter(1, inputs[0]);
		q.setParameter(2, inputs[1]);
		q.setParameter(3, inputs[2]);
		q.setParameter(4, inputs[3]);
		List<Object[]> results = q.getResultList();
		
		em.close();
		if(results!=null && !results.isEmpty()){
			hasResult= true;
		}
					return hasResult;
	}
	
	public boolean checkMarkAsDead(Object[] inputs){
		
		StringBuilder query=new StringBuilder("");
		boolean hasResult=false;
		query.append("Select * From XREFLAND.SRC_ITEM_XRF where CONV_STATUS_CD='D' AND COMPANY_ID =?");
		query.append(" AND DIVISION_ID= ?");
		query.append(" AND SRC_PRODUCT_SKU = ?");
		query.append(" AND SRC_UPC_COUNTRY= ?");
		query.append(" AND SRC_UPC_SYSTEM= ?");
		query.append(" AND SRC_UPC_MANUF = ?");
		query.append(" AND SRC_UPC_SALES= ?");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter(1, inputs[0]);
		q.setParameter(2, inputs[1]);
		q.setParameter(3, inputs[2]);
		q.setParameter(4, inputs[3]);
		q.setParameter(5, inputs[4]);
		q.setParameter(6, inputs[5]);
		q.setParameter(7, inputs[6]);
		List<Object[]> results = q.getResultList();
		
		em.close();
		if(results!=null && !results.isEmpty()){
			hasResult=true;
		}
		return hasResult;
	}

	public boolean markAsDead(Object[] inputs){
		
		boolean hasResult=false;
		
		StringBuilder query=new StringBuilder("");
		query.append("Update XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD ='D',CONV_STATUS_SUB_CD ='B', STATUS_REASON_TXT = :DeadReason,CONV_STATUS_DSC='Dead' Where COMPANY_ID =");
		query.append(":companyId");
		query.append(" AND DIVISION_ID= ");
		query.append(":divisionId");
		query.append(" AND SRC_PRODUCT_SKU =");
		query.append(":productSku");
		query.append(" AND SRC_UPC_COUNTRY =");
		query.append(":upcCountry");
		query.append(" AND SRC_UPC_SYSTEM =");
		query.append(":upcSystem");
		query.append(" AND SRC_UPC_MANUF =");
		query.append(":upcManuf");
		query.append(" AND  SRC_UPC_SALES =");
		query.append(":upcSales");
		query.append(" AND CORP_ITEM_CD is null ");
		
		StringBuilder queryforEtl=new StringBuilder("");
		queryforEtl .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD= 'CORRECTED',CORP_ITEM_CD =0  WHERE MATCHING_STATUS_CD IN( 'UN_MAPPED','AWAITING_NEW_CIC','AWAITING_DIVISION_INPUT','OTHERS' ) AND "
				+ "  COMPANY_ID = :companyId  AND DIVISION_ID = :divisionId AND PRODUCT_SKU= :productSku AND MATCHED_ITEM_TYPE_CD  = 'E' AND MATCHING_TYPE_CD = 'ETL_AUTO_MATCH'  ");
		

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		        EntityTransaction et = em.getTransaction();
	        et.begin();
	        Query q = em.createNativeQuery(query.toString());
	        q.setParameter("companyId", inputs[0]);
	        q.setParameter("divisionId", inputs[1]);
	        q.setParameter("productSku", inputs[2]);
	        q.setParameter("upcCountry", inputs[3]);
	        q.setParameter("upcSystem", inputs[4]);
	        q.setParameter("upcManuf", inputs[5]);
	        q.setParameter("upcSales", inputs[6]);
	        q.setParameter("DeadReason", inputs[7]);
	        int result = q.executeUpdate();
	        
	        Query q1 = em.createNativeQuery(queryforEtl.toString());
	        q1.setParameter("companyId", inputs[0]);
	        q1.setParameter("divisionId", inputs[1]);
	        q1.setParameter("productSku", inputs[2]);
	        result = q1.executeUpdate();
	        
	        et.commit();
	        LOG.info("Completed Updating SRC_ITEM_XREF records.");
	        em.close();
	        if(result>0){
	        	hasResult=true;
	        }
	        return hasResult;
	}
	
	public List listOfUPCforForceNew(Object[] inputs)
	{
		StringBuilder query=new StringBuilder("");
		query.append("select UPC from ECFLAND.ITEM_AGGREGATE_CORP where COMPANY_ID = :companyId");
		query.append(" AND DIVISION_ID= :divisionId");
		query.append(" AND PRODUCT_SKU = :productSku");
		query.append(" AND UPC NOT IN (select UPC from  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  where COMPANY_ID = :companyId");
		query.append(" AND DIVISION_ID= :divisionId");
		query.append(" AND PRODUCT_SKU = :productSku");
        query.append(")");

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		        Query q = em.createNativeQuery(query.toString());
		        q.setParameter("companyId", inputs[0]);
		        q.setParameter("divisionId", inputs[1]);
		        q.setParameter("productSku", inputs[2]);
	        List<Object[]> results = q.getResultList();
	        LOG.info("Completed inserting  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  records.");
	        em.close();
	        return results;
	}
	
	public List<String> fetchUpcList(String companyId, String divisionId, String productSku) {
		LOG.info("Fetching UPC From ITEM_AGGREGATE_CORP.");
		StringBuilder query=new StringBuilder("");
		
		query.append("SELECT DISTINCT D.UPC FROM ECFLAND.ITEM_AGGREGATE_CORP D "
				+ "LEFT JOIN ECFLAND.DISPLAY_ITEM_COMPONENTS S "
				+ "ON D.COMPANY_ID = S.COMPANY_ID "
				+ "AND D.DIVISION_ID = S.DIVISION_ID "
				+ "AND D.PRODUCT_SKU = S.PRODUCT_SKU "
				+ "JOIN XREFLAND.SRC_ITEM_XRF X "
				+ "ON D.COMPANY_ID = X.COMPANY_ID "
				+ "AND D.DIVISION_ID = X.DIVISION_ID "
				+ "AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU "
				+" and D.UPC= X.SRC_UPC "
				+ " WHERE D.PRODUCT_SKU = :productSku AND D.COMPANY_ID = :companyId   AND D.DIVISION_ID = :divisionId AND X.CONV_STATUS_CD NOT IN('D','O','C')");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
        q.setParameter("companyId", companyId);
        q.setParameter("divisionId", divisionId);
        q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "50");
		List<String> results = q.getResultList();
		LOG.info("Completed fetching UPC From ITEM_AGGREGATE_CORP.");
		em.close();
		return results;
	}
	/**
	 * 
	 * @param companyID
	 * @param divisionID
	 * @param searchCriteria
	 * @param searchCriteriaValue
	 * @param itemType
	 * @return
	 */
	public List<Object[]> fetchMappedList(String companyID, String divisionID, String searchCriteria,
			String searchCriteriaValue, String mappingStatus) {

		LOG.info("Fetching Mapped Items");
		StringBuilder query = new StringBuilder("");
		StringBuilder joinQuery = new StringBuilder("");
		Map<String,Object> queryParameters = new HashMap<>();
		if (null != searchCriteria && !searchCriteria.isEmpty() && null != searchCriteriaValue
				&& !searchCriteriaValue.isEmpty() && searchCriteria.equals("WDS.DST_CNTR")) {
			joinQuery.append(" LEFT JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS ON CDS.CORP_ITEM_CD =WDS.CORP_ITEM_CD ");
			
		}

		query.append(
				"select /*+ PARALLEL(4) */ DISTINCT M.PRODUCT_SKU,C.ITEM_DESC,(C.MASTER_CASE_PACK_NBR / NULLIF(C.SHIPPING_PACK_NBR,0)) AS VCF,"
						+ "C.SHIPPING_PACK_NBR,C.SIZE_NBR,C.MULTI_COMP_ITEM_IND,"
						+ "'UPC_LIST' AS UPC_LIST,"
						+ "CAST(C.ITEM_SETUP_DT AS DATE) AS ITEM_SETUP_DT," + " null ,CAST(SD.last_ship_dt AS DATE) AS last_ship_dt,"
						+ "CASE  WHEN C.EXPENSE_ITEM_IND ='N' " 
						+ "AND C.MATERIAL_ITEM_IND ='N' " 
						+ "AND C.STORE_CREATED_ITEM_IND='N'  THEN 'R' "  
						+ "WHEN C.EXPENSE_ITEM_IND ='Y' THEN 'E' " 
						+ "WHEN C.MATERIAL_ITEM_IND ='Y' THEN 'M' " 
						+ "END USAGE1,"
						+ "M.CORP_ITEM_CD,CDS.DESC_ITEM,"
						+ "CDS.VEND_CONV_FCTR,CDS.PACK_WHSE,CDS.SIZE_NUM,CDS.ITEM_USAGE_TYPE,CDS.DISP_FLAG,"
						+ "CDS.CREATE_DT,M.MATCHING_TYPE_CD,M.MATCHING_STATUS_CD,M.MATCHED_ITEM_TYPE_CD "

						+ "FROM  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  M "
						+" JOIN XREFLAND.SRC_ITEM_XRF X"
						+" ON  M.COMPANY_ID = X.COMPANY_ID"
						+" AND M.DIVISION_ID = X.DIVISION_ID"
						+" AND M.PRODUCT_SKU = X.SRC_PRODUCT_SKU"
						+" and M.UPC= X.SRC_UPC "
						+ " JOIN SSIMSLAND.SQLDAT3_SSITMCDS CDS " + "ON CDS.CORP_ITEM_CD = M.CORP_ITEM_CD "				
						+ " JOIN  ECFLAND.ITEM_AGGREGATE_CORP C " + "ON C.COMPANY_ID = M.COMPANY_ID "
						+ "AND C.DIVISION_ID = M.DIVISION_ID " + "AND C.PRODUCT_SKU = M.PRODUCT_SKU "				
						+ " LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD " + " ON C.COMPANY_ID = SD.COMPANY_ID "
						+ " AND C.DIVISION_ID = SD.DIVISION_ID" + " AND C.PRODUCT_SKU = SD.PRODUCT_SKU "
						+ "AND C.UPC = SD.UPC " + joinQuery + "WHERE M.COMPANY_ID= :companyID "
						+ " AND M.DIVISION_ID= :divisionID "
						+ " AND M.MATCHING_TYPE_CD IN ('ADD_MAP','INHERIT_MAP','ETL_AUTO_MATCH') AND M.CORP_ITEM_CD!=0");

		if (null != searchCriteria && !searchCriteria.isEmpty() && null != searchCriteriaValue
				&& !searchCriteriaValue.isEmpty()) {

			if (searchCriteria.equals("WHSE")) {
				query.append(" AND C.SOURCE_BY_WHSE  ='Y'");
			} else if (searchCriteria.equals("DSD")) {
				query.append(" AND C.SOURCE_BY_DSD  ='Y'");
			}
			else if (searchCriteria.equals("M.UPC")) {
				query.append(PerishableSQLConstants.AND + searchCriteria + " like UPPER(" + ":"
						+ searchCriteria + ")");
				queryParameters.put(searchCriteria, "%" + searchCriteriaValue.replaceAll("-", "") + "%");
			}
			else if (searchCriteria.equals("M.PRODUCT_SKU") || searchCriteria.equals("M.CORP_ITEM_CD")) {
				query.append(PerishableSQLConstants.AND + searchCriteria + " like UPPER(" + ":"
						+ searchCriteria + ")");
				queryParameters.put(searchCriteria, "%"	+ searchCriteriaValue + "%");
			}else if (searchCriteria.equals("C.ITEM_DESC") || searchCriteria.equals("CDS.DESC_ITEM")) {
				query.append(PerishableSQLConstants.AND + searchCriteria + " like UPPER(" + ":"
						+ searchCriteria + ")");
				queryParameters.put(searchCriteria, "%" + searchCriteriaValue.replaceAll("'", "''") + "%");
			} else if (searchCriteria.equals("CDS.RETAIL_SECT")) {
				query.append(PerishableSQLConstants.AND + searchCriteria + " IN (:"
						+ searchCriteria + ")");
				queryParameters.put(searchCriteria, Arrays.asList(searchCriteriaValue.split(",")));
			} 
			else if (searchCriteria.equals("SOURCE_USAGE_TYPE")) {
				if(searchCriteriaValue.equals("R"))
				{
					query.append(" AND C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ");
				}
				else if(searchCriteriaValue.equals("E"))
				{
					query.append(" AND C.EXPENSE_ITEM_IND = 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ");
				}
				else if(searchCriteriaValue.equals("M"))
				{
					query.append(" AND C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND = 'Y' AND C.COUPON_IND <> 'Y' ");
				}
			} 
			else if (searchCriteria.equals("TARGET_USAGE_TYPE")) {                
                	query.append(" AND CDS.ITEM_USAGE_IND  = " );
                	query.append( " :" +searchCriteria ); 
    				queryParameters.put(searchCriteria, searchCriteriaValue.trim());                 
			}else{
				query.append(PerishableSQLConstants.AND + searchCriteria + " like UPPER(:"
						+ searchCriteria + ")");
				queryParameters.put(searchCriteria, searchCriteriaValue + "%");				
			}

		}

		setMappimgStatusFilter(mappingStatus, query, queryParameters);

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
        q.setParameter("companyID", companyID);
        q.setParameter("divisionID", divisionID);
        for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		List<Object[]> results = q.getResultList();
		em.close();
		if(!results.isEmpty())
		{
			getMappedUPCAgregateList(results,companyID,divisionID,mappingStatus);
		}
			
		LOG.info("Completed Mapped Items");
		
		return results;
	}

	private void getMappedUPCAgregateList(List<Object[]> results,
			String companyID, String divisionID, String mappingStatus) {
		Map<String,Object> queryParameters = new HashMap<>();
		StringBuilder query = new StringBuilder("");
		query.append(
				"select /*+ PARALLEL(4) */ DISTINCT M.PRODUCT_SKU,"
						+ "STRING_AGG(M.UPC,';') as UPC "
						+ "FROM  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  M "	
						+" JOIN XREFLAND.SRC_ITEM_XRF X "
	                    +" ON  M.COMPANY_ID = X.COMPANY_ID "
	                    +" AND M.DIVISION_ID = X.DIVISION_ID "
	                    +" AND M.PRODUCT_SKU = X.SRC_PRODUCT_SKU "
	                    +" and M.UPC= X.SRC_UPC "
						+ " WHERE M.COMPANY_ID= :companyID"
						+ " AND M.DIVISION_ID= :divisionID"
						+ " AND M.MATCHING_TYPE_CD IN ('ADD_MAP','INHERIT_MAP','ETL_AUTO_MATCH') AND M.CORP_ITEM_CD!=0 ");
		query.append(" AND M.MATCHING_STATUS_CD = 'MAPPED'"); 
		query.append(" AND M.PRODUCT_SKU IN (:productSku)");
		
   	    setMappimgStatusFilter(mappingStatus, query, queryParameters);
   	    
   	    query.append(" GROUP BY M.PRODUCT_SKU Order By M.PRODUCT_SKU ");
   	 
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("companyID", companyID);
		q.setParameter("divisionID", divisionID);
		q.setParameter("productSku", results.stream().map(result -> result[0]).collect(Collectors.toList()));
		for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		List<Object[]> upcResults = q.getResultList();
		em.close();
		for(Object[] resultObj :results)
		{
			for(Object[] upcObject : upcResults)
			{
				if(resultObj[0].equals(upcObject[0]))
				{
					resultObj[6]=upcObject[1];
					break;
				}
			}
		}
		
		
		
	}

	/**
	 * @param mappingStatus
	 * @param query
	 */
	private void setMappimgStatusFilter(String mappingStatus,
			StringBuilder query, Map<String,Object> queryParameters) {
		if(null!=mappingStatus && !mappingStatus.isEmpty()){
			if(PerishableSQLConstants.SHOW_ALL.equals(mappingStatus)){
				query.append(" AND M.MATCHING_STATUS_CD  IN ( 'MAPPED' , 'CONVERTED' )");
				query.append(" AND X.CONV_STATUS_CD  IN ('R','S','Q','A','C') ");
			}else if("ADD_MAP".equals(mappingStatus)){
				query.append(" AND M.MATCHING_TYPE_CD  ='ADD_MAP'");
				query.append(" AND X.CONV_STATUS_CD  IN('R','S','Q','A') ");
			}else if("INHERIT_MAP".equals(mappingStatus)){
				query.append(" AND M.MATCHING_TYPE_CD  ='INHERIT_MAP'");
				query.append(" AND X.CONV_STATUS_CD  IN('R','S','Q','A')");
			}else if("BOTH".equals(mappingStatus)){
				query.append(" AND M.MATCHING_TYPE_CD  IN ( 'ADD_MAP','INHERIT_MAP','ETL_AUTO_MATCH')");
				query.append(" AND X.CONV_STATUS_CD  IN('R','S','Q','A') ");
			}
			else if("CONVERTED".equals(mappingStatus)){
				query.append(" AND M.MATCHING_STATUS_CD = 'MAPPED'");  	
				query.append(" AND X.CONV_STATUS_CD IN('C')");
			}
			else{
				query.append(" AND M.MATCHING_STATUS_CD = :mappingStatus"); 
				queryParameters.put(mappingStatus, mappingStatus);
			}
		}
	}

	
 	
	/**
	 * 
	 * Method to update the mapping status in   ITEM_CONV_MANUAL_MATCHING_PLAN  mapping table 
	 * when user selects mapping action as UN_MAPPED
	 * 
	 * @param companyID
	 * @param divisionID
	 * @param sku
	 * @param cic
	 * @param upc
	 * @param mappingType
	 * @param mappingStatus 
	 * @param mappingstatus
	 * @return
	 */
	public boolean updateMappingStatus(String companyID, String divisionID, String sku, String cic,
			String upc, String mappingType, String mappingStatus) {
       
		boolean hasResult=false;
		
		LOG.info("Updating ITEM_CONV_MANUAL_MATCHING_PLAN  records.");	
		StringBuilder queryforEtl=new StringBuilder("");
		StringBuilder queryforManual=new StringBuilder("");
		
		
			queryforEtl .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD= 'UN_MAPPED',CORP_ITEM_CD =0  WHERE MATCHING_STATUS_CD IN( 'MAPPED' ,'CORRECTED' ) AND "
					+ "  COMPANY_ID = :companyID  AND DIVISION_ID = :divisionID AND PRODUCT_SKU= :sku AND MATCHED_ITEM_TYPE_CD  = 'E' AND MATCHING_TYPE_CD = 'ETL_AUTO_MATCH' ");
		
			queryforManual .append("DELETE FROM  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  WHERE MATCHING_STATUS_CD = 'MAPPED' AND ")
				.append("  COMPANY_ID = ?  AND DIVISION_ID = ? AND PRODUCT_SKU = ?  AND MATCHED_ITEM_TYPE_CD in('Y','S','B','E','P' ) AND MATCHING_TYPE_CD IN ('ADD_MAP','INHERIT_MAP') ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(queryforEtl.toString());
		q.setParameter("companyID", companyID);
	    q.setParameter("divisionID", divisionID);
	    q.setParameter("sku", sku);
		int result = q.executeUpdate();
		
		Query q1 = em.createNativeQuery(queryforManual.toString());
		q1.setParameter(1, companyID);
		q1.setParameter(2, divisionID);
		q1.setParameter(3, sku);
		result = q1.executeUpdate();
		
		et.commit();
		LOG.info("Completed Updating   ITEM_CONV_MANUAL_MATCHING_PLAN  records.");
		em.close();
		if(result > 0) {
			hasResult=true;
		}
		return hasResult;
	}
	/**
	 * 
	 * 
	 * **/
	public boolean updateForceNewMappingStatus(String companyID, String divisionID, String sku,
			 String mappingType, String mappingStatus) {

		boolean hasResult=false;
		LOG.info("Updating ITEM_CONV_MANUAL_MATCHING_PLAN  records.");	
		StringBuilder query=new StringBuilder("");
		query .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  SET MATCHING_STATUS_CD = :mappingStatus ,CORP_ITEM_CD=0 "
				+ " WHERE COMPANY_ID = :companyID   AND DIVISION_ID = :divisionID  AND PRODUCT_SKU = "
				+ ":sku AND MATCHING_TYPE_CD= :mappingType AND MATCHING_STATUS_CD is null ");
		
		StringBuilder queryforEtl=new StringBuilder("");
		queryforEtl .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD= 'CORRECTED',CORP_ITEM_CD =0  WHERE MATCHING_STATUS_CD IN( 'UN_MAPPED') AND "
				+ "  COMPANY_ID = :companyID   AND DIVISION_ID = :divisionID  AND PRODUCT_SKU= :sku AND MATCHED_ITEM_TYPE_CD  = 'E' AND MATCHING_TYPE_CD = 'ETL_AUTO_MATCH'  ");
		
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query.toString());
	    q.setParameter("mappingStatus", mappingStatus);
		q.setParameter("companyID", companyID);
	    q.setParameter("divisionID", divisionID);
	    q.setParameter("sku", sku);
	    q.setParameter("mappingType", mappingType);
		int result = q.executeUpdate();
		Query q1 = em.createNativeQuery(queryforEtl.toString());
		q1.setParameter("companyID", companyID);
	    q1.setParameter("divisionID", divisionID);
	    q1.setParameter("sku", sku);
		result = q1.executeUpdate();
		et.commit();
		LOG.info("Completed Updating ITEM_CONV_MANUAL_MATCHING_PLAN  records.");
		em.close();
		if(result > 0) {
			hasResult=true;
		}
		return hasResult;
	}
	
	public List<Object[]> getDepartmentForSource(String companyId, String divisionId) {

		LOG.info("Fetching department records.");
		StringBuilder query=new StringBuilder("");
		query.append("SELECT DISTINCT PROD_HIERARCHY_LVL_4_CD,PROD_HIERARCHY_LVL_5_CD FROM ECFLAND.PRODUCT_HIERARCHY WHERE COMPANY_ID = :companyId");
		query.append(" AND DIVISION_ID  = :divisionId ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department records.");
		em.close();
		return results;
	}

	public List<Object[]> getDepartmentForTarget() {

		LOG.info("Fetching department records.");
		StringBuilder query=new StringBuilder("");
		query.append("SELECT DISTINCT OMD.DEPT_NAME, STRING_AGG(RDS.SECT,',') "
				+ " FROM  SSIMSLAND.SQLDAT3_OMSTRDS  RDS "
				+ " JOIN  SSIMSLAND.SQLDAT3_OMDEPT OMD "
				+ " ON RDS.DEPT = OMD.DEPT "
				+ " GROUP BY OMD.DEPT_NAME  ORDER BY OMD.DEPT_NAME ASC ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department records.");
		em.close();
		return results;
	}

	public List<Object[]> getUpcListDetails(String companyId, String divisionId,String sku,String mappingType,String itemType){
		LOG.info("Fetching totalsales and salesDate corresponding UPC");
		Map<String,Object> queryParameters = new HashMap<>();
		StringBuilder query=new StringBuilder("");
		query.append("SELECT /*+ PARALLEL(4) */ DISTINCT C.UPC,SD.TOTAL_SALES,CAST(SD.last_sale_dt AS DATE) "
          +" FROM ECFLAND.ITEM_AGGREGATE_CORP C"
          +"   LEFT JOIN "
          +" ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD " 
          +"  ON C.COMPANY_ID = SD.COMPANY_ID " 
          +"  AND C.DIVISION_ID = SD.DIVISION_ID  "
          +"  AND C.PRODUCT_SKU = SD.PRODUCT_SKU " 
          +"   AND C.UPC = SD.UPC "
          
             + " LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU "
             + " ON C.COMPANY_ID = MU.COMPANY_ID "
             + " AND C.DIVISION_ID = MU.DIVISION_ID "
             + " AND C.PRODUCT_SKU = MU.PRODUCT_SKU "
             + " AND C.UPC =  MU.SRC_UPC "
             
             + "JOIN XREFLAND.SRC_ITEM_XRF X " 
             + "ON  C.COMPANY_ID = X.COMPANY_ID " 
             + "AND C.DIVISION_ID = X.DIVISION_ID "
             + "AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU " 
             +" and C.UPC= X.SRC_UPC "
             
	      +" LEFT OUTER JOIN"
          +" ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
          +" ON C.COMPANY_ID = P.COMPANY_ID  "
          +" AND C.DIVISION_ID = P.DIVISION_ID  "
          +" AND C.UPC = P.UPC  "
          +" AND C.PRODUCT_SKU = P.PRODUCT_SKU "
          
		  +" WHERE X.CONV_STATUS_CD NOT IN('O','C') "
          + " AND C.MULTI_COMP_ITEM_IND <> 'Y' "
          + " AND ( MU.PRODUCT_SKU IS NULL or(MU.PRODUCT_SKU IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) AND ") ;
		
		query.append(" C.COMPANY_ID= :companyId");
		query.append(" AND C.DIVISION_ID= :divisionId");
        query.append(" AND C.product_sku= :sku");
        setMappingTypeAndItemTypeFilter(mappingType, itemType, query, queryParameters);
  		query.append(" order by SD.TOTAL_SALES,CAST(SD.last_sale_dt AS DATE) desc ");
        
  		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("sku", sku);
		for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching  records.");
		em.close();
		return results;
	}
	
    public  BigDecimal countPerishablesSourceList(Map<String,String> searchCriteria,Map<String,String> filterCriteria)
    {
    	StringBuilder baseQuery=new StringBuilder("");
    	Map<String, Object> queryParameters = new HashMap<>();
   	 baseQuery.append( " SELECT /*+ PARALLEL(4) */ COUNT(distinct c.product_sku)  "
			  + " FROM ECFLAND.ITEM_AGGREGATE_CORP  C "
			  + " LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD "
		      + " ON C.COMPANY_ID = SD.COMPANY_ID "
             + " AND C.DIVISION_ID = SD.DIVISION_ID "
             + " AND C.PRODUCT_SKU = SD.PRODUCT_SKU "
             + " AND C.UPC = SD.UPC "
             
             + " LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU "
             + " ON C.COMPANY_ID = MU.COMPANY_ID "
             + " AND C.DIVISION_ID = MU.DIVISION_ID "
             + " AND C.PRODUCT_SKU = MU.PRODUCT_SKU "
             + " AND C.UPC =  MU.SRC_UPC "
             
             + "JOIN XREFLAND.SRC_ITEM_XRF X " 
             + "ON  C.COMPANY_ID = X.COMPANY_ID " 
             + "AND C.DIVISION_ID = X.DIVISION_ID "
             + "AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU " 
             +" and C.UPC= X.SRC_UPC "
             /*te vendor id and vendor name**/
				
             + "LEFT JOIN "
             + " XREFLAND.DSD_VENDOR_XREF DVX " 
             + "ON X.COMPANY_ID      = DVX.COMPANY_ID "  
             + "AND X.DIVISION_ID    = DVX.DIVISION_ID  " 
             + "AND X.SRC_SUPPLIER_NUM  collate Latin1_General_CS_AS = DVX.VENDOR_ID "                                                                 
             
             + "LEFT JOIN "
             + "XREFLAND.WHSE_VENDOR_XREF WVX "  
             + "ON X.COMPANY_ID      = WVX.COMPANY_ID "  
             + "AND X.DIVISION_ID    = WVX.DIVISION_ID  " 
             + "AND X.SRC_SUPPLIER_NUM = WVX.VENDOR_ID  "
                          /** vendor id end***/
             
             + " LEFT OUTER JOIN  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P"  
             + " ON C.COMPANY_ID = P.COMPANY_ID "  
             + " AND C.DIVISION_ID = P.DIVISION_ID "  
             + " AND C.PRODUCT_SKU = P.PRODUCT_SKU "
             + " AND C.UPC = P.UPC "
            
             + " WHERE X.CONV_STATUS_CD NOT IN('O','C') "
             + " AND C.MULTI_COMP_ITEM_IND <> 'Y' "
             + " AND ( MU.PRODUCT_SKU IS NULL or(MU.PRODUCT_SKU IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) ") ;
    String searchcriteria=createBaseSearchQuery(searchCriteria,queryParameters);

    String  filtercriteria=createfilterQuery(filterCriteria,queryParameters);	
   baseQuery.append(searchcriteria+filtercriteria);
   
   if(searchCriteria != null && searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) &&
		   searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("WHSE_DSD")){
	   if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("WHSE")){
		   baseQuery.append(" AND C.SOURCE_BY_WHSE  ='Y'");
		}
      if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("DSD")){
    	  baseQuery.append(" AND C.SOURCE_BY_DSD  ='Y'");
		}
	   
   }

   EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
   Query q = em.createNativeQuery(baseQuery.toString());
   for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
		q.setParameter(entry.getKey(), entry.getValue());
	}
   Object results = q.getResultList().get(0);
   em.close();
   BigDecimal count=null;
   if(null!=results){
	   count = new BigDecimal((Integer)results);
   }
   return count;
   }
    private List<Object[]> getUpcAggregateList(List<Object[]> resultlist,String companyId, String divisionId,String mappingType, String itemType )
       {
    	Map<String,Object> queryParameters = new HashMap<>();
    	if(resultlist!=null && !resultlist.isEmpty() ){
    	StringBuilder query=new StringBuilder("");
    	query.append( " SELECT /*+ PARALLEL(4) */ DISTINCT "
    			          + " c.product_sku,"
    			          + " STRING_AGG(c.upc, ';')  as UPC_LIST "   
    			          + ", case when X.CONV_STATUS_CD ='D'   then 'MARK_AS_DEAD' ELSE  P.MATCHING_STATUS_CD  end \"MATCHING_STATUS_CD\" " 
    			          +" FROM ECFLAND.ITEM_AGGREGATE_CORP  C "
    			          +" JOIN XREFLAND.SRC_ITEM_XRF X "
                          +"ON  C.COMPANY_ID = X.COMPANY_ID "
                          +"AND C.DIVISION_ID = X.DIVISION_ID "
                          +"AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU "
                          +" and C.UPC= X.SRC_UPC "
                          +"AND X.CONV_STATUS_CD NOT IN('O','C')  "	
                          
    					  + " LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD "
    				      + " ON C.COMPANY_ID = SD.COMPANY_ID  "
    		              + " AND C.DIVISION_ID = SD.DIVISION_ID "
    		              + " AND C.PRODUCT_SKU = SD.PRODUCT_SKU"
    		              + " AND C.UPC = SD.UPC "
    		              
    		              + " LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU "
    		              + " ON C.COMPANY_ID = MU.COMPANY_ID "
    		              + " AND C.DIVISION_ID = MU.DIVISION_ID "
    		              + " AND C.PRODUCT_SKU = MU.PRODUCT_SKU "
    		              + " AND C.UPC =  MU.SRC_UPC "    		              
    	
    				      +" LEFT OUTER JOIN"
    			          +" ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
    			          +"   ON C.COMPANY_ID = P.COMPANY_ID  "
    			          +"    AND C.DIVISION_ID = P.DIVISION_ID  "
    			          +"  AND C.UPC = P.UPC  "
    			          + " AND C.PRODUCT_SKU = P.PRODUCT_SKU "
    			          
    					  +"WHERE "
    					  + " C.MULTI_COMP_ITEM_IND <> 'Y' "
 		                  + " AND ( MU.PRODUCT_SKU IS NULL or(MU.PRODUCT_SKU IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' ))  "     				
    					  + " AND C.COMPANY_ID= :companyId ");
    					query.append(" AND C.DIVISION_ID= :divisionId");
     			        query.append(" ");
    			        setMappingTypeAndItemTypeFilter(mappingType, itemType,query, queryParameters); 
    
    		query.append(" AND C.PRODUCT_SKU IN (:productsku) GROUP BY c.product_sku " + 
    				"	,X.CONV_STATUS_CD " + 
    				"	,CASE  " + 
    				"		WHEN X.CONV_STATUS_CD = 'D' " + 
    				"			THEN 'MARK_AS_DEAD' " + 
    				"		ELSE P.MATCHING_STATUS_CD " + 
    				"		END");
    	 
      	EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString() );
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setParameter("productsku", resultlist.stream().map(result -> result[0]).collect(Collectors.toList()));
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		
		
		List<Object[]> results = q.getResultList();
		
		em.close();
		appendResultListWithUPC(resultlist, results);
		getProduceRelatedData(companyId,  divisionId,resultlist);
		
    	}
		return resultlist;        
    	
    }
    /**
	 * @param resultlist
	 * @param results
	 */
	private void appendResultListWithUPC(List<Object[]> resultlist, List<Object[]> upcResults) {
		for (Object[] skuObjO : resultlist) {
			for (Object[] skuObj : upcResults) {

				if (skuObjO[0].equals(skuObj[0]) && isMapStatusEqual(skuObjO[9], skuObj[2])) {					
						if(skuObjO[3]==null)
						skuObjO[3] = skuObj[1];
						else
						{skuObjO[3] = skuObjO[3]+";"+skuObj[1];}
					 
				}

			}
		}
	}
	/**
	 * 
	 * @param object
	 * @param object2
	 * @return
	 */
	private boolean isMapStatusEqual(Object object, Object object2) {		
		return  (object != null && object2 != null && object.equals(object2) )|| (object == null && object2 == null);
	}
	/**
	 * @param mappingType
	 * @param itemType
	 * @param query
	 */
	private void setMappingTypeAndItemTypeFilter(String mappingType,
			String itemType, StringBuilder query, Map<String,Object> queryParameters) {
		if(null!= mappingType && !( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) || PerishableSQLConstants.SHOW_ALL.equals(mappingType))){
		    if(PerishableSQLConstants.TO_BE_MAPPED.equals(mappingType)){
		    	query.append(PerishableSQLConstants.AND_P_MACHING_STATUS_CD);
		    	query.append(PerishableSQLConstants.IS_NULL);	
		    	query.append(" OR P.MATCHING_STATUS_CD ='UN_MAPPED' ");
		    	query.append(" ) ");
		    }
		    else if(mappingType.equals(PerishableSQLConstants.RESERVED))
		    {

		    	query.append(" AND P.MATCHING_STATUS_CD");
		    	query.append(" IN ( '"+PerishableSQLConstants.AWAITING_CIC+"',");
		    	query.append(" '"+PerishableSQLConstants.AWAITING_DIVISION+"',");
		    	query.append(" '"+PerishableSQLConstants.OTHER+"' )");
		    	query.append(" AND P.MATCHED_ITEM_TYPE_CD in ('Y','E','P') ");
		    
		    }
		else{
		    query.append(" AND P.MATCHING_STATUS_CD= :mappingType");
		    query.append(" AND P.MATCHED_ITEM_TYPE_CD in('Y','E','P' )");
		    queryParameters.put("mappingType", mappingType);
		  }
		    
		}
		 if(null!= mappingType && !( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) || PerishableSQLConstants.SHOW_ALL.equals(mappingType))){
		    	query.append(" AND X.CONV_STATUS_CD NOT IN('D')");
		    }
		 
		 if(null!= mappingType && ( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) )){
		    	query.append(" AND X.CONV_STATUS_CD  IN('D')");
		    	query.append("AND P.MATCHING_STATUS_CD = 'MARK_AS_DEAD'");
		    }
		 /*
		 
		  if(null!=itemType){
			 if(itemType.equals(PerishableSQLConstants.SYSTEM2))
			 {					
				 query.append(" and X.SRC_UPC_SYSTEM =2 ");
			}
			else if(itemType.equals(PerishableSQLConstants.SYSTEM4))
			{
				 
				query.append(" and X.SRC_UPC_SYSTEM =4 ");
			}
			else if(itemType.equals("PLU"))
			{	
				query.append(" AND X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND X.SRC_UPC_SALES > 0 ");
			}
		  }
		  
		  */
	}
	public List<String> addtionalDetailsForDto(String companyId, String divisionId,
			String productSku) {
		StringBuilder query=new StringBuilder("  select C.case_upc from  ECFLAND.ITEM_AGGREGATE_CORP C where C.company_id =? and "
				+ " C.division_id =? and C.product_sku = ? ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter(1, companyId);
		q.setParameter(2, divisionId);
		q.setParameter(3, productSku);
		List<String> results = q.getResultList();
		em.close();
	 return 	results;
		
	}

	/**
	 *Method to update conversion status in  XREFLAND.SRC_ITEM_XRF table
	 * @param pm
	 */
	public boolean updateStatusForMappingAction(Object[] inputs) {
		
		boolean hasResult=false;
		
		StringBuilder query=new StringBuilder("");
		query.append("Update XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD ='R',CONV_STATUS_SUB_CD ='A', STATUS_REASON_TXT ='Ready to process',CONV_STATUS_DSC='Ready' Where COMPANY_ID =");
		query.append(":companyId");
		query.append(" AND DIVISION_ID= ");
		query.append(":divisionId");
		query.append(" AND SRC_PRODUCT_SKU =");
		query.append(":productSku");
		query.append(" AND SRC_UPC_COUNTRY =");
		query.append(":upcCountry");
		query.append(" AND SRC_UPC_SYSTEM =");
		query.append(":upcSystem");
		query.append(" AND SRC_UPC_MANUF =");
		query.append(":upcManuf");
		query.append(" AND  SRC_UPC_SALES =");
		query.append(":upcSales");
		query.append(" AND CORP_ITEM_CD is null "); 

		StringBuilder queryforEtl=new StringBuilder("");
		queryforEtl .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD= 'CORRECTED',CORP_ITEM_CD =0  WHERE MATCHING_STATUS_CD IN( 'UN_MAPPED','AWAITING_NEW_CIC','AWAITING_DIVISION_INPUT','OTHERS') AND "
				+ "  COMPANY_ID = :companyId  AND DIVISION_ID = :divisionId AND PRODUCT_SKU= :productSku AND MATCHED_ITEM_TYPE_CD  = 'E' AND MATCHING_TYPE_CD = 'ETL_AUTO_MATCH'  ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		        EntityTransaction et = em.getTransaction();
	        et.begin();
	        Query q = em.createNativeQuery(query.toString());
	        q.setParameter("companyId", inputs[0]);
	        q.setParameter("divisionId", inputs[1]);
	        q.setParameter("productSku", inputs[2]);
	        q.setParameter("upcCountry", inputs[3]);
	        q.setParameter("upcSystem", inputs[4]);
	        q.setParameter("upcManuf", inputs[5]);
	        q.setParameter("upcSales", inputs[6]);
	        int result = q.executeUpdate();
	    	Query q1 = em.createNativeQuery(queryforEtl.toString());
	    	q1.setParameter("companyId", inputs[0]);
	        q1.setParameter("divisionId", inputs[1]);
	        q1.setParameter("productSku", inputs[2]);
			result = q1.executeUpdate();
	        et.commit();
	        LOG.info("Completed Updating SRC_ITEM_XREF records.");
	        em.close();
	        if(result>0){
	        	hasResult=true;
	        }
	        return hasResult;
	}

	/**
	 * 
	 * Method to update  unmap action   as 'E' 'U' User Action Pending' status in  XREFLAND.SRC_ITEM_XRF table	 
	 * @param inputs
	 */
	public boolean updateStatusForUnMapAction(Object[] inputs) {
		
		boolean hasResult=false;
		
		StringBuilder query=new StringBuilder("");
		query.append("Update XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD ='E',CONV_STATUS_SUB_CD ='U', STATUS_REASON_TXT ='User Action Pending',CONV_STATUS_DSC='Valid' Where COMPANY_ID =");
		query.append(":companyId");
		query.append(" AND DIVISION_ID= ");
		query.append(":divisionId");
		query.append(" AND SRC_PRODUCT_SKU =");
		query.append(":productSku");
		query.append(" AND SRC_UPC_COUNTRY =");
		query.append(":upcCountry");
		query.append(" AND SRC_UPC_SYSTEM =");
		query.append(":upcSystem");
		query.append(" AND SRC_UPC_MANUF =");
		query.append(":upcManuf");
		query.append(" AND  SRC_UPC_SALES =");
		query.append(":upcSales");

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		        EntityTransaction et = em.getTransaction();
	        et.begin();
	        Query q = em.createNativeQuery(query.toString());
	        q.setParameter("companyId", inputs[0]);
	        q.setParameter("divisionId", inputs[1]);
	        q.setParameter("productSku", inputs[2]);
	        q.setParameter("upcCountry", inputs[3]);
	        q.setParameter("upcSystem", inputs[4]);
	        q.setParameter("upcManuf", inputs[5]);
	        q.setParameter("upcSales", inputs[6]);
	        int result = q.executeUpdate();
	        et.commit();
	        LOG.info("Completed Updating SRC_ITEM_XREF records.");
	        em.close();
	        if(result>0){
	        	hasResult=true;
	        }
	        return hasResult;
	}
	
	/**
	 * Method to check UPC match available in target side to redirect force new action to augmentation/override
	 * @param perishableItemCreateMatchCicDto
	 * @return
	 */
	public boolean isUPCMatchAvailableInTarget(Object[] inputs) {

		
		StringBuilder query=new StringBuilder("");
		boolean hasResult=false;
		query.append("Select CDS.CORP_ITEM_CD From SSIMSLAND.SQLDAT3_SSITMXRF XRF "
				+ "JOIN SSIMSLAND.SQLDAT3_SSITMCDS CDS"
				+" ON XRF.CORP_ITEM_CD=CDS.CORP_ITEM_CD "
				+ " LEFT OUTER JOIN SSIMSLAND.SQLDAT3_SSITMPOS POS" 
				+" ON POS.UPC_MANUF = XRF.UPC_MANUF" 
                +" AND POS.UPC_SALES = XRF.UPC_SALES" 
                +" AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY"
                +" AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  where ");
		query.append(" XRF.UPC_COUNTRY= ?");
		query.append(" AND XRF.UPC_SYSTEM= ?");
		query.append(" AND XRF.UPC_MANUF = ?");
		query.append(" AND XRF.UPC_SALES= ?");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter(1, inputs[0]);
		q.setParameter(2, inputs[1]);
		q.setParameter(3, inputs[2]);
		q.setParameter(4, inputs[3]);
		List<Object[]> results = q.getResultList();
		
		em.close();
		if(results!=null && !results.isEmpty()){
			hasResult=true;
		}
		return hasResult;
	
	}

	public BigDecimal countPerishablesTargetList(
			Map<String, String> searchCriteria,
			Map<String, String> filterCriteria) {
		
		Map<String, Object> queryParameters = new HashMap<>();
		StringBuilder baseQueryJoin1 = new StringBuilder("SELECT /*+ PARALLEL(4)  */ count (DISTINCT CDS.CORP_ITEM_CD) "
				+ "FROM SSIMSLAND.SQLDAT3_SSITMCDS CDS "
				+"JOIN SSIMSLAND.SQLDAT3_SSITMXRF XRF "
				+ "ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD "
						
				+"LEFT OUTER JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS "
				+"ON POS.UPC_MANUF = XRF.UPC_MANUF "
				+"AND POS.UPC_SALES = XRF.UPC_SALES "
				+"AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY "
				+"AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  "
				
				+"  JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS "
				+" ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD "
				
				+"JOIN SSIMSLAND.SQLDAT3_OMSTRDS RDS "
				+"ON CDS.RETAIL_SECT = RDS.SECT "
				
				+"JOIN  SSIMSLAND.SQLDAT3_OMDEPT OMDEPT "
				+"ON OMDEPT.DEPT = RDS.DEPT "
				
				+" LEFT JOIN "+defaultSchema+".ITEM_CONV_ITEM_VENDOR_XRF VRF "
				+"ON CDS.CORP_ITEM_CD = VRF.CORP_ITEM_CD ");
				
						
			String baseQueryJoin2 ="LEFT OUTER JOIN  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
				+"ON CDS.CORP_ITEM_CD = P.CORP_ITEM_CD "
				
				+"WHERE CDS.STATUS_CORP <> 'D' ";
		
			
	
 
		String searchcriteria = createTargetSearchQuery(searchCriteria,queryParameters);
		String filtercriteria = createTargetFilterQuery(filterCriteria,queryParameters);
		
    
		StringBuilder query = baseQueryJoin1.append(baseQueryJoin2).append(searchcriteria ).append( filtercriteria.replaceAll("ORDER BY CDS.CORP_ITEM_CD", ""));
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		for(Map.Entry<String, Object> entry : queryParameters.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		Object results = q.getResultList().get(0);
		   em.close();
		   BigDecimal count=null;
		   if(null!=results){
			   count = new BigDecimal((Integer)results);
		   }
		   return count;
		  
	}
	
	private List<Object[]> getProduceRelatedData(String company, String division,
			List<Object[]>  resultlist) {
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append(" select distinct rog.product_Sku, selling_method_cd, ");
		baseQuery.append(" case when whse.receive_random_ind is not null then whse.receive_random_ind ");
		baseQuery.append(" when dsd.receive_random_ind is not null then dsd.receive_random_ind end \"RANDOM_IND\" ");
		baseQuery.append(" from ecfland.item_aggregate_rog rog ");
		baseQuery.append("  LEFT JOIN ecfland.item_aggregate_whse whse on ");
		baseQuery.append(" rog.company_id =whse.company_id and rog.division_id =whse.division_id ");
		baseQuery.append(" and rog.product_sku =whse.product_Sku ");
		baseQuery.append(" LEFT JOIN ecfland.item_aggregate_dsd dsd on ");
		baseQuery.append("rog.company_id =dsd.company_id and rog.division_id =dsd.division_id");
		baseQuery.append(" and  rog.product_sku =dsd.product_Sku");
		baseQuery.append(" where rog.company_id = :company ");
		baseQuery.append( "and rog.division_id =:division ");
		baseQuery.append(" and rog.product_Sku IN ( :productsku )");
		
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("productsku", resultlist.stream().map(result -> result[0]).collect(Collectors.toList()));
		
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		List<Object[]> produceResults = q.getResultList();
		LOG.info("");
		em.close();
		appendProduceRelatedData(resultlist,produceResults);
		return resultlist;
	}

	private void appendProduceRelatedData(List<Object[]> resultlist,
			List<Object[]> produceResults) {
		for (Object[] skuObjO : resultlist) {
			for (Object[] produceObj : produceResults) {

				if (skuObjO[0].equals(produceObj[0]) ) {					
						
						skuObjO[26] = produceObj[1];
						skuObjO[27] = produceObj[2];
					 break;
				}

			}
		}
	}
	
}