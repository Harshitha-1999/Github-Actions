package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/* ***************************************************************************
 * NAME : ItemConvManualMatchingPlan 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U62616 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  Mar 09, 2018 sgang06 - Initial Creation
 * *************************************************************************
 */

@Entity
@Table(name="ITEM_CONV_MANUAL_MATCHING_PLAN" ,schema="ECFLAND")
public class ItemConvManualMatchingPlan implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ItemConvManualMatchingPlanPK itemConvManualMatchingPlanPk;
	
	@Column(name = "CORP_ITEM_CD")
	private BigDecimal corpItemCd;
		
	@Column(name = "MATCHING_TYPE_CD")
	private String mappingType;
	
	@Column(name = "MATCHING_STATUS_CD")
	private String mappingStatus;
	
	@Column(name = "MATCHING_COMMENTS_TXT")
	private String mappingComments;

	

	@Column(name ="MATCH_DT")
	@Temporal(TemporalType.DATE)
	private Date matchDate;
	
	@Column(name ="LAST_UPDATE_TS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateTs;
	
	@Column(name ="UPDATE_USER_ID")
	private String updateUserId;
	
	@Column(name ="TARGET_PLU")
	private String targetPlu;

	
	@Column(name ="DC_PACK_DESC")
	private String packDesc;
	
	@Column(name ="DC_SIZE_DESC")
	private String sizeDesc;
	
	@Column(name ="RETAIL_UNIT_PACK")
	private String retailUnitPack;
	
	@Column(name ="RING")
	private String ring;
	
	@Column(name ="HICONE")
	private String hicone;
	
	
	@Column(name="PROD_WGHT")
	private String prodwght;
	
	@Column(name="HANDLING_CODE")
	private String handlingCode;
	
	@Column(name="DC_BUYER_NUM")
	private String buyerNum;
	
	@Column(name="RANDOM_WT_CD")
	private String randomWtCd;	
	
	@Column(name="AUTO_COST_INV")
	private String autoCostInv; 
	
	@Column(name="BILLING_TYPE")
	private String billingType;
	
	@Column(name="FD_STMP")
	private String fdStmp;
	
	@Column(name="TARE_CD")
	private String tareCd;
	
	@Column(name="label_size")
	private String labelSize;
	
	@Column(name="label_numbers")
	private String labelNumbers;
	
	@Column(name="prc_type_cd")
	private String prcTypeCd;
	
	@Column(name="SGN_COUNT1")
	private String sgnCount1;
	
	@Column(name="SGN_COUNT2")
	private String sgnCount2;
	
	@Column(name="SGN_COUNT3")
	private String sgnCount3;
	
	@Column(name="SELL_BY_DAYS")
	private String sellByDays;
	
	@Column(name="EAT_BY_DAYS")
	private String eatByDays;
	
	@Column(name="PULL_BY_DAYS")
	private String pullByDays;
	
	@Column(name="COST_VEND")
	private String costVend;
	
	@Column(name="COST_IB")
	private String costIb;
	
	@Column(name="COST_INV")
	private String costInv;
	
	@Column(name="COST_ALLOW")
	private String costAllow;
	
	
	public ItemConvManualMatchingPlanPK getItemConvManualMatchingPlanPK() {
		return itemConvManualMatchingPlanPk;
	}

	public void setItemConvManualMatchingPlanPK(
			ItemConvManualMatchingPlanPK itemConvManualMatchingPlanPK) {
		this.itemConvManualMatchingPlanPk = itemConvManualMatchingPlanPK;
	}


	public BigDecimal getCorpItemCd() {
		return corpItemCd;
	}

	public void setCorpItemCd(BigDecimal corpItemCd) {
		this.corpItemCd = corpItemCd;
	}

	public String getMappingType() {
		return mappingType;
	}

	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}

	public String getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public String getMappingComments() {
		return mappingComments;
	}

	public void setMappingComments(String mappingComments) {
		this.mappingComments = mappingComments;
	}

	
	public Date getMatchDate() {
		return matchDate;
	}

	public void setMatchDate(Date matchDate) {
		this.matchDate = matchDate;
	}

	public Date getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getTargetPlu() {
		return targetPlu;
	}

	public void setTargetPlu(String targetPlu) {
		this.targetPlu = targetPlu;
	}
	
	public String getPackDesc() {
		return packDesc;
	}

	public void setPackDesc(String packDesc) {
		this.packDesc = packDesc;
	}

	public String getSizeDesc() {
		return sizeDesc;
	}

	public void setSizeDesc(String sizeDesc) {
		this.sizeDesc = sizeDesc;
	}

	
	

	public String getBuyerNum() {
		return buyerNum;
	}

	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}

	public String getRandomWtCd() {
		return randomWtCd;
	}

	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}

	public String getAutoCostInv() {
		return autoCostInv;
	}

	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	

	public ItemConvManualMatchingPlanPK getItemConvManualMatchingPlanPk() {
		return itemConvManualMatchingPlanPk;
	}

	public void setItemConvManualMatchingPlanPk(
			ItemConvManualMatchingPlanPK itemConvManualMatchingPlanPk) {
		this.itemConvManualMatchingPlanPk = itemConvManualMatchingPlanPk;
	}

	public String getRetailUnitPack() {
		return retailUnitPack;
	}

	public void setRetailUnitPack(String retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}

	public String getRing() {
		return ring;
	}

	public void setRing(String ring) {
		this.ring = ring;
	}

	public String getHicone() {
		return hicone;
	}

	public void setHicone(String hicone) {
		this.hicone = hicone;
	}
	
	public String getProdwght() {
		return prodwght;
	}

	public void setProdwght(String prodwght) {
		this.prodwght = prodwght;
	}

	public String getHandlingCode() {
		return handlingCode;
	}

	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}

	public String getFdStmp() {
		return fdStmp;
	}

	public void setFdStmp(String fdStmp) {
		this.fdStmp = fdStmp;
	}

	public String getTareCd() {
		return tareCd;
	}

	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}

	public String getLabelNumbers() {
		return labelNumbers;
	}

	public void setLabelNumbers(String labelNumbers) {
		this.labelNumbers = labelNumbers;
	}

	public String getSgnCount1() {
		return sgnCount1;
	}

	public void setSgnCount1(String sgnCount1) {
		this.sgnCount1 = sgnCount1;
	}

	public String getSgnCount2() {
		return sgnCount2;
	}

	public void setSgnCount2(String sgnCount2) {
		this.sgnCount2 = sgnCount2;
	}

	public String getSgnCount3() {
		return sgnCount3;
	}

	public void setSgnCount3(String sgnCount3) {
		this.sgnCount3 = sgnCount3;
	}

	public String getSellByDays() {
		return sellByDays;
	}

	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}

	public String getEatByDays() {
		return eatByDays;
	}

	public void setEatByDays(String eatByDays) {
		this.eatByDays = eatByDays;
	}

	public String getPullByDays() {
		return pullByDays;
	}

	public void setPullByDays(String pullByDays) {
		this.pullByDays = pullByDays;
	}

	public String getCostVend() {
		return costVend;
	}

	public void setCostVend(String costVend) {
		this.costVend = costVend;
	}

	public String getCostIb() {
		return costIb;
	}

	public void setCostIb(String costIb) {
		this.costIb = costIb;
	}

	public String getCostInv() {
		return costInv;
	}

	public void setCostInv(String costInv) {
		this.costInv = costInv;
	}

	public String getCostAllow() {
		return costAllow;
	}

	public void setCostAllow(String costAllow) {
		this.costAllow = costAllow;
	}

	public String getLabelSize() {
		return labelSize;
	}

	public void setLabelSize(String labelSize) {
		this.labelSize = labelSize;
	}

	

	public String getPrcTypeCd() {
		return prcTypeCd;
	}

	public void setPrcTypeCd(String prcTypeCd) {
		this.prcTypeCd = prcTypeCd;
	}

	

}
