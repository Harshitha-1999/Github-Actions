package com.safeway.app.memi.domain.util;

import java.io.Serializable;
import java.util.Comparator;

import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

public class ExcelSortSeqComparator implements Comparator<UIExceptionSrcDto>, Serializable {

	private static final long serialVersionUID = 1L;

	@Override
	public int compare(UIExceptionSrcDto left, UIExceptionSrcDto right) {
		if (left == null && right == null)
			return 0;
		if (left == null)
			return -1;
		if (right == null)
			return 1;
		return Comparator
				.comparing(UIExceptionSrcDto::getCategoryDesc, Comparator.nullsFirst(Comparator.naturalOrder()))
				.thenComparing(UIExceptionSrcDto::getSubCategoryDesc, Comparator.nullsFirst(Comparator.naturalOrder()))
				.thenComparing(UIExceptionSrcDto::getGroupDesc, Comparator.nullsFirst(Comparator.naturalOrder()))
				.thenComparing(UIExceptionSrcDto::getProductSKU, Comparator.nullsFirst(Comparator.naturalOrder()))
				.thenComparing(UIExceptionSrcDto::getUpc, Comparator.nullsFirst(Comparator.naturalOrder()))
				.compare(left, right);
	}
}
