package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Set;

public class DisplayItemUnMapDto {
	private String companyId;
	private String divisionId;
	private String productSku;
	private BigDecimal upcCountry;
	private BigDecimal upcSystem;
	private BigDecimal upcManuf;
	private BigDecimal upcSales;
	private String convStatusCode;
	private Set<String> convStatusCodeSet;

	public Set<String> getConvStatusCodeSet() {
		return convStatusCodeSet;
	}

	public void setConvStatusCodeSet(Set<String> convStatusCodeSet) {
		this.convStatusCodeSet = convStatusCodeSet;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSku() {
		return productSku;
	}

	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}

	public BigDecimal getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(BigDecimal upcCountry) {
		this.upcCountry = upcCountry;
	}

	public BigDecimal getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(BigDecimal upcSystem) {
		this.upcSystem = upcSystem;
	}

	public BigDecimal getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(BigDecimal upcManuf) {
		this.upcManuf = upcManuf;
	}

	public BigDecimal getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(BigDecimal upcSales) {
		this.upcSales = upcSales;
	}

	public String getConvStatusCode() {
		return convStatusCode;
	}

	public void setConvStatusCode(String convStatusCode) {
		this.convStatusCode = convStatusCode;
	}

	@Override
	public String toString() {
		return "DisplayItemUnMapDto [companyId=" + companyId + ", divisionId="
				+ divisionId + ", productSku=" + productSku + ", upcCountry="
				+ upcCountry + ", upcSystem=" + upcSystem + ", upcManuf="
				+ upcManuf + ", upcSales=" + upcSales + ", convStatusCode="
				+ convStatusCode + ", convStatusCodeSet=" + convStatusCodeSet
				+ "]";
	}

}
