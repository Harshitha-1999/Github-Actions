package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entity class for Database table ITEM_CONV_SALES_SHIP_DATA.
 * 
 */
@Entity
@Table(name = "ITEM_CONV_SALES_SHIP_DATA", schema="ECFLAND")
@NamedQuery(name = "SalesShip.findAll", query = "SELECT s FROM SalesShip s")
public class SalesShip implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SalesShipPk salesShipPk;

	@Column(name = "ITEM_SETUP_DT")
	@Temporal(TemporalType.DATE)
	private Date itemSetupDate;
	
	@Column(name = "LAST_SHIP_DT")
	@Temporal(TemporalType.DATE)
	private Date lastShipDate;
	
	@Column(name = "LAST_SALE_DT")
	@Temporal(TemporalType.DATE)
	private Date lastSaleDate;
	
	@Column(name = "TOTAL_SALES")
	private BigDecimal totalSales;

	@Column(name = "ON_ORDER_QTY ")
	private BigDecimal casesOrdrd;

	public SalesShipPk getSalesShipPk() {
		return salesShipPk;
	}

	public void setSalesShipPk(SalesShipPk salesShipPk) {
		this.salesShipPk = salesShipPk;
	}

	public Date getItemSetupDate() {
		return itemSetupDate;
	}

	public void setItemSetupDate(Date itemSetupDate) {
		this.itemSetupDate = itemSetupDate;
	}

	public Date getLastShipDate() {
		return lastShipDate;
	}

	public void setLastShipDate(Date lastShipDate) {
		this.lastShipDate = lastShipDate;
	}

	public Date getLastSaleDate() {
		return lastSaleDate;
	}

	public void setLastSaleDate(Date lastSaleDate) {
		this.lastSaleDate = lastSaleDate;
	}

	public BigDecimal getTotalSales() {
		return totalSales;
	}

	public void setTotalSales(BigDecimal totalSales) {
		this.totalSales = totalSales;
	}

	public BigDecimal getCasesOrdrd() {
		return casesOrdrd;
	}

	public void setCasesOrdrd(BigDecimal casesOrdrd) {
		this.casesOrdrd = casesOrdrd;
	}

	@Override
	public String toString() {
		return "SalesShip [salesShipPk=" + salesShipPk + ", itemSetupDate="
				+ itemSetupDate + ", lastShipDate=" + lastShipDate
				+ ", lastSaleDate=" + lastSaleDate + ", totalSales="
				+ totalSales + ", casesOrdrd=" + casesOrdrd + "]";
	}
	
}