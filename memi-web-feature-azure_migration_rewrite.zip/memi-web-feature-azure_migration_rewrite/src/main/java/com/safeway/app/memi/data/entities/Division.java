package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : Division 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************/
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * Entity class for Database table DIVISION.
 * 
 */
@Entity
@Table(name = "DIVISION", schema="ECFLAND")
@NamedQuery(name = "Division.findAll", query = "SELECT s FROM Division s")
public class Division implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "DIVISION_ID")
	private String divisionId;

	@Column(name = "DIVISION_NM")
	private String divisionNM;

	@Column(name = "DIVISION_LEGAL_NM")
	private String divisionLegalNM;

	@Column(name = "DIVISION_ACTIVE_IND")
	private String divisionActiveInd;

	@Column(name = "COMPANY_ID")
	private String companyid;

	public String getDivisionNM() {
		return divisionNM;
	}

	public void setDivisionNM(String divisionNM) {
		this.divisionNM = divisionNM;
	}

	public String getDivisionLegalNM() {
		return divisionLegalNM;
	}

	public void setDivisionLegalNM(String divisionLegalNM) {
		this.divisionLegalNM = divisionLegalNM;
	}

	public String getDivisionActiveInd() {
		return divisionActiveInd;
	}

	public void setDivisionActiveInd(String divisionActiveInd) {
		this.divisionActiveInd = divisionActiveInd;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getCompanyid() {
		return companyid;
	}

	public void setCompanyid(String companyId) {
		this.companyid = companyId;
	}

}