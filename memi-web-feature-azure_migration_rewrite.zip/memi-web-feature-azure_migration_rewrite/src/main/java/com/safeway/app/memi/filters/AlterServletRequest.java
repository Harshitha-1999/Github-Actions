
package com.safeway.app.memi.filters;	

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class AlterServletRequest extends HttpServletRequestWrapper {
	
	public static String swyOSSOCookie = "swyEntDirectoryPro";
	private Map<String, String> customHeaderMap = null;
	
	public AlterServletRequest(HttpServletRequest request) {
		super(request);
		customHeaderMap = new HashMap<String, String>();
	}
	
	@Override
	public String getHeader(String name) {
		HttpServletRequest request = (HttpServletRequest) getRequest();

		if (name.equalsIgnoreCase(swyOSSOCookie)) {
			Cookie[] cookies = request.getCookies();

			if (cookies == null) {
				return null;
			}
			// iterate over cookies
			for (int i = 0; i < cookies.length; i++) {
				Cookie c = cookies[i];
				if (c.getName().equalsIgnoreCase(swyOSSOCookie)) {
					String val = cookies[i].getValue();
					return val;
				}
			}

		}
		return request.getHeader(name);
	}
	
	public Enumeration<String> getHeaderNames() {
		List<String> headerList = new ArrayList<String>();

		HttpServletRequest request = (HttpServletRequest) getRequest();
		Enumeration<String> e = request.getHeaderNames();
		while (e.hasMoreElements()) {
			String headerName = (String) e.nextElement();

			headerList.add(headerName);
		}

		// Also, add the custom header name to the request
		headerList.add(swyOSSOCookie);
		Enumeration<String> en = Collections.enumeration(headerList);

		return en;
	}
	
	public void addHeader(String name, String value) {
		customHeaderMap.put(name, value);
	}
}
