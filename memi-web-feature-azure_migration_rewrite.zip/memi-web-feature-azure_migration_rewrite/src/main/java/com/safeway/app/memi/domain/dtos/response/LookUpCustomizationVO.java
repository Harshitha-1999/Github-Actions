package com.safeway.app.memi.domain.dtos.response;

import java.io.Serializable;
import java.util.List;

public class LookUpCustomizationVO implements Serializable {

	private String userId;
	private List<ColumnVO> columnList;
	private List<ColumnVO> availableList;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	public List<ColumnVO> getColumnList() {
		return columnList;
	}
	public void setColumnList(List<ColumnVO> columnList) {
		this.columnList = columnList;
	}
	public List<ColumnVO> getAvailableList() {
		return availableList;
	}
	public void setAvailableList(List<ColumnVO> availableList) {
		this.availableList = availableList;
	}
	
	
	
	
	
}

class ColumnVO implements Serializable
{
	private String label;
	private String width;
	private String id;
	private String product;
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	
	
}