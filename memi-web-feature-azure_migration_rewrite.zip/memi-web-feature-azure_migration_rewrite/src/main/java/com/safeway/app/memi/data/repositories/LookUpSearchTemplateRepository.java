package com.safeway.app.memi.data.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.safeway.app.memi.data.entities.LookUpSearchObjectTemplate;


public interface LookUpSearchTemplateRepository extends JpaRepository<LookUpSearchObjectTemplate, Long> {

	
	@Query
	List<LookUpSearchObjectTemplate> findByUserId(String userId);
}
