/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.adapters;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedItemVO;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRetailScanDetails;
import com.safeway.app.memi.domain.dtos.response.PerishableSKUSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableUPCwisedDetails;
import com.safeway.app.memi.domain.util.PerishableConstants;

/**
 ****************************************************************************
 * NAME			: PerishablesAdapter 
 * 
 * DESCRIPTION	: PerishablesAdapter is the class for 
 * 				  mapping values fetched from DB to corresponding VO object
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U62616
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 07, 2018  - Initial Creation
 * *************************************************************************
 */

public class PerishablesAdapter {
    /**
     * Method to set values to source item list
     * @param perishableSKUSearchResults
     * @return
     */
	public List<PerishableSKUSearchResults> mapSourceItem(List<Object[]> perishableSKUSearchResults) {

		List<PerishableSKUSearchResults> skuSearchResults = new ArrayList<PerishableSKUSearchResults>();

		for (Object[] skuObj : perishableSKUSearchResults) {
			PerishableSKUSearchResults skuResult = new PerishableSKUSearchResults();
			
			String[] upcArray = parseUpc((skuObj[3] != null ? skuObj[3] : null));
			String pluList =appendPlus(upcArray);

			skuResult.setSku(getStringValue((skuObj[0] != null ? skuObj[0] : null)));
			skuResult.setItemDesc(getStringValue((skuObj[1] != null ? skuObj[1] : null)));
			skuResult.setSize(getStringValue((skuObj[2] != null ? skuObj[2] : null)));
			skuResult.setUpc(parseUpc((skuObj[3] != null ? skuObj[3] : null)));
			skuResult.setAbsUPCNo(upcArray!= null && upcArray.length>0 ? upcArray[0] : null);
			skuResult.setDisplay(getStringValue((skuObj[4] != null ? skuObj[4] : null)));
			skuResult.setAbsDSDWhse(getStringValue((skuObj[5] != null ? skuObj[5] : null)));
			skuResult.setDeptName(getStringValue((skuObj[6] != null ? skuObj[6] : null)));
			skuResult.setUpdateUser(getStringValue((skuObj[7] != null ? skuObj[7] : null)));
	    	skuResult.setVcf((BigDecimal) (skuObj[8] != null ? skuObj[8] : null));
			if((skuObj[9]) == null || ("UN_MAPPED").equals(skuObj[9])){
				skuResult.setMappingStatus(PerishableConstants.TO_BE_MAPPED);
			}else{
				skuResult.setMappingStatus(getStringValue(skuObj[9]));
			}
	    	skuResult.setSizeNumber((BigDecimal) (skuObj[10] != null ? skuObj[10] : null));
	    	skuResult.setCreatedOn(parseDate((Timestamp)(skuObj[11] != null ? skuObj[11] : null)));
	    	skuResult.setPackNum((BigDecimal) (skuObj[12] != null ? skuObj[12] : null));
	    	skuResult.setUsage(convertToChar((skuObj[13] != null ? skuObj[13] : null)));	    	
	    	skuResult.setHierarchyLevelOne(getStringValue((skuObj[14] != null ? skuObj[14] : null)));	 
	    	skuResult.setHierarchyLevelTwo(getStringValue((skuObj[15] != null ? skuObj[15] : null)));	
	    	skuResult.setHierarchyLevelThree(getStringValue((skuObj[16] != null ? skuObj[16] : null)));	
	  	
	    	skuResult.setLastShipdate(parseDate((Timestamp)(skuObj[17] != null ? skuObj[17] : null)));
	    	
	    	skuResult.setOnHand(skuObj[18] != null ? BigDecimal.valueOf((Double)skuObj[18]) : null);
	    	skuResult.setOnOrder(skuObj[19] != null ? BigDecimal.valueOf((Double)skuObj[19]) : null);
	    	
	    	skuResult.setSlot(getStringValue((skuObj[20] != null ? skuObj[20] : null)));	 
	    	skuResult.setUsage_Modification_Status(getStringValue((skuObj[21] != null ? skuObj[21] : null)));
	    	
	    	skuResult.setSupplierNm(getStringValue (skuObj[22] != null ? skuObj[22] : null));
	    	skuResult.setSupplierNam(getStringValue((skuObj[23] != null ? skuObj[23] : null)));
	    	skuResult.setCaseUpc(getStringValue((skuObj[24] != null ? skuObj[24] : null)));
	    	skuResult.setSizeUomCd(getStringValue((skuObj[25] != null ? skuObj[25] : null)));
	    		    	
	    	if(skuObj[26]!=null && getStringValue(skuObj[26]).equalsIgnoreCase("W") )
	    		skuResult.setSellingMethodCd("POUND");	
			else if(skuObj[26]!=null && getStringValue(skuObj[26]).equalsIgnoreCase("E") )
				skuResult.setSellingMethodCd("EACH");
	    	
	    	if(skuObj[27]!=null && getStringValue(skuObj[27]).equalsIgnoreCase("N") )
	    		skuResult.setRecievingRandomInd("CASE");	
			else if(skuObj[27]!=null && getStringValue(skuObj[27]).equalsIgnoreCase("Y") )
				skuResult.setRecievingRandomInd("POUND");  
	    	
	    		    	
	    	skuResult.setPlu(pluList);
	    	if(skuObj[17] != null)
	    	{
	    		skuResult.setShippedDetail("YES");
	    	}
	    	else
	    	{
	    		skuResult.setShippedDetail("NO");
	    	}
	    	skuSearchResults.add(skuResult);
		}

		return skuSearchResults;

	}

	
	/**
	 * Method to map the DB target fetch result to the corresponding vo object
	 * 
	 * @param perishableCICSearchResults
	 * @return
	 */

	public List<PerishableCICSearchResults> mapTargetItem(List<Object[]> perishableCICSearchResults) {

		List<PerishableCICSearchResults> cicSearchResults = new ArrayList<PerishableCICSearchResults>();
		for (Object[] cicObj : perishableCICSearchResults) {
			PerishableCICSearchResults cicResult = new PerishableCICSearchResults();
			cicResult.setCic((BigDecimal)(cicObj[0] != null ? cicObj[0] : null));
			cicResult.setItemDesc(getStringValue(cicObj[1] != null ? cicObj[1] : null));
			cicResult.setVcf((BigDecimal)(cicObj[2] != null ? cicObj[2] : null));
			cicResult.setPack((BigDecimal)(cicObj[3] != null ? cicObj[3] : null));
			cicResult.setSize(getStringValue (cicObj[4] != null ? cicObj[4] : null));
			cicResult.setUsage(convertToChar(cicObj[5] != null ? cicObj[5] : null));
			cicResult.setUpc(parseUpc((cicObj[6] != null ? cicObj[6] : null)));
			cicResult.setPlu((BigDecimal)(!cicObj[7].toString().equals("PLU") ? cicObj[7] : null));
			cicResult.setDisplay(convertToChar(cicObj[8] != null ? cicObj[8] : null));
			cicResult.setStatusCorp(convertToChar(cicObj[9] != null ? cicObj[9] : null));
			cicResult.setSmic(getStringValue(cicObj[10] != null ? cicObj[10] : null));
			cicResult.setDeptName(getStringValue(cicObj[11] != null ? cicObj[11] : null));
			if((cicObj[12]) == null || ("UN_MAPPED").equals(cicObj[12])){
				cicResult.setMappingStatus(PerishableConstants.TO_BE_MAPPED);
			}else{
				cicResult.setMappingStatus(getStringValue(cicObj[12] != null ? (cicObj[12]) : null));
			}
			cicResult.setWhseDsd(getStringValue(!cicObj[13].equals("productsource")  ? cicObj[13] : null));
			cicResult.setItemUSageInd(convertToChar(cicObj[14] != null ? cicObj[14] : null));
			cicResult.setFarmOrWild(convertToChar(cicObj[15] != null ? cicObj[15] : null));
			cicResult.setVendor_detail(parseUpc((!cicObj[16].equals("VENDOR_DETAIL") ? cicObj[16] : null)));
			cicResult.setVoc(getStringValue(cicObj[17] != null ? cicObj[17] : null));		
			cicResult.setSign_scale(getStringValue(cicObj[18] != null ? cicObj[18] : null));
			cicResult.setSize_Uom(getStringValue(cicObj[19] != null ? cicObj[19] : null));
			
			cicSearchResults.add(cicResult);
		}

		return cicSearchResults;

	}

	/**
	 * @param obj
	 * @return string
	 */
	private String getStringValue(Object obj) {
		if (obj == null)
		{
			return "";
		}
		String str = (String) obj;
		return str.trim();
		
	}
	
	private char convertToChar(Object obj){
		if(obj !=null && obj.toString().length() == 1)
		{
			return obj.toString().charAt(0);
		}
		else
		{
			return Character.MIN_VALUE;
			}
	
	}

	/**
	 * @param obj
	 * @return string[]
	 */
	private String[] parseUpc(Object obj) {
		String[] str=null;
		if (obj == null){
			return str;
		}
		else
		{
			List<String> list = Arrays.asList(obj.toString().split(";"));
		    Set<String> set = new HashSet<String>(list);
		    String[] result = new String[set.size()];
		    set.toArray(result);
		    return result;
		}
		
		
	}
	
	private String parseDate(Timestamp dt)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
        if(dt!=null){
	    return dateFormat.format(dt);
        }
        else{
        return null;
        }
	    
	}
	
	private String parseSQLDate(Date dt)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
        if(dt!=null){
	    return dateFormat.format(dt);
        }
        else{
        return null;
        }
	    
	}
	
	public List<PerishableMappedResultWrapper> setMappedItems(List<Object[]> mappedItems){
		
		List<PerishableMappedResultWrapper> maddedItems=new ArrayList<PerishableMappedResultWrapper>();
		
		for(Object[] mappedObj:mappedItems){
			
			PerishableMappedResultWrapper wrapperVO=new PerishableMappedResultWrapper();
			PerishableMappedItemVO sourceItemVO=new PerishableMappedItemVO();
			PerishableMappedItemVO targetItemVO=new PerishableMappedItemVO();
			
			createMappedSource(mappedObj, sourceItemVO);
		
		    createMapppedTarget(mappedObj, targetItemVO);
		    
		    wrapperVO.setSource(sourceItemVO);
		    wrapperVO.setTarget(targetItemVO);
		    wrapperVO.setMappingType(getStringValue((mappedObj[19] != null ? (mappedObj[19]) : null)));
		    wrapperVO.setMappedStatus(getStringValue((mappedObj[20] != null ? (mappedObj[20]) : null)));
		    wrapperVO.setMappedItemIndicator(getStringValue((mappedObj[21] != null ? (mappedObj[21]) : null)));
		    maddedItems.add(wrapperVO);
		}
		
		return maddedItems;
	}

	private void createMapppedTarget(Object[] mappedObj,
			PerishableMappedItemVO targetItemVO) {
		targetItemVO.setTargetCIC((BigDecimal)(mappedObj[11] != null ? (mappedObj[11]) : null));
		targetItemVO.setItemDesc(getStringValue((mappedObj[12] != null ? (mappedObj[12]) : null)));
		targetItemVO.setVcf((BigDecimal)(mappedObj[13] != null ? (mappedObj[13]) : null));
		targetItemVO.setPack((BigDecimal)(mappedObj[14] != null ? (mappedObj[14]) : null));
		targetItemVO.setSize((BigDecimal)(mappedObj[15] != null ? (mappedObj[15]) : null));
		targetItemVO.setUsage(convertToChar((mappedObj[16] != null ? (mappedObj[16]) : null)));
		targetItemVO.setDisplay(convertToChar((mappedObj[17] != null ? (mappedObj[17]) : null)));
		targetItemVO.setCreatedOn(parseDate((Timestamp)(mappedObj[18] != null ? (mappedObj[18]) : null)));
	}

	private void createMappedSource(Object[] mappedObj,
			PerishableMappedItemVO sourceItemVO) {
		sourceItemVO.setSourceSKU(getStringValue((mappedObj[0] != null ? (mappedObj[0]) : null)));
		sourceItemVO.setItemDesc(getStringValue((mappedObj[1] != null ? (mappedObj[1]) : null)));
		sourceItemVO.setVcf((BigDecimal)(mappedObj[2] != null ? (mappedObj[2]) : null));
		sourceItemVO.setPack((BigDecimal)(mappedObj[3] != null ? (mappedObj[3]) : null));
		sourceItemVO.setSize((BigDecimal)(mappedObj[4] != null ? (mappedObj[4]) : null));
		sourceItemVO.setDisplay(convertToChar((mappedObj[5] != null ? (mappedObj[5]) : null)));
		sourceItemVO.setUpcList(parseUpc((mappedObj[6] != null ? (mappedObj[6]) : null)));
		sourceItemVO.setCreatedOn(parseSQLDate(mappedObj[7] != null ? (Date)(mappedObj[7]) : null));
		sourceItemVO.setLastSalesDate(parseSQLDate(mappedObj[8] != null ? (Date)(mappedObj[8]) : null));
		sourceItemVO.setLastShipDate(parseSQLDate(mappedObj[9] != null ? (Date)(mappedObj[9]) : null));
		sourceItemVO.setUsage(convertToChar((mappedObj[10] != null ? mappedObj[10] : null)));
	}
	
	public List<PerishableUPCwisedDetails> setUPCwiseDetails(List<Object[]> resultObjects)
	{
		List<PerishableUPCwisedDetails> upcDetailsList =new ArrayList();
		for(Object[] resultObject: resultObjects)
		{
		PerishableUPCwisedDetails perishableUPCwisedDetails =new PerishableUPCwisedDetails();
		perishableUPCwisedDetails.setUpc(getStringValue(resultObject[0] != null ? (resultObject[0]) : null));
		perishableUPCwisedDetails.setTotalSales((BigDecimal)(resultObject[1] != null ? (resultObject[1]) : null));
		perishableUPCwisedDetails.setLastSalesDate(parseDate((Timestamp)(resultObject[2] != null ? (resultObject[2]) : null)));		
		perishableUPCwisedDetails.setCheckedUPc(true);
		upcDetailsList.add(perishableUPCwisedDetails);
		}
		return upcDetailsList;
		
		
	}
	
	
	private String appendPlus(String[] upcArray) {
		StringBuilder upcList = new StringBuilder("");
		if(upcArray!=null){
		for(int i =0;i< upcArray.length;i++)
		{
			if(Long.parseLong(upcArray[i])<100000)
				{
					 upcList.append(Long.parseLong(upcArray[i]));			    	
					 if(i< upcArray.length-1 ){
						 upcList.append(","); 
		    		 }
			 
				}
		}
		}
		return upcList.toString();
	}
	
	public PerishableAdditionalDetailsDto setAddtionalDetailsForRetail(Map resultMap)
	{
		PerishableAdditionalDetailsDto perishableAdditionalDetailsDto =new PerishableAdditionalDetailsDto();		
		
		Object count = resultMap.get("ROG_COUNT");
		List<Object[]> detailsList = (List<Object[]>) resultMap.get("RETAIL_SCAN_DETAIL");
		
		PerishableMappingRetailScanDetails additionalDetail =new PerishableMappingRetailScanDetails();
		
		Set rogSet= new HashSet();
		for(Object[] detailObj : detailsList)
		{
			String dstCntr=getStringValue((detailObj[0] != null ? (detailObj[0]) : null));
			BigDecimal vendCost =(BigDecimal)(detailObj[1] != null ? (detailObj[1]) : null);
			char dstStatus =convertToChar((detailObj[2] != null ? (detailObj[2]) : null));
			String vProd=getStringValue((detailObj[4] != null ? (detailObj[4]) : null));
			if(additionalDetail.getDstCntr()==null)
			{
				additionalDetail.setDstCntr(dstCntr);
				additionalDetail.setVendCost(vendCost);
				additionalDetail.setDstStatus(dstStatus);
				additionalDetail.setvProd(vProd);
				rogSet.add(detailObj[3] != null ? (detailObj[3]) : null);
			}
			else if(additionalDetail.getDstCntr().equals(dstCntr) &&
					additionalDetail.getVendCost().equals(vendCost)&&
					additionalDetail.getDstStatus()==dstStatus			
					
					)
			{
				rogSet.add(detailObj[3] != null ? (detailObj[3]) : null);
			}
			else
			{
				additionalDetail.setRogs(rogSet);					
				perishableAdditionalDetailsDto.addAdditonaldetais(additionalDetail);
				/* new set addition*/
				additionalDetail =new PerishableMappingRetailScanDetails();
				additionalDetail.setDstCntr(dstCntr);
				additionalDetail.setVendCost(vendCost);
				additionalDetail.setDstStatus(dstStatus);
				additionalDetail.setvProd(vProd);
				rogSet=new HashSet();
				rogSet.add(detailObj[3] != null ? (detailObj[3]) : null);		
				
			}		
						
			
		}
		additionalDetail.setRogs(rogSet);	
		perishableAdditionalDetailsDto.addAdditonaldetais(additionalDetail);
				
		perishableAdditionalDetailsDto.setRogCount((BigDecimal) count);
	
		return perishableAdditionalDetailsDto;
	}


	public ManualMapAdditionalLoadDto setOnMatchEditDto(List targetFieldResult,List<Object[]> skuWeightList) {

		ManualMapAdditionalLoadDto onMatchEditDto =null;
			boolean mUFlag =false;
			if(targetFieldResult.get(2)!=null )
			{
				List<Object[]> muchek =(List<Object[]>) targetFieldResult.get(2);
				Object[] mucountObj =muchek.get(0);
				if(Integer.parseInt(mucountObj[1].toString()) ==2)
				{
					mUFlag=true;	
				}
		
			}
			if(!targetFieldResult.isEmpty())
			{		
				onMatchEditDto =new ManualMapAdditionalLoadDto();
				/**Size details**/
					onMatchEditDto.addSizeDetails((List<Object[]>) targetFieldResult.get(0));
				/***/
					/*Rog details*/
					onMatchEditDto.addRogDetails((List<Object[]>) targetFieldResult.get(1),(List<Object[]>) targetFieldResult.get(3));								
								
					onMatchEditDto.setMultiUnitFlag(mUFlag);
			}
			if(onMatchEditDto!=null && skuWeightList!=null)
			{
				/*Prod Wt details*/
				for(Object[] obje : skuWeightList)
				{
					onMatchEditDto.addProdWtDetails(obje);
					/**/
					onMatchEditDto.overrideWithSourceCost(obje);
				}
			}
		
		
		
		return onMatchEditDto;
		
	}


}
