package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class PerishableUPCwisedDetails {	
	private String upc;
	private String lastSalesDate;
	private BigDecimal totalSales;
	private boolean checkedUPc;
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getLastSalesDate() {
		return lastSalesDate;
	}
	public void setLastSalesDate(String lastSalesDate) {
		this.lastSalesDate = lastSalesDate;
	}
	public BigDecimal getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(BigDecimal totalSales) {
		this.totalSales = totalSales;
	}
	public boolean isCheckedUPc() {
		return checkedUPc;
	}
	public void setCheckedUPc(boolean checkedUPc) {
		this.checkedUPc = checkedUPc;
	}	

}
