/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */

package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

/**
 ****************************************************************************
 * NAME : PerishableMappingRequestWrapper 
 * 
 * DESCRIPTION :PerishableMappingRequestWrapper is the class to wrap the mapping request parameter with search parameter
 * 			     
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY  
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */
public class PerishableMappingRequestWrapper {
	
	private PerishableSearchRequestVO sourceSearchRequest;
	private PerishableSearchRequestVO targetSearchRequest;
	private PerishableSearchRequestVO mappedSearchRequest;
	private List<PerishableMappingRequest> mappingrequest; 
	private List<ManualExpeseTypeChangeRequest> expenseChangeRequest;
	private List<String> errorMessages;
	private boolean isFromMappedScreen;
	private int actionSuccessStatus;
	/**
	 * @return the sourceSearchRequest
	 */
	public PerishableSearchRequestVO getSourceSearchRequest() {
		return sourceSearchRequest;
	}
	/**
	 * @param sourceSearchRequest the sourceSearchRequest to set
	 */
	public void setSourceSearchRequest(PerishableSearchRequestVO sourceSearchRequest) {
		this.sourceSearchRequest = sourceSearchRequest;
	}
	/**
	 * @return the targetSearchRequest
	 */
	public PerishableSearchRequestVO getTargetSearchRequest() {
		return targetSearchRequest;
	}
	/**
	 * @param targetSearchRequest the targetSearchRequest to set
	 */
	public void setTargetSearchRequest(PerishableSearchRequestVO targetSearchRequest) {
		this.targetSearchRequest = targetSearchRequest;
	}
	
	
	/**
	 * @return the mappedSearchRequest
	 */
	public PerishableSearchRequestVO getMappedSearchRequest() {
		return mappedSearchRequest;
	}
	/**
	 * @param mappedSearchRequest the mappedSearchRequest to set
	 */
	public void setMappedSearchRequest(PerishableSearchRequestVO mappedSearchRequest) {
		this.mappedSearchRequest = mappedSearchRequest;
	}
	/**
	 * @return the mappingrequest
	 */
	public List<PerishableMappingRequest> getMappingrequest() {
		return mappingrequest;
	}
	/**
	 * @param mappingrequest the mappingrequest to set
	 */
	public void setMappingrequest(List<PerishableMappingRequest> mappingrequest) {
		this.mappingrequest = mappingrequest;
	}
	/**
	 * @return the errorMessages
	 */
	public List<String> getErrorMessages() {
		return errorMessages;
	}
	/**
	 * @param errorMessages the errorMessages to set
	 */
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	/**
	 * @return the isFromMappedScreen
	 */
	public boolean isFromMappedScreen() {
		return isFromMappedScreen;
	}
	/**
	 * @param isFromMappedScreen the isFromMappedScreen to set
	 */
	public void setFromMappedScreen(boolean isFromMappedScreen) {
		this.isFromMappedScreen = isFromMappedScreen;
	}
	public List<ManualExpeseTypeChangeRequest> getExpenseChangeRequest() {
		return expenseChangeRequest;
	}
	public void setExpenseChangeRequest(List<ManualExpeseTypeChangeRequest> expenseChangeRequest) {
		this.expenseChangeRequest = expenseChangeRequest;
	}
	public int getActionSuccessStatus() {
		return actionSuccessStatus;
	}
	public void setActionSuccessStatus(int actionSuccessStatus) {
		this.actionSuccessStatus = actionSuccessStatus;
	}
	
	
}
