package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : Company 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  Oct 12, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * Entity class for database table COMPANY.
 * 
 */
@Entity
@Table(name = "ITEM_CONV_MANUAL_MAPPING", schema="ECFLAND")
public class ManualMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
	private ManualMappingPK manualMappingPK;
    
	@Column(name = "CORP_ITEM_CD")
	private BigDecimal cic;
    
	@Column(name = "CREATE_USER_ID")
	private String createUser;

	public ManualMappingPK getManualMappingPK() {
		return manualMappingPK;
	}

	public void setManualMappingPK(ManualMappingPK manualMappingPK) {
		this.manualMappingPK = manualMappingPK;
	}

	public BigDecimal getCic() {
		return cic;
	}

	public void setCic(BigDecimal cic) {
		this.cic = cic;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}