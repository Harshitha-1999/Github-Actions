package com.safeway.app.memi.domain.services;

import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

public interface MasterItemService {

	/**
	 * @param srcDto
	 * @return
	 */
	public boolean killItem(UIExceptionSrcDto srcDto, String reason);
	
	public boolean updateItemStatusXRF(UIExceptionSrcDto srcDto,String reason );

}
