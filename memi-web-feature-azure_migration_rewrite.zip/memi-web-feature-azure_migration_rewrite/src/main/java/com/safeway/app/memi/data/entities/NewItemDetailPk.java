package com.safeway.app.memi.data.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Embedded key class for Database table COMPANY.
 * 
 */
@Embeddable
public class NewItemDetailPk implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "COMPANY_ID")
	private String companyId;

	@Column(name = "DIVISION_ID")
	private String divisionId;

	@Column(name = "PRODUCT_SKU")
	private String productSKU;

	@Column(name = "PROD_SRC_CD")
	private String productSrcCd;

	@Column(name = "UPC_COUNTRY")
	private String upcCountry;

	@Column(name = "UPC_SYSTEM")
	private String upcSystem;

	@Column(name = "UPC_MANUF")
	private String upcManufacturer;

	@Column(name = "UPC_SALES")
	private String upcSales;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSKU() {
		return productSKU;
	}

	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}

	public String getProductSrcCd() {
		return productSrcCd;
	}

	public void setProductSrcCd(String productSrcCd) {
		this.productSrcCd = productSrcCd;
	}

	public String getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(String upcCountry) {
		this.upcCountry = upcCountry;
	}

	public String getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(String upcSystem) {
		this.upcSystem = upcSystem;
	}

	public String getUpcManufacturer() {
		return upcManufacturer;
	}

	public void setUpcManufacturer(String upcManufacturer) {
		this.upcManufacturer = upcManufacturer;
	}

	public String getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(String upcSales) {
		this.upcSales = upcSales;
	}

}
