package com.safeway.app.memi.domain.dtos.response;

import org.springframework.web.multipart.MultipartFile;

public class ExcelFileRequest {
	private String companyId;
	private String divisionId;
	private String divisionName;
	private String deptName;
	private String deptCode;
	private String userId;
	private MultipartFile file;
	
	public ExcelFileRequest() {
		
	}
	public ExcelFileRequest(String companyId, String divisionId,
			String divisionName, String deptName,String deptCode, String userId,
			MultipartFile file) {
		super();
		this.companyId = companyId;
		this.divisionId = divisionId;
		this.divisionName = divisionName;
		this.deptName = deptName;
		this.deptCode = deptCode;
		this.userId = userId;
		this.file = file;
	}
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getDivisionName() {
		return divisionName;
	}
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	@Override
	public String toString() {
		return "ExcelFileRequest [companyId=" + companyId + ", divisionId="
				+ divisionId + ", divisionName=" + divisionName + ", deptName="
				+ deptName + ", deptCode=" + deptCode + ", userId=" + userId
				+ ", file=" + file + "]";
	}
}
