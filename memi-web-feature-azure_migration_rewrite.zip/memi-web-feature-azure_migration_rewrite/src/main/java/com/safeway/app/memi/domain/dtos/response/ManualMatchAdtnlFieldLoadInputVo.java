package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

public class ManualMatchAdtnlFieldLoadInputVo {
	
   private String buyingCic;
   private String sellingCic;
   private String[] productSKUs;
   private String whseDsd;
   private String companyId;
   private String divisionId;
   
public String getBuyingCic() {
	return buyingCic;
}
public void setBuyingCic(String buyingCic) {
	this.buyingCic = buyingCic;
}
public String getSellingCic() {
	return sellingCic;
}
public void setSellingCic(String sellingCic) {
	this.sellingCic = sellingCic;
}
public String getWhseDsd() {
	return whseDsd;
}
public String[] getProductSKUs() {
	return productSKUs;
}
public void setProductSKUs(String[] productSKUs) {
	this.productSKUs = productSKUs;
}
public void setWhseDsd(String whseDsd) {
	this.whseDsd = whseDsd;
}
public String getCompanyId() {
	return companyId;
}
public void setCompanyId(String companyId) {
	this.companyId = companyId;
}
public String getDivisionId() {
	return divisionId;
}
public void setDivisionId(String divisionId) {
	this.divisionId = divisionId;
}

}
