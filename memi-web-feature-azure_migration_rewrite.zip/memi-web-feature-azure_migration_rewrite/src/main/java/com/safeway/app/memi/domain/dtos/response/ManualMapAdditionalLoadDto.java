package com.safeway.app.memi.domain.dtos.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ManualMapAdditionalLoadDto {
	
	private List<SizeDetails> sizeDetails;
	private Set<RogDetails> rogDetail;
	private List<SourceProdWt> sourceWieght;
	private boolean multiUnitFlag;
	
	public List<SizeDetails> getSizeDetails() {
		return sizeDetails;
	}


	public void setSizeDetails(List<SizeDetails> sizeDetails) {
		this.sizeDetails = sizeDetails;
	}


	public Set<RogDetails> getRogDetail() {
		return rogDetail;
	}


	public void setRogDetail(Set<RogDetails> rogDetail) {
		this.rogDetail = rogDetail;
	}


	public List<SourceProdWt> getSourceWieght() {
		return sourceWieght;
	}

	
	public void setSourceWieght(List<SourceProdWt> sourceWieght) {
		this.sourceWieght = sourceWieght;
	}
	
	
	
	
	public List<SizeDetails> addSizeDetails(List<Object[]> sizedetails) {
		if(this.sizeDetails ==null)
		{
			this.sizeDetails = new ArrayList();
		}
		for(Object[] obj: sizedetails)
		{
		
		SizeDetails sd =new SizeDetails();
		sd.setDstCntr(getStringValue(obj[0].toString()));
		sd.setDcPackDesc(getStringValue(obj[1].toString()));
		sd.setDcSizeDesc(getStringValue(obj[2].toString()));	
		
			
		sd.setHandlingCode(getStringValue(obj[3].toString()));	
		sd.setBuyerNum(getStringValue(obj[4].toString()));	
		sd.setRandomWtCd(getStringValue(obj[5].toString()));	
		sd.setAutoCostInv(getStringValue(obj[6].toString()));	
		sd.setBillingType(getStringValue(obj[7].toString()));	
		sd.setShelfLife(getStringValue(obj[8].toString()));	
		sd.setCostVendor(obj[9].toString());
		sd.setCostIb(getStringValue(obj[10].toString()));
		sd.setCostInv(getStringValue(obj[11].toString()));
		sd.setCostAllow(getStringValue(obj[12].toString()));
		sd.setPrcTypeCd(getStringValue(obj[13].toString()));
		
			this.sizeDetails .add(sd);
		}
		
		return this.sizeDetails;
		
	}
	
	
	public Set<RogDetails> addRogDetails(List<Object[]> rogdetails,List<Object[]> rogRankList) {
		if(this.rogDetail ==null)
		{
			this.rogDetail = new HashSet();
		}
		Map tempMap =new HashMap();
		Object[] topRankObj =rogRankList !=null && !rogRankList.isEmpty() ? rogRankList.get(0) : null;
		for(Object[] obj: rogdetails)
		{
			RogDetails rd ;
			if(tempMap.containsKey(obj[0].toString()))
			{
				    rd=	(RogDetails) tempMap.get(getStringValue(obj[0] ));
				    rd.setRog(getStringValue(obj[0] ));
					rd.setRing( getStringValue(obj[1] ));
					rd.setHicone(getStringValue(obj[2] ));
					rd.setRetailUnitPack(getStringValue(obj[3] ));
					rd.setTareCd(getStringValue(obj[4] ));
					rd.setFoodStamp(getStringValue(obj[5] ));
					rd.setTagSize(getStringValue(obj[6] ));
					rd.setTagNumber(getStringValue(obj[7] ));
					rd.setSgnCount1(getStringValue(obj[8] ));
					rd.setSgnCount2(getStringValue(obj[9] ));
					rd.setSgnCount3(getStringValue(obj[10] ));
					
					if(topRankObj!=null && topRankObj.length >0 && getStringValue(topRankObj[0]).equals(rd.getRog()))
					{
						rd.setTopRank(true);
					}
					else
					{
						rd.setTopRank(false);
					}
			}
			else
			{
			    rd=	new RogDetails();
			    rd.setRog(getStringValue(obj[0] ));
				rd.setRing(getStringValue(obj[1] ));
				rd.setHicone(getStringValue(obj[2] ));
				rd.setRetailUnitPack(getStringValue(obj[3] ));
				rd.setTareCd(getStringValue(obj[4] ));
				rd.setFoodStamp(getStringValue(obj[5] ));
				rd.setTagSize(getStringValue(obj[6] ));
				rd.setTagNumber(getStringValue(obj[7] ));
				rd.setSgnCount1(getStringValue(obj[8] ));
				rd.setSgnCount2(getStringValue(obj[9] ));
				rd.setSgnCount3(getStringValue(obj[10] ));
				if(topRankObj!=null && getStringValue(topRankObj[0]).equals(rd.getRog()))
				{
					rd.setTopRank(true);
				}
				else
				{
					rd.setTopRank(false);
				}
				
				
			}
			
		tempMap.put(getStringValue(obj[0]) , rd);		
		}
		this.rogDetail =tempMap.entrySet();
		return this.rogDetail;
	}
	
	public void addProdWtDetails(Object[] obj)
	{
		if(this.sourceWieght == null)
		{
			this.sourceWieght = new ArrayList();
		}
	
		SourceProdWt spw =new SourceProdWt();
		spw.setProductSku(getStringValue(obj[0] ));
		spw.setProdWt(getStringValue(obj[1] ));
		this.sourceWieght.add(spw);
	
	}
	public void overrideWithSourceCost(Object[] obj)
	{
		if(!this.sizeDetails.isEmpty())
		{
			for(SizeDetails sd :this.sizeDetails)
			{
				if(obj.length>2)
				sd.setCostVendor(obj[2]!=null ? obj[2].toString() : sd.getCostVendor());
			}
		}
	}

	public boolean isMultiUnitFlag() {
		return multiUnitFlag;
	}


	public void setMultiUnitFlag(boolean multiUnitFlag) {
		this.multiUnitFlag = multiUnitFlag;
	}


	private String getStringValue(Object obj) {
		if (obj == null)
		{
			return "";
		}
		String str = obj.toString();
		return str.trim();
		
	}
	

}
class SizeDetails
{
	private String dstCntr;
	private String dcPackDesc;
	private String dcSizeDesc;
	
	
	private String handlingCode;
	private String buyerNum;
	private String randomWtCd;
	private String autoCostInv;
	private String billingType;
	private String shelfLife;
	private String costVendor;
	private String costIb;
	private String costInv;
	private String costAllow;
	private String prcTypeCd;
	
	
	public String getDstCntr() {
		return dstCntr;
	}
	public void setDstCntr(String dstCntr) {
		this.dstCntr = dstCntr;
	}
	public String getDcPackDesc() {
		return dcPackDesc;
	}
	public void setDcPackDesc(String dcPackDesc) {
		this.dcPackDesc = dcPackDesc;
	}
	public String getDcSizeDesc() {
		return dcSizeDesc;
	}
	public void setDcSizeDesc(String dcSizeDesc) {
		this.dcSizeDesc = dcSizeDesc;
	}
	
	public String getHandlingCode() {
		return handlingCode;
	}
	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}
	public String getBuyerNum() {
		return buyerNum;
	}
	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}
	public String getRandomWtCd() {
		return randomWtCd;
	}
	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}
	public String getAutoCostInv() {
		return autoCostInv;
	}
	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getShelfLife() {
		return shelfLife;
	}
	public void setShelfLife(String shelfLife) {
		this.shelfLife = shelfLife;
	}
	public String getCostVendor() {
		return costVendor;
	}
	public void setCostVendor(String costVendor) {
		this.costVendor = costVendor;
	}
	public String getCostIb() {
		return costIb;
	}
	public void setCostIb(String costIb) {
		this.costIb = costIb;
	}
	public String getCostInv() {
		return costInv;
	}
	public void setCostInv(String costInv) {
		this.costInv = costInv;
	}
	public String getCostAllow() {
		return costAllow;
	}
	public void setCostAllow(String costAllow) {
		this.costAllow = costAllow;
	}
	public String getPrcTypeCd() {
		return prcTypeCd;
	}
	public void setPrcTypeCd(String prcTypeCd) {
		this.prcTypeCd = prcTypeCd;
	}
	
	
	
}

class RogDetails
{	
	private String rog;
	private Set retailUnitPack;
	private Set ring;
	private Set hicone;
	private Set tareCd;
	private Set foodStamp;
	private Set tagSize;
	private Set tagNumber;
	private Set sgnCount1;
	private Set sgnCount2;
	private Set sgnCount3;
	private boolean topRank ;
	
	public String getRog() {
		return rog;
	}
	public void setRog(String rog) {
		this.rog = rog;
	}
	public Set getRetailUnitPack() {
		return retailUnitPack;
	}
	public void setRetailUnitPack(Object retailUnitPackVal) {
		if(this.retailUnitPack==null)
		{
			this.retailUnitPack=new HashSet();
		}		
		this.retailUnitPack.add(retailUnitPackVal); 
	}
	public Set getRing() {
		return ring;
	}
	public void setRing(Object ringval) {

		if(this.ring==null)
		{
			this.ring=new HashSet();
		}		
		this.ring.add(ringval); 
	
	}
	public Set getHicone() {
		return hicone;
	}
	public void setHicone(Object hiconeval) {
		
		if(this.hicone==null)
		{
			this.hicone=new HashSet();
		}		
		this.hicone.add(hiconeval); 
		
	}
	public Set getTareCd() {
		return tareCd;
	}
	public void setTareCd(Object tareCdval) {
		
		if(this.tareCd==null)
		{
			this.tareCd=new HashSet();
		}		
		this.tareCd.add(tareCdval);
	}
	public Set getFoodStamp() {
		return foodStamp;
	}
	public void setFoodStamp(Object foodStampVal) {
		
		if(this.foodStamp  == null)
		{
			this.foodStamp = new HashSet<>();
		}
		this.foodStamp.add(foodStampVal);
	}
	public Set getTagSize() {
		return tagSize;
	}
	public void setTagSize(Object tagSizeVal) {
		
		if(this.tagSize  == null)
		{
			this.tagSize = new HashSet<>();
		}
		this.tagSize.add(tagSizeVal);		
		
	}
	public Set getTagNumber() {
		return tagNumber;
	}
	public void setTagNumber(Object tagNumberVal) {
		
		if(this.tagNumber  == null)
		{
			this.tagNumber = new HashSet<>();
		}
		this.tagNumber.add(tagNumberVal);	
		
	}
	public Set getSgnCount1() {
		return sgnCount1;
	}
	public void setSgnCount1(Object sgnCount1Val) {
		
		if(this.sgnCount1  == null)
		{
			this.sgnCount1 = new HashSet<>();
		}
		this.sgnCount1.add(sgnCount1Val);
	}
	public Set getSgnCount2() {
		return sgnCount2;
	}
	public void setSgnCount2(Object sgnCount2Val) {
		
		if(this.sgnCount2  == null)
		{
			this.sgnCount2 = new HashSet<>();
		}
		this.sgnCount2.add(sgnCount2Val);
	}
	public Set getSgnCount3() {
		return sgnCount3;
	}
	public void setSgnCount3(Object sgnCount3Val) {
	
		if(this.sgnCount3  == null)
		{
			this.sgnCount3 = new HashSet<>();
		}
		this.sgnCount3.add(sgnCount3Val);
	}
	public boolean isTopRank() {
		return topRank;
	}
	public void setTopRank(boolean topRank) {
		this.topRank = topRank;
	}
	
	
}
class SourceProdWt
{
	private String productSku;
	private String prodWt;
	public String getProductSku() {
		return productSku;
	}
	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}
	public String getProdWt() {
		return prodWt;
	}
	public void setProdWt(String prodWt) {
		this.prodWt = prodWt;
	}
}

