package com.safeway.app.memi.domain.dtos.response;

import java.util.ArrayList;
import java.util.List;

public class OverDataVo {
    
	public static final int STATUS_SUCCESS = 0;
	public static final int STATUS_DEAD = 1;
	public static final int STATUS_VALIDATION_ERROR = 2;
	
    private UIExceptionSrcDto uiEceptionSrcDto;
    private NewItemDetailDto newItemDto;
    private List<SimsLikeItemDto> likeitemList;
    boolean killProdSku;
    private List<String> errorMessages;
    private int status = 0;
    public UIExceptionSrcDto getUiEceptionSrcDto() {
        return uiEceptionSrcDto;
    }
    public void setUiEceptionSrcDto(UIExceptionSrcDto uiEceptionSrcDto) {
        this.uiEceptionSrcDto = uiEceptionSrcDto;
    }
    public NewItemDetailDto getNewItemDto() {
        return newItemDto;
    }
    public void setNewItemDto(NewItemDetailDto newItemDto) {
        this.newItemDto = newItemDto;
    }
    public boolean isKillProdSku() {
        return killProdSku;
    }
    public void setKillProdSku(boolean killProdSku) {
        this.killProdSku = killProdSku;
    }
	public List<String> getErrorMessages() {
		return errorMessages;
	}
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	public void addErrorMessages(String errorMessage) {
		if(errorMessages == null)
			errorMessages = new ArrayList<>();
		errorMessages.add(errorMessage);
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
    public List<SimsLikeItemDto> getLikeitemList() {
        return likeitemList;
    }
    public void setLikeitemList(List<SimsLikeItemDto> likeitemList) {
        this.likeitemList = likeitemList;
    }

}
