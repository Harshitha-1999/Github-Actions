package com.safeway.app.memi.domain.dtos.response;




public class LookUpSearchInputs  {
	
	
	private String companyId;
	private String divisionId;
	private String conversionGroupCd;
	private String productSKU;
	private String itemDescription;
	private String supplierNum;
	private String supplierName;
	private String prodHierarchyLvl1Cd;
	private String prodHierarchyLvl2Cd;
	private String prodHierarchyLvl3Cd;
	private String prodHierarchyLvl4Cd;
	private String prodHierarchyLvl5Cd;
	private String producthierarchyName;
	private String upc;	
	private String plu;
	private String corpItemCd;
	private String conversionStatus; 
	private String itemType;
	private String supplyType;
	private String startIndex;
	private String endIndex;
	
	private String [] sortItems;
	private String sortOrder;
	
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getConversionGroupCd() {
		return conversionGroupCd;
	}
	public void setConversionGroupCd(String conversionGroupCd) {
		this.conversionGroupCd = conversionGroupCd;
	}
	public String getProductSKU() {
		return productSKU;
	}
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getSupplierNum() {
		return supplierNum;
	}
	public void setSupplierNum(String supplierNum) {
		this.supplierNum = supplierNum;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getProdHierarchyLvl1Cd() {
		return prodHierarchyLvl1Cd;
	}
	public void setProdHierarchyLvl1Cd(String prodHierarchyLvl1Cd) {
		this.prodHierarchyLvl1Cd = prodHierarchyLvl1Cd;
	}
	public String getProdHierarchyLvl2Cd() {
		return prodHierarchyLvl2Cd;
	}
	public void setProdHierarchyLvl2Cd(String prodHierarchyLvl2Cd) {
		this.prodHierarchyLvl2Cd = prodHierarchyLvl2Cd;
	}
	public String getProdHierarchyLvl3Cd() {
		return prodHierarchyLvl3Cd;
	}
	public void setProdHierarchyLvl3Cd(String prodHierarchyLvl3Cd) {
		this.prodHierarchyLvl3Cd = prodHierarchyLvl3Cd;
	}
	public String getProdHierarchyLvl4Cd() {
		return prodHierarchyLvl4Cd;
	}
	public void setProdHierarchyLvl4Cd(String prodHierarchyLvl4Cd) {
		this.prodHierarchyLvl4Cd = prodHierarchyLvl4Cd;
	}
	public String getProdHierarchyLvl5Cd() {
		return prodHierarchyLvl5Cd;
	}
	public void setProdHierarchyLvl5Cd(String prodHierarchyLvl5Cd) {
		this.prodHierarchyLvl5Cd = prodHierarchyLvl5Cd;
	}
	public String getProducthierarchyName() {
		return producthierarchyName;
	}
	public void setProducthierarchyName(String producthierarchyName) {
		this.producthierarchyName = producthierarchyName;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getPlu() {
		return plu;
	}
	public void setPlu(String plu) {
		this.plu = plu;
	}
	public String getCorpItemCd() {
		return corpItemCd;
	}
	public void setCorpItemCd(String corpItemCd) {
		this.corpItemCd = corpItemCd;
	}
	public String getConversionStatus() {
		return conversionStatus;
	}
	public void setConversionStatus(String conversionStatus) {
		this.conversionStatus = conversionStatus;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public String getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}
	public String getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(String endIndex) {
		this.endIndex = endIndex;
	}
	public String[] getSortItems() {
		return sortItems;
	}
	public void setSortItems(String[] sortItems) {
		this.sortItems = sortItems;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	
	

}
