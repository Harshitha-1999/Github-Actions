package com.safeway.app.memi.data.repositories;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;
/**
 ****************************************************************************
 * NAME			: PerishableAdditonalSQLRepository 
 * 
 * DESCRIPTION	: PerishableAdditonalSQLRepository is the repository class for performing 
 * 				  perishable DB operations
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U62762
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 05, 2018  - Initial Creation
 * Revision 0.0.0.2 Feb 08, 2018  - Added target search query
 * *************************************************************************
 */

/**
 * Repository class for perishable DB operations
 */
@Repository
@SuppressWarnings("unchecked")
public class PerishableAdditonalSQLRepository {
	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;
	@Value("${spring.datasource.hikari.schema}")
	private String defaultSchema;
	private static final Logger LOG = LoggerFactory.getLogger(PerishableAdditonalSQLRepository.class);
	
	
	public List<Object[]> loadCICSuggestions(Object[] upcs) {
		StringBuilder baseQuery= new StringBuilder("");
		List<Object> upcsList = Arrays.asList(upcs);
		List<String> upcsStrList = upcsList.stream().map(upc -> upc.toString().replaceAll("-", "")).collect(Collectors.toList());
		
		baseQuery.append(" select distinct corp_item_cd,count (corp_item_cd) as match_count from SSIMSLAND.SQLDAT3_SSITMXRF XRF");
		baseQuery.append(" WHERE concat( xrf.upc_country ,  xrf.upc_system ,  right(replicate('0',5) + cast(xrf.upc_manuf as varchar),5) , right(replicate('0',5) + cast(xrf.upc_sales as varchar),5)   ) IN");
		baseQuery.append("(:upcsStrList)");
		 baseQuery.append(" group by corp_item_cd ");
		 baseQuery.append(" order by match_count desc ");
		
		 EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
					.createEntityManager();
			        Query q = em.createNativeQuery(baseQuery.toString());
			        q.setParameter("upcsStrList", upcsStrList);
		       List<Object[]> results = q.getResultList();
		        LOG.info("Completed inserting  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  records.");
		        em.close();
		       
		return results;
		
	}


	public List<Object[]> fetchMatchingCICdetails(List<Object[]> cicList) {
		
		List<Object[]> finalResult=null;
		List<String> cicStrList = cicList.stream().map(cic -> (cic[0]).toString()).collect(Collectors.toList());
		StringBuilder cics= new StringBuilder("");
		 
		 StringBuilder baseQuery =new StringBuilder( "SELECT /*+ PARALLEL(4) FIRST_ROWS(1000) */ DISTINCT "
					+ "CDS.CORP_ITEM_CD,CDS.DESC_ITEM,"
					+ "CDS.VEND_CONV_FCTR,CDS.PACK_WHSE,CDS.CDS_SIZE,CDS.ITEM_USAGE_TYPE,"
					+ " NULL,"
					+ "POS.PLU_CD,CDS.DISP_FLAG,CDS.STATUS_CORP,"
					+ "CONCAT (CDS.GROUP_CD ,'-', CDS.CTGRY_CD ,'-', CDS.CLASS_CD ,'-', CDS.SUB_CLASS_CD ,'-', CDS.SUBSB_CLASS_CD) AS SMIC,"
					+ "OMDEPT.DEPT_NAME,P.MATCHING_STATUS_CD,'productsource' as productsource,CDS.ITEM_USAGE_IND,CDS.SCALE_PRETEXT_IND "
					+ ",'VENDOR_DETAIL' as VENDOR_DETAIL"
					+ ", CONCAT (CDS.VEN_UPC_PACK_IND,'-', CDS.VEN_UPC_COUNTRY,'-', CDS.VEN_UPC_NUM_SYS,'-', CDS.VEN_UPC_MANUF,'-', CDS.VEN_UPC_ITEM) AS VOC "
					+" , DSR.RTL_ITEM_DESC "
					+"  ,CDS.SIZE_UOM "
					+ "FROM SSIMSLAND.SQLDAT3_SSITMCDS CDS "
					+"JOIN SSIMSLAND.SQLDAT3_SSITMXRF XRF "
					+ "ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD "
					
					+"LEFT OUTER JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS " /* Expense related so that using outer join */
					+"ON POS.UPC_MANUF = XRF.UPC_MANUF "
					+"AND POS.UPC_SALES = XRF.UPC_SALES "
					+"AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY "
					+"AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  "
					
					+"JOIN SSIMSLAND.SQLDAT3_OMSTRDS RDS "
					+"ON CDS.RETAIL_SECT = RDS.SECT "
					
					+"JOIN  SSIMSLAND.SQLDAT3_OMDEPT OMDEPT "
					+"ON OMDEPT.DEPT = RDS.DEPT " 
					
					+"JOIN SSIMSLAND.SQLDAT3_SSITMDSR DSR "
					+"ON CDS.CORP_ITEM_CD = DSR.CORP_ITEM_CD "
					
					+" JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS "
					+" ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD "
					
					+" LEFT OUTER JOIN  ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
					+"ON CDS.CORP_ITEM_CD = P.CORP_ITEM_CD "					
					+"WHERE CDS.STATUS_CORP <> 'D' " );
		 baseQuery.append(" AND CDS.CORP_ITEM_CD IN (:cicStrList) ");
		
		 
		 EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
					.createEntityManager();
			Query q = em.createNativeQuery(baseQuery.toString());
			q.setParameter("cicStrList", cicStrList);
			q.setHint(PerishableSQLConstants.FETCH_SIZE, "50");
			
			
			List<Object[]> results = q.getResultList();
			em.close();
			if (null != results && !results.isEmpty()) {
				finalResult = getTargetUpcAggregateList(results,cicStrList);
				
			}		
			
		 
		return finalResult;
	}


	


	private List<Object[]> getTargetUpcAggregateList(List<Object[]> results,
			List<String> cicStrList) {
		if(results!=null && !results.isEmpty() ){		
			
	    	StringBuilder query=new StringBuilder("");
	    	query.append( "SELECT /*+ PARALLEL(4) */ DISTINCT CDS.CORP_ITEM_CD,"
             +"STRING_AGG(CONCAT( XRF.UPC_COUNTRY,XRF.UPC_SYSTEM,right(replicate('0',5) + cast(xrf.upc_manuf as varchar),5),right(replicate('0',5) + cast(xrf.upc_sales as varchar),5)),';')"
             + "as UPC_LIST "
             +"FROM"
             +" SSIMSLAND.SQLDAT3_SSITMCDS CDS"
             +" JOIN"
             +" SSIMSLAND.SQLDAT3_SSITMXRF XRF" 
             +" ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD" 
             
             +" WHERE");
	    	 query.append(" CDS.CORP_ITEM_CD IN (:cicStrList) GROUP BY CDS.CORP_ITEM_CD ORDER BY CDS.CORP_ITEM_CD");
	    	 
	      	EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
			Query q = em.createNativeQuery(query.toString());
			q.setParameter("cicStrList", cicStrList);
			q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
			List<Object[]> upcResults = q.getResultList();
			em.close();
			appendTargetResultListWithUPC(results, upcResults);
			 getTargetWhseDsd(results,cicStrList);
    		 getTargetVendorDetails(results,cicStrList);
			
	    	}
			return results;  
	}


	private void appendTargetResultListWithUPC(List<Object[]> results,
			List<Object[]> upcResults) {
		for (Object[] skuObjO : results) {
			for (Object[] skuObj : upcResults) {
				if (skuObjO[0].equals(skuObj[0])) {
						skuObjO[6] = skuObj[1];						
				}

			}
		}
	}

	private void getTargetWhseDsd(List<Object[]> results, List<String> cicStrList) {
		if(results!=null && !results.isEmpty() ){
			StringBuilder query=new StringBuilder("");
			query.append(" SELECT DISTINCT CORP_ITEM_CD, STRING_AGG(SUBSTRING(DST_CNTR,1,1),'')"
					+ " \"WHSE_DSD\" from SSIMSLAND.SQLDAT3_SSITMWDS  ");
			query.append(" WHERE CORP_ITEM_CD IN (:cicStrList) GROUP BY CORP_ITEM_CD ORDER BY CORP_ITEM_CD");
			
	    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
				Query q = em.createNativeQuery(query.toString());
				q.setParameter("cicStrList", cicStrList);
				q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
				List<Object[]> whseresults = q.getResultList();
				em.close();
			appendWhseDsdResult(results,whseresults);
		}
		
	}

	private void appendWhseDsdResult(List<Object[]> results,
			List<Object[]> whseresults) {
		for (Object[] skuObjO : results) {
			for (Object[] skuObj : whseresults) {
				if (skuObjO[0].equals(skuObj[0])) {	
					
					if(skuObj[1].toString().contains("DW") || skuObj[1].toString().contains("WD"))
					{
						skuObjO[13] = "WHSE-DSD";
					}
					else if(!skuObj[1].toString().contains("W"))
					{
						skuObjO[13] = "DSD";
					}
					else if(!skuObj[1].toString().contains("D"))
					{
						skuObjO[13] = "WHSE";
					}
						
											
				}

			}
		}
		
	}
	private void getTargetVendorDetails(List<Object[]> newresults,List<String> cicStrList) {
		if(newresults!=null && !newresults.isEmpty() ){
			StringBuilder query=new StringBuilder("");
			query.append(" SELECT  DISTINCT CORP_ITEM_CD, vend_num,name "
					+ " from "+defaultSchema+".ITEM_CONV_ITEM_VENDOR_XRF ");
			query.append(" WHERE CORP_ITEM_CD IN (:cicStrList)");
			 
	    	 
	    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
				Query q = em.createNativeQuery(query.toString());
				q.setParameter("cicStrList", cicStrList);
				q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
				List<Object[]> results = q.getResultList();
				em.close();
			appendTargetVendor(newresults,results);
		}
		
	}


	private void appendTargetVendor(List<Object[]> newresults,
			List<Object[]> results) {
		for (Object[] skuObjO : newresults) {
			for (Object[] skuObj : results) {
				if (skuObjO[0].equals(skuObj[0])) {					
					
					if(skuObjO[16].equals("VENDOR_DETAIL"))
					{
						skuObjO[16] = skuObj[1]+"-"+skuObj[2]+";";	
					}
					else
					{
						skuObjO[16] = skuObjO[16]+""+skuObj[1]+"-"+skuObj[2]+";";	
					}
					
											
				}

			}
		}

	}

	public Map fetchAdditonalRetailScandetails(String corpItemCd) {
		
		Map resultMap= new HashMap<String,List>();
		List<String> corpItemCdList = Arrays.asList(corpItemCd.split(","));
		
		  StringBuilder countQuery=new StringBuilder("");
		  countQuery.append(" SELECT count(*) from SSIMSLAND.SQLDAT3_SSITMROG  ");
		  countQuery.append(" WHERE CORP_ITEM_CD IN (:corpItemCd)");
		      	  
    	  StringBuilder detailQuery=new StringBuilder("");
    	  detailQuery.append("SELECT DISTINCT WDS.DST_CNTR,WDS.COST_VEND,WDS.STATUS_DST,");
		  detailQuery.append(" concat( ROG.ROG , ' - ', URX.ring) as ROGs, VPL.VEND_PROD_CDE ");        
    	  detailQuery.append("from   SSIMSLAND.SQLDAT3_SSITMWDS WDS ");
    	  detailQuery.append("JOIN  SSIMSLAND.SQLDAT3_SSITMURX URX ");
    	  detailQuery.append("ON WDS.CORP_ITEM_CD =URX.CORP_ITEM_CD ");
    	  detailQuery.append("JOIN SSIMSLAND.SQLDAT3_SSITMROG ROG ");
    	  detailQuery.append("on ROG.CORP_ITEM_CD=WDS.CORP_ITEM_CD and ROG.FACILITY =WDS.FACILITY ");
		  detailQuery.append(" LEFT JOIN SSIMSLAND.SQLDAT3_SSITMVPL VPL ");
		  detailQuery.append(" ON  WDS.CORP = VPL.CORP ");
		  detailQuery.append(" And WDS.CORP_ITEM_CD = VPL.CORP_ITEM_CD ");
		  detailQuery.append(" AND WDS.VEND_NUM = VPL.VEND_NUM  ");
		  detailQuery.append(" AND WDS.VEND_SUB_ACNT = VPL.VEND_SUB_ACNT ");
		  detailQuery.append("WHERE  ROG.CORP_ITEM_CD IN (:corpItemCd)");
    	  detailQuery.append(" order by WDS.DST_CNTR,WDS.COST_VEND,WDS.STATUS_DST asc ");
    	 
			EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
			Query qcount = em.createNativeQuery(countQuery.toString());
			qcount.setParameter("corpItemCd", corpItemCdList);
			Query qdetail=em.createNativeQuery(detailQuery.toString());
			qdetail.setParameter("corpItemCd", corpItemCdList);
			List<Object[]> results = qcount.getResultList();
			List<Object[]> detailResults = qdetail.getResultList();			
			em.close();
			
			resultMap.put("ROG_COUNT", results.get(0));
			resultMap.put("RETAIL_SCAN_DETAIL", detailResults);			
			return resultMap;
			
			
			
	}


	public List<Object[]> getMappedUpcListDetails(String companyId, String divisionId,String sku,String mappingType,String itemType) {
		LOG.info("Fetching totalsales and salesDate corresponding UPC");
		StringBuilder query=new StringBuilder("");
		query.append("SELECT /*+ PARALLEL(4) */ DISTINCT C.UPC,SD.TOTAL_SALES,CAST(SD.last_sale_dt AS DATE) "
          +" FROM ECFLAND.ITEM_AGGREGATE_CORP C"
          +"   LEFT JOIN "
          +" ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD " 
          +"  ON C.COMPANY_ID = SD.COMPANY_ID " 
          +"  AND C.DIVISION_ID = SD.DIVISION_ID  "
          +"  AND C.PRODUCT_SKU = SD.PRODUCT_SKU " 
          +"   AND C.UPC = SD.UPC "
          
             + " LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU "
             + " ON C.COMPANY_ID = MU.COMPANY_ID "
             + " AND C.DIVISION_ID = MU.DIVISION_ID "
             + " AND C.PRODUCT_SKU = MU.PRODUCT_SKU "
             + " AND C.UPC =  MU.SRC_UPC "
             
             + "JOIN XREFLAND.SRC_ITEM_XRF X " 
             + "ON  C.COMPANY_ID = X.COMPANY_ID " 
             + "AND C.DIVISION_ID = X.DIVISION_ID "
             + "AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU " 
             +" and C.UPC= X.SRC_UPC "
             
	      +" LEFT OUTER JOIN"
          +" ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
          +" ON C.COMPANY_ID = P.COMPANY_ID  "
          +" AND C.DIVISION_ID = P.DIVISION_ID  "
          +" AND C.UPC = P.UPC  "
          +" AND C.PRODUCT_SKU = P.PRODUCT_SKU "
          
		  +" WHERE  "
          + " C.MULTI_COMP_ITEM_IND <> 'Y' "
          + " AND MU.PRODUCT_SKU is null AND ") ;
		
		query.append(" C.COMPANY_ID= :companyId");
		query.append(" AND C.DIVISION_ID= :divisionId");
        query.append(" AND C.product_sku= :sku");
        
        setMappingTypeAndItemTypeFilter(mappingType, itemType, query);
  		 query.append(" order by SD.TOTAL_SALES,CAST(SD.last_sale_dt AS DATE) desc ");
        
  		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("sku", sku);
		if(null!= mappingType && !( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) )){
			  if(PerishableSQLConstants.MAPPED.equals(mappingType))
			    {
				  q.setParameter("mappingType", mappingType);
			    }
		} 
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching  records.");
		em.close();
		return results;
	}
	/**
	 * @param mappingType
	 * @param itemType
	 * @param query
	 */
	private void setMappingTypeAndItemTypeFilter(String mappingType,
			String itemType, StringBuilder query) {
		if(null!= mappingType && !( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) )){
		  if(PerishableSQLConstants.MAPPED.equals(mappingType))
		    {
			    query.append(" AND P.MATCHING_STATUS_CD= :mappingType");
			    query.append(" AND X.CONV_STATUS_CD  IN( 'R','S','Q','A')");
		    	
		    }
		  else if(PerishableSQLConstants.CONVERTED.equals(mappingType))
		    {
			    query.append(" AND P.MATCHING_STATUS_CD= 'MAPPED' ");			    
		    	query.append(" AND X.CONV_STATUS_CD  IN ('C') ");
		    	
		    }
		else{
				query.append(" AND P.MATCHING_STATUS_CD= 'MAPPED' ");	
			    query.append(" AND X.CONV_STATUS_CD  IN( 'R','S','Q','A','C')");
			    
		  }
		    
		}
		
		 
		  if(null!=itemType){
			 if(itemType.equals(PerishableSQLConstants.SYSTEM2))
			 {					
				 query.append(" AND X.SRC_UPC_COUNTRY =0 and X.SRC_UPC_SYSTEM =2 ");
			}
			else if(itemType.equals(PerishableSQLConstants.SYSTEM4))
			{
				 
				query.append(" AND X.SRC_UPC_COUNTRY =0 and X.SRC_UPC_SYSTEM =4 ");
			}
			else if(itemType.equals("PLU"))
			{	
				query.append(" AND X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND X.SRC_UPC_SALES > 0 ");
			}
		  }
	}
	
	
	public boolean updateExpeseType(
			List<Object[]> changeRequests) {
		
		boolean operationsTatus =false;
		
		StringBuilder updateaggregateCorp =new StringBuilder("");
		updateaggregateCorp.append("UPDATE ECFLAND.ITEM_AGGREGATE_CORP SET EXPENSE_ITEM_IND = ?,MATERIAL_ITEM_IND =? ")
							.append("WHERE company_id =? and DIVISION_ID = ? and product_SKU =?");
		
		StringBuilder deleteDataReplace =new StringBuilder("");
		deleteDataReplace.append("DELETE FROM ECFLAND.ITEM_CONV_SRC_DATA_REPLACE WHERE company_id =? and DIVISION_ID = ? and product_SKU =?" )
				         .append( " and TABLE_NAME_ITM_DSC_TXT = 'STORE_LEVEL_ITEM' and COLUMN_NAME_ITM_DSC_TXT in ('EXPENSE_ITEM_IND','MATERIAL_ITEM_IND') ");
		
		StringBuilder insertDataReplaceExpense =new StringBuilder("");
		insertDataReplaceExpense.append("INSERT INTO ECFLAND.ITEM_CONV_SRC_DATA_REPLACE ")
		                 .append("(COMPANY_ID, DIVISION_ID, PRODUCT_SKU, REPLACE_LEVEL_CD, TABLE_NAME_ITM_DSC_TXT,COLUMN_NAME_ITM_DSC_TXT,CONFIG_VAL,CREATE_UPDATE_TS,CREATE_UPDATE_USER_ID,LOGICAL_DEL_IND)")
		                 .append(" VALUES (?,?,?,?,?,?,?,?,?,? )");	
		
		StringBuilder insertDataReplaceMaterial =new StringBuilder("");
		insertDataReplaceMaterial.append("INSERT INTO ECFLAND.ITEM_CONV_SRC_DATA_REPLACE ")
		                 .append("(COMPANY_ID, DIVISION_ID, PRODUCT_SKU, REPLACE_LEVEL_CD, TABLE_NAME_ITM_DSC_TXT,COLUMN_NAME_ITM_DSC_TXT,CONFIG_VAL,CREATE_UPDATE_TS,CREATE_UPDATE_USER_ID,LOGICAL_DEL_IND)")
		                 .append(" VALUES (?,?,?,?,?,?,?,?,?,? )");		
		
		
		
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		
		
		Query qagreggate = em.createNativeQuery(updateaggregateCorp.toString());
		Query qdelete = em.createNativeQuery(deleteDataReplace.toString());
		Query qinsertExpense = em.createNativeQuery(insertDataReplaceExpense.toString());
		Query qinsertMaterial = em.createNativeQuery(insertDataReplaceMaterial.toString());
		
		 EntityTransaction et = em.getTransaction();
		try{
		
	        et.begin();
				for(Object[] obj :changeRequests)
				{
										
					qdelete.setParameter(1, obj[0]);
					qdelete.setParameter(2, obj[1]);
					qdelete.setParameter(3, obj[2]);
					
					qinsertExpense.setParameter(1, obj[0]);
					qinsertExpense.setParameter(2, obj[1]);
					qinsertExpense.setParameter(3, obj[2]);
					qinsertExpense.setParameter(4, 'I');
					qinsertExpense.setParameter(5, "STORE_LEVEL_ITEM");
					qinsertExpense.setParameter(6, "EXPENSE_ITEM_IND");
					
					
					qinsertMaterial.setParameter(1, obj[0]);
					qinsertMaterial.setParameter(2, obj[1]);
					qinsertMaterial.setParameter(3, obj[2]);
					qinsertMaterial.setParameter(4, 'I');
					qinsertMaterial.setParameter(5, "STORE_LEVEL_ITEM");
					qinsertMaterial.setParameter(6, "MATERIAL_ITEM_IND");
					
					
					if(obj[3].equals("R"))
					{
						qagreggate.setParameter(1, 'N');
						qagreggate.setParameter(2, 'N');
						
						qinsertExpense.setParameter(7, 'N');
						qinsertMaterial.setParameter(7, 'N');
					}
					else if(obj[3].equals("E"))
					{
						qagreggate.setParameter(1, 'Y');
						qagreggate.setParameter(2, 'N');
						
						qinsertExpense.setParameter(7, 'Y');
						qinsertMaterial.setParameter(7, 'N');
					}
					else if(obj[3].equals("M"))
					{
						qagreggate.setParameter(1, 'N');
						qagreggate.setParameter(2, 'Y');
						
						qinsertExpense.setParameter(7, 'N');
						qinsertMaterial.setParameter(7, 'Y');
					}
					
					qagreggate.setParameter(3, obj[0]);
					qagreggate.setParameter(4, obj[1]);
					qagreggate.setParameter(5, obj[2]);
					
					Date timeStamp =new Date();
					
					qinsertExpense.setParameter(8, timeStamp);
					qinsertExpense.setParameter(9, obj[4]);
					qinsertExpense.setParameter(10, 'N');
					
					qinsertMaterial.setParameter(8, timeStamp);
					qinsertMaterial.setParameter(9, obj[4]);
					qinsertMaterial.setParameter(10, 'N');		
					
										
					qagreggate.executeUpdate();
					qdelete.executeUpdate();
					qinsertExpense.executeUpdate();
					qinsertMaterial.executeUpdate();
				}
           et.commit();
           operationsTatus =true;
		}
		catch(Exception e)
		{	
			et.rollback();
		}
		finally{
			em.close();
		}
		
		return operationsTatus;
	}
	
	public List  loadTargetFieldsForMapEdit(String corpItemCd,String companyId,String divisonId)
	{
		StringBuilder querySizeDesc = new StringBuilder("");
		querySizeDesc.append(" select distinct WDS.DST_CNTR,WDS.pack_desc,WDS.size_desc, ");
		querySizeDesc.append("WDS.handling_code,WDS.buyer_num,WDS.random_wt_Cd,WDS.auto_cost_inv,WDS.billing_type,WDS.shelf_life,");
		querySizeDesc.append(" WDS.COST_VEND,WDS.COST_IB,WDS.COST_INV,WDS.COST_ALLOW,ROG.PRC_TYPE_CD ");
		querySizeDesc.append(" from SSIMSLAND.SQLDAT3_SSITMWDS WDS LEFT JOIN SSIMSLAND.SQLDAT3_SSITMROG ROG ");
		querySizeDesc.append(" ON WDS.CORP_ITEM_CD =ROG.CORP_ITEM_CD ");
		querySizeDesc.append(" WHERE  WDS.CORP_ITEM_CD =:corpItemCd ");	
		
		StringBuilder queryRog = new StringBuilder("");
		queryRog.append(" select distinct RO.ROG,POS.ring,POS.hicone,URX.pack_Retail, ");		
		queryRog.append(" POS.tare_CD,POS.FD_STMP,URX.label_size,URX.label_numbers, ");	
		queryRog.append(" POS.SGN_COUNT1,POS.SGN_COUNT2,POS.SGN_COUNT3 ");		
		queryRog.append(" FROM SSIMSLAND.SQLDAT3_SSITMURX URX ");
		queryRog.append(" JOIN SSIMSLAND.SQLDAT3_SSITMROG RO   " );
		queryRog.append(" ON URX.CORP_ITEM_CD =RO.CORP_ITEM_CD AND URX.ROG =RO.ROG ");
		queryRog.append(" LEFT JOIN SSIMSLAND.SQLDAT3_SSITMPOS POS ");
		queryRog.append(" ON  URX.upc_country = POS.upc_country And URX.upc_system = POS.upc_system");
		queryRog.append(" AND URX.upc_manuf = POS.upc_manuf AND  URX.upc_sales = POS.upc_sales  AND URX.ROG= POS.ROG");		
		queryRog.append(" WHERE  URX.CORP_ITEM_CD =:corpItemCd order by 1,2,3,4 asc ");	
		
		StringBuilder queryMultiUnitCheck = new StringBuilder("");
		queryMultiUnitCheck.append("select  corp_item_cd, count (distinct unit_type) from SSIMSLAND.SQLDAT3_SSITMXRF");
		queryMultiUnitCheck.append(" where corp_item_cd =:corpItemCd ");
		queryMultiUnitCheck.append(" group by corp_item_cd ");
		
		StringBuilder queryRogRanks = new StringBuilder("");
		queryRogRanks.append("select ro.rog,rank.rog_rank_nbr from SSIMSLAND.SQLDAT3_SSITMROG RO ");
		queryRogRanks.append(" JOIN ECFLAND.item_conv_rog_rank rank on RO.ROG= rank.rog ");
		queryRogRanks.append(" where company_id =:companyId and division_id =:divisionId and ro.corp_item_cd =:corpItemCd ");
		queryRogRanks.append(" order by  rank.rog_rank_nbr  ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(querySizeDesc.toString());
		q.setParameter("corpItemCd", corpItemCd);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> sizeResults = q.getResultList();
		
		Query q1 = em.createNativeQuery(queryRog.toString());
		q1.setParameter("corpItemCd", corpItemCd);
		q1.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> rogResults = q1.getResultList();
		
		Query q2 = em.createNativeQuery(queryMultiUnitCheck.toString());
		q2.setParameter("corpItemCd", corpItemCd);
		q2.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> mUCheckResult = q2.getResultList();
		
		Query q3 = em.createNativeQuery(queryRogRanks.toString());
		q3.setParameter("corpItemCd", corpItemCd);
		q3.setParameter("companyId", companyId);
		q3.setParameter("divisionId", divisonId);
		q3.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		
		List<Object[]> rogRankresult = q3.getResultList();
		
		em.close();
		
		List results =new ArrayList();
	
		results.add(sizeResults);
		results.add(rogResults);
		results.add(mUCheckResult);
		results.add(rogRankresult);
		return results;
	}
	public List<Object[]> loadSourceItemForEdit(String companyId,String divisionId, String[] skus) 
	{
		List<String> skuList = Arrays.asList(skus);
		StringBuilder queryWt = new StringBuilder(" select product_sku,PRODUCTION_WEIGHT_NBR,VENDOR_LIST_COST_NBR from ecfland.item_aggregate_whse ");
		queryWt.append(" where COMPANY_ID =:companyId and DIVISION_ID =:divisionId ");
		queryWt.append(" and product_sku in ( :skuList) ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(queryWt.toString());		
		q.setParameter("companyId",companyId );
		q.setParameter("divisionId",divisionId );
		q.setParameter("skuList",skuList );
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> wtResult = q.getResultList();
		em.close();
	
		return wtResult;
	}

}
