package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : Company 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * Entity class for database table COMPANY.
 * 
 */

@Entity
@Table(name = "COMPANY", schema="ECFLAND")
@NamedQuery(name = "Company.findAll", query = "SELECT s FROM Company s")
public class Company implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "COMPANY_ID")
    private String companyId;

    @Column(name = "COMPANY_LEGAL_NM")
    private String companyLegalNM;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getCompanyLegalNM() {
		return companyLegalNM;
	}

	public void setCompanyLegalNM(String companyLegalNM) {
		this.companyLegalNM = companyLegalNM;
	}

}