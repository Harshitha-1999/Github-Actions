package com.safeway.app.memi.domain.dtos.response;

public class BakeryMappedResultWrapper {

	
	private BakeryMappedItemVO source;
	private BakeryMappedItemVO target;
	private String mappingType;
	
	public BakeryMappedItemVO getSource() {
		return source;
	}
	public void setSource(BakeryMappedItemVO source) {
		this.source = source;
	}
	public BakeryMappedItemVO getTarget() {
		return target;
	}
	public void setTarget(BakeryMappedItemVO target) {
		this.target = target;
	}
	public String getMappingType() {
		return mappingType;
	}
	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}
	
	
	
}
