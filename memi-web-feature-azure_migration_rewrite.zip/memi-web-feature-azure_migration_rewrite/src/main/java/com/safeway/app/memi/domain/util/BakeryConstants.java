package com.safeway.app.memi.domain.util;

/**
 ****************************************************************************
 * NAME			: BakeryConstants 
 * 
 * DESCRIPTION	: BakeryConstants is the  class for holding constant values and validation messages 
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U63169
 * 
 * REVISION HISTORY
 * 
 * Revision     0.0.0.1     March 09, 2018  - Initial Creation
 * *************************************************************************
 */

public class BakeryConstants {
	
	
	
	

   /**
    * Constant to hold the search option "BUYER" for target search in bakery mapping
    */
   public static final String BUYER = "B";
   
   /**
    * Constant to hold the search option "SELLER" for target search in bakery mapping
    */
   public static final String SELLER = "S";
   
   /**
    * Constant to hold error message if target search doesn't contains Buyer/seller option
    */
   public static final String INVALID_TARGET_SEARCH = "Buyer/Seller missing";
   
   /**
    * Constant to hold error message for item type selection
    */
   public static final String VALIDATION_ITEM_TYPE = "Please select item type from radio buttons";
   
   


	


   

}
