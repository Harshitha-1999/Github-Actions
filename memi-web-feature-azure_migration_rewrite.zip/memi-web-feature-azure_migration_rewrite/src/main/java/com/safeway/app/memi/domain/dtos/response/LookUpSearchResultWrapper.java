package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.List;

public class LookUpSearchResultWrapper {
	
	private List<LookUpSearchResultVOS> serchResults;
	private BigDecimal count;
	private BigDecimal start_index;
	private BigDecimal end_index;
	private List errorList ;
	public List<LookUpSearchResultVOS> getSerchResults() {
		return serchResults;
	}
	public void setSerchResults(List<LookUpSearchResultVOS> serchResults) {
		this.serchResults = serchResults;
	}
	public BigDecimal getCount() {
		return count;
	}
	public void setCount(BigDecimal count) {
		this.count = count;
	}
	public BigDecimal getStart_index() {
		return start_index;
	}
	public void setStart_index(BigDecimal start_index) {
		this.start_index = start_index;
	}
	public BigDecimal getEnd_index() {
		return end_index;
	}
	public void setEnd_index(BigDecimal end_index) {
		this.end_index = end_index;
	}
	public List getErrorList() {
		return errorList;
	}
	public void setErrorList(List errorList) {
		this.errorList = errorList;
	}

}
