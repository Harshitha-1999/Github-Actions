/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

/* ***************************************************************************
 * NAME : NewItemDetailServiceImpl SYSTEM : MEMI AUTHOR : Subhash G REVISION
 * HISTORY Revision 0.0.0.1 May 09, 2017 - sgang06 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.SMICDetail;
import com.safeway.app.memi.data.entities.SizeUOMDetail;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.NewItemDetailRepository;
import com.safeway.app.memi.data.repositories.SMICDetailRepository;
import com.safeway.app.memi.data.repositories.SizeUOMDetailRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.adapters.DtoFieldsAdapter;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.services.NewItemDetailService;

/**
 * Service implementation class for new item operations
 */
@Service("newItemDetailService")
public class NewItemDetailServiceImpl implements NewItemDetailService {

	private static final Logger LOG = LoggerFactory
			.getLogger(NewItemDetailServiceImpl.class);

	@Autowired
	private NewItemDetailRepository newItemDetailRepo;

	@Autowired
	private SMICDetailRepository smicDetailnRepo;

	@Autowired
	private SizeUOMDetailRepository sizeUOMDetailnRepo;

	@Autowired
	private UIExceptionSrcRepository exceptionRepo;

	@Autowired
	private CommonSQLRepository likeItemRepository;

	private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();
	private DtoFieldsAdapter dtoFieldAdapter = new DtoFieldsAdapter();

	@Override
	public List<NewItemDetailDto> getAllItems() {
		LOG.info("Started execution for getting all src list items");
		List<NewItemDetail> srcList = newItemDetailRepo.findAll();
		LOG.info("Completed execution for"+srcList.size()+" getting all src list items");

		return viewAdapter.mapToNewItemDetailDtoList(srcList);
	}

	/**
     * Method to find find new CIC record
     */
	@Override
	public List<NewItemDetailDto> findByCompanyIdAndDivisionIdAndExcptnTypeCd(
			String companyId, String divisionId, String exceptionType) {
		LOG.info("Started execution for getting all src list items based on findBy CompanyId And DivisionId And ExcptnTypeCd");

		List<NewItemDetail> srcList = newItemDetailRepo
				.findByNewItemPkCompanyIdAndNewItemPkDivisionIdAndExcptnTypeCd(
						companyId, divisionId, exceptionType);
		LOG.info(" completed execution for getting "+srcList.size()+" src list items based on findBy CompanyId And DivisionId And ExcptnTypeCd");
				

		return viewAdapter.mapToNewItemDetailDtoList(srcList);
	}

	/**
     * Method to list the items that need review
     */
	@Override
	public List<NewItemDetailDto> findbyReviewItem(String company,
			String division) {
		List<NewItemDetail> reviewItemList = newItemDetailRepo
				.findByNewItemPkDivisionIdAndNewItemPkCompanyIdAndAugOverCmplnInd(
						division, company, 'N');
		LOG.debug("Review list is " + reviewItemList);

		List<NewItemDetailDto> reviewItems = viewAdapter
				.mapToNewItemDetailDtoList(reviewItemList);
		LOG.debug("Review list Dto is " + reviewItems);
		return reviewItems;
	}

	/**
     * Method to save new CIC record with Augmentation data
     */
	@Override
	@Transactional
	public void saveItem(AugDataVo newItemtoDb) {
		LOG.info("Started execution for save new CIC record with Augmentation data ");

		if (newItemtoDb.getNewItemDto().getAugOverCmplnInd() == 'Y') {

			if (validateData(newItemtoDb) == false) {
				newItemtoDb.setStatus(AugDataVo.STATUS_VALIDATION_ERROR);
				return;
			}
		}
		UIExceptionSrcDto srcItem = newItemtoDb.getUiEceptionSrcDto();
		String division = srcItem.getDivisionId();
		String company = srcItem.getCompanyId();
		String productsku = srcItem.getProductSKU();
		char excptnProInd = srcItem.getExcptnProInd();
		
		
		
		
		NewItemDetailDto saveItem = newItemtoDb.getNewItemDto();
		
		List<UIExceptionSrc> sourceObjs = exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
						productsku, division, company, 'A', excptnProInd);
		LOG.info("Exception Source Objects loaded.");
		if(sourceObjs != null && !sourceObjs.isEmpty())
		{
			for(UIExceptionSrc excSrc :  sourceObjs)
			{
				NewItemDetail newItem = dtoFieldAdapter.mapToNewItemDetailtoSave(
						excSrc, saveItem);
				newItemDetailRepo.save(newItem);
				excSrc.setUpdatedUserID(srcItem.getUpdatedUserID());
				UIExceptionSrc updSource = excSrc;
				if (newItemtoDb.getNewItemDto().getAugOverCmplnInd() == 'Y') {
					excSrc.setExcptnProcessdInd('C');
					updSource = exceptionRepo.save(excSrc);
				}
				if (newItemtoDb.getNewItemDto().getAugOverCmplnInd() == 'N') {
					excSrc.setExcptnProcessdInd('R');
					updSource = exceptionRepo.save(excSrc);
				}
				if (newItem == null && updSource == null) {
					newItemtoDb.setStatus(AugDataVo.STATUS_SUCCESS);
				} else {
					newItemtoDb.setStatus(AugDataVo.STATUS_DEAD);
				}

			}
		}
		LOG.info("completed execution for save  new CIC record with Augmentation data");

	}

	/**
     * Method to save new CIC record with Override data
     */
	@Override
	@Transactional
	public void saveItem(OverrideDataVo newItemtoDb) {
		LOG.info("started execution for save  new CIC record with Override data");


		if (validateData(newItemtoDb) == false) {
			newItemtoDb.setStatus(AugDataVo.STATUS_VALIDATION_ERROR);
			return;
		}
		UIExceptionSrcDto srcItem = newItemtoDb.getUiEceptionSrcDto();
		NewItemDetailDto saveItem = newItemtoDb.getNewItemDto();
		String division = srcItem.getDivisionId();
		String company = srcItem.getCompanyId();
		String productsku = srcItem.getProductSKU();
		char excptnProInd = srcItem.getExcptnProInd();
		List<UIExceptionSrc> sourceObjs = exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
						productsku, division, company, 'O', excptnProInd);
		LOG.info("Exception Source Objects loaded.");
		if(sourceObjs != null && !sourceObjs.isEmpty())
		{
			for(UIExceptionSrc excSrc :  sourceObjs)
			{
				NewItemDetail newItem = dtoFieldAdapter.mapToNewItemDetailtoSave(excSrc, saveItem);
				newItemDetailRepo.save(newItem);
				excSrc.setUpdatedUserID(srcItem.getUpdatedUserID());
				excSrc.setExcptnProcessdInd('C');
				UIExceptionSrc updSource = exceptionRepo.save(excSrc);
				if (newItem == null && updSource == null) {
					newItemtoDb.setStatus(AugDataVo.STATUS_SUCCESS);
				} else {
					newItemtoDb.setStatus(AugDataVo.STATUS_DEAD);
				}

			}
		
		}
		LOG.info("completed execution for save  new CIC record with Override data");

	}

	/**
	 * @param value
	 * @return
	 */
	private int getIntValue(String value) {
		return value == null || value.trim().length() == 0 ? 0 : Integer
				.parseInt(value);
	}

	/**
	 * @param value
	 * @return
	 */
	private String getStringValue(int value) {
		return Integer.toString(value);
	}

    /**
     * Method to validate form data from Augmentation Screen
     */
	private boolean validateData(AugDataVo newItemtoDb) {
		
		LOG.debug("started execution for validate form data from Augmentation Screen");

		if (newItemtoDb.getNewItemDto() == null) {
			newItemtoDb.addErrorMessages("No details to save.");
			return false;
		}
		NewItemDetailDto saveItem = newItemtoDb.getNewItemDto();
		boolean dataValid = true;

		List<SMICDetail> smicDetails = smicDetailnRepo
				.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(
						getStringValue(saveItem.getGrpCd()),
						getStringValue(saveItem.getCtgryCd()),
						getStringValue(saveItem.getClsCd() != null ? saveItem.getClsCd() : 0),
						getStringValue(saveItem.getSbClsCd() != null ? saveItem.getSbClsCd() : 0),
						getStringValue(saveItem.getSubSbClass() != null ? saveItem.getSubSbClass() : 0));
		LOG.debug("Completed fetching all "+smicDetails.size()+"smicDetails");
		if (smicDetails == null || smicDetails.isEmpty()) {
			newItemtoDb.addErrorMessages("Invalid SMIC Code.");
			dataValid = false;
		}
		
		List<SizeUOMDetail> uomDetail = sizeUOMDetailnRepo
				.findByUomCode(saveItem.getUpdSizeUom().trim());
		LOG.debug("Completed fetching all "+uomDetail.size()+"uomDetail");

		if (uomDetail == null || uomDetail.isEmpty()) {
			newItemtoDb.addErrorMessages("Invalid UOM Code.");
			dataValid = false;
		}

		String validSpecialChars = " .-/%&)'";
		if (!isValidString(saveItem.getUpdItmDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("Item Description contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		if (!isValidString(saveItem.getUpdWhseItmDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("Warehouse Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		if (!isValidString(saveItem.getUpdRtlItmDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("S & S Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		if (saveItem.getUpcSystem().equalsIgnoreCase("2")
				&& saveItem.getUpdRtlItmDesc().length() > 32) {
			newItemtoDb
					.addErrorMessages("S & S Desc has more than 32 characters.");
			dataValid = false;
		}

		if (!isValidString(saveItem.getUpdIntenetItemDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("Internet Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		String validSpecialCharsForPOS = " .-/%&)'#";
		if (!isValidString(saveItem.getUpdPosDesc(), validSpecialCharsForPOS)) {
			newItemtoDb
					.addErrorMessages("POS Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE, '#' ] are allowed.");
			dataValid = false;
		}
		
		if (saveItem.getCscDsc() != null && saveItem.getCscDsc().length() > 0 && !isValidString(saveItem.getCscDsc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("CSC Description contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}
		/*Produce PLU */
		if (saveItem.getDcPackDesc() != null && saveItem.getDcPackDesc().trim().length()>3 ) {
			newItemtoDb
			.addErrorMessages("Dc level pack description allowed maximum of 3 characters  and  Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
	
			dataValid = false;
		}
		if (saveItem.getDcSizeDsc() != null && saveItem.getDcSizeDsc().trim().length()>7 ) {
			newItemtoDb
			.addErrorMessages("Dc level pack description allowed maximum of 3 characters  and  Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
				dataValid = false;
		}
		if (saveItem.getRing() != null && !saveItem.getRing().trim().matches("[0-5]{1}") ) {
			newItemtoDb
			.addErrorMessages(" Ring value should be 0 or 1 all others are rejected");
				dataValid = false;
		}
		if (saveItem.getHicone() != null && !saveItem.getHicone().trim().matches("[0-2]{1}") ) {
			newItemtoDb.addErrorMessages("Hicone value should be 0,1 or 2 others are rejected");
				dataValid = false;
		}
		String singleCharRegExp ="[a-bA-Z0-9]{1}";
		String singleDigRegExp ="[0-9]{1}";
		String daysCountExp ="[0-9]{1,16}";
		
		if(saveItem.getProdwght()!=null && !saveItem.getProdwght().trim().matches("[0-9]{1,7}+[.]?[0-9]{0,4}"))
			{newItemtoDb.addErrorMessages("Prod Weight is not a number in the prescribed format ");
			dataValid = false;
			}
		if(saveItem.getHandlingCode()!=null &&!saveItem.getHandlingCode().trim().matches("[0-9]{1,3}"))
			{newItemtoDb.addErrorMessages("Handling code should be a number with maximum 3 digits ");	
			dataValid = false;
			}
		if(saveItem.getBuyerNum()!=null &&!saveItem.getBuyerNum().trim().matches("[a-bA-Z0-9]{1,2}"))
			{newItemtoDb.addErrorMessages("Buyer num should not exceed two characters ");
			dataValid = false;
			}
		if(saveItem.getRandomWtCd()!=null  && !saveItem.getRandomWtCd().trim().equals("")
			&&	!saveItem.getRandomWtCd().trim().matches("[R]{0,1}"))
			{newItemtoDb.addErrorMessages("Random weight code should be R or a empty  ");	
			dataValid = false;
			}
		if(saveItem.getAutoCostInv()!=null &&!saveItem.getAutoCostInv().trim().matches("[A,C,I]{1}"))
			{newItemtoDb.addErrorMessages("Auto const inv should be A,C, or I character ");
			dataValid = false;
			}
		if(saveItem.getBillingType()!=null  && !saveItem.getBillingType().trim().equals("")
			&&	!saveItem.getBillingType().trim().matches("[A]{0,1}"))
			{newItemtoDb.addErrorMessages("Billing type should be A or empty ");
			dataValid = false;
			}
		if(saveItem.getFdStmp()!=null &&!saveItem.getFdStmp().trim().matches("[0-1]{0,1}"))
			{newItemtoDb.addErrorMessages("Food stamp should be 0 or 1 ");
			dataValid = false;
			}
		if(saveItem.getLabelSize()!=null &&!saveItem.getLabelSize().trim().matches("[M,N,S]{1}"))
			{newItemtoDb.addErrorMessages("Tag size type should be M,N or S character ");
			dataValid = false;
			}
		if(saveItem.getLabelNumbers()!=null &&!saveItem.getLabelNumbers().trim().matches(singleDigRegExp))
			{newItemtoDb.addErrorMessages("Tag number type should be single digit ");
			dataValid = false;
			}
		if(saveItem.getSgnCount1()!=null &&!saveItem.getSgnCount1().trim().matches(singleDigRegExp))
			{newItemtoDb.addErrorMessages("Sign count1 type should be single digit ");
			dataValid = false;
			}
		if(saveItem.getSgnCount2()!=null &&!saveItem.getSgnCount2().trim().matches(singleDigRegExp))
			{newItemtoDb.addErrorMessages("Sign count2 type should be single digit ");
			dataValid = false;
			}
		if(saveItem.getSgnCount3()!=null &&!saveItem.getSgnCount3().trim().matches(singleDigRegExp))
			{newItemtoDb.addErrorMessages("Sign count3 type should be single digit ");
			dataValid = false;
			}
		if(saveItem.getSellByDays()!=null &&!saveItem.getSellByDays().trim().matches(daysCountExp))
			{newItemtoDb.addErrorMessages("Sell by days should be decimal number ");
			dataValid = false;
			}
		if(saveItem.getUseByDays()!=null &&!saveItem.getUseByDays().trim().matches(daysCountExp))
			{newItemtoDb.addErrorMessages("Use by days should be decimal number ");
			dataValid = false;
			}
		if(saveItem.getPullBydays()!=null &&!saveItem.getPullBydays().trim().matches(daysCountExp))
			{newItemtoDb.addErrorMessages("Pull by days should be decimal number ");
			dataValid = false;
			}
		if(saveItem.getTareCd()!=null &&!saveItem.getTareCd().trim().matches("[0-9]{1,16}"))
			{newItemtoDb.addErrorMessages("Tare code should be a number ");
				dataValid = false;
		}
		
		
		for(UPCVo upcfull :saveItem.getUpcVoList())
		{
			String upc =upcfull.getUpc().replaceAll("-", "").trim();
			if(Float.parseFloat(upc)<100000 && saveItem.getEditedPLU(upc)>0 && saveItem.getEditedPLU(upc) >=100000)
			{    
				newItemtoDb
				.addErrorMessages("Editted PLU value should be maximum of 5 digits");
			}
			else if(Float.parseFloat(upc)>=100000)
			{
				if(saveItem.getEditedUpc(upc)!=null && !saveItem.getEditedUpc(upc).replaceAll("-", "").trim().matches("[0-9]{12}"))
				{
					newItemtoDb
					.addErrorMessages("Editted UPC value should be 12 digt number and allow left zero to reach it");
				}
			}
		}
		LOG.debug("Completed execution for validate form data from Augmentation Screen");

		return dataValid;
	}

	/**
	 * @param str
	 * @param allowedSplChars
	 * @return
	 */
	public static boolean isValidString(String str, String allowedSplChars) {
		char[] chars = str.toCharArray();
		for (char c : chars) {
			if (!Character.isLetterOrDigit(c)) {
				if (allowedSplChars != null && allowedSplChars.length() > 0) {
					if (allowedSplChars.indexOf(c) == -1)
						return false;
				} else
					return false;
			}
		}

		return true;
	}

	/**
     * Method to validate form data from Override Screen
     */
	private boolean validateData(OverrideDataVo newItemtoDb) {
		LOG.debug("Started execution for validate form data from Override Screen");

		if (newItemtoDb.getNewItemDto() == null) {
			newItemtoDb.addErrorMessages("No details to save.");
			return false;
		}
		NewItemDetailDto saveItem = newItemtoDb.getNewItemDto();
		boolean dataValid = true;

		List<SMICDetail> smicDetails = smicDetailnRepo
				.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(
						getStringValue(saveItem.getGrpCd()),
						getStringValue(saveItem.getCtgryCd()),
						getStringValue(saveItem.getClsCd() != null ? saveItem.getClsCd() : 0),
						getStringValue(saveItem.getSbClsCd() != null ? saveItem.getSbClsCd() : 0),
						getStringValue(saveItem.getSubSbClass() != null ? saveItem.getSubSbClass() : 0));
		LOG.debug("Completed fetching all "+smicDetails.size()+"smicDetails");

		if (smicDetails == null || smicDetails.isEmpty()) {
			newItemtoDb.addErrorMessages("Invalid SMIC Code.");
			dataValid = false;
		}

		List<SizeUOMDetail> uomDetail = sizeUOMDetailnRepo
				.findByUomCode(saveItem.getUpdSizeUom().trim());
		LOG.debug("Completed fetching all "+uomDetail.size()+"uomDetail");

		if (uomDetail == null || uomDetail.isEmpty()) {
			newItemtoDb.addErrorMessages("Invalid UOM Code.");
			dataValid = false;
		}

		String validSpecialChars = " .-/%&)'";
		if (!isValidString(saveItem.getUpdItmDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("Item Description contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		if (!isValidString(saveItem.getUpdWhseItmDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("Warehouse Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		if (!isValidString(saveItem.getUpdRtlItmDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("S & S Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}

		if (saveItem.getUpcSystem().equalsIgnoreCase("2")
				&& saveItem.getUpdRtlItmDesc().length() > 32) {
			newItemtoDb
					.addErrorMessages("S & S Desc has more than 32 characters.");
			dataValid = false;
		}

		if (!isValidString(saveItem.getUpdIntenetItemDesc(), validSpecialChars)) {
			newItemtoDb
					.addErrorMessages("Internet Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE ] are allowed.");
			dataValid = false;
		}
		
		String validSpecialCharsForPOS = " .-/%&)'#";
		if (!isValidString(saveItem.getUpdPosDesc(), validSpecialCharsForPOS)) {
			newItemtoDb
					.addErrorMessages("POS Desc contains invalid characters. Only Alphabets, Numbers and these Special Characters [ Space, '.', '-', '/', '%', '&', ')', QUOTE, '#' ] are allowed.");
			dataValid = false;
		}
		LOG.debug("completed execution for validate form data from Override Screen");

		return dataValid;
	}

}