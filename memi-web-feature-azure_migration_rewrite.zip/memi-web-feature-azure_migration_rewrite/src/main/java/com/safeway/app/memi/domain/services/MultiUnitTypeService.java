package com.safeway.app.memi.domain.services;

import java.util.List;
import java.util.Map;

import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceTargetSearchRequest;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSrcTargetDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitTypeTargetDto;

public interface MultiUnitTypeService {

	List<MultiUnitTypeTargetDto> getMultiUnitTypeTargetDataList(
			List<MultiUnitSourceDto> multiUnitSource);

	Map<String, String> updateSourceBasedOnTarget(
			MultiUnitSrcTargetDto multiUnitSrcTargetDto);

	Map<String, List<String>> markMultiUnitItemsAsDead(
			List<MultiUnitSourceDto> multiUnitSource);

	Map<String, List<String>> markNotAMultiUnitItem(
			List<MultiUnitSourceDto> multiUnitSource);

	MultiUnitSrcTargetDto fetchMultiUnitData(String company, String division,String matchIndicator);

	List<MultiUnitSourceDto> getMultiUnitSourceDetail(
			List<MultiUnitSourceTargetSearchRequest> sourceRequest);

	List<MultiUnitTypeTargetDto> getMultiUnitTargetDetail(
			List<MultiUnitSourceTargetSearchRequest> targetRequest);

	List<MultiUnitSourceDto> getMultiUnitTypeSourceDataList(
			List<MultiUnitTypeTargetDto> multiUnitTarget);

	Map<String, String> updateSourceBasedOnTargetUnMap(
			MultiUnitSrcTargetDto multiUnitSrcTargetDto);

	Map<String, String> markItemAsMultiUnit(
			List<MultiUnitSourceDto> multiUnitSourceDto);

	MultiUnitSrcTargetDto fetchMultiUnitSourceData(String company,
			String division, String matchIndicator);

	MultiUnitSrcTargetDto fetchMultiUnitTargetData(String company,
			String division, String matchIndicator);

	List<Object[]> fetchMuTTargetUpcPopUpData(String corpItemCd);

}
