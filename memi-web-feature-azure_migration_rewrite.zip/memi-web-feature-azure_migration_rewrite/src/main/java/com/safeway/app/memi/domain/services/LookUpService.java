package com.safeway.app.memi.domain.services;

import java.util.List;
import java.util.Map;

import com.safeway.app.memi.domain.dtos.response.LookUpActionRequest;
import com.safeway.app.memi.domain.dtos.response.LookUpCustomizationVO;
import com.safeway.app.memi.domain.dtos.response.LookUpScreenLoadVO;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchInputs;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultWrapper;

public interface LookUpService {

	LookUpScreenLoadVO lookUpScreenLoad(String companyId, String divisionId, String userId);

	Map saveLookUpCostomization(LookUpCustomizationVO customVO);

	LookUpSearchResultWrapper fetchLookUpResult(LookUpSearchInputs searchInput);

	List<String> performStatusChanges(List<LookUpActionRequest> actionsRequests,String user);

	
}
