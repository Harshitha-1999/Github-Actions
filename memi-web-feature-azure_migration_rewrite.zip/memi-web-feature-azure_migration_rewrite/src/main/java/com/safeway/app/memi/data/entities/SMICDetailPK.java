package com.safeway.app.memi.data.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SMICDetailPK implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "GROUP_CD")
	private String grpCd;

	@Column(name = "CTGRY_CD")
	private String ctgryCd;

	@Column(name = "CLASS_CD")
	private String clsCd;

	@Column(name = "SUB_CLASS_CD")
	private String sbClsCd;

	@Column(name = "SUBSB_CLASS_CD")
	private String subSbClass;

	public String getGrpCd() {
		return grpCd;
	}

	public void setGrpCd(String grpCd) {
		this.grpCd = grpCd;
	}

	public String getCtgryCd() {
		return ctgryCd;
	}

	public void setCtgryCd(String ctgryCd) {
		this.ctgryCd = ctgryCd;
	}

	public String getClsCd() {
		return clsCd;
	}

	public void setClsCd(String clsCd) {
		this.clsCd = clsCd;
	}

	public String getSbClsCd() {
		return sbClsCd;
	}

	public void setSbClsCd(String sbClsCd) {
		this.sbClsCd = sbClsCd;
	}

	public String getSubSbClass() {
		return subSbClass;
	}

	public void setSubSbClass(String subSbClass) {
		this.subSbClass = subSbClass;
	}
	
	
}
