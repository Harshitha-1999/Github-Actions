package com.safeway.app.memi.domain.dtos.response;

public class UPCVo {
	
	String upc;
	char primaryUPCInd;
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = formatUPCField(upc);
	}
	public char getPrimaryUPCInd() {
		return primaryUPCInd;
	}
	public void setPrimaryUPCInd(char primaryUPCInd) {
		this.primaryUPCInd = primaryUPCInd;
	}
	 
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((upc == null) ? 0 : upc.hashCode());
		return result;
	}
	
	
	@Override
	public boolean equals(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    if(obj == this)
	    	return true;
	    if (this.getClass() != obj.getClass())
	        return false;
	    if (!UPCVo.class.isAssignableFrom(obj.getClass())) {
	        return false;
	    }
	    final UPCVo other = (UPCVo) obj;
	    if ((this.upc == null) ? (other.upc != null) : !this.upc.equals(other.upc)) {
	        return false;
	    }
	    return true;
	}
	
	private String formatUPCField(String upc){
		 String[] fields = upc.split("-");
		 StringBuilder formattedUPC = new StringBuilder();
		 for(int i = 0 ; i <  fields.length; i++)
		 {
			 formattedUPC.append(prefixZeros(fields[i], i < 2 ? 1 : 5));
			 if(i < fields.length -1)
				 formattedUPC.append("-");
		 }
		 return formattedUPC.toString();
	 }
	 
	 private String prefixZeros(String val, int fieldLength){
		 if(val != null){
			val = val.trim();
			if (val.length() >= fieldLength)
				return val;
		}
		 else
			 val = "";
		 StringBuilder str = new StringBuilder();
		 int zeroesNeeded = fieldLength - val.length();
		 for(int i = 0; i < zeroesNeeded; i++)
			 str.append('0');
		 str.append(val);
		 return str.toString();
	 }

}
