/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

/* ***************************************************************************
 * NAME         : ExceptionSrcService 
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 May 09, 2017  -  Initial Creation
 *
 ***************************************************************************/
import java.math.BigDecimal;
import java.util.List;

import com.safeway.app.memi.data.entities.SizeUOMDetail;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.DepartmentDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

/**
 * 
 * Interface definition for ExceptionSrc Service
 * 
 */
public interface ExceptionSrcService {

    /**
     * Method to fetch Exception List
     */
    public List<UIExceptionSrcDto> getAllItems();

    /**
     * @param divisionId
     * @return
     */
    public List<UIExceptionSrcDto> findByDivision(String divisionId);

    /**
     * @param upc
     * @return
     */
    public UIExceptionSrcDto findByUpc(String upc);
    
    /**
     * @param productSKU
     * @return
     */
    public UIExceptionSrcDto findByProductSKU(String productSKU);

    /**
     * @param company
     * @param division
     * @return
     */
    public List<UIDataVO> getDepartmentWiseData(String company, String division, char exceptionType);

    /**
     * @param company
     * @param division
     * @return
     */
    public List<UIExceptionSrcDto> getAugData(String company, String division);

    /**
     * @param company
     * @param division
     * @param productsku
     * @return
     */
    public AugDataVo loadItemData(String company, String division, String productsku);

    /**
     * @param company
     * @param division
     * @param sourceUpc
     * @return
     */
    public AugDataVo loadItemDataByUPC(String company, String division, String sourceUpc);
    
    /**
     * @param sourceObj
     * @return
     */
    public boolean markItemComplete(UIExceptionSrcDto sourceObj, char exceptionType);
    
    /**
     * @param sourceObj
     * @return
     */
    public boolean removeCICRecord(UIExceptionSrcDto sourceObj, char exceptionType);
    
    /** 
     * @param company
     * @param division
     * @param productsku
     * @return
     */
    public OverrideDataVo loadOverrideItemData(String company, String division, String productsku);
    
    /**
     * @param company
     * @param division
     * @param upc
     * @return
     */
    public OverrideDataVo loadOverrideItemDataByUPC(String company, String division, String upc);
    
    /**
     * @param company
     * @param division
     * @param dept
     * @return
     */
    public List<UIExceptionSrcDto> loadDeptExportData(String company, String division, String dept);
    
    /**
     * @param companyId
     * @param divisionId
     * @param departmentCode
     * @param exceptionType
     * @param status
     * @param type
     * @return
     */
    public List<String> loadProductSKUList(String companyId, String divisionId, String departmentCode, char exceptionType, char status, char type);
    
    /**
     * @param company
     * @param division
     * @param productsku
     * @return
     */
    public boolean getOnhandStatus(String companyId, String divisionId,	String produckSKU);
    
    public List<SizeUOMDetail> getUOMCodes();
    
    /**
     * @param companyId
     * @param divisionId
     * @return
     */
    public List<DepartmentDto> getDepartmentDetails(String companyId, String divisionId);
    
    /**
     * @param exception
     */
    public void saveException(UIExceptionSrcDto exception);
    
    /**
     * @param exception
     */
    public void saveItemAggregateCorp(UIExceptionSrcDto exception);
    
    
    /**
     * @param exception
     * @param CIC
     * @param UPC
     */
    public void insertManualMappingRecord(UIExceptionSrcDto exception, BigDecimal cic);

	public boolean checkTargetProdClass(String prodClass,String groupCode);

}
