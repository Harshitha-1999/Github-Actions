package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entity class for Database table ITEM_CONV_UI_EXCEPTION_SRC.
 * 
 */
@Entity
@Table(name = "ITEM_CONV_UI_EXCEPTION_SRC", schema="ECFLAND")
@NamedQuery(name = "UIExceptionSrc.findAll", query = "SELECT s FROM UIExceptionSrc s")
public class UIExceptionSrc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private UiExceptionSrcPk uiSrcPk;

	@Column(name = "PLU_CD")
	private String pluCd;

	@Column(name = "PRIMARY_UPC_IND")
	private Character prmyUpcInd;

	@Column(name = "ITEM_USAGE_IND")
	private Character itemUsgeInd;

	@Column(name = "ITEM_USAGE_TYPE_IND")
	private Character itemUsageTypInd;

	@Column(name = "PRIVATE_LABEL_IND")
	private Character ptLabelInd;

	@Column(name = "DISP_FLAG")
	private Character dispFlag;

	@Column(name = "ITEM_DESC")
	private String itmDesc;

	@Column(name = "WHSE_ITEM_DESC")
	private String whseItmDesc;

	@Column(name = "RTL_ITEM_DESC")
	private String rtlItmDesc;

	@Column(name = "INTERNET_ITEM_DESC")
	private String intenetItemDesc;

	@Column(name = "POS_DESC")
	private String posDesc;

	@Column(name = "VEND_CONV_FCTR")
	private BigDecimal vendConvFactor;

	@Column(name = "PACK_WHSE")
	private BigDecimal packwhse;

	@Column(name = "SIZE_NBR")
	private BigDecimal sizeNmbr;

	@Column(name = "SIZE_UOM")
	private String sizeUom;

	@Column(name = "SIZE_DESC")
	private String sizeDesc;

	@Column(name = "COST")
	private Float cost;

	@Column(name = "PROD_HIERARCHY_LVL_1_CD")
	private String prdHierLevel1;

	@Column(name = "PROD_HIERARCHY_LVL_2_CD")
	private String prdHierLevel2;

	@Column(name = "PROD_HIERARCHY_LVL_3_CD")
	private String prdHierLevel3;

	@Column(name = "PROD_HIERARCHY_LVL_4_CD")
	private String prdHierLevel4;

	@Column(name = "PROD_HIERARCHY_LVL_5_CD")
	private String prdHierLevel5;

	@Column(name = "EXCEPTION_TYPE_CD")
	private Character excptnTypeCd;

	@Column(name = "EXCEPTION_DESC")
	private String excptionDesc;

	@Column(name = "EXCEPTION_PROCESSED_IND")
	private Character excptnProcessdInd;

	@Column(name = "BATCH_ID")
	private Integer batchId;

	@Column(name = "LOGICAL_DEL_IND")
	private Character logicalInd;

	@Column(name = "CASE_UPC")
	private String caseUPC;

	@Column(name = "CREATE_UPDATE_USER_ID")
	private String updatedUserID;
	
	@Column(name = "CREATE_UPDATE_TS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date  createUpdateTimestamp;

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "PROD_HIERARCHY_LVL_1_CD", referencedColumnName = "PROD_HIERARCHY_LVL_1_CD", insertable = false, updatable = false),
			@JoinColumn(name = "PROD_HIERARCHY_LVL_2_CD", referencedColumnName = "PROD_HIERARCHY_LVL_2_CD", insertable = false, updatable = false),
			@JoinColumn(name = "PROD_HIERARCHY_LVL_3_CD", referencedColumnName = "PROD_HIERARCHY_LVL_3_CD", insertable = false, updatable = false),
			@JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID", insertable = false, updatable = false),
			@JoinColumn(name = "DIVISION_ID", referencedColumnName = "DIVISION_ID", insertable = false, updatable = false) })
	
	private DepartmentDetail deptDtl;

	public DepartmentDetail getDeptDtl() {
		return deptDtl;
	}

	public void setDeptDtl(DepartmentDetail deptDtl) {
		this.deptDtl = deptDtl;
	}

	public String getPluCd() {
		return pluCd;
	}

	public void setPluCd(String pluCd) {
		this.pluCd = pluCd;
	}

	public Character getPrmyUpcInd() {
		return prmyUpcInd;
	}

	public void setPrmyUpcInd(Character prmyUpcInd) {
		this.prmyUpcInd = prmyUpcInd;
	}

	public Character getItemUsgeInd() {
		return itemUsgeInd;
	}

	public void setItemUsgeInd(Character itemUsgeInd) {
		this.itemUsgeInd = itemUsgeInd;
	}

	public Character getItemUsageTypInd() {
		return itemUsageTypInd;
	}

	public void setItemUsageTypInd(Character itemUsageTypInd) {
		this.itemUsageTypInd = itemUsageTypInd;
	}

	public Character getPtLabelInd() {
		return ptLabelInd;
	}

	public void setPtLabelInd(Character ptLabelInd) {
		this.ptLabelInd = ptLabelInd;
	}

	public Character getDispFlag() {
		return dispFlag;
	}

	public void setDispFlag(Character dispFlag) {
		this.dispFlag = dispFlag;
	}

	public String getItmDesc() {
		return itmDesc;
	}

	public void setItmDesc(String itmDesc) {
		this.itmDesc = itmDesc;
	}

	public String getWhseItmDesc() {
		return whseItmDesc;
	}

	public void setWhseItmDesc(String whseItmDesc) {
		this.whseItmDesc = whseItmDesc;
	}

	public String getRtlItmDesc() {
		return rtlItmDesc;
	}

	public void setRtlItmDesc(String rtlItmDesc) {
		this.rtlItmDesc = rtlItmDesc;
	}

	public String getIntenetItemDesc() {
		return intenetItemDesc;
	}

	public void setIntenetItemDesc(String intenetItemDesc) {
		this.intenetItemDesc = intenetItemDesc;
	}

	public String getPosDesc() {
		return posDesc;
	}

	public void setPosDesc(String posDesc) {
		this.posDesc = posDesc;
	}

	public BigDecimal getVendConvFactor() {
		return vendConvFactor;
	}

	public void setVendConvFactor(BigDecimal vendConvFactor) {
		this.vendConvFactor = vendConvFactor;
	}

	public BigDecimal getPackwhse() {
		return packwhse;
	}

	public void setPackwhse(BigDecimal packwhse) {
		this.packwhse = packwhse;
	}

	public BigDecimal getSizeNmbr() {
		return sizeNmbr;
	}

	public void setSizeNmbr(BigDecimal sizeNmbr) {
		this.sizeNmbr = sizeNmbr;
	}

	public String getSizeUom() {
		return sizeUom;
	}

	public void setSizeUom(String sizeUom) {
		this.sizeUom = sizeUom;
	}

	public String getSizeDesc() {
		return sizeDesc;
	}

	public void setSizeDesc(String sizeDesc) {
		this.sizeDesc = sizeDesc;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public String getPrdHierLevel1() {
		return prdHierLevel1;
	}

	public void setPrdHierLevel1(String prdHierLevel1) {
		this.prdHierLevel1 = prdHierLevel1;
	}

	public String getPrdHierLevel2() {
		return prdHierLevel2;
	}

	public void setPrdHierLevel2(String prdHierLevel2) {
		this.prdHierLevel2 = prdHierLevel2;
	}

	public String getPrdHierLevel3() {
		return prdHierLevel3;
	}

	public void setPrdHierLevel3(String prdHierLevel3) {
		this.prdHierLevel3 = prdHierLevel3;
	}

	public String getPrdHierLevel4() {
		return prdHierLevel4;
	}

	public void setPrdHierLevel4(String prdHierLevel4) {
		this.prdHierLevel4 = prdHierLevel4;
	}

	public String getPrdHierLevel5() {
		return prdHierLevel5;
	}

	public void setPrdHierLevel5(String prdHierLevel5) {
		this.prdHierLevel5 = prdHierLevel5;
	}

	public Character getExcptnTypeCd() {
		return excptnTypeCd;
	}

	public void setExcptnTypeCd(Character excptnTypeCd) {
		this.excptnTypeCd = excptnTypeCd;
	}

	public String getExcptionDesc() {
		return excptionDesc;
	}

	public void setExcptionDesc(String excptionDesc) {
		this.excptionDesc = excptionDesc;
	}

	public Character getExcptnProcessdInd() {
		return excptnProcessdInd;
	}

	public void setExcptnProcessdInd(Character excptnProcessdInd) {
		this.excptnProcessdInd = excptnProcessdInd;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public Character getLogicalInd() {
		return logicalInd;
	}

	public void setLogicalInd(Character logicalInd) {
		this.logicalInd = logicalInd;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "UIExceptionSrc [uiSrcPk=" + uiSrcPk + ", pluCd=" + pluCd
				+ ", prmyUpcInd=" + prmyUpcInd + ", itemUsgeInd=" + itemUsgeInd
				+ ", itemUsageTypInd=" + itemUsageTypInd + ", ptLabelInd="
				+ ptLabelInd + ", dispFlag=" + dispFlag + ", itmDesc="
				+ itmDesc + ", whseItmDesc=" + whseItmDesc + ", rtlItmDesc="
				+ rtlItmDesc + ", intenetItemDesc=" + intenetItemDesc
				+ ", posDesc=" + posDesc + ", vendConvFactor=" + vendConvFactor
				+ ", packwhse=" + packwhse + ", sizeNmbr=" + sizeNmbr
				+ ", sizeUom=" + sizeUom + ", sizeDesc=" + sizeDesc + ", cost="
				+ cost + ", prdHierLevel1=" + prdHierLevel1
				+ ", prdHierLevel2=" + prdHierLevel2 + ", prdHierLevel3="
				+ prdHierLevel3 + ", prdHierLevel4=" + prdHierLevel4
				+ ", prdHierLevel5=" + prdHierLevel5 + ", excptnTypeCd="
				+ excptnTypeCd + ", excptionDesc=" + excptionDesc
				+ ", excptnProcessdInd=" + excptnProcessdInd + ", batchId="
				+ batchId + ", logicalInd=" + logicalInd + ", deptDtl="
				+ deptDtl + ", getDeptDtl()=" + getDeptDtl() + ", getPluCd()="
				+ getPluCd() + ", getPrmyUpcInd()=" + getPrmyUpcInd()
				+ ", getItemUsgeInd()=" + getItemUsgeInd()
				+ ", getItemUsageTypInd()=" + getItemUsageTypInd()
				+ ", getPtLabelInd()=" + getPtLabelInd() + ", getDispFlag()="
				+ getDispFlag() + ", getItmDesc()=" + getItmDesc()
				+ ", getWhseItmDesc()=" + getWhseItmDesc()
				+ ", getRtlItmDesc()=" + getRtlItmDesc()
				+ ", getIntenetItemDesc()=" + getIntenetItemDesc()
				+ ", getPosDesc()=" + getPosDesc() + ", getVendConvFactor()="
				+ getVendConvFactor() + ", getPackwhse()=" + getPackwhse()
				+ ", getSizeNmbr()=" + getSizeNmbr() + ", getSizeUom()="
				+ getSizeUom() + ", getSizeDesc()=" + getSizeDesc()
				+ ", getCost()=" + getCost() + ", getPrdHierLevel1()="
				+ getPrdHierLevel1() + ", getPrdHierLevel2()="
				+ getPrdHierLevel2() + ", getPrdHierLevel3()="
				+ getPrdHierLevel3() + ", getPrdHierLevel4()="
				+ getPrdHierLevel4() + ", getPrdHierLevel5()="
				+ getPrdHierLevel5() + ", getExcptnTypeCd()="
				+ getExcptnTypeCd() + ", getExcptionDesc()="
				+ getExcptionDesc() + ", getExcptnProcessdInd()="
				+ getExcptnProcessdInd() + ", getBatchId()=" + getBatchId()
				+ ", getLogicalInd()=" + getLogicalInd() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public UiExceptionSrcPk getUiSrcPk() {
		return uiSrcPk;
	}

	public void setUiSrcPk(UiExceptionSrcPk uiSrcPk) {
		this.uiSrcPk = uiSrcPk;
	}

	public String getCaseUPC() {
		return caseUPC;
	}

	public void setCaseUPC(String caseUPC) {
		this.caseUPC = caseUPC;
	}

	public String getUpdatedUserID() {
		return updatedUserID;
	}

	public void setUpdatedUserID(String updatedUserID) {
		this.updatedUserID = updatedUserID;
	}

	public Date getCreateUpdateTimestamp() {
		return createUpdateTimestamp;
	}

	public void setCreateUpdateTimestamp(Date createUpdateTimestamp) {
		this.createUpdateTimestamp = createUpdateTimestamp;
	}

}