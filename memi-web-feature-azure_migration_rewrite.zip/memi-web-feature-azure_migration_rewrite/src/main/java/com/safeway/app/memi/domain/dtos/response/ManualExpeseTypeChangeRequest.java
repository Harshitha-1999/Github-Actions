package com.safeway.app.memi.domain.dtos.response;

public class ManualExpeseTypeChangeRequest {
	
	
	private String companyID;
	private String divisionID;
	private String sku;
	private String expenseTypeCurrent;
	private String expeseTypeChange;	
	private String updatedbyUser;
	
	public String getCompanyID() {
		return companyID;
	}
	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}
	public String getDivisionID() {
		return divisionID;
	}
	public void setDivisionID(String divisionID) {
		this.divisionID = divisionID;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getExpenseTypeCurrent() {
		return expenseTypeCurrent;
	}
	public void setExpenseTypeCurrent(String expenseTypeCurrent) {
		this.expenseTypeCurrent = expenseTypeCurrent;
	}
	public String getExpeseTypeChange() {
		return expeseTypeChange;
	}
	public void setExpeseTypeChange(String expeseTypeChange) {
		this.expeseTypeChange = expeseTypeChange;
	}
	public String getUpdatedbyUser() {
		return updatedbyUser;
	}
	public void setUpdatedbyUser(String updatedbyUser) {
		this.updatedbyUser = updatedbyUser;
	}
	
}
