/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */

package com.safeway.app.memi.domain.dtos.response;

 /**
  ****************************************************************************
  * NAME : PerishableItemTypeVO 
  * 
  * DESCRIPTION :PerishableItemTypeVO is the class identify the type of search	  
  * 
  * SYSTEM : MEMI 
  * 
  * AUTHOR : U63169
  * 
  * REVISION HISTORY
  * 
  * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
  * *************************************************************************
  */
public class PerishableItemTypeVO {
	
	private boolean all;
	private boolean system2;
	private boolean system4;
	private boolean plu;
	/**
	 * @return the all
	 */
	public boolean isAll() {
		return all;
	}
	/**
	 * @param all the all to set
	 */
	public void setAll(boolean all) {
		this.all = all;
	}
	/**
	 * @return the system2
	 */
	public boolean isSystem2() {
		return system2;
	}
	/**
	 * @param system2 the system2 to set
	 */
	public void setSystem2(boolean system2) {
		this.system2 = system2;
	}
	/**
	 * @return the system4
	 */
	public boolean isSystem4() {
		return system4;
	}
	/**
	 * @param system4 the system4 to set
	 */
	public void setSystem4(boolean system4) {
		this.system4 = system4;
	}
	/**
	 * @return the plu
	 */
	public boolean isPlu() {
		return plu;
	}
	/**
	 * @param plu the plu to set
	 */
	public void setPlu(boolean plu) {
		this.plu = plu;
	}
	
	

}
