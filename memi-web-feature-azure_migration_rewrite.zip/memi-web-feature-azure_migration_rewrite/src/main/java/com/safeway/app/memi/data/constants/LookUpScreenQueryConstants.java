package com.safeway.app.memi.data.constants;

public class LookUpScreenQueryConstants {
	
	private LookUpScreenQueryConstants()
	{
		
	}
	
	
	/**Query Parts**/
	public static final String VENDOR_DET = "WITH   ITEM_VENDOR_DETAILS   AS  (SELECT CORP.COMPANY_ID, CORP.DIVISION_ID,CORP.PRODUCT_SKU, DSD.VENDOR_ID, DVX.VENDOR_NM"
		            						+" FROM ECFLAND.ITEM_AGGREGATE_CORP  AS CORP  JOIN ECFLAND.ITEM_AGGREGATE_DSD  AS DSD  ON   CORP.COMPANY_ID = DSD.COMPANY_ID AND "
		            						+" CORP.DIVISION_ID = DSD.DIVISION_ID AND CORP.PRODUCT_SKU = DSD.PRODUCT_SKU LEFT JOIN XREFLAND.DSD_VENDOR_XREF  AS DVX ON  DSD.COMPANY_ID = DVX.COMPANY_ID AND "
		            						+" DSD.DIVISION_ID = DVX.DIVISION_ID AND  DSD.VENDOR_ID collate Latin1_General_CI_AS = DVX.VENDOR_ID  WHERE  CORP.COMPANY_ID = :companyId AND  CORP.DIVISION_ID = :divisionId AND "
		            						+" CORP.SOURCE_BY_DSD = 'Y' UNION SELECT CORP.COMPANY_ID, CORP.DIVISION_ID,CORP.PRODUCT_SKU, WHSE.PRIMARY_VENDOR_ID AS VENDOR_ID, "
		            						+" WVX.VENDOR_NM  FROM  ECFLAND.ITEM_AGGREGATE_CORP  AS CORP JOIN ECFLAND.ITEM_AGGREGATE_WHSE  AS WHSE ON CORP.COMPANY_ID = WHSE.COMPANY_ID AND "
		            						+" CORP.DIVISION_ID = WHSE.DIVISION_ID AND CORP.PRODUCT_SKU = WHSE.PRODUCT_SKU LEFT JOIN XREFLAND.WHSE_VENDOR_XREF  AS WVX ON WHSE.COMPANY_ID = WVX.COMPANY_ID AND "
		            						+" WHSE.DIVISION_ID = WVX.DIVISION_ID AND WHSE.PRIMARY_VENDOR_ID = WVX.VENDOR_ID WHERE CORP.COMPANY_ID = :companyId AND CORP.DIVISION_ID = :divisionId AND CORP.SOURCE_BY_WHSE = 'Y' ),";
		    
	
	public static final String PH1=" PH1  AS ( SELECT COMPANY_ID, DIVISION_ID,PROD_HIERARCHY_LVL_1_CD, PROD_HIERARCHY_LVL_2_CD, PROD_HIERARCHY_LVL_3_CD, HIERARCHY_LEVEL_DESC "
									+" FROM ECFLAND.PRODUCT_HIERARCHY WHERE CAST(PRODUCT_HIERARCHY.COMPANY_ID AS numeric(38, 10)) =:companyId AND CAST(PRODUCT_HIERARCHY.DIVISION_ID AS numeric(38, 10))  = :divisionId "
									+" AND HIERARCHY_LEVEL_NM     = 'CATGRY_NUM' GROUP BY COMPANY_ID, DIVISION_ID,PROD_HIERARCHY_LVL_1_CD, PROD_HIERARCHY_LVL_2_CD, PROD_HIERARCHY_LVL_3_CD,   HIERARCHY_LEVEL_DESC  ),";	
	public static final String PH2="PH2" + 
			"    AS" + 
			"    (" + 
			"        SELECT" + 
			"            PRODUCT_HIERARCHY.COMPANY_ID," + 
			"            PRODUCT_HIERARCHY.DIVISION_ID," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_1_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_2_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_3_CD," + 
			"            PRODUCT_HIERARCHY.HIERARCHY_LEVEL_DESC" + 
			"        FROM ECFLAND.PRODUCT_HIERARCHY" + 
			"        WHERE " + 
			"         CAST(PRODUCT_HIERARCHY.COMPANY_ID AS numeric(38, 10)) = :companyId AND" + 
			"            CAST(PRODUCT_HIERARCHY.DIVISION_ID AS numeric(38, 10)) = :divisionId AND" + 
			"            PRODUCT_HIERARCHY.HIERARCHY_LEVEL_NM = 'SUB_CATGRY_NUM'" + 
			"        GROUP BY " + 
			"         PRODUCT_HIERARCHY.COMPANY_ID, " + 
			"         PRODUCT_HIERARCHY.DIVISION_ID, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_1_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_2_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_3_CD, " + 
			"         PRODUCT_HIERARCHY.HIERARCHY_LEVEL_DESC" + 
			"    ),";
	public static final String PH3= " PH3" + 
			"    AS" + 
			"    (" + 
			"        SELECT" + 
			"            PRODUCT_HIERARCHY.COMPANY_ID," + 
			"            PRODUCT_HIERARCHY.DIVISION_ID," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_1_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_2_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_3_CD," + 
			"            PRODUCT_HIERARCHY.HIERARCHY_LEVEL_DESC" + 
			"        FROM ECFLAND.PRODUCT_HIERARCHY" + 
			"        WHERE " + 
			"         CAST(PRODUCT_HIERARCHY.COMPANY_ID AS numeric(38, 10)) = :companyId AND" + 
			"            CAST(PRODUCT_HIERARCHY.DIVISION_ID AS numeric(38, 10)) = :divisionId AND" + 
			"            PRODUCT_HIERARCHY.HIERARCHY_LEVEL_NM = 'GRP_ID'" + 
			"        GROUP BY " + 
			"         PRODUCT_HIERARCHY.COMPANY_ID, " + 
			"         PRODUCT_HIERARCHY.DIVISION_ID, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_1_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_2_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_3_CD, " + 
			"         PRODUCT_HIERARCHY.HIERARCHY_LEVEL_DESC" + 
			"    ), ";
	public static final String PH4= "PH4" + 
			"    AS" + 
			"    (" + 
			"        SELECT" + 
			"            PRODUCT_HIERARCHY.COMPANY_ID," + 
			"            PRODUCT_HIERARCHY.DIVISION_ID," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_1_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_2_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_3_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_4_CD," + 
			"            PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_5_CD," + 
			"            PRODUCT_HIERARCHY.DEPARTMENT_CD," + 
			"            PRODUCT_HIERARCHY.DEPARTMENT_NM" + 
			"        FROM ECFLAND.PRODUCT_HIERARCHY" + 
			"        WHERE CAST(PRODUCT_HIERARCHY.COMPANY_ID AS numeric(38, 10)) = :companyId" + 
			"            AND CAST(PRODUCT_HIERARCHY.DIVISION_ID AS numeric(38, 10)) = :divisionId" + 
			"        GROUP BY " + 
			"         PRODUCT_HIERARCHY.COMPANY_ID, " + 
			"         PRODUCT_HIERARCHY.DIVISION_ID, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_1_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_2_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_3_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_4_CD, " + 
			"         PRODUCT_HIERARCHY.PROD_HIERARCHY_LVL_5_CD, " + 
			"         PRODUCT_HIERARCHY.DEPARTMENT_CD, " + 
			"         PRODUCT_HIERARCHY.DEPARTMENT_NM" + 
			"    ),";
	 
	public static final String SRC_BASE =  "SRC" + 
			"    AS" + 
			"    (" + 
			"        SELECT" + 
			"            TMP1.RNUM," + 
			"            TMP1.CONVERSION_GROUP," + 
			"            TMP1.DEPARTMENT_CD," + 
			"            TMP1.DEPARTMENT_NM," + 
			"            TMP1.PROD_HIERARCHY_LVL_1_CD," + 
			"            TMP1.PROD_HIERARCHY_LVL_2_CD," + 
			"            TMP1.PROD_HIERARCHY_LVL_3_CD," + 
			"            TMP1.PROD_HIERARCHY_LVL_4_CD," + 
			"            TMP1.PROD_HIERARCHY_LVL_5_CD," + 
			"            TMP1.PROD_HIERARCHY_LVL_1_NM," + 
			"            TMP1.PROD_HIERARCHY_LVL_2_NM," + 
			"            TMP1.PROD_HIERARCHY_LVL_3_NM," + 
			"            TMP1.SRC_SUPPLIER_NUM," + 
			"            TMP1.PRODUCT_SKU," + 
			"            TMP1.ITEM_DESC," + 
			"            TMP1.SHIPPING_PACK_NBR," + 
			"            TMP1.VCF," + 
			"            TMP1.SIZE_DESC," + 
			"            TMP1.SIZE_NBR," + 
			"            TMP1.SIZE_UOM_CD," + 
			"            TMP1.UPC," + 
			"            TMP1.SRC_UPC_COUNTRY," + 
			"            TMP1.SRC_UPC_SYSTEM," + 
			"            TMP1.SRC_UPC_MANUF," + 
			"            TMP1.SRC_UPC_SALES," + 
			"            TMP1.WHSE_DSD," + 
			"            TMP1.ROG," + 
			"            TMP1.CONV_STATUS_CD," + 
			"            TMP1.CONV_STATUS_SUB_CD," + 
			"            TMP1.CORP_ITEM_CD," + 
			"            TMP1.EXCEPTION_CORP_ITEM_CD," + 
			"            TMP1.VENDOR_NM" + 
			"        FROM" + 
			"            (" + 
			"           SELECT" + 
			"                SSMAROWNUM.ROWNUM AS RNUM," + 
			"                SSMAROWNUM.CONVERSION_GROUP," + 
			"                SSMAROWNUM.DEPARTMENT_CD," + 
			"                SSMAROWNUM.DEPARTMENT_NM," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_1_CD," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_2_CD," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_3_CD," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_4_CD," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_5_CD," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_1_NM," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_2_NM," + 
			"                SSMAROWNUM.PROD_HIERARCHY_LVL_3_NM," + 
			"                SSMAROWNUM.SRC_SUPPLIER_NUM," + 
			"                SSMAROWNUM.PRODUCT_SKU," + 
			"                SSMAROWNUM.ITEM_DESC," + 
			"                SSMAROWNUM.SHIPPING_PACK_NBR," + 
			"                SSMAROWNUM.VCF," + 
			"                SSMAROWNUM.SIZE_DESC," + 
			"                SSMAROWNUM.SIZE_NBR," + 
			"                SSMAROWNUM.SIZE_UOM_CD," + 
			"                SSMAROWNUM.UPC," + 
			"                SSMAROWNUM.SRC_UPC_COUNTRY," + 
			"                SSMAROWNUM.SRC_UPC_SYSTEM," + 
			"                SSMAROWNUM.SRC_UPC_MANUF," + 
			"                SSMAROWNUM.SRC_UPC_SALES," + 
			"                SSMAROWNUM.WHSE_DSD," + 
			"                SSMAROWNUM.ROG," + 
			"                SSMAROWNUM.CONV_STATUS_CD," + 
			"                SSMAROWNUM.CONV_STATUS_SUB_CD," + 
			"                SSMAROWNUM.CORP_ITEM_CD," + 
			"                SSMAROWNUM.EXCEPTION_CORP_ITEM_CD," + 
			"                SSMAROWNUM.VENDOR_NM" + 
			"            FROM" + 
			"                (" + 
			"                  SELECT" + 
			"                    CONVERSION_GROUP," + 
			"                    DEPARTMENT_CD," + 
			"                    DEPARTMENT_NM," + 
			"                    PROD_HIERARCHY_LVL_1_CD," + 
			"                    PROD_HIERARCHY_LVL_2_CD," + 
			"                    PROD_HIERARCHY_LVL_3_CD," + 
			"                    PROD_HIERARCHY_LVL_4_CD," + 
			"                    PROD_HIERARCHY_LVL_5_CD," + 
			"                    PROD_HIERARCHY_LVL_1_NM," + 
			"                    PROD_HIERARCHY_LVL_2_NM," + 
			"                    PROD_HIERARCHY_LVL_3_NM," + 
			"                    SRC_SUPPLIER_NUM," + 
			"                    PRODUCT_SKU," + 
			"                    ITEM_DESC," + 
			"                    SHIPPING_PACK_NBR," + 
			"                    VCF," + 
			"                    SIZE_DESC," + 
			"                    SIZE_NBR," + 
			"                    SIZE_UOM_CD," + 
			"                    UPC," + 
			"                    SRC_UPC_COUNTRY," + 
			"                    SRC_UPC_SYSTEM," + 
			"                    SRC_UPC_MANUF," + 
			"                    SRC_UPC_SALES," + 
			"                    WHSE_DSD," + 
			"                    ROG," + 
			"                    CONV_STATUS_CD," + 
			"                    CONV_STATUS_SUB_CD," + 
			"                    CORP_ITEM_CD," + 
			"                    EXCEPTION_CORP_ITEM_CD," + 
			"                    VENDOR_NM," + 
			"                    ROW_NUMBER() OVER(" + 
			"                        ORDER BY SSMAPSEUDOCOLUMN) AS ROWNUM" + 
			"                FROM" + 
			"                    (" + 
			"                        SELECT" + 
			"                        TMP.CONVERSION_GROUP," + 
			"                        TMP.DEPARTMENT_CD," + 
			"                        TMP.DEPARTMENT_NM," + 
			"                        TMP.PROD_HIERARCHY_LVL_1_CD," + 
			"                        TMP.PROD_HIERARCHY_LVL_2_CD," + 
			"                        TMP.PROD_HIERARCHY_LVL_3_CD," + 
			"                        TMP.PROD_HIERARCHY_LVL_4_CD," + 
			"                        TMP.PROD_HIERARCHY_LVL_5_CD," + 
			"                        TMP.PROD_HIERARCHY_LVL_1_NM," + 
			"                        TMP.PROD_HIERARCHY_LVL_2_NM," + 
			"                        TMP.PROD_HIERARCHY_LVL_3_NM," + 
			"                        TMP.SRC_SUPPLIER_NUM," + 
			"                        TMP.PRODUCT_SKU," + 
			"                        TMP.ITEM_DESC," + 
			"                        TMP.SHIPPING_PACK_NBR," + 
			"                        TMP.VCF," + 
			"                        TMP.SIZE_DESC," + 
			"                        TMP.SIZE_NBR," + 
			"                        TMP.SIZE_UOM_CD," + 
			"                        TMP.UPC," + 
			"                        TMP.SRC_UPC_COUNTRY," + 
			"                        TMP.SRC_UPC_SYSTEM," + 
			"                        TMP.SRC_UPC_MANUF," + 
			"                        TMP.SRC_UPC_SALES," + 
			"                        TMP.WHSE_DSD," + 
			"                        TMP.ROG," + 
			"                        TMP.CONV_STATUS_CD," + 
			"                        TMP.CONV_STATUS_SUB_CD," + 
			"                        TMP.CORP_ITEM_CD," + 
			"                        TMP.EXCEPTION_CORP_ITEM_CD," + 
			"                        TMP.VENDOR_NM," + 
			"                        0 AS SSMAPSEUDOCOLUMN" + 
			"                    FROM" + 
			"                        (" + 
			"                              SELECT DISTINCT" + 
			"                            PH4.PROD_HIERARCHY_LVL_5_CD AS CONVERSION_GROUP," + 
			"                            PH4.DEPARTMENT_CD," + 
			"                            PH4.DEPARTMENT_NM," + 
			"                            D.PROD_HIERARCHY_LVL_1_CD AS PROD_HIERARCHY_LVL_1_CD," + 
			"                            D.PROD_HIERARCHY_LVL_2_CD AS PROD_HIERARCHY_LVL_2_CD," + 
			"                            D.PROD_HIERARCHY_LVL_3_CD AS PROD_HIERARCHY_LVL_3_CD," + 
			"                            D.PROD_HIERARCHY_LVL_4_CD AS PROD_HIERARCHY_LVL_4_CD," + 
			"                            D.PROD_HIERARCHY_LVL_5_CD AS PROD_HIERARCHY_LVL_5_CD," + 
			"                            PH1.HIERARCHY_LEVEL_DESC AS PROD_HIERARCHY_LVL_1_NM," + 
			"                            PH2.HIERARCHY_LEVEL_DESC AS PROD_HIERARCHY_LVL_2_NM," + 
			"                            PH3.HIERARCHY_LEVEL_DESC AS PROD_HIERARCHY_LVL_3_NM," + 
			"                            XRF.SRC_SUPPLIER_NUM AS SRC_SUPPLIER_NUM," + 
			"                            D.PRODUCT_SKU AS PRODUCT_SKU," + 
			"                            D.ITEM_DESC AS ITEM_DESC," + 
			"                            D.SHIPPING_PACK_NBR AS SHIPPING_PACK_NBR," + 
			"                            (D.MASTER_CASE_PACK_NBR / nullif(D.SHIPPING_PACK_NBR, 0)) AS VCF," + 
			"                            D.SIZE_DESC AS SIZE_DESC," + 
			"                            D.SIZE_NBR AS SIZE_NBR," + 
			"                            D.SIZE_UOM_CD AS SIZE_UOM_CD," + 
			"                            D.UPC AS UPC," + 
			"                            XRF.SRC_UPC_COUNTRY," + 
			"                            XRF.SRC_UPC_SYSTEM," + 
			"                            XRF.SRC_UPC_MANUF," + 
			"                            XRF.SRC_UPC_SALES," + 
			"                            CASE " + 
			"                                    WHEN D.SOURCE_BY_WHSE = 'Y' THEN 'WHSE'" + 
			"                                    WHEN D.SOURCE_BY_DSD = 'Y' THEN 'DSD'" + 
			"                                 END AS WHSE_DSD," + 
			"                            XRF.ROG AS ROG," + 
			"                            XRF.CONV_STATUS_CD AS CONV_STATUS_CD," + 
			"                            XRF.CONV_STATUS_SUB_CD AS CONV_STATUS_SUB_CD," + 
			"                            XRF.CORP_ITEM_CD AS CORP_ITEM_CD," + 
			"                            XRF.EXCEPTION_CORP_ITEM_CD AS EXCEPTION_CORP_ITEM_CD," + 
			"                            IV.VENDOR_NM" + 
			"                        FROM" + 
			"                            XREFLAND.SRC_ITEM_XRF  AS XRF" + 
			"                            JOIN ECFLAND.ITEM_AGGREGATE_CORP  AS D" + 
			"                            ON " + 
			"                                       XRF.COMPANY_ID = D.COMPANY_ID AND" + 
			"                                XRF.DIVISION_ID = D.DIVISION_ID AND" + 
			"                                XRF.SRC_PRODUCT_SKU = D.PRODUCT_SKU AND" + 
			"                                XRF.SRC_UPC = D.UPC" + 
			"                            LEFT JOIN ITEM_VENDOR_DETAILS  AS IV" + 
			"                            ON " + 
			"                                       XRF.COMPANY_ID = IV.COMPANY_ID AND" + 
			"                                XRF.DIVISION_ID = IV.DIVISION_ID AND" + 
			"                                XRF.SRC_PRODUCT_SKU = IV.PRODUCT_SKU AND" + 
			"                                XRF.SRC_SUPPLIER_NUM = IV.VENDOR_ID" + 
			"                            LEFT JOIN PH1" + 
			"                            ON " + 
			"                                       D.COMPANY_ID = PH1.COMPANY_ID AND" + 
			"                                D.DIVISION_ID = PH1.DIVISION_ID AND" + 
			"                                D.PROD_HIERARCHY_LVL_1_CD = PH1.PROD_HIERARCHY_LVL_1_CD AND" + 
			"                                PH1.PROD_HIERARCHY_LVL_2_CD = 0 AND" + 
			"                                PH1.PROD_HIERARCHY_LVL_3_CD = 0" + 
			"                            LEFT JOIN PH2" + 
			"                            ON " + 
			"                                       D.COMPANY_ID = PH2.COMPANY_ID AND" + 
			"                                D.DIVISION_ID = PH2.DIVISION_ID AND" + 
			"                                D.PROD_HIERARCHY_LVL_1_CD = PH2.PROD_HIERARCHY_LVL_1_CD AND" + 
			"                                D.PROD_HIERARCHY_LVL_2_CD = PH2.PROD_HIERARCHY_LVL_2_CD AND" + 
			"                                PH2.PROD_HIERARCHY_LVL_3_CD = 0" + 
			"                            LEFT JOIN PH3" + 
			"                            ON " + 
			"                                       D.COMPANY_ID = PH3.COMPANY_ID AND" + 
			"                                D.DIVISION_ID = PH3.DIVISION_ID AND" + 
			"                                D.PROD_HIERARCHY_LVL_1_CD = PH3.PROD_HIERARCHY_LVL_1_CD AND" + 
			"                                D.PROD_HIERARCHY_LVL_2_CD = PH3.PROD_HIERARCHY_LVL_2_CD AND" + 
			"                                D.PROD_HIERARCHY_LVL_3_CD = PH3.PROD_HIERARCHY_LVL_3_CD" + 
			"                            LEFT JOIN PH4" + 
			"                            ON " + 
			"                                       D.COMPANY_ID = PH4.COMPANY_ID AND" + 
			"                                D.DIVISION_ID = PH4.DIVISION_ID AND" + 
			"                                D.PROD_HIERARCHY_LVL_1_CD = PH4.PROD_HIERARCHY_LVL_1_CD AND" + 
			"                                D.PROD_HIERARCHY_LVL_2_CD = PH4.PROD_HIERARCHY_LVL_2_CD AND" + 
			"                                D.PROD_HIERARCHY_LVL_3_CD = PH4.PROD_HIERARCHY_LVL_3_CD" + 
			"                            LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE  AS MUT" + 
			"                            ON " + 
			"                                       XRF.COMPANY_ID = MUT.COMPANY_ID AND" + 
			"                                XRF.DIVISION_ID = MUT.DIVISION_ID AND" + 
			"                                XRF.SRC_PRODUCT_SKU = MUT.PRODUCT_SKU ";
		                        
		                           
									


	public static final String SRC_BASE_CONDN = " WHERE " + 
			"                                 XRF.COMPANY_ID = :companyId AND" + 
			"                            XRF.DIVISION_ID = :divisionId AND" + 
			"                            PH4.PROD_HIERARCHY_LVL_4_CD = :prodHierarchyLvl4Cd";
	

	public static final String SRC_WRAPPER =")  AS TMP" + 
			"                     )  AS SSMAPSEUDO" + 
			"               )  AS SSMAROWNUM" + 
			"         )  AS TMP1" + 
			"        WHERE TMP1.RNUM >= :start_index AND TMP1.RNUM <= :end_index" + 
			"    ),";	  
	
	public static final String TGT_BASEQUERY= "TGT" + 
			"    AS" + 
			"    (" + 
			"        SELECT" + 
			"            CDS.CORP_ITEM_CD AS TGT_CORP_ITEM_CD," + 
			"            CDS.DESC_ITEM," + 
			"            CDS.PACK_WHSE," + 
			"            CDS.VEND_CONV_FCTR," + 
			"            CDS.CDS_SIZE," + 
			"            CDS.SIZE_NUM," + 
			"            CDS.SIZE_UOM," + 
			"            CDS.ITEM_USAGE_TYPE," + 
			"            CDS.ITEM_USAGE_IND," + 
			"            CDS.DISP_FLAG," + 
			"            CDS.GROUP_CD," + 
			"            CDS.CTGRY_CD," + 
			"            CDS.CLASS_CD," + 
			"            CDS.SUB_CLASS_CD," + 
			"            CDS.SUBSB_CLASS_CD," + 
			"            X2.UPC_COUNTRY AS TGT_UPC_COUNTRY," + 
			"            X2.UPC_SYSTEM AS TGT_UPC_SYSTEM," + 
			"            X2.UPC_MANUF AS TGT_UPC_MANUF," + 
			"            X2.UPC_SALES AS TGT_UPC_SALES," + 
			"            X2.UNIT_TYPE," + 
			"            WDS.DIVISION," + 
			"            WDS.DST_CNTR," + 
			"            WDS.FACILITY," + 
			"            WDS.PACK_DESC AS WDS_PACK_DESC," + 
			"            WDS.SIZE_DESC AS WDS_SIZE_DESC," + 
			"            URX.PACK_RETAIL," + 
			"            URX.PACK_DESC AS URX_PACK_DESC," + 
			"            URX.SIZE_DESC AS URX_SIZE_DESC," + 
			"            URX.PRIMARY_UPC_SW," + 
			"            POS.PLU_CD," + 
			"            POS.RING," + 
			"            POS.HICONE," + 
			"            POS.GIFT_CARD_TYPE_IND," + 
			"" + 
			"            ISNULL(CAST(X2.UPC_COUNTRY AS nvarchar(max)), '')" + 
			"             + " + 
			"            '-'" + 
			"             + " + 
			"            ISNULL(CAST(X2.UPC_SYSTEM AS nvarchar(max)), '')" + 
			"             + " + 
			"            '-'" + 
			"             + " + 
			"            ISNULL(ssma_oracle.lpad_nvarchar(X2.UPC_MANUF, 5, '0'), '')" + 
			"             + " + 
			"            '-'" + 
			"             + " + 
			"            ISNULL(ssma_oracle.lpad_nvarchar(X2.UPC_SALES, 5, '0'), '') AS expr" + 
			"        FROM" + 
			"            SRC  AS X1" + 
			"            INNER JOIN SSIMSLAND.SQLDAT3_SSITMCDS  AS CDS" + 
			"            ON X1.CORP_ITEM_CD = CDS.CORP_ITEM_CD" + 
			"            INNER JOIN SSIMSLAND.SQLDAT3_SSITMXRF  AS X2" + 
			"            ON " + 
			"               CDS.CORP_ITEM_CD = X2.CORP_ITEM_CD AND" + 
			"                X1.SRC_UPC_COUNTRY = X2.UPC_COUNTRY AND" + 
			"                X1.SRC_UPC_SYSTEM = X2.UPC_SYSTEM AND" + 
			"                X1.SRC_UPC_MANUF = X2.UPC_MANUF AND" + 
			"                X1.SRC_UPC_SALES = X2.UPC_SALES" + 
			"            INNER JOIN SSIMSLAND.SQLDAT3_SSITMWDS  AS WDS" + 
			"            ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD" + 
			"            INNER JOIN SSIMSLAND.SQLDAT3_SSITMROG  AS ROG" + 
			"            ON " + 
			"               WDS.CORP = ROG.CORP_ORD AND" + 
			"                WDS.DIVISION = ROG.DIVISION_ORD AND" + 
			"                WDS.FACILITY = ROG.FACILITY AND" + 
			"                WDS.CORP_ITEM_CD = ROG.CORP_ITEM_CD AND" + 
			"                X1.ROG = ROG.ROG" + 
			"            INNER JOIN SSIMSLAND.SQLDAT3_SSITMURX  AS URX" + 
			"            ON " + 
			"               ROG.CORP = URX.CORP AND" + 
			"                ROG.ROG = URX.ROG AND" + 
			"                X1.ROG = URX.ROG AND" + 
			"                ROG.CORP_ITEM_CD = URX.CORP_ITEM_CD AND" + 
			"                X2.CORP_ITEM_CD = URX.CORP_ITEM_CD AND" + 
			"                X2.UPC_COUNTRY = URX.UPC_COUNTRY AND" + 
			"                X2.UPC_SYSTEM = URX.UPC_SYSTEM AND" + 
			"                X2.UPC_MANUF = URX.UPC_MANUF AND" + 
			"                X2.UPC_SALES = URX.UPC_SALES AND" + 
			"                X1.SRC_UPC_COUNTRY = URX.UPC_COUNTRY AND" + 
			"                X1.SRC_UPC_SYSTEM = URX.UPC_SYSTEM AND" + 
			"                X1.SRC_UPC_MANUF = URX.UPC_MANUF AND" + 
			"                X1.SRC_UPC_SALES = URX.UPC_SALES" + 
			"            INNER JOIN SSIMSLAND.SQLDAT3_SSITMPOS  AS POS" + 
			"            ON " + 
			"               URX.CORP = POS.CORP AND" + 
			"                URX.ROG = POS.ROG AND" + 
			"                X1.ROG = POS.ROG AND" + 
			"                URX.UPC_COUNTRY = POS.UPC_COUNTRY AND" + 
			"                URX.UPC_SYSTEM = POS.UPC_SYSTEM AND" + 
			"                URX.UPC_MANUF = POS.UPC_MANUF AND" + 
			"                URX.UPC_SALES = POS.UPC_SALES AND" + 
			"                X1.SRC_UPC_COUNTRY = POS.UPC_COUNTRY AND" + 
			"                X1.SRC_UPC_SYSTEM = POS.UPC_SYSTEM AND" + 
			"                X1.SRC_UPC_MANUF = POS.UPC_MANUF AND" + 
			"                X1.SRC_UPC_SALES = POS.UPC_SALES" + 
			"        WHERE X1.CONV_STATUS_CD = 'C'" + 
			"    ) ";

	public static final String TGT_END_QUERY = " SELECT DISTINCT" + 
			"    SRC.RNUM," + 
			"    SRC.CONVERSION_GROUP," + 
			"    SRC.DEPARTMENT_CD," + 
			"    SRC.DEPARTMENT_NM," + 
			"    SRC.PROD_HIERARCHY_LVL_1_CD," + 
			"    SRC.PROD_HIERARCHY_LVL_2_CD," + 
			"    SRC.PROD_HIERARCHY_LVL_3_CD," + 
			"    SRC.PROD_HIERARCHY_LVL_4_CD," + 
			"    SRC.PROD_HIERARCHY_LVL_5_CD," + 
			"    SRC.PROD_HIERARCHY_LVL_1_NM," + 
			"    SRC.PROD_HIERARCHY_LVL_2_NM," + 
			"    SRC.PROD_HIERARCHY_LVL_3_NM," + 
			"    CASE LEN(SRC.SRC_SUPPLIER_NUM) " +
		    "	 WHEN 6 THEN CONCAT('0',SRC.SRC_SUPPLIER_NUM) " +
		    "	 WHEN 5 THEN CONCAT('00',SRC.SRC_SUPPLIER_NUM) " +
		    "	 WHEN 4 THEN CONCAT('000',SRC.SRC_SUPPLIER_NUM) " +
		    "	 WHEN 3 THEN CONCAT('0000',SRC.SRC_SUPPLIER_NUM) " +
		    "	 WHEN 2 THEN CONCAT('00000',SRC.SRC_SUPPLIER_NUM) " +
		    "	 WHEN 1 THEN CONCAT('000000',SRC.SRC_SUPPLIER_NUM) " +
		    "	 ELSE SRC.SRC_SUPPLIER_NUM " +
		    "	 END AS SRC_SUPPLIER_NUM, " +
			"    SRC.PRODUCT_SKU," + 
			"    SRC.ITEM_DESC," + 
			"    SRC.SHIPPING_PACK_NBR," + 
			"    SRC.VCF," + 
			"    SRC.SIZE_DESC," + 
			"    SRC.SIZE_NBR," + 
			"    SRC.SIZE_UOM_CD," + 
			"    SRC.UPC," + 
			"    SRC.SRC_UPC_COUNTRY," + 
			"    SRC.SRC_UPC_SYSTEM," + 
			"    SRC.SRC_UPC_MANUF," + 
			"    SRC.SRC_UPC_SALES," + 
			"    SRC.WHSE_DSD," + 
			"    SRC.ROG," + 
			"    SRC.CONV_STATUS_CD," + 
			"    SRC.CONV_STATUS_SUB_CD," + 
			"    SRC.CORP_ITEM_CD," + 
			"    SRC.EXCEPTION_CORP_ITEM_CD," + 
			"    SRC.VENDOR_NM," + 
			"    TGT.TGT_CORP_ITEM_CD," + 
			"    TGT.DESC_ITEM," + 
			"    TGT.PACK_WHSE," + 
			"    TGT.VEND_CONV_FCTR," + 
			"    TGT.CDS_SIZE," + 
			"    TGT.SIZE_NUM," + 
			"    TGT.SIZE_UOM," + 
			"    TGT.ITEM_USAGE_TYPE," + 
			"    TGT.ITEM_USAGE_IND," + 
			"    TGT.DISP_FLAG," + 
			"    TGT.GROUP_CD," + 
			"    TGT.CTGRY_CD," + 
			"    TGT.CLASS_CD," + 
			"    TGT.SUB_CLASS_CD," + 
			"    TGT.SUBSB_CLASS_CD," + 
			"    TGT.TGT_UPC_COUNTRY," + 
			"    TGT.TGT_UPC_SYSTEM," + 
			"    TGT.TGT_UPC_MANUF," + 
			"    TGT.TGT_UPC_SALES," + 
			"    TGT.UNIT_TYPE," + 
			"    TGT.DIVISION," + 
			"    TGT.DST_CNTR," + 
			"    TGT.FACILITY," + 
			"    TGT.WDS_PACK_DESC," + 
			"    TGT.WDS_SIZE_DESC," + 
			"    TGT.PACK_RETAIL," + 
			"    TGT.URX_PACK_DESC," + 
			"    TGT.URX_SIZE_DESC," + 
			"    TGT.PRIMARY_UPC_SW," + 
			"    TGT.PLU_CD," + 
			"    TGT.RING," + 
			"    TGT.HICONE," + 
			"    TGT.GIFT_CARD_TYPE_IND," + 
			"    TGT.expr" + 
			" FROM" + 
			"    SRC" + 
			"    LEFT JOIN TGT" + 
			"    ON SRC.CORP_ITEM_CD = TGT.TGT_CORP_ITEM_CD AND" + 
			"        CASE " + 
			"            WHEN SRC.CONV_STATUS_CD = 'C' THEN 1" + 
			"            ELSE 0" + 
			"         END = 1 " ;
			//" GO";
	
	
	
	
	
}
	

