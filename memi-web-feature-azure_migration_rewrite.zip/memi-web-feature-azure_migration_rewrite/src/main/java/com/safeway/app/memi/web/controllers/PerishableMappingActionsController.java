package com.safeway.app.memi.web.controllers;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.safeway.app.memi.domain.dtos.response.ManualExpeseTypeChangeRequest;
import com.safeway.app.memi.domain.dtos.response.PerishableItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequest;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableSearchRequestVO;
import com.safeway.app.memi.domain.services.PerishableMappingServices;
import com.safeway.app.memi.domain.util.ActionValidations;
import com.safeway.app.memi.domain.util.PerishableConstants;

/**
 ****************************************************************************
 * NAME			: PerishableMappingActionsController 
 * 
 * DESCRIPTION	: PerishableMappingActionsController is the controller class for performing 
 * 				  different actions in mapping screen.
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U47849
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Feb 02, 2018  - Initial Creation
 * *************************************************************************
 */

@Controller
@RequestMapping("/perishable")
public class PerishableMappingActionsController {
	private static final Logger LOG = LoggerFactory.getLogger(PerishableMappingActionsController.class);

    @Autowired
    private PerishableMappingServices perishableMappingServices;
    
    @Autowired
    private ActionValidations actionValidations;
   
   /**
    * Method for perishable actions
 * @param PerishableSearchRequestVO 
 * @throws Exception 
    */
   
   @RequestMapping(value = "/actions", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
   public @ResponseBody PerishableMappingRequestWrapper perishableAction(@RequestBody PerishableMappingRequestWrapper mappingRequest) throws Exception {
	   LOG.info("Started Execution for  perishable Action.");
		List<PerishableMappingRequest> perishableMappingRequest = mappingRequest.getMappingrequest();
		String actionSuccess ="0";
		if(mappingRequest.isFromMappedScreen()){
			unmapAction(mappingRequest, perishableMappingRequest);
			
		}else{
			List<String> validateActionsResult =new ArrayList();
			validateActionsResult = actionValidations.validateActions(perishableMappingRequest);
			boolean duplicate = perishableMappingServices.duplicateCheckOnMappedItems(perishableMappingRequest);
			/* validates the mapping request objects */
			
			if (duplicate) {
				validateActionsResult.add("Already mapped sources are selected");
				mappingRequest.setErrorMessages(validateActionsResult);
			} else if (validateActionsResult.isEmpty()) {
				perishableMappingServices.performAction(mappingRequest);
				validateActionsResult.add("Mapped succesfully");
				mappingRequest.setErrorMessages(validateActionsResult);
				actionSuccess ="1";
			} else {
				mappingRequest.setErrorMessages(validateActionsResult);
			}
			

			/* Loads source and target data based on existing search inputs */
			if (mappingRequest.getSourceSearchRequest() != null && actionSuccess.equalsIgnoreCase("1") ) {
				mappingRequest.setSourceSearchRequest(perishableMappingServices.listSKUPerishableItems(mappingRequest.getSourceSearchRequest()));
			}
			/* Restrict target loading in case of add or inherit map performed*/
			boolean targetLoad =false;
			for(int i=0; i< perishableMappingRequest.size() && !targetLoad ; i++ )
			{  
				if(perishableMappingRequest.get(i).getMappingType().equals("ADD_MAP")||
						perishableMappingRequest.get(i).getMappingType().equals("INHERIT_MAP"))
				{
					targetLoad=true;
					break;
				}
				
			}
			if (mappingRequest.getTargetSearchRequest() != null && targetLoad && actionSuccess.equalsIgnoreCase("1") ) {
				PerishableSearchRequestVO perishableSearchRequestVO = perishableMappingServices
						.listCICPerishableItems(mappingRequest.getTargetSearchRequest());
				mappingRequest.getTargetSearchRequest().setCicSearchResults(perishableSearchRequestVO.getCicSearchResults());
				mappingRequest.getTargetSearchRequest().setTargetCount(perishableSearchRequestVO.getTargetCount());
				
			}
		}
		mappingRequest.setActionSuccessStatus(Integer.parseInt(actionSuccess));
		LOG.info("Completed the action");
		return mappingRequest;
	   
   }

/**
 * @param mappingRequest
 * @param perishableMappingRequest
 */
private void unmapAction(PerishableMappingRequestWrapper mappingRequest,
		List<PerishableMappingRequest> perishableMappingRequest) {
	LOG.debug("Started execution for the unmap Action");

	List<String> validateActionsResult = actionValidations.validateUnmapActions(perishableMappingRequest);
	if(CollectionUtils.isEmpty(validateActionsResult)){
		validateActionsResult = new ArrayList<String>();
		perishableMappingServices.performAction(mappingRequest);
		validateActionsResult.add("Mapped succesfully");
	}			
	mappingRequest.setErrorMessages(validateActionsResult);
	if (mappingRequest.getMappedSearchRequest() != null) {
		List<PerishableMappedResultWrapper> perishableMappedResultWrappers = perishableMappingServices
				.listMappedData(mappingRequest.getMappedSearchRequest());
		if(!CollectionUtils.isEmpty(perishableMappedResultWrappers)){
			mappingRequest.getMappedSearchRequest().setMappedResultWrapper(perishableMappedResultWrappers);
		}
		
	}
	LOG.debug("completed execution for the unmap Action");

}

   @RequestMapping(value = "/forcenew",  method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
   public @ResponseBody Map<String,String> perishableActionForceNew(@RequestBody List<PerishableMappingRequest> perishableMappingRequest) {
		LOG.info("Started execution for the perishable Action Force New");

	   Map<String,String> result =new HashMap<>();
	   String message = perishableMappingServices.saveForceNewInPerishableMapping(perishableMappingRequest);
	   result.put("actionresult", message);
		LOG.info("completed execution for the perishable Action Force New");

	   return result;
   }
   
 
   
	/**
    * Method to identify the type of force new ie, Override / augmentation 
    * @param displayItemCreateMatchCicDto
    * @return
    */
   @RequestMapping(value = "/checkForceNewCategory", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, String> checkForceNewType(@RequestBody PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto) {
		LOG.info("Started execution for the check Force New Category");

		boolean isMatchTargetUPC = false;
		HashMap<String, String> response = new HashMap<String, String>();
		if(perishableItemCreateMatchCicDto!= null){
			String forceNewCategory="ForceNewCategory";
			if ('Y'== perishableItemCreateMatchCicDto.getDisplayFlag()) {
				perishableMappingServices.createNewCic(perishableItemCreateMatchCicDto,PerishableConstants.AUGMENTATION);
				response.put(forceNewCategory, PerishableConstants.AUGMENTATION);

			} else if (('N' == perishableItemCreateMatchCicDto.getDisplayFlag() || (' '== perishableItemCreateMatchCicDto.getDisplayFlag()))
					&& !CollectionUtils.isEmpty(perishableItemCreateMatchCicDto.getSourceComponentUpc())) {
				isMatchTargetUPC = perishableMappingServices.checkMatchingUPCInTarget(perishableItemCreateMatchCicDto);
				if (isMatchTargetUPC) {
					perishableMappingServices.createNewCic(perishableItemCreateMatchCicDto,PerishableConstants.OVERRIDE);
					response.put(forceNewCategory, PerishableConstants.OVERRIDE);
				}else{
					perishableMappingServices.createNewCic(perishableItemCreateMatchCicDto,PerishableConstants.AUGMENTATION);
					response.put(forceNewCategory, PerishableConstants.AUGMENTATION);
				}
			}
		}
		LOG.info("completed execution for the check Force New Category");

		return response;
	}
	
   @RequestMapping(value = "/changeExpenseType", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
   public @ResponseBody PerishableMappingRequestWrapper expesetypeChangingaction(@RequestBody PerishableMappingRequestWrapper changeTypeRequestWrapper) throws Exception {
	   
		LOG.info("started execution for the change Expense Type");

	   List<ManualExpeseTypeChangeRequest> changeRequests =new ArrayList<>();
	   List<String> validateActions=new ArrayList<>();
	   Set<String> excludeSet = new HashSet<>() ;
	   for(ManualExpeseTypeChangeRequest expenseRequest :changeTypeRequestWrapper.getExpenseChangeRequest())
	   {
		  if(!expenseRequest.getExpenseTypeCurrent().equals(expenseRequest.getExpeseTypeChange())) 
		  {
			  changeRequests.add(expenseRequest);
		  }
		  else
		  {
			  excludeSet.add(expenseRequest.getSku());
		  }
	   }
	  
	  if(!excludeSet.isEmpty()) 
	  {
		  validateActions.add("Both exisitng and changing expense type for  "+excludeSet.size()+ " SKUs are same and they are updated in DB");  
	  }
	   
	 boolean status=  perishableMappingServices.changeExpenseType(changeRequests);
	 if(status)
	 {   validateActions.add("Usage type updated successfully");
   
	 }
	 else
	 {
		 validateActions.add("Usage type update failed"); 
	 }
	   
	   /* Loads source and target data based on existing search inputs */
		if (changeTypeRequestWrapper.getSourceSearchRequest() != null) {
			changeTypeRequestWrapper.setSourceSearchRequest(perishableMappingServices.listSKUPerishableItems(changeTypeRequestWrapper.getSourceSearchRequest()));
		}
		 changeTypeRequestWrapper.setErrorMessages(validateActions);
			LOG.info("completed execution for the change Expense Type");

	   return changeTypeRequestWrapper;
   }  
   
  
}


