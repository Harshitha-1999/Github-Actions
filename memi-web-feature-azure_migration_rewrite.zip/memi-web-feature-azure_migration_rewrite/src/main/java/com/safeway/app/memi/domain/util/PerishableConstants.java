package com.safeway.app.memi.domain.util;

import java.util.HashMap;
import java.util.Map;

public class PerishableConstants {
	
	
	private PerishableConstants() {

	}

	
	public static final String ADD_MAP = "ADD_MAP";
	public static final String INHERIT_MAP = "INHERIT_MAP";
	public static final String LET_AUTO_MATCH = "LET_AUTO_MATCH";
	public static final String MARK_AS_DEAD = "MARK_AS_DEAD";
	public static final String FORCE_NEW = "FORCE_NEW";
	public static final String RESERVED = "RESERVED";

	
	/*Status*/
	public static final String MAPPED = "MAPPED";
	public static final String UN_MAPPED = "UN_MAPPED";
	public static final String TO_BE_MAPPED = "TO_BE_MAPPED";
	public static final String CONVERT = "LET_TO_CONVERT";
	public static final String AWAITING_CIC = "AWAITING_NEW_CIC";
	public static final String AWAITING_DIVISION = "AWAITING_DIVISION_INPUT";
	public static final String OTHER = "OTHERS";
	
	
	
	/*Filter query*/
	public static final String department = "department";
	public static final String itemDescription = "itemDescription";
	public static final String plu = "plu";
	public static final String slu = "slu";
	public static final String itemType = "itemType";
	public static final String upc = "upc";
	public static final String mappingStatus = "mappingStatus";
	public static final String searchType = "searchType";
	public static final String  AND  = " AND ";
	public static final String DIVISION_ID = "DIVISION_ID";
	public static final String WHSE_DSD = "WHSE_DSD";
	public static final String CDS_DISP_FLAG="CDS.DISP_FLAG";
	/* Error Messages*/
	public static final String VALIDATION_MESSAGE_ITEM = "Please select item type from radio buttons";
	public static final String VALIDATION_MESSAGE_COMPANY="Mandatory fields company or division is empty";
	public static final String VALIDATION_MESSAGE_ITEM_MAPPING_TYPE="Please avoid items which is marked as automatch and mark as dead ...!";
	public static final String VALIDATION_MESSAGE_UNMAP_ITEM_SELECTION ="Please select at least one item to unmap...!";
	
   /*Search query*/
   public static final String DEPT_NAME = "DEPT_NAME";	
   public static final String PLU_VAL="PLU_VAL";
   public static final String UPC_VAL="UPC_VAL";
   public static final String SKU_VAL="SKU_VAL";
   public static final String ITEM_DESC="ITEM_DESC";
   public static final String SEARCH_VAL="searchValue";
   public static final String CIC_VAL ="CIC_VAL";
   public static final String DISP="DISP";
   public static final String DST_CNTR="DST_CNTR";
   public static final String WHSE="WHSE";
   public static final String DSD="DSD";
   public static final String USAGE_TYPE="USAGE_TYPE";
   
   
   /*Item Type*/
   public static final String ALL="All";
   public static final String PLU="PLU";
   public static final String SYSTEM_2="System2";
   public static final String SYSTEM_4="System4";
   
   /* */
   
   public static final String SOURCE_INDICATOR = "SOURCE_INDICATOR";
   public static final String TARGET_INDICATOR = "TARGET_INDICATOR";
   
   public static final String AUGMENTATION = "A";
   public static final String OVERRIDE = "O";
   
   public static final String AUGMENTATION_DESC = "Augmentation";
   public static final String OVERRIDE_DESC = "Override";
   
   
   


	


   

}
