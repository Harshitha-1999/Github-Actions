/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

/* ***************************************************************************
 * NAME         : ReportController 
 *
 * SYSTEM       : MEMD
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 March 30, 2017  -  Initial Creation
 *
 ***************************************************************************/

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.safeway.app.memi.domain.dtos.response.SMICDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.services.SMICDetailService;

/**
 * 
 * REST service controller class for SIMC Details
 * 
 */
@Controller
@RequestMapping("/smic")
public class SMICDetailController {
    private static final Logger LOG = LoggerFactory.getLogger(SMICDetailController.class);

    
    @Autowired
    private SMICDetailService smicService;
    
    
    /**
     * Method to load SMIC Details
     */
    @RequestMapping(value = "/detail/{grpCd}/{ctgryCd}/{clsCd}/{sbClsCd}/{subSbClass}", method = RequestMethod.GET)
    public ResponseEntity<List<SMICDetailDto>> getCompaniesList(@PathVariable("grpCd") String grpCd, 
    		@PathVariable("ctgryCd") String ctgryCd,
    		@PathVariable("clsCd") String clsCd,
    		@PathVariable("sbClsCd") String sbClsCd,
    		@PathVariable("subSbClass") String subSbClass) {
    	LOG.info("Started Fetching all the SMIC records.");
    	
    	String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
		String categoryCd = ctgryCd != null && ctgryCd.length() > 0 ? ctgryCd : "0";
		String classCd = clsCd != null && clsCd.length() > 0 && !clsCd.equalsIgnoreCase("null") ? clsCd : "0";
		String subClassCd = sbClsCd != null && sbClsCd.length() > 0 && !sbClsCd.equalsIgnoreCase("null") ? sbClsCd : "0";
		String subSubClassCd = subSbClass != null && subSbClass.length() > 0 && !subSbClass.equalsIgnoreCase("null") ? subSbClass : "0";
        List<SMICDetailDto> response = smicService.findByGrpCdAndCtgryCdAndClsCdAndSbClsCdAndSubSbClass(groupCd, categoryCd, classCd, subClassCd, subSubClassCd);

        LOG.info("Completed Fetching all the SMIC records.");
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/smicdetail", method = RequestMethod.GET)
    public ResponseEntity<List<SmicCodeDescWrapper>> getGroupCodeList() {
    	LOG.info("Started fetching group code onload ");
    	List<SmicCodeDescWrapper> response = smicService.getGroupCode();
        LOG.info("Completed fetching group code onload");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
   
    @RequestMapping(value = "/smicdetail/{grpCd}", method = RequestMethod.GET)
    public ResponseEntity<List<SmicCodeDescWrapper>> getCategoryCodeList(
    		@PathVariable("grpCd") String grpCd) {
    	LOG.info("Started fetching category code based on group code");
    	 String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
		List<SmicCodeDescWrapper> response = smicService
				.getCategoryCode(groupCd);
    	 LOG.info("Completed fetching category code based on group code");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/smicdetail/{grpCd}/{ctgryCd}", method = RequestMethod.GET)
    public ResponseEntity<List<SmicCodeDescWrapper>> getClassCodeList(
    		@PathVariable("grpCd") String grpCd,
			@PathVariable("ctgryCd") String ctgryCd) {
    	LOG.info("Started fetching class code based on group & category code");
    	String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
		String categoryCd = ctgryCd != null && ctgryCd.length() > 0 ? ctgryCd
				: "0";
		List<SmicCodeDescWrapper> response = smicService.getClassCode(groupCd,
				categoryCd);
    	LOG.info("Completed fetching class code based on group & category code");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/smicdetail/{grpCd}/{ctgryCd}/{clsCd}", method = RequestMethod.GET)
    public ResponseEntity<List<SmicCodeDescWrapper>> getSubClassCodeList(
    		@PathVariable("grpCd") String grpCd,
    		@PathVariable("ctgryCd") String ctgryCd,
    		@PathVariable("clsCd") String clsCd) {
    	LOG.info("Started fetching category code based on group, category & class code");
    	String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
		String categoryCd = ctgryCd != null && ctgryCd.length() > 0 ? ctgryCd : "0";
		String classCd = clsCd != null && clsCd.length() > 0 && !clsCd.equalsIgnoreCase("null") ? clsCd : "0";
		List<SmicCodeDescWrapper> response = smicService.getSubClassCode(groupCd, categoryCd,classCd);
    	LOG.info("Completed fetching class code based on group, category & class code");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/smicdetail/{grpCd}/{ctgryCd}/{clsCd}/{sbClsCd}", method = RequestMethod.GET)
    public ResponseEntity<List<SmicCodeDescWrapper>> getsubSubClassCodeList(
    		@PathVariable("grpCd") String grpCd,
    		@PathVariable("ctgryCd") String ctgryCd,
    		@PathVariable("clsCd") String clsCd,
    		@PathVariable("sbClsCd") String sbClsCd) {
    	LOG.info("Started fetching category code based on group, category, class & subclass code");
    	String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
		String categoryCd = ctgryCd != null && ctgryCd.length() > 0 ? ctgryCd : "0";
		String classCd = clsCd != null && clsCd.length() > 0 && !clsCd.equalsIgnoreCase("null") ? clsCd : "0";
		String subClassCd = sbClsCd != null && sbClsCd.length() > 0 && !sbClsCd.equalsIgnoreCase("null") ? sbClsCd : "0";
		List<SmicCodeDescWrapper> response = smicService.getSubSubClassCode(groupCd, categoryCd, classCd, subClassCd);
    	LOG.info("Completed fetching class code based on group, category, class & subclass code");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
