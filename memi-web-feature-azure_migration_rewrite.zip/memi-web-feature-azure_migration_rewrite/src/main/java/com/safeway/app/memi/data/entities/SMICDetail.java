package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : SMICDetail 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Varada Nellayikunnath  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 9, 2017 vnell00 - Initial Creation
 * ************************************************************************/

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Entity class for Database table SQLDAT3_MEPRDCLF.
 * 
 */
@Entity
@Table(name = "SQLDAT3_MEPRDCLF", schema = "SSIMSLAND")
public class SMICDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SMICDetailPK SMICDetailPK;
	
	@Column(name = "CLSIFICATION_DESC")
	private String SMICDesc;

	public SMICDetailPK getSMICDetailPK() {
		return SMICDetailPK;
	}

	public void setSMICDetailPK(SMICDetailPK smicDetailPk) {
		this.SMICDetailPK = smicDetailPk;
	}

	public String getSMICDesc() {
		return SMICDesc;
	}

	public void setSMICDesc(String sMICDesc) {
		SMICDesc = sMICDesc;
	}

}
