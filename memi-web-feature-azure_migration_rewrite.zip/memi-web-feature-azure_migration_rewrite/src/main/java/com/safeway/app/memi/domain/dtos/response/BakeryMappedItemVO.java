package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class BakeryMappedItemVO {

	private String sourceSKU;
	private BigDecimal targetCIC;
	private String itemDesc;
	private BigDecimal pack;
	private BigDecimal size;
	private char usage;
	private char display;	
	private BigDecimal salesValue;
	private String createdOn;
	private String lastSalesDate;
	private String lastShipDate;
	private String mappedStatus;
	private BigDecimal vcf;
	private String upc;
	public String getSourceSKU() {
		return sourceSKU;
	}
	public void setSourceSKU(String sourceSKU) {
		this.sourceSKU = sourceSKU;
	}
	public BigDecimal getTargetCIC() {
		return targetCIC;
	}
	public void setTargetCIC(BigDecimal targetCIC) {
		this.targetCIC = targetCIC;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public BigDecimal getPack() {
		return pack;
	}
	public void setPack(BigDecimal pack) {
		this.pack = pack;
	}
	public BigDecimal getSize() {
		return size;
	}
	public void setSize(BigDecimal size) {
		this.size = size;
	}
	public char getUsage() {
		return usage;
	}
	public void setUsage(char usage) {
		this.usage = usage;
	}
	public char getDisplay() {
		return display;
	}
	public void setDisplay(char display) {
		this.display = display;
	}
	public BigDecimal getSalesValue() {
		return salesValue;
	}
	public void setSalesValue(BigDecimal salesValue) {
		this.salesValue = salesValue;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getLastSalesDate() {
		return lastSalesDate;
	}
	public void setLastSalesDate(String lastSalesDate) {
		this.lastSalesDate = lastSalesDate;
	}
	public String getLastShipDate() {
		return lastShipDate;
	}
	public void setLastShipDate(String lastShipDate) {
		this.lastShipDate = lastShipDate;
	}
	public String getMappedStatus() {
		return mappedStatus;
	}
	public void setMappedStatus(String mappedStatus) {
		this.mappedStatus = mappedStatus;
	}
	public BigDecimal getVcf() {
		return vcf;
	}
	public void setVcf(BigDecimal vcf) {
		this.vcf = vcf;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	
	
}
