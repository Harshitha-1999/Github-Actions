package com.safeway.app.memi.data.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

//import oracle.sql.CLOB;


@Entity
@Table(name="LOOK_UP_SEARCH_TEMPLATE",schema="ECFLAND")
public class LookUpSearchObjectTemplate {
	
	@Id
	@Column(name="USER_ID")
	private String userId;
	
	@Lob
	@Column(name="COL_CUSTOMIZATION")
	private byte[] custColumn;
	@Lob
	@Column(name="SEARCH_CUSTOMIZATION")
	private byte[] custSearch;
	
	@Column(name="CREATE_UPDATE_TS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateTs;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	public Date getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	

	public byte[] getCustColumn() {
		return custColumn;
	}

	public void setCustColumn(byte[] custColumn) {
		this.custColumn = custColumn;
	}

	public byte[] getCustSearch() {
		return custSearch;
	}

	public void setCustSearch(byte[] custSearch) {
		this.custSearch = custSearch;
	}
	
	

}
