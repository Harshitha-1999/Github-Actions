/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

/* ***************************************************************************
 * NAME : ExceptionSrcServiceImpl SYSTEM : MEMI AUTHOR : Subhash G REVISION
 * HISTORY Revision 0.0.0.1 May 03, 2017 - sgang06 - Initial Creation
 * *************************************************************************
 */

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.ManualMapping;
import com.safeway.app.memi.data.entities.ManualMappingPK;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.SalesShip;
import com.safeway.app.memi.data.entities.SizeUOMDetail;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ManualMappingRepository;
import com.safeway.app.memi.data.repositories.MasterDataRepository;
import com.safeway.app.memi.data.repositories.NewItemDetailRepository;
import com.safeway.app.memi.data.repositories.SalesShipRepository;
import com.safeway.app.memi.data.repositories.SizeUOMDetailRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.DepartmentDto;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.SalesData;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.services.ExceptionSrcService;
import com.safeway.app.memi.domain.util.LikeItemUtils;

/**
 * 
 * Implementation class for Exception Src Service
 *
 */
@Service("exceptionSrcService")
public class ExceptionSrcServiceImpl implements ExceptionSrcService {

	private static final Logger LOG = LoggerFactory
			.getLogger(ExceptionSrcServiceImpl.class);

	@Autowired
	private UIExceptionSrcRepository exceptionRepo;

	@Autowired
	private SalesShipRepository salesShipRepo;

	@Autowired
	private NewItemDetailRepository newItemDetailRepo;

	@Autowired
	private CommonSQLRepository commonSQLRepo;

	@Autowired
	private SizeUOMDetailRepository sizeUOMDetailnRepo;

	@Autowired
	private ItemAggregateCorpRepository itemAggregateRepo;

	@Autowired
	private MasterDataRepository itemXrefRepo;

	@Autowired
	private ManualMappingRepository manualMappingRepository;

	private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#getAllItems()
	 */
	@Override
	public List<UIExceptionSrcDto> getAllItems() {
		LOG.info("Fetching all Source Lists");
		List<UIExceptionSrc> srcList = exceptionRepo.findAll();
		LOG.info("Completed fetching all"+srcList.size()+"src List");
		return viewAdapter.mapToExceptionSrcDtoList(srcList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#findByDivision
	 * (java.lang.String)
	 */
	@Override
	public List<UIExceptionSrcDto> findByDivision(String divisionId) {
		LOG.info("Fetching all Source Lists by division id");
		List<UIExceptionSrc> srcList = exceptionRepo
				.findByUiSrcPkDivisionId(divisionId);
		LOG.info("Completed fetching all"+srcList.size()+"srcList by division id");
		return viewAdapter.mapToExceptionSrcDtoList(srcList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#findByUpc(java
	 * .lang.String)
	 */
	@Override
	public UIExceptionSrcDto findByUpc(String upc) {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#getOverRideData
	 * (java.lang.String, java.lang.String)
	 */
	@Override
	public List<UIDataVO> getDepartmentWiseData(String company,
			String division, char exceptionType) {
		LOG.info("Fetching all buildDepartmentDetails");
		List<UIDataVO> checkTest = buildDepartmentDetails(company, division,
				exceptionType);
		LOG.info("Completed fetching all"+checkTest.size()+"buildDepartmentDetails");
		return checkTest;

	}

	/**
	 * @param srclist
	 * @return
	 */
	private List<UIDataVO> buildDepartmentDetails(String companyId,
			String divisionId, char exceptionType) {
		LOG.debug("Fetching all DepartmentDetails");
		List<UIDataVO> voList = new ArrayList<>();
		
		List<Object[]> departmentRecords = commonSQLRepo
				.fetchDepartmentWiseExceptions(companyId, divisionId,
						exceptionType, 'N');
		LOG.debug("Fetching all "+departmentRecords.size()+"departmentRecords");
		for (Object[] deptRecord : departmentRecords) {
			UIDataVO vo = new UIDataVO();
			vo.setTotalRecord((Integer)deptRecord[0]);
			vo.setDeptName(getStringValue(deptRecord[1]));
			vo.setDeptCode(getStringValue(deptRecord[2]));
			vo.setTotalDSDRecords((Integer)deptRecord[3]);
			vo.setTotalWHSERecords((Integer)deptRecord[4]);
			voList.add(vo);
		}
		
		List<Object[]> completedRecords = commonSQLRepo
				.fetchDepartmentWiseExceptions(companyId, divisionId,
						exceptionType, 'C');
		LOG.debug("Fetching all "+completedRecords.size()+"completedRecords");
		for (Object[] completedRecord : completedRecords) {
			UIDataVO vo = new UIDataVO();
			UIDataVO existingVo;
			vo.setDeptCode(getStringValue(completedRecord[2]));
			if (voList.contains(vo)) {
				existingVo = voList.get(voList.indexOf(vo));
				existingVo.setCompletedItmCnt((Integer)
						completedRecord[0]);
				existingVo.setCompletedDSDItmCnt((Integer)
						completedRecord[3]);
				existingVo.setCompletedWHSEItmCnt((Integer)
						completedRecord[4]);
			} else {
				vo.setCompletedItmCnt((Integer)completedRecord[0]);
				vo.setCompletedDSDItmCnt((Integer)completedRecord[3]);
				vo.setCompletedWHSEItmCnt((Integer)completedRecord[4]);
				vo.setDeptName(getStringValue(completedRecord[1]));
				voList.add(vo);
			}
		}
		if (exceptionType == 'A') {
			departmentRecords = commonSQLRepo.fetchDepartmentWiseExceptions(
					companyId, divisionId, exceptionType, 'R');
			for (Object[] deptRecord : departmentRecords) {
				UIDataVO vo = new UIDataVO();
				UIDataVO existingVo;
				String departmentCode = (String) (deptRecord[2] != null ? (deptRecord[2])
						: null);
				vo.setDeptCode(departmentCode);
				if (voList.contains(vo)) {
					existingVo = voList.get(voList.indexOf(vo));
					existingVo
							.setReviewItmCnt((int)deptRecord[0]);
					existingVo.setReviewDSDItmCnt((int)
							deptRecord[3]);
					existingVo.setReviewWHSEItmCnt((int)
							deptRecord[4]);
				} else {
					vo.setReviewItmCnt((int)deptRecord[0]);
					vo.setReviewDSDItmCnt((int)deptRecord[3]);
					vo.setReviewWHSEItmCnt((int)deptRecord[4]);
					vo.setDeptName(getStringValue(deptRecord[1]));
					voList.add(vo);
				}

			}
		}
		LOG.debug("Completed Fetching all DepartmentDetails");
		return voList;
	}

	/**
	 * @param srclist
	 * @return
	 */
	@SuppressWarnings("unused")
	private List<UIDataVO> setValidDeptwisedata(List<UIExceptionSrc> srclist) {
		LOG.debug("Started execution for setValidDeptwisedata ");
		List<UIDataVO> overRideRecList = new ArrayList<>();
		UIDataVO overrideRec = null;

		Set<String> deptSet = new TreeSet<>();
		for (UIExceptionSrc obj : srclist) {
			if (null != obj.getDeptDtl().getDeptName()) {
				LOG.info("Object is " + obj);
				String deptName = obj.getDeptDtl().getDeptName();
				deptSet.add(deptName);
			}

		}

		for (String st : deptSet) {
			overrideRec = new UIDataVO();
			int noOfrec = 0;
			Set<String> productSKUSet = new HashSet<>();
			for (UIExceptionSrc obj : srclist) {
				if (obj.getDeptDtl().getDeptName().equals(st)) {
					noOfrec++;
					overrideRec.setDeptName(st);
					productSKUSet.add(obj.getUiSrcPk().getProductSKU());
				}
			}
			overrideRec.setPrdskuSet(productSKUSet);
			overrideRec.setTotalRecord(noOfrec);
			overRideRecList.add(overrideRec);
			
		}
		LOG.debug("cOmPLeTeD execution for setValidDeptwisedata ");
		return overRideRecList;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#getAugData(java
	 * .lang.String, java.lang.String)
	 */
	@Override
	public List<UIExceptionSrcDto> getAugData(String company, String division) {
		LOG.info("Fetching all divisions");
		List<UIExceptionSrc> srcAugList = exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
						division, company, 'A', 'N');
		LOG.info("completed Fetching all divisions");
		return viewAdapter.mapToExceptionSrcDtoList(srcAugList);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#findByProductSKU
	 * (java.lang.String)
	 */
	@Override
	public UIExceptionSrcDto findByProductSKU(String productSKU) {
		UIExceptionSrc src = exceptionRepo.findByUiSrcPkProductSKU(productSKU);
		return viewAdapter.mapToUIExceptionSrcDto(src);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#loadItemData
	 * (java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public AugDataVo loadItemData(String company, String division,
			String productsku) {
		LOG.info("Started execution for loadItemDatas");
		List<UIExceptionSrc> exceptionList = exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndExcptnTypeCdAndAndExcptnProcessdIndNotOrderByPrmyUpcIndDesc(
						division, company, productsku, 'A', 'D');
		LOG.debug("Completed fetching all"+exceptionList.size()+"exceptionList");
		if (!exceptionList.isEmpty()) {
			UIExceptionSrcDto uiExceptionSrcDto = null;
			SalesData salesData = null;
			List<String> upcList = getUpcList(exceptionList);
			List<UPCVo> upcVOList = getUpcVoList(exceptionList);

			uiExceptionSrcDto = viewAdapter
					.mapToUIExceptionSrcDto(exceptionList.get(0));
			uiExceptionSrcDto.setUpcLIst(upcList);
			uiExceptionSrcDto.setUpcVoList(upcVOList);

			String upcCountry = exceptionList.get(0).getUiSrcPk()
					.getUpcCountry();
			String upcSystem = exceptionList.get(0).getUiSrcPk().getUpcSystem();
			String upcManuf = exceptionList.get(0).getUiSrcPk()
					.getUpcManufacturer();
			String upcSales = exceptionList.get(0).getUiSrcPk().getUpcSales();
			
			List<SalesShip> shipData = salesShipRepo
					.findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKUAndSalesShipPkUpcCountryAndSalesShipPkUpcSystemAndSalesShipPkUpcManufacturerAndSalesShipPkUpcSales(
							division, company, productsku, upcCountry,
							upcSystem, upcManuf, upcSales);
			LOG.debug("Completed fetching all"+shipData.size()+"shipData");

			if (!shipData.isEmpty()) {
				salesData = viewAdapter.mapToSalesData(shipData.get(0));
			}
			List<Object[]> produceInfo=commonSQLRepo.getProduceRelatedData(company,division,productsku);
			LOG.debug("Completed fetching all"+produceInfo.size()+"produceInfo");
			if(!produceInfo.isEmpty())
			{
				for(Object[] obj :produceInfo)
				{
					if(obj[0]!=null && obj[0].toString().equalsIgnoreCase("W") )
						uiExceptionSrcDto.setSelling_method_cd("POUND");	
					else if(obj[0]!=null && obj[0].toString().equalsIgnoreCase("E") )
						uiExceptionSrcDto.setSelling_method_cd("EACH");
					
					if(obj[1]!=null && obj[1].toString().equalsIgnoreCase("N") )
						uiExceptionSrcDto.setReceiving_cd("CASE");	
					else if(obj[1]!=null && obj[1].toString().equalsIgnoreCase("Y") )
						uiExceptionSrcDto.setReceiving_cd("POUND");	
				}
			}

			setSlotIDAndOnhandStatus(uiExceptionSrcDto);
			setProductHierarchyDetails(uiExceptionSrcDto);
			NewItemDetailDto newItem = augItemCheckinDb(uiExceptionSrcDto);
			newItem.setAssocUpc(upcList);
			newItem.setUpcVoList(upcVOList);
			AugDataVo augVo = new AugDataVo();
			augVo.setUiEceptionSrcDto(uiExceptionSrcDto);
			augVo.setSalesData(salesData);
			augVo.setNewItemDto(newItem);
			LOG.info("COMpLEtEd execution for loadItemDatas");
			return augVo;
		} else {
			return new AugDataVo();
		}
		
	}

	/**
	 * @param exceptionList
	 * @return
	 */
	private List<String> getUpcList(List<UIExceptionSrc> exceptionList) {
		LOG.debug("Started execution for getUpcList");
		List<String> upcLIst = new ArrayList<>();
		for (UIExceptionSrc excptionObj : exceptionList) {
			String upc = excptionObj.getUiSrcPk().getUpcCountry() + "-"
					+ excptionObj.getUiSrcPk().getUpcSystem() + "-"
					+ excptionObj.getUiSrcPk().getUpcManufacturer() + "-"
					+ excptionObj.getUiSrcPk().getUpcSales();
			upcLIst.add(upc);
		}
		LOG.debug("COMpLEtEd  execution for "+upcLIst.size()+" getUpcList");
		return upcLIst;
	}

	/**
	 * @param uiExceptionSrcDto
	 * @return
	 */
	private NewItemDetailDto overrideItemCheckinDb(
			UIExceptionSrcDto uiExceptionSrcDto) {
		LOG.debug("Started execution for NewItemDetailDto");
		String division = uiExceptionSrcDto.getDivisionId();
		String company = uiExceptionSrcDto.getCompanyId();
		String productsku = uiExceptionSrcDto.getProductSKU();

		List<NewItemDetail> newItems = newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndExcptnTypeCdOrderByPrmyUpcIndDesc(
						productsku, division, company, 'O');
		LOG.debug("Completed fetching all"+newItems.size()+"newItems");
		if (newItems != null && !(newItems.isEmpty())) {
			NewItemDetailDto newItemDto = viewAdapter.mapNewItemCICDto(newItems
					.get(0));
			newItemDto.setUpcVoList(getUpcVoListFromCICRecords(newItems));
			return newItemDto;
		} else {
			if (uiExceptionSrcDto.getExcptnProInd() == 'C') {
				List<ItemXrefData> xrefRecord = itemXrefRepo
						.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId(
								productsku, company, division);
				LOG.debug("Completed fetching all"+xrefRecord.size()+"xrefRecord");
				if (xrefRecord != null && !(xrefRecord.isEmpty())) {
					uiExceptionSrcDto.setMarkedAsDead(xrefRecord.get(0)
							.getConvStatusCode().equals("D")
							&& xrefRecord.get(0).getConvStatusSubCode() != null
							&& xrefRecord.get(0).getConvStatusSubCode()
									.equals("B"));
					uiExceptionSrcDto.setManualMapped(xrefRecord.get(0)
							.getConvStatusCode().equals("O")
							&& xrefRecord.get(0).getConvStatusSubCode() != null
							&& xrefRecord.get(0).getConvStatusSubCode()
									.equals("U"));
				}
				if (!uiExceptionSrcDto.isManualMapped()
						&& !uiExceptionSrcDto.isMarkedAsDead()) {

					List<Object[]> markedForManualMapping = commonSQLRepo.isMarkedForManualMapping(company, division,
									productsku);
					LOG.debug("Completed fetching all"+markedForManualMapping.size()+"markedForManualMapping");
					if (!markedForManualMapping.isEmpty()) {
						uiExceptionSrcDto.setMarkedForManualMapping(true);
					} else {
						uiExceptionSrcDto.setMarkedForManualMapping(false);
					}
				}

			}
		}
		LOG.debug("Completed execution for NewItemDetailDto");
		return null;
	}

	/**
	 * @param uiExceptionSrcDto
	 * @return
	 */
	private NewItemDetailDto augItemCheckinDb(
			UIExceptionSrcDto uiExceptionSrcDto) {
		LOG.debug("sTARTeD execution for augItemCheckinDb");
		String division = uiExceptionSrcDto.getDivisionId();
		String company = uiExceptionSrcDto.getCompanyId();
		String productsku = uiExceptionSrcDto.getProductSKU();
		String proSrcCd = uiExceptionSrcDto.getProductSrcCd();
		String upcContry = uiExceptionSrcDto.getUpcCountry();
		String upcManuf = uiExceptionSrcDto.getUpcManufacturer();
		String upcSales = uiExceptionSrcDto.getUpcSales();
		String upcSys = uiExceptionSrcDto.getUpcSystem();
		NewItemDetailDto newItemDto = null;
		NewItemDetail newItemDtl = newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkProductSrcCdAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkUpcCountryAndNewItemPkUpcSystemAndNewItemPkUpcManufacturerAndNewItemPkUpcSales(
						productsku, proSrcCd, division, company, upcContry,
						upcSys, upcManuf, upcSales);
		if (newItemDtl == null) {
			newItemDto = viewAdapter.setNewItemforView(uiExceptionSrcDto);
			List<Object[]> cicDetails = commonSQLRepo.getCICDetails(upcManuf,
					upcSales, upcContry, upcSys);
			LOG.debug("Completed fetching all"+cicDetails.size()+"cicDetails");
			if (uiExceptionSrcDto.getExcptnProInd() == 'C') {
				List<ItemXrefData> xrefRecord = itemXrefRepo
						.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId(
								productsku, company, division);
				LOG.debug("Completed fetching all"+ xrefRecord.size()+" xrefRecord");
				if (xrefRecord != null && !xrefRecord.isEmpty()) {
					uiExceptionSrcDto.setMarkedAsDead(xrefRecord.get(0)
							.getConvStatusCode().equals("D")
							&& xrefRecord.get(0).getConvStatusSubCode()
									.equals("B"));
					uiExceptionSrcDto.setManualMapped(xrefRecord.get(0)
							.getConvStatusCode().equals("O")
							&& xrefRecord.get(0).getConvStatusSubCode()
									.equals("U"));
				}
				if (!uiExceptionSrcDto.isManualMapped() && !uiExceptionSrcDto.isMarkedAsDead()){
					List<Object[]> markedForManualMapping=commonSQLRepo.isMarkedForManualMapping(company, division,
									productsku);
					LOG.debug("Completed fetching all"+markedForManualMapping.size()+"markedForManualMapping");
					if(!markedForManualMapping.isEmpty()){
						uiExceptionSrcDto.setMarkedForManualMapping(true);
					}else{
						uiExceptionSrcDto.setMarkedForManualMapping(false);
					}
				}
					
					
			}
			// Borrowing SMIC codes, UsageInd and UsageTypeInd from existing CIC
			// if present in SSIMS
			if (cicDetails != null) {
				int i=0;
				for (Object[] record : cicDetails) {
					char usageInd = getCharacterValue(record[1]);
					char usageTypeInd = getCharacterValue(record[2]);
					newItemDto.setUpdUsgeInd(usageInd);
					newItemDto.setUpdUsageTypInd(usageTypeInd);
					newItemDto.setBorrowedUsageDetails(true);
					char displayFlag = getCharacterValue(record[3]);
					// Borrow SMIC only if CIC is non display item
					if (displayFlag != 'Y') {
						newItemDto.setGrpCd(getBigDecimalValue(record[4])
								.intValue());
						newItemDto.setCtgryCd(getBigDecimalValue(record[5])
								.intValue());
						newItemDto.setClsCd(getBigDecimalValue(record[6])
								.intValue());
						newItemDto.setSbClsCd(getBigDecimalValue(record[7])
								.intValue());
						newItemDto.setSubSbClass(getBigDecimalValue(record[8])
								.intValue());
						newItemDto.setProductionGrpCd(getBigDecimalValue(record[9])
								.intValue());
						newItemDto.setProductionCtgryCd(getBigDecimalValue(
								record[10]).intValue());
						newItemDto.setProductionClsCd(getBigDecimalValue(
								record[11]).intValue());
						newItemDto.setBorrowedSMIC(true);
					}
					i++;
					if (i == 1) {
						break;
					}
				}
			}
		} else {
			newItemDto = viewAdapter.mapNewItemCICDto(newItemDtl);
			/**Target PLU override changes**/
			List<Object[]> correctedUPCList =commonSQLRepo.getSourceAndEditedUpcDataMgmt(company,division,productsku,proSrcCd);
			LOG.debug("Completed fetching all"+correctedUPCList.size()+"correctedUPCList");
			for(Object[] neDtl :correctedUPCList)
			{
				String upc =neDtl[0].toString();
				if(Float.parseFloat(upc)<100000)
				{
					newItemDto.addUpdPlu(neDtl[0].toString(), neDtl[2] != null ? neDtl[2].toString() : null);
				}
				else
				{
					newItemDto.addUpdUpc(neDtl[0].toString(), neDtl[1] != null ? neDtl[1].toString() : null);
				}
				
			}
			/***/		
			
		}
		
		/*Addtional details for Produce,deli and bakery*/
		List<Object[]>	addtionDetailsObj =commonSQLRepo.getAddtnlFieldsDataForUI( division,company,productsku);
		newItemDto=viewAdapter.mapAddnlDetailsOnDto(newItemDto,uiExceptionSrcDto,addtionDetailsObj);
		LOG.debug("Completed execution for "+addtionDetailsObj.size()+" addtionDetailsObj");
		LOG.debug("sTARTeD execution for augItemCheckinDb");
		return newItemDto;
	}

	private List<NewItemDetail> loadNewItemCICRecord(
			UIExceptionSrcDto uiExceptionSrcDto, char exceptionType) {
		LOG.debug("Started execution for get newItems");
		List<NewItemDetail> newItems = newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndExcptnTypeCdOrderByPrmyUpcIndDesc(
						uiExceptionSrcDto.getProductSKU(),
						uiExceptionSrcDto.getDivisionId(),
						uiExceptionSrcDto.getCompanyId(), exceptionType);
		LOG.debug("Completed execution for get newItems");
		return newItems;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#loadItemDatabyUpc
	 * (java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public AugDataVo loadItemDataByUPC(String company, String division,
			String sourceUpc) {
		LOG.info("Started execution for loadItemDataByUPC");
		List<UIExceptionSrc> exceptionList = exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdIndNot(
						division, company, sourceUpc.substring(0, 1),
						sourceUpc.substring(1, 2), sourceUpc.substring(2, 7),
						sourceUpc.substring(7, 12), 'A', 'D');
		LOG.debug("Completed fetching all"+exceptionList.size()+"exceptionList");
		if (!exceptionList.isEmpty()) {
			UIExceptionSrcDto uiExceptionSrcDto = null;
			SalesData salesData = null;
			List<String> upcList = getUpcList(exceptionList);
			List<UPCVo> upcVOList = getUpcVoList(exceptionList);

			uiExceptionSrcDto = viewAdapter
					.mapToUIExceptionSrcDto(exceptionList.get(0));
			uiExceptionSrcDto.setUpcLIst(upcList);
			uiExceptionSrcDto.setUpcVoList(upcVOList);

			String upcCountry = exceptionList.get(0).getUiSrcPk()
					.getUpcCountry();
			String upcSystem = exceptionList.get(0).getUiSrcPk().getUpcSystem();
			String upcManuf = exceptionList.get(0).getUiSrcPk()
					.getUpcManufacturer();
			String upcSales = exceptionList.get(0).getUiSrcPk().getUpcSales();
			String productsku = exceptionList.get(0).getUiSrcPk()
					.getProductSKU();

			List<SalesShip> shipData = salesShipRepo
					.findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKUAndSalesShipPkUpcCountryAndSalesShipPkUpcSystemAndSalesShipPkUpcManufacturerAndSalesShipPkUpcSales(
							division, company, productsku, upcCountry,
							upcSystem, upcManuf, upcSales);
			LOG.debug("Completed fetching all"+shipData.size()+"shipData");

			if (!shipData.isEmpty()) {
				salesData = viewAdapter.mapToSalesData(shipData.get(0));
			}
			List<Object[]> produceInfo=commonSQLRepo.getProduceRelatedData(company,division,productsku);
			LOG.debug("Completed fetching all"+produceInfo.size()+"produceInfo");
			if(!produceInfo.isEmpty())
			{
				for(Object[] obj :produceInfo)
				{
					if(obj[0]!=null && obj[0].toString().equalsIgnoreCase("W") )
						uiExceptionSrcDto.setSelling_method_cd("POUND");	
					else if(obj[0]!=null && obj[0].toString().equalsIgnoreCase("E") )
						uiExceptionSrcDto.setSelling_method_cd("EACH");
					
					if(obj[1]!=null && obj[1].toString().equalsIgnoreCase("N") )
						uiExceptionSrcDto.setReceiving_cd("CASE");	
					else if(obj[1]!=null && obj[1].toString().equalsIgnoreCase("Y") )
						uiExceptionSrcDto.setReceiving_cd("POUND");	
				}
			}
			setSlotIDAndOnhandStatus(uiExceptionSrcDto);
			setProductHierarchyDetails(uiExceptionSrcDto);
			NewItemDetailDto newItem = augItemCheckinDb(uiExceptionSrcDto);
			newItem.setAssocUpc(upcList);
			newItem.setUpcVoList(upcVOList);
			AugDataVo augVo = new AugDataVo();
			augVo.setUiEceptionSrcDto(uiExceptionSrcDto);
			augVo.setSalesData(salesData);
			augVo.setNewItemDto(newItem);
			LOG.info("Completed execution for loadItemDataByUPC");
			return augVo;
			
		}

		else {
			return new AugDataVo();
		}
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#markItemComplete
	 * (com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto)
	 */

	@Override
	public boolean markItemComplete(UIExceptionSrcDto sourceObj,
			char exceptionType) {
		LOG.info("Started execution for markItemComplete");
		String division = sourceObj.getDivisionId();
		String company = sourceObj.getCompanyId();
		String productsku = sourceObj.getProductSKU();
		
		List<UIExceptionSrc> sourceObjs = exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCd(
						productsku, division, company, exceptionType);
		LOG.debug("Completed fetching all"+sourceObjs.size()+"sourceObjs");
		boolean completed = true;
		if (sourceObjs != null && !sourceObjs.isEmpty()) {
			for (UIExceptionSrc excSrc : sourceObjs) {
				excSrc.setExcptnProcessdInd('C');
				excSrc.setUpdatedUserID(sourceObj.getUpdatedUserID());
				UIExceptionSrc exc = exceptionRepo.save(excSrc);
			}
		}
		LOG.info("Started execution for markItemComplete");
		return completed;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#loadOverrideItemData
	 * (java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public OverrideDataVo loadOverrideItemData(String company, String division,
			String productsku) {
		LOG.info("Started execution for loadOverrideItemData");
		List<UIExceptionSrc> exceptionList = exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndExcptnTypeCdAndAndExcptnProcessdIndNotOrderByPrmyUpcIndDesc(
						division, company, productsku, 'O', 'D');
		
		if (!exceptionList.isEmpty()) {
			UIExceptionSrcDto uiExceptionSrcDto = null;
			List<String> upcList = getUpcList(exceptionList);
			List<UPCVo> upcVOList = getUpcVoList(exceptionList);
			uiExceptionSrcDto = viewAdapter
					.mapToUIExceptionSrcDto(exceptionList.get(0));
			uiExceptionSrcDto.setUpcLIst(upcList);
			uiExceptionSrcDto.setUpcVoList(upcVOList);

			OverrideDataVo overrideDataVo = new OverrideDataVo();
			overrideDataVo.setUiEceptionSrcDto(uiExceptionSrcDto);

			NewItemDetailDto copiedSrcItem = viewAdapter
					.setNewItemforView(uiExceptionSrcDto);
			copiedSrcItem.setAssocUpc(upcList);
			copiedSrcItem.setUpcVoList(upcVOList);
			copiedSrcItem.setLikeItem(false);
			List<NewItemDetailDto> likeItemDtoList = new ArrayList<>();
			likeItemDtoList.add(copiedSrcItem);
			List<Object[]> likeItemObjList = commonSQLRepo
					.fetchLikeItemsForMultiUPCs(
							uiExceptionSrcDto.getProductSKU(),
							uiExceptionSrcDto.getCompanyId(),
							uiExceptionSrcDto.getDivisionId());
			List<NewItemDetailDto> likeItemDtoListFromDB = viewAdapter
					.buildLikeItemDetailDtoList(likeItemObjList,
							uiExceptionSrcDto);
			List<Object[]> rogRankings = commonSQLRepo.loadROGRanking(
					uiExceptionSrcDto.getCompanyId(),
					uiExceptionSrcDto.getDivisionId());
			likeItemDtoListFromDB = new LikeItemUtils().orderLikeItems(
					likeItemDtoListFromDB, uiExceptionSrcDto, rogRankings);
			likeItemDtoList.addAll(likeItemDtoListFromDB);
			overrideDataVo.setLikeItems(likeItemDtoList);
			
			if (uiExceptionSrcDto.getExcptnProInd() == 'C') {
				NewItemDetailDto newCICRecord = overrideItemCheckinDb(uiExceptionSrcDto);
				if (newCICRecord != null)
					overrideDataVo.setNewItemDto(newCICRecord);
				else {
					overrideDataVo.setNewItemDto(copiedSrcItem);
				}
			} else {
				if (likeItemDtoList.size() > 1)
					overrideDataVo.setNewItemDto(likeItemDtoList.get(1));
				else
					overrideDataVo.setNewItemDto(copiedSrcItem);
			}
			LOG.info("completed execution for loadOverrideItemData");
			return overrideDataVo;
		} else {
			return new OverrideDataVo();
		}
	}

	@Override
	public OverrideDataVo loadOverrideItemDataByUPC(String company,
			String division, String upc) {
		LOG.info("Started execution for loadOverrideItemDataByUPC");
		List<UIExceptionSrc> exceptionList = exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdIndNot(
						division, company, upc.substring(0, 1),
						upc.substring(1, 2), upc.substring(2, 7),
						upc.substring(7, 12), 'O', 'D');
		LOG.debug("Completed fetching all"+exceptionList.size()+"exceptionList");
		if (!exceptionList.isEmpty()) {
			UIExceptionSrcDto uiExceptionSrcDto = new UIExceptionSrcDto();
			List<String> upcList = getUpcList(exceptionList);
			List<UPCVo> upcVOList = getUpcVoList(exceptionList);
			for (UIExceptionSrc excptionObj : exceptionList) {
				uiExceptionSrcDto = viewAdapter
						.mapToUIExceptionSrcDto(excptionObj);
				uiExceptionSrcDto.setUpcLIst(upcList);
				uiExceptionSrcDto.setUpcVoList(upcVOList);
			}
			OverrideDataVo overrideDataVo = new OverrideDataVo();
			overrideDataVo.setUiEceptionSrcDto(uiExceptionSrcDto);

			NewItemDetailDto copiedSrcItem = viewAdapter
					.setNewItemforView(uiExceptionSrcDto);

			copiedSrcItem.setAssocUpc(upcList);
			copiedSrcItem.setUpcVoList(upcVOList);
			copiedSrcItem.setLikeItem(false);
			List<NewItemDetailDto> likeItemDtoList = new ArrayList<>();
			likeItemDtoList.add(copiedSrcItem);
			List<Object[]> likeItemObjList = commonSQLRepo.fetchLikeItems(
					uiExceptionSrcDto.getUpcManufacturer(),
					uiExceptionSrcDto.getUpcSales(),
					uiExceptionSrcDto.getUpcCountry(),
					uiExceptionSrcDto.getUpcSystem());
			LOG.debug("Completed fetching all"+likeItemObjList.size()+"likeItemObjList");

			List<NewItemDetailDto> likeItemDtoListFromDB = viewAdapter
					.buildLikeItemDetailDtoList(likeItemObjList,
							uiExceptionSrcDto);
			LOG.debug("Completed fetching all"+likeItemDtoListFromDB.size()+"likeItemDtoListFromDB");
			List<Object[]> rogRankings = commonSQLRepo.loadROGRanking(
					uiExceptionSrcDto.getCompanyId(),
					uiExceptionSrcDto.getDivisionId());
			LOG.debug("Completed fetching all"+rogRankings.size()+"rogRankings");
			likeItemDtoListFromDB = new LikeItemUtils().orderLikeItems(
					likeItemDtoListFromDB, uiExceptionSrcDto, rogRankings);
			likeItemDtoList.addAll(likeItemDtoListFromDB);
			overrideDataVo.setLikeItems(likeItemDtoList);
			LOG.info("COmPLeted execution for loadOverrideItemDataByUPC");
			if (likeItemDtoList.size() > 2)
				overrideDataVo.setNewItemDto(likeItemDtoList.get(1));
			else
				overrideDataVo.setNewItemDto(copiedSrcItem);
			return overrideDataVo;
		} else {
			return new OverrideDataVo();
		}
	}

	@Override
	public List<UIExceptionSrcDto> loadDeptExportData(String company,
			String division, String dept) {
		LOG.info("Started execution for exceptionList");
		List<UIExceptionSrc> exceptionList = exceptionRepo
				.findByUiSrcPkCompanyIdAndUiSrcPkDivisionIdAndExcptnTypeCdAndExcptnProcessdIndAndDeptDtlDeptName(
						company, division, 'O', 'N', dept);
		LOG.info("completed execution for exceptionList");
		return viewAdapter.mapToExceptionSrcDtoList(exceptionList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#loadProductSKUList
	 * (java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */

	@Override
	
	public List<String> loadProductSKUList(String companyId, String divisionId,
			String departmentCode, char exceptionType, char status, char type) {
		return commonSQLRepo.fetchDepartmentWiseExcpnSKUs(companyId,
				divisionId, exceptionType, status, departmentCode, type);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.safeway.app.memi.domain.services.ExceptionSrcService#getOnhandStatus
	 * (java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public boolean getOnhandStatus(String companyId, String divisionId,
			String produckSKU) {
		LOG.info("Started execution for  getOnhandStatus");
		List<Object[]> records = commonSQLRepo.loadOnhandStatus(companyId,
				divisionId, produckSKU);
		LOG.debug("Completed execution for"+records.size()+"  getOnhandStatus");
		if (records == null || records.isEmpty())
			return false;
		for (Object[] record : records) {
			String slotId = (String) (record[0] != null ? (record[0]) : null);
			BigDecimal onhandNbr = (BigDecimal) (record[1] != null ? (record[1])
					: null);
			LOG.info("completd execution for  getOnhandStatus");
			if (slotId != null && slotId.length() > 0 && onhandNbr != null
					&& onhandNbr.intValue() > 0)
				return true;
		}
		return false;
	}

	@Override
	public boolean removeCICRecord(UIExceptionSrcDto sourceObj,
			char exceptionType) {
		LOG.info("Started execution for  newItemRecs");
		List<NewItemDetail> newItemRecs = loadNewItemCICRecord(sourceObj,
				exceptionType);
		LOG.debug("Completed execution for"+newItemRecs.size()+"  newItemRecs");
		if (newItemRecs == null || newItemRecs.isEmpty()) {
			return true;
		}
		for (NewItemDetail record : newItemRecs)
			newItemDetailRepo.delete(record);
		LOG.info("Completed execution for  newItemRecs");
		return true;
	}

	/**
	 * @param exceptionList
	 * @return
	 */
	private List<UPCVo> getUpcVoList(List<UIExceptionSrc> exceptionList) {
		LOG.debug("EXEcution started for getUpcVoList");
		List<UPCVo> upcLIst = new ArrayList<>();
		UPCVo upcVo = null;
		for (UIExceptionSrc excptionObj : exceptionList) {
			String upc = excptionObj.getUiSrcPk().getUpcCountry() + "-"
					+ excptionObj.getUiSrcPk().getUpcSystem() + "-"
					+ excptionObj.getUiSrcPk().getUpcManufacturer() + "-"
					+ excptionObj.getUiSrcPk().getUpcSales();
			upcVo = new UPCVo();
			upcVo.setUpc(upc);
			upcVo.setPrimaryUPCInd(excptionObj.getPrmyUpcInd());
			upcLIst.add(upcVo);
		}
		LOG.debug("EXEcution completed for getUpcVoList");
		return upcLIst;
	}

	private List<UPCVo> getUpcVoListFromCICRecords(
			List<NewItemDetail> newCicList) {
		LOG.debug("EXEcution started for getUpcVoListFromCICRecords");
		
		List<UPCVo> upcLIst = new ArrayList<>();
		UPCVo upcVo = null;
		for (NewItemDetail cicObj : newCicList) {
			String upc = cicObj.getNewItemPk().getUpcCountry() + "-"
					+ cicObj.getNewItemPk().getUpcSystem() + "-"
					+ cicObj.getNewItemPk().getUpcManufacturer() + "-"
					+ cicObj.getNewItemPk().getUpcSales();
			upcVo = new UPCVo();
			upcVo.setUpc(upc);
			upcVo.setPrimaryUPCInd(cicObj.getPrmyUpcInd());
			upcLIst.add(upcVo);
		}
		LOG.debug("EXEcution completed for getUpcVoListFromCICRecords");
		return upcLIst;

	}

	@Override
	public List<SizeUOMDetail> getUOMCodes() {
		LOG.info("EXEcution started for getUOMCodes");
		
		
		// return sizeUOMDetailnRepo.findAll();

		 /*As per the request from the business, we are adding this as a work
		 around for not showing UOM code in the UI.
		even though this is not a good solution, we are implementing because
		/of time constraints.*/

		List<SizeUOMDetail> validUom = new ArrayList<>();
		List<String> inValidUOMArray = Arrays.asList("AS", "BA", "BB", "BI",
				"BL", "BR", "BT", "CE", "CL", "CO", "CW", "DR", "EV", "EX",
				"FA", "HC", "HD", "HP", "JR", "LK", "LR", "MR", "MS", "MX",
				"PA", "PE", "PN", "RK", "RO", "SI", "SM", "SV", "SY", "CC",
				"PG", "US", "BD", "CM", "CR", "PL", "BN", "CI", "PD", "PS",
				"CU", "CN", "KT", "FL", "SQ");
		List<SizeUOMDetail> uomAll = sizeUOMDetailnRepo
				.findAllByOrderByUomCodeAsc();
		LOG.info("FEtChing all "+uomAll.size()+" Uom");
		Iterator<SizeUOMDetail> uomIterator = uomAll.iterator();
		int i = 0;
		while (uomIterator.hasNext()) {
			if (!inValidUOMArray.contains(uomIterator.next().getUomCode())) {

				validUom.add(uomAll.get(i));
			}

			i++;

		}
		LOG.info("EXEcution completed for getUOMCodes");
		return validUom;
	}

	@Override
	public List<DepartmentDto> getDepartmentDetails(String companyId,
			String divisionId) {
		
		List<Object[]> departmentRecs = commonSQLRepo.getDepartments(companyId,
				divisionId);
		LOG.debug("Completed fetching all"+departmentRecs.size()+"departmentRecs");
		return viewAdapter.buildDepartmentDtoList(departmentRecs);
	}

	/**
	 * @param uiExceptionSrcDto
	 * @return
	 */
	@SuppressWarnings("unused")
	private NewItemDetailDto loadNewItemRecord(UIExceptionSrcDto uiExceptionSrcDto) {
		LOG.debug("EXEcution started for loadNewItemRecord");
		String division = uiExceptionSrcDto.getDivisionId();
		String company = uiExceptionSrcDto.getCompanyId();
		String productsku = uiExceptionSrcDto.getProductSKU();
		String proSrcCd = uiExceptionSrcDto.getProductSrcCd();
		String upcContry = uiExceptionSrcDto.getUpcCountry();
		String upcManuf = uiExceptionSrcDto.getUpcManufacturer();
		String upcSales = uiExceptionSrcDto.getUpcSales();
		String upcSys = uiExceptionSrcDto.getUpcSystem();
		NewItemDetailDto newItem = null;
		NewItemDetail newItemDto = newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkProductSrcCdAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkUpcCountryAndNewItemPkUpcSystemAndNewItemPkUpcManufacturerAndNewItemPkUpcSales(
						productsku, proSrcCd, division, company, upcContry,
						upcSys, upcManuf, upcSales);
		if (newItemDto == null) {
			newItem = viewAdapter.setNewItemforView(uiExceptionSrcDto);
		} else {
			newItem = viewAdapter.mapNewItemCICDto(newItemDto);
		}
		LOG.debug("EXEcution completed for loadNewItemRecord");
		return newItem;
	}

	@Override
	public void saveException(UIExceptionSrcDto exception) {
		LOG.info("EXEcution started for save exception");
		List<UIExceptionSrc> sourceObjs = exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCd(
						exception.getProductSKU(), exception.getDivisionId(),
						exception.getCompanyId(), 'A');
		
		LOG.debug("Exception Source Objects loaded.");
		if (sourceObjs != null && !(sourceObjs.isEmpty())) {
			for (UIExceptionSrc excSrc : sourceObjs) {
				excSrc.setPrdHierLevel4(exception.getHierLevel4());
				excSrc.setPrdHierLevel5(exception.getHierLevel5());
				exceptionRepo.save(excSrc);
			}
		}
		LOG.info("EXEcution completd for save exception");
	}

	@Override
	public void saveItemAggregateCorp(UIExceptionSrcDto exception) {
		LOG.info("EXEcution started for saveItemAggregateCorp");
		List<ItemAggregateCorp> sourceObjs = itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyId(
						exception.getProductSKU(), exception.getDivisionId(),
						exception.getCompanyId());
		LOG.debug("Completed fetching all"+sourceObjs.size()+"sourceObjs");
		LOG.info("Exception Source Objects loaded.");
		if (sourceObjs != null && !(sourceObjs.isEmpty())) {
			for (ItemAggregateCorp item : sourceObjs) {
				item.setPrdHierLevel4(exception.getHierLevel4());
				item.setPrdHierLevel5(exception.getHierLevel5());
				itemAggregateRepo.save(item);
			}
		}
		LOG.info("EXEcution completed for saveItemAggregateCorp");
	}

	private void setSlotIDAndOnhandStatus(UIExceptionSrcDto exceptionSrcDto) {
		LOG.debug("EXEcution started for setSlotIDAndOnhandStatus");
		List<Object[]> records = commonSQLRepo.loadOnhandStatus(
				exceptionSrcDto.getCompanyId(),
				exceptionSrcDto.getDivisionId(),
				exceptionSrcDto.getProductSKU());
		LOG.info("Completed fetching all"+records.size()+"setSlotIDAndOnhandStatus");
		if (records != null && !(records.isEmpty())) {
			Object[] record = records.get(0);
			String slotId = getStringValue(record[0]);
			BigDecimal onhandNbr =getBigDecimalValue(record[1]);
			if ((slotId != null && slotId.length() > 0) && (onhandNbr != null
					&& onhandNbr.intValue() > 0))
				exceptionSrcDto.setSlotId(slotId);
			if (onhandNbr != null && onhandNbr.intValue() > 0)
				exceptionSrcDto.setOnhandNbr(onhandNbr);
		}
		LOG.debug("EXEcution completed for setSlotIDAndOnhandStatus");
	}

	private void setProductHierarchyDetails(UIExceptionSrcDto exceptionSrcDto) {
		LOG.debug("Started fetching all setProductHierarchyDetails");
		List<Object[]> records = commonSQLRepo.getHigherarchyDetails(
				exceptionSrcDto.getCompanyId(),
				exceptionSrcDto.getDivisionId(),
				exceptionSrcDto.getHierLevel1(),
				exceptionSrcDto.getHierLevel2(),
				exceptionSrcDto.getHierLevel3());
		LOG.debug("Completed fetching all"+records.size()+"HierarchyDetails");
		if (records != null && !(records.isEmpty())) {
			Object[] record;
			for (int i = 0; i < records.size(); i++) {
				record = records.get(i);
				String description = getStringValue(record[8]);
				if (i == 0) {
					exceptionSrcDto.setCategoryDesc(description);
				}
				if (i == 1) {
					exceptionSrcDto.setSubCategoryDesc(description);
				}
				if (i == 2) {
					exceptionSrcDto.setGroupDesc(description);
				}
			}
		}
		LOG.debug("Completed fetching all setProductHierarchyDetails");
	}

	@Override
	public void insertManualMappingRecord(UIExceptionSrcDto exception,
			BigDecimal cic) {
		LOG.info("Inseert ManualMappingRecord");
		ManualMapping entity = new ManualMapping();
		ManualMappingPK entityPk = new ManualMappingPK();
		entityPk.setCompanyId(exception.getCompanyId());
		entityPk.setDivisionId(exception.getDivisionId());
		entityPk.setProductSKU(exception.getProductSKU());
		entity.setManualMappingPK(entityPk);
		entity.setCic(cic);
		entity.setCreateUser(exception.getUpdatedUserID());
		List<UPCVo> upcList = exception.getUpcVoList();
		LOG.debug("Completed fetching all"+upcList.size()+"Company records");
		if (upcList == null || upcList.isEmpty()) {
			entityPk.setUpc(exception.getPrimaryUPC());
			manualMappingRepository.save(entity);
		} else {
			String upc = "";
			for (int i = 0; i < upcList.size(); i++) {
				upc = upcList.get(i).getUpc();
				String[] upcFields = upc.split("-");
				StringBuilder upcVal = new StringBuilder();
				for (int j = 0; j < upcFields.length; j++)
					upcVal.append(upcFields[j]);
				if (upcVal.length() > 0) {
					entityPk.setUpc(upcVal.toString());
					manualMappingRepository.save(entity);
				}
			}

		}
		LOG.info("Successfully Inseerted ManualMappingRecord");
	}

	private BigDecimal getBigDecimalValue(Object obj) {
		if (obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}

	private String getStringValue(Object obj) {
		if (obj == null)
			return "";
		return ((String) obj).trim();
	}

	private Character getCharacterValue(Object obj) {
		String empty = " ";
		if (obj == null)
			return Character.valueOf(empty.charAt(0));
		return (Character) obj;
	}

	@Override
	public boolean checkTargetProdClass(String prodClass, String groupCode) {
		LOG.info("Fetching all checkTargetProdClass");
		List<String> result = commonSQLRepo.getTargetProdClass(prodClass);
		boolean isvalid = false;
		if (result != null && !result.isEmpty()) {
			if ( groupCode.equals("84")) {
				if (result.get(0).startsWith("84")) {
					isvalid = true;
				} else {
					isvalid = false;
				}
			} else {
				isvalid = true;
			}
		}
		LOG.info("Completed Fetching all checkTargetProdClass");
		return isvalid;
	}

}
