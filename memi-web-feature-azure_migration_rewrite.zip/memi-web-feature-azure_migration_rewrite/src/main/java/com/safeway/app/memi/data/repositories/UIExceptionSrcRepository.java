package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : UIExceptionSrcRepository
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.UIExceptionSrc;

/**
 * Repository class for all DB operations for ITEM_CONV_UI_EXCEPTION_SRC table
 */
@Repository
public interface UIExceptionSrcRepository extends JpaRepository<UIExceptionSrc, Long> {


    /**
     * @param divisionId
     * @return
     */
    @Query
    List<UIExceptionSrc> findByUiSrcPkDivisionId(String divisionId);
    

    /**
     * @param productSKU
     * @return
     */
    @Query
    UIExceptionSrc findByUiSrcPkProductSKU(String productSKU);
    

    /**
     * @return
     */
    @Query("select deptDtl from UIExceptionSrc s")
    List<UIExceptionSrc> findDeptartment();


    /**
     * @param divisionId
     * @param companyId
     * @param excptnTypeCd
     * @param excptnProcessdInd
     * @return
     */
    @Query
    @QueryHints(@javax.persistence.QueryHint(name="org.hibernate.fetchSize", value="1000"))
    List<UIExceptionSrc> findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(String divisionId,
        String companyId, char excptnTypeCd, char excptnProcessdInd);

    /**
     * @param divisionId
     * @param companyId
     * @param excptnTypeCd
     * @return
     */
    @Query
    List<UIExceptionSrc> findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCd(String divisionId, String companyId,
        char excptnTypeCd);
    
    /**
     * @param division
     * @param company
     * @param productsku
     * @param excptnTypeCd
     * @return
     */
    @Query
    List<UIExceptionSrc> findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndExcptnTypeCdAndAndExcptnProcessdIndNotOrderByPrmyUpcIndDesc(String division, String company, String productsku, char excptnTypeCd, char excptnProcessdInd);
   
    /**
     * @param division
     * @param company
     * @param productsku
     * @param prmyUpcInd
     * @return
     */
    @Query
    UIExceptionSrc findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndPrmyUpcInd(String division, String company,
        String productsku, char prmyUpcInd);

    /**
     * @param division
     * @param company
     * @param upc_Country
     * @param upc_System
     * @param upc_Manuf
     * @param upc_Sales
     * @param excptnTypeCd
     * @return
     */
    @Query
    List<UIExceptionSrc> findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdIndNot(String division,
        String company, String upc_Country, String upc_System, String upc_Manuf, String upc_Sales, char excptnTypeCd, char excptnProcessdInd);
    /**
     * @param productsku
     * @param proSrcCd
     * @param division
     * @param company
     * @param upcContry
     * @param upcSys
     * @param upcManuf
     * @param upcSales
     * @return
     */
    @Query
    UIExceptionSrc findByUiSrcPkProductSKUAndUiSrcPkProductSrcCdAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSales(
        String productsku, String proSrcCd, String division, String company, String upcContry, String upcSys,
        String upcManuf, String upcSales);
    
    /**
     * @param productsku
     * @param proSrcCd
     * @param division
     * @param excptnTypeCd
     * @return
     */
    @Query
    List<UIExceptionSrc> findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCd(
        String productsku, String division, String company, char excptnTypeCd);
    
    /**
     * @param productsku
     * @param proSrcCd
     * @param division
     * @param company
     * @param upcContry
     * @param upcSys
     * @param upcManuf
     * @param upcSales
     * @param c
     * @return
     */
    @Query
    UIExceptionSrc findByUiSrcPkProductSKUAndUiSrcPkProductSrcCdAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndPrmyUpcInd(
        String productsku, String proSrcCd, String division, String company, String upcContry, String upcSys,
        String upcManuf, String upcSales, char c);
    
    /**
     * @param companyId
     * @param divisionId
     * @param excptnTypeCd
     * @param processedInd
     * @param deptCD
     * @return
     */
    @Query
    @QueryHints(@javax.persistence.QueryHint(name="org.hibernate.fetchSize", value="1000"))
    List<UIExceptionSrc> findByUiSrcPkCompanyIdAndUiSrcPkDivisionIdAndExcptnTypeCdAndExcptnProcessdIndAndDeptDtlDeptName(String companyId, String divisionId, 
        char excptnTypeCd, char processedInd, String deptName);
    
  
    /**
     * @param productsku
     * @param excptnTypeCd
     * @param divisionId
     * @param companyId
     * @return
     */
    @Query
    List<UIExceptionSrc> findByUiSrcPkProductSKUAndAndExcptnTypeCdAndUiSrcPkDivisionIdAndUiSrcPkCompanyId(String productsku,
            char excptnTypeCd, String divisionId, String companyId);

    @Query
	List<UIExceptionSrc> findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
			String productsku, String division, String company, char excptnTypeCd,
			char excptnProInd);
    @Query
	UIExceptionSrc findByUiSrcPkProductSKUAndUiSrcPkProductSrcCdAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdInd(
			String productSku, String productSrcCode, String divisionId,
			String companyId, String upcCountry, String upcSystem,
			String upcManuf, String upcSales, char excptnTypeCd, char excptnProcessdInd);
    
}
