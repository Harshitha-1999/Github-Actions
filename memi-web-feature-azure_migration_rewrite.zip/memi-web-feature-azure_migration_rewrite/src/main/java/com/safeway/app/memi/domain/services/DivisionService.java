/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.domain.services;

/* ***************************************************************************
 * NAME         : DivisionService 
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 May 09, 2017  -  Initial Creation
 *
 ***************************************************************************/

import java.util.List;

import com.safeway.app.memi.domain.dtos.response.DivisionDto;

/**
 * 
 * Interface definition for Division Services
 *
 */
public interface DivisionService {

    /**
     * Method to fetch Division List
     */
    public List<DivisionDto> getAllItems();
    
    /**
     * Method to fetch Division List for a Company
     */
    public List<DivisionDto> findByCompanyId(String companyID);

}
