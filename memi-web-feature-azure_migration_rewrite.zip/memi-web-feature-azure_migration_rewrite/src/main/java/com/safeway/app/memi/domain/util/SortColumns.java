package com.safeway.app.memi.domain.util;

import java.util.HashMap;
import java.util.Map;

public enum SortColumns {
	  
			DEPT("PROD_HIERARCHY_LVL_4_CD"),
		   HIER1("PROD_HIERARCHY_LVL_1_NM"),
		   HIER2("PROD_HIERARCHY_LVL_2_NM"),
		   HIER3("PROD_HIERARCHY_LVL_3_NM"),
		   SUPPL("VENDOR_NM "),
		 //  PSKU("to_number(PRODUCT_SKU)"),
		   PSKU("PRODUCT_SKU"),
		   ITDS("ITEM_DESC"),
		   
	/**Look up**/
    LKPCONGP("SRC.CONVERSION_GROUP"),
    LKPHIER1("SRC.PROD_HIERARCHY_LVL_1_NM"),
    LKPHIER2("SRC.PROD_HIERARCHY_LVL_2_NM"),
    LKPHIER3("SRC.PROD_HIERARCHY_LVL_3_NM"),
    LKPSUPNO("SRC.SRC_SUPPLIER_NUM"),
    LKPSUPNM("SRC.VENDOR_NM"),
    LKPITMDS("SRC.ITEM_DESC"),
  //  LKPSKU( "to_number(D.PRODUCT_SKU)");
    LKPSKU("SRC.PRODUCT_SKU");
	
    private String columns;
    
    SortColumns(String columns) {
        this.columns = columns;
    }
 
    public String getColumns() {
        return columns;
    }
   


}
