package com.safeway.app.memi.configuratons;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceConfiguration {
	@Value("${spring.datasource.url}")
	String dataSourceURL;
	@Value("${spring.datasource.driverClassName}")
	String driverClassName;
	@Value("${spring.datasource.username}")
	String userName;
	@Value("${spring.datasource.password}")
	String password;
	@Value("${spring.datasource.hikari.maximum-pool-size}")
	Integer connectionPoolMaxSize;
	@Value("${spring.datasource.hikari.idle-timeout}")
	Integer idleTimeoutMs;
	@Value("${spring.datasource.useServerPrepStmts}")
	Boolean useServerPrepStmts;
	@Value("${spring.datasource.cachePrepStmts}")
	Boolean cachePrepStmts;
	@Value("${spring.datasource.prepStmtCacheSize}")
	Integer prepStmtCacheSize;

	@Bean
	public DataSource getDataSource() {
		HikariConfig config = new HikariConfig();
		config.setDriverClassName(driverClassName);
		config.setJdbcUrl(dataSourceURL);
		config.setUsername(userName);
		config.setPassword(password);
		config.setMaximumPoolSize(connectionPoolMaxSize);
		config.setIdleTimeout(idleTimeoutMs);
		config.addDataSourceProperty("cachePrepStmts", cachePrepStmts);
		config.addDataSourceProperty("prepStmtCacheSize", prepStmtCacheSize);
		config.addDataSourceProperty("useServerPrepStmts", useServerPrepStmts);
		return new HikariDataSource(config);
	}
}