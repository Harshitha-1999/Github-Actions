package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "ITEM_CONV_BULK_UPLOAD_TRACKING", schema="ECFLAND")
public class ItemConvBulkUploadTracking implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BULK_UPLOAD_ID")
	private BigDecimal bulkUploadId;
	
	@Column(name = "COMPANY_ID")
	private String companyId;

	@Column(name = "DIVISION_ID")
	private String divisionId;
	
	@Column(name = "DEPARTMENT_NM")
	private String deptName;
	
	@Column(name = "FILE_NM")
	private String fileName;
	
	@Column(name = "FILE_PATH")
	private String filePath;
	
	@Column(name = "STATUS_CD")
	private String statusCode;
	
	@Column(name = "RECORD_COUNT")
	private BigDecimal recordCount;
	
	@Column(name = "VALID_RECORD_COUNT")
	private BigDecimal validRecordCount;
	
	@Column(name = "CREATE_USER_ID")
	private String createUserId;
	
	@Column(name = "CREATE_UPDATE_TS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date  createUpdateTimestamp;

	public BigDecimal getBulkUploadId() {
		return bulkUploadId;
	}

	public void setBulkUploadId(BigDecimal bulkUploadId) {
		this.bulkUploadId = bulkUploadId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public BigDecimal getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(BigDecimal recordCount) {
		this.recordCount = recordCount;
	}

	public BigDecimal getValidRecordCount() {
		return validRecordCount;
	}

	public void setValidRecordCount(BigDecimal validRecordCount) {
		this.validRecordCount = validRecordCount;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateUpdateTimestamp() {
		return createUpdateTimestamp;
	}

	public void setCreateUpdateTimestamp(Date createUpdateTimestamp) {
		this.createUpdateTimestamp = createUpdateTimestamp;
	}
}
