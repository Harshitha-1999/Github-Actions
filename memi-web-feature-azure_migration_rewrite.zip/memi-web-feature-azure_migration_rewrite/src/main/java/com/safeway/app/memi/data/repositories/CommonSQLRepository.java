/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.data.repositories;

/* ***************************************************************************
 * NAME         : LikeItemSQLRepository 
 *
 * SYSTEM       : MEMI
 * 
 * AUTHOR       : Subhash G
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.0 June 11, 2017 sgang06 -  Initial Creation
 *
 ***************************************************************************/


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.NewItemDetail;
/**
 * Repository class for LikeItem DB operations
 */
@Repository
@SuppressWarnings("unchecked")
public class CommonSQLRepository{

	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;

	private static final Logger LOG = LoggerFactory
			.getLogger(CommonSQLRepository.class);


	/**
	 * This method fetches Like Items from the Database
	 */
	public List<Object[]> fetchLikeItems(String upcManuf, String upcSales, String upcCountry, String upcSystem) {

		
		LOG.info("Fetching like items.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("WITH T1 AS (SELECT CORP_ITEM_CD, CREATE_DATE FROM SSIMSLAND.SQLDAT3_SSITMXRF WHERE UPC_MANUF = :upcManuf AND UPC_SALES = :upcSales  AND UPC_COUNTRY = :upcCountry  AND UPC_SYSTEM = :upcSystem  ) ,T4 AS (SELECT A.CORP_ITEM_CD, A.DESC_ITEM, A.PACK_WHSE, A.VEND_CONV_FCTR, A.ITEM_USAGE_IND, A.ITEM_USAGE_TYPE, A.DISP_FLAG, A.GROUP_CD, A.CTGRY_CD, A.CLASS_CD, A.SUB_CLASS_CD, A.SUBSB_CLASS_CD, A.CDS_SIZE, A.SIZE_NUM, A.SIZE_UOM, A.MANUF_TYPE_IND, C.WHSE_ITEM_DESC, B.RTL_ITEM_DESC, B.INTERNET_ITEM_DESC, D.CLSIFICATION_DESC, concat( A.VEN_UPC_PACK_IND , '-' , A.VEN_UPC_COUNTRY , '-' , A.VEN_UPC_NUM_SYS , '-' , A.VEN_UPC_MANUF , '-' , A.VEN_UPC_ITEM , '-' , A.VEN_UPC_CHECK) AS CASE_UPC, A.STATUS_CORP, A.ONE_TM_BUY_ITM_SW, A.INNER_PACK, FLOOR(T1.CORP_ITEM_CD/10000) AS PRODUCT_CLASS_CODE, A.PROD_CD_GROUP, A.PROD_CD_CTGRY,A.PROD_CD_CLASS  FROM  SSIMSLAND.SQLDAT3_SSITMCDS A, SSIMSLAND.SQLDAT3_SSITMDSR B, SSIMSLAND.SQLDAT3_SSITMDSW C, SSIMSLAND.SQLDAT3_MEPRDCLF D, T1 WHERE T1.CORP_ITEM_CD = A.CORP_ITEM_CD AND T1.CORP_ITEM_CD = B.CORP_ITEM_CD AND T1.CORP_ITEM_CD = C.CORP_ITEM_CD AND A.CORP_ITEM_CD  = B.CORP_ITEM_CD AND B.CORP_ITEM_CD  = C.CORP_ITEM_CD AND D.GROUP_CD = A.GROUP_CD AND D.CTGRY_CD = A.CTGRY_CD AND D.CLASS_CD = A.CLASS_CD AND D.SUB_CLASS_CD  = A.SUB_CLASS_CD AND D.SUBSB_CLASS_CD  = A.SUBSB_CLASS_CD ), T5 AS ( SELECT DISTINCT A.CORP_ITEM_CD, A.DST_CNTR, A.STATUS_DST, A.COST_VEND, A.ITEM_ON_NEW_DSD_SW, B.TYPE, B.US_BILLING_ROG, C.PRODUCT_SOURCE_IND, C.UPC_MANUF, C.UPC_SALES, C.UPC_COUNTRY, C.UPC_SYSTEM, C.PRIMARY_UPC_SW, D.DESC_POS, E.ROG, F.DEPT_NAME, F.DEPT FROM SSIMSLAND.SQLDAT3_SSITMWDS A, SSIMSLAND.SQLDAT3_CODSTTAB B, SSIMSLAND.SQLDAT3_SSITMURX C, SSIMSLAND.SQLDAT3_SSITMPOS D, SSIMSLAND.SQLDAT3_SSITMROG E, SSIMSLAND.SQLDAT3_OMDEPT F, T1 WHERE  T1.CORP_ITEM_CD = A.CORP_ITEM_CD AND A.DST_CNTR = B.DST_CNTR AND B.US_BILLING_ROG  = C.ROG AND A.CORP_ITEM_CD  = C.CORP_ITEM_CD AND A.CORP_ITEM_CD  = E.CORP_ITEM_CD AND C.UPC_MANUF  = D.UPC_MANUF AND C.UPC_SALES  = D.UPC_SALES AND C.UPC_COUNTRY = D.UPC_COUNTRY AND C.UPC_SYSTEM = D.UPC_SYSTEM AND C.ROG = D.ROG AND D.ROG = E.ROG AND E.CORP = '001' AND F.DEPT_TYPE = 'W' AND F.DEPT = A.DEPT ) SELECT DISTINCT  T4.CORP_ITEM_CD, T4.DESC_ITEM AS ITEM_DESC, T4.WHSE_ITEM_DESC AS WHSE_DESC, T4.RTL_ITEM_DESC AS SS_DESC, T4.INTERNET_ITEM_DESC AS INTER_DESC, T5.DESC_POS  AS POS_DESC, T4.PACK_WHSE AS PACK, T4.VEND_CONV_FCTR AS VCF, T4.ITEM_USAGE_IND AS USAGE_IND, T4.ITEM_USAGE_TYPE  AS USAGE_TYPE, T4.DISP_FLAG AS DISPLAY, T4.GROUP_CD  AS SMIC1, T4.CTGRY_CD  AS SMIC2, T4.CLASS_CD  AS SMIC3, T4.SUB_CLASS_CD  AS SMIC4, T4.SUBSB_CLASS_CD AS SMIC5, T5.DST_CNTR  AS DC, T5.ROG  AS ROG, T5.PRIMARY_UPC_SW, T5.COST_VEND AS COST, concat( T5.UPC_COUNTRY , '-' , T5.UPC_SYSTEM , '-' , T5.UPC_MANUF , '-' , T5.UPC_SALES) AS PRIMARY_UPC, T5.ITEM_ON_NEW_DSD_SW AS TRUE_DSD, T4.CDS_SIZE  AS DESC_SIZE, T4.SIZE_NUM  AS NUM_SIZE, T4.SIZE_UOM  AS NUM_UOM, ( CASE WHEN T5.TYPE = 'D' THEN 'DD' WHEN T5.TYPE = 'W' THEN 'WHSE' WHEN T5.TYPE = 'D' AND T5.ITEM_ON_NEW_DSD_SW <> 'Y' THEN 'SS' ELSE ' ' END )  AS PRODUCT_SRC, T4.CLSIFICATION_DESC AS SMIC_DESC, T4.MANUF_TYPE_IND  AS PRIVATE_LABEL, T4.CASE_UPC, T4.STATUS_CORP, T1.CREATE_DATE, T5.DEPT_NAME, T5.DEPT, T5.STATUS_DST, T4.ONE_TM_BUY_ITM_SW,T4.INNER_PACK,T4.PRODUCT_CLASS_CODE,T4.PROD_CD_GROUP,T4.PROD_CD_CTGRY,T4.PROD_CD_CLASS FROM  T4, T5, T1 WHERE T4.CORP_ITEM_CD = T5.CORP_ITEM_CD  ORDER BY 1");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("upcManuf", upcManuf);
		q.setParameter("upcSales", upcSales);
		q.setParameter("upcCountry", upcCountry);
		q.setParameter("upcSystem", upcSystem);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		q.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching like items.");
		em.close();
		return results;
	}
	
	/**
	 * This method fetches Like Items from the Database
	 */
	public List<Object[]> fetchLikeItemsForMultiUPCs(String productSku, String companyId, String divisionId) {

		LOG.info("Fetching like items.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT T1.CORP_ITEM_CD, A.DESC_ITEM AS ITEM_DESC, C.WHSE_ITEM_DESC AS WHSE_DESC, B.RTL_ITEM_DESC AS SS_DESC, B.INTERNET_ITEM_DESC AS INTER_DESC, H.DESC_POS AS POS_DESC, A.PACK_WHSE AS PACK, A.VEND_CONV_FCTR AS VCF,A.ITEM_USAGE_IND AS USAGE_IND, A.ITEM_USAGE_TYPE AS USAGE_TYPE, A.DISP_FLAG AS DISPLAY ,A.GROUP_CD AS SMIC1 , A.CTGRY_CD AS SMIC2 , A.CLASS_CD AS SMIC3 , A.SUB_CLASS_CD AS SMIC4 , A.SUBSB_CLASS_CD AS SMIC5 ,E.DST_CNTR    AS DC , I.ROG  AS ROG, G.PRIMARY_UPC_SW, E.COST_VEND AS COST , concat(T2.UPC_COUNTRY,'-',T2.UPC_SYSTEM,'-',T2.UPC_MANUF,'-',T2.UPC_SALES) AS PRIMARY_UPC,")
		.append(" E.ITEM_ON_NEW_DSD_SW AS TRUE_DSD,A.CDS_SIZE AS DESC_SIZE, A.SIZE_NUM AS NUM_SIZE, A.SIZE_UOM AS NUM_UOM ,( CASE WHEN F.TYPE = 'D' THEN 'DD' WHEN F.TYPE = 'W' THEN 'WHSE' WHEN F.TYPE = 'D' AND E.ITEM_ON_NEW_DSD_SW <> 'Y' THEN 'SS' ELSE ' ' END )  AS PRODUCT_SRC, D.CLSIFICATION_DESC AS SMIC_DESC , A.MANUF_TYPE_IND  AS PRIVATE_LABEL, concat(A.VEN_UPC_PACK_IND , '-' , A.VEN_UPC_COUNTRY , '-' , A.VEN_UPC_NUM_SYS , '-' , A.VEN_UPC_MANUF ,'-',A.VEN_UPC_ITEM) AS CASE_UPC, A.STATUS_CORP, A.CREATE_DT, J.SECT_NAME AS DEPT_NAME, A.RETAIL_SECT AS DEPT, E.STATUS_DST, A.ONE_TM_BUY_ITM_SW,")
		.append(" A.INNER_PACK, FLOOR(T1.CORP_ITEM_CD/10000) AS PRODUCT_CLASS_CODE, A.PROD_CD_GROUP, A.PROD_CD_CTGRY, A.PROD_CD_CLASS FROM SSIMSLAND.SQLDAT3_SSITMXRF T1 JOIN ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC EXC ON EXC.PRODUCT_SKU =:productSku  AND EXC.COMPANY_ID = :companyId  AND EXC.DIVISION_ID = :divisionId  AND T1.UPC_MANUF = EXC.UPC_MANUF AND T1.UPC_SALES   = EXC.UPC_SALES AND T1.UPC_COUNTRY = EXC.UPC_COUNTRY  AND T1.UPC_SYSTEM  = EXC.UPC_SYSTEM INNER JOIN SSIMSLAND.SQLDAT3_SSITMXRF T2 ON T1.CORP_ITEM_CD = T2.CORP_ITEM_CD INNER JOIN SSIMSLAND.SQLDAT3_SSITMCDS A ON T1.CORP_ITEM_CD = A.CORP_ITEM_CD AND A.DISP_FLAG != 'Y' AND A.STATUS_CORP != 'D'")
		.append(" INNER JOIN SSIMSLAND.SQLDAT3_OMSECT J ON A.RETAIL_SECT = J.SECT INNER JOIN SSIMSLAND.SQLDAT3_SSITMDSR B ON A.CORP_ITEM_CD = B.CORP_ITEM_CD INNER JOIN SSIMSLAND.SQLDAT3_SSITMDSW C ON A.CORP_ITEM_CD = C.CORP_ITEM_CD INNER JOIN SSIMSLAND.SQLDAT3_MEPRDCLF D ON D.GROUP_CD = A.GROUP_CD AND D.CTGRY_CD = A.CTGRY_CD AND D.CLASS_CD = A.CLASS_CD AND D.SUB_CLASS_CD = A.SUB_CLASS_CD AND D.SUBSB_CLASS_CD = A.SUBSB_CLASS_CD INNER JOIN SSIMSLAND.SQLDAT3_SSITMWDS E ON A.CORP_ITEM_CD = E.CORP_ITEM_CD  AND E.STATUS_DST !='D' INNER JOIN SSIMSLAND.SQLDAT3_CODSTTAB F ON E.DST_CNTR = F.DST_CNTR LEFT OUTER JOIN")
		.append(" SSIMSLAND.SQLDAT3_SSITMROG I ON E.CORP_ITEM_CD = I.CORP_ITEM_CD AND E.FACILITY = I.FACILITY LEFT OUTER JOIN SSIMSLAND.SQLDAT3_SSITMURX G ON E.CORP_ITEM_CD = G.CORP_ITEM_CD AND I.ROG = G.ROG AND G.UPC_MANUF = T2.UPC_MANUF AND G.UPC_SALES = T2.UPC_SALES  AND G.UPC_COUNTRY = T2.UPC_COUNTRY AND G.UPC_SYSTEM = T2.UPC_SYSTEM LEFT OUTER JOIN SSIMSLAND.SQLDAT3_SSITMPOS H  ON I.ROG = H.ROG AND H.CORP = '001'  AND G.UPC_MANUF = H.UPC_MANUF AND G.UPC_SALES = H.UPC_SALES AND G.UPC_COUNTRY = H.UPC_COUNTRY AND G.UPC_SYSTEM = H.UPC_SYSTEM ")
		.append(" WHERE E.FACILITY = '3057' OR (E.FACILITY <> '3057' AND I.CORP_ITEM_CD IS NOT NULL AND G.CORP_ITEM_CD IS NOT NULL AND H.ROG IS NOT NULL) ORDER BY T1.CORP_ITEM_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		q.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching like items.");
		em.close();
		return results;
	}
	
	/**
	 * This method fetches Department wise exception details from the Database
	 */
	public List<Object[]> fetchDepartmentWiseExceptions(String companyId, String divisionId, char exceptionType, char exceptionProcessedInd) {

		LOG.info("Fetching fetchDepartmentWiseExceptions details.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT COUNT(*) AS EXCEPTION_COUNT,DEPARTMENT_NM, DEPARTMENT_CD, COUNT(CASE WHEN PROD_SRC_CD LIKE 'D%' THEN 1 ELSE NULL END) AS EXCEPTION_COUNT_DSD, COUNT(CASE WHEN PROD_SRC_CD LIKE 'W%' THEN 1 ELSE NULL END) AS EXCEPTION_COUNT_WHSE  FROM (SELECT DISTINCT PRODUCT_SKU, upper(PROD_HIERARCHY_LVL_5_CD) AS DEPARTMENT_NM, PROD_HIERARCHY_LVL_4_CD AS DEPARTMENT_CD, PROD_SRC_CD FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC WHERE PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND COMPANY_ID= :companyId   AND DIVISION_ID =:divisionId  AND EXCEPTION_TYPE_CD = :exceptionType AND EXCEPTION_PROCESSED_IND = :exceptionProcessedInd ) INNER_TABLE GROUP BY DEPARTMENT_NM,DEPARTMENT_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("exceptionType", exceptionType);
		q.setParameter("exceptionProcessedInd", exceptionProcessedInd);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "25");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching fetchDepartmentWiseExceptions details.");
		em.close();
		return results;
	}
	
	/**
	 * This method fetches Department wise exception details from the Database
	 */
	public List<String> fetchDepartmentWiseExcpnSKUs(String companyId, String divisionId, char exceptionType, char exceptionProcessedInd, String departmentCode, char type) {
		LOG.info("Fetching department details.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT PRODUCT_SKU FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC WHERE PROD_HIERARCHY_LVL_5_CD IS NOT NULL AND PROD_HIERARCHY_LVL_4_CD = :departmentCode  AND COMPANY_ID= :companyId  AND DIVISION_ID =:divisionId AND EXCEPTION_TYPE_CD = :exceptionType  AND EXCEPTION_PROCESSED_IND=:exceptionProcessedInd");
		if(type != 'A'){
			baseQuery.append(" AND PROD_SRC_CD LIKE :type ");
		}
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("exceptionType", exceptionType);
		q.setParameter("exceptionProcessedInd", exceptionProcessedInd);
		q.setParameter("departmentCode", departmentCode);
		if(type != 'A')
		q.setParameter("type", type+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "5000");
		List<String> results = q.getResultList();
		LOG.info("Completed fetching department details.");
		em.close();
		return results;
	}

	/**
	 * This method fetches Department wise exception details from the Database
	 */
	public List<Object[]> fetchDepartmentWiseReviewItems(String companyId, String divisionId) {

		LOG.info("Fetching department details.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT COUNT(B.DEPARTMENT_CD) AS EXCEPTION_COUNT, B.DEPARTMENT_NM, B.DEPARTMENT_CD FROM ECFLAND.ITEM_CONV_NEW_CIC_DATA_MGMT A JOIN ECFLAND.PRODUCT_HIERARCHY B ON A.COMPANY_ID = :companyId  AND A.DIVISION_ID = :divisionId  AND A.EXCEPTION_TYPE_CD='A' AND A.AUG_OVERRIDE_COMPLETION_IND='Y' AND A.PROD_HIERARCHY_LVL_1_CD = B.PROD_HIERARCHY_LVL_1_CD AND A.PROD_HIERARCHY_LVL_2_CD = B.PROD_HIERARCHY_LVL_2_CD AND A.PROD_HIERARCHY_LVL_3_CD = B.PROD_HIERARCHY_LVL_3_CD GROUP BY B.DEPARTMENT_NM,  B.DEPARTMENT_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "25");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department details.");
		em.close();
		return results;
	}
	
	/**
	 * This method fetches Department wise exception details from Database
	 */
	public List<Object[]> fetchDepartmentWiseExportRecords(String companyId, String divisionId, String departmentCode) {

		LOG.info("Fetching records to export.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("WITH T1 AS (SELECT C.CORP_ITEM_CD, B.DEPARTMENT_NM, B.DEPARTMENT_CD, A.*, C.CREATE_DATE, C.UPC_MANUF AS LIKE_ITEM_UPC_MANUF, C.UPC_SALES AS LIKE_ITEM_UPC_SALES, C.UPC_COUNTRY AS LIKE_ITEM_UPC_COUNTRY, C.UPC_SYSTEM AS LIKE_ITEM_UPC_SYSTEM FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC A JOIN ECFLAND.PRODUCT_HIERARCHY B ON B.DEPARTMENT_NM = :departmentCode   AND A.EXCEPTION_PROCESSED_IND='N' AND A.EXCEPTION_TYPE_CD='O' AND A.COMPANY_ID = :companyId  AND A.DIVISION_ID = :divisionId AND A.PROD_HIERARCHY_LVL_1_CD = B.PROD_HIERARCHY_LVL_1_CD AND A.PROD_HIERARCHY_LVL_2_CD = B.PROD_HIERARCHY_LVL_2_CD AND A.PROD_HIERARCHY_LVL_3_CD = B.PROD_HIERARCHY_LVL_3_CD AND A.PROD_HIERARCHY_LVL_4_CD = B.PROD_HIERARCHY_LVL_4_CD AND A.PROD_HIERARCHY_LVL_5_CD = B.PROD_HIERARCHY_LVL_5_CD JOIN SSIMSLAND.SQLDAT3_SSITMXRF C ON C.UPC_MANUF = A.UPC_MANUF AND C.UPC_SALES = A.UPC_SALES AND C.UPC_COUNTRY = A.UPC_COUNTRY AND C.UPC_SYSTEM = A.UPC_SYSTEM) , T4 AS (SELECT T1.CORP_ITEM_CD, T1.CREATE_DATE, A.DESC_ITEM , A.PACK_WHSE , A.VEND_CONV_FCTR , A.ITEM_USAGE_IND , A.ITEM_USAGE_TYPE , A.DISP_FLAG , A.GROUP_CD , A.CTGRY_CD , A.CLASS_CD , A.SUB_CLASS_CD , A.SUBSB_CLASS_CD , A.CDS_SIZE , A.SIZE_NUM , A.SIZE_UOM , A.MANUF_TYPE_IND , C.WHSE_ITEM_DESC , B.RTL_ITEM_DESC , B.INTERNET_ITEM_DESC , D.CLSIFICATION_DESC,concat( A.VEN_UPC_PACK_IND , '-' , A.VEN_UPC_COUNTRY ,'-' ,A.VEN_UPC_NUM_SYS ,'-' ,A.VEN_UPC_MANUF ,'-' ,A.VEN_UPC_ITEM ,'-' ,A.VEN_UPC_CHECK) AS CASE_UPC, A.STATUS_CORP FROM T1 INNER JOIN SSIMSLAND.SQLDAT3_SSITMXRF AA ON T1.CORP_ITEM_CD = AA.CORP_ITEM_CD INNER JOIN SSIMSLAND.SQLDAT3_SSITMCDS A  ON A.CORP_ITEM_CD = AA.CORP_ITEM_CD LEFT JOIN SSIMSLAND.SQLDAT3_SSITMDSR B ON T1.CORP_ITEM_CD = B.CORP_ITEM_CD AND A.CORP_ITEM_CD  = B.CORP_ITEM_CD LEFT JOIN SSIMSLAND.SQLDAT3_SSITMDSW C ON  T1.CORP_ITEM_CD = C.CORP_ITEM_CD AND B.CORP_ITEM_CD  = C.CORP_ITEM_CD LEFT JOIN SSIMSLAND.SQLDAT3_MEPRDCLF D ON D.GROUP_CD = A.GROUP_CD AND D.CTGRY_CD = A.CTGRY_CD AND D.CLASS_CD = A.CLASS_CD AND D.SUB_CLASS_CD  = A.SUB_CLASS_CD AND D.SUBSB_CLASS_CD  = A.SUBSB_CLASS_CD ) , T5 AS ( SELECT DISTINCT T1.CORP_ITEM_CD, T1.CREATE_DATE, A.DST_CNTR , A.STATUS_DST, A.COST_VEND , A.ITEM_ON_NEW_DSD_SW , C.PRODUCT_SOURCE_IND , AA.UPC_MANUF AS UPC_MANUF, AA.UPC_SALES AS UPC_SALES, AA.UPC_COUNTRY AS UPC_COUNTRY, AA.UPC_SYSTEM AS UPC_SYSTEM, C.PRIMARY_UPC_SW, D.DESC_POS, E.ROG, F.DEPT_NAME, F.DEPT FROM T1 INNER JOIN SSIMSLAND.SQLDAT3_SSITMXRF AA ON T1.CORP_ITEM_CD = AA.CORP_ITEM_CD LEFT JOIN SSIMSLAND.SQLDAT3_SSITMWDS A ON T1.CORP_ITEM_CD = A.CORP_ITEM_CD LEFT JOIN SSIMSLAND.SQLDAT3_SSITMURX C ON A.CORP_ITEM_CD  = C.CORP_ITEM_CD LEFT JOIN SSIMSLAND.SQLDAT3_SSITMPOS D ON C.UPC_MANUF  = D.UPC_MANUF AND C.UPC_SALES  = D.UPC_SALES AND C.UPC_COUNTRY = D.UPC_COUNTRY AND C.UPC_SYSTEM = D.UPC_SYSTEM AND C.ROG  = D.ROG LEFT JOIN SSIMSLAND.SQLDAT3_SSITMROG E ON A.CORP_ITEM_CD  = E.CORP_ITEM_CD AND D.ROG  = E.ROG AND A.CORP = E.CORP_ORD AND A.DIVISION = E.DIVISION_ORD AND A.FACILITY = E.FACILITY AND E.CORP = '001' LEFT JOIN SSIMSLAND.SQLDAT3_OMDEPT F ON F.DEPT_TYPE  = 'W' AND F.DEPT = A.DEPT ) SELECT DISTINCT T4.CORP_ITEM_CD AS LIKE_ITEM_CIC, T4.DESC_ITEM AS LIKE_ITEM_DESC , T4.WHSE_ITEM_DESC AS WHSE_DESC , T4.RTL_ITEM_DESC AS SS_DESC , T4.INTERNET_ITEM_DESC AS INTER_DESC , T5.DESC_POS  AS LIKE_ITEM_POS_DESC , T4.PACK_WHSE AS LIKE_ITEM_PACK , T4.VEND_CONV_FCTR AS VCF , T4.ITEM_USAGE_IND AS LIKE_ITEM_USAGE_IND , T4.ITEM_USAGE_TYPE  AS LIKE_ITEM_USAGE_TYPE , T4.DISP_FLAG AS LIKE_ITEM_DISPLAY , T4.GROUP_CD  AS SMIC1 , T4.CTGRY_CD  AS SMIC2 , T4.CLASS_CD  AS SMIC3 , T4.SUB_CLASS_CD  AS SMIC4 , T4.SUBSB_CLASS_CD AS SMIC5 , T5.DST_CNTR  AS DC , T5.ROG  AS ROG, T5.PRIMARY_UPC_SW, T5.COST_VEND AS LIKE_ITEM_COST , concat(T5.UPC_COUNTRY ,'-' ,T5.UPC_SYSTEM ,'-' ,T5.UPC_MANUF ,'-' ,T5.UPC_SALES) AS LIKE_ITEM_PRIMARY_UPC , T5.ITEM_ON_NEW_DSD_SW AS TRUE_DSD , T4.CDS_SIZE  AS DESC_SIZE , T4.SIZE_NUM  AS NUM_SIZE , T4.SIZE_UOM  AS NUM_UOM , ( CASE  WHEN T5.PRODUCT_SOURCE_IND = 'D' THEN 'DD'  WHEN T5.PRODUCT_SOURCE_IND = 'W' THEN 'WHSE'  WHEN T5.PRODUCT_SOURCE_IND = 'D'  AND T5.ITEM_ON_NEW_DSD_SW <> 'Y' THEN 'SS'  ELSE ' ' END )  AS PRODUCT_SRC , T4.CLSIFICATION_DESC AS SMIC_DESC , T4.MANUF_TYPE_IND  AS PRIVATE_LABEL, T1.*, T4.CASE_UPC AS LIKE_ITEM_CASE_UPC, T4.STATUS_CORP, T5.DEPT, T5.DEPT_NAME FROM T4, T5, T1 WHERE T4.CORP_ITEM_CD = T5.CORP_ITEM_CD  AND T1.CORP_ITEM_CD = T4.CORP_ITEM_CD  AND T1.CORP_ITEM_CD = T5.CORP_ITEM_CD ORDER BY 1");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("departmentCode", departmentCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		q.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching records to report.");
		em.close();
		return results;
		
	}
	
	/**
	 * This method fetches Department wise exception details from Database
	 */
	public List<Object[]> fetchDepartmentWiseExportExceptions(String companyId, String divisionId, String departmentCode, char exceptionType, char exceptionProcessedInd) {

		LOG.info("Fetching records to export.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("WITH EXC AS (SELECT A.COMPANY_ID,A.DIVISION_ID,A.PRODUCT_SKU,A.PROD_SRC_CD,A.UPC_COUNTRY,A.UPC_SYSTEM,A.UPC_MANUF,A.UPC_SALES,A.CASE_UPC,A.PLU_CD,A.PRIMARY_UPC_IND,A.ITEM_USAGE_IND,A.ITEM_USAGE_TYPE_IND,A.PRIVATE_LABEL_IND,A.DISP_FLAG,A.ITEM_DESC,A.WHSE_ITEM_DESC,A.RTL_ITEM_DESC,A.INTERNET_ITEM_DESC,A.POS_DESC,A.VEND_CONV_FCTR,A.PACK_WHSE,A.SIZE_NBR,A.SIZE_UOM,A.SIZE_DESC,A.COST,A.PROD_HIERARCHY_LVL_1_CD,A.PROD_HIERARCHY_LVL_2_CD,A.PROD_HIERARCHY_LVL_3_CD,A.PROD_HIERARCHY_LVL_4_CD,A.PROD_HIERARCHY_LVL_5_CD,A.EXCEPTION_TYPE_CD,A.EXCEPTION_DESC,A.EXCEPTION_PROCESSED_IND,A.CREATE_UPDATE_TS,A.CREATE_UPDATE_USER_ID,A.BATCH_ID,A.LOGICAL_DEL_IND,B.SLOT_ID, B.ONHAND_NBR, D.ITEM_SETUP_DT, D.LAST_SHIP_DT, D.LAST_SALE_DT, D.TOTAL_SALES, D.ON_ORDER_QTY,M.UPD_ITEM_DESC, M.UPD_WHSE_ITEM_DESC, M.UPD_RTL_ITEM_DESC, M.UPD_INTERNET_ITEM_DESC, M.UPD_POS_DESC, M.GROUP_CD, M.CATEGORY_CD, M.CLASS_CD, M.SUB_CLASS_CD,M.SUB_SUB_CLASS_CD,M.PRODUCTION_GROUP_CD,M.PRODUCTION_CATEGORY_CD,M.PRODUCTION_CLASS_CD,M.PRODUCT_CLASS_CD,M.UPD_SIZE,M.UPD_SIZE_NUM,M.UPD_SIZE_UOM,M.INNER_PACK,M.RETAIL_UNIT_PACK,M.UPD_ITEM_USAGE_IND,M.UPD_ITEM_USAGE_TYPE_IND,M.UPD_PRIVATE_LABEL_IND,M.UPD_DISP_FLAG,M.ETHNIC_TYPE_CD,M.PACKAGE_TYPE_ID,M.COV_TEAM_COMMENTS_TXT, "
				  +"B.PRODUCTION_WEIGHT_NBR,B.RECEIVE_RANDOM_IND, C.LABEL_SIZE_SRC_CD, R.TAG_SIZE_TXT, C.LABEL_NUMBERS_SRC_CD,r.tag_count_nbr,R.sign_Type_Cd,R.sign_count_nbr,        C.FD_STMP_SRC_CD,R.food_stamp_ind,C.RING_SRC_CD,C.HICONE_SRC_CD,R.QUANTITY_REQUIRED_IND,B.VENDOR_LIST_COST_NBR, M.RING " 
				 + "FROM (SELECT * FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC WHERE PROD_HIERARCHY_LVL_4_CD = :departmentCode   AND EXCEPTION_PROCESSED_IND=:exceptionProcessedInd  AND EXCEPTION_TYPE_CD=:exceptionType  AND COMPANY_ID = :companyId  AND DIVISION_ID= :divisionId) A LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_WHSE B ON A.PRODUCT_SKU = B.PRODUCT_SKU AND A.COMPANY_ID = B.COMPANY_ID AND A.DIVISION_ID = B.DIVISION_ID LEFT OUTER JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA D ON A.PRODUCT_SKU = D.PRODUCT_SKU AND A.COMPANY_ID = D.COMPANY_ID AND A.DIVISION_ID = D.DIVISION_ID LEFT OUTER JOIN ECFLAND.ITEM_CONV_NEW_CIC_DATA_MGMT M ON A.PRODUCT_SKU = M.PRODUCT_SKU AND A.COMPANY_ID = M.COMPANY_ID AND A.DIVISION_ID = M.DIVISION_ID"
						+ " JOIN ECFLAND.ITEM_CONV_DATA_SRC_CONFIG C "
						+ " ON A.company_id =C.company_id AND A.division_id =C.division_id  AND C.item_set_id  in(3) "
						+ "LEFT JOIN ECFLAND.ITEM_AGGREGATE_ROG R "
						+ " ON A.company_id =R.company_id  AND A.division_id =R.division_id AND A.product_sku =R.product_sku  )")
		.append(" SELECT EXC.*, PRD_HIERARCHY.PROD_HIERARCHY_LVL_1_CD AS PROD_GROUP_CD, PRD_HIERARCHY.PROD_HIERARCHY_LVL_2_CD AS PROD_CATEGORY_CD, PRD_HIERARCHY.PROD_HIERARCHY_LVL_3_CD AS PROD_SUB_CATEGORY_CD, PRD_HIERARCHY.HIERARCHY_LEVEL_NM, PRD_HIERARCHY.HIERARCHY_LEVEL_DESC FROM EXC JOIN ECFLAND.PRODUCT_HIERARCHY PRD_HIERARCHY ON PRD_HIERARCHY.COMPANY_ID = EXC.COMPANY_ID AND PRD_HIERARCHY.DIVISION_ID = EXC.DIVISION_ID AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_1_CD = EXC.PROD_HIERARCHY_LVL_1_CD AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_2_CD = '000' AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_3_CD = '000' ")
		.append(" UNION SELECT EXC.*, PRD_HIERARCHY.PROD_HIERARCHY_LVL_1_CD AS PROD_GROUP_CD, PRD_HIERARCHY.PROD_HIERARCHY_LVL_2_CD AS PROD_CATEGORY_CD, PRD_HIERARCHY.PROD_HIERARCHY_LVL_3_CD AS PROD_SUB_CATEGORY_CD, PRD_HIERARCHY.HIERARCHY_LEVEL_NM, PRD_HIERARCHY.HIERARCHY_LEVEL_DESC FROM EXC JOIN ECFLAND.PRODUCT_HIERARCHY PRD_HIERARCHY ON PRD_HIERARCHY.COMPANY_ID = EXC.COMPANY_ID AND PRD_HIERARCHY.DIVISION_ID = EXC.DIVISION_ID AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_1_CD = EXC.PROD_HIERARCHY_LVL_1_CD AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_2_CD = EXC.PROD_HIERARCHY_LVL_2_CD AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_3_CD = '000'  ")
		.append(" UNION SELECT EXC.*, PRD_HIERARCHY.PROD_HIERARCHY_LVL_1_CD AS PROD_GROUP_CD, PRD_HIERARCHY.PROD_HIERARCHY_LVL_2_CD AS PROD_CATEGORY_CD, PRD_HIERARCHY.PROD_HIERARCHY_LVL_3_CD AS PROD_SUB_CATEGORY_CD, PRD_HIERARCHY.HIERARCHY_LEVEL_NM, PRD_HIERARCHY.HIERARCHY_LEVEL_DESC FROM EXC JOIN ECFLAND.PRODUCT_HIERARCHY PRD_HIERARCHY ON PRD_HIERARCHY.COMPANY_ID = EXC.COMPANY_ID AND PRD_HIERARCHY.DIVISION_ID = EXC.DIVISION_ID AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_1_CD = EXC.PROD_HIERARCHY_LVL_1_CD AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_2_CD = EXC.PROD_HIERARCHY_LVL_2_CD AND PRD_HIERARCHY.PROD_HIERARCHY_LVL_3_CD = EXC.PROD_HIERARCHY_LVL_3_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("exceptionType", exceptionType);
		q.setParameter("exceptionProcessedInd", exceptionProcessedInd);
		q.setParameter("departmentCode", departmentCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "10000");
		q.setHint(PerishableSQLConstants.QUERY_TIMEOUT, 1000 * 60 * 180);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching records to report.");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchSalesDataExport(String companyId, String divisionId, String productSKU) {
		LOG.info("Fetching Source Details.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT ITEM_SETUP_DT, LAST_SHIP_DT, LAST_SALE_DT, TOTAL_SALES, ON_ORDER_QTY FROM ECFLAND.ITEM_CONV_SALES_SHIP_DATA WHERE COMPANY_ID = :companyId  AND DIVISION_ID= :divisionId  AND PRODUCT_SKU= :productSKU ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSKU", productSKU);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching records to export.");
		em.close();
		return results;
	}
	
	/**
	 * This method loads ROG Ranking from Database
	 */
	public List<Object[]> loadROGRanking(String companyId, String divisionId) {

		LOG.info("Fetching ROG ranking.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT RULE_VAL, CONFIG_VAL FROM ECFLAND.ITEM_CONV_MATCHING_RULE WHERE COMPANY_ID = :companyId  AND DIVISION_ID = :divisionId  ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "10");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching ROG ranking.");
		em.close();
		return results;
	}
	
	/**
	 * This method checks a Product SKU in ITEM_AGGREGATE_WHSE table before marking as dead.
	 */
	public List<Object[]> loadOnhandStatus(String companyId, String divisionId, String productSKU) {

		LOG.info("Fetching SLOT_ID and ONHAND_NBR.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT SLOT_ID, ONHAND_NBR FROM ECFLAND.ITEM_AGGREGATE_WHSE WHERE PRODUCT_SKU = :productSKU AND COMPANY_ID = :companyId  AND DIVISION_ID = :divisionId");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSKU", productSKU);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "10");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching SLOT_ID and ONHAND_NBR.");
		em.close();
		return results;
	}
	
	/**
	 * This method loads CIC details from SSIMS for a UPC.
	 */
	public List<Object[]> getCICDetails(String upcManuf, String upcSales, String upcCountry, String upcSystem) {

		LOG.info("Fetching CIC details.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT A.CORP_ITEM_CD, B.ITEM_USAGE_IND, B.ITEM_USAGE_TYPE, B.DISP_FLAG, B.GROUP_CD, B.CTGRY_CD, B.CLASS_CD, B.SUB_CLASS_CD, B.SUBSB_CLASS_CD,B.PROD_CD_GROUP,B.PROD_CD_CTGRY,B.PROD_CD_CLASS  FROM SSIMSLAND.SQLDAT3_SSITMXRF A JOIN SSIMSLAND.SQLDAT3_SSITMCDS B ON A.UPC_MANUF = :upcManuf AND A.UPC_SALES = :upcSales AND A.UPC_COUNTRY = :upcCountry  AND A.UPC_SYSTEM = :upcSystem  AND A.CORP_ITEM_CD = B.CORP_ITEM_CD ORDER BY DISP_FLAG");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("upcManuf", upcManuf);
		q.setParameter("upcSales", upcSales);
		q.setParameter("upcCountry", upcCountry);
		q.setParameter("upcSystem", upcSystem);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching CIC details.");
		em.close();
		return results;
	}
	 
	/**
	 * This method loads CIC details from SSIMS for a UPC.
	 */
	public List<Object[]> getDepartments(String companyId, String divisionId) {

		LOG.info("Fetching department records.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT PROD_HIERARCHY_LVL_5_CD, PROD_HIERARCHY_LVL_4_CD FROM ECFLAND.PRODUCT_HIERARCHY WHERE COMPANY_ID = :companyId  AND DIVISION_ID  = :divisionId");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching department records.");
		em.close();
		return results;
	}
	
	/**
	 * This method loads Category, Sub Category and Group details from PRODUCT_HIERARCHY table.
	 * @param companyId
	 * @param divisionId
	 * @param prdHierLevel1
	 * @param prdHierLevel2
	 * @param prdHierLevel3
	 * @return
	 */
	public List<Object[]> getHigherarchyDetails(String companyId, String divisionId, String prdHierLevel1, String prdHierLevel2, String prdHierLevel3) {

		LOG.info("Fetching PRODUCT_HIERARCHY records.");
		StringBuilder baseQuery = new StringBuilder("");
		List<String> prdHierLevel2List = new ArrayList<>();
		prdHierLevel2List.addAll(Arrays.asList(prdHierLevel2.split(",")));
		prdHierLevel2List.add("0");
		List<String> prdHierLevel3List = new ArrayList<>();
		prdHierLevel3List.addAll(Arrays.asList(prdHierLevel3.split(",")));
		prdHierLevel3List.add("0");
		baseQuery.append("SELECT * FROM ECFLAND.PRODUCT_HIERARCHY WHERE COMPANY_ID = :companyId   AND DIVISION_ID = :divisionId AND PROD_HIERARCHY_LVL_1_CD = :prdHierLevel1  AND PROD_HIERARCHY_LVL_2_CD IN (:prdHierLevel2) AND PROD_HIERARCHY_LVL_3_CD IN (:prdHierLevel3) ORDER BY PROD_HIERARCHY_LVL_2_CD ASC, PROD_HIERARCHY_LVL_3_CD ASC");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("prdHierLevel1", prdHierLevel1);
		q.setParameter("prdHierLevel2", prdHierLevel2List);
		q.setParameter("prdHierLevel3", prdHierLevel3List);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching PRODUCT_HIERARCHY records.");
		em.close();
		return results;
	}
	
	/**
	 * This method checks if an item is present in from ITEM_CONV_MANUAL_MAPPING table.
	 * @param companyId
	 * @param divisionId
	 * @param productSku
	 * @return
	 */
	
	public List<Object[]> isMarkedForManualMapping(String companyId, String divisionId, String productSku) {

		LOG.info("Fetching count of ITEM_CONV_MANUAL_MAPPING records.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT COUNT(*) AS COUNT FROM ECFLAND.ITEM_CONV_MANUAL_MAPPING WHERE COMPANY_ID = :companyId   AND DIVISION_ID = :divisionId   AND PRODUCT_SKU = :productSku" );
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching count of ITEM_CONV_MANUAL_MAPPING records.");
		em.close();
		return results;
	}
//NOT USED
	/**
	 * This method inserts new record into ITEM_CONV_MANUAL_MAPPING table.
	 * @param companyId
	 * @param divisionId
	 * @param productSku
	 * @param upc
	 * @param cic
	 * @param createdUserID
	 * @return
	 */
	//@Transactional
	public int insertManualMappingRecord(String companyId, String divisionId, String productSku, String upc, BigDecimal cic, String createdUserID) {

		LOG.info("Inserting ITEM_CONV_MANUAL_MAPPING record.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("INSERT INTO ECFLAND.ITEM_CONV_MANUAL_MAPPING (COMPANY_ID, DIVISION_ID, PRODUCT_SKU, UPC, CORP_ITEM_CD, CREATE_USER_ID) VALUES (:companyId,:divisionId,:productSku,:upc,:cic,:createdUserID");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		q.setParameter("upc", upc);
		q.setParameter("cic", cic);
		q.setParameter("createdUserID", createdUserID);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed fetching ITEM_CONV_MANUAL_MAPPING records.");
		em.close();
		return result;
	}//NOT USED

	public List<Object[]> fetchGroupCodeWithDesc() {
		
		LOG.info("Fetching GROUP_CD,CLSIFICATION_DESC for smic");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT GROUP_CD, CLSIFICATION_DESC FROM SSIMSLAND.SQLDAT3_MEPRDCLF WHERE CTGRY_CD = 0 AND CLASS_CD = 0 AND SUB_CLASS_CD = 0 AND SUBSB_CLASS_CD = 0 AND CLSIFICATION_DESC NOT LIKE 'DELETE%' ORDER BY GROUP_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching GROUP_CD, CLSIFICATION_DESC for smic");
		em.close();
		return results;
	}

	public List<Object[]> fetchCategoryCodeWithDesc(String groupCode) {
		LOG.info("Fetching CTGRY_CD,CLSIFICATION_DESC for smic");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT CTGRY_CD, CLSIFICATION_DESC FROM SSIMSLAND.SQLDAT3_MEPRDCLF WHERE GROUP_CD=:groupCode  AND CTGRY_CD >= 0 AND CLASS_CD = 0 AND SUB_CLASS_CD = 0 AND SUBSB_CLASS_CD = 0 AND CLSIFICATION_DESC NOT LIKE 'DELETE%' ORDER BY CTGRY_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("groupCode", groupCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching CTGRY_CD, CLSIFICATION_DESC for smic");
		em.close();
		return results;
	}

	public List<Object[]> fetchClassCodeWithDesc(String groupCode, String categoryCode) {
		LOG.info("Fetching CLASS_CD,CLSIFICATION_DESC for smic");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT CLASS_CD, CLSIFICATION_DESC FROM SSIMSLAND.SQLDAT3_MEPRDCLF WHERE GROUP_CD=:groupCode  AND CTGRY_CD=:categoryCode AND CLASS_CD >= 0 AND SUB_CLASS_CD = 0 AND SUBSB_CLASS_CD = 0 AND CLSIFICATION_DESC NOT LIKE 'DELETE%' ORDER BY CLASS_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("groupCode", groupCode);
		q.setParameter("categoryCode", categoryCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching CLASS_CD, CLSIFICATION_DESC for smic");
		em.close();
		return results;
	}

	public List<Object[]> fetchSubClassCodeWithDesc(String groupCode,String categoryCode, String classCode) {
		LOG.info("Fetching SUB_CLASS_CD,CLSIFICATION_DESC for smic");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT SUB_CLASS_CD, CLSIFICATION_DESC FROM SSIMSLAND.SQLDAT3_MEPRDCLF WHERE GROUP_CD=:groupCode AND CTGRY_CD=:categoryCode AND CLASS_CD =:classCode AND SUB_CLASS_CD >= 0 AND SUBSB_CLASS_CD = 0 AND CLSIFICATION_DESC NOT LIKE 'DELETE%' ORDER BY SUB_CLASS_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("groupCode", groupCode);
		q.setParameter("categoryCode", categoryCode);
		q.setParameter("classCode", classCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching SUB_CLASS_CD, CLSIFICATION_DESC for smic");
		em.close();
		return results;
	}

	public List<Object[]> fetchSubSubClassCodeWithDesc(String groupCode,String categoryCode, String classCode, String subClassCode) {
		LOG.info("Fetching SUBSB_CLASS_CD,CLSIFICATION_DESC for smic");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT SUBSB_CLASS_CD, CLSIFICATION_DESC FROM SSIMSLAND.SQLDAT3_MEPRDCLF WHERE GROUP_CD=:groupCode AND CTGRY_CD = :categoryCode  AND CLASS_CD = :classCode AND SUB_CLASS_CD =:subClassCode AND SUBSB_CLASS_CD >= 0 AND CLSIFICATION_DESC NOT LIKE 'DELETE%' ORDER BY SUBSB_CLASS_CD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("groupCode", groupCode);
		q.setParameter("categoryCode", categoryCode);
		q.setParameter("classCode", classCode);
		q.setParameter("subClassCode", subClassCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching SUBSB_CLASS_CD, CLSIFICATION_DESC for smic");
		em.close();
		return results;
	}
	
	
public List<Object[]> fetchProductionGroupCodeWithDesc() {
		
		LOG.info("Fetching PROD_CD_GROUP, PROD_CD_DESC for Production Code");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT PROD_CD_GROUP, PROD_CD_DESC FROM SSIMSLAND.SQLDAT3_MEPRODCD WHERE PROD_CD_CTGRY = 0 AND PROD_CD_CLASS = 0 AND PROD_CD_SUB_CLASS = 0 AND PROD_CD_SBSB_CLASS = 0 AND PROD_CD_DESC NOT LIKE 'DELETE%' ORDER BY PROD_CD_GROUP");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching PROD_CD_GROUP, PROD_CD_DESC for Production Code");
		em.close();
		return results;
		
	}

	public List<Object[]> fetchProductionCategoryCodeWithDesc(String groupCode) {
		
		LOG.info("Fetching PROD_CD_CTGRY,PROD_CD_DESC for Production Code");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT PROD_CD_CTGRY, PROD_CD_DESC FROM SSIMSLAND.SQLDAT3_MEPRODCD WHERE PROD_CD_GROUP=:groupCode  AND PROD_CD_CTGRY >= 0 AND PROD_CD_CLASS = 0 AND PROD_CD_SUB_CLASS = 0 AND PROD_CD_SBSB_CLASS = 0 AND PROD_CD_DESC NOT LIKE 'DELETE%' ORDER BY PROD_CD_CTGRY");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("groupCode", groupCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching PROD_CD_CTGRY,PROD_CD_DESC for Production Code");
		em.close();
		return results;
		
	}

	public List<Object[]> fetchProductionClassCodeWithDesc(String groupCode, String categoryCode) {
		
		LOG.info("Fetching PROD_CD_CLASS, PROD_CD_DESC for Production Code");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT PROD_CD_CLASS, PROD_CD_DESC FROM SSIMSLAND.SQLDAT3_MEPRODCD WHERE PROD_CD_GROUP=:groupCode  AND PROD_CD_CTGRY=:categoryCode AND PROD_CD_CLASS >= 0 AND PROD_CD_SUB_CLASS = 0 AND PROD_CD_SBSB_CLASS = 0 AND PROD_CD_DESC NOT LIKE 'DELETE%' ORDER BY PROD_CD_CLASS");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("groupCode", groupCode);
		q.setParameter("categoryCode", categoryCode);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching PROD_CD_CLASS, PROD_CD_DESC for Production Code");
		em.close();
		return results;
		
	}

	public List<Object[]> fetchProductionCode(String grpCd, String ctgryCd,
			String clsCd, String sbClsCd, String subSbClass) {
		
		LOG.info("Fetching for Production Code");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT PROD_CD_GROUP,PROD_CD_CTGRY,PROD_CD_CLASS, PROD_CD_DESC FROM SSIMSLAND.SQLDAT3_MEPRODCD WHERE PROD_CD_GROUP=:grpCd AND PROD_CD_CTGRY=:ctgryCd  AND PROD_CD_CLASS =:clsCd AND PROD_CD_SUB_CLASS = :sbClsCd  AND PROD_CD_SBSB_CLASS = :subSbClass AND PROD_CD_DESC NOT LIKE 'DELETE%'");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("grpCd", grpCd);
		q.setParameter("ctgryCd", ctgryCd);
		q.setParameter("clsCd", clsCd);
		q.setParameter("sbClsCd", sbClsCd);
		q.setParameter("subSbClass", subSbClass);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching Production Code");
		em.close();
		return results;
		
	}

	public List<String> fetchRecordBasedOnCompanyIdDivisionIdProductSku(String companyId, String divisionId, Set<String> productSkuSet) {
		LOG.info("Fetching record from ITEM_CONV_NEW_CIC_DATA_MGMT");
		List<String> productSkus=new ArrayList<>(productSkuSet);
		List<List<String>> productSkusPartition = ListUtils.partition(productSkus, 998);
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.PRODUCT_SKU FROM ECFLAND.ITEM_CONV_NEW_CIC_DATA_MGMT P ")
		.append(" WHERE P.COMPANY_ID =").append(":companyId")
		.append(" AND P.DIVISION_ID =").append(":divisionId")	
		.append(" AND P.AUG_OVERRIDE_COMPLETION_IND != 'N'");
		baseQuery.append(" AND ( P.PRODUCT_SKU IN (:sku0)");
		for(int i= 1;i < productSkusPartition.size(); i++)
		{
			baseQuery.append("OR P.PRODUCT_SKU IN (:sku" + i + ")");
		}
		baseQuery.append(")");				
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		for(int i= 0;i < productSkusPartition.size(); i++)
		{
			q.setParameter("sku"+i, productSkusPartition.get(i));
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<String> results = q.getResultList();
		LOG.info("Completed Fetching record from ITEM_CONV_NEW_CIC_DATA_MGMT");
		em.close();
		return results;
	
	}
	
	/**PROD CLASS EXISTENCE CHECK 
	 * 
	 * by NFRAN**/
	public List<String> getTargetProdClass(String prodClass) {
		LOG.info("Fetching  PROD CLASS");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT  SUBSTRING(cast(PROD_CLASS as varchar),1,4) from SSIMSLAND.SQLDAT3_SSITMPCD where prod_Class like ");
		baseQuery.append(":prodClass");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("prodClass", StringUtils.stripStart(prodClass,"0") + "%");
		List<String> results = q.getResultList();
		LOG.info("FETCHING TARGET PROD CLASS");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchRecordBasedOnCompanyIdDivisionIdProductSkuSet(
			Set<String> productSkuSet, String companyId, String divisionId) {
		LOG.info("Fetching record from SRC_ITEM_XRF");
		List<String> productSkus=new ArrayList<>(productSkuSet);
		List<List<String>> productSkusPartition = ListUtils.partition(productSkus, 998);
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.SRC_PRODUCT_SKU, P.CONV_STATUS_CD, P.CONV_STATUS_SUB_CD, P.SRC_UPC_COUNTRY,P.SRC_UPC_SYSTEM,P.SRC_UPC_MANUF,P.SRC_UPC_SALES, P.SRC_SUPPLIER_NUM, P.ROG FROM XREFLAND.SRC_ITEM_XRF P ")
		.append(" WHERE P.COMPANY_ID =").append(":companyId")
		.append(" AND P.DIVISION_ID =").append(":divisionId");
		baseQuery.append(" AND ( P.SRC_PRODUCT_SKU IN (:sku0)");
		for(int i= 1;i < productSkusPartition.size(); i++)
		{
			baseQuery.append("OR P.SRC_PRODUCT_SKU IN (:sku" + i + ")");
		}
		baseQuery.append(")");				
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		for(int i= 0;i < productSkusPartition.size(); i++)
		{
			q.setParameter("sku"+i, productSkusPartition.get(i));
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching record from SRC_ITEM_XRF");
		em.close();
		return results;
	
	}

	public List<Object[]> fetchRecordBasedOnCompanyIdDivisionIdProductSkuSetFromUiExceptionSource(
			String companyId, String divisionId, Set<String> productSkuSet) {
		LOG.info("Fetching record from SRC_ITEM_XRF");
		List<String> productSkus=new ArrayList<>(productSkuSet);
		List<List<String>> productSkusPartition = ListUtils.partition(productSkus, 998);
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, CONCAT(right(replicate('0',1) + cast(P.UPC_COUNTRY as varchar),1)  , '-' , right(replicate('0',1) + cast(P.UPC_SYSTEM as varchar),1)  , '-' , right(replicate('0',5) + cast(P.UPC_MANUF as varchar),5)  , '-' , right(replicate('0',5) + cast(P.UPC_SALES as varchar),5) ) as UPC, P.PLU_CD, P.PRIMARY_UPC_IND, P.WHSE_ITEM_DESC, P.RTL_ITEM_DESC, P.INTERNET_ITEM_DESC, P.POS_DESC, P.ITEM_USAGE_IND, P.ITEM_USAGE_TYPE_IND, P.PRIVATE_LABEL_IND, P.PROD_HIERARCHY_LVL_1_CD, P.PROD_HIERARCHY_LVL_2_CD, P.PROD_HIERARCHY_LVL_3_CD, P.PROD_HIERARCHY_LVL_4_CD,P.PROD_HIERARCHY_LVL_5_CD, P.BATCH_ID,P.SIZE_NBR,P.SIZE_UOM FROM ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC P")
		.append(" WHERE P.COMPANY_ID =").append(":companyId")
		.append(" AND P.DIVISION_ID =").append(":divisionId  AND P.EXCEPTION_PROCESSED_IND IN('N','R') AND P.EXCEPTION_TYPE_CD='A'");
		baseQuery.append(" AND ( P.PRODUCT_SKU IN (:sku0)");
		for(int i= 1;i < productSkusPartition.size(); i++)
		{
			baseQuery.append("OR P.PRODUCT_SKU IN (:sku" + i + ")");
		}
		baseQuery.append(")");					
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		for(int i= 0;i < productSkusPartition.size(); i++)
		{
			q.setParameter("sku"+i, productSkusPartition.get(i));
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching record from SRC_ITEM_XRF");
		em.close();
		return results;
	}

	public void updateXrefAndUiException(List<NewItemDetail> newItemList)  {
		LOG.info("Started Updating SRC_ITEM_XRF and ITEM_CONV_UI_EXCEPTION_SRC records.");
		String convStatusDesc = "Ready for Auto Conversion";
	
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		for (NewItemDetail newItem : newItemList) {
			String xrefQuery = "UPDATE XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD='R', CONV_STATUS_SUB_CD='A', CONV_STATUS_DSC= :convStatusDesc ,STATUS_REASON_TXT="
					+ ":statusReasonTxt,CREATE_UPDATE_USER_ID=:createUser ,CREATE_UPDATE_TS=SYSDATETIMEOFFSET() WHERE COMPANY_ID = :companyId  AND DIVISION_ID = "
					+ ":divisionId AND SRC_PRODUCT_SKU = :productSku AND SRC_UPC_COUNTRY = :upcCountry AND SRC_UPC_SYSTEM = :upcSystem AND SRC_UPC_MANUF = :upcManuf AND SRC_UPC_SALES = :upcSales AND CONV_STATUS_CD='E' AND CONV_STATUS_SUB_CD='A' ";
			
			String uiExcSrcQuery = "UPDATE ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC SET EXCEPTION_PROCESSED_IND='C',CREATE_UPDATE_TS=SYSDATETIMEOFFSET(), CREATE_UPDATE_USER_ID= :createUser"
					+ " WHERE COMPANY_ID = :companyId AND DIVISION_ID = :divisionId AND PRODUCT_SKU = :productSku AND UPC_COUNTRY = :upcCountry AND UPC_SYSTEM = :upcSystem AND UPC_MANUF = :upcManuf AND UPC_SALES = :upcSales";
		
			
			Query xref = em.createNativeQuery(xrefQuery);

			xref.setParameter("convStatusDesc", convStatusDesc);
			xref.setParameter("statusReasonTxt", convStatusDesc);
			xref.setParameter("createUser", newItem.getCreateUser());
			xref.setParameter("companyId", newItem.getNewItemPk().getCompanyId());
			xref.setParameter("divisionId", newItem.getNewItemPk().getDivisionId());
			xref.setParameter("productSku", newItem.getNewItemPk().getProductSKU());
			xref.setParameter("upcCountry", newItem.getNewItemPk().getUpcCountry());
			xref.setParameter("upcSystem", newItem.getNewItemPk().getUpcSystem());
			xref.setParameter("upcManuf", newItem.getNewItemPk().getUpcManufacturer());
			xref.setParameter("upcSales", newItem.getNewItemPk().getUpcSales());
			xref.executeUpdate();
			Query uiSrc = em.createNativeQuery(uiExcSrcQuery);
			uiSrc.setParameter("createUser", newItem.getCreateUser());
			uiSrc.setParameter("companyId", newItem.getNewItemPk().getCompanyId());
			uiSrc.setParameter("divisionId", newItem.getNewItemPk().getDivisionId());
			uiSrc.setParameter("productSku", newItem.getNewItemPk().getProductSKU());
			uiSrc.setParameter("upcCountry", newItem.getNewItemPk().getUpcCountry());
			uiSrc.setParameter("upcSystem", newItem.getNewItemPk().getUpcSystem());
			uiSrc.setParameter("upcManuf", newItem.getNewItemPk().getUpcManufacturer());
			uiSrc.setParameter("upcSales", newItem.getNewItemPk().getUpcSales());
			uiSrc.executeUpdate();
		}
		et.commit();		
		em.close();
	
		LOG.info("Completed Updating SRC_ITEM_XRF  and  ITEM_CONV_UI_EXCEPTION_SRC records.");
	}
	
	public void markExcelItemAsDead(List<ItemXrefData> itemXrefList) {
		LOG.info("Started marking item as dead");
		String convStatusDesc = "Dead Item - Business assigned status.";
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		for (ItemXrefData xrefItem : itemXrefList) {
			String xrefQuery = "UPDATE XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD='D', CONV_STATUS_SUB_CD='B', CONV_STATUS_DSC=:convStatusDesc ,STATUS_REASON_TXT="
					+ ":statusReasonTxt ,CREATE_UPDATE_USER_ID=:createUser,CREATE_UPDATE_TS=SYSDATETIMEOFFSET() WHERE COMPANY_ID = :companyId  AND DIVISION_ID = '"
			        + ":divisionId AND SRC_PRODUCT_SKU = :productSku AND SRC_UPC_COUNTRY = :upcCountry AND SRC_UPC_SYSTEM = :upcSystem AND SRC_UPC_MANUF = :upcManuf AND SRC_UPC_SALES = :upcSales AND CONV_STATUS_CD='E' AND CONV_STATUS_SUB_CD='A' ";
			String uiExcSrcQuery = "UPDATE ECFLAND.ITEM_CONV_UI_EXCEPTION_SRC SET EXCEPTION_PROCESSED_IND='C',CREATE_UPDATE_TS=SYSDATETIMEOFFSET(), CREATE_UPDATE_USER_ID=:createUser"
         			+ " WHERE COMPANY_ID = :companyId AND DIVISION_ID = :divisionId AND PRODUCT_SKU = :productSku AND UPC_COUNTRY = :upcCountry AND UPC_SYSTEM = :upcSystem AND UPC_MANUF = :upcManuf AND UPC_SALES = :upcSales";
			String newItemQuery = "DELETE FROM ECFLAND.ITEM_CONV_NEW_CIC_DATA_MGMT WHERE COMPANY_ID = :companyId AND DIVISION_ID = :divisionId AND PRODUCT_SKU = :prodSku AND UPC_COUNTRY = :upcCountry AND UPC_SYSTEM = :upcSystem  AND UPC_MANUF = :upcManu AND UPC_SALES = :upcSales";
			
			Query xref = em.createNativeQuery(xrefQuery);
			xref.setParameter("convStatusDesc", convStatusDesc);
			xref.setParameter("statusReasonTxt", xrefItem.getStatusReasonText());
			xref.setParameter("createUser", xrefItem.getUpdatedUserId());
			xref.setParameter("companyId", xrefItem.getItemPk().getCompanyId());
			xref.setParameter("divisionId", xrefItem.getItemPk().getDivisionId());
			xref.setParameter("prodSku", xrefItem.getItemPk().getProdSku());
			xref.setParameter("upcCountry", xrefItem.getItemPk().getUpcCountry());
			xref.setParameter("upcSystem", xrefItem.getItemPk().getUpcSystem());
			xref.setParameter("upcManu", xrefItem.getItemPk().getUpcManu());
			xref.setParameter("upcSales", xrefItem.getItemPk().getUpcSales());
			xref.executeUpdate();
			Query uiSrc = em.createNativeQuery(uiExcSrcQuery);
			uiSrc.setParameter("createUser", xrefItem.getUpdatedUserId());
			uiSrc.setParameter("companyId", xrefItem.getItemPk().getCompanyId());
			uiSrc.setParameter("divisionId", xrefItem.getItemPk().getDivisionId());
			uiSrc.setParameter("prodSku", xrefItem.getItemPk().getProdSku());
			uiSrc.setParameter("upcCountry", xrefItem.getItemPk().getUpcCountry());
			uiSrc.setParameter("upcSystem", xrefItem.getItemPk().getUpcSystem());
			uiSrc.setParameter("upcManu", xrefItem.getItemPk().getUpcManu());
			uiSrc.setParameter("upcSales", xrefItem.getItemPk().getUpcSales());
			uiSrc.executeUpdate();
			Query newItem = em.createNativeQuery(newItemQuery);
			newItem.setParameter("companyId", xrefItem.getItemPk().getCompanyId());
			newItem.setParameter("divisionId", xrefItem.getItemPk().getDivisionId());
			newItem.setParameter("prodSku", xrefItem.getItemPk().getProdSku());
			newItem.setParameter("upcCountry", xrefItem.getItemPk().getUpcCountry());
			newItem.setParameter("upcSystem", xrefItem.getItemPk().getUpcSystem());
			newItem.setParameter("upcManu", xrefItem.getItemPk().getUpcManu());
			newItem.setParameter("upcSales", xrefItem.getItemPk().getUpcSales());
			newItem.executeUpdate();
		}
		
		et.commit();		
		em.close();
		LOG.info("Completed marking item as dead");
	}
	
	public List<String> fetchUomCode() {
		LOG.info("Fetching UOMCODE from SQLDAT3_COUOMCDS");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT UOM_CODE FROM SSIMSLAND.SQLDAT3_COUOMCDS");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<String> results = q.getResultList();
		LOG.info("Completed UOMCODE from SQLDAT3_COUOMCDS");
		em.close();
		return results;
	}
	
	public List<String> fetchSmicCode() {
		LOG.info("Fetching SMIC CODE from SQLDAT3_MEPRDCLF");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT concat(right(replicate('0',2) + cast(GROUP_CD as varchar),2) ,'-',right(replicate('0',2) + cast(CTGRY_CD as varchar),2) ,'-',  right(replicate('0',2) + cast(CLASS_CD as varchar),2) ,'-',right(replicate('0',2) + cast(SUB_CLASS_CD as varchar),2) ,'-', right(replicate('0',2) + cast(SUBSB_CLASS_CD as varchar),2) ) AS SMIC  from SSIMSLAND.SQLDAT3_MEPRDCLF");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "10000");
		List<String> results = q.getResultList();
		LOG.info("Completed SMIC CODE from SQLDAT3_MEPRDCLF");
		em.close();
		return results;
	}
	
	public List<Object[]> fetchProductionCode() {
		LOG.info("Fetching Production Code from SQLDAT3_MEPRODCD");
		StringBuilder baseQuery=new StringBuilder("");
		baseQuery.append("SELECT DISTINCT right(replicate('0',2) + cast(PROD_CD_GROUP as varchar),2) as col1, right(replicate('0',2) + cast(PROD_CD_CTGRY as varchar),2)  as col2, right(replicate('0',2) + cast(PROD_CD_CLASS as varchar),2)  as col3 FROM SSIMSLAND.SQLDAT3_MEPRODCD");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "200");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching  Production Code from SQLDAT3_MEPRODCD");
		em.close();
		return results;
	}
	
	public List<String> fetchProductClassCode() {
		LOG.info("Fetching PROD_CLASS from SQLDAT3_SSITMPCD");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT SUBSTRING(cast(PROD_CLASS as varchar),1,4) FROM SSIMSLAND.SQLDAT3_SSITMPCD WHERE PROD_GROUP='84'");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		List<String> results = q.getResultList();
		LOG.info("Completed PROD_CLASS from SQLDAT3_SSITMPCD");
		em.close();
		return results;
	}
	
	public List<Object[]> getProduceRelatedData(String company, String division,
			String productsku) {
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("select top 1* from ( select distinct selling_method_cd, ");
		baseQuery.append(" case when whse.receive_random_ind is not null then whse.receive_random_ind ");
		baseQuery.append(" when dsd.receive_random_ind is not null then dsd.receive_random_ind end \"RANDOM_IND\" ");
		baseQuery.append(" from ecfland.item_aggregate_rog rog ");
		baseQuery.append("  LEFT JOIN ecfland.item_aggregate_whse whse on ");
		baseQuery.append(" rog.company_id =whse.company_id and rog.division_id =whse.division_id ");
		baseQuery.append(" and rog.product_sku =whse.product_Sku ");
		baseQuery.append(" LEFT JOIN ecfland.item_aggregate_dsd dsd on ");
		baseQuery.append("rog.company_id =dsd.company_id and rog.division_id =dsd.division_id");
		baseQuery.append(" and  rog.product_sku =dsd.product_Sku");
		baseQuery.append(" where rog.company_id = :company ");
		baseQuery.append( "and rog.division_id =:division ");
		baseQuery.append(" and rog.product_Sku=	:product_Sku ");
		baseQuery.append(" ) INNER_TABLE ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		System.out.println(baseQuery.toString());
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("product_Sku", productsku);	
		
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1");
		List<Object[]> results = q.getResultList();
		em.close();
		return results;
	}
	
	public List<Object[]> getSourceAndEditedUpcDataMgmt(String company, String division,
			String productsku,String proSrcCd)
	{
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("select concat(upc_country ,  upc_system ,  right(replicate('0',5) + cast(upc_manuf as varchar),5) ,  right(replicate('0',5) + cast(upc_sales as varchar),5) ),upd_upc,upd_plu_cd "
				+ "from  ecfland.item_conv_new_cic_data_mgmt ");
		baseQuery.append(" where company_id = :company ");
		baseQuery.append( "and division_id =:division ");
		baseQuery.append(" and product_Sku=	:product_Sku ");
		baseQuery.append(" and prod_Src_Cd=	:proSrcCd ");
	
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("product_Sku", productsku);	
		q.setParameter("proSrcCd", proSrcCd);	
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1");
		List<Object[]> results = q.getResultList();
		em.close();
		return results;
	}
	
	public List<Object[]> getAddtnlFieldsDataForUI(String division,
			String company, String productsku) {

		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("select  ");
		baseQuery.append("W.PRODUCTION_WEIGHT_NBR,W.RECEIVE_RANDOM_IND,");
		baseQuery.append("C.LABEL_SIZE_SRC_CD,R.TAG_SIZE_TXT,");
		baseQuery.append("C.LABEL_NUMBERS_SRC_CD,r.tag_count_nbr,");
		baseQuery.append("R.sign_Type_Cd,R.sign_count_nbr,");
		baseQuery.append("C.FD_STMP_SRC_CD,R.food_stamp_ind, ");
		baseQuery.append("C.RING_SRC_CD, ");
		baseQuery.append("C.HICONE_SRC_CD,R.QUANTITY_REQUIRED_IND, ");
		baseQuery.append("W.VENDOR_LIST_COST_NBR ");
		
		baseQuery.append("from ECFLAND.ITEM_AGGREGATE_CORP D ");
		baseQuery.append("JOIN ECFLAND.ITEM_CONV_DATA_SRC_CONFIG C ");
		baseQuery.append("ON D.company_id =C.company_id ");
		baseQuery.append("AND D.division_id =C.division_id ");
		baseQuery.append("AND C.item_set_id  in(3) ");
		baseQuery.append("LEFT JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ");
		baseQuery.append("ON D.company_id =W.company_id AND D.division_id =W.division_id AND D.product_sku =W.product_sku ");
		baseQuery.append("LEFT JOIN ECFLAND.ITEM_AGGREGATE_ROG R ");
		baseQuery.append(" ON D.company_id =R.company_id AND D.division_id =R.division_id AND D.product_sku =R.product_sku ");
		baseQuery.append("where D.company_id =:company AND D.division_id =:division AND D.product_sku =:product_Sku");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("product_Sku", productsku);	
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1");
		List<Object[]> results = q.getResultList();
		em.close();
		return results;
	}
	
}