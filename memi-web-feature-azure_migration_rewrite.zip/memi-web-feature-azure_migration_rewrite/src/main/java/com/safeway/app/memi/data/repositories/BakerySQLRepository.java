package com.safeway.app.memi.data.repositories;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;

/**
 ****************************************************************************
 * NAME			: BakerySQLRepository 
 * 
 * DESCRIPTION	: BakerySQLRepository is the repository class for performing 
 * 				  bakery DB operations
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U47849
 * 
 * 
 * 
 * *************************************************************************
 */

/**
 * Repository class for bakery DB operations
 */

@Repository
@SuppressWarnings("unchecked")
public class BakerySQLRepository {

	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;
	private static final String LIKE_START_BRACKET="('%";
	private static final String LIKE_END_BRACKET="%')";
	private static final String whse_dsd ="WHSE_DSD";
	private static final Logger LOG = LoggerFactory.getLogger(BakerySQLRepository.class);
	@Value("${spring.datasource.hikari.schema}")
	private String defaultSchema;
	/**
	 * Method to fetch source item list
	 * @param searchCriteria
	 * @param filterCriteria
	 * @return
	 */
	public List<Object[]> fetchBakerySourceList(Map<String, String> searchCriteria,
			Map<String, String> filterCriteria) {
		
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder baseQuery = new StringBuilder("");
		List<Object[]> newresults = null;
		Integer companyId = Integer.valueOf(0);
    	Integer divisionId =Integer.valueOf(0);
		if (searchCriteria != null && searchCriteria.size() > 0) {
			if (searchCriteria.containsKey(PerishableSQLConstants.COMPANY_ID)) {
				companyId = Integer.valueOf(searchCriteria.get(PerishableSQLConstants.COMPANY_ID));
			}
			if (searchCriteria.containsKey(PerishableSQLConstants.DIVISION_ID_SMALL_CASE)) {
				divisionId =Integer.valueOf(searchCriteria.get(PerishableSQLConstants.DIVISION_ID_SMALL_CASE));
			}
		}

		baseQuery.append("SELECT PRODUCT_SKU, ITEM_DESC, SIZE_DESC, NULL, MULTI_COMP_ITEM_IND	, WHSE_DSD, PROD_HIERARCHY_LVL_4_CD	, LAST_UPD_USR_ID" + 
				"	, VCF, MATCHING_STATUS_CD, SIZE_NBR, ITEM_SETUP_DT, SHIPPING_PACK_NBR, USAGE1, PROD_HIERARCHY_LVL_1_NM, PROD_HIERARCHY_LVL_2_NM" + 
				"	, PROD_HIERARCHY_LVL_3_NM, LAST_SHIP_DT, ON_HAND, ON_ORDER_QTY, SLOT, 'SELLING_METHOD_CD' as SELLING_METHOD_CD, 'RECIEVE_METHOD_CD' "+
				"  as RECIEVE_METHOD_CD, "+
				"  VENDOR_ID, VENDOR_NM FROM (");

		baseQuery.append("SELECT DISTINCT c.product_sku, c.item_desc , c.size_desc, NULL as 'DUMMY', C.MULTI_COMP_ITEM_IND, CASE WHEN C.SOURCE_BY_WHSE = 'Y' THEN 'WHSE'" + 
				" WHEN C.SOURCE_BY_DSD = 'Y' THEN 'DSD'	END WHSE_DSD, C.PROD_HIERARCHY_LVL_4_CD, C.LAST_UPD_USR_ID, (C.MASTER_CASE_PACK_NBR / NULLIF(C.SHIPPING_PACK_NBR, 0)) AS VCF" + 
				", CASE WHEN X.CONV_STATUS_CD = 'D' THEN 'MARK_AS_DEAD'ELSE P.MATCHING_STATUS_CD END MATCHING_STATUS_CD, C.SIZE_NBR, C.ITEM_SETUP_DT, C.SHIPPING_PACK_NBR, CASE" + 
				" WHEN C.EXPENSE_ITEM_IND = 'N' AND C.MATERIAL_ITEM_IND = 'N' AND (C.STORE_CREATED_ITEM_IND = 'N' OR C.COUPON_IND = 'N')  THEN 'R' WHEN C.EXPENSE_ITEM_IND = 'Y'" + 
				" THEN 'E' WHEN C.MATERIAL_ITEM_IND = 'Y' THEN 'M' END USAGE1, PH1.HIERARCHY_LEVEL_DESC PROD_HIERARCHY_LVL_1_NM, PH2.HIERARCHY_LEVEL_DESC PROD_HIERARCHY_LVL_2_NM" + 
				",PH3.HIERARCHY_LEVEL_DESC PROD_HIERARCHY_LVL_3_NM, SD.LAST_SHIP_DT, SD.ON_HAND, SD.ON_ORDER_QTY, SD.SLOT, CASE WHEN C.SOURCE_BY_WHSE = 'Y' THEN WVX.VENDOR_ID" + 
				" WHEN C.SOURCE_BY_DSD = 'Y' THEN DVX.VENDOR_ID collate Latin1_General_CS_AS END VENDOR_ID, CASE  WHEN C.SOURCE_BY_WHSE = 'Y' THEN WVX.VENDOR_NM WHEN C.SOURCE_BY_DSD = 'Y' " + 
				"THEN DVX.VENDOR_NM END VENDOR_NM FROM ECFLAND.ITEM_AGGREGATE_CORP C JOIN XREFLAND.SRC_ITEM_XRF X ON C.COMPANY_ID = X.COMPANY_ID AND C.DIVISION_ID = X.DIVISION_ID " + 
				" AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND C.UPC = X.SRC_UPC AND X.CONV_STATUS_CD NOT IN ('O','C') LEFT JOIN ( SELECT COMPANY_ID, DIVISION_ID, PROD_HIERARCHY_LVL_1_CD" + 
				" , PROD_HIERARCHY_LVL_2_CD, PROD_HIERARCHY_LVL_3_CD, HIERARCHY_LEVEL_DESC FROM ECFLAND.PRODUCT_HIERARCHY WHERE CAST(COMPANY_ID AS NUMERIC(38, 10)) =  :companyId" + 
				" AND CAST(DIVISION_ID AS NUMERIC(38, 10)) = :divisionId AND HIERARCHY_LEVEL_NM = 'CATGRY_NUM' GROUP BY COMPANY_ID,DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD" + 
				" ,PROD_HIERARCHY_LVL_3_CD,HIERARCHY_LEVEL_DESC) PH1 ON C.COMPANY_ID = PH1.COMPANY_ID AND C.DIVISION_ID = PH1.DIVISION_ID AND C.PROD_HIERARCHY_LVL_1_CD = PH1.PROD_HIERARCHY_LVL_1_CD" + 
				" AND PH1.PROD_HIERARCHY_LVL_2_CD = '000' AND PH1.PROD_HIERARCHY_LVL_3_CD = '000'  LEFT JOIN (SELECT COMPANY_ID, DIVISION_ID, PROD_HIERARCHY_LVL_1_CD, PROD_HIERARCHY_LVL_2_CD" + 
				" , PROD_HIERARCHY_LVL_3_CD, HIERARCHY_LEVEL_DESC FROM ECFLAND.PRODUCT_HIERARCHY WHERE CAST(COMPANY_ID AS NUMERIC(38, 10)) = :companyId  AND CAST(DIVISION_ID AS NUMERIC(38, 10)) = :divisionId" + 
				" AND HIERARCHY_LEVEL_NM = 'SUB_CATGRY_NUM'  GROUP BY COMPANY_ID,DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD,PROD_HIERARCHY_LVL_3_CD,HIERARCHY_LEVEL_DESC " + 
				" ) PH2 ON C.COMPANY_ID = PH2.COMPANY_ID AND C.DIVISION_ID = PH2.DIVISION_ID AND C.PROD_HIERARCHY_LVL_1_CD = PH2.PROD_HIERARCHY_LVL_1_CD AND C.PROD_HIERARCHY_LVL_2_CD = PH2.PROD_HIERARCHY_LVL_2_CD " + 
				" AND PH2.PROD_HIERARCHY_LVL_3_CD = '000' LEFT JOIN (SELECT COMPANY_ID, DIVISION_ID, PROD_HIERARCHY_LVL_1_CD, PROD_HIERARCHY_LVL_2_CD, PROD_HIERARCHY_LVL_3_CD" + 
				" , HIERARCHY_LEVEL_DESC FROM ECFLAND.PRODUCT_HIERARCHY  WHERE CAST(COMPANY_ID AS NUMERIC(38, 10)) = :companyId  AND CAST(DIVISION_ID AS NUMERIC(38, 10)) = :divisionId" + 
				" AND HIERARCHY_LEVEL_NM = 'GRP_ID' GROUP BY COMPANY_ID,DIVISION_ID,PROD_HIERARCHY_LVL_1_CD,PROD_HIERARCHY_LVL_2_CD,PROD_HIERARCHY_LVL_3_CD,HIERARCHY_LEVEL_DESC " + 
				" ) PH3 ON C.COMPANY_ID = PH3.COMPANY_ID AND C.DIVISION_ID = PH3.DIVISION_ID AND C.PROD_HIERARCHY_LVL_1_CD = PH3.PROD_HIERARCHY_LVL_1_CD AND C.PROD_HIERARCHY_LVL_2_CD = PH3.PROD_HIERARCHY_LVL_2_CD" + 
				" AND C.PROD_HIERARCHY_LVL_3_CD = PH3.PROD_HIERARCHY_LVL_3_CD LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD ON C.COMPANY_ID = SD.COMPANY_ID  AND C.DIVISION_ID = SD.DIVISION_ID" + 
				" AND C.PRODUCT_SKU = SD.PRODUCT_SKU AND C.UPC = SD.UPC LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON C.COMPANY_ID = MU.COMPANY_ID AND C.DIVISION_ID = MU.DIVISION_ID" + 
				" AND C.PRODUCT_SKU = MU.PRODUCT_SKU AND C.UPC = MU.SRC_UPC LEFT JOIN XREFLAND.DSD_VENDOR_XREF DVX ON X.COMPANY_ID = DVX.COMPANY_ID AND X.DIVISION_ID = DVX.DIVISION_ID " + 
				" AND X.SRC_SUPPLIER_NUM collate Latin1_General_CS_AS = DVX.VENDOR_ID LEFT JOIN XREFLAND.WHSE_VENDOR_XREF WVX ON X.COMPANY_ID = WVX.COMPANY_ID" + 
				" AND X.DIVISION_ID = WVX.DIVISION_ID  AND X.SRC_SUPPLIER_NUM = WVX.VENDOR_ID LEFT OUTER JOIN ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN P ON C.COMPANY_ID = P.COMPANY_ID " + 
				" AND C.DIVISION_ID = P.DIVISION_ID AND C.UPC = P.UPC AND C.PRODUCT_SKU = P.PRODUCT_SKU  WHERE C.PROD_HIERARCHY_LVL_4_CD = 'BAKERY' AND C.MULTI_COMP_ITEM_IND <> 'Y' " + 
				" AND (MU.PRODUCT_SKU IS NULL OR ( MU.PRODUCT_SKU IS NOT NULL AND MU.AUTO_MANUAL_IND = 'N')) ");
		
		
		
		baseParams.put("companyId", companyId);
		baseParams.put("divisionId", divisionId);
		
		StringBuilder searchcriteria = createBaseSearchQuery(searchCriteria,baseParams);
		StringBuilder filtercriteria = createfilterQuery(filterCriteria,baseParams);

		String baseQueryWrapper = " GROUP BY PRODUCT_SKU,ITEM_DESC,SIZE_DESC,MULTI_COMP_ITEM_IND,WHSE_DSD,PROD_HIERARCHY_LVL_4_CD,LAST_UPD_USR_ID,VCF,MATCHING_STATUS_CD" + 
				"	,SIZE_NBR,ITEM_SETUP_DT,SHIPPING_PACK_NBR,USAGE1,PROD_HIERARCHY_LVL_1_NM,PROD_HIERARCHY_LVL_2_NM,PROD_HIERARCHY_LVL_3_NM,LAST_SHIP_DT" + 
				"	,ON_HAND,ON_ORDER_QTY,SLOT,VENDOR_ID,VENDOR_NM ORDER BY WHSE_DSD,PRODUCT_SKU";

		baseQuery.append(searchcriteria.append(filtercriteria).append(") as tmp"));
	

		baseQuery.append(baseQueryWrapper);

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "50");
		q.setMaxResults(50);
		List<Object[]> results = q.getResultList();
		em.close();
		if (null != searchCriteria) {
			newresults = getUpcAggregateList(results, searchCriteria.get(PerishableSQLConstants.COMPANY_ID),
					searchCriteria.get(PerishableSQLConstants.DIVISION_ID_SMALL_CASE),
					searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS),
					searchCriteria.get(PerishableSQLConstants.ITEM_TYPE));
		}
		
		return newresults;

	}

	/**
	 * @param searchCriteria
	 * @param baseQuery
	 */
	// never used so 
	
	private void appendWhseDsdInBaseQuery(Map<String, String> searchCriteria, StringBuilder baseQuery) {
		if (searchCriteria != null && searchCriteria.size() > 0
				&& searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE)
				&& searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE) != null
				&& !searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("")
				&& searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals(whse_dsd)) {
			baseQuery.append(" WHERE ");
			baseQuery.append(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE));
			baseQuery.append(PerishableSQLConstants.LIKE_UPPER);
			if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {/* dropdown list */
				baseQuery.append(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
				baseQuery.append(LIKE_END_BRACKET);
			}
		}
	}

	/**
	 * 
	 * @param filterCriteria
	 * @return
	 */
	private StringBuilder createfilterQuery(Map<String, String> filterCriteria,Map<String, Object> baseParams) {

		StringBuilder queryFilter = new StringBuilder("");
		if (null != filterCriteria.keySet() && !filterCriteria.keySet().isEmpty()) {
			if (filterCriteria.containsKey(PerishableSQLConstants.DEPARTMENT)) {
				queryFilter.append("AND C.PROD_HIERARCHY_LVL_4_CD = :cprodhierarchylvl4cd ");
				baseParams.put("cprodhierarchylvl4cd", filterCriteria.get(PerishableSQLConstants.DEPARTMENT));
			}
			if (filterCriteria.containsKey("divisionNum")) {
				queryFilter.append(" AND C.DIVISION_ID= :divisionNum");
				baseParams.put("divisionNum", filterCriteria.get("divisionNum"));
			}
			if (filterCriteria.containsKey(PerishableSQLConstants.ITEM_DESCRIPTION)) {
				String itemDesc = filterCriteria.get(PerishableSQLConstants.ITEM_DESCRIPTION).replaceAll("'", "''");
				queryFilter.append(" AND C.ITEM_DESC  LIKE UPPER(");
				queryFilter.append(" :citemdesc");
				queryFilter.append(")");
				baseParams.put("citemdesc", "%"+itemDesc+"%");
			}
			if (filterCriteria.containsKey("productSKU")) {
				queryFilter.append(" AND C.PRODUCT_SKU= :cproductsku");
				baseParams.put("cproductsku", filterCriteria.get("productSKU") );
			}
			if (filterCriteria.containsKey(PerishableSQLConstants.PLU)) {
				queryFilter.append(" AND  X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND  X.SRC_UPC_SALES  = :xrcupcsales");
				baseParams.put("xrcupcsales", filterCriteria.get(PerishableSQLConstants.PLU) );
			}
			if (filterCriteria.containsKey("supplierName")) {
				//queryFilter.append(" AND upper(SD.SRC_SUPPLIER_NM)= '"+filterCriteria.get("supplierName")+"'");
				queryFilter.append("  AND ( trim( upper(WVX.VENDOR_NM)) =  :wvxvendornm");
				queryFilter.append(" OR trim( upper(DVX.VENDOR_NM)) = :dvxvendornm");
				baseParams.put("wvxvendornm", filterCriteria.get("supplierName") );
				baseParams.put("dvxvendornm", filterCriteria.get("supplierName") );
			}
			if (filterCriteria.containsKey("supplierNum")) {
				//queryFilter.append(" AND upper(X.SRC_SUPPLIER_NUM)= '"+filterCriteria.get("supplierNum")+ "'");
				queryFilter.append("  AND ( upper(WVX.VENDOR_ID) =  :wvxvendorid");
				queryFilter.append(" OR  upper(DVX.VENDOR_ID) = :dvxvendorid");
				baseParams.put("wvxvendorid", filterCriteria.get("supplierNum") );
				baseParams.put("dvxvendorid", filterCriteria.get("supplierNum") );
				 
			}
			buildCriteriaForSLUAndUPC(filterCriteria, queryFilter,baseParams);
			buildCriteriaForHierarchy(filterCriteria, queryFilter,baseParams);			

		}
		return queryFilter;
	}
	
	/**
	 * 
	 * @param filterCriteria
	 * @param queryFilter
	 */
	private void buildCriteriaForHierarchy(Map<String, String> filterCriteria,StringBuilder queryFilter,Map<String, Object> baseParams) {
		if (filterCriteria.containsKey("prodhierarchyLevel1")) {
			queryFilter.append(" AND C.PROD_HIERARCHY_LVL_1_CD = :prodhierarchyLevel1");
			baseParams.put("prodhierarchyLevel1", filterCriteria.get("prodhierarchyLevel1"));
		}
		if (filterCriteria.containsKey("prodhierarchyLevel2")) {
			queryFilter.append(" AND C.PROD_HIERARCHY_LVL_2_CD = :prodhierarchyLevel2");
			baseParams.put("prodhierarchyLevel2", filterCriteria.get("prodhierarchyLevel2"));
		}
		if (filterCriteria.containsKey("prodhierarchyLevel3")) {
			queryFilter.append(" AND C.PROD_HIERARCHY_LVL_3_CD = :prodhierarchyLevel3");
			baseParams.put("prodhierarchyLevel3", filterCriteria.get("prodhierarchyLevel3"));
		}
		buildCriteriaForExpensSearch(filterCriteria, queryFilter,baseParams);
	}

	private void buildCriteriaForExpensSearch(
			Map<String, String> filterCriteria, StringBuilder queryFilter,Map<String, Object> baseParams) {
		
		if(filterCriteria.containsKey("expenseType"))
		{
			if(filterCriteria.get("expenseType").equals("R"))
			{
				queryFilter.append(" AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
			}
			else if(filterCriteria.get("expenseType").equals("E"))
			{ 
				queryFilter.append(" AND ( C.EXPENSE_ITEM_IND = 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
			}
			else if(filterCriteria.get("expenseType").equals("M"))
			{
				queryFilter.append(" AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND = 'Y' AND C.COUPON_IND <> 'Y' ) ");
			}
		}	
		
		 if(filterCriteria.containsKey("TOTAL_SALES_SEARCH_VALUE")){
		    	queryFilter.append(" AND SD.TOTAL_SALES ");
		    	if(null!=filterCriteria.get("TOTAL_SALES_OPERATOR")){
		    	if(filterCriteria.get("TOTAL_SALES_OPERATOR").equals("GREATER_THAN")){
		    		queryFilter.append(">");
		    	}else if(filterCriteria.get("TOTAL_SALES_OPERATOR").equals("LESS_THAN")){
		    		queryFilter.append("<");	
		    	}else if(filterCriteria.get("TOTAL_SALES_OPERATOR").equals("EQUALS")){
		    		queryFilter.append("=");	
		    	 }
		    	}
		    	queryFilter.append(" :totalsalessearchvalue");
		    	baseParams.put("totalsalessearchvalue", filterCriteria.get("TOTAL_SALES_SEARCH_VALUE"));
		    }
		if(filterCriteria.containsKey("shipmentSearch"))
		{
			if(filterCriteria.get("shipmentSearch").equals("Y"))
			{
				queryFilter.append(" AND  SD.LAST_SHIP_DT is NOT NULL ");
			}
			if(filterCriteria.get("shipmentSearch").equals("N"))
			{
				queryFilter.append(" AND SD.LAST_SHIP_DT is  NULL ");
			}
		}
	}

	/**
	 * @param filterCriteria
	 * @param queryFilter
	 */
	private void buildCriteriaForSLUAndUPC(Map filterCriteria,
			StringBuilder queryFilter,Map<String, Object> baseParams) {
		if(filterCriteria.containsKey(PerishableSQLConstants.SLU)){
			if(PerishableSQLConstants.SYSTEM2.equals(filterCriteria.get(PerishableSQLConstants.ITEM_TYPE))){
				queryFilter.append(" AND X.SRC_UPC_COUNTRY=0 AND X.SRC_UPC_SALES=0 AND X.SRC_UPC_MANUF= :xsrcupcmanuf");
				baseParams.put("xsrcupcmanuf", filterCriteria.get("slu"));
			}else if("System0".equals(filterCriteria.get(PerishableSQLConstants.ITEM_TYPE))){
				queryFilter.append(" AND X.SRC_UPC_MANUF=41144 AND X.SRC_UPC_SALES= :xsrcupcsales");
				baseParams.put("xsrcupcsales", filterCriteria.get("slu"));
			}else if("All".equals(filterCriteria.get(PerishableSQLConstants.ITEM_TYPE))){
				queryFilter.append(" AND((X.SRC_UPC_SYSTEM=2 AND X.SRC_UPC_COUNTRY=0 AND X.SRC_UPC_SALES=0 AND X.SRC_UPC_MANUF= :xsrcupcmanuf");
				queryFilter.append(")");
				queryFilter.append(" OR(X.SRC_UPC_SYSTEM=0 AND X.SRC_UPC_MANUF=41144 AND X.SRC_UPC_SALES= :xsrcupcsales");
				queryFilter.append("))");
				baseParams.put("xsrcupcmanuf", filterCriteria.get(PerishableSQLConstants.SLU));
				baseParams.put("xsrcupcsales", filterCriteria.get(PerishableSQLConstants.SLU));
				
			}
		}
		if(filterCriteria.containsKey(PerishableSQLConstants.UPC)){
			Float upcVal =  Float.parseFloat((String) filterCriteria.get("upc"));
			if(upcVal< 100000 ){
				queryFilter.append(" AND C.UPC like :cupclike");	
				baseParams.put("cupclike", "%0000000"+filterCriteria.get("upc"));
				
			}else{
				queryFilter.append(" AND C.UPC= :cupcequal");
				baseParams.put("cupcequal", filterCriteria.get("upc"));
			}
			
		
		}
	}

	private StringBuilder createBaseSearchQuery(Map searchCriteria,Map<String, Object> baseParams) {
		
		StringBuilder queryFilter=new StringBuilder("");
		if(searchCriteria!=null && searchCriteria.size()>0)
		{
			if(searchCriteria.containsKey("companyID"))
			  { 
				queryFilter.append(" AND C.COMPANY_ID= :ccompanyID");
				baseParams.put("ccompanyID", searchCriteria.get("companyID"));
			  }
		    
			if(searchCriteria.containsKey("divisionID"))
			  {
				queryFilter.append(" AND C.DIVISION_ID= :cdivisionID");
			    baseParams.put("cdivisionID", searchCriteria.get("divisionID"));
			  }
			if(searchCriteria.containsKey(PerishableSQLConstants.MAPPING_STATUS))
			  {
				if(!(PerishableSQLConstants.MARK_AS_DEAD.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS)) ||
			    		PerishableSQLConstants.SHOW_ALL.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS)))){
			    	queryFilter.append(" AND X.CONV_STATUS_CD NOT IN('D') ");
				}
			    if("TO_BE_MAPPED".equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	queryFilter.append(" AND (P.MATCHING_STATUS_CD  is null ");
			    	queryFilter.append(" OR P.MATCHING_STATUS_CD ='UN_MAPPED' ");	
			    	queryFilter.append(" ) ");
			    	
			    }else if(PerishableSQLConstants.MARK_AS_DEAD.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	
			    	queryFilter.append(" AND X.CONV_STATUS_CD IN('D') ");
			    	queryFilter.append("AND (P.MATCHING_STATUS_CD = 'MARK_AS_DEAD' )");
			    	
			    }else if(PerishableSQLConstants.SHOW_ALL.equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	queryFilter.append("  AND ( P.MATCHED_ITEM_TYPE_CD IN('B','S','F','Y', 'E')  OR P.MATCHED_ITEM_TYPE_CD IS NULL )");
			    	queryFilter.append(" AND (P.MATCHING_STATUS_CD IS  NULL OR  P.MATCHING_STATUS_CD NOT IN ( 'CORRECTED') ) ");
			    }
			    else if (searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS).equals("MAPPED"))
			    {
			    	queryFilter.append(" AND C.PRODUCT_SKU = P.PRODUCT_SKU");
			    	queryFilter.append(" AND P.MATCHED_ITEM_TYPE_CD  IN('B','S','F','Y','E') ");
			    	queryFilter.append(" AND P.MATCHING_STATUS_CD = ");
			    	queryFilter.append(" :pmatchingstatuscd");
			    	baseParams.put("pmatchingstatuscd", searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS));
			    }
			    else if(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS).equals(PerishableSQLConstants.RESERVED))
			    {

			    	queryFilter.append(" AND P.MATCHING_STATUS_CD");
			    	queryFilter.append(" IN ( '"+PerishableSQLConstants.AWAITING_CIC+"',");
			    	queryFilter.append(" '"+PerishableSQLConstants.AWAITING_DIVISION+"',");
			    	queryFilter.append(" '"+PerishableSQLConstants.OTHER+"' )");
			    	queryFilter.append(" AND P.MATCHED_ITEM_TYPE_CD in ('B','S','F','Y','E') ");
			    
			    }
			    else{
			    	queryFilter.append(" AND C.PRODUCT_SKU = P.PRODUCT_SKU");
			    	queryFilter.append(" AND P.MATCHED_ITEM_TYPE_CD  IN('B','S','F','Y','E' ) ");
			    	queryFilter.append(" AND P.MATCHING_STATUS_CD ");
			    	queryFilter.append("= :pmatchingstatuscd");
			    	baseParams.put("pmatchingstatuscd", searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS));
			    }
			  }
			buildItemTypeForBaseSearch(searchCriteria, queryFilter);
						
			buildSearchCriteria(searchCriteria, queryFilter,baseParams);			
		}
		
		return queryFilter;
	}


	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void buildSearchCriteria(Map<String, String> searchCriteria, StringBuilder queryFilter,Map<String, Object> baseParams) {
		if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE)
				&& searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE) != null
				&& !searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("")) {
			if (searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("DESC_ITEM")) {
				if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
					queryFilter.append(" AND C.ITEM_DESC LIKE UPPER(");
					String itemDesc = searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).replaceAll("'", "''");
					queryFilter.append(" :itemDesc");
					queryFilter.append(")");
					baseParams.put("itemDesc", "%"+itemDesc+"%");
				}
			} 
			else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("UPC_VAL")){
		        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
		               queryFilter.append(" AND C.UPC LIKE UPPER(");
		               queryFilter.append(" :cupc");
		               queryFilter.append(")");
		               baseParams.put("cupc", "%"+searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE)+"%");
		        } 		      
		    }else if (searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("TOTAL_SALES")) {
				compareTotalSales(searchCriteria, queryFilter,baseParams);
			}
		    else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("USAGE_TYPE"))
			{
				if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("R"))
				{
					queryFilter.append("AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
				}
				else if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("E"))
				{
					queryFilter.append("AND ( C.EXPENSE_ITEM_IND = 'Y' AND C.MATERIAL_ITEM_IND <> 'Y' AND C.COUPON_IND <> 'Y' ) ");
				}
				else if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equals("M"))
				{
					queryFilter.append("AND ( C.EXPENSE_ITEM_IND <> 'Y' AND C.MATERIAL_ITEM_IND = 'Y' AND C.COUPON_IND <> 'Y' ) ");
				}
			}
		    else if(searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) &&
					   searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals(whse_dsd)){
				   if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("WHSE")){
					   queryFilter.append(" AND C.SOURCE_BY_WHSE  ='Y' ");
					}
			      if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("DSD")){
			    	  queryFilter.append(" AND C.SOURCE_BY_DSD  ='Y' ");
					}
				   
			   }
		    else {
				if (!searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals(whse_dsd)) {
					otherSearchs(searchCriteria, queryFilter,baseParams);
				}
			}
		}
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void otherSearchs(Map<String, String> searchCriteria, StringBuilder queryFilter,Map<String, Object> baseParams) {
		queryFilter.append(PerishableSQLConstants.AND + searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE));
		queryFilter.append(" LIKE UPPER( ");
		if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
			queryFilter.append(" :searchType");
			queryFilter.append(")");
			baseParams.put("searchType", searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
		}
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void compareTotalSales(Map<String, String> searchCriteria, StringBuilder queryFilter,Map<String, Object> baseParams) {
		queryFilter.append("AND SD.TOTAL_SALES ");
		if (null != searchCriteria.get(PerishableSQLConstants.OPERATOR)) {
			if (searchCriteria.get(PerishableSQLConstants.OPERATOR).equals("GREATER_THAN")) {
				queryFilter.append(">");
			} else if (searchCriteria.get(PerishableSQLConstants.OPERATOR).equals("LESS_THAN")) {
				queryFilter.append("<");
			} else if (searchCriteria.get(PerishableSQLConstants.OPERATOR).equals("EQUALS")) {
				queryFilter.append("=");
			}
		}
		queryFilter.append(" :sdtotalsales");
		baseParams.put("sdtotalsales", searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void buildItemTypeForBaseSearch(Map searchCriteria, StringBuilder queryFilter) {
		if (searchCriteria.containsKey(PerishableSQLConstants.ITEM_TYPE)) {
		

			if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals(PerishableSQLConstants.SYSTEM2)) {
				queryFilter.append(" AND X.SRC_UPC_COUNTRY =0  and X.SRC_UPC_SYSTEM =2 ");
				
			} else if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals(PerishableSQLConstants.SYSTEM4)) {

				queryFilter.append(" AND X.SRC_UPC_COUNTRY =0  and X.SRC_UPC_SYSTEM =4 ");
				
			} else if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals(PerishableSQLConstants.PLU_CAPS)) {
				 queryFilter.append(" AND X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND X.SRC_UPC_SALES > 0 ");
			}
		}
	}



	
	/**
	 * 
	 * @param searchCriteria
	 * @param filterCriteria
	 * @param targetTypeIndicator
	 * @return
	 */
	public List<Object[]> fetchBakeryTargetList(Map<String, String> searchCriteria, Map<String, String> filterCriteria,
			String targetTypeIndicator) {
		List<Object[]> newresults=null;
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder query=new StringBuilder("");
		String baseQueryJoin1 = "\n" + 
				"SELECT DISTINCT CDS.CORP_ITEM_CD,CDS.DESC_ITEM,CDS.VEND_CONV_FCTR,CDS.PACK_WHSE,CDS.CDS_SIZE,CDS.ITEM_USAGE_TYPE,NULL,POS.PLU_CD" + 
				"	,CDS.DISP_FLAG,CDS.STATUS_CORP,CONCAT (CDS.GROUP_CD,'-',CDS.CTGRY_CD,'-',CDS.CLASS_CD,'-',CDS.SUB_CLASS_CD,'-',CDS.SUBSB_CLASS_CD) AS SMIC" + 
				"	,OMDEPT.DEPT_NAME,P.MATCHING_STATUS_CD,POS.RING,POS.TARE_CD,POS.SCALE_GRADE,POS.SCALE_SHELF_LIFE,POS.SCALE_NET_WT,POS.SCALE_NET_WT_UNIT" + 
				"	,POS.BAKE_INGRED,POS.SCALE_SELL_BY_DAYS,POS.SCALE_EAT_BY_DAYS,'productsource' as productsource,CDS.ITEM_USAGE_IND,CDS.SCALE_PRETEXT_IND,'VENDOR_DETAIL' as VENDOR_DETAIL" + 
				"	,CDS.SIZE_UOM,CONCAT (CDS.VEN_UPC_PACK_IND,'-',CDS.VEN_UPC_COUNTRY,'-',CDS.VEN_UPC_NUM_SYS,'-',CDS.VEN_UPC_MANUF,'-',CDS.VEN_UPC_ITEM) AS VOC" + 
				" FROM SSIMSLAND.SQLDAT3_SSITMCDS CDS JOIN SSIMSLAND.SQLDAT3_SSITMXRF XRF ON CDS.CORP_ITEM_CD = XRF.CORP_ITEM_CD LEFT OUTER JOIN SSIMSLAND.SQLDAT3_SSITMPOS " + 
				" POS ON POS.UPC_MANUF = XRF.UPC_MANUF AND POS.UPC_SALES = XRF.UPC_SALES	AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY	AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM" + 
				" JOIN SSIMSLAND.SQLDAT3_OMSTRDS RDS ON CDS.RETAIL_SECT = RDS.SECT LEFT JOIN "+defaultSchema+".ITEM_CONV_ITEM_VENDOR_XRF VRF ON CDS.CORP_ITEM_CD = VRF.CORP_ITEM_CD" + 
				" JOIN SSIMSLAND.SQLDAT3_OMDEPT OMDEPT ON OMDEPT.DEPT = RDS.DEPT ";
				
				
			
		String baseQueryJoin2 ="LEFT OUTER JOIN ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
				+"ON CDS.CORP_ITEM_CD = P.CORP_ITEM_CD "
				
				+"WHERE CDS.RETAIL_SECT = '316' "
			
				+" AND CDS.STATUS_CORP <> 'D' " ; 
		
		String conditonalJoin ="" ;
		String searchcriteria = createTargetSearchQuery(searchCriteria,targetTypeIndicator,baseParams);
		String filtercriteria = createTargetFilterQuery(filterCriteria,baseParams);
		if(null!=searchCriteria && searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) &&
				searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("WDS.DST_CNTR"))
		{
			conditonalJoin =" LEFT JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS "
					+" ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD ";
		}
		query.append( baseQueryJoin1 );
		query.append( conditonalJoin );	
		query.append( baseQueryJoin2);
		query.append( searchcriteria );
		query.append( filtercriteria);
		


		EntityManager em =  entityManagerFactory
				.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setMaxResults(100);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "100");
		List<Object[]> results = q.getResultList();
		em.close();
		if (null != searchCriteria) {
			newresults = getTargetUpcAggregateList(results,searchCriteria.get(PerishableSQLConstants.ITEM_TYPE));
		}
		
		return newresults;
	}

	/**
	 *  Method the get upc aggregate for the given cic list
	 * @param resultlist
	 * @return
	 */
	private List<Object[]> getTargetUpcAggregateList(List<Object[]> resultlist, String itemType) {
		if(resultlist!=null && !resultlist.isEmpty() ){
			List<String> corpStrList = resultlist.stream().map(cic -> (cic[0]).toString()).collect(Collectors.toList());
			String conditonalJoin ="" ;
			/* if (null != itemType && !itemType.equals("") && itemType.equals("PLU") ) {
				 conditonalJoin=" JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS ON POS.UPC_MANUF = XRF.UPC_MANUF "
								+"AND POS.UPC_SALES =XRF.UPC_SALES "
								+"AND POS.UPC_COUNTRY= XRF.UPC_COUNTRY "
								+"AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  ";
	 			}  */
	    	StringBuilder query=new StringBuilder("");
	    	query.append( "SELECT " + 
	    			"CDS.CORP_ITEM_CD,STRING_AGG(" + 
	    			" cast(CONCAT( XRF.UPC_COUNTRY,XRF.UPC_SYSTEM,right(replicate('0',5) +" + 
	    			" cast(xrf.upc_manuf as varchar),5),right(replicate('0',5) + cast(xrf.upc_sales as varchar),5)) as varchar(max)),';' ) " + 
	    			" as UPC_LIST " + 
	    			" FROM" + 
	    			" SSIMSLAND.SQLDAT3_SSITMCDS CDS" + 
	    			" JOIN" + 
	    			" SSIMSLAND.SQLDAT3_SSITMXRF XRF" + 
	    			" ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD"    
             +conditonalJoin
             +" WHERE");
	    		query.append(" CDS.CORP_ITEM_CD IN ( :corpStrList");
	    	 query.append(")");
	    	 query.append(" GROUP BY CDS.CORP_ITEM_CD ");
	    	 
	    	/* if (null != itemType && !itemType.equals("")) {
		 			final String system_2 = "2";
		 			final String system_4 = "4";
		 			 if (itemType.equals("System2")) {
		 				query.append(" AND XRF.UPC_SYSTEM= " + system_2);
		 			} else if (itemType.equals("System4")) {
		 				query.append(" AND XRF.UPC_SYSTEM= " + system_4);
		 			} else if (itemType.equals("PLU")) {
		 				query.append(" AND POS.PLU_CD>0 ");
		 			}
		 		} */
	      	EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
			Query q = em.createNativeQuery(query.toString());
			q.setParameter("corpStrList", corpStrList);
			q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
			List<Object[]> results = q.getResultList();
			em.close();
			appendTargetResultListWithUPC(resultlist, results);
			
			 getTargetWhseDsd(resultlist);
			 getTargetVendorDetails(resultlist);
	    	}
			return resultlist;  
	}
	
	/**
	 * Method to append upc with the primary query result object
	 * @param resultlist
	 * @param results
	 */
	private void appendTargetResultListWithUPC(List<Object[]> resultlist, List<Object[]> results) {
			for (Object[] skuObjO : resultlist) {
				for (Object[] skuObj : results) {
					if (skuObjO[0].equals(skuObj[0])) {
							skuObjO[6] = skuObj[1];						
					}

				}
			}
		}

	private void getTargetWhseDsd(List<Object[]> newresults) {
		List<String> newStrList = newresults.stream().map(cic -> (cic[0]).toString()).collect(Collectors.toList());
		if(newresults!=null && !newresults.isEmpty() ){
			StringBuilder query=new StringBuilder("");
			query.append("SELECT CORP_ITEM_CD, STRING_AGG(SUBSTRING(DST_CNTR,1,1),'')  WHSE_DSD from SSIMSLAND.SQLDAT3_SSITMWDS  ");
					
			query.append(" WHERE CORP_ITEM_CD IN ( :newStrList)");
			query.append(" GROUP BY CORP_ITEM_CD ");
	    	 
	    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
				Query q = em.createNativeQuery(query.toString());
				q.setParameter("newStrList", newStrList);
				q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
				List<Object[]> results = q.getResultList();
				em.close();
			appendWhseDsdResult(newresults,results);
		}

	}

	private void appendWhseDsdResult(List<Object[]> newresults,
			List<Object[]> results) {
		for (Object[] skuObjO : newresults) {
			for (Object[] skuObj : results) {
				if (skuObjO[0].equals(skuObj[0])) {	
					
					if(skuObj[1].toString().contains("DW") || skuObj[1].toString().contains("WD"))
					{
						skuObjO[22] = "WHSE-DSD";
					}
					else if(!skuObj[1].toString().contains("W"))
					{
						skuObjO[22] = "DSD";
					}
					else if(!skuObj[1].toString().contains("D"))
					{
						skuObjO[22] = "WHSE";
					}
						
											
				}

			}
		}
		
	}
	private void getTargetVendorDetails(List<Object[]> newresults) {
		List<String> newStrList = newresults.stream().map(cic -> (cic[0]).toString()).collect(Collectors.toList());
		if(newresults!=null && !newresults.isEmpty() ){
			StringBuilder query=new StringBuilder("");
			query.append(" SELECT  DISTINCT CORP_ITEM_CD, vend_num,name from "
					
					+defaultSchema+ ".ITEM_CONV_ITEM_VENDOR_XRF    ");
			query.append(" WHERE CORP_ITEM_CD IN ( :newStrList)");
	    	
	    	 
	    		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
				Query q = em.createNativeQuery(query.toString());
				q.setParameter("newStrList", newStrList);
				q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
				List<Object[]> results = q.getResultList();
				em.close();
			appendTargetVendor(newresults,results);
		}
		
	}


	private void appendTargetVendor(List<Object[]> newresults,
			List<Object[]> results) {
		for (Object[] skuObjO : newresults) {
			for (Object[] skuObj : results) {
					
				if(skuObjO[25].equals("VENDOR_DETAIL"))
				{
					skuObjO[25] = skuObj[1]+"-"+skuObj[2]+";";	
				}
				else
				{
					skuObjO[25] = skuObjO[25]+""+skuObj[1]+"-"+skuObj[2]+";";	
				}
											

			}
		}
		
	}
	/**
	 * 
	 * @param filterCriteria
	 * @return
	 */
	private String createTargetFilterQuery(Map<String, String> filterCriteria,Map<String, Object> baseParams) {
		StringBuilder queryFilter = new StringBuilder("");

		if (null != filterCriteria.keySet() && !filterCriteria.keySet().isEmpty()) {
			buildDepartmentSearch(filterCriteria, queryFilter, baseParams);
			if (filterCriteria.containsKey(PerishableSQLConstants.ITEM_DESCRIPTION)) {
				String itemDesc = filterCriteria.get(PerishableSQLConstants.ITEM_DESCRIPTION).replaceAll("'", "''");
				queryFilter.append(" AND CDS.DESC_ITEM LIKE UPPER" + "(");
				queryFilter.append(" :cdsdescitem");
				queryFilter.append(")");
				baseParams.put("cdsdescitem", "%"+itemDesc+"%");
			}

			if (filterCriteria.containsKey("corpItemCD")) {
				queryFilter.append(" AND CDS.CORP_ITEM_CD=");
				queryFilter.append(":cdscorpitemcd");
				baseParams.put("cdscorpitemcd", filterCriteria.get("corpItemCD") );
			}
			if (filterCriteria.containsKey(PerishableSQLConstants.PLU)) {
				queryFilter.append(" AND POS.PLU_CD=");
				queryFilter.append(":posplucd");
				baseParams.put("posplucd",filterCriteria.get(PerishableSQLConstants.PLU));
			}

			if (filterCriteria.containsKey("upc")) {
				queryFilter.append(" AND CONCAT( xrf.upc_country ,  xrf.upc_system , right(replicate('0',5) + cast(xrf.upc_manuf as varchar),5),right(replicate('0',5) + cast(xrf.upc_sales as varchar),5)) =");
				queryFilter.append(" :xrfupc");
				baseParams.put("xrfupc",filterCriteria.get("upc"));
			}
			if(filterCriteria.containsKey("vendorName")){
            	queryFilter.append(" AND VRF.NAME LIKE UPPER" + "(");
                queryFilter.append(" :vrfname");
                queryFilter.append(")");
                baseParams.put("vrfname", "%"+filterCriteria.get("vendorName").replaceAll("'", "''")+"%" );
            }
            if(filterCriteria.containsKey("vendorCode")){
            	queryFilter.append(" AND VRF.VEND_NUM=");
            	queryFilter.append(":vrfvendnum");
            	baseParams.put("vrfvendnum", filterCriteria.get("vendorCode") );
            }
            if(filterCriteria.containsKey("expenseType")){
            	queryFilter.append("  AND CDS.ITEM_USAGE_IND  = ");
            	queryFilter.append(" :cdsitemusageind");
            	baseParams.put("cdsitemusageind", filterCriteria.get("expenseType") );
            }
            
            if(filterCriteria.containsKey("usageType")){
            	queryFilter.append("  AND CDS.ITEM_USAGE_TYPE  = ");
            	queryFilter.append(":cdsitemusagetype");
            	baseParams.put("cdsitemusagetype", filterCriteria.get("usageType") );
            }
            
            if(filterCriteria.containsKey("vendorOrderFilter")){
            	String[] vendorObject=filterCriteria.get("vendorOrderFilter").split("-");
            	
            	if(!vendorObject[0].equals("NA"))
            	{
            		queryFilter.append("  AND CDS.VEN_UPC_PACK_IND  = :cdsvenupcpackind");
            		baseParams.put("cdsvenupcpackind", vendorObject[0] );
            	
            	}
            	if(!vendorObject[1].equals("NA"))
            	{
            		queryFilter.append("  AND CDS.VEN_UPC_COUNTRY  = :cdsvenupccountry");
            		baseParams.put("cdsvenupccountry", vendorObject[1] );
            		
            	}
            	if(!vendorObject[2].equals("NA"))
            	{
            		queryFilter.append("  AND CDS.VEN_UPC_NUM_SYS  = :cdsvenupcnumsys");
            		baseParams.put("cdsvenupcnumsys", vendorObject[2] );
            	}
            	if(!vendorObject[3].equals("NA"))
            	{
            		queryFilter.append("  AND CDS.VEN_UPC_MANUF  = :cdsvenupcmanuf");
            		baseParams.put("cdsvenupcmanuf", vendorObject[3] );
            	
            	}
            	if(!vendorObject[4].equals("NA"))
            	{
            		queryFilter.append("  AND CDS.VEN_UPC_ITEM  = :cdsvenupcitem");
            		baseParams.put("cdsvenupcitem", vendorObject[4] );
            	}
            	
            }
			buildSMICFilter(filterCriteria, queryFilter,baseParams);
		}
		queryFilter.append(" ORDER BY CDS.CORP_ITEM_CD");
		return queryFilter.toString();
	}

	/**
	 * @param filterCriteria
	 * @param queryFilter
	 */
	private void buildSMICFilter(Map<String, String> filterCriteria,
			StringBuilder queryFilter,Map<String, Object> baseParams) {
		if(filterCriteria.containsKey("groupCd")){
			queryFilter.append(" AND CDS.GROUP_CD=");
			queryFilter.append(":cdsgroupcd");
			baseParams.put("cdsgroupcd", filterCriteria.get("groupCd"));
		}
		if(filterCriteria.containsKey("catgryCd")){
			queryFilter.append(" AND CDS.CTGRY_CD=");
			queryFilter.append(":cdscatgrycd");
			baseParams.put("cdscatgrycd", filterCriteria.get("catgryCd"));
		}

		if(filterCriteria.containsKey("classCd")){
			queryFilter.append(" AND CDS.CLASS_CD=");
			queryFilter.append(":cdsclasscd");
			baseParams.put("cdsclasscd", filterCriteria.get("classCd"));
		}

		if(filterCriteria.containsKey("subClassCd")){
			queryFilter.append(" AND CDS.SUB_CLASS_CD=");
			queryFilter.append(":cdssubclasscd");
			baseParams.put("cdssubclasscd", filterCriteria.get("subClassCd"));
		}

		if(filterCriteria.containsKey("subSubClassCd")){
			queryFilter.append(" AND CDS.SUBSB_CLASS_CD=");
			queryFilter.append(" :cdssubsubclasscd");
			baseParams.put("cdssubsubclasscd", filterCriteria.get("subSubClassCd"));
		}
		
        }
	

	/**
	 * @param filterCriteria
	 * @param queryFilter
	 */
	private void buildDepartmentSearch(Map<String, String> filterCriteria,
			StringBuilder queryFilter,Map<String, Object> baseParams) {
		if(filterCriteria.containsKey(PerishableSQLConstants.DEPARTMENT)){
			queryFilter.append(" AND CDS.RETAIL_SECT IN" + "(");
			queryFilter.append(" :cdsretailsect");
			queryFilter.append(")");
			baseParams.put("cdsretailsect", filterCriteria.get(PerishableSQLConstants.DEPARTMENT));
		}
	}
	
	
	/**
	 * 
	 * @param searchCriteria
	 * @return
	 */

	private String createTargetSearchQuery(Map<String, String> searchCriteria,String targetTypeIndicator,Map<String, Object> baseParams) {

		StringBuilder queryFilter = new StringBuilder("");
		if (searchCriteria != null && searchCriteria.size() > 0) {
			if(searchCriteria.containsKey(PerishableSQLConstants.MAPPING_STATUS))
			  {
			    if("TO_BE_MAPPED".equals(searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS))){
			    	queryFilter.append(" AND (P.MATCHING_STATUS_CD ");
			    	queryFilter.append(" is null )");	
			    
			    }else{

			    	queryFilter.append(" AND P.MATCHING_STATUS_CD ");
			    	queryFilter.append("= :pmatchingstatuscd");
			    	baseParams.put("pmatchingstatuscd", searchCriteria.get(PerishableSQLConstants.MAPPING_STATUS));

			    }
			  }
			
			if (searchCriteria.containsKey(PerishableSQLConstants.ITEM_TYPE)) {
				final String system2 = "2";
				final String system4 = "4";
				 if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("System2")) {
					queryFilter.append(" AND  xrf.upc_country =0  AND XRF.UPC_SYSTEM=");
					queryFilter.append(" :xrfupcsystem");
					baseParams.put("xrfupcsystem", system2);
				} else if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals("System4")) {
					queryFilter.append(" AND  xrf.upc_country =0  AND XRF.UPC_SYSTEM=");
					queryFilter.append(" :xrfupcsystem");
					baseParams.put("xrfupcsystem", system4);
				} else if (searchCriteria.get(PerishableSQLConstants.ITEM_TYPE).equals(PerishableSQLConstants.PLU_CAPS)) {
					queryFilter.append(" AND POS.PLU_CD>0 ");
				}
			}
			buildSearchCriteriaFilter(searchCriteria, queryFilter, baseParams);
		}

		return queryFilter.toString();
	
	}

	/**
	 * @param searchCriteria
	 * @param queryFilter
	 */
	private void buildSearchCriteriaFilter(Map<String, String> searchCriteria,
			StringBuilder queryFilter,Map<String, Object> baseParams) {
		if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE)){
			if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("UPC_VAL")){	
				if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
					queryFilter.append(" AND concat( xrf.upc_country ,  xrf.upc_system , right(replicate('0',5) + cast(xrf.upc_manuf as varchar),5),right(replicate('0',5) + cast(xrf.upc_sales as varchar),5)) " + " LIKE (");
					String searchValue =searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).replaceAll("-", "");
					queryFilter.append(" :searchValueUPC_VAL");
					queryFilter.append(")");
					baseParams.put("searchValueUPC_VAL", "%"+searchValue+"%");
				}			
			}else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("SMIC")){					
				if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
					queryFilter.append(" AND concat(cds.group_cd, cds.ctgry_cd ,  cds.class_cd ,  cds.sub_class_cd , cds.subsb_class_cd) =");
					queryFilter.append(" :searchValueSMIC" );
					baseParams.put("searchValueSMIC", searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
				}					
			}
		    else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("CIC_VAL")){
		        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
		               queryFilter.append(" AND CDS.CORP_ITEM_CD LIKE (");
		               queryFilter.append(" :searchValueCIC_VAL )" );
		               baseParams.put("searchValueCIC_VAL", "%"+searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE)+"%");
		        }      
		    }
		    else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("DESC_ITEM")){
		        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)  &&  null!=searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE)) {
		        	   
		        	  String itemDesc =searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).replaceAll("'", "''") ;
		        	   queryFilter.append(" AND CDS.DESC_ITEM LIKE UPPER( " );
		               queryFilter.append(" :itemDesc");
		               queryFilter.append(")");
		               baseParams.put("itemDesc", "%"+itemDesc+"%");
		        }      
		    }
			 else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("DEPT_NAME")){
			        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)) {
			               queryFilter.append(" AND CDS.RETAIL_SECT IN" + "(");
			               queryFilter.append(" :cdsretailsect");
			               queryFilter.append( ")");
			               baseParams.put("cdsretailsect", searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
			        }      
			 }
			 else if(searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("USAGE_TYPE")){
                 if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
                        queryFilter.append(" AND CDS.ITEM_USAGE_IND  = :cdsitemusageind " );
                        baseParams.put("cdsitemusageind",searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE));
                 }      
            }
			 
			 else{
			        if (searchCriteria.containsKey(PerishableSQLConstants.SEARCH_VALUE)){
			               queryFilter.append(" AND CAST(" + searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE) + " AS varchar) like UPPER(");
			               queryFilter.append( " :castsearchValue");
			               queryFilter.append(")");
			               baseParams.put("castsearchValue","%"+searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE)+"%");
			        }
				}
			}
	}
	
	
	
	public boolean checkMarkAsDead(Object[] inputs){
		StringBuilder query=new StringBuilder("");
		boolean hasResult=false;
		query.append("Select * From XREFLAND.SRC_ITEM_XRF where CONV_STATUS_CD='D' AND COMPANY_ID = :cmpId");
		query.append(" AND DIVISION_ID= :dvsnId");
		query.append(" AND SRC_PRODUCT_SKU = :sps");
		query.append(" AND SRC_UPC_COUNTRY= :suc");
		query.append(" AND SRC_UPC_SYSTEM= :sus");
		query.append(" AND SRC_UPC_MANUF= :sum");
		query.append(" AND SRC_UPC_SALES= :susl ");
		
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("cmpId", inputs[0]);
		q.setParameter("dvsnId", inputs[1]);
		q.setParameter("sps", inputs[2]);
		q.setParameter("suc", inputs[3]);
		q.setParameter("sus", inputs[4]);
		q.setParameter("sum", inputs[5]);
		q.setParameter("susl", inputs[6]);
		
		List<Object[]> results = q.getResultList();
		
		em.close();
		if(results!=null && !results.isEmpty()){
			hasResult= true;
		}
		return hasResult;
	}
	
public boolean markAsDead(Object[] inputs){
	
	boolean hasResult=false;
		
		StringBuilder query=new StringBuilder("");
		query.append("Update XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD ='D',CONV_STATUS_SUB_CD ='B', STATUS_REASON_TXT = :DeadReason,CONV_STATUS_DSC='Dead' Where COMPANY_ID =");
		query.append(":companyId AND DIVISION_ID= :divisionId AND SRC_PRODUCT_SKU = :productSku AND SRC_UPC_COUNTRY =:upcCountry AND SRC_UPC_SYSTEM =:upcSystem AND SRC_UPC_MANUF =:upcManuf  AND SRC_UPC_SALES =:upcSales ");


		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		        EntityTransaction et = em.getTransaction();
	        et.begin();
	        Query q = em.createNativeQuery(query.toString());
	        q.setParameter("companyId", inputs[0]);
	        q.setParameter("divisionId", inputs[1]);
	        q.setParameter("productSku", inputs[2]);
	        q.setParameter("upcCountry", inputs[3]);
	        q.setParameter("upcSystem", inputs[4]);
	        q.setParameter("upcManuf", inputs[5]);
	        q.setParameter("upcSales", inputs[6]);
	        q.setParameter("DeadReason", inputs[7]);
	        int result = q.executeUpdate();
	        et.commit();
	        LOG.info("Completed Updating SRC_ITEM_XREF records.");
	        em.close();
	        if(result>0){
	        	hasResult= true;
	        }
	        return hasResult;
	}

	
	/**
	 * Method to update the mapping status in  ITEM_CONV_MANUAL_MATCHING_PLAN mapping table 
	 * when user selects mapping action as UN_MAPPED
	 * 
	 * @param companyID
	 * @param divisionID
	 * @param sku
	 * @param cic
	 * @param upc
	 * @param mappingType
	 * @param mappingStatus 
	 * @param mappingstatus
	 * @return
	 */
	public boolean updateMappingStatus(String companyID, String divisionID, String sku, String cic,
			String upc, String mappingType, String mappingStatus) {
       
		LOG.info("Updating ITEM_CONV_MANUAL_MATCHING_PLAN records.");	
		boolean hasResult=false;
		StringBuilder query=new StringBuilder("");
		query .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD = :mappingStatus, CORP_ITEM_CD=0 "
				+ " WHERE MATCHED_ITEM_TYPE_CD IN ('B','Y','S')  AND DIVISION_ID = :divisionID  AND PRODUCT_SKU = "
				+ " :sku AND CORP_ITEM_CD = :cic  AND UPC =: upc");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("mappingStatus", mappingStatus);
		q.setParameter("divisionID", divisionID);
		q.setParameter("sku", sku);
		q.setParameter("cic", cic);
		q.setParameter("upc", upc);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed Updating ITEM_CONV_MANUAL_MATCHING_PLAN records.");
		em.close();
		if (result > 0) {
			hasResult= true;
		}
		return hasResult;
	}
	
	/**
	 * 
	 * @param companyID
	 * @param divisionID
	 * @param searchCriteria
	 * @param searchCriteriaValue
	 * @param itemType
	 * @return
	 */
	public List<Object[]> fetchMappedList(String companyID, String divisionID, String searchCriteria,
			String searchCriteriaValue, String itemType, String mappingStatus) {

		LOG.info("Fetching Mapped Items");
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder query = new StringBuilder("");
		StringBuilder joinQuery = new StringBuilder("");
		if (null != searchCriteria && !searchCriteria.isEmpty() && null != searchCriteriaValue
				&& !searchCriteriaValue.isEmpty() && (searchCriteria.equals("WDS.DST_CNTR"))) {
			joinQuery.append(" LEFT JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS ON CDS.CORP_ITEM_CD =WDS.CORP_ITEM_CD AND WDS.DST_CNTR like UPPER(");
			joinQuery.append(":searchCriteriaValue)");
			
			baseParams.put("searchCriteriaValue", searchCriteriaValue);

		}

		query.append("select /*+ PARALLEL(4) */ DISTINCT M.PRODUCT_SKU,C.ITEM_DESC,(C.MASTER_CASE_PACK_NBR / NULLIF(C.SHIPPING_PACK_NBR,0)) AS VCF,"
						+ "C.SHIPPING_PACK_NBR,C.SIZE_NBR,C.MULTI_COMP_ITEM_IND,M.UPC,CAST(C.ITEM_SETUP_DT AS DATE),"
						+ "CAST(sd.last_sale_dt AS DATE),CAST(SD.last_ship_dt AS DATE),"
						+ "M.CORP_ITEM_CD,CDS.DESC_ITEM,"
						+ "CDS.VEND_CONV_FCTR,CDS.PACK_WHSE,CDS.SIZE_NUM,CDS.ITEM_USAGE_TYPE,CDS.DISP_FLAG,"
						+ "CDS.CREATE_DT,M.MATCHING_TYPE_CD "
						+ "FROM ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN M "
						+ "LEFT JOIN SSIMSLAND.SQLDAT3_SSITMCDS CDS " + "ON CDS.CORP_ITEM_CD = M.CORP_ITEM_CD "
						+ "LEFT JOIN SSIMSLAND.SQLDAT3_SSITMXRF XRF " + "ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD "
						+ "LEFT JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS " + "ON  POS.UPC_MANUF = XRF.UPC_MANUF "
						+ "AND POS.UPC_SALES = XRF.UPC_SALES " + "AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY "
						+ "AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM "
						+ "LEFT JOIN  ECFLAND.ITEM_AGGREGATE_CORP C " + "ON C.COMPANY_ID = M.COMPANY_ID "
						+ "AND C.DIVISION_ID = M.DIVISION_ID " + "AND C.PRODUCT_SKU = M.PRODUCT_SKU "

						+ "LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD " + " ON C.COMPANY_ID = SD.COMPANY_ID "
						+ " AND C.DIVISION_ID = SD.DIVISION_ID" + " AND C.PRODUCT_SKU= SD.PRODUCT_SKU "
						+ "AND C.UPC = SD.UPC " + joinQuery + "WHERE M.COMPANY_ID= :companyID"
						+ " AND M.DIVISION_ID= :divisionID" 
						+ " AND M.MATCHING_TYPE_CD IN ('ADD_MAP','INHERIT_MAP') AND M.CORP_ITEM_CD!=0");
		baseParams.put("companyID", companyID);
		baseParams.put("divisionID", divisionID);

		if (null != searchCriteria && !searchCriteria.isEmpty() && null != searchCriteriaValue
				&& !searchCriteriaValue.isEmpty()) {
			if ("WHSE".equals(searchCriteria)) {
				query.append(" AND C.SOURCE_BY_WHSE  ='Y'");
			} else if("DSD".equals(searchCriteria)) {
				query.append(" AND C.SOURCE_BY_DSD  ='Y'");
			} else if("M.UPC".equals(searchCriteria)) {
				String searchValue = searchCriteriaValue.replaceAll("-", "");
				query.append(PerishableSQLConstants.AND);
				query.append(searchCriteria);
				query.append(" like UPPER(");
				query.append(":searchValue");
				query.append(")");
				baseParams.put("searchValue", searchValue);
			} else if (!"WDS.DST_CNTR".equals(searchCriteria)) {
				query.append(PerishableSQLConstants.AND);
				query.append(searchCriteria);
				query.append(" like UPPER(");
				query.append(":searchCriteriaValue");
				query.append(")");
				baseParams.put("searchCriteriaValue", searchCriteriaValue);
				
				
			}
		}
		if (null != mappingStatus && !mappingStatus.isEmpty()) {
			if (!"ALL".equals(mappingStatus)) {
				query.append(" AND M.MATCHING_STATUS_CD = :mappingStatus" );
				baseParams.put("mappingStatus", mappingStatus);
			}
		} else {
			query.append("AND M.MATCHING_STATUS_CD = 'MAPPED'");
		}

		buildItemTypeForMappedList(itemType, query, baseParams);

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "50");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Mapped Items");
		em.close();
		return results;
	}
	 /**
     * 
     * @param itemType
     * @param query
     */
	private void buildItemTypeForMappedList(String itemType, StringBuilder query,Map<String, Object> baseParams) {

		if (null != itemType) {
			final String system2 = "2";
			final String system4 = "4";

			if ("System2".equals(itemType)) {
				query.append(" and XRF.UPC_SYSTEM = :system2");
				baseParams.put("system2", system2);
			} else if ("System4".equals(itemType)) {
				query.append(" and XRF.UPC_SYSTEM = :system4");
				baseParams.put("system4", system4);
			} else if (PerishableSQLConstants.PLU_CAPS.equals(itemType)) {
				query.append("AND POS.PLU_CD>0");
			}
		}
	}

	public boolean checkDuplicateExistence(Object[] inputs)
	{  
		boolean hasResult=false;
		String query ="Select * from ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN WHERE MATCHING_STATUS_CD NOT IN ('UN_MAPPED') and "
				+"COMPANY_ID = ? AND "  
				+"DIVISION_ID = ? AND "
				+"PRODUCT_SKU = ? AND "
				+"UPC = ? AND "
				+"MATCHED_ITEM_TYPE_CD =? ";
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		
		Query q = em.createNativeQuery(query);
		q.setParameter(1, inputs[0]);
		q.setParameter(2, inputs[1]);
		q.setParameter(3, inputs[2]);
		q.setParameter(4, inputs[3]);
		q.setParameter(5, inputs[4]);
		List<Object[]> results = q.getResultList();
		
		em.close();
		if(results!=null && !results.isEmpty()){
			hasResult= true;
		}
		return hasResult;
	}
	
	public List listOfUPCforForceNew(Object[] inputs)
	{
		StringBuilder query=new StringBuilder("");
		query.append("select UPC from ECFLAND.ITEM_AGGREGATE_CORP where COMPANY_ID = :cmpId");
		query.append(" AND DIVISION_ID= :dvsnId");
		query.append(" AND PRODUCT_SKU = :prdsku");
		query.append(" AND UPC NOT IN (select UPC from ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN where COMPANY_ID = :cmpId1");
		query.append(" AND DIVISION_ID= :dvsnId1");
		query.append(" AND PRODUCT_SKU = :prdsku1");
		query.append(")");

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		        Query q = em.createNativeQuery(query.toString());
		        q.setParameter("cmpId", inputs[0]);
		        q.setParameter("dvsnId", inputs[1]);
		        q.setParameter("prdsku", inputs[2]);
		        q.setParameter("cmpId1", inputs[0]);
		        q.setParameter("dvsnId1", inputs[1]);
		        q.setParameter("prdsku1", inputs[2]);
	        List<Object[]> results = q.getResultList();
	        LOG.info("Completed inserting ITEM_CONV_MANUAL_MATCHING_PLAN records.");
	        em.close();
	        return results;
	}
	
	public List<String> fetchUpcList(String companyId, String divisionId, String productSku) {
		LOG.info("Fetching UPC From ITEM_AGGREGATE_CORP.");
		StringBuilder query=new StringBuilder("");
		
		query.append("SELECT DISTINCT D.UPC FROM ECFLAND.ITEM_AGGREGATE_CORP D "
				+ "LEFT JOIN ECFLAND.DISPLAY_ITEM_COMPONENTS S "
				+ "ON D.COMPANY_ID = S.COMPANY_ID "
				+ "AND D.DIVISION_ID = S.DIVISION_ID "
				+ "AND D.PRODUCT_SKU = S.PRODUCT_SKU "
				+ "JOIN XREFLAND.SRC_ITEM_XRF X "
				+ "ON D.COMPANY_ID = X.COMPANY_ID "
				+ "AND D.DIVISION_ID = X.DIVISION_ID "
				+ "AND D.PRODUCT_SKU = X.SRC_PRODUCT_SKU "
				+" and D.UPC= X.SRC_UPC "
				+ " WHERE D.PRODUCT_SKU = :prdsku AND D.COMPANY_ID = :cmpId  AND D.DIVISION_ID = :dvsnId AND X.CONV_STATUS_CD NOT IN('D','O','C')");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("prdsku", productSku);
		q.setParameter("cmpId", companyId);
		q.setParameter("dvsnId", divisionId);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "50");
		List<String> results = q.getResultList();
		LOG.info("Completed fetching UPC From ITEM_AGGREGATE_CORP.");
		em.close();
		return results;
	}

	public boolean checkAlreadyMappedCIC(String cic, String targetTypeIndicator) {
		boolean hasResult=false;
		String query ="Select * from ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN WHERE MATCHING_STATUS_CD NOT IN ('UN_MAPPED') and "
				+"CORP_ITEM_CD = ? AND "  
				+"MATCHED_ITEM_TYPE_CD =? ";
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query);
		q.setParameter(1, cic);
		q.setParameter(2, targetTypeIndicator);
		
		List<Object[]> results = q.getResultList();
		
		em.close();
		if(results!=null && !results.isEmpty()){
			hasResult= true;
		}
		return hasResult;
	}
	public boolean updateForceNewMappingStatus(String companyID, String divisionID, String sku,
			 String mappingType, String mappingStatus) {
		boolean hasResult=false;
		LOG.info("Updating ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  records.");	
		StringBuilder query=new StringBuilder("");
		query.append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  SET MATCHING_STATUS_CD = :mappingStatus ,CORP_ITEM_CD=0 WHERE COMPANY_ID = :companyID")
		.append(" AND DIVISION_ID = :divisionID AND PRODUCT_SKU = :sku AND MATCHING_TYPE_CD= :mappingType AND MATCHING_STATUS_CD is null and MATCHED_ITEM_TYPE_CD = 'F' ");
		
		StringBuilder queryforEtl=new StringBuilder("");
		queryforEtl .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD= 'CORRECTED',CORP_ITEM_CD =0  WHERE MATCHING_STATUS_CD IN( 'UN_MAPPED') AND "
				+ "  COMPANY_ID = :companyID   AND DIVISION_ID = :divisionID  AND PRODUCT_SKU= :sku AND MATCHED_ITEM_TYPE_CD  = 'E' AND MATCHING_TYPE_CD = 'ETL_AUTO_MATCH'  ");
		
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(query.toString());
		q.setParameter("mappingStatus", mappingStatus);
		q.setParameter("companyID", companyID);
		q.setParameter("divisionID", divisionID);
		q.setParameter("sku", sku);
		q.setParameter("mappingType", mappingType);
		int result = q.executeUpdate();
		Query q1 = em.createNativeQuery(queryforEtl.toString());
		q1.setParameter("companyID", companyID);
		q1.setParameter("divisionID", divisionID);
		q1.setParameter("sku", sku);
		result = q1.executeUpdate();
		et.commit();
		LOG.info("Completed Updating ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  records.");
		em.close();
		if (result > 0) {
			hasResult= true;
		}
		return hasResult;
	
	}

	
    public  BigDecimal countBakerySourceList(Map<String,String> searchCriteria,Map<String,String> filterCriteria)
    {
    	StringBuilder baseQuery=new StringBuilder("");
    	Map<String, Object> baseParams = new HashMap<>();
   	    baseQuery.append( "SELECT COUNT(DISTINCT C.product_Sku) FROM ECFLAND.ITEM_AGGREGATE_CORP C LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD ON C.COMPANY_ID = SD.COMPANY_ID " + 
   	    		"	AND C.DIVISION_ID = SD.DIVISION_ID	AND C.PRODUCT_SKU = SD.PRODUCT_SKU	AND C.UPC = SD.UPC LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON C.COMPANY_ID = MU.COMPANY_ID " + 
   	    		"	AND C.DIVISION_ID = MU.DIVISION_ID	AND C.PRODUCT_SKU = MU.PRODUCT_SKU	AND C.UPC = MU.SRC_UPC  JOIN XREFLAND.SRC_ITEM_XRF X ON C.COMPANY_ID = X.COMPANY_ID	AND C.DIVISION_ID = X.DIVISION_ID " + 
   	    		"    AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND C.UPC = X.SRC_UPC LEFT JOIN XREFLAND.DSD_VENDOR_XREF DVX ON X.COMPANY_ID = DVX.COMPANY_ID AND X.DIVISION_ID = DVX.DIVISION_ID " + 
   	    		"	AND X.SRC_SUPPLIER_NUM collate Latin1_General_CS_AS = DVX.VENDOR_ID LEFT JOIN XREFLAND.WHSE_VENDOR_XREF WVX ON X.COMPANY_ID = WVX.COMPANY_ID AND X.DIVISION_ID = WVX.DIVISION_ID " + 
   	    		"	AND X.SRC_SUPPLIER_NUM = WVX.VENDOR_ID LEFT OUTER JOIN ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN P ON C.COMPANY_ID = P.COMPANY_ID	AND C.DIVISION_ID = P.DIVISION_ID	AND C.UPC = P.UPC " + 
   	    		"	AND C.PRODUCT_SKU = P.PRODUCT_SKU WHERE X.CONV_STATUS_CD NOT IN ('O','C') AND C.MULTI_COMP_ITEM_IND <> 'Y'	AND (MU.PRODUCT_SKU IS NULL	OR (" + 
   	    		"	MU.PRODUCT_SKU IS NOT NULL	AND MU.AUTO_MANUAL_IND = 'N'))" + 
   	    		"	AND C.PROD_HIERARCHY_LVL_4_CD = 'BAKERY' ") ;
	   StringBuilder searchcriteria=createBaseSearchQuery(searchCriteria,baseParams);
	
	   StringBuilder  filtercriteria=createfilterQuery(filterCriteria,baseParams);	
	   baseQuery.append(searchcriteria.append(filtercriteria));
	   if(searchCriteria != null && searchCriteria.containsKey(PerishableSQLConstants.SEARCH_TYPE) &&
			   searchCriteria.get(PerishableSQLConstants.SEARCH_TYPE).equals("WHSE_DSD")){
		   if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("WHSE")){
			   baseQuery.append(" AND C.SOURCE_BY_WHSE  ='Y'");
			}
	      if(searchCriteria.get(PerishableSQLConstants.SEARCH_VALUE).equalsIgnoreCase("DSD")){
	    	  baseQuery.append(" AND C.SOURCE_BY_DSD  ='Y'");
			}
		   
	   }
	   EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
	   Query q = em.createNativeQuery(baseQuery.toString());
	   for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
	   Object results = q.getResultList().get(0);
	   em.close();
	   BigDecimal count=null;
	   if(null!=results){
		   count = new BigDecimal((Integer)results);
	   }
	   return count;
    }
    
    /**
     * 
     * @param resultlist
     * @param companyId
     * @param divisionId
     * @param mappingType
     * @param itemType
     * @return
     */
    private List<Object[]> getUpcAggregateList(List<Object[]> resultlist,String companyId, String divisionId,String mappingType, String itemType )
    {
    	Map<String, Object> baseParams = new HashMap<>();
    	List<String> corpStrList = resultlist.stream().map(cic -> (cic[0]).toString()).collect(Collectors.toList());
    	if(resultlist!=null && !resultlist.isEmpty() ){
	    	StringBuilder query=new StringBuilder("");
	    	query.append( " SELECT c.product_sku,STRING_AGG(c.upc, ';') AS UPC_LIST	,CASE WHEN X.CONV_STATUS_CD = 'D' THEN 'MARK_AS_DEAD' ELSE P.MATCHING_STATUS_CD " + 
	    			"		END MATCHING_STATUS_CD FROM ECFLAND.ITEM_AGGREGATE_CORP C JOIN XREFLAND.SRC_ITEM_XRF X ON C.COMPANY_ID = X.COMPANY_ID " + 
	    			"	    AND C.DIVISION_ID = X.DIVISION_ID	AND C.PRODUCT_SKU = X.SRC_PRODUCT_SKU	AND C.UPC = X.SRC_UPC	AND X.CONV_STATUS_CD NOT IN ('O','C') " + 
	    			"        LEFT JOIN ECFLAND.ITEM_CONV_SALES_SHIP_DATA SD ON C.COMPANY_ID = SD.COMPANY_ID	AND C.DIVISION_ID = SD.DIVISION_ID	AND C.PRODUCT_SKU = SD.PRODUCT_SKU " + 
	    			"	    AND C.UPC = SD.UPC LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON C.COMPANY_ID = MU.COMPANY_ID AND C.DIVISION_ID = MU.DIVISION_ID " + 
	    			"	    AND C.PRODUCT_SKU = MU.PRODUCT_SKU	AND C.UPC = MU.SRC_UPC	AND (MU.PRODUCT_SKU IS NULL	OR (MU.PRODUCT_SKU IS NOT NULL	AND MU.AUTO_MANUAL_IND = 'N')) " + 
	    			"        LEFT OUTER JOIN ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN P ON C.COMPANY_ID = P.COMPANY_ID	AND C.DIVISION_ID = P.DIVISION_ID	AND C.UPC = P.UPC " + 
	    			"	    AND C.PRODUCT_SKU = P.PRODUCT_SKU WHERE C.MULTI_COMP_ITEM_IND <> 'Y' AND ( MU.PRODUCT_SKU IS NULL OR ( MU.PRODUCT_SKU IS NOT NULL " + 
	    			"		AND MU.AUTO_MANUAL_IND = 'N')) AND " 
	    					  + " C.COMPANY_ID= :cmpId ");
			query.append(" ");
			query.append(" AND C.DIVISION_ID= ");
		    query.append(" :dvsnId"); 
		    query.append("");
		    setMappingTypeAndItemTypeFilter(mappingType, itemType,query,baseParams);
	    	query.append(" AND C.PRODUCT_SKU IN ( :corpStrList");
	    	
	    	
	    	query.append(")");
	    	query.append(" GROUP BY c.product_sku	,CASE WHEN X.CONV_STATUS_CD = 'D' THEN 'MARK_AS_DEAD' ELSE P.MATCHING_STATUS_CD	END");
	    
	      	EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
			Query q = em.createNativeQuery(query.toString());
			q.setParameter("cmpId", companyId);
			q.setParameter("dvsnId", divisionId);
			q.setParameter("corpStrList", corpStrList);
			for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
				q.setParameter(entry.getKey(), entry.getValue());
			}
			List<Object[]> results = q.getResultList();
			em.close();
			appendResultListWithUPC(resultlist, results);
			
			getProduceRelatedData(companyId,  divisionId,resultlist);
			
    	}
		return resultlist;        
    }

	/**
	 * @param resultlist
	 * @param results
	 */
	private void appendResultListWithUPC(List<Object[]> resultlist, List<Object[]> results) {
		for (Object[] skuObjO : resultlist) {
			for (Object[] skuObj : results) {
				if (skuObjO[0].equals(skuObj[0]) && isMapStatusEqual(skuObjO[9], skuObj[2])) {
					if(skuObjO[3] ==null)
					{skuObjO[3] = skuObj[1];}
					else
					{skuObjO[3] =skuObjO[3]+";"+ skuObj[1];}
				}
			}
		}
	}
	
	/**
	 * 
	 * @param object
	 * @param object2
	 * @return
	 */
	private boolean isMapStatusEqual(Object object, Object object2) {		
		return  (object != null && object2 != null && object.equals(object2) )|| (object == null && object2 == null);
	}

	/**
	 * @param mappingType
	 * @param itemType
	 * @param query
	 */
	private void setMappingTypeAndItemTypeFilter(String mappingType, String itemType, StringBuilder query,Map<String, Object> baseParams) {
		if (null!= mappingType && !( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) || PerishableSQLConstants.SHOW_ALL.equals(mappingType))) {
			if (PerishableSQLConstants.TO_BE_MAPPED.equals(mappingType)) {
				query.append(PerishableSQLConstants.AND_P_MACHING_STATUS_CD);
				query.append(PerishableSQLConstants.IS_NULL);
				query.append(" OR P.MATCHING_STATUS_CD ='UN_MAPPED' ");				
				query.append(" ) ");
			}
			 else if(mappingType.equals(PerishableSQLConstants.RESERVED))
			    {

			    	query.append(" AND P.MATCHING_STATUS_CD");
			    	query.append(" IN ( '"+PerishableSQLConstants.AWAITING_CIC+"',");
			    	query.append(" '"+PerishableSQLConstants.AWAITING_DIVISION+"',");
			    	query.append(" '"+PerishableSQLConstants.OTHER+"' )");
			    	query.append(" AND P.MATCHED_ITEM_TYPE_CD in ('B','S','F','Y','E') ");
			    
			    }
			else {
				query.append(" AND P.MATCHING_STATUS_CD= :mappingType");
				query.append(" AND P.MATCHED_ITEM_TYPE_CD IN ('B','S','F','Y','E')");
				baseParams.put("mappingType", mappingType) ;
			}
		}
	   if(null!= mappingType && !( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) || PerishableSQLConstants.SHOW_ALL.equals(mappingType))){
	    	query.append(" AND X.CONV_STATUS_CD NOT IN('D')");
	    }
	   if(null!= mappingType && ( PerishableSQLConstants.MARK_AS_DEAD.equals(mappingType) )){
	    	query.append(" AND X.CONV_STATUS_CD  IN('D')");
	    	query.append("AND P.MATCHING_STATUS_CD = 'MARK_AS_DEAD'");
	    	query.append("AND ( P.MATCHED_ITEM_TYPE_CD IN ('B','Y','E') or P.MATCHED_ITEM_TYPE_CD is null  ) ");
	    }
	   
		/*if (null != itemType) {
			if (itemType.equals(PerishableSQLConstants.SYSTEM2)) {
				query.append(" and X.SRC_UPC_SYSTEM =2 ");
			} else if (itemType.equals(PerishableSQLConstants.SYSTEM4)) {
				query.append(" and X.SRC_UPC_SYSTEM =4 ");
			} else if ((PerishableSQLConstants.PLU_CAPS).equals(itemType)) {
				query.append(" AND X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND X.SRC_UPC_SALES > 0 ");
			}
		}*/
		}
	
	
	/**
	 *Method to update conversion status in  XREFLAND.SRC_ITEM_XRF table
	 * @param pm
	 */
	public boolean updateStatusForMappingAction(Object[] inputs) {
		
		boolean hasResult=false;
		
		StringBuilder query=new StringBuilder("");
		query.append("Update XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD ='R',CONV_STATUS_SUB_CD ='A', STATUS_REASON_TXT ='Ready to process', CONV_STATUS_DSC='Ready' Where COMPANY_ID =");
		query.append(":companyId AND DIVISION_ID= :divisionId AND SRC_PRODUCT_SKU = :productSku AND SRC_UPC_COUNTRY = :upcCountry AND SRC_UPC_SYSTEM =  :upcSystem AND SRC_UPC_MANUF = :upcManuf AND  SRC_UPC_SALES = :upcSales AND CORP_ITEM_CD is null "); 
		
		
		StringBuilder queryforEtl=new StringBuilder("");
		queryforEtl .append("UPDATE ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN SET MATCHING_STATUS_CD= 'CORRECTED',CORP_ITEM_CD =0  WHERE MATCHING_STATUS_CD IN( 'UN_MAPPED','AWAITING_NEW_CIC','AWAITING_DIVISION_INPUT','OTHERS' ) AND "
				+ "  COMPANY_ID = :companyId AND DIVISION_ID= :divisionId AND PRODUCT_SKU = :productSku AND MATCHED_ITEM_TYPE_CD  = 'E' AND MATCHING_TYPE_CD = 'ETL_AUTO_MATCH' ");
		

		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		    EntityTransaction et = em.getTransaction();
		        
	        et.begin();
	        
	        Query q = em.createNativeQuery(query.toString());
	        q.setParameter("companyId", inputs[0]);
	        q.setParameter("divisionId", inputs[1]);
	        q.setParameter("productSku", inputs[2]);
	        q.setParameter("upcCountry", inputs[3]);
	        q.setParameter("upcSystem", inputs[4]);
	        q.setParameter("upcManuf", inputs[5]);
	        q.setParameter("upcSales", inputs[6]);
	        int result = q.executeUpdate();
	        
	        Query q1 = em.createNativeQuery(queryforEtl.toString());
			q1.setParameter("companyId", inputs[0]);
		    q1.setParameter("divisionId", inputs[1]);
		    q1.setParameter("productSku", inputs[2]);
		    result = q1.executeUpdate();
		    
	        et.commit();
	        
	        LOG.info("Completed Updating SRC_ITEM_XREF records.");
	        em.close();
	        if(result>0){
	        	hasResult=true;
	        }
	        return hasResult;
	}
	public BigDecimal countBakeryTargetList(Map<String, String> searchCriteria,
			Map<String, String> filterCriteria,String targetTypeIndicator) {
		
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder query=new StringBuilder("");
		String baseQueryJoin1 = "SELECT  COUNT( DISTINCT CDS.CORP_ITEM_CD)  FROM SSIMSLAND.SQLDAT3_SSITMCDS CDS  JOIN SSIMSLAND.SQLDAT3_SSITMXRF XRF " + 
				"	ON CDS.CORP_ITEM_CD =XRF.CORP_ITEM_CD JOIN  SSIMSLAND.SQLDAT3_SSITMPOS POS 	ON POS.UPC_MANUF = XRF.UPC_MANUF " + 
				"	AND POS.UPC_SALES = XRF.UPC_SALES AND POS.UPC_COUNTRY = XRF.UPC_COUNTRY	AND POS.UPC_SYSTEM = XRF.UPC_SYSTEM  " + 
				"	JOIN SSIMSLAND.SQLDAT3_SSITMWDS WDS ON CDS.CORP_ITEM_CD = WDS.CORP_ITEM_CD "   ;

			
		String baseQueryJoin2 ="LEFT OUTER JOIN ECFLAND.ITEM_CONV_MANUAL_MATCHING_PLAN  P "
				+"ON CDS.CORP_ITEM_CD = P.CORP_ITEM_CD "
				
				+"WHERE CDS.RETAIL_SECT = '316' "
				
				+" AND CDS.STATUS_CORP <> 'D' " ; 
		
		
		String searchcriteria = createTargetSearchQuery(searchCriteria,targetTypeIndicator,baseParams);
		String filtercriteria = createTargetFilterQuery(filterCriteria,baseParams);
		
		query.append( baseQueryJoin1 );
		query.append( baseQueryJoin2);
		query.append( searchcriteria );
		query.append( filtercriteria.replaceAll("ORDER BY CDS.CORP_ITEM_CD", ""));
				
    	
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		Object results = q.getResultList().get(0);
		   em.close();
		   BigDecimal count=null;
		   if(null!=results){
			   count=new BigDecimal((Integer)results);
		   }
		   return count;
		  
	}
	private List<Object[]> getProduceRelatedData(String company, String division,
			List<Object[]>  resultlist) {
		List<String> corpStrList = resultlist.stream().map(cic -> (cic[0]).toString()).collect(Collectors.toList());
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append(" select distinct rog.product_Sku, selling_method_cd, ");
		baseQuery.append(" case when whse.receive_random_ind is not null then whse.receive_random_ind ");
		baseQuery.append(" when dsd.receive_random_ind is not null then dsd.receive_random_ind end \"RANDOM_IND\" ");
		baseQuery.append(" from ecfland.item_aggregate_rog rog ");
		baseQuery.append("  LEFT JOIN ecfland.item_aggregate_whse whse on ");
		baseQuery.append(" rog.company_id =whse.company_id and rog.division_id =whse.division_id ");
		baseQuery.append(" and rog.product_sku =whse.product_Sku ");
		baseQuery.append(" LEFT JOIN ecfland.item_aggregate_dsd dsd on ");
		baseQuery.append("rog.company_id =dsd.company_id and rog.division_id =dsd.division_id");
		baseQuery.append(" and  rog.product_sku =dsd.product_Sku");
		baseQuery.append(" where rog.company_id = :company ");
		baseQuery.append( "and rog.division_id =:division ");
		baseQuery.append(" and rog.product_Sku IN ( :corpStrList ");
		
		baseQuery.append(") ");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("corpStrList", corpStrList);
		
		
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		List<Object[]> produceResults = q.getResultList();
		LOG.info("");
		em.close();
		appendProduceRelatedData(resultlist,produceResults);
		return resultlist;
	}

	private void appendProduceRelatedData(List<Object[]> resultlist,
			List<Object[]> produceResults) {
		for (Object[] skuObjO : resultlist) {
			for (Object[] produceObj : produceResults) {

				if (skuObjO[0].equals(produceObj[0]) ) {					
						
						skuObjO[21] = produceObj[1];
						skuObjO[22] = produceObj[2];
					 break;
				}

			}
		}
	}

}
