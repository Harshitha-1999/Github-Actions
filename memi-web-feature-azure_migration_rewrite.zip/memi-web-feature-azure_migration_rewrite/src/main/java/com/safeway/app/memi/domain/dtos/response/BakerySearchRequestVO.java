/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

/**
 ****************************************************************************
 * NAME : BakerySearchRequestVO 
 * 
 * DESCRIPTION :BakerySearchRequestVO is the class for holding search/filter values in
 * 			     mapping process
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Mar 5, 2018  - Initial Creation
 * *************************************************************************
 */

public class BakerySearchRequestVO {
	
	/**
	 * Attribute to hold  the company id
	 */
    private String companyID;
    
    /**
     * Attribute to hold the division id
     */
    private String divisionID;
	
	/**
	 * Attribute to hold the radio button search value
	 */
	private PerishableItemTypeVO ItemType;	
	
	/**
	 * Attribute to hold the data to which the filter should be applied
	 */
	private PerishableFilterVO filter;	

	
	
	
	/**
	 * Attribute to hold the error messages.
	 */
	private List<String> errorMessages;
	
	/**
	 * Attribute to hold the mapped status 
	 */
	private String mappingStatus;
	
	/**
	 * Attribute to hold the drop down field
	 */
	private String searchCriteria;
	
	/**
	 * Attribute to hold the the value corresponding to the drop down selected.
	 */
	private String searchCriteriaValue;
	
	/**
	 * Attribute to hold type of mapping selected such as showAll,letAutoMatch,
	 * MarkedAsDead,toBeMapped,mappingReview,
	 * mapped,converted.
	 */
	private String mappingType;
	
	/**
	 * Attribute to check filter conditions are present.
	 */
	private boolean isFilterAvail;

	
	/**
	 * Attribute to identify source and target while searching.
	 */
	private String searchIndicator;
	
		
	
	/**

	 * Attribute to hold the target type(SELLER/BUYER) .
	 */
	private String targetTypeIndicator;
	
	
	private String totalSalesOperator;
	
	/**

	 * @return the companyID
	 */
	public String getCompanyID() {
		return companyID;
	}

	/**
	 * @param companyID the companyID to set
	 */
	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	/**
	 * @return the divisionID
	 */
	public String getDivisionID() {
		return divisionID;
	}

	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(String divisionID) {
		this.divisionID = divisionID;
	}

	/**
	 * @return the itemType
	 */
	public PerishableItemTypeVO getItemType() {
		return ItemType;
	}

	/**
	 * @param itemType the itemType to set
	 */
	public void setItemType(PerishableItemTypeVO itemType) {
		ItemType = itemType;
	}

	/**
	 * @return the filter
	 */
	public PerishableFilterVO getFilter() {
		return filter;
	}

	/**
	 * @param filter the filter to set
	 */
	public void setFilter(PerishableFilterVO filter) {
		this.filter = filter;
	}

	/**
	 * @return the errorMessages
	 */
	public List<String> getErrorMessages() {
		return errorMessages;
	}

	/**
	 * @param errorMessages the errorMessages to set
	 */
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}

	/**
	 * @return the mappingStatus
	 */
	public String getMappingStatus() {
		return mappingStatus;
	}

	/**
	 * @param mappingStatus the mappingStatus to set
	 */
	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	/**
	 * @return the searchCriteria
	 */
	public String getSearchCriteria() {
		return searchCriteria;
	}

	/**
	 * @param searchCriteria the searchCriteria to set
	 */
	public void setSearchCriteria(String searchCriteria) {
		this.searchCriteria = searchCriteria;
	}

	/**
	 * @return the searchCriteriaValue
	 */
	public String getSearchCriteriaValue() {
		return searchCriteriaValue;
	}

	/**
	 * @param searchCriteriaValue the searchCriteriaValue to set
	 */
	public void setSearchCriteriaValue(String searchCriteriaValue) {
		this.searchCriteriaValue = searchCriteriaValue;
	}

	/**
	 * @return the mappingType
	 */
	public String getMappingType() {
		return mappingType;
	}

	/**
	 * @param mappingType the mappingType to set
	 */
	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}

	/**
	 * @return the isFilterAvail
	 */
	public boolean isFilterAvail() {
		return isFilterAvail;
	}

	/**
	 * @param isFilterAvail the isFilterAvail to set
	 */
	public void setFilterAvail(boolean isFilterAvail) {
		this.isFilterAvail = isFilterAvail;
	}


	/**
	 * @return the searchIndicator
	 */

	public String getSearchIndicator() {
		return searchIndicator;
	}

	/**
	 * @param searchIndicator the searchIndicator to set
	 */
	public void setSearchIndicator(String searchIndicator) {
		this.searchIndicator = searchIndicator;
	}


	/**
	 * @return the targetTypeIndicator
	 */
	public String getTargetTypeIndicator() {
		return targetTypeIndicator;
	}

	/**
	 * @param targetTypeIndicator the targetTypeIndicator to set
	 */
	public void setTargetTypeIndicator(String targetTypeIndicator) {
		this.targetTypeIndicator = targetTypeIndicator;
	}

	/**
	 * @return the totalSalesOperator
	 */
	public String getTotalSalesOperator() {
		return totalSalesOperator;
	}

	/**
	 * @param totalSalesOperator the totalSalesOperator to set
	 */
	public void setTotalSalesOperator(String totalSalesOperator) {
		this.totalSalesOperator = totalSalesOperator;
	}

	

}
