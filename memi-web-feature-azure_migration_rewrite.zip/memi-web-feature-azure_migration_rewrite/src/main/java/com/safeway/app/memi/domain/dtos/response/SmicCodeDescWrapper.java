package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class SmicCodeDescWrapper {

	private BigDecimal code;
	private String codeDesc;

	public BigDecimal getCode() {
		return code;
	}

	public void setCode(BigDecimal code) {
		this.code = code;
	}

	public String getCodeDesc() {
		return codeDesc;
	}

	public void setCodeDesc(String codeDesc) {
		this.codeDesc = codeDesc;
	}

	@Override
	public String toString() {
		return "SmicCodeDescWrapper [code=" + code + ", codeDesc=" + codeDesc
				+ "]";
	}

}
