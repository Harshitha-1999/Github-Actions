/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;


import java.math.BigDecimal;
import java.util.Date;


/**
 ****************************************************************************
 * NAME : BakerySKUSearchResults 
 * 
 * DESCRIPTION :BakerySKUSearchResults is the class to store the bakery search data of source item
 * 			    
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 mar 05, 2018  - Initial Creation
 * *************************************************************************
 */
public class BakerySKUSearchResults extends PerishableSKUSearchResults {
	
	private String ring;
	private String tareCode;
	private String scale;
	private String shelfLife;
	private String bakeryIngredients;
	private String scaleSellByDays;
	private String scaleEatByDays;
	private String scaleNetWeight;
	private String scaleNetWeightUnit;
	/**
	 * @return the ring
	 */
	public String getRing() {
		return ring;
	}
	/**
	 * @param ring the ring to set
	 */
	public void setRing(String ring) {
		this.ring = ring;
	}
	/**
	 * @return the tareCode
	 */
	public String getTareCode() {
		return tareCode;
	}
	/**
	 * @param tareCode the tareCode to set
	 */
	public void setTareCode(String tareCode) {
		this.tareCode = tareCode;
	}
	/**
	 * @return the scale
	 */
	public String getScale() {
		return scale;
	}
	/**
	 * @param scale the scale to set
	 */
	public void setScale(String scale) {
		this.scale = scale;
	}
	/**
	 * @return the shelfLife
	 */
	public String getShelfLife() {
		return shelfLife;
	}
	/**
	 * @param shelfLife the shelfLife to set
	 */
	public void setShelfLife(String shelfLife) {
		this.shelfLife = shelfLife;
	}
	/**
	 * @return the bakeryIngredients
	 */
	public String getBakeryIngredients() {
		return bakeryIngredients;
	}
	/**
	 * @param bakeryIngredients the bakeryIngredients to set
	 */
	public void setBakeryIngredients(String bakeryIngredients) {
		this.bakeryIngredients = bakeryIngredients;
	}
	/**
	 * @return the scaleSellByDays
	 */
	public String getScaleSellByDays() {
		return scaleSellByDays;
	}
	/**
	 * @param scaleSellByDays the scaleSellByDays to set
	 */
	public void setScaleSellByDays(String scaleSellByDays) {
		this.scaleSellByDays = scaleSellByDays;
	}
	/**
	 * @return the scaleEatByDays
	 */
	public String getScaleEatByDays() {
		return scaleEatByDays;
	}
	/**
	 * @param scaleEatByDays the scaleEatByDays to set
	 */
	public void setScaleEatByDays(String scaleEatByDays) {
		this.scaleEatByDays = scaleEatByDays;
	}
	/**
	 * @return the scaleNetWeight
	 */
	public String getScaleNetWeight() {
		return scaleNetWeight;
	}
	/**
	 * @param scaleNetWeight the scaleNetWeight to set
	 */
	public void setScaleNetWeight(String scaleNetWeight) {
		this.scaleNetWeight = scaleNetWeight;
	}
	/**
	 * @return the scaleNetWeightUnit
	 */
	public String getScaleNetWeightUnit() {
		return scaleNetWeightUnit;
	}
	/**
	 * @param scaleNetWeightUnit the scaleNetWeightUnit to set
	 */
	public void setScaleNetWeightUnit(String scaleNetWeightUnit) {
		this.scaleNetWeightUnit = scaleNetWeightUnit;
	}
	
	
	
}
