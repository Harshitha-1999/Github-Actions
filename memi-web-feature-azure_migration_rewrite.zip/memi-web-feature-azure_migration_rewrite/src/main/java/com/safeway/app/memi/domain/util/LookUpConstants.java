package com.safeway.app.memi.domain.util;

public class LookUpConstants {
	
	public static final String EQUALS =" = ";	
	public static final String EQUALITY =" = '";		
	public static final String EQUALITY_END ="'";

	public static final String LIKE =" LIKE UPPER ( ";		
	public static final String LIKE_END =")";

}
