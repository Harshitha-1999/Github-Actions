package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

public class DisplayExceptionItemDetail {
	
	String deptCode;
	String departmentNm;
	String exceptionCategory;
	String productSKU;
	String itemDesc;
	BigDecimal packQty;
	String sizeDesc;
	BigDecimal displayItemCost;
	String caseUPC;

	String componentItemDesc;
	BigDecimal componentQty;
	String componentSizeDesc;
	BigDecimal componentCost;

	String upcCountry;
	String upcSystem;
	String upcManuf;
	String upcSales;
	String componentUpc;
	
	BigDecimal sizeNum;
	
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDepartmentNm() {
		return departmentNm;
	}
	public void setDepartmentNm(String departmentNm) {
		this.departmentNm = departmentNm;
	}
	public String getExceptionCategory() {
		return exceptionCategory;
	}
	public void setExceptionCategory(String exceptionCategory) {
		this.exceptionCategory = exceptionCategory;
	}
	public String getProductSKU() {
		return productSKU;
	}
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public BigDecimal getPackQty() {
		return packQty;
	}
	public void setPackQty(BigDecimal packQty) {
		this.packQty = packQty;
	}
	public String getSizeDesc() {
		return sizeDesc;
	}
	public void setSizeDesc(String sizeDesc) {
		this.sizeDesc = sizeDesc;
	}
	public BigDecimal getDisplayItemCost() {
		return displayItemCost;
	}
	public void setDisplayItemCost(BigDecimal displayItemCost) {
		this.displayItemCost = displayItemCost;
	}
	public String getCaseUPC() {
		return caseUPC;
	}
	public void setCaseUPC(String caseUPC) {
		this.caseUPC = caseUPC;
	}
	public String getComponentItemDesc() {
		return componentItemDesc;
	}
	public void setComponentItemDesc(String componentItemDesc) {
		this.componentItemDesc = componentItemDesc;
	}
	public BigDecimal getComponentQty() {
		return componentQty;
	}
	public void setComponentQty(BigDecimal componentQty) {
		this.componentQty = componentQty;
	}
	public String getComponentSizeDesc() {
		return componentSizeDesc;
	}
	public void setComponentSizeDesc(String componentSizeDesc) {
		this.componentSizeDesc = componentSizeDesc;
	}
	public BigDecimal getComponentCost() {
		return componentCost;
	}
	public void setComponentCost(BigDecimal componentCost) {
		this.componentCost = componentCost;
	}
	public String getUpcCountry() {
		return upcCountry;
	}
	public void setUpcCountry(String upcCountry) {
		this.upcCountry = upcCountry;
	}
	public String getUpcSystem() {
		return upcSystem;
	}
	public void setUpcSystem(String upcSystem) {
		this.upcSystem = upcSystem;
	}
	public String getUpcManuf() {
		return upcManuf;
	}
	public void setUpcManuf(String upcManuf) {
		this.upcManuf = upcManuf;
	}
	public String getUpcSales() {
		return upcSales;
	}
	public void setUpcSales(String upcSales) {
		this.upcSales = upcSales;
	}
	public String getComponentUpc() {
		return componentUpc;
	}
	public void setComponentUpc(String componentUpc) {
		this.componentUpc = componentUpc;
	}
	public BigDecimal getSizeNum() {
		return sizeNum;
	}
	public void setSizeNum(BigDecimal sizeNum) {
		this.sizeNum = sizeNum;
	}

}
