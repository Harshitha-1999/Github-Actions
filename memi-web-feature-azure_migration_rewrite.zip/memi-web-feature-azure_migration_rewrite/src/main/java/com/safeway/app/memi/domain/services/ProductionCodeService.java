package com.safeway.app.memi.domain.services;

import java.util.List;

import com.safeway.app.memi.domain.dtos.response.ProductionCodeDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;

public interface ProductionCodeService {

	public List<ProductionCodeDetailDto> getProductionCode(String grpCd,
			String ctgryCd, String clsCd, String sbClsCd, String subSbClass);

	public List<SmicCodeDescWrapper> getProductionGroupCode();

	public List<SmicCodeDescWrapper> getProductionCategoryCode(String groupCode);

	public List<SmicCodeDescWrapper> getProductionClassCode(String groupCode,
			String categoryCode);

}
