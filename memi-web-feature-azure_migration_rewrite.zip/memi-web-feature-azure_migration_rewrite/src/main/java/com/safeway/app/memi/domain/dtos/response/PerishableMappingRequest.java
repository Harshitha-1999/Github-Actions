/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;

import javax.persistence.Column;


/**
 ****************************************************************************
 * NAME : PerishableMappingRequest 
 * 
 * DESCRIPTION :PerishableMappingRequest is the class to hold the parameters for mapping action to perform
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Jan 31, 2018  - Initial Creation
 * *************************************************************************
 */
public class PerishableMappingRequest {
	private String companyID;
	private String divisionID;
	private String upc;
	private String sku;
	private String mappingType;
	private String mappingstatus;
	private String cic;
	private String comments;
	private String updatedUserId;
	
	/* For ExpenseIitemIndicator*/
	private String matchedItemTypeCd;
	private String targetPLU;
	
	
	/**For addtional fileds**/
	private boolean targetEdited;
	private String dcPackDesc;
	private String dcSizeDsc;
	private String retailUnitPack;
	private String ring;
	private String hicone;
	
	private String prodwght;
	private String handlingCode;
	private String buyerNum;
	private String randomWtCd;	
	private String autoCostInv; 
	private String billingType;
	private String fdStmp;
	private String tareCd;
	private String labelSize;
	private String labelNumbers;
	private String prcTypeCd;
	private String sgnCount1;
	private String sgnCount2;
	private String sgnCount3;
	private String costAllow;
	private String costIb;
	private String costVend;
	private String costInv;	
	private String sellByDays;
	private String useByDays;
	private String pullBydays;
	
	
	
	
	/**
	 * @return the companyID
	 */
	public String getCompanyID() {
		return companyID;
	}
	/**
	 * @param companyID the companyID to set
	 */
	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}
	/**
	 * @return the divisionID
	 */
	public String getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(String divisionID) {
		this.divisionID = divisionID;
	}
	/**
	 * @return the upc
	 */
	public String getUpc() {
		return upc;
	}
	/**
	 * @param upc the upc to set
	 */
	public void setUpc(String upc) {
		this.upc = upc;
	}
	/**
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}
	/**
	 * @param sku the sku to set
	 */
	public void setSku(String sku) {
		this.sku = sku;
	}
	/**
	 * @return the mappingType
	 */
	public String getMappingType() {
		return mappingType;
	}
	/**
	 * @param mappingType the mappingType to set
	 */
	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}
	/**
	 * @return the mappingstatus
	 */
	public String getMappingstatus() {
		return mappingstatus;
	}
	/**
	 * @param mappingstatus the mappingstatus to set
	 */
	public void setMappingstatus(String mappingstatus) {
		this.mappingstatus = mappingstatus;
	}
	/**
	 * @return the cic
	 */
	public String getCic() {
		return cic;
	}
	/**
	 * @param cic the cic to set
	 */
	public void setCic(String cic) {
		this.cic = cic;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the updatedUserId
	 */
	public String getUpdatedUserId() {
		return updatedUserId;
	}
	/**
	 * @param updatedUserId the updatedUserId to set
	 */
	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}
	public String getMatchedItemTypeCd() {
		return matchedItemTypeCd;
	}
	public void setMatchedItemTypeCd(String matchedItemTypeCd) {
		this.matchedItemTypeCd = matchedItemTypeCd;
	}
	public String getTargetPLU() {
		return targetPLU;
	}
	public void setTargetPLU(String targetPLU) {
		this.targetPLU = targetPLU;
	}
	public String getDcPackDesc() {
		return dcPackDesc;
	}
	public void setDcPackDesc(String dcPackDesc) {
		this.dcPackDesc = dcPackDesc;
	}
	public String getDcSizeDsc() {
		return dcSizeDsc;
	}
	public void setDcSizeDsc(String dcSizeDsc) {
		this.dcSizeDsc = dcSizeDsc;
	}
	public String getRetailUnitPack() {
		return retailUnitPack;
	}
	public void setRetailUnitPack(String retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}
	public String getRing() {
		return ring;
	}
	public void setRing(String ring) {
		this.ring = ring;
	}
	public String getHicone() {
		return hicone;
	}
	public void setHicone(String hicone) {
		this.hicone = hicone;
	}
	public boolean isTargetEdited() {
		return targetEdited;
	}
	public void setTargetEdited(boolean targetEdited) {
		this.targetEdited = targetEdited;
	}
	public String getProdwght() {
		return prodwght;
	}
	public void setProdwght(String prodwght) {
		this.prodwght = prodwght;
	}
	public String getHandlingCode() {
		return handlingCode;
	}
	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}
	public String getBuyerNum() {
		return buyerNum;
	}
	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}
	public String getRandomWtCd() {
		return randomWtCd;
	}
	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}
	public String getAutoCostInv() {
		return autoCostInv;
	}
	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getFdStmp() {
		return fdStmp;
	}
	public void setFdStmp(String fdStmp) {
		this.fdStmp = fdStmp;
	}
	public String getTareCd() {
		return tareCd;
	}
	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}
	public String getLabelSize() {
		return labelSize;
	}
	public void setLabelSize(String labelSize) {
		this.labelSize = labelSize;
	}
	public String getLabelNumbers() {
		return labelNumbers;
	}
	public void setLabelNumbers(String labelNumbers) {
		this.labelNumbers = labelNumbers;
	}
	public String getPrcTypeCd() {
		return prcTypeCd;
	}
	public void setPrcTypeCd(String prcTypeCd) {
		this.prcTypeCd = prcTypeCd;
	}
	public String getSgnCount1() {
		return sgnCount1;
	}
	public void setSgnCount1(String sgnCount1) {
		this.sgnCount1 = sgnCount1;
	}
	public String getSgnCount2() {
		return sgnCount2;
	}
	public void setSgnCount2(String sgnCount2) {
		this.sgnCount2 = sgnCount2;
	}
	public String getSgnCount3() {
		return sgnCount3;
	}
	public void setSgnCount3(String sgnCount3) {
		this.sgnCount3 = sgnCount3;
	}
	public String getCostAllow() {
		return costAllow;
	}
	public void setCostAllow(String costAllow) {
		this.costAllow = costAllow;
	}
	public String getCostIb() {
		return costIb;
	}
	public void setCostIb(String costIb) {
		this.costIb = costIb;
	}
	public String getCostVend() {
		return costVend;
	}
	public void setCostVend(String costVend) {
		this.costVend = costVend;
	}
	public String getCostInv() {
		return costInv;
	}
	public void setCostInv(String costInv) {
		this.costInv = costInv;
	}
	public String getSellByDays() {
		return sellByDays;
	}
	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}
	public String getUseByDays() {
		return useByDays;
	}
	public void setUseByDays(String useByDays) {
		this.useByDays = useByDays;
	}
	public String getPullBydays() {
		return pullBydays;
	}
	public void setPullBydays(String pullBydays) {
		this.pullBydays = pullBydays;
	}
	
	
	
	
	
}
