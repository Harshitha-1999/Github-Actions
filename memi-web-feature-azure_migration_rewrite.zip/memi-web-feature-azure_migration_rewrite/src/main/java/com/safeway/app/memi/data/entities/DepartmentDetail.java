package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : DepartmentDetail 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Varada Nellayikunnath  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 4, 2017 vnell00 - Initial Creation
 * ************************************************************************/
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity class for database table PRODUCT_HIERARCHY.
 * 
 */
@Entity
@Table(name = "PRODUCT_HIERARCHY", schema="ECFLAND")
public class DepartmentDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "HIERARCHY_LEVEL_NM")
	private String hierLevelName;

	@Column(name = "HIERARCHY_LEVEL_DESC")
	private String hierLevelDesc;

	@Column(name = "DEPARTMENT_NM")
	private String deptName;

	@Column(name = "DEPARTMENT_CD")
	private String deptCd;

	@Id
	@Column(name = "COMPANY_ID")
	private String companyId;

	@Id
	@Column(name = "DIVISION_ID")
	private String divisionId;

	@Id
	@Column(name = "PROD_HIERARCHY_LVL_1_CD")
	private String prdHierLevel1;

	@Id
	@Column(name = "PROD_HIERARCHY_LVL_2_CD")
	private String prdHierLevel2;

	@Id
	@Column(name = "PROD_HIERARCHY_LVL_3_CD")
	private String prdHierLevel3;

	public String getHierLevelName() {
		return hierLevelName;
	}

	public void setHierLevelName(String hierLevelName) {
		this.hierLevelName = hierLevelName;
	}

	public String getHierLevelDesc() {
		return hierLevelDesc;
	}

	public void setHierLevelDesc(String hierLevelDesc) {
		this.hierLevelDesc = hierLevelDesc;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptCd() {
		return deptCd;
	}

	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getPrdHierLevel1() {
		return prdHierLevel1;
	}

	public void setPrdHierLevel1(String prdHierLevel1) {
		this.prdHierLevel1 = prdHierLevel1;
	}

	public String getPrdHierLevel2() {
		return prdHierLevel2;
	}

	public void setPrdHierLevel2(String prdHierLevel2) {
		this.prdHierLevel2 = prdHierLevel2;
	}

	public String getPrdHierLevel3() {
		return prdHierLevel3;
	}

	public void setPrdHierLevel3(String prdHierLevel3) {
		this.prdHierLevel3 = prdHierLevel3;
	}

	@Override
	public String toString() {
		return "DepartmentDetail [hierLevelName=" + hierLevelName
				+ ", hierLevelDesc=" + hierLevelDesc + ", deptName=" + deptName
				+ ", deptCd=" + deptCd + ", companyId=" + companyId
				+ ", divisionId=" + divisionId + ", prdHierLevel1="
				+ prdHierLevel1 + ", prdHierLevel2=" + prdHierLevel2
				+ ", prdHierLevel3=" + prdHierLevel3
				+ "]";
	}

}
