package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BakeryMappingRequestWrapper {
	
	private BakerySearchRequestVO sourceSearchRequest;
	private BakerySearchRequestVO targetBuyerSearchRequest;
	private BakerySearchRequestVO targetSellerSearchRequest;
	private List<BakeryMappingRequest> mappingrequestBuyer; 
	private List<BakeryMappingRequest> mappingrequestSeller;
	private BigDecimal sourceCount;
	private BigDecimal targetBuyerCount;
	private BigDecimal targetSellerCount;
	
	
	
	
	/**/
	private List<BakerySKUSearchResults> bakerySKUSearchResults;
	private List<BakeryCICSearchResults> bakeryBuyerCICSearchResults;
	private List<BakeryCICSearchResults> bakerySellerCICSearchResults;
	/**/
	
	private List<String> errorMessages;
	private int actionSuccessStatus;

	public BakerySearchRequestVO getSourceSearchRequest() {
		return sourceSearchRequest;
	}
	public void setSourceSearchRequest(BakerySearchRequestVO sourceSearchRequest) {
		this.sourceSearchRequest = sourceSearchRequest;
	}
	
	public BakerySearchRequestVO getTargetBuyerSearchRequest() {
		return targetBuyerSearchRequest;
	}
	public void setTargetBuyerSearchRequest(BakerySearchRequestVO targetBuyerSearchRequest) {
		this.targetBuyerSearchRequest = targetBuyerSearchRequest;
	}
	public BakerySearchRequestVO getTargetSellerSearchRequest() {
		return targetSellerSearchRequest;
	}
	public void setTargetSellerSearchRequest(BakerySearchRequestVO targetSellerSearchRequest) {
		this.targetSellerSearchRequest = targetSellerSearchRequest;
	}
	
	/**
	 * @return the bakerySKUSearchResults
	 */
	public List<BakerySKUSearchResults> getBakerySKUSearchResults() {
		return bakerySKUSearchResults;
	}
	/**
	 * @param bakerySKUSearchResults the bakerySKUSearchResults to set
	 */
	public void setBakerySKUSearchResults(
			List<BakerySKUSearchResults> bakerySKUSearchResults) {
		this.bakerySKUSearchResults = bakerySKUSearchResults;
	}
	/**
	 * @return the bakeryBuyerCICSearchResults
	 */
	public List<BakeryCICSearchResults> getBakeryBuyerCICSearchResults() {
		return bakeryBuyerCICSearchResults;
	}
	/**
	 * @param bakeryBuyerCICSearchResults the bakeryBuyerCICSearchResults to set
	 */
	public void setBakeryBuyerCICSearchResults(
			List<BakeryCICSearchResults> bakeryBuyerCICSearchResults) {
		this.bakeryBuyerCICSearchResults = bakeryBuyerCICSearchResults;
	}
	/**
	 * @return the bakerySellerCICSearchResults
	 */
	public List<BakeryCICSearchResults> getBakerySellerCICSearchResults() {
		return bakerySellerCICSearchResults;
	}
	/**
	 * @param bakerySellerCICSearchResults the bakerySellerCICSearchResults to set
	 */
	public void setBakerySellerCICSearchResults(
			List<BakeryCICSearchResults> bakerySellerCICSearchResults) {
		this.bakerySellerCICSearchResults = bakerySellerCICSearchResults;
	}
	public List<String> getErrorMessages() {
		return errorMessages;
	}
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	public List<BakeryMappingRequest> getMappingrequestSeller() {
		return mappingrequestSeller;
	}
	public void setMappingrequestSeller(List<BakeryMappingRequest> mappingrequestSeller) {
		this.mappingrequestSeller = mappingrequestSeller;
	}
	public List<BakeryMappingRequest> getMappingrequestBuyer() {
		return mappingrequestBuyer;
	}
	public void setMappingrequestBuyer(List<BakeryMappingRequest> mappingrequestBuyer) {
		this.mappingrequestBuyer = mappingrequestBuyer;
	}
	/**
	 * @return the sourceCount
	 */
	public BigDecimal getSourceCount() {
		return sourceCount;
	}
	/**
	 * @param sourceCount the sourceCount to set
	 */
	public void setSourceCount(BigDecimal sourceCount) {
		this.sourceCount = sourceCount;
	}
	public BigDecimal getTargetBuyerCount() {
		return targetBuyerCount;
	}
	public void setTargetBuyerCount(BigDecimal targetBuyerCount) {
		this.targetBuyerCount = targetBuyerCount;
	}
	public BigDecimal getTargetSellerCount() {
		return targetSellerCount;
	}
	public void setTargetSellerCount(BigDecimal targetSellerCount) {
		this.targetSellerCount = targetSellerCount;
	}
	public int getActionSuccessStatus() {
		return actionSuccessStatus;
	}
	public void setActionSuccessStatus(int actionSuccessStatus) {
		this.actionSuccessStatus = actionSuccessStatus;
	}
	
	
	
	
	
}
