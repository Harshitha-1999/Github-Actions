package com.safeway.app.memi.domain.dtos.response;
/* ***************************************************************************
 * NAME         : ExceptionReportDto
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Subhash G
 *
  REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 7, 2017 sgang06 - Initial Creation
 *
 ***************************************************************************/
public class ExceptionReportDto {
	
	private UIExceptionSrcDto exceptionSrc;

	public UIExceptionSrcDto getExceptionSrc() {
		return exceptionSrc;
	}

	public void setExceptionSrc(UIExceptionSrcDto exceptionSrc) {
		this.exceptionSrc = exceptionSrc;
	}

}
