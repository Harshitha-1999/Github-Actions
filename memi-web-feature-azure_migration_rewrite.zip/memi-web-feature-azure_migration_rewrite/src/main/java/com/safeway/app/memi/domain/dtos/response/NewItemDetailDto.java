package com.safeway.app.memi.domain.dtos.response;
/* ***************************************************************************
 * NAME         : NewItemDetailDto
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Varada Nellayikunnath
 *
  REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 8, 2017 vnell00 - Initial Creation
 *
 ***************************************************************************/
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class NewItemDetailDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String companyId;

    private String divisionId;

    private String productSKU;

    private String productSrcCd;

    private String upcCountry;

    private String upcSystem;

    private String upcManufacturer;

    private String upcSales;

    private String pluCd;

    private Character prmyUpcInd;

    private String caseUPC;

    private String caseUPCForDisplay;

    private BigDecimal vendConvFactor;

    private BigDecimal packwhse;

    private String cost;

    private String srcItmDesc;

    private String srcWhseItmDesc;

    private String srcRtlItmDesc;

    private String srcIntenetItemDesc;

    private String srcPosDesc;

    private Character itemUsgeInd;

    private Character itemUsageTypInd;

    private Character ptLabelInd;

    private Character dispFlag;

    private String size;

    private String srcSizeUom;

    private String descSize;

    private BigDecimal srcSizeNmbr;

    private String updItmDesc;

    private String updWhseItmDesc;

    private String updRtlItmDesc;

    private String updIntenetItemDesc;

    private String updPosDesc;

    private Character updUsgeInd;

    private Character updUsageTypInd;

    private Character updPtLabelInd;

    private Character updDispFlag;

    private String updSize;

    private String updSizeUom;

    private BigDecimal updSizeNmbr;

    private String prdHierLevel1;

    private String prdHierLevel2;

    private String prdHierLevel3;

    private String prdHierLevel4;

    private String prdHierLevel5;

    private Integer grpCd;

    private Integer ctgryCd;

    private Integer clsCd;

    private Integer sbClsCd;

    private Integer subSbClass;

    private String SMICDesc;
    
    private String smicCode;
    
    private String smicCodeForDisplay;

    private String dtaSrcInd;

    private String dtaSrcDesc;

    private Character augOverCmplnInd;

    private BigDecimal dtaOverCic;

    private String covTeamComment;

    private Character excptnTypeCd;

    private String excptionDesc;

    private Character excptnProcessdInd;

    private Integer batchId;

    private Character logicalInd;
    
    private String createId;

    private String deptName;
    
    private String deptCd;
    
    private List<String> assocUpc;
    
    private String primayUpcString;
    
    private int peckingOrder = 100;
    
    private int upcMatchCount = 0;
    
    private boolean likeItem = false;
    
    private boolean mostRecommendedItem = false;
    
    private Set<String> upcs;
    
    private Set<String> dcList;
    
    private Character trueDSDFlag;
    
    private List<DCDetailsVo> dcDetails;
    
    private String cscDsc;

    private Character statusCorp;
    
    private Date cicCreateDate;
    
    private List<UPCVo> upcVoList;
    
    private UPCVo primaryUPCVo;
    
    private boolean borrowedUsageDetails = false;
    
    private boolean borrowedSMIC = false;
    
    private Integer productionGrpCd;
    private Integer productionCtgryCd;
    private Integer productionClsCd;
    private String ethnicTypeCd;
    private BigDecimal pckTypeId;
    private Integer productClsCd;
    private Integer innerPack;
    private Integer retailUnitPack;
    
    private List<SourceTgtUpc> updUpc;
    private List<SourceTgtUpc> updPlu;
    
    
    private String dcPackDesc;
	private String dcSizeDsc;
	private String ring;
	private String hicone;
    
	private String prodwght;
	private String handlingCode;
	private String buyerNum;
	private String randomWtCd;	
	private String autoCostInv; 
	private String billingType;
	private String fdStmp;
	private String labelSize;
	private String labelNumbers;
	private String sgnCount1;
	private String sgnCount2;
	private String sgnCount3;
	private String sellByDays;
	private String useByDays;
	private String pullBydays;
	private String tareCd;
	
	private String updpackwhse;
	
	
    public Integer getProductionGrpCd() {
		return productionGrpCd;
	}

	public void setProductionGrpCd(Integer productionGrpCd) {
		this.productionGrpCd = productionGrpCd;
	}

	public Integer getProductionCtgryCd() {
		return productionCtgryCd;
	}

	public void setProductionCtgryCd(Integer productionCtgryCd) {
		this.productionCtgryCd = productionCtgryCd;
	}

	public Integer getProductionClsCd() {
		return productionClsCd;
	}

	public void setProductionClsCd(Integer productionClsCd) {
		this.productionClsCd = productionClsCd;
	}

	public String getEthnicTypeCd() {
		return ethnicTypeCd;
	}

	public void setEthnicTypeCd(String ethnicTypeCd) {
		this.ethnicTypeCd = ethnicTypeCd;
	}

	public BigDecimal getPckTypeId() {
		return pckTypeId;
	}

	public void setPckTypeId(BigDecimal pckTypeId) {
		this.pckTypeId = pckTypeId;
	}

	public Integer getProductClsCd() {
		return productClsCd;
	}

	public void setProductClsCd(Integer productClsCd) {
		this.productClsCd = productClsCd;
	}

	public Integer getRetailUnitPack() {
		return retailUnitPack;
	}

	public void setRetailUnitPack(Integer retailUnitPack) {
		this.retailUnitPack = retailUnitPack;
	}

	public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(String divisionId) {
        this.divisionId = divisionId;
    }

    public String getProductSKU() {
        return productSKU;
    }

    public void setProductSKU(String productSKU) {
        this.productSKU = productSKU;
    }

    public String getProductSrcCd() {
        return productSrcCd;
    }

    public void setProductSrcCd(String productSrcCd) {
        this.productSrcCd = productSrcCd;
    }

    public String getUpcCountry() {
        return upcCountry;
    }

    public void setUpcCountry(String upcCountry) {
        this.upcCountry = upcCountry;
    }

    public String getUpcSystem() {
        return upcSystem;
    }

    public void setUpcSystem(String upcSystem) {
        this.upcSystem = upcSystem;
    }

    public String getUpcManufacturer() {
        return upcManufacturer;
    }

    public void setUpcManufacturer(String upcManufacturer) {
        this.upcManufacturer = upcManufacturer;
    }

    public String getUpcSales() {
        return upcSales;
    }

    public void setUpcSales(String upcSales) {
        this.upcSales = upcSales;
    }

    public String getPluCd() {
        return pluCd;
    }

    public void setPluCd(String pluCd) {
        this.pluCd = pluCd;
    }

    public Character getPrmyUpcInd() {
        return prmyUpcInd;
    }

    public void setPrmyUpcInd(Character prmyUpcInd) {
        this.prmyUpcInd = prmyUpcInd;
    }

    public BigDecimal getVendConvFactor() {
        return vendConvFactor;
    }

    public void setVendConvFactor(BigDecimal vendConvFactor) {
        this.vendConvFactor = vendConvFactor;
    }

    public BigDecimal getPackwhse() {
        return packwhse;
    }

    public void setPackwhse(BigDecimal packwhse) {
        this.packwhse = packwhse;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getSrcItmDesc() {
        return srcItmDesc;
    }

    public void setSrcItmDesc(String srcItmDesc) {
        this.srcItmDesc = srcItmDesc;
    }

    public String getSrcWhseItmDesc() {
        return srcWhseItmDesc;
    }

    public void setSrcWhseItmDesc(String srcWhseItmDesc) {
        this.srcWhseItmDesc = srcWhseItmDesc;
    }

    public String getSrcRtlItmDesc() {
        return srcRtlItmDesc;
    }

    public void setSrcRtlItmDesc(String srcRtlItmDesc) {
        this.srcRtlItmDesc = srcRtlItmDesc;
    }

    public String getSrcIntenetItemDesc() {
        return srcIntenetItemDesc;
    }

    public void setSrcIntenetItemDesc(String srcIntenetItemDesc) {
        this.srcIntenetItemDesc = srcIntenetItemDesc;
    }

    public String getSrcPosDesc() {
        return srcPosDesc;
    }

    public void setSrcPosDesc(String srcPosDesc) {
        this.srcPosDesc = srcPosDesc;
    }

    public Character getItemUsgeInd() {
        return itemUsgeInd;
    }

    public void setItemUsgeInd(Character itemUsgeInd) {
        this.itemUsgeInd = itemUsgeInd;
    }

    public Character getItemUsageTypInd() {
        return itemUsageTypInd;
    }

    public void setItemUsageTypInd(Character itemUsageTypInd) {
        this.itemUsageTypInd = itemUsageTypInd;
    }

    public Character getPtLabelInd() {
        return ptLabelInd;
    }

    public void setPtLabelInd(Character ptLabelInd) {
        this.ptLabelInd = ptLabelInd;
    }

    public Character getDispFlag() {
        return dispFlag;
    }

    public void setDispFlag(Character dispFlag) {
        this.dispFlag = dispFlag;
    }


    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getSrcSizeUom() {
        return srcSizeUom;
    }

    public void setSrcSizeUom(String srcSizeUom) {
        this.srcSizeUom = srcSizeUom;
    }

    public BigDecimal getSrcSizeNmbr() {
        return srcSizeNmbr;
    }

    public void setSrcSizeNmbr(BigDecimal srcSizeNmbr) {
        this.srcSizeNmbr = srcSizeNmbr;
    }

    public String getUpdItmDesc() {
        return updItmDesc;
    }

    public void setUpdItmDesc(String updItmDesc) {
        this.updItmDesc = updItmDesc;
    }

    public String getUpdWhseItmDesc() {
        return updWhseItmDesc;
    }

    public void setUpdWhseItmDesc(String updWhseItmDesc) {
        this.updWhseItmDesc = updWhseItmDesc;
    }

    public String getUpdRtlItmDesc() {
        return updRtlItmDesc;
    }

    public void setUpdRtlItmDesc(String updRtlItmDesc) {
        this.updRtlItmDesc = updRtlItmDesc;
    }

    public String getUpdIntenetItemDesc() {
        return updIntenetItemDesc;
    }

    public void setUpdIntenetItemDesc(String updIntenetItemDesc) {
        this.updIntenetItemDesc = updIntenetItemDesc;
    }

    public String getUpdPosDesc() {
        return updPosDesc;
    }

    public void setUpdPosDesc(String updPosDesc) {
        this.updPosDesc = updPosDesc;
    }

    public Character getUpdUsgeInd() {
        return updUsgeInd;
    }

    public void setUpdUsgeInd(Character updUsgeInd) {
        this.updUsgeInd = updUsgeInd;
    }

    public Character getUpdUsageTypInd() {
        return updUsageTypInd;
    }

    public void setUpdUsageTypInd(Character updUsageTypInd) {
        this.updUsageTypInd = updUsageTypInd;
    }

    public Character getUpdPtLabelInd() {
        return updPtLabelInd;
    }

    public void setUpdPtLabelInd(Character updPtLabelInd) {
        this.updPtLabelInd = updPtLabelInd;
    }

    public Character getUpdDispFlag() {
        return updDispFlag;
    }

    public void setUpdDispFlag(Character updDispFlag) {
        this.updDispFlag = updDispFlag;
    }


    public String getUpdSize() {
        return updSize;
    }

    public void setUpdSize(String updSize) {
        this.updSize = updSize;
    }

    public String getUpdSizeUom() {
        return updSizeUom;
    }

    public void setUpdSizeUom(String updSizeUom) {
    	if(updSizeUom != null)
    		updSizeUom = updSizeUom.trim();
        this.updSizeUom = updSizeUom;
    }

    public BigDecimal getUpdSizeNmbr() {
        return updSizeNmbr;
    }

    public void setUpdSizeNmbr(BigDecimal updSizeNmbr) {
        this.updSizeNmbr = updSizeNmbr;
    }

    public String getPrdHierLevel1() {
        return prdHierLevel1;
    }

    public void setPrdHierLevel1(String prdHierLevel1) {
        this.prdHierLevel1 = prdHierLevel1;
    }

    public String getPrdHierLevel2() {
        return prdHierLevel2;
    }

    public void setPrdHierLevel2(String prdHierLevel2) {
        this.prdHierLevel2 = prdHierLevel2;
    }

    public String getPrdHierLevel3() {
        return prdHierLevel3;
    }

    public void setPrdHierLevel3(String prdHierLevel3) {
        this.prdHierLevel3 = prdHierLevel3;
    }

    public String getPrdHierLevel4() {
        return prdHierLevel4;
    }

    public void setPrdHierLevel4(String prdHierLevel4) {
        this.prdHierLevel4 = prdHierLevel4;
    }

    public String getPrdHierLevel5() {
        return prdHierLevel5;
    }

    public void setPrdHierLevel5(String prdHierLevel5) {
        this.prdHierLevel5 = prdHierLevel5;
    }

    public Integer getGrpCd() {
        return grpCd;
    }

    public void setGrpCd(Integer grpCd) {
        this.grpCd = grpCd;
    }

    public Integer getCtgryCd() {
        return ctgryCd;
    }

    public void setCtgryCd(Integer ctgryCd) {
        this.ctgryCd = ctgryCd;
    }

    public Integer getSbClsCd() {
        return sbClsCd;
    }

    public void setSbClsCd(Integer sbClsCd) {
        this.sbClsCd = sbClsCd;
    }

    public Integer getClsCd() {
        return clsCd;
    }

    public void setClsCd(Integer clsCd) {
        this.clsCd = clsCd;
    }

    public Integer getSubSbClass() {
        return subSbClass;
    }

    public void setSubSbClass(Integer subSbClass) {
        this.subSbClass = subSbClass;
    }

    public String getDtaSrcInd() {
        return dtaSrcInd;
    }

    public void setDtaSrcInd(String dtaSrcInd) {
        this.dtaSrcInd = dtaSrcInd;
    }

    public String getDtaSrcDesc() {
        return dtaSrcDesc;
    }

    public void setDtaSrcDesc(String dtaSrcDesc) {
        this.dtaSrcDesc = dtaSrcDesc;
    }

    public Character getAugOverCmplnInd() {
        return augOverCmplnInd;
    }

    public void setAugOverCmplnInd(Character augOverCmplnInd) {
        this.augOverCmplnInd = augOverCmplnInd;
    }

    public BigDecimal getDtaOverCic() {
        return dtaOverCic;
    }

    public void setDtaOverCic(BigDecimal dtaOverCic) {
        this.dtaOverCic = dtaOverCic;
    }

    public String getCovTeamComment() {
        return covTeamComment;
    }

    public void setCovTeamComment(String covTeamComment) {
        this.covTeamComment = covTeamComment;
    }

    public Character getExcptnTypeCd() {
        return excptnTypeCd;
    }

    public void setExcptnTypeCd(Character excptnTypeCd) {
        this.excptnTypeCd = excptnTypeCd;
    }

    public String getExcptionDesc() {
        return excptionDesc;
    }

    public void setExcptionDesc(String excptionDesc) {
        this.excptionDesc = excptionDesc;
    }

    public Character getExcptnProcessdInd() {
        return excptnProcessdInd;
    }

    public void setExcptnProcessdInd(Character excptnProcessdInd) {
        this.excptnProcessdInd = excptnProcessdInd;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Character getLogicalInd() {
        return logicalInd;
    }

    public void setLogicalInd(Character logicalInd) {
        this.logicalInd = logicalInd;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public List<String> getAssocUpc() {
        return assocUpc;
    }

    public void setAssocUpc(List<String> assocUpc) {
        this.assocUpc = assocUpc;
    }

    public String getPrimayUpcString() {
        return primayUpcString;
    }

    public void setPrimayUpcString(String primayUpcString) {
        this.primayUpcString = primayUpcString;
    }

    public String getCreateId() {
        return createId;
    }

    public void setCreateId(String createId) {
        this.createId = createId;
    }

	public int getPeckingOrder() {
		return peckingOrder;
	}

	public void setPeckingOrder(int peckingOrder) {
		this.peckingOrder = peckingOrder;
	}

	public boolean isLikeItem() {
		return likeItem;
	}

	public void setLikeItem(boolean likeItem) {
		this.likeItem = likeItem;
	}

	public boolean isMostRecommendedItem() {
		return mostRecommendedItem;
	}

	public void setMostRecommendedItem(boolean mostRecommendedItem) {
		this.mostRecommendedItem = mostRecommendedItem;
	}
	
	@Override
	public boolean equals(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    if(obj == this)
	    	return true;
	    if (this.getClass() != obj.getClass())
	        return false;
	    if (!NewItemDetailDto.class.isAssignableFrom(obj.getClass())) {
	        return false;
	    }
	    final NewItemDetailDto other = (NewItemDetailDto) obj;
	    if ((this.dtaOverCic == null) ? (other.dtaOverCic != null) : !this.dtaOverCic.equals(other.dtaOverCic)) {
	        return false;
	    }
	    return true;
	}
	
	@Override
	public int hashCode() {
	    int hash = 3;
	    hash = 53 * hash + (this.dtaOverCic != null ? this.dtaOverCic.hashCode() : 0);
	    return hash;
	}

	public Set<String> getUpcs() {
		return upcs;
	}

	public void setUpcs(Set<String> upcs) {
		this.upcs = upcs;
	}
	
	public void addUpc(String upc) {
		if(upcs == null)
			upcs = new HashSet<>();
		upcs.add(upc);
	}

	public Set<String> getDcList() {
		return dcList;
	}

	public void setDcList(Set<String> dcList) {
		this.dcList = dcList;
	}
	
	public void addDC(String dc) {
		if(dcList == null)
			dcList = new HashSet<>();
		dcList.add(dc);
	}

	public Character getTrueDSDFlag() {
		return trueDSDFlag;
	}

	public void setTrueDSDFlag(Character trueDSDFlag) {
		this.trueDSDFlag = trueDSDFlag;
	}

	public List<DCDetailsVo> getDcDetails() {
		return dcDetails;
	}

	public void setDcDetails(List<DCDetailsVo> dcDetails) {
		this.dcDetails = dcDetails;
	}
	
	public void addDCDetails(DCDetailsVo dcDetail)
	{
		if(dcDetails == null)
			dcDetails = new ArrayList<>();
		dcDetails.add(dcDetail);
	}

	public String getCscDsc() {
		return cscDsc;
	}

	public void setCscDesc(String cscDsc) {
		this.cscDsc = cscDsc;
	}
	

	public String getDescSize() {
		return descSize;
	}

	public void setDescSize(String descSize) {
		this.descSize = descSize;
	}

	public void setCscDsc(String cscDsc) {
		this.cscDsc = cscDsc;
	}
	
	public String getSmicCode()
	{
		if(grpCd != null && ctgryCd != null && clsCd != null && sbClsCd != null && subSbClass != null)
			return grpCd.toString() + ctgryCd.toString() + clsCd.toString() + sbClsCd.toString() + subSbClass.toString();
		else
			return "";
	}

	public String getSmicCodeForDisplay() {
		if(grpCd != null && ctgryCd != null && clsCd != null && sbClsCd != null && subSbClass != null){
			StringBuilder sb = new StringBuilder();
			sb.append(grpCd.toString());
			sb.append("-");
			sb.append(ctgryCd.toString());
			sb.append("-");
			sb.append(clsCd.toString());
			sb.append("-");
			sb.append(sbClsCd.toString());
			sb.append("-");
			sb.append(subSbClass.toString());
			return sb.toString();
		}
		else
			return "";
	}

	public String getSMICDesc() {
		return SMICDesc;
	}

	public void setSMICDesc(String sMICDesc) {
		SMICDesc = sMICDesc;
	}

	public void setSmicCode(String smicCode) {
		this.smicCode = smicCode;
	}

	public String getCaseUPC() {
		return caseUPC;
	}

	public void setCaseUPC(String caseUPC) {
		this.caseUPC = caseUPC;
	}

	public int getUpcMatchCount() {
		return upcMatchCount;
	}

	public void setUpcMatchCount(int upcMatchCount) {
		this.upcMatchCount = upcMatchCount;
	}

	public Character getStatusCorp() {
		return statusCorp;
	}

	public void setStatusCorp(Character statusCorp) {
		this.statusCorp = statusCorp;
	}

	public Date getCicCreateDate() {
		return cicCreateDate;
	}

	public void setCicCreateDate(Date cicCreateDate) {
		this.cicCreateDate = cicCreateDate;
	}

	public void setSmicCodeForDisplay(String smicCodeForDisplay) {
		this.smicCodeForDisplay = smicCodeForDisplay;
	}

	public List<UPCVo> getUpcVoList() {
		return upcVoList;
	}

	public void setUpcVoList(List<UPCVo> upcVoList) {
		this.upcVoList = upcVoList;
	}
	
	public void addUpcVo(UPCVo upcVo) {
		if(upcVoList != null && upcVoList.contains(upcVo))
			return;
		if(upcVoList == null)
			upcVoList = new ArrayList<UPCVo>();
		upcVoList.add(upcVo);
	}
	
	public UPCVo getPrimaryUPCVo() {
		primaryUPCVo = new UPCVo();
		primaryUPCVo.setUpc(getPrimayUpcString());
		return primaryUPCVo;
	}

	public void setPrimaryUPCVo(UPCVo primaryUPCVo) {
		this.primaryUPCVo = primaryUPCVo;
	}

	public boolean isBorrowedUsageDetails() {
		return borrowedUsageDetails;
	}

	public void setBorrowedUsageDetails(boolean borrowedUsageDetails) {
		this.borrowedUsageDetails = borrowedUsageDetails;
	}

	public boolean isBorrowedSMIC() {
		return borrowedSMIC;
	}

	public void setBorrowedSMIC(boolean borrowedSMIC) {
		this.borrowedSMIC = borrowedSMIC;
	}

	public Integer getInnerPack() {
		return innerPack;
	}

	public void setInnerPack(Integer innerPack) {
		this.innerPack = innerPack;
	}

	public String getCaseUPCForDisplay() {
		//No need to display Case UPC for DSD Items
		if(productSrcCd != null && productSrcCd.startsWith("D"))
			return "";
		caseUPCForDisplay = formatCaseUPCField(caseUPC);
		return caseUPCForDisplay;
	}

	public void setCaseUPCForDisplay(String caseUPCForDisplay) {
		this.caseUPCForDisplay = caseUPCForDisplay;
	}
	
	 @Override
	    public String toString() {
	        return "NewItemDetailDto [companyId=" + companyId + ", divisionId=" + divisionId + ", productSKU=" + productSKU
	            + ", productSrcCd=" + productSrcCd + ", upcCountry=" + upcCountry + ", upcSystem=" + upcSystem
	            + ", upcManufacturer=" + upcManufacturer + ", upcSales=" + upcSales + ", pluCd=" + pluCd + ", prmyUpcInd="
	            + prmyUpcInd + ", vendConvFactor=" + vendConvFactor + ", packwhse=" + packwhse + ", cost=" + cost
	            + ", srcItmDesc=" + srcItmDesc + ", srcWhseItmDesc=" + srcWhseItmDesc + ", srcRtlItmDesc=" + srcRtlItmDesc
	            + ", srcIntenetItemDesc=" + srcIntenetItemDesc + ", srcPosDesc=" + srcPosDesc + ", itemUsgeInd="
	            + itemUsgeInd + ", itemUsageTypInd=" + itemUsageTypInd + ", ptLabelInd=" + ptLabelInd + ", dispFlag="
	            + dispFlag + ", size=" + size + ", srcSizeUom=" + srcSizeUom + ", srcSizeNmbr=" + srcSizeNmbr
	            + ", updItmDesc=" + updItmDesc + ", updWhseItmDesc=" + updWhseItmDesc + ", updRtlItmDesc=" + updRtlItmDesc
	            + ", updIntenetItemDesc=" + updIntenetItemDesc + ", updPosDesc=" + updPosDesc + ", updUsgeInd="
	            + updUsgeInd + ", updUsageTypInd=" + updUsageTypInd + ", updPtLabelInd=" + updPtLabelInd + ", updDispFlag="
	            + updDispFlag + ", updSize=" + updSize + ", updSizeUom=" + updSizeUom + ", updSizeNmbr=" + updSizeNmbr
	            + ", prdHierLevel1=" + prdHierLevel1 + ", prdHierLevel2=" + prdHierLevel2 + ", prdHierLevel3="
	            + prdHierLevel3 + ", prdHierLevel4=" + prdHierLevel4 + ", prdHierLevel5=" + prdHierLevel5 + ", grpCd="
	            + grpCd + ", ctgryCd=" + ctgryCd + ", clsCd=" + clsCd + ", sbClsCd=" + sbClsCd + ", subSbClass="
	            + subSbClass + ", dtaSrcInd=" + dtaSrcInd + ", dtaSrcDesc=" + dtaSrcDesc + ", augOverCmplnInd="
	            + augOverCmplnInd + ", dtaOverCic=" + dtaOverCic + ", covTeamComment=" + covTeamComment + ", excptnTypeCd="
	            + excptnTypeCd + ", excptionDesc=" + excptionDesc + ", excptnProcessdInd=" + excptnProcessdInd
	            + ", batchId=" + batchId + ", logicalInd=" + logicalInd + ", deptName=" + deptName + ", deptCd=" + deptCd
	            + ", assocUpc=" + assocUpc + ", cscDsc=" + cscDsc 
	            + ", productionGrpCd=" + productionGrpCd
				+ ", productionCtgryCd=" + productionCtgryCd
				+ ", productionClsCd=" + productionClsCd + ", ethnicTypeCd="
				+ ethnicTypeCd + ", pckTypeId=" + pckTypeId + ", productClsCd="
				+ productClsCd + ", innerPack=" + innerPack
				+ ", retailUnitPack=" + retailUnitPack + "]";
	    }
	 
	 public static String formatCaseUPCField(String upc)
	 {
		 if(upc == null || upc.length() == 0)
			 return "0-0-0-00000-00000";
		 String[] fields = upc.split("-");
		 if(fields.length == 0)
			 return "0-0-0-00000-00000";
		 StringBuilder formattedUPC = new StringBuilder();
		 for(int i = 0 ; i <  fields.length; i++)
		 {
			 formattedUPC.append(prefixZeros(fields[i], i < 3 ? 1 : 5));
			 if(i < fields.length -1)
				 formattedUPC.append("-");
		 }
		 return formattedUPC.toString();
	 }
	 
	

	public static String prefixZeros(String val, int fieldLength)
	 {
		 if(val != null){
			val = val.trim();
			if (val.length() >= fieldLength)
				return val;
		}
		 else
			 val = "";
		 StringBuilder str = new StringBuilder();
		 int zeroesNeeded = fieldLength - val.length();
		 for(int i = 0; i < zeroesNeeded; i++)
			 str.append('0');
		 str.append(val);
		 return str.toString();
	 }
	
	public List<SourceTgtUpc> getUpdUpc() {
		return updUpc;
	}

	public void setUpdUpc(List<SourceTgtUpc> updUpc) {
		this.updUpc = updUpc;
	}
	public List<SourceTgtUpc> getUpdPlu() {
			return updPlu;
	}

	public void setUpdPlu(List<SourceTgtUpc> updPlu) {
			this.updPlu = updPlu;
	}
	
	public String getEditedUpc(String sourceUpc)
	{
		String editedUpc =null;
		if(this.updUpc !=null && !this.updUpc.isEmpty())
		{
			for(SourceTgtUpc stgtUpc:this.updUpc  )
			{
				if(stgtUpc.getSourceUpc().equals(sourceUpc))
					{
					editedUpc = stgtUpc.getEditedUpc();
					break;
					
					}
			}
		}
		return editedUpc;
		
	}
	
	public int getEditedPLU(String sourceUpc)
	{
		String editedUpc ="0";
		if(this.updPlu !=null && !this.updPlu.isEmpty())
		{
			for(SourceTgtUpc stgtUpc:this.updPlu  )
			{
				if(stgtUpc.getSourceUpc().equals(sourceUpc))
					{
					editedUpc = stgtUpc.getEditedUpc();
					break;
					
					}
			}
		}
		return Integer.parseInt(editedUpc);
		
	}

	public String getDcPackDesc() {
		return dcPackDesc;
	}

	public void setDcPackDesc(String dcPackDesc) {
		this.dcPackDesc = dcPackDesc;
	}

	public String getDcSizeDsc() {
		return dcSizeDsc;
	}

	public void setDcSizeDsc(String dcSizeDsc) {
		this.dcSizeDsc = dcSizeDsc;
	}

	public String getRing() {
		return ring;
	}

	public void setRing(String ring) {
		this.ring = ring;
	}

	public String getHicone() {
		return hicone;
	}

	public void setHicone(String hicone) {
		this.hicone = hicone;
	}
	
	public String getProdwght() {
		return prodwght;
	}
	public void setProdwght(String prodwght) {
		this.prodwght = prodwght;
	}
	public String getHandlingCode() {
		return handlingCode;
	}
	public void setHandlingCode(String handlingCode) {
		this.handlingCode = handlingCode;
	}
	public String getBuyerNum() {
		return buyerNum;
	}
	public void setBuyerNum(String buyerNum) {
		this.buyerNum = buyerNum;
	}
	public String getRandomWtCd() {
		return randomWtCd;
	}
	public void setRandomWtCd(String randomWtCd) {
		this.randomWtCd = randomWtCd;
	}
	public String getAutoCostInv() {
		return autoCostInv;
	}
	public void setAutoCostInv(String autoCostInv) {
		this.autoCostInv = autoCostInv;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getFdStmp() {
		return fdStmp;
	}
	public void setFdStmp(String fdStmp) {
		this.fdStmp = fdStmp;
	}
	public String getLabelSize() {
		return labelSize;
	}
	public void setLabelSize(String labelSize) {
		this.labelSize = labelSize;
	}
	public String getLabelNumbers() {
		return labelNumbers;
	}
	public void setLabelNumbers(String labelNumbers) {
		this.labelNumbers = labelNumbers;
	}
	
	public String getSgnCount1() {
		return sgnCount1;
	}
	public void setSgnCount1(String sgnCount1) {
		this.sgnCount1 = sgnCount1;
	}
	public String getSgnCount2() {
		return sgnCount2;
	}
	public void setSgnCount2(String sgnCount2) {
		this.sgnCount2 = sgnCount2;
	}
	public String getSgnCount3() {
		return sgnCount3;
	}
	public void setSgnCount3(String sgnCount3) {
		this.sgnCount3 = sgnCount3;
	}
	public String getSellByDays() {
		return sellByDays;
	}
	public void setSellByDays(String sellByDays) {
		this.sellByDays = sellByDays;
	}
	public String getUseByDays() {
		return useByDays;
	}
	public void setUseByDays(String useByDays) {
		this.useByDays = useByDays;
	}
	public String getPullBydays() {
		return pullBydays;
	}
	public void setPullBydays(String pullBydays) {
		this.pullBydays = pullBydays;
	}
	
	public String getTareCd() {
		return tareCd;
	}

	public void setTareCd(String tareCd) {
		this.tareCd = tareCd;
	}

	public void addUpdUpc(String source,String edited)
	{
		if(this.updUpc ==null)
		{
			this.updUpc =new ArrayList<SourceTgtUpc>();
		}
		SourceTgtUpc stgup =new SourceTgtUpc();
		stgup.setSourceUpc(source);
		stgup.setEditedUpc(edited);		
		this.updUpc.add(stgup);
		
	}
	
	public void addUpdPlu(String source,String edited)
	{
		if(this.updPlu ==null)
		{
			this.updPlu =new ArrayList<SourceTgtUpc>();
		}
		SourceTgtUpc stgup =new SourceTgtUpc();
		stgup.setSourceUpc(source);
		stgup.setEditedUpc(edited);		
		this.updPlu.add(stgup);
		
	}
	
	public String getUpdpackwhse() {
		return updpackwhse;
	}

	public void setUpdpackwhse(String updpackwhse) {
		this.updpackwhse = updpackwhse;
	}
	
	
}
class SourceTgtUpc
{
	private String sourceUpc;
	private String editedUpc;
	public String getEditedUpc() {
		return editedUpc;
	}
	public void setEditedUpc(String editedUpc) {
		this.editedUpc = editedUpc;
	}
	public String getSourceUpc() {
		return sourceUpc;
	}
	public void setSourceUpc(String sourceUpc) {
		this.sourceUpc = sourceUpc;
	}
}
