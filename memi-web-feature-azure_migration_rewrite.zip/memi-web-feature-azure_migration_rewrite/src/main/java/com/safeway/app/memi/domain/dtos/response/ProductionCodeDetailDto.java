package com.safeway.app.memi.domain.dtos.response;

public class ProductionCodeDetailDto {
	
	private Integer prdctnGrpCd;

    private Integer prdctnCtgryCode;

    private Integer prdctnClsCode;

    private Integer prdctnSubClsCode;

    private Integer prdctnSubSubClass;

    private String productionCodeDesc;

    
	public Integer getPrdctnGrpCd() {
		return prdctnGrpCd;
	}


	public void setPrdctnGrpCd(Integer prdctnGrpCd) {
		this.prdctnGrpCd = prdctnGrpCd;
	}


	public Integer getPrdctnCtgryCode() {
		return prdctnCtgryCode;
	}


	public void setPrdctnCtgryCode(Integer prdctnCtgryCode) {
		this.prdctnCtgryCode = prdctnCtgryCode;
	}


	public Integer getPrdctnClsCode() {
		return prdctnClsCode;
	}


	public void setPrdctnClsCode(Integer prdctnClsCode) {
		this.prdctnClsCode = prdctnClsCode;
	}


	public Integer getPrdctnSubClsCode() {
		return prdctnSubClsCode;
	}


	public void setPrdctnSubClsCode(Integer prdctnSubClsCode) {
		this.prdctnSubClsCode = prdctnSubClsCode;
	}


	public Integer getPrdctnSubSubClass() {
		return prdctnSubSubClass;
	}


	public void setPrdctnSubSubClass(Integer prdctnSubSubClass) {
		this.prdctnSubSubClass = prdctnSubSubClass;
	}


	public String getProductionCodeDesc() {
		return productionCodeDesc;
	}


	public void setProductionCodeDesc(String productionCodeDesc) {
		this.productionCodeDesc = productionCodeDesc;
	}

	@Override
	public String toString() {
		return "ProductionCodeDetailDto [prdctnGrpCd=" + prdctnGrpCd
				+ ", prdctnCtgryCode=" + prdctnCtgryCode + ", prdctnClsCode="
				+ prdctnClsCode + ", prdctnSubClsCode=" + prdctnSubClsCode
				+ ", prdctnSubSubClass=" + prdctnSubSubClass
				+ ", productionCodeDesc=" + productionCodeDesc + "]";
	}

	

}
