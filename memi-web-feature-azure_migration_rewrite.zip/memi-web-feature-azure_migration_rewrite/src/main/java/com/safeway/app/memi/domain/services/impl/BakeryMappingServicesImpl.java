/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlan;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlanPK;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.data.repositories.BakeryAdditionalSQLRepository;
import com.safeway.app.memi.data.repositories.BakerySQLRepository;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ItemConvManualMatchingPlanRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.adapters.BakeryAdapter;
import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakeryMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryResponseVO;
import com.safeway.app.memi.domain.dtos.response.BakerySKUSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakerySearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.ManualMapAdditionalLoadDto;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.services.BakeryMappingServices;
import com.safeway.app.memi.domain.util.PerishableConstants;

/**
 **************************************************************************** 
 * NAME : BakeryMappingServicesImpl
 * 
 * DESCRIPTION : BakeryMappingServicesImpl is the implementation class for
 * performing search and filter operations for mapping screen and mapped screen
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : U63169
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Mar 05, 2018 - Initial Creation
 * *************************************************************************
 */
@Service("BakeryMappingServices")
public class BakeryMappingServicesImpl implements BakeryMappingServices {

	private static final Logger LOG = LoggerFactory
			.getLogger(BakeryMappingServicesImpl.class);

	@Autowired
	private BakerySQLRepository bakerySQLRepository;
	
	@Autowired
	private BakeryAdditionalSQLRepository bakeryAdditionalSQLRepository;
	
	@Autowired
	private ItemConvManualMatchingPlanRepository itemConvManualMatchingPlanRepository;
	

	@Autowired
	 private ItemAggregateCorpRepository itemAggregateRepo;
	
	 @Autowired
	 private UIExceptionSrcRepository exSrcRepo;

	private BakeryAdapter bakeryAdapter = new BakeryAdapter();

	/**
	 * Method to retrieve the bakery SKU search results
	 * 
	 * @param searchRequestVO
	 * @return
	 * @throws Exception 
	 */

	@Override
	public BakeryResponseVO listBakerySKUItems(BakerySearchRequestVO bakerySearchRequestVO) throws Exception {
		LOG.info("started Fetching all listBakerySKUItems");
		
		final Map<String, String> searchCriteria = createSearchCriteriaMap(bakerySearchRequestVO);
		final Map<String, String> filterCriteria = createFilterCriteriaMap(bakerySearchRequestVO);
		
		BakeryResponseVO bakeryResponseVO = new BakeryResponseVO();
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		try
		{ 
					
			Future<BigDecimal> future1 =executorService.submit(new Callable<BigDecimal>() {
			    public BigDecimal call() throws Exception {
			    	 return bakerySQLRepository.countBakerySourceList(searchCriteria, filterCriteria);
			        
			    }
			});
	
			Future<List<BakerySKUSearchResults>> future2 =executorService.submit(new Callable<List<BakerySKUSearchResults>>() {
			    public List<BakerySKUSearchResults> call() throws Exception {
			    	
			    	List<Object[]> bakerySKUSearchResults = bakerySQLRepository
							.fetchBakerySourceList(searchCriteria, filterCriteria);
					return  bakeryAdapter
							.mapBakerySourceItem(bakerySKUSearchResults);
					
			    }
			});
		
			bakeryResponseVO.setSourceCount(future1.get());					
			if(null!=future2.get() && ! future2.get().isEmpty()){
				bakeryResponseVO.setBakerySkuSearchResults(future2.get());
			}
	       		
		}
		catch(InterruptedException | ExecutionException e)
		{
			LOG.error(e.getMessage());
			throw e;
		}
		finally{
		executorService.shutdown();
		}
		LOG.info("Completed Fetching all  listBakerySKUItems");
		return bakeryResponseVO;
	}

	/**
	 * 
	 * @param searchRequestVO
	 * @return
	 */
	private Map<String, String> createFilterCriteriaMap(BakerySearchRequestVO bakerySearchRequestVO) {
		LOG.debug("Started Execution for createFilterCriteriaMap");
		HashMap<String, String> filterCriteria = new HashMap<String, String>();
		setItemType(bakerySearchRequestVO, filterCriteria);
		if (null != bakerySearchRequestVO.getFilter() && bakerySearchRequestVO.isFilterAvail()) {
			if (null != bakerySearchRequestVO.getFilter().getCorpItemCD() && ! bakerySearchRequestVO.getFilter()
					.getCorpItemCD().isEmpty()) {
				filterCriteria.put("corpItemCD", bakerySearchRequestVO.getFilter()
						.getCorpItemCD());
			}
			setOtherFilters(bakerySearchRequestVO, filterCriteria);
			if (null != bakerySearchRequestVO.getFilter().getSupplierName() && ! bakerySearchRequestVO.getFilter()
					.getSupplierName().isEmpty()) {
				filterCriteria.put("supplierName", bakerySearchRequestVO.getFilter()
						.getSupplierName());
			}
			if (null != bakerySearchRequestVO.getFilter().getSupplierNum() && ! bakerySearchRequestVO.getFilter()
					.getSupplierNum().isEmpty()) {
				filterCriteria.put("supplierNum", bakerySearchRequestVO.getFilter()
						.getSupplierNum());
			}

			if (null != bakerySearchRequestVO.getFilter().getSlu() && ! bakerySearchRequestVO.getFilter()
					.getSlu().isEmpty()) {
				filterCriteria.put("slu", bakerySearchRequestVO.getFilter().getSlu());
			}
			if (null != bakerySearchRequestVO.getFilter().getVendorCode() && ! bakerySearchRequestVO.getFilter()
					.getVendorCode().isEmpty()) {
				filterCriteria.put("vendorCode", bakerySearchRequestVO.getFilter().getVendorCode());
			}
			if (null != bakerySearchRequestVO.getFilter().getVendorName() && ! bakerySearchRequestVO.getFilter()
					.getVendorName().isEmpty()) {
				filterCriteria.put("vendorName", bakerySearchRequestVO.getFilter().getVendorName());
			}
			buildSMICAndUpcFilter(bakerySearchRequestVO, filterCriteria);
			buildProdHierarchyFilter(bakerySearchRequestVO, filterCriteria);
			buildExpenseFilters(bakerySearchRequestVO, filterCriteria);
			setVendorOrderFilter(bakerySearchRequestVO, filterCriteria);
		}
		LOG.debug("Completed Execution for"+filterCriteria.size()+" createFilterCriteriaMap");
		return filterCriteria;
	}

	
	/**
	 * @param bakerySearchRequestVO
	 * @param filterCriteria
	 */
	private void setOtherFilters(BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> filterCriteria) {
		if (null != bakerySearchRequestVO.getFilter().getDepartment() && ! bakerySearchRequestVO.getFilter()
				.getDepartment().isEmpty()) {
			filterCriteria.put("department", bakerySearchRequestVO.getFilter()
					.getDepartment());
		}
		if (null != bakerySearchRequestVO.getFilter().getDivisionNum() && ! bakerySearchRequestVO.getFilter()
				.getDivisionNum().isEmpty()) {
			filterCriteria.put("divisionNum", bakerySearchRequestVO.getFilter()
					.getDivisionNum());
		}
		if (null != bakerySearchRequestVO.getFilter().getHierarchy() && ! bakerySearchRequestVO.getFilter()
				.getHierarchy().isEmpty()) {
			filterCriteria.put("hierarchy", bakerySearchRequestVO.getFilter()
					.getHierarchy());
		}
		if (null != bakerySearchRequestVO.getFilter().getItemNum() && ! bakerySearchRequestVO.getFilter()
				.getItemNum().isEmpty()) {
			filterCriteria.put("itemNum", bakerySearchRequestVO.getFilter()
					.getItemNum());
		}
		if (null != bakerySearchRequestVO.getFilter().getItemDescription() && ! bakerySearchRequestVO
				.getFilter().getItemDescription().isEmpty()) {
			filterCriteria.put("itemDescription", bakerySearchRequestVO
					.getFilter().getItemDescription());
		}
		if (null != bakerySearchRequestVO.getFilter().getProductSKU()  && ! bakerySearchRequestVO
				.getFilter().getProductSKU().isEmpty()) {
			filterCriteria.put("productSKU", bakerySearchRequestVO.getFilter()
					.getProductSKU());
		}
		if (null != bakerySearchRequestVO.getFilter().getPlu() && ! bakerySearchRequestVO.getFilter()
				.getPlu().isEmpty()) {
			filterCriteria.put("plu", bakerySearchRequestVO.getFilter().getPlu());
		}
	}

	/**
	 * @param bakerySearchRequestVO
	 * @param filterCriteria
	 */
	private void buildProdHierarchyFilter(
			BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> filterCriteria) {
		if (null != bakerySearchRequestVO.getFilter().getProdhierarchyLevel1() && ! bakerySearchRequestVO.getFilter()
				.getProdhierarchyLevel1().isEmpty()) {
			filterCriteria.put("prodhierarchyLevel1", bakerySearchRequestVO.getFilter().getProdhierarchyLevel1());
		}

		if (null != bakerySearchRequestVO.getFilter().getProdhierarchyLevel2() && ! bakerySearchRequestVO.getFilter()
				.getProdhierarchyLevel2().isEmpty()) {
			filterCriteria.put("prodhierarchyLevel2", bakerySearchRequestVO.getFilter().getProdhierarchyLevel2());
		}

		if (null != bakerySearchRequestVO.getFilter().getProdhierarchyLevel3() && ! bakerySearchRequestVO.getFilter()
				.getProdhierarchyLevel3().isEmpty()) {
			filterCriteria.put("prodhierarchyLevel3", bakerySearchRequestVO.getFilter().getProdhierarchyLevel3());
		}
	}

	/**
	 * @param bakerySearchRequestVO
	 * @param filterCriteria
	 */
	private void buildSMICAndUpcFilter(BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> filterCriteria) {
		if (null != bakerySearchRequestVO.getFilter().getSmicGroupCd() && ! bakerySearchRequestVO.getFilter().getSmicGroupCd().isEmpty()) {
			filterCriteria.put("groupCd", bakerySearchRequestVO.getFilter().getSmicGroupCd());
		}
		if (null != bakerySearchRequestVO.getFilter().getSmicCtgryCd() && ! bakerySearchRequestVO.getFilter()
				.getSmicCtgryCd().isEmpty()) {
			filterCriteria.put("catgryCd", bakerySearchRequestVO.getFilter().getSmicCtgryCd());
		}

		if (null != bakerySearchRequestVO.getFilter().getSmicClassCd() && ! bakerySearchRequestVO.getFilter()
				.getSmicClassCd().isEmpty()) {
			filterCriteria.put("classCd", bakerySearchRequestVO.getFilter().getSmicClassCd());
		}

		if (null != bakerySearchRequestVO.getFilter().getSmicSubClassCd() && ! bakerySearchRequestVO.getFilter()
				.getSmicSubClassCd().isEmpty()) {
			filterCriteria.put("subClassCd", bakerySearchRequestVO.getFilter().getSmicSubClassCd());
		}

		if (null != bakerySearchRequestVO.getFilter().getSmicSubSubClassCd() && ! bakerySearchRequestVO.getFilter()
				.getSmicSubSubClassCd().isEmpty()) {
			filterCriteria.put("subSubClassCd", bakerySearchRequestVO.getFilter().getSmicSubSubClassCd());
		}
		if (null != bakerySearchRequestVO.getFilter().getUpc() && ! bakerySearchRequestVO.getFilter()
				.getUpc().isEmpty()) {
			filterCriteria.put("upc", bakerySearchRequestVO.getFilter().getUpc().replaceAll("-", ""));
		}

	}
	private void buildExpenseFilters(BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> filterCriteria) {
		if(bakerySearchRequestVO.isFilterAvail())
		{
			if(bakerySearchRequestVO.getFilter().isUsageTypeIndFilter())
			{
				filterCriteria.put("expenseType", bakerySearchRequestVO.getFilter().getUsageTypeInd());
			}
			
			if(bakerySearchRequestVO.getFilter().isUsageFilter())
			{
				filterCriteria.put("usageType", bakerySearchRequestVO.getFilter().getUsageType());
			}
			
			if(bakerySearchRequestVO.getFilter().isTotalSalesFilter())
			{
				filterCriteria.put("TOTAL_SALES_SEARCH_VALUE", bakerySearchRequestVO.getFilter().getTotalSalesvalue());
				filterCriteria.put("TOTAL_SALES_OPERATOR", bakerySearchRequestVO.getFilter().getTotalSalesOperator());
			}
			if(bakerySearchRequestVO.getFilter().isShipped())
			{
				if(bakerySearchRequestVO.getFilter().getShipSearchValue().equals("Y"))
				filterCriteria.put("shipmentSearch", "Y");
				else if(bakerySearchRequestVO.getFilter().getShipSearchValue().equals("N"))
				filterCriteria.put("shipmentSearch", "N");	
			}
		}
	}
	/**Vendor order Code Filter**/
	private void setVendorOrderFilter(
			BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> filterCriteria) {
		LOG.debug("Execution started for setVendorOrderFilter");
		if(bakerySearchRequestVO.isFilterAvail() && bakerySearchRequestVO.getFilter().isVendorOrderFilter())
		{
			StringBuilder vendorOrder =new StringBuilder(""); 
			vendorOrder.append(bakerySearchRequestVO.getFilter().getVendUpcPackInd() !=null && !bakerySearchRequestVO.getFilter().getVendUpcPackInd().trim().equals("")
					?  bakerySearchRequestVO.getFilter().getVendUpcPackInd() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(bakerySearchRequestVO.getFilter().getVendUpcCountry() !=null && !bakerySearchRequestVO.getFilter().getVendUpcCountry().trim().equals("")
					?  bakerySearchRequestVO.getFilter().getVendUpcCountry() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(bakerySearchRequestVO.getFilter().getVendUpcNumSys() !=null && !bakerySearchRequestVO.getFilter().getVendUpcNumSys().trim().equals("")
					?  bakerySearchRequestVO.getFilter().getVendUpcNumSys() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(bakerySearchRequestVO.getFilter().getVendUpcManuf() !=null && !bakerySearchRequestVO.getFilter().getVendUpcManuf().trim().equals("")
					?  bakerySearchRequestVO.getFilter().getVendUpcManuf() : "NA");
			vendorOrder.append("-");
			vendorOrder.append(bakerySearchRequestVO.getFilter().getVendUpcItem() !=null && !bakerySearchRequestVO.getFilter().getVendUpcItem().trim().equals("")
					?  bakerySearchRequestVO.getFilter().getVendUpcItem() : "NA");
			
			filterCriteria.put("vendorOrderFilter", vendorOrder.toString());
			LOG.debug("Execution completed for setVendorOrderFilter");
			
		}
		
	}
	
	private void setSearchType(BakerySearchRequestVO bakerySearchRequestVO, HashMap<String, String> searchCriteria) {

		if (null != bakerySearchRequestVO.getSearchCriteria()
				&& !bakerySearchRequestVO.getSearchCriteria().isEmpty()) {
			if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)) {
				searchCriteria.put(PerishableConstants.searchType, "upper(C.PROD_HIERARCHY_LVL_4_CD)");
			}
			if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.SKU_VAL)) {
				searchCriteria.put(PerishableConstants.searchType, "upper(C.product_sku)");
			}
			if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)) {
				searchCriteria.put(PerishableConstants.searchType, "DESC_ITEM");
			}
			if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL)) {
				searchCriteria.put(PerishableConstants.searchType, PerishableConstants.UPC_VAL);
			}
			if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.PLU_VAL)) {
				searchCriteria.put(PerishableConstants.searchType, "  X.SRC_UPC_COUNTRY =0 AND X.SRC_UPC_SYSTEM =0 AND X.SRC_UPC_MANUF = 0 AND upper( X.SRC_UPC_SALES ) ");
			}
			if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.USAGE_TYPE)){
				
				searchCriteria.put(PerishableConstants.searchType, PerishableConstants.USAGE_TYPE);
			}
			setOtherSearchTypes(bakerySearchRequestVO, searchCriteria);			
	   }
	
		
	}

	
	/**
	 * 
	 * @param bakerySearchRequestVO
	 * @param searchCriteria
	 */
	private void setOtherSearchTypes(BakerySearchRequestVO bakerySearchRequestVO,HashMap<String, String> searchCriteria) {
		if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.WHSE_DSD)) {
			searchCriteria.put(PerishableConstants.searchType, PerishableConstants.WHSE_DSD);
		}
		if (bakerySearchRequestVO.getSearchCriteria().endsWith("DISP")) {
			searchCriteria.put(PerishableConstants.searchType, "C.MULTI_COMP_ITEM_IND");
		}
		if (bakerySearchRequestVO.getSearchCriteria().endsWith("TOTAL_SALES")) {
			searchCriteria.put(PerishableConstants.searchType, "TOTAL_SALES");
			if(null!=bakerySearchRequestVO.getTotalSalesOperator()){
				searchCriteria.put("OPERATOR", bakerySearchRequestVO.getTotalSalesOperator());
			}
		}
		
	
		
	}

	
	/**
	 *  Method to map the search criteria details to a search Criteria map
	 * @param searchRequestVO
	 * @return
	 */
	private Map<String, String> createSearchCriteriaMap(BakerySearchRequestVO bakerySearchRequestVO) {
		HashMap<String, String> searchCriteria = new HashMap<String, String>();

		if (null != bakerySearchRequestVO.getCompanyID()
				&& !bakerySearchRequestVO.getCompanyID().isEmpty()) {
			searchCriteria.put("companyID", bakerySearchRequestVO.getCompanyID());
		}
		if (null != bakerySearchRequestVO.getDivisionID()
				&& !bakerySearchRequestVO.getDivisionID().isEmpty()) {
			searchCriteria.put("divisionID", bakerySearchRequestVO.getDivisionID());
		}
		if (null != bakerySearchRequestVO.getMappingStatus()
				&& !bakerySearchRequestVO.getMappingStatus().isEmpty()) {
				searchCriteria.put("mappingStatus",
						bakerySearchRequestVO.getMappingStatus());
		}
		setItemType(bakerySearchRequestVO, searchCriteria);
		setSearchType(bakerySearchRequestVO, searchCriteria);
			if (null != bakerySearchRequestVO.getSearchCriteriaValue()
					&& !bakerySearchRequestVO.getSearchCriteriaValue().isEmpty()){
				if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.PLU_VAL)){
				 searchCriteria.put(PerishableConstants.SEARCH_VAL,"%"+bakerySearchRequestVO.getSearchCriteriaValue().trim());
				}
				else if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL))
				{
					 searchCriteria.put(PerishableConstants.SEARCH_VAL,bakerySearchRequestVO.getSearchCriteriaValue().trim().replaceAll("-", ""));
				}
				else{
					searchCriteria.put(PerishableConstants.SEARCH_VAL,bakerySearchRequestVO.getSearchCriteriaValue().trim());	
				}
			}
		return searchCriteria;
	}

	private void setItemType(BakerySearchRequestVO bakerySearchRequestVO, HashMap<String, String> searchCriteria) {

		if (null != bakerySearchRequestVO.getItemType()) {
			if (bakerySearchRequestVO.getItemType().isAll()) {
				searchCriteria.put(PerishableConstants.itemType, "All");
			}
			if (bakerySearchRequestVO.getItemType().isPlu()) {
				searchCriteria.put(PerishableConstants.itemType, "PLU");
			}
			if (bakerySearchRequestVO.getItemType().isSystem2()) {
				searchCriteria.put(PerishableConstants.itemType, "System2");
			}
			if (bakerySearchRequestVO.getItemType().isSystem4()) {
				searchCriteria.put(PerishableConstants.itemType, "System4");
			}
		}
	
		
	}

	/**
	 * Method to search buyer bakery target CIC items
	 * @param bakerySearchRequestVO
	 * @return
	 * @throws Exception 
	 */

	@Override
	public BakeryResponseVO listBakeryCICItems(BakerySearchRequestVO bakerySearchRequestVO) throws Exception{
		LOG.info("Fetching all listBakeryCICItems");
		final Map<String, String> searchCriteria = createTargetSearchCriteriaMap(bakerySearchRequestVO);
		LOG.debug("Completed fetching all"+searchCriteria.size()+"search Criteria company  records");
		final Map<String, String> filterCriteria = createFilterCriteriaMap(bakerySearchRequestVO);
		LOG.debug("Completed fetching all"+filterCriteria.size()+"filter Criteria company  records");
		
		final String targetTypeIndicator =bakerySearchRequestVO.getTargetTypeIndicator();
		BakeryResponseVO bakeryResponseVO = new BakeryResponseVO();
		
		
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		try
		{ 
					
			Future<BigDecimal> future1 =executorService.submit(new Callable<BigDecimal>() {
			    public BigDecimal call() throws Exception {
			    	 return bakerySQLRepository.countBakeryTargetList(searchCriteria, filterCriteria, targetTypeIndicator);
			        
			    }
			});
	
			Future<List<BakeryCICSearchResults>> future2 =executorService.submit(new Callable<List<BakeryCICSearchResults>>() {
			    public List<BakeryCICSearchResults> call() throws Exception {
			    
			    	
			    	List<Object[]> bakeryCICSearchResults = bakerySQLRepository
							.fetchBakeryTargetList(searchCriteria, filterCriteria, targetTypeIndicator);
			    	LOG.debug("Completed fetching all"+bakeryCICSearchResults.size()+"bakeryCICSearchResults");
					return  bakeryAdapter
							.mapBakeryTargetItem(bakeryCICSearchResults);
			        
			    }
			});
		
			bakeryResponseVO.setTargetCount(future1.get());					
			if(null!=future2.get() && ! future2.get().isEmpty()){
				bakeryResponseVO.setBakeryCicSearchResults(future2.get());
			}
	       		
		}
		catch(InterruptedException | ExecutionException e)
		{
			e.getMessage();
			LOG.error(e.getMessage());
			throw e;
		}
		finally{
		executorService.shutdown();
		}
		LOG.info(" Completed  Fetching for listBakeryCICItems");
		
		return bakeryResponseVO;
	}
	
	/**
	 * Method to retrieve the bakery CIC search results
	 * 
	 * @param searchRequestVO
	 * @return
	 */
	private Map<String, String> createTargetSearchCriteriaMap(
			BakerySearchRequestVO bakerySearchRequestVO) {
		HashMap<String, String> searchCriteria = new HashMap<String, String>();

		if (null != bakerySearchRequestVO.getMappingStatus()
				&& !bakerySearchRequestVO.getMappingStatus().isEmpty() && !"SHOW_ALL".equals(bakerySearchRequestVO.getMappingStatus())) {
			searchCriteria.put("mappingStatus",
					bakerySearchRequestVO.getMappingStatus());
		}
		setItemType(bakerySearchRequestVO, searchCriteria);
		if (null != bakerySearchRequestVO.getSearchCriteria()
				&& !bakerySearchRequestVO.getSearchCriteria().isEmpty()) {
		
            if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
                searchCriteria.put(PerishableConstants.searchType, PerishableConstants.DEPT_NAME);
                setDeptNameFilter(bakerySearchRequestVO, searchCriteria);
          }else{

				setOtherFilter(bakerySearchRequestVO, searchCriteria);
				if(bakerySearchRequestVO.getSearchCriteria().endsWith("DISP")){
					searchCriteria.put(PerishableConstants.searchType, PerishableConstants.CDS_DISP_FLAG);
				}
				if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.USAGE_TYPE)){
					
					searchCriteria.put(PerishableConstants.searchType, PerishableConstants.USAGE_TYPE);
				}
				if(bakerySearchRequestVO.getSearchCriteria().endsWith("WHSE_DSD"))
					{
						searchCriteria.put(PerishableConstants.SEARCH_VAL,bakerySearchRequestVO.getSearchCriteriaValue().substring(0,1));
					}
			   else
					{
						searchCriteria.put(PerishableConstants.SEARCH_VAL,bakerySearchRequestVO.getSearchCriteriaValue());
					}
				}

				
		}
		return searchCriteria;
	}

	/**
	 * @param bakerySearchRequestVO
	 * @param searchCriteria
	 */
	private void setOtherFilter(BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> searchCriteria) {
		if (bakerySearchRequestVO.getSearchCriteria().endsWith("CIC_VAL")) {
			searchCriteria.put(PerishableConstants.searchType, "CIC_VAL");
		}
		if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)) {
			searchCriteria.put(PerishableConstants.searchType, "DESC_ITEM");
		}
		if (bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL)) {
			searchCriteria.put(PerishableConstants.searchType, "UPC_VAL");
		}
		
		if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
			searchCriteria.put(PerishableConstants.searchType, "OMDEPT.DEPT_NAME");
		}
		if(bakerySearchRequestVO.getSearchCriteria().endsWith("ITEM_USAGE")){
			searchCriteria.put(PerishableConstants.searchType, "CDS.ITEM_USAGE_TYPE");
		}
		if(bakerySearchRequestVO.getSearchCriteria().endsWith("DISPLAY")){
			searchCriteria.put(PerishableConstants.searchType, PerishableConstants.CDS_DISP_FLAG);
		}
		if(bakerySearchRequestVO.getSearchCriteria().endsWith("SMIC")){
			searchCriteria.put(PerishableConstants.searchType, "SMIC");
		}
		if(bakerySearchRequestVO.getSearchCriteria().endsWith(PerishableConstants.PLU_VAL)){
			searchCriteria.put(PerishableConstants.searchType, "POS.PLU_CD");
		}
		if(bakerySearchRequestVO.getSearchCriteria().endsWith("WHSE_DSD")){
			searchCriteria.put(PerishableConstants.searchType, "WDS.DST_CNTR");
			
		}
	}

	/**
	 * @param bakerySearchRequestVO
	 * @param searchCriteria
	 */
	private void setDeptNameFilter(BakerySearchRequestVO bakerySearchRequestVO,
			HashMap<String, String> searchCriteria) {
		LOG.debug("Execution started for setDeptNameFilter");
		if (!bakerySearchRequestVO.getSearchCriteriaValue().isEmpty()) {
		       String[] searchValueList = bakerySearchRequestVO
		                     .getSearchCriteriaValue().split(",");
		       StringBuilder searchValue = new StringBuilder();
		       for (String value : searchValueList) {
		              if (searchValue.length() > 0) {
		                     searchValue.append(",");
		              }
		              searchValue.append("'");
		              searchValue.append(value);
		              searchValue.append("'");
		       }
		       searchCriteria.put(PerishableConstants.SEARCH_VAL, searchValue.toString());
		       LOG.debug("Execution completed for setDeptNameFilter");
		}
	}
	
	
	 /**
     * Method to perform mapping action based on mapping option selected
     * 
     *  @param mappingRequest
	 *  @return
     */
    @Override
	public void performAction(BakeryMappingRequestWrapper mappingRequest) {
    	LOG.info("Fetching all company Bakery records");
    	List<BakeryMappingRequest> bakeryMappingRequestBuyer = mappingRequest.getMappingrequestBuyer();
    	
		if (null != mappingRequest.getMappingrequestBuyer() && !mappingRequest.getMappingrequestBuyer().isEmpty()) {			
			
			performMappingAction(bakeryMappingRequestBuyer);			
			
		}
		if (null != mappingRequest.getMappingrequestSeller() && !mappingRequest.getMappingrequestSeller().isEmpty()	)
		{
			
			List<BakeryMappingRequest> bakeryMappingRequestSeller = mappingRequest.getMappingrequestSeller();
			if(!bakeryMappingRequestSeller.get(0).getCic().equals(bakeryMappingRequestBuyer.get(0).getCic()))
			 {
				performMappingAction(bakeryMappingRequestSeller);	
				}	
			
		}
		LOG.info("Completed Fetching and Mapping all company Bakery records");

	}
    
    /**
  	 * @param perishableMappingRequest
  	 */
  	private void performMappingAction(List<BakeryMappingRequest> bakeryMappingRequest) {
  		
  		/*PRODUCE PLU CALL*/
  		LOG.debug("Execution started for performMappingAction");
		HashMap<String, String> productSkuMap=createMapBasedOnProductSku(bakeryMappingRequest);
  		
  		for (BakeryMappingRequest pm : bakeryMappingRequest) {
  			if (!PerishableConstants.FORCE_NEW.equals(pm.getMappingType()) && !PerishableConstants.RESERVED.equals(pm.getMappingType())) {
  				removeFromReservedList(pm);
  				updateStatusForAction(pm,false);
  				ItemConvManualMatchingPlan entity = buildEntity(pm);
  				entity.getItemConvManualMatchingPlanPK().setMatchedItemTypeCd(productSkuMap.get(pm.getSku()));  				
  				itemConvManualMatchingPlanRepository.saveAndFlush(entity);

  			}
  			else if(PerishableConstants.RESERVED.equals(pm.getMappingType()))
			{
				
  				ItemConvManualMatchingPlan  entity =itemConvManualMatchingPlanRepository.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndItemConvManualMatchingPlanPkMatchedItemTypeCdAndMappingTypeAndMappingStatus
						(pm.getCompanyID(), pm.getDivisionID(), pm.getSku(), pm.getUpc(), "E", "ETL_AUTO_MATCH", "UN_MAPPED");
				if(entity!=null)
				{	entity.setMappingStatus(pm.getMappingstatus().trim().toUpperCase());
					entity.setMappingComments(pm.getComments());
					entity.setUpdateTs(new Date());
					entity.setTargetPlu(null);
					
				}
				else
				{
					 entity = buildEntity(pm);
				}
				itemConvManualMatchingPlanRepository.saveAndFlush(entity);
			}
  		}
  		LOG.debug("Execution Completed for performMappingAction");
   	}
  	
  	
  	
  	private void removeFromReservedList(BakeryMappingRequest pm) {
  		LOG.debug("Execution Started for removeFromReservedList");
		
		ItemConvManualMatchingPlan  entity =itemConvManualMatchingPlanRepository.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndMappingType
				(pm.getCompanyID(), pm.getDivisionID(), pm.getSku(), pm.getUpc().replaceAll("-", ""), "RESERVED");
		if(entity!=null)
		{
			itemConvManualMatchingPlanRepository.delete(entity);
		}
		LOG.debug("Execution Completed for removeFromReservedList");
		
	}
  	
  	private void updateFromETLReservedList(BakeryMappingRequest pm) {
  		LOG.debug("Execution Startted for updateFromETLReservedList");
		
		ItemConvManualMatchingPlan  entity =itemConvManualMatchingPlanRepository.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndMappingType
				(pm.getCompanyID(), pm.getDivisionID(), pm.getSku(), pm.getUpc().replaceAll("-", ""), "ETL_AUTO_MATCH");
		if(entity!=null)
		{   entity.setMappingStatus("CORRECTED");
			itemConvManualMatchingPlanRepository.saveAndFlush(entity);
		}
		LOG.debug("Execution Completed for updateFromETLReservedList");
	}

	/**
	 * Service Method to update conversion status in  XREFLAND.SRC_ITEM_XRF table
	 * @param pm
	 */
	private void updateStatusForAction(BakeryMappingRequest bakeryMappingRequest,boolean isUnmap) {
		LOG.debug("Execution Started for updateStatusForAction");
		Object[] inputs =new Object[8];
		
		inputs[0]=bakeryMappingRequest.getCompanyID();
		inputs[1]=bakeryMappingRequest.getDivisionID();
		inputs[2]=bakeryMappingRequest.getSku();
		inputs[3]=bakeryMappingRequest.getUpc().substring(0,1);
        inputs[4]=bakeryMappingRequest.getUpc().substring(1,2);
        inputs[5]=bakeryMappingRequest.getUpc().substring(2,7);
        inputs[6]=bakeryMappingRequest.getUpc().substring(7,12);
        
        inputs[7]=bakeryMappingRequest.getComments();
       
    	if (PerishableConstants.MARK_AS_DEAD.equals(bakeryMappingRequest
				.getMappingType())) {        
	        if(!bakerySQLRepository.checkMarkAsDead(inputs)){
	        	if(bakerySQLRepository.markAsDead(inputs)){
	        		LOG.info("Sucessfully updated as mark as dead");
	        	}else{
	        		LOG.info("mark as dead update failed..");
	        	}
	        }
        }
        
        else if (PerishableConstants.ADD_MAP.equals(bakeryMappingRequest.getMappingType())
				|| PerishableConstants.INHERIT_MAP.equals(bakeryMappingRequest.getMappingType()) ||
				PerishableConstants.FORCE_NEW.equals(bakeryMappingRequest.getMappingType()) || 
				PerishableConstants.LET_AUTO_MATCH.equals(bakeryMappingRequest.getMappingType())) {
    		if(bakerySQLRepository.updateStatusForMappingAction(inputs)){
        		LOG.info("Sucessfully updated");
        	}else{
        		LOG.info("Action failed");
        	}
    		
    	}
      
    	LOG.debug("Execution Completed for updateStatusForAction");
		
	}
  	
  	/**
	 * Method to perform mapping action when Mark as Dead option is chosen
	 * 
	 * @param request
	 */
	private void performMarkAsDeadAction(BakeryMappingRequest request){
		
		Object[] inputs =new Object[8];
		
		inputs[0]=request.getCompanyID();
		inputs[1]=request.getDivisionID();
		inputs[2]=request.getSku();
		inputs[3]=request.getUpc().substring(0,1);
        inputs[4]=request.getUpc().substring(1,2);
        inputs[5]=request.getUpc().substring(2,7);
        inputs[6]=request.getUpc().substring(7,12);
        inputs[7]=request.getComments();
        
        if(!bakerySQLRepository.checkMarkAsDead(inputs)){
        	if(bakerySQLRepository.markAsDead(inputs)){
        		LOG.info("Sucessfully updated");
        	}else{
        		LOG.info("Action failed");
        	}
        }
	}
	
	
	/**
	 * @param pm
	 * @return
	 */
	private ItemConvManualMatchingPlan buildEntity(BakeryMappingRequest pm) {
		LOG.debug("Execution Started for Build entity");
		ItemConvManualMatchingPlan entity = new ItemConvManualMatchingPlan();
		ItemConvManualMatchingPlanPK entityPk = new ItemConvManualMatchingPlanPK();
		entityPk.setCompanyId(pm.getCompanyID());
		entityPk.setDivisionId(pm.getDivisionID());
		entityPk.setProductSKU(pm.getSku());
		entityPk.setUpc(pm.getUpc());
		entityPk.setMatchedItemTypeCd(pm.getTargetTypeIndicator());
		
		entity.setCorpItemCd((pm.getCic() != null && !pm.getCic()
				.equals("")) ? new BigDecimal(pm.getCic())
				: new BigDecimal("0"));
		if (PerishableConstants.MARK_AS_DEAD.equals(pm
				.getMappingType())) {
			entity.setMappingStatus(PerishableConstants.MARK_AS_DEAD);
		} 
		else if(PerishableConstants.LET_AUTO_MATCH.equals(pm.getMappingType())){
			entity.setMappingStatus(PerishableConstants.LET_AUTO_MATCH);	
		}
		else if(PerishableConstants.FORCE_NEW.equals(pm.getMappingType())){
			entity.setMappingStatus(PerishableConstants.FORCE_NEW);	
		}
		else if(PerishableConstants.RESERVED.equals(pm.getMappingType())){
			entity.setMappingType(PerishableConstants.RESERVED);
			entity.setMappingStatus(pm.getMappingstatus());	
			entity.setCorpItemCd(new BigDecimal("0"));
			entityPk.setMatchedItemTypeCd("Y");
			
			
		}
		else {
			entity.setMappingStatus(PerishableConstants.MAPPED);
		}

		entity.setMappingType(pm.getMappingType());
		entity.setMappingComments(pm.getComments());
		entity.setUpdateTs(new Date());
		entity.setUpdateUserId(pm.getUpdatedUserId());
		entity.setTargetPlu(null);
		entity.setItemConvManualMatchingPlanPK(entityPk);
		
		
		if(pm.isTargetEdited())
		{entity.setPackDesc(getStringValue(pm.getDcPackDesc()));
		entity.setSizeDesc(getStringValue(pm.getDcSizeDsc()));
		entity.setRetailUnitPack(getStringValue(pm.getRetailUnitPack()));
		entity.setRing(getStringValue(pm.getRing()));
		entity.setHicone(getStringValue(pm.getHicone()));
		
		/**/
		
		entity.setProdwght(getStringValue(pm.getProdwght()));
		entity.setHandlingCode(getStringValue(pm.getHandlingCode()));
		entity.setBuyerNum(getStringValue(pm.getBuyerNum()));
		entity.setRandomWtCd(getStringValue(pm.getRandomWtCd()));
		entity.setAutoCostInv(getStringValue(pm.getAutoCostInv()));
		entity.setBillingType(getStringValue(pm.getBillingType()));
		entity.setFdStmp(getStringValue(pm.getFdStmp()));
		entity.setTareCd(getStringValue(pm.getTareCd()));
		entity.setLabelSize(getStringValue(pm.getLabelSize()));
		entity.setLabelNumbers(getStringValue(pm.getLabelNumbers()));
		entity.setPrcTypeCd(getStringValue(pm.getPrcTypeCd()));
		entity.setSgnCount1(getStringValue(pm.getSgnCount1()));
		entity.setSgnCount2(getStringValue(pm.getSgnCount2()));
		entity.setSgnCount3(getStringValue(pm.getSgnCount3()));
		entity.setCostAllow(getStringValue(pm.getCostAllow()));
		entity.setCostIb(getStringValue(pm.getCostIb()));
		entity.setCostInv(getStringValue(pm.getCostInv()));
		entity.setCostVend(getStringValue(pm.getCostVend()));
		entity.setSellByDays(getStringValue(pm.getSellByDays()));
		entity.setEatByDays(getStringValue(pm.getUseByDays()));
		entity.setPullByDays(getStringValue(pm.getPullBydays()));
		}
		LOG.debug("Execution Completed for Build entity");
		return entity;
	}
	private String getStringValue(Object obj) {
		if (obj == null)
		{
			return "";
		}
		String str = (String) obj;
		return str.trim();
		
	}
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return  new BigDecimal(obj.toString());
	}
	private Integer getIntegerValue(Object obj){
		if(obj == null)
			return Integer.valueOf(0);
		return Integer.parseInt(obj.toString());
	}
	private HashMap<String, String> createMapBasedOnProductSku(List<BakeryMappingRequest> bakeryMappingRequestList) {
		LOG.debug("Execution Started for createMapBasedOnProductSku");
		HashMap<String, String> map = new HashMap<>();
		for (BakeryMappingRequest pm : bakeryMappingRequestList) {
			String productSku = pm.getSku();
			String upc = StringUtils.leftPad(pm.getUpc().replaceAll("-", ""),12, "0");
			if(pm.getTargetTypeIndicator() !=null && !pm.getTargetTypeIndicator().equals("")){			
			
			
					if(!map.containsKey(productSku)){
						if(
							(pm.getMappingType().equals(PerishableConstants.ADD_MAP) || pm.getMappingType().equals(PerishableConstants.INHERIT_MAP)
							||pm.getMappingType().equals(PerishableConstants.FORCE_NEW))	
								&&
							(Float.parseFloat(upc) < 100000) && pm.getTargetTypeIndicator().equals("S")
								) 
						{
							map.put(productSku, "P");
						}
						else if (pm.getTargetTypeIndicator().equals("E")) {
							map.put(productSku, "E");
						}
						else if (
								pm.getTargetTypeIndicator().equals("B") || pm.getTargetTypeIndicator().equals("S")||pm.getTargetTypeIndicator().equals("F")
								){
							map.put(productSku, pm.getTargetTypeIndicator());
						}
						
						
					}else{
						 if (
								(pm.getMappingType().equals(PerishableConstants.ADD_MAP) || pm.getMappingType().equals(PerishableConstants.INHERIT_MAP)
										||pm.getMappingType().equals(PerishableConstants.FORCE_NEW))	
										&&								
										(Float.parseFloat(upc) < 100000) && pm.getTargetTypeIndicator().equals("S")
											)
						{
							map.put(productSku, "P");
						}
						else if(pm.getTargetTypeIndicator().equals("E") && !map.get(productSku).equals("P"))
						{
							map.put(productSku, "E");
						}
						else if(
								(!map.get(productSku).equals("P") && !map.get(productSku).equals("E") ) &&
								(pm.getTargetTypeIndicator().equals("B") || pm.getTargetTypeIndicator().equals("S")||pm.getTargetTypeIndicator().equals("F") )
								)
						{
							map.put(productSku, pm.getTargetTypeIndicator());
						}
					}
				 
				 
				 
				 
			}
		}
		LOG.debug("Execution Completed for createMapBasedOnProductSku");
		return map;
	}
	
public List<BakeryMappedResultWrapper> listMappedData(BakerySearchRequestVO searchRequestVO){
	LOG.info("Fetching all Mapped data");
		List<BakeryMappedResultWrapper> maddedItems=new ArrayList<BakeryMappedResultWrapper>();
		LOG.debug("Successfully Fetched all "+maddedItems.size()+" Mapped Items");
		String searchCriteria=null;
	     if(null!=searchRequestVO.getSearchCriteria() && !searchRequestVO.getSearchCriteria().isEmpty() && searchRequestVO.getSearchIndicator().equals(PerishableConstants.SOURCE_INDICATOR)){
	    	 searchCriteria = sourceFilterForMappedScreen(searchRequestVO,
					searchCriteria);
	     }
	     else if(null!=searchRequestVO.getSearchCriteria() && !searchRequestVO.getSearchCriteria().isEmpty() && searchRequestVO.getSearchIndicator().equals(PerishableConstants.TARGET_INDICATOR))   {
	    	 searchCriteria = targetFilterForMappedScreen(searchRequestVO,
					searchCriteria);
	     }
      String itemType = setItemTypeFilter(searchRequestVO);
		List<Object[]> mappedObjects= bakerySQLRepository.fetchMappedList(searchRequestVO.getCompanyID(), searchRequestVO.getDivisionID(), searchCriteria, searchRequestVO.getSearchCriteriaValue(),itemType,searchRequestVO.getMappingStatus());
		 LOG.debug("Successfully Fetched all "+mappedObjects.size()+" Mapped Ojects");
		if(null!=mappedObjects && ! mappedObjects.isEmpty()){
			 maddedItems=bakeryAdapter.setMappedItems(mappedObjects);
			
		}
		LOG.info(" Successfully Fetching all Mapped data");
		return maddedItems;
	}

/**
 * @param searchRequestVO
 * @param searchCriteria
 * @return
 */
private String targetFilterForMappedScreen(
		BakerySearchRequestVO searchRequestVO, String searchCriteria) {
	if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.CIC_VAL)) {
		 searchCriteria="M.CORP_ITEM_CD" ;
	 }
	else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)){
		searchCriteria="CDS.DESC_ITEM"; 
	}
	else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DISP)){
		searchCriteria="CDS.DISP_FLAG"; 
	}
	else if(searchRequestVO.getSearchCriteria().endsWith("DST_CNTR")){
		searchCriteria="WDS.DST_CNTR"; 
	}
	return searchCriteria;
}

/**
 * @param searchRequestVO
 * @param searchCriteria
 * @return
 */
private String sourceFilterForMappedScreen(
		BakerySearchRequestVO searchRequestVO, String searchCriteria) {
	if (searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.SKU_VAL)) {
		 searchCriteria="M.PRODUCT_SKU";
	 }    	 
	 else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.ITEM_DESC)){
	    	searchCriteria="C.ITEM_DESC"; 
	 }
	 else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.UPC_VAL)){
		 searchCriteria="M.UPC"; 
	 }
	else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DISP)){
		searchCriteria="C.MULTI_COMP_ITEM_IND"; 
	}
	else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.WHSE)){
		searchCriteria="C.SOURCE_BY_WHSE"; 
	}
	else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DSD)){
		searchCriteria="C.SOURCE_BY_DSD"; 
	}
	else if(searchRequestVO.getSearchCriteria().endsWith(PerishableConstants.DEPT_NAME)){
		searchCriteria="C.PROD_HIERARCHY_LVL_4_CD"; 
	}
	return searchCriteria;
}

/**
 * @param searchRequestVO
 * @return
 */
private String setItemTypeFilter(BakerySearchRequestVO searchRequestVO) {
	String itemType=null;
		if (null != searchRequestVO.getItemType()) {
			if (searchRequestVO.getItemType().isAll()) {
				itemType= PerishableConstants.ALL;
			}
			if (searchRequestVO.getItemType().isPlu()) {
				itemType= PerishableConstants.PLU;
			}
			if (searchRequestVO.getItemType().isSystem2()) {
				itemType= PerishableConstants.SYSTEM_2;
			}
			if (searchRequestVO.getItemType().isSystem4()) {
				itemType= PerishableConstants.SYSTEM_4;
			}
		}
	return itemType;
}


@Override
public List<String> duplicateCheckOnMappedItems(
		List<BakeryMappingRequest> bakeryMappingRequests) {
	LOG.info("Fetching all duplicateCheckOnMappedItems");
	List<String> duplicateMappings = new ArrayList();
	
	for (BakeryMappingRequest pm : bakeryMappingRequests) {
			Object[] inputs =new Object[5];
				
			inputs[0]=pm.getCompanyID();
			inputs[1]=pm.getDivisionID();
			inputs[2]=pm.getSku();
			inputs[3]=pm.getUpc();
			inputs[4]=pm.getTargetTypeIndicator();
			
			if(bakerySQLRepository.checkDuplicateExistence(inputs))
			{
				duplicateMappings.add("This particualar SKU "+pm.getSku()+" already mapped to a CIC with this matched item");
			}
			
		/*	
		 * if(pm.getCic()!=null && !pm.getCic().equals("") &&
					bakerySQLRepository.checkAlreadyMappedCIC(pm.getCic(),pm.getTargetTypeIndicator())	)
			{
				duplicateMappings.add("This particualar CIC "+pm.getCic()+" already mapped as a "
											+(pm.getTargetTypeIndicator() == "S" ? "Seller" : "Buyer"));
			}*/
			LOG.info("Completed Fetching all"+duplicateMappings.size()+" duplicateCheckOnMappedItems");	
		}
	
	return duplicateMappings;
}

@Override
public String saveForceNewInPerishableMapping(
		List<BakeryMappingRequest> bakeryMappingRequests
		) {
	LOG.info("Started execution for inserting ForceNewInPerishableMapping ");
	if(bakeryMappingRequests!=null && !bakeryMappingRequests.isEmpty())
	{
		/*PRODUCE PLU CALL*/
		HashMap<String, String> productSkuMap=createMapBasedOnProductSku(bakeryMappingRequests);
		LOG.debug("completd fetching"+productSkuMap.size()+ "productSkuMap");
		for(BakeryMappingRequest bakeryMappingRequest : bakeryMappingRequests)
		{
			/*Reserve action changes*/
			removeFromReservedList(bakeryMappingRequest);
			updateFromETLReservedList(bakeryMappingRequest);
			updateForceNewInPerishableMapping(bakeryMappingRequest);
			ItemConvManualMatchingPlan entity = new ItemConvManualMatchingPlan();
			ItemConvManualMatchingPlanPK entityPk = new ItemConvManualMatchingPlanPK();
			entityPk.setCompanyId(bakeryMappingRequest.getCompanyID());
			entityPk.setDivisionId(bakeryMappingRequest.getDivisionID());
			entityPk.setProductSKU(bakeryMappingRequest.getSku());
			entityPk.setUpc(bakeryMappingRequest.getUpc().replaceAll("-", ""));
			if(productSkuMap.containsKey(bakeryMappingRequest.getSku()))
			{
				entityPk.setMatchedItemTypeCd(productSkuMap.get(bakeryMappingRequest.getSku()));	
			}
			else
			{
				entityPk.setMatchedItemTypeCd("F");
			}
			entity.setItemConvManualMatchingPlanPK(entityPk);
			entity.setMappingStatus(PerishableConstants.FORCE_NEW);
			entity.setMappingType(PerishableConstants.FORCE_NEW);
			entity.setMappingComments(bakeryMappingRequest.getComments());
			entity.setUpdateTs(new Date());
			entity.setCorpItemCd(new BigDecimal("0"));
			entity.setUpdateUserId(bakeryMappingRequest.getUpdatedUserId());
			entity.setTargetPlu(null);
			itemConvManualMatchingPlanRepository.saveAndFlush(entity);
			LOG.info("Successfully inserted");
		}
	}
	
	return "Successfully inserted";
}

public Map<String, String> createNewCic(List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
	LOG.info("Started execution for createNewCic ");
	HashMap<String, String> response = new HashMap<String, String>();
	insertRecordToUIExceptionSrc(displayItemCreateMatchCicDto);
	response.put("Result", " New CIC created successfully");
	LOG.info("completed execution for "+response.size()+" createNewCic ");
	return response;
}




private void insertRecordToUIExceptionSrc(List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
	
	LOG.debug("Started execution for inserting RecordToUIExceptionSrc ");
	if (displayItemCreateMatchCicDto != null && !displayItemCreateMatchCicDto.isEmpty()) {
		for (DisplayItemCreateMatchCicDto header : displayItemCreateMatchCicDto) {
			List<String> upcListCorp = bakerySQLRepository.fetchUpcList(
					header.getCompanyId(), header.getDivisionId(),header.getProductSku());
			LOG.debug("completd fetching"+upcListCorp.size()+ "upcListCorp");
				boolean isInserted = false;
				if (!upcListCorp.isEmpty()) {
					int i=0;
					for (String corpUpc : upcListCorp) {
						List<ItemAggregateCorp> sourceObjs = itemAggregateRepo
									.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
											header.getProductSku(),header.getDivisionId(),header.getCompanyId(),corpUpc);
						LOG.debug("completd fetching"+sourceObjs.size()+ "sourceObjs");
								UIExceptionSrc excSrc = new UIExceptionSrc();
								UiExceptionSrcPk excSrcPk = new UiExceptionSrcPk();
								setUIExceptionSrc(header, corpUpc, excSrc,excSrcPk);
								for (ItemAggregateCorp itemAggregateCorp : sourceObjs) {
									setExcSrc(excSrc, excSrcPk,itemAggregateCorp);
								}
								excSrc.setUiSrcPk(excSrcPk);
								exSrcRepo.save(excSrc);
								isInserted = true;
								i++;
								if (i == 1) {
									break;
								}
					}
				}
				if (isInserted)
					break;
		}
	}
	LOG.debug("Completed execution for inserting RecordToUIExceptionSrc ");
}

/**
 * @param excSrc
 * @param excSrcPk
 * @param itemAggregateCorp
 */
private void setExcSrc(UIExceptionSrc excSrc, UiExceptionSrcPk excSrcPk,
		ItemAggregateCorp itemAggregateCorp) {
	excSrc.setPrdHierLevel1((itemAggregateCorp.getPrdHierLevel1()));
	excSrc.setPrdHierLevel2((itemAggregateCorp.getPrdHierLevel2()));
	excSrc.setPrdHierLevel3((itemAggregateCorp.getPrdHierLevel3()));
	excSrc.setPrdHierLevel4((itemAggregateCorp.getPrdHierLevel4()));
	excSrc.setPrdHierLevel5((itemAggregateCorp.getPrdHierLevel5()));

	excSrc.setSizeNmbr(itemAggregateCorp.getSizeNmbr());
	excSrc.setSizeUom(itemAggregateCorp.getSizeUom());
	excSrc.setSizeDesc(itemAggregateCorp.getSizeDesc());
	excSrc.setItmDesc(itemAggregateCorp.getItemDesc());
	excSrc.setPrmyUpcInd(itemAggregateCorp.getPrimaryUpcInd());
	
	excSrc.setPtLabelInd(itemAggregateCorp.getPrivateLevelInd());
	excSrc.setLogicalInd(itemAggregateCorp.getLogicalDelInd());
	excSrc.setBatchId(itemAggregateCorp.getBatchId().intValue());
	excSrc.setIntenetItemDesc(itemAggregateCorp.getInternetDesc());
	excSrc.setWhseItmDesc(itemAggregateCorp.getWhseItemDesc());
	
	if (itemAggregateCorp.getSrcByDsd()
			.equals("Y")) {
		excSrcPk.setProductSrcCd("DSD");
	}
	if (itemAggregateCorp.getSrcByWhse()
			.equals("Y")) {
		excSrcPk.setProductSrcCd("WHSE");
	}
	
	if(itemAggregateCorp.getMaterialItemInd().equals('Y') &&
			itemAggregateCorp.getExpenseItemInd().equals('N')	
			)
	{
		excSrc.setItemUsgeInd('M');
		excSrc.setItemUsageTypInd('M');
	}
	else if(itemAggregateCorp.getMaterialItemInd().equals('N') &&
			itemAggregateCorp.getExpenseItemInd().equals('Y')	
			)
	{
		excSrc.setItemUsgeInd('E');
		
	}
	else if(itemAggregateCorp.getMaterialItemInd().equals('N') &&
			itemAggregateCorp.getExpenseItemInd().equals('N') 
			)
	{
		excSrc.setItemUsgeInd('R');
		excSrc.setItemUsageTypInd('R');
	}
}

/**
 * @param header
 * @param corpUpc
 * @param excSrc
 * @param excSrcPk
 */
private void setUIExceptionSrc(DisplayItemCreateMatchCicDto header,
		String corpUpc, UIExceptionSrc excSrc, UiExceptionSrcPk excSrcPk) {
	excSrcPk.setCompanyId(header.getCompanyId());
	excSrcPk.setDivisionId(header
			.getDivisionId());
	excSrcPk.setProductSKU(header
			.getProductSku());
	excSrcPk.setUpcCountry(corpUpc.substring(0,1));
	excSrcPk.setUpcSystem(corpUpc.substring(1,2));
	excSrcPk.setUpcManufacturer(corpUpc.substring(2,7));
	excSrcPk.setUpcSales(corpUpc.substring(7,12));
	excSrc.setCaseUPC(header.getCaseUpc());
	excSrc.setExcptnTypeCd('A');
	excSrc.setExcptionDesc("Augmentation");
	excSrc.setExcptnProcessdInd('N');
	excSrc.setDispFlag(header.getDisplayFlag());
	excSrc.setUpdatedUserID(header
			.getUpdatedUserId());
	excSrc.setCost(header.getCost().floatValue());
	excSrc.setPackwhse(header.getPack());
	excSrc.setVendConvFactor(header
			.getVendorConvFactor());
	//excSrc.setItemUsgeInd('R');
	//excSrc.setItemUsageTypInd('R');
}

	@Override
	public String updateForceNewInPerishableMapping(BakeryMappingRequest bakeryMappingRequest) {
		LOG.info("Updating ForceNewInPerishableMapping ");

		boolean update = bakerySQLRepository.updateForceNewMappingStatus(bakeryMappingRequest.getCompanyID(),
				bakeryMappingRequest.getDivisionID(), bakeryMappingRequest.getSku(), PerishableConstants.FORCE_NEW,
				PerishableConstants.FORCE_NEW);
		
		if (update) {
			LOG.info("Successfully updated");
			return "Successfully updated";
		} else {
			return "updation failed";
		}
	}

	@Override
	public List<BakeryCICSearchResults> getSuggestedTargetList(
			PerishableMatchingTargetInputVO upcDetails) {
		LOG.info("Fetching all SuggestedTargetList");
		List<Object[]> cicList = bakeryAdditionalSQLRepository.loadCICSuggestions(upcDetails.getUpcs());
		LOG.debug("Completed fetching all"+cicList.size()+"cicList");
		if(null != cicList &&!cicList.isEmpty())
		{
		List<Object[]> bakeryCICSearchResults =bakeryAdditionalSQLRepository.fetchMatchingCICdetails(cicList,upcDetails.getWhseDsd());
		List<Object[]> sortedbakeryCICSearchResults = sortedList(cicList,bakeryCICSearchResults);
		LOG.debug("Completed fetching all"+sortedbakeryCICSearchResults.size()+"sortedbakeryCICSearchResults");
		LOG.info("Completed Fetching all SuggestedTargetList");
		return bakeryAdapter.mapBakeryTargetItem(sortedbakeryCICSearchResults);
		}
		else
			return null;
		
		
	}
	private List<Object[]> sortedList(List<Object[]> cicList,List<Object[]> bakeryCICSearchResults) {
		List<Object[]> sortedbakeryCICSearchResults = new ArrayList();
		
		
		if(null != bakeryCICSearchResults && !bakeryCICSearchResults.isEmpty()) {
			for (Object[] cicObj : cicList) {
				for (Object[] cicListObj : bakeryCICSearchResults) {
					if (cicObj[0].equals(cicListObj[0])) {
						sortedbakeryCICSearchResults.add(cicListObj);
						break;
					}

				}
			}
				
		}
		
		return sortedbakeryCICSearchResults;
	}
	
	@Override
	public PerishableAdditionalDetailsDto getadditionalRetailscanDetails(
			String corpItemCd) {
		
		LOG.info("Fetching all company records");
		Map resultMap =bakeryAdditionalSQLRepository.fetchAdditonalRetailScandetails(corpItemCd);
		LOG.info("Completed fetching all"+resultMap.size()+"Company records");
		
		return bakeryAdapter.setAddtionalDetailsForRetail(resultMap);
		
	}
	
	@Override
	public Map  fetchTargetEditITems(ManualMatchAdtnlFieldLoadInputVo inputVo) {
		LOG.info("Fetching all fetchTargetEditITems");
		Map addtionalResult =new HashMap<String,ManualMapAdditionalLoadDto>();
		ManualMapAdditionalLoadDto buyDto;
		ManualMapAdditionalLoadDto sellDto;
	
		List  buyResult=bakeryAdditionalSQLRepository.loadTargetFieldsForMapEdit(inputVo.getBuyingCic(),inputVo.getCompanyId(), inputVo.getDivisionId());
		LOG.debug("Completed fetching all"+buyResult.size()+"Company records");
		List<Object[]> skuWeightList = new ArrayList();
		if(inputVo.getWhseDsd()!=null && inputVo.getWhseDsd().trim().equalsIgnoreCase("WHSE"))
		{
			skuWeightList =bakeryAdditionalSQLRepository.loadSourceItemForEdit(inputVo.getCompanyId(), inputVo.getDivisionId(), inputVo.getProductSKUs());
					
		}
		else
		{
			for(String sku:inputVo.getProductSKUs())
			{
				Object[] obj= new Object[2];
				obj[0] =sku;
				obj[1]="0.01";
				skuWeightList.add(obj);
			}
		}
		buyDto=bakeryAdapter.setOnMatchEditDto(buyResult,skuWeightList);
		
		
		addtionalResult.put("buyDto", buyDto);		
		if(inputVo.getSellingCic() !=null && !inputVo.getBuyingCic().equals(inputVo.getSellingCic()))
		{
			LOG.info("Fetching all addtionalResult");
			List  sellResult=bakeryAdditionalSQLRepository.loadTargetFieldsForMapEdit(inputVo.getSellingCic(),inputVo.getCompanyId(), inputVo.getDivisionId());
			sellDto=bakeryAdapter.setOnMatchEditDto(sellResult,skuWeightList);
			addtionalResult.put("sellDto", sellDto);
			LOG.info("Successfully Fetched all addtionalResult");
		}
		LOG.info("Completed Fetching all fetchTargetEditITems");
		return addtionalResult;
	}
	

   }