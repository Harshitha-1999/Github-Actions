package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

public class DisplayItemSourceSimsItems {

	private List<DisplayItemSourceUPC> displayItemSourceUPC;
	private List<DisplaySimsLikeItems> displaySimsLikeItems;
	public List<DisplayItemSourceUPC> getDisplayItemSourceUPC() {
		return displayItemSourceUPC;
	}
	public void setDisplayItemSourceUPC(
			List<DisplayItemSourceUPC> displayItemSourceUPC) {
		this.displayItemSourceUPC = displayItemSourceUPC;
	}
	public List<DisplaySimsLikeItems> getDisplaySimsLikeItems() {
		return displaySimsLikeItems;
	}
	public void setDisplaySimsLikeItems(
			List<DisplaySimsLikeItems> displaySimsLikeItems) {
		this.displaySimsLikeItems = displaySimsLikeItems;
	}
	
	@Override
	public String toString() {
		return "DisplayItemSourceSimsItems [displayItemSourceUPC="
				+ displayItemSourceUPC + ", displaySimsLikeItems="
				+ displaySimsLikeItems + "]";
	}
	
}
