/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.domain.services;

/* ***************************************************************************
 * NAME         : CompanyService 
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 May 09, 2017  -  Initial Creation
 *
 ***************************************************************************/

import java.util.List;

import com.safeway.app.memi.domain.dtos.response.CompanyDto;

/**
 * 
 * Interface definition for Company services
 *
 */
public interface CompanyService {

    /**
     * Method to fetch Company List
     */
    public List<CompanyDto> getAllItems();

}
