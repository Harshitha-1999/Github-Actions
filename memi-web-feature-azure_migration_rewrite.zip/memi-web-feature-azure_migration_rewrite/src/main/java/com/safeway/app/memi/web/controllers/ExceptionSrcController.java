/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

/* ***************************************************************************
 * NAME         : ExceptionSrcController 
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 May 3, 2017  -  Initial Creation
 *
 ***************************************************************************/

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.data.entities.SizeUOMDetail;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.DepartmentDto;
import com.safeway.app.memi.domain.dtos.response.ExcelFileRequest;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.services.ExceptionSrcService;
import com.safeway.app.memi.domain.services.FileUploadService;
import com.safeway.app.memi.domain.services.NewItemDetailService;
import com.safeway.app.memi.domain.util.ExceptionReportWritter;

/**
 * 
 * REST service controller class for Exceptions Records
 * 
 */
@Controller
@RequestMapping("/exsrc")
public class ExceptionSrcController {
	private static final Logger LOG = LoggerFactory
			.getLogger(ExceptionSrcController.class);

	@Autowired
	private ExceptionSrcService exceptionSrcService;

	@Autowired
	private ExceptionReportWritter reportWritter;

	@Autowired
	private NewItemDetailService newItemDetailService;
	
	@Autowired
	private FileUploadService fileUploadService;
	
	/**
	 * Method to load exceptions
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ResponseEntity<List<UIExceptionSrcDto>> getExceptionSrcList() {
		LOG.info("Fetching Exception records.");
		List<UIExceptionSrcDto> response = exceptionSrcService.getAllItems();
		LOG.debug("Completed fetching for "+response.size()+" Exception records.");
		LOG.info("Completed fetching for "+response.size()+" Exception records.");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * Method to list division
	 */
	@RequestMapping(value = "/division/{division}", method = RequestMethod.GET)
	public ResponseEntity<List<UIExceptionSrcDto>> getExceptionSrcForDivision(
			@PathVariable("division") String divId) {
		LOG.info("Fetching Division records.");
		List<UIExceptionSrcDto> response = exceptionSrcService
				.findByDivision(divId);
		LOG.info("Completed Fetching for "+response.size()+" Division records.");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * Method to get product details
	 */
	@RequestMapping(value = "/sku/{productSKU}", method = RequestMethod.GET)
	public ResponseEntity<UIExceptionSrcDto> getExceptionSrcForUPC(
			@PathVariable("productSKU") String productSKU) {
		LOG.info("Fetching Product SKU.");
		UIExceptionSrcDto response = exceptionSrcService
				.findByProductSKU(productSKU);
		LOG.info("Completed fetching for  Product SKU.");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/downloadExcel/{company}/{division}/{department}/{exceptionType}/{status}", method = RequestMethod.GET)
	public void getReportFile(HttpServletRequest request,
			HttpServletResponse response,
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("department") String department,
			@PathVariable("exceptionType") char exceptionType,
			@PathVariable("status") char status) {
		LOG.info("Downloading excel sheet : ");
		
		String dataDirectory = request.getSession().getServletContext()
				.getRealPath("/");
		String departmentName = reportWritter.createExceptionReportSheet(dataDirectory, department, company, division, exceptionType, status);
		Path file = Paths.get(dataDirectory, "Exceptions.xlsx");
		if (Files.exists(file)) {
			response.setContentType("application/vnd.ms-excel");
			response.addHeader("Content-Disposition", "attachment; filename="
					+ "Exceptions_"+departmentName+".xlsx");
			try {
				Files.copy(file, response.getOutputStream());
				response.getOutputStream().flush();
				try {
				    Files.delete(file);
				} catch (NoSuchFileException x) {
					LOG.error("No such file.");
				} catch (DirectoryNotEmptyException x) {
					LOG.error("No such directory.");
				} catch (IOException x) {
					LOG.error(x.getMessage());
				}
			} catch (IOException ex) {
				LOG.error(ex.getMessage());
			}
		}
		LOG.info("Completed Downloading excel sheet : ");
		request.getSession().invalidate();
	}
	

	@RequestMapping(value = "/listOverRideData/{company}/{division}", method = RequestMethod.GET)
	public ResponseEntity<List<UIDataVO>> getExceptionSrcList(
			@PathVariable("company") String company,
			@PathVariable("division") String division) {

		LOG.info("Fetching Override records.");

		List<UIDataVO> response = exceptionSrcService.getDepartmentWiseData(company,
				division, 'O');
		LOG.info("Completed Fetching for "+response.size()+"Override records.");

		return new ResponseEntity<>(response, HttpStatus.OK);

	}
	
	@RequestMapping(value = "/loadProductSKUs/{company}/{division}/{department}/{exceptionType}/{status}/{type}", method = RequestMethod.GET)
	public ResponseEntity<List<String>> getExceptionSKUList(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("department") String department,
			@PathVariable("exceptionType") char exceptionType,
			@PathVariable("status") char status,
			@PathVariable("type") char type) {

		LOG.info("Fetching oadProductSKUList.");

		List<String> response = exceptionSrcService.loadProductSKUList(company,
				division, department, exceptionType, status, type);

		List<String> finalResponse = new ArrayList<>();
		for(String result : response) {
			result = Encode.forJava(result);
			finalResponse.add(result);
		}
		
		LOG.info("Completed Fetching for {} oadProductSKUList.", response.size());

		return new ResponseEntity<>(finalResponse, HttpStatus.OK);

	}

	@RequestMapping(value = "/listAugData/{company}/{division}", method = RequestMethod.GET)
	public ResponseEntity<List<UIDataVO>> getExceptionSrcAugList(
			@PathVariable("company") String company,
			@PathVariable("division") String division) {

		LOG.info("Fetching Augmentation records.");

		List<UIDataVO> response = exceptionSrcService.getDepartmentWiseData(company,
				division, 'A');

		LOG.info("Completed Fetching "+response.size()+" Augmentation records.");

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@RequestMapping(value = "/loadData/{company}/{division}/{productsku}", method = RequestMethod.GET)
	public ResponseEntity<AugDataVo> loadItemDetail(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("productsku") String productsku) {
		LOG.info("Fetching Division specific records.");

		AugDataVo response = exceptionSrcService.loadItemData(company,
				division, productsku);

		LOG.info("Completed Fetching Division specific records.");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/loadDataByUpc/{company}/{division}/{sourceUpc}", method = RequestMethod.GET)
	public ResponseEntity<AugDataVo> loadItemDetailbyUpc(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("sourceUpc") String sourceUpc) {
		LOG.info("Fetching UPC specific records.");

		AugDataVo response = exceptionSrcService.loadItemDataByUPC(company,
				division, sourceUpc);

		LOG.info("Completed Fetching UPC specific records.");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/loadOverrideData/{company}/{division}/{productsku}", method = RequestMethod.GET)
	public ResponseEntity<OverrideDataVo> loadOverrideItemDetail(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("productsku") String productsku) {
		LOG.info("Fetching Override item details.");

		OverrideDataVo response = exceptionSrcService.loadOverrideItemData(
				company, division, productsku);

		LOG.info("Completed Override item details");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/loadOverrideDataByUPC/{company}/{division}/{sourceUpc}", method = RequestMethod.GET)
	public ResponseEntity<OverrideDataVo> loadOverrideItemDetailByUPC(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("sourceUpc") String sourceUpc) {
		LOG.info("Fetching Override item details.");

		OverrideDataVo response = exceptionSrcService
				.loadOverrideItemDataByUPC(company, division, sourceUpc);

		LOG.info("Completed fetching Override item details.");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/onhandStatus/{company}/{division}/{productsku}", method = RequestMethod.GET)
	public ResponseEntity<String> getOnhandStatus(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("productsku") String productsku) {
		LOG.info("Fetching OnhandStatus.");

		String onhandStatus = exceptionSrcService.getOnhandStatus(
				company, division, productsku) ? "true" : "false";

		LOG.info("Completed fetching OnhandStatus.");

		return new ResponseEntity<>(onhandStatus, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/UOM/list", method = RequestMethod.GET)
	public ResponseEntity<List<SizeUOMDetail>> loadUOMList() {
		LOG.info("Fetching UOM codes.");

		List<SizeUOMDetail> response = exceptionSrcService.getUOMCodes();

		LOG.info("Completed Fetching for "+response.size()+"UOM codes.");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/department/list/{company}/{division}", method = RequestMethod.GET)
	public ResponseEntity<List<DepartmentDto>> loadDepartmentList(
			@PathVariable("company") String company,
			@PathVariable("division") String division) {
		LOG.info("Fetching department lists.");

		List<DepartmentDto> response = exceptionSrcService.getDepartmentDetails(company, division);
		LOG.debug("Completed Fetching for "+response.size()+" UOM codes.");

		
		LOG.info("Completed Fetching department lists.");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	/**
     * Method to Save New CIC Records for Augmentation Screen
     */
    @RequestMapping(value = "/exception", method = RequestMethod.POST)
    public  ResponseEntity<UIExceptionSrcDto> updateDepartment(HttpServletRequest request, @RequestBody String itemDetails) {
        LOG.info("Request Received, JSON String to save ");
        UIExceptionSrcDto exception = new UIExceptionSrcDto();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
        	exception = (UIExceptionSrcDto) mapper.readValue(itemDetails, UIExceptionSrcDto.class);
        }
        catch (IOException e) {
        	LOG.error("Failed to parse JSON.");
        	LOG.error(e.getMessage());
        }
       
        if(exception != null)
        {
           exceptionSrcService.saveException(exception);
           exceptionSrcService.saveItemAggregateCorp(exception);
        }
        
        LOG.info(" completed Fetching department lists.");
        return new ResponseEntity<>(exception, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody  Map uploadFileHandler(@RequestParam("file") MultipartFile uploadedExcelfile,@RequestParam("companyId") String companyId,
			@RequestParam("divisionId") String divisionId,@RequestParam("divisionName") String divisionName,
			@RequestParam("deptName") String deptName,@RequestParam("deptCode") String deptCode, @RequestParam("userId") String userId) throws Exception {
    	LOG.info("Execution started for excel file upload.");
    	String response = fileUploadService.uploadExcel(new ExcelFileRequest(companyId,divisionId,divisionName,deptName,deptCode,userId,uploadedExcelfile));
    	
    	Map<String,String> responseStatus =new HashMap<>();
    	responseStatus.put("status",response);
    	LOG.info("Execution completed for for excel file upload.");
		return responseStatus;
	}
}