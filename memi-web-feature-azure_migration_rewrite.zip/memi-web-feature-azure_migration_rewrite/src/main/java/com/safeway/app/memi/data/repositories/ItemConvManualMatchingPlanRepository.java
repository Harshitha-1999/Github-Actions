package com.safeway.app.memi.data.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlan;
@Repository
public interface ItemConvManualMatchingPlanRepository extends JpaRepository<ItemConvManualMatchingPlan, Long> {

    @Query
    ItemConvManualMatchingPlan  findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndItemConvManualMatchingPlanPkMatchedItemTypeCdAndMappingTypeAndMappingStatus(String companyId,String divisionId,String productSKU, String upc,String matchedItemTypeCd, String mappingType ,String mappingStatus); 

    @Query
    ItemConvManualMatchingPlan  findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndMappingType(String companyId,String divisionId,String productSKU, String upc, String mappingType ); 


}
