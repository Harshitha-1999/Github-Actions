package com.safeway.app.memi.data.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.SourceItemCIC;
import com.safeway.app.memi.data.entities.SourceItemCICPk;

@Repository
public interface SourceItemRepository extends JpaRepository<SourceItemCIC, SourceItemCICPk> {
    
}
