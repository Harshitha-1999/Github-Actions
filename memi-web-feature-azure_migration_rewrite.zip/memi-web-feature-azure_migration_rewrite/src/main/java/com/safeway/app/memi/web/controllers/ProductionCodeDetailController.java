package com.safeway.app.memi.web.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.safeway.app.memi.domain.dtos.response.ProductionCodeDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.services.ProductionCodeService;

@Controller
@RequestMapping("/prdctnCd")
public class ProductionCodeDetailController {
	 private static final Logger LOG = LoggerFactory.getLogger(ProductionCodeDetailController.class);
	 
	 @Autowired
	 private ProductionCodeService productionCodeService;
	 
	 @RequestMapping(value = "/detail/{grpCd}/{ctgryCd}/{clsCd}/{sbClsCd}/{subSbClass}", method = RequestMethod.GET)
	    public ResponseEntity<List<ProductionCodeDetailDto>> getSmicDetails(@PathVariable("grpCd") String grpCd, 
	    		@PathVariable("ctgryCd") String ctgryCd,
	    		@PathVariable("clsCd") String clsCd,
	    		@PathVariable("sbClsCd") String sbClsCd,
	    		@PathVariable("subSbClass") String subSbClass) {
		 LOG.info("Started Fetching all the SMIC records.");
	    	String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
			String categoryCd = ctgryCd != null && ctgryCd.length() > 0 ? ctgryCd : "0";
			String classCd = clsCd != null && clsCd.length() > 0 && !clsCd.equalsIgnoreCase("null") ? clsCd : "0";
			String subClassCd = sbClsCd != null && sbClsCd.length() > 0 && !sbClsCd.equalsIgnoreCase("null") ? sbClsCd : "0";
			String subSubClassCd = subSbClass != null && subSbClass.length() > 0 && !subSbClass.equalsIgnoreCase("null") ? subSbClass : "0";
	        List<ProductionCodeDetailDto> response = productionCodeService.getProductionCode(groupCd, categoryCd, classCd, subClassCd, subSubClassCd);
	        LOG.info("Completed Fetching all the SMIC records.");
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
	    
	    @RequestMapping(value = "/prdctnCdDetail", method = RequestMethod.GET)
	    public ResponseEntity<List<SmicCodeDescWrapper>> getGroupCodeList() {
	    	LOG.info("Started fetching group code onload ");
	    	List<SmicCodeDescWrapper> response = productionCodeService.getProductionGroupCode();
	        LOG.info("Completed fetching group code onload");
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
	   
	    @RequestMapping(value = "/prdctnCdDetail/{prdctnGrpCd}", method = RequestMethod.GET)
	    public ResponseEntity<List<SmicCodeDescWrapper>> getCategoryCodeList(
	    		@PathVariable("prdctnGrpCd") String grpCd) {
	    	LOG.info("Started fetching category code based on group code");
	    	 String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
	    	 List<SmicCodeDescWrapper> response = productionCodeService.getProductionCategoryCode(groupCd);
	    	 LOG.info("Completed fetching category code based on group code");
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
	    
	    @RequestMapping(value = "/prdctnCdDetail/{prdctnGrpCd}/{prdctnCtgryCd}", method = RequestMethod.GET)
	    public ResponseEntity<List<SmicCodeDescWrapper>> getClassCodeList(
	    		@PathVariable("prdctnGrpCd") String grpCd,
	    		@PathVariable("prdctnCtgryCd") String ctgryCd
	    		) {
	    	LOG.info("Started fetching class code based on group & category code");
	    	String groupCd =  grpCd != null && grpCd.length() > 0 ? grpCd : "0";
			String categoryCd = ctgryCd != null && ctgryCd.length() > 0 ? ctgryCd : "0";
			List<SmicCodeDescWrapper> response = productionCodeService.getProductionClassCode(groupCd, categoryCd);
	    	LOG.info("Completed fetching class code based on group & category code");
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
}
