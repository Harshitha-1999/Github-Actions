package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Entity class for Database table ITEM_AGGREGATE_CORP.
 * 
 */
@Entity
@Table(name = "ITEM_AGGREGATE_CORP", schema = "ECFLAND")
@NamedQuery(name = "ItemAggregateCorp.findAll", query = "SELECT s FROM ItemAggregateCorp s")
public class ItemAggregateCorp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ItemAggregateCorpPk itemAggregateCorpPk;

	@Column(name = "PROD_HIERARCHY_LVL_1_CD")
	private String prdHierLevel1;

	@Column(name = "PROD_HIERARCHY_LVL_2_CD")
	private String prdHierLevel2;

	@Column(name = "PROD_HIERARCHY_LVL_3_CD")
	private String prdHierLevel3;

	@Column(name = "PROD_HIERARCHY_LVL_4_CD")
	private String prdHierLevel4;

	@Column(name = "PROD_HIERARCHY_LVL_5_CD")
	private String prdHierLevel5;

	@Column(name = "SOURCE_BY_WHSE")
	private String srcByWhse;

	@Column(name = "SOURCE_BY_DSD")
	private String srcByDsd;

	@Column(name = "SIZE_NBR")
	private BigDecimal sizeNmbr;

	@Column(name = "SIZE_UOM_CD")
	private String sizeUom;

	@Column(name = "SIZE_DESC")
	private String sizeDesc;

	@Column(name = "ITEM_DESC")
	private String itemDesc;
	
	@Column(name = "WAREHOUSE_ITEM_DESC")
	private String whseItemDesc;
	
	@Column(name = "INTERNET_DESC")
	private String internetDesc;
	
	@Column(name = "PRIVATE_LABEL_IND")
	private Character privateLevelInd;
	
	@Column(name = "BATCH_ID")
	private BigDecimal batchId;
	
	@Column(name = "LOGICAL_DEL_IND")
	private Character logicalDelInd;
	
	@Column(name = "PRIMARY_UPC_IND")
	private Character primaryUpcInd;
	
	@Column(name = "EXPENSE_ITEM_IND")
	private Character expenseItemInd;
	
	@Column(name = "MATERIAL_ITEM_IND")
	private Character materialItemInd;
	
	@Column(name = "STORE_CREATED_ITEM_IND")
	private Character storeCreatedItemInd;
	
	
	

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getWhseItemDesc() {
		return whseItemDesc;
	}

	public void setWhseItemDesc(String whseItemDesc) {
		this.whseItemDesc = whseItemDesc;
	}

	public String getInternetDesc() {
		return internetDesc;
	}

	public void setInternetDesc(String internetDesc) {
		this.internetDesc = internetDesc;
	}

	public Character getPrivateLevelInd() {
		return privateLevelInd;
	}

	public void setPrivateLevelInd(Character privateLevelInd) {
		this.privateLevelInd = privateLevelInd;
	}

	public BigDecimal getBatchId() {
		return batchId;
	}

	public void setBatchId(BigDecimal batchId) {
		this.batchId = batchId;
	}

	public Character getLogicalDelInd() {
		return logicalDelInd;
	}

	public void setLogicalDelInd(Character logicalDelInd) {
		this.logicalDelInd = logicalDelInd;
	}

	public Character getPrimaryUpcInd() {
		return primaryUpcInd;
	}

	public void setPrimaryUpcInd(Character primaryUpcInd) {
		this.primaryUpcInd = primaryUpcInd;
	}

	public BigDecimal getSizeNmbr() {
		return sizeNmbr;
	}

	public void setSizeNmbr(BigDecimal sizeNmbr) {
		this.sizeNmbr = sizeNmbr;
	}

	public String getSizeUom() {
		return sizeUom;
	}

	public void setSizeUom(String sizeUom) {
		this.sizeUom = sizeUom;
	}

	public String getSizeDesc() {
		return sizeDesc;
	}

	public void setSizeDesc(String sizeDesc) {
		this.sizeDesc = sizeDesc;
	}

	public ItemAggregateCorpPk getItemAggregateCorpPk() {
		return itemAggregateCorpPk;
	}

	public void setItemAggregateCorpPk(ItemAggregateCorpPk itemAggregateCorpPk) {
		this.itemAggregateCorpPk = itemAggregateCorpPk;
	}

	public String getPrdHierLevel1() {
		return prdHierLevel1;
	}

	public void setPrdHierLevel1(String prdHierLevel1) {
		this.prdHierLevel1 = prdHierLevel1;
	}

	public String getPrdHierLevel2() {
		return prdHierLevel2;
	}

	public void setPrdHierLevel2(String prdHierLevel2) {
		this.prdHierLevel2 = prdHierLevel2;
	}

	public String getPrdHierLevel3() {
		return prdHierLevel3;
	}

	public void setPrdHierLevel3(String prdHierLevel3) {
		this.prdHierLevel3 = prdHierLevel3;
	}

	public String getPrdHierLevel4() {
		return prdHierLevel4;
	}

	public void setPrdHierLevel4(String prdHierLevel4) {
		this.prdHierLevel4 = prdHierLevel4;
	}

	public String getPrdHierLevel5() {
		return prdHierLevel5;
	}

	public void setPrdHierLevel5(String prdHierLevel5) {
		this.prdHierLevel5 = prdHierLevel5;
	}

	public String getSrcByWhse() {
		return srcByWhse;
	}

	public void setSrcByWhse(String srcByWhse) {
		this.srcByWhse = srcByWhse;
	}

	public String getSrcByDsd() {
		return srcByDsd;
	}

	public void setSrcByDsd(String srcByDsd) {
		this.srcByDsd = srcByDsd;
	}

	public Character getExpenseItemInd() {
		return expenseItemInd;
	}

	public void setExpenseItemInd(Character expenseItemInd) {
		this.expenseItemInd = expenseItemInd;
	}

	public Character getMaterialItemInd() {
		return materialItemInd;
	}

	public void setMaterialItemInd(Character materialItemInd) {
		this.materialItemInd = materialItemInd;
	}

	public Character getStoreCreatedItemInd() {
		return storeCreatedItemInd;
	}

	public void setStoreCreatedItemInd(Character storeCreatedItemInd) {
		this.storeCreatedItemInd = storeCreatedItemInd;
	}

}