package com.safeway.app.memi.data.repositories;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;

/**
 ****************************************************************************
 * NAME			: MultiUnitSQLRepository 
 * 
 * DESCRIPTION	: MultiUnitSQLRepository is the repository class for performing 
 * 				  multi-unit type DB operations
 * 
 * SYSTEM		: MEMI 
 * 
 * AUTHOR		: U51095
 * 
 * *************************************************************************
 */

/**
 * Repository class for multi-unit type DB operations
 */
@Repository
@SuppressWarnings("unchecked")
public class MultiUnitSQLRepository {
	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;
	@Value("${spring.datasource.hikari.schema}")
	private String defaultSchema;
	
	private static final Logger LOG = LoggerFactory
			.getLogger(MultiUnitSQLRepository.class);

	public List<Object[]> fetchMultiUnitTypeSrcItemOnload(String companyId,
			String divisionId, String matchIndicator) {
		LOG.info("Fetching multi unit source item onload");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, P.SRC_ITEM_DESC, P.SRC_PACK_WHSE, P.SRC_VEND_CONV_FCTR, P.SIZE_DESC, P.PROD_SOURCE_CD, P.SRC_COST, P.SRC_PROD_HIERARCHY_LVL_5_CD, P.SRC_PROD_HIERARCHY_LVL_1_CD, P.SRC_PROD_HIERARCHY_LVL_2_CD, P.SRC_PROD_HIERARCHY_LVL_3_CD, P.SRC_UPC, X.CONV_STATUS_CD, P.SRC_MAX_RETAIL, P.SRC_VEND_NAME,P.CONV_PRODUCT_SKU FROM ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE P JOIN XREFLAND.SRC_ITEM_XRF X ON P.COMPANY_ID=X.COMPANY_ID AND P.DIVISION_ID=X.DIVISION_ID AND P.CONV_PRODUCT_SKU =X.SRC_PRODUCT_SKU AND P.SRC_UPC =concat(right(replicate('0',1) + cast(X.SRC_UPC_COUNTRY as varchar),1) , right(replicate('0',1) + cast(X.SRC_UPC_SYSTEM as varchar),1) ," + 
				" right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5) , right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5))")
		.append(" WHERE P.COMPANY_ID =").append(":companyId")
		.append(" AND P.DIVISION_ID =").append(":divisionId")
		.append(" AND P.AUTO_MANUAL_IND =")
		.append(":matchIndicator")
		.append(" AND X.CONV_STATUS_CD NOT IN ('D','O','C') ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching multi unit source item onload.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeTargetItemOnload(String companyId,
			String divisionId, String matchIndicator) {

		LOG.info("Fetching Multi Unit Target Details onload.");
		
		StringBuilder joinMultiUnitType = null;
		if (matchIndicator.equals("A")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else if (matchIndicator.equals("M")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.SRC_UPC = D.UPC");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
				.append("SELECT A.*, B.UPC AS SSIMS_UPC, B.UNIT_TYPE AS SSIMS_UNIT_TYPE FROM (SELECT DISTINCT D.CORP_ITEM_CD, D.ITEM_DESC, D.PACK_WHSE, D.VEND_CONV_FCTR,D.UPC,D.UNIT_TYPE, concat(right(replicate('0',2) + cast(D.GROUP_CD as varchar),2) , '-' ,right(replicate('0',2) + cast(D.CTGRY_CD as varchar),2) , '-' , right(replicate('0',2) + cast(D.CLASS_CD as varchar),2) ,'-', right(replicate('0',2) + cast(D.SUB_CLASS_CD as varchar),2) ,'-', right(replicate('0',2) + cast(D.SUBSB_CLASS_CD as varchar),2)) AS SMIC, D.SIZE_DESC AS SIMS_SIZE, concat(right(replicate('0',1) + cast(D.VEN_UPC_PACK_IND as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(D.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',5) + cast(D.VEN_UPC_MANUF as varchar),5) ,'-',     right(replicate('0',5) + cast(D.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC, D.INNER_PACK, D.RETAIL_SECT, D.STATUS_CORP, D.DEPT_NAME, D.COST_VEND, SUBSTRING(D.DST_CNTR , 1, 1) AS DSD_WHSE, D.VEND_NUM, D.VEND_NAME FROM ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA D JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE N ")
				.append(joinMultiUnitType)
				.append(" AND N.COMPANY_ID =")
				.append(":companyId")
				.append(" AND N.DIVISION_ID =")
				.append(":divisionId")
				.append(" WHERE N.AUTO_MANUAL_IND =")
				.append(":matchIndicator")
				.append(") A, ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA B WHERE A.CORP_ITEM_CD = B.CORP_ITEM_CD ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Multi Unit Target details onload.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeTargetBasedOnSourceSelection(
			String companyId, String divisionId, String upcs,
			String matchIndicator) {
		LOG.info("Fetching Multi Unit Target Details based on source selection");
		List<String> upcsList = Arrays.asList(upcs.split(","));
		StringBuilder joinMultiUnitType = null;
		if (matchIndicator.equals("A")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else if (matchIndicator.equals("M")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.SRC_UPC = D.UPC");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
				.append("SELECT A.*, B.UPC AS SSIMS_UPC, B.UNIT_TYPE AS SSIMS_UNIT_TYPE FROM(SELECT DISTINCT D.CORP_ITEM_CD, D.ITEM_DESC, D.PACK_WHSE, D.VEND_CONV_FCTR,D.UPC,D.UNIT_TYPE, concat(right(replicate('0',2) + cast(D.GROUP_CD as varchar),2) , '-' ,right(replicate('0',2) + cast(D.CTGRY_CD as varchar),2) , '-' , right(replicate('0',2) + cast(D.CLASS_CD as varchar),2) ,'-', right(replicate('0',2) + cast(D.SUB_CLASS_CD as varchar),2) ,'-', right(replicate('0',2) + cast(D.SUBSB_CLASS_CD as varchar),2) ) AS SMIC, D.SIZE_DESC AS SIMS_SIZE, concat(right(replicate('0',1) + cast(D.VEN_UPC_PACK_IND as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(D.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',5) + cast(D.VEN_UPC_MANUF as varchar),5) ,'-',     right(replicate('0',5) + cast(D.VEN_UPC_ITEM as varchar),5) ) AS CASE_UPC, D.INNER_PACK, D.RETAIL_SECT, D.STATUS_CORP, D.DEPT_NAME, D.COST_VEND, SUBSTRING(D.DST_CNTR , 1, 1) AS DSD_WHSE, D.VEND_NUM, D.VEND_NAME FROM ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA D JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE N ")
				.append(joinMultiUnitType)
				.append(" AND N.COMPANY_ID = :companyId")
				.append(" AND N.DIVISION_ID = :divisionId")
				.append(" WHERE N.AUTO_MANUAL_IND = :matchIndicator")
				.append(" AND D.UPC IN (:upcsList)")
				.append(") A, ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA B WHERE A.CORP_ITEM_CD = B.CORP_ITEM_CD ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("upcsList", upcsList);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Multi Unit Target details.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeSourceBasedOnTargetSelection(
			String companyId, String divisionId, String sourceUpcString,
			String matchIndicator) {
		LOG.info("Fetching Multi Unit Source Details Based On Target Selection");
		
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, P.SRC_ITEM_DESC, P.SRC_PACK_WHSE, P.SRC_VEND_CONV_FCTR, P.SIZE_DESC, P.PROD_SOURCE_CD, P.SRC_COST, P.SRC_PROD_HIERARCHY_LVL_5_CD, P.SRC_PROD_HIERARCHY_LVL_1_CD, P.SRC_PROD_HIERARCHY_LVL_2_CD, P.SRC_PROD_HIERARCHY_LVL_3_CD, P.SRC_UPC, X.CONV_STATUS_CD, P.SRC_MAX_RETAIL, P.SRC_VEND_NAME, P.CONV_PRODUCT_SKU FROM ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE P JOIN XREFLAND.SRC_ITEM_XRF X ON P.COMPANY_ID=X.COMPANY_ID AND P.DIVISION_ID=X.DIVISION_ID AND P.CONV_PRODUCT_SKU =X.SRC_PRODUCT_SKU AND P.SRC_UPC =concat(right(replicate('0',1) + cast(X.SRC_UPC_COUNTRY as varchar),1) , right(replicate('0',1) + cast(X.SRC_UPC_SYSTEM as varchar),1) ,right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5) , right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5))")
		.append(" WHERE P.COMPANY_ID = :companyId")
		.append(" AND P.DIVISION_ID = :divisionId")
		.append(" AND P.AUTO_MANUAL_IND =")
		.append(":matchIndicator")
		.append(" AND P.SRC_UPC IN (").append(":sourceUpcString")
		.append(") AND X.CONV_STATUS_CD NOT IN ('D','O','C') ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("sourceUpcString", Arrays.asList(sourceUpcString.replaceAll("'", "").split(",")));
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Multi Unit Source Details Based On Target Selection.");
		em.close();
		return results;
	}

	public int markItemsAsDead(String company, String division,
			String productSkuString, String markAsDeadReason, String updatedUserId) {
		LOG.info("Updating SRC_ITEM_XRF records.");
		

		String convStatusDesc = "Dead Item - Business assigned status.";
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("UPDATE XREFLAND.SRC_ITEM_XRF SET CONV_STATUS_CD='D', CONV_STATUS_SUB_CD='B', CONV_STATUS_DSC=")
		.append(":convStatusDesc").append(",STATUS_REASON_TXT=").append(":markAsDeadReason")
		.append(",CREATE_UPDATE_USER_ID=").append(":updatedUserId")
		.append(" WHERE COMPANY_ID =").append(":company")
		.append(" AND DIVISION_ID =").append(":division")
		.append(" AND SRC_PRODUCT_SKU IN(").append(":productSkuString)");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("convStatusDesc", convStatusDesc);
		q.setParameter("markAsDeadReason", markAsDeadReason);
		q.setParameter("updatedUserId", updatedUserId);
		q.setParameter("company", company);
		q.setParameter("division", division);
		q.setParameter("productSkuString", productSkuString);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed Updating SRC_ITEM_XRF records.");
		em.close();
		return result;
	}

	public int markNotAMultiUnit(String companyId, String divisionId,
			String productSku, String updatedUserId) {
		LOG.info("Updating ITEM_CONV_MULTI_UNIT_TYPE records.");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("UPDATE ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE SET AUTO_MANUAL_IND='N', STATUS='C', CREATE_UPDATE_USER_ID=")
		.append(":updatedUserId")
		.append(" WHERE COMPANY_ID =").append(":companyId")
		.append(" AND DIVISION_ID =").append(":divisionId")
		.append(" AND CONV_PRODUCT_SKU =")
		.append(":productSku");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("updatedUserId", updatedUserId);
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSku", productSku);
		int result = q.executeUpdate();
		et.commit();
		LOG.info("Completed Updating ITEM_CONV_MULTI_UNIT_TYPE records.");
		em.close();
		return result;
	}

	public List<Object[]> fetchSrcItemBasedOnItemDesc(String companyId,
			String divisionId, String itemDesc) {
		LOG.info("Started fetching not a multiunit item from Corp table based on item desc");

		StringBuilder itemDescription = null;

		if (itemDesc.contains("|")) {
			itemDescription = new StringBuilder()
					.append(" AND I.ITEM_DESC LIKE :itemDesc ESCAPE '|'");
		} else {
			itemDescription = new StringBuilder()
					.append(" AND I.ITEM_DESC LIKE :itemDesc ");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT I.COMPANY_ID, I.DIVISION_ID, I.PRODUCT_SKU,I.ITEM_DESC,I.SHIPPING_PACK_NBR,(I.MASTER_CASE_PACK_NBR/NULLIF(I.SHIPPING_PACK_NBR,0)) AS VCF,I.SIZE_DESC,I.UPC,I.PROD_HIERARCHY_LVL_5_CD,CONCAT(I.PROD_HIERARCHY_LVL_1_CD,'-', I.PROD_HIERARCHY_LVL_2_CD,'-', I.PROD_HIERARCHY_LVL_3_CD)  AS PRODUCT_HIERARCHY,I.SOURCE_BY_DSD,I.SOURCE_BY_WHSE,D.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, X.CONV_STATUS_CD, Z.MAX_RETAIL, Z.VENDOR_NM, D.CONV_PRODUCT_SKU,I.CASE_UPC,Z.VENDOR_ID  ")
		.append(" FROM ECFLAND.ITEM_AGGREGATE_CORP I LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_DSD D ON I.COMPANY_ID = D.COMPANY_ID AND I.DIVISION_ID = D.DIVISION_ID AND I.PRODUCT_SKU = D.PRODUCT_SKU LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON I.COMPANY_ID = W.COMPANY_ID AND I.DIVISION_ID = W.DIVISION_ID AND I.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON I.COMPANY_ID = MU.COMPANY_ID AND I.DIVISION_ID = MU.DIVISION_ID AND I.PRODUCT_SKU = MU.CONV_PRODUCT_SKU ")
		.append(" JOIN XREFLAND.SRC_ITEM_XRF X ON I.COMPANY_ID = X.COMPANY_ID AND I.DIVISION_ID = X.DIVISION_ID AND I.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND X.CONV_STATUS_CD NOT IN ('D', 'O','C') JOIN "+defaultSchema+".ITEM_CONV_VENDOR_INFO Z ON I.COMPANY_ID = Z.COMPANY_ID AND I.DIVISION_ID = Z.DIVISION_ID AND I.PRODUCT_SKU = Z.PRODUCT_SKU WHERE I.COMPANY_ID=")
		.append(" :companyId AND I.DIVISION_ID =").append(":divisionId "+itemDescription+" AND ( MU.COMPANY_ID IS NULL or(MU.COMPANY_ID IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("itemDesc", "%"+itemDesc+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching not a multiunit item from corp table based on item desc");
		em.close();
		return results;

	}

	public List<Object[]> fetchSrcItemBasedOnVendorName(String companyId,
			String divisionId, String srcVendName) {
		LOG.info("Started fetching not a multiunit item from Corp table based on item desc");

		StringBuilder vendorDescription = null;
		if (srcVendName.contains("|")) {
			vendorDescription = new StringBuilder()
					.append(" AND Z.VENDOR_NM LIKE :srcVendName ESCAPE '|'");
		} else {
			vendorDescription = new StringBuilder()
					.append(" AND Z.VENDOR_NM LIKE :srcVendName ");
		}
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT I.COMPANY_ID, I.DIVISION_ID, I.PRODUCT_SKU,I.ITEM_DESC,I.SHIPPING_PACK_NBR,(I.MASTER_CASE_PACK_NBR/NULLIF(I.SHIPPING_PACK_NBR,0)) AS VCF,I.SIZE_DESC,I.UPC,I.PROD_HIERARCHY_LVL_5_CD,CONCAT(I.PROD_HIERARCHY_LVL_1_CD,'-', I.PROD_HIERARCHY_LVL_2_CD,'-', I.PROD_HIERARCHY_LVL_3_CD)  AS PRODUCT_HIERARCHY,I.SOURCE_BY_DSD,I.SOURCE_BY_WHSE,D.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, X.CONV_STATUS_CD, Z.MAX_RETAIL, Z.VENDOR_NM, D.CONV_PRODUCT_SKU,I.CASE_UPC,Z.VENDOR_ID  ")
		.append(" FROM ECFLAND.ITEM_AGGREGATE_CORP I LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_DSD D ON I.COMPANY_ID = D.COMPANY_ID AND I.DIVISION_ID = D.DIVISION_ID AND I.PRODUCT_SKU = D.PRODUCT_SKU LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON I.COMPANY_ID = W.COMPANY_ID AND I.DIVISION_ID = W.DIVISION_ID AND I.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON I.COMPANY_ID = MU.COMPANY_ID AND I.DIVISION_ID = MU.DIVISION_ID AND I.PRODUCT_SKU = MU.CONV_PRODUCT_SKU ")
		.append(" JOIN XREFLAND.SRC_ITEM_XRF X ON I.COMPANY_ID = X.COMPANY_ID AND I.DIVISION_ID = X.DIVISION_ID AND I.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND X.CONV_STATUS_CD NOT IN ('D', 'O','C') JOIN "+defaultSchema+".ITEM_CONV_VENDOR_INFO Z ON I.COMPANY_ID = Z.COMPANY_ID AND I.DIVISION_ID = Z.DIVISION_ID AND I.PRODUCT_SKU = Z.PRODUCT_SKU WHERE I.COMPANY_ID=")
		.append(":companyId AND I.DIVISION_ID =").append(" :divisionId "+vendorDescription+" AND ( MU.COMPANY_ID IS NULL or(MU.COMPANY_ID IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) ");
		EntityManager em =  entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("srcVendName", "%"+srcVendName+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching not a multiunit item from corp table based on item desc");
		em.close();
		return results;
	}

	public List<Object[]> fetchSrcItemBasedOnProductHierarchy(String companyId,
			String divisionId, String srcprodHierarchyLvl1Cd,
			String srcprodHierarchyLvl2Cd, String srcprodHierarchyLvl3Cd) {
		Map<String, Object> baseParams = new HashMap<>();
		LOG.info("Started fetching not a multiunit item from Corp table  based on product hierarchy");
		StringBuilder productHierarchy = new StringBuilder();
		if (!srcprodHierarchyLvl1Cd.isEmpty()) {
			productHierarchy = productHierarchy
					.append(" AND I.PROD_HIERARCHY_LVL_1_CD = :srcprodHierarchyLvl1Cd");
			baseParams.put("srcprodHierarchyLvl1Cd", srcprodHierarchyLvl1Cd);
		}
		
		if (!srcprodHierarchyLvl2Cd.isEmpty()) {
			productHierarchy = productHierarchy
					.append(" AND I.PROD_HIERARCHY_LVL_2_CD = :srcprodHierarchyLvl2Cd");
		baseParams.put("srcprodHierarchyLvl2Cd", srcprodHierarchyLvl2Cd);
		}
		if (!srcprodHierarchyLvl3Cd.isEmpty()) {
			productHierarchy = productHierarchy
					.append(" AND I.PROD_HIERARCHY_LVL_3_CD = :srcprodHierarchyLvl3Cd");
							
		baseParams.put("srcprodHierarchyLvl3Cd", srcprodHierarchyLvl3Cd);	
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT I.COMPANY_ID, I.DIVISION_ID, I.PRODUCT_SKU,I.ITEM_DESC,I.SHIPPING_PACK_NBR,(I.MASTER_CASE_PACK_NBR/NULLIF(I.SHIPPING_PACK_NBR,0)) AS VCF,I.SIZE_DESC,I.UPC,I.PROD_HIERARCHY_LVL_5_CD,CONCAT(I.PROD_HIERARCHY_LVL_1_CD,'-', I.PROD_HIERARCHY_LVL_2_CD,'-', I.PROD_HIERARCHY_LVL_3_CD)  AS PRODUCT_HIERARCHY,I.SOURCE_BY_DSD,I.SOURCE_BY_WHSE,D.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, X.CONV_STATUS_CD, Z.MAX_RETAIL, Z.VENDOR_NM, D.CONV_PRODUCT_SKU,I.CASE_UPC,Z.VENDOR_ID  ")
		.append(" FROM ECFLAND.ITEM_AGGREGATE_CORP I LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_DSD D ON I.COMPANY_ID = D.COMPANY_ID AND I.DIVISION_ID = D.DIVISION_ID AND I.PRODUCT_SKU = D.PRODUCT_SKU LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON I.COMPANY_ID = W.COMPANY_ID AND I.DIVISION_ID = W.DIVISION_ID AND I.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON I.COMPANY_ID = MU.COMPANY_ID AND I.DIVISION_ID = MU.DIVISION_ID AND I.PRODUCT_SKU = MU.CONV_PRODUCT_SKU ")
		.append(" JOIN XREFLAND.SRC_ITEM_XRF X ON I.COMPANY_ID = X.COMPANY_ID AND I.DIVISION_ID = X.DIVISION_ID AND I.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND X.CONV_STATUS_CD NOT IN ('D', 'O','C') JOIN "+defaultSchema+".ITEM_CONV_VENDOR_INFO Z ON I.COMPANY_ID = Z.COMPANY_ID AND I.DIVISION_ID = Z.DIVISION_ID AND I.PRODUCT_SKU = Z.PRODUCT_SKU WHERE I.COMPANY_ID=")
		.append(" :companyId AND I.DIVISION_ID =").append(" :divisionId "+productHierarchy+" AND ( MU.COMPANY_ID IS NULL or(MU.COMPANY_ID IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		baseParams.put("companyId", companyId);
		baseParams.put("divisionId", divisionId);
		Query q = em.createNativeQuery(baseQuery.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching not a multiunit item from corp table  based on product hierarchy");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeSrcItemBasedOnItemDesc(
			String companyId, String divisionId, String itemDesc,
			String matchIndicator) {
		LOG.info("Fetching multi unit source item based on item desc");
		StringBuilder itemDescription = null;

		if (itemDesc.contains("|")) {
			itemDescription = new StringBuilder()
					.append(" AND P.SRC_ITEM_DESC LIKE :itemDesc ESCAPE '|'");
		} else {
			itemDescription = new StringBuilder()
					.append(" AND P.SRC_ITEM_DESC LIKE :itemDesc");
		}
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, P.SRC_ITEM_DESC, P.SRC_PACK_WHSE, P.SRC_VEND_CONV_FCTR, P.SIZE_DESC, P.PROD_SOURCE_CD, P.SRC_COST, P.SRC_PROD_HIERARCHY_LVL_5_CD, P.SRC_PROD_HIERARCHY_LVL_1_CD, P.SRC_PROD_HIERARCHY_LVL_2_CD, P.SRC_PROD_HIERARCHY_LVL_3_CD, P.SRC_UPC, X.CONV_STATUS_CD, P.SRC_MAX_RETAIL, P.SRC_VEND_NAME, P.CONV_PRODUCT_SKU FROM ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE P JOIN XREFLAND.SRC_ITEM_XRF X ON P.COMPANY_ID=X.COMPANY_ID AND P.DIVISION_ID=X.DIVISION_ID AND P.CONV_PRODUCT_SKU =X.SRC_PRODUCT_SKU AND P.SRC_UPC =concat(right(replicate('0',1) + cast(X.SRC_UPC_COUNTRY as varchar),1) , right(replicate('0',1) + cast(X.SRC_UPC_SYSTEM as varchar),1) ,right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5) , right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5))")
		.append(" WHERE P.COMPANY_ID =").append(" :companyId ")
		.append(" AND P.DIVISION_ID = :divisionId").append(itemDescription)
		.append(" AND P.AUTO_MANUAL_IND = :matchIndicator ")
		.append(" AND X.CONV_STATUS_CD NOT IN ('D','O','C') ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("itemDesc", "%"+itemDesc+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching multi unit source item based on item desc.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeSrcItemBasedOnVendorName(
			String companyId, String divisionId, String srcVendName,
			String matchIndicator) {
		LOG.info("Fetching multi unit source item based on item desc");
		StringBuilder vendorDescription = null;

		if (srcVendName.contains("|")) {
			vendorDescription = new StringBuilder()
					.append(" AND P.SRC_VEND_NAME LIKE :srcVendName ESCAPE '|'");
		} else {
			vendorDescription = new StringBuilder()
					.append(" AND P.SRC_VEND_NAME LIKE :srcVendName ");
		}
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, P.SRC_ITEM_DESC, P.SRC_PACK_WHSE, P.SRC_VEND_CONV_FCTR, P.SIZE_DESC, P.PROD_SOURCE_CD, P.SRC_COST, P.SRC_PROD_HIERARCHY_LVL_5_CD, P.SRC_PROD_HIERARCHY_LVL_1_CD, P.SRC_PROD_HIERARCHY_LVL_2_CD, P.SRC_PROD_HIERARCHY_LVL_3_CD, P.SRC_UPC, X.CONV_STATUS_CD, P.SRC_MAX_RETAIL, P.SRC_VEND_NAME,P.CONV_PRODUCT_SKU FROM ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE P JOIN XREFLAND.SRC_ITEM_XRF X ON P.COMPANY_ID=X.COMPANY_ID AND P.DIVISION_ID=X.DIVISION_ID AND P.CONV_PRODUCT_SKU =X.SRC_PRODUCT_SKU AND P.SRC_UPC =concat(right(replicate('0',1) + cast(X.SRC_UPC_COUNTRY as varchar),1) , right(replicate('0',1) + cast(X.SRC_UPC_SYSTEM as varchar),1) ,right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5) , right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5))")
		.append(" WHERE P.COMPANY_ID =").append(" :companyId")
		.append(" AND P.DIVISION_ID =").append(" :divisionId "+vendorDescription+"")
		.append(" AND P.AUTO_MANUAL_IND = :matchIndicator")
		.append(" AND X.CONV_STATUS_CD NOT IN ('D','O','C') ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("srcVendName", "%"+srcVendName+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching multi unit source item based on item desc.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeSrcItemBasedOnProductHierarchy(
			String companyId, String divisionId, String srcprodHierarchyLvl1Cd,
			String srcprodHierarchyLvl2Cd, String srcprodHierarchyLvl3Cd,
			String matchIndicator) {
		LOG.info("Fetching multi unit source item based on product hierarchy");
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder productHierarchy = new StringBuilder();
		if (!srcprodHierarchyLvl1Cd.isEmpty()) {
			productHierarchy = productHierarchy
					.append(" AND P.SRC_PROD_HIERARCHY_LVL_1_CD = :srcprodHierarchyLvl1Cd");
		    baseParams.put("srcprodHierarchyLvl1Cd",srcprodHierarchyLvl1Cd);
						
		}
		if (!srcprodHierarchyLvl2Cd.isEmpty()) {
			productHierarchy = productHierarchy
					.append(" AND P.SRC_PROD_HIERARCHY_LVL_2_CD = :srcprodHierarchyLvl2Cd");
			baseParams.put("srcprodHierarchyLvl2Cd",srcprodHierarchyLvl2Cd);				
		}
		if (!srcprodHierarchyLvl3Cd.isEmpty()) {
			productHierarchy = productHierarchy
					.append(" AND P.SRC_PROD_HIERARCHY_LVL_3_CD = :srcprodHierarchyLvl3Cd");
							
			baseParams.put("srcprodHierarchyLvl3Cd",srcprodHierarchyLvl3Cd);	
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, P.SRC_ITEM_DESC, P.SRC_PACK_WHSE, P.SRC_VEND_CONV_FCTR, P.SIZE_DESC, P.PROD_SOURCE_CD, P.SRC_COST, P.SRC_PROD_HIERARCHY_LVL_5_CD, P.SRC_PROD_HIERARCHY_LVL_1_CD, P.SRC_PROD_HIERARCHY_LVL_2_CD, P.SRC_PROD_HIERARCHY_LVL_3_CD, P.SRC_UPC, X.CONV_STATUS_CD, P.SRC_MAX_RETAIL, P.SRC_VEND_NAME, P.CONV_PRODUCT_SKU FROM ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE P JOIN XREFLAND.SRC_ITEM_XRF X ON P.COMPANY_ID=X.COMPANY_ID AND P.DIVISION_ID=X.DIVISION_ID AND P.CONV_PRODUCT_SKU =X.SRC_PRODUCT_SKU AND P.SRC_UPC =concat(right(replicate('0',1) + cast(X.SRC_UPC_COUNTRY as varchar),1) , right(replicate('0',1) + cast(X.SRC_UPC_SYSTEM as varchar),1) ,right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5) , right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5))")
		.append(" WHERE P.COMPANY_ID = :companyId")
		.append(" AND P.DIVISION_ID = :divisionId").append(""+productHierarchy+"")
		.append(" AND P.AUTO_MANUAL_IND = :matchIndicator")
		.append(" AND X.CONV_STATUS_CD NOT IN ('D','O','C') ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		baseParams.put("companyId", companyId);
		baseParams.put("divisionId", divisionId);
		baseParams.put("matchIndicator", matchIndicator);
		Query q = em.createNativeQuery(baseQuery.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching multi unit source item based on product hierarchy.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeTargetItemBasedOnItemDesc(
			String companyId, String divisionId, String itemDesc,
			String matchIndicator) {
		LOG.info("Fetching multi unit target details based on item desc.");
		StringBuilder itemDescription = null;
		if (itemDesc.contains("|")) {
			itemDescription = new StringBuilder()
					.append(" AND D.ITEM_DESC LIKE :itemDesc ESCAPE '|'");
		} else {
			itemDescription = new StringBuilder()
					.append(" AND D.ITEM_DESC LIKE :itemDesc");
		}
		
		StringBuilder joinMultiUnitType = null;
		if (matchIndicator.equals("A")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else if (matchIndicator.equals("M")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.SRC_UPC = D.UPC");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
				.append("SELECT A.*, B.UPC AS SSIMS_UPC, B.UNIT_TYPE AS SSIMS_UNIT_TYPE FROM(SELECT DISTINCT D.CORP_ITEM_CD, D.ITEM_DESC, D.PACK_WHSE,D.VEND_CONV_FCTR,D.UPC,D.UNIT_TYPE, CONCAT(right(replicate('0',2) + cast(D.GROUP_CD as varchar),2),'-', right(replicate('0',2) + cast(D.CTGRY_CD as varchar),2),'-', right(replicate('0',2) + cast(D.CLASS_CD as varchar),2),'-',  right(replicate('0',2) + cast(D.SUB_CLASS_CD as varchar),2),'-','-', right(replicate('0',2) + cast(D.SUBSB_CLASS_CD as varchar),2))  AS SMIC, D.SIZE_DESC AS SIMS_SIZE,  CONCAT(right(replicate('0',1) + cast(D.VEN_UPC_PACK_IND as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_COUNTRY as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_MANUF as varchar),1) ,'-', right(replicate('0',5) + cast(D.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC, D.INNER_PACK, D.RETAIL_SECT, D.STATUS_CORP, D.DEPT_NAME, D.COST_VEND, SUBSTRING(D.DST_CNTR , 1, 1) AS DSD_WHSE, D.VEND_NUM, D.VEND_NAME FROM ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA D JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE N ")
				.append(joinMultiUnitType)
				.append(" AND N.COMPANY_ID = :companyId")
				.append(" AND N.DIVISION_ID = :divisionId")
				.append(" WHERE N.AUTO_MANUAL_IND = :matchIndicator")
				.append(itemDescription)
				.append(") A, ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA B WHERE A.CORP_ITEM_CD = B.CORP_ITEM_CD ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("itemDesc", "%"+itemDesc+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching multi unit target details based on item desc.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeTargetItemBasedOnVendorName(
			String companyId, String divisionId, String tarVendorName,
			String matchIndicator) {
		LOG.info("Fetching multi unit target details based on item desc.");
		StringBuilder vendorDescription = null;
		if (tarVendorName.contains("|")) {
			vendorDescription = new StringBuilder()
					.append(" AND D.VEND_NAME LIKE :tarVendorName ESCAPE '|'");
			
		} else {
			vendorDescription = new StringBuilder()
					.append(" AND D.VEND_NAME LIKE :tarVendorName ");
		}
		StringBuilder joinMultiUnitType = null;
		if (matchIndicator.equals("A")) {
			joinMultiUnitType = new StringBuilder()
					.append(" ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else if (matchIndicator.equals("M")) {
			joinMultiUnitType = new StringBuilder()
					.append(" ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else {
			joinMultiUnitType = new StringBuilder()
					.append(" ON N.SRC_UPC = D.UPC");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
				.append("SELECT A.*, B.UPC AS SSIMS_UPC, B.UNIT_TYPE AS SSIMS_UNIT_TYPE FROM(SELECT DISTINCT D.CORP_ITEM_CD, D.ITEM_DESC, D.PACK_WHSE, D.VEND_CONV_FCTR,D.UPC,D.UNIT_TYPE, CONCAT(right(replicate('0',2) + cast(D.GROUP_CD as varchar),2),'-',right(replicate('0',2) + cast(D.CTGRY_CD as varchar),2) ,'-', right(replicate('0',2) + cast(D.CLASS_CD as varchar),2),'-',right(replicate('0',2) + cast(D.SUB_CLASS_CD as varchar),2) , '-',right(replicate('0',2) + cast(D.SUBSB_CLASS_CD as varchar),2)) AS SMIC, D.SIZE_DESC AS SIMS_SIZE,CONCAT(right(replicate('0',1) + cast(D.VEN_UPC_PACK_IND as varchar),1) ,'-',right(replicate('0',1) + cast(D.VEN_UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(D.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',5) + cast(D.VEN_UPC_MANUF as varchar),5),'-', right(replicate('0',5) + cast(D.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC, D.INNER_PACK, D.RETAIL_SECT, D.STATUS_CORP, D.DEPT_NAME, D.COST_VEND, SUBSTRING(D.DST_CNTR , 1, 1) AS DSD_WHSE, D.VEND_NUM, D.VEND_NAME FROM ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA D JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE N")
				.append(joinMultiUnitType)
				.append(" AND N.COMPANY_ID = :companyId")
				.append(" AND N.DIVISION_ID = :divisionId")
				.append(" WHERE N.AUTO_MANUAL_IND = :matchIndicator")
				.append(vendorDescription)
				.append(") A, ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA B WHERE A.CORP_ITEM_CD = B.CORP_ITEM_CD ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("tarVendorName", "%"+tarVendorName+"%");
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching multi unit target details based on item desc.");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeTargetItemBasedOnSmicCode(
			String companyId, String divisionId, String tarGrpCd,
			String tarCtgryCd, String tarClsCd, String tarSbClsCd,
			String tarSubSbClass, String matchIndicator) {
		LOG.info("Fetching multi unit target details based on Smic Code.");
		Map<String, Object> baseParams = new HashMap<>();
		StringBuilder smicCode = new StringBuilder();
		StringBuilder joinMultiUnitType = null;
		if (!tarGrpCd.isEmpty()) {
			smicCode = smicCode.append(" AND D.GROUP_CD = :tarGrpCd");
			baseParams.put("tarGrpCd", tarGrpCd);
		}
		if (!tarCtgryCd.isEmpty()) {
			smicCode = smicCode.append(" AND D.CTGRY_CD = :tarCtgryCd");
			baseParams.put("tarCtgryCd", tarCtgryCd);
		}
		if (!tarClsCd.isEmpty()) {
			smicCode = smicCode.append(" AND D.CLASS_CD = :tarClsCd");
			baseParams.put("tarClsCd", tarClsCd);
		}
		if (!tarSbClsCd.isEmpty()) {
			smicCode = smicCode.append(" AND D.SUB_CLASS_CD = :tarSbClsCd");
			baseParams.put("tarSbClsCd", tarSbClsCd);
		}
		if (!tarSubSbClass.isEmpty()) {
			smicCode = smicCode.append(" AND D.SUBSB_CLASS_CD = :tarSubSbClass");
			baseParams.put("tarSubSbClass", tarSubSbClass);
		}
		
		if (matchIndicator.equals("A")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else if (matchIndicator.equals("M")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.SRC_UPC = D.UPC");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
				.append("SELECT A.*, B.UPC AS SSIMS_UPC, B.UNIT_TYPE AS SSIMS_UNIT_TYPE FROM(SELECT DISTINCT D.CORP_ITEM_CD, D.ITEM_DESC, D.PACK_WHSE, D.VEND_CONV_FCTR,D.UPC,D.UNIT_TYPE, CONCAT(right(replicate('0',2) + cast(D.GROUP_CD as varchar),2),'-',right(replicate('0',2) + cast(D.CTGRY_CD as varchar),2) ,'-', right(replicate('0',2) + cast(D.CLASS_CD as varchar),2),'-',right(replicate('0',2) + cast(D.SUB_CLASS_CD as varchar),2) , '-',right(replicate('0',2) + cast(D.SUBSB_CLASS_CD as varchar),2))  AS SMIC, D.SIZE_DESC AS SIMS_SIZE, CONCAT(right(replicate('0',1) + cast(D.VEN_UPC_PACK_IND as varchar),1) ,'-',right(replicate('0',1) + cast(D.VEN_UPC_COUNTRY as varchar),1),'-', right(replicate('0',1) + cast(D.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',5) + cast(D.VEN_UPC_MANUF as varchar),5),'-', right(replicate('0',5) + cast(D.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC, D.INNER_PACK, D.RETAIL_SECT, D.STATUS_CORP, D.DEPT_NAME, D.COST_VEND, SUBSTRING(D.DST_CNTR , 1, 1) AS DSD_WHSE, D.VEND_NUM, D.VEND_NAME FROM ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA D JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE N ")
				.append(joinMultiUnitType)
				.append(" AND N.COMPANY_ID = :companyId")
				.append(" AND N.DIVISION_ID = :divisionId ")
				.append(" WHERE N.AUTO_MANUAL_IND = :matchIndicator")
				.append(smicCode)
				.append(") A, ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA B WHERE A.CORP_ITEM_CD = B.CORP_ITEM_CD ");
		
		baseParams.put("companyId", companyId);
		baseParams.put("divisionId", divisionId);
		baseParams.put("matchIndicator", matchIndicator);
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			q.setParameter(entry.getKey(), entry.getValue());
		}
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching multi unit target details based on Smic Code.");
		em.close();
		return results;
	}
	
	public List<String> findProductSkuBasedOnConvProductSku(String companyId, String divisionId,
			String convProductSku) {
		LOG.info("Started fetching productsku based on conversion product Sku for DSD item .");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT D.PRODUCT_SKU FROM ECFLAND.ITEM_AGGREGATE_DSD D JOIN XREFLAND.SRC_ITEM_XRF X ON X.COMPANY_ID=D.COMPANY_ID AND X.DIVISION_ID=D.DIVISION_ID AND X.SRC_PRODUCT_SKU =D.PRODUCT_SKU AND X.SRC_UPC=D.UPC AND X.CONV_STATUS_CD NOT IN ('D','O','C') WHERE D.COMPANY_ID= :companyId  AND D.DIVISION_ID = :divisionId AND D.CONV_PRODUCT_SKU = :convProductSku");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("convProductSku", convProductSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "5000");
		List<String> results = q.getResultList();
		LOG.info("Completed fetching productsku based on conversion product Sku for DSD item .");
		em.close();
		return results;
	}

	public List<String> findProductSkuBasedOnProductSku(String companyId,
			String divisionId, String convProductSku) {
		LOG.info("Started fetching productsku based on conversion product Sku for WHSE item .");
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT D.PRODUCT_SKU FROM ECFLAND.ITEM_AGGREGATE_WHSE D JOIN XREFLAND.SRC_ITEM_XRF X ON X.COMPANY_ID=D.COMPANY_ID AND X.DIVISION_ID=D.DIVISION_ID AND X.SRC_PRODUCT_SKU =D.PRODUCT_SKU AND X.CONV_STATUS_CD NOT IN ('D','O','C') WHERE D.COMPANY_ID= :companyId  AND D.DIVISION_ID = :divisionId  AND D.PRODUCT_SKU = :convProductSku");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("convProductSku", convProductSku);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "5000");
		List<String> results = q.getResultList();
		LOG.info("Completed fetching productsku based on conversion product Sku for WHSE item .");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitTypeSrcItemBasedOnProductSKU(
			String companyId, String divisionId, String productSKU,
			String matchIndicator) {
		LOG.info("Fetching multi unit source item based on product sku");
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT P.COMPANY_ID, P.DIVISION_ID, P.PRODUCT_SKU, P.SRC_ITEM_DESC, P.SRC_PACK_WHSE, P.SRC_VEND_CONV_FCTR, P.SIZE_DESC, P.PROD_SOURCE_CD, P.SRC_COST, P.SRC_PROD_HIERARCHY_LVL_5_CD, P.SRC_PROD_HIERARCHY_LVL_1_CD, P.SRC_PROD_HIERARCHY_LVL_2_CD, P.SRC_PROD_HIERARCHY_LVL_3_CD, P.SRC_UPC, X.CONV_STATUS_CD, P.SRC_MAX_RETAIL, P.SRC_VEND_NAME, P.CONV_PRODUCT_SKU FROM ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE P JOIN XREFLAND.SRC_ITEM_XRF X ON P.COMPANY_ID=X.COMPANY_ID AND P.DIVISION_ID=X.DIVISION_ID AND P.CONV_PRODUCT_SKU =X.SRC_PRODUCT_SKU AND P.SRC_UPC =concat(right(replicate('0',1) + cast(X.SRC_UPC_COUNTRY as varchar),1) , right(replicate('0',1) + cast(X.SRC_UPC_SYSTEM as varchar),1) ,right(replicate('0',5) + cast(X.SRC_UPC_MANUF as varchar),5) , right(replicate('0',5) + cast(X.SRC_UPC_SALES as varchar),5))")
		.append(" WHERE P.COMPANY_ID = :companyId")
		.append(" AND P.DIVISION_ID = :divisionId").append(" AND P.PRODUCT_SKU = :productSKU ")
		.append(" AND P.AUTO_MANUAL_IND = :matchIndicator")
		.append(" AND X.CONV_STATUS_CD NOT IN ('D','O','C') ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSKU", productSKU);
		q.setParameter("matchIndicator", matchIndicator);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "500");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching multi unit source item based on item desc.");
		em.close();
		return results;
	}

	public List<Object[]> fetchSrcItemBasedOnProductSKU(String companyId,
			String divisionId, String productSKU) {
		LOG.info("Started fetching not a multiunit item from Corp table based on ProductSKU");

		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("SELECT DISTINCT I.COMPANY_ID, I.DIVISION_ID, I.PRODUCT_SKU,I.ITEM_DESC,I.SHIPPING_PACK_NBR,(I.MASTER_CASE_PACK_NBR/NULLIF(I.SHIPPING_PACK_NBR,0)) AS VCF,I.SIZE_DESC,I.UPC,I.PROD_HIERARCHY_LVL_5_CD,CONCAT(I.PROD_HIERARCHY_LVL_1_CD,'-', I.PROD_HIERARCHY_LVL_2_CD,'-', I.PROD_HIERARCHY_LVL_3_CD)  AS PRODUCT_HIERARCHY,I.SOURCE_BY_DSD,I.SOURCE_BY_WHSE,D.VENDOR_LIST_COST_NBR AS DSD_COST,W.VENDOR_LIST_COST_NBR AS WHSE_COST, X.CONV_STATUS_CD, Z.MAX_RETAIL, Z.VENDOR_NM, D.CONV_PRODUCT_SKU,I.CASE_UPC,Z.VENDOR_ID  ")
		.append(" FROM ECFLAND.ITEM_AGGREGATE_CORP I LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_DSD D ON I.COMPANY_ID = D.COMPANY_ID AND I.DIVISION_ID = D.DIVISION_ID AND I.PRODUCT_SKU = D.PRODUCT_SKU LEFT OUTER JOIN ECFLAND.ITEM_AGGREGATE_WHSE W ON I.COMPANY_ID = W.COMPANY_ID AND I.DIVISION_ID = W.DIVISION_ID AND I.PRODUCT_SKU = W.PRODUCT_SKU LEFT JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE MU ON I.COMPANY_ID = MU.COMPANY_ID AND I.DIVISION_ID = MU.DIVISION_ID AND I.PRODUCT_SKU = MU.CONV_PRODUCT_SKU ")
		.append(" JOIN XREFLAND.SRC_ITEM_XRF X ON I.COMPANY_ID = X.COMPANY_ID AND I.DIVISION_ID = X.DIVISION_ID AND I.PRODUCT_SKU = X.SRC_PRODUCT_SKU AND X.CONV_STATUS_CD NOT IN ('D', 'O','C') JOIN "+defaultSchema+".ITEM_CONV_VENDOR_INFO Z ON I.COMPANY_ID = Z.COMPANY_ID AND I.DIVISION_ID = Z.DIVISION_ID AND I.PRODUCT_SKU = Z.PRODUCT_SKU WHERE I.COMPANY_ID=")
		.append(":companyId AND I.DIVISION_ID =").append(":divisionId AND I.PRODUCT_SKU = :productSKU  AND ( MU.COMPANY_ID IS NULL or(MU.COMPANY_ID IS NOT NULL AND MU.AUTO_MANUAL_IND ='N' )) ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("productSKU", productSKU);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed fetching not a multiunit item from corp table based on ProductSKU");
		em.close();
		return results;

	}

	public List<Object[]> fetchMultiUnitTypeTargetItemBasedOnCIC(
			String companyId, String divisionId, String targetCIC,
			String matchIndicator) {
		LOG.info("Fetching multi unit target details based on corpItemCode");
		
		StringBuilder joinMultiUnitType = null;
		if (matchIndicator.equals("A")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else if (matchIndicator.equals("M")) {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.CORP_ITEM_CD = D.CORP_ITEM_CD");
		} else {
			joinMultiUnitType = new StringBuilder()
					.append("ON N.SRC_UPC = D.UPC");
		}
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery
				.append("SELECT A.*, B.UPC AS SSIMS_UPC, B.UNIT_TYPE AS SSIMS_UNIT_TYPE FROM(SELECT DISTINCT D.CORP_ITEM_CD, D.ITEM_DESC, D.PACK_WHSE, D.VEND_CONV_FCTR,D.UPC,D.UNIT_TYPE, CONCAT(right(replicate('0',2) + cast(D.GROUP_CD as varchar),2),'-', right(replicate('0',2) + cast(D.CTGRY_CD as varchar),2),'-', right(replicate('0',2) + cast(D.CLASS_CD as varchar),2),'-',  right(replicate('0',2) + cast(D.SUB_CLASS_CD as varchar),2),'-','-', right(replicate('0',2) + cast(D.SUBSB_CLASS_CD as varchar),2)) AS SMIC, D.SIZE_DESC AS SIMS_SIZE, CONCAT(right(replicate('0',1) + cast(D.VEN_UPC_PACK_IND as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_COUNTRY as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_NUM_SYS as varchar),1) ,'-', right(replicate('0',1) + cast(D.VEN_UPC_MANUF as varchar),1) ,'-', right(replicate('0',5) + cast(D.VEN_UPC_ITEM as varchar),5)) AS CASE_UPC, D.INNER_PACK, D.RETAIL_SECT, D.STATUS_CORP, D.DEPT_NAME, D.COST_VEND, SUBSTRING(D.DST_CNTR , 1, 1) AS DSD_WHSE, D.VEND_NUM, D.VEND_NAME FROM ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA D JOIN ECFLAND.ITEM_CONV_MULTI_UNIT_TYPE N ")
				.append(joinMultiUnitType)
				.append(" AND N.COMPANY_ID = :companyId")
				.append(" AND N.DIVISION_ID = :divisionId")
				.append(" WHERE N.AUTO_MANUAL_IND = :matchIndicator")
				.append(" AND D.CORP_ITEM_CD = :targetCIC")
				.append(") A, ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA B WHERE A.CORP_ITEM_CD = B.CORP_ITEM_CD ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter("companyId", companyId);
		q.setParameter("divisionId", divisionId);
		q.setParameter("matchIndicator", matchIndicator);
		q.setParameter("targetCIC", targetCIC);
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching multi unit target details based on corpItemCode");
		em.close();
		return results;
	}

	public List<Object[]> fetchMultiUnitUPCPopUpDetals(String corpItemCd) {
		
		StringBuilder baseQuery = new StringBuilder("");
		baseQuery.append("select distinct  CONCAT (MUD.upc_country,MUD.upc_system,right(replicate('0',5) + cast(MUD.upc_manuf as varchar),5) ,right(replicate('0',5) + cast(MUD.upc_sales as varchar),5))  as \"UPC\",MUD.UNIT_TYPE, URX.PACK_RETAIL ");
		baseQuery.append(" from  ECFLAND.MULTI_UNIT_TYPE_SSIMS_DATA MUD LEFT JOIN  SSIMSLAND.SQLDAT3_SSITMURX URX");
		baseQuery.append(" on MUD.corp_item_cd=URX.corp_item_Cd");
		baseQuery.append(" and MUD.upc_country =URX.upc_country and MUD.upc_system =URX.upc_system");
		baseQuery.append(" and MUD.upc_manuf =URX.upc_manuf and MUD.upc_sales =URX.upc_sales");		
		baseQuery.append(" where MUD.corp_item_cd= ?	");		
		baseQuery.append(" order by 1 asc");
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory().createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "2000");
		q.setParameter(1, corpItemCd);
		List<Object[]> results = q.getResultList();
		LOG.info("Completed Fetching multi unit target details based on corpItemCode");
		em.close();

		return results;
	}
}
