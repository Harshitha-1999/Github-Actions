package com.safeway.app.memi.data.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Entity class for Database table ITEM_CONV_DISPLAY_ITEMS.
 * 
 */

@Entity
@Table(name = "ITEM_CONV_DISPLAY_ITEMS", schema="ECFLAND")
@NamedQuery(name = "ItemConvDisplayItem.findAll", query = "SELECT s FROM ItemConvDisplayItem s")
public class ItemConvDisplayItem implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ItemConvDisplayItemPk itemConvDisplayItemPk;
	
	@Column(name = "SRC_ITEM_DESC")
	private String srcItemDesc;
	
	@Column(name = "CASE_UPC")
	private String caseUpc;
	
	@Column(name = "CORP_ITEM_CD")
	private BigDecimal cic;
	
	@Column(name = "ITEM_DESC")
	private String itemDesc;
	
	@Column(name = "COMP_ITEM_DESC")
	private String compItemDesc;
	
	@Column(name = "SHELF_UNIT")
	private BigDecimal shelfUnit;
	
	@Column(name = "COST_MEMO")
	private BigDecimal costMemo;

	@Column(name = "NEW_CIC_IND")
	private Character newCicInd;
	
	@Column(name = "DISPLAY_ITEM_PROCESSED_IND")
	private Character displayItemProcessedIndicator;
	
	@Column(name = "MATCH_TYPE")
	private Character matchType;

	public ItemConvDisplayItemPk getItemConvDisplayItemPk() {
		return itemConvDisplayItemPk;
	}

	public void setItemConvDisplayItemPk(ItemConvDisplayItemPk itemConvDisplayItemPk) {
		this.itemConvDisplayItemPk = itemConvDisplayItemPk;
	}

	public String getSrcItemDesc() {
		return srcItemDesc;
	}

	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public BigDecimal getCic() {
		return cic;
	}

	public void setCic(BigDecimal cic) {
		this.cic = cic;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getCompItemDesc() {
		return compItemDesc;
	}

	public void setCompItemDesc(String compItemDesc) {
		this.compItemDesc = compItemDesc;
	}

	public BigDecimal getShelfUnit() {
		return shelfUnit;
	}

	public void setShelfUnit(BigDecimal shelfUnit) {
		this.shelfUnit = shelfUnit;
	}

	public BigDecimal getCostMemo() {
		return costMemo;
	}

	public void setCostMemo(BigDecimal costMemo) {
		this.costMemo = costMemo;
	}

	public Character getNewCicInd() {
		return newCicInd;
	}

	public void setNewCicInd(Character newCicInd) {
		this.newCicInd = newCicInd;
	}

	public Character getDisplayItemProcessedIndicator() {
		return displayItemProcessedIndicator;
	}

	public void setDisplayItemProcessedIndicator(
			Character displayItemProcessedIndicator) {
		this.displayItemProcessedIndicator = displayItemProcessedIndicator;
	}

	public Character getMatchType() {
		return matchType;
	}

	public void setMatchType(Character matchType) {
		this.matchType = matchType;
	}
	
	

}
