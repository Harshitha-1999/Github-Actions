package com.safeway.app.memi.domain.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.Borders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.domain.dtos.response.DCDetailsVo;
import com.safeway.app.memi.domain.dtos.response.ExceptionReportDto;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.services.ExceptionSrcService;



@Component
public class ExceptionReportWritter {
	private static final Logger LOG = LoggerFactory
			.getLogger(ExceptionReportWritter.class);
	public static final String BILLING_SUMMARY_SHEET_NAME = "Forecast";
	public static final String EQUALS = "=";
	public static final String MULTIPY = "*";
	public static final String COMMA = ",";
	public static final String DAYS_SHEET_NAME_COL = "Days!";
	public static final String BUDGET_PERIOD_HEADER = "Budget P";
	public static final String BUDGET_MONTH_HEADER = "Budget ";
	public static final String RESOURCE_HEADER = " Resource";
	public static final String NB_HEADER = " NB";
	long count = 1;
	
	public static final String[] NB_TYPES = {"Buffer"};

	
	public static final int DAILY_HOURS = 8;
	public static final int WEEK_HOURS = 40;

	/*public static String[] headersNew = { "Product SKU", "UPC", 
			"Item Desc", "Internet Desc", "Pack", "VCF", "Num Size", "Case UPC", "Usage IND", "Display IND", 
			"Product Src", "Vendor Cost", "Slot Id", "Onhand Nbr",  "Category",  "Sub Category", "Group", "New Date", "Last Ship Date",
			"Last Sale Date", "Total Sales", "Cases Ordered",
			"Production Group Code","Production Category Code","Production Class Code","Ethynic Type Code","Package Type Code","Product Class Code","Inner Pack","Retail Unit Pack",
			"Upd Item Desc","Upd Whse Item Desc","Upd Rtl Item Desc","Upd Internet Item Desc","Upd Pos Desc","Upd Item Usage Ind","Upd Item Usage Type Ind","Upd Private Label Ind",
			"Upd Display Flag","Upd Size","Upd Size Num","Upd Size Uom","Group Code","Category Code","Class Code","Sub Class Code","Sub Sub Class Code","Conv Team Comments Txt"
	};*/
	
	public static String[] headersNew = { 
		"Mark Dead","Product SKU", "UPC","Item Desc", "Internet Item Desc","Whse Item Desc",
		"Rtl Item Desc","Pos Desc","Pack", "VCF", "Num Size", "Case UPC", "Usage IND", 
		"Display IND","Product Src", "Vendor Cost", "Slot Id","Onhand Nbr", "Category",
		"Sub Category", "Group","New Date", "Last Ship Date","Last Sale Date", "Total Sales",
		"Cases Ordered","Upd Item Desc","Upd Whse Item Desc","Upd Rtl Item Desc",
		"Upd Internet Item Desc","Upd Pos Desc","Group Code","Category Code","Class Code",
		"Sub Class Code","Sub Sub Class Code","Production Group Code","Production Category Code",
		"Production Class Code","Product Class Code","Upd Size","Upd Size Num","Upd Size Uom",
		"Inner Pack","Retail Unit Pack","Upd Item Usage Ind","Upd Item Usage Type Ind",
		"Upd Private Label Ind","Upd Display Flag","Ethnic Type Code","Package Type Code",
		"Upd UPC","Upd PLU Cd","Dc Pack Desc","Dc Size desc","Ring","Hicone",
		
		"Prod Weight","Handling Code","Buyer Num","Random Wt Cd","AutoCostInv", 
		"Billing Type","Food Stamp","Label Size","Label Numbers","Sgn Count1",
		"Sgn Count2","Sgn Count3","Sell By Days","Use By Days","Pull By Days","Tare",
		"Conv Team Comments Txt"
	};

	public static String[] headers = { "Product SKU", "SRC_Primary_UPC",
			"SRC_Item Desc", "SRC_WHSE Desc", "SRC_S&S Desc",
			"SRC_Internet Desc", "SRC_POS Desc", "SRC_Case UPC", "SRC_Pack",
			"SRC_VCF", "SRC_Desc Size", "SRC_Num Size", "SRC_Usage",
			"SRC_Product Src", "SRC_Display", "SRC_Cost", "CIC",
			"LIKITM_Primary_UPC", "LIKITM_True DSD_ IND", "LIKITM _Item Desc",
			"LIKITM _WHSE Desc", "LIKITM _S&S Desc", "LIKITM _Internet Desc",
			"LIKITM _POS Desc", "LIKITM _Case UPC", "LIKITM _Pack",
			"LIKITM _VCF", "LIKITM _Desc Size", "LIKITM _Num Size",
			"LIKITM _Usage IND & TYPE", "LIKITM _Product Src",
			"LIKITM _Display", "LIKITM _Cost", "SMIC", "SMIC Desc",
			"Department Name", "Department Number", "Private Label" };
		
	Workbook wb;
	Sheet exception;
	Sheet exceptionsSheet;
	LikeItemUtils likeItemUtils;
	
	List<ExceptionReportDto> data;
	
	@Autowired
	private ExceptionSrcService exceptionService;
	
	@Autowired
	private CommonSQLRepository commonSQLRepo;
	
	
	CellStyle holidayStyle;
	CellStyle weekDayStyle;
	CellStyle fcHeader;
	CellStyle fcEvenRow;
	CellStyle fcOddRow;
	CellStyle currencyStyle;
	
	String billRateColumn = "";
	
	
	public String createExceptionReportSheet(String fileName, String department, String company, String division, char exceptionType, char exceptionProcessedInd) {
		LOG.info("Execution started for createExceptionReportSheet");
		likeItemUtils= new LikeItemUtils() ; 
		wb = new XSSFWorkbook();
		fcHeader = null;
		fcOddRow = null;
		fcEvenRow = null;
		String departmentName = "";
		
		exceptionsSheet = wb.getSheet("Exceptions");
		if(exceptionsSheet == null)
			exceptionsSheet = wb.createSheet("Exceptions"+count);
		count++;
		int rowIndex = 0;
		Row header = exceptionsSheet.createRow(rowIndex);
		int colIndex = 0;
		
		for(String headerString : headersNew) {
			Cell cell = header.createCell(colIndex++);
			cell.setCellStyle(getHeaderStyle());
			cell.setCellValue(headerString);
		}
		long start = System.currentTimeMillis();
		List<Object[]> records = commonSQLRepo.fetchDepartmentWiseExportExceptions(company, division, department, exceptionType, exceptionProcessedInd);
		long end = System.currentTimeMillis();
		float sec = (end - start) / 1000F;
		LOG.info("DB query execution time {}",sec);
		LOG.info("DB query execution time to get the record count {}",records.size());
		List<UIExceptionSrcDto> exceptionRecords = buildLikeItemDetailDtoListNew(records);
		LOG.info("Completed fetching all"+exceptionRecords.size()+"exceptionRecords");
		long start1 = System.currentTimeMillis();
		if(!exceptionRecords.isEmpty()){
			Collections.sort(exceptionRecords,new ExcelSortSeqComparator());
		}
		if(exceptionRecords != null && !exceptionRecords.isEmpty()){
			departmentName = exceptionRecords.get(0).getHierLevel5();
			if(departmentName != null)
				departmentName = departmentName.trim();
		}
		
		for(UIExceptionSrcDto srcRecord : exceptionRecords) {
			
			colIndex = 0;
			Row row = exceptionsSheet.createRow(++rowIndex);
			CellStyle rowStyle = getRowStyle(rowIndex);
			
			Cell cell0 = createCell(row, colIndex++, rowStyle);
			cell0.setCellValue("");
			
			Cell cell1 = createCell(row, colIndex++, rowStyle);
			cell1.setCellValue(srcRecord.getProductSKU());
			
			Cell cell2 = createCell(row, colIndex++, rowStyle);
			cell2.setCellValue(srcRecord.getPrimaryUPCVo().getUpc());

			Cell cell3 = createCell(row, colIndex++, rowStyle);
			cell3.setCellValue(srcRecord.getItmDescrbtn());

			Cell cell4 = createCell(row, colIndex++, rowStyle);
			cell4.setCellValue(srcRecord.getIntenetItemDescrbtn());
			
			Cell cell5 = createCell(row, colIndex++, rowStyle);
			cell5.setCellValue(srcRecord.getWhseItmDescrbtn());
			
			Cell cell6 = createCell(row, colIndex++, rowStyle);
			cell6.setCellValue(srcRecord.getRtlItmDescrbtn());
			
			Cell cell7 = createCell(row, colIndex++, rowStyle);
			cell7.setCellValue(srcRecord.getPosDescrbtn());

			Cell cell8 = createCell(row, colIndex++, rowStyle);
			cell8.setCellValue(srcRecord.getPackWhse().doubleValue());

			Cell cell9 = createCell(row, colIndex++, rowStyle);
			cell9.setCellValue(srcRecord.getVdCnvFactor().doubleValue());
			
			Cell cell10 = createCell(row, colIndex++, rowStyle);
			cell10.setCellValue(srcRecord.getSizeNbr().doubleValue());

			Cell cell11 = createCell(row, colIndex++, rowStyle);
			cell11.setCellValue(likeItemUtils.formatCaseUpc(srcRecord.getCaseUPC()));

			Cell cell12 = createCell(row, colIndex++, rowStyle);
			cell12.setCellValue(""+(Character)srcRecord.getItmUsgeInd());

			Cell cell13 = createCell(row, colIndex++, rowStyle);
			cell13.setCellValue(""+(Character)srcRecord.getDspFlag());

			Cell cell14 = createCell(row, colIndex++, rowStyle);
			cell14.setCellValue(srcRecord.getProductSrcCd());
			
			Cell cell15 = createCell(row, colIndex++, rowStyle);
			cell15.setCellValue("$"+srcRecord.getCostItm());
			
			Cell cell16 = createCell(row, colIndex++, rowStyle);
			cell16.setCellValue(srcRecord.getSlotId());
			
			Cell cell17 = createCell(row, colIndex++, rowStyle);
			cell17.setCellValue(srcRecord.getOnhandNbr() != null ? srcRecord.getOnhandNbr().doubleValue() : 0 );
			
			Cell cell18 = createCell(row, colIndex++, rowStyle);
			cell18.setCellValue(srcRecord.getCategoryDesc());
			
			Cell cell19 = createCell(row, colIndex++, rowStyle);
			cell19.setCellValue(srcRecord.getSubCategoryDesc());
			
			Cell cell20 = createCell(row, colIndex++, rowStyle);
			cell20.setCellValue(srcRecord.getGroupDesc());
			
			Cell cell21 = createCell(row, colIndex++, rowStyle);
			cell21.setCellValue(srcRecord.getNewDate());
			
			Cell cell22 = createCell(row, colIndex++, rowStyle);
			cell22.setCellValue(srcRecord.getLastShipDate());
			
			Cell cell23 = createCell(row, colIndex++, rowStyle);
			cell23.setCellValue(srcRecord.getLastSaleDate());
			
			Cell cell24 = createCell(row, colIndex++, rowStyle);
			cell24.setCellValue(srcRecord.getTotalSales() != null ? srcRecord.getTotalSales().doubleValue() : 0 );
			
			Cell cell25 = createCell(row, colIndex++, rowStyle);
			cell25.setCellValue(srcRecord.getCasesOrdered() != null ? srcRecord.getCasesOrdered().doubleValue() : 0 );
			
			Cell cell26 = createCell(row, colIndex++, rowStyle);
			cell26.setCellValue(srcRecord.getUpdItemDesc());

			Cell cell27 = createCell(row, colIndex++, rowStyle);
			cell27.setCellValue(srcRecord.getUpdWhseItemDesc());
			
			Cell cell28 = createCell(row, colIndex++, rowStyle);
			cell28.setCellValue(srcRecord.getUpdRtlItemDesc());
			
			Cell cell29 = createCell(row, colIndex++, rowStyle);
			cell29.setCellValue(srcRecord.getUpdInternetItemDesc());
			
			Cell cell30 = createCell(row, colIndex++, rowStyle);
			cell30.setCellValue(srcRecord.getUpdPosDesc());
			
			Cell cell31 = createCell(row, colIndex++, rowStyle);
			
			Cell cell32 = createCell(row, colIndex++, rowStyle);
			
			Cell cell33 = createCell(row, colIndex++, rowStyle);
			
			Cell cell34 = createCell(row, colIndex++, rowStyle);
			
			Cell cell35 = createCell(row, colIndex++, rowStyle);
			
			if(Character.valueOf(exceptionProcessedInd).equals('C')||Character.valueOf(exceptionProcessedInd).equals('R')){
				cell31.setCellValue(srcRecord.getGrpCd());
				cell32.setCellValue(srcRecord.getCtgryCd());
				cell33.setCellValue(srcRecord.getClsCd());
				cell34.setCellValue(srcRecord.getSbClsCd());
				cell35.setCellValue(srcRecord.getSubSbClassCd());
			}else{
				cell31.setCellValue("");
				cell32.setCellValue("");
				cell33.setCellValue("");
				cell34.setCellValue("");
				cell35.setCellValue("");
			}
			
			Cell cell36 = createCell(row, colIndex++, rowStyle);
			cell36.setCellValue(srcRecord.getProductionGrpCd());
			
			Cell cell37 = createCell(row, colIndex++, rowStyle);
			cell37.setCellValue(srcRecord.getProductionCtgryCd());
			
			Cell cell38 = createCell(row, colIndex++, rowStyle);
			cell38.setCellValue(srcRecord.getProductionClsCd());
			
			Cell cell39 = createCell(row, colIndex++, rowStyle);
			cell39.setCellValue(srcRecord.getProductClsCd());
			
			Cell cell40 = createCell(row, colIndex++, rowStyle);
			cell40.setCellValue(srcRecord.getUpdSize());
			
			Cell cell41 = createCell(row, colIndex++, rowStyle);
			cell41.setCellValue(srcRecord.getUpdSizeNmbr()!= null ? srcRecord.getUpdSizeNmbr().doubleValue() : 0);
			
			Cell cell42 = createCell(row, colIndex++, rowStyle);
			cell42.setCellValue(srcRecord.getUpdSizeUom());
			
			Cell cell43 = createCell(row, colIndex++, rowStyle);
			cell43.setCellValue(srcRecord.getInnerPack());
			
			Cell cell44 = createCell(row, colIndex++, rowStyle);
			cell44.setCellValue(srcRecord.getRetailUnitPack());
			
			Cell cell45 = createCell(row, colIndex++, rowStyle);
			cell45.setCellValue(""+(Character)srcRecord.getUpdItemUsageInd());
			
			Cell cell46 = createCell(row, colIndex++, rowStyle);
			cell46.setCellValue(""+(Character)srcRecord.getUpdItemUsageTypInd());
			
			Cell cell47 = createCell(row, colIndex++, rowStyle);
			cell47.setCellValue(""+(Character)srcRecord.getUpdPrivateLabelInd());
			
			Cell cell48 = createCell(row, colIndex++, rowStyle);
			cell48.setCellValue(""+(Character)srcRecord.getUpdDispFlag());
			
			Cell cell49 = createCell(row, colIndex++, rowStyle);
			cell49.setCellValue(srcRecord.getEthnicTypeCd());
			
			Cell cell50 = createCell(row, colIndex++, rowStyle);
			cell50.setCellValue(srcRecord.getPckTypeId()!= null ? srcRecord.getPckTypeId().doubleValue() : 0 );
			
			/*PRODUCE PLU and other addtional */
			
			Cell cell51 = createCell(row, colIndex++, rowStyle);
			cell51.setCellValue(srcRecord.getUpc().toLowerCase());//upc
			

			Cell cell52 = createCell(row, colIndex++, rowStyle);
			if (Double.parseDouble(srcRecord.getUpc().replaceAll("-", "")) < 100000)
			cell52.setCellValue(Double.parseDouble(srcRecord.getUpc().replaceAll("-", "")));//plu
			else
			cell52.setCellValue("");//plu	
			
			Cell cell53 = createCell(row, colIndex++, rowStyle);
			cell53.setCellValue(srcRecord.getPackWhse().doubleValue());//dc pack
			
			Cell cell54 = createCell(row, colIndex++, rowStyle);
			cell54.setCellValue(srcRecord.getSzDesc());//dc size
			
			Cell cell55 = createCell(row, colIndex++, rowStyle);
			cell55.setCellValue(srcRecord.getSrcRing());//ring
			
			Cell cell56 = createCell(row, colIndex++, rowStyle);
			cell56.setCellValue(srcRecord.getSrcHicone());//hicone
			
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcProdwght());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcHandlingCode());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcBuyerNum());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcRandomWtCd());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcAutoCostInv());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcBillingType());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcFdStmp());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcLabelSize());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcLabelNumbers());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcSgnCount1());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcSgnCount2());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSrcSgnCount3());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getSellByDays());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getUseByDays());
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getPullBydays());			
			createCell(row, colIndex++, rowStyle).setCellValue(srcRecord.getTareCd());
			
			/*PRODUCE PLU*/
			Cell cell57 = createCell(row, colIndex++, rowStyle);
			cell57.setCellValue(srcRecord.getConvTeamComments());
			
		}

		for(int ii=0;ii<72;ii++) {
			exceptionsSheet.autoSizeColumn(ii);
		}
		
		String dir = fileName;
		File file = new File(dir , "Exceptions.xlsx");
		
		// Write the output to a file
		try (FileOutputStream fileOut = new FileOutputStream(file)) {
			wb.write(fileOut);
		} catch (IOException e) {
			LOG.error("Exception in generating the export to excel file"+e.getMessage());
			
			System.exit(-1);
		}
		long end1 = System.currentTimeMillis();
		float sec1 = (end1 - start1) / 1000F;
		LOG.info("Execution completed for createExceptionReportSheet {}",sec1);
		return departmentName;
	}
	
public void createExceptionReportSheetOld(String fileName, String department, String company, String division) {
	LOG.info("Execution started for createExceptionReportSheetOld");
		wb = new XSSFWorkbook();
		fcHeader = null;
		fcOddRow = null;
		fcEvenRow = null;
		
		exceptionsSheet = wb.getSheet("Exceptions");
		if(exceptionsSheet == null)
			exceptionsSheet = wb.createSheet("Exceptions");
		
		int rowIndex = 0;
		Row header = exceptionsSheet.createRow(rowIndex);
		int colIndex = 0;
		
		for(String headerString : headers) {
			Cell cell = header.createCell(colIndex++);
			cell.setCellStyle(getHeaderStyle());
			cell.setCellValue(headerString);
		}
		
		List<Object[]> records = commonSQLRepo.fetchDepartmentWiseExportRecords(company, division, department);
		List<OverrideDataVo> overrideRecords = buildLikeItemDetailDtoList(records);
		List<Object[]> rogRankings = commonSQLRepo.loadROGRanking(overrideRecords.get(0).getUiEceptionSrcDto().getCompanyId(), overrideRecords.get(0).getUiEceptionSrcDto().getDivisionId());
		LOG.debug("Completed fetching all"+rogRankings.size()+"rogRankings");
		for(OverrideDataVo record : overrideRecords) {
			
			colIndex = 0;
			Row row = exceptionsSheet.createRow(++rowIndex);
			CellStyle rowStyle = getRowStyle(rowIndex);
			UIExceptionSrcDto srcRecord = record.getUiEceptionSrcDto();
			List<NewItemDetailDto> orderedLikeItems = new LikeItemUtils().orderLikeItems(record.getLikeItems(),
					srcRecord, rogRankings);
			NewItemDetailDto likeItem = orderedLikeItems.get(0);
			
			Cell cell0 = createCell(row, colIndex++, rowStyle);
			cell0.setCellValue(srcRecord.getProductSKU());
			
			Cell cell1 = createCell(row, colIndex++, rowStyle);
			cell1.setCellValue(srcRecord.getPrimaryUPCforDisplay());

			Cell cell2 = createCell(row, colIndex++, rowStyle);
			cell2.setCellValue(srcRecord.getItmDescrbtn());

			Cell cell3 = createCell(row, colIndex++, rowStyle);
			cell3.setCellValue(srcRecord.getWhseItmDescrbtn());

			Cell cell4 = createCell(row, colIndex++, rowStyle);
			cell4.setCellValue(srcRecord.getRtlItmDescrbtn());

			Cell cell5 = createCell(row, colIndex++, rowStyle);
			cell5.setCellValue(srcRecord.getIntenetItemDescrbtn());

			Cell cell6 = createCell(row, colIndex++, rowStyle);
			cell6.setCellValue(srcRecord.getPosDescrbtn());

			Cell cell7 = createCell(row, colIndex++, rowStyle);
			cell7.setCellValue(srcRecord.getPrimaryUPC());

			Cell cell8 = createCell(row, colIndex++, rowStyle);
			cell8.setCellValue(srcRecord.getPackWhse().doubleValue());
			
			Cell cell9 = createCell(row, colIndex++, rowStyle);
			cell9.setCellValue(srcRecord.getVdCnvFactor().doubleValue());

			Cell cell10 = createCell(row, colIndex++, rowStyle);
			cell10.setCellValue(srcRecord.getSzDesc());

			Cell cell11 = createCell(row, colIndex++, rowStyle);
			cell11.setCellValue(srcRecord.getSizeNbr().doubleValue());

			Cell cell12 = createCell(row, colIndex++, rowStyle);
			cell12.setCellValue(""+(Character)srcRecord.getItmUsgeInd());

			Cell cell13 = createCell(row, colIndex++, rowStyle);
			cell13.setCellValue(srcRecord.getProductSrcCd());

			Cell cell14 = createCell(row, colIndex++, rowStyle);
			cell14.setCellValue(""+(Character)srcRecord.getDspFlag());

			Cell cell15 = createCell(row, colIndex++, rowStyle);
			cell15.setCellValue(srcRecord.getCostItm());

			Cell cell16 = createCell(row, colIndex++, rowStyle);
			cell16.setCellValue(likeItem.getDtaOverCic().doubleValue());

			Cell cell17 = createCell(row, colIndex++, rowStyle);
			cell17.setCellValue(likeItem.getPrimayUpcString());

			Cell cell18 = createCell(row, colIndex++, rowStyle);
			cell18.setCellValue(""+(Character)likeItem.getTrueDSDFlag());

			Cell cell19 = createCell(row, colIndex++, rowStyle);
			cell19.setCellValue(likeItem.getUpdItmDesc());

			Cell cell20 = createCell(row, colIndex++, rowStyle);
			cell20.setCellValue(likeItem.getUpdWhseItmDesc());

			Cell cell21 = createCell(row, colIndex++, rowStyle);
			cell21.setCellValue(likeItem.getUpdRtlItmDesc());

			Cell cell22 = createCell(row, colIndex++, rowStyle);
			cell22.setCellValue(likeItem.getUpdIntenetItemDesc());

			Cell cell23 = createCell(row, colIndex++, rowStyle);
			cell23.setCellValue(likeItem.getUpdPosDesc());

			Cell cell24 = createCell(row, colIndex++, rowStyle);
			cell24.setCellValue(likeItem.getCaseUPC());

			Cell cell25 = createCell(row, colIndex++, rowStyle);
			cell25.setCellValue(likeItem.getPackwhse().doubleValue());

			Cell cell26 = createCell(row, colIndex++, rowStyle);
			cell26.setCellValue(likeItem.getVendConvFactor().doubleValue());

			Cell cell27 = createCell(row, colIndex++, rowStyle);
			cell27.setCellValue(likeItem.getDescSize());

			Cell cell28 = createCell(row, colIndex++, rowStyle);
			cell28.setCellValue(likeItem.getUpdSizeNmbr().doubleValue());

			Cell cell29 = createCell(row, colIndex++, rowStyle);
			cell29.setCellValue(likeItem.getUpdUsageTypInd() + " & " +likeItem.getUpdUsgeInd());

			Cell cell30 = createCell(row, colIndex++, rowStyle);
			cell30.setCellValue(likeItem.getProductSrcCd());

			Cell cell31 = createCell(row, colIndex++, rowStyle);
			cell31.setCellValue(""+(Character)likeItem.getDispFlag());

			Cell cell32 = createCell(row, colIndex++, rowStyle);
			cell32.setCellValue(likeItem.getCost());

			Cell cell33 = createCell(row, colIndex++, rowStyle);
			cell33.setCellValue(likeItem.getSmicCodeForDisplay());

			Cell cell34 = createCell(row, colIndex++, rowStyle);
			cell34.setCellValue(likeItem.getSMICDesc());

			Cell cell35 = createCell(row, colIndex++, rowStyle);
			cell35.setCellValue(likeItem.getDeptName());

			Cell cell36 = createCell(row, colIndex++, rowStyle);
			cell36.setCellValue(likeItem.getDeptCd());

			Cell cell37 = createCell(row, colIndex++, rowStyle);
			cell37.setCellValue(""+(Character)likeItem.getUpdPtLabelInd());
			
		}

		for(int ii=0;ii<36;ii++) {
			exceptionsSheet.autoSizeColumn(ii);
		}
		
		String dir = fileName;
		File file = new File(dir , "Exceptions.xlsx");
		
		// Write the output to a file
		try (FileOutputStream fileOut = new FileOutputStream(file)) {
			wb.write(fileOut);
		} catch (IOException e) {
			LOG.error("Exception in generating the export to excel file"+e.getMessage());
			System.exit(-1);
		}
		LOG.info("Execution completed for createExceptionReportSheetOld");
	}
	
	public Cell createCell(Row row, int index, CellStyle cs) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cs);		
		return cell;
	}
	
	private CellStyle getRowStyleTemplate() {
		LOG.debug("Execution started for getRowStyleTemplate");
		CellStyle template = wb.createCellStyle();
		
		Font f = wb.createFont();
		f.setFontName("Calibri");
		//f.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		f.setBold(false);
		template.setFont(f);
		
		template.setBorderRight(BorderStyle.THIN);
		template.setRightBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderLeft(BorderStyle.THIN);
		template.setLeftBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderTop(BorderStyle.THIN);
		template.setTopBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderBottom(BorderStyle.THIN);
		template.setBottomBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());	
		template.setWrapText(true);
		LOG.debug("Execution completed for getRowStyleTemplate");
		return template;
	}
	
	public CellStyle getHeaderStyle() {
		if(fcHeader == null) {
			
			fcHeader = wb.createCellStyle();
			
			XSSFCellStyle cs = (XSSFCellStyle)fcHeader;
			cs.setFillForegroundColor(new XSSFColor(new Color(192, 192, 192)));
			
			Font f = wb.createFont();
			f.setColor(IndexedColors.BLACK.getIndex());
			f.setFontName("Calibri");
			//f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			f.setBold(true);
			fcHeader.setFont(f);
			fcHeader.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			fcHeader.setBorderRight(BorderStyle.THIN);
			fcHeader.setRightBorderColor(IndexedColors.BLACK.getIndex());
			fcHeader.setBorderLeft(BorderStyle.THIN);
			fcHeader.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			fcHeader.setBorderTop(BorderStyle.THIN);
			fcHeader.setTopBorderColor(IndexedColors.BLACK.getIndex());
			fcHeader.setBorderBottom(BorderStyle.THIN);
			fcHeader.setBottomBorderColor(IndexedColors.BLACK.getIndex());			
		}
		return fcHeader;
	}
	
	public CellStyle getRowStyle(int row) {
		if(fcOddRow == null) {
			fcOddRow = getRowStyleTemplate();
			XSSFCellStyle cs = (XSSFCellStyle)fcOddRow;
			cs.setFillForegroundColor(new XSSFColor(new Color(220, 230, 241)));
			fcOddRow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}
		if(fcEvenRow == null) {
			fcEvenRow = getRowStyleTemplate();
			XSSFCellStyle cs = (XSSFCellStyle)fcEvenRow;
			cs.setFillForegroundColor(new XSSFColor(new Color(255, 255, 255)));
			fcEvenRow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}
		
		if(row%2==0) {
			return fcEvenRow;
		}
		else {
			return fcOddRow;
		}
	}


	public static String[] getHeaders() {
		return headers;
	}
	
	
	public List<UIExceptionSrcDto> buildLikeItemDetailDtoListNew(
			List<Object[]> likeItemObjList) {
		LOG.info("Execution started for buildLikeItemDetailDtoListNew");
		UIExceptionSrcDto excSrcDto = new UIExceptionSrcDto();
		List<UIExceptionSrcDto> exceptionList = new ArrayList<>();
		for (Object[] excSrcObj : likeItemObjList) {
			
			excSrcDto = new UIExceptionSrcDto();
			excSrcDto.setCompanyId(getStringValue(excSrcObj[0]));
			excSrcDto.setDivisionId(getStringValue(excSrcObj[1]));
			excSrcDto.setProductSKU(getStringValue(excSrcObj[2]));
			String upcCountry=StringUtils.leftPad(getBigDecimalValue(excSrcObj[4]).toString(), 1, "0");
			String upcSystem=StringUtils.leftPad(getBigDecimalValue(excSrcObj[5]).toString(), 1, "0");
			String upcManuf=StringUtils.leftPad(getBigDecimalValue(excSrcObj[6]).toString(), 5, "0");
			String upcSales=StringUtils.leftPad(getBigDecimalValue(excSrcObj[7]).toString(), 5, "0");
			excSrcDto.setUpcCountry(upcCountry);
			excSrcDto.setUpcSystem(upcSystem);
			excSrcDto.setUpcManufacturer(upcManuf);
			excSrcDto.setUpcSales(upcSales);
			StringBuilder upc=new StringBuilder().append(upcCountry).append(upcSystem).append(upcManuf).append(upcSales);
			excSrcDto.setUpc(upc.toString());
			
			String heirarchyLvl2 = getStringValue(excSrcObj[87]);//PROD_GROUP_CD
			String heirarchyLvl3 = getStringValue(excSrcObj[88]);//PROD_CATEGORY_CD
			String heirarchyDesc = getStringValue(excSrcObj[90]);//HIERARCHY_LEVEL_DESC
					
			if(!exceptionList.contains(excSrcDto)){
				// RING value logic related code
				long start = System.currentTimeMillis();
				/*List<Object[]> produceInfo=commonSQLRepo.getProduceRelatedData(excSrcDto.getCompanyId(), excSrcDto.getDivisionId(), excSrcDto.getProductSKU());
				long end = System.currentTimeMillis();
				float sec = (end - start) / 1000F;
				LOG.info("DB query execution time getProduceRelatedData {}",sec);
				LOG.info("Completed fetching all"+produceInfo.size()+"produceInfo");
				if(!produceInfo.isEmpty())
				{
					for(Object[] obj :produceInfo)
					{
						if(obj[0]!=null && obj[0].toString().equalsIgnoreCase("W") )
							excSrcDto.setSelling_method_cd("POUND");	
						else if(obj[0]!=null && obj[0].toString().equalsIgnoreCase("E") )
							excSrcDto.setSelling_method_cd("EACH");
						
						if(obj[1]!=null && obj[1].toString().equalsIgnoreCase("N") )
							excSrcDto.setReceiving_cd("CASE");	
						else if(obj[1]!=null && obj[1].toString().equalsIgnoreCase("Y") )
							excSrcDto.setReceiving_cd("POUND");	
					}
				} */
				excSrcDto.setSrcRing(excSrcObj[85] != null ? getStringValue(excSrcObj[85]) : null);
				String srcItemDesc=getStringValue(excSrcObj[15]);
				String srcWhseItemDesc=getStringValue(excSrcObj[16]);
				String srcRtlItemDesc=getStringValue(excSrcObj[17]);
				String srcInternetItemDesc=getStringValue(excSrcObj[18]);
				String srcPosDesc=getStringValue(excSrcObj[19]);
				
				String updItemDesc=getStringValue(excSrcObj[45]);
				String updWhseItemDesc=getStringValue(excSrcObj[46]);
				String updRtlItemDesc=getStringValue(excSrcObj[47]);
				String updInternetItemDesc=getStringValue(excSrcObj[48]);
				String updPosDesc=getStringValue(excSrcObj[49]);
				
				String innerPack= getDoubleValue(excSrcObj[62]).toString();
				String retailUnitPack=getBigDecimalValue(excSrcObj[63]).toString();
				
				Character srcItemUsageInd=getCharacterValue(excSrcObj[11]);
				Character srcItemUsageTypeInd=getCharacterValue(excSrcObj[12]);
				Character srcPrivateLabelInd=getCharacterValue(excSrcObj[13]);
				Character srcDisplayFlagInd=getCharacterValue(excSrcObj[14]);
				
				String srcSizeDesc=getStringValue(excSrcObj[24]);
				BigDecimal srcSizeNumber=getBigDecimalValue(excSrcObj[22]);
				String srcSizeUom=getStringValue(excSrcObj[23]);
				
				Character updItemUsageInd=getCharacterValue(excSrcObj[64]);
				Character updItemUsageTypeInd=getCharacterValue(excSrcObj[65]);
				Character updPrivateLabelInd=getCharacterValue(excSrcObj[66]);
				Character updDisplayFlagInd=getCharacterValue(excSrcObj[67]);
				String updSizeDesc=getStringValue(excSrcObj[59]);
				BigDecimal updSizeNumber=getBigDecimalValue(excSrcObj[60]);
				String updSizeUom=getStringValue(excSrcObj[61]);
				
				
				excSrcDto.setProductSrcCd(getStringValue(excSrcObj[3]));
				excSrcDto.setCaseUPC(getStringValue(excSrcObj[8]));
				excSrcDto.setItmUsgeInd(srcItemUsageInd);
				excSrcDto.setItmUsgeTypInd(srcItemUsageTypeInd);
				excSrcDto.setPtLblInd(srcPrivateLabelInd);
				excSrcDto.setDspFlag(srcDisplayFlagInd);
				
				excSrcDto.setItmDescrbtn(srcItemDesc);
				excSrcDto.setWhseItmDescrbtn(srcWhseItemDesc);
				excSrcDto.setRtlItmDescrbtn(srcRtlItemDesc);
				excSrcDto.setIntenetItemDescrbtn(srcInternetItemDesc);
				excSrcDto.setPosDescrbtn(srcPosDesc);
				
				excSrcDto.setVdCnvFactor(getBigDecimalValue(excSrcObj[20]));
				excSrcDto.setPackWhse(getBigDecimalValue(excSrcObj[21]));
				excSrcDto.setSizeNbr(srcSizeNumber);
				excSrcDto.setSzUom(srcSizeUom);
				
				excSrcDto.setSzDesc(srcSizeDesc);
				excSrcDto.setCostItm(getBigDecimalValue(excSrcObj[25]).toString());
				excSrcDto.setHierLevel1(getStringValue(excSrcObj[26]));
				excSrcDto.setHierLevel2(getStringValue(excSrcObj[27]));
				excSrcDto.setHierLevel3(getStringValue(excSrcObj[28]));
				excSrcDto.setHierLevel4(getStringValue(excSrcObj[29]));
				excSrcDto.setHierLevel5(getStringValue(excSrcObj[30]));
				excSrcDto.setExptnTypCd(getCharacterValue(excSrcObj[31]));
				excSrcDto.setExptnDesc(getStringValue(excSrcObj[32]));
				excSrcDto.setExcptnProInd(getCharacterValue(excSrcObj[33]));
				excSrcDto.setSlotId(getStringValue(excSrcObj[38]));
				excSrcDto.setOnhandNbr(getBigDecimalValue(excSrcObj[39]));
				excSrcDto.setNewDate(getDate(excSrcObj[40]));
				excSrcDto.setLastShipDate(getDate(excSrcObj[41]));
				excSrcDto.setLastSaleDate(getDate(excSrcObj[42]));
				excSrcDto.setTotalSales(getBigDecimalValue(excSrcObj[43]));
				excSrcDto.setCasesOrdered(BigDecimal.valueOf(getDoubleValue(excSrcObj[44])));
				
				if(!updItemDesc.isEmpty()){
					excSrcDto.setUpdItemDesc(updItemDesc);
				}else{
					excSrcDto.setUpdItemDesc(srcItemDesc);
				}
				if(!updWhseItemDesc.isEmpty()){
					excSrcDto.setUpdWhseItemDesc(updWhseItemDesc);
				}else{
					excSrcDto.setUpdWhseItemDesc(srcWhseItemDesc);
				}
				if(!updWhseItemDesc.isEmpty()){
					excSrcDto.setUpdWhseItemDesc(updWhseItemDesc);
				}else{
					excSrcDto.setUpdWhseItemDesc(srcWhseItemDesc);
				}
				if(!srcRtlItemDesc.isEmpty()){
					if(!updRtlItemDesc.isEmpty()){
						excSrcDto.setUpdRtlItemDesc(updRtlItemDesc);
					}else{
						excSrcDto.setUpdRtlItemDesc(srcRtlItemDesc);
					}
				}else{
					if(!updRtlItemDesc.isEmpty()){
						excSrcDto.setUpdRtlItemDesc(updRtlItemDesc);
					}else{
						excSrcDto.setUpdRtlItemDesc(srcItemDesc);
					}
				}
				if(!srcInternetItemDesc.isEmpty()){
					if(!updInternetItemDesc.isEmpty()){
						excSrcDto.setUpdInternetItemDesc(updInternetItemDesc);
					}else{
						excSrcDto.setUpdInternetItemDesc(srcInternetItemDesc);
					}
				}else{
					if(!updInternetItemDesc.isEmpty()){
						excSrcDto.setUpdInternetItemDesc(updInternetItemDesc);
					}else{
						excSrcDto.setUpdInternetItemDesc(srcItemDesc);
					}
				}
				
				if(!updPosDesc.isEmpty()){
					excSrcDto.setUpdPosDesc(updPosDesc);
				}else{
					excSrcDto.setUpdPosDesc(srcPosDesc);
				}
				
				excSrcDto.setGrpCd(getDoubleValue(excSrcObj[50]).intValue());
				excSrcDto.setCtgryCd(getDoubleValue(excSrcObj[51]).intValue());
				excSrcDto.setClsCd(getDoubleValue(excSrcObj[52]).intValue());
				excSrcDto.setSbClsCd(getDoubleValue(excSrcObj[53]).intValue());
				excSrcDto.setSubSbClassCd(getDoubleValue(excSrcObj[54]).intValue());
				
				excSrcDto.setProductionGrpCd(getDoubleValue(excSrcObj[55]).intValue());
				excSrcDto.setProductionCtgryCd(getDoubleValue(excSrcObj[56]).intValue());
				excSrcDto.setProductionClsCd(getDoubleValue(excSrcObj[57]).intValue());
				excSrcDto.setProductClsCd(getDoubleValue(excSrcObj[58]).intValue());
				if(!updSizeDesc.isEmpty()){
					excSrcDto.setUpdSize(updSizeDesc);
				}else{
					excSrcDto.setUpdSize(srcSizeDesc);
				}
				if(!updSizeNumber.equals(new BigDecimal(0))){
					excSrcDto.setUpdSizeNmbr(updSizeNumber);
				}else{
					excSrcDto.setUpdSizeNmbr(srcSizeNumber);
				}
				if(!updSizeUom.isEmpty()){
					excSrcDto.setUpdSizeUom(updSizeUom);
				}else{
					excSrcDto.setUpdSizeUom(srcSizeUom);
				}
				
				
				if(innerPack.equals("0")){
					excSrcDto.setInnerPack((new BigDecimal(1)).intValue());
				}else{
					excSrcDto.setInnerPack(getDoubleValue(excSrcObj[62]).intValue());
				}
				
				if(retailUnitPack.equals("0")){
					excSrcDto.setRetailUnitPack(getBigDecimalValue(excSrcObj[21]).intValue());
				}else{
					excSrcDto.setRetailUnitPack(getBigDecimalValue(excSrcObj[63]).intValue());
				}
				String emptyCharacter=" ";
				if(!updItemUsageInd.equals(Character.valueOf(emptyCharacter.charAt(0)))){
					excSrcDto.setUpdItemUsageInd(updItemUsageInd);
				}else{
					excSrcDto.setUpdItemUsageInd(srcItemUsageInd);
				}
				
				if(!updItemUsageTypeInd.equals(Character.valueOf(emptyCharacter.charAt(0)))){
					excSrcDto.setUpdItemUsageTypInd(updItemUsageTypeInd);
				}else{
					excSrcDto.setUpdItemUsageTypInd(srcItemUsageTypeInd);
				}
				
				if(!updPrivateLabelInd.equals(Character.valueOf(emptyCharacter.charAt(0)))){
					excSrcDto.setUpdPrivateLabelInd(updPrivateLabelInd);
				}else{
					excSrcDto.setUpdPrivateLabelInd(srcPrivateLabelInd);
				}
				
				if(!updDisplayFlagInd.equals(Character.valueOf(emptyCharacter.charAt(0)))){
					excSrcDto.setUpdDispFlag(updDisplayFlagInd);
				}else{
					excSrcDto.setUpdDispFlag(srcDisplayFlagInd);
				}
				excSrcDto.setEthnicTypeCd(getStringValue(excSrcObj[68]));
				excSrcDto.setPckTypeId(getBigDecimalValue(excSrcObj[69]));
				excSrcDto.setConvTeamComments(getStringValue(excSrcObj[70]));
				
				if(heirarchyLvl2.equalsIgnoreCase("000") && heirarchyLvl3.equalsIgnoreCase("000"))
					excSrcDto.setCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("000") && heirarchyLvl3.equalsIgnoreCase("000"))
					excSrcDto.setSubCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("000") && !heirarchyLvl3.equalsIgnoreCase("000"))
					excSrcDto.setGroupDesc(heirarchyDesc);
				
				mapAddnlDetailsOnDto(excSrcDto,excSrcObj);
				exceptionList.add(excSrcDto);
			}
			else
			{
				excSrcDto = exceptionList.get(exceptionList.indexOf(excSrcDto));
				if(heirarchyLvl2.equalsIgnoreCase("000") && heirarchyLvl3.equalsIgnoreCase("000"))
					excSrcDto.setCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("000") && heirarchyLvl3.equalsIgnoreCase("000"))
					excSrcDto.setSubCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("000") && !heirarchyLvl3.equalsIgnoreCase("000"))
					excSrcDto.setGroupDesc(heirarchyDesc);
			}
		}
		LOG.info("Execution completed for buildLikeItemDetailDtoListNew {}", exceptionList.size());
		return exceptionList;
	}
	
	
	/*public List<UIExceptionSrcDto> buildLikeItemDetailDtoListNew(
			List<Object[]> likeItemObjList) {
		UIExceptionSrcDto excSrcDto = new UIExceptionSrcDto();
		List<UIExceptionSrcDto> exceptionList = new ArrayList<>();
		for (Object[] excSrcObj : likeItemObjList) {
			
			excSrcDto = new UIExceptionSrcDto();
			excSrcDto.setProductSKU(getStringValue(excSrcObj[2]));
			excSrcDto.setUpcCountry(getBigDecimalValue(excSrcObj[4] ).toString());
			excSrcDto.setUpcSystem(getBigDecimalValue(excSrcObj[5]).toString());
			excSrcDto.setUpcManufacturer(getBigDecimalValue(excSrcObj[6]).toString());
			excSrcDto.setUpcSales(getBigDecimalValue(excSrcObj[7]).toString());
			
			
			String heirarchyLvl2 = getStringValue(excSrcObj[53]);
			String heirarchyLvl3 = getStringValue(excSrcObj[54]);
			String heirarchyDesc = getStringValue(excSrcObj[57]);
			
			if(!exceptionList.contains(excSrcDto)){
				excSrcDto.setProductSrcCd(getStringValue(excSrcObj[3]));
				excSrcDto.setCaseUPC(getStringValue(excSrcObj[8]));
				excSrcDto.setSlotId(getStringValue(excSrcObj[38]));
				excSrcDto.setOnhandNbr(getBigDecimalValue(excSrcObj[39]));
				excSrcDto.setNewDate(getDate(excSrcObj[40]));
				excSrcDto.setLastShipDate(getDate(excSrcObj[41]));
				excSrcDto.setLastSaleDate(getDate(excSrcObj[42]));
				excSrcDto.setTotalSales(getBigDecimalValue(excSrcObj[43]));
				excSrcDto.setCasesOrdered(getBigDecimalValue(excSrcObj[44]));
				excSrcDto.setProductionGrpCd(getBigDecimalValue(excSrcObj[45]).intValue());
				excSrcDto.setProductionCtgryCd(getBigDecimalValue(excSrcObj[46]).intValue());
				excSrcDto.setProductionClsCd(getBigDecimalValue(excSrcObj[47]).intValue());
				excSrcDto.setEthnicTypeCd(getStringValue(excSrcObj[48]));
				excSrcDto.setPckTypeId(getBigDecimalValue(excSrcObj[49]));
				excSrcDto.setProductClsCd(getBigDecimalValue(excSrcObj[50]).intValue());
				
				String innerPack=getBigDecimalValue(excSrcObj[51]).toString();
				
				if(innerPack.equals("0")){
					excSrcDto.setInnerPack((new BigDecimal(1)).intValue());
				}else{
					excSrcDto.setInnerPack(getBigDecimalValue(excSrcObj[51]).intValue());
				}
				String retailUnitPack=getBigDecimalValue(excSrcObj[52]).toString();
				if(retailUnitPack.equals("0")){
					excSrcDto.setRetailUnitPack(getBigDecimalValue(excSrcObj[21]).intValue());
				}else{
					excSrcDto.setRetailUnitPack(getBigDecimalValue(excSrcObj[52]).intValue());
				}
				
				excSrcDto.setItmUsgeInd(getCharacterValue(excSrcObj[11]));
				excSrcDto.setItmUsgeTypInd(getCharacterValue(excSrcObj[12]));
				excSrcDto.setDspFlag(getCharacterValue(excSrcObj[14]));
				excSrcDto.setItmDescrbtn(getStringValue(excSrcObj[15]));
				excSrcDto.setIntenetItemDescrbtn(getStringValue(excSrcObj[18]));
				excSrcDto.setVdCnvFactor(getBigDecimalValue(excSrcObj[20]));
				excSrcDto.setPackWhse(getBigDecimalValue(excSrcObj[21]));
				excSrcDto.setSizeNbr(getBigDecimalValue(excSrcObj[22]));
				excSrcDto.setSzUom(getStringValue(excSrcObj[23]));
				excSrcDto.setCostItm(getBigDecimalValue(excSrcObj[25]).toString());//toString
				excSrcDto.setHierLevel4(getStringValue(excSrcObj[29]));
				excSrcDto.setHierLevel5(getStringValue(excSrcObj[30]));
				if(heirarchyLvl2.equalsIgnoreCase("0") && heirarchyLvl3.equalsIgnoreCase("0"))
					excSrcDto.setCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("0") && heirarchyLvl3.equalsIgnoreCase("0"))
					excSrcDto.setSubCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("0") && !heirarchyLvl3.equalsIgnoreCase("0"))
					excSrcDto.setGroupDesc(heirarchyDesc);
				exceptionList.add(excSrcDto);
			}
			else
			{
				excSrcDto = exceptionList.get(exceptionList.indexOf(excSrcDto));
				if(heirarchyLvl2.equalsIgnoreCase("0") && heirarchyLvl3.equalsIgnoreCase("0"))
					excSrcDto.setCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("0") && heirarchyLvl3.equalsIgnoreCase("0"))
					excSrcDto.setSubCategoryDesc(heirarchyDesc);
				if(!heirarchyLvl2.equalsIgnoreCase("0") && !heirarchyLvl3.equalsIgnoreCase("0"))
					excSrcDto.setGroupDesc(heirarchyDesc);
			}
				

		}
		return exceptionList;
	}*/
	
	private String getDate(Object obj){
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		if(obj == null){
			return "";
		}
		else{
			Date str = (Date) obj;
			return formatter.format(str);
		}
	}
	
	public List<OverrideDataVo> buildLikeItemDetailDtoList(
			List<Object[]> likeItemObjList) {
		LOG.info("Execution started for  buildLikeItemDetailDtoList");
		UIExceptionSrcDto excSrcDto = new UIExceptionSrcDto();
		List<OverrideDataVo> overrideRecords = new ArrayList<>();
		OverrideDataVo overrideRec;
		for (Object[] srcObj : likeItemObjList) {
			excSrcDto = new UIExceptionSrcDto();
			
			excSrcDto.setProductSKU(getStringValue(srcObj[33]));
			overrideRec = new OverrideDataVo();
			overrideRec.setUiEceptionSrcDto(excSrcDto);
			if(overrideRecords.contains(overrideRec)){
				overrideRec = overrideRecords.get(overrideRecords.indexOf(overrideRec));
			}
			else
			{
				excSrcDto.setCompanyId(getStringValue(srcObj[31]));
				excSrcDto.setDivisionId(getStringValue(srcObj[32]));
				overrideRecords.add(overrideRec);
			}
			
			NewItemDetailDto newItemDto = new NewItemDetailDto();
			newItemDto.setLikeItem(true);
			newItemDto
					.setDtaOverCic(getBigDecimalValue(srcObj[0]));
			if (overrideRec.getLikeItems() == null || !overrideRec.getLikeItems().contains(newItemDto)) {
				newItemDto.setUpdItmDesc(getStringValue(srcObj[1]));
				newItemDto.setUpdWhseItmDesc(getStringValue(srcObj[2]));
				newItemDto.setUpdRtlItmDesc(getStringValue(srcObj[3]));
				newItemDto.setUpdIntenetItemDesc(getStringValue(srcObj[4]));
				newItemDto.setUpdPosDesc(getStringValue(srcObj[5]));
				newItemDto.setPackwhse(getBigDecimalValue(srcObj[6]));
				newItemDto.setVendConvFactor(getBigDecimalValue(srcObj[7]));
				newItemDto.setUpdUsgeInd(getCharacterValue(srcObj[8]));
				newItemDto.setUpdUsageTypInd(getCharacterValue(srcObj[9]));
				newItemDto.setDispFlag((Character) (srcObj[10] != null && ((Character) srcObj[10] != ' ') ? (srcObj[10]): 'N'));
				newItemDto.setGrpCd(((Double)srcObj[11]).intValue());
				newItemDto.setCtgryCd(((Double)srcObj[12]).intValue());
				newItemDto.setClsCd(((Double)srcObj[13]).intValue());
				newItemDto.setSbClsCd(((Double)srcObj[14]).intValue());
				newItemDto.setSubSbClass(((Double)srcObj[15]).intValue());
				String dc = getStringValue(srcObj[16]);
				if(dc != null && dc.trim().length() > 0){
					newItemDto.addDC(dc);
					String rog = getStringValue(srcObj[17]);
					BigDecimal cost =getBigDecimalValue(srcObj[19]);
					newItemDto.setCost(cost.toString());
					DCDetailsVo dcDetailsVo = new DCDetailsVo();
					dcDetailsVo.setDc(getStringValue(srcObj[16]));
					dcDetailsVo.setCost(cost);
					dcDetailsVo.addRog(rog);
					newItemDto.addDCDetails(dcDetailsVo);
				}
				newItemDto.setPrimayUpcString(getStringValue(srcObj[20]));
				newItemDto.setTrueDSDFlag((Character) (srcObj[21] != null && ((Character) srcObj[21] != ' ') ? (srcObj[21]): 'N'));
				newItemDto.setDescSize(getStringValue(srcObj[22]));
				newItemDto.setUpdSizeNmbr(getBigDecimalValue(srcObj[23]));
				newItemDto.setUpdSizeUom(getStringValue(srcObj[24]));
				newItemDto.setProductSrcCd(getStringValue(srcObj[25]));
				newItemDto.setSMICDesc(getStringValue(srcObj[26]));
				newItemDto.setUpdPtLabelInd(getCharacterValue(srcObj[27]));
				newItemDto.setCaseUPC(getStringValue(srcObj[74]));
				newItemDto.setStatusCorp(getCharacterValue(srcObj[75]));
				newItemDto.setDeptCd(getStringValue(srcObj[76] ));
				newItemDto.setDeptName(getStringValue(srcObj[77]));
				excSrcDto.setProductSrcCd(getStringValue(srcObj[34]));
				excSrcDto.setUpcCountry(getBigDecimalValue(srcObj[35]).toString());
				excSrcDto.setUpcSystem(getBigDecimalValue(srcObj[36]).toString());
				excSrcDto.setUpcManufacturer(getBigDecimalValue(srcObj[37]).toString());
				excSrcDto.setUpcSales(getBigDecimalValue(srcObj[38]).toString());
				excSrcDto.setCaseUPC(getStringValue(srcObj[39]));
				excSrcDto.setPLUcd(getBigDecimalValue(srcObj[40]).toString());
				excSrcDto.setPrimryUpcInd(getCharacterValue(srcObj[41]));
				excSrcDto.setItmUsgeInd(getCharacterValue(srcObj[42]));
				excSrcDto.setItmUsgeTypInd(getCharacterValue(srcObj[43]));
				excSrcDto.setPtLblInd(getCharacterValue(srcObj[44]));
				excSrcDto.setDspFlag(getCharacterValue(srcObj[45]));
				excSrcDto.setItmDescrbtn(getStringValue(srcObj[46]));
				excSrcDto.setWhseItmDescrbtn(getStringValue(srcObj[47]));
				excSrcDto.setRtlItmDescrbtn(getStringValue(srcObj[48]));
				excSrcDto.setIntenetItemDescrbtn(getStringValue(srcObj[49]));
				excSrcDto.setPosDescrbtn(getStringValue(srcObj[50]));
				excSrcDto.setVdCnvFactor(getBigDecimalValue(srcObj[51]));
				excSrcDto.setPackWhse(getBigDecimalValue(srcObj[52]));
				excSrcDto.setSizeNbr((BigDecimal) (srcObj[53]));
				excSrcDto.setSzUom(getStringValue(srcObj[54]));
				excSrcDto.setSzDesc(getStringValue(srcObj[55]));
				excSrcDto.setCostItm(getBigDecimalValue(srcObj[56]).toString());
				excSrcDto.addToUpcLIst(excSrcDto.getPrimaryUPCforDisplay());
				newItemDto.setUpcCountry(excSrcDto.getUpcCountry());
				newItemDto.setUpcManufacturer(excSrcDto.getUpcManufacturer());
				newItemDto.setUpcSales(excSrcDto.getUpcSales());
				newItemDto.setUpcSystem(excSrcDto.getUpcSystem());
				if (overrideRec.getLikeItems() == null)
					overrideRec.setLikeItems(new ArrayList<NewItemDetailDto>());
				overrideRec.getLikeItems().add(newItemDto);
			} else {
				NewItemDetailDto existingItemDto = overrideRec.getLikeItems().get(overrideRec.getLikeItems().indexOf(newItemDto));
				existingItemDto.addUpc(getStringValue(srcObj[20]));
				String dc = getStringValue(srcObj[16]);
				if(dc != null && dc.trim().length() > 0){
					existingItemDto.addDC(dc);
					DCDetailsVo dcDetailsVo = new DCDetailsVo();
					dcDetailsVo.setDc(dc);
					if(existingItemDto.getDcDetails().contains(dcDetailsVo))
					{
						dcDetailsVo = existingItemDto.getDcDetails().get(existingItemDto.getDcDetails().indexOf(dcDetailsVo));
						String rog = getStringValue(srcObj[17]);
						dcDetailsVo.addRog(rog);
					}
					else
					{
						String rog = getStringValue(srcObj[17]);
						BigDecimal cost = getBigDecimalValue(srcObj[19]);
						dcDetailsVo.setCost(cost);
						dcDetailsVo.addRog(rog);
						existingItemDto.addDCDetails(dcDetailsVo);
					}
				}
			}

		}
		LOG.info("Execution completed for  buildLikeItemDetailDtoList");
		return overrideRecords;
	}
	
	/**
	 * @param obj
	 * @return
	 */
	private String getStringValue(Object obj){
		if(obj == null)
			return "";
		return ( obj.toString()).trim();
	}
	
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}
	private Double getDoubleValue(Object obj){
		if(obj == null)
			return new Double(0);
		return (Double) obj;
	}
	
	private Character getCharacterValue(Object obj){
		String empty=" ";
		if(obj == null)
			return Character.valueOf(empty.charAt(0));
		return (Character) obj;
	}
	private UIExceptionSrcDto mapAddnlDetailsOnDto(UIExceptionSrcDto uiExceptionSrcDto,
			Object[] addtionDetailsObj) {
		LOG.debug("Execution started for mapAddnlDetailsOnDto");
		uiExceptionSrcDto.setPullBydays(uiExceptionSrcDto.getPullBydays()!=null ?uiExceptionSrcDto.getPullBydays() :null);
		uiExceptionSrcDto.setSellByDays(uiExceptionSrcDto.getSellByDays()!=null ?uiExceptionSrcDto.getSellByDays() :"0");
		uiExceptionSrcDto.setUseByDays(uiExceptionSrcDto.getUseByDays()!=null ?uiExceptionSrcDto.getUseByDays() :"0");
		uiExceptionSrcDto.setTareCd(uiExceptionSrcDto.getTareCd() !=null ? uiExceptionSrcDto.getTareCd() : "0");
		
					
		
			if(uiExceptionSrcDto.getDspFlag().equals('Y') )
				{
				uiExceptionSrcDto.setSrcProdwght(uiExceptionSrcDto.getSrcProdwght()!=null ? uiExceptionSrcDto.getSrcProdwght() :"0");
				uiExceptionSrcDto.setSrcRandomWtCd(uiExceptionSrcDto.getSrcRandomWtCd()!=null ? uiExceptionSrcDto.getSrcRandomWtCd() :" ");
				uiExceptionSrcDto.setSrcAutoCostInv(uiExceptionSrcDto.getSrcAutoCostInv()!=null ? uiExceptionSrcDto.getSrcAutoCostInv() :"A" );
				uiExceptionSrcDto.setSrcLabelSize(uiExceptionSrcDto.getSrcLabelSize()!=null ? uiExceptionSrcDto.getSrcLabelSize() : "N");
				uiExceptionSrcDto.setSrcLabelNumbers(uiExceptionSrcDto.getSrcLabelNumbers()!=null ? uiExceptionSrcDto.getSrcLabelNumbers() : "0");
				uiExceptionSrcDto.setSrcSgnCount1(uiExceptionSrcDto.getSrcSgnCount1()!=null ? uiExceptionSrcDto.getSrcSgnCount1() : "0");
				uiExceptionSrcDto.setSrcSgnCount2(uiExceptionSrcDto.getSrcSgnCount2()!=null ? uiExceptionSrcDto.getSrcSgnCount2() : "0");
				uiExceptionSrcDto.setSrcSgnCount3(uiExceptionSrcDto.getSrcSgnCount3()!=null ? uiExceptionSrcDto.getSrcSgnCount3() : "0");
				
				}
			else if( uiExceptionSrcDto.getProductSrcCd().equalsIgnoreCase("D"))
			{

				uiExceptionSrcDto.setSrcProdwght(uiExceptionSrcDto.getSrcProdwght()!=null ? uiExceptionSrcDto.getSrcProdwght() :"0");
				uiExceptionSrcDto.setSrcRandomWtCd(uiExceptionSrcDto.getSrcRandomWtCd()!=null ? uiExceptionSrcDto.getSrcRandomWtCd() :" ");
				uiExceptionSrcDto.setSrcAutoCostInv(uiExceptionSrcDto.getSrcAutoCostInv()!=null ? uiExceptionSrcDto.getSrcAutoCostInv() :"I" );
					
			}
			else if(uiExceptionSrcDto.getProductSrcCd().equalsIgnoreCase("W"))
			{
				uiExceptionSrcDto.setSrcProdwght(uiExceptionSrcDto.getSrcProdwght()!=null ? uiExceptionSrcDto.getSrcProdwght(): getStringValue(addtionDetailsObj[71]));
				 if(getStringValue(addtionDetailsObj[72]).equalsIgnoreCase("Y"))
				 {
					 uiExceptionSrcDto.setSrcRandomWtCd(uiExceptionSrcDto.getSrcRandomWtCd()!=null ? uiExceptionSrcDto.getSrcRandomWtCd() : "R"); 
					 uiExceptionSrcDto.setSrcAutoCostInv(uiExceptionSrcDto.getSrcAutoCostInv()!=null ? uiExceptionSrcDto.getSrcAutoCostInv() :"I" );
					 uiExceptionSrcDto.setSrcBillingType(uiExceptionSrcDto.getSrcBillingType()!=null ?uiExceptionSrcDto.getSrcBillingType() : "A");
				 }
				 else if(getStringValue(addtionDetailsObj[72]).equalsIgnoreCase("N"))
				 {
					 uiExceptionSrcDto.setSrcRandomWtCd(uiExceptionSrcDto.getSrcRandomWtCd()!=null ? uiExceptionSrcDto.getSrcRandomWtCd() : " ");
					 uiExceptionSrcDto.setSrcAutoCostInv(uiExceptionSrcDto.getSrcAutoCostInv()!=null ? uiExceptionSrcDto.getSrcAutoCostInv() :"A" );
					 
				 }
				 else
				 {
					 uiExceptionSrcDto.setSrcRandomWtCd(uiExceptionSrcDto.getSrcRandomWtCd()!=null ? uiExceptionSrcDto.getSrcRandomWtCd() : null); 
					 uiExceptionSrcDto.setSrcAutoCostInv(uiExceptionSrcDto.getSrcAutoCostInv()!=null ? uiExceptionSrcDto.getSrcAutoCostInv() :"A" );
					 
				 }
			}
			
			uiExceptionSrcDto.setSrcBillingType(uiExceptionSrcDto.getSrcBillingType()!=null ?uiExceptionSrcDto.getSrcBillingType() : " "); 
			
			// For label size
			if(getStringValue(addtionDetailsObj[73]).equalsIgnoreCase("S"))
			{
				uiExceptionSrcDto.setSrcLabelSize(uiExceptionSrcDto.getSrcLabelSize()!=null ? uiExceptionSrcDto.getSrcLabelSize() : getStringValue(addtionDetailsObj[74]));	
			}
			else
			{
				uiExceptionSrcDto.setSrcLabelSize(uiExceptionSrcDto.getSrcLabelSize()!=null ? uiExceptionSrcDto.getSrcLabelSize() : null);
			}
			// For lable number
			if(getStringValue(addtionDetailsObj[75]).equalsIgnoreCase("S"))
			{
				uiExceptionSrcDto.setSrcLabelNumbers(uiExceptionSrcDto.getSrcLabelNumbers()!=null ? uiExceptionSrcDto.getSrcLabelNumbers() : getStringValue(addtionDetailsObj[76]));	
			}
			else
			{
				uiExceptionSrcDto.setSrcLabelNumbers(uiExceptionSrcDto.getSrcLabelNumbers()!=null ? uiExceptionSrcDto.getSrcLabelNumbers() : null);
			}
			
			
			uiExceptionSrcDto.setSrcSgnCount1(uiExceptionSrcDto.getSrcSgnCount1()!=null ? uiExceptionSrcDto.getSrcSgnCount1() : getStringValue(addtionDetailsObj[78]));
			uiExceptionSrcDto.setSrcSgnCount2(uiExceptionSrcDto.getSrcSgnCount2()!=null ? uiExceptionSrcDto.getSrcSgnCount2() : getStringValue(addtionDetailsObj[78]));
			uiExceptionSrcDto.setSrcSgnCount3(uiExceptionSrcDto.getSrcSgnCount3()!=null ? uiExceptionSrcDto.getSrcSgnCount3() : getStringValue(addtionDetailsObj[78]));
			
			/*For food Stamp*/
			if( getStringValue(addtionDetailsObj[79]).equalsIgnoreCase("I") || getStringValue(addtionDetailsObj[79]).equalsIgnoreCase("D"))
			{
				uiExceptionSrcDto.setSrcFdStmp(uiExceptionSrcDto.getSrcFdStmp() !=null ? uiExceptionSrcDto.getSrcFdStmp() :null);
			}
			else if ( getStringValue(addtionDetailsObj[79]).equalsIgnoreCase("S") && getStringValue(addtionDetailsObj[80]).equalsIgnoreCase("Y"))
			{
				uiExceptionSrcDto.setSrcFdStmp(uiExceptionSrcDto.getSrcFdStmp() !=null ? uiExceptionSrcDto.getSrcFdStmp() :"1");
			}
			else if ( getStringValue(addtionDetailsObj[79]).equalsIgnoreCase("S") && getStringValue(addtionDetailsObj[80]).equalsIgnoreCase("N"))
			{
				uiExceptionSrcDto.setSrcFdStmp(uiExceptionSrcDto.getSrcFdStmp() !=null ? uiExceptionSrcDto.getSrcFdStmp() :"0");
			}
			
			/*RING setting*/
			boolean plu =false;
			
				if(Float.parseFloat(uiExceptionSrcDto.getUpc().replaceAll("-", "")) <100000)
				{
					plu =true;
					
				}
			
				if(getStringValue(addtionDetailsObj[81]).equalsIgnoreCase("S") && uiExceptionSrcDto.getSelling_method_cd() != null && (uiExceptionSrcDto.getSelling_method_cd().equals("W") || uiExceptionSrcDto.getSelling_method_cd().equals("POUND"))
						&& uiExceptionSrcDto.getUpcSystem().equals("2")	&&	uiExceptionSrcDto.getUpcCountry().equals("0"))
				{
					uiExceptionSrcDto.setSrcRing(uiExceptionSrcDto.getSrcRing()!=null ? uiExceptionSrcDto.getSrcRing():"1");
				}
				else if(getStringValue(addtionDetailsObj[81]).equalsIgnoreCase("S") && uiExceptionSrcDto.getSelling_method_cd() != null && (uiExceptionSrcDto.getSelling_method_cd().equals("E") || uiExceptionSrcDto.getSelling_method_cd().equals("EACH"))
						 &&	uiExceptionSrcDto.getUpcSystem().equals("2")	&&	uiExceptionSrcDto.getUpcCountry().equals("0")
							)
				{
					uiExceptionSrcDto.setSrcRing(uiExceptionSrcDto.getSrcRing()!=null ? uiExceptionSrcDto.getSrcRing():"5");
				}
				else if(getStringValue(addtionDetailsObj[81]).equalsIgnoreCase("S") && uiExceptionSrcDto.getSelling_method_cd() != null && (uiExceptionSrcDto.getSelling_method_cd().equals("W") || uiExceptionSrcDto.getSelling_method_cd().equals("POUND"))
						 && plu
							)
				{
					uiExceptionSrcDto.setSrcRing(uiExceptionSrcDto.getSrcRing()!=null ? uiExceptionSrcDto.getSrcRing():"2");
				}else
				{
					uiExceptionSrcDto.setSrcRing(uiExceptionSrcDto.getSrcRing()!=null ? uiExceptionSrcDto.getSrcRing():"0");
				}
					
			/*Hicone default setting*/
			if(getStringValue(addtionDetailsObj[82]).equalsIgnoreCase("S") && getStringValue(addtionDetailsObj[83]).equalsIgnoreCase("Y") )
				{
					uiExceptionSrcDto.setSrcHicone(uiExceptionSrcDto.getSrcHicone()!=null ? uiExceptionSrcDto.getSrcHicone():"1");
				}
				else if(getStringValue(addtionDetailsObj[82]).equalsIgnoreCase("S") && getStringValue(addtionDetailsObj[83]).equalsIgnoreCase("N") )
				{
					uiExceptionSrcDto.setSrcHicone(uiExceptionSrcDto.getSrcHicone()!=null ? uiExceptionSrcDto.getSrcHicone():"0");
				}				
				else
				{
					uiExceptionSrcDto.setSrcHicone(uiExceptionSrcDto.getSrcHicone()!=null ? uiExceptionSrcDto.getSrcHicone():"0");
				}
				
			uiExceptionSrcDto.setCost(uiExceptionSrcDto.getCost()!=null ? uiExceptionSrcDto.getCost() :getStringValue(addtionDetailsObj[84]));
		
		
			LOG.debug("Execution completed for mapAddnlDetailsOnDto");
		return uiExceptionSrcDto;
	}

}
 