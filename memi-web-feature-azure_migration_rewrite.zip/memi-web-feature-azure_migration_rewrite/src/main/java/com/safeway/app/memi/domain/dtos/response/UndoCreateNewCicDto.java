package com.safeway.app.memi.domain.dtos.response;

import java.io.Serializable;
import java.util.Set;

public class UndoCreateNewCicDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String companyId;
	private String divisionId;
	private String productSku;
	private String updatedUserId;
	private Character cicType;
	private Set<String> upcList;
	
	public String getUpdatedUserId() {
		return updatedUserId;
	}
	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}
	public Character getCicType() {
		return cicType;
	}
	public void setCicType(Character cicType) {
		this.cicType = cicType;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getProductSku() {
		return productSku;
	}
	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}
	public Set<String> getUpcList() {
		return upcList;
	}
	public void setUpcList(Set<String> upcList) {
		this.upcList = upcList;
	}
	
	@Override
	public String toString() {
		return "UndoCreateNewCicDto [companyId=" + companyId + ", divisionId="
				+ divisionId + ", productSku=" + productSku
				+ ", updatedUserId=" + updatedUserId + ", cicType=" + cicType
				+ ", upcList=" + upcList + "]";
	}

}
