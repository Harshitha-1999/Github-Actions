package com.safeway.app.memi.data.repositories;
/* ***************************************************************************
 * NAME : SizeUOMDetailRepository
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  June 9, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.SizeUOMDetail;

@Repository
public interface SizeUOMDetailRepository extends JpaRepository<SizeUOMDetail, Long> {

	@Query
	List<SizeUOMDetail> findAllByOrderByUomCodeAsc();
	
	/**
	 * @param uomCode
	 * @return
	 */
	@Query
    List<SizeUOMDetail> findByUomCode(String uomCode);

}
