package com.safeway.app.memi.web.controllers;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceSimsItems;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UndoCreateNewCicDto;
import com.safeway.app.memi.domain.services.DisplayService;
import com.safeway.app.memi.domain.util.DisplayItemsReportWriter;

/**
 * 
 * Rest service controller class for display item
 * 
 */
@Controller
@RequestMapping("/dsply")
public class DisplayController {
	private static final Logger LOG = LoggerFactory.getLogger(DisplayController.class);

	@Autowired
	private DisplayService dispayItemService;

	@Autowired
	private DisplayItemsReportWriter displayReportWritter;
	
	@Autowired
	ServletContext context;

	@RequestMapping(value = "/listDisplayerData/{company}/{division}", method = RequestMethod.GET)
	public ResponseEntity<List<UIDataVO>> getDisplayItemList(
			@PathVariable("company") String company,
			@PathVariable("division") String division) {
		LOG.info("Execution started for display item summary record.");
		List<UIDataVO> response = dispayItemService
				.getDepartmentWiseDisplayItemData(company, division);
		LOG.info("Execution completed for"+response.size()+" display item summary record.");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/loadDeptWiseDisplayItem/{company}/{division}/{department}/{exceptionType}/{status}/{type}", method = RequestMethod.GET)
	public ResponseEntity<List<DisplayItemDetail>> getDepartmentwiseItemList(
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("department") String department,
			@PathVariable("exceptionType") char exceptionType,
			@PathVariable("status") char status, @PathVariable("type") char type) {
		LOG.info("Execution started for getting DepartmentwiseItemList");
		List<DisplayItemDetail> response = dispayItemService
				.loadDepartmentWiseDisplayItemList(company, division,
						department, exceptionType, status, type);
		LOG.info("Execution completed for "+response.size()+" getting DepartmentwiseItemList");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/markDisplay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, List<String>> markDisplay(
			@RequestBody List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Execution started for mark Display() method.");
		Map<String, List<String>> resonse = dispayItemService
				.updateMultiCompItemInd(displayItemDetail, 'M');
		LOG.info("Execution completed for "+resonse.size()+" mark Display() method.");
		return resonse;
	}

	@RequestMapping(value = "/unMarkDisplay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, List<String>> unMarkDisplay(
			@RequestBody List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Execution started for unMark Display() method.");
		Map<String, List<String>> resonse = dispayItemService
				.updateMultiCompItemInd(displayItemDetail, 'U');
		LOG.info("Execution completed for "+resonse.size()+" unMark Display() method.");
		return resonse;
	}

	@RequestMapping(value = "/markDead", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, List<String>> markDead(
			@RequestBody List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Execution Started for mark Dead() method.");
		Map<String, List<String>> resonse = dispayItemService
				.markItemsAsDead(displayItemDetail);
		LOG.info("Execution completed for "+resonse.size()+" mark Dead() method.");
		return resonse;
	}

	@RequestMapping(value = "/displayersSearchOnItemDesc", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnItemDesc(
			@RequestBody List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Execution started for displayer item based on item desc.");
		List<DisplayItemDetail> response = dispayItemService
				.getDeptWiseItemDetailsBasedOnItemDesc(displayItemDetail);
		LOG.info("Execution completed for  "+response.size()+" displayer item based on item desc.");
		return response;
	}
	
	@RequestMapping(value = "/displayersSearchOnProductSku", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnProductSku(
			@RequestBody List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Execution started for displayer item based on product sku.");
		List<DisplayItemDetail> response = dispayItemService
				.getDeptWiseItemDetailsBasedOnProductSku(displayItemDetail);
		LOG.info("Execution completed for "+response.size()+" displayer item based on product sku.");
		return response;
	}
	
	@RequestMapping(value = "/displayersSearchOnOneTimeBuyFlag", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnOneTimeBuyFlag(@RequestBody List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Execution started for displayer item based on OneTimeBuyFlag.");
		List<DisplayItemDetail> response = dispayItemService.
				getDeptWiseItemDetailsBasedOnOneTimeBuyFlag(displayItemDetail);
		LOG.info("Execution completed for "+response.size()+" displayer item based on OneTimeBuyFlag.");
		return response;
	}
	
	@RequestMapping(value = "/displayersDownloadExcel/{company}/{division}/{deptCode}/{deptName}/{status}", method = RequestMethod.GET)
	public void getDisplayItemReportFile(HttpServletRequest request,
			HttpServletResponse response,
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("deptCode") String deptCode,
			@PathVariable("deptName") String deptName,
			@PathVariable("status") char status) {
		LOG.info("Downloading Display Item excel sheet : ");
		String dataDirectory = request.getSession().getServletContext()
				.getRealPath("/");
		String departmentName = displayReportWritter
				.createDisplayItemReportSheet(dataDirectory, deptCode, company,
						division, deptName, status);
		Path file = Paths.get(dataDirectory, "DisplayItems.xlsx");
		if (Files.exists(file)) {
			response.setContentType("application/vnd.ms-excel");
			response.addHeader("Content-Disposition", "attachment; filename="
					+ "DisplayItems_" + departmentName + ".xlsx");
			try {
				Files.copy(file, response.getOutputStream());
				response.getOutputStream().flush();
				try {
					Files.delete(file);
				} catch (NoSuchFileException x) {
					LOG.error("No such file.");
				} catch (DirectoryNotEmptyException x) {
					LOG.error("No such directory.");
				} catch (IOException x) {
					LOG.error(x.getMessage());
				}
			} catch (IOException ex) {
				LOG.error(ex.getMessage());
			}
		}
		LOG.info(" COMpLtED Downloading Display Item excel sheet  ");
	}

	@RequestMapping(value = "/loadSourceSimsItems", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody DisplayItemSourceSimsItems getSourceSimsData(
			@RequestBody DisplayItemDetail displayItemDetail) {
		LOG.info("Execution started for get Source Sims Data() method.");
		DisplayItemSourceSimsItems resonse = dispayItemService.fetchSourceAndSimsDetails(displayItemDetail);
		LOG.info("Execution completed for get Source Sims Data() method.");
		return resonse;
	}

	@RequestMapping(value = "/matchToSimsCic", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, String> matchCic(
			@RequestBody List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
		LOG.info("Execution started for matchCic() method.");
		Map<String, String> resonse = dispayItemService.updateCicMatch(displayItemCreateMatchCicDto);
		LOG.info("Execution completed for "+resonse.size()+" match Cic() method.");
		return resonse;
	}

	@RequestMapping(value = "/undoDisplayersCompleted", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, String> undoDisplayersCompleted(
			@RequestBody UndoCreateNewCicDto undoDisplayerCompleted) {
		LOG.info("Execution started for undo Displayers Completed method.");
		Map<String, String> resonse = dispayItemService.undoDisplayersCompleted(undoDisplayerCompleted);
		LOG.info("Execution completed for  "+resonse.size()+" undo Displayers Completed method.");
		return resonse;
	}

	@RequestMapping(value = "/createNewCic", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, String> createCic(
			@RequestBody List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
		LOG.info("Execution started for create Cic method.");
		Map<String, String> resonse = dispayItemService.createNewCic(displayItemCreateMatchCicDto);
		LOG.info("Execution completed for "+resonse.size()+" create Cic method.");
		return resonse;
	}

	@RequestMapping(value = "/undoCreateNewCic", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, String> undoCreateNewCic(
			@RequestBody UndoCreateNewCicDto undoCreateNewCicDto) {
		LOG.info("Execution started for undo Create New Cic method.");
		Map<String, String> resonse = dispayItemService.undoCreateNewCic(undoCreateNewCicDto);
		LOG.info("Execution completed for "+resonse.size()+" undo Create New Cic method.");
		return resonse;
	}
	/**
	 * Displayer enhancement:-display component exception file download
	 * **/
	@RequestMapping(value = "/displayersExceptionExcelDownload/{company}/{division}/{deptCode}/{deptName}/{whsedsd}", method = RequestMethod.GET)
	public void downloadDisplayComponentExceptionFile(HttpServletRequest request,
			HttpServletResponse response,
			@PathVariable("company") String company,
			@PathVariable("division") String division,
			@PathVariable("deptCode") String deptCode,
			@PathVariable("deptName") String deptName,
			@PathVariable("whsedsd") String whsedsd) {
		LOG.info("Downloading Display Item excel sheet : ");
		String dataDirectory = request.getSession().getServletContext()
				.getRealPath("/");
		String departmentName = displayReportWritter
				.createDisplayItemExceptionReportSheet(dataDirectory, deptCode, company,
						division, deptName, whsedsd);
		Path file = Paths.get(dataDirectory, "DisplayExceptionItems.xlsx");
		if (Files.exists(file)) {
			response.setContentType("application/vnd.ms-excel");
			response.addHeader("Content-Disposition", "attachment; filename="
					+ "DisplayExceptionItems_" + departmentName + ".xlsx");
			try {
				Files.copy(file, response.getOutputStream());
				response.getOutputStream().flush();
				try {
					Files.delete(file);
				} catch (NoSuchFileException x) {
					LOG.error("No such file.");
				} catch (DirectoryNotEmptyException x) {
					LOG.error("No such directory.");
				} catch (IOException x) {
					LOG.error(x.getMessage());
				}
			} catch (IOException ex) {
				LOG.error(ex.getMessage());
			}
		}
		LOG.info("COMpLtEd Downloading Display Item excel sheet : ");
	}
	
	@RequestMapping(value = "/uploadExceptionFile", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody  Map<String,String> uploadFileHandler(@RequestParam("file") MultipartFile uploadedExcelfile,@RequestParam("companyId") String companyId,
			@RequestParam("divisionId") String divisionId,@RequestParam("deptCode") String deptCode,@RequestParam("displayType") String displayType, @RequestParam("userId") String userId) throws Exception {
    	LOG.info("Execution started for excel file upload.");
    	
    	String dataDirectory = context.getRealPath("/");
    	String response = dispayItemService.uploadExcel(dataDirectory, companyId,divisionId,deptCode,displayType,userId,uploadedExcelfile);
    	LOG.info("Execution completed for for excel file upload.");
    	Map<String,String> responseStatus =new HashMap<>();
    	responseStatus.put("status",response);
		return responseStatus;
	}
	 
	 /**New search feature for the reviewed screen**/
	 @RequestMapping(value = "/displayersSearchOnReviewedItemDesc", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public @ResponseBody List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedItemDesc(
				@RequestBody List<DisplayItemDetail> displayItemDetail) {
			LOG.info("Execution started for displayer item based on item desc.");
			List<DisplayItemDetail> response = dispayItemService
					.getDeptWiseItemDetailsBasedOnReviewedItemDesc(displayItemDetail);
			LOG.info("Execution completed for "+response.size()+" displayer item based on item desc.");
			return response;
		}
		
		@RequestMapping(value = "/displayersSearchOnReviewedProductSku", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public @ResponseBody List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedProductSku(
				@RequestBody List<DisplayItemDetail> displayItemDetail) {
			LOG.info("Execution started for displayer item based on product sku.");
			List<DisplayItemDetail> response = dispayItemService
					.getDeptWiseItemDetailsBasedOnReviewedProductSku(displayItemDetail);
			LOG.info("Execution completed for "+response.size()+" displayer item based on product sku.");
			return response;
		}
		
		@RequestMapping(value = "/displayersSearchOnReviewedOneTimeBuyFlag", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
		public @ResponseBody List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(@RequestBody List<DisplayItemDetail> displayItemDetail) {
			LOG.info("Execution started for displayer item based on OneTimeBuyFlag.");
			List<DisplayItemDetail> response = dispayItemService.
					getDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(displayItemDetail);
			LOG.info("Execution completed for "+response.size()+" displayer item based on OneTimeBuyFlag.");
			return response;
		}
	 
	 
	 
}