package com.safeway.app.memi.data.repositories;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.constants.LookUpScreenQueryConstants;


@Repository
@SuppressWarnings("unchecked")
public class LookUpSearchRepository {
	@Autowired
	private LocalContainerEntityManagerFactoryBean entityManagerFactory;

	private static final Logger LOG = LoggerFactory.getLogger(LookUpSearchRepository.class);

	public List<Object[]> fetchAllConvGroups(String companyId, String divisionId) {
		
		StringBuilder baseQuery = new StringBuilder("select distinct  PROD_HIERARCHY_LVL_4_CD,PROD_HIERARCHY_LVL_5_CD from ECFLAND.PRODUCT_HIERARCHY where company_id =? and division_id =? and PROD_HIERARCHY_LVL_4_CD is not null  and PROD_HIERARCHY_LVL_5_CD is not null  ");
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(baseQuery.toString());
		q.setParameter(1, companyId);
		q.setParameter(2, divisionId);		
		
		List<Object[]> results = q.getResultList();
		em.close();
		return results;
		
	}

	public List<Object[]> fetchLookUpSearchResult(
			String filterSearchConditons,String condtionalJoins, Map<String, Object> baseParams,StringBuilder sortColumns) {
		
		StringBuilder query =new StringBuilder("");
		query.append(LookUpScreenQueryConstants.VENDOR_DET);
		query.append(LookUpScreenQueryConstants.PH1);
		query.append(LookUpScreenQueryConstants.PH2);
		query.append(LookUpScreenQueryConstants.PH3);
		query.append(LookUpScreenQueryConstants.PH4);
		query.append(LookUpScreenQueryConstants.SRC_BASE);
		
		query.append(condtionalJoins);
		query.append(LookUpScreenQueryConstants.SRC_BASE_CONDN);
		query.append(filterSearchConditons);
		query.append(LookUpScreenQueryConstants.SRC_WRAPPER);
		query.append(LookUpScreenQueryConstants.TGT_BASEQUERY);
		query.append(LookUpScreenQueryConstants.TGT_END_QUERY);
		LOG.info("sortColumns Result {}",(sortColumns!=null && !sortColumns.toString().isEmpty()));
		if(sortColumns!=null && !sortColumns.toString().isEmpty())
		{
			query.append(" ORDER BY ");	
			query.append(sortColumns);	
		}
		else {
			query.append(" ORDER BY SRC.RNUM");
		}
		long start = System.currentTimeMillis();
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		Query q = em.createNativeQuery(query.toString());
		for(Map.Entry<String, Object> entry : baseParams.entrySet()) {
			if("convStatusSuBCDStrList".equalsIgnoreCase(entry.getKey()) ) {
				List<Object> ListObj = Arrays.asList(entry.getValue().toString().split("-"));
				List<String> StrList = ListObj.stream().map(upc -> upc.toString().toUpperCase()).collect(Collectors.toList());
				q.setParameter(entry.getKey(), StrList);
			}else if ("cnvstatus".equalsIgnoreCase(entry.getKey()) ) {
				List<Object> ListObj = Arrays.asList(entry.getValue().toString().split("="));
				List<String> StrList = ListObj.stream().map(upc -> upc.toString().toUpperCase()).collect(Collectors.toList());
				q.setParameter(entry.getKey(), StrList);
			}else {
				q.setParameter(entry.getKey(), entry.getValue());
			}
			
		}
		
		q.setHint(PerishableSQLConstants.FETCH_SIZE, "1000");
		List results = q.getResultList();
		long end = System.currentTimeMillis();
		float sec = (end - start) / 1000F;
		LOG.info("DB query execution time {}",sec);
		em.close();
		return results;
	}

	public boolean updateProductStatus(String companyId, String divisionId,
			String productSKU, String upc, String updateStatus,String user,String reasonComments ) {
		int result =0;
		
		StringBuilder updateQuery = new StringBuilder("");
		if(updateStatus.equals("READY"))
		{
			updateQuery.append("UPDATE XREFLAND.SRC_ITEM_XRF  set CONV_STATUS_CD='R', CONV_STATUS_SUB_CD ='A',CONV_STATUS_DSC ='READY', status_reason_txt =:reason ");
		}
		else if(updateStatus.equals("DEAD"))
		{
			updateQuery.append("UPDATE XREFLAND.SRC_ITEM_XRF  set CONV_STATUS_CD='D', CONV_STATUS_SUB_CD ='B',CONV_STATUS_DSC ='Dead', status_reason_txt =:reason  ");
		}
		
		if(!updateQuery.toString().equals("")){
			
			updateQuery.append(",create_update_ts =:timestamp , create_update_user_id =:userId ");
			
			updateQuery.append("WHERE COMPANY_ID =:companyId AND DIVISION_ID =:divisionId ");
			updateQuery.append("AND SRC_PRODUCT_SKU =:SKU  ");
			
			updateQuery.append("AND SRC_UPC_COUNTRY =:country  ");
			updateQuery.append("AND SRC_UPC_SYSTEM =:system  ");
			updateQuery.append("AND SRC_UPC_MANUF =:manuf  ");
			updateQuery.append("AND SRC_UPC_SALES =:sales  ");
			
			
		}
		
		EntityManager em = entityManagerFactory.getNativeEntityManagerFactory()
				.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		if(!updateQuery.toString().equals("")){
				Query q = em.createNativeQuery(updateQuery.toString());
				q.setParameter("reason", reasonComments);
				q.setParameter("companyId", companyId);
				q.setParameter("divisionId",divisionId);
				q.setParameter("SKU",productSKU );
				q.setParameter("country", upc.substring(0, 1));
				q.setParameter("system", upc.substring(1, 2));
				q.setParameter("manuf", upc.substring(2, 7));
				q.setParameter("sales", upc.substring(7, 12));
				q.setParameter("timestamp", new Date());
				q.setParameter("userId", user);
				
				 result =q.executeUpdate();

		}
		et.commit();
		em.close();
		
		 if(result>0)
			 return true;
		 else
			 return false;
	}

	
}
