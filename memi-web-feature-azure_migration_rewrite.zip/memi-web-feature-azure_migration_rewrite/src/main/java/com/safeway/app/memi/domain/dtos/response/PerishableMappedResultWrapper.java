package com.safeway.app.memi.domain.dtos.response;

public class PerishableMappedResultWrapper {
	
	private PerishableMappedItemVO source;
	private PerishableMappedItemVO target;
	private String mappingType;
	private String mappedStatus;
	private String mappedItemIndicator ;
	
	
	public PerishableMappedItemVO getSource() {
		return source;
	}
	public void setSource(PerishableMappedItemVO source) {
		this.source = source;
	}
	public PerishableMappedItemVO getTarget() {
		return target;
	}
	public void setTarget(PerishableMappedItemVO target) {
		this.target = target;
	}
	public String getMappingType() {
		return mappingType;
	}
	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}
	public String getMappedStatus() {
		return mappedStatus;
	}
	public void setMappedStatus(String mappedStatus) {
		this.mappedStatus = mappedStatus;
	}
	/**
	 * @return the mappedItemIndicator
	 */
	public String getMappedItemIndicator() {
		return mappedItemIndicator;
	}
	/**
	 * @param mappedItemIndicator the mappedItemIndicator to set
	 */
	public void setMappedItemIndicator(String mappedItemIndicator) {
		this.mappedItemIndicator = mappedItemIndicator;
	}
	
	
	
	
	

}
