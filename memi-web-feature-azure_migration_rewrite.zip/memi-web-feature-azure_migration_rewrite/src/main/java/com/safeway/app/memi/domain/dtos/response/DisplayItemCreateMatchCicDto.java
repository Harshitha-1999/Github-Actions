package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.List;

public class DisplayItemCreateMatchCicDto {
	
	private String companyId;
	private String divisionId;
	private String productSku;
	private String srcItemDesc;
	private String caseUpc;
	private String cic;
	private Character displayFlag;
	private BigDecimal cost;
	private BigDecimal pack;
	private BigDecimal vendorConvFactor;
	private String updatedUserId;
	private String ssimsHeaderItemDesc;
	private List<DisplayItemSimsUPC> ssimsComponent;
	private List<DisplayItemSourceUPC> sourceComponentUpc;
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}
	public String getProductSku() {
		return productSku;
	}
	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}
	public String getSrcItemDesc() {
		return srcItemDesc;
	}
	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}
	public String getCaseUpc() {
		return caseUpc;
	}
	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public Character getDisplayFlag() {
		return displayFlag;
	}
	public void setDisplayFlag(Character displayFlag) {
		this.displayFlag = displayFlag;
	}
	public BigDecimal getCost() {
		return cost;
	}
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}
	public BigDecimal getPack() {
		return pack;
	}
	public void setPack(BigDecimal pack) {
		this.pack = pack;
	}
	public BigDecimal getVendorConvFactor() {
		return vendorConvFactor;
	}
	public void setVendorConvFactor(BigDecimal vendorConvFactor) {
		this.vendorConvFactor = vendorConvFactor;
	}
	public String getUpdatedUserId() {
		return updatedUserId;
	}
	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}
	public String getSsimsHeaderItemDesc() {
		return ssimsHeaderItemDesc;
	}
	public void setSsimsHeaderItemDesc(String ssimsHeaderItemDesc) {
		this.ssimsHeaderItemDesc = ssimsHeaderItemDesc;
	}
	public List<DisplayItemSimsUPC> getSsimsComponent() {
		return ssimsComponent;
	}
	public void setSsimsComponent(List<DisplayItemSimsUPC> ssimsComponent) {
		this.ssimsComponent = ssimsComponent;
	}
	public List<DisplayItemSourceUPC> getSourceComponentUpc() {
		return sourceComponentUpc;
	}
	public void setSourceComponentUpc(List<DisplayItemSourceUPC> sourceComponentUpc) {
		this.sourceComponentUpc = sourceComponentUpc;
	}
	
	@Override
	public String toString() {
		return "DisplayItemCreateMatchCicDto [companyId=" + companyId
				+ ", divisionId=" + divisionId + ", productSku=" + productSku
				+ ", srcItemDesc=" + srcItemDesc + ", caseUpc=" + caseUpc
				+ ", cic=" + cic + ", displayFlag=" + displayFlag + ", cost="
				+ cost + ", pack=" + pack + ", vendorConvFactor="
				+ vendorConvFactor + ", updatedUserId=" + updatedUserId
				+ ", ssimsHeaderItemDesc=" + ssimsHeaderItemDesc
				+ ", ssimsComponent=" + ssimsComponent
				+ ", sourceComponentUpc=" + sourceComponentUpc + "]";
	}
	
}