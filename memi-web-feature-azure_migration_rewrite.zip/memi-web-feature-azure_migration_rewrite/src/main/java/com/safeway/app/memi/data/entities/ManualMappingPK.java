package com.safeway.app.memi.data.entities;

/* ***************************************************************************
 * NAME : Company 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  Oct 12, 2017 sgang06 - Initial Creation
 * *************************************************************************
 */
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * Embedded key class for Database table ITEM_CONV_MANUAL_MAPPING.
 * 
 */
@Embeddable
public class ManualMappingPK implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Column(name = "COMPANY_ID")
	private String companyId;

	@Column(name = "DIVISION_ID")
	private String divisionId;

	@Column(name = "PRODUCT_SKU")
	private String productSKU;
	
	@Column(name = "UPC")
	private String upc;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSKU() {
		return productSKU;
	}

	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

}