package com.safeway.app.memi.data.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.safeway.app.memi.data.entities.ItemConvBulkUploadTracking;

@Repository
public interface ItemConvBulkUploadRepository extends JpaRepository<ItemConvBulkUploadTracking, Long>{

    @Query("SELECT p FROM ItemConvBulkUploadTracking p WHERE p.companyId = :companyId and p.divisionId =:divisionId and p.fileName =:fileName")
	ItemConvBulkUploadTracking findRecordByFileName(@Param("companyId")String companyId, @Param("divisionId")String divisionId, @Param("fileName")String fileName);

}
