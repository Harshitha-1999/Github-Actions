package com.safeway.app.memi.domain.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.safeway.app.memi.data.repositories.DisplaySQLRepository;
import com.safeway.app.memi.domain.dtos.response.DisplayExceptionItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;

@Component
public class DisplayItemsReportWriter {
	private static final Logger LOG = LoggerFactory
			.getLogger(DisplayItemsReportWriter.class);

	@Autowired
	private DisplaySQLRepository displayerSQLRepo;

	public static String[] headerRowColumns = { "Product SKU","Item Desc", "Pack", "VCF", 
		"Size", "Display","Display Candidate","Product Source Code","Case UPC", "Onhand Nbr", "On Order Qty", "Slot Id", "Item Create Date",
		"Last Ship Date", "Cost" };

	public static String[] displayExceptionHeaderRowColumns = { "Department Nm","Exception Category","Product SKU", "Item Desc",
		"Pack Qty","Num Size", "Size Desc", "Display Item Cost","Case UPC","Upc Country","Upc System","Upc Manuf","Upc Sales","Component Item Desc", "Component Qty",
		"Component Size Desc","Component Cost"};

	Workbook wb;
	Sheet displayItemsSheet;
	

	CellStyle fcHeader;
	CellStyle fcEvenRow;
	CellStyle fcOddRow;
	
	public String createDisplayItemReportSheet(String fileName,
			String department, String company, String division,String deptName,char status) {
       LOG.info("Execution started for Display Item Report Sheet");
		wb = new XSSFWorkbook();
		fcHeader = null;
		fcOddRow = null;
		fcEvenRow = null;
		String departmentName = "";

		displayItemsSheet = wb.getSheet("DisplayItems");
		if (displayItemsSheet == null)
			displayItemsSheet = wb.createSheet("DisplayItems");

		int rowIndex = 0;
		Row header = displayItemsSheet.createRow(rowIndex);
		int colIndex = 0;

		for (String headerString : headerRowColumns) {
			Cell cell = header.createCell(colIndex++);
			cell.setCellStyle(getHeaderStyle());
			cell.setCellValue(headerString);
		}

		List<Object[]> records = displayerSQLRepo
				.fetchDeptWiseDisplayItemForExport(company, division,
						department,status);
		List<DisplayItemDetail> displayRecords = buildDisplayItemDetailDtoList(records);
		LOG.debug("Completed fetching all"+displayRecords.size()+"display Records");
		if (!displayRecords.isEmpty()) {
			departmentName=deptName;

			for (DisplayItemDetail srcRecord : displayRecords) {

				colIndex = 0;
				Row row = displayItemsSheet.createRow(++rowIndex);
				CellStyle rowStyle = getRowStyle(rowIndex);

				Cell cell0 = createCell(row, colIndex++, rowStyle);
				cell0.setCellValue(srcRecord.getProductSku());

				Cell cell1 = createCell(row, colIndex++, rowStyle);
				cell1.setCellValue(srcRecord.getItemDesc());

				Cell cell2 = createCell(row, colIndex++, rowStyle);
				cell2.setCellValue(srcRecord.getShippingPackNumber() != null ? srcRecord
						.getShippingPackNumber().intValue() : Integer.valueOf(0));

				Cell cell3 = createCell(row, colIndex++, rowStyle);
				cell3.setCellValue(srcRecord.getMasterCasePackNumber() != null ? srcRecord
						.getMasterCasePackNumber().intValue() : Integer.valueOf(0));

				Cell cell4 = createCell(row, colIndex++, rowStyle);
				cell4.setCellValue(srcRecord.getSizeNumber() != null ? srcRecord
						.getSizeNumber().intValue() : Integer.valueOf(0));

				Cell cell5 = createCell(row, colIndex++, rowStyle);
				cell5.setCellValue(srcRecord.getMultiComponentItemInd());
				
				Cell cell6 = createCell(row, colIndex++, rowStyle);
				cell6.setCellValue(srcRecord.getOneTimeBuyFlag());
				
				Cell cell7 = createCell(row, colIndex++, rowStyle);
				cell7.setCellValue(srcRecord.getProductSourceCode());

				Cell cell8 = createCell(row, colIndex++, rowStyle);
				cell8.setCellValue(srcRecord.getCaseUpc());

				Cell cell9 = createCell(row, colIndex++, rowStyle);
				cell9.setCellValue(srcRecord.getOnHandQty() != null ? srcRecord
						.getOnHandQty().intValue() : Integer.valueOf(0));

				Cell cell10 = createCell(row, colIndex++, rowStyle);
				cell10.setCellValue(srcRecord.getOnOrderQty() != null ? srcRecord
						.getOnOrderQty().intValue() : Integer.valueOf(0));

				Cell cell11 = createCell(row, colIndex++, rowStyle);
				cell11.setCellValue(srcRecord.getSlot()!= null ? srcRecord
						.getSlot() : "");
				
				Cell cell12 = createCell(row, colIndex++, rowStyle);
				cell12.setCellValue(srcRecord.getItemCreateDate()!= null ? srcRecord
						.getItemCreateDate() : "");
				
				Cell cell13 = createCell(row, colIndex++, rowStyle);
				cell13.setCellValue(srcRecord.getLastShipDate()!= null ? srcRecord
						.getLastShipDate() : "");
				
				Cell cell14 = createCell(row, colIndex++, rowStyle);
				cell14.setCellValue("$ " + srcRecord.getCost());
			}
		}
		for (int ii = 0; ii < 36; ii++) {
			displayItemsSheet.autoSizeColumn(ii);
		}

		String dir = fileName;
		File file = new File(dir, "DisplayItems.xlsx");

		// Write the output to a file
		try (FileOutputStream fileOut = new FileOutputStream(file)) {
			wb.write(fileOut);
		} catch (IOException e) {
			LOG.error("Exception in generating the export to excel file"
					+ e.getMessage());
			System.exit(-1);
		}
		LOG.info("Execution completed for Display Item Report Sheet");
		return departmentName;
	}

	public CellStyle getHeaderStyle() {
		LOG.info("Execution started for CellStyle getHeaderStyle");

		if (fcHeader == null) {

			fcHeader = wb.createCellStyle();

			XSSFCellStyle cs = (XSSFCellStyle) fcHeader;
			cs.setFillForegroundColor(new XSSFColor(new Color(192, 192, 192)));

			Font f = wb.createFont();
			f.setColor(IndexedColors.BLACK.getIndex());
			f.setFontName("Calibri");
			//f.setBoldweight(Font.BOLDWEIGHT_BOLD);
			f.setBold(true);
			
			fcHeader.setFont(f);
			fcHeader.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			fcHeader.setBorderRight(BorderStyle.THIN);
			fcHeader.setRightBorderColor(IndexedColors.BLACK.getIndex());
			fcHeader.setBorderLeft(BorderStyle.THIN);
			fcHeader.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			fcHeader.setBorderTop(BorderStyle.THIN);
			fcHeader.setTopBorderColor(IndexedColors.BLACK.getIndex());
			fcHeader.setBorderBottom(BorderStyle.THIN);
			fcHeader.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		}
		LOG.info("Execution completed for CellStyle getHeaderStyle");
		return fcHeader;
	}

	public CellStyle getRowStyle(int row) {
		LOG.info("Execution completed for CellStyle getRowStyle");
		if (fcOddRow == null) {
			fcOddRow = getRowStyleTemplate();
			XSSFCellStyle cs = (XSSFCellStyle) fcOddRow;
			cs.setFillForegroundColor(new XSSFColor(new Color(220, 230, 241)));
			fcOddRow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}
		if (fcEvenRow == null) {
			fcEvenRow = getRowStyleTemplate();
			XSSFCellStyle cs = (XSSFCellStyle) fcEvenRow;
			cs.setFillForegroundColor(new XSSFColor(new Color(255, 255, 255)));
			fcEvenRow.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}

		if (row % 2 == 0) {
			LOG.info("Execution completed for CellStyle fcEvenRow");
			return fcEvenRow;
		}
		else {
			LOG.info("Execution completed for CellStyle fcOddRow");
		
			return fcOddRow;
		}
	}

	private CellStyle getRowStyleTemplate() {
		LOG.debug("Execution started for getRowStyleTemplate");
		CellStyle template = wb.createCellStyle();

		Font f = wb.createFont();
		f.setFontName("Calibri");
		//f.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		f.setBold(false);
		template.setFont(f);

		template.setBorderRight(BorderStyle.THIN);
		template.setRightBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderLeft(BorderStyle.THIN);
		template.setLeftBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderTop(BorderStyle.THIN);
		template.setTopBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setBorderBottom(BorderStyle.THIN);
		template.setBottomBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
		template.setWrapText(true);
		LOG.debug("Execution completed for CellStyle getRowStyleTemplate");
		return template;
	}

	public Cell createCell(Row row, int index, CellStyle cs) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cs);
		return cell;
	}
	

	/**
	 * @param obj
	 * @return
	 */
	private String getStringValue(Object obj) {
		if (obj == null)
			return "";
		return ((String) obj).trim();
	}
	
	/**
	 * @param obj
	 * @return
	 */
	
	private String getDate(Object obj){
		DateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		if(obj == null){
			return "";
		}
		else{
			return formatter.format((Date) obj);
		}
	}
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		else if (obj instanceof Double)
			return BigDecimal.valueOf((Double)obj);
		else if (obj instanceof Integer)
			return new BigDecimal((Integer)obj);
		return (BigDecimal) obj;
	}
	
	public List<DisplayItemDetail> buildDisplayItemDetailDtoList(
			List<Object[]> displayItemObjList) {
		LOG.info("Execution started for buildDisplayItemDetailDtoList");
		Set<DisplayItemDetail> displayitemdetail = new LinkedHashSet<>();
		for (Object[] obj : displayItemObjList){
			DisplayItemDetail disp = new DisplayItemDetail();
			disp.setProductSku(getStringValue(obj[0]));
			disp.setItemDesc(getStringValue(obj[1]));
			disp.setShippingPackNumber(getBigDecimalValue(obj[2]));
			disp.setMasterCasePackNumber(getBigDecimalValue(obj[3]));
			disp.setSizeNumber(getBigDecimalValue(obj[4]));
			disp.setMultiComponentItemInd(getStringValue(obj[5]));
			disp.setCaseUpc(getStringValue(obj[6]));
			disp.setOnHandQty(getBigDecimalValue(obj[7]));
			disp.setOnOrderQty(getBigDecimalValue(obj[8]));
			disp.setSlot(getStringValue(obj[9]));
			disp.setItemCreateDate(getDate(obj[10]));
			//whse
			if(getStringValue(obj[16]).equals("Y")){
				disp.setCost(getBigDecimalValue(obj[14]));
				disp.setLastShipDate(getDate (obj[12]));
			}
			//dsd
			if(getStringValue(obj[17]).equals("Y")){
				disp.setCost(getBigDecimalValue(obj[13]));
				disp.setLastShipDate(getDate (obj[11]));
			}
			disp.setOneTimeBuyFlag(getStringValue(obj[15]));
			disp.setProductSourceCode(updateSourceBasedOnDsdAndWhse(getStringValue(obj[16]),getStringValue(obj[17])));
			displayitemdetail.add(disp);
		}
		LOG.info("Execution completed for buildDisplayItemDetailDtoList");
		return new ArrayList<>(displayitemdetail);
	}
	
	private String updateSourceBasedOnDsdAndWhse(String whse, String dsd) {
		String dsdOrWhse=null;
		if(whse.equals("Y")){
			dsdOrWhse="WHSE";
		}
		if(dsd.equals("Y")){
			dsdOrWhse="DSD";
		}
		return dsdOrWhse;
	}
	
	@SuppressWarnings("deprecation")
	public String createDisplayItemExceptionReportSheet(String exceptionFileName,
			String deptCode, String company, String division, String deptName,
			String whsedsd ) {
		LOG.info("Execution started for createDisplayItemExceptionReportSheet");

		wb = new XSSFWorkbook();
		fcHeader = null;
		fcOddRow = null;
		fcEvenRow = null;
		String departmentName = "";

		displayItemsSheet = wb.getSheet("DisplayExceptionItems");
		if (displayItemsSheet == null)
			displayItemsSheet = wb.createSheet("DisplayExceptionItems");
		
		displayItemsSheet.setAutoFilter(CellRangeAddress.valueOf("A1:D1"));

		int rowIndex = 0;
		Row header = displayItemsSheet.createRow(rowIndex);
		int colIndex = 0;

		for (String headerString : displayExceptionHeaderRowColumns) {
			Cell cell = header.createCell(colIndex++);
			cell.setCellStyle(getHeaderStyle());
			cell.setCellValue(headerString);
			
			
		}

		List<Object[]> records = displayerSQLRepo.fetchDeptWiseDisplayComponentExceptionListExport(company, division,
						deptCode,whsedsd);
		List<DisplayExceptionItemDetail> displayRecords = buildDisplayExceptionItemDetailDtoList(records);
		LOG.debug("Completed fetching all"+displayRecords.size()+"displayRecords");
		if (!displayRecords.isEmpty()) {
			departmentName=deptName;

			for (DisplayExceptionItemDetail srcRecord : displayRecords) {

				colIndex = 0;
				Row row = displayItemsSheet.createRow(++rowIndex);
				CellStyle rowStyle = getRowStyle(rowIndex);
				rowStyle.setWrapText(false);

				Cell cell0 = createCell(row, colIndex++, rowStyle);
				cell0.setCellValue(srcRecord.getDepartmentNm());

				Cell cell1 = createCell(row, colIndex++, rowStyle);
				cell1.setCellValue(srcRecord.getExceptionCategory());
				

				Cell cell2 = createCell(row, colIndex++, rowStyle);
				cell2.setCellValue(srcRecord.getProductSKU());

				Cell cell3 = createCell(row, colIndex++, rowStyle);
				cell3.setCellValue(srcRecord.getItemDesc());

				Cell cell4 = createCell(row, colIndex++, rowStyle);
				cell4.setCellValue( (srcRecord.getPackQty() != null ? srcRecord.getPackQty().doubleValue()
						: Integer.valueOf(0)));

				Cell cellSizeNum = createCell(row, colIndex++, rowStyle);
				cellSizeNum.setCellValue(srcRecord.getSizeNum().doubleValue());

				Cell cell5 = createCell(row, colIndex++, rowStyle);
				cell5.setCellValue(srcRecord.getSizeDesc());
				
				Cell cell6 = createCell(row, colIndex++, rowStyle);
				cell6.setCellValue((Double) (srcRecord.getDisplayItemCost() != null ? srcRecord.getDisplayItemCost().doubleValue()
						: null));
				
				Cell cell7 = createCell(row, colIndex++, rowStyle);
				cell7.setCellValue(srcRecord.getCaseUPC());

				/**UPC Split**/
				
				Cell cell8 = createCell(row, colIndex++, rowStyle);
				cell8.setCellValue(srcRecord.getUpcCountry());
				

				Cell cell9 = createCell(row, colIndex++, rowStyle);
				cell9.setCellValue(srcRecord.getUpcSystem());

				Cell cell10 = createCell(row, colIndex++, rowStyle);
				cell10.setCellValue(srcRecord.getUpcManuf());

				Cell cell11 = createCell(row, colIndex++, rowStyle);
				cell11.setCellValue(srcRecord.getUpcSales());
			
				/*UPC SPLIT*/
				
				Cell cell12 = createCell(row, colIndex++, rowStyle);
				cell12.setCellValue(srcRecord.getComponentItemDesc());
				
				Cell cell13 = createCell(row, colIndex++, rowStyle);
				if(srcRecord.getComponentQty().compareTo(new BigDecimal(0)) > 0)
				{
					cell13.setCellValue(srcRecord.getComponentQty().doubleValue());
				}
				else if(srcRecord.getExceptionCategory().equalsIgnoreCase("MISSING COST EXCEPTION") ||
						srcRecord.getExceptionCategory().equalsIgnoreCase("MISSING QUANTITY EXCEPTION") ||
						srcRecord.getExceptionCategory().equalsIgnoreCase("MISSING COST AND QUANTITY EXCEPTION")
						)
				{
					cell13.setCellValue(srcRecord.getComponentQty().doubleValue());
				}
				else
				{
					cell13.setCellValue("");
				}
				
				Cell cell14 = createCell(row, colIndex++, rowStyle);
				cell14.setCellValue(srcRecord.getComponentSizeDesc());
				
				Cell cell15 = createCell(row, colIndex++, rowStyle);			
				if(srcRecord.getComponentCost().compareTo(new BigDecimal(0)) > 0)
				{
					cell15.setCellValue(srcRecord.getComponentCost().doubleValue());
				}
				else if(srcRecord.getExceptionCategory().equalsIgnoreCase("MISSING COST EXCEPTION") ||
						srcRecord.getExceptionCategory().equalsIgnoreCase("MISSING QUANTITY EXCEPTION") ||
						srcRecord.getExceptionCategory().equalsIgnoreCase("MISSING COST AND QUANTITY EXCEPTION") )
				{
					cell15.setCellValue(srcRecord.getComponentCost().doubleValue());
				}
				else
				{
					cell15.setCellValue("");
				}
				
			}
		}
		for (int ii = 0; ii < 36; ii++) {
			displayItemsSheet.autoSizeColumn(ii);
		}

		String dir = exceptionFileName;
		File file = new File(dir, "DisplayExceptionItems.xlsx");

		// Write the output to a file
		try (FileOutputStream fileOut = new FileOutputStream(file)) {
			wb.write(fileOut);
		} catch (IOException e) {
			LOG.error("Exception in generating the export to excel file"
					+ e.getMessage());
			System.exit(-1);
		}
		LOG.info("Execution completed for createDisplayItemExceptionReportSheet");
		return departmentName;
	}
	
	public List<DisplayExceptionItemDetail> buildDisplayExceptionItemDetailDtoList(
			List<Object[]> displayItemObjList) {
		LOG.info("Execution started for buildDisplayExceptionItemDetailDtoList");
		Set<DisplayExceptionItemDetail> displayitemdetail = new LinkedHashSet<>();
		for (Object[] obj : displayItemObjList){
			DisplayExceptionItemDetail disp = new DisplayExceptionItemDetail();
			
			disp.setProductSKU(getStringValue(obj[0]));
			disp.setDepartmentNm(getStringValue(obj[1]));
			disp.setItemDesc(getStringValue(obj[2]));
			disp.setPackQty(getBigDecimalValue(obj[3]));
			disp.setSizeNum(getBigDecimalValue(obj[4]));
			disp.setSizeDesc(getStringValue(obj[5]));
			disp.setDisplayItemCost(getBigDecimalValue(obj[6]));
			disp.setCaseUPC(getStringValue(obj[7]));
			if(getStringValue(obj[16])!=null &&  
					!getStringValue(obj[16]).equalsIgnoreCase("MISSING COMPONENT EXCEPTION"))
			{
	
			disp.setUpcCountry(getBigDecimalValue(obj[8]).toString());
			disp.setUpcSystem(getBigDecimalValue(obj[9]).toString());
			disp.setUpcManuf(getBigDecimalValue(obj[10]).toString());
			disp.setUpcSales(getBigDecimalValue(obj[11]).toString());
			}
			else
			{
				disp.setUpcCountry("");
				disp.setUpcSystem("");
				disp.setUpcManuf("");
				disp.setUpcSales("");
			}
						
			disp.setComponentItemDesc(getStringValue(obj[12]));
			disp.setComponentQty(getBigDecimalValue(obj[13]));
			disp.setComponentSizeDesc(getStringValue(obj[14]));			
			disp.setComponentCost(getBigDecimalValue(obj[15]));
			if(!getStringValue(obj[16]).equalsIgnoreCase("No_EXCEPTION"))
			{
			disp.setExceptionCategory(getStringValue(obj[16]));
			}
			else
			{
				disp.setExceptionCategory("");
			}
			
			
			displayitemdetail.add(disp);
		}
		LOG.info("Execution completed for buildDisplayExceptionItemDetailDtoList");
		return new ArrayList<>(displayitemdetail);
	}

}
