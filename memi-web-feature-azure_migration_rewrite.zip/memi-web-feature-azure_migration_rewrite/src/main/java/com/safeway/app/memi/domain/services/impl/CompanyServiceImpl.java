/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services.impl;

/* ***************************************************************************
 * NAME : CompanyServiceImpl 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 May 03, 2017 - sgang06 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safeway.app.memi.data.entities.Company;
import com.safeway.app.memi.data.repositories.CompanyRepository;
import com.safeway.app.memi.domain.adapters.ViewFieldsAdapter;
import com.safeway.app.memi.domain.dtos.response.CompanyDto;
import com.safeway.app.memi.domain.services.CompanyService;

@Service("companyService")
public class CompanyServiceImpl implements CompanyService {

    private static final Logger LOG = LoggerFactory.getLogger(CompanyServiceImpl.class);

    
    @Autowired
    private CompanyRepository companyRepo;

    private ViewFieldsAdapter viewAdapter = new ViewFieldsAdapter();

	/* (non-Javadoc)
	 * @see com.safeway.app.memi.domain.services.CompanyService#getAllItems()
	 */
	@Override
	public List<CompanyDto> getAllItems() {
		LOG.info(" fetching Company records");
		List<Company> companyList = companyRepo.findAll();
		List<CompanyDto> companyDtoList = viewAdapter.mapToCompanyDtoList(companyList);
		LOG.info("Completed fetching and mapping all Company records");
		return companyDtoList;
	}

}
