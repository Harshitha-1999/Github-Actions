/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

/* ***************************************************************************
 * NAME         : ReportController 
 *
 * SYSTEM       : MEMD
 *
 * AUTHOR       : SafewayIT
 *
 * REVISION HISTORY
 *
 * Revision 0.0.0.1 March 09, 2016  -  Initial Creation
 *
 ***************************************************************************/

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.safeway.app.memi.domain.dtos.response.CompanyDto;
import com.safeway.app.memi.domain.services.CompanyService;

/**
 * 
 * REST service controller class for Company
 * 
 */
@Controller
@RequestMapping("/company")
public class CompanyListController {
    private static final Logger LOG = LoggerFactory.getLogger(CompanyListController.class);

    
    @Autowired
    private CompanyService companyService;
    
    
    /**
     * Method to list Companies
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseEntity<List<CompanyDto>> getCompaniesList() {

        LOG.info("Fetching company records.");

        List<CompanyDto> response = companyService.getAllItems();

        LOG.info("Completed Fetching all the company records");
        
        return new ResponseEntity<List<CompanyDto>>(response, HttpStatus.OK);

    }

}
