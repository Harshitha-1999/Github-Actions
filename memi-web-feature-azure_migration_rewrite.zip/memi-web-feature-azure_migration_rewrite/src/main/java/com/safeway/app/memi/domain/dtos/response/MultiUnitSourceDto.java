package com.safeway.app.memi.domain.dtos.response;

import java.math.BigDecimal;
import java.util.Set;

public class MultiUnitSourceDto {

	private String companyId;
	private String divisionId;
	private String productSku;
	private String convProductSku;
	private String srcItemDesc;
	private BigDecimal srcPackWhse;
	private BigDecimal srcVendConvFctr;
	private String srcSize;
	private String srcUpc;
	private String prodSourceCd;
	private String caseUpc;
	private BigDecimal srcCost;
	private BigDecimal srcVendNum;
	private String srcVendName;
	private Set<String> upcs;
	private Set<String> deptNames;
	private BigDecimal maxRetail;
	private String deptName;
	private String productHierarchy;
	private String markAsDeadReason;
	private String updatedUserId;
	private String matchIndicator;
	private String convStatusCode;
	private Set<String> productSkuSet;

	public String getConvStatusCode() {
		return convStatusCode;
	}

	public void setConvStatusCode(String convStatusCode) {
		this.convStatusCode = convStatusCode;
	}

	public String getMatchIndicator() {
		return matchIndicator;
	}

	public void setMatchIndicator(String matchIndicator) {
		this.matchIndicator = matchIndicator;
	}

	public String getMarkAsDeadReason() {
		return markAsDeadReason;
	}

	public void setMarkAsDeadReason(String markAsDeadReason) {
		this.markAsDeadReason = markAsDeadReason;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}

	public String getProductHierarchy() {
		return productHierarchy;
	}

	public void setProductHierarchy(String productHierarchy) {
		this.productHierarchy = productHierarchy;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(String divisionId) {
		this.divisionId = divisionId;
	}

	public String getProductSku() {
		return productSku;
	}
	
	public String getConvProductSku() {
		return convProductSku;
	}

	public void setConvProductSku(String convProductSku) {
		this.convProductSku = convProductSku;
	}

	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}

	public String getSrcItemDesc() {
		return srcItemDesc;
	}

	public void setSrcItemDesc(String srcItemDesc) {
		this.srcItemDesc = srcItemDesc;
	}

	public BigDecimal getSrcPackWhse() {
		return srcPackWhse;
	}

	public void setSrcPackWhse(BigDecimal srcPackWhse) {
		this.srcPackWhse = srcPackWhse;
	}

	public BigDecimal getSrcVendConvFctr() {
		return srcVendConvFctr;
	}

	public void setSrcVendConvFctr(BigDecimal srcVendConvFctr) {
		this.srcVendConvFctr = srcVendConvFctr;
	}

	public String getSrcSize() {
		return srcSize;
	}

	public void setSrcSize(String srcSize) {
		this.srcSize = srcSize;
	}

	public String getSrcUpc() {
		return srcUpc;
	}

	public void setSrcUpc(String srcUpc) {
		this.srcUpc = srcUpc;
	}

	public String getProdSourceCd() {
		return prodSourceCd;
	}

	public void setProdSourceCd(String prodSourceCd) {
		this.prodSourceCd = prodSourceCd;
	}

	public String getCaseUpc() {
		return caseUpc;
	}

	public void setCaseUpc(String caseUpc) {
		this.caseUpc = caseUpc;
	}

	public BigDecimal getSrcCost() {
		return srcCost;
	}

	public void setSrcCost(BigDecimal srcCost) {
		this.srcCost = srcCost;
	}

	public BigDecimal getSrcVendNum() {
		return srcVendNum;
	}

	public void setSrcVendNum(BigDecimal srcVendNum) {
		this.srcVendNum = srcVendNum;
	}

	public String getSrcVendName() {
		return srcVendName;
	}

	public void setSrcVendName(String srcVendName) {
		this.srcVendName = srcVendName;
	}

	public Set<String> getUpcs() {
		return upcs;
	}

	public void setUpcs(Set<String> upcs) {
		this.upcs = upcs;
	}

	public Set<String> getDeptNames() {
		return deptNames;
	}

	public void setDeptNames(Set<String> deptNames) {
		this.deptNames = deptNames;
	}

	public BigDecimal getMaxRetail() {
		return maxRetail;
	}

	public void setMaxRetail(BigDecimal maxRetail) {
		this.maxRetail = maxRetail;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public Set<String> getProductSkuSet() {
		return productSkuSet;
	}

	public void setProductSkuSet(Set<String> productSkuSet) {
		this.productSkuSet = productSkuSet;
	}

	@Override
	public String toString() {
		return "MultiUnitSourceDto [companyId=" + companyId + ", divisionId="
				+ divisionId + ", productSku=" + productSku
				+ ", convProductSku=" + convProductSku + ", srcItemDesc="
				+ srcItemDesc + ", srcPackWhse=" + srcPackWhse
				+ ", srcVendConvFctr=" + srcVendConvFctr + ", srcSize="
				+ srcSize + ", srcUpc=" + srcUpc + ", prodSourceCd="
				+ prodSourceCd + ", caseUpc=" + caseUpc + ", srcCost="
				+ srcCost + ", srcVendNum=" + srcVendNum + ", srcVendName="
				+ srcVendName + ", upcs=" + upcs + ", deptNames=" + deptNames
				+ ", maxRetail=" + maxRetail + ", deptName=" + deptName
				+ ", productHierarchy=" + productHierarchy
				+ ", markAsDeadReason=" + markAsDeadReason + ", updatedUserId="
				+ updatedUserId + ", matchIndicator=" + matchIndicator
				+ ", convStatusCode=" + convStatusCode + ", productSkuSet="
				+ productSkuSet + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((convProductSku == null) ? 0 : convProductSku.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MultiUnitSourceDto other = (MultiUnitSourceDto) obj;
		if (convProductSku == null) {
			if (other.convProductSku != null)
				return false;
		} else if (!convProductSku.equals(other.convProductSku))
			return false;
		return true;
	}
	

}
