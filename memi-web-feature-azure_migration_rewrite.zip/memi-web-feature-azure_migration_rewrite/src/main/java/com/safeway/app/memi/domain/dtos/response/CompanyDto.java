/* **************************************************************************
 * Copyright 2017 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.domain.dtos.response;
/* ***************************************************************************
 * NAME         : CompanyDto
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : Safeway IT
 *
 * REVISION HISTORY
 *
 * Initial creation for MEMD
 *
 ***************************************************************************/
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value = { "createTsForSort", "lastUpdateTsForSort" })
public class CompanyDto {

    private String companyID;
    private String companyLglNm;


    @Override
    public String toString() {
        return "Company [companyID=" + companyID + ", companyLglNm=" + companyLglNm + "]";
    }


	public String getCompanyID() {
		return companyID;
	}


	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}


	public String getCompanyLglNm() {
		return companyLglNm;
	}


	public void setCompanyLglNm(String companyLglNm) {
		this.companyLglNm = companyLglNm;
	}
}