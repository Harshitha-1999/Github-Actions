package com.safeway.app.memi.domain.dtos.response;

import java.util.List;

public class UiLikeItemVO {
   
    private UIExceptionSrcDto UiExceptionSrc;
    private List<SimsLikeItemDto> likeItemList;
    

    public List<SimsLikeItemDto> getLikeItemList() {
        return likeItemList;
    }

    public void setLikeItemList(List<SimsLikeItemDto> likeItemList) {
        this.likeItemList = likeItemList;
    }

    public UIExceptionSrcDto getUiExceptionSrc() {
        return UiExceptionSrc;
    }

    public void setUiExceptionSrc(UIExceptionSrcDto uiExceptionSrc) {
        UiExceptionSrc = uiExceptionSrc;
    }

    @Override
    public String toString() {
        return "UiLikeItemVO [UiExceptionSrc=" + UiExceptionSrc + ", likeItemList=" + likeItemList + "]";
    }

}
