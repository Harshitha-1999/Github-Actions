package com.safeway.app.memi.domain.services.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemConvDisplayItem;
import com.safeway.app.memi.data.entities.ItemConvDisplayItemComponents;
import com.safeway.app.memi.data.entities.ItemConvDisplayItemComponentsPK;
import com.safeway.app.memi.data.entities.ItemConvDisplayItemPk;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.data.repositories.DisplaySQLRepository;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ItemConvDisplayItemComponentRepository;
import com.safeway.app.memi.data.repositories.ItemConvDisplayItemRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.adapters.DisplayerAdapter;
import com.safeway.app.memi.domain.dtos.response.DisplayExceptionItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemMatch;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSimsUPC;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceSimsItems;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceUPC;
import com.safeway.app.memi.domain.dtos.response.DisplayItemUnMapDto;
import com.safeway.app.memi.domain.dtos.response.DisplaySimsLikeItems;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UndoCreateNewCicDto;
import com.safeway.app.memi.domain.services.DisplayService;
import com.safeway.app.memi.domain.util.EmailFacilitator;

@Service("DisplayService")
public class DisplayServiceImpl implements DisplayService{
	private static final Logger LOG = LoggerFactory.getLogger(DisplayServiceImpl.class);
	
	//Used For Source Upc
	Set<String> srcUpcList;
	BigDecimal srcTotalQuantity;
	
	 @Autowired
	 private DisplaySQLRepository displayerSQLRepo;
	 
	 @Autowired
	 private ItemConvDisplayItemRepository dispItemRepo;
	 
	 @Autowired
	 private ItemAggregateCorpRepository itemAggregateRepo;
	 
	 @Autowired
	 private UIExceptionSrcRepository exSrcRepo;
	 
	 @Autowired
	 private ItemConvDisplayItemRepository itemConvDisplayRepo;

	 private DisplayerAdapter displayAdapter = new DisplayerAdapter(); 

	 
	 /*FILE UPLOAD Related*/
	 @Autowired
	 private ItemConvDisplayItemComponentRepository dispayComponentRepo;
	 
	 @Value("${memi.mail.fromAddress}")
	 private String fromAddress;
		
	 @Autowired
	 private EmailFacilitator email;
	 /*FILE UPLOAD*/

	@Override
	public List<UIDataVO> getDepartmentWiseDisplayItemData(String company, String division) {
		LOG.info("Fetching all ItemDepartmentDetails ");
		List<UIDataVO> checkTest = buildDisplayItemDepartmentDetails(company, division);
        return checkTest;
	}
	/**
     * @param srclist
     * @return
     */
	private List<UIDataVO> buildDisplayItemDepartmentDetails(String companyId, String divisionId) {
		List<UIDataVO> voList = new ArrayList<>();
		LOG.debug("Started Execution for buildDisplayItemDepartmentDetails ");
		List<Object[]> departmentRecords = displayerSQLRepo.fetchDepartmentWiseDisplayItemData(companyId, divisionId);
		for (Object[] deptRecord : departmentRecords) {
			UIDataVO vo = new UIDataVO();
			vo.setTotalRecord(getBigDecimalValue(deptRecord[0]).intValue());
			vo.setDeptName(getStringValue(deptRecord[1]));
			vo.setDeptCode(getStringValue(deptRecord[2]));
			vo.setTotalDSDRecords(getBigDecimalValue(deptRecord[3]).intValue());
			vo.setTotalWHSERecords(getBigDecimalValue(deptRecord[4]).intValue());
			voList.add(vo);
		}
		
		List<Object[]> completedRecords = displayerSQLRepo.fetchDepartmentWiseCompletedDisplayItem(companyId, divisionId);
		for (Object[] completedRecord : completedRecords) {
			UIDataVO vo = new UIDataVO();
			UIDataVO existingVo;
			vo.setDeptCode(getStringValue(completedRecord[2]));
			if(voList.contains(vo))
			{
				existingVo = voList.get(voList.indexOf(vo));
				existingVo.setCompletedItmCnt(getBigDecimalValue(completedRecord[0]).intValue());
				existingVo.setCompletedDSDItmCnt(getBigDecimalValue(completedRecord[3]).intValue());
				existingVo.setCompletedWHSEItmCnt(getBigDecimalValue(completedRecord[4]).intValue());
			}
			else
			{
				vo.setCompletedItmCnt(getIntegerValue(completedRecord[0]).intValue());
				vo.setCompletedDSDItmCnt(getIntegerValue(completedRecord[3]).intValue());
				vo.setCompletedWHSEItmCnt(getIntegerValue(completedRecord[4]).intValue());
				vo.setDeptName(getStringValue(completedRecord[1]));
				voList.add(vo);
			}
		}
		LOG.debug("Completed Execution for buildDisplayItemDepartmentDetails.");
		return voList;
	}
	
	@Override
    public List<DisplayItemDetail> loadDepartmentWiseDisplayItemList(String companyId,String divisionId, String departmentCode,
                  char exceptionType, char status, char type) {
		LOG.info("Fetching all DepartmentWiseDisplayItemDetails");
		List<Object[]> displayitemdetail = displayerSQLRepo.fetchDepartmentWiseDisplayItemDetails(companyId, divisionId, departmentCode, status, type);
		return displayAdapter.mapToDisplayItemDetail(displayitemdetail);
    }
	
	@Override
	public Map<String,List<String>> updateMultiCompItemInd(List<DisplayItemDetail> displayItemDetail,char markUnmarkInd){
		LOG.info("Started Execution for updateMultiCompItemInd ");
		Map<String,List<String>> response=new HashMap<>();
		List<String> productSkuSuccess = new ArrayList<>();
		List<String> productSkuFailure = new ArrayList<>();
		for (DisplayItemDetail item : displayItemDetail) {
			LOG.info("Fetching all ItemConvDisplayItems");
			List<ItemConvDisplayItem> record = itemConvDisplayRepo
					.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
		if(!record.isEmpty())
		{
			for(ItemConvDisplayItem itemrecord :  record) {
				if(markUnmarkInd=='U'){
					itemConvDisplayRepo.delete(itemrecord);
				}
			}
		}
			
		int result=	displayerSQLRepo.updateMultiCompItemInd(item.getCompanyId(),item.getDivisionId(),item.getProductSku(),item.getDeptCode(),item.getCaseUpc(), markUnmarkInd);
		
			if (result>0) {
				List<Object[]> list=	displayerSQLRepo.checkForDsdWhse(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
				String tableName=null;
				String configValue=null;
				
				for (Object[] obj : list) {
					if (obj[0] != null && obj[0].equals("Y"))
						tableName = "DSD_LEVEL_ITEM";
					if (obj[1] != null && obj[1].equals("Y"))
						tableName = "WAREHOUSE_LEVEL_ITEM";
				}
				if(markUnmarkInd=='M') configValue="Y";
				
				if(markUnmarkInd=='U') configValue="N";
				
				List<Object[]> skuList =displayerSQLRepo.checkForRecordItemConSrcDataReplace(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
				if(skuList.isEmpty()){
					displayerSQLRepo.insertRecordToItemConSrcDataReplace(item.getCompanyId(),item.getDivisionId(),item.getProductSku(),tableName,configValue,item.getUpdatedUserID());
					
				}else{
					displayerSQLRepo.updateRecordToItemConSrcDataReplace(item.getCompanyId(),item.getDivisionId(),item.getProductSku(),configValue,item.getUpdatedUserID());
				}
				productSkuSuccess.add(item.getProductSku());
			} else {
				productSkuFailure.add(item.getProductSku());
			}
		}
		response.put("Success", productSkuSuccess);
		response.put("Failure", productSkuFailure);
		LOG.info("Completed Execution for updateMultiCompItemInd ");
		return response;
	}
	
	
	@Override
	public Map<String,List<String>> markItemsAsDead(List<DisplayItemDetail> displayItemDetail) {
		LOG.info("Started Execution for markItemsAsDead ");
		HashMap<String,List<String>> response=new HashMap<>();
		List<String> productSkuSuccess = new ArrayList<>();
		List<String> productSkuFailure = new ArrayList<>();
		for (DisplayItemDetail item : displayItemDetail) {
			int result=	displayerSQLRepo.markItemsAsDead(item.getCompanyId(), item.getDivisionId(), item.getProductSku(), item.getMarkAsDeadReason(),item.getUpdatedUserID());
			if (result > 0) {
				productSkuSuccess.add(item.getProductSku());
			} else {
				productSkuFailure.add(item.getProductSku());
			}
		}
		response.put("Success", productSkuSuccess);
		response.put("Failure", productSkuFailure);
		LOG.info("Completed Execution for markItemsAsDead ");
		return response;
	}
	
	@Override
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnItemDesc(List<DisplayItemDetail> displayItem) {
		LOG.info("Fetching all DeptWiseItemDetailsBasedOnItemDesc");
		List<Object[]> displayitemdetailBasedonItemDesc = displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnItemDesc(displayItem.get(0).getCompanyId(), displayItem.get(0).getDivisionId(), displayItem.get(0).getDeptCode(), escapeMetaCharacters(displayItem.get(0).getItemDesc()), displayItem.get(0).getItemType());
		return displayAdapter.mapToDisplayItemDetail(displayitemdetailBasedonItemDesc);
	}
	
	@Override
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnProductSku(List<DisplayItemDetail> displayItem) {
		LOG.info("Fetching all displayitemdetailBasedonProductSku");
		List<Object[]> displayitemdetailBasedonProductSku = displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnProductSku(displayItem.get(0).getCompanyId(), displayItem.get(0).getDivisionId(), displayItem.get(0).getDeptCode(), escapeMetaCharacters(displayItem.get(0).getProductSku()), displayItem.get(0).getItemType());
		return displayAdapter.mapToDisplayItemDetail(displayitemdetailBasedonProductSku);
	}
	
	@Override
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnOneTimeBuyFlag(List<DisplayItemDetail> displayItem) {
		LOG.info("Fetching all Dept Wise Item Details Based On display item detail Based on One Time Buy Flag");
		List<Object[]> displayitemdetailBasedonOneTimeBuyFlag = displayerSQLRepo.fetchDeptWiseItemDetailsBasedOndisplayitemdetailBasedonOneTimeBuyFlag(displayItem.get(0).getCompanyId(), displayItem.get(0).getDivisionId(), displayItem.get(0).getDeptCode(), escapeMetaCharacters(displayItem.get(0).getOneTimeBuyFlag()), displayItem.get(0).getItemType());
		return displayAdapter.mapToDisplayItemDetail(displayitemdetailBasedonOneTimeBuyFlag);
	}
	
	public String escapeMetaCharacters(String inputString) {

		if (inputString.contains("'")) {
			inputString = StringUtils.replace(inputString, "'", "''");
		}
		if (inputString.contains("&")) {
			inputString = StringUtils.replace(inputString, "&", "&'||'");
		}
		if (inputString.contains("%")) {
			inputString = StringUtils.replace(inputString, "%", "|%");
		}
		if (inputString.contains("_")) {
			inputString = StringUtils.replace(inputString, "_", "|_");
		}
		return StringUtils.strip(inputString.toUpperCase());
	}
	
	private String removeZero(String str){
		StringBuilder  sb = new StringBuilder(str);
        while (sb.length()>1 && sb.charAt(0) == '0')
            sb.deleteCharAt(0);
        return sb.toString(); 
    }
	
	private List<DisplayItemSourceUPC> buildSrcItemDetailUPCList(
			List<Object[]> displayItemObjList) {
		LOG.debug("Fetching all Item DetailUPCList");
		DisplayItemSourceUPC upcDetail = null;
		List<DisplayItemSourceUPC> upcDetailList = new ArrayList<>();
		srcUpcList = new HashSet<>();
		
		srcTotalQuantity=new BigDecimal(0);
		for (Object[] obj : displayItemObjList) {
			upcDetail = new DisplayItemSourceUPC();
			upcDetail.setUpc(getStringValue(obj[0]));
			upcDetail.setUpcDesc(getStringValue(obj[1]));
			
			upcDetail.setQuantity(getBigDecimalValueFromBigDecimal(obj[2]));
			upcDetail.setMemoCost(getBigDecimalValueFromBigDecimal(obj[3]));
			srcTotalQuantity = srcTotalQuantity.add(getBigDecimalValueFromBigDecimal(obj[2]));
			srcUpcList.add(upcDetail.getUpc());
			upcDetailList.add(upcDetail);
			
		}
		if(!upcDetailList.isEmpty()){
			Collections.sort(upcDetailList,DisplayItemSourceUPC.upcComparator);
		}
		LOG.debug("Completed Fetching all Item DetailUPCList");
		return upcDetailList;
	}
	
	
	private List<DisplaySimsLikeItems> buildSimsItemBasedOnCaseUpc(List<Object[]> simsDetails, List<String> cicList,String srcCaseUpc,BigDecimal srcCost) {
		LOG.debug("Fetching all SimsItemBasedOnCaseUpc");
		Map<String,List<DisplayItemMatch>> simsDataMap=new HashMap<>();
		List<DisplaySimsLikeItems> displaySimsLikeItemList = new ArrayList<>();
		DisplayItemMatch simsDetail = null;
		List<DisplayItemMatch> displayItemMatchList;
		
		for (Object[] obj : simsDetails) {
			
			String key = ((BigDecimal) obj[0]).toString();
			
			if(simsDataMap.containsKey(key)){
				displayItemMatchList =simsDataMap.get(key);
				simsDetail = new DisplayItemMatch();
				simsDetail.setCic(getBigDecimalValue(obj[0]));
				simsDetail.setCaseUpc(getStringValue(obj[1]));
				simsDetail.setItemDesc(getStringValue(obj[2]));
				simsDetail.setDisplayItem(getCharacterValue(obj[3]));
				simsDetail.setUpc(getStringValue(obj[4]));
				simsDetail.setUpcDesc(getStringValue(obj[5]));
				simsDetail.setQuantity(getBigDecimalValue (obj[6]));
				simsDetail.setMemoCost(getBigDecimalValue(obj[7]));
				simsDetail.setCost(getBigDecimalValue(obj[8]));
				displayItemMatchList.add(simsDetail);
				simsDataMap.put(simsDetail.getCic().toString(), displayItemMatchList);
				
			}
			else {
				displayItemMatchList = new ArrayList<>(); 
				simsDetail = new DisplayItemMatch();
				simsDetail.setCic(getBigDecimalValue(obj[0]));
				simsDetail.setCaseUpc(getStringValue(obj[1]));
				simsDetail.setItemDesc(getStringValue(obj[2]));
				simsDetail.setDisplayItem(getCharacterValue(obj[3]));
				simsDetail.setUpc(getStringValue(obj[4]));
				simsDetail.setUpcDesc(getStringValue(obj[5]));
				simsDetail.setQuantity(getBigDecimalValue (obj[6]));
				simsDetail.setMemoCost(getBigDecimalValue(obj[7]));
				simsDetail.setCost(getBigDecimalValue(obj[8]));
				displayItemMatchList.add(simsDetail);
				simsDataMap.put(simsDetail.getCic().toString(), displayItemMatchList);
				
			}
			
		}
		for (Map.Entry<String, List<DisplayItemMatch>> entry : simsDataMap.entrySet()) {
			String cic=entry.getKey();
			List<DisplayItemMatch> displayItemMatchMapList = simsDataMap.get(cic);
			DisplaySimsLikeItems displaySimsLikeItems = new DisplaySimsLikeItems();
			DisplayItemMatch disp = displayItemMatchMapList.get(0);
			for (String exCic : cicList) {
				if(exCic.equals(disp.getCic().toString())){
					displaySimsLikeItems.setCicAlreadyProcessed('Y');
					break;
				}
				else{
					displaySimsLikeItems.setCicAlreadyProcessed('N');
				}			
			}
			displaySimsLikeItems.setCic(disp.getCic());
			displaySimsLikeItems.setItemDesc(disp.getItemDesc());
			displaySimsLikeItems.setCaseUpc(disp.getCaseUpc());
			displaySimsLikeItems.setDisplayItem(disp.getDisplayItem());
			displaySimsLikeItems.setCaseUpcMatch(getCaseUpcMatch(disp.getCaseUpc(),srcCaseUpc));
			BigDecimal costCic = new BigDecimal(0); 
			BigDecimal quantityCIC= new BigDecimal(0);
			Set<String> upcSetInItemMatch = new HashSet<>();
			
			Set<DisplayItemSimsUPC> displayItemUPCList = new HashSet<>();
			
			for(DisplayItemMatch dim : displayItemMatchMapList){
				DisplayItemSimsUPC itemUpc = new DisplayItemSimsUPC();
				itemUpc.setUpcDesc(dim.getUpcDesc());
				itemUpc.setUpc(dim.getUpc());
				upcSetInItemMatch.add(dim.getUpc());
				costCic=costCic.max(dim.getCost());
				itemUpc.setMemoCost(dim.getMemoCost());
				itemUpc.setQuantity(dim.getQuantity());
				displayItemUPCList.add(itemUpc);
			}
			for (DisplayItemSimsUPC displayItemSimsUPC : displayItemUPCList) {
				quantityCIC=quantityCIC.add(displayItemSimsUPC.getQuantity());
			}
			displaySimsLikeItems.setUpcMatch(getUpcMatch(new ArrayList<String>(upcSetInItemMatch)));
			displaySimsLikeItems.setCost(costCic);
			displaySimsLikeItems.setCostMatch(getCostMatchForCic(srcCost,costCic));
			displaySimsLikeItems.setQtyMatch(getQuantityMatch(quantityCIC));
			displaySimsLikeItems.setDisplayItemUPC(new ArrayList<DisplayItemSimsUPC>(displayItemUPCList));
			displaySimsLikeItemList.add(displaySimsLikeItems);
			
		}
		LOG.debug("Completed Fetching all SimsItemBasedOnCaseUpc");
		return displaySimsLikeItemList;
	}
private List<DisplaySimsLikeItems> buildSimsItemBasedOnUpcSet(List<Object[]> simsDetails, List<String> cicList,String srcCaseUpc,List<String> srcUpcList,BigDecimal srcCost) 
{

	LOG.debug("Fetching all DisplaySimsLikeItems BasedOnUpcSet");
		Map<String,List<DisplayItemMatch>> simsDataMap=new HashMap<>();
		List<DisplaySimsLikeItems> displaySimsLikeItemList = new ArrayList<>();
		DisplayItemMatch simsDetail = null;
		List<DisplayItemMatch> displayItemMatchList;
		Set<String> upcSetSims=new HashSet<>();
		
		for (Object[] obj : simsDetails) {
			
			String key = ((BigDecimal) obj[0]).toString();
			
			if(simsDataMap.containsKey(key)){
				displayItemMatchList =simsDataMap.get(key);
				simsDetail = new DisplayItemMatch();
				simsDetail.setCic(getBigDecimalValueFromBigDecimal(obj[0]));
				simsDetail.setCaseUpc(getStringValue(obj[1]));
				simsDetail.setItemDesc(getStringValue(obj[2]));
				simsDetail.setDisplayItem(getCharacterValue(obj[3]));
				simsDetail.setUpc(getStringValue(obj[4]));
				simsDetail.setUpcDesc(getStringValue(obj[5]));
				simsDetail.setQuantity(getBigDecimalValueFromBigDecimal(obj[6]));
				simsDetail.setMemoCost(getBigDecimalValueFromBigDecimal(obj[7]));
				simsDetail.setCost(getBigDecimalValueFromBigDecimal(obj[8]));
				upcSetSims.add(getStringValue(obj[4]));
				displayItemMatchList.add(simsDetail);
				simsDataMap.put(simsDetail.getCic().toString(), displayItemMatchList);
				
			}
			else {
				displayItemMatchList = new ArrayList<>(); 
				simsDetail = new DisplayItemMatch();
				simsDetail.setCic(getBigDecimalValueFromBigDecimal(obj[0]));
				simsDetail.setCaseUpc(getStringValue(obj[1]));
				simsDetail.setItemDesc(getStringValue(obj[2]));
				simsDetail.setDisplayItem(getCharacterValue(obj[3]));
				simsDetail.setUpc(getStringValue(obj[4]));
				simsDetail.setUpcDesc(getStringValue(obj[5]));
				simsDetail.setQuantity(getBigDecimalValueFromBigDecimal(obj[6]));
				simsDetail.setMemoCost(getBigDecimalValueFromBigDecimal(obj[7]));
				simsDetail.setCost(getBigDecimalValueFromBigDecimal(obj[8]));
				upcSetSims.add(getStringValue(obj[4]));
				displayItemMatchList.add(simsDetail);
				simsDataMap.put(simsDetail.getCic().toString(), displayItemMatchList);
				
			}
			
		}
		for (Map.Entry<String, List<DisplayItemMatch>> entry : simsDataMap.entrySet()) {
			String cic=entry.getKey();
			List<DisplayItemMatch> displayItemMatchMapList = simsDataMap.get(cic);
			DisplaySimsLikeItems displaySimsLikeItems = new DisplaySimsLikeItems();
			DisplayItemMatch disp = displayItemMatchMapList.get(0);
			for (String exCic : cicList) {
				if(exCic.equals(disp.getCic().toString())){
					displaySimsLikeItems.setCicAlreadyProcessed('Y');
					break;
				}
				else{
					displaySimsLikeItems.setCicAlreadyProcessed('N');
				}			
			}
			if(!(disp.getCaseUpc().equals(srcCaseUpc))){
				Set<String> upcListInItemMatch = new HashSet<>();
				if(upcSetSims.size()==srcUpcList.size()){
					List<String> upcSetList=new ArrayList<>(upcSetSims);
					if(CollectionUtils.isEqualCollection(upcSetList,srcUpcList)){
						Set<DisplayItemSimsUPC> displayItemUPCList = new HashSet<>();
						BigDecimal costCic = new BigDecimal(0); 
						BigDecimal quantityCIC= new BigDecimal(0);
						for(DisplayItemMatch dim : displayItemMatchMapList){
							DisplayItemSimsUPC itemUpc = new DisplayItemSimsUPC();
							itemUpc.setUpcDesc(dim.getUpcDesc());
							itemUpc.setUpc(dim.getUpc());
							upcListInItemMatch.add(dim.getUpc());
							costCic=costCic.max(dim.getCost());
							itemUpc.setMemoCost(dim.getMemoCost());
							itemUpc.setQuantity(dim.getQuantity());
							displayItemUPCList.add(itemUpc);
						}
						for (DisplayItemSimsUPC displayItemSimsUPC : displayItemUPCList) {
							quantityCIC=quantityCIC.add(displayItemSimsUPC.getQuantity());
						}
						if(CollectionUtils.isEqualCollection(new ArrayList<String>(getSrcUpcList()),new ArrayList<String>(upcListInItemMatch)))
						{
							displaySimsLikeItems.setCic(disp.getCic());
							displaySimsLikeItems.setItemDesc(disp.getItemDesc());
							displaySimsLikeItems.setCaseUpc(disp.getCaseUpc());
							displaySimsLikeItems.setDisplayItem(disp.getDisplayItem());
							displaySimsLikeItems.setCaseUpcMatch(getCaseUpcMatch(disp.getCaseUpc(),srcCaseUpc));
							displaySimsLikeItems.setUpcMatch(getUpcMatch(new ArrayList<String>(upcListInItemMatch)));
							displaySimsLikeItems.setCost(costCic);
							displaySimsLikeItems.setCostMatch(getCostMatchForCic(srcCost,costCic));
							displaySimsLikeItems.setQtyMatch(getQuantityMatch(quantityCIC));
							displaySimsLikeItems.setDisplayItemUPC(new ArrayList<DisplayItemSimsUPC>(displayItemUPCList));
							displaySimsLikeItemList.add(displaySimsLikeItems);
							
						}
						
					}
					
				}
				
			}
			
		}
		LOG.debug(" Completed Fetching all DisplaySimsLikeItems BasedOnUpcSet");
		return displaySimsLikeItemList;
	}
	
	private Character getCaseUpcMatch(String srcCaseUpc,String tarCaseUpc) {
		if(tarCaseUpc.equals(srcCaseUpc))
			return 'Y';
		else 
			return 'N';
	}
	public Set<String> getSrcUpcList() {
		return srcUpcList;
	}
	public void setSrcUpcList(Set<String> srcUpcList) {
		this.srcUpcList = srcUpcList;
	}
	public BigDecimal getSrcTotalQuantity() {
		return srcTotalQuantity;
	}
	public void setSrcTotalQuantity(BigDecimal srcTotalQuantity) {
		this.srcTotalQuantity = srcTotalQuantity;
	}

	private Character getUpcMatch(List<String> upcListInItemMatch) {
		if(CollectionUtils.isEqualCollection(new ArrayList<String>(getSrcUpcList()),upcListInItemMatch))
			return 'Y';
		else 
			return 'N';
	}
	private Character getQuantityMatch(BigDecimal quantityCIC) {
		if(getSrcTotalQuantity().equals(quantityCIC))
			return 'Y';
		else 
			return 'N';
	}
	private Character getCostMatchForCic(BigDecimal srcCostMatch,BigDecimal costMatchCic) {
		if(costMatch(srcCostMatch,costMatchCic))
			return 'Y';
		else 
			return 'N';
	}
	
	private boolean costMatch(BigDecimal srcCostMatch, BigDecimal costMatchCic){
		
		if((srcCostMatch.equals(new BigDecimal(0))) && (costMatchCic.equals(new BigDecimal(0)))){
			return true;
		}else if((srcCostMatch.compareTo(costMatchCic) > 0) || (srcCostMatch.compareTo(costMatchCic) == 0)){
			if(!srcCostMatch.equals(new BigDecimal(0))){
				BigDecimal resultBasedonSrc=((srcCostMatch.subtract(costMatchCic)).divide(srcCostMatch,RoundingMode.HALF_EVEN)).multiply(new BigDecimal(100));
				if((resultBasedonSrc.compareTo(new BigDecimal(5))==0) || (resultBasedonSrc.compareTo(new BigDecimal(5)) < 0)){
					return true;
				}	
			}
		}else{
			if(!costMatchCic.equals(new BigDecimal(0))){
				BigDecimal resultBasedTarget=((costMatchCic.subtract(srcCostMatch)).divide(costMatchCic,RoundingMode.HALF_EVEN)).multiply(new BigDecimal(100));
				if((resultBasedTarget.compareTo(new BigDecimal(5))==0) || (resultBasedTarget.compareTo(new BigDecimal(5)) < 0)){
					return true;
				}
			}
			
		}
		return false;
	}
	
	private String getStringValue(Object obj){
		if(obj == null)
			return "";
		String str = (String) obj;
		return str.trim();
	}
	
	@Override
	public Map<String, String> updateCicMatch(List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
		LOG.info("Update Cic match");
		Map<String, String> response=new HashMap<>();
			if(!displayItemCreateMatchCicDto.isEmpty()){
				for(DisplayItemCreateMatchCicDto header : displayItemCreateMatchCicDto){
					for(DisplayItemSimsUPC simsData : header.getSsimsComponent()){
						String[] upcDetails=simsData.getUpc().split("-");
						if(upcDetails.length==4){
							ItemConvDisplayItem item= new ItemConvDisplayItem();
							ItemConvDisplayItemPk itemPk= new ItemConvDisplayItemPk();
							itemPk.setCompanyId(header.getCompanyId());
							itemPk.setDivisionId(header.getDivisionId());
							itemPk.setProductSKU(header.getProductSku());
							itemPk.setUpcCountry(upcDetails[0]);
							itemPk.setUpcSystem(upcDetails[1]);
							itemPk.setUpcManufacturer(upcDetails[2]);
							itemPk.setUpcSales(upcDetails[3]);
							item.setItemConvDisplayItemPk(itemPk);
							String srcItemDesc = header.getSrcItemDesc().trim().replaceAll(" +", " ");
							item.setSrcItemDesc(srcItemDesc);
							item.setCaseUpc(header.getCaseUpc());
							item.setCic( new BigDecimal(header.getCic()));
							String itemDesc = header.getSsimsHeaderItemDesc().trim().replaceAll(" +", " ");
							String itmDesc =null;
							if(itemDesc.length() >= 40){
								itmDesc=itemDesc.substring(0, 39);
							}else{
								itmDesc=itemDesc;
							}
							item.setItemDesc(itmDesc);
							String componentItemDesc = simsData.getUpcDesc().trim().replaceAll(" +", " ");
							String compDesc =null;
							if(componentItemDesc.length() >= 40){
								compDesc=componentItemDesc.substring(0, 39);
							}else{
								compDesc=componentItemDesc;
							}
							item.setCompItemDesc(compDesc);
							item.setShelfUnit(simsData.getQuantity());
							item.setCostMemo(simsData.getMemoCost());
							item.setNewCicInd('N');
							item.setDisplayItemProcessedIndicator('Y');
							item.setMatchType('M');
							dispItemRepo.save(item);
						}
					}
				}
				
			}
			
			LOG.info( " CIC matched successfully");
			return response;
    }
	
	@Override
	public Map<String, String> createNewCic(List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
		Map<String, String> response = new HashMap<>();
		insertRecordToItemConvDisplayItem(displayItemCreateMatchCicDto);
		insertRecordToUIExceptionSrc(displayItemCreateMatchCicDto);
		LOG.info(" New CIC created successfully");
		return response;
	}
	
	private void insertRecordToItemConvDisplayItem(
			List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
		LOG.debug(" Started execution for RecordToItemConvDisplayItem ");
		if (!displayItemCreateMatchCicDto.isEmpty()) {
			for (DisplayItemCreateMatchCicDto header : displayItemCreateMatchCicDto) {
				for (DisplayItemSourceUPC srcData : header.getSourceComponentUpc()) {

					String[] upcDetails = srcData.getUpc().split("-");
					if (upcDetails.length == 4) {
						ItemConvDisplayItem item = new ItemConvDisplayItem();
						ItemConvDisplayItemPk itemPk = new ItemConvDisplayItemPk();
						itemPk.setCompanyId(header.getCompanyId());
						itemPk.setDivisionId(header.getDivisionId());
						itemPk.setProductSKU(header.getProductSku());
						itemPk.setUpcCountry(upcDetails[0]);
						itemPk.setUpcSystem(upcDetails[1]);
						itemPk.setUpcManufacturer(upcDetails[2]);
						itemPk.setUpcSales(upcDetails[3]);
						item.setItemConvDisplayItemPk(itemPk);
						String srcItemDesc = header.getSrcItemDesc().trim().replaceAll(" +", " ");

						item.setSrcItemDesc(getStringValue(srcItemDesc));
						item.setCaseUpc(getStringValue(header.getCaseUpc()));

						item.setCic(new BigDecimal(0));
						String itemDesc = header.getSrcItemDesc().trim().replaceAll(" +", " ");
						String itmDesc =null;
						if(itemDesc.length() >= 40){
							itmDesc=itemDesc.substring(0, 39);
						}else{
							itmDesc=itemDesc;
						}
						item.setItemDesc(getStringValue(itmDesc));
						String componentItemDesc = srcData.getUpcDesc().trim().replaceAll(" +", " ");
						String compDesc =null;
						if(componentItemDesc.length() >= 40){
							compDesc=componentItemDesc.substring(0, 39);
						}else{
							compDesc=componentItemDesc;
						}
						item.setCompItemDesc(compDesc);
						item.setShelfUnit(srcData.getQuantity());
						item.setCostMemo(srcData.getMemoCost());
						item.setNewCicInd('Y');
						item.setDisplayItemProcessedIndicator('Y');
						item.setMatchType('M');
						dispItemRepo.save(item);
					}
				}
			}

		}
		LOG.debug(" Completed execution for RecordToItemConvDisplayItem ");
	}
	
	private void insertRecordToUIExceptionSrc(
			List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDto) {
		LOG.debug(" Started execution for RecordToUIExceptionSrc ");
		if (!displayItemCreateMatchCicDto.isEmpty()) {
			for (DisplayItemCreateMatchCicDto header : displayItemCreateMatchCicDto) {
				List<String> upcListCorp = displayerSQLRepo.fetchUpcList(
						header.getCompanyId(), header.getDivisionId(),
						header.getProductSku());
					boolean isInserted = false;
					
					if (!upcListCorp.isEmpty()) {
						int i=0;
						for (String corpUpc : upcListCorp  ) {
						
							List<ItemAggregateCorp> sourceObjs = itemAggregateRepo
										.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
												header.getProductSku(),
												header.getDivisionId(),
												header.getCompanyId(),
												corpUpc);
									UIExceptionSrc excSrc = new UIExceptionSrc();
									UiExceptionSrcPk excSrcPk = new UiExceptionSrcPk();
									excSrcPk.setCompanyId(header.getCompanyId());
									excSrcPk.setDivisionId(header
											.getDivisionId());
									excSrcPk.setProductSKU(header
											.getProductSku());
									excSrcPk.setUpcCountry(corpUpc.substring(0,1));
									excSrcPk.setUpcSystem(corpUpc.substring(1,2));
									excSrcPk.setUpcManufacturer(corpUpc.substring(2,7));
									excSrcPk.setUpcSales(corpUpc.substring(7,12));
									excSrc.setCaseUPC(getStringValue(header.getCaseUpc()));
									excSrc.setExcptnTypeCd('A');
									excSrc.setExcptionDesc("Augmentation");
									excSrc.setExcptnProcessdInd('N');
									excSrc.setDispFlag(getCharacterValue(header.getDisplayFlag()));
									excSrc.setUpdatedUserID(getStringValue(header.getUpdatedUserId()));
									excSrc.setCost(getBigDecimalValue(header.getCost()).floatValue());
									excSrc.setPackwhse(getBigDecimalValue(header.getPack()));
									excSrc.setVendConvFactor(getBigDecimalValue(header.getVendorConvFactor()));
								//	excSrc.setItemUsgeInd('R');
								//	excSrc.setItemUsageTypInd('R');
									
									for (ItemAggregateCorp itemAggregateCorp : sourceObjs) {

										excSrc.setPrdHierLevel1((itemAggregateCorp.getPrdHierLevel1()));
										excSrc.setPrdHierLevel2((itemAggregateCorp.getPrdHierLevel2()));
										excSrc.setPrdHierLevel3((itemAggregateCorp.getPrdHierLevel3()));
										excSrc.setPrdHierLevel4((itemAggregateCorp.getPrdHierLevel4()));
										excSrc.setPrdHierLevel5((itemAggregateCorp.getPrdHierLevel5()));

										excSrc.setSizeNmbr(itemAggregateCorp.getSizeNmbr());
										excSrc.setSizeUom(itemAggregateCorp.getSizeUom());
										excSrc.setSizeDesc(itemAggregateCorp.getSizeDesc());
										excSrc.setItmDesc(itemAggregateCorp.getItemDesc());
																														
										excSrc.setPrmyUpcInd(itemAggregateCorp.getPrimaryUpcInd());
										
										excSrc.setPtLabelInd(itemAggregateCorp.getPrivateLevelInd());
										excSrc.setLogicalInd(itemAggregateCorp.getLogicalDelInd());
										excSrc.setBatchId(itemAggregateCorp.getBatchId().intValue());
										excSrc.setIntenetItemDesc(itemAggregateCorp.getInternetDesc());
										excSrc.setWhseItmDesc(itemAggregateCorp.getWhseItemDesc());
										
										if (itemAggregateCorp.getSrcByDsd()
												.equals("Y")) {
											excSrcPk.setProductSrcCd("DSD");
										}
										if (itemAggregateCorp.getSrcByWhse()
												.equals("Y")) {
											excSrcPk.setProductSrcCd("WHSE");
										}
										
										if(itemAggregateCorp.getMaterialItemInd().equals('Y') &&
												itemAggregateCorp.getExpenseItemInd().equals('N')	
												)
										{
											excSrc.setItemUsgeInd('M');
											excSrc.setItemUsageTypInd('M');
										}
										else if(itemAggregateCorp.getMaterialItemInd().equals('N') &&
												itemAggregateCorp.getExpenseItemInd().equals('Y')	
												)
										{
											excSrc.setItemUsgeInd('E');
										}
										else if(itemAggregateCorp.getMaterialItemInd().equals('N') &&
												itemAggregateCorp.getExpenseItemInd().equals('N')
												)
										{
											excSrc.setItemUsgeInd('R');
											excSrc.setItemUsageTypInd('R');
										}

									}
									excSrc.setUiSrcPk(excSrcPk);
									exSrcRepo.save(excSrc);
									isInserted = true;
									i++;
									if (i == 1) {
										break;
									}
						}
					}
					if (isInserted)
						break;
			}
		}
		LOG.debug(" Started execution for RecordToUIExceptionSrc ");
	}
	@Override
	public Map<String, String> undoCreateNewCic(UndoCreateNewCicDto item) {
		LOG.info("Execution started for undoCreateNewCic");
		Map<String, String> response = new HashMap<>();
		boolean isDeleted=false;
		if (item != null) {
			displayerSQLRepo.deleteRecordFromItemConvDisplayItem(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
			displayerSQLRepo.deleteRecordFromUIExceptionSrc(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
			isDeleted=true;
		}
		if(isDeleted)
			response.put("Result", " Record removed successfully");
		
		
		LOG.info("Record removed successfully");
		
		
		return response;
		
	}
	
	
	@Override
	public Map<String, String> undoDisplayersCompleted(UndoCreateNewCicDto item) {
		LOG.info("Execution started for undoDisplayers");
		Map<String, String> response = new HashMap<>();
		boolean isDeleted=false;
		if (item != null) {
			//C=create New CIC
			if(item.getCicType()=='C'){
			
				List<Object[]> record = displayerSQLRepo.checkNewItemAlreadyConverted(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
				List<DisplayItemUnMapDto> itemList= displayAdapter.mapToDisplayItemUnmapDto(record);
				LOG.info("ItemConvDisplayItem Objects loaded.");
				if(!itemList.isEmpty())
				{
					for (DisplayItemUnMapDto displayItem : itemList) {
					
						if(!(displayItem.getConvStatusCodeSet().contains("C"))){
							displayerSQLRepo.deleteRecordFromItemConvDisplayItem(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
							displayerSQLRepo.deleteRecordFromUIExceptionSrc(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
							displayerSQLRepo.deleteRecordFromNewItemDetail(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
							displayerSQLRepo.updateItemXref(item.getCompanyId(),item.getDivisionId(),item.getProductSku(),displayItem.getUpcCountry(),displayItem.getUpcSystem(),displayItem.getUpcManuf(),displayItem.getUpcSales(),item.getUpdatedUserId());
							isDeleted=true;
							break;
						
					}else{
						isDeleted=false;
					}
					}
				}
			}
			//M=match to cic
			if(item.getCicType()=='M'){
				List<String> record = displayerSQLRepo.checkMatchedItemAlreadyConverted(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
				
				if(!record.isEmpty())
				{
					List<String> convStatusCodeList=new ArrayList<>();
					for (String obj : record) {
						//C-means already Converted
						convStatusCodeList.add(getStringValue(obj));
					}
					//C-means already Converted
					if(!(convStatusCodeList.contains("C"))){
						displayerSQLRepo.deleteRecordFromItemConvDisplayItem(item.getCompanyId(),item.getDivisionId(),item.getProductSku());
						isDeleted=true;	
					}else{
						isDeleted=false;
					}
				}
				
			}
			if (isDeleted){
				response.put("Result", " Record removed successfully");
			}else{
				response.put("Result", " Item Already Converted By ETL");
			}
		
		}
		LOG.info("Execution completed for undoDisplayersCompleted");
		return response;
	}
	
	@Override
	public DisplayItemSourceSimsItems fetchSourceAndSimsDetails(
			DisplayItemDetail displayItemDetail) {
		LOG.info(" fetching SourceAndSimsDetails");
		String company=displayItemDetail.getCompanyId();
		String division=displayItemDetail.getDivisionId();
		String productSku=displayItemDetail.getProductSku();
		String caseUpc=displayItemDetail.getCaseUpc();
		String productSourceCode=null;
		if(displayItemDetail.getProductSourceCode().startsWith("W")){
			productSourceCode="W";
		}
		if(displayItemDetail.getProductSourceCode().startsWith("D")){
			productSourceCode="D";
		}
		BigDecimal srcCost=displayItemDetail.getCost();

		DisplayItemSourceSimsItems displayItemSourceSimsItems = new DisplayItemSourceSimsItems();
		
		List<Object[]> sourceComponent=	displayerSQLRepo.fetchSourceComponentDetails(company, division, productSku);
		if(!sourceComponent.isEmpty()){
			List<DisplayItemSourceUPC> displayItemSourceUPC = buildSrcItemDetailUPCList(sourceComponent);
			List<String> cicList= new ArrayList<>();
			
			List<ItemConvDisplayItem> record = itemConvDisplayRepo
					.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(company,division,productSku);
			if(!record.isEmpty())
			{
				for(ItemConvDisplayItem itemrecord :  record)
				{	
					cicList.add(itemrecord.getCic().toString());
				}
			}
			displayItemSourceSimsItems.setDisplayItemSourceUPC(displayItemSourceUPC);
			String[] caseUpcData = caseUpc.split("-");
			List<Object[]> simsDetails =new ArrayList<>();
			if (caseUpcData.length == 5) {
				 simsDetails = displayerSQLRepo.fetchSrcSimsDetails(
						caseUpcData[0], caseUpcData[1], caseUpcData[2],
						caseUpcData[3], caseUpcData[4],productSourceCode);
				}
				
				if(!simsDetails.isEmpty()){
					displayItemSourceSimsItems.setDisplaySimsLikeItems(buildSimsItemBasedOnCaseUpc(simsDetails,cicList,caseUpc,srcCost));
				}else{
					Set<String> countrySet=new HashSet<>();
					Set<String> systemSet=new HashSet<>();
					Set<String> manufSet=new HashSet<>();
					Set<String> salesSet=new HashSet<>();
					List<String> upcList=new ArrayList<>(getSrcUpcList());
					if(!upcList.isEmpty()){
						for (String upc: upcList) {
							String [] upcs=upc.split("-");
							countrySet.add(removeZero(upcs[0]));
							systemSet.add(removeZero(upcs[1]));
							manufSet.add(removeZero(upcs[2]));
							salesSet.add(removeZero(upcs[3]));
						}
					}
					String upcCountry = StringUtils.join(countrySet.toArray(), ",");
					String upcSystem = StringUtils.join(systemSet.toArray(), ",");
					String upcManuf = StringUtils.join(manufSet.toArray(), ",");
					String upcSales = StringUtils.join(salesSet.toArray(), ",");
					List<Object[]> upcSetSimsDetail = displayerSQLRepo.fetchSimsDetailsBasedonSourceUpcSet(upcCountry,upcSystem,upcManuf,upcSales,productSourceCode);
					displayItemSourceSimsItems.setDisplaySimsLikeItems(buildSimsItemBasedOnUpcSet(upcSetSimsDetail,cicList,caseUpc,new ArrayList<String>(srcUpcList),srcCost));
					LOG.debug("Completed fetching all"+upcSetSimsDetail.size()+"upcSetSimsDetail");
				}
				
		

		}
		LOG.info("Completed  fetching SourceAndSimsDetails");
		return displayItemSourceSimsItems;
	
	}
	
	private BigDecimal getBigDecimalValueFromBigDecimal(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		return (BigDecimal) obj;
	}
	
	private BigDecimal getBigDecimalValue(Object obj){
		if(obj == null)
			return new BigDecimal(0);
		else if(obj instanceof Double) {
			return BigDecimal.valueOf((Double)obj);
		}
		else if(obj instanceof Integer) {
			return new BigDecimal((Integer)obj);
		}
		else {
			return (BigDecimal) obj;
		}
	}
	
	private Integer getIntegerValue(Object obj){
		if(obj == null)
			return 0;
		return (Integer) obj;
	}
	
	private Character getCharacterValue(Object obj){
		String empty=" ";
		if(obj == null)
			return Character.valueOf(empty.charAt(0));
		return (Character) obj;
	}

	
	/* File upload servcie methods*/
	
	@Override
	public String uploadExcel(String dataDirectory, String companyId, String divisionId,
			String deptCode, String displayType, String userId,
			 MultipartFile uploadedExcelfile) {
		LOG.info(" Started uploading excel");
		String fileStatus;
		String fileName = uploadedExcelfile.getOriginalFilename();
		if(fileName == null) {
			fileStatus="NOT_EXCEL";
		}
		else{
			String timeStamp=new SimpleDateFormat("yyyyMMddHHmmss").format(new java.sql.Timestamp(System.currentTimeMillis()));
			final StringBuilder excelFileName=new StringBuilder("").append(fileName.replaceAll(".xlsx", "-")).append(timeStamp).append(".xlsx");
			final MultipartFile workingfile=uploadedExcelfile;		 
			final String company =companyId;
			final String division =divisionId;
			final String creatUserId=userId;
			
			fileStatus ="SUCCESS";
			if(!fileName.endsWith(".xlsx"))
			{
				fileStatus="NOT_EXCEL";
			}else {
				final File convFile = new File(dataDirectory, "file.xlsx");
				try {
					workingfile.transferTo(convFile);

				} catch (IllegalStateException | IOException e) {
					LOG.error("Error while uploding excel file with exception: {}", e.getMessage());
					fileStatus = "STR_CHANGE";
				}
				
				if(!checkExcelstructure(workingfile, convFile))
				{
					fileStatus ="STR_CHANGE";
				}
				
				if(fileStatus.equals("SUCCESS"))
				{
				ExecutorService executorService = Executors.newSingleThreadExecutor();
				executorService.execute(new Runnable() {
				    public void run() {
				    	LOG.info("Execution started for ExecutorService execute() method");
				    	try {
				    		Map readAndValidatedExcelData = readRecordFromExcelFilePutInMap(company,division,convFile);
				    		Map<String, DisplayExceptionItemDetail> successRecords = (Map<String, DisplayExceptionItemDetail>) readAndValidatedExcelData.get("successlistRecords");
				    		Map<String,List<String>> failedSet =(Map<String, List<String>>) readAndValidatedExcelData.get("errorSKUset");
				    		insertUpdateSuccesfullDisplayItemComponents(company,division,creatUserId,successRecords);
				    		sendEmail(creatUserId,excelFileName.toString(),failedSet);		    		
						} catch (Exception e) {
							LOG.error("Error occured inside readRecordFromExcelFilePutInMap() method : {}",e.getMessage());
							sendErrorEmail(creatUserId,excelFileName.toString(),e.getMessage());	
							
						}
				    	 finally
				    	 {
				    		 File deleteFile =new File(fileName);
				    		 boolean isDeleted = deleteFile.delete();
				    		 LOG.debug("file Deleted successfully : {}", isDeleted);
				    		 
				    	 }
				    	LOG.info("Execution completed for ExecutorService execute() method");
				    }
		
							
				    
				});
				executorService.shutdown();
				
				}
			}
			
			
	    }
		LOG.info("Completed uploading excel");
		return fileStatus;
	}

	private boolean checkExcelstructure(MultipartFile workingfile, File convFile ) {
		LOG.debug("Execution started for checkExcelstructure");
		boolean status = true;
		
		String[] displayExceptionHeaderRowColumns = { "Department Nm", "Exception Category", "Product SKU", "Item Desc",
				"Pack Qty", "Num Size", "Size Desc", "Display Item Cost", "Case UPC", "Upc Country", "Upc System",
				"Upc Manuf", "Upc Sales", "Component Item Desc", "Component Qty", "Component Size Desc",
				"Component Cost" };
		
		try (FileInputStream inputStream = new FileInputStream(convFile);
				Workbook workbook = new XSSFWorkbook(inputStream)) {

			Sheet sheetName = workbook.getSheetAt(0);
			Row headerRow = sheetName.getRow(0);
			Iterator<Cell> cellIterator = headerRow.cellIterator();
			int i = 0;
			while (cellIterator.hasNext() && i < 16 && status) {
				Cell cell = cellIterator.next();
				i = cell.getColumnIndex();
				StringBuilder columnName = new StringBuilder(cell.getStringCellValue());
				if (!displayExceptionHeaderRowColumns[i].equalsIgnoreCase(columnName.toString())) {
					status = false;
				}
			}

		} catch (IllegalStateException | IOException e) {
			LOG.error("Error occured inside  method : {}", e.getMessage());
			status = false;
		}
		LOG.debug("Execution completed for checkExcelstructure");

		return status;
	}
	private Map readRecordFromExcelFilePutInMap(String companyId, String divisionId,File processFile) throws IOException, IllegalStateException {
		LOG.debug("Execution started for readRecordFromExcelFilePutInMap()");
		Map<String, DisplayExceptionItemDetail> successlistRecords = new HashMap<>();
		Map<String, List> errorSKUset =new HashMap();
		
		// Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();
		try (FileInputStream inputStream = new FileInputStream(processFile)) {
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet sheetName = workbook.getSheetAt(0);
			Iterator<Row> rowIterartor = sheetName.iterator();
			
			while (rowIterartor.hasNext()) {
				Row row = rowIterartor.next();
				//just skip the rows if row number is 0
				if(row.getRowNum()==0){
					   continue; 
				}
				Iterator<Cell> cellIterator = row.cellIterator();
				List<String> cellValue=addCellObjects(cellIterator);				
				
		       	         
				         if(!errorSKUset.containsKey(cellValue.get(2)) &&
				        		 cellValue.get(1)!=null && !cellValue.get(1).toString().equals("")	 
				        		 )
				         {
				        	Map objectMap = mapToExcelFileRow(companyId,divisionId,cellValue);
							List<String> validations =(List<String>) objectMap.get("validation");
							DisplayExceptionItemDetail record = (DisplayExceptionItemDetail) objectMap.get("record");
							if(validations.get(0).equals("SUCCESS") )
							{									
								successlistRecords.put(record.getProductSKU()+"-"+ record.getComponentUpc(),record);
							}
							else
							{
								errorSKUset.put(record.getProductSKU(), validations);
							}
				         }
			}
			
			Iterator successSKUKeys =successlistRecords.keySet().iterator();	
			List itemsToRemoveSuccessList =new ArrayList<String>();
			while(successSKUKeys.hasNext())
			{	String key =successSKUKeys.next().toString();
				DisplayExceptionItemDetail localRecord=successlistRecords.get(key);
				if(!errorSKUset.isEmpty() && errorSKUset.containsKey(localRecord.getProductSKU()) )
				{
					itemsToRemoveSuccessList.add(key);
				}
			}
			
			for(Object key : itemsToRemoveSuccessList)
			{
				successlistRecords.remove(key.toString());
			}
			
		}
		catch (Exception e) {

			LOG.error("Error occurred while reading file : {}", e);
			
		}
		
		Map finalMapObjects =new HashMap();
		finalMapObjects.put("successlistRecords", successlistRecords);
		finalMapObjects.put("errorSKUset", errorSKUset);
		LOG.debug("Execution completed for readRecordFromExcelFilePutInMap().");
		return finalMapObjects;
	}
	private List<String> addCellObjects(Iterator<Cell> cellIterator) {
		/*Method to set each row to a 16 cell object*/
		List cells =new ArrayList();
		String [] cellformatvalue ={"","","","","","","","","","","","","","","","",""};
		DataFormatter dataFormatter = new DataFormatter();
		  while (cellIterator.hasNext()) {
	             Cell cell = cellIterator.next();
	             cellformatvalue[cell.getColumnIndex()] =dataFormatter.formatCellValue(cell);                                   
	           
	         }	
		  for(String val :cellformatvalue)
		  {
			  cells.add(val);  
		  }
		
		return cells;
	}
	private Map mapToExcelFileRow(String companyId, String divisionId,List<String> cellValue) {
		LOG.debug("Execution started for mapToExcelFileRow ");
		
		List<String> validationMessages =new ArrayList();
		DisplayExceptionItemDetail record =new DisplayExceptionItemDetail();
		CharSequence cost ="COST".subSequence(0, 3);
		CharSequence quantity ="QUANTITY".subSequence(0, 7);		
		CharSequence component ="COMPONENT".subSequence(0, 8);
		
		String validSpecialChars = " .-/%&)$";
		
		if(cellValue.get(0).equals(""))
		{
			
			validationMessages.add("Department name should not be empty");
		}
		else
		{
			record.setDepartmentNm(cellValue.get(0));
		}
		
				
		if(cellValue.get(1).equals(""))
		{
			validationMessages.add("Exception category should not be empty");
		}
		else if(!cellValue.get(1).trim().toUpperCase().endsWith("EXCEPTION")  && 
				(cellValue.get(1).trim().toUpperCase().contains(cost) ||
						cellValue.get(1).trim().toUpperCase().contains(quantity) ||		
						cellValue.get(1).trim().toUpperCase().contains(component)						
						)				
				)
		{
			validationMessages.add("Exception category is in valid");
		}
		else
		{			
			record.setExceptionCategory(cellValue.get(1));
		}
				
		
		if(cellValue.get(2).equals(""))
		{
			validationMessages.add("Product SKU should not empty");
		}
		else if(cellValue.get(2).matches("[0-9]{1,20}"))
		{
			record.setProductSKU(cellValue.get(2).trim());
		}
		else
		{
			validationMessages.add("Product SKU should be a number within 20 digits");
		}
		
		
		
		if(cellValue.get(3).equals(""))
		{
			validationMessages.add("Item description should not empty");
		}
		else if(cellValue.get(3).trim().matches("[,.-/%&)'$]+"))
		{
			validationMessages.add("Item description should be a valid string");
		}
		else if(cellValue.get(3).trim().length()>40 || !isValidString(cellValue.get(3).trim(), validSpecialChars))
		{
			validationMessages.add("Item description should be within 40 characters & can contain special charcters  .-/%&)$  ");
		}
		else 
		{
			record.setItemDesc(cellValue.get(3).trim());
		}
		
				
		if(cellValue.get(4).equals(""))
		{
			validationMessages.add("Package quantity should not empty ");
		}
		else if(cellValue.get(4).matches("[0-9]{1,5}"))
		{
			record.setPackQty(new BigDecimal(cellValue.get(4)));
		}
		else
		{
			validationMessages.add("Package quantity should be a number within 5 digits ");
			
		}
		
		if(cellValue.get(6).equals(""))
		{
			validationMessages.add("Size description should not empty");
		}
		else if(cellValue.get(6).trim().matches("[,.-/%&)'$]+"))
		{
			validationMessages.add("Size description should be a valid string");
		}
		else if(cellValue.get(6).trim().length()>20  || !isValidString(cellValue.get(6).trim(), validSpecialChars))
		{
			validationMessages.add("Size description should within  20 characters & can contain special charcters  .-/%&)$ ");
		}
		else 
		{
			record.setSizeDesc(cellValue.get(6).trim());
		}
				
		if(cellValue.get(7).equals(""))
		{
			validationMessages.add("Item cost should not empty");
		}
		else if(cellValue.get(7).matches("[0-9]+[.]?[0-9]{0,2}"))
		{
			record.setDisplayItemCost(new BigDecimal(cellValue.get(7)));
		}
		else
		{
			validationMessages.add("Item cost should be  decimal number with maximum two decimal ");
		}
		
		
		if(cellValue.get(8).equals(""))
		{
			validationMessages.add("Case UPC should not empty");
		}
		else if(cellValue.get(8).matches("[0-9]{1,14}"))
		{ 
			record.setCaseUPC(cellValue.get(8));
		}
		else
		{
			validationMessages.add("Case UPC should be within 14 digits");
		}
		
		
		
		if(cellValue.get(9).equals("") || cellValue.get(10).equals("") || cellValue.get(11).equals("") || cellValue.get(12).equals(""))
		{
			validationMessages.add("Please provide UPC components");				
		}
		else if(cellValue.get(9).matches("[0-9]{1}") && cellValue.get(10).matches("[0-9]{1}") && cellValue.get(11).matches("[0-9]{1,5}")
				&& cellValue.get(12).matches("[0-9]{1,5}"))
		{
			record.setComponentUpc(cellValue.get(9)+cellValue.get(10)+StringUtils.leftPad(cellValue.get(11), 5, '0')
					+StringUtils.leftPad(cellValue.get(12), 5, '0'));
			
			record.setUpcCountry(cellValue.get(9));
			record.setUpcSystem(cellValue.get(10));
			record.setUpcManuf(StringUtils.leftPad(cellValue.get(11), 5, '0'));
			record.setUpcSales(StringUtils.leftPad(cellValue.get(12), 5, '0'));			
			
		}
		else
		{
			validationMessages.add("UPC components are not in the defined format");
		}
		
		
		/*Component validations*/
		if(cellValue.get(13).isEmpty() || cellValue.get(13).trim().equals("") )
		{
			
			validationMessages.add("Component Item description should not empty");
		}
		else if(cellValue.get(13).trim().matches("[,.-/%&)'$]+"))
		{
			validationMessages.add("Component Item description should be a valid string");
		}
		else if(cellValue.get(13).trim().length() >40 || !isValidString(cellValue.get(13).trim(), validSpecialChars))
		{
			validationMessages.add("Component item description should be within 40 characters & can contain special charcters  ,.-/%&)'$ ");
		}
		else
		{
			record.setComponentItemDesc(cellValue.get(13));
		}
		
		
		if(cellValue.get(14).isEmpty() || cellValue.get(14).trim().equals("") )
		{
			validationMessages.add("Component quantity should not be empty");
		}
		else if(cellValue.get(14).matches("[0-9]{1,6}"))
		{ 
			 if(Double.parseDouble(cellValue.get(14).toString()) > 0)
			 {			
			   record.setComponentQty(new BigDecimal(cellValue.get(14)));
			 }
			 else
			 {
				 validationMessages.add("Component quantity should  be greater than 0 "); 
			 }
		}
		else
		{
			validationMessages.add("Component quantity should  be a number within 6 digits");
		}
		
		
		
		if(cellValue.get(15).isEmpty() || cellValue.get(15).trim().equals("") )
		{
			validationMessages.add("Component size should not be empty");
		}
		else if(cellValue.get(15).trim().matches("[,.-/%&)'$]+"))
		{
			validationMessages.add("Component size should be a valid string");
		}
		else if(cellValue.get(15).trim().length()>20  || !isValidString(cellValue.get(15).trim(), validSpecialChars))
		{
			validationMessages.add("Component size description length should be within 20 characters  & can contain special charcters  ,.-/%&)'$  ");
		}
		else
		{
			record.setComponentSizeDesc(cellValue.get(15).trim());
		}
		
		
		
		if(cellValue.get(16).isEmpty() || cellValue.get(16).trim().equals("") )
		{
			validationMessages.add("Component cost should not be empty");
		}
		else if(cellValue.get(16).matches("[0-9]{1,9}[.]?[0-9]{0,3}"))
		{  if(Double.parseDouble(cellValue.get(16).toString()) > 0)
			 {record.setComponentCost(new BigDecimal(cellValue.get(16)));}
			else
			 {validationMessages.add("Component cost should be greater than 0 ");	}
		}
		else
		{
			validationMessages.add("Component cost should be a number with maximum 3 decimals ");
		}	
		
		
		
		/*If No validation*/
		if(validationMessages.isEmpty())
		{
		List<Object[]> result= displayerSQLRepo.validDisplayEntry(companyId,divisionId,record.getProductSKU(),record.getComponentUpc());
		  if(result==null || result.size() <1)
		  {
			  validationMessages.add("The ProductSKU "+record.getProductSKU()+"  does not belongs to Displayers un-reviewed category");
		  }
		
		}
		
		
		if(validationMessages.isEmpty())
		{
			validationMessages.add("SUCCESS");
		}
		
		Map objectValidationMap =new HashMap();		
		objectValidationMap.put("record", record);
		objectValidationMap.put("validation", validationMessages);
		LOG.debug("Execution complted for mapToExcelFileRow ");
		
		return objectValidationMap;
		
	}
	private  boolean isValidString(String str, String allowedSplChars) {
		char[] chars = str.toCharArray();
		for (char c : chars) {
			if (!Character.isLetterOrDigit(c)) {
				if (allowedSplChars != null && allowedSplChars.length() > 0) {
					if (allowedSplChars.indexOf(c) == -1)
						return false;
				} else
					return false;
			}
		}
		return true;
	}
	private void insertUpdateSuccesfullDisplayItemComponents(String companyId, String divisionId,String creatUserId,Map<String, DisplayExceptionItemDetail> successRecords) 
	{
		LOG.debug(" Started execution for insertUpdateSuccesfullDisplayItem ");
		Iterator keySet =successRecords.keySet().iterator();
		
		while(keySet.hasNext())
		{   String key =keySet.next().toString();
		     
		     
			DisplayExceptionItemDetail record=(DisplayExceptionItemDetail) successRecords.get(key);
			BigDecimal upcCountry =new BigDecimal(record.getUpcCountry());
			BigDecimal upcSystem =new BigDecimal(record.getUpcSystem());
			BigDecimal upcManuf =new BigDecimal(record.getUpcManuf());
			BigDecimal upcSales =new BigDecimal(record.getUpcSales());
			
			
			List<ItemConvDisplayItemComponents> updateList=dispayComponentRepo.findByItemConvDisplayItemComponentsPkCompanyidAndItemConvDisplayItemComponentsPkDivisonIdAndItemConvDisplayItemComponentsPkProductSkuAndItemConvDisplayItemComponentsPkUpcCountryAndItemConvDisplayItemComponentsPkUpcSystemAndItemConvDisplayItemComponentsPkUpcManufAndItemConvDisplayItemComponentsPkUpcSales
			(companyId, divisionId, record.getProductSKU(),upcCountry ,upcSystem,upcManuf , upcSales);
			if(updateList.isEmpty())
			{
				ItemConvDisplayItemComponents newRecord= new ItemConvDisplayItemComponents();
				ItemConvDisplayItemComponentsPK newRecordPk =new ItemConvDisplayItemComponentsPK(); 
				newRecordPk.setCompanyid(companyId);
				newRecordPk.setDivisonId(divisionId);
				newRecordPk.setProductSku(record.getProductSKU());
				newRecordPk.setUpcCountry(upcCountry);
				newRecordPk.setUpcSystem(upcSystem);
				newRecordPk.setUpcManuf(upcManuf);
				newRecordPk.setUpcSales(upcSales);
				
				newRecord.setItemConvDisplayItemComponentsPk(newRecordPk);
				newRecord.setCaseUpc(record.getCaseUPC());
				newRecord.setItemmDesc(record.getItemDesc());
				newRecord.setShipCaseQty(record.getPackQty());
				newRecord.setShipSizeDesc(record.getSizeDesc());
				newRecord.setMemoCost(record.getDisplayItemCost());
				
				newRecord.setCompItemDesc(record.getComponentItemDesc());
				newRecord.setCompShelfUnit(record.getComponentQty());
				newRecord.setCompSizeDesc(record.getComponentSizeDesc());
				newRecord.setUnitCost(record.getComponentCost());
				newRecord.setCreatUserId(creatUserId);
				newRecord.setUpdateTs(new Date());
				
				dispayComponentRepo.saveAndFlush(newRecord);				
				
				
			}
			else
			{
				bulkUpdateExistingRecords(record, creatUserId,updateList);
				
			}
			
		}
		LOG.debug(" Completed execution for insertUpdateSuccesfullDisplayItem ");
	}
	private void bulkUpdateExistingRecords(DisplayExceptionItemDetail record,String creatUserId,List<ItemConvDisplayItemComponents> updateList) {
		LOG.debug("Execution started for bulkUpdateExistingRecords");
		for(ItemConvDisplayItemComponents updtObj : updateList)
		{
			updtObj.setCompItemDesc(record.getComponentItemDesc());
			updtObj.setCompShelfUnit(record.getComponentQty());
			updtObj.setCompSizeDesc(record.getComponentSizeDesc());
			updtObj.setUnitCost(record.getComponentCost());
			updtObj.setCreatUserId(creatUserId);
			updtObj.setUpdateTs(new Date());
			dispayComponentRepo.saveAndFlush(updtObj);	
			LOG.debug("Completed Execution started for bulkUpdateExistingRecords");
		}
		
	}

	public File multipartToFile(MultipartFile multipart) throws  IOException, IllegalStateException
	{
		
		LOG.info("Exectution started for multipartToFile()");
	    File convFile = new File("/temp/");
	    multipart.transferTo(convFile);
	    LOG.info("Exectution completed for multipartToFile().");
	    return convFile;
		
			 
	}
	
private void sendEmail(String userId, String excelFileName, Map<String,List<String>> invalidProductSkuMap) throws AddressException {
	LOG.debug("Execution started for sendEmail");
		InternetAddress fromAddr =new InternetAddress(new StringBuilder().append(fromAddress).append("@safeway.com").toString());
		InternetAddress[] toAddr =InternetAddress.parse(userId+"@safeway.com");		
				
		Set<String> invalidProductSkuSet =invalidProductSkuMap.keySet();
		String fileName = excelFileName.substring(0, excelFileName.lastIndexOf("-"));
		// email subject
		String subject = "Display Item Components File Upload Status";
		// email body
		StringBuilder finalRejectReasonBuilder=new StringBuilder().append("<table style='width:100%;border: 1px solid black;border-collapse: collapse;'><tr><th style='width:22%;border: 1px solid black;'>Product SKU</th> <th style='width:75%;border: 1px solid black;'>Column Failing Validation</th></tr>");
		for (Map.Entry<String,List<String>> entry : invalidProductSkuMap.entrySet()) {
			String rejectReasons = StringUtils.join(entry.getValue(), ",");
			finalRejectReasonBuilder.append(new StringBuilder().append("<tr><td style='border: 1px solid black'>"+entry.getKey()+"</td>").append("<td style='border: 1px solid black'>"+rejectReasons+" </td></tr>"));
		}
		String body=null;
		if(invalidProductSkuSet.isEmpty()){
			body="<html>" +
	                "<body>" +
					"<i><p>Hi "+userId+",</p>"+
	                "<p>Thanks for using MIDAS. The file uploaded with the name "+fileName+".xlsx has been successfully processed.</p>"+
	                "<p>In case of any queries, please reach out to Midas.Support@albertsons.com.</p>"+
	                "<p>Thanks & Regards<br>"+
	                "MIDAS</p></i>"+
	                "</body>" +
	                "</html>";
		}else{
			body="<html>" +
	                "<body>" +
	                "<i><p>Hi "+userId+",</p>"+
	                "<p>Thanks for using MIDAS. The file uploaded with the name "+fileName+".xlsx has been processed.</p>"+
	                "<p>We would like to bring to your notice that we were "+"<b>NOT</b>"+" able to process the undermentioned items, as these failed display component validations. </p></i>"+
	                "<p> "+finalRejectReasonBuilder+" </table> </p>"+
	                "<i><p>If you need further assistance please reach out to Midas.Support@albertsons.com.</p>"+
	                "<p>Thanks & Regards<br>"+
	                "MIDAS</p></i>"+
	                "</body>" +
	                "</html>";
		}
		//email.sendEmailMessage(fromAddr,toAddr, subject, body);
		
		LOG.info("-------------------------------EMAIL_BODY---------------------------------------------\\n");
		LOG.info("Email Body : {}", body);
		LOG.info("-------------------------------EMAIL_BODY---------------------------------------------\\n");
		
		LOG.debug("mail sent successfully!");
	}
private void sendErrorEmail(String userId, String excelFileName,String message)  {
	try {
		InternetAddress fromAddr =new InternetAddress(new StringBuilder().append(fromAddress).append("@safeway.com").toString());
	
		InternetAddress[] toAddr =InternetAddress.parse(new StringBuilder().append("Sasipriya.Venugopal@safeway.com").append(",nfran07@safeway.com").append(","+userId+"@safeway.com").toString());
		InternetAddress[] toAddrDev= InternetAddress.parse("nfran07@safeway.com");
		
	
	String fileName = excelFileName.substring(0, excelFileName.lastIndexOf("-"));
	// email subject
	String subject = "Display Item Components File Upload Status";
	String body="<html>" +
				"<body>" +
				"<i><p>Hi "+userId+",</p>"+
				"<p>Thanks for using MIDAS. The file uploaded with the name "+fileName+".xlsx has encountred a problem please check and verify data.</p>"+
				"<p>In case of any queries, please reach out to Midas.Support@albertsons.com.</p>"+
				"<p>Thanks & Regards<br>"+
				"MIDAS</p></i>"+
				"</body>" +
				"</html>";
	
	
	String errorBody="<html>" +
			"<body>" +
			"<i><p>Hi Dev,</p>"+
			"<p>Thanks for using MIDAS. The file uploaded with the name "+fileName+".xlsx has encountred a problem please check and verify data.</p>"+
			"<p>Exception Detail</p>"+
			"<p>"+message+"</p>"+
			"<p>In case of any queries, please reach out to Midas.Support@albertsons.com.</p>"+
			"<p>Thanks & Regards<br>"+
			" MIDAS</p></i>"+
			"</body>" +
			"</html>";
	/**TO USER**/
	email.sendEmailMessage(fromAddr,toAddr, subject, body);
	
	/**TECHNICAL TEAM**/
	email.sendEmailMessage(fromAddr,toAddrDev, subject, errorBody);
	
	
	} catch (AddressException e) {		
		LOG.error("Errorwhile sending email : {}", e.getMessage());
	}
	
}	
	/**new feature**/
	@Override
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedItemDesc(List<DisplayItemDetail> displayItem) {
		List<Object[]> displayitemdetailBasedonItemDesc = displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnReviewedItemDesc(displayItem.get(0).getCompanyId(), displayItem.get(0).getDivisionId(), displayItem.get(0).getDeptCode(), escapeMetaCharacters(displayItem.get(0).getItemDesc()), displayItem.get(0).getItemType());
		return displayAdapter.mapToDisplayItemDetail(displayitemdetailBasedonItemDesc);
	}
	
	@Override
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedProductSku(List<DisplayItemDetail> displayItem) {
		List<Object[]> displayitemdetailBasedonProductSku = displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnReviewedProductSku(displayItem.get(0).getCompanyId(), displayItem.get(0).getDivisionId(), displayItem.get(0).getDeptCode(), escapeMetaCharacters(displayItem.get(0).getProductSku()), displayItem.get(0).getItemType());
		return displayAdapter.mapToDisplayItemDetail(displayitemdetailBasedonProductSku);
	}
	@Override
	public List<DisplayItemDetail> getDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(List<DisplayItemDetail> displayItem) {
		List<Object[]> displayitemdetailBasedonOneTimeBuyFlag = displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(displayItem.get(0).getCompanyId(), displayItem.get(0).getDivisionId(), displayItem.get(0).getDeptCode(), escapeMetaCharacters(displayItem.get(0).getOneTimeBuyFlag()), displayItem.get(0).getItemType());
		
		return displayAdapter.mapToDisplayItemDetail(displayitemdetailBasedonOneTimeBuyFlag);
	}
	/**/
	
}