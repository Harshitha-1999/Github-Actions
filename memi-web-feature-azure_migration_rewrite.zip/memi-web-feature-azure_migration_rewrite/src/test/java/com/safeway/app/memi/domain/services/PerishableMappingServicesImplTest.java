/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

import com.safeway.app.memi.domain.dtos.response.*;
import org.apache.commons.collections4.map.HashedMap;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlan;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ItemConvManualMatchingPlanRepository;
import com.safeway.app.memi.data.repositories.PerishableAdditonalSQLRepository;
import com.safeway.app.memi.data.repositories.PerishableSQLRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.services.impl.PerishableMappingServicesImpl;
import com.safeway.app.memi.domain.util.PerishableConstants;

/**
 **************************************************************************** 
 * NAME : PerishableMappingServicesImplTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Nov 24, 2021 - Initial Creation
 * *************************************************************************
 */
@SpringBootTest(classes = PerishableMappingServicesImpl.class)
public class PerishableMappingServicesImplTest {

	@Autowired
	private PerishableMappingServicesImpl perishableMappingServicesImpl;
	@MockBean
	private PerishableSQLRepository perishableSQLRepository;
	@MockBean
	private ItemConvManualMatchingPlanRepository itemConvManualMatchingPlanRepository;
	@MockBean
	private ItemAggregateCorpRepository itemAggregateRepo;
	@MockBean
	private UIExceptionSrcRepository exSrcRepo;
	@MockBean
	private PerishableAdditonalSQLRepository perishableAdditonalSQLRepository;
	private static PerishableSearchRequestVO perishableSearchRequestVO;
	private static PerishableItemTypeVO perishableItemTypeVo;
	private static PerishableFilterVO perishableFilterVo;
	private static List<PerishableMappingRequest> perishableMappingRequests;
	private static PerishableMappingRequest perishableMappingRequest;

	@BeforeAll
	public static void init() {
		perishableSearchRequestVO = new PerishableSearchRequestVO();
		perishableSearchRequestVO.setStartIndex("startIndex");
		perishableSearchRequestVO.setEndIndex("endIndex");
		perishableSearchRequestVO.setCompanyID("companyID");
		perishableSearchRequestVO.setDivisionID("divisionID");
		perishableSearchRequestVO.setMappingStatus("mappingStatus");
		perishableSearchRequestVO.setSearchCriteriaValue("searchCriteriaValue");
		perishableItemTypeVo = new PerishableItemTypeVO();
		perishableItemTypeVo.setAll(true);
		perishableItemTypeVo.setPlu(true);
		perishableItemTypeVo.setSystem2(true);
		perishableItemTypeVo.setSystem4(true);
		perishableSearchRequestVO.setItemType(perishableItemTypeVo);
		perishableFilterVo = new PerishableFilterVO();
		perishableFilterVo.setCorpItemCD("corpItemCD");
		perishableFilterVo.setDepartment("department");
		perishableFilterVo.setPlu("plu");
		perishableFilterVo.setSlu("slu");
		perishableFilterVo.setVendorCode("vendorCode");
		perishableFilterVo.setVendorName("vendorName");
		perishableFilterVo.setUsageFilter(true);
		perishableFilterVo.setSmicGroupCd("smicGroupCd");
		perishableFilterVo.setSmicCtgryCd("smicCtgryCd");
		perishableFilterVo.setSmicClassCd("smicClassCd");
		perishableFilterVo.setSmicSubClassCd("smicSubClassCd");
		perishableFilterVo.setSmicSubSubClassCd("smicSubSubClassCd");
		perishableFilterVo.setUpc("upc");
		perishableFilterVo.setProdhierarchyLevel1("prodhierarchyLevel1");
		perishableFilterVo.setProdhierarchyLevel2("prodhierarchyLevel2");
		perishableFilterVo.setProdhierarchyLevel3("prodhierarchyLevel3");
		perishableFilterVo.setProdhierarchyLevel3("prodhierarchyLevel3");
		perishableFilterVo.setDivisionNum("divisionNum");
		perishableFilterVo.setHierarchy("hierarchy");
		perishableFilterVo.setItemNum("itemNum");
		perishableFilterVo.setItemDescription("itemDescription");
		perishableFilterVo.setProductSKU("productSKU");
		perishableFilterVo.setSupplierName("supplierName");
		perishableFilterVo.setSupplierNum("supplierNum");
		perishableFilterVo.setShipSearchValue("Y");
		perishableFilterVo.setUsageTypeIndFilter(true);
		perishableFilterVo.setTotalSalesFilter(true);
		perishableFilterVo.setShipped(true);
		perishableFilterVo.setVendorOrderFilter(true);
		perishableFilterVo.setVendUpcPackInd("vendUpcPackInd");
		perishableFilterVo.setVendUpcItem("vendUpcItem");
		perishableFilterVo.setVendUpcManuf("vendUpcManuf");
		perishableFilterVo.setVendUpcNumSys("vendUpcNumSys");
		perishableFilterVo.setVendUpcCountry("vendUpcCountry");
		perishableSearchRequestVO.setFilter(perishableFilterVo);
		perishableSearchRequestVO.setFilterAvail(true);
//		perishableSearchRequestVO.setSortItems(new String[] {"col1","col2"});
		perishableMappingRequest = new PerishableMappingRequest();
		perishableMappingRequest.setUpc("100");
		perishableMappingRequest.setMatchedItemTypeCd("matchedItemTypeCd");
		perishableMappingRequest.setMappingType(PerishableConstants.FORCE_NEW);
		perishableMappingRequests = Collections.singletonList(perishableMappingRequest);
	}

	@Test
	public void listSKUPerishableItems() throws Exception {
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.PLU_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(" ");
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.WHSE_DSD);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("DISP");
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("TOTAL_SALES");
		PerishableSearchRequestVO res = perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		assertEquals("companyID",res.getCompanyID());
	}

	@Test
	public void listSKUPerishableItemsSortingItemsD() throws Exception {
		String[] sortItems=new String[8];
		sortItems[0]="DEPT";
		sortItems[1]="HIER1";
		sortItems[2]="HIER2";
		sortItems[3]="HIER3";
		sortItems[4]="SUPPL";
		sortItems[5]="PSKU";
		sortItems[6]="ITDS";
		sortItems[7]="LKPSUPNO";
		perishableSearchRequestVO.setSortItems(sortItems);
		perishableSearchRequestVO.setSortOrder("D");
		PerishableSKUSearchResults testSearchResult=new PerishableSKUSearchResults();
		testSearchResult.setDeptName("xyz");
		testSearchResult.setHierarchyLevelOne("xyz");
		testSearchResult.setHierarchyLevelTwo("xyz");
		testSearchResult.setHierarchyLevelThree("xyz");
		testSearchResult.setSupplierNam("xyz");
		testSearchResult.setSku("xyz");
		testSearchResult.setItemDesc("xyz");
		testSearchResult.setSupplierNm("xyz");
		PerishableSKUSearchResults testSearchResult1=new PerishableSKUSearchResults();
		testSearchResult1.setDeptName("abc");
		testSearchResult1.setHierarchyLevelOne("abc");
		testSearchResult1.setHierarchyLevelTwo("abc");
		testSearchResult1.setHierarchyLevelThree("abc");
		testSearchResult1.setSupplierNam("abc");
		testSearchResult1.setSku("abc");
		testSearchResult1.setItemDesc("abc");
		testSearchResult1.setSupplierNm("abc");
		List<PerishableSKUSearchResults> skuSearchResults=new ArrayList<>();
		skuSearchResults.add(testSearchResult);
		skuSearchResults.add(testSearchResult1);
		perishableSearchRequestVO.setSkuSearchResults(skuSearchResults);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.PLU_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(" ");
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.WHSE_DSD);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("DISP");
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("TOTAL_SALES");
		PerishableSearchRequestVO res = perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		assertEquals("companyID",res.getCompanyID());
	}

	@Test
	public void listSKUPerishableItemsSortingItemsNotD() throws Exception {
		String[] sortItems=new String[8];
		sortItems[0]="DEPT";
		sortItems[1]="HIER1";
		sortItems[2]="HIER2";
		sortItems[3]="HIER3";
		sortItems[4]="SUPPL";
		sortItems[5]="PSKU";
		sortItems[6]="ITDS";
		sortItems[7]="LKPSUPNO";
		perishableSearchRequestVO.setSortItems(sortItems);
		perishableSearchRequestVO.setSortOrder("A");
		PerishableSKUSearchResults testSearchResult=new PerishableSKUSearchResults();
		testSearchResult.setDeptName("xyz");
		testSearchResult.setHierarchyLevelOne("xyz");
		testSearchResult.setHierarchyLevelTwo("xyz");
		testSearchResult.setHierarchyLevelThree("xyz");
		testSearchResult.setSupplierNam("xyz");
		testSearchResult.setSku("xyz");
		testSearchResult.setItemDesc("xyz");
		testSearchResult.setSupplierNm("xyz");
		PerishableSKUSearchResults testSearchResult1=new PerishableSKUSearchResults();
		testSearchResult1.setDeptName("abc");
		testSearchResult1.setHierarchyLevelOne("abc");
		testSearchResult1.setHierarchyLevelTwo("abc");
		testSearchResult1.setHierarchyLevelThree("abc");
		testSearchResult1.setSupplierNam("abc");
		testSearchResult1.setSku("abc");
		testSearchResult1.setItemDesc("abc");
		testSearchResult1.setSupplierNm("abc");
		List<PerishableSKUSearchResults> skuSearchResults=new ArrayList<>();
		skuSearchResults.add(testSearchResult);
		skuSearchResults.add(testSearchResult1);
		perishableSearchRequestVO.setSkuSearchResults(skuSearchResults);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.PLU_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(" ");
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.WHSE_DSD);
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("DISP");
		perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("TOTAL_SALES");
		PerishableSearchRequestVO res = perishableMappingServicesImpl.listSKUPerishableItems(perishableSearchRequestVO);
		assertEquals("companyID",res.getCompanyID());
	}

	@Test
	public void listCICPerishableItems() throws Exception {
		perishableSearchRequestVO.setSearchCriteria("CIC_VAL");
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("ITEM_USAGE");
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("DISPLAY");
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("SMIC");
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.PLU_VAL);
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.WHSE_DSD);
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria("DISP");
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		PerishableSearchRequestVO res = perishableMappingServicesImpl.listCICPerishableItems(perishableSearchRequestVO);
		assertEquals("companyID",res.getCompanyID());
	}

	@Test
	public void performAction() {
		PerishableMappingRequestWrapper perishableMappingResultWrapper = new PerishableMappingRequestWrapper();
		perishableMappingResultWrapper.setMappingrequest(perishableMappingRequests);
		perishableMappingResultWrapper.setFromMappedScreen(true);
		perishableMappingRequests.get(0).setTargetEdited(true);
		perishableMappingServicesImpl.performAction(perishableMappingResultWrapper);
		perishableMappingResultWrapper.setFromMappedScreen(false);
		perishableMappingRequests.get(0).setMappingType("NEW");
		perishableMappingServicesImpl.performAction(perishableMappingResultWrapper);
		perishableMappingRequests.get(0).setMappingType(PerishableConstants.RESERVED);
		perishableMappingServicesImpl.performAction(perishableMappingResultWrapper);
		perishableMappingRequests.get(0).setMappingstatus("mappingstatus");
		when(itemConvManualMatchingPlanRepository
				.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndItemConvManualMatchingPlanPkMatchedItemTypeCdAndMappingTypeAndMappingStatus(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any())).thenReturn(new ItemConvManualMatchingPlan());
		perishableMappingServicesImpl.performAction(perishableMappingResultWrapper);
		assertTrue(true);
	}
	

	@Test
	public void duplicateCheckOnMappedItems() {
		boolean res = perishableMappingServicesImpl.duplicateCheckOnMappedItems(perishableMappingRequests);
		assertFalse(res);
	}

	@Test
	public void saveForceNewInPerishableMapping() {
		String res = perishableMappingServicesImpl.saveForceNewInPerishableMapping(perishableMappingRequests);
		assertEquals("Successfully inserted" , res);
	}

	@Test
	public void createNewCic() {
		PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto = new PerishableItemCreateMatchCicDto();
		perishableItemCreateMatchCicDto.setCost(new BigDecimal(1));
		List<DisplayItemSourceUPC> displayItemSourceUPCs = new ArrayList<DisplayItemSourceUPC>();
		DisplayItemSourceUPC displayItemSourceUPC = new DisplayItemSourceUPC();
		displayItemSourceUPC.setUpc("              upc                         ");
		displayItemSourceUPCs.add(displayItemSourceUPC);
		perishableItemCreateMatchCicDto.setSourceComponentUpc(displayItemSourceUPCs);
		List<ItemAggregateCorp> list = new ArrayList<>();
		ItemAggregateCorp aggregateCorp = new ItemAggregateCorp();
		list.add(aggregateCorp);
		aggregateCorp.setSrcByDsd("Y");
		aggregateCorp.setSrcByWhse("Y");
		aggregateCorp.setBatchId(new BigDecimal(1));
		aggregateCorp.setMaterialItemInd('y');
		aggregateCorp.setExpenseItemInd('N');
		when(itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(list);
		perishableMappingServicesImpl.createNewCic(perishableItemCreateMatchCicDto, "A");
		aggregateCorp.setMaterialItemInd('N');
		aggregateCorp.setExpenseItemInd('Y');
		perishableMappingServicesImpl.createNewCic(perishableItemCreateMatchCicDto, "O");
		aggregateCorp.setMaterialItemInd('N');
		aggregateCorp.setExpenseItemInd('N');
		assertTrue(true);
	}

	@Test
	public void listMappedData() {
		perishableSearchRequestVO.setSearchIndicator(PerishableConstants.SOURCE_INDICATOR);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DSD);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.WHSE);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DISP);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchIndicator(PerishableConstants.TARGET_INDICATOR);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DSD);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.DISP);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		perishableSearchRequestVO.setSearchCriteria(PerishableConstants.CIC_VAL);
		List<PerishableMappedResultWrapper>list = perishableMappingServicesImpl.listMappedData(perishableSearchRequestVO);
		assertEquals(0,list.size());
	}

	@Test
	public void updateForceNewInPerishableMapping() {
		String res = perishableMappingServicesImpl.updateForceNewInPerishableMapping(perishableMappingRequest);
		assertEquals("updation failed",res);
	}

	@Test
	public void getSouceDepartmentDetails() {
		perishableMappingServicesImpl.getSouceDepartmentDetails("company", "division");
		assertTrue(true);
	}

	@Test
	public void getTargetDepartmentDetails() {
		perishableMappingServicesImpl.getTargetDepartmentDetails("company", "division");
		assertTrue(true);
	}

	@Test
	public void getUpcListDetails() {
		List<Object[]> objects = Collections
				.singletonList(new Object[] { "", new BigDecimal(1), new Timestamp(11111l) });
		when(perishableSQLRepository.getUpcListDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(objects);
		perishableMappingServicesImpl.getUpcListDetails(new Object[] { "", "", "", "", "" });
		assertTrue(true);
	}

	@Test
	public void checkMatchingUPCInTarget() {
		PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto = new PerishableItemCreateMatchCicDto();
		List<DisplayItemSourceUPC> sourceComponentUpc = new ArrayList<>();
		DisplayItemSourceUPC displayItemSourceUPC = new DisplayItemSourceUPC();
		displayItemSourceUPC.setUpc("123456789101112");
		sourceComponentUpc.add(displayItemSourceUPC);
		perishableItemCreateMatchCicDto.setSourceComponentUpc(sourceComponentUpc);
		perishableMappingServicesImpl.checkMatchingUPCInTarget(perishableItemCreateMatchCicDto);
		assertTrue(true);
	}

	@Test
	public void getSuggestedTargetList() {
		PerishableMatchingTargetInputVO perishableMatchingTargetInputVO = new PerishableMatchingTargetInputVO();
		when(perishableAdditonalSQLRepository.loadCICSuggestions(Mockito.any()))
				.thenReturn(Collections.singletonList(new Object[] { "" }));
		when(perishableAdditonalSQLRepository.fetchMatchingCICdetails(Mockito.anyList())).thenReturn(
				Collections.singletonList(new Object[] { new BigDecimal(1), "", new BigDecimal(1), new BigDecimal(1),
						"", 'C', null, new BigDecimal(1), 'A', "", "", "", "", 'A', "", "", "", "" }));
		perishableMappingServicesImpl.getSuggestedTargetList(perishableMatchingTargetInputVO);
		assertTrue(true);
	}

	@Test
	public void getadditionalRetailscanDetails() {
		Map<String, Object> map = new HashedMap<>();
		map.put("RETAIL_SCAN_DETAIL", Collections.singletonList(new Object[] { "", new BigDecimal(1), 'A', "", "" }));
		when(perishableAdditonalSQLRepository.fetchAdditonalRetailScandetails(Mockito.anyString())).thenReturn(map);
		perishableMappingServicesImpl.getadditionalRetailscanDetails("corpItemCd");
		assertTrue(true);
	}

	@Test
	public void getMappedUpcListDetails() {
		perishableMappingServicesImpl.getMappedUpcListDetails(new Object[] { "", "", "", "", "", "" });
		assertTrue(true);
	}

	@Test
	public void changeExpenseType() {
		List<ManualExpeseTypeChangeRequest> changeRequests = new ArrayList<>();
		ManualExpeseTypeChangeRequest manualExpeseTypeChangeRequest = new ManualExpeseTypeChangeRequest();
		changeRequests.add(manualExpeseTypeChangeRequest);
		boolean res = perishableMappingServicesImpl.changeExpenseType(changeRequests);
		assertFalse(res);
	}

	@Test
	public void fetchTargetEditITems() {
		List<Object> list = new ArrayList<>();
		list.add(Collections.singletonList(new Object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }));
		list.add(Collections.singletonList(new Object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }));
		list.add(Collections.singletonList(new Object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }));
		list.add(Collections.singletonList(new Object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }));
		when(perishableAdditonalSQLRepository.loadTargetFieldsForMapEdit(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(list);
		ManualMatchAdtnlFieldLoadInputVo inputVo = new ManualMatchAdtnlFieldLoadInputVo();
		inputVo.setBuyingCic("buyingCic");
		inputVo.setCompanyId("companyId");
		inputVo.setDivisionId("divisionId");
		inputVo.setProductSKUs(new String[] { "" });
		perishableMappingServicesImpl.fetchTargetEditITems(inputVo);
		assertTrue(true);
	}
	
	@Test
	public void testperformMarkAsDeadAction() throws Exception{
		when(perishableSQLRepository.checkMarkAsDead(Mockito.any())).thenReturn(false);
		PerishableMappingRequest request = new PerishableMappingRequest();
		request.setUpc("0000000000000000000000000");
		Method method = perishableMappingServicesImpl.getClass().getDeclaredMethod("performMarkAsDeadAction", PerishableMappingRequest.class);
		method.setAccessible(true);
		method.invoke(perishableMappingServicesImpl, request);
		assertTrue(true);
	}

}