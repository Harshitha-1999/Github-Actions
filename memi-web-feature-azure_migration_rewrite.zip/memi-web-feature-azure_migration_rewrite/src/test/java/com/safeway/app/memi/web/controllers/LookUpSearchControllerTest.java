package com.safeway.app.memi.web.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;

import javax.servlet.ServletContext;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.LookUpActionWrapper;
import com.safeway.app.memi.domain.dtos.response.LookUpCustomizationVO;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchInputs;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultWrapper;
import com.safeway.app.memi.domain.services.LookUpService;
import com.safeway.app.memi.domain.util.LookUpExcelWriter;

@WebMvcTest(controllers = LookUpSearchController.class)
public class LookUpSearchControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private LookUpService lookUpService;
	@MockBean
	private LookUpExcelWriter excelWriter;
	@MockBean
	ServletContext context;

	@Test
	public void testLoadLookUpScreen() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/lookUp/loadScreen/company/division/userId")
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testsaveCustomizedColumns() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/lookUp/saveColumnCustomization")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new LookUpCustomizationVO())))
				.andExpect(status().isOk());
	}

	@Test
	public void testloadSearchResults() throws Exception {
		LookUpSearchInputs inputs = new LookUpSearchInputs();
		mockMvc.perform(MockMvcRequestBuilders.post("/lookUp/loadSearchData")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(new ObjectMapper().writeValueAsString(inputs)))
				.andExpect(status().isOk());
		inputs.setCompanyId("divisionId");
		mockMvc.perform(MockMvcRequestBuilders.post("/lookUp/loadSearchData")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(new ObjectMapper().writeValueAsString(inputs)))
				.andExpect(status().isOk());
		inputs.setDivisionId("divisionId");
		mockMvc.perform(MockMvcRequestBuilders.post("/lookUp/loadSearchData")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(new ObjectMapper().writeValueAsString(inputs)))
				.andExpect(status().isOk());
		inputs.setProdHierarchyLvl4Cd("prodHierarchyLvl4Cd");
		mockMvc.perform(MockMvcRequestBuilders.post("/lookUp/loadSearchData")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(new ObjectMapper().writeValueAsString(inputs)))
				.andExpect(status().isOk());
	}

	@Test
	public void testlookUpStatusChange() throws Exception {
		LookUpSearchResultWrapper searchResultWrapper = new LookUpSearchResultWrapper();
		when(lookUpService.fetchLookUpResult(Mockito.any())).thenReturn(searchResultWrapper);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/lookUp/performButtonAction").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(new LookUpActionWrapper())))
				.andExpect(status().isOk());
	}

	@Test
	public void testdownloadexcelReport() throws Exception {
		LookUpSearchResultWrapper fullResultWrapper = new LookUpSearchResultWrapper();
		when(excelWriter.writeIntoExcel(Mockito.any(), Mockito.any())).thenReturn("Exceptions_SEAFOOD.xlsx");
		when(lookUpService.fetchLookUpResult(Mockito.any(LookUpSearchInputs.class))).thenReturn(fullResultWrapper);
		MockedStatic<Files> fileMock = Mockito.mockStatic(Files.class);
		fileMock.when(() -> Files.exists(Mockito.any())).thenReturn(true);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/lookUp/exportIntoExcel").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(new LookUpSearchInputs())))
				.andExpect(status().isOk());
		fileMock.close();
	}

}
