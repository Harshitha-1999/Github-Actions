package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.services.ExceptionSrcService;



@SpringBootTest(classes = ExceptionReportWritter.class)
public class ExceptionReportWritterTest {
	@MockBean
	private ExceptionSrcService exceptionService;
	@MockBean
	private CommonSQLRepository commonSQLRepo;
	@Autowired
	private ExceptionReportWritter exceptionReportWritter;

	@Test
	public void testCreateExceptionReportSheet() {
		List<Object[]> list = new ArrayList<>();
		list.add(new Object[100]);
		when(commonSQLRepo.fetchDepartmentWiseExportExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar())).thenReturn(list);
		exceptionReportWritter.createExceptionReportSheet("src/test/resources/", "department", "company", "division", 'E', 'E');
		String res = exceptionReportWritter.createExceptionReportSheet("src/test/resources/", "department", "company", "division", 'E', 'C');
		assertEquals("", res);
	}
	
	@Test
	public void testCreateExceptionReportSheetOld() {
		List<Object[]> list = new ArrayList<>();
		Object[] array = new Object[100];
		array[11] = new Double(1);
		array[12] = new Double(1);
		array[13] = new Double(1);
		array[14] = new Double(1);
		array[15] = new Double(1);
		array[53] = new BigDecimal(1);
		list.add(array);
		when(commonSQLRepo.fetchDepartmentWiseExportRecords(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		exceptionReportWritter.createExceptionReportSheetOld("src/test/resources/", "department", "company", "division");
		assertTrue(true);
	}
	
	@Test
	public void testBuildLikeItemDetailDtoListNew() {
		List<Object[]> list = new ArrayList<>();
		Object[] array = new Object[100];
		array[17] = "Y";
		array[18] = "Y";
		array[14] = 'Y';
		array[45] = "abc";
		array[46] = "abc";
		array[49] = "abc";
		array[53] = new Double(1);
		array[64] = 'A';
		array[65] = 'A';
		array[66] = 'A';
		array[67] = 'A';
		array[59] = "abc";
		array[87] = "000";
		array[88] = "000";
		array[0] = "W";
		array[1] = "N";
		list.add(array);
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[62] = new Double("0");
		array[60] = new BigDecimal("0");
		array[61] = "0";
		array[63] = new BigDecimal("1");
		array[14] = 'D';
		array[47] = "abc";
		array[48] = "abc";
		array[3] = 'D';
		array[87] = "001";
		array[88] = "000";
		array[0] = "E";
		array[1] = "Y";
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[14] = 'W';
		array[3] = 'W';
		array[87] = "000";
		array[88] = "001";
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[14] = 'D';
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[72] = 'Y';
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[72] = 'N';
		list.add(array);
		array[87] = "001";
		array[88] = "001";
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[87] = "001";
		array[88] = "000";
		exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		array[87] = "000";
		array[88] = "000";
		List<UIExceptionSrcDto> dataVos = exceptionReportWritter.buildLikeItemDetailDtoListNew(list);
		assertEquals(1, dataVos.size());
	}
	
	@Test
	public void testBuildLikeItemDetailDtoList() {
		List<Object[]> list = new ArrayList<>();
		Object[] array = new Object[100];
		array[11] = new Double(1);
		array[12] = new Double(1);
		array[13] = new Double(1);
		array[14] = new Double(1);
		array[15] = new Double(1);
		array[16] = "ABC";
		array[19] = new BigDecimal(1);
		list.add(array);
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		List<OverrideDataVo> dataVos = exceptionReportWritter.buildLikeItemDetailDtoList(list);
		assertEquals(1, dataVos.size());
	}
	
}
 