package com.safeway.app.memi.web.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryResponseVO;
import com.safeway.app.memi.domain.dtos.response.BakerySearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.services.BakeryMappingServices;
import com.safeway.app.memi.domain.util.BakeryActionValidations;

/**
 ****************************************************************************
 * NAME : BakeryMappingActionsControllerTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Nov 17, 2021 - Initial Creation
 * *************************************************************************
 */
@WebMvcTest( controllers = BakeryMappingActionsController.class )
public class BakeryMappingActionsControllerTest {
	private static final Logger LOG = LoggerFactory.getLogger(BakeryMappingActionsControllerTest.class);

	@MockBean
	private BakeryMappingServices bakeryMappingServices;
	@MockBean
	private BakeryActionValidations bakeryActionValidations;
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testBakeryAction() throws JsonProcessingException, Exception {
		LOG.info("Testing /bakery/bakeryactions");
		BakeryMappingRequestWrapper requestWrapper = new BakeryMappingRequestWrapper();
		requestWrapper.setMappingrequestBuyer(new ArrayList<>());
		when(bakeryMappingServices.duplicateCheckOnMappedItems(Mockito.anyList())).thenReturn(Collections.singletonList(""));
		mockMvc.perform(MockMvcRequestBuilders.post("/bakery/bakeryactions")
				.content(new ObjectMapper().writeValueAsString(requestWrapper))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
	}
	@Test
	public void testBakeryAction1() throws JsonProcessingException, Exception {
		LOG.info("Testing /bakery/bakeryactions");
		BakeryMappingRequestWrapper requestWrapper = new BakeryMappingRequestWrapper();
		requestWrapper.setSourceSearchRequest(new BakerySearchRequestVO());
		List<BakeryMappingRequest> bakeryMappingRequests = new ArrayList<>(); 
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setMappingType("INHERIT_MAP");
		bakeryMappingRequests.add(bakeryMappingRequest);
		requestWrapper.setMappingrequestBuyer(bakeryMappingRequests);
		requestWrapper.setTargetBuyerSearchRequest(new BakerySearchRequestVO());
		requestWrapper.setTargetSellerSearchRequest(new BakerySearchRequestVO());
		when( bakeryMappingServices
 						.listBakerySKUItems(Mockito.any(BakerySearchRequestVO.class))).thenReturn(new BakeryResponseVO());
		when(bakeryMappingServices
 						.listBakeryCICItems(Mockito.any(BakerySearchRequestVO.class))).thenReturn(new BakeryResponseVO());
		mockMvc.perform(MockMvcRequestBuilders.post("/bakery/bakeryactions")
				.content(new ObjectMapper().writeValueAsString(requestWrapper))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
	}
	@Test
	public void testPerishableActionForceNew() throws JsonProcessingException, Exception {
		LOG.info("Testing /bakery/forcenew");
		mockMvc.perform(MockMvcRequestBuilders.post("/bakery/forcenew")
				.content(new ObjectMapper().writeValueAsString(new ArrayList<BakeryMappingRequest>()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();

	}
	@Test
	public void testCreateCic() throws JsonProcessingException, Exception {
		LOG.info("Testing /bakery/createNewCic");
		mockMvc.perform(MockMvcRequestBuilders.post("/bakery/createNewCic")
				.content(new ObjectMapper().writeValueAsString(new ArrayList<DisplayItemCreateMatchCicDto>()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();

	}
	@Test
	public void testPerishableActionForceNewUpdate() throws JsonProcessingException, Exception {
		LOG.info("Testing /bakery/forcenewupdate");
		mockMvc.perform(MockMvcRequestBuilders.post("/bakery/forcenewupdate")
				.content(new ObjectMapper().writeValueAsString(new BakeryMappingRequest()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();

	}

}
