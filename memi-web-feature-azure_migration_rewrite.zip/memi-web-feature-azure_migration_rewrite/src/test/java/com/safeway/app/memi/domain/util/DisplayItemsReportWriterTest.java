package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.repositories.DisplaySQLRepository;

@SpringBootTest(classes = DisplayItemsReportWriter.class)
public class DisplayItemsReportWriterTest {
	@Autowired
	private DisplayItemsReportWriter displayItemsReportWriter;
	@MockBean
	private DisplaySQLRepository displayerSQLRepo;

	@Test
	public void testCreateDisplayItemReportSheet() {
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] array = new Object[20];
		array[16] = "Y";
		array[17] = "Y";
		list.add(array);
		when(displayerSQLRepo.fetchDeptWiseDisplayItemForExport(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyChar())).thenReturn(list);
		String res = displayItemsReportWriter.createDisplayItemReportSheet("src/test/resources", "department", "company",
				"division", "deptName", 's');
		assertEquals("deptName", res);
	}
	
	@Test
	public void testCreateDisplayItemExceptionReportSheet() {
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] array = new Object[20];
		array[16] = "Y";
		list.add(array);
		when(displayerSQLRepo.fetchDeptWiseDisplayComponentExceptionListExport(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(list);
		String  res = displayItemsReportWriter.createDisplayItemExceptionReportSheet("src/test/resources", "department", "company",
				"division", "deptName", "whseDSD");
		assertEquals("deptName", res);
	}
	
	@Test
	public void testgetBigDecimalValue() throws Exception{
		Method method = displayItemsReportWriter.getClass().getDeclaredMethod("getBigDecimalValue", Object.class);
		method.setAccessible(true);
		Object obj = method.invoke(displayItemsReportWriter, new Double(1));
		assertEquals(BigDecimal.valueOf(new Double(1)), new BigDecimal(obj.toString()));
	}
}
