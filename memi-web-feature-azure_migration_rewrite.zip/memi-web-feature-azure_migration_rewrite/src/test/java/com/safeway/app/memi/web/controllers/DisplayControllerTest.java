package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;
import com.safeway.app.memi.domain.dtos.response.UndoCreateNewCicDto;
import com.safeway.app.memi.domain.services.DisplayService;
import com.safeway.app.memi.domain.util.DisplayItemsReportWriter;

@WebMvcTest(controllers = DisplayController.class)
public class DisplayControllerTest {

	@MockBean
	private DisplayService dispayItemService;
	@MockBean
	private DisplayItemsReportWriter displayReportWritter;

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testGetDisplayItemList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/dsply/listDisplayerData/company/division"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetDepartmentwiseItemList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/dsply/loadDeptWiseDisplayItem/company/division/department/A/S/T"))
				.andExpect(status().isOk());
	}

	@Test
	public void testMarkDisplay() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/markDisplay").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testUnMarkDisplay() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/unMarkDisplay").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testMarkDead() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/markDead").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnItemDesc() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders.post("/dsply/displayersSearchOnItemDesc").contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(new ArrayList<>())))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnProductSku() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/displayersSearchOnProductSku")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnOneTimeBuyFlag() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/displayersSearchOnOneTimeBuyFlag")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetDisplayItemReportFile() throws Exception {
		MockedStatic<Files> fileMock = Mockito.mockStatic(Files.class);
		fileMock.when(() -> Files.exists(Mockito.any())).thenReturn(true);
		mockMvc.perform(
				MockMvcRequestBuilders.get("/dsply/displayersDownloadExcel/company/division/deptCod/deptName/s"))
				.andExpect(status().isOk());
		fileMock.close();
	}

	@Test
	public void testGetSourceSimsData() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders.post("/dsply/loadSourceSimsItems").contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(new DisplayItemDetail())))
				.andExpect(status().isOk());
	}

	@Test
	public void testMatchCic() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/matchToSimsCic").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testUndoDisplayersCompleted() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders.post("/dsply/undoDisplayersCompleted").contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(new UndoCreateNewCicDto())))
				.andExpect(status().isOk());
	}

	@Test
	public void testCreateCic() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/createNewCic").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testUndoCreateNewCic() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/undoCreateNewCic").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new UndoCreateNewCicDto()))).andExpect(status().isOk());
	}

	@Test
	public void testDownloadDisplayComponentExceptionFile() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders
				.get("/dsply/displayersExceptionExcelDownload/company/division/deptCode/deptName/whsedsd"))
				.andExpect(status().isOk());
	}

	@Test
	public void testUploadFileHandler() throws Exception {
		MockMultipartFile jsonFile = new MockMultipartFile("file", "file", "application/json",
				"{\"key1\": \"value1\"}".getBytes());

		mockMvc.perform(MockMvcRequestBuilders.multipart("/dsply/uploadExceptionFile").file(jsonFile)
				.contentType(MediaType.APPLICATION_JSON).param("companyId", "companyId")
				.param("divisionId", "divisionId").param("deptCode", "deptCode").param("displayType", "displayType")
				.param("userId", "userId")).andExpect(status().isOk());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnReviewedItemDesc() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/displayersSearchOnReviewedItemDesc")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnReviewedProductSku() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/displayersSearchOnReviewedProductSku")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/dsply/displayersSearchOnReviewedOneTimeBuyFlag")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

}