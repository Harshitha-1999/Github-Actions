/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.services.ExceptionSrcService;
import com.safeway.app.memi.domain.services.MasterItemService;
import com.safeway.app.memi.domain.services.NewItemDetailService;

@WebMvcTest(controllers = NewItemDetailsController.class)
public class NewItemDetailsControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private NewItemDetailService newItemDetailService;
	@MockBean
	private MasterItemService masterItemService;
	@MockBean
	private ExceptionSrcService exceptionSrcService;

	@Test
	public void testGetExceptionSrcList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/newitem/list")).andExpect(status().isOk());
	}

	@Test
	public void testSaveItemDetails() throws Exception {
		AugDataVo augDataVo = new AugDataVo();
		augDataVo.setKillProdSku(true);
		mockMvc.perform(MockMvcRequestBuilders.post("/newitem/save").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(augDataVo))).andExpect(status().isOk());
		augDataVo.setKillProdSku(false);
		augDataVo.setManualMap(true);
		mockMvc.perform(MockMvcRequestBuilders.post("/newitem/save").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(augDataVo))).andExpect(status().isOk());
		augDataVo.setKillProdSku(false);
		augDataVo.setManualMap(false);
		NewItemDetailDto newItemDetailDto = new NewItemDetailDto();
		newItemDetailDto.setPrimayUpcString("");
		newItemDetailDto.setAugOverCmplnInd('A');
		augDataVo.setNewItemDto(newItemDetailDto);
		mockMvc.perform(MockMvcRequestBuilders.post("/newitem/save").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(augDataVo))).andExpect(status().isOk());
		try {
			mockMvc.perform(MockMvcRequestBuilders.post("/newitem/save").contentType(MediaType.APPLICATION_JSON_VALUE)
					.content(new ObjectMapper().writeValueAsString(augDataVo + "abc}"))).andExpect(status().is(500));
		} catch (Exception e) {
		}
	}

	@Test
	public void testSaveOverrideItemDetails() throws Exception {
		OverrideDataVo newItemToDB = new OverrideDataVo();
		newItemToDB.setKillProdSku(true);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/newitem/override/save").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(newItemToDB)))
				.andExpect(status().isOk());
		newItemToDB.setKillProdSku(false);
		newItemToDB.setManualMap(true);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/newitem/override/save").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(newItemToDB)))
				.andExpect(status().isOk());
		newItemToDB.setKillProdSku(false);
		newItemToDB.setManualMap(false);
		newItemToDB.setMoveToManualMap(true);
		NewItemDetailDto newItemDetailDto = new NewItemDetailDto();
		newItemDetailDto.setPrimayUpcString("");
		newItemDetailDto.setAugOverCmplnInd('A');
		newItemToDB.setNewItemDto(newItemDetailDto);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/newitem/override/save").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(newItemToDB)))
				.andExpect(status().isOk());
		newItemToDB.setKillProdSku(false);
		newItemToDB.setManualMap(false);
		newItemToDB.setMoveToManualMap(false);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/newitem/override/save").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(newItemToDB)))
				.andExpect(status().isOk());
		try {
			mockMvc.perform(
					MockMvcRequestBuilders.post("/newitem/override/save").contentType(MediaType.APPLICATION_JSON_VALUE)
							.content(new ObjectMapper().writeValueAsString("{" + newItemToDB)))
					.andExpect(status().is(200));
		} catch (Exception e) {
		}
	}

	@Test
	public void testGetTargetProdClassValidate() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/newitem/targetProdValidate/prodClass/groupCode"))
				.andExpect(status().isOk());
	}
}
