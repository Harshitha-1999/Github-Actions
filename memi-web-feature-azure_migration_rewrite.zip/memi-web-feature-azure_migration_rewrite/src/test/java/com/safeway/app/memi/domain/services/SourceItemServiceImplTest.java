/* Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

/* ***************************************************************************
 * NAME : ReportServiceImplTest 
 * 
 * AUTHOR : TCS 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Nov 23, 2021 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.SourceItemCIC;
import com.safeway.app.memi.data.entities.SourceItemCICPk;
import com.safeway.app.memi.data.repositories.SourceItemRepository;
import com.safeway.app.memi.domain.dtos.response.SourceItem;
import com.safeway.app.memi.domain.services.impl.SourceItemServiceImpl;

@SpringBootTest(classes = SourceItemServiceImpl.class)
public class SourceItemServiceImplTest {

	@Autowired
	private SourceItemServiceImpl sourceItemServiceImpl;
	@MockBean
	private SourceItemRepository srcItemRepo;

	@Test
	public void getAllItems() {
		List<SourceItemCIC> srcItemList = new ArrayList<>();
		SourceItemCIC itemCIC = new SourceItemCIC();
		SourceItemCICPk itemCICPk = new SourceItemCICPk();
		itemCIC.setSourceItemCICPk(itemCICPk);
		itemCICPk.setCompanyId("companyId");
		srcItemList.add(itemCIC);
		when(srcItemRepo.findAll()).thenReturn(srcItemList);
		List<SourceItem> items = sourceItemServiceImpl.getAllItems("");
		assertEquals("companyId", items.get(0).getCompanyID());
	}

	@Test
	public void getItem() {
		assertNull(sourceItemServiceImpl.getItem(null));
	}

}
