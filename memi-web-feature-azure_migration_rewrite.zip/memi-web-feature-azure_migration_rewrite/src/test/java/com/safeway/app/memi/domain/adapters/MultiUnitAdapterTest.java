package com.safeway.app.memi.domain.adapters;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitTypeTargetDto;
import com.safeway.app.memi.domain.util.BakeryActionValidations;

@SpringBootTest(classes = BakeryActionValidations.class)
public class MultiUnitAdapterTest {

	private MultiUnitAdapter multiUnitAdapter = new MultiUnitAdapter();
	
	@Test
	public void testBuildNonMultiUnitSourceItem() {
		List<Object[]> multiUnitSrcList = new ArrayList<>();
		Object[] objects = {"99","1","2","3",new BigDecimal(4),new BigDecimal(5),"6","7","8","9","Y","Y",new BigDecimal(12),new BigDecimal(13),"14",new BigDecimal(15),"","","","19"};
		multiUnitSrcList.add(objects);
		multiUnitSrcList.add(objects);
		List<MultiUnitSourceDto> multiUnitSourceList = multiUnitAdapter.buildNonMultiUnitSourceItem(multiUnitSrcList);
		assertEquals("99", multiUnitSourceList.get(0).getCompanyId());
	}
	
	@Test
	public void testBuildMultiUnitSourceItem() {
		List<Object[]> multiUnitSrcList = new ArrayList<>();
		Object[] objects = {"99","1","2","3",new BigDecimal(4),new BigDecimal(5),"6","7",new BigDecimal(8),"9","10","11","12","13","14",new BigDecimal(15),"","","",new BigDecimal(12)};
		multiUnitSrcList.add(objects);
		multiUnitSrcList.add(objects);
		List<MultiUnitSourceDto> multiUnitSourceList = multiUnitAdapter.buildMultiUnitSourceItem(multiUnitSrcList);
		assertEquals("99", multiUnitSourceList.get(0).getCompanyId());
	}
	
	@Test
	public void buildMultiUnitTargetItem() {
		List<Object[]> multiUnitSrcList = new ArrayList<>();
		Object[] objects = {new BigDecimal(12),"",new BigDecimal(12),new BigDecimal(3),"4",new BigDecimal(5),"6","7","8",new BigDecimal(9),"10","11","12",new BigDecimal(13),"14","15","16","17",new BigDecimal(18)};
		multiUnitSrcList.add(objects);
		multiUnitSrcList.add(objects);
		List<MultiUnitTypeTargetDto> dtos = multiUnitAdapter.buildMultiUnitTargetItem(multiUnitSrcList);
		assertEquals(1, dtos.size());
	}
	
}
