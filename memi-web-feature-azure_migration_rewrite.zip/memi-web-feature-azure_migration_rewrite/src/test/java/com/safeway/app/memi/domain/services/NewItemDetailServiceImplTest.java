package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.DepartmentDetail;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.NewItemDetailPk;
import com.safeway.app.memi.data.entities.SMICDetail;
import com.safeway.app.memi.data.entities.SMICDetailPK;
import com.safeway.app.memi.data.entities.SizeUOMDetail;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.NewItemDetailRepository;
import com.safeway.app.memi.data.repositories.SMICDetailRepository;
import com.safeway.app.memi.data.repositories.SizeUOMDetailRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.services.impl.NewItemDetailServiceImpl;

@SpringBootTest(classes = NewItemDetailServiceImpl.class)
public class NewItemDetailServiceImplTest {

	@Autowired
	private NewItemDetailServiceImpl exceptionSrcServiceImpl;
	@MockBean
	private NewItemDetailRepository newItemDetailRepo;
	@MockBean
	private SMICDetailRepository smicDetailnRepo;
	@MockBean
	private SizeUOMDetailRepository sizeUOMDetailnRepo;
	@MockBean
	private UIExceptionSrcRepository exceptionRepo;
	@MockBean
	private CommonSQLRepository likeItemRepository;

	private static List<NewItemDetail> newItemDetailList;
	private static NewItemDetail newItemDetail;
	private static NewItemDetailPk newItemDetailPk;
	private static DepartmentDetail departmentDetail;
	private static AugDataVo augDataVo;
	private static AugDataVo augDataVo2;
	private static NewItemDetailDto newItemDetailDto;
	private static NewItemDetailDto newItemDetailDto2;
	private static List<UIExceptionSrc> uiExceptionSrcs;
	private static UIExceptionSrc uiExceptionSrc;
	private static UiExceptionSrcPk uiExceptionSrcPk;
	private static List<SMICDetail> smicDetails;
	private static SMICDetail sMICDetail;
	private static List<SizeUOMDetail> uomDetail;
	private static SizeUOMDetail sizeUOMDetail;
	private static OverrideDataVo overrideDataVo;
	private static List<UPCVo> upcvoList;
	private static UPCVo upcvo;
	private static SMICDetailPK sMICDetailPK;
	private static UIExceptionSrcDto uiEceptionSrcDto;

	@BeforeAll
	public static void init() {
		newItemDetailList = new ArrayList<>();
		departmentDetail = new DepartmentDetail();
		departmentDetail.setCompanyId("Safeway");
		departmentDetail.setDivisionId("IND");
		departmentDetail.setDeptCd("IT");
		newItemDetailPk = new NewItemDetailPk();
		newItemDetailPk.setCompanyId("Safeway");
		newItemDetailPk.setDivisionId("IND");
		newItemDetail = new NewItemDetail();
		newItemDetail.setCost(10.0f);
		newItemDetail.setBillingType("Monthly");
		newItemDetail.setNewItemPk(newItemDetailPk);
		newItemDetail.setDeptDtl(departmentDetail);
		newItemDetail.setPrmyUpcInd('P');
		newItemDetailList.add(newItemDetail);
		upcvoList = new ArrayList<>();
		upcvo = new UPCVo();
		upcvo.setPrimaryUPCInd('A');
		upcvo.setUpc("1000001");
		upcvoList.add(upcvo);
		newItemDetailDto = new NewItemDetailDto();
		newItemDetailDto.setBatchId(1);
		newItemDetailDto.setBuyerNum("ABS");
		newItemDetailDto.setCompanyId("Safeway");
		newItemDetailDto.setAugOverCmplnInd('Y');
		newItemDetailDto.setGrpCd(1);
		newItemDetailDto.setCtgryCd(2);
		newItemDetailDto.setClsCd(3);
		newItemDetailDto.setSbClsCd(4);
		newItemDetailDto.setSubSbClass(5);
		newItemDetailDto.setUpcCountry("A");
		newItemDetailDto.setUpcManufacturer("B");
		newItemDetailDto.setUpcMatchCount(0);
		newItemDetailDto.setUpcs(null);
		newItemDetailDto.setUpcSales("Retail");
		newItemDetailDto.setUpcSystem("2");
		newItemDetailDto.setUpdItmDesc("@$");
		newItemDetailDto.setUpdWhseItmDesc("@$");
		newItemDetailDto.setUpdRtlItmDesc("@$@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" + "@@@@@@@@@@@@@@@@@@@@@@");
		newItemDetailDto.setUpdIntenetItemDesc("@$");
		newItemDetailDto.setUpdPosDesc("@$");
		newItemDetailDto.setUpdSizeUom("uom");
		newItemDetailDto.setUpdSize("ten");
		newItemDetailDto.setUpdSizeNmbr(new BigDecimal(1));
		newItemDetailDto.setCscDsc("@$");
		newItemDetailDto.setDcPackDesc("Anything");
		newItemDetailDto.setDcSizeDsc("dcsizesc");
		newItemDetailDto.setRing("Ring");
		newItemDetailDto.setHicone("Hi");
		newItemDetailDto.setProdwght("prod");
		newItemDetailDto.setHandlingCode("handling");
		newItemDetailDto.setBuyerNum("Buyer");
		newItemDetailDto.setRandomWtCd("Random");
		newItemDetailDto.setAutoCostInv("Zero");
		newItemDetailDto.setBillingType("Recurring");
		newItemDetailDto.setFdStmp("fd");
		newItemDetailDto.setLabelSize("1");
		newItemDetailDto.setLabelNumbers("count1");
		newItemDetailDto.setSgnCount1("count1");
		newItemDetailDto.setSgnCount2("count2");
		newItemDetailDto.setSgnCount3("count3");
		newItemDetailDto.setSellByDays("ten");
		newItemDetailDto.setUseByDays("one");
		newItemDetailDto.setPullBydays("two");
		newItemDetailDto.setTareCd("Tare");
		newItemDetailDto.setUpcVoList(upcvoList);
		augDataVo = new AugDataVo();
		augDataVo.setKillProdSku(false);
		augDataVo.setManualMap(false);
		augDataVo.setMarkAsDeadReason("Reason");
		augDataVo.setNewItemDto(newItemDetailDto);
		augDataVo.setStatus(1);
		uiExceptionSrcPk = new UiExceptionSrcPk();
		uiExceptionSrcPk.setCompanyId("Safeway");
		uiExceptionSrcPk.setDivisionId("IND");
		uiExceptionSrcs = new ArrayList<>();
		uiExceptionSrc = new UIExceptionSrc();
		uiExceptionSrc.setBatchId(101);
		uiExceptionSrc.setCost(10.50f);
		uiExceptionSrc.setExcptionDesc("Safeway");
		uiExceptionSrc.setItmDesc("item1");
		uiExceptionSrc.setUiSrcPk(uiExceptionSrcPk);
		uiExceptionSrc.setPrmyUpcInd('P');
		uiExceptionSrc.setExcptnProcessdInd('C');
		uiExceptionSrc.setDeptDtl(departmentDetail);
		uiExceptionSrcs.add(uiExceptionSrc);
		sMICDetailPK = new SMICDetailPK();
		sMICDetailPK.setClsCd("clscd");
		sMICDetailPK.setCtgryCd("catogory");
		sMICDetailPK.setGrpCd("group");
		sMICDetailPK.setSbClsCd("sb");
		smicDetails = new ArrayList<>();
		sMICDetail = new SMICDetail();
		sMICDetail.setSMICDesc("Desc");
		sMICDetail.setSMICDetailPK(sMICDetailPK);
		;
		smicDetails.add(sMICDetail);
		uomDetail = new ArrayList<>();
		sizeUOMDetail = new SizeUOMDetail();
		sizeUOMDetail.setUomCode("Code");
		sizeUOMDetail.setUomCodeUS("IND");
		uomDetail.add(sizeUOMDetail);
		overrideDataVo = new OverrideDataVo();
		overrideDataVo.setKillProdSku(false);
		overrideDataVo.setNewItemDto(newItemDetailDto);
		newItemDetailDto2 = new NewItemDetailDto();
		newItemDetailDto2.setBatchId(1);
		newItemDetailDto2.setBuyerNum("ABS");
		newItemDetailDto2.setCompanyId("Safeway");
		newItemDetailDto2.setAugOverCmplnInd('N');
		newItemDetailDto2.setGrpCd(1);
		newItemDetailDto2.setCtgryCd(2);
		newItemDetailDto2.setClsCd(3);
		newItemDetailDto2.setSbClsCd(4);
		newItemDetailDto2.setSubSbClass(5);
		newItemDetailDto2.setUpcCountry("A");
		newItemDetailDto2.setUpcManufacturer("B");
		newItemDetailDto2.setUpcMatchCount(0);
		newItemDetailDto2.setUpcs(null);
		uiEceptionSrcDto = new UIExceptionSrcDto();
		uiEceptionSrcDto.setBtId(1);
		uiEceptionSrcDto.setDivisionId("Division");
		uiEceptionSrcDto.setCompanyId("Company");
		uiEceptionSrcDto.setProductSKU("SKU");
		uiEceptionSrcDto.setExcptnProInd('E');
		augDataVo2 = new AugDataVo();
		augDataVo2.setStatus(1);
		augDataVo2.setKillProdSku(false);
		augDataVo2.setManualMap(false);
		augDataVo2.setMarkAsDeadReason("Reason");
		augDataVo2.setNewItemDto(newItemDetailDto2);
		augDataVo2.setUiEceptionSrcDto(uiEceptionSrcDto);

	}

	@Test
	public void testGetAllItems() throws Exception {
		when(newItemDetailRepo.findAll()).thenReturn(newItemDetailList);
		List<NewItemDetailDto> result = exceptionSrcServiceImpl.getAllItems();
		assertEquals("IND", result.get(0).getDivisionId());
		assertEquals("Safeway", result.get(0).getCompanyId());
	}

	@Test
	public void testFindByCompanyIdAndDivisionIdAndExcptnTypeCd() throws Exception {
		when(newItemDetailRepo.findByNewItemPkCompanyIdAndNewItemPkDivisionIdAndExcptnTypeCd(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(newItemDetailList);
		List<NewItemDetailDto> result = exceptionSrcServiceImpl.findByCompanyIdAndDivisionIdAndExcptnTypeCd("deptName",
				"deptCode", "A");
		assertEquals("IND", result.get(0).getDivisionId());
		assertEquals("Safeway", result.get(0).getCompanyId());
	}

	@Test
	public void testFindbyReviewItem() throws Exception {
		when(newItemDetailRepo.findByNewItemPkDivisionIdAndNewItemPkCompanyIdAndAugOverCmplnInd(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyChar())).thenReturn(newItemDetailList);
		List<NewItemDetailDto> result = exceptionSrcServiceImpl.findbyReviewItem("deptName", "deptCode");
		assertEquals("IND", result.get(0).getDivisionId());
		assertEquals("Safeway", result.get(0).getCompanyId());
	}

	@Test
	public void testSaveItem() throws Exception {
		NewItemDetailServiceImpl mock = mock(NewItemDetailServiceImpl.class);
		when(exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
						Mockito.anyChar())).thenReturn(uiExceptionSrcs);
		when(smicDetailnRepo
				.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
								.thenReturn(smicDetails);
		when(sizeUOMDetailnRepo.findByUomCode(Mockito.any())).thenReturn(uomDetail);
		mock.saveItem(augDataVo);
		exceptionSrcServiceImpl.saveItem(augDataVo);
		verify(mock).saveItem(augDataVo);
	}

	@Test
	public void testSaveItemsTwo() throws Exception {
		NewItemDetailServiceImpl mock = mock(NewItemDetailServiceImpl.class);
		when(smicDetailnRepo
				.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString())).thenReturn(smicDetails);
		when(exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
						Mockito.anyChar())).thenReturn(uiExceptionSrcs);
		when(exceptionRepo.save(Mockito.any())).thenReturn(uiExceptionSrc);
		mock.saveItem(overrideDataVo);
		exceptionSrcServiceImpl.saveItem(overrideDataVo);
		verify(mock).saveItem(overrideDataVo);
	}

	@Test
	public void testSaveItemsElse() throws Exception {
		NewItemDetailServiceImpl mock = mock(NewItemDetailServiceImpl.class);
		when(exceptionRepo
				.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
						Mockito.anyChar())).thenReturn(uiExceptionSrcs);
		when(smicDetailnRepo
				.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
								.thenReturn(smicDetails);
		when(sizeUOMDetailnRepo.findByUomCode(Mockito.any())).thenReturn(uomDetail);
		mock.saveItem(augDataVo2);
		exceptionSrcServiceImpl.saveItem(augDataVo2);
		verify(mock).saveItem(augDataVo2);
	}
}