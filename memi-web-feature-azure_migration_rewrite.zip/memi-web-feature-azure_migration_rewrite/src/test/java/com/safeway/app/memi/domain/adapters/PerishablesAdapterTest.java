/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.adapters;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableSKUSearchResults;
import com.safeway.app.memi.domain.util.BakeryActionValidations;

/**
 ****************************************************************************
 * NAME : PerishablesAdapterTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Dec 10, 2021 - Initial Creation
 * *************************************************************************
 */

@SpringBootTest(classes = BakeryActionValidations.class)
public class PerishablesAdapterTest {

	private PerishablesAdapter perishablesAdapter = new PerishablesAdapter();

	@Test
	public void testMapSourceItem() {
		Object[] skuObj = new Object[50];
		List<Object[]> perishableSKUSearchResults = Collections.singletonList(skuObj);
		skuObj[26] = "E";
		skuObj[27] = "Y";
		List<PerishableSKUSearchResults> skuSearchResults = perishablesAdapter
				.mapSourceItem(perishableSKUSearchResults);
		skuObj[3] = "00";
		skuObj[0] = "sku";
		skuObj[1] = "Upc";
		skuObj[2] = "Upc";
		skuObj[4] = "Upc";
		skuObj[5] = "Upc";
		skuObj[6] = "Upc";
		skuObj[7] = "Upc";
		skuObj[8] = new BigDecimal(1);
		skuObj[9] = "Mapped";
		skuObj[10] = new BigDecimal(1);
		skuObj[11] = new Timestamp(100000l);
		skuObj[12] = new BigDecimal(1);
		skuObj[13] = 'n';
		skuObj[14] = "";
		skuObj[15] = "";
		skuObj[16] = "";
		skuObj[17] = new Timestamp(100000l);
		skuObj[18] = new Double(1);
		skuObj[19] = new Double(1);
		skuObj[20] = "";
		skuObj[21] = "";
		skuObj[22] = "";
		skuObj[23] = "";
		skuObj[24] = "";
		skuObj[25] = "";
		skuObj[26] = "W";
		skuObj[27] = "N";
		skuSearchResults = perishablesAdapter.mapSourceItem(perishableSKUSearchResults);
		assertEquals("sku", skuSearchResults.get(0).getSku());
	}

	@Test
	public void testMapTargetItem() {
		Object[] cicObj = new Object[50];
		List<Object[]> perishableCICSearchResults = Collections.singletonList(cicObj);
		cicObj[13] = "product";
		cicObj[16] = "VENDOR";
		cicObj[7] = new BigDecimal(1);
		List<PerishableCICSearchResults> cicSearchResults = perishablesAdapter
				.mapTargetItem(perishableCICSearchResults);
		cicObj[0] = new BigDecimal(1);
		cicObj[1] = "";
		cicObj[2] = new BigDecimal(1);
		cicObj[3] = new BigDecimal(1);
		cicObj[4] = "";
		cicObj[5] = 'a';
		cicObj[6] = "Upc";
		cicObj[7] = "PLU";
		cicObj[8] = 'a';
		cicObj[9] = 'a';
		cicObj[11] = "";
		cicObj[12] = "Mapped";
		cicObj[13] = "productsource";
		cicObj[14] = 'a';
		cicObj[15] = 'a';
		cicObj[16] = "VENDOR_DETAIL";
		cicObj[17] = "";
		cicObj[18] = "";
		cicObj[19] = "";
		cicSearchResults = perishablesAdapter.mapTargetItem(perishableCICSearchResults);
		assertEquals(new BigDecimal(1), cicSearchResults.get(0).getCic());
	}

	@Test
	public void setMappedItems() {
		Object[] mappedObj = new Object[50];
		List<Object[]> mappedItems = Collections.singletonList(mappedObj);
		List<PerishableMappedResultWrapper> mappedResultWrappers = perishablesAdapter.setMappedItems(mappedItems);
		mappedObj[0] = "";
		mappedObj[1] = "";
		mappedObj[2] = new BigDecimal(1);
		mappedObj[3] = new BigDecimal(1);
		mappedObj[4] = new BigDecimal(1);
		mappedObj[5] = 'a';
		mappedObj[6] = "00";
		mappedObj[7] = new Date(10l);
		mappedObj[8] = new Date(10l);
		mappedObj[9] = new Date(10l);
		mappedObj[10] = 'a';
		mappedObj[11] = new BigDecimal(1);
		mappedObj[12] = "a";
		mappedObj[13] = new BigDecimal(1);
		mappedObj[14] = new BigDecimal(1);
		mappedObj[15] = new BigDecimal(1);
		mappedObj[16] = 'a';
		mappedObj[17] = 'a';
		mappedObj[18] = new Timestamp(1000l);
		mappedObj[19] = "";
		mappedObj[20] = "";
		mappedObj[21] = "";
		mappedResultWrappers = perishablesAdapter.setMappedItems(mappedItems);
		assertEquals(new BigDecimal(1), mappedResultWrappers.get(0).getTarget().getTargetCIC());
	}
}
