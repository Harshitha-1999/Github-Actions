package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.memi.domain.services.ProductionCodeService;

@WebMvcTest(controllers = ProductionCodeDetailController.class)
public class ProductionCodeDetailControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private ProductionCodeService productionCodeService;

	@Test
	public void testGetSmicDetails() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/prdctnCd/detail/grpCd/ctgryCd/clsCd/sbClsCd/subSbClass"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetGroupCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/prdctnCd/prdctnCdDetail")).andExpect(status().isOk());
	}

	@Test
	public void testGetCategoryCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/prdctnCd/prdctnCdDetail/prdctnGrpCd")).andExpect(status().isOk());
	}

	@Test
	public void testGetClassCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/prdctnCd/prdctnCdDetail/prdctnGrpCd/prdctnCtgryCd"))
				.andExpect(status().isOk());
	}
}
