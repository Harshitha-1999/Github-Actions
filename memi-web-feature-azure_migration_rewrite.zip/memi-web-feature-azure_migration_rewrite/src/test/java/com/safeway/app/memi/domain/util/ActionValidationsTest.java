package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequest;

@SpringBootTest(classes = ActionValidations.class)
public class ActionValidationsTest {
	private static final Logger LOG = LoggerFactory.getLogger(ActionValidationsTest.class);
	@Autowired
	private ActionValidations actionValidations;
    private static List<PerishableMappingRequest> perishableMappingRequestList;
    
    @BeforeAll
    public static void init() {
    	perishableMappingRequestList = new ArrayList<>();
    	PerishableMappingRequest perishableMappingRequest = new PerishableMappingRequest();
    	perishableMappingRequestList.add(perishableMappingRequest);
    	perishableMappingRequest.setMappingType(PerishableConstants.ADD_MAP);
    	perishableMappingRequest.setUpc("");
    	perishableMappingRequest.setTargetPLU("");
    	perishableMappingRequest.setTargetEdited(true);
    }
	@Test
	public void testValidateActions1() {
		LOG.info("testing validate Actions method");
		perishableMappingRequestList.get(0).setMappingType(PerishableConstants.LET_AUTO_MATCH);
		PerishableMappingRequest perishableMappingRequest = new PerishableMappingRequest();
    	perishableMappingRequestList.add(perishableMappingRequest);
    	perishableMappingRequest.setMappingType(PerishableConstants.LET_AUTO_MATCH);
    	perishableMappingRequest.setUpc("");
    	perishableMappingRequest.setTargetPLU("");
    	perishableMappingRequest.setTargetEdited(true);
		List<String> list = actionValidations.validateActions(perishableMappingRequestList);
		assertEquals(0, list.size());
	}
	@Test
	public void testValidateActions2() {
		LOG.info("testing validate Actions method");
		LOG.info("testing validate Actions method");
		PerishableMappingRequest perishableMappingRequest = perishableMappingRequestList.get(0);
		perishableMappingRequest.setDcPackDesc("DcPackDesc");
		perishableMappingRequest.setDcSizeDsc("getDcSizeDsc");
		perishableMappingRequest.setRetailUnitPack("Retail");
		perishableMappingRequest.setRing("");
		perishableMappingRequest.setHicone("");
		perishableMappingRequest.setProdwght("");
		perishableMappingRequest.setHandlingCode("");
		perishableMappingRequest.setBuyerNum("");
		perishableMappingRequest.setRandomWtCd("012");
		perishableMappingRequest.setAutoCostInv("");
		perishableMappingRequest.setBillingType("B");
		perishableMappingRequest.setFdStmp("");
		perishableMappingRequest.setTareCd("");
		perishableMappingRequest.setLabelSize("");
		perishableMappingRequest.setLabelNumbers("");
		perishableMappingRequest.setSgnCount1("");
		perishableMappingRequest.setSgnCount2("");
		perishableMappingRequest.setSgnCount3("");
		perishableMappingRequest.setPrcTypeCd("");
		perishableMappingRequest.setCostAllow("");
		perishableMappingRequest.setCostInv("");
		perishableMappingRequest.setCostIb("");
		perishableMappingRequest.setCostVend("");
		perishableMappingRequest.setSellByDays("");
		perishableMappingRequest.setUseByDays("");
		perishableMappingRequest.setPullBydays("");
    	perishableMappingRequest.setTargetPLU("12");
		List<String> list = actionValidations.validateActions(perishableMappingRequestList);
		assertEquals("DC Pack desc maximum three characters allowed", list.get(0));
		PerishableMappingRequest perishableMappingRequest1 = new PerishableMappingRequest(); 
		perishableMappingRequest.setMappingType(PerishableConstants.LET_AUTO_MATCH);
		perishableMappingRequest1.setMappingType(PerishableConstants.INHERIT_MAP);
	    perishableMappingRequest1.setDcPackDesc("DcPackDesc");
		perishableMappingRequest1.setDcSizeDsc("getDcSizeDsc");
		perishableMappingRequest1.setRetailUnitPack("Retail");
		perishableMappingRequest1.setRing("");
		perishableMappingRequest1.setHicone("");
		perishableMappingRequest1.setProdwght("");
		perishableMappingRequest1.setHandlingCode("");
		perishableMappingRequest1.setBuyerNum("");
		perishableMappingRequest1.setRandomWtCd("");
		perishableMappingRequest1.setAutoCostInv("");
		perishableMappingRequest1.setBillingType("B");
		perishableMappingRequest1.setFdStmp("");
		perishableMappingRequest1.setTareCd("");
		perishableMappingRequest1.setLabelSize("");
		perishableMappingRequest1.setLabelNumbers("");
		perishableMappingRequest1.setSgnCount1("");
		perishableMappingRequest1.setSgnCount2("");
		perishableMappingRequest1.setSgnCount3("");
		perishableMappingRequest1.setPrcTypeCd("");
		perishableMappingRequest1.setCostAllow("");
		perishableMappingRequest1.setCostInv("");
		perishableMappingRequest1.setCostIb("");
		perishableMappingRequest1.setCostVend("");
		perishableMappingRequest1.setSellByDays("");
		perishableMappingRequest1.setUseByDays("");
		perishableMappingRequest1.setPullBydays("");
		perishableMappingRequestList.add(perishableMappingRequest1);
		actionValidations.validateActions(perishableMappingRequestList);
		perishableMappingRequest1.setCic("cic");
		perishableMappingRequest1.setMappingType(PerishableConstants.MARK_AS_DEAD);
		actionValidations.validateActions(perishableMappingRequestList);
		perishableMappingRequest1.setMappingType(PerishableConstants.RESERVED);
		perishableMappingRequest1.setMappingstatus(PerishableConstants.AWAITING_DIVISION);
		actionValidations.validateActions(perishableMappingRequestList);
	}
	@Test
	public void testValidateUnmapActions() {
		LOG.info("testing validate Unmap Actions method");
		List<String> list = actionValidations.validateUnmapActions(perishableMappingRequestList);
		assertEquals("Please avoid items which is marked as automatch and mark as dead ...!",list.get(0));
	}

}
