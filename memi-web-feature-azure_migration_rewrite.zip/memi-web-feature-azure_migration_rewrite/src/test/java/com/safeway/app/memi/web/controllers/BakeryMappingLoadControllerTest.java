/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.web.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakerySearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableItemTypeVO;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.services.BakeryMappingServices;

/**
 ****************************************************************************
 * NAME : BakeryMappingLoadControllerTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 November 22, 2021 - Initial Creation
 * *************************************************************************
 */

@WebMvcTest(controllers = BakeryMappingLoadController.class)
public class BakeryMappingLoadControllerTest {

	@MockBean
	private BakeryMappingServices bakeryMappingServices;
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testListBakerySourceData() throws Exception {
		BakerySearchRequestVO bakerySearchRequestVO = new BakerySearchRequestVO();
		bakerySearchRequestVO.setCompanyID("");
		bakerySearchRequestVO.setDivisionID("");
		PerishableItemTypeVO itemType = new PerishableItemTypeVO();
		bakerySearchRequestVO.setItemType(itemType);
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/bakerySourceList")
				.content(new ObjectMapper().writeValueAsString(bakerySearchRequestVO))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
		itemType.setSystem4(true);
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/bakerySourceList")
				.content(new ObjectMapper().writeValueAsString(bakerySearchRequestVO))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
	}

	@Test
	public void testListBakerySourceData1() throws Exception {
		BakerySearchRequestVO bakerySearchRequestVO = new BakerySearchRequestVO();
		bakerySearchRequestVO.setCompanyID(null);
		bakerySearchRequestVO.setDivisionID("");
		PerishableItemTypeVO itemType = new PerishableItemTypeVO();
		itemType.setPlu(true);
		itemType.setSystem2(true);
		bakerySearchRequestVO.setItemType(itemType);
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/bakerySourceList")
				.content(new ObjectMapper().writeValueAsString(bakerySearchRequestVO))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
	}

	@Test
	public void testListBakeryTargetData() throws Exception {
		BakerySearchRequestVO bakerySearchRequestVO = new BakerySearchRequestVO();
		PerishableItemTypeVO itemType = new PerishableItemTypeVO();
		bakerySearchRequestVO.setItemType(itemType);
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/bakeryTargetList")
				.content(new ObjectMapper().writeValueAsString(bakerySearchRequestVO))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();

		itemType.setPlu(true);
		itemType.setSystem2(true);

		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/bakeryTargetList")
				.content(new ObjectMapper().writeValueAsString(bakerySearchRequestVO))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
	}

	@Test
	public void testGetMatchingTargetList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/matchingBakeryTargetList")
				.content(new ObjectMapper().writeValueAsString(new PerishableMatchingTargetInputVO()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
		when(bakeryMappingServices.getSuggestedTargetList(Mockito.any(PerishableMatchingTargetInputVO.class)))
				.thenReturn(Collections.singletonList(new BakeryCICSearchResults()));
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/matchingBakeryTargetList")
				.content(new ObjectMapper().writeValueAsString(new PerishableMatchingTargetInputVO()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();
	}

	@Test
	public void testGetadditionalRetailscanDetails() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/additionalTargetRetailsScanBakeryList")
				.content(new ObjectMapper().writeValueAsString(new String("")))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();

	}

	@Test
	public void testLoadOnMapEditFields() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/mapping/loadOnMapEditFields")
				.content(new ObjectMapper().writeValueAsString(new ManualMatchAdtnlFieldLoadInputVo()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn();

	}
}