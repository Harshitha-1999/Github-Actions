package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultVOS;

@SpringBootTest(classes = LookUpExcelWriter.class)
public class LookUpExcelWriterTest {

	@Autowired
	private LookUpExcelWriter lookUpExcelWriter;

	@Test
	public void testWriteIntoExcel() {
		List<LookUpSearchResultVOS> searchResults = new ArrayList<LookUpSearchResultVOS>();
		LookUpSearchResultVOS lookUpSearchResultVOS = new LookUpSearchResultVOS();
		searchResults.add(lookUpSearchResultVOS);
		String res = lookUpExcelWriter.writeIntoExcel(searchResults, "src/test/resources");
		assertTrue(res.contains("LookUpDownLoad"));
	}

}