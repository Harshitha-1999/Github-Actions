package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.web.util.UIObjectBuilder;

@SpringBootTest(classes = BakeryActionValidations.class)
public class UIObjectBuilderTest {

	private UIObjectBuilder UiObjectBuilder = new UIObjectBuilder();

	@Test
	public void buildAugDataObject() {
		UIExceptionSrcDto exceptionSrcDto = new UIExceptionSrcDto();
		NewItemDetailDto detailDto = new NewItemDetailDto();
		detailDto.setDeptName("deptName");
		exceptionSrcDto.setDeptName("deptName");
		detailDto.setProductSKU("productSKU");
		exceptionSrcDto.setProductSKU("productSKU");
		List<UIExceptionSrcDto> exceptionList = Collections.singletonList(exceptionSrcDto);
		List<NewItemDetailDto> reviewItemList = Collections.singletonList(detailDto);
		List<UIDataVO> dataVOs = UiObjectBuilder.buildAugDataObject(exceptionList, reviewItemList);
		assertEquals("deptName",dataVOs.get(0).getDeptName());
	}
}
