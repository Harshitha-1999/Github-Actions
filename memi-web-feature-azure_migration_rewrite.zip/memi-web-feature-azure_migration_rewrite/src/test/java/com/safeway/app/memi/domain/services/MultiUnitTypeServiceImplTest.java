package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.ItemConvMultiUnitType;
import com.safeway.app.memi.data.repositories.ItemConvMultiUnitTypeRepository;
import com.safeway.app.memi.data.repositories.MultiUnitSQLRepository;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSourceTargetSearchRequest;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSrcTargetDto;
import com.safeway.app.memi.domain.dtos.response.MultiUnitTypeTargetDto;
import com.safeway.app.memi.domain.services.impl.MultiUnitTypeServiceImpl;

@SpringBootTest(classes = MultiUnitTypeServiceImpl.class)
public class MultiUnitTypeServiceImplTest {

	@Autowired
	private MultiUnitTypeServiceImpl multiUnitTypeServiceImpl;
	@MockBean
	private ItemConvMultiUnitTypeRepository multiUnitTypeRepo;
	@MockBean
	private MultiUnitSQLRepository multiunitSQLRepo;

	private static List<MultiUnitSourceDto> multiUnitSourceDtoList;
	private static List<MultiUnitTypeTargetDto> multiUnitTarget;
	private static MultiUnitSrcTargetDto multiUnitSrcTargetDto;
	private static MultiUnitSrcTargetDto multiUnitSrcTargetDtoElse;
	private static List<Object[]> listOfObject;
	private static Object[] lkpObj;
	private static List<Object[]> listOfObjectSource;
	private static Object[] lkpObjSource;
	private static MultiUnitSourceDto multiUnitSourceDto;
	private static MultiUnitTypeTargetDto multiUnitTypeTargetDto;
	private static Set<String> upcs;
	private static List<ItemConvMultiUnitType> itemConvMultiUnitTypeList;
	private static ItemConvMultiUnitType itemConvMultiUnitType;
	private static List<String> listOfStrings;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestList;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequest;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestList1;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequest1;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestList2;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequest2;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestList3;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequest3;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestListElse;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequestElse;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestListElse1;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequestElse1;
	private static List<MultiUnitSourceTargetSearchRequest> multiUnitSourceTargetSearchRequestListElse2;
	private static MultiUnitSourceTargetSearchRequest multiUnitSourceTargetSearchRequestElse2;
	private static List<Object[]> listOfObjectSourceDetail;
	private static Object[] lkpObjSourceDetail;

	@BeforeAll
	public static void init() {
		multiUnitSourceDtoList = new ArrayList<>();
		listOfObject = new ArrayList<>();
		multiUnitTarget = new ArrayList<>();
		listOfObjectSourceDetail = new ArrayList<>();
		lkpObjSourceDetail = new Object[66];
		listOfStrings = new ArrayList<>();
		listOfObjectSource = new ArrayList<>();
		lkpObjSource = new Object[66];
		upcs = new HashSet<>();
		multiUnitSrcTargetDto = new MultiUnitSrcTargetDto();
		multiUnitSrcTargetDtoElse = new MultiUnitSrcTargetDto();
		multiUnitSourceDto = new MultiUnitSourceDto();
		multiUnitTypeTargetDto = new MultiUnitTypeTargetDto();
		lkpObj = new Object[66];
		lkpObj[0] = new BigDecimal(1);
		lkpObj[1] = "A";
		lkpObj[2] = new BigDecimal(5);
		lkpObj[3] = new BigDecimal(5);
		lkpObj[4] = "upcSystem";
		lkpObj[5] = new BigDecimal(5);
		lkpObj[6] = "upcSystem";
		lkpObj[7] = "upcManufacturer";
		lkpObj[8] = "upcSystem";
		lkpObj[9] = new BigDecimal(15);
		lkpObj[10] = "ten";
		lkpObj[11] = "leven";
		lkpObj[12] = "twelve";
		lkpObj[13] = new BigDecimal(15);
		lkpObj[14] = "fourteen";
		lkpObj[15] = "sixteen";
		lkpObj[16] = "sixteen";
		lkpObj[17] = "sixteen";
		lkpObj[18] = new BigDecimal(15);
		listOfObject.add(lkpObj);
		lkpObjSource[0] = "ten";
		lkpObjSource[1] = "A";
		lkpObjSource[2] = "ten";
		lkpObjSource[3] = "ten";
		lkpObjSource[4] = new BigDecimal(1);
		lkpObjSource[5] = new BigDecimal(5);
		lkpObjSource[6] = "upcSystem";
		lkpObjSource[7] = "upcManufacturer";
		lkpObjSource[8] = new BigDecimal(15);
		lkpObjSource[9] = "ten";
		lkpObjSource[10] = "ten";
		lkpObjSource[11] = "leven";
		lkpObjSource[12] = "twelve";
		lkpObjSource[13] = "ten";
		lkpObjSource[14] = "fourteen";
		lkpObjSource[15] = new BigDecimal(15);
		lkpObjSource[16] = "sixteen";
		lkpObjSource[17] = "sixteen";
		listOfObjectSource.add(lkpObjSource);
		upcs.add("A");
		upcs.add("B");
		upcs.add("C");
		upcs.add("D");
		upcs.add("E");
		multiUnitSourceDto.setCaseUpc("Case");
		multiUnitSourceDto.setCompanyId("Safeway");
		multiUnitSourceDto.setConvProductSku("Product");
		multiUnitSourceDto.setConvStatusCode("C");
		multiUnitSourceDto.setDeptName("IT");
		multiUnitSourceDto.setDivisionId("IND");
		multiUnitSourceDto.setMarkAsDeadReason("Mark");
		multiUnitSourceDto.setSrcItemDesc("Desc");
		multiUnitSourceDto.setMatchIndicator("M");
		multiUnitSourceDto.setMaxRetail(new BigDecimal(2));
		multiUnitSourceDto.setProdSourceCd("DSD");
		multiUnitSourceDto.setProductHierarchy("Tree-Tree-Tree");
		multiUnitSourceDto.setProductSku("Sku");
		multiUnitSourceDto.setSrcCost(new BigDecimal(2));
		multiUnitSourceDto.setSrcItemDesc("Desc");
		multiUnitSourceDto.setSrcPackWhse(new BigDecimal(2));
		multiUnitSourceDto.setSrcSize("Big");
		multiUnitSourceDto.setSrcUpc("UPC");
		multiUnitSourceDto.setSrcVendConvFctr(new BigDecimal(2));
		multiUnitSourceDto.setSrcVendName("Ven Name");
		multiUnitSourceDto.setSrcVendNum(new BigDecimal(2));
		multiUnitSourceDto.setUpcs(upcs);
		multiUnitSourceDto.setUpdatedUserId("ID");
		multiUnitSourceDtoList.add(multiUnitSourceDto);
		multiUnitTypeTargetDto.setCaseUpc("Case");
		multiUnitTypeTargetDto.setCompanyId("Safeway");
		multiUnitTypeTargetDto.setCorpItemCd(new BigDecimal(10));
		multiUnitTypeTargetDto.setCorpStatus("P");
		multiUnitTypeTargetDto.setMatchIndicator("M");
		multiUnitTarget.add(multiUnitTypeTargetDto);
		multiUnitSrcTargetDto.setSrcMultiUnitFlag("Y");
		multiUnitSrcTargetDto.setMultiUnitSource(multiUnitSourceDtoList);
		multiUnitSrcTargetDto.setMultiUnitTarget(multiUnitTarget);
		multiUnitSrcTargetDtoElse.setSrcMultiUnitFlag("A");
		multiUnitSrcTargetDtoElse.setMultiUnitSource(multiUnitSourceDtoList);
		multiUnitSrcTargetDtoElse.setMultiUnitTarget(multiUnitTarget);
		multiUnitTypeTargetDto.setCompanyId("ABS");
		multiUnitTypeTargetDto.setDivisionId("Ind");
		multiUnitTypeTargetDto.setMatchIndicator("M");
		multiUnitTypeTargetDto.setUpcList(upcs);
		itemConvMultiUnitTypeList = new ArrayList<>();
		itemConvMultiUnitType = new ItemConvMultiUnitType();
		itemConvMultiUnitType.setAutoManualInd("Manual");
		itemConvMultiUnitTypeList.add(itemConvMultiUnitType);
		listOfStrings.add("A");
		listOfStrings.add("B");
		listOfStrings.add("C");
		multiUnitSourceTargetSearchRequestList = new ArrayList<>();
		multiUnitSourceTargetSearchRequest = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequest.setSrcMultiUnitFlag('N');
		multiUnitSourceTargetSearchRequest.setMatchIndicator("P");
		multiUnitSourceTargetSearchRequest.setItemDescFlag('Y');
		multiUnitSourceTargetSearchRequest.setSrcItemDesc("Desc");
		multiUnitSourceTargetSearchRequest.setVenderNameFlag('Y');
		multiUnitSourceTargetSearchRequest.setSrcVendName("VName");
		multiUnitSourceTargetSearchRequest.setHierarchyOrSmicFlag('Y');
		multiUnitSourceTargetSearchRequest.setSrcprodHierarchyLvl1Cd("1");
		multiUnitSourceTargetSearchRequest.setSrcprodHierarchyLvl2Cd("2");
		multiUnitSourceTargetSearchRequest.setSrcprodHierarchyLvl3Cd("3");
		multiUnitSourceTargetSearchRequest.setProductSKUsearchFlag('A');
		multiUnitSourceTargetSearchRequest.setProductSKUsearchFlag('Y');
		multiUnitSourceTargetSearchRequest.setSrcProductSKU("3");
		multiUnitSourceTargetSearchRequest.setTarItemDesc("'&%-");
		multiUnitSourceTargetSearchRequest.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequest.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequest.setTarVendorName("'&%-");
		multiUnitSourceTargetSearchRequest.setTarGrpCd("Grp");
		multiUnitSourceTargetSearchRequest.setTarCtgryCd("gry");
		multiUnitSourceTargetSearchRequest.setTarClsCd("CLD");
		multiUnitSourceTargetSearchRequest.setTarSbClsCd("Sub");
		multiUnitSourceTargetSearchRequest.setTarSubSbClass("Sub class");
		multiUnitSourceTargetSearchRequest.setTargetCICsearchFlag('T');
		multiUnitSourceTargetSearchRequest.setTargetCIC("CIC");
		multiUnitSourceTargetSearchRequestList.add(multiUnitSourceTargetSearchRequest);
		lkpObjSourceDetail[0] = "ten";
		lkpObjSourceDetail[1] = "A";
		lkpObjSourceDetail[2] = "ten";
		lkpObjSourceDetail[3] = "ten";
		lkpObjSourceDetail[4] = new BigDecimal(1);
		lkpObjSourceDetail[5] = new BigDecimal(5);
		lkpObjSourceDetail[6] = "upcSystem";
		lkpObjSourceDetail[7] = "upcManufacturer";
		lkpObjSourceDetail[8] = "upcManufacturer";
		lkpObjSourceDetail[9] = "ten";
		lkpObjSourceDetail[10] = "Y";
		lkpObjSourceDetail[11] = "Y";
		lkpObjSourceDetail[12] = new BigDecimal(15);
		lkpObjSourceDetail[13] = new BigDecimal(15);
		lkpObjSourceDetail[14] = "fourteen";
		lkpObjSourceDetail[15] = new BigDecimal(15);
		lkpObjSourceDetail[16] = "sixteen";
		lkpObjSourceDetail[17] = "sixteen";
		lkpObjSourceDetail[18] = "sixteen";
		lkpObjSourceDetail[19] = "112";
		listOfObjectSourceDetail.add(lkpObjSourceDetail);
		multiUnitSourceTargetSearchRequestList1 = new ArrayList<>();
		multiUnitSourceTargetSearchRequest1 = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequest1.setSrcMultiUnitFlag('N');
		multiUnitSourceTargetSearchRequest1.setMatchIndicator("P");
		multiUnitSourceTargetSearchRequest1.setVenderNameFlag('Y');
		multiUnitSourceTargetSearchRequest1.setSrcVendName("VName");
		multiUnitSourceTargetSearchRequest1.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequest1.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequest1.setItemDescFlag('q');
		multiUnitSourceTargetSearchRequest1.setSrcItemDesc("q");
		multiUnitSourceTargetSearchRequestList1.add(multiUnitSourceTargetSearchRequest1);
		multiUnitSourceTargetSearchRequestList2 = new ArrayList<>();
		multiUnitSourceTargetSearchRequest2 = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequest2.setSrcMultiUnitFlag('N');
		multiUnitSourceTargetSearchRequest2.setMatchIndicator("P");
		multiUnitSourceTargetSearchRequest2.setHierarchyOrSmicFlag('Y');
		multiUnitSourceTargetSearchRequest2.setSrcprodHierarchyLvl2Cd("VName");
		multiUnitSourceTargetSearchRequest2.setSrcprodHierarchyLvl1Cd("VName");
		multiUnitSourceTargetSearchRequest2.setSrcprodHierarchyLvl3Cd("VName");
		multiUnitSourceTargetSearchRequest2.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequest2.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequest2.setItemDescFlag('N');
		multiUnitSourceTargetSearchRequest2.setVenderNameFlag('N');
		multiUnitSourceTargetSearchRequest2.setSrcVendName("VName");
		multiUnitSourceTargetSearchRequest2.setSrcItemDesc("q");
		multiUnitSourceTargetSearchRequestList2.add(multiUnitSourceTargetSearchRequest2);
		multiUnitSourceTargetSearchRequestList3 = new ArrayList<>();
		multiUnitSourceTargetSearchRequest3 = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequest3.setSrcMultiUnitFlag('N');
		multiUnitSourceTargetSearchRequest3.setMatchIndicator("P");
		multiUnitSourceTargetSearchRequest3.setHierarchyOrSmicFlag('O');
		multiUnitSourceTargetSearchRequest3.setSrcprodHierarchyLvl2Cd("VName");
		multiUnitSourceTargetSearchRequest3.setSrcprodHierarchyLvl1Cd("VName");
		multiUnitSourceTargetSearchRequest3.setSrcprodHierarchyLvl3Cd("VName");
		multiUnitSourceTargetSearchRequest3.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequest3.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequest3.setItemDescFlag('N');
		multiUnitSourceTargetSearchRequest3.setVenderNameFlag('N');
		multiUnitSourceTargetSearchRequest3.setSrcVendName("VName");
		multiUnitSourceTargetSearchRequest3.setSrcItemDesc("q");
		multiUnitSourceTargetSearchRequest3.setHierarchyOrSmicFlag('N');
		multiUnitSourceTargetSearchRequest3.setProductSKUsearchFlag('Y');
		multiUnitSourceTargetSearchRequest3.setSrcProductSKU("VName");
		multiUnitSourceTargetSearchRequest3.setHierarchyOrSmicFlag('N');
		multiUnitSourceTargetSearchRequestList3.add(multiUnitSourceTargetSearchRequest3);
		multiUnitSourceTargetSearchRequestListElse = new ArrayList<>();
		multiUnitSourceTargetSearchRequestElse = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequestElse.setSrcMultiUnitFlag('O');
		multiUnitSourceTargetSearchRequestElse.setMatchIndicator("P");
		multiUnitSourceTargetSearchRequestElse.setItemDescFlag('Y');
		multiUnitSourceTargetSearchRequestElse.setSrcItemDesc("Y");
		multiUnitSourceTargetSearchRequestElse.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequestElse.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequestListElse.add(multiUnitSourceTargetSearchRequestElse);
		multiUnitSourceTargetSearchRequestListElse1 = new ArrayList<>();
		multiUnitSourceTargetSearchRequestElse1 = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequestElse1.setSrcMultiUnitFlag('M');
		multiUnitSourceTargetSearchRequestElse1.setMatchIndicator("V");
		multiUnitSourceTargetSearchRequestElse1.setVenderNameFlag('Y');
		multiUnitSourceTargetSearchRequestElse1.setSrcVendName("VName");
		multiUnitSourceTargetSearchRequestElse1.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequestElse1.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequestElse1.setItemDescFlag('q');
		multiUnitSourceTargetSearchRequestElse1.setSrcItemDesc("q");
		multiUnitSourceTargetSearchRequestListElse1.add(multiUnitSourceTargetSearchRequestElse1);
		multiUnitSourceTargetSearchRequestList1.add(multiUnitSourceTargetSearchRequest1);
		multiUnitSourceTargetSearchRequestListElse2 = new ArrayList<>();
		multiUnitSourceTargetSearchRequestElse2 = new MultiUnitSourceTargetSearchRequest();
		multiUnitSourceTargetSearchRequestElse2.setSrcMultiUnitFlag('M');
		multiUnitSourceTargetSearchRequestElse2.setMatchIndicator("O");
		multiUnitSourceTargetSearchRequestElse2.setHierarchyOrSmicFlag('Y');
		multiUnitSourceTargetSearchRequestElse2.setSrcprodHierarchyLvl2Cd("VName");
		multiUnitSourceTargetSearchRequestElse2.setSrcprodHierarchyLvl1Cd("VName");
		multiUnitSourceTargetSearchRequestElse2.setSrcprodHierarchyLvl3Cd("VName");
		multiUnitSourceTargetSearchRequestElse2.setCompanyId("ABS");
		multiUnitSourceTargetSearchRequestElse2.setDivisionId("Ind");
		multiUnitSourceTargetSearchRequestElse2.setItemDescFlag('N');
		multiUnitSourceTargetSearchRequestElse2.setVenderNameFlag('N');
		multiUnitSourceTargetSearchRequestElse2.setSrcVendName("VName");
		multiUnitSourceTargetSearchRequestElse2.setSrcItemDesc("q");
		multiUnitSourceTargetSearchRequestListElse2.add(multiUnitSourceTargetSearchRequestElse2);

	}

	@Test
	public void testFetchLookUpResult() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeSrcItemOnload(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSource);
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetItemOnload(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObject);
		MultiUnitSrcTargetDto result = multiUnitTypeServiceImpl.fetchMultiUnitData("Safeway", "IND", "safeway@123");
		assertNull(result.getSrcMultiUnitFlag());
	}

	@Test
	public void testGetMultiUnitTypeTargetDataList() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetBasedOnSourceSelection(Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(listOfObject);
		List<MultiUnitTypeTargetDto> result = multiUnitTypeServiceImpl
				.getMultiUnitTypeTargetDataList(multiUnitSourceDtoList);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testGetMultiUnitTypeSourceDataList() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeSourceBasedOnTargetSelection(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObjectSource);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl.getMultiUnitTypeSourceDataList(multiUnitTarget);
		assertEquals("ten", result.get(0).getCompanyId());
	}

	@Test
	public void testUpdateSourceBasedOnTarget() throws Exception {
		when(multiUnitTypeRepo.findMultiUnitTypeSrcItemByProductSkuUpcList(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyList())).thenReturn(itemConvMultiUnitTypeList);
		Map<String, String> result = multiUnitTypeServiceImpl.updateSourceBasedOnTarget(multiUnitSrcTargetDto);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testUpdateSourceBasedOnTargetElse() throws Exception {
		when(multiunitSQLRepo.findProductSkuBasedOnConvProductSku(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfStrings);
		Map<String, String> result = multiUnitTypeServiceImpl.updateSourceBasedOnTarget(multiUnitSrcTargetDtoElse);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testMarkMultiUnitItemsAsDead() throws Exception {
		int intResult = 1;
		when(multiunitSQLRepo.findProductSkuBasedOnConvProductSku(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfStrings);
		when(multiunitSQLRepo.markItemsAsDead(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(intResult);
		Map<String, List<String>> result = multiUnitTypeServiceImpl.markMultiUnitItemsAsDead(multiUnitSourceDtoList);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testMarkNotAMultiUnitItem() throws Exception {
		int intResult = 1;
		when(multiunitSQLRepo.markNotAMultiUnit(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(intResult);
		Map<String, List<String>> result = multiUnitTypeServiceImpl.markNotAMultiUnitItem(multiUnitSourceDtoList);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetail() throws Exception {
		when(multiunitSQLRepo.fetchSrcItemBasedOnItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		when(multiunitSQLRepo.fetchSrcItemBasedOnVendorName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		when(multiunitSQLRepo.fetchSrcItemBasedOnProductHierarchy(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		when(multiunitSQLRepo.fetchSrcItemBasedOnProductSKU(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestList);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetailVenderNameFlag() throws Exception {
		when(multiunitSQLRepo.fetchSrcItemBasedOnVendorName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestList1);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetailVenderSmicFlag() throws Exception {
		when(multiunitSQLRepo.fetchSrcItemBasedOnProductHierarchy(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestList2);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetailVenderSKUsearchFlag() throws Exception {
		when(multiunitSQLRepo.fetchSrcItemBasedOnProductSKU(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSourceDetail);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestList3);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetailElse() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObjectSource);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestListElse);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetailElseVenderNameFlag() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnVendorName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObjectSource);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestListElse1);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitSourceDetailElseSmicFlag() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeSrcItemBasedOnProductHierarchy(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
						.thenReturn(listOfObjectSource);
		List<MultiUnitSourceDto> result = multiUnitTypeServiceImpl
				.getMultiUnitSourceDetail(multiUnitSourceTargetSearchRequestListElse2);
		assertFalse(result.isEmpty());
	}

	@Test
	public void tesGetMultiUnitTargetDetail() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObject);
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnVendorName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObject);
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnSmicCode(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObject);
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetItemBasedOnCIC(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(listOfObject);
		List<MultiUnitTypeTargetDto> result = multiUnitTypeServiceImpl
				.getMultiUnitTargetDetail(multiUnitSourceTargetSearchRequestList);
		assertFalse(result.isEmpty());
		multiUnitSourceTargetSearchRequestList.get(0).setItemDescFlag('A');
		multiUnitSourceTargetSearchRequestList.get(0).setVenderNameFlag('Y');
		multiUnitSourceTargetSearchRequestList.get(0).setTarVendorName("tarVendorName");
		multiUnitTypeServiceImpl
		.getMultiUnitTargetDetail(multiUnitSourceTargetSearchRequestList);
		multiUnitSourceTargetSearchRequestList.get(0).setVenderNameFlag('a');
		multiUnitSourceTargetSearchRequestList.get(0).setHierarchyOrSmicFlag('Y');
		multiUnitSourceTargetSearchRequestList.get(0).setTarGrpCd("");
		multiUnitSourceTargetSearchRequestList.get(0).setTarCtgryCd("");
		multiUnitTypeServiceImpl
		.getMultiUnitTargetDetail(multiUnitSourceTargetSearchRequestList);
		multiUnitSourceTargetSearchRequestList.get(0).setHierarchyOrSmicFlag('a');
		multiUnitSourceTargetSearchRequestList.get(0).setTargetCICsearchFlag('Y');
		multiUnitSourceTargetSearchRequestList.get(0).setTargetCIC("");
		multiUnitTypeServiceImpl
		.getMultiUnitTargetDetail(multiUnitSourceTargetSearchRequestList);
	}

	@Test
	public void testUpdateSourceBasedOnTargetUnMap() throws Exception {
		when(multiUnitTypeRepo.findMultiUnitTypeSrcItemByProductSkuUpcList(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyList())).thenReturn(itemConvMultiUnitTypeList);
		Map<String, String> result = multiUnitTypeServiceImpl.updateSourceBasedOnTargetUnMap(multiUnitSrcTargetDtoElse);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testUpdateSourceBasedOnTargetUnMapElse() throws Exception {
		List<MultiUnitTypeTargetDto> multiUnitTargetA = new ArrayList<>();
		List<MultiUnitSourceDto> multiUnitSourceDtoListA = new ArrayList<>();
		MultiUnitSrcTargetDto multiUnitSrcTargetDtoElseA = new MultiUnitSrcTargetDto();
		MultiUnitTypeTargetDto multiUnitTypeTargetDtoA = new MultiUnitTypeTargetDto();
		multiUnitSrcTargetDtoElseA.setSrcMultiUnitFlag("A");
		MultiUnitSourceDto multiUnitSourceDtoA = new MultiUnitSourceDto();
		multiUnitSourceDtoA.setCaseUpc("Case");
		multiUnitSourceDtoA.setCompanyId("Safeway");
		multiUnitSourceDtoA.setConvProductSku("Product");
		multiUnitSourceDtoA.setConvStatusCode("C");
		multiUnitSourceDtoA.setDeptName("IT");
		multiUnitSourceDtoA.setDivisionId("IND");
		multiUnitSourceDtoA.setMarkAsDeadReason("Mark");
		multiUnitSourceDtoA.setSrcItemDesc("Desc");
		multiUnitSourceDtoA.setMatchIndicator("A");
		multiUnitSourceDtoA.setMaxRetail(new BigDecimal(2));
		multiUnitSourceDtoA.setProdSourceCd("DSD");
		multiUnitSourceDtoA.setProductHierarchy("Tree-Tree-Tree");
		multiUnitSourceDtoA.setProductSku("Sku");
		multiUnitSourceDtoA.setSrcCost(new BigDecimal(2));
		multiUnitSourceDtoA.setSrcItemDesc("Desc");
		multiUnitSourceDtoA.setSrcPackWhse(new BigDecimal(2));
		multiUnitSourceDtoA.setSrcSize("Big");
		multiUnitSourceDtoA.setSrcUpc("UPC");
		multiUnitSourceDtoA.setSrcVendConvFctr(new BigDecimal(2));
		multiUnitSourceDtoA.setSrcVendName("Ven Name");
		multiUnitSourceDtoA.setSrcVendNum(new BigDecimal(2));
		multiUnitSourceDtoA.setUpcs(upcs);
		multiUnitSourceDtoA.setUpdatedUserId("ID");
		multiUnitSourceDtoListA.add(multiUnitSourceDtoA);
		multiUnitTypeTargetDtoA.setCaseUpc("Case");
		multiUnitTypeTargetDtoA.setCompanyId("Safeway");
		multiUnitTypeTargetDtoA.setCorpItemCd(new BigDecimal(10));
		multiUnitTypeTargetDtoA.setCorpStatus("P");
		multiUnitTypeTargetDtoA.setMatchIndicator("A");
		multiUnitTargetA.add(multiUnitTypeTargetDtoA);
		multiUnitSrcTargetDtoElseA.setMultiUnitSource(multiUnitSourceDtoListA);
		multiUnitSrcTargetDtoElseA.setMultiUnitTarget(multiUnitTargetA);
		when(multiUnitTypeRepo.findMultiUnitTypeSrcItemByProductSkuUpcList(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyList())).thenReturn(itemConvMultiUnitTypeList);
		Map<String, String> result = multiUnitTypeServiceImpl
				.updateSourceBasedOnTargetUnMap(multiUnitSrcTargetDtoElseA);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testMarkItemAsMultiUnit() throws Exception {
		when(multiunitSQLRepo.findProductSkuBasedOnConvProductSku(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfStrings);
		Map<String, String> result = multiUnitTypeServiceImpl.markItemAsMultiUnit(multiUnitSourceDtoList);
		assertFalse(result.isEmpty());
	}

	@Test
	public void testFetchMultiUnitSourceData() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeSrcItemOnload(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObjectSource);
		MultiUnitSrcTargetDto result = multiUnitTypeServiceImpl.fetchMultiUnitSourceData("ABS", "Ind", "Chn");
		assertEquals("ten", result.getMultiUnitSource().get(0).getCompanyId());
	}

	@Test
	public void testFetchMultiUnitTargetData() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitTypeTargetItemOnload(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(listOfObject);
		MultiUnitSrcTargetDto result = multiUnitTypeServiceImpl.fetchMultiUnitTargetData("ABS", "Ind", "Chn");
		assertEquals("upcSystem", result.getMultiUnitTarget().get(0).getCaseUpc());
	}

	@Test
	public void testFetchMuTTargetUpcPopUpData() throws Exception {
		when(multiunitSQLRepo.fetchMultiUnitUPCPopUpDetals(Mockito.anyString())).thenReturn(listOfObject);
		List<Object[]> result = multiUnitTypeServiceImpl.fetchMuTTargetUpcPopUpData("ABS");
		assertFalse(result.isEmpty());
	}

}