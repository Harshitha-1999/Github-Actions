package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.memi.data.entities.ItemConvBulkUploadTracking;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.ItemConvBulkUploadRepository;
import com.safeway.app.memi.data.repositories.MasterDataRepository;
import com.safeway.app.memi.data.repositories.NewItemDetailRepository;
import com.safeway.app.memi.data.repositories.SMICDetailRepository;
import com.safeway.app.memi.data.repositories.SizeUOMDetailRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.dtos.response.ExcelFileDto;
import com.safeway.app.memi.domain.dtos.response.ExcelFileKey;
import com.safeway.app.memi.domain.dtos.response.ExcelFileRequest;
import com.safeway.app.memi.domain.dtos.response.ExcelFileRow;
import com.safeway.app.memi.domain.services.impl.FileUploadServiceImpl;
import com.safeway.app.memi.domain.util.EmailFacilitator;

@SpringBootTest(classes = FileUploadServiceImpl.class)
public class FileUploadServiceImplTest {
	@Autowired
	private FileUploadServiceImpl fileUploadServiceImpl;
	@MockBean
	private ItemConvBulkUploadRepository itemConvBulkUploadRepository;
	@MockBean
	private NewItemDetailRepository newItemRepo;
	@MockBean
	private EmailFacilitator email;
	@MockBean
	private CommonSQLRepository commonSQLRepo;
	@MockBean
	private UIExceptionSrcRepository exceptionRepo;
	@MockBean
	private MasterDataRepository masterDataRepo;
	@MockBean
	private SMICDetailRepository smicDetailnRepo;
	@MockBean
	private SizeUOMDetailRepository sizeUOMDetailnRepo;

	private static ExcelFileRequest excelFileRequest;

	@BeforeAll
	public static void init() {
		excelFileRequest = new ExcelFileRequest("companyId", "divisionId", "divisionName", "deptName", "deptCode",
				"userId", null);
	}

	@Test
	public void testUploadExcel() throws IllegalStateException, IOException {
		MultipartFile uploadedExcelFile = Mockito.mock(MultipartFile.class);
		when(uploadedExcelFile.getOriginalFilename()).thenReturn("Exceptions_SEAFOOD.xlsx");
		when(uploadedExcelFile.isEmpty()).thenReturn(false);
		doAnswer(invocation -> {
			Object arg0 = invocation.getArgument(0);
			File destFile = (File) arg0;
			File sourceFile = new File("src/test/resources/Exceptions_SEAFOOD.xlsx");
			FileCopyUtils.copy(new FileInputStream(sourceFile), new FileOutputStream(destFile));
			return null;
		}).when(uploadedExcelFile).transferTo(Mockito.any(File.class));
		ItemConvBulkUploadTracking value = new ItemConvBulkUploadTracking();
		value.setCompanyId("companyId");
		value.setDivisionId("divisionId");
		value.setDeptName("deptName");
		value.setFileName("Exceptions_SEAFOOD.xlsx");
		value.setFilePath("/");
		value.setStatusCode("statusCode");
		value.setRecordCount(new BigDecimal(1));
		value.setValidRecordCount(new BigDecimal(1));
		value.setCreateUserId("test");
		value.setCreateUpdateTimestamp(new Date());
		when(itemConvBulkUploadRepository.save(Mockito.any(ItemConvBulkUploadTracking.class))).thenReturn(value);
		excelFileRequest.setFile(uploadedExcelFile);
		String message = fileUploadServiceImpl.uploadExcel(excelFileRequest);
		assertEquals("SUCCESS", message);
	}

	@Test
	public void testProcessExcelFileWithoutSave() {
		try {
			List<Object[]> list = new ArrayList<>();
			Object[] objects = new Object[] { "", "", "", "", new BigDecimal(1), 'A', "", "", "", "", 'A', 'a', 'a', "",
					"", "", "", "", new BigDecimal(1), new BigDecimal(1), "" };
			list.add(objects);
			when(commonSQLRepo.fetchRecordBasedOnCompanyIdDivisionIdProductSkuSetFromUiExceptionSource(Mockito.any(),
					Mockito.any(), Mockito.any())).thenReturn(list);
			MultipartFile uploadedExcelFile = Mockito.mock(MultipartFile.class);
			doAnswer(invocation -> {
				Object arg0 = invocation.getArgument(0);
				File destFile = (File) arg0;
				File sourceFile = new File("src/test/resources/Exceptions_SEAFOOD.xlsx");
				FileCopyUtils.copy(new FileInputStream(sourceFile), new FileOutputStream(destFile));
				return null;
			}).when(uploadedExcelFile).transferTo(Mockito.any(File.class));
			excelFileRequest.setFile(uploadedExcelFile);
			excelFileRequest.setUserId("test");
			ItemConvBulkUploadTracking bulkUploadTracking = new ItemConvBulkUploadTracking();
			bulkUploadTracking.setCompanyId("1");
			bulkUploadTracking.setDivisionId("1");
			bulkUploadTracking.setDeptName("1");
			bulkUploadTracking.setFileName("test-test");
			bulkUploadTracking.setFilePath("1");
			bulkUploadTracking.setStatusCode("");
			bulkUploadTracking.setRecordCount(new BigDecimal(1));
			bulkUploadTracking.setValidRecordCount(new BigDecimal(1));
			bulkUploadTracking.setCreateUserId("test");
			bulkUploadTracking.setCreateUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
			Method method = FileUploadServiceImpl.class.getDeclaredMethod("processExcelFileWithoutSave",
					ExcelFileRequest.class, ItemConvBulkUploadTracking.class);
			method.setAccessible(true);
			method.invoke(fileUploadServiceImpl, excelFileRequest, bulkUploadTracking);
		} catch (Exception e) {
		}
	}

	@Test
	public void testMarkMultipleItemAsDead() {
		Map<ExcelFileKey, ExcelFileDto> markDeadMap = new HashMap<>();
		ExcelFileKey excelFileKey = new ExcelFileKey(" ", "0-1-00000-00000");
		ExcelFileDto value = new ExcelFileDto();
		value.setConvTeamComments("comment");
		markDeadMap.put(excelFileKey, value);
		Set<String> productSkuSet = new HashSet<>();
		List<Object[]> dbRecord = new ArrayList<>();
		Object[] objects = new Object[] { null, null, null, "", "", null, new BigDecimal(1), null, null, null, null };
		dbRecord.add(objects);
		when(commonSQLRepo.fetchRecordBasedOnCompanyIdDivisionIdProductSkuSet(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(dbRecord);
		Method method;
		try {
			method = FileUploadServiceImpl.class.getDeclaredMethod("markMultipleItemAsDead", Map.class,
					ExcelFileRequest.class, Set.class);
			method.setAccessible(true);
			method.invoke(fileUploadServiceImpl, markDeadMap, excelFileRequest, productSkuSet);
		} catch (Exception e) {
		}
	}

	@Test
	public void testBuildFinalDtoForValidation() {
		ExcelFileDto excelFileDto = new ExcelFileDto();
		ExcelFileRow excelFileRow = new ExcelFileRow();
		excelFileDto.setEthnicTypeCd("abc");
		excelFileDto.setInnerPack("12");
		excelFileDto.setRetailUnitPack("12");
		excelFileDto.setGrpCd("12");
		excelFileDto.setCtgryCd("12");
		excelFileDto.setProductionGrpCd("12");
		excelFileDto.setProductionCtgryCd("12");
		excelFileDto.setProductionClsCd("12");
		excelFileDto.setUpdUpc("");
		excelFileDto.setUpdPlu("");
		excelFileDto.setDcPackDesc("");
		excelFileDto.setDcSizeDsc("");
		excelFileDto.setRing("");
		excelFileDto.setHicone("");
		Method method;
		try {
			method = FileUploadServiceImpl.class.getDeclaredMethod("buildFinalDtoForValidation", ExcelFileDto.class,
					ExcelFileRow.class);
			method.setAccessible(true);
			method.invoke(fileUploadServiceImpl, excelFileDto, excelFileRow);
		} catch (Exception e) {
		}
	}

	@Test
	public void testSaveValidExcelObject() {
		Map<ExcelFileKey, ExcelFileRow> finalMapForValidation = new HashMap<ExcelFileKey, ExcelFileRow>();
		ItemConvBulkUploadTracking obj = new ItemConvBulkUploadTracking();
		Set<String> validProductSkuSet = new HashSet<>();
		Set<String> invalidProductSkuSet = new HashSet<>();
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		validProductSkuSet.add("prd-sku");
		ExcelFileRow exlObj = new ExcelFileRow();
		exlObj.setUpc("00-00-00-00");
		exlObj.setCompanyId("companyId");
		exlObj.setDivisionId("divisionId");
		exlObj.setProductSku("prd-sku");
		exlObj.setProductSrcCd("productSrcCd");
		exlObj.setVendorCost(new BigDecimal("1"));
		exlObj.setBatchId(new BigDecimal(1));
		exlObj.setUpdUpc("123");
		exlObj.setUpdPlu("updPlu");
		exlObj.setDcPackDesc("dcPackDesc");
		exlObj.setDcSizeDsc("dcSizeDsc");
		exlObj.setPackWhse(new BigDecimal(1));
		obj.setCreateUserId("createUserId");
		ExcelFileKey excelFileKey = new ExcelFileKey("prd-sku", "00-00-00-00");
		finalMapForValidation.put(excelFileKey, exlObj);
		Method method;
		try {
			method = FileUploadServiceImpl.class.getDeclaredMethod("saveValidExcelObject", Map.class,
					ItemConvBulkUploadTracking.class, Set.class, Set.class, Map.class);
			method.setAccessible(true);
			method.invoke(fileUploadServiceImpl, finalMapForValidation, obj, validProductSkuSet, invalidProductSkuSet,
					invalidProductSkuMap);
			exlObj.setPackWhse(null);
			method.invoke(fileUploadServiceImpl, finalMapForValidation, obj, validProductSkuSet, invalidProductSkuSet,
					invalidProductSkuMap);

		} catch (Exception e) {
		}
	}

	@Test
	public void testValidateExcelFileColumn() {
		ExcelFileDto saveItem = new ExcelFileDto();
		Map<String, List<String>> updIndTypeHm = new HashMap<>();
		Map<String, Set<String>> productionCodeMap = new HashMap<>();
		Map<String, List<String>> validationHashMap = new HashMap<>();
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		productionCodeMap.put("productionGroupCode", Collections.singleton(""));
		productionCodeMap.put("productionCategoryCode", Collections.singleton(""));
		productionCodeMap.put("productionClassCode", Collections.singleton(""));
		saveItem.setUpc("00-00-00-00-00");
		saveItem.setProductSku("productSku");
		validationHashMap.put("exception ColumnList",
				Arrays.asList(new String[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
						"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
						"", "", "", "", "" }));
		try {
			Method method = FileUploadServiceImpl.class.getDeclaredMethod("validateExcelFileColumn", ExcelFileDto.class,
					Map.class, Map.class, Map.class, Map.class);
			method.setAccessible(true);
			method.invoke(fileUploadServiceImpl, saveItem, updIndTypeHm, productionCodeMap, validationHashMap,
					invalidProductSkuMap);
		} catch (Exception e) {
		}
	}

	@Test
	public void testIsValidString() {
		Boolean isValid = FileUploadServiceImpl.isValidString("@", "@");
		assertTrue(isValid);
		isValid = FileUploadServiceImpl.isValidString("@", "");
		assertFalse(isValid);
	}

	@Test
	public void testmapToExcelFileRow() throws Exception {
		String[] arr = new String[100];
		List<String> column = Arrays.asList(arr);
		arr[13] = "";
		arr[15] = "";
		arr[36] = "";
		arr[37] = "";
		arr[38] = "";
		arr[39] = "12";
		arr[51] = "";
		arr[60] = "a";
		arr[61] = "a";
		arr[62] = "a";
		arr[64] = "a";
		ExcelFileRequest fReq = new ExcelFileRequest("companyId", "divisionId", "divisionName", "deptName", "deptCode",
				"userId", null);
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("mapToExcelFileRow", List.class,
				ExcelFileRequest.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, column, fReq);
	}

	@Test
	public void testbuildLikeItemDetailDtoListAsMap() {
		Object[] arr = new Object[100];
		arr[0] = "999";
		arr[4] = new BigDecimal("09");
		List<Object[]> likeItemObjList = Collections.singletonList(arr);
		fileUploadServiceImpl.buildLikeItemDetailDtoListAsMap(likeItemObjList);
	}

	@Test
	public void testupdateStatusToDatabase() throws Exception {
		ItemConvBulkUploadTracking obj = new ItemConvBulkUploadTracking();
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("updateStatusToDatabase",
				ItemConvBulkUploadTracking.class, String.class, BigDecimal.class, BigDecimal.class, String.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, obj, "statusCode", new BigDecimal(1), new BigDecimal(1), "filePath");
	}

	@Test
	public void testsendEmail() throws Exception {
		String userId = "userID";
		String excelFileName = "file-name";
		Set<String> invalidProductSkuSet = new HashSet<>();
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		invalidProductSkuMap.put("key", Arrays.asList(""));
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("sendEmail", String.class, String.class,
				Set.class, Map.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, userId, excelFileName, invalidProductSkuSet, invalidProductSkuMap);
		invalidProductSkuSet.addAll(Arrays.asList(""));
		method.invoke(fileUploadServiceImpl, userId, excelFileName, invalidProductSkuSet, invalidProductSkuMap);
	}

	@Test
	public void testbuildFinalMapForValidation() throws Exception {
		ExcelFileKey excelFileKey = new ExcelFileKey("productSku", "upc");
		ExcelFileDto excelFileDto = new ExcelFileDto();
		ExcelFileRow excelFileRow = new ExcelFileRow();
		Map<ExcelFileKey, ExcelFileDto> excelMap = new HashMap<>();
		Map<ExcelFileKey, ExcelFileRow> dbMap = new HashMap<>();
		Set<String> validProductSkuSet = new HashSet<>(Arrays.asList("productSku"));
		Set<String> invalidProductSkuSet = new HashSet<>();
		excelMap.put(excelFileKey, excelFileDto);
		dbMap.put(excelFileKey, excelFileRow);
		excelFileDto.setProductSku("productSku");
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("buildFinalMapForValidation", Map.class,
				Map.class, Set.class, Set.class, Map.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, excelMap, dbMap, validProductSkuSet, invalidProductSkuSet,
				invalidProductSkuMap);
	}

	@Test
	public void testsaveExcelDataToDatabase() throws Exception {
		ItemConvBulkUploadTracking obj = new ItemConvBulkUploadTracking();
		obj.setCompanyId("companyId");
		obj.setDivisionId("divisionId");
		List<String> dbRecord = Arrays.asList("value");
		Set<String> validProductSkuSet = new HashSet<>(Arrays.asList("value"));
		Set<String> invalidProductSkuSet = new HashSet<>();
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		when(commonSQLRepo.fetchRecordBasedOnCompanyIdDivisionIdProductSku(Mockito.anyString(), Mockito.anyString(),
				Mockito.anySet())).thenReturn(dbRecord);
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("saveExcelDataToDatabase", Map.class,
				ItemConvBulkUploadTracking.class, Set.class, Set.class, Map.class);
		method.setAccessible(true);
		try {
			method.invoke(fileUploadServiceImpl, null, obj, validProductSkuSet, invalidProductSkuSet,
					invalidProductSkuMap);
		} catch (Exception e) {

		}
	}

	@Test
	public void testfindValidRecorFromExcelBasedOnValidProductSku() throws Exception {
		ExcelFileDto excelFileDto = new ExcelFileDto();
		ExcelFileKey excelFileKey = new ExcelFileKey("productSku", "upc");
		excelFileDto.setProductSku("productSku");
		Map<ExcelFileKey, ExcelFileDto> excelMap = new HashMap<>();
		excelMap.put(excelFileKey, excelFileDto);
		Set<String> validProductSkuSet = new HashSet<>(Arrays.asList("productSku"));
		Method method = fileUploadServiceImpl.getClass()
				.getDeclaredMethod("findValidRecorFromExcelBasedOnValidProductSku", Map.class, Set.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, excelMap, validProductSkuSet);
	}

	@Test
	public void testvalidatedProductSkusFromExcel() throws Exception {
		List<Object[]> productionCodeList = Collections.singletonList(new Object[]{"0","1","2"});
		ExcelFileDto excelFileDto = new ExcelFileDto();
		ExcelFileKey excelFileKey = new ExcelFileKey("productSku", "upc");
		excelFileDto.setProductSku("productSku");
		excelFileDto.setUpc("00-00");
		Map<ExcelFileKey, ExcelFileDto> excelDataMap = new HashMap<>();
		excelDataMap.put(excelFileKey, excelFileDto);
		Set<String> validProductSkuSet = new HashSet<>();
		Set<String> invalidProductSkuSet = new HashSet<>();
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		when(commonSQLRepo.fetchProductionCode()).thenReturn(productionCodeList);
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("validatedProductSkusFromExcel", Map.class,
				Set.class, Set.class, Map.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, excelDataMap, validProductSkuSet, invalidProductSkuSet,
				invalidProductSkuMap);
		
		excelFileDto.setUpdItemDesc("updItemDesc@");
		excelFileDto.setUpdWhseItemDesc("updWhseItemDesc@");
		excelFileDto.setUpdRtlItemDesc("updRtlItemDesc@");
		excelFileDto.setUpdInternetItemDesc("updInternetItemDesc@");
		excelFileDto.setUpdPosDesc("updPosDesc");
		excelFileDto.setUpdSize("updSize");
		excelFileDto.setUpdSizeNmbr("updSizeNmbr");
		excelFileDto.setUpdSizeUom("updSizeUom");
		excelFileDto.setRetailUnitPack("retailUnitPack");
		excelFileDto.setInnerPack("ab");
		excelFileDto.setGrpCd("grpCd");
		excelFileDto.setCtgryCd("ctgryCd");
		excelFileDto.setClsCd("clsCd");
		excelFileDto.setSbClsCd("sbClsCd");
		excelFileDto.setSubSbClassCd("subSbClassCd");
		excelFileDto.setPckTypeId("pckTypeId");
		excelFileDto.setUpdSize("updSize");
		excelFileDto.setUpdItemUsageInd("R");
		excelFileDto.setUpdItemUsageTypInd("A");
		excelFileDto.setUpdPrivateLabelInd("AB");
		excelFileDto.setUpdDispFlag("AB");
		excelFileDto.setUpdSizeNmbr("AB");
		excelFileDto.setEthnicTypeCd("ABC");
		excelFileDto.setPckTypeId("AB");
		excelFileDto.setUpdSizeUom("ab");
		excelFileDto.setProductClsCd("ab");
		excelFileDto.setGrpCd("84");
		excelFileDto.setProductionGrpCd("productionGrpCd");
		excelFileDto.setProductionCtgryCd("productionCtgryCd");
		excelFileDto.setProductionClsCd("productionClsCd");
		excelFileDto.setDcPackDesc("dcPackDesc");
		excelFileDto.setDcSizeDsc("dcSizeDsc");
		excelFileDto.setRing("ring");
		excelFileDto.setHicone("hicone");
		excelFileDto.setProdwght("prodwght");
		excelFileDto.setHandlingCode("handlingCode");
		excelFileDto.setBuyerNum("buyerNum");
		excelFileDto.setRandomWtCd("randomWtCd");
		excelFileDto.setAutoCostInv("autoCostInv");
		excelFileDto.setBillingType("billingType");
		excelFileDto.setFdStmp("fdStmp");
		excelFileDto.setLabelSize("labelSize");
		excelFileDto.setLabelNumbers("labelNumbers");
		excelFileDto.setSgnCount1("sgnCount1");
		excelFileDto.setSgnCount2("sgnCount2");
		excelFileDto.setSgnCount3("sgnCount3");
		excelFileDto.setSellByDays("sellByDays");
		excelFileDto.setUseByDays("useByDays");
		excelFileDto.setPullBydays("pullBydays");
		excelFileDto.setTareCd("tareCd");
		method.invoke(fileUploadServiceImpl, excelDataMap, validProductSkuSet, invalidProductSkuSet,
				invalidProductSkuMap);
		
		excelFileDto.setUpdItemUsageTypInd("A");
		excelFileDto.setRetailUnitPack("0");
		excelFileDto.setUpdItemUsageInd("Q");
		excelFileDto.setUpdPrivateLabelInd("A");
		excelFileDto.setUpdDispFlag("A");
		excelFileDto.setUpdSizeUom("12");
		method.invoke(fileUploadServiceImpl, excelDataMap, validProductSkuSet, invalidProductSkuSet,
				invalidProductSkuMap);

		excelFileDto.setUpdItemUsageTypInd("A");
		method.invoke(fileUploadServiceImpl, excelDataMap, validProductSkuSet, invalidProductSkuSet,
				invalidProductSkuMap);
		
		
	}
	
	@Test
	public void testbuildValidMapAfterMarkDead() throws Exception {
		ExcelFileDto excelFileDto = new ExcelFileDto();
		ExcelFileKey excelFileKey = new ExcelFileKey("productSku", "upc");
		excelFileDto.setProductSku("productSku");
		excelFileDto.setUpc("00-00");
		excelFileDto.setAction("D");
		Map<ExcelFileKey, ExcelFileDto> excelMap = new HashMap<>();
		ExcelFileRequest fReq = new ExcelFileRequest();
		excelMap.put(excelFileKey, excelFileDto);
		Method method = fileUploadServiceImpl.getClass().getDeclaredMethod("buildValidMapAfterMarkDead", Map.class,ExcelFileRequest.class);
		method.setAccessible(true);
		method.invoke(fileUploadServiceImpl, excelMap,fReq);
		excelFileDto.setAction("A");
		method.invoke(fileUploadServiceImpl, excelMap,fReq);
	}
}
