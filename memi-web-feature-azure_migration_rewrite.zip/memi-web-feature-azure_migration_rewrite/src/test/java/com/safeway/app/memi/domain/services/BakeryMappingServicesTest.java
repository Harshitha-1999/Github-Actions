/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemConvManualMatchingPlan;
import com.safeway.app.memi.data.repositories.BakeryAdditionalSQLRepository;
import com.safeway.app.memi.data.repositories.BakerySQLRepository;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ItemConvManualMatchingPlanRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakeryMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;
import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.BakeryResponseVO;
import com.safeway.app.memi.domain.dtos.response.BakerySearchRequestVO;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableAdditionalDetailsDto;
import com.safeway.app.memi.domain.dtos.response.PerishableFilterVO;
import com.safeway.app.memi.domain.dtos.response.PerishableItemTypeVO;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.services.impl.BakeryMappingServicesImpl;
import com.safeway.app.memi.domain.util.PerishableConstants;

/**
 ****************************************************************************
 * NAME : BakeryMappingServicesTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Nov 17, 2021 - Initial Creation
 * *************************************************************************
 */

@SpringBootTest(classes = BakeryMappingServicesImpl.class)
public class BakeryMappingServicesTest {

	@Autowired
	private BakeryMappingServicesImpl bakeryMappingServicesImpl;
	@MockBean
	private BakerySQLRepository bakerySQLRepository;
	@MockBean
	private BakeryAdditionalSQLRepository bakeryAdditionalSQLRepository;
	@MockBean
	private ItemConvManualMatchingPlanRepository itemConvManualMatchingPlanRepository;
	@MockBean
	private ItemAggregateCorpRepository itemAggregateRepo;
	@MockBean
	private UIExceptionSrcRepository exSrcRepo;
	private static BakerySearchRequestVO bakerySearchRequestVO;
	private static List<BakeryMappingRequest> bakeryMappingRequests;
	private static BakeryMappingRequest bakeryMappingRequest;

	@BeforeAll
	public static void init() {
		bakerySearchRequestVO = new BakerySearchRequestVO();
		bakerySearchRequestVO.setCompanyID("34");
		bakerySearchRequestVO.setDivisionID("3400");
		bakerySearchRequestVO.setMappingStatus("");
		bakerySearchRequestVO.setSearchCriteriaValue(PerishableConstants.PLU_VAL);
		PerishableItemTypeVO itemTypeVO = new PerishableItemTypeVO();
		itemTypeVO.setAll(true);
		bakerySearchRequestVO.setItemType(itemTypeVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		PerishableFilterVO perishableFilterVO = new PerishableFilterVO();
		perishableFilterVO.setCorpItemCD(" ");
		perishableFilterVO.setDepartment(" ");
		perishableFilterVO.setDivisionNum(" ");
		perishableFilterVO.setHierarchy(" ");
		perishableFilterVO.setItemNum(" ");
		perishableFilterVO.setItemDescription(" ");
		perishableFilterVO.setProductSKU(" ");
		perishableFilterVO.setPlu(" ");
		perishableFilterVO.setSupplierNum(" ");
		perishableFilterVO.setSupplierName(" ");
		perishableFilterVO.setSlu(" ");
		perishableFilterVO.setVendorName(" ");
		perishableFilterVO.setVendorCode(" ");
		perishableFilterVO.setSmicGroupCd(" ");
		perishableFilterVO.setSmicCtgryCd(" ");
		perishableFilterVO.setSmicClassCd(" ");
		perishableFilterVO.setSmicSubClassCd(" ");
		perishableFilterVO.setSmicSubSubClassCd(" ");
		perishableFilterVO.setUpc(" ");
		perishableFilterVO.setProdhierarchyLevel1(" ");
		perishableFilterVO.setProdhierarchyLevel2(" ");
		perishableFilterVO.setProdhierarchyLevel3(" ");
		perishableFilterVO.setUsageTypeIndFilter(true);
		perishableFilterVO.setUsageFilter(true);
		perishableFilterVO.setTotalSalesFilter(true);
		perishableFilterVO.setShipped(true);
		perishableFilterVO.setShipSearchValue("Y");
		bakerySearchRequestVO.setFilter(perishableFilterVO);
		bakerySearchRequestVO.setFilterAvail(true);

		bakeryMappingRequests = new ArrayList<>();
		bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequests.add(bakeryMappingRequest);
	}

	@Test
	public void testListBakerySKUItems() throws Exception {
		when(bakerySQLRepository.countBakerySourceList(Mockito.anyMap(), Mockito.anyMap()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakerySourceList(Mockito.anyMap(), Mockito.anyMap()))
				.thenReturn(Collections.singletonList(new Object[100]));
		BakeryResponseVO bakeryResponseVO = bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		assertEquals(5, bakeryResponseVO.getSourceCount().intValue());
	}

	@Test
	public void testListBakerySKUItems1() throws Exception {
		bakerySearchRequestVO.setFilterAvail(true);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		PerishableFilterVO filterVO = new PerishableFilterVO();
		bakerySearchRequestVO.setFilter(filterVO);
		filterVO.setVendorOrderFilter(true);
		when(bakerySQLRepository.countBakerySourceList(Mockito.anyMap(), Mockito.anyMap()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakerySourceList(Mockito.anyMap(), Mockito.anyMap()))
				.thenReturn(Collections.singletonList(new Object[1]));
		try {
			bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testListBakerySKUItems2() throws Exception {
		bakerySearchRequestVO.setFilterAvail(true);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		PerishableFilterVO filterVO = new PerishableFilterVO();
		bakerySearchRequestVO.setFilter(filterVO);
		filterVO.setVendorOrderFilter(true);
		when(bakerySQLRepository.countBakerySourceList(Mockito.anyMap(), Mockito.anyMap()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakerySourceList(Mockito.anyMap(), Mockito.anyMap()))
				.thenReturn(Collections.singletonList(new Object[50]));
		bakerySearchRequestVO.setSearchCriteria("");
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.getItemType().setPlu(true);
		bakerySearchRequestVO.getItemType().setSystem2(true);
		bakerySearchRequestVO.getItemType().setSystem4(true);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.PLU_VAL);
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.WHSE_DSD);
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("DISP");
		bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("TOTAL_SALES");
		BakeryResponseVO bakeryResponseVO = bakeryMappingServicesImpl.listBakerySKUItems(bakerySearchRequestVO);
		assertEquals(new BigDecimal("5"),bakeryResponseVO.getSourceCount());
	}

	@Test
	public void testListBakeryCICItems() throws Exception {
		when(bakerySQLRepository.countBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.any()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.anyString()))
				.thenReturn(new ArrayList<>());
		bakerySearchRequestVO.setMappingStatus(" ");
		BakeryResponseVO bakeryResponseVO = bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		assertEquals(new BigDecimal("5"),bakeryResponseVO.getTargetCount());
	}

	@Test
	public void testListBakeryCICItems1() throws Exception {
		when(bakerySQLRepository.countBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.any()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.anyString()))
				.thenReturn(new ArrayList<>());
		bakerySearchRequestVO.setSearchCriteria(" DISP");
		BakeryResponseVO bakeryResponseVO = bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		assertEquals(new BigDecimal("5"),bakeryResponseVO.getTargetCount());
	}

	@Test
	public void testListBakeryCICItems2() throws Exception {
		when(bakerySQLRepository.countBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.any()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.anyString()))
				.thenReturn(Collections.singletonList(null));
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.USAGE_TYPE);
		BakeryResponseVO bakeryResponseVO = bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		assertEquals(new BigDecimal("5"),bakeryResponseVO.getTargetCount());
	}

	@Test
	public void testListBakeryCICItems3() throws Exception {
		when(bakerySQLRepository.countBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.any()))
				.thenReturn(new BigDecimal("5"));
		when(bakerySQLRepository.fetchBakeryTargetList(Mockito.anyMap(), Mockito.anyMap(), Mockito.anyString()))
				.thenReturn(new ArrayList<>());
		bakerySearchRequestVO.setSearchCriteria("WHSE_DSD");
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("CIC_VAL");
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.DEPT_NAME);
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("ITEM_USAGE");
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("DISPLAY");
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("SMIC");
		bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.PLU_VAL);
		BakeryResponseVO bakeryResponseVO = bakeryMappingServicesImpl.listBakeryCICItems(bakerySearchRequestVO);
		assertEquals(new BigDecimal("5"),bakeryResponseVO.getTargetCount());
	}

	@Test
	public void testPerformAction() throws Exception {
		BakeryMappingRequestWrapper mappingRequest = new BakeryMappingRequestWrapper();
		bakeryMappingRequest.setUpc("                  ");
		bakeryMappingRequest.setCic("25");
		bakeryMappingRequest.setMappingType(" ");
		mappingRequest.setMappingrequestBuyer(Collections.singletonList(bakeryMappingRequest));
		mappingRequest.setMappingrequestSeller(Collections.singletonList(bakeryMappingRequest));
		bakeryMappingServicesImpl.performAction(mappingRequest);
		assertTrue(true);
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testPerformAction1() throws Exception {
		BakeryMappingRequestWrapper mappingRequest = new BakeryMappingRequestWrapper();
		bakeryMappingRequest.setUpc("                  ");
		bakeryMappingRequest.setCic("25");
		bakeryMappingRequest.setMappingType(PerishableConstants.RESERVED);
		bakeryMappingRequest.setCompanyID(" ");
		bakeryMappingRequest.setDivisionID("  ");
		bakeryMappingRequest.setSku(" ");
		bakeryMappingRequest.setUpc(" ");
		bakeryMappingRequest.setMappingstatus("  status ");
		mappingRequest.setMappingrequestBuyer(Collections.singletonList(bakeryMappingRequest));
		mappingRequest.setMappingrequestSeller(Collections.singletonList(bakeryMappingRequest));
		when(itemConvManualMatchingPlanRepository
				.findByItemConvManualMatchingPlanPkCompanyIdAndItemConvManualMatchingPlanPkDivisionIdAndItemConvManualMatchingPlanPkProductSKUAndItemConvManualMatchingPlanPkUpcAndItemConvManualMatchingPlanPkMatchedItemTypeCdAndMappingTypeAndMappingStatus(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
								.thenReturn(new ItemConvManualMatchingPlan());
		bakeryMappingServicesImpl.performAction(mappingRequest);
		assertTrue(true);
	}

	@Test
	public void testDuplicateCheckOnMappedItems() throws Exception {
		List<String> strings = bakeryMappingServicesImpl.duplicateCheckOnMappedItems(bakeryMappingRequests);
		assertEquals(0, strings.size());
	}

	@Test
	public void testSaveForceNewInPerishableMapping() throws Exception {
		bakeryMappingRequest.setUpc(" ");
		bakeryMappingRequest.setTargetTypeIndicator(" ");
		String res = bakeryMappingServicesImpl.saveForceNewInPerishableMapping(bakeryMappingRequests);
		assertEquals("Successfully inserted",res);
	}

	@Test
	public void testCreateNewCic() throws Exception {
		List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDtos = new ArrayList<>();
		DisplayItemCreateMatchCicDto header = new DisplayItemCreateMatchCicDto();
		header.setCost(new BigDecimal("1"));
		displayItemCreateMatchCicDtos.add(header);
		ItemAggregateCorp itemAggregateCorp = new ItemAggregateCorp();
		itemAggregateCorp.setBatchId(new BigDecimal("1"));
		itemAggregateCorp.setSrcByDsd("Y");
		itemAggregateCorp.setSrcByWhse("Y");
		when(bakerySQLRepository.fetchUpcList(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(Collections.singletonList(" fetchUpcList        "));
		when(itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
								.thenReturn(Collections.singletonList(itemAggregateCorp));
		itemAggregateCorp.setMaterialItemInd('Y');
		itemAggregateCorp.setExpenseItemInd('N');
		bakeryMappingServicesImpl.createNewCic(displayItemCreateMatchCicDtos);
		itemAggregateCorp.setMaterialItemInd('N');
		itemAggregateCorp.setExpenseItemInd('Y');
		bakeryMappingServicesImpl.createNewCic(displayItemCreateMatchCicDtos);
		itemAggregateCorp.setMaterialItemInd('N');
		itemAggregateCorp.setExpenseItemInd('N');
		bakeryMappingServicesImpl.createNewCic(displayItemCreateMatchCicDtos);
		assertTrue(true);
	}

	@Test
	public void testListMappedData() throws Exception {
		bakerySearchRequestVO.setSearchIndicator(PerishableConstants.SOURCE_INDICATOR);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.SKU_VAL);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.UPC_VAL);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.DISP);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.WHSE);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.DSD);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		assertTrue(true);
	}

	@Test
	public void testListMappedData1() throws Exception {
		bakerySearchRequestVO.setSearchIndicator(PerishableConstants.TARGET_INDICATOR);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.CIC_VAL);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.ITEM_DESC);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria(PerishableConstants.DISP);
		bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		bakerySearchRequestVO.setSearchCriteria("DST_CNTR");
		List<BakeryMappedResultWrapper> list = bakeryMappingServicesImpl.listMappedData(bakerySearchRequestVO);
		assertEquals(0,list.size());
	}

	@Test
	public void testUpdateForceNewInPerishableMapping() throws Exception {
		String res = bakeryMappingServicesImpl.updateForceNewInPerishableMapping(bakeryMappingRequest);
		assertEquals("updation failed",res);
	}

	@Test
	public void testGetSuggestedTargetList() throws Exception {
		PerishableMatchingTargetInputVO upcDetails = new PerishableMatchingTargetInputVO();
		when(bakeryAdditionalSQLRepository.loadCICSuggestions(Mockito.any()))
				.thenReturn(Collections.singletonList(new Object[1]));
		List<BakeryCICSearchResults> list = bakeryMappingServicesImpl.getSuggestedTargetList(upcDetails);
		assertEquals(0 ,list.size());
	}

	@Test
	public void testGetadditionalRetailscanDetails() throws Exception {
		Map<String, Object> map = new HashedMap<>();
		map.put("RETAIL_SCAN_DETAIL", new ArrayList<>());
		when(bakeryAdditionalSQLRepository.fetchAdditonalRetailScandetails(Mockito.anyString())).thenReturn(map);
		PerishableAdditionalDetailsDto res = bakeryMappingServicesImpl.getadditionalRetailscanDetails(" ");
		assertNull(res.getRogCount());
	}

	@Test
	public void testFetchTargetEditITems() throws Exception {
		List<Object> list = new ArrayList<>();
		list.add(new ArrayList<>());
		list.add(new ArrayList<>());
		list.add(null);
		list.add(new ArrayList<>());
		when(bakeryAdditionalSQLRepository.loadTargetFieldsForMapEdit(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(list);
		ManualMatchAdtnlFieldLoadInputVo inputVo = new ManualMatchAdtnlFieldLoadInputVo();
		inputVo.setProductSKUs(new String[] { "", "", "" });
		inputVo.setBuyingCic("");
		inputVo.setCompanyId(" ");
		inputVo.setDivisionId("");
		inputVo.setSellingCic(" ");
		inputVo.setBuyingCic("   ");
		inputVo.setWhseDsd("WHSE");
		bakeryMappingServicesImpl.fetchTargetEditITems(inputVo);
		inputVo.setWhseDsd(null);
		bakeryMappingServicesImpl.fetchTargetEditITems(inputVo);
		assertTrue(true);
	}
	
	@Test
	public void testSetValidDeptwisedata() throws Exception {
		Method method = BakeryMappingServicesImpl.class.getDeclaredMethod("buildEntity", BakeryMappingRequest.class);
		method.setAccessible(true);
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setCompanyID("ABS");
		bakeryMappingRequest.setDivisionID("Chn");
		bakeryMappingRequest.setSku("SKU");
		bakeryMappingRequest.setUpc("upc");
		bakeryMappingRequest.setTargetTypeIndicator("Target");
		bakeryMappingRequest.setCic("10");
		bakeryMappingRequest.setMappingType("RESERVED");
		bakeryMappingRequest.setTargetEdited(true);
		method.invoke(bakeryMappingServicesImpl, bakeryMappingRequest);
		assertEquals("ABS", bakeryMappingRequest.getCompanyID());
	}
	
	@Test
	public void testSetValidDeptwisedataMarkAsDead() throws Exception {
		Method method = BakeryMappingServicesImpl.class.getDeclaredMethod("buildEntity", BakeryMappingRequest.class);
		method.setAccessible(true);
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setMappingType("MARK_AS_DEAD");
		bakeryMappingRequest.setTargetEdited(true);
		method.invoke(bakeryMappingServicesImpl, bakeryMappingRequest);
		assertTrue(true);
	}
	
	@Test
	public void testSetValidDeptwisedataLetAutoMatch() throws Exception {
		Method method = BakeryMappingServicesImpl.class.getDeclaredMethod("buildEntity", BakeryMappingRequest.class);
		method.setAccessible(true);
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setMappingType("LET_AUTO_MATCH");
		bakeryMappingRequest.setTargetEdited(true);
		method.invoke(bakeryMappingServicesImpl, bakeryMappingRequest);
		assertTrue(true);
	}
	
	@Test
	public void testSetValidDeptwisedataForceNew() throws Exception {
		Method method = BakeryMappingServicesImpl.class.getDeclaredMethod("buildEntity", BakeryMappingRequest.class);
		method.setAccessible(true);
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setMappingType("FORCE_NEW");
		bakeryMappingRequest.setTargetEdited(true);
		method.invoke(bakeryMappingServicesImpl, bakeryMappingRequest);
		assertTrue(true);
	}
	
	@Test
	public void testPerformMarkAsDeadAction() throws Exception {
		Method method = BakeryMappingServicesImpl.class.getDeclaredMethod("performMarkAsDeadAction", BakeryMappingRequest.class);
		method.setAccessible(true);
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setCompanyID("ABS");
		bakeryMappingRequest.setDivisionID("Chn");
		bakeryMappingRequest.setUpc("upcupcupcupcupcupc");
		bakeryMappingRequest.setComments("Any");	
		method.invoke(bakeryMappingServicesImpl, bakeryMappingRequest);
		assertTrue(true);
	}
	
	@Test
	public void testcreateMapBasedOnProductSkuElse() throws Exception {
		Method method = BakeryMappingServicesImpl.class.getDeclaredMethod("createMapBasedOnProductSku", List.class);
		method.setAccessible(true);
		List<BakeryMappingRequest> bakeryMappingRequests = new ArrayList<>();
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setUpc("12345");
		bakeryMappingRequest.setTargetTypeIndicator("S");
		bakeryMappingRequest.setSku("SKU");
		bakeryMappingRequest.setMappingType("ADD_MAP");
		bakeryMappingRequests.add(bakeryMappingRequest);
		method.invoke(bakeryMappingServicesImpl, bakeryMappingRequests);
		assertTrue(true);
	}

}