package com.safeway.app.memi.domain.services;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.DepartmentDetail;
import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.NewItemDetailPk;
import com.safeway.app.memi.data.entities.SalesShip;
import com.safeway.app.memi.data.entities.SalesShipPk;
import com.safeway.app.memi.data.entities.SizeUOMDetail;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ManualMappingRepository;
import com.safeway.app.memi.data.repositories.MasterDataRepository;
import com.safeway.app.memi.data.repositories.NewItemDetailRepository;
import com.safeway.app.memi.data.repositories.SalesShipRepository;
import com.safeway.app.memi.data.repositories.SizeUOMDetailRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.dtos.response.AugDataVo;
import com.safeway.app.memi.domain.dtos.response.DepartmentDto;
import com.safeway.app.memi.domain.dtos.response.OverrideDataVo;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.services.impl.ExceptionSrcServiceImpl;

@SpringBootTest(classes = ExceptionSrcServiceImpl.class)
public class ExceptionSrcServiceImplTest {

	@Autowired
	private ExceptionSrcServiceImpl exceptionSrcServiceImpl;
	@MockBean
	private UIExceptionSrcRepository exceptionRepo;
	@MockBean
	private SalesShipRepository salesShipRepo;
	@MockBean
	private NewItemDetailRepository newItemDetailRepo;
	@MockBean
	private CommonSQLRepository commonSQLRepo;
	@MockBean
	private SizeUOMDetailRepository sizeUOMDetailnRepo;
	@MockBean
	private ItemAggregateCorpRepository itemAggregateRepo;
	@MockBean
	private MasterDataRepository itemXrefRepo;
	@MockBean
	private ManualMappingRepository manualMappingRepository;
	private static List<Object[]> resultList;
	private static List<UIExceptionSrc> uiExceptionSrcs;
	private static List<SalesShip> shipData;
	private static List<String> stringList;
	private static UIExceptionSrc uiExceptionSrc;
	private static UiExceptionSrcPk uiExceptionSrcPk;
	private static SalesShip salesShip;
	private static SalesShipPk salesShipPk;
	private static Object[] lkpObj;
	private static DepartmentDetail departmentDetail;
	private static UIExceptionSrcDto uIExceptionSrcDto;
	private static List<NewItemDetail> newItemDetailList;
	private static NewItemDetail newItemDetail;
	private static List<ItemAggregateCorp> itemAggregateCorpList;
	private static ItemAggregateCorp itemAggregateCorp;
	private static List<UPCVo> upcvoList;
	private static UPCVo uPCVo;
	private static List<ItemXrefData> itemXrefDataList;
	private static ItemXrefData itemXrefData;
	private static NewItemDetailPk newItemDetailPk;

	@BeforeAll
	public static void init() {
		resultList = new ArrayList<>();
		lkpObj = new Object[66];
		lkpObj[0] = "W";
		lkpObj[1] = new BigDecimal(10);
		lkpObj[2] = "divisionId ";
		lkpObj[3] = "productSKU";
		lkpObj[4] = "productSrcCd";
		lkpObj[5] = "upcCountry";
		lkpObj[6] = "upcSystem";
		lkpObj[7] = "upcManufacturer";
		lkpObj[8] = "upcSales";
		lkpObj[9] = "PLUcd";
		lkpObj[10] = "companyId";
		resultList.add(lkpObj);
		departmentDetail = new DepartmentDetail();
		departmentDetail.setCompanyId("Safeway");
		departmentDetail.setDivisionId("IND");
		departmentDetail.setDeptCd("IT");
		departmentDetail.setDeptName("Tcs");
		uiExceptionSrcPk = new UiExceptionSrcPk();
		uiExceptionSrcPk.setCompanyId("Safeway");
		uiExceptionSrcPk.setDivisionId("IND");
		uiExceptionSrcs = new ArrayList<>();
		uiExceptionSrc = new UIExceptionSrc();
		uiExceptionSrc.setBatchId(101);
		uiExceptionSrc.setCost(10.50f);
		uiExceptionSrc.setExcptionDesc("Safeway");
		uiExceptionSrc.setItmDesc("item1");
		uiExceptionSrc.setUiSrcPk(uiExceptionSrcPk);
		uiExceptionSrc.setPrmyUpcInd('P');
		uiExceptionSrc.setExcptnProcessdInd('C');
		uiExceptionSrc.setDeptDtl(departmentDetail);
		uiExceptionSrcs.add(uiExceptionSrc);
		uIExceptionSrcDto = new UIExceptionSrcDto();
		uIExceptionSrcDto.setCompanyId("Safeway");
		uIExceptionSrcDto.setDivisionId("any");
		uIExceptionSrcDto.setProductSKU("SKU");
		uIExceptionSrcDto.setExcptnProInd('C');
		shipData = new ArrayList<>();
		salesShip = new SalesShip();
		salesShipPk = new SalesShipPk();
		salesShipPk.setCompanyId("Safeway");
		salesShipPk.setDivisionId("IND");
		salesShip.setSalesShipPk(salesShipPk);
		shipData.add(salesShip);
		newItemDetailList = new ArrayList<>();
		newItemDetailPk = new NewItemDetailPk();
		newItemDetailPk.setCompanyId("Safeway");
		newItemDetailPk.setDivisionId("IND");
		newItemDetail = new NewItemDetail();
		newItemDetail.setCost(10.0f);
		newItemDetail.setBillingType("Monthly");
		newItemDetail.setNewItemPk(newItemDetailPk);
		newItemDetail.setDeptDtl(departmentDetail);
		newItemDetail.setPrmyUpcInd('P');
		newItemDetailList.add(newItemDetail);
		itemAggregateCorpList = new ArrayList<>();
		itemAggregateCorp = new ItemAggregateCorp();
		itemAggregateCorp.setInternetDesc("test");
		itemAggregateCorp.setItemDesc("Store");
		itemAggregateCorpList.add(itemAggregateCorp);
		upcvoList = new ArrayList<>();
		uPCVo = new UPCVo();
		uPCVo.setPrimaryUPCInd('U');
		uPCVo.setUpc("UPC");
		upcvoList.add(uPCVo);
		uIExceptionSrcDto.setUpcVoList(upcvoList);
		itemXrefDataList = new ArrayList<>();
		itemXrefData = new ItemXrefData();
		itemXrefData.setConvStatusCode("ABC");
		itemXrefData.setConvStatusDesc("Approved");
		itemXrefDataList.add(itemXrefData);
	}

	@Test
	public void testGetAllItems() throws Exception {
		when(exceptionRepo.findAll()).thenReturn(uiExceptionSrcs);
		List<UIExceptionSrcDto> UIExceptionList = exceptionSrcServiceImpl.getAllItems();
		assertEquals("IND", UIExceptionList.get(0).getDivisionId());
		assertEquals("Safeway", UIExceptionList.get(0).getCompanyId());
	}

	@Test
	public void testFindByDivision() throws Exception {
		when(exceptionRepo.findByUiSrcPkDivisionId("ABS")).thenReturn(uiExceptionSrcs);
		List<UIExceptionSrcDto> UIExceptionList = exceptionSrcServiceImpl.findByDivision("ABS");
		assertEquals("IND", UIExceptionList.get(0).getDivisionId());
		assertEquals("Safeway", UIExceptionList.get(0).getCompanyId());
	}

	@Test
	public void testFindByUpc() throws Exception {
		UIExceptionSrcDto UIExceptionSrcDto = exceptionSrcServiceImpl.findByUpc(null);
		assertNull(UIExceptionSrcDto);
	}

	@Test
	public void testGetDepartmentWiseData() throws Exception {
		List<Object[]> uiDataVOList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[0] = 10;
		lkpObj[1] = "deptName";
		lkpObj[2] = "deptCode";
		lkpObj[3] = 11;
		lkpObj[4] = 12;
		uiDataVOList.add(lkpObj);
		when(commonSQLRepo.fetchDepartmentWiseExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar())).thenReturn(uiDataVOList);
		when(commonSQLRepo.fetchDepartmentWiseExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar())).thenReturn(uiDataVOList);
		when(commonSQLRepo.fetchDepartmentWiseExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar())).thenReturn(uiDataVOList);
		List<UIDataVO> uiDataVO = exceptionSrcServiceImpl.getDepartmentWiseData("deptName", "deptCode", 'N');
		assertEquals("deptName", uiDataVO.get(0).getDeptName());
	}

	@Test
	public void testGetDepartmentWiseDataExpTypeA() throws Exception {
		List<Object[]> uiDataVOList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[0] = 10;
		lkpObj[1] = "deptName";
		lkpObj[2] = "deptCode";
		lkpObj[3] = 11;
		lkpObj[4] = 12;
		uiDataVOList.add(lkpObj);
		when(commonSQLRepo.fetchDepartmentWiseExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar())).thenReturn(null);
		when(commonSQLRepo.fetchDepartmentWiseExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar())).thenReturn(uiDataVOList);
		when(commonSQLRepo.fetchDepartmentWiseExceptions(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar())).thenReturn(uiDataVOList);
		List<UIDataVO> uiDataVO = exceptionSrcServiceImpl.getDepartmentWiseData("deptName", "deptCode", 'A');
		assertEquals("deptName", uiDataVO.get(0).getDeptName());
	}

	@Test
	public void testGetAugData() throws Exception {
		when(exceptionRepo.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCdAndExcptnProcessdInd(
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar()))
						.thenReturn(uiExceptionSrcs);
		List<UIExceptionSrcDto> UIExceptionList = exceptionSrcServiceImpl.getAugData("Safeway", "IND");
		assertEquals("IND", UIExceptionList.get(0).getDivisionId());
		assertEquals("Safeway", UIExceptionList.get(0).getCompanyId());
	}

	@Test
	public void testFindByProductSKU() throws Exception {
		when(exceptionRepo.findByUiSrcPkProductSKU(Mockito.anyString())).thenReturn(uiExceptionSrc);
		UIExceptionSrcDto uiExceptionSrcDto = exceptionSrcServiceImpl.findByProductSKU("Safeway");
		assertEquals("IND", uiExceptionSrcDto.getDivisionId());
		assertEquals("Safeway", uiExceptionSrcDto.getCompanyId());
	}

	@Test
	public void testLoadItemData() throws Exception {
		when(exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndExcptnTypeCdAndAndExcptnProcessdIndNotOrderByPrmyUpcIndDesc(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
						Mockito.anyChar())).thenReturn(uiExceptionSrcs);
		when(salesShipRepo
				.findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKUAndSalesShipPkUpcCountryAndSalesShipPkUpcSystemAndSalesShipPkUpcManufacturerAndSalesShipPkUpcSales(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(shipData);
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		when(newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkProductSrcCdAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkUpcCountryAndNewItemPkUpcSystemAndNewItemPkUpcManufacturerAndNewItemPkUpcSales(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any())).thenReturn(newItemDetail);
		when(commonSQLRepo.getCICDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultList);
		when(itemXrefRepo.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(itemXrefDataList);
		when(commonSQLRepo.isMarkedForManualMapping(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(resultList);
		AugDataVo augDataVo = exceptionSrcServiceImpl.loadItemData("Safeway", "IND", "Product");
		assertEquals("Safeway", augDataVo.getUiEceptionSrcDto().getCompanyId());
		assertEquals("IND", augDataVo.getUiEceptionSrcDto().getDivisionId());
	}

	@Test
	public void testLoadItemDataByUPC() throws Exception {
		List<Object[]> resultList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[0] = "W";
		lkpObj[1] = "N";
		lkpObj[2] = "divisionId ";
		lkpObj[3] = "productSKU";
		lkpObj[4] = "productSrcCd";
		lkpObj[5] = "upcCountry";
		lkpObj[6] = "upcSystem";
		lkpObj[7] = "upcManufacturer";
		lkpObj[8] = "upcSales";
		lkpObj[9] = "PLUcd";
		lkpObj[10] = "companyId";
		resultList.add(lkpObj);
		when(exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdIndNot(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar()))
								.thenReturn(uiExceptionSrcs);
		when(salesShipRepo
				.findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKUAndSalesShipPkUpcCountryAndSalesShipPkUpcSystemAndSalesShipPkUpcManufacturerAndSalesShipPkUpcSales(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(shipData);
		when(commonSQLRepo.getProduceRelatedData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		AugDataVo augDataVoResult = exceptionSrcServiceImpl.loadItemDataByUPC("Safeway", "IND", "Product-safeway.com");
		assertEquals("Safeway", augDataVoResult.getUiEceptionSrcDto().getCompanyId());
	}

	@Test
	public void testLoadItemDataByUPCElseCheck() throws Exception {
		List<Object[]> resultListIn = new ArrayList<>();
		Object[] lkpObjIn = new Object[66];
		lkpObjIn[0] = "W";
		lkpObjIn[1] = "N";
		lkpObjIn[2] = "divisionId ";
		lkpObjIn[3] = "productSKU";
		lkpObjIn[4] = "productSrcCd";
		lkpObjIn[5] = "upcCountry";
		lkpObjIn[6] = "upcSystem";
		lkpObjIn[7] = "upcManufacturer";
		lkpObjIn[8] = "upcSales";
		lkpObjIn[9] = "PLUcd";
		lkpObjIn[10] = "companyId";
		resultListIn.add(lkpObj);
		when(exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdIndNot(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar()))
								.thenReturn(uiExceptionSrcs);
		when(salesShipRepo
				.findBySalesShipPkDivisionIdAndSalesShipPkCompanyIdAndSalesShipPkProductSKUAndSalesShipPkUpcCountryAndSalesShipPkUpcSystemAndSalesShipPkUpcManufacturerAndSalesShipPkUpcSales(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(shipData);
		when(commonSQLRepo.getProduceRelatedData(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(resultListIn);
		when(commonSQLRepo.loadOnhandStatus(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(resultListIn);
		when(commonSQLRepo.getHigherarchyDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(resultListIn);
		AugDataVo augDataVoResult = exceptionSrcServiceImpl.loadItemDataByUPC("Safeway", "IND", "Product-safeway.com");
		assertEquals("Safeway", augDataVoResult.getUiEceptionSrcDto().getCompanyId());
	}

	@Test
	public void testLoadItemDataByUPCElseCheckElse() throws Exception {
		List<Object[]> resultList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[0] = "E";
		lkpObj[1] = "Y";
		lkpObj[2] = "dvisionId ";
		when(commonSQLRepo.loadOnhandStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		when(commonSQLRepo.getHigherarchyDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(resultList);
		AugDataVo augDataVoResult = exceptionSrcServiceImpl.loadItemDataByUPC("Safeway", "IND", "Product-safeway.com");
		assertNull(augDataVoResult.getUiEceptionSrcDto());
	}

	@Test
	public void testMarkItemComplete() throws Exception {
		when(exceptionRepo.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCd(
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar()))
						.thenReturn(uiExceptionSrcs);
		boolean result = exceptionSrcServiceImpl.markItemComplete(uIExceptionSrcDto, 'A');
		assertEquals(true, result);
	}

	@Test
	public void testLoadOverrideItemData() throws Exception {
		List<ItemXrefData> itemXrefDataListIn = new ArrayList<>();
		ItemXrefData itemXrefDatain = new ItemXrefData();
		itemXrefDatain.setConvStatusCode("ABC");
		itemXrefDatain.setConvStatusDesc("Approved");
		itemXrefDataListIn.add(itemXrefDatain);
		when(exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndExcptnTypeCdAndAndExcptnProcessdIndNotOrderByPrmyUpcIndDesc(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
						Mockito.anyChar())).thenReturn(uiExceptionSrcs);
		when(commonSQLRepo.fetchLikeItemsForMultiUPCs(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		when(commonSQLRepo.loadROGRanking(Mockito.anyString(), Mockito.anyString())).thenReturn(resultList);
		when(newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndExcptnTypeCdOrderByPrmyUpcIndDesc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyChar())).thenReturn(newItemDetailList);
		when(itemXrefRepo.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(itemXrefDataListIn);
		OverrideDataVo overrideDataVo = exceptionSrcServiceImpl.loadOverrideItemData("Safeway", "IND", "Product");
		assertEquals("Safeway", overrideDataVo.getUiEceptionSrcDto().getCompanyId());
		assertEquals("IND", overrideDataVo.getUiEceptionSrcDto().getDivisionId());
	}

	@Test
	public void testLoadOverrideItemDataElse() throws Exception {
		List<ItemXrefData> itemXrefDataListIn = new ArrayList<>();
		ItemXrefData itemXrefDatain = new ItemXrefData();
		itemXrefDatain.setConvStatusCode("ABC");
		itemXrefDatain.setConvStatusDesc("Approved");
		itemXrefDataListIn.add(itemXrefDatain);
		when(exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkProductSKUAndExcptnTypeCdAndAndExcptnProcessdIndNotOrderByPrmyUpcIndDesc(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
						Mockito.anyChar())).thenReturn(uiExceptionSrcs);
		when(commonSQLRepo.fetchLikeItemsForMultiUPCs(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		when(commonSQLRepo.loadROGRanking(Mockito.anyString(), Mockito.anyString())).thenReturn(resultList);
		when(newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndExcptnTypeCdOrderByPrmyUpcIndDesc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyChar())).thenReturn(new ArrayList<>());
		when(itemXrefRepo.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(itemXrefDataListIn);
		OverrideDataVo overrideDataVo = exceptionSrcServiceImpl.loadOverrideItemData("Safeway", "IND", "Product");
		assertEquals("Safeway", overrideDataVo.getUiEceptionSrcDto().getCompanyId());
		assertEquals("IND", overrideDataVo.getUiEceptionSrcDto().getDivisionId());
	}

	@Test
	public void testLoadOverrideItemDataByUPC() throws Exception {
		when(exceptionRepo
				.findByUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndUiSrcPkUpcCountryAndUiSrcPkUpcSystemAndUiSrcPkUpcManufacturerAndUiSrcPkUpcSalesAndExcptnTypeCdAndExcptnProcessdIndNot(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar()))
								.thenReturn(uiExceptionSrcs);
		when(commonSQLRepo.fetchLikeItems(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultList);
		when(commonSQLRepo.loadROGRanking(Mockito.anyString(), Mockito.anyString())).thenReturn(resultList);
		OverrideDataVo overrideDataVo = exceptionSrcServiceImpl.loadOverrideItemDataByUPC("Safeway", "IND",
				"Product safeway.com");
		assertEquals("Safeway", overrideDataVo.getUiEceptionSrcDto().getCompanyId());
		assertEquals("IND", overrideDataVo.getUiEceptionSrcDto().getDivisionId());
	}

	@Test
	public void testLoadDeptExportData() throws Exception {
		when(exceptionRepo
				.findByUiSrcPkCompanyIdAndUiSrcPkDivisionIdAndExcptnTypeCdAndExcptnProcessdIndAndDeptDtlDeptName(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar(),
						Mockito.anyString())).thenReturn(uiExceptionSrcs);
		List<UIExceptionSrcDto> UIExceptionList = exceptionSrcServiceImpl.loadDeptExportData("Safeway", "IND",
				"Product safeway com");
		assertEquals("IND", UIExceptionList.get(0).getDivisionId());
		assertEquals("Safeway", UIExceptionList.get(0).getCompanyId());
	}

	@Test
	public void testLoadProductSKUList() throws Exception {
		when(commonSQLRepo.fetchDepartmentWiseExcpnSKUs(Mockito.anyString(), Mockito.anyString(), Mockito.anyChar(),
				Mockito.anyChar(), Mockito.anyString(), Mockito.anyChar())).thenReturn(stringList);
		List<String> result = exceptionSrcServiceImpl.loadProductSKUList("Safeway", "IND", "Product safeway com", 'A',
				'B', 'C');
		assertNull(result);
	}

	@Test
	public void testGetOnhandStatusNull() throws Exception {
		List<Object[]> resultList = new ArrayList<>();
		when(commonSQLRepo.loadOnhandStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		boolean result = exceptionSrcServiceImpl.getOnhandStatus("Safeway", "IND", "Product safeway com");
		assertEquals(false, result);
	}

	@Test
	public void testGetOnhandStatus() throws Exception {
		when(commonSQLRepo.loadOnhandStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		boolean result = exceptionSrcServiceImpl.getOnhandStatus("Safeway", "IND", "Product safeway com");
		assertEquals(true, result);
	}

	@Test
	public void testRemoveCICRecord() throws Exception {
		UIExceptionSrcDto uiExceptionSrcDto = new UIExceptionSrcDto();
		uiExceptionSrcDto.setCompanyId("Safeway");
		uiExceptionSrcDto.setDivisionId("IND");
		uiExceptionSrcDto.setExcptnProInd('C');
		boolean result = exceptionSrcServiceImpl.removeCICRecord(uiExceptionSrcDto, 'C');
		assertEquals(true, result);
	}

	@Test
	public void testRemoveCICRecordNull() throws Exception {
		when(newItemDetailRepo
				.findByNewItemPkProductSKUAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndExcptnTypeCdOrderByPrmyUpcIndDesc(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar()))
								.thenReturn(newItemDetailList);
		boolean result = exceptionSrcServiceImpl.removeCICRecord(uIExceptionSrcDto, 'C');
		assertEquals(true, result);
	}

	@Test
	public void testGetUOMCodes() throws Exception {
		List<SizeUOMDetail> sizeUomDetailList = new ArrayList<>();
		;
		SizeUOMDetail sizeUOMDetail = new SizeUOMDetail();
		sizeUOMDetail.setUomCode("101");
		sizeUOMDetail.setUomCodeUS("US");
		sizeUomDetailList.add(sizeUOMDetail);
		when(sizeUOMDetailnRepo.findAllByOrderByUomCodeAsc()).thenReturn(sizeUomDetailList);
		List<SizeUOMDetail> result = exceptionSrcServiceImpl.getUOMCodes();
		assertEquals("101", result.get(0).getUomCode());
		assertEquals("US", result.get(0).getUomCodeUS());
	}

	@Test
	public void testGetDepartmentDetails() throws Exception {
		when(commonSQLRepo.getDepartments(Mockito.anyString(), Mockito.anyString())).thenReturn(resultList);
		List<DepartmentDto> result = exceptionSrcServiceImpl.getDepartmentDetails("Safeway", "IND");
		assertEquals(1, result.size());
	}

	@Test
	public void testSaveException() throws Exception {
		ExceptionSrcServiceImpl mock = mock(ExceptionSrcServiceImpl.class);
		mock.saveException(uIExceptionSrcDto);
		when(exceptionRepo.findByUiSrcPkProductSKUAndUiSrcPkDivisionIdAndUiSrcPkCompanyIdAndExcptnTypeCd(
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyChar()))
						.thenReturn(uiExceptionSrcs);
		exceptionSrcServiceImpl.saveException(uIExceptionSrcDto);
		verify(mock).saveException(uIExceptionSrcDto);
	}

	@Test
	public void testSaveItemAggregateCorp() throws Exception {
		ExceptionSrcServiceImpl mock = mock(ExceptionSrcServiceImpl.class);
		when(itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyId(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
								.thenReturn(itemAggregateCorpList);
		mock.saveItemAggregateCorp(uIExceptionSrcDto);
		exceptionSrcServiceImpl.saveItemAggregateCorp(uIExceptionSrcDto);
		verify(mock).saveItemAggregateCorp(uIExceptionSrcDto);
	}

	@Test
	public void testInsertManualMappingRecord() throws Exception {
		ExceptionSrcServiceImpl mock = mock(ExceptionSrcServiceImpl.class);
		mock.insertManualMappingRecord(uIExceptionSrcDto, new BigDecimal(10));
		exceptionSrcServiceImpl.insertManualMappingRecord(uIExceptionSrcDto, new BigDecimal(10));
		verify(mock).insertManualMappingRecord(uIExceptionSrcDto, new BigDecimal(10));
	}

	public void testInsertManualMappingRecordupcList() throws Exception {
		ExceptionSrcServiceImpl mock = mock(ExceptionSrcServiceImpl.class);
		mock.insertManualMappingRecord(uIExceptionSrcDto, new BigDecimal(10));
		exceptionSrcServiceImpl.insertManualMappingRecord(uIExceptionSrcDto, new BigDecimal(10));

		verify(mock).insertManualMappingRecord(uIExceptionSrcDto, new BigDecimal(10));
	}

	@Test
	public void testCheckTargetProdClass() throws Exception {
		List<String> stringListCheck = new ArrayList<>();
		stringListCheck.add("test1");
		stringListCheck.add("84");
		when(commonSQLRepo.getTargetProdClass(Mockito.anyString())).thenReturn(stringListCheck);
		boolean result = exceptionSrcServiceImpl.checkTargetProdClass("test1", "84");
		assertEquals(false, result);
	}

	@Test
	public void testCheckTargetProdClassElse() throws Exception {
		List<String> stringListCheck = new ArrayList<>();
		stringListCheck.add("84");
		stringListCheck.add("84");
		when(commonSQLRepo.getTargetProdClass(Mockito.anyString())).thenReturn(stringListCheck);
		boolean result = exceptionSrcServiceImpl.checkTargetProdClass("84", "84");
		assertEquals(true, result);
	}

	@Test
	public void testCheckTargetProdClassElseTrue() throws Exception {
		List<String> stringListCheck = new ArrayList<>();
		stringListCheck.add("84");
		stringListCheck.add("test");
		when(commonSQLRepo.getTargetProdClass(Mockito.anyString())).thenReturn(stringListCheck);
		boolean result = exceptionSrcServiceImpl.checkTargetProdClass("84", "test");
		assertEquals(true, result);
	}
	
	@Test
	public void testLoadNewItemRecord() throws Exception {
		Method method = ExceptionSrcServiceImpl.class.getDeclaredMethod("loadNewItemRecord", UIExceptionSrcDto.class);
		method.setAccessible(true);
		UIExceptionSrcDto uiExceptionSrcDto = new UIExceptionSrcDto();
		uiExceptionSrcDto.setDivisionId("Ind");
		uiExceptionSrcDto.setCompanyId("Safeway");
		uiExceptionSrcDto.setProductSKU("SKU");
		uiExceptionSrcDto.setProductSrcCd("srccd");
		uiExceptionSrcDto.setUpcCountry("abc");
		uiExceptionSrcDto.setUpcManufacturer("Production");
		uiExceptionSrcDto.setUpcSales("Sales");
		uiExceptionSrcDto.setUpcSystem("Upc system");
		when(newItemDetailRepo.findByNewItemPkProductSKUAndNewItemPkProductSrcCdAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkUpcCountryAndNewItemPkUpcSystemAndNewItemPkUpcManufacturerAndNewItemPkUpcSales
				(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), 
						Mockito.anyString(), Mockito.anyString())).thenReturn(newItemDetail);
		method.invoke(exceptionSrcServiceImpl, uiExceptionSrcDto);
		assertEquals("Safeway", uiExceptionSrcDto.getCompanyId());
	}
	
	@Test
	public void testSetValidDeptwisedata() throws Exception {
		Method method = ExceptionSrcServiceImpl.class.getDeclaredMethod("setValidDeptwisedata", List.class);
		method.setAccessible(true);
		method.invoke(exceptionSrcServiceImpl, uiExceptionSrcs);
		assertEquals("Safeway", uiExceptionSrcs.get(0).getExcptionDesc());
	}
	
	@Test
	public void testAugItemCheckinDb() throws Exception {
		Method method = ExceptionSrcServiceImpl.class.getDeclaredMethod("augItemCheckinDb", UIExceptionSrcDto.class);
		method.setAccessible(true);
		UIExceptionSrcDto uiExceptionSrcDtoDb = new UIExceptionSrcDto();
		uiExceptionSrcDtoDb.setDivisionId("Ind");
		uiExceptionSrcDtoDb.setCompanyId("Safeway");
		uiExceptionSrcDtoDb.setProductSKU("SKU");
		uiExceptionSrcDtoDb.setProductSrcCd("srccd");
		uiExceptionSrcDtoDb.setUpcCountry("abc");
		uiExceptionSrcDtoDb.setUpcManufacturer("Production");
		uiExceptionSrcDtoDb.setUpcSales("Sales");
		uiExceptionSrcDtoDb.setUpcSystem("Upc system");
		uiExceptionSrcDtoDb.setExcptnProInd('C');
		uiExceptionSrcDtoDb.setItmDescrbtn("producer with java implementaion we choose rest proxy");
		List<ItemXrefData> xrefRecord = new ArrayList<>();
		ItemXrefData itemXrefData = new ItemXrefData();
		itemXrefData.setConvStatusCode("D");
		itemXrefData.setConvStatusDesc("Approved");
		itemXrefData.setConvStatusSubCode("B");
		xrefRecord.add(itemXrefData);
		List<Object[]> cicDetails = new ArrayList<>();
		Object[] record = new Object[66];
		record[0] = "W";
		record[1] = 'A';
		record[2] = 'B';
		record[3] = 'C';
		record[4] = new BigDecimal(10);
		record[5] = new BigDecimal(10);
		record[6] = new BigDecimal(10);
		record[7] = new BigDecimal(10);
		record[8] = new BigDecimal(10);
		record[9] = new BigDecimal(10);
		record[10] = new BigDecimal(10);
		record[11] = new BigDecimal(10);
		cicDetails.add(record); 
		when(newItemDetailRepo.findByNewItemPkProductSKUAndNewItemPkProductSrcCdAndNewItemPkDivisionIdAndNewItemPkCompanyIdAndNewItemPkUpcCountryAndNewItemPkUpcSystemAndNewItemPkUpcManufacturerAndNewItemPkUpcSales
				(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), 
						Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		when(commonSQLRepo.getCICDetails
				(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(cicDetails);
		when(itemXrefRepo
				.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionId
				(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(xrefRecord);
		method.invoke(exceptionSrcServiceImpl, uiExceptionSrcDtoDb);
		assertEquals("Safeway", uiExceptionSrcDtoDb.getCompanyId());
	}


}