/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.memi.domain.services.SourceItemService;

@WebMvcTest(controllers = SourceItemController.class)
public class SourceItemControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private SourceItemService sourceItemService;

	@Test
	public void testGetAllSourceItems() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/sourceItems/list")).andExpect(status().isOk());
	}

}
