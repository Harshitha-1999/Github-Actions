/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.adapters;

import static org.junit.jupiter.api.Assertions.assertEquals;

/* ***************************************************************************
 * NAME : ViewFieldsAdapterTest 
 * SYSTEM : MEMI 
 * AUTHOR : TCS
 * REVISION HISTORY
 * Revision 0.0.0.1 Dec 10, 2021 - Initial Creation
 * *************************************************************************
 */
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.data.entities.SalesShip;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.SalesData;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UInewItemVO;
import com.safeway.app.memi.domain.util.BakeryActionValidations;

@SpringBootTest(classes = BakeryActionValidations.class)
public class ViewFieldsAdapterTest {

	private ViewFieldsAdapter viewFieldsAdater = new ViewFieldsAdapter();

	@Test
	public void testBuildLikeItemDetailDtoList() {
		Object[] srcObj = new Object[50];
		List<Object[]> likeItemObjList = new ArrayList<>();
		likeItemObjList.add(srcObj);
		likeItemObjList.add(srcObj);
		UIExceptionSrcDto excSrcDto = new UIExceptionSrcDto();
		List<NewItemDetailDto> srcList = viewFieldsAdater.buildLikeItemDetailDtoList(likeItemObjList, excSrcDto);
		srcObj[0] = new BigDecimal(10);
		srcObj[1] = "";
		srcObj[2] = "";
		srcObj[3] = "";
		srcObj[4] = "";
		srcObj[5] = "";
		srcObj[6] = new BigDecimal(10);
		srcObj[7] = new BigDecimal(10);
		srcObj[8] = 'a';
		srcObj[9] = 'a';
		srcObj[10] = 'a';
		srcObj[11] = new BigDecimal(10);
		srcObj[12] = new BigDecimal(10);
		srcObj[13] = new BigDecimal(10);
		srcObj[14] = new BigDecimal(10);
		srcObj[15] = new BigDecimal(10);
		srcObj[16] = "";
		srcObj[17] = "";
		srcObj[18] = 'a';
		srcObj[19] = new BigDecimal(10);
		srcObj[20] = "";
		srcObj[21] = 'a';
		srcObj[22] = "";
		srcObj[23] = new BigDecimal(10);
		srcObj[24] = "";
		srcObj[25] = "";
		srcObj[26] = "";
		srcObj[27] = 'a';
		srcObj[28] = "";
		srcObj[29] = 'a';
		srcObj[30] = new Date();
		srcObj[31] = "";
		srcObj[32] = "";
		srcObj[36] = new BigDecimal(10);
		srcObj[37] = new BigDecimal(10);
		srcObj[38] = new BigDecimal(10);
		srcObj[39] = new BigDecimal(10);
		srcObj[33] = 'a';
		srcList = viewFieldsAdater.buildLikeItemDetailDtoList(likeItemObjList, excSrcDto);
		assertEquals(new BigDecimal(10), srcList.get(0).getDtaOverCic());
	}

	@Test
	public void testUInewItemObjtoDto() {
		UInewItemVO updObj = new UInewItemVO();
		updObj.setCtgryCd(12);
		UIExceptionSrc srcObj = new UIExceptionSrc();
		UiExceptionSrcPk exceptionSrcPk = new UiExceptionSrcPk();
		srcObj.setUiSrcPk(exceptionSrcPk);
		NewItemDetailDto newItemDto = viewFieldsAdater.UInewItemObjtoDto(updObj, srcObj);
		assertEquals(12, newItemDto.getCtgryCd());
	}

	@Test
	public void testMapToSalesData() {
		SalesShip salesShip = new SalesShip();
		salesShip.setTotalSales(new BigDecimal(10));
		SalesData salesDataDto = viewFieldsAdater.mapToSalesData(salesShip);
		assertEquals(new BigDecimal(10), salesDataDto.getTotalSales());
	}

	@Test
	public void testMapAddnlDetailsOnDto() {
		NewItemDetailDto newItemDto = new NewItemDetailDto();
		newItemDto.setPullBydays("pullBydays");
		UIExceptionSrcDto uiExceptionSrcDto = new UIExceptionSrcDto();
		Object[] obj = new Object[50];
		List<Object[]> addtionDetailsObj = Collections.singletonList(obj);
		uiExceptionSrcDto.setDspFlag('A');
		uiExceptionSrcDto.setProductSrcCd("W");
		uiExceptionSrcDto.setSelling_method_cd("POUND");
		uiExceptionSrcDto.setUpcSystem("2");
		uiExceptionSrcDto.setUpcCountry("0");
		uiExceptionSrcDto.setUpcLIst(Collections.singletonList("12-12"));
		obj[1] = "Y";
		obj[2] = "S";
		obj[4] = "S";
		obj[8] = "I";
		obj[9] = "Y";
		obj[10] = "S";
		obj[11] = "S";
		obj[12] = "Y";
		NewItemDetailDto newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto,
				addtionDetailsObj);
		newItemDto.setRandomWtCd("randomWtCd");
		newItemDto.setAutoCostInv("autoCostInv");
		newItemDto.setBillingType("billingType");
		uiExceptionSrcDto.setSelling_method_cd("EACH");
		viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		obj[1] = "N";
		newItemDto.setProdwght("prodwght");
		obj[2] = "T";
		obj[4] = "T";
		obj[8] = "S";
		obj[9] = "N";
		obj[12] = "N";
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		newItemDto.setRandomWtCd(null);
		newItemDto.setAutoCostInv(null);
		obj[12] = "O";
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		obj[1] = "R";
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		newItemDto.setRandomWtCd("randomWtCd");
		newItemDto.setAutoCostInv("autoCostInv");
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		uiExceptionSrcDto.setProductSrcCd("D");
		newItemDto.setBillingType("billingType");
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		newItemDto.setRandomWtCd(null);
		newItemDto.setAutoCostInv(null);
		newItemDto.setBillingType(null);
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		uiExceptionSrcDto.setDspFlag('Y');
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		newItemDto.setRandomWtCd("randomWtCd");
		newItemDto.setProdwght("autoCostInv");
		newItemDto.setAutoCostInv("billingType");
		newItemDto.setLabelSize("labelSize");
		newItemDto.setLabelNumbers("labelNumbers");
		newItemDto.setSgnCount1("sgnCount1");
		newItemDto.setSgnCount2("sgnCount2");
		newItemDto.setSgnCount3("sgnCount3");
		newItemDto.setRing("ring");
		newItemDetailDto = viewFieldsAdater.mapAddnlDetailsOnDto(newItemDto, uiExceptionSrcDto, addtionDetailsObj);
		assertEquals("pullBydays", newItemDetailDto.getPullBydays());
	}

}
