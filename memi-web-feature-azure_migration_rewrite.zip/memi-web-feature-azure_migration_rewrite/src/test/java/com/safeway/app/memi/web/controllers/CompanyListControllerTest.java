/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.memi.domain.services.CompanyService;

@WebMvcTest(controllers = CompanyListController.class)
public class CompanyListControllerTest {

	@MockBean
	private CompanyService companyService;
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testGetCompaniesList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/company/list")).andExpect(status().isOk());

	}

}
