/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.web.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.ManualMatchAdtnlFieldLoadInputVo;
import com.safeway.app.memi.domain.dtos.response.PerishableCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.PerishableItemTypeVO;
import com.safeway.app.memi.domain.dtos.response.PerishableMatchingTargetInputVO;
import com.safeway.app.memi.domain.dtos.response.PerishableSearchRequestVO;
import com.safeway.app.memi.domain.services.PerishableMappingServices;

/**
 ****************************************************************************
 * NAME : PerishableMappingLoadControllerTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Dec 01, 2021 - Initial Creation
 * *************************************************************************
 */

@WebMvcTest(controllers = PerishableMappingLoadController.class)
public class PerishableMappingLoadControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private PerishableMappingServices perishableMappingServices;

	@Test
	public void testListSourceData() throws Exception {
		PerishableSearchRequestVO searchRequestVO = new PerishableSearchRequestVO();
		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/sourceList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());
		PerishableItemTypeVO perishableItemTypeVO = new PerishableItemTypeVO();
		perishableItemTypeVO.setSystem4(true);
		searchRequestVO.setCompanyID("companyID");
		searchRequestVO.setDivisionID("divisionID");
		searchRequestVO.setItemType(perishableItemTypeVO);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/sourceList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());
		perishableItemTypeVO.setSystem4(false);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/sourceList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());
	}

	@Test
	public void testListTargetData() throws Exception {
		PerishableSearchRequestVO searchRequestVO = new PerishableSearchRequestVO();
		PerishableItemTypeVO perishableItemTypeVO = new PerishableItemTypeVO();
		perishableItemTypeVO.setSystem4(true);
		searchRequestVO.setCompanyID("companyID");
		searchRequestVO.setDivisionID("divisionID");
		searchRequestVO.setItemType(perishableItemTypeVO);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/targetList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());
		perishableItemTypeVO.setSystem4(false);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/targetList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());

	}

	@Test
	public void testListMappedData() throws Exception {
		PerishableSearchRequestVO searchRequestVO = new PerishableSearchRequestVO();

		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/mappedList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());
		PerishableItemTypeVO perishableItemTypeVO = new PerishableItemTypeVO();
		perishableItemTypeVO.setSystem4(true);
		searchRequestVO.setCompanyID("companyID");
		searchRequestVO.setDivisionID("divisionID");
		searchRequestVO.setItemType(perishableItemTypeVO);

		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/mappedList").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(searchRequestVO)))
				.andExpect(status().isOk());
	}

	@Test
	public void getDepartmentDetailsForSource() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/perishable/listDepartmentSource/company/division"))
				.andExpect(status().isOk());
	}

	@Test
	public void getDepartmentDetailsForTarget() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/perishable/listDepartmentTarget/company/division"))
				.andExpect(status().isOk());
	}

	@Test
	public void getUpcListDetails() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/upcList").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new Object[1]))).andExpect(status().isOk());
	}

	@Test
	public void testGetMatchingTargetList() throws Exception {
		PerishableMatchingTargetInputVO targetInputVo = new PerishableMatchingTargetInputVO();
		List<PerishableCICSearchResults> perishableCICSearchResults = new ArrayList<>();
		when(perishableMappingServices.getSuggestedTargetList(Mockito.any())).thenReturn(perishableCICSearchResults);
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/matchingTargetList")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(targetInputVo))).andExpect(status().isOk());

		PerishableCICSearchResults cicSearchResults = new PerishableCICSearchResults();
		perishableCICSearchResults.add(cicSearchResults);
		when(perishableMappingServices.getSuggestedTargetList(Mockito.any())).thenReturn(perishableCICSearchResults);
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/matchingTargetList")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(targetInputVo))).andExpect(status().isOk());
	}

	@Test
	public void getadditionalRetailscanDetails() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/additionalTargetRetailsScanList")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new String("")))).andExpect(status().isOk());
	}

	@Test
	public void getMappedUpcListDetails() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/mappedUpcListDetails")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new Object[1]))).andExpect(status().isOk());
	}

	@Test
	public void testLoadOnMapEditFields() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/loadOnMapEditFields")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ManualMatchAdtnlFieldLoadInputVo())))
				.andExpect(status().isOk());
	}

}
