/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

/* ***************************************************************************
 * NAME : CompanyServiceImpl 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Subhash G
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 May 03, 2017 - sgang06 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.Company;
import com.safeway.app.memi.data.repositories.CompanyRepository;
import com.safeway.app.memi.domain.dtos.response.CompanyDto;
import com.safeway.app.memi.domain.services.impl.CompanyServiceImpl;

@SpringBootTest(classes = CompanyServiceImpl.class)
public class CompanyServiceImplTest {

    @MockBean
    private CompanyRepository companyRepo;
    @Autowired
    private CompanyServiceImpl companyServiceImpl;
    
	@Test
	public void testGetAllItems() {
		List<Company> companys = new ArrayList<>();
		Company company = new Company();
		company.setCompanyId("companyId");
		companys.add(company);
		when(companyRepo.findAll()).thenReturn(companys);
		List<CompanyDto> companyDtos = companyServiceImpl.getAllItems();
		assertEquals("companyId", companyDtos.get(0).getCompanyID());
	}

}
