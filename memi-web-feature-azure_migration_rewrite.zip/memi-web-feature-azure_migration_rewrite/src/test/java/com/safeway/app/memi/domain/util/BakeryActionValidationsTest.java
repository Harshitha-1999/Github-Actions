package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.BakeryMappingRequest;

@SpringBootTest(classes = BakeryActionValidations.class)
public class BakeryActionValidationsTest {

	@Autowired
	private BakeryActionValidations bakeryActionValidation;

	@Test
	public void validateActions() {
		BakeryMappingRequest bakeryMappingRequest = new BakeryMappingRequest();
		bakeryMappingRequest.setMappingType(PerishableConstants.INHERIT_MAP);
		bakeryMappingRequest.setSku("sku");
		bakeryMappingRequest.setTargetTypeIndicator("targetTypeIndicator");
		bakeryMappingRequest.setTargetEdited(true);
		bakeryMappingRequest.setDcPackDesc("dcPackDesc");
		bakeryMappingRequest.setDcSizeDsc("dcSizeDsc");
		bakeryMappingRequest.setRetailUnitPack("retailUnitPack");
		bakeryMappingRequest.setRing("ring");
		bakeryMappingRequest.setHicone("hicone");
		bakeryMappingRequest.setProdwght("prodwght");
		bakeryMappingRequest.setHandlingCode("handlingCode");
		bakeryMappingRequest.setBuyerNum("buyerNum");
		bakeryMappingRequest.setRandomWtCd("randomWtCd");
		bakeryMappingRequest.setAutoCostInv("autoCostInv");
		bakeryMappingRequest.setBillingType("billingType");
		bakeryMappingRequest.setFdStmp("fdStmp");
		bakeryMappingRequest.setTareCd("tareCd");
		bakeryMappingRequest.setLabelSize("labelSize");
		bakeryMappingRequest.setLabelNumbers("labelNumbers");
		bakeryMappingRequest.setSgnCount1("sgnCount1");
		bakeryMappingRequest.setSgnCount2("sgnCount2");
		bakeryMappingRequest.setSgnCount3("sgnCount3");
		bakeryMappingRequest.setPrcTypeCd("prcTypeCd");
		bakeryMappingRequest.setCostAllow("costAllow");
		bakeryMappingRequest.setCostInv("costInv");
		bakeryMappingRequest.setCostIb("costIb");
		bakeryMappingRequest.setCostVend("costVend");
		bakeryMappingRequest.setSellByDays("sellByDays");
		bakeryMappingRequest.setUseByDays("useByDays");
		bakeryMappingRequest.setPullBydays("pullBydays");
		List<BakeryMappingRequest> bakeryMappingRequestsBuyer = new ArrayList<>();
		bakeryMappingRequestsBuyer.add(bakeryMappingRequest);
		List<BakeryMappingRequest> bakeryMappingRequestsSeller = Collections.singletonList(bakeryMappingRequest);
		List<String> strings = bakeryActionValidation.validateActions(bakeryMappingRequestsBuyer,
				bakeryMappingRequestsSeller);
		assertEquals("Prod Weight is not a number in the prescribed format ", strings.get(0));
		BakeryMappingRequest bakeryMappingRequest1 = new BakeryMappingRequest();
		bakeryMappingRequest.setMappingType(PerishableConstants.LET_AUTO_MATCH);
		bakeryMappingRequest1.setMappingType(PerishableConstants.MARK_AS_DEAD);
		bakeryMappingRequest1.setSku("sku");
		bakeryMappingRequest1.setTargetTypeIndicator("targetTypeIndicator");
		bakeryMappingRequest1.setTargetEdited(true);
		bakeryMappingRequest1.setDcPackDesc("dcPackDesc");
		bakeryMappingRequest1.setDcSizeDsc("dcSizeDsc");
		bakeryMappingRequest1.setRetailUnitPack("retailUnitPack");
		bakeryMappingRequest1.setRing("ring");
		bakeryMappingRequest1.setHicone("hicone");
		bakeryMappingRequest1.setProdwght("prodwght");
		bakeryMappingRequest1.setHandlingCode("handlingCode");
		bakeryMappingRequest1.setBuyerNum("buyerNum");
		bakeryMappingRequest1.setCic("cic");
		bakeryMappingRequest1.setRandomWtCd("randomWtCd");
		bakeryMappingRequest1.setAutoCostInv("autoCostInv");
		bakeryMappingRequest1.setBillingType("billingType");
		bakeryMappingRequest1.setFdStmp("fdStmp");
		bakeryMappingRequest1.setTareCd("tareCd");
		bakeryMappingRequest1.setLabelSize("labelSize");
		bakeryMappingRequest1.setLabelNumbers("labelNumbers");
		bakeryMappingRequest1.setSgnCount1("sgnCount1");
		bakeryMappingRequest1.setSgnCount2("sgnCount2");
		bakeryMappingRequest1.setSgnCount3("sgnCount3");
		bakeryMappingRequest1.setPrcTypeCd("prcTypeCd");
		bakeryMappingRequest1.setCostAllow("costAllow");
		bakeryMappingRequest1.setCostInv("costInv");
		bakeryMappingRequest1.setCostIb("costIb");
		bakeryMappingRequest1.setCostVend("costVend");
		bakeryMappingRequest1.setSellByDays("sellByDays");
		bakeryMappingRequest1.setUseByDays("useByDays");
		bakeryMappingRequest1.setPullBydays("pullBydays");
		bakeryMappingRequestsBuyer.add(bakeryMappingRequest1);
		bakeryActionValidation.validateActions(bakeryMappingRequestsBuyer,
				bakeryMappingRequestsSeller);
		bakeryMappingRequest1.setMappingType(PerishableConstants.RESERVED);
		bakeryMappingRequest1.setMappingstatus("mappingstatus");
		bakeryActionValidation.validateActions(bakeryMappingRequestsBuyer,
				bakeryMappingRequestsSeller);
	}

}
