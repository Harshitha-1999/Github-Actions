package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.LookUpSearchObjectTemplate;
import com.safeway.app.memi.data.repositories.LookUpSearchRepository;
import com.safeway.app.memi.data.repositories.LookUpSearchTemplateRepository;
import com.safeway.app.memi.domain.adapters.LookUpScreenAdapter;
import com.safeway.app.memi.domain.dtos.response.LookUpActionRequest;
import com.safeway.app.memi.domain.dtos.response.LookUpCustomizationVO;
import com.safeway.app.memi.domain.dtos.response.LookUpScreenLoadVO;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchInputs;
import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultWrapper;
import com.safeway.app.memi.domain.services.impl.LookUpServiceImpl;

@SpringBootTest(classes = LookUpServiceImpl.class)
public class LookUpServiceImplTest {

	@Autowired
	private LookUpServiceImpl lookUpServiceImpl;
	@MockBean
	private LookUpSearchRepository lookUpSearchRepository;
	@MockBean
	private LookUpSearchTemplateRepository templateRepo;
	@MockBean
	private LookUpScreenAdapter lookUpScreenAdapter;

	private static List<Object[]> resultList;
	private static Object[] lkpObj;
	private static List<LookUpSearchObjectTemplate> template;
	private static LookUpSearchObjectTemplate lookUpSearchObjectTemplate;
	private static LookUpSearchInputs lookUpSearchInputs;
	private static LookUpCustomizationVO lookUpCustomizationVO;
	private static boolean executionresult;
	private static List<LookUpActionRequest> lookUpActionRequestList;
	private static LookUpActionRequest lookUpActionRequest;

	@BeforeAll
	public static void init() {
		resultList = new ArrayList<>();
		lkpObj = new Object[66];
		lkpObj[0] = "Safeway";
		lkpObj[1] = new BigDecimal(10);
		lkpObj[2] = "divisionId ";
		resultList.add(lkpObj);
		template = new ArrayList<>();
		lookUpSearchObjectTemplate = new LookUpSearchObjectTemplate();
		lookUpSearchObjectTemplate.setUserId("safeway@123");
		template.add(lookUpSearchObjectTemplate);
		lookUpSearchInputs = new LookUpSearchInputs();
		lookUpSearchInputs.setCompanyId("safeway");
		lookUpSearchInputs.setStartIndex("1");
		lookUpSearchInputs.setEndIndex("10");
		lookUpSearchInputs.setItemType("REG");
		lookUpSearchInputs.setProductSKU("Product");
		lookUpSearchInputs.setItemDescription("Des");
		lookUpSearchInputs.setConversionGroupCd("Conversion");
		lookUpSearchInputs.setProdHierarchyLvl1Cd("1");
		lookUpSearchInputs.setProdHierarchyLvl2Cd("2");
		lookUpSearchInputs.setProdHierarchyLvl3Cd("3");
		lookUpSearchInputs.setProdHierarchyLvl4Cd("4");
		lookUpSearchInputs.setProdHierarchyLvl5Cd("Lv5");
		lookUpSearchInputs.setPlu("PLU");
		lookUpSearchInputs.setUpc("UPC");
		lookUpSearchInputs.setSupplierName("safeway");
		lookUpSearchInputs.setSupplierNum("10");
		lookUpSearchInputs.setCorpItemCd("A");
		lookUpSearchInputs.setConversionStatus("AB-CD-EF");
		lookUpSearchInputs.setSupplyType("E");
		lookUpSearchInputs.setProducthierarchyName("Product");
		lookUpCustomizationVO = new LookUpCustomizationVO();
		lookUpCustomizationVO.setUserId("safeway@123");
		executionresult = true;
		lookUpActionRequestList = new ArrayList<>();
		lookUpActionRequest = new LookUpActionRequest();
		lookUpActionRequest.setCompanyId("Safeway");
		lookUpActionRequest.setDivisionId("Div");
		lookUpActionRequest.setChangestatusCd("READY");
		lookUpActionRequest.setCurrentStatusCd("Current");
		lookUpActionRequest.setProductSKU("SKU");
		lookUpActionRequest.setStatusReasonComments("Reason");
		lookUpActionRequest.setUpc(null);
		lookUpActionRequestList.add(lookUpActionRequest);

	}

	@Test
	public void testLookUpScreenLoad() throws Exception {
		when(lookUpSearchRepository.fetchAllConvGroups(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultList);
		when(templateRepo.findByUserId(Mockito.anyString())).thenReturn(template);
		LookUpScreenLoadVO result = lookUpServiceImpl.lookUpScreenLoad("Safeway", "IND", "safeway@123");
		assertNotNull(result);
	}

	@Test
	public void testSaveLookUpCostomization() throws Exception {
		when(templateRepo.saveAndFlush(Mockito.any())).thenReturn(null);
		assertNull(lookUpServiceImpl.saveLookUpCostomization(lookUpCustomizationVO));
	}

	@Test
	public void testFetchLookUpResult() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}

	@Test
	public void testPerformStatusChanges() throws Exception {
		when(lookUpSearchRepository.updateProductStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
						.thenReturn(executionresult);
		List<String> result = lookUpServiceImpl.performStatusChanges(lookUpActionRequestList, "Test");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testFetchLookUpResultCaseDIT() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("DIT");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCasePlu() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("PLU");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCaseSYS2() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("SYS2");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCaseSYS4() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("SYS4");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCaseEXP() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("EXP");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCaseMTE() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("MTE");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCaseMUT() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("MUT");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
	
	@Test
	public void testFetchLookUpResultCaseMUL() throws Exception {
		when(lookUpSearchRepository.fetchLookUpSearchResult(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(),
				Mockito.any())).thenReturn(resultList);
		lookUpSearchInputs.setItemType("MUL");
		LookUpSearchResultWrapper result = lookUpServiceImpl.fetchLookUpResult(lookUpSearchInputs);
		assertEquals(new BigDecimal(1), result.getStart_index());
		assertEquals(new BigDecimal(10), result.getEnd_index());
	}
}