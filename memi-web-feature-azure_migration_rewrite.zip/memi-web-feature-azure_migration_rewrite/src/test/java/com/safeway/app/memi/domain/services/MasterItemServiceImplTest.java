package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.ItemXrefPk;
import com.safeway.app.memi.data.repositories.MasterDataRepository;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.dtos.response.UPCVo;
import com.safeway.app.memi.domain.services.impl.MasterItemServiceImpl;

@SpringBootTest(classes = MasterItemServiceImpl.class)
public class MasterItemServiceImplTest {

	@Autowired
	private MasterItemServiceImpl masterItemServiceImpl;
	@MockBean
	private MasterDataRepository masterDataRepo;

	private static List<UPCVo> volist;
	private static UPCVo uPCVo;
	private static UIExceptionSrcDto uIExceptionSrcDto;
	private static List<ItemXrefData> itemXrefDataList;
	private static ItemXrefData itemXrefData;
	private static ItemXrefPk itemXrefPk;

	@BeforeAll
	public static void init() {
		volist = new ArrayList<>();
		uPCVo = new UPCVo();
		uPCVo.setPrimaryUPCInd('P');
		uPCVo.setUpc("111-222-333-4444-55555-6666");
		volist.add(uPCVo);
		uIExceptionSrcDto = new UIExceptionSrcDto();
		uIExceptionSrcDto.setCompanyId("safe");
		uIExceptionSrcDto.setUpcVoList(volist);
		uIExceptionSrcDto.setBtId(1);
		uIExceptionSrcDto.setCasesOrdered(new BigDecimal(10));
		uIExceptionSrcDto.setCaseUPC("case");
		uIExceptionSrcDto.setCategoryDesc("Catogory");
		uIExceptionSrcDto.setClsCd(1);
		uIExceptionSrcDto.setConvGroupCd("Group");
		uIExceptionSrcDto.setConvGroupNm("Com");
		uIExceptionSrcDto.setConvTeamComments("Yearly");
		uIExceptionSrcDto.setCost("1000");
		uIExceptionSrcDto.setDivisionId("Ind");
		uIExceptionSrcDto.setProductSKU("SKU");
		itemXrefDataList = new ArrayList<>();
		itemXrefData = new ItemXrefData();
		itemXrefData.setConvStatusCode("C");
		itemXrefData.setConvStatusDesc("D");
		itemXrefData.setConvStatusSubCode("Sub");
		itemXrefData.setStatusReasonText("Text");
		itemXrefData.setUpdatedUserId("Update");
		itemXrefDataList.add(itemXrefData);
		itemXrefPk = new ItemXrefPk();
		itemXrefPk.setCompanyId("safeway");
		itemXrefPk.setDivisionId("IND");
		itemXrefPk.setProdSku("Pro");
		itemXrefPk.setRog("Rog");
		itemXrefPk.setSrcSupplierNum("TCS");
		itemXrefPk.setUpcCountry(1);
		itemXrefPk.setUpcManu(10);
		itemXrefPk.setUpcSales(2);
		itemXrefPk.setUpcSystem(3);
		itemXrefData.setItemPk(itemXrefPk);

	}

	@Test
	public void testKillItem() throws Exception {
		when(masterDataRepo
				.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionIdAndItemPkUpcCountryAndItemPkUpcSystemAndItemPkUpcManuAndItemPkUpcSales(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
						Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(itemXrefDataList);
		boolean result = masterItemServiceImpl.killItem(uIExceptionSrcDto, "123456");
		assertEquals(false, result);

	}

	@Test
	public void testUpdateItemStatusXRF() throws Exception {
		when(masterDataRepo
				.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionIdAndItemPkUpcCountryAndItemPkUpcSystemAndItemPkUpcManuAndItemPkUpcSales(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
						Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(itemXrefDataList);
		boolean result = masterItemServiceImpl.updateItemStatusXRF(uIExceptionSrcDto, "A");
		assertEquals(false, result);
	}

	@Test
	public void testUpdateItemStatusXRFReasonO() throws Exception {
		when(masterDataRepo
				.findByItemPkProdSkuAndItemPkCompanyIdAndItemPkDivisionIdAndItemPkUpcCountryAndItemPkUpcSystemAndItemPkUpcManuAndItemPkUpcSales(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
						Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(itemXrefDataList);
		boolean result = masterItemServiceImpl.updateItemStatusXRF(uIExceptionSrcDto, "O");
		assertEquals(false, result);
	}
}