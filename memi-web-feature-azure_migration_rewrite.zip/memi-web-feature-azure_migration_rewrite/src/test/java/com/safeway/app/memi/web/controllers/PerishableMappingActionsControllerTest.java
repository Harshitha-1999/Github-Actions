package com.safeway.app.memi.web.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceUPC;
import com.safeway.app.memi.domain.dtos.response.ManualExpeseTypeChangeRequest;
import com.safeway.app.memi.domain.dtos.response.PerishableItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequest;
import com.safeway.app.memi.domain.dtos.response.PerishableMappingRequestWrapper;
import com.safeway.app.memi.domain.dtos.response.PerishableSearchRequestVO;
import com.safeway.app.memi.domain.services.PerishableMappingServices;
import com.safeway.app.memi.domain.util.ActionValidations;

/**
 ****************************************************************************
 * NAME : PerishableMappingActionsControllerTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Dec 01, 2021 - Initial Creation
 * *************************************************************************
 */

@WebMvcTest(controllers = PerishableMappingActionsController.class)
public class PerishableMappingActionsControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private PerishableMappingServices perishableMappingServices;
	@MockBean
	private ActionValidations actionValidations;
	private static PerishableMappingRequest perishableMappingRequest;
	private static PerishableMappingRequestWrapper perishableMappingRequestWrapper = new PerishableMappingRequestWrapper();

	@BeforeAll
	public static void init() {
		perishableMappingRequest = new PerishableMappingRequest();
		perishableMappingRequest.setMappingType("INHERIT_MAP");
		perishableMappingRequestWrapper.setMappedSearchRequest(new PerishableSearchRequestVO());
		perishableMappingRequestWrapper.setMappingrequest(Collections.singletonList(perishableMappingRequest));
		ManualExpeseTypeChangeRequest expenseChangeRequest = new ManualExpeseTypeChangeRequest();
		expenseChangeRequest.setExpenseTypeCurrent("expenseTypeCurrent");
		perishableMappingRequestWrapper.setExpenseChangeRequest(Collections.singletonList(expenseChangeRequest));
	}

	@Test
	public void testPerishableAction() throws Exception {
		perishableMappingRequestWrapper.setFromMappedScreen(true);
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/actions").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableMappingRequestWrapper)))
				.andExpect(status().isOk());
		when(perishableMappingServices
						.listCICPerishableItems(Mockito.any())).thenReturn(new PerishableSearchRequestVO());
		perishableMappingRequestWrapper.setFromMappedScreen(false);
		perishableMappingRequestWrapper.setSourceSearchRequest(new PerishableSearchRequestVO());
		perishableMappingRequestWrapper.setTargetSearchRequest(new PerishableSearchRequestVO());
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/actions").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableMappingRequestWrapper)))
				.andExpect(status().isOk());
		when(perishableMappingServices.duplicateCheckOnMappedItems(Mockito.any())).thenReturn(true);
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/actions").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableMappingRequestWrapper)))
				.andExpect(status().isOk());
	}

	@Test
	public void testPerishableActionForceNew() throws Exception {
		List<PerishableMappingRequest> mappingRequests = new ArrayList<>();
		mappingRequests.add(perishableMappingRequest);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/perishable/forcenew").contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(new ObjectMapper().writeValueAsString(mappingRequests)))
				.andExpect(status().isOk());
	}

	@Test
	public void testCheckForceNewType() throws Exception {
		PerishableItemCreateMatchCicDto perishableItemCreateMatchCicDto = new PerishableItemCreateMatchCicDto();
		perishableItemCreateMatchCicDto.setDisplayFlag('Y');
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/checkForceNewCategory")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableItemCreateMatchCicDto)))
				.andExpect(status().isOk());

		perishableItemCreateMatchCicDto.setDisplayFlag('N');
		perishableItemCreateMatchCicDto.setSourceComponentUpc(Collections.singletonList(new DisplayItemSourceUPC()));
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/checkForceNewCategory")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableItemCreateMatchCicDto)))
				.andExpect(status().isOk());
		when(perishableMappingServices.checkMatchingUPCInTarget(Mockito.any())).thenReturn(true);
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/checkForceNewCategory")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableItemCreateMatchCicDto)))
				.andExpect(status().isOk());
	}

	@Test
	public void testExpesetypeChangingaction() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/perishable/changeExpenseType")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(perishableMappingRequestWrapper)))
				.andExpect(status().isOk());
	}

}
