/* **************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;

/* ***************************************************************************
 * NAME : CompanyServiceImplTest 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Nov 23, 2021  - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.SMICDetail;
import com.safeway.app.memi.data.entities.SMICDetailPK;
import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.data.repositories.SMICDetailRepository;
import com.safeway.app.memi.domain.dtos.response.SMICDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.services.impl.SMICDetailServiceImpl;

@SpringBootTest(classes = SMICDetailServiceImpl.class)
public class SMICDetailServiceImplTest {

	@Autowired
	private SMICDetailServiceImpl smicDetailServiceImpl;
	@MockBean
	private SMICDetailRepository smicRepo;
	@MockBean
	private CommonSQLRepository commonSQLRepo;

	@Test
	public void getAllItems() {
		List<SMICDetail> smicList = new ArrayList<>();
		SMICDetail smicDetail = new SMICDetail();
		smicDetail.setSMICDesc("sMICDesc");
		smicDetail.setSMICDetailPK(new SMICDetailPK());
		smicList.add(smicDetail);
		when(smicRepo.findAll()).thenReturn(smicList);
		List<SMICDetailDto> detailDtos = smicDetailServiceImpl.getAllItems();
		assertEquals("sMICDesc", detailDtos.get(0).getSMICDesc());
	}

	@Test
	public void findByGrpCdAndCtgryCdAndClsCdAndSbClsCdAndSubSbClass() {
		List<SMICDetail> smicList = new ArrayList<>();
		SMICDetail smicDetail = new SMICDetail();
		smicDetail.setSMICDetailPK(new SMICDetailPK());
		smicDetail.setSMICDesc("sMICDesc");
		smicList.add(smicDetail);
		when(smicRepo
				.findBySMICDetailPKGrpCdAndSMICDetailPKCtgryCdAndSMICDetailPKClsCdAndSMICDetailPKSbClsCdAndSMICDetailPKSubSbClass(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString())).thenReturn(smicList);
		List<SMICDetailDto> detailDtos = smicDetailServiceImpl.findByGrpCdAndCtgryCdAndClsCdAndSbClsCdAndSubSbClass("",
				"", "", "", "");
		assertEquals("sMICDesc", detailDtos.get(0).getSMICDesc());
	}

	@Test
	public void getGroupCode() {
		List<Object[]> groupCodeAndDescList = new ArrayList<>();
		groupCodeAndDescList.add(new Object[] { new BigDecimal("5"), "codeDesc" });
		when(commonSQLRepo.fetchGroupCodeWithDesc()).thenReturn(groupCodeAndDescList);
		List<SmicCodeDescWrapper> codeDescWrappers = smicDetailServiceImpl.getGroupCode();
		assertEquals("codeDesc", codeDescWrappers.get(0).getCodeDesc());
	}

	@Test
	public void getCategoryCode() {
		List<Object[]> groupCodeAndDescList = new ArrayList<>();
		groupCodeAndDescList.add(new Object[] { new BigDecimal("5"), "codeDesc" });
		when(commonSQLRepo.fetchCategoryCodeWithDesc(Mockito.anyString())).thenReturn(groupCodeAndDescList);

		List<SmicCodeDescWrapper>codeDescWrappers = smicDetailServiceImpl.getCategoryCode("");
		assertEquals("codeDesc", codeDescWrappers.get(0).getCodeDesc());
	}

	@Test
	public void getClassCode() {
		List<Object[]> groupCodeAndDescList = new ArrayList<>();
		groupCodeAndDescList.add(new Object[] { new BigDecimal("5"), "codeDesc" });
		when(commonSQLRepo.fetchClassCodeWithDesc(Mockito.anyString(),Mockito.anyString())).thenReturn(groupCodeAndDescList);
		List<SmicCodeDescWrapper>codeDescWrappers = smicDetailServiceImpl.getClassCode("","");
		assertEquals("codeDesc", codeDescWrappers.get(0).getCodeDesc());
	}

	@Test
	public void getSubClassCode() {
		List<Object[]> groupCodeAndDescList = new ArrayList<>();
		groupCodeAndDescList.add(new Object[] { new BigDecimal("5"), "codeDesc" });
		when(commonSQLRepo.fetchSubClassCodeWithDesc(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(groupCodeAndDescList);
		List<SmicCodeDescWrapper>codeDescWrappers = smicDetailServiceImpl.getSubClassCode("","","");
		assertEquals("codeDesc", codeDescWrappers.get(0).getCodeDesc());
	}

	@Test
	public void getSubSubClassCode() {
		List<Object[]> groupCodeAndDescList = new ArrayList<>();
		groupCodeAndDescList.add(new Object[] { new BigDecimal("5"), "codeDesc" });
		when(commonSQLRepo.fetchSubSubClassCodeWithDesc(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(groupCodeAndDescList);
		List<SmicCodeDescWrapper>codeDescWrappers = smicDetailServiceImpl.getSubSubClassCode("","","","");
		assertEquals("codeDesc", codeDescWrappers.get(0).getCodeDesc());
	}

}