package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.memi.data.entities.ItemAggregateCorp;
import com.safeway.app.memi.data.entities.ItemConvDisplayItem;
import com.safeway.app.memi.data.entities.ItemConvDisplayItemComponents;
import com.safeway.app.memi.data.entities.ItemConvDisplayItemComponentsPK;
import com.safeway.app.memi.data.repositories.DisplaySQLRepository;
import com.safeway.app.memi.data.repositories.ItemAggregateCorpRepository;
import com.safeway.app.memi.data.repositories.ItemConvDisplayItemComponentRepository;
import com.safeway.app.memi.data.repositories.ItemConvDisplayItemRepository;
import com.safeway.app.memi.data.repositories.UIExceptionSrcRepository;
import com.safeway.app.memi.domain.dtos.response.DisplayExceptionItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemCreateMatchCicDto;
import com.safeway.app.memi.domain.dtos.response.DisplayItemDetail;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSimsUPC;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceSimsItems;
import com.safeway.app.memi.domain.dtos.response.DisplayItemSourceUPC;
import com.safeway.app.memi.domain.dtos.response.ExcelFileRequest;
import com.safeway.app.memi.domain.dtos.response.UIDataVO;
import com.safeway.app.memi.domain.dtos.response.UndoCreateNewCicDto;
import com.safeway.app.memi.domain.services.impl.DisplayServiceImpl;
import com.safeway.app.memi.domain.util.EmailFacilitator;

@SpringBootTest(classes = DisplayServiceImpl.class)
public class DisplayServiceImplTest {
	private static final Logger LOG = LoggerFactory.getLogger(DisplayServiceImplTest.class);
	@Autowired
	private DisplayServiceImpl displayServiceImpl;
	@MockBean
	private DisplaySQLRepository displayerSQLRepo;
	@MockBean
	private ItemAggregateCorpRepository itemAggregateRepo;
	@MockBean
	private UIExceptionSrcRepository exSrcRepo;
	@MockBean
	private ItemConvDisplayItemRepository itemConvDisplayRepo;
	@MockBean
	private ItemConvDisplayItemComponentRepository dispayComponentRepo;
	@MockBean
	private EmailFacilitator email;

	private static List<Object[]> resultList;
	private static List<Object[]> resultListElse;
	private static List<Object[]> resultEmpty;
	private static Object[] resultObjElse;
	private static List<Object[]> resultListSims;
	private static Object[] lkpObjSims;
	private static Object[] lkpObj;
	private static List<ItemConvDisplayItem> record;
	private static ItemConvDisplayItem itemConvDisplayItem;
	private static int result;
	private static List<DisplayItemDetail> displayItemDetailList;
	private static DisplayItemDetail displayItemDetail;
	private static List<DisplayItemDetail> displayItemDetailListSku;
	private static DisplayItemDetail displayItemDetailSku;
	private static List<DisplayItemDetail> displayItemDetailListFlag;
	private static DisplayItemDetail displayItemDetailFlag;
	private static List<Object[]> resultListElseList;
	private static Object[] lkpObjList;
	private static List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDtoList;
	private static DisplayItemCreateMatchCicDto displayItemCreateMatchCicDto;
	private static List<DisplayItemSimsUPC> ssimsComponent;
	private static DisplayItemSimsUPC displayItemSimsUPC;
	private static List<DisplayItemSourceUPC> sourceComponentUpc;
	private static DisplayItemSourceUPC displayItemSourceUPC;
	private static List<String> upcListCorp;
	private static List<ItemAggregateCorp> itemAggregateCorpList;
	private static ItemAggregateCorp itemAggregateCorp;
	private static UndoCreateNewCicDto undoCreateNewCicDto;
	private static UndoCreateNewCicDto undoCreateNewCicDtoC;
	private static List<Object[]> resultListComp;
	private static Object[] lkpObjComp;
	private static List<Object[]> resultListCompSims;
	private static Object[] lkpObjCompSims;
	private static Set<String> setOfString;
	private static List<Object[]> resElseList;
	private static Object[] resElseObj;
	private static DisplayItemDetail displayItemDetailOne;
	private static List<DisplayItemDetail> displayItemDetailListInd;
	private static DisplayItemDetail displayItemDetailInd;
	private static ExcelFileRequest excelFileRequest;

	@BeforeAll
	public static void init() throws IOException {
		resultList = new ArrayList<>();
		resultListElse = new ArrayList<>();
		lkpObj = new Object[66];
		lkpObj[0] = new Integer(1);
		lkpObj[1] = "divisionId";
		lkpObj[2] = "productSKU";
		lkpObj[3] = new Integer(1);
		lkpObj[4] = new Integer(1);
		resultList.add(lkpObj);
		resElseList = new ArrayList<>();
		resElseObj = new Object[66];
		resElseObj = new Object[66];
		resElseObj[0] = 1;
		resElseObj[1] = "divisionId";
		resElseObj[2] = "productSKU";
		resElseObj[3] = 1;
		resElseObj[4] = 1;
		resElseList.add(resElseObj);
		resultListSims = new ArrayList<>();
		lkpObjSims = new Object[66];
		lkpObjSims[0] = "02-03-04-05";
		lkpObjSims[1] = "02";
		lkpObjSims[2] = new BigDecimal(3);
		lkpObjSims[3] = new BigDecimal(3);
		resultListSims.add(lkpObjSims);
		setOfString = new HashSet<>();
		setOfString.add("01-01-01-01");
		setOfString.add("01");
		setOfString.add("02");
		setOfString.add("03");
		record = new ArrayList<>();
		itemConvDisplayItem = new ItemConvDisplayItem();
		itemConvDisplayItem.setCaseUpc("case");
		itemConvDisplayItem.setCic(new BigDecimal(1));
		itemConvDisplayItem.setCompItemDesc("Desc");
		record.add(itemConvDisplayItem);
		displayItemDetailList = new ArrayList<>();
		displayItemDetail = new DisplayItemDetail();
		displayItemDetail.setCaseUpc("UPC-upc-upc-upc-upc");
		displayItemDetail.setCompanyId("ABS");
		displayItemDetail.setCreateId("ABS001");
		displayItemDetail.setDivisionId("IND");
		displayItemDetail.setDeptCode("abc");
		displayItemDetail.setItemType('C');
		displayItemDetail.setItemDesc("'&%_");
		displayItemDetail.setProductSku("'&%_");
		displayItemDetail.setOneTimeBuyFlag("'&%_");
		displayItemDetail.setProductSourceCode("W");
		displayItemDetail.setCost(new BigDecimal(1));
		displayItemDetailList.add(displayItemDetail);
		displayItemDetailListSku = new ArrayList<>();
		displayItemDetailSku = new DisplayItemDetail();
		displayItemDetailSku.setCaseUpc("UPC-upc-upc-upc-upc");
		displayItemDetailSku.setCompanyId("ABS");
		displayItemDetailSku.setCreateId("ABS001");
		displayItemDetailSku.setDivisionId("IND");
		displayItemDetailSku.setDeptCode("abc");
		displayItemDetailSku.setItemType('C');
		displayItemDetailSku.setItemDesc("'&%_");
		displayItemDetailSku.setProductSku("'&%_");
		displayItemDetailSku.setOneTimeBuyFlag("'&%_");
		displayItemDetailSku.setProductSourceCode("W");
		displayItemDetailSku.setCost(new BigDecimal(1));
		displayItemDetailListSku.add(displayItemDetailSku);
		resultListElseList = new ArrayList<>();
		lkpObjList = new Object[66];
		lkpObjList[0] = "Y";
		lkpObjList[1] = "Y";
		lkpObjList[2] = new BigDecimal(1);
		lkpObjList[3] = new BigDecimal(1);
		lkpObjList[4] = new BigDecimal(1);
		lkpObjList[5] = "Y";
		lkpObjList[6] = "Y";
		lkpObjList[7] = new Double(1);
		lkpObjList[8] = new Double(1);
		lkpObjList[9] = "Y";
		lkpObjList[10] = new Date();
		lkpObjList[11] = new Date();
		lkpObjList[12] = new Date();
		lkpObjList[13] = new BigDecimal(1);
		lkpObjList[14] = new BigDecimal(1);
		lkpObjList[15] = "Y";
		lkpObjList[16] = "Y";
		lkpObjList[17] = "Y";
		result = 1;
		resultListElseList.add(lkpObjList);
		ssimsComponent = new ArrayList<>();
		displayItemSimsUPC = new DisplayItemSimsUPC();
		displayItemSimsUPC.setMemoCost(new BigDecimal(1));
		displayItemSimsUPC.setQuantity(new BigDecimal(1));
		displayItemSimsUPC.setUpc("UPCdsdsfffa-upcdsfsdfsdfafdsfs-upcdsfdsfas-upcfdsfdsfsf");
		displayItemSimsUPC.setUpcDesc("UPCDESC");
		ssimsComponent.add(displayItemSimsUPC);
		sourceComponentUpc = new ArrayList<>();
		displayItemSourceUPC = new DisplayItemSourceUPC();
		displayItemSourceUPC.setMemoCost(new BigDecimal(1));
		displayItemSourceUPC.setQuantity(new BigDecimal(1));
		displayItemSourceUPC.setUpc("UPC-upc-upc-upc");
		displayItemSourceUPC.setUpcDesc("Desc");
		sourceComponentUpc.add(displayItemSourceUPC);
		displayItemCreateMatchCicDtoList = new ArrayList<>();
		displayItemCreateMatchCicDto = new DisplayItemCreateMatchCicDto();
		displayItemCreateMatchCicDto.setCompanyId("ABS");
		displayItemCreateMatchCicDto.setDivisionId("IND");
		displayItemCreateMatchCicDto.setProductSku("Product");
		displayItemCreateMatchCicDto.setSrcItemDesc("Desc");
		displayItemCreateMatchCicDto.setCaseUpc("Upc");
		displayItemCreateMatchCicDto.setCic("1");
		displayItemCreateMatchCicDto.setSsimsHeaderItemDesc("Header");
		displayItemCreateMatchCicDto.setSsimsComponent(ssimsComponent);
		displayItemCreateMatchCicDto.setSourceComponentUpc(sourceComponentUpc);
		displayItemCreateMatchCicDtoList.add(displayItemCreateMatchCicDto);
		upcListCorp = new ArrayList<>();
		upcListCorp.add("OneOneOneOne");
		upcListCorp.add("TwoTwoTwoTwo");
		itemAggregateCorpList = new ArrayList<>();
		itemAggregateCorp = new ItemAggregateCorp();
		itemAggregateCorp.setPrdHierLevel1("1");
		itemAggregateCorp.setPrdHierLevel2("2");
		itemAggregateCorp.setPrdHierLevel3("3");
		itemAggregateCorp.setPrdHierLevel4("4");
		itemAggregateCorp.setPrdHierLevel5("5");
		itemAggregateCorp.setSizeDesc("Size desc");
		itemAggregateCorp.setSizeNmbr(new BigDecimal(1));
		itemAggregateCorp.setSizeUom("Uom");
		itemAggregateCorp.setItemDesc("Desc");
		itemAggregateCorp.setPrimaryUpcInd('P');
		itemAggregateCorp.setPrivateLevelInd('L');
		itemAggregateCorp.setLogicalDelInd('D');
		itemAggregateCorp.setBatchId(new BigDecimal(2));
		itemAggregateCorp.setInternetDesc("Internet");
		itemAggregateCorp.setWhseItemDesc("Whse");
		itemAggregateCorp.setSrcByDsd("Y");
		itemAggregateCorp.setSrcByWhse("Y");
		itemAggregateCorp.setMaterialItemInd('Y');
		itemAggregateCorp.setExpenseItemInd('N');
		itemAggregateCorpList.add(itemAggregateCorp);
		undoCreateNewCicDto = new UndoCreateNewCicDto();
		undoCreateNewCicDto.setCicType('M');
		undoCreateNewCicDto.setCompanyId("ABS");
		undoCreateNewCicDto.setDivisionId("IND");
		undoCreateNewCicDto.setProductSku("SKU");
		undoCreateNewCicDto.setUpdatedUserId("abs1");
		undoCreateNewCicDtoC = new UndoCreateNewCicDto();
		undoCreateNewCicDtoC.setCicType('C');
		undoCreateNewCicDtoC.setCompanyId("ABS");
		undoCreateNewCicDtoC.setDivisionId("IND");
		undoCreateNewCicDtoC.setProductSku("SKU");
		undoCreateNewCicDtoC.setUpdatedUserId("abs1");
		resultListComp = new ArrayList<>();
		lkpObjComp = new Object[66];
		lkpObjComp[0] = "1";
		lkpObjComp[1] = "2";
		lkpObjComp[2] = "3";
		lkpObjComp[3] = new BigDecimal(1);
		lkpObjComp[4] = new BigDecimal(1);
		lkpObjComp[5] = new BigDecimal(1);
		lkpObjComp[6] = new BigDecimal(1);
		lkpObjComp[7] = "7";
		resultListComp.add(lkpObjComp);
		resultListCompSims = new ArrayList<>();
		lkpObjCompSims = new Object[66];
		lkpObjCompSims[0] = new BigDecimal(1);
		lkpObjCompSims[1] = "2";
		lkpObjCompSims[2] = "3";
		lkpObjCompSims[3] = '2';
		lkpObjCompSims[4] = "2";
		lkpObjCompSims[5] = "2";
		lkpObjCompSims[6] = new BigDecimal(1);
		lkpObjCompSims[7] = new BigDecimal(1);
		lkpObjCompSims[8] = new BigDecimal(1);
		resultListCompSims.add(lkpObjCompSims);
		resultListElse = new ArrayList<>();
		resultObjElse = new Object[66];
		resultObjElse[0] = new BigDecimal("147.87932");
		resultObjElse[1] = "2";
		resultObjElse[2] = "3";
		resultObjElse[3] = 'c';
		resultObjElse[4] = "3";
		resultObjElse[5] = "3";
		resultObjElse[6] = new BigDecimal(1);
		resultObjElse[7] = new Integer(1);
		resultObjElse[8] = new Integer(1);
		resultListElse.add(resultObjElse);
		displayItemDetailList = new ArrayList<>();
		displayItemDetailOne = new DisplayItemDetail();
		displayItemDetailOne.setCompanyId("ABS");
		displayItemDetailOne.setDivisionId("IND");
		displayItemDetailOne.setDeptCode("IT");
		displayItemDetailOne.setItemDesc("");
		displayItemDetailOne.setItemType('C');
		displayItemDetailList.add(displayItemDetailOne);
		displayItemDetailListFlag = new ArrayList<>();
		displayItemDetailFlag = new DisplayItemDetail();
		displayItemDetailFlag.setCaseUpc("UPC-upc-upc-upc-upc");
		displayItemDetailFlag.setCompanyId("ABS");
		displayItemDetailFlag.setCreateId("ABS001");
		displayItemDetailFlag.setDivisionId("IND");
		displayItemDetailFlag.setDeptCode("abc");
		displayItemDetailFlag.setItemType('C');
		displayItemDetailFlag.setItemDesc("'&%_");
		displayItemDetailFlag.setProductSku("'&%_");
		displayItemDetailFlag.setOneTimeBuyFlag("'&%_");
		displayItemDetailFlag.setProductSourceCode("W");
		displayItemDetailFlag.setCost(new BigDecimal(1));
		displayItemDetailListFlag.add(displayItemDetailFlag);
		displayItemDetailListInd = new ArrayList<>();
		displayItemDetailInd = new DisplayItemDetail();
		displayItemDetailInd.setCompanyId("ABS");
		displayItemDetailInd.setDivisionId("Ind");
		displayItemDetailInd.setProductSku("SKU");
		displayItemDetailInd.setDeptCode("ABS");
		displayItemDetailInd.setCaseUpc("ABS");
		displayItemDetailListInd.add(displayItemDetailInd);
		resultEmpty = new ArrayList<>();
		excelFileRequest = new ExcelFileRequest("companyId", "divisionId", "divisionName", "deptName", "deptCode",
				"userId", null);

	}

	@Test
	public void testGetDepartmentWiseDisplayItemData() throws Exception {
		when(displayerSQLRepo.fetchDepartmentWiseDisplayItemData(Mockito.any(), Mockito.any())).thenReturn(resElseList);
		when(displayerSQLRepo.fetchDepartmentWiseCompletedDisplayItem(Mockito.any(), Mockito.any()))
				.thenReturn(resultList);
		List<UIDataVO> checkTest = displayServiceImpl.getDepartmentWiseDisplayItemData("ABS", "IND");
		assertEquals("divisionId", checkTest.get(0).getDeptName());
	}

	@Test
	public void testGetDepartmentWiseDisplayItemDataElse() throws Exception {
		when(displayerSQLRepo.fetchDepartmentWiseDisplayItemData(Mockito.any(), Mockito.any())).thenReturn(resultList);
		when(displayerSQLRepo.fetchDepartmentWiseCompletedDisplayItem(Mockito.any(), Mockito.any()))
				.thenReturn(resultList);
		List<UIDataVO> checkTest = displayServiceImpl.getDepartmentWiseDisplayItemData("ABS", "IND");
		assertEquals("divisionId", checkTest.get(0).getDeptName());
	}

	@Test
	public void testGetDepartmentWiseDisplayItemDataElseVo() throws Exception {
		List<Object[]> emptyResultList = new ArrayList<>();
		when(displayerSQLRepo.fetchDepartmentWiseDisplayItemData(Mockito.any(), Mockito.any()))
				.thenReturn(emptyResultList);
		when(displayerSQLRepo.fetchDepartmentWiseCompletedDisplayItem(Mockito.any(), Mockito.any()))
				.thenReturn(resultList);
		List<UIDataVO> checkTest = displayServiceImpl.getDepartmentWiseDisplayItemData("ABS", "IND");
		assertEquals("divisionId", checkTest.get(0).getDeptName());
	}

	@Test
	public void testUpdateMultiCompItemInd() throws Exception {
		List<ItemConvDisplayItem> record = new ArrayList<>();
		int intResultRecord = 1;
		ItemConvDisplayItem itemConvDisplayItem = new ItemConvDisplayItem();
		itemConvDisplayItem.setCaseUpc("case");
		itemConvDisplayItem.setCic(new BigDecimal(1));
		itemConvDisplayItem.setCompItemDesc("Desc");
		record.add(itemConvDisplayItem);
		when(itemConvDisplayRepo
				.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(record);
		when(displayerSQLRepo.updateMultiCompItemInd(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(intResultRecord);
		when(displayerSQLRepo.checkForDsdWhse(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultListElseList);
		when(displayerSQLRepo.checkForRecordItemConSrcDataReplace(Mockito.anyString(), Mockito.anyString(),
				Mockito.any())).thenReturn(resultList);
		when(displayerSQLRepo.insertRecordToItemConSrcDataReplace(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.updateRecordToItemConSrcDataReplace(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(1);
		Map<String, List<String>> checkTest = displayServiceImpl.updateMultiCompItemInd(displayItemDetailListInd, 'U');
		assertEquals(2, checkTest.size());
	}

	@Test
	public void testMarkItemsAsDead() throws Exception {
		when(displayerSQLRepo.markItemsAsDead(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(result);
		Map<String, List<String>> checkTest = displayServiceImpl.markItemsAsDead(displayItemDetailList);
		assertFalse(checkTest.isEmpty());
	}
	
	@Test
	public void testMarkItemsAsDeadElse() throws Exception {
		when(displayerSQLRepo.markItemsAsDead(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(0);
		Map<String, List<String>> checkTest = displayServiceImpl.markItemsAsDead(displayItemDetailList);
		assertFalse(checkTest.isEmpty());
	}

	@Test
	public void testLoadDepartmentWiseDisplayItemList() throws Exception {
		when(displayerSQLRepo.fetchDepartmentWiseDisplayItemDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyChar(), Mockito.anyChar())).thenReturn(resultListElseList);
		List<DisplayItemDetail> checkTest = displayServiceImpl.loadDepartmentWiseDisplayItemList("ABS", "IND", "C", 'a',
				'b', 'c');
		assertEquals("Y", checkTest.get(0).getCaseUpc());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnItemDesc() throws Exception {
		when(displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(resultListElseList);
		List<DisplayItemDetail> checkTest = displayServiceImpl
				.getDeptWiseItemDetailsBasedOnItemDesc(displayItemDetailList);
		assertEquals("Y", checkTest.get(0).getProductSku());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnProductSku() throws Exception {
		List<Object[]> result = new ArrayList<>();
		Object[] ObjList = new Object[66];
		ObjList[0] = "Y";
		ObjList[1] = "Y";
		ObjList[2] = new BigDecimal(1);
		ObjList[3] = new BigDecimal(1);
		ObjList[4] = new BigDecimal(1);
		ObjList[5] = "Y";
		ObjList[6] = "Y";
		ObjList[7] = new BigDecimal(1);
		ObjList[8] = new BigDecimal(1);
		ObjList[9] = "Y";
		ObjList[10] = new Date();
		ObjList[11] = new Date();
		ObjList[12] = new Date();
		ObjList[13] = new BigDecimal(1);
		ObjList[14] = new BigDecimal(1);
		ObjList[15] = "Y";
		ObjList[16] = "Y";
		ObjList[17] = "Y";
		result.add(ObjList);
		when(displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(result);
		List<DisplayItemDetail> checkTest = displayServiceImpl
				.getDeptWiseItemDetailsBasedOnProductSku(displayItemDetailListSku);
		assertTrue(checkTest.isEmpty());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnOneTimeBuyFlag() throws Exception {
		when(displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(resultListElseList);
		List<DisplayItemDetail> checkTest = displayServiceImpl
				.getDeptWiseItemDetailsBasedOnOneTimeBuyFlag(displayItemDetailListFlag);
		assertTrue(checkTest.isEmpty());
	}

	@Test
	public void testUpdateCicMatch() throws Exception {
		Map<String, String> checkTest = displayServiceImpl.updateCicMatch(displayItemCreateMatchCicDtoList);
		assertTrue(checkTest.isEmpty());
	}

	@Test
	public void testCreateNewCic() throws Exception {
		when(displayerSQLRepo.fetchUpcList(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(upcListCorp);
		when(itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(itemAggregateCorpList);
		Map<String, String> checkTest = displayServiceImpl.createNewCic(displayItemCreateMatchCicDtoList);
		assertTrue(checkTest.isEmpty());
	}

	@Test
	public void testUndoCreateNewCic() throws Exception {
		when(displayerSQLRepo.deleteRecordFromItemConvDisplayItem(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.deleteRecordFromUIExceptionSrc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		Map<String, String> checkTest = displayServiceImpl.undoCreateNewCic(undoCreateNewCicDto);
		assertFalse(checkTest.isEmpty());
	}

	@Test
	public void testUndoDisplayersCompleted() throws Exception {
		when(displayerSQLRepo.checkNewItemAlreadyConverted(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultListComp);
		when(displayerSQLRepo.deleteRecordFromItemConvDisplayItem(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.deleteRecordFromUIExceptionSrc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.deleteRecordFromNewItemDetail(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.updateItemXref(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.checkMatchedItemAlreadyConverted(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(upcListCorp);
		when(displayerSQLRepo.deleteRecordFromItemConvDisplayItem(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		Map<String, String> checkTest = displayServiceImpl.undoDisplayersCompleted(undoCreateNewCicDto);
		assertFalse(checkTest.isEmpty());
	}

	@Test
	public void testUndoDisplayersCompletedCom() throws Exception {
		when(displayerSQLRepo.checkNewItemAlreadyConverted(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultListComp);
		when(displayerSQLRepo.deleteRecordFromItemConvDisplayItem(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.deleteRecordFromUIExceptionSrc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.deleteRecordFromNewItemDetail(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.updateItemXref(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.checkMatchedItemAlreadyConverted(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(upcListCorp);
		when(displayerSQLRepo.deleteRecordFromItemConvDisplayItem(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);
		Map<String, String> checkTest = displayServiceImpl.undoDisplayersCompleted(undoCreateNewCicDtoC);
		assertFalse(checkTest.isEmpty());
	}

	@Test
	public void testFetchSourceAndSimsDetails() throws Exception {
		Set<String> set = new HashSet<>();
		set.add("01-01-01-01");
		DisplayServiceImpl mockImpl = mock(DisplayServiceImpl.class);
		when(displayerSQLRepo.fetchSourceComponentDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultListSims);
		when(itemConvDisplayRepo
				.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(record);
		when(displayerSQLRepo.fetchSrcSimsDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(resultEmpty);
		when(mockImpl.getSrcUpcList()).thenReturn(set);
		when(displayerSQLRepo.fetchSimsDetailsBasedonSourceUpcSet(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(resultListCompSims);
		DisplayItemSourceSimsItems checkTest = displayServiceImpl.fetchSourceAndSimsDetails(displayItemDetail);
		assertEquals("02", checkTest.getDisplayItemSourceUPC().get(0).getUpcDesc());
	}

	@Test
	public void testUploadExcel() throws Exception {
		MultipartFile uploadedExcelFileToDest = Mockito.mock(MultipartFile.class);
		List<Object[]> resultOne = new ArrayList<>();
		Object[] objOne = new Object[1];
		objOne[0] = "Test";
		resultOne.add(objOne);
		List<ItemConvDisplayItemComponents> updateList = new ArrayList<>();
		when(uploadedExcelFileToDest.getOriginalFilename()).thenReturn("DisplayExceptionItems_NonPerishable.xlsx");
		when(uploadedExcelFileToDest.isEmpty()).thenReturn(false);
		doAnswer(invocation -> {
			Object obj = invocation.getArgument(0);
			File destFileLocation = (File) obj;
			File sourceFileLocation = new File("src/test/resources/DisplayExceptionItems_NonPerishable.xlsx");
			FileCopyUtils.copy(new FileInputStream(sourceFileLocation), new FileOutputStream(destFileLocation));
			return null;
		}).when(uploadedExcelFileToDest).transferTo(Mockito.any(File.class));
		ItemConvDisplayItemComponents newRecord = new ItemConvDisplayItemComponents();
		ItemConvDisplayItemComponentsPK newRecordPk = new ItemConvDisplayItemComponentsPK();
		newRecordPk.setCompanyid("companyId");
		newRecordPk.setDivisonId("divisionId");
		newRecordPk.setProductSku("ProductSKU");
		newRecordPk.setUpcCountry(new BigDecimal(1));
		newRecordPk.setUpcSystem(new BigDecimal(1));
		newRecordPk.setUpcManuf(new BigDecimal(1));
		newRecordPk.setUpcSales(new BigDecimal(1));

		newRecord.setItemConvDisplayItemComponentsPk(newRecordPk);
		newRecord.setCaseUpc("getCaseUPC");
		newRecord.setItemmDesc("getItemDesc");
		newRecord.setShipCaseQty(new BigDecimal(1));
		newRecord.setShipSizeDesc("getSizeDesc");
		newRecord.setMemoCost(new BigDecimal(1));

		newRecord.setCompItemDesc("getComponentItemDesc");
		newRecord.setCompShelfUnit(new BigDecimal(1));
		newRecord.setCompSizeDesc("getComponentSizeDesc");
		newRecord.setUnitCost(new BigDecimal(1));
		newRecord.setCreatUserId("creatUserId");
		newRecord.setUpdateTs(new Date());
		when(dispayComponentRepo.saveAndFlush(Mockito.any(ItemConvDisplayItemComponents.class))).thenReturn(newRecord);
		when(displayerSQLRepo.fetchSourceComponentDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultListSims);
		when(itemConvDisplayRepo
				.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(record);
		when(displayerSQLRepo.fetchSrcSimsDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(resultListElse);
		when(displayerSQLRepo.fetchSimsDetailsBasedonSourceUpcSet(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(resultListComp);
		when(dispayComponentRepo
				.findByItemConvDisplayItemComponentsPkCompanyidAndItemConvDisplayItemComponentsPkDivisonIdAndItemConvDisplayItemComponentsPkProductSkuAndItemConvDisplayItemComponentsPkUpcCountryAndItemConvDisplayItemComponentsPkUpcSystemAndItemConvDisplayItemComponentsPkUpcManufAndItemConvDisplayItemComponentsPkUpcSales(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any())).thenReturn(updateList);
		when(displayerSQLRepo.validDisplayEntry(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(resultOne);
		excelFileRequest.setFile(uploadedExcelFileToDest);
		String message = displayServiceImpl.uploadExcel("", "B", "C", "D", "E", "E", uploadedExcelFileToDest);
		LOG.info(message);
     	assertTrue(true);
	}

	@Test
	public void testFetchSourceAndSimsDetailsNotEmpty() throws Exception {
		Set<String> set = new HashSet<>();
		set.add("01-01-01-01");
		List<Object[]> resultListNotEmpty = new ArrayList<>();
		Object[] resultObjNotEmpty = new Object[66];
		resultObjNotEmpty[0] = new BigDecimal(1);
		resultObjNotEmpty[1] = "2";
		resultObjNotEmpty[2] = "3";
		resultObjNotEmpty[3] = 'c';
		resultObjNotEmpty[4] = "3";
		resultObjNotEmpty[5] = "3";
		resultObjNotEmpty[6] = new Integer(7);
		resultObjNotEmpty[7] = new Integer(7);
		resultObjNotEmpty[8] = new Integer(8);
		resultListNotEmpty.add(resultObjNotEmpty);
		DisplayServiceImpl mockImpl = mock(DisplayServiceImpl.class);
		when(displayerSQLRepo.fetchSourceComponentDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(resultListSims);
		when(itemConvDisplayRepo
				.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(record);
		when(displayerSQLRepo.fetchSrcSimsDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(resultListNotEmpty);
		when(mockImpl.getSrcUpcList()).thenReturn(set);
		when(displayerSQLRepo.fetchSimsDetailsBasedonSourceUpcSet(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(resultListCompSims);
		DisplayItemSourceSimsItems checkTest = displayServiceImpl.fetchSourceAndSimsDetails(displayItemDetail);
		assertEquals("02", checkTest.getDisplayItemSourceUPC().get(0).getUpcDesc());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnReviewedItemDesc() throws Exception {
		when(displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnReviewedItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(resultListElseList);
		List<DisplayItemDetail> checkTest = displayServiceImpl
				.getDeptWiseItemDetailsBasedOnReviewedItemDesc(displayItemDetailList);
		assertFalse(checkTest.isEmpty());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnReviewedProductSku() throws Exception {
		when(displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnReviewedItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(resultListElseList);
		List<DisplayItemDetail> checkTest = displayServiceImpl
				.getDeptWiseItemDetailsBasedOnReviewedProductSku(displayItemDetailListSku);
		assertTrue(checkTest.isEmpty());
	}

	@Test
	public void testGetDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag() throws Exception {
		when(displayerSQLRepo.fetchDeptWiseItemDetailsBasedOnReviewedItemDesc(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(resultListElseList);
		List<DisplayItemDetail> checkTest = displayServiceImpl
				.getDeptWiseItemDetailsBasedOnReviewedOneTimeBuyFlag(displayItemDetailListFlag);
		assertTrue(checkTest.isEmpty());
	}

	@Test
	public void testMapToExcelFileRow() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("mapToExcelFileRow", String.class, String.class,
				List.class);
		List<String> cellValue = new ArrayList<>();
		method.setAccessible(true);
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		cellValue.add("");
		method.invoke(displayServiceImpl, "", "user", cellValue);
		cellValue.set(0, "0");
		cellValue.set(1, "componentEXCEPTION");
		cellValue.set(2, "01");
		cellValue.set(3, "%01");
		cellValue.set(4, "01");
		cellValue.set(6, "%01");
		cellValue.set(7, "0.0");
		cellValue.set(8, "01");
		cellValue.set(9, "1");
		cellValue.set(10, "1");
		cellValue.set(11, "01");
		cellValue.set(12, "01");
		cellValue.set(13, "%01");
		cellValue.set(14, "01");
		cellValue.set(15, "%01");
		cellValue.set(16, "0.0");
		method.invoke(displayServiceImpl, "", "user", cellValue);
		cellValue.set(1, "compotEXCEPTION");
		cellValue.set(2, "ABC");
		cellValue.set(3, "0123456789101112131415161718192021222324252627282930");
		cellValue.set(4, "ab");
		cellValue.set(6, "0123456789101112131415161718192021222324252627282930");
		cellValue.set(7, "ab");
		cellValue.set(8, "ab");
		cellValue.set(12, "ab");
		cellValue.set(13, "0123456789101112131415161718192021222324252627282930");
		cellValue.set(14, "ab");
		cellValue.set(15, "0123456789101112131415161718192021222324252627282930");
		cellValue.set(16, "1.0");
		method.invoke(displayServiceImpl, "", "user", cellValue);
		cellValue.set(3, "01234567891");
		cellValue.set(6, "01234567891");
		cellValue.set(13, "ab");
		cellValue.set(15, "0123456");
		cellValue.set(16, "ab");
		method.invoke(displayServiceImpl, "", "user", cellValue);
		assertTrue(true);
	}

	@Test
	public void testinsertUpdateSuccesfullDisplayItemComponents() throws Exception {
		Map<String, DisplayExceptionItemDetail> successRecords = new HashMap<String, DisplayExceptionItemDetail>();
		DisplayExceptionItemDetail record = new DisplayExceptionItemDetail();
		record.setUpcCountry("0");
		record.setUpcSales("0");
		record.setUpcSystem("0");
		record.setUpcManuf("0");
		record.setProductSKU("productSKU");
		successRecords.put("key", record);
		ItemConvDisplayItemComponents components = new ItemConvDisplayItemComponents();
		List<ItemConvDisplayItemComponents> updateList = Collections.singletonList(components);
		when(dispayComponentRepo
				.findByItemConvDisplayItemComponentsPkCompanyidAndItemConvDisplayItemComponentsPkDivisonIdAndItemConvDisplayItemComponentsPkProductSkuAndItemConvDisplayItemComponentsPkUpcCountryAndItemConvDisplayItemComponentsPkUpcSystemAndItemConvDisplayItemComponentsPkUpcManufAndItemConvDisplayItemComponentsPkUpcSales(
						Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(BigDecimal.class), Mockito.any(BigDecimal.class), Mockito.any(BigDecimal.class),
						Mockito.any(BigDecimal.class))).thenReturn(updateList);
		Method method = displayServiceImpl.getClass().getDeclaredMethod("insertUpdateSuccesfullDisplayItemComponents",
				String.class, String.class, String.class, Map.class);
		method.setAccessible(true);
		method.invoke(displayServiceImpl, "99", "2400", "testuser", successRecords);
		assertTrue(true);
	}

	@Test
	public void testbulkUpdateExistingRecords() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("bulkUpdateExistingRecords",
				DisplayExceptionItemDetail.class, String.class, List.class);
		DisplayExceptionItemDetail record = new DisplayExceptionItemDetail();
		List<ItemConvDisplayItemComponents> updateList = new ArrayList<ItemConvDisplayItemComponents>();
		method.setAccessible(true);
		method.invoke(displayServiceImpl, record, "user", updateList);
		assertTrue(true);
	}

	@Test
	public void testmultipartToFile() throws Exception {
		MultipartFile multipart = Mockito.mock(MultipartFile.class);
		displayServiceImpl.multipartToFile(multipart);
		assertTrue(true);
	}

	@Test
	public void testsendEmail() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("sendEmail", String.class, String.class, Map.class);
		Map<String, List<String>> invalidProductSkuMap = new HashMap<>();
		invalidProductSkuMap.put("key", Collections.singletonList("value"));
		method.setAccessible(true);
		method.invoke(displayServiceImpl, "test-User", "file-Name", invalidProductSkuMap);
		assertTrue(true);
	}

	@Test
	public void testsendErrorEmail() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("sendErrorEmail", String.class, String.class,
				String.class);
		method.setAccessible(true);
		method.invoke(displayServiceImpl, "test-User", "file-Name", "message");
		assertTrue(true);
	}
	
	@Test
	public void testCreateNewCicElseIfNY() throws Exception {
		List<ItemAggregateCorp> itemAggregateCorpListNY = new ArrayList<>();
		ItemAggregateCorp itemAggregateCorp = new ItemAggregateCorp();
		itemAggregateCorp.setMaterialItemInd('N');
		itemAggregateCorp.setExpenseItemInd('Y');
		itemAggregateCorp.setPrdHierLevel1("1");
		itemAggregateCorp.setPrdHierLevel2("2");
		itemAggregateCorp.setPrdHierLevel3("3");
		itemAggregateCorp.setPrdHierLevel4("4");
		itemAggregateCorp.setPrdHierLevel5("5");
		itemAggregateCorp.setSizeDesc("Size desc");
		itemAggregateCorp.setSizeNmbr(new BigDecimal(1));
		itemAggregateCorp.setSizeUom("Uom");
		itemAggregateCorp.setItemDesc("Desc");
		itemAggregateCorp.setPrimaryUpcInd('P');
		itemAggregateCorp.setPrivateLevelInd('L');
		itemAggregateCorp.setLogicalDelInd('D');
		itemAggregateCorp.setBatchId(new BigDecimal(2));
		itemAggregateCorp.setInternetDesc("Internet");
		itemAggregateCorp.setWhseItemDesc("Whse");
		itemAggregateCorp.setSrcByDsd("Y");
		itemAggregateCorp.setSrcByWhse("Y");
		itemAggregateCorpListNY.add(itemAggregateCorp);
		when(displayerSQLRepo.fetchUpcList(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(upcListCorp);
		when(itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(itemAggregateCorpListNY);
		Map<String, String> checkTest = displayServiceImpl.createNewCic(displayItemCreateMatchCicDtoList);
		assertTrue(checkTest.isEmpty());
	}
	
	@Test
	public void testCreateNewCicElseIfNN() throws Exception {
		List<ItemAggregateCorp> itemAggregateCorpListNN = new ArrayList<>();
		ItemAggregateCorp itemAggregateCorp = new ItemAggregateCorp();
		itemAggregateCorp.setMaterialItemInd('N');
		itemAggregateCorp.setExpenseItemInd('N');
		itemAggregateCorp.setPrdHierLevel1("1");
		itemAggregateCorp.setPrdHierLevel2("2");
		itemAggregateCorp.setPrdHierLevel3("3");
		itemAggregateCorp.setPrdHierLevel4("4");
		itemAggregateCorp.setPrdHierLevel5("5");
		itemAggregateCorp.setSizeDesc("Size desc");
		itemAggregateCorp.setSizeNmbr(new BigDecimal(1));
		itemAggregateCorp.setSizeUom("Uom");
		itemAggregateCorp.setItemDesc("Desc");
		itemAggregateCorp.setPrimaryUpcInd('P');
		itemAggregateCorp.setPrivateLevelInd('L');
		itemAggregateCorp.setLogicalDelInd('D');
		itemAggregateCorp.setBatchId(new BigDecimal(2));
		itemAggregateCorp.setInternetDesc("Internet");
		itemAggregateCorp.setWhseItemDesc("Whse");
		itemAggregateCorp.setSrcByDsd("Y");
		itemAggregateCorp.setSrcByWhse("Y");
		itemAggregateCorpListNN.add(itemAggregateCorp);
		when(displayerSQLRepo.fetchUpcList(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(upcListCorp);
		when(itemAggregateRepo
				.findByItemAggregateCorpPkProductSKUAndItemAggregateCorpPkDivisionIdAndItemAggregateCorpPkCompanyIdAndItemAggregateCorpPkUpc(
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(itemAggregateCorpListNN);
		Map<String, String> checkTest = displayServiceImpl.createNewCic(displayItemCreateMatchCicDtoList);
		assertTrue(checkTest.isEmpty());
	}
	
	@Test
	public void testInsertUpdateSuccesfullDisplayItemComponents() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("insertUpdateSuccesfullDisplayItemComponents", String.class, String.class,
				String.class, Map.class);
		Map<String, DisplayExceptionItemDetail> successRecords = new HashMap<>();
		DisplayExceptionItemDetail displayExceptionItemDetail = new DisplayExceptionItemDetail();
		displayExceptionItemDetail.setDepartmentNm("IT");
		displayExceptionItemDetail.setUpcCountry("1");
		displayExceptionItemDetail.setUpcSystem("2");
		displayExceptionItemDetail.setUpcManuf("3");
		displayExceptionItemDetail.setUpcSales("4");
		successRecords.put("One", displayExceptionItemDetail);
		method.setAccessible(true);
		when(dispayComponentRepo.findByItemConvDisplayItemComponentsPkCompanyidAndItemConvDisplayItemComponentsPkDivisonIdAndItemConvDisplayItemComponentsPkProductSkuAndItemConvDisplayItemComponentsPkUpcCountryAndItemConvDisplayItemComponentsPkUpcSystemAndItemConvDisplayItemComponentsPkUpcManufAndItemConvDisplayItemComponentsPkUpcSales
				(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), 
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
		method.invoke(displayServiceImpl, "test-User", "file-Name", "message", successRecords);
		assertTrue(true);
	}
	
	@Test
	public void testUpdateMultiCompItemIndEmpty() throws Exception {
		List<ItemConvDisplayItem> record = new ArrayList<>();
		int intResultRecord = 1;
		ItemConvDisplayItem itemConvDisplayItem = new ItemConvDisplayItem();
		itemConvDisplayItem.setCaseUpc("case");
		itemConvDisplayItem.setCic(new BigDecimal(1));
		itemConvDisplayItem.setCompItemDesc("Desc");
		record.add(itemConvDisplayItem);
		List<Object[]> obj= new ArrayList<>();
		when(itemConvDisplayRepo
				.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(record);
		when(displayerSQLRepo.updateMultiCompItemInd(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(intResultRecord);
		when(displayerSQLRepo.checkForDsdWhse(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(resultListElseList);
		when(displayerSQLRepo.checkForRecordItemConSrcDataReplace(Mockito.anyString(), Mockito.anyString(),
				Mockito.any())).thenReturn(obj);
		when(displayerSQLRepo.insertRecordToItemConSrcDataReplace(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(1);
		when(displayerSQLRepo.updateRecordToItemConSrcDataReplace(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(1);
		Map<String, List<String>> checkTest = displayServiceImpl.updateMultiCompItemInd(displayItemDetailListInd, 'U');
		assertEquals(2, checkTest.size());
	}
	
	@Test
	public void testUpdateMultiCompItemIndEmptyElse() throws Exception {
		List<ItemConvDisplayItem> record = new ArrayList<>();
		int intResultRecord = 0;
		ItemConvDisplayItem itemConvDisplayItem = new ItemConvDisplayItem();
		itemConvDisplayItem.setCaseUpc("case");
		itemConvDisplayItem.setCic(new BigDecimal(1));
		itemConvDisplayItem.setCompItemDesc("Desc");
		record.add(itemConvDisplayItem);
		when(itemConvDisplayRepo
				.findByItemConvDisplayItemPkCompanyIdAndItemConvDisplayItemPkDivisionIdAndItemConvDisplayItemPkProductSKU(
						Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(record);
		when(displayerSQLRepo.updateMultiCompItemInd(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyChar())).thenReturn(intResultRecord);
		Map<String, List<String>> checkTest = displayServiceImpl.updateMultiCompItemInd(displayItemDetailListInd, 'U');
		assertEquals(2, checkTest.size());
	}

	@Test
	public void testCostMatch() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("costMatch", BigDecimal.class, BigDecimal.class);
		method.setAccessible(true);
		method.invoke(displayServiceImpl, new BigDecimal(0), new BigDecimal(0));
		assertTrue(true);
	}
	
	@Test
	public void testCostMatchNonZero() throws Exception {
		Method method = DisplayServiceImpl.class.getDeclaredMethod("costMatch", BigDecimal.class, BigDecimal.class);
		method.setAccessible(true);
		method.invoke(displayServiceImpl, new BigDecimal(1), new BigDecimal(1));
		assertTrue(true);
	}
	
	@Test
	public void testUpdateCicMatchLength() throws Exception {
		List<DisplayItemCreateMatchCicDto> displayItemCreateMatchCicDtoList = new ArrayList<>();
		List<DisplayItemSimsUPC> ssimsComponentList = new ArrayList<>();
		DisplayItemSimsUPC DisplayItemSimsUPC = new DisplayItemSimsUPC();
		DisplayItemSimsUPC.setUpcDesc("ssimsComponentssimsComponentssimsComponentssimsComponent");
		DisplayItemCreateMatchCicDto displayItemCreateMatchCicDto = new DisplayItemCreateMatchCicDto();
		displayItemCreateMatchCicDto.setCompanyId("ABS");
		displayItemCreateMatchCicDto.setDivisionId("IND");
		displayItemCreateMatchCicDto.setProductSku("Product");
		displayItemCreateMatchCicDto.setSrcItemDesc("Desc");
		displayItemCreateMatchCicDto.setCaseUpc("Upc");
		displayItemCreateMatchCicDto.setCic("1");
		displayItemCreateMatchCicDto.setSsimsHeaderItemDesc("ssimsComponentssimsComponentssimsComponentssimsComponent");
		displayItemCreateMatchCicDto.setSsimsComponent(ssimsComponentList);
		displayItemCreateMatchCicDto.setSourceComponentUpc(sourceComponentUpc);
		displayItemCreateMatchCicDtoList.add(displayItemCreateMatchCicDto);
		Map<String, String> checkTest = displayServiceImpl.updateCicMatch(displayItemCreateMatchCicDtoList);
		assertTrue(checkTest.isEmpty());
	}
}