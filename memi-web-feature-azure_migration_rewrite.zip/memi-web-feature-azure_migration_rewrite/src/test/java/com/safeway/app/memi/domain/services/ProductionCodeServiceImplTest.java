package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.repositories.CommonSQLRepository;
import com.safeway.app.memi.domain.dtos.response.ProductionCodeDetailDto;
import com.safeway.app.memi.domain.dtos.response.SmicCodeDescWrapper;
import com.safeway.app.memi.domain.services.impl.ProductionCodeServiceImpl;

@SpringBootTest(classes = ProductionCodeServiceImpl.class)
public class ProductionCodeServiceImplTest {

	@Autowired
	private ProductionCodeServiceImpl productionCodeServiceImpl;
	@MockBean
	private CommonSQLRepository commonSQLRepo;

	@Test
	public void testGetProductionCode() {
		List<Object[]> productionCodeList = new ArrayList<>();
		productionCodeList.add(new Object[] { 1, 2, 3, "code" });
		when(commonSQLRepo.fetchProductionCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(productionCodeList);
		List<ProductionCodeDetailDto> productionCodeDetailDtos = productionCodeServiceImpl.getProductionCode("", "", "",
				"", "");
		assertEquals("code", productionCodeDetailDtos.get(0).getProductionCodeDesc());
	}

	@Test
	public void testGetProductionGroupCode() {
		List<Object[]> groupCodeAndDescList = new ArrayList<>();
		groupCodeAndDescList.add(new Object[] { new BigDecimal("0"), "" });
		when(commonSQLRepo.fetchProductionGroupCodeWithDesc()).thenReturn(groupCodeAndDescList);
		List<SmicCodeDescWrapper> smicCodeDescWrappers = productionCodeServiceImpl.getProductionGroupCode();
		assertEquals(new BigDecimal("0"), smicCodeDescWrappers.get(0).getCode());
	}

	@Test
	public void testGetProductionCategoryCode() {
		List<Object[]> categoryCodeAndDescList = new ArrayList<>();
		categoryCodeAndDescList.add(new Object[] { new BigDecimal("0"), "" });
		when(commonSQLRepo.fetchProductionCategoryCodeWithDesc(Mockito.anyString()))
				.thenReturn(categoryCodeAndDescList);
		List<SmicCodeDescWrapper> smicCodeDescWrappers = productionCodeServiceImpl.getProductionCategoryCode("");
		assertEquals(new BigDecimal("0"), smicCodeDescWrappers.get(0).getCode());
	}

	@Test
	public void testGetProductionClassCode() {
		List<Object[]> categoryCodeAndDescList = new ArrayList<>();
		categoryCodeAndDescList.add(new Object[] { new BigDecimal("0"), "" });
		when(commonSQLRepo.fetchProductionClassCodeWithDesc(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(categoryCodeAndDescList);
		List<SmicCodeDescWrapper> smicCodeDescWrappers = productionCodeServiceImpl.getProductionClassCode("", "");
		assertEquals(new BigDecimal("0"), smicCodeDescWrappers.get(0).getCode());
	}

}