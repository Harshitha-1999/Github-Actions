package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.app.memi.domain.dtos.response.MultiUnitSrcTargetDto;
import com.safeway.app.memi.domain.services.MultiUnitTypeService;

@WebMvcTest(controllers = MultiUnitTypeController.class)
public class MultiUnitTypeControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private MultiUnitTypeService multiUnitTypeService;

	@Test
	public void testGetSourceTargetData() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/multiUnitType/loadMultiUnit/company/division/matchIndicator"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetMultiUnitTypeSourceDataBasedOnTarget() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/listSrcOnTarSel")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetMultiUnitTypeTargetDataBasedOnSource() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/listTargetOnSrcSel")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testUpdateSouceBasedOnTarget() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/mapMultiUnitItem")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new MultiUnitSrcTargetDto())))
				.andExpect(status().isOk());
	}

	@Test
	public void testMarkMultiUnitItemDead() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/markMultiUnitDead")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testUnMarkMultiUnit() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/markNotAMultiUnit")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetMultiUnitSourceDetail() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/multiUnitSourceSearch")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetMultiUnitTargetDetail() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/multiUnitTargetSearch")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testUpdateSouceBasedOnTargetUnmap() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/unMapMultiUnitItem")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new MultiUnitSrcTargetDto())))
				.andExpect(status().isOk());
	}

	@Test
	public void testMarkItemAsMultiUnit() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/multiUnitType/markItemAsMultiUnit")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(new ArrayList<>()))).andExpect(status().isOk());
	}

	@Test
	public void testGetSourceDataRefresh() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders.get("/multiUnitType/loadMultiUnitSourceRefresh/company/division/matchIndicator"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetTargetDataRefresh() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders.get("/multiUnitType/loadMultiUnitTargetRefresh/company/division/matchIndicator"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetTargetUPCPopUpDetails() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/multiUnitType/loadMultiUnitTargetUpcPopUp/corpItemCd"))
				.andExpect(status().isOk());
	}

}
