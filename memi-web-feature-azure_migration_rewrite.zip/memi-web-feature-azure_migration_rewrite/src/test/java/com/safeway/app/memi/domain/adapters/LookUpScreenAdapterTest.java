package com.safeway.app.memi.domain.adapters;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.LookUpSearchResultVOS;

@SpringBootTest(classes = LookUpScreenAdapter.class)
public class LookUpScreenAdapterTest {

	@Autowired
	private LookUpScreenAdapter adapter;
	

	@Test
	public void buildLookUpSearchResultDto() {
		List<Object[]> resultList;
		resultList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[1] = "Src_conv_gp_cd";
		lkpObj [2] = "Src_dept_code ";
		lkpObj [3] = "Src_dept_name";
		lkpObj [4] = "Hier1_lvl_cd";
		lkpObj [5] = "Hier2_lvl_cd";
		lkpObj [6] = "Hier3_lvl_cd";
		lkpObj [7] = "Hier4_cd";
		lkpObj [8] = "Hier5_name";
		lkpObj [9] = "Hier1_lvl_name";
		lkpObj [10] = "Hier2_lvl_name";
		lkpObj [11] = "Hier3_lvl_name";
		lkpObj [12] = "rc_suplier_no ";
		lkpObj [13] = "Src_prod_sku";
		lkpObj [14] = "Src_item_description";
		lkpObj[15] = new BigDecimal(15);
		lkpObj[16] = new BigDecimal(15);
		lkpObj [17] = "Src_desc_size";
		lkpObj [18] = new BigDecimal(15);
		lkpObj [19] = "Src_uom" ;
		lkpObj[21] =new BigDecimal(15);
		lkpObj[22] = new BigDecimal(15);
		lkpObj[23] = new BigDecimal(15);
		lkpObj[24] = new BigDecimal(15);
		lkpObj[25] = "new BigDecimal(15)";
		lkpObj[26] = "new BigDecimal(15)";
		lkpObj[27] = "new BigDecimal(15)";
		lkpObj[28] = "new BigDecimal(15)";
		lkpObj[29] = new BigDecimal(15);
		lkpObj[30] = new BigDecimal(15);
		lkpObj[31] = "new BigDecimal(15)";
		lkpObj[32] = new BigDecimal(15);
		lkpObj[33] = "new BigDecimal(15)";
		lkpObj[34] = new BigDecimal(15);
		lkpObj[35] = new BigDecimal(15);
		lkpObj[36] = "new BigDecimal(15)";
		lkpObj[37] = new BigDecimal(15);
		lkpObj[38] = "new BigDecimal(15)";
		lkpObj[40] = "new BigDecimal(15)";
		lkpObj[41] = 'n';
		lkpObj[43] = new BigDecimal(15);
		lkpObj[44] = new BigDecimal(15);
		lkpObj[45] = new BigDecimal(15);
		lkpObj[46] = new BigDecimal(15);
		lkpObj[47] = new BigDecimal(15);
		lkpObj[48] = new BigDecimal(15);
		lkpObj[49] = new BigDecimal(15);
		lkpObj[50] = new BigDecimal(15);
		lkpObj[51] = new BigDecimal(15);
		lkpObj[52] = "new BigDecimal(15)";
		lkpObj[53] = "new BigDecimal(15)";
		lkpObj[54] = "new BigDecimal(15)";
		lkpObj[55] = "new BigDecimal(15)";
		lkpObj[56] = "new BigDecimal(15)";
		lkpObj[57] = new BigDecimal(15);
		lkpObj[58] = "new BigDecimal(15)";
		lkpObj[59] = "new BigDecimal(15)";
		lkpObj[60] = 'n';
		lkpObj[61] = new BigDecimal(15);
		lkpObj[62] = new BigDecimal(15);
		lkpObj[63] = new BigDecimal(15);
		lkpObj[64] = 'n';
		lkpObj[65] = "new BigDecimal(15)";
		lkpObj[39] = 'A';
		resultList.add(lkpObj);
		resultList.get(0)[20] = "UPCFormat";
		List<LookUpSearchResultVOS> lookUpSearchResultVOSs = adapter.buildLookUpSearchResultDto(resultList);
		assertEquals("Src_item_description", lookUpSearchResultVOSs.get(0).getSrc_item_description());
		assertEquals("Src_prod_sku", lookUpSearchResultVOSs.get(0).getSrc_prod_sku());
		assertEquals("Src_dept_code", lookUpSearchResultVOSs.get(0).getSrc_dept_code());
	}
	@Test
	public void buildLookUpSearchResultDto1() {
		List<Object[]> resultList;
		resultList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[1] = "Src_conv_gp_cd";
		lkpObj [2] = "Src_dept_code ";
		lkpObj [3] = "Src_dept_name";
		lkpObj [4] = "Hier1_lvl_cd";
		lkpObj [5] = "Hier2_lvl_cd";
		lkpObj [6] = "Hier3_lvl_cd";
		lkpObj [7] = "Hier4_cd";
		lkpObj [8] = "Hier5_name";
		lkpObj [9] = "Hier1_lvl_name";
		lkpObj [10] = "Hier2_lvl_name";
		lkpObj [11] = "Hier3_lvl_name";
		lkpObj [12] = "rc_suplier_no ";
		lkpObj [13] = "Src_prod_sku";
		lkpObj [14] = "Src_item_description";
		lkpObj[15] = new BigDecimal(15);
		lkpObj[16] = new BigDecimal(15);
		lkpObj [17] = "Src_desc_size";
		lkpObj [18] = new BigDecimal(15);
		lkpObj [19] = "Src_uom" ;
		lkpObj[21] =new BigDecimal(15);
		lkpObj[22] = new BigDecimal(15);
		lkpObj[23] = new BigDecimal(15);
		lkpObj[39] = 'A';
		resultList.add(lkpObj);
		resultList.get(0)[20] = "getUPCFormat";
		List<LookUpSearchResultVOS> lookUpSearchResultVOSs = adapter.buildLookUpSearchResultDto(resultList);
		assertEquals("Src_item_description", lookUpSearchResultVOSs.get(0).getSrc_item_description());
		assertEquals("Src_prod_sku", lookUpSearchResultVOSs.get(0).getSrc_prod_sku());
		assertEquals("Src_dept_code", lookUpSearchResultVOSs.get(0).getSrc_dept_code());
	}
	@Test
	public void buildLookUpSearchResultDto3() {
		List<Object[]> resultList;
		resultList = new ArrayList<>();
		Object[] lkpObj = new Object[66];
		lkpObj[1] = null;
		lkpObj [2] = null;
		lkpObj [3] = null;
		lkpObj [4] = null;
		lkpObj [5] = null;
		lkpObj [6] = null;
		lkpObj [7] = null;
		lkpObj [8] = null;
		lkpObj [9] = null;
		lkpObj [10] = null;
		lkpObj [11] = null;
		lkpObj [12] =null;
		lkpObj [13] = null;
		lkpObj [14] = null;
		lkpObj[15] = null;
		lkpObj[16] = null;
		lkpObj [17] = null;
		lkpObj [18] = null;
		lkpObj [19] = null;
		lkpObj[21] = null;
		lkpObj[22] = null;
		lkpObj[23] = null;
		lkpObj[39] = null;
		resultList.add(lkpObj);
		resultList.get(0)[20] = "getUPCFormatted";
		List<LookUpSearchResultVOS> lookUpSearchResultVOSs = adapter.buildLookUpSearchResultDto(resultList);
		assertEquals("", lookUpSearchResultVOSs.get(0).getSrc_item_description());
		assertEquals("", lookUpSearchResultVOSs.get(0).getSrc_prod_sku());
		assertEquals("", lookUpSearchResultVOSs.get(0).getSrc_dept_code());
	}

}
