/**
 * *************************************************************************
 * Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.adapters;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.BakeryCICSearchResults;
import com.safeway.app.memi.domain.dtos.response.BakeryMappedResultWrapper;
import com.safeway.app.memi.domain.dtos.response.BakerySKUSearchResults;
import com.safeway.app.memi.domain.util.BakeryActionValidations;

/**
 ****************************************************************************
 * NAME : BakeryAdapterTest
 * 
 * SYSTEM : MEMI
 * 
 * AUTHOR : TCS
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 Dec 10, 2021 - Initial Creation
 * *************************************************************************
 */

@SpringBootTest(classes = BakeryActionValidations.class)
public class BakeryAdapterTest {

	private BakeryAdapter bakeryAdapter = new BakeryAdapter();

	@Test
	public void testMapBakerySourceItem() {
		Object[] skuObj = new Object[50];
		List<Object[]> bakerySKUSearchResults = Collections.singletonList(skuObj);
		skuObj[21] = "E";
		skuObj[22] = "Y";
		List<BakerySKUSearchResults> skuSearchResults = bakeryAdapter.mapBakerySourceItem(bakerySKUSearchResults);
		skuObj[3] = "00";
		skuObj[0] = "sku";
		skuObj[1] = "itemdesc";
		skuObj[2] = "size";
		skuObj[4] = "dsp";
		skuObj[5] = "dssdwh";
		skuObj[6] = "dept";
		skuObj[7] = "test";
		skuObj[8] = new BigDecimal(1);
		skuObj[9] = "Mapped";
		skuObj[10] = new BigDecimal(1);
		skuObj[11] = new Timestamp(100l);
		skuObj[12] = new BigDecimal(1);
		skuObj[13] = 'a';
		skuObj[14] = "";
		skuObj[15] = "";
		skuObj[16] = "";
		skuObj[17] = new Timestamp(110l);
		skuObj[18] = new Double(1);
		skuObj[19] = new Double(1);
		skuObj[20] = "";
		skuObj[21] = "W";
		skuObj[22] = "N";
		skuObj[23] = "SupplierNm";
		skuObj[24] = "";
		skuSearchResults = bakeryAdapter.mapBakerySourceItem(bakerySKUSearchResults);
		assertEquals("SupplierNm", skuSearchResults.get(0).getSupplierNm());
	}

	@Test
	public void testMapBakeryTargetItem() {
		Object[] cicObj = new Object[50];
		List<Object[]> bakeryCICSearchResults = Collections.singletonList(cicObj);
		cicObj[25] = "VENDOR";
		List<BakeryCICSearchResults> cicSearchResults = bakeryAdapter.mapBakeryTargetItem(bakeryCICSearchResults);
		cicObj[0] = new BigDecimal(1);
		cicObj[1] = "ItemDesc";
		cicObj[2] = new BigDecimal(1);
		cicObj[3] = new BigDecimal(1);
		cicObj[4] = "";
		cicObj[5] = 'a';
		cicObj[6] = "00";
		cicObj[7] = new BigDecimal(1);
		cicObj[8] = 'a';
		cicObj[9] = 'a';
		cicObj[10] = "";
		cicObj[11] = "Mapped";
		cicObj[12] = "";
		cicObj[13] = new BigDecimal(1);
		cicObj[14] = new BigDecimal(1);
		cicObj[15] = 'a';
		cicObj[16] = new BigDecimal(1);
		cicObj[17] = new BigDecimal(1);
		cicObj[18] = "";
		cicObj[19] = new BigDecimal(1);
		cicObj[20] = new BigDecimal(1);
		cicObj[21] = new BigDecimal(1);
		cicObj[22] = "a";
		cicObj[23] = 'a';
		cicObj[24] = 'a';
		cicObj[25] = "VENDOR_DETAIL";
		cicObj[26] = "";
		cicObj[27] = "";
		cicSearchResults = bakeryAdapter.mapBakeryTargetItem(bakeryCICSearchResults);
		assertEquals("ItemDesc", cicSearchResults.get(0).getItemDesc());
	}

	@Test
	public void testSetMappedItems() {
		Object[] mappedObj = new Object[50];
		List<Object[]> mappedItems = Collections.singletonList(mappedObj);
		List<BakeryMappedResultWrapper> maddedItems = bakeryAdapter.setMappedItems(mappedItems);
		mappedObj[10] = new BigDecimal(1);
		mappedObj[11] = "";
		mappedObj[12] = new BigDecimal(1);
		mappedObj[13] = new BigDecimal(1);
		mappedObj[14] = new BigDecimal(1);
		mappedObj[15] = 'a';
		mappedObj[16] = 'a';
		mappedObj[17] = new Timestamp(100l);
		mappedObj[18] = "mappingType";
		mappedObj[0] = "";
		mappedObj[1] = "";
		mappedObj[2] = new BigDecimal(1);
		mappedObj[3] = new BigDecimal(1);
		mappedObj[4] = new BigDecimal(1);
		mappedObj[5] = 'a';
		mappedObj[6] = "";
		mappedObj[7] = new Timestamp(100l);
		mappedObj[8] = new Timestamp(100l);
		mappedObj[9] = new Timestamp(100l);
		maddedItems = bakeryAdapter.setMappedItems(mappedItems);
		assertEquals("mappingType", maddedItems.get(0).getMappingType());
	}
}
