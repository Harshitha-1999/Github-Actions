package com.safeway.app.memi.domain.adapters;
/* ***************************************************************************
 * NAME :DtoFieldsAdapter 
 * 
 * SYSTEM : MEMI 
 * 
 * AUTHOR : Varada Nellayikunnath  
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.0  May 12, 2017 vnell00 - Initial Creation
 * *************************************************************************
 */

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.data.entities.ItemXrefData;
import com.safeway.app.memi.data.entities.NewItemDetail;
import com.safeway.app.memi.data.entities.UIExceptionSrc;
import com.safeway.app.memi.data.entities.UiExceptionSrcPk;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;
import com.safeway.app.memi.domain.util.BakeryActionValidations;

@SpringBootTest(classes = BakeryActionValidations.class)
public class DtoFieldsAdapterTest {

	private DtoFieldsAdapter dtoFieldsAdapter = new DtoFieldsAdapter();

	@Test
	public void testMapToNewItemDetail() {
		NewItemDetailDto srcObj = new NewItemDetailDto();
		srcObj.setBatchId(123);
		srcObj.setCost("12");
		NewItemDetail newItemDto = dtoFieldsAdapter.mapToNewItemDetail(srcObj);
		assertEquals(123, newItemDto.getBatchId());
	}

	@Test
	public void testMapToNewItemDetailtoSave() {
		UIExceptionSrc sourceObj = new UIExceptionSrc();
		NewItemDetailDto uiSaveObj = new NewItemDetailDto();
		UiExceptionSrcPk exceptionSrcPk = new UiExceptionSrcPk();
		exceptionSrcPk.setCompanyId("999");
		exceptionSrcPk.setUpcCountry("1");
		exceptionSrcPk.setUpcSystem("0");
		exceptionSrcPk.setUpcManufacturer("0");
		exceptionSrcPk.setUpcSales("0");
		sourceObj.setUiSrcPk(exceptionSrcPk);
		sourceObj.setExcptnTypeCd('A');
		NewItemDetail newItem = dtoFieldsAdapter.mapToNewItemDetailtoSave(sourceObj, uiSaveObj);
		assertEquals("999", newItem.getNewItemPk().getCompanyId());

	}

	@Test
	public void testGetMasterData() {
		UIExceptionSrcDto srcDto = new UIExceptionSrcDto();
		srcDto.setCompanyId("999");
		srcDto.setUpcCountry("0");
		srcDto.setUpcManufacturer("0");
		srcDto.setUpcSales("0");
		srcDto.setUpcSystem("0");
		ItemXrefData masterData = dtoFieldsAdapter.getMasterData(srcDto);
		assertEquals("999", masterData.getItemPk().getCompanyId());
	}
}
