/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.memi.domain.services.ExceptionSrcService;
import com.safeway.app.memi.domain.services.FileUploadService;
import com.safeway.app.memi.domain.services.NewItemDetailService;
import com.safeway.app.memi.domain.util.ExceptionReportWritter;

@WebMvcTest(controllers = ExceptionSrcController.class)
public class ExceptionSrcControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private ExceptionSrcService exceptionSrcService;
	@MockBean
	private ExceptionReportWritter reportWritter;
	@MockBean
	private NewItemDetailService newItemDetailService;
	@MockBean
	private FileUploadService fileUploadService;

	@Test
	public void testGetExceptionSrcList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/list")).andExpect(status().isOk());
	}

	@Test
	public void testGetExceptionSrcForDivision() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/division/division")).andExpect(status().isOk());
	}

	@Test
	public void testGetExceptionSrcForUPC() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/sku/productSKU")).andExpect(status().isOk());
	}

	@Test
	public void testGetReportFile() throws Exception {
		MockedStatic<Files> fileMock = Mockito.mockStatic(Files.class);
		fileMock.when(() -> Files.exists(Mockito.any())).thenReturn(true);
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/downloadExcel/company/division/department/e/s"))
				.andExpect(status().isOk());
		fileMock.close();
	}

	@Test
	public void testGetExceptionSrcList1() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/listOverRideData/company/division"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetExceptionSKUList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/loadProductSKUs/company/division/department/e/s/t"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetExceptionSrcAugList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/listAugData/company/division")).andExpect(status().isOk());
	}

	@Test
	public void testloadItemDetail() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/loadData/company/division/productsku"))
				.andExpect(status().isOk());
	}

	@Test
	public void testloadItemDetailbyUpc() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/loadDataByUpc/company/division/sourceUpc"))
				.andExpect(status().isOk());
	}

	@Test
	public void testloadOverrideItemDetail() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/loadOverrideData/company/division/productsku"))
				.andExpect(status().isOk());
	}

	@Test
	public void testloadOverrideItemDetailByUPC() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/loadOverrideDataByUPC/company/division/sourceUpc"))
				.andExpect(status().isOk());
	}

	@Test
	public void testgetOnhandStatus() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/onhandStatus/company/divisio/productsku"))
				.andExpect(status().isOk());
	}

	@Test
	public void testloadUOMList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/UOM/list")).andExpect(status().isOk());
	}

	@Test
	public void testloadDepartmentList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/exsrc/department/list/company/division"))
				.andExpect(status().isOk());
	}

	@Test
	public void testupdateDepartment() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/exsrc/exception").accept(MediaType.APPLICATION_JSON)
				.content("itemDetails")).andExpect(status().isOk());
	}

	@Test
	public void testuploadFileHandler() throws Exception {
		MockMultipartFile jsonFile = new MockMultipartFile("file", "file", "application/json",
				"{\"key1\": \"value1\"}".getBytes());
		mockMvc.perform(MockMvcRequestBuilders.multipart("/exsrc/uploadFile").file(jsonFile)
				.param("companyId", "companyId").param("deptCode", "deptCode").param("divisionId", "divisionId")
				.param("divisionName", "divisionName").param("deptName", "deptName").param("userId", "userId")
				.accept(MediaType.APPLICATION_JSON).content("itemDetails")).andExpect(status().isOk());
	}
}