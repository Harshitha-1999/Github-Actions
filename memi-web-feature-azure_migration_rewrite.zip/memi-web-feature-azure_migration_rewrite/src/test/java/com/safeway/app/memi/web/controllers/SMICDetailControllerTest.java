/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.safeway.app.memi.web.controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.memi.domain.services.SMICDetailService;

@WebMvcTest(controllers = SMICDetailController.class)
public class SMICDetailControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private SMICDetailService smicService;

	@Test
	public void testGetCompaniesList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/smic/detail/grpCd/ctgryCd/clsCd/sbClsCd/subSbClass"))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetGroupCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/smic/smicdetail")).andExpect(status().isOk());
	}

	@Test
	public void testGetCategoryCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/smic/smicdetail/grpCd")).andExpect(status().isOk());
	}

	@Test
	public void testGetClassCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/smic/smicdetail/grpCd/ctgryCd")).andExpect(status().isOk());
	}

	@Test
	public void testGetSubClassCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/smic/smicdetail/grpCd/ctgryCd/clsCd")).andExpect(status().isOk());
	}

	@Test
	public void testGetsubSubClassCodeList() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/smic/smicdetail/grpCd/ctgryCd/clsCd/sbClsCd"))
				.andExpect(status().isOk());
	}
}
