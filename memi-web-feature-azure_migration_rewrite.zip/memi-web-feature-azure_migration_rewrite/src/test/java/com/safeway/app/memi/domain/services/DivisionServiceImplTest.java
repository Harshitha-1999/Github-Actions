/* Copyright 2016 Safeway, Inc. This document/file contains proprietary data
 * that is the property of Safeway, Inc. Information contained herein may not be
 * used,copied or disclosed in whole or in part except as permitted by a written
 * agreement signed by an officer of Safeway. Unauthorized use, copying or other
 * reproduction of this document/file is prohibited by law.
 * *************************************************************************
 */
package com.safeway.app.memi.domain.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

/* ***************************************************************************
 * NAME : ReportServiceImpl 
 * 
 * SYSTEM : MEMD 
 * 
 * AUTHOR : SafewayIT 
 * 
 * REVISION HISTORY
 * 
 * Revision 0.0.0.1 March 09, 2016 - Initial Creation
 * *************************************************************************
 */

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.safeway.app.memi.data.entities.Division;
import com.safeway.app.memi.data.repositories.DivisionRepository;
import com.safeway.app.memi.domain.dtos.response.DivisionDto;
import com.safeway.app.memi.domain.services.impl.DivisionServiceImpl;

@SpringBootTest(classes = DivisionServiceImpl.class)
public class DivisionServiceImplTest {

	@Autowired
	private DivisionServiceImpl divisionServiceImpl;
	@MockBean
	private DivisionRepository divisionRepo;

	@Test
	public void testGetAllItems() {
		List<Division> divisionList = new ArrayList<>();
		Division division = new Division();
		division.setCompanyid("companyId");
		divisionList.add(division);
		when(divisionRepo.findAll()).thenReturn(divisionList);
		List<DivisionDto> divisionDtos = divisionServiceImpl.getAllItems();
		assertEquals("companyId", divisionDtos.get(0).getCompanyID());
	}

	@Test
	public void findByCompanyId() {
		List<Division> divisionList = new ArrayList<>();
		Division division = new Division();
		division.setCompanyid("companyId");
		divisionList.add(division);
		when(divisionRepo.findByCompanyid(Mockito.anyString())).thenReturn(divisionList);
		List<DivisionDto> divisionDtos = divisionServiceImpl.findByCompanyId("companyID");
		assertEquals("companyId", divisionDtos.get(0).getCompanyID());
	}

}
