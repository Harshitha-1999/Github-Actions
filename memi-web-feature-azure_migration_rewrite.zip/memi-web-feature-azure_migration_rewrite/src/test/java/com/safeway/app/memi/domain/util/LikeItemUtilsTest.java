package com.safeway.app.memi.domain.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.TreeSet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.safeway.app.memi.domain.dtos.response.DCDetailsVo;
import com.safeway.app.memi.domain.dtos.response.NewItemDetailDto;
import com.safeway.app.memi.domain.dtos.response.UIExceptionSrcDto;

/* ***************************************************************************
 * NAME         : LikeItemUtilsTest
 *
 * SYSTEM       : MEMI
 *
 * AUTHOR       : TCS
 *
  REVISION HISTORY
 * 
 * Revision 0.0.0.0  Dec 08, 2021 - Initial Creation
 *
 ***************************************************************************/

@SpringBootTest(classes = BakeryActionValidations.class)
public class LikeItemUtilsTest {

	private LikeItemUtils likeItemUtils = new LikeItemUtils();

	@Test
	public void orderLikeItemsOriginal() {
		List<NewItemDetailDto> likeItems = new ArrayList<>();
		UIExceptionSrcDto excSrcItem = new UIExceptionSrcDto();
		NewItemDetailDto likeItem = new NewItemDetailDto();
		likeItems.add(likeItem);
		LikeItemUtils.orderLikeItemsOriginal(likeItems, null);
		likeItem.setPeckingOrder(1);
		likeItem.setPrimayUpcString("0-0-0-0");
		excSrcItem.setUpcCountry("0");
		excSrcItem.setUpcSystem("0");
		excSrcItem.setUpcManufacturer("0");
		excSrcItem.setUpcSales("0");
		LikeItemUtils.orderLikeItemsOriginal(likeItems, excSrcItem);
		likeItem.setPrimayUpcString("0-0-0-1");
		likeItem.setDispFlag('d');
		excSrcItem.setDspFlag('d');
		LikeItemUtils.orderLikeItemsOriginal(likeItems, excSrcItem);
		likeItem.setDispFlag('e');
		likeItem.setItemUsageTypInd('c');
		excSrcItem.setItmUsgeTypInd('c');
		LikeItemUtils.orderLikeItemsOriginal(likeItems, excSrcItem);
		likeItem.setItemUsageTypInd('f');
		BigDecimal bc = new BigDecimal(1);
		likeItem.setUpdSizeNmbr(bc);
		excSrcItem.setSizeNbr(bc);
		likeItem.setUpdSizeUom("updSizeUom");
		excSrcItem.setSzUom("updSizeUom");
		LikeItemUtils.orderLikeItemsOriginal(likeItems, excSrcItem);
		excSrcItem.setSzUom("updSizeU");
		LikeItemUtils.orderLikeItemsOriginal(likeItems, excSrcItem);
		assertTrue(true);
	}

	@Test
	public void testorderLikeItems() {
		List<NewItemDetailDto> detailDtos;
		List<Object[]> rogRankings = Collections.singletonList(new Object[] { "rank", "rogs,rogs" });
		NewItemDetailDto likeItem = new NewItemDetailDto();
		likeItem.setDcList(Collections.singleton(""));
		List<NewItemDetailDto> likeItems = Collections.singletonList(likeItem);
		UIExceptionSrcDto excSrcItem = new UIExceptionSrcDto();
		excSrcItem.setProductSrcCd("productSrcCd");
		excSrcItem.setPackWhse(new BigDecimal(1));
		excSrcItem.setVdCnvFactor(new BigDecimal(1));
		likeItem.setVendConvFactor(new BigDecimal(2));
		likeItem.setPackwhse(new BigDecimal(1));
		likeItem.setUpdSizeUom("updSizeUom");
		likeItem.setPrimayUpcString("00-00-00-00");
		excSrcItem.setUpcLIst(Arrays.asList("upc", "upc1", "upc2"));
		likeItem.setCaseUPC("caseUPC");
		likeItem.setDcList(Collections.singleton("dc"));
		likeItemUtils.orderLikeItems(likeItems, null, rogRankings);
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		excSrcItem.setCaseUPC("caseUPC");
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		likeItem.setProductSrcCd("productSrcCd");
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		excSrcItem.setSzUom("updSizeUom");
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		excSrcItem.setSizeNbr(new BigDecimal(1));
		likeItem.setUpdSizeNmbr(new BigDecimal(1));
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		likeItem.setVendConvFactor(new BigDecimal(1));
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		excSrcItem.setItmUsgeTypInd('I');
		likeItem.setItemUsageTypInd('I');
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		excSrcItem.setDspFlag('U');
		likeItem.setUpdDispFlag('U');
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		excSrcItem.setUpcCountry("00");
		excSrcItem.setUpcSystem("00");
		excSrcItem.setUpcManufacturer("00");
		excSrcItem.setUpcSales("00");
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		likeItem.setUpcs(new TreeSet<String>(Arrays.asList("upc", "upc1", "upc2")));
		detailDtos = likeItemUtils.orderLikeItems(likeItems, excSrcItem, rogRankings);
		assertNotNull(detailDtos);
	}

	@Test
	public void testformatCaseUpc() {
		String string = likeItemUtils.formatCaseUpc("caseUpc");
		assertEquals("caseUpc", string);
		string = likeItemUtils.formatCaseUpc("caseUpccaseUp");
		assertEquals("c-a-s-eUpcc-aseUp", string);
	}
	
	@Test
	public void testprocessLikeItemRanking() {
		List<NewItemDetailDto> likeItems = new ArrayList<>();
		NewItemDetailDto likeItem = new NewItemDetailDto();
		UIExceptionSrcDto excSrcItem = new UIExceptionSrcDto();
		DCDetailsVo dcDetailsVo = new DCDetailsVo();
		dcDetailsVo.setRogs(new HashSet<>(Arrays.asList("rog1","rog2")));
		int startingRank = 0;
		likeItems.add(likeItem);
		likeItem.setUpcs(new HashSet<>(Arrays.asList("upc1","upc2")));
		excSrcItem.setUpcLIst(Arrays.asList("upc1","upc3"));
		likeItemUtils.processLikeItemRanking(likeItems, null, startingRank);
		likeItemUtils.processLikeItemRanking(likeItems, excSrcItem, startingRank);
		likeItem.setCaseUPC("caseUPC");
		excSrcItem.setCaseUPC("caseUPC");
		likeItemUtils.processLikeItemRanking(likeItems, excSrcItem, 9);
		likeItem.setDcList(new HashSet<>(Arrays.asList("dc1","dc2")));
		likeItemUtils.processLikeItemRanking(likeItems, excSrcItem, 10);
		likeItem.setDcDetails(Arrays.asList(dcDetailsVo));
		List<NewItemDetailDto> res = likeItemUtils.processLikeItemRanking(likeItems, excSrcItem, 12);
		assertNotNull(res);
	}
	
	@Test
	public void testaddToItemsRankingTable() {
		Hashtable<Integer, List<NewItemDetailDto>> likeItemRankingTable = new Hashtable<>();
		List<NewItemDetailDto> items = new ArrayList<NewItemDetailDto>();
		int rank = 0;
		likeItemUtils.addToItemsRankingTable(likeItemRankingTable, items, rank);
		assertTrue(true);
	}

}
