package com.albertsons.dxpf.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="TrailerEventContent")
public class TrailerContent {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long trailerEventContentSk ;
	@Column(name = "SourceCommodityCd", nullable = false)
	private String sourceCommodityCd ;
	@Column(name = "PalletCnt", nullable = false)
	private Integer palletCnt ;
	@Column(name = "CreateTS", nullable = false)
	private Timestamp dwCreateTs;
	@Column(name = "CreateUserID", nullable = false)
	private String dwCreateUserId;
	@Column(name = "LastUpdTS")
	private Timestamp dwLastUpdateTs;
	@Column(name = "LastUpdUserID")
	private String dwLastUpdatedUserId;
	@ManyToOne
	@JoinColumn(name="TrailerEventSK", referencedColumnName="TrailerEventSK")
	TrailerEvent trailerEvent ;	
	
}
