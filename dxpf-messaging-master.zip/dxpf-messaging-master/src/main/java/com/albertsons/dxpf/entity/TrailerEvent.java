package com.albertsons.dxpf.entity;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="TrailerEvent")
public class TrailerEvent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	/*@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trailer_event_seq")
    @SequenceGenerator(name = "trailer_event_seq", sequenceName = "TRAILER_EVENT_SEQ", allocationSize = 1)*/
	@Column(name = "TrailerEventSK", unique = true, nullable = false)
	private long id ;
	@Column(name = "DCID", nullable = false)
	private String dc_id ;
	@Column(name = "EventTypeInd", nullable = false)
	private String eventType;
	@Column(name = "RouteID", nullable = false)
	private String routeId;
	@Column(name = "EventTS", nullable = false)
	private Timestamp eventTs;
	@Column(name = "TrailerID", nullable = false)
	private String trailerId;
	@Column(name = "CreateTS", nullable = false)
	private Timestamp dwCreateTs;
	@Column(name = "CreateUserID", nullable = false)
	private String dwCreateUserId;
	@Column(name = "LastUpdTS")
	private Timestamp dwLastUpdateTs;
	@Column(name = "LastUpdUserID")
	private String dwLastUpdatedUserId;
	@OneToMany(mappedBy="trailerEvent", cascade = {CascadeType.ALL})
	private List <TrailerContent> trailerContents ;	
}
