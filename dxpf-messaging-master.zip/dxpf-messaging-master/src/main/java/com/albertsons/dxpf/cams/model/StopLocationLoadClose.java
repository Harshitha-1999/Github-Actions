package com.albertsons.dxpf.cams.model;

public class StopLocationLoadClose {

}
