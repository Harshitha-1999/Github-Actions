package com.albertsons.dxpf.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;
import org.xml.sax.SAXException;

import com.albertsons.dxpf.cams.model.GetTransportationStatus;
import com.albertsons.dxpf.cams.model.GetTransportationStatusLoadClose;
import com.albertsons.dxpf.cams.model.ShipmentOrderTypeLoadClose;
import com.albertsons.dxpf.cams.model.ShipmentStopsTypeLoadClose;
import com.albertsons.dxpf.cams.model.TransportationStatusType;
import com.albertsons.dxpf.cams.model.TransportationStatusTypeLoadClose;
import com.albertsons.dxpf.cams.model.TripResourceType;
import com.albertsons.dxpf.dxpc.model.Commodity;
import com.albertsons.dxpf.dxpc.model.Location;
import com.albertsons.dxpf.dxpc.model.TrailerRecord;
import com.albertsons.dxpf.entity.DCTimeZoneDetails;
import com.albertsons.dxpf.entity.TrailerContent;
import com.albertsons.dxpf.entity.TrailerEvent;
import com.albertsons.dxpf.model.TrailerData;

public class DxpfConsumerUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(DxpfConsumerUtils.class);

	private static final String GET_SHIPMENT_ORIGIN = "getShipmentOrigin";
	private static final String GET_ORIGIN_LOCATION_DATA = "getOriginLocationData";
	private static final String GET_EVENT_STATUS = "getEventStatus";

	private static final String GET_CODE = "getCode";
	private static final String GET_VALUE = "getValue";
	private static final String FEATURE_URL = "http://apache.org/xml/features/disallow-doctype-decl" ;
	
	
	
	private DxpfConsumerUtils() {

	}

	public static boolean validate(String message, String xsdPath) {
		try {
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			schemaFactory.setFeature(FEATURE_URL, true);
			URL xsdURL = DxpfConsumerUtils.class.getResource(xsdPath);
			Schema schema = schemaFactory.newSchema(xsdURL);
			Source xmlInput = new StreamSource(new StringReader(message));
			Validator validator = schema.newValidator();
			validator.validate(xmlInput);
		} catch (SAXException e) {
			String regtxt = ".*Invalid content was found starting with element .* No child element is expected at this point.";
			if (Pattern.matches(regtxt, e.getMessage())) {
				LOGGER.warn("***************XML Validation Error Occured - Invalid content ************************** {}", e.getMessage());
				String newtag = StringUtils.substringBetween(e.getMessage(), "'Abs:", "'.");
				Pattern p = Pattern.compile("<Abs:" + newtag + ">(.*?)</Abs:" + newtag + ">",
						Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
				String newmessage = p.matcher(message).replaceAll("");
				validate(newmessage, xsdPath);
			} else {
				LOGGER.error("***************XML Validation Error Occured ************************** {}", e.getMessage());
				return false;
			}
			
		} catch (IOException e) {
				LOGGER.error("***************XML Validation Error Occured ************************** {}", e.getMessage());
				return false;
		}
		return true;
	}
	
	
	public static boolean validateLoadClose(String message) {
		String xsdPath = "/xsd/BOD/GetTransportationStatusLoadClose.xsd";
		boolean isValidated = validate(message, xsdPath);
		return isValidated;
	}

	public static boolean validateDXPCLoadClose(String message) {
		String xsdPath = "/xsd/BOD/DXPCLoadClose.xsd";
		boolean isValidated = validate(message, xsdPath);
		return isValidated;
	}

	public static GetTransportationStatus unMarshall(String message) throws JAXBException {
		JAXBContext jbc = JAXBContext.newInstance(GetTransportationStatus.class);
		Unmarshaller unmarshaller = jbc.createUnmarshaller();
		Source xmlInput = new StreamSource(new StringReader(message));
		JAXBElement<GetTransportationStatus> root = unmarshaller.unmarshal(xmlInput, GetTransportationStatus.class);
		return root.getValue();
	}
	
	public static GetTransportationStatusLoadClose unMarshallLoadClose(String message) throws JAXBException {
		JAXBContext jbc = JAXBContext.newInstance(GetTransportationStatusLoadClose.class);
		Unmarshaller unmarshaller = jbc.createUnmarshaller();
		Source xmlInput = new StreamSource(new StringReader(message));
		JAXBElement<GetTransportationStatusLoadClose> root = unmarshaller.unmarshal(xmlInput, GetTransportationStatusLoadClose.class);
		return root.getValue();
	}

	public static TrailerRecord unMarshallDXPCLoadClose(String fileLocation) throws JAXBException {
		TrailerRecord trailerRecord = new TrailerRecord();
		try (FileInputStream fileInputStream = new FileInputStream(fileLocation)) {
			JAXBContext jbc = JAXBContext.newInstance(com.albertsons.dxpf.dxpc.model.TrailerRecord.class);
			Unmarshaller unmarshaller = jbc.createUnmarshaller();
			trailerRecord = (TrailerRecord) unmarshaller.unmarshal(fileInputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return trailerRecord;
	}
	public static String extractMessageType(GetTransportationStatus getTransportationStatus)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {

		TransportationStatusType transportationStatusType = (TransportationStatusType) getTransportationStatus
				.getDocumentDataAndTransportationStatusData().get(1);
		String eventStatus = (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, GET_EVENT_STATUS, GET_CODE }, StringUtils.EMPTY);

		if (!ObjectUtils.isEmpty(eventStatus) && "DISPATCH".equalsIgnoreCase(eventStatus.trim())) {
			return "TRIP_DISPATCH";
		} else {
			return "TRIP_COMPLETE";
		}
	}

	public static String extractDcId(GetTransportationStatus getTransportationStatus)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		TransportationStatusType transportationStatusType = (TransportationStatusType) getTransportationStatus
				.getDocumentDataAndTransportationStatusData().get(1);
		return (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, GET_ORIGIN_LOCATION_DATA, "getAltFacilityId" }, StringUtils.EMPTY);
	}

	// TODO
	public static String extractLoadCloseDcId(GetTransportationStatusLoadClose getTransportationStatus)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		TransportationStatusTypeLoadClose transportationStatusType = (TransportationStatusTypeLoadClose) getTransportationStatus
				.getDocumentDataAndTransportationStatusData().get(1);
		return (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, GET_ORIGIN_LOCATION_DATA, "getDistributionCenterId" },
				StringUtils.EMPTY);
	}

	public static String extractCamsSiteCd(GetTransportationStatus getTransportationStatus)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		TransportationStatusType transportationStatusType = (TransportationStatusType) getTransportationStatus
				.getDocumentDataAndTransportationStatusData().get(1);
		return (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, GET_ORIGIN_LOCATION_DATA, "getSiteId" }, StringUtils.EMPTY);
	}

	public static Timestamp extractTimestamp(Object baseObject, String[] methodList)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {

		Object result = valueReader(baseObject, methodList);

		if (result != null) {
			XMLGregorianCalendar value = (XMLGregorianCalendar) result;
			return new Timestamp(value.toGregorianCalendar().getTimeInMillis());
		} else {
			return null;
		}

	}

	public static Object valueReader(Object baseObject, String[] methodList, Object... defaultValue)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {

		Object defaultReturnValue;

		if (!(ObjectUtils.isEmpty(defaultValue)) && (defaultValue.length > 0)) {
			defaultReturnValue = defaultValue[0];
		} else {
			defaultReturnValue = null;
		}

		Object result = null;
		Object node = baseObject;

		if (ObjectUtils.isEmpty(node)) {
			return defaultReturnValue;
		}

		for (String methodName : methodList) {

			Method method = node.getClass().getDeclaredMethod(methodName);
			result = method.invoke(node);

			if (result == null) {
				break;
			} else {
				node = result;
			}

		}

		if (result == null) {
			return defaultReturnValue;
		} else {
			return result;
		}
	}

	public static String extractLoadCloseDescription (GetTransportationStatusLoadClose getTransportationStatus) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		TransportationStatusTypeLoadClose transportationStatusType = (TransportationStatusTypeLoadClose) getTransportationStatus
				.getDocumentDataAndTransportationStatusData().get(1);
		String eventDescription = (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, GET_EVENT_STATUS, "getDescription" }, StringUtils.EMPTY);
		return eventDescription ;
	}
	
	public static TrailerData mapCamsDXPFTrailerEvent(GetTransportationStatus getTransportationStatus,
			String sourceApplicationCd)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		TrailerEvent trailerEvent = new TrailerEvent();
		List<TrailerEvent> trailerEvents = new ArrayList<>();
		TrailerData trailerData = new TrailerData();

		TransportationStatusType transportationStatusType = (TransportationStatusType) getTransportationStatus
				.getDocumentDataAndTransportationStatusData().get(1);

		String routeId = (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, "getRouteId" }, StringUtils.EMPTY);

		Timestamp dispatchTs = extractTimestamp(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, "getDispatchTs", GET_VALUE });

		String dcIdFromXML = extractDcId(getTransportationStatus);

		trailerEvent.setDc_id(dcIdFromXML);
		trailerEvent.setRouteId(!StringUtils.isEmpty(routeId) ? routeId.trim().toUpperCase() : null);
		trailerEvent.setEventTs(dispatchTs);
		trailerEvent.setEventType("D");
		trailerEvent.setDwCreateUserId(StringUtils.isEmpty(sourceApplicationCd) ? null : sourceApplicationCd);
		trailerEvent.setDwCreateTs(new Timestamp(System.currentTimeMillis()));
		trailerEvent.setDwLastUpdatedUserId(trailerEvent.getDwCreateUserId());
		trailerEvent.setDwLastUpdateTs(trailerEvent.getDwCreateTs());

		for (TripResourceType resource : transportationStatusType.getResourceData()) {
			if (!(StringUtils.isEmpty(resource.getResourceType().getCode()))
					&& resource.getResourceType().getCode().equalsIgnoreCase("TRAILER")
					&& !ObjectUtils.isEmpty(resource.getTrailerOrdinalNbr())) {
				if ((resource.getTrailerOrdinalNbr() == 1)) {
					String trailerId = fetchTrailerIdFromResourceType(resource);
					trailerEvent.setTrailerId(trailerId);
					trailerEvents.add(trailerEvent);
				} else if ((resource.getTrailerOrdinalNbr() == 2)) {
					String secTrailer = fetchTrailerIdFromResourceType(resource);
					if (!StringUtils.isEmpty(routeId) && !StringUtils.isEmpty(secTrailer)) {
						boolean pupRoute = checkForTrailerPupRoute(routeId);
						TrailerEvent secTrailerEvent = populateSecondTrailerEvent(trailerEvent, secTrailer,
								sourceApplicationCd, pupRoute);
						trailerEvents.add(secTrailerEvent);
					}
				}
			}
		}
		trailerData.setTrailerEvents(trailerEvents);
		return trailerData;
	}
	
	public static TrailerEvent populateSecondTrailerEvent(TrailerEvent trailerEvent, String secTrailer,
			String sourceApplicationCd, boolean pupRoute) {
		TrailerEvent secTrailerEvent = new TrailerEvent();
		if (!StringUtils.isEmpty(secTrailer) && pupRoute == true && trailerEvent.getDc_id().equalsIgnoreCase("52")) {
			String routeId = null;
			String secRouteId = null;
			if (!StringUtils.isEmpty(trailerEvent.getRouteId())) {
				routeId = trailerEvent.getRouteId();
				if (routeId.length() > 0) {
					String pupTrailerId = Integer.toString(Integer.parseInt(routeId.substring(0, 4)) + 1);
					String pupTrailerRoute = routeId.substring(4, routeId.length());
					String pupFinalRoute = pupTrailerId.concat(pupTrailerRoute);
					secRouteId = pupFinalRoute.trim().toUpperCase();

					secTrailerEvent.setEventType(trailerEvent.getEventType());
					secTrailerEvent.setDc_id(trailerEvent.getDc_id());
					secTrailerEvent.setRouteId(secRouteId);
					secTrailerEvent.setEventTs(trailerEvent.getEventTs());
					secTrailerEvent.setTrailerId(secTrailer);
					secTrailerEvent
							.setDwCreateUserId(StringUtils.isEmpty(sourceApplicationCd) ? null : sourceApplicationCd);
					secTrailerEvent.setDwCreateTs(new Timestamp(System.currentTimeMillis()));
					secTrailerEvent.setDwLastUpdatedUserId(secTrailerEvent.getDwCreateUserId());
					secTrailerEvent.setDwLastUpdateTs(
							!ObjectUtils.isEmpty(secTrailerEvent.getDwCreateTs()) ? secTrailerEvent.getDwCreateTs()
									: null);
				}
			}
		}
		return secTrailerEvent;
	}

	public static String fetchTrailerIdFromResourceType (TripResourceType resource) {
		String secTrailer = null;
		if (!StringUtils.isEmpty(resource.getEmployeeId())) {
			secTrailer = resource.getEmployeeId();
		} else if (!ObjectUtils.isEmpty(resource.getResourceCd())
				&& !ObjectUtils.isEmpty(resource.getResourceCd().getCode())) {
			secTrailer = resource.getResourceCd().getCode();
		}
		return secTrailer ;
	}
	
	public static boolean checkForTrailerPupRoute (String routeId) {
		boolean pupRoute = true;
		int length = routeId.length();
		if (length > 4) {
			if (length > 7) {
				pupRoute = false;
			} else {
				if (routeId.charAt(4) != ' '
						&& ((routeId.charAt(4) == 'r') || (routeId.charAt(4) == 'R'))) {
					// proper route
				} else {
					pupRoute = false;
				}
				pupRoute = validatePupRouteWithRouteId (routeId, length, pupRoute) ;
				
			}
		} else if (length == 4) {
			pupRoute = validatePupRouteWithRouteId (routeId, length, pupRoute) ;
		} else {
			pupRoute = false;
		}
		return pupRoute ;
	}
	
	public static boolean validatePupRouteWithRouteId (String routeId, int length, boolean pupRoute) {
		if (length > 5 && routeId.charAt(5) != ' ' && !Character.isDigit(routeId.charAt(5))) {
				pupRoute = false;
		}
		if (length > 6 && routeId.charAt(6) != ' ' && !Character.isAlphabetic(routeId.charAt(6))) {
				pupRoute = false;
		}
		if (length == 4) {
			for (char c : routeId.toCharArray()) {
				if (!Character.isDigit(c)) {
					pupRoute = false;
				}
			}
		}
		return pupRoute ;
	}
	

	public static TrailerData mapLoadCloseDXPFTrailerEvent(GetTransportationStatusLoadClose parsedLoadCloseMessage,
			String sourceApplicationCd)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		TrailerEvent trailerEvent = new TrailerEvent();
		List<TrailerEvent> trailerEvents = new ArrayList<>();
		List<TrailerContent> trailerContents = new ArrayList<>();
		TrailerData trailerData = new TrailerData();

		TransportationStatusTypeLoadClose transportationStatusType = (TransportationStatusTypeLoadClose) parsedLoadCloseMessage
				.getDocumentDataAndTransportationStatusData().get(1);

		trailerEvent.setEventType("C");
		String dcIdFromXML = extractLoadCloseDcId(parsedLoadCloseMessage);
		trailerEvent.setDc_id(StringUtils.isEmpty(dcIdFromXML) ? null : dcIdFromXML);

		String routeId = (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, "getRouteId" }, StringUtils.EMPTY);
		trailerEvent.setRouteId(!StringUtils.isEmpty(routeId) ? routeId.trim().toUpperCase() : null);

		Timestamp createTs = extractTimestamp(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, "getCreateTs", GET_VALUE });
		trailerEvent.setEventTs(createTs);
		trailerEvent.setDwCreateUserId(StringUtils.isEmpty(sourceApplicationCd) ? null : sourceApplicationCd);
		trailerEvent.setDwCreateTs(new Timestamp(System.currentTimeMillis()));
		trailerEvent.setDwLastUpdatedUserId(!StringUtils.isEmpty(trailerEvent.getDwCreateUserId()) ? trailerEvent.getDwCreateUserId() : null);
		trailerEvent.setDwLastUpdateTs(!ObjectUtils.isEmpty(trailerEvent.getDwCreateTs()) ? trailerEvent.getDwCreateTs() : null);
	
		String equipmentType = (String) valueReader(transportationStatusType,
				new String[] { GET_SHIPMENT_ORIGIN, "getCarrier", "getEquipmentType", GET_CODE }, StringUtils.EMPTY);
		if((!StringUtils.isEmpty(equipmentType)) && (equipmentType.equalsIgnoreCase("Trailer"))) {
			String trailerId = (String) valueReader(transportationStatusType,
					new String[] { GET_SHIPMENT_ORIGIN, "getCarrier", "getEquipmentNbr" }, StringUtils.EMPTY);
			trailerEvent.setTrailerId(trailerId);
		}

		trailerEvents.add(trailerEvent);
		for (ShipmentStopsTypeLoadClose shipmentStop : transportationStatusType.getShipmentStops()) {
			List<ShipmentOrderTypeLoadClose> shipmentDetails = shipmentStop.getShipmentDetail();
			shipmentDetails.stream().forEach(shipmentOrder -> {
				TrailerContent trailerContent = new TrailerContent();
				Map<String, Integer> palletMap = fetchPalletCountDetails (shipmentOrder);				
				palletMap.entrySet().stream().forEach(entry -> {
					trailerContent.setSourceCommodityCd(entry.getKey());
					trailerContent.setPalletCnt(entry.getValue());
					trailerContent.setDwCreateUserId(sourceApplicationCd);
					trailerContent.setDwCreateTs(new Timestamp(System.currentTimeMillis()));
					trailerContent.setDwLastUpdatedUserId(trailerContent.getDwCreateUserId()) ;
					trailerContent.setDwLastUpdateTs(trailerContent.getDwCreateTs()) ;
					trailerContents.add(trailerContent);
				});
			});
		}
		trailerData.setTrailerEvents(trailerEvents);
		trailerData.setTrailerContents(trailerContents);
		return trailerData;
	}
	
	public static Map<String, Integer> fetchPalletCountDetails (ShipmentOrderTypeLoadClose shipmentOrder) {
		Map<String, Integer> palletMap = new HashMap<>();
		if (!StringUtils.isEmpty(shipmentOrder.getWareHouseDepartmentCd())
				&& !ObjectUtils.isEmpty(shipmentOrder.getPalletCnt())) {
			if (ObjectUtils.isEmpty(palletMap.get(shipmentOrder.getWareHouseDepartmentCd()))) {
				palletMap.put(shipmentOrder.getWareHouseDepartmentCd(), shipmentOrder.getPalletCnt());
			} else {
				int palletCount = palletMap.get(shipmentOrder.getWareHouseDepartmentCd())
						+ shipmentOrder.getPalletCnt();
				palletMap.put(shipmentOrder.getWareHouseDepartmentCd(), palletCount);
			}
		}
		return palletMap ;
	}
	
	public static TrailerData mapDXPCLoadCloseMessage(TrailerRecord parsedTrailerRecord, DCTimeZoneDetails dcTimeZoneDetails) {
		TrailerEvent trailerEvent = new TrailerEvent();
		List<TrailerEvent> trailerEvents = new ArrayList<>();
		List<TrailerContent> trailerContents = new ArrayList<>();
		TrailerData trailerData = new TrailerData();
		
		trailerEvent.setEventType("X");
		trailerEvent.setDc_id(!StringUtils.isEmpty(dcTimeZoneDetails.getDcId()) ? dcTimeZoneDetails.getDcId() : null);
		trailerEvent.setTrailerId(!StringUtils.isEmpty(parsedTrailerRecord.getTrailerID()) ? parsedTrailerRecord.getTrailerID() : null);
		trailerEvent.setRouteId(!StringUtils.isEmpty(parsedTrailerRecord.getRouteNum()) ? parsedTrailerRecord.getRouteNum().trim().toUpperCase() : null);
		if (!StringUtils.isEmpty(parsedTrailerRecord.getTrailerReadyTime())) {
			Instant instant = Instant.parse(parsedTrailerRecord.getTrailerReadyTime());
			if (!StringUtils.isEmpty(dcTimeZoneDetails.getTimeZoneCode())) {
				ZonedDateTime zdtInLocalTimeline = instant.atZone(ZoneId.of(dcTimeZoneDetails.getTimeZoneCode()));
				trailerEvent.setEventTs(Timestamp.valueOf(zdtInLocalTimeline.toLocalDateTime()));
			}
		}
		trailerEvent.setDwCreateUserId("EXE");
		trailerEvent.setDwCreateTs(new Timestamp(System.currentTimeMillis()));
		trailerEvent.setDwLastUpdatedUserId(!StringUtils.isEmpty(trailerEvent.getDwCreateUserId()) ? trailerEvent.getDwCreateUserId() : null);
		trailerEvent.setDwLastUpdateTs(!ObjectUtils.isEmpty(trailerEvent.getDwCreateTs()) ? trailerEvent.getDwCreateTs() : null);
		
		Map<String, Integer> palletMap = fetchPalletCountDetailsForDxpc (parsedTrailerRecord) ;
		trailerEvents.add(trailerEvent) ;
		
		//Trailer contents
		palletMap.entrySet().stream().forEach(entry -> {
			TrailerContent trailerContent = new TrailerContent();
			trailerContent.setSourceCommodityCd(entry.getKey());
			trailerContent.setPalletCnt(entry.getValue());
			trailerContent.setDwCreateUserId("EXE");
			trailerContent.setDwCreateTs(new Timestamp(System.currentTimeMillis()));
			trailerContent.setDwLastUpdatedUserId(trailerContent.getDwCreateUserId()) ;
			trailerContent.setDwLastUpdateTs(trailerContent.getDwCreateTs());
			trailerContents.add(trailerContent);
		});
		
		trailerData.setTrailerEvents(trailerEvents);
		trailerData.setTrailerContents(trailerContents);
		return trailerData;
		
	}
	public static Map<String, Integer> fetchPalletCountDetailsForDxpc(TrailerRecord parsedTrailerRecord) {
		Map<String, Integer> palletMap = new HashMap<>();
		if (!ObjectUtils.isEmpty(parsedTrailerRecord.getLocations())
				&& !ObjectUtils.isEmpty(parsedTrailerRecord.getLocations().getLocation())) {
			List<Location> locations = parsedTrailerRecord.getLocations().getLocation();
			locations.stream().forEach(location -> {
				if (!ObjectUtils.isEmpty(location.getCommodity())) {
					List<Commodity> commodityList = location.getCommodity();
					commodityList.stream().forEach(commodity -> {
						if (ObjectUtils.isEmpty(palletMap.get(commodity.getCode()))) {
							palletMap.put(commodity.getCode(), commodity.getPallets());
						} else {
							int palletCount = palletMap.get(commodity.getCode()) + commodity.getPallets();
							palletMap.put(commodity.getCode(), palletCount);
						}
					});
				}
			});
		}
		return palletMap ;
	}
	public static Timestamp convertStringToTimeStamp(String timeStamp) {
        return Timestamp.valueOf(timeStamp.replace("T", " "));
    }
}
