package com.albertsons.dxpf.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.albertsons.dxpf.entity.TrailerContent;
import com.albertsons.dxpf.entity.TrailerEvent;
import com.albertsons.dxpf.model.TrailerData;
import com.albertsons.dxpf.repository.TrailerEventRepository;
import com.albertsons.dxpf.service.DxpfService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DxpfServiceImpl implements DxpfService {

	@Autowired
	TrailerEventRepository trailerEventRepository;

	@Override
	public boolean persistDXPFTrailerEvents(TrailerData trailerData) {
		try {
			List<TrailerContent> trailerContents = new ArrayList<>();

			if (!CollectionUtils.isEmpty(trailerData.getTrailerContents())) {
				trailerContents = trailerData.getTrailerContents();
			}
			for (TrailerEvent trailerEvent : trailerData.getTrailerEvents()) {
				trailerContents.stream().forEach(trailerContent -> {
					trailerContent.setTrailerEvent(trailerEvent);
				});
				trailerEvent.setTrailerContents(CollectionUtils.isEmpty(trailerContents) ? null : trailerContents);
				trailerEventRepository.save(trailerEvent);
			}
			return true ;
		} catch (Exception e) {
			log.error("Error while persisting to Database {}", e.getMessage());
			return false ;
		}
	}
}
