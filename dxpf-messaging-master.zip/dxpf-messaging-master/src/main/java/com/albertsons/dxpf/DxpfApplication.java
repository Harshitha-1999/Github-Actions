package com.albertsons.dxpf;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication(scanBasePackages = "com.albertsons.dxpf.*")
@PropertySource(value = "dctimezone.sql.properties")
public class DxpfApplication 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(DxpfApplication.class, args);
    }
}
