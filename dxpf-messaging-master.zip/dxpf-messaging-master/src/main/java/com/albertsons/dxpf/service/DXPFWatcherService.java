package com.albertsons.dxpf.service;

import java.io.IOException;

public interface DXPFWatcherService {
	
	boolean processDXPCLoadCloseMessage(String messagePath, String dcCenter) throws IOException ;
}
