package com.albertsons.dxpf.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name="DistributionCenter")
public class DCTimeZoneDetails {
	@Id
	@Column(name = "DstCntrCd", nullable = false)
	private String distributionCenterCd ;
	@Column(name = "DCID", nullable = false)
	private String dcId ;
	@Column(name = "TMZoneCd", nullable = false)
	private String timeZoneCode ;
	@Column(name = "MountainTMZoneOffsetHr", nullable = false)
	private Integer tz_offset ;
	@Column(name = "CreateTS", nullable = false)
	private Timestamp dwCreateTs;
	@Column(name = "CreateUserID", nullable = false)
	private String dwCreateUserId;
	@Column(name = "LastUpdTS")
	private Timestamp dwLastUpdateTs;
	@Column(name = "LastUpdUserID")
	private String dwLastUpdatedUserId;
}
