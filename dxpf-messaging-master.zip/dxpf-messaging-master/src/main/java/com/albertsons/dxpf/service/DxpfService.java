package com.albertsons.dxpf.service;

import com.albertsons.dxpf.model.TrailerData;

public interface DxpfService {
	boolean persistDXPFTrailerEvents(TrailerData trailerData) ;
}
