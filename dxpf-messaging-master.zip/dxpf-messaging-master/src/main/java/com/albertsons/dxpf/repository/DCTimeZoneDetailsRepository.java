package com.albertsons.dxpf.repository;

import com.albertsons.dxpf.entity.DCTimeZoneDetails;

public interface DCTimeZoneDetailsRepository {
	 public DCTimeZoneDetails fetchDCTimeZoneDetails(String dstCntrCd);
}
