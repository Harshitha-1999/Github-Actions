package com.albertsons.dxpf.config;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;

import com.albertsons.dxpf.exception.KafkaTimeoutException;

@Configuration
@EnableKafka
public class DxpfConsumerConfig {
	private static final Logger log = LoggerFactory.getLogger(DxpfConsumerConfig.class);
	@Value("${kafka.server}")
	private String consumerServer;
	
	@Value("${app.cams.topic.dxpf}")
	private String topic;
	
	@Value("${app.topic.dxpf.group}")
	private String group;

	@Value("${spring.kafka.topic.username}")
	private String userName;

	@Value("${spring.kafka.topic.password}")
	private String password;

	@Value("${spring.kafka.security.protocol}")
	private String protocol;

	@Value("${spring.kafka.security.mechanism}")
	private String securityMechanism;

	@Value("${spring.kafka.consumer.max.poll.interval.ms}")
	private int maxPollInterval;

	@Value("${spring.kafka.consumer.auto.offset.reset}")
	private String offset;

	@Value("${spring.kafka.consumer.enable.auto.commit}")
	private boolean autoCommit;

	@Value("${spring.kafka.consumer.isolation.level}")
	private String isolationLevel;

	@Value("${spring.kafka.topic.ssl.trust.password}")
	private String sslTrustPassword;

	@Value("${app.dxpf.jaasTemplate}")
	private String jaasTemplate;
	
	@Value("${spring.kafka.topic.ssl.trust.location}")
	private String sslTrustLocation;
	
	
	//Topic for CAMS dispatch message
	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		factory.setErrorHandler(new SeekToCurrentErrorHandler());
		factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
		factory.getContainerProperties().setSyncCommits(true);
		factory.setAckDiscarded(true);
		return factory;
	}

	@Bean
	public ConsumerFactory<String, String> consumerFactory() {
		return new DefaultKafkaConsumerFactory<>(consumerProps());
	}

	private Map<String, Object> consumerProps() {
		final String consJaasCfg = String.format(jaasTemplate, userName, password);
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, consumerServer);

		props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, protocol);
		props.put(SaslConfigs.SASL_MECHANISM, securityMechanism);
		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslTrustLocation);
		props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslTrustPassword);
		props.put(SaslConfigs.SASL_JAAS_CONFIG, consJaasCfg);
		props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");

		props.put(ConsumerConfig.GROUP_ID_CONFIG, group);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

		props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollInterval);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offset);
		props.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, isolationLevel);

		log.info("passed values {}", props.values());
		return props;
	}

	public String getKafkaServerDetails() throws KafkaTimeoutException, UnknownHostException {
		String returnValue = "";
        log.info("Bootstrap servers: {}", consumerServer);
        log.info("Consumer group: {}", group);
        log.info("Secuirty protocol: {}", protocol);
        log.info("SASL Mechanism: {}", securityMechanism);
        log.info("SSL Truststore location: {}", sslTrustLocation);
        try (KafkaConsumer<String, String> conmr = new KafkaConsumer<>(consumerProps())) {
            Map<String, List<PartitionInfo>> topics = conmr.listTopics();
            log.info("Number of topics that the application has access to:{} ", topics.size());
            Set<String> keySet = topics.keySet();
            
            keySet.forEach(key -> {
                List<PartitionInfo> ab = topics.get(key);
                ab.forEach(part -> log.debug("Kafka Topic Name: {}", part.topic()));
            });
            
            returnValue = "Kafka Connection Established Successfully";
        } catch (TimeoutException | InterruptException e) {
            log.error("Error in checking topics ", e);
            throw new KafkaTimeoutException("Kafaka connectivity is failed to establish");
		}
       return returnValue;
	}          
}
