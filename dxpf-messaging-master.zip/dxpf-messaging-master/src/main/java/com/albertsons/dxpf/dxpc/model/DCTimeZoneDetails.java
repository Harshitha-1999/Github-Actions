package com.albertsons.dxpf.dxpc.model;

import lombok.Data;

@Data
public class DCTimeZoneDetails {
	private String corp_item_Cd ;
	private String distributionCenter ;
	private String dcId ;
	private String timeZoneCode ;
	private String tz_offset ;
}
