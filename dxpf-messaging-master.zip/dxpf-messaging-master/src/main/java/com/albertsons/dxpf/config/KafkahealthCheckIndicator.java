package com.albertsons.dxpf.config;

import java.net.UnknownHostException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.albertsons.dxpf.exception.KafkaTimeoutException;

@Profile("!test")
@Component
public class KafkahealthCheckIndicator implements HealthIndicator {

	@Autowired
	private KafkaListenerManagement kafkaListenerManagement;

	@Autowired
	private DxpfConsumerConfig kafkaConsumerConfig;

	private static final String KAFKALISTENER = "KafakaListener";

	private static final String FAILED_MSG = "KafakaListner is failed";

	private static final String SUCCES_MSG = "KafakaListner is UP";

	@Override
	public Health health() {

		if (!kafkaListenerManagement.isKafkaRunning()) {
			return Health.down().withDetail(KAFKALISTENER, FAILED_MSG).build();
		}

		try {
			kafkaConsumerConfig.getKafkaServerDetails();
		} catch (KafkaTimeoutException | UnknownHostException e) {
			return Health.down().withDetail(KAFKALISTENER, FAILED_MSG).build();
		}

		return Health.up().withDetail(KAFKALISTENER, SUCCES_MSG).build();
	}
}
