package com.albertsons.dxpf.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.albertsons.dxpf.entity.TrailerEvent;


@Repository
public interface TrailerEventRepository extends JpaRepository<TrailerEvent, Long> {

}
