package com.albertsons.dxpf.service.impl;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.albertsons.dxpf.cams.model.GetTransportationStatus;
import com.albertsons.dxpf.cams.model.GetTransportationStatusLoadClose;
import com.albertsons.dxpf.model.TrailerData;
import com.albertsons.dxpf.service.DxpfService;
import com.albertsons.dxpf.utils.DxpfConsumerUtils;

@Service
public class DxpfConsumerServiceListener {
    private static final Logger log = LoggerFactory.getLogger(DxpfConsumerServiceListener.class);
    @Autowired
    private DxpfService dxpfService;
    @Value("${app.cams.topic.dxpf}")
    private String topic;


    @KafkaListener(topics = "${app.cams.topic.dxpf}")
    public void receiveCams(@Payload String message, Acknowledgment ack) {
    	log.debug("received message : {}", message);
		try {
			String description = StringUtils.substringBetween(message, "<Abs:Description>",
					"</Abs:Description>");
			if(!StringUtils.isEmpty(description.trim()) && (description.equalsIgnoreCase("Trip status tracking for Dispatched Vehicle"))) {
				String xsdPath = "/xsd/BOD/GetTransportationStatus.xsd";
				Boolean validXML = DxpfConsumerUtils.validate(message, xsdPath);
				if (validXML) {
					String sourceApplicationCd = StringUtils.substringBetween(message, "<Abs:SourceApplicationCd>",
							"</Abs:SourceApplicationCd>");
					GetTransportationStatus parsedCamsMessage = DxpfConsumerUtils.unMarshall(message);
					extractAndSaveCamsDispatchMessage(parsedCamsMessage, sourceApplicationCd);
				} else {
					log.debug("invalid xml : {}", message);
				}
			} else if(!StringUtils.isEmpty(description.trim()) && !(description.equalsIgnoreCase("Trip status tracking for completed trip"))) {
				Boolean validXML = DxpfConsumerUtils.validateLoadClose(message);
				if (validXML) {
				String sourceApplicationCd = StringUtils.substringBetween(message, "<Abs:SourceApplicationCd>",
						"</Abs:SourceApplicationCd>");
				GetTransportationStatusLoadClose parsedLoadCloseMessage = DxpfConsumerUtils.unMarshallLoadClose(message);
				extractAndSaveLoadCloseMessage (parsedLoadCloseMessage, sourceApplicationCd) ;
				} else {
					log.debug("invalid xml : {}", message);
				}
			}
		} catch (Exception e) {
			log.error("Error during XML parsing {}", e.getMessage());
			log.error("Xml message which causes error ::{}", message);
		}
		ack.acknowledge();
    }    
    private void extractAndSaveCamsDispatchMessage(GetTransportationStatus parsedCamsMessage , String sourceApplicationCd) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException{
    	TrailerData trailerData = DxpfConsumerUtils.mapCamsDXPFTrailerEvent(parsedCamsMessage, sourceApplicationCd);   	
    	dxpfService.persistDXPFTrailerEvents(trailerData);
    }
    
    private void extractAndSaveLoadCloseMessage(GetTransportationStatusLoadClose parsedLoadCloseMessage , String sourceApplicationCd) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException{
    	TrailerData trailerData = DxpfConsumerUtils.mapLoadCloseDXPFTrailerEvent(parsedLoadCloseMessage, sourceApplicationCd);   	
    	dxpfService.persistDXPFTrailerEvents(trailerData);
    }
}

