package com.albertsons.dxpf.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.albertsons.dxpf.entity.DCTimeZoneDetails;
import com.albertsons.dxpf.repository.DCTimeZoneDetailsRepository;

@Repository
public class DCTimeZoneDetailsRepositoryImpl implements DCTimeZoneDetailsRepository{

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Value("${dc.fetch.query}")
	private String dcFetchQuery;
	
	@Override
	public DCTimeZoneDetails fetchDCTimeZoneDetails(String dstCntrCd) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		namedParameters.addValue("dstCntrCd", dstCntrCd);
		return namedParameterJdbcTemplate.queryForObject(dcFetchQuery, namedParameters,
				(rs, rowNum) -> new DCTimeZoneDetails(rs.getString("DstCntrCd"), rs.getString("DCID"),
						rs.getString("TMZoneCd"), rs.getInt("MountainTMZoneOffsetHr"), rs.getTimestamp("CreateTS"),
						rs.getString("CreateUserID"), rs.getTimestamp("LastUpdTS") , rs.getString("LastUpdUserID")));
	}

}
