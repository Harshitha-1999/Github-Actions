package com.albertsons.dxpf.exception;

@SuppressWarnings("serial")
public class KafkaTimeoutException extends Exception {
   public KafkaTimeoutException(Throwable cause) {
        super(cause);
    }
   public KafkaTimeoutException(String message) {
        super(message);
    }
   public KafkaTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}