package com.albertsons.dxpf.model;

import java.util.List;

import com.albertsons.dxpf.entity.TrailerContent;
import com.albertsons.dxpf.entity.TrailerEvent;

import lombok.Data;

@Data
public class TrailerData {
	
	List<TrailerEvent> trailerEvents ;
	List<TrailerContent> trailerContents ;

}
