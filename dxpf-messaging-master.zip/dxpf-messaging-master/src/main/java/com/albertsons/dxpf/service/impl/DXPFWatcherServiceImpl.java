package com.albertsons.dxpf.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.albertsons.dxpf.dxpc.model.TrailerRecord;
import com.albertsons.dxpf.entity.DCTimeZoneDetails;
import com.albertsons.dxpf.model.TrailerData;
import com.albertsons.dxpf.repository.DCTimeZoneDetailsRepository;
import com.albertsons.dxpf.service.DXPFWatcherService;
import com.albertsons.dxpf.service.DxpfService;
import com.albertsons.dxpf.utils.DxpfConsumerUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class DXPFWatcherServiceImpl implements DXPFWatcherService {

	private static final String FOLDER_MONITORING_ERROR_MESSAGE = "incorrect monitoring folder:";
	
	@Autowired
	private DxpfService dxpfService;

	@Autowired
	private DCTimeZoneDetailsRepository timeZoneDetailsRepository;

	@Value("${dxpc.folder.datain}")
    private String folder_to_Monitor;
	
	@Value("${dxpc.folder.archive}")
	private String archiveFolder;

	@Value("${dxpc.folder.datareject}")
	private String dataRejectFolder;
	
	@EventListener(ApplicationReadyEvent.class)
	public void validateMonitoringFolders() throws IOException {
		log.info("Validating the existence of fileshare folders");
		Path path_wanc = Paths.get(folder_to_Monitor + "//" + "WANC");
		Path path_waub = Paths.get(folder_to_Monitor + "//" + "WAUB");
		Path path_wbre = Paths.get(folder_to_Monitor + "//" + "WBRE");
		Path path_wdal = Paths.get(folder_to_Monitor + "//" + "WDAL");
		Path path_wden = Paths.get(folder_to_Monitor + "//" + "WDEN");
		Path path_wirv = Paths.get(folder_to_Monitor + "//" + "WIRV");
		Path path_wlan = Paths.get(folder_to_Monitor + "//" + "WLAN");
		Path path_wmel = Paths.get(folder_to_Monitor + "//" + "WMEL");
		Path path_wmet = Paths.get(folder_to_Monitor + "//" + "WMET");
		Path path_wnca = Paths.get(folder_to_Monitor + "//" + "WNCA");
		Path path_wpha = Paths.get(folder_to_Monitor + "//" + "WPHA");
		Path path_wpoa = Paths.get(folder_to_Monitor + "//" + "WPOA");
		Path path_wpon = Paths.get(folder_to_Monitor + "//" + "WPON");
		Path path_wslc = Paths.get(folder_to_Monitor + "//" + "WSLC");
		Path path_wspk = Paths.get(folder_to_Monitor + "//" + "WSPK");
		Path path_wsun = Paths.get(folder_to_Monitor + "//" + "WSUN");
		Path path_wwel = Paths.get(folder_to_Monitor + "//" + "WWEL");
		if (!Files.isDirectory(path_wanc) || !Files.isDirectory(path_waub) || !Files.isDirectory(path_wbre)
				|| !Files.isDirectory(path_wdal) || !Files.isDirectory(path_wden) || !Files.isDirectory(path_wirv)
				|| !Files.isDirectory(path_wlan) || !Files.isDirectory(path_wmel) || !Files.isDirectory(path_wmet)
				|| !Files.isDirectory(path_wnca) || !Files.isDirectory(path_wpha) || !Files.isDirectory(path_wpoa)
				|| !Files.isDirectory(path_wpon) || !Files.isDirectory(path_wslc) || !Files.isDirectory(path_wspk)
				|| !Files.isDirectory(path_wsun) || !Files.isDirectory(path_wwel)) {
			throw new IOException(FOLDER_MONITORING_ERROR_MESSAGE);
		}
	}

	@Scheduled (cron = "* * * * * *")
	public void fetchAndProcessLoadCloseMessages()
			throws IOException {
		log.info("Processing the files from Fileshare");
		File datainDir = new File(folder_to_Monitor);
		for (File file : datainDir.listFiles()) {
			String dcCenter = file.getName() ;
			if (file.isDirectory()) {
				for (File fileContent : file.listFiles()) {
					try {
						String fileName = fileContent.getName();
						boolean isFileAlreadyProcessed = checkWhetherFileAlreadyProcessedOrNot(dcCenter.concat("_").concat(fileName));
						String filePath = fileContent.getPath();
						if (!isFileAlreadyProcessed) {
							boolean isProcessed = processDXPCLoadCloseMessage(filePath, dcCenter);

							String fileToPrefix;
							fileToPrefix = dcCenter.concat("_");
							fileName = fileToPrefix.concat(fileName);
							renameAndMoveToArchiveOrReject(isProcessed, fileName, filePath) ;
						} else {
							renameAndMoveAlreadyProcessedFileToArchiveOrReject(dcCenter.concat("_").concat(fileName), filePath) ;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} 
		}
	}
	

	@Override
	public boolean processDXPCLoadCloseMessage(String fileLocation, String dstCntrCd)
			throws IOException {
		File fileToRead = new File(fileLocation);
		try (Reader fr = new FileReader(fileToRead); BufferedReader br = new BufferedReader(fr)) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line).append("\n");
				line = br.readLine();
			}
			String message = sb.toString();
			Boolean validXML = DxpfConsumerUtils.validateDXPCLoadClose(message);

			TrailerRecord parsedLoadCloseMessage = DxpfConsumerUtils.unMarshallDXPCLoadClose(fileLocation);
			if (validXML) {
				DCTimeZoneDetails dcTimeZoneDetails = timeZoneDetailsRepository.fetchDCTimeZoneDetails(dstCntrCd);
				TrailerData trailerData = DxpfConsumerUtils.mapDXPCLoadCloseMessage(parsedLoadCloseMessage,
						dcTimeZoneDetails);
				boolean isSuccess;
				isSuccess = dxpfService.persistDXPFTrailerEvents(trailerData);
				return isSuccess;
			} else {
				log.debug("invalid xml " + message);
				return false;
			}
		} catch (Exception e) {
			log.error("Error while processing XML {}", e.getMessage());
			return false;
		}
	}
	
	public boolean checkWhetherFileAlreadyProcessedOrNot(String fileName) {
		String archivePath = archiveFolder + "//" + fileName;
		boolean isAlreadyProcessed = false;
		File fileArchive = new File(archivePath);
		if (!fileArchive.exists()) {
			String rejectPath = dataRejectFolder + "//" + fileName;
			File fileReject = new File(rejectPath);
			if (fileReject.exists()) {
				isAlreadyProcessed = true;
			}
		} else {
			isAlreadyProcessed = true;
		}
		return isAlreadyProcessed;
	}

	public void renameAndMoveToArchiveOrReject (boolean isProcessed, String fileName, String filePath) throws IOException {
		if (isProcessed) {
			String archivePath = archiveFolder + "//" + fileName;
			File fileToRead = new File(filePath);
			File fileDest = new File(archivePath);
			if (!fileToRead.renameTo(fileDest)) {
				throw new IOException("Error while moving the files to Archive folder");
			}
		} else {
			String rejectPath = dataRejectFolder + "//" + fileName;
			File fileToRead = new File(filePath);
			File fileDest = new File(rejectPath);
			if(!fileToRead.renameTo(fileDest)) {
				throw new IOException("Error while moving the files to Reject folder");
			}
		}
	}
	
	private boolean renameAndMoveAlreadyProcessedFileToArchiveOrReject(String fileName,
			String filePath){
		
		String archivePath = archiveFolder + "//" + fileName;
		File fileArchive = new File(archivePath);
		if (!fileArchive.exists()) {
			return createCopyFile(new File(dataRejectFolder),new File(filePath),dataRejectFolder + "//" + fileName,fileName);
		} else {
			return createCopyFile(new File(archiveFolder),new File(filePath),archivePath,fileName);
			
		}
		
	}
	
	
	private boolean  createCopyFile(File dir, File fileToRead, String newFilePath,String fileName) {
		Pattern p = Pattern.compile(fileName);
		File[] files = dir.listFiles();
		Arrays.sort(files);
		int count =0;
		for (File f : files) {
		    Matcher m = p.matcher(f.getName());
		    if (m.find()) {
		    	count++;
		    }
		}
		File fileDest = new File(newFilePath.concat("-Copy"+count));
		return fileToRead.renameTo(fileDest);
	}
}