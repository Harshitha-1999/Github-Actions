package com.albertsons.dxpf.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * This class responsible for Kafka management
 */
@Component
@Slf4j
public class KafkaListenerManagement {

	@Autowired
	private KafkaListenerEndpointRegistry registry;

	static boolean kafkaRunningStatus = true;

	/**
	 * If KafkaListenerEndpointRegistry is not running it will start.
	 */
	public void start() {
		if (!registry.isRunning()) {
			registry.start();
			log.info("Kafka Started");
		}
	}

	/**
	 * If KafkaListenerEndpointRegistry is running it will stop.
	 */
	public void stop() {
		if (registry.isRunning()) {
			registry.stop();
			log.info("Kafka Stopped");
		}
	}

	/**
	 * To check the kafka running status
	 * 
	 * @return kafkaRunningStatus
	 */
	public boolean isKafkaRunning() {
		return kafkaRunningStatus;
	}
}
