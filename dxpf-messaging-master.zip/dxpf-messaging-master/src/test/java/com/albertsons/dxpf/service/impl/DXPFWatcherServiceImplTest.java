package com.albertsons.dxpf.service.impl;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

import java.io.IOException;
import java.sql.Timestamp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.test.context.ActiveProfiles;

import com.albertsons.dxpf.entity.DCTimeZoneDetails;
import com.albertsons.dxpf.repository.DCTimeZoneDetailsRepository;
import com.albertsons.dxpf.service.DxpfService;

//@SpringBootTest(classes = {DxpfApplication.class})
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@ActiveProfiles("test")
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
class DXPFWatcherServiceImplTest {
	
	final String SUCCESS_MESSAGE_PATH = "src/test/resources/dxpc-samples/DXPC_LoadClose_20220706144422930_log.xml";
	final String FAILURE_MESSAGE_PATH = "src/test/resources/dxpc-samples/DXPC_LoadClose_20220706144422930_log_fail.xml";
	final String DC_CENTER = "WANC" ;

	@Mock
	private DCTimeZoneDetailsRepository timeZoneDetailsRepository ;
	
	@InjectMocks
	DXPFWatcherServiceImpl watcherServiceImpl ;

	@Mock
	private DxpfService dxpfService ;
		
	@BeforeEach
	void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testProcessDXPCLoadCloseMessage() {		
		DCTimeZoneDetails dcTimeZoneDetails_WANC = getTimeZoneDetails(DC_CENTER) ;
		Mockito.when(timeZoneDetailsRepository.fetchDCTimeZoneDetails(DC_CENTER)).thenReturn(dcTimeZoneDetails_WANC);
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		try {
			assertEquals(true, watcherServiceImpl.processDXPCLoadCloseMessage (SUCCESS_MESSAGE_PATH, DC_CENTER)) ;
		} catch (IOException e) {
		}
	}
	
	@Test
	void testFailureProcessDXPCLoadCloseMessage() {		
		DCTimeZoneDetails dcTimeZoneDetails_WANC = getTimeZoneDetails(DC_CENTER) ;
		Mockito.when(timeZoneDetailsRepository.fetchDCTimeZoneDetails(DC_CENTER)).thenReturn(dcTimeZoneDetails_WANC);
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		try {
			assertNotEquals(true, watcherServiceImpl.processDXPCLoadCloseMessage (FAILURE_MESSAGE_PATH, DC_CENTER)) ;
		} catch (IOException e) {
		}
	}

	@Test
	void testPersistDXPCLoadCloseMessage() {		
		DCTimeZoneDetails dcTimeZoneDetails_WANC = getTimeZoneDetails(DC_CENTER) ;
		Mockito.when(timeZoneDetailsRepository.fetchDCTimeZoneDetails(DC_CENTER)).thenReturn(dcTimeZoneDetails_WANC);
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		try {
			watcherServiceImpl.processDXPCLoadCloseMessage (SUCCESS_MESSAGE_PATH, DC_CENTER) ;
			Mockito.verify(dxpfService, Mockito.times(1)).persistDXPFTrailerEvents(any()) ;
		} catch (IOException e) {
		}
	}
	
	private DCTimeZoneDetails getTimeZoneDetails (String dcCenter) {
		DCTimeZoneDetails dcTimeZoneDetails = new DCTimeZoneDetails (dcCenter, "30", "US/Alaska", -2, Timestamp.valueOf("2022-08-10 04:08:49.386"), "gthel00", Timestamp.valueOf("2022-08-10 04:08:49.386"), "gthel00") ;
		return dcTimeZoneDetails ;		
	}
}
