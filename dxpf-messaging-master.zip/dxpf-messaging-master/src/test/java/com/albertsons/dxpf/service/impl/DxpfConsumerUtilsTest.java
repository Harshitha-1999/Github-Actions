package com.albertsons.dxpf.service.impl;

import static org.mockito.ArgumentMatchers.any;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.test.context.ActiveProfiles;

import com.albertsons.dxpf.service.DxpfService;

@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
class DxpfConsumerUtilsTest {

	final String SUCCESS_MESSAGE_PATH = "src/test/resources/cams-dispatch/cams_dispatch.xml";
	final String FAILURE_MESSAGE_PATH = "src/test/resources/cams-dispatch/cams_dispatch_fail.xml" ;
	final String SUCCESS_LOAD_CLOSE_PATH = "src/test/resources/load-close/LoadClose.xml";
	final String FAILURE_LOAD_CLOSE_PATH = "src/test/resources/load-close/LoadClose_fail.xml" ;
	
	
	@InjectMocks
	DxpfConsumerServiceListener serviceListener ;
	
	@Mock
	private DxpfService dxpfService ;
	
	@Mock
	Acknowledgment ack ;
		
	@BeforeEach
	void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testReceiveCamsSuccess() {
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		String message = null;
		try {
			message = getMessage(SUCCESS_MESSAGE_PATH);
		} catch (IOException e) {
		}
		serviceListener.receiveCams(message, ack);
		Mockito.verify(dxpfService, Mockito.times(1)).persistDXPFTrailerEvents(any()) ;
	}
	
	@Test
	void testReceiveCamsFailure() {
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		String message = null;
		try {
			message = getMessage(FAILURE_MESSAGE_PATH);
		} catch (IOException e) {
		}
		serviceListener.receiveCams(message, ack);
		Mockito.verify(dxpfService, Mockito.times(0)).persistDXPFTrailerEvents(any()) ;
	}
	
	@Test
	void testReceiveCamsLoadCloseSuccess() {
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		String message = null;
		try {
			message = getMessage(SUCCESS_LOAD_CLOSE_PATH);
		} catch (IOException e) {
		}
		serviceListener.receiveCams(message, ack);
		Mockito.verify(dxpfService, Mockito.times(1)).persistDXPFTrailerEvents(any()) ;
	}
	
	@Test
	void testReceiveCamsLoadCloseFailure() {
		Mockito.when(dxpfService.persistDXPFTrailerEvents(any())).thenReturn(true) ;
		String message = null;
		try {
			message = getMessage(FAILURE_LOAD_CLOSE_PATH);
		} catch (IOException e) {
		}
		serviceListener.receiveCams(message, ack);
		Mockito.verify(dxpfService, Mockito.times(0)).persistDXPFTrailerEvents(any()) ;
	}
	String getMessage(String messagePath) throws IOException {
		final byte[] encoded = Files.readAllBytes(Paths.get(messagePath));
		String message = new String(encoded, StandardCharsets.UTF_8);
		return message;
	}
}
