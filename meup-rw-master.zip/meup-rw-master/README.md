# MEUP-RW SECURITY (LOCALHOST) NOTES:  v0404
0. Update src-msal-server/.env.dev with
REACT_APP_CLIENT_SECRET=""
1. copy contents of .env.dev to .env

# MEUP-RW (LOCALHOST) NOTES:  
0. Run npx json-server -p 3500 -w data/db.json
java -jar meup-app-0.0.1-SNAPSHOT.jar --server.port=8080
# INSTALLATION
# MEUP-RW + MSAL-SECURITY
-------------------------------------------
Updated INSTALL NOTES:

npm install

Install Server separately  ..

npm run buildsrv\

------------------------------\
# Run MSAL Server

Security Server UI\
open new terminal window\
cd server\
node index.js\
npm run startsrv\

-----------------------------------\
# Run Client App

Client UI\
open new terminal window\
npm run start\
or
npm run start:loc\  -- for localhost

------------------------------\
# Test MSAL Server Routes:
Test the "/authenticate" route on port 7000.
http://localhost:7000/authenticate
https://memiu-dev.albertsons.com/7000/authenticate

# Routes on MSAL Server that need corresponding entries in dns-route-tables:
/authenticate
/azureAdRedirect
/azurelogout
/loginError

================================
REPACKAGE MSAL SERVER: Branch:LoginBackup:
original no change npm install Step -1
added npm run mkdirs Step 0
added npm run buildsrv step 1
added npm run startsrv step 2
existing - no change npm start (a new console) - client step 3
removed npm run startSrv deleted
set to correct branch - Dockerfile Docker Step -2

# 051221 -  MSAL + App Join Initial versions: 051221

is01-isc-app Feature: MG1Login 4.8.21
---
Permissions: AD-GROUP for  AD-GROUPS?: [MEMIU-DEV] [albertsons.authn]:
"@albertsons-authn/abs-node-authn": "^1.1.210805-mr40",
registry=http://albertsons-binrepo.westus.cloudapp.azure.com/artifactory/api/npm/npm-registry/
---

---------------------
### `npm install`
### `npm start`

Access: Need need to be added for artifactory [AD-GROUP?] for "@albertsons-authn/abs-node-authn": "^1.1.210805-mr40",

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.<br />

### `npm run build`

Builds the app for production to the `build` folder.<br />
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.<br />
Your app is ready to be deployed!

### `NOTE:`

Two values in the azure-config json need to be updated to point to dev uri routes, they currently point to localhost.
The keys are "redirectUri" and "postLogoutRedirectUri".

-- parameters for this application in localhost.

You will also need to clear your cookies and session storage to show the login flow

note the .env files in the app .. env.dev is the one you want localhost

C:\Users\JSTE442\08032\is01-isc-app\server> node index.js

##############################################################################################################

### 'PRODUCTION / QA / DEV / DEPLOYMENTS

REACT_APP_REDIRECT_URI="http://localhost:7000/azureAdRedirect"
REACT_APP_POST_LOGOUT_REDIRECT_URI="http://localhost:7000/authenticate"
BASE_URL="http://localhost:8080/memiu-web"
LOGIN_ERROR_PAGE="http://localhost:7000/loginError"

---

REACT_APP_REDIRECT_URI=${app_redirect_uri}
REACT_APP_POST_LOGOUT_REDIRECT_URI=${app_post_logout_redirect_uri}
BASE_URL=${app_base_url}
LOGIN_ERROR_PAGE=${app_error_url}

Externalized values:\
.env - the values need to look similar to those on the right side of the top section. Replace "localhost" with "machine-name".
/src_msal_server has the env files to update prior to installing npm install

##################################################################################################################

###################################
DEVELOPMENT NOTES:
###################################
All css reference go in /css/App.css.

/css/App.css

if you copy code where a style is defined, move it into App.css

## https://github.albertsons.com/jste442/is01-app-reference-design/blob/master/src/css/App.css

placement=top; or placement=inline;

---

To run json-server run: 

npx json-server -p 3500 -w data/db.json

---

Any console log information statements should be added to the LogContext (ContextMessages.addString(newMessage))
-------------------------------------------
Current Prod Release: App in QA
https://memiu-qa.safeway.com/memiu/#/
---------------------------------------------
----------------------------------------------------------
 alignItems="row"-Label left
 alignItems="column"-Label top

 MEMI07 - Example

                                           
                                            <TextFieldMemi length={15}  alignItems="row" label ="On Hand" id="On Hand outlined-disabled" disabled value={onHand} error={errOnHand} setTextValue={(value) => setOnHand(value)} setError={(value) => setErrOnHand(value)} labelLeft={true} TextFieldClass="textField2" input ="input14" disabled={true}/>

                                            <TextFieldMemi length={15}  alignItems="column" label ="On Hand" id="On Hand outlined-disabled" disabled value={onHand} error={errOnHand} setTextValue={(value) => setOnHand(value)} setError={(value) => setErrOnHand(value)} labelLeft={true} TextFieldClass="textField2" input ="input14" disabled={true}/>

--------------------------------------------------------------------------
DropDown Width control by classNameMemi 
                                            <DropDownMemi options={['Type1', 'Type2', 'Type3', 'Type4']} label="Private Label" alignItems="row" value={privatelabel} setValue={value => setPrivateLabel(value)} error={errPrivateLabel} setError={(value) => setErrPrivateLabel(value)} classNameMemi="drp2" />

--------------------------------------------------------------------------------------------
Data Table 
<TableMemmi>
For dataGrid row height property is set dynamically (rowHeight={props.rowheight}) and  for each table we can implement diffrent css so we added  props called className={props.classnameMemi} 



LINK FOR DEV's
https://jira.safeway.com/browse/ECMM-3254
https://github.albertsons.com/albertsons/MEUP-RW
https://meup-qa.safeway.com/meup/faces/mainmenu.jsp
https://confluence.safeway.com/display/EMM/MEUP-Dev+Notes

##################
Onboarding
#################
access to repos  MEUP, MEMI-RW
Confluence
Jira
Add ui to adgroup for login 
 

