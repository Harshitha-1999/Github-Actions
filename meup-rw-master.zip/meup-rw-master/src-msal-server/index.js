/**
 * Sample Node JS application
 */
 const express = require("express");
 const msal = require("@azure/msal-node");
 const AlbertsonsMsal = require("@albertsons-authn/abs-node-authn");
 //const testObj = require("./externalize.js")
 var cookieParser = require("cookie-parser");
 var path = require("path");
 require("custom-env").env(); // to remove dependency on dev
 
 const MSAL_BASE_URL = process.env.MSAL_BASE_URL;
 const APP_BASE_URL = process.env.APP_BASE_URL;
 const CONTEXT_PATH = process.env.MSAL_CONTEXT_PATH;
 const REDIRECT_URL = MSAL_BASE_URL + process.env.MSAL_CONTEXT_PATH + "/azureAdRedirect";
 const POST_LOGOUT_URL = MSAL_BASE_URL + process.env.MSAL_CONTEXT_PATH + "/authenticate";
 const LOGIN_ERROR_URL = MSAL_BASE_URL + process.env.MSAL_CONTEXT_PATH + "/loginError";
 
 const SERVER_PORT = process.env.MSAL_PORT || 7000;
 const app = express();
 app.use(cookieParser());
 
 console.log("---------------------------------------");
 console.log("--- MSAL Server UI v0208-6 --------------");
 console.log("---------------------------------------");
 //console.log("process.env.REACT_APP_CLIENT_SECRET:", process.env.REACT_APP_CLIENT_SECRET.substring(0, 2));
 console.log("process.env.REACT_APP_CLIENT_ID:", process.env.REACT_APP_CLIENT_ID.substring(0, 5));
 console.log("CONTEXT_PATH:", CONTEXT_PATH);
 console.log("LOGIN_ERROR_URL:", LOGIN_ERROR_URL);
 console.log("MSAL_BASE_URL:", MSAL_BASE_URL);
 console.log("APP_BASE_URL", APP_BASE_URL);
 console.log("REDIRECT_URL:", REDIRECT_URL);
 console.log("POST_LOGOUT_URL:", POST_LOGOUT_URL);
 console.log("MSAL-SERVER Version:", "031822");
 
 // Azure AD application configuration
 const config = {
   scopes: process.env.SCOPES.split(","), //externalize and remove from github
   auth: {
     clientId: process.env.REACT_APP_CLIENT_ID,
     authority: process.env.REACT_APP_AUTHORITY,
     clientSecret: process.env.REACT_APP_CLIENT_SECRET,
     validateAuthority: true,
     baseUri: APP_BASE_URL,
     redirectUri: REDIRECT_URL,
     postLogoutRedirectUri: POST_LOGOUT_URL,
   },
   system: {
     loggerOptions: {
       loggerCallback(loglevel, message, containsPii) {
         //  console.log(message);
       },
       piiLoggingEnabled: false,
       logLevel: msal.LogLevel.Verbose,
     },
   },
 };
 
 AlbertsonsMsal.msalInitialize(config);
 
 app.get(["/loginError", CONTEXT_PATH + "/loginError",], (req, res) => {
   res.sendFile(path.join(__dirname + "/home.html"));
 });
 
 // requires corresponding changes for err call back in wcax 
 app.get(["/azureAdRedirect", CONTEXT_PATH + "/azureAdRedirect"], (req, res) => {
   try {
     AlbertsonsMsal.msalExchangeCodeForToken(req, res, function (err) {
       //  console.log("token received in browser");
       // Once a token is obtained and msalExchangeCodeForToken() returns back to the calling handler function, the Application should redirect to desired location
       // positive casee
       if (err === undefined) {
         console.log("azureAdRedirect:no error redirecting to app_base_url", APP_BASE_URL);
         if (CONTEXT_PATH != undefined || CONTEXT_PATH != "")
           res.redirect(APP_BASE_URL);
       }
       else {
         console.log("azureAdRedirect: err:", err);
         console.log("azureAdRedirect: Redirecting because of error:", LOGIN_ERROR_URL);
         res.redirect(LOGIN_ERROR_URL);
       }
     });
   } catch (err) {
     console.log('ERROR CAUGHT: AlbertsonsMsal.msalExchangeCodeForToken:' + error);
   }
 }
 );
 
 app.get(["/azurelogout", CONTEXT_PATH + "/azurelogout"], (req, res) => {
   AlbertsonsMsal.msalLogout(req, res);
 });
 
 app.get(["/authenticate", CONTEXT_PATH + "/authenticate"], (req, res) => {
   //console.log("authenticate called token  in browser");
   AlbertsonsMsal.msalCheckAuthStatus(res, req.cookies, function (authResult) {
     res.redirect(APP_BASE_URL);
   });
 });
 
 app.listen(SERVER_PORT, () =>
   console.log(
     `APPID-MSAL-SERVER: listening on port ${SERVER_PORT}!`
   )
 );
  //-------------------Jeff Steinberg Notes: 11172021 ---------------
 