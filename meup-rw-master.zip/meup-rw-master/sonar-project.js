const sonarqubeScanner = require("sonarqube-scanner");
sonarqubeScanner(
    {
        serverUrl: "https://sonarqube.albertsons.com",
        token: "9ec49eabe28427675ffc017e46110925e9ceff10",
        options: {
            "sonar.sources": "./src",
            "sonar.login": "9ec49eabe28427675ffc017e46110925e9ceff10",
            "sonar.exclusions": "**/*.test.*",
            "sonar.tests": "./src/",
            "sonar.test.inclusions": "**/*.test.js,./src/**/*.test.js",
            "sonar.javascript.lcov.reportPaths": "coverage/lcov.info",
            "sonar.testExecutionReportPaths": "reports/test-report.xml",
            "sonar.branch.name": "MG1Login"
        },
    },
    () => { },
);
