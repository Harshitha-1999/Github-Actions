import {
  ADD_DATA,
  DELETE_DATA,
  SET_DATA,
  ADD_USERINFO,
  SET_USERINFO,
  ADD_LASTSEARCH,
  SET_LASTSEARCH,
  ADD_MEMI01,
  SET_MEMI01,
  SET_MEMI08,
  ADD_MEMI08,
  SET_MEMI13,
  ADD_MEMI13,
  SET_MEMI20,
  SET_MEMI21,
  SET_MEMI22,
  SET_MEMIMenu,
  ADD_MEMIMenu,
  SET_CONFIGURATION_SETS,
  ADD_CONFIGURATION_SETS,
  ADD_MEMI14_A,
  SET_MEMI14_A,
  ADD_MEMI17,
  SET_MEMI17,
  ADD_MEMI23,
  SET_MEMI23,
  ADD_MEMI24_A,
  SET_MEMI24_A,
  SET_CONFIGURATION_VARS,
  ADD_CONFIGURATION_VARS,
  ADD_MEMI24_B,
  SET_MEMI24_B,
  ADD_MEMI24_C,
  SET_MEMI24_C,
  SET_MEUP51,
  SET_MEUP54,
  SET_MEUP57,
  SET_MEUP58,
  SET_MEUP62,
  SET_MEUP63,
  SET_COMPANYID,
  SET_DIVISIONID,
  SET_MEUP52DIVISIONS,
  SET_MEUP53DIVISIONS,
  SET_MEUP53GROUPS,
  SET_MEUP53CATEGORYLIST,
  SET_UNBLOCK_RES,
  SET_MEUP51_UPLOADITEM,
  SET_MEUP52_BLOCK_ITEMS_AND_STORES,
  SET_MEUP54_STORE_ITEMS_FOR_REPORT,
  SET_MEUP56_STORE_ITEMS_HISTORY,
  SET_SELECTED_ROWS,
  SET_RADIO_OPTION,
  SET_MEUP,
  SET_APP_STATE,
  SET_LOADER,
  ADD_LOADER
} from "./ApplicationConstants";

export const ApplicationReducer = (state, action) => {
  switch (action.type) {
    case SET_DATA:
      return {
        ...state,
        data: action.payload,
      };
    case ADD_DATA:
      return {
        ...state,
        data: [...state.data, action.payload],
      };
    case DELETE_DATA:
      return {};
    case SET_USERINFO:
      return {
        ...state,
        userInfo: action.payload,
      };
    case ADD_USERINFO:
      return {
        ...state,
        userInfo: [...state.userInfo, action.payload],
      };
    case SET_LASTSEARCH:
      return {
        ...state,
        lastSearch: action.payload,
      };
    case ADD_LASTSEARCH:
      return {
        ...state,
        lastSearch: [...state.lastSearch, action.payload],
      };
    case SET_MEMI01:
      return {
        ...state,
        memi01: action.payload,
      };

    case SET_MEMI08:
      return {
        ...state,
        memi08: action.payload,
      };

    case SET_MEMI13:
      return {
        ...state,
        memi13: action.payload,
      };
    case SET_MEMI20:
      return {
        ...state,
        memi20: action.payload,
      };
    case SET_MEMI14_A:
      return {
        ...state,
        memi14_A: action.payload,
      };
    case SET_MEMI17:
      return {
        ...state,
        memi17: action.payload,
      };
    case SET_MEMI23:
      return {
        ...state,
        memi23: action.payload,
      };
    case SET_MEMI24_A:
      return {
        ...state,
        memi24_A: action.payload,
      };
    case SET_MEMI24_B:
      return {
        ...state,
        memi24_B: action.payload,
      };
    case SET_MEMI24_C:
      return {
        ...state,
        memi24_C: action.payload,
      };

    case SET_MEMI21:
      return {
        ...state,
        memi21: action.payload,
      };
    case SET_MEMI22:
      return {
        ...state,
        memi22: action.payload,
      };

    case ADD_MEMI01:
      return {
        ...state,
        memi01: [...state.memi01, action.payload],
      };
    case ADD_MEMI08:
      return {
        ...state,
        memi08: [...state.memi08, action.payload],
      };
    case ADD_MEMI13:
      return {
        ...state,
        memi13: [...state.memi13, action.payload],
      };
    case SET_MEMIMenu:
      return {
        ...state,
        configure: action.payload,
      };
    case ADD_MEMIMenu:
      return {
        ...state,
        configure: [...state.configure, action.payload],
      };

    case SET_CONFIGURATION_SETS:
      return {
        ...state,
        configurationSets: action.payload,
      };
    case ADD_CONFIGURATION_SETS:
      return {
        ...state,
        configurationSets: [...state.configurationSets, action.payload],
      };

    case SET_CONFIGURATION_VARS:
      return {
        ...state,
        configurationVars: action.payload,
      };
    case ADD_CONFIGURATION_VARS:
      return {
        ...state,
        configurationVars: [...state.configurationVars, action.payload],
      };

    case ADD_MEMI14_A:
      return {
        ...state,
        memi14_A: [...state.memi14_A, action.payload],
      };
    case ADD_MEMI17:
      return {
        ...state,
        memi17: [...state.memi17, action.payload],
      };
    case ADD_MEMI23:
      return {
        ...state,
        memi23: [...state.memi23, action.payload],
      };
    case ADD_MEMI24_A:
      return {
        ...state,
        memi24_A: [...state.memi24_A, action.payload],
      };
    case ADD_MEMI24_B:
      return {
        ...state,
        memi24_B: [...state.memi24_B, action.payload],
      };
    case ADD_MEMI24_C:
      return {
        ...state,
        memi24_C: [...state.memi24_C, action.payload],
      };
    case SET_MEUP51:
      return {
        ...state,
        meup51: action.payload,
      };
    case SET_MEUP54:
      return {
        ...state,
        meup54: action.payload,
      };
    case SET_MEUP57:
      return {
        ...state,
        meup57: action.payload,
      };
    case SET_MEUP58:
      return {
        ...state,
        meup58: action.payload,
      };
    case SET_MEUP62:
      return {
        ...state,
        meup62: action.payload,
      };
    case SET_MEUP63:
      return {
        ...state,
        meup63: action.payload,
      };

    case SET_COMPANYID:
      return {
        ...state,
        companyId: action.payload,
      };
    case SET_DIVISIONID:
      return {
        ...state,
        divisionId: action.payload,
      };
    case SET_MEUP52DIVISIONS:
      return {
        ...state,
        meup52Divisions: action.payload,
      };
    case SET_MEUP53DIVISIONS:
      return {
        ...state,
        meup53Divisions: action.payload,
      };
    case SET_MEUP53GROUPS:
      return {
        ...state,
        meup53Groups: action.payload,
      };
    case SET_MEUP53CATEGORYLIST:
      return {
        ...state,
        meup53CategoryList: action.payload,
      };
    case SET_UNBLOCK_RES:
      return {
        ...state,
        unblockRes: action.payload,
      };
    case SET_SELECTED_ROWS:
      return {
        ...state,
        rowData: action.payload,
      };
    case SET_MEUP51_UPLOADITEM:
      return {
        ...state,
        meup51UploadItem: action.payload,
      };
    case SET_RADIO_OPTION:
      return {
        ...state,
        radioVal: action.payload,
      };
    case SET_MEUP52_BLOCK_ITEMS_AND_STORES:
      return {
        ...state,
        meup52BlockItemsAndStores: action.payload,
      };
    case SET_MEUP54_STORE_ITEMS_FOR_REPORT:
      return {
        ...state,
        meup54StoreItemsForReport: action.payload,
      };
    case SET_MEUP56_STORE_ITEMS_HISTORY:
      return {
        ...state,
        meup56StoreItemsHistory: action.payload,
      };
      case SET_LOADER:
        return {
          ...state,
          loader: action.payload,
        };
      case ADD_LOADER:
        return {
          ...state,
          loader: state.loader + action.payload
        }
    case SET_MEUP:
        return action.payload
    case SET_APP_STATE:
        return {
          ...state,
          appState: {...state.appState, ...action.payload}
        }
    default:
      return state;
  }
};
