
import { ADD_STRING, DELETE_STRING } from "./LogConstants";

export const logReducer = (state, action) => {
  switch (action.type) {
    case ADD_STRING:
      return {
        ...state,
        messages: [...state.messages, action.payload],
      };
    case DELETE_STRING:
      return {};
    default:
      return state;
  }
};
