import React from 'react';
import { render } from "@testing-library/react";
import ErrorBoundary from './ErrorBoundary';

const mockHistoryPush = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}));

describe("<ErrorBoundary />", () => {

    const ThrowsError = () => {
        throw new Error('Error');
    }

    const fallback = error =>(
        <span>
            Error: {error.message}
        </span>
    )

    it('Should render without errors', () => {
        const {debug, getByTestId} = render(
          <ErrorBoundary error={fallback}>
              <ThrowsError/>
          </ErrorBoundary>
        )
    });
})