import React from 'react';
import { AppContext } from 'context/AppContext';


export const AppContextProvider = ({ children }) => {
  return <AppContext.Provider value={{data : {}}}>{children}</AppContext.Provider>;
};

export default AppContextProvider;