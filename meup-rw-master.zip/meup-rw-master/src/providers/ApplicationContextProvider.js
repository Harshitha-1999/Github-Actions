import React, {  useReducer } from "react";
import { ApplicationContext } from "../context/ApplicationContext";
import { ApplicationReducer } from "../context/ApplicationReducer";
import {
  ADD_DATA,
  DELETE_DATA,
  SET_DATA,
  ADD_USERINFO,
  SET_USERINFO,
  ADD_LASTSEARCH,
  SET_LASTSEARCH,
  ADD_MEMI01,
  SET_MEMI01,
  SET_MEMI08,
  ADD_MEMI08,
  SET_MEMI13,
  SET_MEMI20,
  SET_MEMI21,
  SET_MEMI22,
  ADD_MEMI13,
  SET_CONFIGURATION_SETS,
  ADD_CONFIGURATION_SETS,
  SET_CONFIGURATION_VARS,
  ADD_CONFIGURATION_VARS,
  ADD_MEMI14_A,
  SET_MEMI14_A,
  ADD_MEMI17,
  SET_MEMI17,
  ADD_MEMI23,
  SET_MEMI23,
  ADD_MEMI24_A,
  SET_MEMI24_A,
  ADD_MEMI24_B,
  SET_MEMI24_B,
  ADD_MEMI24_C,
  SET_MEMI24_C,
  SET_MEUP51,
  SET_MEUP54,
  SET_MEUP57,
  SET_MEUP58,
  SET_COMPANYID,
  SET_DIVISIONID,
  SET_MEUP52DIVISIONS,
  SET_MEUP53DIVISIONS,
  SET_MEUP53GROUPS,
  SET_MEUP53CATEGORYLIST,
  SET_UNBLOCK_RES,
  SET_RADIO_OPTION,
  SET_SELECTED_ROWS,
  SET_MEUP51_UPLOADITEM,
  SET_MEUP62,
  SET_MEUP63,
  SET_MEUP52_BLOCK_ITEMS_AND_STORES,
  SET_MEUP54_STORE_ITEMS_FOR_REPORT,
  SET_MEUP56_STORE_ITEMS_HISTORY,
  SET_MEUP,
  SET_APP_STATE,
  SET_LOADER,
  ADD_LOADER
} from "../context/ApplicationConstants";

export let initialState = {
  data: [{}],
  userInfo: [{}],
  lastSearch: [{}],
  memi01: [{}],
  memi08: [],
  memi13: [],
  configurationSets: [{}],
  configurationVars: [{}],
  memi14_A: [],
  memi17: [],
  memi23: [],
  memi20: [],
  memi24_A: [],
  memi24_B: [],
  memi24_C: [],
  memi21: [],
  memi22: [],
  meup51: [],
  meup54:[],
  meup57:[],
  meup58:{divisionList: [], stockingSectionList: []},
  division: [],
  meup52Divisions: [],
  meup53Divisions: [],
  meup53Groups: [],
  meup53CategoryList: [],
  unblockRes:[],
  rowData:[],
  radioVal:"",
  companyId: "",
  divisionId: "",
  meup62: [],
  meup63: [],
  appState: {},
  loader:0,
};

export const ApplicationContextProvider = (props) => {
  
  let [state, dispatch] = useReducer(ApplicationReducer, initialState);

  const setData = (data) => {
    dispatch({
      type: SET_DATA,
      payload: data,
    });
  };

  const addData = (data) => {
    dispatch({
      type: ADD_DATA,
      payload: data,
    });
  };
  const deleteData = (dataId) => {
    dispatch({
      type: DELETE_DATA,
      payload: dataId,
    });
  };
  const setUserInfo = (userInfo) => {
    dispatch({
      type: SET_USERINFO,
      payload: userInfo,
    });
  };

  const addUserInfo = (userInfo) => {
    dispatch({
      type: ADD_USERINFO,
      payload: userInfo,
    });
  };

  const setLastSearch = (lastSearch) => {
    dispatch({
      type: SET_LASTSEARCH,
      payload: lastSearch,
    });
  };

  const addLastSearch = (lastSearch) => {
    dispatch({
      type: ADD_LASTSEARCH,
      payload: lastSearch,
    });
  };

  const setMemi01 = (memi01) => {
    dispatch({
      type: SET_MEMI01,
      payload: memi01,
    });
  };

  const setMemi13 = (memi13) => {
    dispatch({
      type: SET_MEMI13,
      payload: memi13,
    });
  };

  const setMemi20 = (memi20) => {
    dispatch({
      type: SET_MEMI20,
      payload: memi20,
    });
  };
  const setMemi21 = (memi21) => {
    dispatch({
      type: SET_MEMI21,
      payload: memi21,
    });
  };
  const setMemi14_A = (memi14_A) => {
    dispatch({
      type: SET_MEMI14_A,
      payload: memi14_A,
    });
  };
  const setMemi17 = (memi17) => {
    dispatch({
      type: SET_MEMI17,
      payload: memi17,
    });
  };
  const setMemi23 = (memi23) => {
    dispatch({
      type: SET_MEMI23,
      payload: memi23,
    });
  };
  const setMemi24_A = (memi24_A) => {
    dispatch({
      type: SET_MEMI24_A,
      payload: memi24_A,
    });
  };
  const setMemi24_B = (memi24_B) => {
    dispatch({
      type: SET_MEMI24_B,
      payload: memi24_B,
    });
  };
  const setMemi24_C = (memi24_C) => {
    dispatch({
      type: SET_MEMI24_C,
      payload: memi24_C,
    });
  };

  

  const setMemi22 = (memi22) => {
    dispatch({
      type: SET_MEMI22,
      payload: memi22,
    });
  };
  const addMemi01 = (memi01) => {
    dispatch({
      type: ADD_MEMI01,
      payload: memi01,
    });
  };

  const setMemi08 = (memi08) => {
    dispatch({
      type: SET_MEMI08,
      payload: memi08,
    });
  };

  const addMemi08 = (memi08) => {
    dispatch({
      type: ADD_MEMI08,
      payload: memi08,
    });
  };
  const addMemi13 = (memi13) => {
    dispatch({
      type: ADD_MEMI13,
      payload: memi13,
    });
  };

  const resetApplicationContext = (intitalState) => {
    dispatch({
      type: SET_MEUP,
      payload: initialState
    })
  }

  const setConfigurationSets = (configurationSets) => {
    dispatch({
      type: SET_CONFIGURATION_SETS,
      payload: configurationSets,
    });
  };
  const addConfigurationSets = (configurationSets) => {
    dispatch({
      type: ADD_CONFIGURATION_SETS,
      payload: configurationSets,
    });
  };

  const setConfigurationVars = (configurationVars) => {
    dispatch({
      type: SET_CONFIGURATION_VARS,
      payload: configurationVars,
    });
  };
  const addConfigurationVars = (configurationVars) => {
    dispatch({
      type: ADD_CONFIGURATION_VARS,
      payload: configurationVars,
    });
  };

  const addMemi14_A = (memi14_A) => {
    dispatch({
      type: ADD_MEMI14_A,
      payload: memi14_A,
    });
  };
  const addMemi17 = (memi17) => {
    dispatch({
      type: ADD_MEMI17,
      payload: memi17,
    });
  };
  const addMemi23 = (memi23) => {
    dispatch({
      type: ADD_MEMI23,
      payload: memi23,
    });
  };
  const addMemi24_A = (memi24_A) => {
    dispatch({
      type: ADD_MEMI24_A,
      payload: memi24_A,
    });
  };
  const addMemi24_B = (memi24_B) => {
    dispatch({
      type: ADD_MEMI24_B,
      payload: memi24_B,
    });
  };
  const addMemi24_C = (memi24_C) => {
    dispatch({
      type: ADD_MEMI24_C,
      payload: memi24_C,
    });
  };
  const setMeup51 = (meup51) => {
    dispatch({
      type: SET_MEUP51,
      payload: meup51,
    });
  };

  const setMeup54 = (meup54) => {
    dispatch({
      type: SET_MEUP54,
      payload: meup54,
    });
  };
  const setMeup57 = (meup57) => {
    dispatch({
      type: SET_MEUP57,
      payload: meup57,
    });
  };

  const setMeup58 = (meup58) => {
    dispatch({
      type: SET_MEUP58,
      payload: meup58,
    });
  };


  const setCompanyId = (companyId) => {
    dispatch({
      type: SET_COMPANYID,
      payload: companyId,
    });
  }

  const setDivisionId = (divisionId) => {
    dispatch({
      type: SET_DIVISIONID,
      payload: divisionId,
    });
  }

  

  const setMeup52Divisions = (divisions) => {
    dispatch({
      type: SET_MEUP52DIVISIONS,
      payload: divisions
    })
  }

  const setMeup53Divisions = (divisions) => {
    dispatch({
      type: SET_MEUP53DIVISIONS,
      payload: divisions
    })
  }

  const setMeup53Groups = (groups) => {
   // console.log("groups in context", groups)
    dispatch({
      type: SET_MEUP53GROUPS,
      payload: groups
    })
  }

  const setMeup53CategoryList = (categoryList) => {
    // console.log("groups in context", categoryList)
    dispatch({
      type: SET_MEUP53CATEGORYLIST,
      payload: categoryList
    })
  }
  const setUnblockResponse=(unblockMap)=> {
    console.log("unblock Response",unblockMap);
    dispatch({
      type: SET_UNBLOCK_RES,
      payload: unblockMap
    })
  }
  const setOptionSearch=(radioBtn)=> {
    console.log("UPDATE SEARCH FOR",radioBtn);
    dispatch({
      type: SET_RADIO_OPTION,
      payload: radioBtn
    })
  }

  const mapSelectedRowData=(data)=>{
    console.log(data);
    dispatch({
      type:SET_SELECTED_ROWS,
      payload:data
    })
  }
  
  const setMeup51UploadItem = (meup51UploadItem) => {
    dispatch({
      type: SET_MEUP51_UPLOADITEM,
      payload: meup51UploadItem
    })
  }

  const setMeup62 = (meup62) => {
    dispatch({
      type: SET_MEUP62,
      payload: meup62
    })
  }

  const setMeup63 = (meup63) => {
    dispatch({
      type: SET_MEUP63,
      payload: meup63
    })
  }

  const setMeup52BlockItemsAndStores = (meup52BlockItemsAndStores) => {
    dispatch({
      type: SET_MEUP52_BLOCK_ITEMS_AND_STORES,
      payload: meup52BlockItemsAndStores
    })
  }

  const setMeup54StoreItemsForReport = (meup54StoreItemsForReport) => {
    dispatch({
      type: SET_MEUP54_STORE_ITEMS_FOR_REPORT,
      payload: meup54StoreItemsForReport
    })
  }


  const setMeup56StoreItemsHistory = (meup56StoreItemsHistory) => {
    dispatch({
      type: SET_MEUP56_STORE_ITEMS_HISTORY,
      payload: meup56StoreItemsHistory
    })
  }

  const setAppState = (key, value) => {
    dispatch({
      type: SET_APP_STATE,
      payload: {[`${key}`]: value}
    })
  }

  const setLoader = (loader) => {
    dispatch({
      type: SET_LOADER,
      payload:loader
    })
  }

  const addLoader = (loader) => {
    dispatch({
      type: ADD_LOADER,
      payload: loader
    })
  }
  return (
    <ApplicationContext.Provider
      value={{
        memi01: state.memi01,
        memi08: state.memi08,
        memi13: state.memi13,
        memi20: state.memi20,
        memi21: state.memi21,
        memi22: state.memi22,
        lastSearch: state.lastSearch,
        userInfo: state.userInfo,
        data: state.data,
        configurationSets: state.configurationSets,
        configurationVars: state.configurationVars,
        memi14_A: state.memi14_A,
        memi17: state.memi17,
        memi23: state.memi23,
        memi24_A: state.memi24_A,
        memi24_B: state.memi24_B,
        memi24_C: state.memi24_C,
        meup51: state.meup51,
        meup54:state.meup54,
        meup57:state.meup57,
        meup58: state.meup58,
        division: state.division,
        division2: state.division2,
        companyId: state.companyId,
        divisionId: state.divisionId,
        meup52Divisions: state.meup52Divisions,
        meup53Divisions: state.meup53Divisions,
        unblockRes:state.unblockRes,
        rowData:state.rowData,
        meup53Groups: state.meup53Groups,
        meup53CategoryList: state.meup53CategoryList,
        meup51UploadItem: state.meup51UploadItem,
        radioVal:state.radioVal,
        meup62: state.meup62,
        meup63: state.meup63,
        meup52BlockItemsAndStores: state.meup52BlockItemsAndStores,
        meup54StoreItemsForReport: state.meup54StoreItemsForReport,
        meup56StoreItemsHistory: state.meup56StoreItemsHistory,
        appState: state.appState,
        loader:state.loader,
        addData,
        deleteData,
        setData,
        setUserInfo,
        addUserInfo,
        setLastSearch,
        addLastSearch,
        setMemi01,
        addMemi01,
        setMemi08,
        addMemi08,
        addMemi13,
        setMemi13,
        setMemi20,
        setMemi21,
        setMemi22,
        setConfigurationSets,
        addConfigurationSets,
        setConfigurationVars,
        addConfigurationVars,
        addMemi14_A,
        setMemi14_A,
        addMemi17,
        setMemi17,
        addMemi23,
        setMemi23,
        addMemi24_A,
        setMemi24_A,
        addMemi24_B,
        setMemi24_B,
        addMemi24_C,
        setMemi24_C,
        setMeup51,
        setMeup54,
        setMeup57,
        setMeup58,
        setCompanyId,
        setDivisionId,
        setMeup52Divisions,
        setMeup53Divisions,
        setMeup53Groups,
        setMeup53CategoryList,
        setUnblockResponse,
        setOptionSearch,
        mapSelectedRowData,
        setMeup51UploadItem,
        setMeup62,
        setMeup63,
        setMeup52BlockItemsAndStores,
        setMeup54StoreItemsForReport,
        setMeup56StoreItemsHistory,
        resetApplicationContext,
        setAppState,
        setLoader,
        addLoader
      }}
    >
      {props.children}
    </ApplicationContext.Provider>
  );
};

export default ApplicationContextProvider;
