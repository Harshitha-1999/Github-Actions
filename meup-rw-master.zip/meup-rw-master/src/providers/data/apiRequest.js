import axios from "axios";

const apiRequest = async (url = "") => {
  try {
    const response = await fetch(url);
    if (!response.ok) throw Error("Please reload the app");
  } catch (err) {
    errMsg = err.message;
  } finally {
    return errMsg;
  }
};

export default apiRequest;
