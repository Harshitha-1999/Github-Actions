import React, { useEffect, useCallback } from 'react';
import { authTokenCookie } from 'utils';
import { ServiceError } from 'components';
import { useAccessDetails, useFieldDetails, useInterceptors } from 'hooks';
import { LOGIN_ROOT } from 'api/constants';

export const AccessDetailsProvider = ({ children }) => {
    const { authCookie } = authTokenCookie();
    const { fetchAccessDetails, accessDetailsError, accessDetailsLoading, accessDetailsData } = useAccessDetails();
    const { fetchFieldDetails, fieldDetailsError, fieldDetailsLoading, fieldDetailsData } = useFieldDetails();
    const {
        clearResponseInterceptors,
        setupResponseInterceptors,
    } = useInterceptors();

    useEffect(() => {
        clearResponseInterceptors();
        setupResponseInterceptors();
    }, [clearResponseInterceptors, setupResponseInterceptors]);

    useEffect(() => {
        let navigated=window.location.href.indexOf("navigated=true")>0
        if (authCookie.name) {
            fetchAccessDetails();
            fetchFieldDetails();
        }
        else {
            //Clear browser session storage on logout.
            sessionStorage.clear();
            if(navigated){
                let sessionUrl=window.location.href
                document.cookie= `sessionUrl= ${sessionUrl}`
            }
            window.location.replace(`${LOGIN_ROOT}/authenticate`);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fetchAccessDetails, fetchFieldDetails]);

    const checkAccess = useCallback(() => {
        return (
            !accessDetailsLoading && !fieldDetailsLoading &&
            !accessDetailsError && !fieldDetailsError &&
            accessDetailsData && fieldDetailsData
        );
    }, [accessDetailsData, accessDetailsLoading, accessDetailsError, fieldDetailsError, fieldDetailsLoading, fieldDetailsData]);

    if (accessDetailsError || fieldDetailsError) {
        const errorDetails = accessDetailsError ? accessDetailsError : fieldDetailsError;
        return (
            <ServiceError programName={"ACCESS DETAILS"} error={errorDetails} />
        );
    }

    if (checkAccess()) {
        return <>{children}</>
    }

    return null;
};

export default AccessDetailsProvider;