import React from 'react';
import { ServiceError } from 'components';

export class ErrorBoundary extends React.Component {
    constructor(props) {
      super(props);
      
      this.state = { hasError: false, type:"", description: "" };
    }
    
  
    static getDerivedStateFromError(error) {
      // Update state so the next render will show the fallback UI.
      return { hasError: true, description:"Failed -> System Error Occured. Please contact admin"};
    }
    
   
    render() {
      
      if (this.state.hasError) {
        // You can render any custom fallback UI
        return (
            <ServiceError label={this.props.label} programName={"MEUP"} error={{config: { method: 'JS' }, message : this.state.description}} />
        )        
      }  
      return this.props.children; 
    }
  }

  export default ErrorBoundary;