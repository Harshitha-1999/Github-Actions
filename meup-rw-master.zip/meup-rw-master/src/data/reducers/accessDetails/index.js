import {
    handleStateLifecycle,
    createAxiosAsyncDispatcher
  } from 'middleware/asyncDispatcher';

  import { FETCH_ACCESS_DETAILS } from './actions';

  const AccessDetailsDispatcher = createAxiosAsyncDispatcher((state, action) => {
    if(action.type === FETCH_ACCESS_DETAILS){
      return handleStateLifecycle(state, action);
    }
    else{
      return state;
    }
  });

  export default AccessDetailsDispatcher;