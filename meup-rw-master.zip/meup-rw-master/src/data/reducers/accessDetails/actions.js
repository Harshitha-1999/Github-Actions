import { AccessDetailsService } from "api/accessDetails";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_ACCESS_DETAILS = 'security/FETCH_ACCESS_DETAILS';

export const getAccessDetails = () =>
createAxiosAction({
    type: FETCH_ACCESS_DETAILS,
    promise: AccessDetailsService.getAccessDetails()
});