import {
    handleStateLifecycle,
    createAxiosAsyncDispatcher
  } from 'middleware/asyncDispatcher';

  import { FETCH_FIELD_DETAILS } from './actions';

  const FieldDetailsDispatcher = createAxiosAsyncDispatcher((state, action) => {
    if(action.type === FETCH_FIELD_DETAILS){
      return handleStateLifecycle(state, action);
    }
    else{
      return state;
    }
  });

  export default FieldDetailsDispatcher;