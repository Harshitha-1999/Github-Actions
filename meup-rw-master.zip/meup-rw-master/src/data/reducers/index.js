import { combineReducers } from "redux";
import AccessDetailsDispatcher from './accessDetails';
import FieldDetailsDispatcher from './fieldDetails';

export const initialRootState = {
  AccessDetails: AccessDetailsDispatcher.initialState,
  FieldDetails: FieldDetailsDispatcher.initialState,

};

const rootReducer = combineReducers({
  AccessDetails: AccessDetailsDispatcher.reducer,
  FieldDetails: FieldDetailsDispatcher.reducer,
 
});

export default rootReducer;
