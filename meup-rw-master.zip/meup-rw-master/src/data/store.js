import { createStore, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import thunk from "redux-thunk";
import asyncDispatcher from "middleware/asyncDispatcher";

import rootReducer, { initialRootState } from "./reducers";

export const middlewareStack = [thunk, asyncDispatcher];

const store = createStore(
  rootReducer,
  initialRootState,
  composeWithDevTools(applyMiddleware(...middlewareStack))
);

export default store;
