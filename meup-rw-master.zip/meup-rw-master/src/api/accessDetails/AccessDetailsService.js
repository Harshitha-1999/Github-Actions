import { DefaultAxios, getNoCacheHeaders } from 'api/util';
import { ENDPOINT_ACCESS_DETAILS } from 'api/constants';

export class AccessDetailsService {
    static async getAccessDetails() {
        return DefaultAxios.get(ENDPOINT_ACCESS_DETAILS, {
            headers: getNoCacheHeaders()
        });
    }
}
export default AccessDetailsService;
