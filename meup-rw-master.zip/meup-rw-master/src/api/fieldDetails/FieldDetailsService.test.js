import {FieldDetailsService} from './FieldDetailsService';
import {DefaultAxios} from 'api/util/axios-instances/DefaultAxios';

describe('FieldDetailsService class', () => {
    let axiosPostSpy = jest.spyOn(DefaultAxios, 'post').mockResolvedValue(true);
        
    afterEach(() => {
        jest.clearAllMocks();
    })

    it('Should call the getFieldDetails function', async () => {
        await FieldDetailsService.getFieldDetails();
        expect(axiosPostSpy).toHaveBeenCalled();
    });
})