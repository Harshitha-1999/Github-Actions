import axios from "axios";

// For common config
//axios.defaults.headers.post["Content-Type"] = "application/json";

const dataAxios = axios.create({
  baseURL: "http://localhost:3500/data",
});

const userInfoAxios = axios.create({
  baseURL: "http://localhost:3500/userInfo",
});

const lastSearchAxios = axios.create({
  baseURL: "http://localhost:3500/lastSearch",
});

const MEMI01Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI01",
});

const MEMI02Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI02",
});

const MEMI03Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI03",
});

const MEMI08Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI08",
});

const MEMI13Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI13",
});

const MEMI20Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI20",
});

const MEMI21Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI21",
});

const MEMI22Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI22",
});
const configurationSetsAxios = axios.create({
  baseURL: "http://localhost:3500/ConfigurationSets",
});

const configurationVarsAxios = axios.create({
  baseURL: "http://localhost:3500/ConfigurationVars",
});

const MEMI14_AAxios = axios.create({
  baseURL: "http://localhost:3500/MEMI14-A",
});

const MEMI17Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI17",
});

const MEMI23Axios = axios.create({
  baseURL: "http://localhost:3500/MEMI23",
});

const MEMI24_AAxios = axios.create({
  baseURL: "http://localhost:3500/MEMI24_A",
});

const MEMI24_BAxios = axios.create({
  baseURL: "http://localhost:3500/MEMI24_B",
});

const MEMI24_CAxios = axios.create({
  baseURL: "http://localhost:3500/MEMI24_C",
});

const MEUP51Axios = axios.create({
  baseURL: "http://localhost:3500/MEUP51"
});

const MEUP54Axios = axios.create({
  baseURL: "http://localhost:3500/MEUP54"
});

const MEUP57Axios = axios.create({
  baseURL: "http://localhost:3500/MEUP57"
});
const MEMIMenu=axios.create({
  baseURL:"http://localhost:3500/MEMIMenu"
})

export {
  dataAxios,
  userInfoAxios,
  lastSearchAxios,
  MEMI01Axios,
  MEMI02Axios,
  MEMI03Axios,
  MEMI08Axios,
  MEMI13Axios,
  MEMI20Axios,
  MEMIMenu,
  configurationSetsAxios,
  configurationVarsAxios,
  MEMI14_AAxios,
  MEMI17Axios,
  MEMI23Axios,
  MEMI24_AAxios,
  MEMI24_BAxios,
  MEMI24_CAxios,
  MEMI22Axios,
  MEMI21Axios,
  MEUP51Axios,
  MEUP54Axios,
  MEUP57Axios,
};
