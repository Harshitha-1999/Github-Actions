import * as SharedInterceptors from "./sharedInterceptors";

describe("sharedInterceptors", () => {
  let axiosInstanceMock = {
    interceptors: {
      request: {
        use: (cb) => {
          cb({ headers: {} });
        },
      },
      response: {
        use: (cb) => {
          cb({ status: 401 });
        },
      },
    },
  };

  test("getRequestInterceptor", () => {
    SharedInterceptors.getRequestInterceptor(axiosInstanceMock);
  });

  test("getResponseInterceptor response is 401", () => {
    SharedInterceptors.getResponseInterceptor(axiosInstanceMock);
  });

  test("getResponseInterceptor response is 402", () => {
    let axiosInstanceMock = {
      interceptors: {
        request: {
          use: (cb) => {
            cb({ headers: {} });
          },
        },
        response: {
          use: (cb) => {
            cb({ status: 402 });
          },
        },
      },
    };

    SharedInterceptors.getResponseInterceptor(axiosInstanceMock);
  });

  test("getResponseInterceptor response has an error 401", () => {
    let axiosInstanceMock = {
      interceptors: {
        request: {
          use: (cb) => {
            cb({ headers: {} });
          },
        },
        response: {
          use: (cb, error) => {
            error({
              response: {
                status: 401,
              },
            });
          },
        },
      },
    };

    SharedInterceptors.getResponseInterceptor(axiosInstanceMock);
  });

  test("getResponseInterceptor response has no error", () => {
    let axiosInstanceMock = {
      interceptors: {
        request: {
          use: (cb) => {
            cb({ headers: {} });
          },
        },
        response: {
          use: (cb, error) => {
            error(false);
          },
        },
      },
    };

    SharedInterceptors.getResponseInterceptor(axiosInstanceMock);
  });
});
