import React from "react";
import { ApiMemi } from "../../components/ApiCallsMemi/ApiCallsMemi";
import { MEUP_APIs } from "../../service/apiUrls";
import { corpCd } from "utils/Constants";
import { authTokenCookie } from "utils";
import { generateUserLevel } from "components/CommonFunctionsMeup/CommonFunctionsMeup";
export class meupServices extends React.Component {
  static unblockUpdateStoreItems(data, otherData, comments, deleteDateTo) {
    const { userId } = authTokenCookie();
    console.log("rows selected to unblock", data);
   
    let obj = otherData.map((x) => {
      
      return {
        divisionDto: { divisionNumber: x.divisionDto.divisionNumber, corp: x.divisionDto.corp },
        smicCategoryDto: { categoryCd: x.smicCategoryDto.categoryCd },
        itemDto: { cic: x.itemDto.cic, dc: x.itemDto.dc },
        upc: x.upc,
        storeNumber: x.storeNumber,
        state: x.state,
        status: x.status,
        blockedTargetDate: x.blockedTargetDate,
        stateEffectiveDate: x.stateEffectiveDate,
        blockedStatus: x.blockedStatus,
        description: x.description,
        size: x.size,
        uom: x.uom,
        casePk: x.casePk.toString(),
        selected: true,
      };
    });
    let payload = {
      storeItemDTOList: obj,
      deleteDate: deleteDateTo !== "" ? deleteDateTo : null,
      userId: userId,
      comment: comments,
    };

    console.log("storeItemDTOList", payload);

    /* let testPayload = {
      storeItemDTOList: [
        {
          divisionDto: { divisionNumber: "33", corp: "001" },
          smicCategoryDto: { categoryCd: "1903" },
          itemDto: { cic: "22010030", dc: "WWEL" },
          upc: "002400001062",
          storeNumber: "1429",
          state: "A",
          status: "Blocked",
          blockedTargetDate: "2021-12-31",
          stateEffectiveDate: "2021-12-31",
          blockedStatus: "B",
          description: "DM PEACHES SLCD HEAVY SYRUP YELLOW CLING",
          size: 29.0,
          uom: "OZ",
          casePk: "6.0",
          selected: true,
        },
        {
          divisionDto: { divisionNumber: "33", corp: "001" },
          smicCategoryDto: { categoryCd: "0201" },
          itemDto: { cic: "02013110", dc: "WWEL" },
          upc: "002113030960",
          storeNumber: "1429",
          state: "A",
          status: "Blocked",
          blockedTargetDate: "2021-12-31",
          stateEffectiveDate: "2021-12-31",
          blockedStatus: "B",
          description: "S SEL COOKIES SMORES",
          size: 9.5,
          uom: "OZ",
          casePk: "12.0",
          selected: true,
        },
      ],
      deleteDate: null,
      userId: "SMURA16",
      comment: "test data",
    }; */
    return ApiMemi(MEUP_APIs.updateStoreItems, "POST", payload);
  }

  static async getDivisionListForUS() {
    return ApiMemi(MEUP_APIs.getDivisionListForUS + `?corpCd=${corpCd}`, "GET");
  }
  static postBlockItemsAndStores(division, date, storeItemHelperList) {
    const { userId } = authTokenCookie();
    let payload = {
      corp: "001",
      userid: userId,
      divisionNumber: division,
      deleteDate: date,
      storeItemHelperList: storeItemHelperList,
    };
    return ApiMemi(MEUP_APIs.postblockItemsAndStores, "POST", payload);
  }

  static async getStockingSections() {
    return ApiMemi(MEUP_APIs.division, "GET");
  }

  static async getAllItems(
    userId,
    country,
    selectedDivisions,
    selectedGroups,
    selectedCategories,
    cic,
    store,
    upc,
    deleteDateTo,
    deleteDateFrom,
    state
  ) {
    if (
      country &&
      userId &&
      (selectedDivisions.length > 0 ||
        selectedGroups.length > 0 ||
        selectedCategories.length > 0 ||
        cic ||
        store ||
        upc ||
        deleteDateTo ||
        deleteDateFrom ||
        state)
    ) {
      const userRole = generateUserLevel();
      const payload = {
        userId: userId,
        countryCd: country,
        divisions:
          selectedDivisions !== undefined && selectedDivisions.length > 0
            ? selectedDivisions.map((division) => {
                return { divisionNumber: division };
              })
            : null,
        groups:
          selectedGroups !== undefined && selectedGroups.length > 0
            ? selectedGroups.map((group) => {
                return { groupCd: group };
              })
            : null,
        categories:
          selectedCategories !== undefined && selectedCategories.length > 0
            ? selectedCategories.map((category) => {
                return { categoryCd: category };
              })
            : null,
        cic: cic,
        storeNumber: store,
        upc: upc,
        deleteDateStart: deleteDateFrom,
        deleteDateEnd: deleteDateTo,
        state: state,
        userDto: {
          userId: userId,
          role: userRole === "meup-admin" ? "ADMIN" : userRole === "meup-holduser" ? "HOLD" :"DIV",
        },
      };
      Object.keys(payload).forEach((key) => {
        if (payload[key] === undefined || payload[key] === "") {
          payload[key] = null;
          // delete payload[key];
        }
      });
      //console.log(payload);
      const testPayload = {
        userId: userId,
        countryCd: "001",
        divisions: [{ divisionNumber: "05" }, { divisionNumber: "15" }],
        groups: [{ groupCd: "01" }],
        categories: [{ categoryCd: "0101" }],
        cic: null,
        storeNumber: null,
        upc: null,
        deleteDateStart: "2019-01-31",
        deleteDateEnd: "2021-02-01",
        userDto: { userId: userId, role: "DIV" },
      };
      return ApiMemi(MEUP_APIs.getStoreItems, "POST", payload);
    } else {
      alert("please select at least other field with country");
    }
  }

  static async getDivisionListForUSMEUP53(country) {
    return ApiMemi(
      MEUP_APIs.getDivisionListForUS + `?corpCd=${country}`,
      "GET"
    );
  }

  static async getUploadItems(data, date, userId) {
    return ApiMemi(
      MEUP_APIs.uploadStoreItems + `?deleteDate=${date}&userID=${userId}`,
      "POST",
      data
    );
  }

  static async getGroupListForDivision(country, selectedDivisions) {
    return ApiMemi(
      MEUP_APIs.getGroupListForDivision +
        `?corp=${country}&divisionNumbers=${selectedDivisions}`,
      "GET"
    );
  }

  static async getCategoryListForGroup(country, selectedGroups) {
    return ApiMemi(
      MEUP_APIs.getCategoryListForGroup +
        `?corp=${country}&groupCds=${selectedGroups}`,
      "GET"
    );
  }

  static async getStoreCountsStoreItemsOnHold(
    divisionList,
    stockingSectionList
  ) {
    return ApiMemi(
      MEUP_APIs.getStoreCountsStoreItemsOnHold +
        `divisionList=${divisionList}&stockingSectionList=${stockingSectionList}&corp=${corpCd}`,
      "GET"
    );
  }
  static async getStoreItemsOnHold(groups = []) {
    return ApiMemi(
      MEUP_APIs.getStoreItemsOnHold + `?corp=001&groupCode=${groups}`,
      "GET"
    );
  }

  static async getStoreItemsForReport(data) {
    return ApiMemi(MEUP_APIs.getStoreItemsForReport, "POST", data);
  }

  static async getItemsReport(data) {
    return ApiMemi(MEUP_APIs.getItemsReport, "POST", data, "blob");
  }
  static async getStoreStockingSection(storeId, stockingSectionNumbr) {
    return ApiMemi(
      MEUP_APIs.getStoreStockingSection +
        `?corp=${corpCd}&storeID=${storeId}&stockSectionNbr=${stockingSectionNumbr}`,
      "GET"
    );
  }
  static async postUpdateHoldStatus(data) {
    const { userId } = authTokenCookie();

    let acceptList = [];
    let rejectList = [];

    for (let i = 0; i < data.length; i++) {
      if (data[i].accept) {
        acceptList.push({
          divisionNbr: data[i].divisionNbr,
          status: "A",
          stockSectionNbr: data[i].stockSectionNbr,
          storeID: data[i].storeID,
          upcID: data[i].upcID
        });
      } else if (data[i].reject) {
        rejectList.push({
          divisionNbr: data[i].divisionNbr,
          status: "R",
          stockSectionNbr: data[i].stockSectionNbr,
          upcID: data[i].upcID
        });
      }
    }


    const postData = {
      groupID: "",
      acceptList,
      rejectList,
      userID: userId,
    };

    return ApiMemi(MEUP_APIs.postUpdateHoldStatus, "POST", postData);
  }

  static async postUpdateHoldStatusStoreLevel(data) {
    const { userId } = authTokenCookie();

    let acceptList = [];
    let rejectList = [];

    for (let i = 0; i < data.length; i++) {
      if (data[i].accept) {
        acceptList.push({
          divisionNbr: data[i].divisionId,
          status: "A",
          stockSectionNbr: data[i].stockSectnbr,
          storeID: data[i].storeId,
        });
      } else if (data[i].reject) {
        rejectList.push({
          divisionNbr: data[i].divisionId,
          status: "R",
          stockSectionNbr: data[i].stockSectnbr,
        });
      }
    }

    

    const postData = {
      groupID: "",
      acceptList,
      rejectList,
      userID: userId,
    };


    return ApiMemi(MEUP_APIs.postUpdateHoldStatusStoreLevel, "POST", postData);
  }

  static async getAllGroupsInHoldStatus() {
    return ApiMemi(MEUP_APIs.getAllGroupsInHoldStatus, "GET");
  }

  static async getItemHistory(itemDetails) {
    const data = {
      userId: itemDetails.userId,
      divisionDto: { divisionNumber: itemDetails.divisionDto },
      smicCategoryDto: {
        categoryCd: itemDetails.categoryCd,
        categoryDesc: itemDetails.categoryDesc,
      },
      itemDto: { cic: itemDetails.cic },
      storeNumber: itemDetails.storeNumber,
      "state ": itemDetails.dispState,
      upc: itemDetails.dispUpc,
      description: itemDetails.description,
      itemType: itemDetails.itemType,
      size: itemDetails.size,
      uom: itemDetails.uom,
      casePk: itemDetails.casePk,
      stateEffectiveDate: itemDetails.stateEffectiveDate,
      blockedStatus: itemDetails.dispBlockedStatus,
      blockedTargetDate: itemDetails.blockedTargetDate,
    };

    console.log(data, itemDetails);
    return ApiMemi(MEUP_APIs.getItemHistory, "POST", data);
  }
}
