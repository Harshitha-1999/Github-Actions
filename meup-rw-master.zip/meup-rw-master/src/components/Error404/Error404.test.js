import React from 'react';
import { fireEvent, render ,screen } from "@testing-library/react";
import Error404 from './index';

const mockHistoryPush = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}));

describe('<Error404 />', () => {
  const mockMessageTitle= '404 Not Found';
  const mockMessage = ' Opps! Lost Somewhere?';
  const buttonLabel = 'Return Home';

  it('Should render without errors', () => {
    const {debug,container} = render(
      <Error404 />
    )
  });

  it('Should call navigate', () => {
    const {debug,container} = render(
      <Error404 />
    );

    fireEvent.click(screen.getByTestId("error-404-button"));
    expect(container).toBeTruthy();
    expect(mockHistoryPush).toHaveBeenCalled()
    });
})


