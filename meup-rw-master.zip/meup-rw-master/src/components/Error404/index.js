import React from 'react';
import {useNavigate} from "hooks";
import "./Error404.scss";

export const Error404 = () => {
  const { navigate } = useNavigate();
  return (
    <div data-testid="error-404" align="center"> 
        <h1> 404 Not Found </h1>
        <h5> Opps! Lost Somewhere? </h5>
        <button data-testid="error-404-button" className={"returnHomeBtn"} onClick={() => navigate('/')} > Return Home </button>
    </div>
  );
}

export default Error404;