import React from "react";
import TextField from "@material-ui/core/TextField";

import { Grid } from "@material-ui/core";


export default function TextFieldMemi(props) {
 
  const errorText = props.errorText !== undefined ? props.errorText : `${props.id} must be at least ${props.length} characters`;
  const onChangeText = (text) => {
    
    if(props.limit && text.length > props.limit) {
      
      return;
    }
    props.setTextValue(text)
    
    if (props.setError) {
      if (text.length < props.length) {
        props.setError(true);
      } else {
        props.setError(false);
      }

    }
    
  };
 
 
  return (
    <Grid container>
      <Grid item sm={props.alignItems === "row" ? 4 :12} style={{display:"flex", alignItems:"center"}}>
        <label className={props.LabelClass}>{props.label}</label>
      </Grid>
      <Grid item sm={props.alignItems === "row" ? 8 :12 }>
        <TextField
          className={`${props.TextFieldClass} ${props.disabled?'disabledtextfield':""}`}
          id={props.id}
          variant="outlined"
          type={props.type}
          value={props.value}
          placeholder={props.placeholderMemi}
          onChange={(e) => onChangeText(e.target.value)}
          error={props.error}
          helperText={props.error ? errorText : ""}
          multiline={props.multiline}
          disabled={props.disabled}
          rows={2}
          required={props.required}
          fullWidth={props.fullWidth === false || props.fullWidth === true ? props.fullWidth : true}
          InputProps={{
            classes: {
              input: props.input,
            },
          }}
        />
      </Grid>
    </Grid>
  );
}
