import React, { useContext, useEffect, useCallback } from 'react';
import TableMemi from "../TableMemi/TableMemi";
import Box from "@mui/material/Box";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { useHistory } from 'react-router';
import { Grid } from "@material-ui/core";
import { DateUtility } from "utils";
import ApplicationContext from "../../context/ApplicationContext";
import { meupServices } from "../../api/meup/meupServices";
import { Link } from 'react-router-dom';
import { RouteBase } from '../../routes/constants/RouteBase'
import {formatdate} from"../CommonFunctionsMeup/CommonFunctionsMeup"
function StoreItemsReport() {

    const history = useHistory();

    const AppData = useContext(ApplicationContext);


    let columns = [

        {
            field: "divisionDto",
            headerName: "DV",
            sortable: true,
            width: 53,
            headerAlign: "left",
            type:"number",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "storeNumber",
            headerName: "Store #",
            sortable: true,
            width: 70,
            headerAlign: "left",
            type:"number",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "dispCategory",
            headerName: "Category",
            sortable: true,
            width: 165,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "dispUpc",
            headerName: "UPC",
            sortable: true,
            width: 76,
            headerAlign: "center",
            type:"number",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "cic",
            headerName: "CIC",
            sortable: true,
            width: 60,
            headerAlign: "center",
            type:"number",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "description",
            headerName: "Description",
            sortable: true,
            width: 210,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "itemType",
            headerName: "Item Type",
            sortable: true,
            width: 80,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "sizeUOMForDisplay",
            headerName: "Size",
            sortable: true,
            width: 65,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            sortComparator: (v1, v2) => {return parseFloat(v1.split(" ")[0]) - parseFloat(v2.split(" ")[0])}

        },
        {
            field: "uom",
            headerName: "UOM",
            sortable: true,
            width: 65,
            headerAlign: "left",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "casePk",
            headerName: "Case Pk",
            sortable: true,
            width: 65,
            headerAlign: "center",
            type:"number",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "dispState",
            headerName: "State",
            sortable: true,
            width: 67,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "stateEffectiveDateForDisplayResult",
            headerName: "State Effective Date",
            sortable: true,
            width: 87,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}

        },
        {
            field: "dispBlockedStatus",
            headerName: "Status",
            sortable: true,
            width: 73,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "blockedTargetDate",
            headerName: "Delete Date",
            sortable: true,
            width: 74,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            valueGetter: (params) => {
                return formatdate(params.value)
            },
            sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}
           

        },
        {
            field: "history",
            headerName: "History",
            sortable: true,
            width: 88,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            renderCell: (params) => <span className={"storeItemsReportLinkClass"} onClick={() =>onRedirectMeup56(params)}>History</span>

            // renderCell: (params) => <Link to={{ pathname: "/MEUP56", query: "params.row" }} target="_blank" className="routelink">
            //     {"History"}
            // </Link>
        }
    ];

    const onRedirectMeup56 = useCallback((params) => {
        localStorage.setItem(`meup55StoreItems${params.row.uniqueSelectionCode}`, JSON.stringify(params.row));
        // console.log(sessionStorage)
        window.open(RouteBase.MEUP56+`?selectionCode=${params.row.uniqueSelectionCode}`, "_blank", "noreferrer");
    }, [])

    const handleSubmit = useCallback(() => {


        if (AppData.meup54StoreItemsForReport && AppData.meup54StoreItemsForReport.length > 0) {

            let result = AppData.meup54StoreItemsForReport.map((value, i) => {
                return { divisionDto: { divisionNumber: value.divisionDto }, smicCategoryDto: { categoryCd: value.categoryCd, categoryDesc: value.categoryDesc }, itemDto: { cic: value.cic }, storeNumber: value.storeNumber, state: value.dispState, upc: value.dispUpc, description: value.description, itemType: value.itemType, size: value.size, uom: value.uom, casePk: value.casePk, stateEffectiveDate: value.stateEffectiveDate, blockedTargetDate: value.blockedTargetDate, blockedStatus: value.dispBlockedStatus, userId: value.userId }

            });

            meupServices.getItemsReport(result).then((res) => {
                const url = window.URL.createObjectURL(new Blob([res.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', "MeupStoreItem.xlsx");
                document.body.appendChild(link);
                link.click();
            })
        }

    }, [])

    return (
        <div>
            
            <Grid container className="blockItemsMarginTop">
            {/* <Box display={"-ms-flexbox"}> */}
                <TableMemi
                    data={(AppData.meup54StoreItemsForReport !== undefined && AppData.meup54StoreItemsForReport !== null && AppData.meup54StoreItemsForReport.length > 0) ? AppData.meup54StoreItemsForReport : []}
                    columns={columns}
                    classnameMemi="tableModifyDeleteDate"
                    showCellRightBorder={true}
                    showColumnRightBorder={true}
                    hideFooter={true}
                    hideFooterPagination={true}
                    hideFooterSelectedRowCount={true}
                    autoHeight={true}
                    rowheight={50}
                    // rowheight={40}
                />
            {/* </Box> */}
                <Grid
                    item
                    xs={12}
                    className="blockItemsMarginTop"
                    style={{ marginBottom: "1rem" }}
                >
                    <ButtonMemi
                        btnval="Search Again"
                        btnvariant="contained"
                        classNameMemi="blockItemsButtons"
                        onClick={() => {
                            history.push(RouteBase.MEUP54);
                        }}
                    />

                    <ButtonMemi
                        btnval="Download to Excel"
                        btnvariant="contained"
                        classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                        onClick={handleSubmit}
                    />

                    <ButtonMemi
                        btnval="Cancel"
                        btnvariant="contained"
                        classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                        onClick={() => {
                            history.push('/');
                        }}
                    />
                </Grid>
            </Grid>
        </div >
    );
}

export default StoreItemsReport;