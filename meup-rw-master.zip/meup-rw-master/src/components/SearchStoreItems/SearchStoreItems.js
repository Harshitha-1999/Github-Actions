import React, { useState, useEffect, useContext, useCallback } from "react";
import { Grid } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { meupServices } from "../../api/meup/meupServices";

import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ListSelectMeup from "components/ListSelectMeup/ListSelectMeup";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ApplicationContext from "../../context/ApplicationContext";

import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";
import { authTokenCookie, DateUtility } from "utils";

import TextFieldMemi from "components/TextField/TextFieldMemi";
import { validateCicUpcStore } from "components/CommonFunctionsMeup/CommonFunctionsMeup";
import { RouteBase } from "routes/constants";
import { usePersistState } from 'hooks/usePersistState';

function SearchStoreItems() {
  const history = useHistory();
  const AppData = useContext(ApplicationContext);
  let { userId } = authTokenCookie();

  const [country, setCountry] = useState("001");

  const [errCountry, setErrorCountry] = useState(false);
  const [selectedDivisions, setSelectedDivisions] = usePersistState([], "meup53SelectedDivisions");
  const [selectedGroups, setSelectedGroups] = usePersistState([], "meup53SelectedGroups");
  const [selectedCategories, setSelectedCategories] =usePersistState([], "meup53SelectedCategories");;
  const [cicUpcStoreValue, setCicUpcStoreValue] = usePersistState({ cic: "", upc: "", store: "", state: "", status: "" }, "meup53CicUpcStore");
  
  const [errors, setErrors] = useState([]);
  const [errorCic, setErrorCic] = useState(false);
  const [errorUpc, setErrorUpc] = useState(false);
  const [errorStore, setErrorStore] = useState(false);

  // fetch division options
  useEffect(() => {
    // AppData.addLoader(1)
    
    AppData.setMeup53Divisions([]);
    setErrors([]);
    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);
    
    meupServices.getDivisionListForUSMEUP53("001")
      .then((res) => {
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispDivision, value: data.divisionNumber };
        });
        
        AppData.setMeup53Divisions(data);
        // AppData.addLoader(-1)
      })
      .catch((error) => {
        // AppData.addLoader(-55)
        AppData.setMeup53Divisions([]);
        setSelectedCategories([])
        setSelectedDivisions([])
        setSelectedGroups([])
        AppData.setMeup53CategoryList([])
        AppData.setMeup53Groups([]);
        setErrors(["An Exception occurred while retrieving the data."]);
        window.scrollTo(0, 0);
      })
  }, []);



  const onChangeDivision = (value) => {

    setSelectedDivisions(value)
    setSelectedGroups([]);
    AppData.setMeup53CategoryList([]);
    setSelectedCategories([]);
    setErrors([]);
    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);
    // AppData.addLoader(1)
    //api call to fetch group of that particular division
    meupServices.getGroupListForDivision(country, value)
      .then((res) => {
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispGroup.trim(), value: data.groupCd };
        });
        // AppData.addLoader(-1)
        AppData.setMeup53Groups(data);
      })
      .catch((error) => {
        // AppData.addLoader(-55)
        AppData.setMeup53Groups([]);
        setErrors(["An Exception occurred while retrieving the data."]);

      });


  };


  const onChangeGroup = (value) => {
    //api call to fetch group of that particular category
    setSelectedCategories([]);
    AppData.setMeup53CategoryList([]);
    setSelectedGroups(value);
    setErrors([]);
    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);

    // AppData.addLoader(1) 
    meupServices.getCategoryListForGroup(country, value)
      .then((res) => {
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispCategory.trim(), value: data.categoryCd };
        });
        // AppData.addLoader(-1)
        AppData.setMeup53CategoryList(data);
      })
      .catch((error) => {
        AppData.setMeup53CategoryList([]);
        setErrors(["An Exception occurred while retrieving the data."]);
        window.scrollTo(0, 0);
        // AppData.addLoader(-55)
      });

  };

  const onChangeCategory = useCallback((value) => {
    setSelectedCategories(value);
    setErrors([]);
    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);

    setCicUpcStoreValue(preState => ({ ...preState, cic: "", upc: "" }));

  }, [cicUpcStoreValue, selectedCategories]);

  const onChangeCIC = useCallback((value) => {
    // setCic(value);

    setCicUpcStoreValue(preState => ({ ...preState, cic: value }));

    if (value.length > 0 && cicUpcStoreValue.upc.length > 0) {
      setSelectedCategories("");
      setSelectedGroups("");
    }
  }, [selectedGroups, cicUpcStoreValue, selectedCategories])

  const onChangeUPC = useCallback((value) => {
    setCicUpcStoreValue(preState => ({ ...preState, upc: value }));

    if (cicUpcStoreValue.cic.length > 0 && value.length > 0) {
      setSelectedCategories("");
      setSelectedGroups("");
    }
  }, [selectedCategories, cicUpcStoreValue, selectedGroups]);

  const handleSubmit = (e) => {
    e.preventDefault()
    let errorList = [];

    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);
  
    validateCicUpcStore("cic", cicUpcStoreValue.cic, 7, (error) => setErrorCic(error), errorList);
    validateCicUpcStore("upc", cicUpcStoreValue.upc, 10, (error) => setErrorUpc(error), errorList);
    validateCicUpcStore("store number", cicUpcStoreValue.store, 4, (error) => setErrorStore(error), errorList);

    setErrors(errorList);
    window.scrollTo(0, 0);

    if (selectedDivisions.length === 0 && selectedGroups.length === 0 && selectedCategories.length === 0 && cicUpcStoreValue.cic === "" && cicUpcStoreValue.store === "" && cicUpcStoreValue.state === "" && cicUpcStoreValue.status === "" && cicUpcStoreValue.upc === "") {
      setErrors(["Please specify at least one parameter other than Country."]);
    } else if (errorList.length <= 0) {

      let data = {
        userId: userId,
        countryCd: country,
        divisions: selectedDivisions.length > 0 ? selectedDivisions.map((division) => { return { "divisionNumber": division } }) : null,
        groups: selectedGroups.length > 0 ? selectedGroups.map((group) => { return { "groupCd": group } }) : null,
        categories: selectedCategories.length > 0 ? selectedCategories.map((category) => { return { "categoryCd": category } }) : null,
        cic: cicUpcStoreValue.cic !== "" ? cicUpcStoreValue.cic : null,
        storeNumber: cicUpcStoreValue.store !== "" ? cicUpcStoreValue.store : null,
        state: cicUpcStoreValue.state !== "" ? cicUpcStoreValue.state : null,
        status: cicUpcStoreValue.status !== "" ? cicUpcStoreValue.status : null,
        upc: cicUpcStoreValue.upc !== "" ? cicUpcStoreValue.upc : null
      }

      // AppData.addLoader(1)

      meupServices.getStoreItemsForReport(data).then((res) => {
        // AppData.setMeup52Divisions(res);
        // AppData.addLoader(-1)
        if (res.hasOwnProperty('data')) {
          var { data } = res;

          if (data.status === "SUCCESS") {

            if (data.hasOwnProperty('data')) {
              var { data } = data;

              if (data.hasOwnProperty('REST_RETURNED_DATA')) {

                let { REST_RETURNED_DATA } = data;

                let meup55Array = [];

                if (REST_RETURNED_DATA !== null && REST_RETURNED_DATA.length > 0) {

                  REST_RETURNED_DATA.map((value, i) => {
                    meup55Array.push({ id: i, storeNumber: value.storeNumber, divisionDto: value.divisionNumber, dispCategory: value.smicCategoryDto.dispCategory, categoryCd: value.smicCategoryDto.categoryCd, categoryDesc: value.smicCategoryDto.categoryDesc, dispUpc: value.itemDto.dispUpc, cic: value.cic, description: value.description, itemType: value.itemType, size: value.size,sizeUOMForDisplay:value.sizeUOMForDisplay, uom: value.uom, casePk: value.casePkForDisplay, dispState: value.dispState, stateEffectiveDateForDisplayResult: value.stateEffectiveDateForDisplayResult, dispBlockedStatus: value.dispBlockedStatus, displayBlockedTargetDate: value.blockedTargetDate !== null ? DateUtility.getFormattedDate(value.blockedTargetDate) : "", stateEffectiveDate: value.stateEffectiveDate,size:value.size, userId: userId, historyInfo: value.historyInfo, blockedTargetDate: value.blockedTargetDate, uniqueSelectionCode: value.uniqueSelectionCode })
                  })

                  AppData.setMeup54StoreItemsForReport(meup55Array);
                  history.push(RouteBase.MEUP55);

                } 

                
                else {
                  setErrors(["No result found"])
                }
              }
              else{
                setErrors([data.FAILED[0].message]);
                AppData.setLoader(-1)
              }

            }
          }
        }

      }).catch((error) => {
        // AppData.addLoader(-55)
        AppData.setMeup54StoreItemsForReport([]);
        setErrors(["An Exception occurred while retrieving the data."]);
        window.scrollTo(0, 0);
        console.log(error)
      });
    }
  };

  return (
    <form onSubmit={handleSubmit}>
    <Grid container>

      <Grid item xs={12}>
        <ErrorListMeup errors={errors} />
      </Grid>
      <Grid item xs={12}>
        <div
          style={{
            color: "rgb(0, 0, 128)",
            // marginTop: "3px",
            fontSize: "medium",
          }}
        >
          <strong>
            {" "}
            Specify the search criteria. In addition to country, at least one
            other parameter should be specified.{" "}
          </strong>
        </div>
      </Grid>

      <Grid
        container
        style={{ border: "1px solid", width: "80rem" }}
        className="blockItemsMarginTop"
      >
        {/* <Button>Save</Button> */}
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label={
              <>
                {" "}
                Country <font color="red">*</font>{" "}
              </>
            }
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={["US"]}
            DropDownClass="blockItemsDropDown"
            value={country}
            error={errCountry}
            disableNone
            setValue={(value) => setCountry(value)}
            setError={(error) => setErrorCountry(error)}
            errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Division"
            LabelClass="labelClassStoreItems"
            options={AppData.meup53Divisions}
            value={selectedDivisions}
            setValue={onChangeDivision}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Group"
            LabelClass="labelClassStoreItems"
            options={AppData.meup53Groups}
            value={selectedGroups}
            setValue={onChangeGroup}
            alignItems="row"
            disabled={cicUpcStoreValue.cic.length > 0 && cicUpcStoreValue.upc.length > 0}
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Category"
            LabelClass="labelClassStoreItems"
            options={AppData.meup53CategoryList}
            value={selectedCategories}
            setValue={onChangeCategory}
            alignItems="row"
            disabled={cicUpcStoreValue.cic.length > 0 && cicUpcStoreValue.upc.length > 0}
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="CIC"
            value={cicUpcStoreValue.cic}
            LabelClass="labelClassStoreItems"
            setTextValue={onChangeCIC}
            alignItems="row"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            disabled={selectedCategories.length > 0}
            errorText=""
            limit={8}
            error={errorCic}
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="UPC"
            value={cicUpcStoreValue.upc}
            LabelClass="labelClassStoreItems"
            setTextValue={onChangeUPC}
            alignItems="row"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            disabled={selectedCategories.length > 0}
            error={errorUpc}
            errorText=""
            limit={12}
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="Store #"
            value={cicUpcStoreValue.store}
            setTextValue={(value) => setCicUpcStoreValue(preState => ({ ...preState, store: value }))}
            alignItems="row"
            LabelClass="labelClassStoreItems"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            error={errorStore}
            errorText=""
            limit={4}
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label={"State"}
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={[{label:"Allocated", value:"A"}, {label:"Unallocated", value:"U"}]}
            DropDownClass="blockItemsDropDown"
            value={cicUpcStoreValue.state}
            // error={errCountry}
            setValue={(value) => setCicUpcStoreValue(preState => ({ ...preState, state: value }))}
          // setError={(error) => setErrorCountry(error)}
          // errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label="Status"
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={[{label:"Blocked", value:"B"}, {label:"Unblocked", value:"U"}]}
            DropDownClass="blockItemsDropDown"
            value={cicUpcStoreValue.status}
            // error={errCountry}
            setValue={(value) => setCicUpcStoreValue(preState => ({ ...preState, status: value }))}
          // setError={(error) => setErrorCountry(error)}
          // errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv"></Grid>
      </Grid>

      <Grid
        item
        xs={12}
        className="blockItemsMarginTop"
        style={{ marginBottom: "1rem" }}
      >
        <ButtonMemi
          btnval="View Report"
          btnvariant="contained"
          classNameMemi="blockItemsButtons"
          type="submit"
          onClick={handleSubmit}
        />

        <ButtonMemi
          btnval="Reset"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            window.location.reload();
          }}
        />

        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            history.push(RouteBase.MEUP50);
          }}
        />
      </Grid>
    </Grid>
  </form>
  );
}

export default SearchStoreItems;
