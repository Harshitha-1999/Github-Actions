import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { Button } from "@material-ui/core";
import { makeStyles} from "@material-ui/core/styles";
import routes from "../../routes/routes";
import { useLocation } from "react-router";
import ButtonLogout from "components/ButtonLogout/ButtonLogout";
import {MEMIMenu} from 'components/MenuData/MenuData';
import DropdownMenuMemiu from 'components/DropdownMenuMemiu/DropdownMenuMemiu';
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ApplicationContext from "../../context/ApplicationContext";
import {apiUrl} from "../../service/apiUrls"
import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
export default function NavigationBarMemi() {

  const AppData = useContext(ApplicationContext);

  
  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();
  
  const [divisions, setDivisions] = useState([]);
  const [companies, setCompanies] = useState([]);

  const {companyId, setDivisionId} = AppData

  

  function changeRoute(path) {
    history.push(path);
  };

 
  
  useEffect(() => {
    ApiMemi(apiUrl.company, "GET").then((res) => {
      const companiesData = res.data.map((data) => {
        return {label:data.companyLglNm, value:data.companyID}
      })
      setCompanies(companiesData);
    })
    .catch((error) => {
      setCompanies([]);
    })
  },[])

  useEffect(() => {
    
    setDivisionId("");
    if(companyId === "") {
      setDivisions([]) 
      return
    }
    else {
      
      ApiMemi(apiUrl.divisions+companyId, "GET").then((res) => {
        
        const divisionData = res.data.map((data) => {
          return {value: data.divisionID, label:data.divisionNm}
        })
        setDivisions(divisionData);
      })
      .catch((error) => {
        setDivisions([]);
      })
    }
  }, [companyId,setDivisionId])
  const getRouteButtonJsx = (props) => {
    // only show navigationBar=true
    var resultsRoutes = routes.filter((item) => item.navigationBar === "yes")
    return (resultsRoutes.map((detail) => {
      var buttonlabel=detail.label ? detail.label : detail.path.replace('/','')
      return <Button onClick={() => changeRoute(detail.path)} className={location.pathname === detail.path ? classes.menuBtnActive : classes.menuBtn}>
        {buttonlabel}
      </Button>
    }))
  }

  return (
    <div
      className={classes.navigationBar}
    >
      {getRouteButtonJsx()}
      <DropdownMenuMemiu label="Navigation Menu" menuData={MEMIMenu} buttonClass={classes.menuBtn}/>

      <div style={{display:"flex", flexDirection:"row", alignItems:"center"}}>
          <DropDownMemi
            alignItems="inline"
            label="-Enter Company-"
            options={companies}
            value={AppData.companyId}
            setValue={(value) => AppData.setCompanyId(value)}
            DropDownClass="dropdownNavigationMemi"
          />
          <DropDownMemi
            alignItems="inline"
            label="-Enter Division-"
            options={divisions}
            value={AppData.divisionId}
            setValue={(value) => AppData.setDivisionId(value)}
            DropDownClass="dropdownNavigationMemi"
          />
      </div>
      
      <ButtonLogout classNameMemi={classes.menuBtn}/>
    </div>
  );
}

const useStyles = makeStyles((theme) => ({
  menuBtn: {
    color: "#fff !important",
    backgroundColor: "#3196d3",
    // boxShadow: "-3px 3px, -2px 2px, -1px 1px",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    // border: "1px solid #4caf50",
    "&:hover": {
      backgroundColor: "#63b4e4",
      color: "#d6ebfb",
    },
    padding: "14px 16px",
    cursor: "pointer",
    textTransform: "none !important"
    // width: "fit-content"
  },
  navigationBar: {
    backgroundColor: "#3196d3",
    width:"max-content",
    display:"flex",
    marginBottom: "10px"
  },
  menuBtnActive: {
    color: "#2e7fb1",
    background: "#d6ebfb",
    height:"4rem",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    "&:hover": {
      background: "#d6ebfb",
    },
    padding: "14px 16px",
    cursor: "pointer",
    textTransform: "none"
    // width: "fit-content"
   
  },
  linkItem: {
    textDecoration: "none",
  },
  formcontrol: {
    display: "flex",
    flexDirection: "row"
  },
}));
