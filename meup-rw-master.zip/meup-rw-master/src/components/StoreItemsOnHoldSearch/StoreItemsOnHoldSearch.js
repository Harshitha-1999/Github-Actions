import React, { useState, useContext } from 'react'
import { Grid } from '@material-ui/core';

import ApplicationContext from "../../context/ApplicationContext";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { useHistory } from 'react-router';
import { RouteBase } from "routes/constants";
import ListSelectMeup from "components/ListSelectMeup/ListSelectMeup";
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';
import { usePersistState } from 'hooks/usePersistState';
import { meupServices } from 'api/meup/meupServices';
function StoreItemsOnHoldSearch(props) {
    const history = useHistory();
    const AppData = useContext(ApplicationContext);
    const [selectedDivisions, setSelectedDivisions] = usePersistState([], "meup58Divisions");
    const [selectedStockingSections, setSelectedStockingSections] = usePersistState([], "meup58StockingSections");
    const [errors, setErrors] = useState([props.errors]);
    

    
    const handleReview = (e) => {
        e.preventDefault()
        if (selectedDivisions=="" && selectedStockingSections=="") {
            alert("Please Select any one");
           
          }
          else{
        meupServices.getStoreCountsStoreItemsOnHold(selectedDivisions, selectedStockingSections)
            .then((res) => {
                const { data } = res;

                if (data.status === "SUCCESS") {
                    const {REST_RETURNED_DATA} = data.data;
                    let holdData = REST_RETURNED_DATA.map((data,index) => {
                        return { ...data,id:index, accept: false, reject: false, hold: data.status === "H" }
                    });

                    if (holdData.length === 0) {
                        setErrors(["No Items on Hold"])
                    }
                    else {
                        AppData.setMeup62(holdData);
                        history.push(RouteBase.MEUP62)
                    }

                }

            })
            .catch((error) => {
                AppData.setMeup62([]);
                setErrors(["An Exception occurred while retrieving the data"])
            })
        }
    }

    return (
        <form onSubmit={handleReview}>
        <Grid container>
            <Grid item xs={12}>

                <div className="">
                    <ErrorListMeup errors={errors} />
                </div>
                <div
                    style={{ border: "1px solid", width: "55rem" }}

                >
                    <div className="storeItemsHistoryInnerDiv">
                        <ListSelectMeup
                            label={<> Stocking <br /> Section </>}
                            LabelClass="labelClassStoreItems"
                            options={AppData.meup58.stockingSectionList}
                            value={selectedStockingSections}
                            setValue={(value) => setSelectedStockingSections(value)}
                            alignItems="row"
                            classNameMeup="listStoreItemsOnHold"
                            selectAll
                        />
                    </div>
                    <div className="storeItemsHistoryInnerDiv">
                        <ListSelectMeup
                            label="Division"
                            LabelClass="labelClassStoreItems"
                            options={AppData.meup58.divisionList}
                            value={selectedDivisions}
                            setValue={(value) => setSelectedDivisions(value)}
                            alignItems="row"
                            classNameMeup="listStoreItemsOnHold"
                            selectAll
                        />
                    </div>
                </div>
            </Grid>
            <Grid
                item
                xs={12}
                className="blockItemsMarginTop"
                style={{ marginBottom: "1rem" }}
            >


                <ButtonMemi
                    btnval="Review"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    onClick={handleReview}
                    type="submit"
                    btnsize="small"
                />

                <ButtonMemi
                    btnval="Cancel"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => {
                        history.push(RouteBase.MEUP50);
                    }}
                    btnsize="small"
                />
            </Grid>
        </Grid>
    </form>
    )
}

export default StoreItemsOnHoldSearch;
