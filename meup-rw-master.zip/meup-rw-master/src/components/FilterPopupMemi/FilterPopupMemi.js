import React, {useState} from 'react';
import {FilterList, Autorenew, Done, Close} from '@material-ui/icons';
import { Grid } from '@material-ui/core';

import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import ModalPopup from 'components/ModalPopup/ModalPopup';
import TextFieldMemi from 'components/TextField/TextFieldMemi';
import DropDownMemi from 'components/DropDownMemi/DropDownMemi';

function FilterPopupMemi(props) {

    //variables to display modal and to show if filter is active
    const [active, setActive] = useState(false);
    const [open, setOpen] = useState(false);

    //state variables
    const [department, setDepartment] = useState("");
    const [productSku, setProductSku] = useState("");
    const [itemDescription, setItemDescription] = useState("");
    const [supplierNum, setSupplierNum] = useState("");
    const [supplierName, setSupplierName] = useState("");
    const [slu, setSlu] = useState("");
    const [level1, setLevel1] = useState("");
    const [level2, setLevel2] = useState("");
    const [level3, setLevel3] = useState("");
    const [plu, setPlu] = useState("");
    const [upc, setUpc] = useState("");
    const [category, setCategory] = useState("");
    const [shipment ,setShipment] = useState("");
    const [usageInd, setUsageInd] = useState("");
    const [totalSales, setTotalSales] = useState("");
    const [sales, setSales] = useState("");
    const [corpItemCode, setCorpItemCode] = useState("");
    const [vendorCode, setVendorCode] = useState("");
    const [vendorName, setVendorName] = useState("");
    const [usageType, setUsageType] = useState("");
    const [packInd, setPackInd] = useState("");
    const [country, setCountry] = useState("");
    const [numSys, setNumSys] = useState("");
    const [manuf, setManuf] = useState("");
    const [upcItem, setUpcItem] = useState("");
    const [group, setGroup] = useState("");
    const [class1, setClass1] = useState("");
    const [subClass1, setSubClass1] = useState("");
    const [subSubClass1, setSubSubClass1] = useState("");
    const handleSubmit = () => {
        
        setActive(true);
        setOpen(false)
    }

    const handleReset = () => {

        //Resets all the variables to initial state
        setActive(false);
        setDepartment("");
        setProductSku("");
        setItemDescription("");
        setSupplierNum("");
        setSupplierName("");
        setSlu("");
        setLevel1("");
        setLevel2("");
        setLevel3("");
        setPlu("");
        setUpc("");
        setCategory("");
        setShipment("");
        setUsageInd("");
        setTotalSales("");
        setSales("");
        setCorpItemCode("");
        setVendorCode("");
        setVendorName("");
        setUsageType("");
        setPackInd("");
        setCountry("");
        setNumSys("");
        setManuf("");
        setUpcItem("");
        setGroup("");
        setClass1("");
        setSubClass1("");
        setSubSubClass1("");
    }

    const handleClose = () => {
        if(!active) {
            handleReset();
        }
        setOpen(false);
    }

    const FilterFormSupplier = (
        
            <Grid container>
                <Grid item xs={4}>
                    <DropDownMemi
                        alignItems="column"
                        label="Department"
                        options={[{value:"string:Seafood", label:"Seafood"}, {value:"string:Bakery", label:"Bakery"}]}
                        value={department}
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                        setValue={(value) => setDepartment(value)}
                    />
                </Grid>
                <Grid item xs={4}>
                    <TextFieldMemi
                        label="Product Sku"
                        alignItems="column"
                        placeholderMemi="Product Sku"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={productSku}
                        setTextValue={(value) => setProductSku(value)}
                    />
                </Grid>
                <Grid item xs={4}>
                    <TextFieldMemi
                        label="Item Description"
                        alignItems="column"
                        placeholderMemi="Item Description"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={itemDescription}
                        setTextValue={(value) => setItemDescription(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Supplier Num"
                        alignItems="column"
                        placeholderMemi="Supplier Num"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={supplierNum}
                        setTextValue={(value) => setSupplierNum(value)}

                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Supplier Name"
                        alignItems="column"
                        placeholderMemi="Supplier Name"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={supplierName}
                        setTextValue={(value) => setSupplierName(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Slu"
                        alignItems="column"
                        placeholderMemi="Slu"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={slu}
                        setTextValue={(value) => setSlu(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Hierachy"
                        alignItems="column"
                        placeholderMemi="Level 1"
                        type="number"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={level1}
                        setTextValue={(value) => setLevel1(value)}

                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Level 2"
                        type="number"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={level2}
                        setTextValue={(value) => setLevel2(value)}

                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Level 3"
                        type="number"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={level3}
                        setTextValue={(value) => setLevel3(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                <TextFieldMemi
                        label="PLU"
                        alignItems="column"
                        placeholderMemi="PLU"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={plu}
                        setTextValue={(value) => setPlu(value)}

                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                <TextFieldMemi
                        label="UPC"
                        alignItems="column"
                        placeholderMemi="UPC"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={upc}
                        setTextValue={(value) => setUpc(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                   <DropDownMemi
                        alignItems="column"
                        label="Shipment"
                        options={[{value:"Y", label:"Yes"}, {value:"N", label:"No"}]}
                       
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                        value={shipment}
                        setValue={(value) => setShipment(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <DropDownMemi
                        alignItems="column"
                        label="Usage Ind"
                        options={[{value:"R", label:"Resale"}, {value:"M", label:"Material"}, {value:"E", label:"Expense"}]}
                        
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                        value={usageInd}
                        setValue={(value) => setUsageInd(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <DropDownMemi
                        alignItems="column"
                        label="Total Sales"
                        options={[{value:"GREATER_THAN", label:"> Greater than"}, {value:"LESS_THAN", label:"< Lesser than"}, {value: "EQUALS", label:"= Equals to"}]}
                        value={totalSales}
                        setValue={(value) => setTotalSales(value)}
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                    
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Sales"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={sales}
                        setTextValue={(value) => setSales(value)}

                    />
                </Grid>
            </Grid>
        )
    
    
    const FilterFormVendor = 
        (
            <Grid container>
               <Grid item xs={4}>
                    <DropDownMemi
                        alignItems="column"
                        label="Department"
                        options={[{value:"string:Seafood", label:"Seafood"}, {value:"string:Bakery", label:"Bakery"}]}
                        value={department}
                        setValue={(value) => setDepartment(value)}
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                    />
                </Grid>
                <Grid item xs={4}>
                    <TextFieldMemi
                        label="Corp Item Code"
                        alignItems="column"
                        placeholderMemi="Corp Item Code"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={corpItemCode}
                        setTextValue={(value) => setCorpItemCode(value)}
                    />
                </Grid>
                <Grid item xs={4}>
                    <TextFieldMemi
                        label="PLU"
                        alignItems="column"
                        placeholderMemi="PLU"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={plu}
                        setTextValue={(value)=> setPlu(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="UPC"
                        alignItems="column"
                        placeholderMemi="UPC"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={upc}
                        setTextValue={(value) => setUpc(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Item Description"
                        alignItems="column"
                        placeholderMemi="Item Description"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={itemDescription}
                        setTextValue={(value) => setItemDescription(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <DropDownMemi
                        alignItems="column"
                        label="Usage Ind"
                        options={[{value:"R", label:"Resale"}, {value:"M", label:"Material"}, {value:"E", label:"Expense"}]}
                        
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                        value={usageInd}
                        setValue={(value) => setUsageInd(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Vendor Code"
                        alignItems="column"
                        placeholderMemi="Vendor Code"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={vendorCode}
                        setTextValue={(value) => setVendorCode(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <TextFieldMemi
                        label="Vendor Name"
                        alignItems="column"
                        placeholderMemi="Vendor Name"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        value={vendorName}
                        setTextValue={(value) => setVendorName(value)}
                    />
                </Grid>
                <Grid item xs={4} style={{marginTop:"1rem"}}>
                    <DropDownMemi
                        alignItems="column"
                        label="Usage Type"
                        options={[{value:"W", label:"W"}, {value:"R", label:"R"}, {value:"P", label:"P"}, {value:"M", label:"M"}, {value:"C", label:"C"}, {value:"O", label:"O"}, {value:"S", label:"S"}]}
                        value={usageType}
                        setValue={(value) => setUsageType(value)}
                        LabelClass="labelClassFilterPopup"
                        classNameMemi="dropdownClassFilterPopup"
                    />
                </Grid>
                <Grid item xs={12} style={{marginTop:"1rem", display:"flex"}}>
                <TextFieldMemi
                        label="Vendor Order Code"
                        alignItems="column"
                        placeholderMemi="PackInd"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={packInd}
                        setTextValue={(value) => setPackInd(value)}
                    />
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Country"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={country}
                        setTextValue={(value) => setCountry(value)}
                    />
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="NumSys"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={numSys}
                        setTextValue={(value) => setNumSys(value)}
                    />
                     <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Manuf"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={manuf}
                        setTextValue={(value) => setManuf(manuf)}
                    />
                     <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="UPCItem"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={upcItem}
                        setTextValue={(value) => setUpcItem(value)}
                    />
                </Grid>
                <Grid item xs={12} style={{marginTop:"1rem", display:"flex"}}>
                <TextFieldMemi
                        label="SMIC"
                        alignItems="column"
                        placeholderMemi="Group"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={group}
                        setTextValue={(value) => setGroup(value)}
                    />
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Category"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={category}
                        setTextValue={(value) => setCategory(value)}
                    />
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="Class"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={class1}
                        setTextValue={(value) => setClass1(value)}
                    />
                    <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="SubClass"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={subClass1}
                        setTextValue={(value) => setSubClass1(value)}
                    />
                    
                     <TextFieldMemi
                        label="."
                        alignItems="column"
                        placeholderMemi="SubSubClass"
                        LabelClass="labelClassFilterPopup"
                        TextFieldClass="textFieldClassFilterPopup"
                        fullWidth={false}
                        type="number"
                        value={subSubClass1}
                        setTextValue={(value) => setSubSubClass1(value)}
                    />
                </Grid>
                
            </Grid>
        )
    

  
    return (
        <>
            <ButtonMemi
                btnval="Filter By"
                classNameMemi={props.buttonClassFilter}
                endIcon={<FilterList style={{color:active ? "red" : "black"}}/>}
                onClick={() => setOpen(true)}
            />
            <ModalPopup
                open={open}
                popupTitleClass="bakeryPopupTitle"
                setClose={() => setOpen(false)}
                classNameMemi={props.modalClass}
                popupTitle={
                    <ButtonMemi
                        btnval="Clear All"
                        classNameMemi="buttonClassFilter"
                        endIcon={<Autorenew/>}
                        onClick={handleReset}
                    />
                }

                popupContent={
                    props.type === "supplier" ? FilterFormSupplier : FilterFormVendor
                }
                popupActions={
                
                    <>
                        <ButtonMemi
                            btnval="Apply"
                            classNameMemi="submitButtonFilter"
                            onClick={handleSubmit}
                            startIcon={<Done/>}
                            btnvariant={"contained"}
                        />
                        <ButtonMemi
                            btnval="Close"
                            classNameMemi="closeButtonFilter"
                            onClick={handleClose}
                            startIcon={<Close/>}
                            btnvariant={"contained"}
                        />
                    </>
                }
                maxWidth="sm"
                fullScreen={true}
                fullWidth={true}
            />
        </>
    )
}

export default FilterPopupMemi;