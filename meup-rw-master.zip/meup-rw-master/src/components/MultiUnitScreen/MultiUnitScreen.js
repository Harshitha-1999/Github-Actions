
import React from "react";
import TableMemi from '../TableMemi/TableMemi'
import { Grid } from "@material-ui/core";
import "../../css/App.css";

function MultiUnitScreen(props) {
    // const [itemsets, setItemSets] = useState(' ');
    // const [errItemSets, setErrorItemSets] = useState(false);

   
    return (
        <div>
           
           <Grid
        container
        spacing={2}
        direction="row"
        className="MainContent"
        alignItems="flex-start"
      >            
{/* <SplitButtonMemi/> */}
<Grid item md={12} >
    <div className="source">{props.heading1}</div>

            {props.buttonRow1}
            <TableMemi
              data={props.memi21data}
              classnameMemi="table27"
              rowheight={40}
              selectionType="checkbox"
            />
           </Grid>
            <Grid item md={12} >
    <div className="source">{props.heading2}</div>

              {props.buttonRow2}
             <TableMemi
              data={props.memi22data}
              classnameMemi="table27"
              rowheight={40}
              selectionType="checkbox"
            />
            </Grid>
            </Grid>
         </div>
    );
}

export default MultiUnitScreen;
