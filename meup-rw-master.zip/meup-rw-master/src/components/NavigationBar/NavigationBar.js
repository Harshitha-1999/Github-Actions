import NavigationBarCommon from "components/NavigationBarCommon/NavigationBarCommon";
import NavigationBarMemi from "components/NavigationBarMemi/NavigationBarMemi";
import NavigationBarMeup from "components/NavigationBarMeup/NavigationBarMeup";
import React from "react";
import { Environment } from "utils";

export default function NavigationBar() {

  const computeNavigationBar = () => {
    if(Environment.getReactAppCode() === "MEMI") {
      return <NavigationBarMemi/>  
    } 
    else if(Environment.getReactAppCode() === "MEUP") {
      return <NavigationBarMeup/>
    }
    else if(Environment.getReactAppCode() === "TATA") {
      return <NavigationBarCommon/>
    }
  }

  return (
    <>
     {computeNavigationBar()}
    </>
    
  );
}

 