import React from "react";
import {  Environment } from "utils";
import { makeStyles } from "@material-ui/core/styles";
import { Button } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  logoutBtn: {
    color: "#fff",
    backgroundColor: "green",
    boxShadow: "-3px 3px #4caf50, -2px 2px #4caf50, -1px 1px #4caf50",
    border: "1px solid #4caf50",
    "&:hover": {
      background: "#d32f2f",
    },
    padding: "10px 35px 10px 35px",
    cursor: "pointer",
  },
}));
/** end styles */

export const ButtonLogout = (props) => {
  const classes = useStyles();

  const logout = () => {
    let cookies = document.cookie ? document.cookie.split(";") : null;
    let cookie = cookies.filter((cookie) => cookie.includes("ent-abs-auth"));
    let cookieTwo = cookies.filter((cookie) => cookie.includes("ent-abs-itkn"));
    sessionStorage.clear();
    document.cookie = cookie + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
    document.cookie = cookieTwo + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
    window.location.replace(`${Environment.getLogoutUrl()}`);
  };

  return (
    <Button onClick={logout} className={props.classNameMemi ? props.classNameMemi : classes.logoutBtn} variant="contained">
      Logout
    </Button>
  );
};

export default ButtonLogout;
