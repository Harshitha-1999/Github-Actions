
import React from 'react';
import {
  OutlinedInput,
  Select,
  MenuItem,
  FormControl,
} from '@material-ui/core';
import "../../css/App.css";
 
//import SearchIcon from '@material-ui/icons/Search';
 
function SearchFieldMemi(props) {
  const {
    classNameMemi,
    options,
    selectedValue,
    handleSelectChange,
    searchValue,
    onChangeSearchValue,
  } = props;
 
  return (
      
    <FormControl className={classNameMemi}>
      <OutlinedInput
        id="outlined-basic"
        fullWidth
        placeholder="Searching"
        variant="outlined"
        value={searchValue}
        onChange={(e) => onChangeSearchValue(e.target.value)}
        
        startAdornment={
          <Select
            id="demo-customized-select-native"
            value={selectedValue}
            onChange={(e) => handleSelectChange(e.target.value)}
            variant="outlined"
          >
            <MenuItem aria-label="None" value=" ">
              <em> All Categories</em>
            </MenuItem>
 
            {options.map((optionValue, index) => {
              return (
                <MenuItem key={index} value={optionValue}>
                  {optionValue}
                </MenuItem>
              );
            })}
          </Select>
        }
      ></OutlinedInput>
    </FormControl>
    
  );
}
 
export default SearchFieldMemi