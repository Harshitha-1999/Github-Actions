import React, { useContext, useEffect, useState } from 'react';
import ApplicationContext from "../../context/ApplicationContext";

function LoaderMeup(props) {
    const AppData = useContext(ApplicationContext);
    const { loader } = AppData;

    const [text, setText] = useState("Ok");
    const [textClass, setTextClass] = useState("meuploader");

    useEffect(() => {
        if (loader < 0) {
            setText("Error");
            setTextClass("meuploadererror");

        }
        else if (loader > 0) {
            setText("Loading");
            setTextClass("meuploaderloading");

        }
        else {
            setText("Ok");
            setTextClass("meuploader");

        }
    }, [loader])
    return (
        <div container className={`${textClass} loadingClass`}>
                {text}
                <span style={{marginLeft:"auto"}}> &#9673; </span>
        </div>
    );
}

export default LoaderMeup;