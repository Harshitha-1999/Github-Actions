import React from "react";
import { withStyles } from "@material-ui/core/styles";

import NativeSelect from "@material-ui/core/NativeSelect";
import InputBase from "@material-ui/core/InputBase";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import { Grid } from "@material-ui/core";


function DropDownMemi(props) {
  const {
    label,
    options,
    value,
    setValue,
    error,
    setError,
    classNameMemi,
    
    alignItems,
    LabelClass,
  } = props;
  const BootstrapInput = withStyles((theme) => ({
    root: {
      "label + &": {
        marginTop: theme.spacing(0),
      },
    },

    input: {
      height: "1.6rem",

      borderRadius: 4,
      position: "relative",
      backgroundColor: theme.palette.background.paper,
      border: error ? "1px solid red" : "1px solid #ced4da",
      fontSize: 16,
      paddingLeft: "0.5rem",
      transition: theme.transitions.create(["border-color", "box-shadow"]),
      // Use the system font instead of the default Roboto font.
      fontFamily: [
        "-apple-system",
        "BlinkMacSystemFont",
        '"Segoe UI"',
        "Roboto",
        '"Helvetica Neue"',
        "Arial",
        "sans-serif",
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(","),
      "&:focus": {
        borderRadius: 4,
        borderColor: "#80bdff",
        boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
        backgroundColor: theme.palette.background.paper,
      },
    },
  }))(InputBase);

  const handleChange = (event) => {
    setValue(event.target.value);
    if (setError) {
      if (event.target.value === " ") {
        setError(true);
      } else {
        setError(false);
      }

    }

  };

  const errorText = props.errorText !== undefined ? props.errorText : `${label} is required`
  return (
    <Grid container>
      <Grid item xs={alignItems === "row" ? 4 : 12} style={{ display: props.alignItems === "inline" ? "none" : "grid" }}>
        <div className={LabelClass} style={{display:"flex", alignItems:"center"}}>
          {props.labelInline ? "" : props.label}
        </div>
      </Grid>
      <Grid item xs={alignItems === 'row' ? 8 : 12}>
        <FormControl error={error} className={classNameMemi} >
          <NativeSelect
            className={`${props.DropDownClass} ${props.disabled ? 'disabledclassnamebtn' : ""}`}
            label={props.label}
            disabled={props.disabled}
            id="demo-customized-select-native"
            value={value}
            onChange={handleChange}
            input={<BootstrapInput />}
          >
            {
              props.disableNone ? "" :   
              <option aria-label="None" value="" disabled={props.disableNone}>
              {props.alignItems === "inline" ? label : 'Select'}
            </option>
            }
            
            {options.map((optionValue, index) => {
              if (typeof (optionValue) === "object") {
                return (
                  <option key={index} value={optionValue.value}>
                    {optionValue.label}
                  </option>
                )
              }
              return (
                <option key={index} value={optionValue}>
                  {optionValue}
                </option>

              )
            }
            )};
          </NativeSelect>
          <FormHelperText>{error ? errorText : ""}</FormHelperText>
        </FormControl>
      </Grid>
    </Grid>
  );
}
export default DropDownMemi;
