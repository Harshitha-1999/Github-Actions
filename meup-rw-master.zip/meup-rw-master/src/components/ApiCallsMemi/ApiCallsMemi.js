


// import { getNoCacheHeadersSecurity } from 'utils/getNoCacheHeadersSecurity'


import { getNoCacheHeaders } from "api/util";
import axios from "axios";

export function ApiMemi(url,methodtype,body, isBlob) {
  
  
var head={
    method: methodtype,
    url: url,
    // url:"http://localhost:3500/MEMI20"
    // headers:getNoCacheHeaders(),
    // headers:flag? getNoCacheHeadersSecurity() : getNoCacheHeaders(), 
    "Content-Type":"application/json",
    //timeout: 40000,
    headers:getNoCacheHeaders(),
    responseType: isBlob ? "blob" : "json"
}

if(methodtype==="GET") {
  return axios({
    ...head
    })
} else if(methodtype==="POST") {
  return axios({
    ...head,
    data:body,
    options:{}
  })
}

}