import React from 'react'
import { Grid } from '@material-ui/core';
import { makeStyles } from "@material-ui/core/styles";
import { authTokenCookie } from 'utils';
const useStyles = makeStyles((theme) => ({
    container: {
        paddingRight: "15px",
        paddingLeft: "15px",
        marginRight: "auto",
        marginLeft: "auto",
        marginTop: "4%",
        justifyContent:"center",
        width:"100%"
    
    },
    groupDiv: {
        paddingLeft: "60px",
        paddingRight: "60px",
        paddingTop:"40px",
        backgroundColor: "#eee",
       fontFamily:"Verdana, Arial, sans-serif",
        fontSize:"23px"
        
    },
    contactList: {
        paddingLeft: "60px",
        paddingRight: "60px",
        paddingTop:"40px",
        textAlign:"center",
       fontFamily:"Verdana, Arial, sans-serif",
        fontSize:"18px"
        
    }
}));

function NoGroupAccessMeup() {
    const classes = useStyles();
    const userId = authTokenCookie().userId ? authTokenCookie().userId : ""; 
    return (
        <Grid container className={classes.container}>
            <Grid item xs={!2} className={classes.groupDiv}>
                <strong> Login Error: Sorry, you are not authorized to access the requested screens </strong>
                <br/>
                <br/>
                The signed in user ({userId}) is not assigned to any of these roles.
                <br/>
                <ul>
                    <li>id.meup.all</li>
                    <li>id.meup.schematicmgr</li>
                    <li>id.meup.admin</li>
                </ul>
            </Grid>
            <Grid item xs={12} className={classes.contactList}>
            For technical help, please contact the Albertsons Companies Technology Support Center at 1-877-286-3200
            </Grid>
        </Grid>
    )
}

export default NoGroupAccessMeup;
