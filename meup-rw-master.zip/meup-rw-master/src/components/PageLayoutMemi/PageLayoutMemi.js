import React from "react";
import "../../css/App.css";
import { Grid} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";

import { Environment } from '../../utils';


const useStyles = makeStyles((theme) => ({
  logout: {
    display: "flex",
    justifyContent: "flex-end",
  },
}));

export default function PageLayoutMemi(props) {
  const classes = useStyles();
  // console.log("Environment.getAppName()");
  // console.log(Environment.getAppName());
  return (
    <Grid container style={{ marginTop: "1px" }}>
      <Grid item sm={11}>
        {props.navigationBar}
      </Grid>
      <Grid item sm={1} style={{ marginTop: "15px", fontSize: "22px" }}>
            {Environment.getAppName()}
          </Grid>
      <Grid container className="pageLayoutContentGrid">
        <Grid item xs={12} className="contentOutline">
          
          <Grid item sm={12} >
            <div className='pageLayoutTitle'>{props.pageTitle}</div>
          </Grid>
          <Grid item sm={12} className={classes.fixedBottom}>
            {props.mainContent}
          </Grid>
        </Grid>
      </Grid>
      <Grid item sm={12} className={classes.fixedBottom}>
        <div className="fixedBottom">{props.footer}</div>
      </Grid>
    </Grid>
  )
};
