import React, {useState} from 'react'
import { Grid } from '@material-ui/core'
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { useHistory } from 'react-router';
import { RouteBase } from "routes/constants";
import CalendarMeup from 'components/CalendarMeup/CalendarMeup';
import TextAreaAutosizeMemi from 'components/TextAreaAutosizeMemi/TextAreaAutosizeMemi';
import TableMemi from "../../components/TableMemi/TableMemi";
import { DateUtility } from "utils";

export default function ModifyDeleteDate(props) {
  const history = useHistory();
  const [deleteDateTo, setDeleteDateTo] = useState(null);
  const [comments, setComments] = useState("");
  let updateTableData = [
    {
      id: 1,
      Apply: "",
      DV: 5,
      Store: 1585,
      Category: "0901-Salty Bagged Canister Snacks kiiiiiiiiiii",
      UPC: "0123456789",
      CIC:"0123456",
      Size:"5.0 OZ",
      Description:"KINDERS ROASTED GARLIC BBQ DIPPING SAUCE"
    },
  ];
  let columnsUnblockTable = [
    
    {
      field: "DV",
      headerName: "DV",
      sortable: false,
     width:70,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Store",
      headerName: "Store",
      sortable: false,
      width:82,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Category",
      headerName: "Category",
      sortable: false,
      width:219,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "UPC",
      headerName: "UPC",
      sortable: false,
      width:82,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "CIC",
      headerName: "CIC",
      sortable: false,
      width:82,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Description",
      headerName: "Description",
      sortable: false,
      width:260,
      headerAlign: "center",
      headerClassName: "headerCss",
    },
    {
      field: "Size",
      headerName: "Size",
      sortable: false,
      // flex: 0.3,
      width:80,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "UOM",
      headerName: "UOM",
      sortable: false,
      // flex: 0.3,
      width:77,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Case Pk",
      headerName: "Case Pk",
      sortable: false,
      // flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "State",
      headerName: "State",
      sortable: false,
      // flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "State Effective Date",
      headerName: "State Effective Date",
      sortable: false,
      // flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss",
      sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}
    },
    {
      field: "Delete Date",
      headerName: "Delete Date",
      sortable: false,
      // flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss",
      sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}
    },
    {
      field: "Last Updated User",
      headerName: "Last Updated User",
      sortable: false,
      // flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
  ];
  return (
    <Grid container>
      <Grid item xs={12}>

        <div style={{ backgroundColor: "#CFC3AD", width: "100%", padding: "0.3rem 0rem 0rem 0.3rem", height: "1.5rem" }}>
          <strong> Update Store Items </strong>
        </div>
      </Grid>
      <Grid item xs={12}>
      <div style={{ color: 'rgb(0, 0, 128)', marginTop: "22px", fontSize: "medium" }}>
        <strong> All greyed cells indicate schematic data. A schematic data cannot be modified by you </strong>
      </div>
      <div style={{display:"flex", flexDirections:"row",marginTop:"2rem"}}>
        <div style={{width:"35rem"}}>
        <CalendarMeup
          label={<> Change delete date to <font color="red">*</font></>}
          alignItems="row"
          value={deleteDateTo}
          setValue={(value) => setDeleteDateTo(value)}
          LabelClass="labelClassBlockedItems" 
        />
        </div>
      
        <ButtonMemi
                      
          btnval="Upload"
          btnvariant="contained"
          classNameMemi="blockItemsButtons"
          onClick={() => {
            alert("clicked");
            }}
        />
        <div style={{width:"35rem", marginLeft:"auto"}}>
        <TextAreaAutosizeMemi
            label={<> Enter Comments <font color="red">*</font></>}
            value={comments}
            setTextValue={(value) => setComments(value)}
            alignItems="row"
            minrow="5"
            maxrp="5"
          />
        </div>
      </div>
      
      </Grid>
      <Grid item xs={12} style={{marginTop:"2rem"}}>
      <TableMemi
          data={updateTableData}
          selectionType="checkbox"
          columns={columnsUnblockTable}
          classnameMemi="tableModifyDeleteDate"
          showCellRightBorder={true}
          showColumnRightBorder={true}
          hideFooter={true}
          hideFooterPagination={true}
          hideFooterSelectedRowCount={true}
          autoHeight
        />
      </Grid>
      <Grid
        item
        xs={12}
        className="blockItemsMarginTop"
        style={{ marginBottom: "3rem" }}
      >
        <ButtonMemi
          btnval="Search Again"
          btnvariant="contained"
          classNameMemi="blockItemsButtons"
          onClick={() => {
            history.goBack();
          }}
        />
        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            history.push(RouteBase.MEUP50);
          }}
        />
      </Grid>
    </Grid>
  )
}
