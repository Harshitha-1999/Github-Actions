import React from 'react';
import {render,screen} from "@testing-library/react";
import ParagraphWidget from './ParagraphWidget';

describe('<ParagraphWidget />', () => {
  const defaultProps = {
    controlId: 'test-id',
    content: 'test message'
  }

  it('Should render without errors', () => {
    const {debug,container} = render(
      <ParagraphWidget {...defaultProps} />
    );
      // console.log(debug())
    expect(container.querySelector('#test-id')).toBeTruthy();
    expect(screen.getByText('test message')).toBeTruthy();
  })
})