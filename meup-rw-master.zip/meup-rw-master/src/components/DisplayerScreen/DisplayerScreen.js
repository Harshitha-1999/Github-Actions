import React, {
  
} from "react";
import TableMemi from "components/TableMemi/TableMemi";
//import Avatar from "@material-ui/core/Avatar";
//import clsx from "clsx";
import { Grid } from "@material-ui/core";
//import Grid from "@mui/material/Grid";
//import Button from "@material-ui/core/Button";
//import DropDownMemi from "../DropDownMemi/DropDownMemi";
//import Paper from "@material-ui/core/Paper";

import {
  makeStyles,
  
} from "@material-ui/core/styles";

import "../../css/App.css";

const useStyles = makeStyles({
  root: {
    "& .super-app-theme--header": {
      backgroundColor: "rgba(255, 7, 0, 0.55)",
    },
  },
  divHeader: {
    backgroundColor: "#fffde7",
    height: "39px",
    display: "flex",
    alignItems: "center",
    padding: "2px",
  },
  elementOne: {
    marginRight: "25%",
  },
  elementTwo: {
    marginRight: "25%",
  },
  elementThree: {},
});

/*
 *  must make 'let customcolumns = null' if not using custom columns
 *  or don't pass customcolumns prop
 *  passing below an array with key/value hide:true allows for hiding a row
 */
//{ field: "image-a", headerName: "", width: "200" },
let customcolumns = [{ field: "id", hide: true }];

function DisplayerTable(props) {
  const classes = useStyles();
  return (
        <Grid item xs={12} sm={12} md={12} xl={12}>
        
            <div className={classes.divHeader}>
              <div className={classes.elementOne}>Departments</div>
              <div className={classes.elementTwo}>
                Displayer - Un-reviewed Items
              </div>
              <div>Displayer - Reviewed Items</div>
            </div>
            <TableMemi
              data={props.AppData.memi23}
              classnameMemi="tableDisplayer"
              rowheight={40}
              rowPerPageOptions={props.AppData.memi23.length - 1}
              selectionType="regular"
              customcolumns={customcolumns}
            />
        
        </Grid>
     
  );
}

export default DisplayerTable;
