import React from 'react';
import { Grid, Button } from "@material-ui/core";
import { Buttons } from '../../routes/routes'
import { useHistory, useLocation } from 'react-router';
import { authTokenCookie } from 'utils';
import { generateUserLevel } from 'components/CommonFunctionsMeup/CommonFunctionsMeup';
import { DateUtility } from 'utils';

function HeaderMeup(props) {
  
  const history = useHistory();
  const location = useLocation();

  function changeRoute(path) {
    history.push(path);
  };

  let { userId } = authTokenCookie();
  const pstDate =  DateUtility.getMountainStdDate().split("-");
  const month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
  const date = `${month[parseInt(pstDate[1]) - 1]} ${pstDate[2]}, ${pstDate[0]}`

  const getRoutes = () => {
    const newButtons = Buttons.filter((Button) => Button.navNames.includes("home") && Button.path !== location.pathname)
    return (newButtons.map((ButtonComp) => {
      return ButtonComp.component ? ButtonComp.component : <> <Button onClick={() => changeRoute(ButtonComp.path)} className="HeaderMeupButton">{ButtonComp.label}</Button> <font size="2" face="Tahoma" color="#FFFFFF">|</font> </>
    }))
  }
  return (
    <Grid item container direction="row" xs={12}  spacing={0}>

      <div className="meupHeadingContainer">

        <Grid className="logomeup">
          <div className="logo">
            <img className="imgLogoCls" src="/logo_abs.gif" alt="" />
          </div>

        </Grid>
        <Grid item className="headingmeup headcotext">

          Unallocated Item Management

      </Grid>
        <Grid item className={`logoutmeup ${location.pathname === "/" ? "logoutShrink" : "logoutExpand"}`}>
          {
            getRoutes()
          }
        </Grid>
      </div>
      <Grid style={{width: "96%"}} >
        <div className="titlemeup">
          <div className="headerTitle">

            {props.title}

          </div>

        </div>

      </Grid>
      <Grid style={{width: "96%"}}>
        <div style={{ display: "flex", flexDirection: "row", fontSize: "small", paddingBottom: "10px" }}>
          <div>

            You are logged in as {userId ? userId.toLowerCase() : ""} ({generateUserLevel().split("-")[1]})

          </div>
          <div style={{ marginLeft: "auto" }}>
            {date}
          </div>

        </div>

      </Grid>
      <br/>
      {
        props.subTitle ? 
        <Grid item xs={12}>

        <div className={`headerSubTitle ${props.fullWidth ? '' : 'headerSubTitleFitContent'}`}>
          {props.subTitle}
        </div>
      </Grid> :  <div className={""} style={{marginTop: "47px"}}>
         
        </div>

      }
      


    </Grid>

  );
}

export default HeaderMeup;