import React, { useContext } from "react";
import { withStyles } from "@material-ui/core/styles";
import { DataGrid } from "@mui/x-data-grid";
import Radio from "@material-ui/core/Radio";
import PropTypes from "prop-types";
import ApplicationContext from "context/ApplicationContext";

function TableMemi(props) {
  const AppData = useContext(ApplicationContext);
  const [selectedId, setSelectedId] = React.useState();
  let rowData = [];
  const changememi = (id) => {
    setSelectedId(id);
  };

  let columns;
  switch (props.classnameMemi) {
    case "tableDisplayer":
      columns = [];
      if (props.data.length > 0) {
        if (props.customcolumns) {
          if (props.customcolumns[0].hide === true) {
            Reflect.ownKeys(props.data[0]).forEach((data) => {
              columns.push({ field: data, headerName: data, width: 150 });
            });

            columns[0].width = "400";
            columns[4].width = "200";
            columns[8].width = "200";
          }
        }
      }
      break;
    case "tableDisplayerCont":
      columns = [];
      if (props.data.length > 0) {
        if (props.data[0].Pack) {
          if (props.customcolumns) {
            if (props.customcolumns[0].hide === true) {
              Reflect.ownKeys(props.data[0]).forEach((data) => {
                columns.push({ field: data, headerName: data, width: 150 });
              });

              columns[0].width = "400";
              columns[4].width = "200";
              columns[8].width = "200";
            }
          }
        } else {
          if (props.customcolumns) {
            if (props.customcolumns[0].hide === true) {
              Reflect.ownKeys(props.data[0]).forEach((data) => {
                columns.push({ field: data, headerName: data, width: 150 });
              });
            }
          }
        }
      }
      break;
    case "another case":
      //code block
      break;
    default:
      if (props.selectionType === "radio") {
        columns = [
          {
            field: " ",
            headerName: " ",
            width: 20,
            hide: props.selectionType === "checkbox" ? true : false,

            renderCell: (params) => (
              <div style={{ display: "flex", alignItems: "center" }}>
                <Radio
                  name="radio-buttons"
                  checked={selectedId === params.row.id}
                  onChange={() => changememi(params.row.id)}
                />
              </div>
            ),
          },
        ];
        if (props.data.length > 0) {
          Reflect.ownKeys(props.data[0]).forEach((data) => {
            columns.push({ field: data, headerName: data, width: 150 });
          });
        }
      } else {
        columns = [];
        if (props.data.length > 0) {
          if (props.customcolumns) {
            if (props.customcolumns[0].hide === true) {
              if (props.classnameMemi === "tableDisplayer") {
                // Reflect.ownKeys(props.data[0]).forEach((data) => {
                //   columns.push({ field: data, headerName: data, width: 150 });
                // });
                // const firstElement = columns.shift();
                // columns[0].width = "400";
              } else {
                Reflect.ownKeys(props.data[0]).forEach((data) => {
                  columns.push({ field: data, headerName: data, width: 150 });
                });

                columns[0].width = "400";
              }
            }
          } else {
            Reflect.ownKeys(props.data[0]).forEach((data) => {
              columns.push({ field: data, headerName: data, width: 150 });
            });
          }
        }
      }
  }

  return (
    <div className={props.classnameMemi} style={{ height: "inherit" }}>
      <StyledDataGrid
        rows={props.data}
        rowHeight={props.rowheight}
        columns={props.columns ? props.columns : columns}
        autoPageSize
        pageSize={props.pageSize}
        onPageSizeChange={props.onPageSizeChange}
        autoHeight={props.autoHeight}
        checkboxSelection={props.selectionType === "checkbox" ? true : false}
        {...props.data}
        selectionModel={props.selectedRows}
        onSelectionModelChange={(newSelectionModel) => {
          props.setSelectionModel(newSelectionModel);
          newSelectionModel.forEach((x) => {
            rowData.push(props.data[x]);
            console.log(rowData);
            AppData.mapSelectedRowData(rowData);
          });
        }}
        components={{
          NoRowsOverlay: props.NoRowsOverlay,
        }}
        disableSelectionOnClick
        hideFooter={props.hideFooter}
        hideFooterPagination={props.hideFooter}
        hideFooterSelectedRowCount={props.hideFooter}
        showCellRightBorder={props.showCellRightBorder}
        showColumnRightBorder={props.showColumnRightBorder}
        isRowSelectable={
          props.selectionCriteria
            ? (params) => props.selectionCriteria(params)
            : (params) => {
                return true;
              }
        }
        disableColumnFilter
        disableColumnMenu
        density={props.density}
      />
    </div>
  );
}

TableMemi.propTypes = {
  hideFooter: PropTypes.bool,
  hideFooterPagination: PropTypes.bool,
  hideFooterSelectedRowCount: PropTypes.bool,
  showCellRightBorder: PropTypes.bool,
  showColumnRightBorder: PropTypes.bool,
  selectionCriteria: PropTypes.func,
  selectionType: PropTypes.string,
  selectedRows: PropTypes.array,
  setSelectionModel: PropTypes.func,
  autoHeight: PropTypes.bool,
  columns: PropTypes.array,
  data: PropTypes.array,
  rowheight: PropTypes.number,
  pageSize:PropTypes.number,
  density:PropTypes.string
};

export default TableMemi;

const StyledDataGrid = withStyles({
  root: {
    "& .MuiDataGrid-renderingZone": {
      maxHeight: "none !important",
    },
    "& .MuiDataGrid-cell": {
      lineHeight: "unset !important",
      maxHeight: "none !important",
      whiteSpace: "normal",
      wordWrap: "break-word",
      alignItems: "center",
    },

    "& .MuiDataGrid-row": {
      "&:hover": {
        backgroundColor: "inherit",
      },
    },
  },
  virtualScrollerContent: {
    height: "100% !important",
    overflow: "scroll",
  },
})(DataGrid);
