import React, {useState} from 'react';


import TextFieldMemi from 'components/TextField/TextFieldMemi';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';

import ModalPopup from 'components/ModalPopup/ModalPopup';
function GeneralModalPopup(props) {
    const [value, setValue] = useState(null);

    const handleClose = () => {
        setValue(null);
        props.setClose();
    }

    const handleSubmit = () => {
        if(props.onSubmit) {
            props.onSubmit(value);
        }
        
        handleClose();
    }



    return (
        <ModalPopup
            {...props}
            popupContent={
                <TextFieldMemi
                    
                value={value}
                setTextValue={(value) => setValue(value)}
                {
                    ...props.InputProps
                }
                
            />
            }
            popupActions={
                
                <>
                    <ButtonMemi
                        btnval="Ok"
                        classNameMemi={props.submitButtonClass}
                        onClick={handleSubmit}
                        btnvariant={props.submitButtonVariant ? props.submitButtonVariant : "contained"}
                    />
                    <ButtonMemi
                        btnval="Close"
                        classNameMemi={props.closeButtonClass}
                        onClick={handleClose}
                        variant={props.submitButtonVariant ? props.submitButtonVariant : "text"}
                    />
                </>
            }
        />
    )
}

export default GeneralModalPopup;