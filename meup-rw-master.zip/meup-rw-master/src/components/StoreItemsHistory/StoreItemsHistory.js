import React, { useState, useEffect, useContext } from 'react';
import { Grid } from '@material-ui/core';

import TableMemi from 'components/TableMemi/TableMemi';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi'
import { meupServices } from 'api/meup/meupServices';
import { useLocation } from 'react-router';
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';
import { DateUtility } from 'utils';
import {formatdate} from "components/CommonFunctionsMeup/CommonFunctionsMeup"
import ApplicationContext from 'context/ApplicationContext';


const DetailsComponent = (props) => {
    return (
        <Grid container style={{ paddingBottom: "1rem" }}>
            <Grid item xs={5}>
                <strong> {props.title} </strong>
            </Grid>
            <Grid item xs={7}>
                {props.value}
            </Grid>
        </Grid>

    )
}
function StoreItemsHistory() {
    const location = useLocation()
    const [errors, setErrors] = useState([]);
    const AppData = useContext(ApplicationContext)
    const uniqueSelectionCode = new URLSearchParams(location.search).get('selectionCode')
    let meup56Res = localStorage.getItem(`meup55StoreItems${uniqueSelectionCode}`) !== undefined ? JSON.parse(localStorage.getItem(`meup55StoreItems${uniqueSelectionCode}`)) : "";

    const [meup57TableDetails, setMeup57TableDetails] = useState([]);

    useEffect(() => {
        meupServices.getItemHistory(meup56Res)
            .then((res) => {
                if (res.hasOwnProperty('data')) {
                    var { data } = res;

                    if (data.status === "SUCCESS") {

                        if (data.hasOwnProperty('data')) {
                            var { data } = data;

                            if (data.hasOwnProperty('REST_RETURNED_DATA')) {

                                let { REST_RETURNED_DATA } = data;
                                REST_RETURNED_DATA = REST_RETURNED_DATA.map((data, index) => {
                                    return { ...data, id: index }
                                })

                                
                                setMeup57TableDetails(REST_RETURNED_DATA);

                            }

                        }
                    }
                }
            })
            .catch((error) => {
                AppData.setLoader(-1)
                setErrors(["An Exception occurred while retrieving the data."]);
            })
    }, [])

    const NoRows = () => {
        return (
            <div> 

            </div>
        )
    }



    let columns = [

        {
            field: "state",
            headerName: "State",
            sortable: true,
            width: 80,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "stateEffectiveDate",
            headerName: "State Effective Date",
            sortable: true,
            width: 113,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            valueGetter: (params) => {

                return formatdate(params.value)
              },
              sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}
        },
        {
            field: "blockedStatus",
            headerName: "Status",
            sortable: true,
            width: 120,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "blockedTargetDate",
            headerName: "Delete Date",
            sortable: true,
            width: 90,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            valueGetter: (params) => {

                return formatdate(params.value)
              },
            sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}

        },
        {
            field: "lastUpdatedUser",
            headerName: "Last Update UserId",
            sortable: true,
            width: 90,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "storeItemHistoryVOID",
            headerName: "Last Update Date",
            sortable: true,
            width: 104,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            valueGetter: (params) => {return params.value !== null && typeof(params.value) === "object" ? formatdate(params.value.lastUpdatedTimeStamp.split("T")[0]) : ""},
            sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}
        },
        {
            field: "comment",
            headerName: "Comments",
            sortable: true,
            width: 160,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory",
            valueGetter: (params) => {return typeof(params.value) === "object" && params.value !== null ? params.value.commentDesc : ""}

        }
    ];
    return (

        <Grid container>
            {/* <Grid item xs={12} style={{ backgroundColor: "#CFC3AD", padding: "0.5rem", fontSize: "13px" }}>
                <strong> Store Item History </strong>
            </Grid> */}
            <Grid item xs={12}>
                <ErrorListMeup errors={errors} />
            </Grid>
            <Grid container style={{ width: "75%", fontSize: "12px" }}>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Division" value={meup56Res ? meup56Res.divisionDto : ""} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Description" value={meup56Res ? meup56Res.description : ""} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Store" value={meup56Res ? meup56Res.storeNumber : ""} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="UPC" value={meup56Res ? meup56Res.dispUpc : ""} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Category" value={meup56Res ? meup56Res.dispCategory : ""} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="CIC" value={meup56Res ? meup56Res.cic : ""} />
                </Grid>
            </Grid>
            <Grid container style={{ height: "100%" }}>
                <TableMemi
                    data={meup57TableDetails}
                    columns={columns}
                    classnameMemi="tableStoreItemHistory"
                    rowHeight={20}
                    showColumnRightBorder={true}
                    hideFooterPagination={true}
                    hideFooterSelectedRowCount={true}
                    autoHeight
                    density="compact"
                    NoRowsOverlay={NoRows}
                />
            </Grid>
            <Grid item xs={12} className=""
                style={{ marginBottom: "1rem" }}>
                <ButtonMemi
                    btnval="Close Window"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    onClick={() => { window.close() }}
                />
            </Grid>
        </Grid>
    )
}

export default StoreItemsHistory;