import React from "react";
// import React, { useContext, useEffect, useCallback} from "react";

import { Grid } from "@material-ui/core";
import "./Footer.scss";
// import LogContext from "../../context/LogContext";
function Footer() {
  // const ContextMessages = useContext(LogContext);

  // const callMessages = useCallback(
  //   () => {
  //     console.table("context console messages: ", ContextMessages.messages);
  //   for (let i = 0; i < ContextMessages.messages.length; i++) {
  //     console.log("Context Console Messages: ", ContextMessages.messages[i]);
  //   }
  //   },
  //   []
  // )
  // useEffect(() => {
  //   const newMessage = {
  //     id: Math.random(),
  //     msg: "Hello World",
  //   };
  //   ContextMessages.addString(newMessage);
  // }, []);

  // useEffect(() => {
  //   let control = document.querySelector("#scrollGrid");
  //   control.scrollTop = control.scrollHeight;
  //   if (ContextMessages.messages.length > 0) {
  //     callMessages();
  //   }
    
  // }, [ContextMessages, callMessages]);

  

  return (
    <>
    <Grid container>
    <Grid item xs={12} sm={12} md={12} xl={12}>
      <Grid id="scrollable"  className="flex-section">
        <Grid id="scrollGrid" item md={12} className={"flex-col-scroll"}>
          
        </Grid>
      </Grid>
      </Grid>
      </Grid>
    </>
  );
}

export default Footer;
