import React, {
    useEffect,
    useContext,
    useState,
    
  } from "react";
  import { makeStyles} from "@material-ui/core/styles";
  import { Grid } from "@material-ui/core";
 
  import TableMemi from "../../components/TableMemi/TableMemi";
 
  import ApplicationContext from "../../context/ApplicationContext";

  //import RemoveRedEyeSharpIcon from '@material-ui/icons/RemoveRedEyeSharp';
  //import EditIcon from '@material-ui/icons/Edit';
  //import RemoveRedEyeIcon from '@material-ui/icons/RemoveRedEye';
  //import SearchIcon from '@material-ui/icons/Search';
  //import RoomIcon from '@material-ui/icons/Room';
  import SearchFieldMemi from "../../components/SearchFieldMemi/SearchFieldMemi";

  // import DoDisturbAltIcon from '@material-ui/icons/DoDisturbAlt';
  // import DoNotDisturbIcon from '@mui/icons-material/DoNotDisturb';
  // import DoDisturbIcon from '@material-ui/icons/DoDisturb';
  //import AddIcon from '@material-ui/icons/Add';
  //import LocalOfferIcon from '@material-ui/icons/LocalOffer';
  

  import { MEMI08Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";

  
  const useStyles = makeStyles((theme) => ({
    root: {
      "& .super-app.positive": {
        color: "#50C878",
        fontWeight: "600",
      },
    },
    root1: {
      "& > *": {
        margin: theme.spacing(3),
  
        width: "40ch",
      },
    },
  }));
  
  export const Mapped = (props) => {
    const classes = useStyles();
    
    const [searchvalue, setSearchType] = useState(" ");
    const [productType, setSearchValue] = useState(" ");
    
  
    const AppData = useContext(ApplicationContext);
  
    useEffect(() => {
      MEMI08Axios.get("/").then((res) => {
        AppData.setMemi08(res.data);
      });
    });
  
    
  
    return (
     
          <Grid
            container
            spacing={2}
            direction="row"
            className="MainContent"
            alignItems="flex-start"
          >
            <Grid item md={12} className={classes.root}>
            
              <div className="search_field_Mapped">
           
           
{/*             
                <DropDownMemi
                          label="Show All"
                          options={["Type1", "Type2", "Type3", "Type4"]}
                         
                          value={pack}
                          setValue={(value) => setPackType(value)}
                          error={errPack}
                          setError={(value) => setErrPack(value)}
                        //   classnamebtn="cascadingbtn"
                          labelInline={true}
                        /> */}
                        
             
  
                <SearchFieldMemi
                  selectedValue={productType}
                  options={["Type1", "Type2", "Type3", "Type4"]}
                  handleSelectChange={(value) => setSearchType(value)}
                  searchValue={searchvalue}
                  onChangeSearchValue={(value) => setSearchValue(value)}
                  classNameMemi="searchBarClass"
                />
               
               
              </div>
              
              <TableMemi
                data={AppData.memi08}
                classnameMemi="table27"
                rowheight={40}
                selectionType="radio"
              />
            </Grid>
           
          </Grid>
      
    );
    
  };
  
  export default Mapped;
  