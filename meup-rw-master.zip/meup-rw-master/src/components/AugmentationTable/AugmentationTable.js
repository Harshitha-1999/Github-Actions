import React from "react";
import TableMemi from "components/TableMemi/TableMemi";
//import Avatar from "@material-ui/core/Avatar";
//import clsx from "clsx";
import { Grid } from "@material-ui/core";
//import Button from "@material-ui/core/Button";
//import DropDownMemi from "../DropDownMemi/DropDownMemi";
//import Paper from "@material-ui/core/Paper";
import ButtonMemi from "../ButtonMemi/ButtonMemi";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import TextFieldMemi from "components/TextField/TextFieldMemi";
import Paper from "@material-ui/core/Paper";
import {
  makeStyles,
  
} from "@material-ui/core/styles";


const useStyles = makeStyles({
  root: {
    "& .super-app-theme--header": {
      backgroundColor: "rgba(255, 7, 0, 0.55)",
    },
  },
  divHeader: {
    backgroundColor: "#fffde7",
    height: "39px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "2px",
  },
  addMarginRight: {
    marginRight: "200px",
  },
  addMarginLeft: {
    marginLeft: "10px",
  },
  gridMargin: {
    marginTop: "9px",
  },
  gridButton: {
    display: "flex",
    justifyContent: "flex-end",
  },
});

/*
 *  must make 'let customcolumns = null' if not using custom columns
 *  or don't pass customcolumns prop
 *  passing below an array with key/value hide:true allows for hiding a row
 */
let customcolumns = [{ field: "id", hide: true }];

function AugmentationTable(props) {
  const classes = useStyles();
  return (
    
      <Grid item xs={12} sm={12} md={12} xl={12}>
        <Paper variant="outlined" elevation={12} className="override">
          <div className={classes.divHeader}>
            <h4 className={classes.addMarginLeft}>Departments</h4>
            <h4>Un Reviewed Items</h4>
            <h4>Need Further Review Items</h4>
            <h4 className={classes.addMarginRight}>Completed Items</h4>
          </div>
          <TableMemi
            data={props.AppData.memi17}
            classnameMemi="table29"
            rowheight={40}
            rowPerPageOptions={props.AppData.memi17.length - 1}
            selectionType="regular"
            customcolumns={customcolumns}
          />
        </Paper> 
        <div>
          <Grid
            item
            mt={3}
            xs={12}
            sm={12}
            md={6}
            xl={6}
            className={classes.gridMargin}
          >
            <div className="root12">
              <Grid item xs={12} md={3}>
                <DropDownMemi
                  LabelClass="labelclass1"
                  DropDownClass="dropdown1"
                  options={["Type1", "Type2", "Type3", "Type4"]}
                  label=""
                  alignItems=""
                  value={""}
                  setValue={""}
                  error={""}
                  setError={""}
                  classNameMemi="drp4"
                />
              </Grid>
              <Grid item xs={1} md={1}>
                <TextFieldMemi
                  length={15}
                  alignItems=""
                  id="Vcf outlined-disabled"
                  disabled={false}
                  value={""}
                  error={""}
                  setTextValue={""}
                  setError={""}
                  labelLeft={true}
                  input="input20"
                  TextFieldClass="textField30"
                />
              </Grid>
              <Grid item xs={1} md={2} className={classes.gridButton}>
                <ButtonMemi
                  btncolor="primary"
                  btnval="Search Item"
                  btnvariant="contained"
                  classnameMemi="btnmemi1"
                  onClick={() => {
                    alert("clicked");
                  }}
                />
              </Grid>
            </div>
          </Grid>
        </div>
      </Grid>
   
  );
}

export default AugmentationTable;
