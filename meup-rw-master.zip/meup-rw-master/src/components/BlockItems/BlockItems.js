import React, { useState, useEffect, useContext, useCallback } from 'react';
import { Grid, OutlinedInput } from '@material-ui/core';
import { useHistory } from 'react-router-dom'

import DropDownMemi from 'components/DropDownMemi/DropDownMemi';
import CalendarMeup from 'components/CalendarMeup/CalendarMeup';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import TableMemi from 'components/TableMemi/TableMemi';

import { meupServices } from "../../api/meup/meupServices";

// import GeneralModalPopup from 'components/GeneralModalPopup/GeneralModalPopup';
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';

import ApplicationContext from "../../context/ApplicationContext";
import { emptyData, invalidDate, pastDate, selectDivision, noItem, duplicate, incompleteStoreItemDetails, noStore, invalidStoreItemLength, nonNumeric } from 'utils/Constants';
import { isValidDate, isPastDate, hasDuplicates, validateStores, validateItems, DateUtility, isNumber } from 'utils';
import { RouteBase } from '../../routes/constants/RouteBase'
import { usePersistState } from 'hooks/usePersistState';

function BlockItems() {
    const history = useHistory();

    // const AppData = useRef(useContext(ApplicationContext));
    const AppData = useContext(ApplicationContext);

    const [division, setDivision] = usePersistState("", "meup52Divisions");



    const handleChange = (value, params, length) => {
        if (value.length > length) {
            return
        }
        const newData = data.map((row) => {
            if (params.row.id === row.id) {
                return { ...row, [`${params.field}`]: value };
            }
            else {
                return row;
            }
        })

        setData(newData)
    }

    useEffect(() => {
       
        meupServices.getDivisionListForUS()
            .then((res) => {
               
                const resData = res.data.data.REST_RETURNED_DATA.map((x) => {
                    return { label: x.dispDivision, value: x.divisionNumber };
                })
                AppData.setMeup52Divisions(resData);
            })
            .catch((error) => {

                AppData.setMeup52Divisions([]);
                setErrors(["An Exception occurred while retrieving the data."]);
                window.scrollTo(0, 0);
              
            })
    }, []) //removed[] to remove warning




    const [data, setData] = usePersistState([
        { "id": 0, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
        { "id": 1, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
        { "id": 2, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
        { "id": 3, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
        { "id": 4, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
    ], "meup52Data");




    const [errDivision, setErrorDivision] = useState(false);
    const [date, setDate] = usePersistState(null, "meup52Date");
    const [resSuccess, setResSuccess] = useState({ isSuccess: false, msg: "" })

    const [store1, setStore1] = usePersistState("", "meup52Store1");
    const [store2, setStore2] = usePersistState("", "meup52Store2");
    const [store3, setStore3] = usePersistState("", "meup52Store3");
    const [store4, setStore4] = usePersistState("", "meup52Store4");
    const [store5, setStore5] = usePersistState("", "meup52Store5");

    const [isErrorStore, setStoreError] = useState({ isErrorStore1: false, isErrorStore2: false, isErrorStore3: false, isErrorStore4: false, isErrorStore5: false });


    const [errors, setErrors] = useState([]);

    let columns = [

        {
            field: "UPC",
            headerName: "UPC",
            sortable: false,
            flex: 0.2,
            renderCell: (params) => (
                <OutlinedInput
                    value={params.value}
                    onChange={(e) => handleChange(e.target.value, params, 12)}
                    fullWidth={false}
                    className="blockItemsInputBox"
                    error={params.row.isUPCError}

                />
            ),
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "CIC",
            headerName: "CIC",
            sortable: false,
            flex: 0.2,
            renderCell: (params) => (
                <OutlinedInput
                    value={params.value}
                    onChange={(e) => handleChange(e.target.value, params, 8)}
                    fullWidth={false}
                    className="blockItemsInputBox"
                    error={params.row.isCICError}
                />

            ),
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        }
    ];

    const onRefresh = useCallback(() => {
        setErrorDivision(false);
        setDivision("");
        setData([
            { "id": 0, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
            { "id": 1, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
            { "id": 2, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
            { "id": 3, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },
            { "id": 4, "UPC": "", "CIC": "", "isUPCError": false, "isCICError": false },

        ]);
        setStore1("");
        setStore2("");
        setStore3("");
        setStore4("");
        setStore5("");
        setDate(null);
        window.scrollTo(0, 0)
        setErrors([]);
        setResSuccess({ isSuccess: false, msg: "" });
        setStoreError({ isErrorStore1: false, isErrorStore2: false, isErrorStore3: false, isErrorStore4: false, isErrorStore5: false });
    }, [errDivision, division, data, store1, store2, store3, store4, store5, date, isErrorStore, resSuccess])

    const handleSubmit = useCallback((e) => {
        e.preventDefault()
        let error = "";
        setErrorDivision(false);
        setResSuccess({ isSuccess: false, msg: "" });
        setStoreError({ isErrorStore1: false, isErrorStore2: false, isErrorStore3: false, isErrorStore4: false, isErrorStore5: false });

        var clearCICUPCError = data.map((value) => {
            return { ...value, "isUPCError": false, "isCICError": false }
        });

        setData(clearCICUPCError)

        let filteredData = [];
        let stores = [store1, store2, store3, store4, store5];

        for (let i = 0; i < data.length; i++) {
            if (data[i]["UPC"].trim() !== "" || data[i]["CIC"].trim() !== "") {
                filteredData.push(data[i])
            }
        }
        stores = stores.filter((store) => {
            return store.trim() !== ""
        })

        let isValidStores = validateStores(stores)
        let isValidItems = validateItems(filteredData);

        if (isValidDate(date)) {
            alert(invalidDate)
            window.scrollTo(0, 0);
            setDate("");
            document.getElementById("blockItemsCal").focus()
            return
        }

        else if (isPastDate(date)) {
            alert(pastDate);
            setDate("");
            window.scrollTo(0, 0)
            document.getElementById("blockItemsCal").focus()
            return
        }

        else if (division === "") {
            error = selectDivision;
            setErrorDivision(true);
        }

        else if (stores.length === 0 && filteredData.length === 0) {
            error = emptyData;
        }

        else if (isValidStores || isValidItems) {
            error = isValidStores ? isValidStores : isValidItems;

            let arrayName = [store1, store2, store3, store4, store5]

            arrayName.map((val, i) => {

                if (val !== "" && !isNumber(val) && error === nonNumeric) {
                    setStoreError(preState => ({ ...preState, [`isErrorStore${i + 1}`]: true }))
                } else if (val !== "" && val.trim().length !== 4 && error === invalidStoreItemLength) {
                    setStoreError(preState => ({ ...preState, [`isErrorStore${i + 1}`]: true }))
                }
            })
            let resultData = [];

            clearCICUPCError.map((val) => {

                resultData.push({ ...val, isUPCError: ((val.CIC !== "" && val.UPC === "" && error === incompleteStoreItemDetails) || (val.UPC !== "" && !isNumber(val.UPC.trim()) && error === nonNumeric) || (val.UPC !== "" && val.UPC.trim().length < 10 && error === invalidStoreItemLength)) ? true : false, isCICError: ((val.UPC !== "" && val.CIC === "" && error === incompleteStoreItemDetails) || (val.CIC !== "" && !isNumber(val.CIC.trim()) && error === nonNumeric) || (val.CIC !== "" && val.CIC.trim().length < 7 && error === invalidStoreItemLength)) ? true : false });
            });

            setData(resultData);

        }

        else if (filteredData.length === 0) {
            error = noItem;
        }

        else {
            let cic = filteredData.map((x) => x["CIC"])
            if (hasDuplicates(stores) || hasDuplicates(cic)) {
                error = duplicate;

                if (hasDuplicates(stores)) {

                    let arrayName = [store1, store2, store3, store4, store5]

                    arrayName.map((value, i) => {

                        if (value !== "" && arrayName.indexOf(value) !== arrayName.lastIndexOf(value)) {
                            setStoreError(preState => ({ ...preState, [`isErrorStore${i + 1}`]: true }))
                        }
                    })

                }

                if (hasDuplicates(cic)) {

                    let filterCic = clearCICUPCError.map((value) => value["CIC"]);

                    let resultData = filterCic.map((value, i) => {

                        if (value !== "" && filterCic.indexOf(value) !== filterCic.lastIndexOf(value)) {
                            return { ...clearCICUPCError[i], isCICError: true };
                        } else {
                            return { ...clearCICUPCError[i], isCICError: false };
                        }
                    });
                    setData(resultData)
                }
            }
        }

        if (error === "") {

            let storeItemHelperList = [];

            for (let i = 0; i < 5; i++) {
                if (data[i]["UPC"].trim() !== "" || data[i]["CIC"].trim() !== "" || (stores[i] && stores[i] !== "")) {
                    storeItemHelperList.push({ upc: data[i]["UPC"] ? data[i]["UPC"] : null, cic: data[i]["CIC"] ? data[i]["CIC"] : null, storeNo: stores[i] ? stores[i] : null })
                }
            }

            let deleteDate = DateUtility.convertDate(date)
            
            meupServices.postBlockItemsAndStores(division, deleteDate, storeItemHelperList).then((res) => {

                if (res.hasOwnProperty('data')) {
                    var { data } = res;

                    if (data.status === "SUCCESS") {
                       
                        if (data.hasOwnProperty('data')) {
                            var { data } = data;

                            if (data.hasOwnProperty('REST_RETURNED_DATA')) {

                                let { REST_RETURNED_DATA } = data;

                                let msg = REST_RETURNED_DATA.pop();

                                if (REST_RETURNED_DATA.length > 0) {

                                    AppData.setMeup52BlockItemsAndStores([REST_RETURNED_DATA, msg.errorMessage]);
                                    history.push(RouteBase.MEUP57);

                                } else {
                                    onRefresh();
                                    setResSuccess({ isSuccess: true, msg: msg.errorMessage })
                                }
                            }

                        }
                    }
                }
            }).catch((err) => {
                setErrors(["An Exception occurred while retrieving the data."]);
                window.scrollTo(0, 0);
                AppData.setMeup52BlockItemsAndStores([]);
               
            })
        }
        window.scrollTo(0, 0)
        setErrors([error]);
    }, [errDivision, division, data, store1, store2, store3, store4, store5, date, resSuccess, isErrorStore])

    return (
        <form onSubmit={handleSubmit}>
        <Grid container>
            <Grid item xs={12}>
                {resSuccess.isSuccess ? <div className="uploadItemsSuccessMsg"> {resSuccess.msg} </div> : <ErrorListMeup errors={errors} />}
            </Grid>
            <Grid item xs={12}>
                <div style={{ color: 'rgb(0, 0, 128)', marginTop: "1px", fontSize: "medium" }}>
                    <strong> All UPC/CICs entered will be blocked in all stores entered. </strong>
                </div>

                <div style={{ width: "50rem" }} className="blockItemsMarginTop">
                    <DropDownMemi
                        label={<> Select Division <font color="red">*</font> </>}
                        LabelClass="labelClassBlockedItems"
                        alignItems="row"
                        options={AppData.meup52Divisions}
                        DropDownClass="blockItemsDropDown"
                        value={division}
                        error={errDivision}
                        setValue={(value) => setDivision(value)}
                        errorText=""
                    />
                </div>
                <div style={{ width: "40rem" }} className="blockItemsMarginTop">
                    <CalendarMeup
                        meupcal="blockItemsCal"
                        id="blockItemsCal"
                        label={<> Set Delete Date  <font color="red">*</font> </>}
                        LabelClass="labelClassBlockedItems"
                        alignItems="row"
                        value={date}
                        setValue={(value) => setDate(value)}
                        disablePastDays={true}

                    />

                </div>
                <div style={{ width: "43rem", display: "flex", flexDirection: "row" }} className="blockItemsMarginTop">
                    <div style={{ display: "flex", flexDirection: "column", justifyContent: "flex-start" }}>
                        <label style={{ whiteSpace: "nowrap" }}> Enter Store #</label>
                    </div>

                    <OutlinedInput
                        value={store1}
                        onChange={(e) => setStore1(e.target.value)}
                        style={{ marginLeft: "9.8rem", height: "1.8rem" }}
                        inputProps={{ maxLength: 4 }}
                        error={isErrorStore.isErrorStore1}
                    />
                    <OutlinedInput
                        value={store2}
                        onChange={(e) => setStore2(e.target.value)}
                        style={{ marginLeft: "1rem", height: "1.8rem" }}
                        inputProps={{ maxLength: 4 }}
                        error={isErrorStore.isErrorStore2}
                    />
                    <OutlinedInput
                        value={store3}
                        onChange={(e) => setStore3(e.target.value)}
                        style={{ marginLeft: "1rem", height: "1.8rem" }}
                        inputProps={{ maxLength: 4 }}
                        error={isErrorStore.isErrorStore3}
                    />
                    <OutlinedInput
                        value={store4}
                        onChange={(e) => setStore4(e.target.value)}
                        style={{ marginLeft: "1rem", height: "1.8rem" }}
                        inputProps={{ maxLength: 4 }}
                        error={isErrorStore.isErrorStore4}
                    />
                    <OutlinedInput
                        value={store5}
                        onChange={(e) => setStore5(e.target.value)}
                        style={{ marginLeft: "1rem", height: "1.8rem" }}
                        inputProps={{ maxLength: 4 }}
                        error={isErrorStore.isErrorStore5}
                    />

                </div>



            </Grid>
            <Grid container style={{ width: "43rem" }}>
                <Grid item xs={12} className="tableBlockItemsHeader blockedItems blockItemsMarginTop" style={{ border: "1px solid" }} >
                    <strong> Enter Items </strong>
                </Grid>
                <Grid item xs={12} style={{  borderLeft: "1px solid" }}>
                    <TableMemi
                        data={data}
                        columns={columns}
                        classnameMemi="tableBlockedItem"
                        showCellRightBorder={true}
                        showColumnRightBorder={true}
                        autoHeight

                    />
                </Grid>
                <Grid item xs={12} className="blockItemsMarginTop" style={{ marginBottom: "1rem" }}>
                    <ButtonMemi

                        btnval="Block Items"
                        btnvariant="contained"
                        classNameMemi="blockItemsButtons"
                        type="submit"
                        onClick={handleSubmit}
                    />

                    <ButtonMemi
                        btnval="Reset"
                        btnvariant="contained"
                        classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                        onClick={onRefresh}

                    />


                    <ButtonMemi

                        btnval="Cancel"
                        btnvariant="contained"
                        classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                        onClick={() => {
                            history.push("/")
                        }}

                    />

                </Grid>
            </Grid>

        </Grid>
    </form>
    )
}

export default BlockItems;