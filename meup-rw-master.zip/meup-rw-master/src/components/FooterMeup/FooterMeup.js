import React from 'react';
import { footerWarning, footerInfoOne, footerInfoTwo } from '../../utils/Constants';


function FooterMeup() {

  return (

    <div className="footermeup">
      <font className="footlink"> 
        <a className="linksafeway" target="_blank"  rel="noreferrer">
          <span className="footwarn">{footerWarning}</span>
        </a>
        <span className="foottext">
          {footerInfoOne}<sup> © </sup>{footerInfoTwo}
        </span>
       
      </font>

    </div>

  );
}

export default FooterMeup;