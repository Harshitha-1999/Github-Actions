import React from 'react';
import { cleanup, fireEvent, render, waitFor } from "@testing-library/react";
import {TextBoxWidget} from './TextBoxWidget';
import * as InputUtils from 'utils/InputUtils';

describe("<TextBoxWidget/> component", () => {
    let props = {
        placeholder : "",
        horizontalForm : false,
        disabled : false,
        readOnly : false,
        maxLength : 3,
        inputType : "text",
        name: "testTextBox",
        value: "Test case for TextBox Widget",
        onChange : jest.fn(),
        onBlur: jest.fn()
    };
    it('renders <TextBoxWidget/> successfully', () => {
        const wrapper = render(
        <TextBoxWidget {...props} />
        );
        expect(wrapper).toBeTruthy();
    });

    it('Fires the onChangeHandler when the text input changes but does not fire setFocus function', () => {
        let focusSpy = jest.spyOn(InputUtils, 'setFocus').mockImplementation(() => {
            return;
        })
        const {container} = render(
        <TextBoxWidget {...props} />
        );

        const ev = {
            target: {
                value: 'sam'
            }
        }
        fireEvent.change(container.querySelector("#testTextBox"), ev)
        expect(focusSpy).not.toHaveBeenCalled();

    });

    it('Should call tabAndArrowNavigationUtil on keydown and key length is zero', () => {
        let tabAndArrowNavigationUtilSpy = jest.spyOn(InputUtils, 'tabAndArrowNavigationUtil')
        .mockImplementation(() => {
            return;
        });

        const {container} = render(
            <TextBoxWidget {...props} />
            );
    
            const ev = {
                key: ''
            }
            fireEvent.keyDown(container.querySelector("#testTextBox"), ev)
            expect(tabAndArrowNavigationUtilSpy).toHaveBeenCalled();
    });

    it('Should call replaceNextCharacterOnKeyPress on keydown and key length is 1', () => {
        let tabAndArrowNavigationUtilSpy = jest.spyOn(InputUtils, 'tabAndArrowNavigationUtil')
        .mockImplementation(() => {
            return;
        });

        let replaceNextCharacterOnKeyPressSpy = jest.spyOn(InputUtils, 'replaceNextCharacterOnKeyPress')
        .mockImplementation(() => {
            return;
        })

        let newProps = {
            ...props,
            setFieldValue: jest.fn()
        }
        const {container} = render(
            <TextBoxWidget {...newProps} />
            );
    
            const ev = {
                key: 'a',
                ctrlKey: false,
                shiftKey: false,
                metaKey: false
            }
            fireEvent.keyDown(container.querySelector("#testTextBox"), ev)
            expect(replaceNextCharacterOnKeyPressSpy).toHaveBeenCalled();
    });

    it('Should call moveCaretBackOnBackSpacePress on keydown', () => {
        let tabAndArrowNavigationUtilSpy = jest.spyOn(InputUtils, 'tabAndArrowNavigationUtil')
        .mockImplementation(() => {
            return;
        });

        let moveCaretBackOnBackSpacePressSpy = jest.spyOn(InputUtils, 'replaceNextCharacterOnKeyPress')
        .mockImplementation(() => {
            return;
        })

        let newProps = {
            ...props,
            setFieldValue: jest.fn()
        }
        const {container} = render(
            <TextBoxWidget {...newProps} />
            );
    
            const ev = {
                key: 'a',
                ctrlKey: false,
                shiftKey: false,
                metaKey: false
            }
            fireEvent.keyDown(container.querySelector("#testTextBox"), ev)
            expect(moveCaretBackOnBackSpacePressSpy).toHaveBeenCalled();
    });

    it('Should call replaceCharactersOnPaste on paste', () => {

        let replaceCharactersOnPasteSpy = jest.spyOn(InputUtils, 'replaceCharactersOnPaste')
        .mockImplementation(() => {
            return;
        })

        let {container} = render(<TextBoxWidget {...props} />);

        let ev = {};
        ev.clipboardData = {
            getData: jest.fn().mockReturnValue("co")
        }

      //  wrapper.find('#testTextBox').simulate('paste',ev);
        fireEvent.paste(container.querySelector("#testTextBox"), ev)

        expect(replaceCharactersOnPasteSpy).toHaveBeenCalled();
        

    })
});
