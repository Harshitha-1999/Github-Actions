import React from 'react';

import {Apps} from '@material-ui/icons';

import DropdownMenuMemiu from 'components/DropdownMenuMemiu/DropdownMenuMemiu';




function HamburgerMenu(props) {

    return (
        <>
            <DropdownMenuMemiu
                label={<Apps/>}
                buttonClass={props.buttonClass}
                menuData={props.menuData}
                disableArrowDown

            />
        </>
    )
}

export default HamburgerMenu;