import React from 'react';
import {fireEvent, render} from "@testing-library/react";
import ServiceError from './index';

const mockHistoryPush = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}));

describe('<ServiceError />', () => {
    const defaultProps = {
        programName: 'ISC020',
        error: {
            message: 'test message',
            response: {
                data: {
                    ABSResponse: {
                        errors: [
                            {code: '10'}
                        ],
                        message: "test message"
                    }
                }
            },
            config: {
                method: 'POST'
            }
        }
    }

    let documentSpy;

    beforeEach(() => {
        documentSpy = jest.spyOn(document, "getElementById").mockReturnValue({
            value: '',
            style: {
                color: '',
                removeProperty: jest.fn()
            }
        })
    })

    it('Should render without errors, config method is POST', () => {
        const {debug,container} = render(
            <ServiceError {...defaultProps} />
        );

        expect(container).toBeTruthy();
    });

    it('Should render without errors, config method is PUT', () => {

        let props = {
            ...defaultProps,
            error: {
                ...defaultProps.error,
                config: {
                    method: 'PUT'
                }
            }
        }
        const {debug,container} = render(
            <ServiceError {...props} />
        );

        expect(container).toBeTruthy();
    });

    it('Should render without errors, config method is DELETE', () => {

        let props = {
            ...defaultProps,
            error: {
                ...defaultProps.error,
                config: {
                    method: 'DELETE'
                }
            }
        }
        const {debug,container} = render(
            <ServiceError {...props} />
        );

        expect(container).toBeTruthy();
    });

    it('Should render without errors, config method is default', () => {

        let props = {
            ...defaultProps,
            error: {
                ...defaultProps.error,
                config: {
                    method: 'DEFAULT'
                }
            }
        }
        const {debug,container} = render(
            <ServiceError {...props} />
        );

        expect(container).toBeTruthy();
    });
    
    it('Should render error message when invalid keys are pressed', () => {
        const {debug,container} = render(
            <ServiceError {...defaultProps} />
        );

        fireEvent.keyDown(document, {key: 'F1'})

        expect(container).toBeTruthy();
        expect(documentSpy).toHaveBeenCalled();
    });

    it('Should fire navigate function when F3 and shift key are pressed', () => {
        const {debug,container} = render(
            <ServiceError {...defaultProps} />
        );

        fireEvent.keyDown(document, {key: 'F3', shiftKey: true});

        expect(container).toBeTruthy();
        // expect(mockHistoryPush).toHaveBeenCalled();
    });

    it('Test default switch block', () => {
        const {debug,container} = render(
            <ServiceError {...defaultProps} />
        );

        fireEvent.keyDown(document, {shiftKey: true});

        expect(container).toBeTruthy();
    });
});