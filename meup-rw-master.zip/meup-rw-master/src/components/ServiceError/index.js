import React, { useCallback, useEffect } from "react";



import "./ServiceError.scss";
import PageLayoutMeup from "components/PageLayoutMeup/PageLayoutMeup";
import HeaderMeup from "components/HeaderMeup/HeaderMeup";
import FooterMeup from "components/FooterMeup/FooterMeup";
import {  useErrorField } from "hooks";

export const ServiceError = (props) => {

  const { error, label, programName } = props
  console.log(label)

  const { clearErrorField } = useErrorField();


  const getFunction = useCallback(() => {
    const { method } = error.config;
    switch (method.toUpperCase()) {
      case "POST":
      case "GET":
        return "READ";
      case "PUT":
        return "UPDATE";
      case "DELETE":
        return "DELETE";
      case "JS":
        return "JS";
      default:
        return null;
    }
  }, [error]);

  useEffect(() => {
    clearErrorField();
  }, [clearErrorField])

  const content = (
    <>
      <div className="error-mainContainer">

        <div className="error-heading">
          <label>An error has occured in {programName}. <br /> please contact data processing immediately.</label>
        </div>
        <div className="error-detail-div">
          <div className="error-inner-div">
            Error Details:
            <br />
            <br />
            <div className="error-content">
              Function : {getFunction()} <br/> <br/>
              Error Description : {error.message}
            </div>
          </div>
        </div>
        <div className="error-heading">
          <label>Please refresh this page to continue</label>
        </div>
      </div>
    </>
  )


  return (
    <PageLayoutMeup
      header={<HeaderMeup title={label} />}
      mainContentMeup={content}
      footerMeup={<FooterMeup />}
    />

  );
}

export default ServiceError;
