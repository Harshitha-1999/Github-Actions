import { Grid } from '@material-ui/core';
import React, { useContext, useState } from 'react'
import ApplicationContext from "../../context/ApplicationContext";
import { useHistory } from 'react-router';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { RouteBase } from 'routes/constants';
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';
import TableHoldItems from 'components/TableHoldItems/TableHoldItems';
import { meupServices } from 'api/meup/meupServices';
import { getSelectedRowData } from 'utils';

import { usePersistState } from 'hooks/usePersistState';


const DetailsComponent = (props) => {
    return (
        <Grid container style={{ paddingBottom: "1rem", "whiteSpace": "nowrap" }}>
            <Grid item xs={5}>
                <strong> {props.title} </strong>
            </Grid>
            <Grid item xs={7}>
                {props.value}
            </Grid>
        </Grid>

    )
}

export default function StoreItemsHoldStoreItem(props) {
    const AppData = useContext(ApplicationContext);
    const history = useHistory();
    const [currPage, setCurrPage] = useState(1);
    const [errors, setErrors] = useState([]);
    const [success, setSuccess] = useState("")
    const [selectedDivisions, setSelectedDivisions] = usePersistState([], "meup58Divisions");
    const [selectedStockingSections, setSelectedStockingSections] = usePersistState([], "meup58StockingSections");
const backagain=()=>{
    meupServices.getStoreCountsStoreItemsOnHold(selectedDivisions, selectedStockingSections)
    .then((res) => {
        const { data } = res;

        if (data.status === "SUCCESS") {
            const {REST_RETURNED_DATA} = data.data;
            let holdData = REST_RETURNED_DATA.map((data) => {
                return { ...data, accept: false, reject: false, hold: data.status === "H" }
            });

          
                AppData.setMeup62(holdData);
                history.push(RouteBase.MEUP62)
            

        }

    })
    .catch((error) => {
        AppData.setMeup62([]);
        setErrors(["An Exception occurred while retrieving the data"])
    })

}


    const handleApplyChanges = (e) => {
        e.preventDefault()
        const datarow = getSelectedRowData(AppData.meup63, currPage, 10)
        
        meupServices.postUpdateHoldStatus(datarow)
            .then((res) => {
                if(res.data.status === "SUCCESS") {
                    const data = res.data.data
                    if(data && data.REST_RETURNED_DATA) {
                        setSuccess(data.REST_RETURNED_DATA)
                        let refresh = AppData.meup63.filter((obj) => {

                            for (let i = 0; i<datarow.length; i++) {
                        
                                if(datarow[i].id === obj.id && obj.accept==true) {
                        
                                    return false
                        
                                }
                        
                            }
                        
                            return true
                        
                        })
                        let reset=refresh.map(obj=>({...obj,accept:false,hold:true}))
                      AppData.setMeup63(reset)
                        setErrors([]);
                    }

                }
                
            })
            .catch((error) => {
                setErrors(["An Exception occurred while applying the changes"])
                setSuccess("")
                
            })
    }

    const columns = [
        {
            fieldName: "stockSectionNbr",
            headerName: "Stocking Section #",
            numeric: true,
            sorting:false
        },
        {
            fieldName: "upcID",
            headerName: "UPC",
            numeric: true,
            sorting:false
        },
        {
            fieldName: "cic",
            headerName: "CIC",
            numeric: true,
            sorting:false
        },
        {
            fieldName: "desc",
            headerName: "Description",
            sorting:false
        },
        {
            fieldName: "schematicEffectiveDate",
            headerName: "Schematic Effective Date",
            sorting:false
        },
    ]

    return (
        <form onSubmit={handleApplyChanges}>
        <Grid container>

            <Grid item xs={12}>
                {
                    errors.length > 0 ?
                        <div>
                            <ErrorListMeup errors={errors} />
                        </div> :
                        <div className="uploadItemsSuccessMsg"> {success} </div>

                }
                <div style={{ display: "flex", width: "30rem" }}>
                    <DetailsComponent
                        title="Division:"
                        value={AppData.meup63.length > 0 ? AppData.meup63[0].divisionNbr : ""}
                    />
                    <DetailsComponent
                        title="Store#:"
                        value={AppData.meup63.length > 0 ? AppData.meup63[0].storeID : ""}
                    />
                </div>

                <TableHoldItems
                    data={AppData.meup63}
                    columns={columns}
                    setData={(data) => AppData.setMeup63(data)}
                    currPage={currPage}
                    setCurrPage={(page) => setCurrPage(page)}
                />

            </Grid>
            <Grid
                item
                xs={12}
                className="blockItemsMarginTop"
                style={{ bottom: "0", marginBottom: "1.5rem" }}
            >


                <ButtonMemi
                    btnval="Apply Changes"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    type="submit"
                    onClick={handleApplyChanges}
                    btnsize="small"
                />

                <ButtonMemi
                    btnval="Search Again"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => history.push(RouteBase.MEUP58)}
                    btnsize="small"
                />
                <ButtonMemi
                    btnval="Back"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={backagain}
                    btnsize="small"

                />
                <ButtonMemi
                    btnval="Cancel"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => history.push(RouteBase.MEUP50)}
                    btnsize="small"

                />
            </Grid>
        </Grid>
    </form>
    )
}
