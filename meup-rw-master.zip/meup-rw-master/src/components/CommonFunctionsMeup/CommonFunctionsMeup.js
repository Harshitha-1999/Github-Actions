import { authTokenCookie } from 'utils';
import Moment from 'moment';

export function formatDate(date) {
  return Moment(date).format('YYYY-MM-DD');
}
 export function formatdate(date){
   return Moment(date).format('MM/DD/YYYY')
 }
export function isNumber(num) {
  return !isNaN(parseFloat(num)) && isFinite(num);
}

export  function validateCicUpcStore(label, value, min, setError, errorList) {
    setError(false)
    if(value === "") {
        return
    }
    if(!isNumber(value)) {
        errorList.push(`${label} must be numeric.`);
        setError(true)
    }
    else if(value.length < min) {
        errorList.push(`${label} should be minimum ${min} digits.`)
        setError(true);
    }
}

export function generateUserLevel() {
    
  let {adGroups} = authTokenCookie()

  if(!adGroups) {
    adGroups = [];
  }
  
  let userLevel = "meup-standard";
  let userLevelAmount = 0

  const levels = {
    admin: [
      "id.meup.admin",
      "az-meup-dev-adm",
      "meup.admin"
    ],
    standard: [
      "id.meup.all",
      "az-meup-dev-users",
      "meup.all",
    ],
    holdUser: [
      "id.meup.schematicmgr",
      "az-meup-dev-mbr",
      "meup.schematicmgr"
    ],
  }
  if(adGroups.length === 0) {
    return "meup-admin"
  }
  
  
  for (let i=0; i<adGroups.length;i++) {
    
    
    if(levels.admin.includes(adGroups[i])) {
      userLevel = "meup-admin"
      userLevelAmount = 10
      
    }

    else if(levels.holdUser.includes(adGroups[i]) && userLevelAmount < 1) {
      userLevel = "meup-holduser";
      userLevelAmount = 1;
     
    }


  }
  return userLevel
}