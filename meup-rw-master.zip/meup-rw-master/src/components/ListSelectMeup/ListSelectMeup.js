import React from 'react';
import {Grid, Select} from '@material-ui/core';
function ListSelectMeup(props) {
   
    const handleChange = (event) => {
        const { options } = event.target;
        let values = [];
        for(let i = 0; i<options.length ; i++) {
            if(options[i].selected) {
                
                values.push(options[i].value);
            }
        } 
        props.setValue(values);
        
      };
    
    const handleSelectAll = () => {
        let values = [];
        
        for(let i = 0; i<props.options.length ; i++) {
            
                
                values.push(props.options[i].value);
           
        } 
        
        props.setValue(values)
    }
    return (
        <Grid container>
            <Grid item xs={props.alignItems === "row" ? 4  : 12} style={{display:"flex", alignItems:"center"}}>
                <label className={props.LabelClass}>
                {props.labelInline ? "" : props.label}
                </label>
            </Grid>
            <Grid item xs={props.alignItems === 'row' ? 8 : 12}>
            <Select
                multiple
                native
                value={props.value}
                // @ts-ignore Typings are not considering `native`
                onChange={handleChange}
                label="Native"
                inputProps={{
                    id: "select-multiple-native"
                }}
                className={props.classNameMeup}
                disabled={props.disabled}
            >
                {
                    props.selectAll ? 
                        <option onClick={() => handleSelectAll()}>
                            ---All---
                        </option> : ""
                }
                {props.options.map((option, index) => (
                    <option key={index} value={option.value}>
                        {option.label}
                    </option>
                ))}
    </Select>
            </Grid>
        </Grid>
    )
}

export default ListSelectMeup;