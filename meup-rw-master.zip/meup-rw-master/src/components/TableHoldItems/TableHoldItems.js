import React, { useState, useEffect } from 'react'
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { Radio } from '@material-ui/core';
import Pagination from '@mui/material/Pagination';
import { ArrowUpward, ArrowDownward } from '@material-ui/icons';
import { IconButton } from '@mui/material';

const SortingHeader = ({ column, key, props, activeColumn, setActiveColumn }) => {
    const [direction, setDirection] = useState("");
    useEffect(() => {
        let isActive = true
        if(activeColumn!==column.fieldName && isActive) {
            setDirection("");
        }
        return (() => {
            isActive=false
        })
    }, [activeColumn])
    function handleSort() {
       setActiveColumn(column.fieldName)
        if (direction === "up") {
            setDirection("down");
            
            const data = stableSort(props.data, getComparator('desc', column.fieldName, column.numeric))
            props.setData(data);
        }
        else {
            setDirection("up");
            const data = stableSort(props.data, getComparator('asc', column.fieldName))
            props.setData(data);
        }
    }
    function descendingComparator(a, b, orderBy) {
        const data_a  = column.numeric ? Number(a[orderBy]) : a[orderBy]
        const data_b=  column.numeric ? Number(b[orderBy]) : b[orderBy]
        if (data_b < data_a) {
            return -1;
        }
        if (data_b > data_a) {
            return 1;
        }
        return 0;
    }

    function getComparator(order, orderBy) {
        return order === 'desc'
            ? (a, b) => descendingComparator(a, b, orderBy)
            : (a, b) => -descendingComparator(a, b, orderBy);
    }

    // This method is created for cross-browser compatibility, if you don't
    // need to support IE11, you can use Array.prototype.sort() directly
    function stableSort(array, comparator) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = comparator(a[0], b[0]);
            if (order !== 0) {
                return order;
            }
            return a[1] - b[1];
        });
        return stabilizedThis.map((el) => el[0]);
    }

    return (
        <th rowSpan="2" className={direction === "" ? "headerClassStoreItemCount headerClassStoreItemCountSvg" : "headerClassStoreItemCount"} key={key} onClick={handleSort}>
            <div className="headerClassStoreItemCountSort">
                <div className="text">{column.headerName}</div>
                <div className="icon">
                    <IconButton>
                        {direction === "down" ? <ArrowDownward style={{ fontSize: "0.95rem" }} className="arrowntableHoldItem" /> : <ArrowUpward style={{ fontSize: "0.95rem" }} />   }
                    </IconButton>
                </div>
            </div>
        </th>
    )

}



export default function TableHoldItems(props) {
    
    const rowsPerPage = props.rowsPerPage ? props.rowsPerPage : 10;
    const [activeColumn, setActiveColumn] = useState("")
    const rows = Math.ceil(props.data.length / 10);
    let pages = []
    for (let i = 1; i <= rows; i++) {
        pages.push(i);
    }

    const handleChangePage = (newPage) => {
        props.setCurrPage(newPage);
    };

    const handleToggle = (targetIndex, type) => {
        const newTargetIndex = targetIndex + rowsPerPage * (props.currPage - 1)
        const newData = props.data.map((data, index) => {
            if (index === newTargetIndex) {
                data[type] = true;
                if (type === "accept") {
                    data["hold"] = false;
                    data["reject"] = false
                }
                else if(type === "hold"){
                    data["reject"] = false;
                    data["accept"] = false;
                }
                else if(type==="reject") {
                    data["hold"] = false;
                    data["accept"] = false;
                }
            }
            return data;
        })
        props.setData(newData)
    }

    const handleSelectAll = (type) => {
        const newData = props.data.map((data, index) => {
            if (index < rowsPerPage * props.currPage - rowsPerPage || index >= rowsPerPage * props.currPage) { return data }
            data[type] = true;
            if (type === "accept") {
                data["hold"] = false;
                data["reject"] = false
            }
            else if(type === "hold"){
                data["reject"] = false;
                data["accept"] = false;
            }
            else if(type==="reject") {
                data["hold"] = false;
                data["accept"] = false;
            }
            return data
        })
        props.setData(newData)
    }

    

   


    return (

        <table className="storeItemHoldCountTable" style={{ width: "74.9rem" }}>
            <thead>
                <tr>
                    {
                        props.columns.map((column, index) => (
                            !(column.sorting === false)?
                                <SortingHeader column={column} key={index} props={props} activeColumn={activeColumn} setActiveColumn={setActiveColumn} />
                                :
                                <th rowSpan="2" className="headerClassStoreItemCount" key={index}> <span> {column.headerName}</span> </th>
                        ))
                    }
                    <th colSpan="2" className="headerClassStoreItemCountaccept"> <span> Block </span></th>
                </tr>
                <tr>

                    <th className="headerClassStoreItemCountaccept" colSpan="1">
                        <span> Accept </span> <br />
                        <ButtonMemi
                            btnval="Select All"
                            btnvariant="contained"
                            classNameMemi="StoreItemOnCountButtons"
                            onClick={() => handleSelectAll("accept")}
                            btnsize="small"

                        />


                    </th>
                    {/* <th className="headerClassStoreItemCount" colSpan="1">
                        <span>  </span> <br />
                        <ButtonMemi
                            btnval="Select All"
                            btnvariant="contained"
                            classNameMemi="StoreItemOnCountButtons"
                            onClick={() => handleSelectAll("reject")}
                            btndisabled={true}
                        />


                    </th> */}
                    <th className="headerClassStoreItemCountaccept" colSpan="1">
                        <span> Hold </span> <br />
                        <ButtonMemi
                            btnval="Select All"
                            btnvariant="contained"
                            classNameMemi="StoreItemOnCountButtons"
                            onClick={() => handleSelectAll("hold")}
                            btnsize="small"
                        // onClick={closeTab}
                        />
                    </th>
                </tr>
            </thead>
            <tbody>
                {
                    props.data.filter((data, index) => { return props.currPage * rowsPerPage >= index + 1 && index + 1 > props.currPage * rowsPerPage - rowsPerPage }).map((data, index) => (

                        <tr key={index} className={index % 2 === 0 ? "tableStoreItemHoldStoreCount" : "tableStoreItemHoldStoreCount tableStoreItemHoldStoreCountOddRow"}>
                            {props.columns.map((column, index) => {
                                return <th key={index} style={{ textAlign: "left" }} >
                                    {column.renderCell ? column.renderCell({ row: data, value: data[column.fieldName] }) : data[column.fieldName]}
                                </th>
                            })}



                            <th style={{textAlign:"left"}} className="tableHoldItemsRadio">
                                <Radio
                                    checked={data.accept}
                                    color="default"
                                    onChange={() => handleToggle(index, "accept")}
                                    className="tableHoldItemsRadio"
                                />

                            </th> 
                            {/* <th >
                                <Radio
                                    checked={data.reject}
                                    color="default"
                                    onChange={() => handleToggle(index, "reject")}
                                    disabled
                                />

                            </th> */}
                            <th style={{textAlign:"left"}} className="tableHoldItemsRadio">
                                <Radio
                                    checked={data.hold}
                                    color="default"
                                    onChange={() => handleToggle(index, "hold")}
                                    className="tableHoldItemsRadio"
                                />

                            </th>
                        </tr>



                    ))
                }
            </tbody>
            <tfoot>
                <tr>
                    <th colSpan={20} rowSpan={1} style={{ textAlign: "left"}}>
                        <Pagination count={rows} shape="rounded" onChange={(value, page) => handleChangePage(page)} />
                    </th>
                </tr>
            </tfoot>
        </table>


    )
}
