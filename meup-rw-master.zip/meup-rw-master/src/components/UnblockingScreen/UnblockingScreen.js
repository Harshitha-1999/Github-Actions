
import React, { useEffect, useCallback, useRef, useState } from "react";
import { Grid } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import DropDownMemi from "../DropDownMemi/DropDownMemi";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import Paper from "@material-ui/core/Paper";
import TableMemi from 'components/TableMemi/TableMemi';
import { styled } from '@material-ui/core/styles';

import {
  makeStyles,
  ThemeProvider,
  createTheme,
} from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from "@material-ui/core/Container";
import "../../css/App.css";
import TextFieldMemi from "../TextField/TextFieldMemi";
import CalendarMeup from "../CalendarMeup/CalendarMeup"

function UnblockingScreen(props) {
   
    const Input = styled('input')({
        display: 'none',
      });
  const [vcf, setvcf] = useState("");
  const [pack, setPackType] = useState(" ");
  const [errPack, setErrPack] = useState(false);
  const [errVcf, setErrVcf] = useState(false);

  const [selectedFiles, setSelectedFiles] = useState([]);
  const [privatelabel, setPrivateLabel] = useState(" ");
  const [errPrivateLabel, setErrPrivateLabel] = useState(false);
  const selectFile = (event) => {
    setSelectedFiles(Array.from(event.target.files));
  };

  const [itemsBlocked, setItemsBlocked] = useState()
  let customColumns = [
      {
          field: "SMIC",
          headerName: "SMIC",
          description: "SMIC Column",
          sortable: false,
          width: 88,
      },
      {
          field: "Category",
          headerName: "Category",
          description: "Category Column",
          sortable: false,
          width: 290,
      },
      {
          field: "UPC",
          headerName: "UPC",
          description: "UPC Column",
          sortable: false,
          width: 115,
      },
      {
          field: "Corp Code",
          headerName: "Corp Code",
          description: "Corp Code Column",
          sortable: false,
          width: 140,
      },
      {
          field: "Long Description",
          headerName: "Long Description",
          description: "Comp Code Column",
          sortable: false,
          width: 320,
      },
      {
          field: "Size",
          headerName: "Size",
          description: "Size column",
          sortable: false,
          width: 80,
      },
      {
          field: "UOM",
          headerName: "UOM",
          description: "UOM Column",
          sortable: false,
          width: 86,
      },
      {
          field: "Case Pk",
          headerName: "Case Pk",
          description: "Case Pk Column",
          sortable: false,
          width: 108,
      },
      {
          field: "Blocked On",
          headerName: "Blocked On",
          description: "Blocked On Column",
          sortable: false,
          width: 126,
      },
  ];

  const unblockAction = () => {
      // console.log("some action");
  }
    return (
        
             <Grid container direction="row" spacing={2}>
           <Grid item xs={12} sm={12} md={6} xl={6} lg={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={12} md={4} >
                      <TextFieldMemi
                        LabelClass="labelclassstore"
                        length={15}
                        label="Store Number"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                       
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textFieldup"
                        input="inputup"
                      />
                    </Grid>
                    {/**classNameMemi="drp1" */}
                    <DropDownMemi
                      LabelClass="labelclass1"
                      options={["Type1", "Type2", "Type3", "Type4"]}
                      //label="Pack"
                      alignItems="row"
                      classNameMemi="drpup"
                      value={pack}
                      setValue={(value) => setPackType(value)}
                      error={errPack}
                      setError={(value) => setErrPack(value)}
                      drp="drp1"
                    />
                  
                  </div>
                  
                  <ButtonMemi
                      btncolor="primary"
                      btnval="search"
                      btnvariant="contained"
                      classNameMemi="btnmemiup"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                     <DropDownMemi
                        LabelClass="labelclassupload"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="SMIC"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drpupload"
                      />
                </Grid>
                
                <Grid item xs={12} sm={12} md={6} xl={6} lg={6}>
                    <div className="root8">
               
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Upload File"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                       
                        value={selectedFiles.map((file) => file['name']).join(', ')}
                        error={errVcf}
                        labelLeft={true}
                        TextFieldClass="textFieldupload"
                        input="inputupload"
                      />
                 

                    
                   
                       <label htmlFor="contained-button-file" className="browser">
        <Input  id="contained-button-file" multiple type="file" onChange={selectFile}  />
        <Button variant="contained" color="primary" component="span">
          Browser
        </Button>
      </label>
      <ButtonMemi
                      btncolor="primary"
                      btnval="Upload"
                      btnvariant="contained"
                      classNameMemi="btnmemiupload"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                    
      </div>
      <div className="root8">
      <CalendarMeup meupcal="cal" label="close Date" LabelClass="labelmeup" alignItems="row"/>
      <ButtonMemi
                      btncolor="primary"
                      btnval="Update"
                      btnvariant="contained"
                      classNameMemi="btnmeup"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                    </div>
                </Grid>
              
                <Grid item sm={12} style={{display:"flex", flexDirection:"row"}}>
                <ButtonMemi btnvariant="contained" btnval="Unblock" onClick={unblockAction} btnsize="sm" classNameMemi="unblockButtonClass"/>
                <div className="textFieldBlocked">
                    <TextFieldMemi
                    
                        length={15}
                        label="Total Items Blocked"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={itemsBlocked}
                        fullWidth={false}
                        setTextValue={(value) => setItemsBlocked(value)}
                        type="number"
                        TextFieldClass="textFieldBlockedItems"
                        LabelClass="labelClassBlockedItems"
                        disabled={false}
                        
                    />
                </div>
            </Grid>
            <Grid item sm={12} lg={12} xl={12}>
                <TableMemi
                    data={props.AppData.meup51}
                    classnameMemi="tableMeup"
                    rowheight={40}
                    rowPerPageOptions={props.AppData.meup51.length - 1}
                    selectionType="checkbox"
                    columns={customColumns}
                />
            </Grid>
            
        </Grid>

                
        

    )
}

export default UnblockingScreen;