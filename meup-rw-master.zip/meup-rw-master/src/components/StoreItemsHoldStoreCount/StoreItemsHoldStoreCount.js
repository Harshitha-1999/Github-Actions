import { Grid } from '@material-ui/core';
import React, { useContext, useState } from 'react'
import ApplicationContext from "../../context/ApplicationContext";
import { useHistory } from 'react-router';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { RouteBase } from 'routes/constants';
import TableHoldItems from 'components/TableHoldItems/TableHoldItems';
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';
import { getSelectedRowData } from 'utils';
import { meupServices } from 'api/meup/meupServices';
import App from 'App';

export default function StoreItemsHoldStoreCount(props) {
    const AppData = useContext(ApplicationContext);
    const history = useHistory(); 
    const [currPage, setCurrPage] = useState(1);
    const [errors, setErrors] = useState([props.errors]);
    const [success, setSuccess] = useState("")
    const handleApplyChanges = (e) => {
        e.preventDefault()
        const datarow = getSelectedRowData(AppData.meup62, currPage, 10)
        meupServices.postUpdateHoldStatusStoreLevel(datarow)
            .then((res) => {
              
                if(res.data.status === "SUCCESS") {
                    const data = res.data.data
                    if(data && data.REST_RETURNED_DATA) {
                        setSuccess(data.REST_RETURNED_DATA)
                        let refresh = AppData.meup62.filter((obj) => {

                            for (let i = 0; i<datarow.length; i++) {
                        
                                if(datarow[i].id === obj.id && obj.accept==true) {
                        
                                    return false
                        
                                }
                        
                            }
                        
                            return true
                        
                        })

                      let reset=refresh.map(obj=>({...obj,accept:false,hold:true}))
                      AppData.setMeup62(reset)
                        setErrors([]);
                        
                    }

                }
                
            })
            .catch((error) => {
                setErrors(["An Exception occurred while applying the changes"])
                window.scrollTo(0, 0)
                setSuccess("")
            })
    }

    const columns = [
        {
            fieldName: "stockSectnbr",
            headerName: "Stocking Section #",
            numeric: true,
            sorting:false
           
        },
        {
            fieldName: "oldPogName",
            headerName: "Old Schematic",
            sorting:false
            
        },
        {
            fieldName: "newPogName",
            headerName: "New Schematic",
            sorting:false
        },
        {
            fieldName: "divisionId",
            headerName: "DV",
            numeric: true,
            sorting:false
           
        },
        {
            fieldName: "storeId",
            headerName: "Store #",
            sorting:false,
            renderCell: (params) => {
                return <div
                    className="storeItemStoreLink"
                    onClick={() => history.push(
                        {
                            pathname: RouteBase.MEUP63,
                            state: { stockSectnBr: params.row.stockSectnbr, storeID: params.row.storeId }
                        })}>
                    {params.value}
                </div>
            },
            numeric: true
           
        },
        {
            fieldName: "itemCount",
            headerName: "Item Counts",
            numeric: true,
            sorting:false
        },
    ]
    return (
        <form onSubmit={handleApplyChanges}>
        <Grid container>
            <Grid item xs={12}>
                {
                    errors.length > 0 ? 
                        <div>
                            <ErrorListMeup errors={errors} />
                        </div> :
                        <div className="uploadItemsSuccessMsg"> {success} </div> 

                }

                <TableHoldItems
                    data={AppData.meup62}
                    columns={columns}
                    
                    setData={(data) => AppData.setMeup62(data)}
                    currPage={currPage}
                    setCurrPage={(page) => setCurrPage(page)}
                />
            </Grid>


            <Grid
                item
                xs={12}
                className="blockItemsMarginTop"
                style={{ marginBottom: "1rem" }}
            >


                <ButtonMemi
                    btnval="Apply Changes"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    type="submit"
                    onClick={handleApplyChanges}
                    btnsize="small"

                />

                <ButtonMemi
                    btnval="Search Again"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => history.push(RouteBase.MEUP58)}
                    btnsize="small"
                />
                <ButtonMemi
                    btnval="Cancel"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => history.push(RouteBase.MEUP50)}
                    btnsize="small"

                />
            </Grid>
        </Grid>
    </form>
    )
}
