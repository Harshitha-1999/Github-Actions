import React, {  useState } from "react";
import { Grid } from "@material-ui/core";

import DropDownMemi from "../DropDownMemi/DropDownMemi";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import Paper from "@material-ui/core/Paper";
import {
  makeStyles,
  ThemeProvider,
  createTheme,
} from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from "@material-ui/core/Container";

import TextFieldMemi from "../TextField/TextFieldMemi";
import TextAreaAutosizeMemi from "../TextAreaAutosizeMemi/TextAreaAutosizeMemi";


const useStyles = makeStyles(() => ({
  centeredText: {
    display: "flex",
    justifyContent: "center",
    color: "red",
    fontSize: "1.2rem",
  },
  gridBottomMargin: {
    marginBottom: "3rem",
  },
}));

function AugmentationScreen(props) {
  const classes = useStyles();
  const theme = createTheme();

  const [primaryUpc, setPrimaryUpc] = useState("");
  const [onHand, setOnHand] = useState("");
  const [vcf, setvcf] = useState("");
  const [otb, setotb] = useState("");
  const [dc, setdc] = useState("");
  const [slotId, setSlotId] = useState("");
  const [pack, setPackType] = useState(" ");
  const [privatelabel, setPrivateLabel] = useState(" ");
  const [errPack, setErrPack] = useState(false);
  const [errPrivateLabel, setErrPrivateLabel] = useState(false);
  const [errPrimaryUpc, setErrPrimaryUpc] = useState(false);
  const [errOnHand, setErrOnHand] = useState(false);
  const [errVcf, setErrVcf] = useState(false);
  const [errDc, setErrDc] = useState(false);
  const [errOtb, setErrOtb] = useState(false);

  const [errSlotId, setErrSlotId] = useState(false);
  
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container component="main" maxWidth="xl">
        <Grid container direction="row" spacing={2}>
          <Grid item xs={12} sm={12} md={4} xl={4}>
            <Paper variant="outlined" elevation={12} className="pap srcitem">
              <Typography
                component="p"
                variant="h6"
                align="center"
                className="augheading"
              >
                Source Item
              </Typography>
              <div className="sourceitem">
              <p className="prod">Product SKU </p>
              <p className="prod">Primary UPC </p>
              <p className="prod">Pack </p>
              <p className="prod">VCF </p>
              <p className="prod">Desc Size </p>
              <p className="prod">Num Size</p>
              <p className="prod">Usage</p>
              <p className="prod">Display</p>
              <p className="prod">Item Description</p>
              <p className="prod">Warehouse desc</p>
              <p className="prod">S&S desc </p>
              <p className="prod">Internet Desc</p>
              <p className="prod">Pos Desc</p>
              <p className="prod">Department </p>
              <p className="prod">Product src </p>
              <p className="prod">Cost </p>
              <p className="prod">New Date</p>
              <p className="prod">Last Ship Date </p>
              <p className="prod">Last Sale Date </p>
              <p className="prod">Total Sales</p>
              <p className="prod">Cases ordered</p>
              <p className="prod">One Time Buy Ind </p>
              <p className="prod">Selling Method </p>
              <p className="prod">Receving Method </p>
              <p className="prod">Sells By Days</p>
              <p className="prod">Use By Days</p>
              <p className="prod">Pull BY Days</p>
              <p className="prod">Cost</p>

              <Grid item xs={12} sm={12} md={1} xl={1}>
                    <ButtonMemi
                      btncolor="primary"
                      btnval="Home"
                      btnvariant="contained"
                      classnameMemi="btnmemi1"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={12} md={1} xl={1}>
                    <ButtonMemi
                      btncolor="primary"
                      btnval="Save"
                      btnvariant="contained"
                      classnameMemi="btnmemi1"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                  </Grid>


              </div>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={12} md={8} xl={8}>
            <Paper variant="outlined" elevation={12} className="pap">
              <Typography
                component="h1"
                variant="h6"
                align="center"
                className="augheading"
              >
                Edit Item
              </Typography>
              <Grid container spacing={0}>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Primary Upc"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        
                        value={primaryUpc}
                        error={errPrimaryUpc}
                        setTextValue={(value) => setPrimaryUpc(value)}
                        setError={(value) => setErrPrimaryUpc(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        alignItems="row"
                        label="On Hand"
                        id="On Hand outlined-disabled"
                       
                        value={onHand}
                        error={errOnHand}
                        setTextValue={(value) => setOnHand(value)}
                        setError={(value) => setErrOnHand(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        
                        disabled={true}
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        disabled={true}
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Pack"
                        alignItems="row"
                       
                        value={pack}
                        setValue={(value) => setPackType(value)}
                        error={errPack}
                        setError={(value) => setErrPack(value)}
                        classNameMemi="drp1"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        alignItems="row"
                        label="Slot ID"
                        id="Slot Id outlined-disabled"
                        //disabled
                        value={slotId}
                        error={errSlotId}
                        setTextValue={(value) => setSlotId(value)}
                        setError={(value) => setErrSlotId(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input15"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={12} md={4}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="VCF"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        disabled={true}
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField21"
                        input="input16"
                      />
                    </Grid>
                    <TextFieldMemi
                      length={15}
                      alignItems="col"
                      id="Vcf outlined-disabled"
                      disabled={true}
                      value={vcf}
                      error={errVcf}
                      setTextValue={(value) => setvcf(value)}
                      setError={(value) => setErrVcf(value)}
                      labelLeft={true}
                      input="input20"
                      TextFieldClass="textField20"
                    />
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Private Label"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        drp="drp2"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Desc Size"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Inner Pack"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={12} md={4}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="num size"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        disabled={true}
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField21"
                        input="input16"
                      />
                    </Grid>
                    {/**classNameMemi="drp1" */}
                    <DropDownMemi
                      LabelClass="labelclass1"
                      options={["Type1", "Type2", "Type3", "Type4"]}
                      //label="Pack"
                      alignItems="row"
                      classNameMemi="drp30"
                      value={pack}
                      setValue={(value) => setPackType(value)}
                      error={errPack}
                      setError={(value) => setErrPack(value)}
                      drp="drp1"
                    />
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Ethnic Type Code"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        disabled
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={12} md={4}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Usage Ind & Type"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        disabled={true}
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField21"
                        input="input16"
                      />
                    </Grid>
                    <DropDownMemi
                    classNameMemi="drp31"
                      LabelClass="labelclass1"
                      options={["Type1", "Type2", "Type3", "Type4"]}
                      //label="Pack"
                      alignItems="row"
                      value={pack}
                      setValue={(value) => setPackType(value)}
                      error={errPack}
                      setError={(value) => setErrPack(value)}
                      drp="drp1"
                    />
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Package Type Code"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                       
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={4}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        DropDownClass="dropdown1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Display"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp1"
                      />
                    </Grid>
                    <TextFieldMemi
                        length={15}
                        alignItems="col"
                        id="Vcf outlined-disabled"
                        disabled={true}
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        input="input20"
                        TextFieldClass="textField30"
                      />
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Item Description"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField4"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Warehouse Desc"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField4"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="S & S Desc"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField5"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Internet Desc"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="POS Desc"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField5"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Department"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField2"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Department Name"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Conv Group"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Category"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Product Src"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField2"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Sub Category"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Cost"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField2"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Group"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={4}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="UPCs"
                        classNameMemi="drpdn1"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        drp="drp2"
                      />
                    </Grid>
                    <TextFieldMemi
                      length={15}
                      alignItems="col"
                      id="Vcf outlined-disabled"
                      value={vcf}
                      error={errVcf}
                      setTextValue={(value) => setvcf(value)}
                      setError={(value) => setErrVcf(value)}
                      labelLeft={true}
                      TextFieldClass="textField23"
                      disabled={false}
                      input="input23"
                    />
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={4}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="PLU CODE"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField25"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                    <TextFieldMemi
                      LabelClass="labelclass24"
                      length={15}
                      alignItems="row"
                      label="OTB"
                      id="otb outlined-disabled"
                      value={otb}
                      error={errOtb}
                      setTextValue={(value) => setotb(value)}
                      setError={(value) => setErrOtb(value)}
                      labelLeft={true}
                      TextFieldClass="textField24"
                      disabled={false}
                      input="input24"
                    />
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextAreaAutosizeMemi
                        value={dc}
                        error={errDc}
                        setTextValue={(value) => setdc(value)}
                        setError={(value) => setErrDc(value)}
                        length={15}
                        disabled={false}
                        LabelClass="labelclass1"
                        classNameMemi="textautosize"
                        minrow={5}
                        maxrow={20}
                        label="Dc,Cost&Status"
                        alignItems="row"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={3}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="SSMIC"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField26"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                    <Grid item xs={7} md={3}>
                      <TextFieldMemi
                        length={15}
                        alignItems="row"
                        id="otb outlined-disabled"
                        value={otb}
                        error={errOtb}
                        setTextValue={(value) => setotb(value)}
                        setError={(value) => setErrOtb(value)}
                        labelLeft={true}
                        TextFieldClass="textField27"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                    <Grid item xs={7} md={3}>
                      <TextFieldMemi
                        length={15}
                        alignItems="row"
                        id="otb outlined-disabled"
                        value={otb}
                        error={errOtb}
                        setTextValue={(value) => setotb(value)}
                        setError={(value) => setErrOtb(value)}
                        labelLeft={true}
                        TextFieldClass="textField28"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                    <Grid item xs={7} md={3}>
                      <TextFieldMemi
                        length={15}
                        alignItems="col"
                        id="otb outlined-disabled"
                        value={otb}
                        error={errOtb}
                        setTextValue={(value) => setotb(value)}
                        setError={(value) => setErrOtb(value)}
                        labelLeft={true}
                        TextFieldClass="textField29"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className={classes.centeredText}>SMIC Attributes</div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Group Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Prod Group Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Category Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Prod Category Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Class Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Prod Class Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Sub Class Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={6} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Product Class Code"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={vcf}
                        error={errVcf}
                        setTextValue={(value) => setvcf(value)}
                        setError={(value) => setErrVcf(value)}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={true}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <DropDownMemi
                        LabelClass="labelclass1"
                        options={["Type1", "Type2", "Type3", "Type4"]}
                        label="Sub Sub Class Code"
                        alignItems="row"
                        value={privatelabel}
                        setValue={(value) => setPrivateLabel(value)}
                        error={errPrivateLabel}
                        setError={(value) => setErrPrivateLabel(value)}
                        classNameMemi="drp3"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className={classes.centeredText}>
                    DC Level Attributes
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Description Pack"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        //disabled
                        value={primaryUpc}
                        error={errPrimaryUpc}
                        setTextValue={(value) => setPrimaryUpc(value)}
                        setError={(value) => setErrPrimaryUpc(value)}
                        labelLeft={true}
                        TextFieldClass="textField3"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        alignItems="row"
                        label="Description Size"
                        id="On Hand outlined-disabled"
                       
                        value={onHand}
                        error={errOnHand}
                        setTextValue={(value) => setOnHand(value)}
                        setError={(value) => setErrOnHand(value)}
                        labelLeft={true}
                        TextFieldClass="textField3"
                        input="input14"
                        
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className={classes.centeredText}>ROG Attributes</div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        alignItems="row"
                        //label="Description Size"
                        id="On Hand outlined-disabled"
                       
                        value={onHand}
                        error={errOnHand}
                        setTextValue={(value) => setOnHand(value)}
                        setError={(value) => setErrOnHand(value)}
                        labelLeft={true}
                        TextFieldClass="textField3"
                        input="input14"
                       
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={7} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass3"
                        length={15}
                        alignItems="row"
                        label="Conversion Team Comments"
                        id="On Hand outlined-disabled"
                        
                        value={onHand}
                        error={errOnHand}
                        setTextValue={(value) => setOnHand(value)}
                        setError={(value) => setErrOnHand(value)}
                        labelLeft={true}
                        TextFieldClass="textField3"
                        input="input14"
                        
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={7} md={6}>
                      <span>checkbox component goes here</span>
                    </Grid>
                  </div>
                </Grid>
                <Grid container>
                  <Grid item xs={12} sm={12} md={1} xl={1}>
                    <ButtonMemi
                      btncolor="primary"
                      btnval="Home"
                      btnvariant="contained"
                      classnameMemi="btnmemi1"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={12} md={1} xl={1}>
                    <ButtonMemi
                      btncolor="primary"
                      btnval="Save"
                      btnvariant="contained"
                      classnameMemi="btnmemi1"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                  </Grid>
                  <Grid
                    container
                    xs={12}
                    sm={12}
                    md={10}
                    xl={10}
                    justifyContent="flex-end"
                    className={classes.gridBottomMargin}
                  >
                    <ButtonMemi
                      btncolor="primary"
                      btnval="Save & Next"
                      btnvariant="contained"
                      classnameMemi="btnmemi1"
                      onClick={() => {
                        alert("clicked");
                      }}
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Container>
      <div style={{ height: "1000px" }}></div>
    </ThemeProvider>
  );
}

export default AugmentationScreen;
