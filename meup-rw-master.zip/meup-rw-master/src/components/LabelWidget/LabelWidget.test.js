import React from 'react';
import {render} from "@testing-library/react";
import LabelWidget from './LabelWidget';

describe("<LabelWidget />", () => {

  const defaultProps = {
    controlId : "testLabel",
    label : "Test Label"
  };

  it('Should render without errors', () => {
    const {debug, container} = render(
      <LabelWidget {...defaultProps} />
    )

    expect(container).toBeTruthy();
  })
})