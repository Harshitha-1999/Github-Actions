import React from 'react';
import "./LabelWidget.scss";


export const LabelWidget = ({controlId,label}) => {
    return (
        <React.Fragment>
            <label id={controlId} >
                {label}
            </label>
        </React.Fragment>
    );
}

export default LabelWidget;