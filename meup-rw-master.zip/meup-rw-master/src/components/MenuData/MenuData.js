import {RouteBase} from '../../routes/constants/RouteBase'
export const MEMIMenu = [
    { "id": 1, "label": "Single UPC WHSE", "path": "/MEMI10" },
    { 
        "id": 2, 
        "label": "Multiple UPC WHSE" , 
        "children":[ 
            {
                "id": 4, 
                "label": "Multiple UPC DSD" , 
                "children":[
                        { "id": 4, "label": "Multiple UPC DSD" , "path": "/MEMI5" },
                        { "id": 4, "label": "Multiple UPC DSD" , "path": "/MEMI50" }
                    ]
            }]
    },
    { "id": 5, "label": "Display Items" , "path": "/MEMI11", "children":[
    { "id": 4, "label": "Multiple UPC DSD" , "path": "/MEMI5" },
    { "id": 4, "label": "Multiple UPC DSD" , "path": "/MEMI50" }
] },
    { "id": 3, "label": "Single UPC DSD" , "path": "/MEMI10" },
    { "id": 4, "label": "Multiple UPC DSD" , "path": "/MEMI10" },
    { "id": 5, "label": "Display Items" , "path": "/MEMI10" }
]

export const MEUPMenu = [
    {
        path: `${RouteBase.MEUP51}`,
        label:"Upload Warehouse Items for Blocking"
    
      },
      {
        path: `${RouteBase.MEUP52}`,
        label: 	"Enter Items and Stores for Blocking"
    
      },
      {
        path: `${RouteBase.MEUP53}`,
       label: "Update Store Items"
    
      },
      {
        path: `${RouteBase.MEUP54}`,
        label: "View Store Items Report"
    
      },
]