import React from 'react';
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import { RouteBase } from '../../routes/constants/'
import { Link } from 'react-router-dom';
import routes from "../../routes/routes";

function MenuMeup(props) {

    const getRoutes = () => {
        return routes.filter((route) => route.navigationBar === "yes" && route.navNames.includes("meup") && route.path !== RouteBase.MEUP50)
    }
    return (
        <div>
            <Paper variant="outlined" elevation={0} className="papmeup" >
                <Typography
                    component="h4"
                    variant="h4"
                    align="center"
                    className="menumeup"
                >
                    Menu
                </Typography>

                <ul style={{ listStyle: "none" }}>
                    {
                        getRoutes().map((route, index) => {
                            return (
                                <li key={index} className="list">
                                    <Link to={route.path} className="routelink">
                                        {route.label}
                                    </Link>
                                </li>)

                        })
                    }


                </ul>
            </Paper>
        </div>
    );
}

export default MenuMeup;