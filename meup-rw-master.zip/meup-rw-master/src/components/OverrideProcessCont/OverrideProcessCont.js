import React from "react";
import TableMemi from "components/TableMemi/TableMemi";

import { Grid } from "@material-ui/core";

import Paper from "@material-ui/core/Paper";
import {
 
  ThemeProvider,
  createTheme,
} from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from "@material-ui/core/Container";
import "../../css/App.css";
import TextFieldMemi from "../TextField/TextFieldMemi";



function OverrideProcessCont(props) {
  const theme = createTheme();
  

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container component="main" maxWidth="xl">
        <Grid item xs={12} sm={12} md={12} xl={12}>
          <Paper variant="outlined" elevation={12} className="override">
            <Typography
              component="h1"
              variant="h4"
              align="center"
              className="augheading"
            >
              Like Items
            </Typography>
            <TableMemi
              data={props.AppData.memi14_A}
              classnameMemi="table28"
              rowheight={40}
              rowPerPageOptions={props.AppData.memi14_A.length - 1}
              selectionType="radio"
            />
          </Paper>
        </Grid>
        <Grid container direction="row" spacing={0}>
          <Grid item xs={12} sm={12} md={3} xl={3}>
            <Paper variant="outlined" elevation={12} className="overrideTitle">
              <Typography
                component="h1"
                variant="h4"
                align="center"
                className="augheading"
              >
                Source Data Review
              </Typography>
              <div style={{ height: "400px" }}></div>
            </Paper>
          </Grid>
          <Grid item xs={12} sm={12} md={9} xl={9}>
            <Paper variant="outlined" elevation={12} className="override">
              <Typography
                component="h1"
                variant="h4"
                align="center"
                className="augheading"
              >
                Borrow CIC Attributes
              </Typography>
              <Grid container spacing={0}>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Primary Upc"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={6} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        length={15}
                        label="Item Description"
                        alignItems="row"
                        id="Vcf outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setvcf(value)
                        setTextValue={""}
                        //(value) => setErrVcf(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField4"
                        disabled={false}
                        input="input16"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="WHSE Desc"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField2"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="True DSD"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={7} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="S & S Desc"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField3"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Internet Desc"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField5"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={7} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="POS Desc"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField2"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={12} xl={12}>
                  <div className="root8">
                    <Grid item xs={7} md={6}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Case UPC"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Pack"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Inner Pack"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      {/*<TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Inner Pack"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />*/}
                    </Grid>
                  </div>
                </Grid>
                <Grid item xs={12} sm={12} md={6} xl={6}>
                  <div className="root8">
                    <Grid item xs={7} md={12}>
                      <TextFieldMemi
                        LabelClass="labelclass1"
                        alignItems="row"
                        label="Desc Size"
                        length={15}
                        id="Primary Upc outlined-disabled"
                        value={""}
                        error={""}
                        //(value) => setPrimaryUpc(value)
                        setTextValue={""}
                        //(value) => setErrPrimaryUpc(value)
                        setError={""}
                        labelLeft={true}
                        TextFieldClass="textField1"
                        disabled={false}
                        input="input13"
                      />
                    </Grid>
                  </div>
                </Grid>
              </Grid>
              <div style={{ height: "400px" }}></div>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </ThemeProvider>
  );
}

export default OverrideProcessCont;
