import React, { useContext, useEffect } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import "./ApplicationData.scss";
import ApplicationContext from "../../context/ApplicationContext";
import { Button, Grid, TextField, Paper } from "@material-ui/core";
import { v4 as uuidv4 } from "uuid";
import {
  dataAxios,
  userInfoAxios,
  lastSearchAxios,
  MEMI01Axios,
 
  configurationSetsAxios,
  configurationVarsAxios,
} from "../../api/memiuAxiosInstances/memiuAxiosInstances";



const validationSchema = Yup.object().shape({
  name: Yup.string().min(3, "It's too short").required("Required"),
  email: Yup.string().email("Enter valid email").required("Required"),
});
const initialValues = {
  name: "",
  email: "",
};




function ApplicationData() {
  const AppData = useContext(ApplicationContext);
  const paperStyle = {
    border: "1px solid grey",
    padding: 20,
    width: "80%",
    margin: "50px auto",
  };

  useEffect(() => {
    dataAxios.get("/").then((res) => {
      AppData.setData(res.data);
    });

    userInfoAxios.get("/").then((res) => {
      AppData.setUserInfo(res.data);
    });

    lastSearchAxios.get("/").then((res) => {
      AppData.setLastSearch(res.data);
    });

    MEMI01Axios.get("/").then((res) => {
      AppData.setMemi01(res.data);
    });

    configurationSetsAxios.get("/").then((res) => {
      AppData.setConfigurationSets(res.data);
    });


//////////////configurationVarsAxios//////////////////////////////////////////////////
    configurationVarsAxios.get("/").then((res) => {
      
      //get the last token and print to console
      //intercept and set the time in the lastTokenRefresh before setting the data.
      var lastToken = res.data.filter(function (el) {
        return el.name === 'lastTokenRefresh';
      });   
      console.log('lastToken');
      console.log(lastToken);
      var currentTime = new Date();
      res.data[0].value=currentTime.getTime();
      // console.log("currentTime from value;");
      // console.log(new Date(res.data[0].value));
      // sets the new time 
      AppData.setConfigurationVars(res.data);
    });
////////////configurationVarsAxios///////////////////////////////////////////////////////





  });

  const onSubmit = (values, props) => {
    setTimeout(() => {
      props.resetForm();
      props.setSubmitting(false);
    }, 2000);
    props.setSubmitting(true);
    const user = {
      username: values.name,
      email: values.email,
      id: uuidv4(),
    };
    AppData.addUserInfo(user);
    userInfoAxios.post("/", user);
  };



  
  return (
    <>
      <Paper elevation={3} style={paperStyle}>
        <Grid align="center">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {(props) => (
              <Form>
                <Grid container spacing={3}>
                  <Grid item md={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      name="name"
                      label="Username"
                      placeholder="Enter your username"
                      helperText={<ErrorMessage name="name" />}
                    />
                  </Grid>
                  <Grid item md={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      name="email"
                      label="Email"
                      placeholder="Enter your email"
                      helperText={<ErrorMessage name="email" />}
                    />
                  </Grid>
                </Grid>
                <Grid>
                  <Grid
                    item
                    xs="auto"
                    style={{
                      display: "flex",
                      justifyContent: "flex-start",
                      marginTop: "10px",
                    }}
                  >
                    <Button
                      type="submit"
                      color="primary"
                      variant="contained"
                      disabled={props.isSubmitting}
                    >
                      {props.isSubmitting ? "Loading" : "Submit"}
                    </Button>
                  </Grid>
                </Grid>
              </Form>
            )}
          </Formik>
        </Grid>
      </Paper>

      <Paper elevation={3} style={paperStyle}>
        <h2 className="AppTitle">Global Application Context Data</h2>
        <div>
          <h2 className="AppTitle">Configuration Vars</h2>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>Configuration Vars</th>
                </tr>
              </thead>
              <tbody>
                {AppData.configurationVars.map((d) => {
                  return (
                    <tr key={d.id}>
                                            <td>{d.name}=</td>
                                            <td>{d.value} </td>

                      <td> {d.description}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </Paper>




      <Paper elevation={3} style={paperStyle}>
        <h2 className="AppTitle">Global Application Context Data</h2>
        <div>
          <h2 className="AppTitle">Configuration Sets</h2>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>Configuration Sets</th>
                </tr>
              </thead>
              <tbody>
                {AppData.configurationSets.map((d) => {
                  return (
                    <tr key={d.id}>
                      <td>{d.description}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </Paper>


      <Paper elevation={3} style={paperStyle}>
        <h2 className="AppTitle">Global Application Context Data</h2>
        <div>
          <h2 className="AppTitle">Configuration Sets</h2>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>Configuration Sets</th>
                </tr>
              </thead>
              <tbody>
                {AppData.configurationSets.map((d) => {
                  return (
                    <tr key={d.id}>
                      <td>{d.description}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <h2 className="AppTitle">USER INFORMATION</h2>
        <div>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>USERNAME</th>
                  <th></th>
                  <th>EMAIL</th>
                </tr>
              </thead>
              <tbody>
                {AppData.userInfo.map((d) => {
                  return (
                    <tr key={d.id}>
                      <td>{d.username}</td>
                      <td></td>
                      <td>{d.email}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <h2 className="AppTitle">LASTSEARCH</h2>
        <div>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>FIRSTNAME</th>
                  <th></th>
                  <th>LASTNAME</th>
                  <th></th>
                  <th>AGE</th>
                </tr>
              </thead>
              <tbody>
                {AppData.lastSearch.map((d) => {
                  return (
                    <tr key={d.id}>
                      <td>{d.firstName}</td>
                      <td></td>
                      <td>{d.lastName}</td>
                      <td></td>
                      <td>{d.age}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        <h2 className="AppTitle">MEMI01</h2>
        <div>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>NAME</th>
                  <th></th>
                  <th>ID</th>
                </tr>
              </thead>
              <tbody>
                {AppData.memi01.map((d) => {
                  return (
                    <tr key={d.id}>
                      <td>{d.Name}</td>
                      <td></td>
                      <td>{d.id}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ height: "1000px" }}></div>
        </div>
      </Paper>



    </>
  );
}
export default ApplicationData;
