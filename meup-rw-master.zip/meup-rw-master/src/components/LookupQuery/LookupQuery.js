
import React, { useState } from "react";
import { Grid } from "@material-ui/core";

import DropDownMemi from '../DropDownMemi/DropDownMemi';



import TextFieldMemi from '../TextField/TextFieldMemi';
import ButtonMemi from '../ButtonMemi/ButtonMemi'

function LookupQuery(props) {

  const [productSKU, setProductSKU] = useState('');
  const [productHierarchy, setProductHierarchy] = useState('');
  const [productHierarchyLevel, setProductHierarchyLevel] = useState('');
  const [productHierarchyLevel2, setProductHierarchyLevel2] = useState('');
  const [productHierarchyLevel3, setProductHierarchyLevel3] = useState('');
 
  const [productName, setProductName] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [supplierNumber, setSupplierNumber] = useState('');
  const [productCategory, setProductCategory] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [age, setAge] = useState(' ');
  const [productType, setProductType] = useState(' ');
  const [department, setDepartmentType] = useState(' ');
  const [itemsets, setItemSets] = useState(' ');
  const [errProductSKU, setErrProductSKU] = useState(false);
  const [errProductHierarchy, setErrProductHierarchy] = useState(false);
  const [errProductHierarchyLevel2, setErrProductHierarchyLevel2] = useState(false);
  const [errProductHierarchyLevel3, setErrProductHierarchyLevel3] = useState(false);

  const [errProductHierarchyLevel, setErrProductHierarchyLevel] = useState(false);
  const [errProductName, setErrProductName] = useState(false);
  const [errSupplierName, setErrSupplierName] = useState(false);
  const [errSupplierNumber, setErrSupplierNumber] = useState(false);
  const [errProductCategory, setErrProductCategory] = useState(false);
  const [errProductDesc, setErrProductDesc] = useState(false);
  const [errAge, setErrorAge] = useState(false);
  const [errDepartment, setErrorDepartment] = useState(false);
  const [errItemSets, setErrorItemSets] = useState(false);
  const [errProductType, setErrorProductType] = useState(false);


  const validateData1 = () => {

    if (
      !errProductHierarchy &&
      !errProductSKU &&
      !errProductHierarchyLevel &&
      !errProductHierarchyLevel2 &&
      !errProductHierarchyLevel3 &&
    
      !errProductName &&
      !errSupplierName &&
      !errSupplierNumber &&
      !errProductCategory &&
      !errProductDesc &&
      productSKU.length >= 10 &&
      productHierarchy.length >= 10 &&
      productHierarchyLevel.length >= 10 &&
      productHierarchyLevel2.length >= 10 &&
      productHierarchyLevel3.length >= 10 &&
      
      productName.length >= 10 &&
      supplierNumber.length >= 10 &&
      supplierName.length >= 10 &&
      productCategory.length >= 8 &&
      setProductDesc.length >= 15

    ) {
setErrorDepartment(false)
setErrorItemSets(false)
setErrorProductType(false)
setErrorAge(false)

      
    } else {
      productSKU.length < 10 ? setErrProductSKU(true) : setErrProductSKU(false);
      productHierarchy.length < 10 ? setErrProductHierarchy(true) : setErrProductHierarchy(false);
      productHierarchyLevel.length < 10 ? setErrProductHierarchyLevel(true) : setErrProductHierarchyLevel(false);
      productHierarchyLevel2.length < 10 ? setErrProductHierarchyLevel2(true) : setErrProductHierarchyLevel2(false);
      productHierarchyLevel3.length < 10 ? setErrProductHierarchyLevel3(true) : setErrProductHierarchyLevel3(false);
     
      productName.length < 10
        ? setErrProductName(true)
        : setErrProductName(false);
        supplierNumber.length < 10
        ? setErrSupplierNumber(true)
        : setErrSupplierNumber(false);
        supplierName.length < 10
        ? setErrSupplierName(true)
        : setErrSupplierName(false);
      productCategory.length < 8
        ? setErrProductCategory(true)
        : setErrProductCategory(false);
      setProductDesc.length < 15
        ? setErrProductDesc(true)
        : setErrProductDesc(false);
      age === ' ' ? setErrorAge(true) : setErrorAge(false);
      productType === ' '
        ? setErrorProductType(true)
        : setErrorProductType(false);
      itemsets === ' ' ?
        setErrorItemSets(true)
        : setErrorItemSets(false);
      department === '' ? setErrorDepartment(true) : setErrorDepartment(false)
      

    }

  };
  
 

  return (
    
          <Grid container spacing={0} className="pap">
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi LabelClass="lookuplabel" label='Product Sku' length={5} id="Product SKU" variant="outlined" value={productSKU} error={errProductSKU} setTextValue={value => setProductSKU(value)} setError={value => setErrProductSKU(value)}
                TextFieldClass="textFieldproductsku"
                input="input1"/>
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <DropDownMemi DropDownClass="departmentdrop" LabelClass="lookuplabel" label="Department" alignItems="column" options={['Type1', 'Type2', 'Type3', 'Type4']} value={department} setValue={value => setDepartmentType(value)} error={errDepartment} setError={(value) => setErrorDepartment(value)} />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi label='UPC'LabelClass="lookuplabel"  TextFieldClass="textFieldproductupc" length={10} id="Product Name" value={productName} error={errProductName} setTextValue={value => setProductName(value)} setError={value => setErrProductName(value)}textField="textField1" input="input2"   />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <DropDownMemi DropDownClass="itemsetdrop"LabelClass="lookuplabel"  label={'Item Sets'} options={['Type1', 'Type2', 'Type3', 'Type4']} value={itemsets} setValue={value => setItemSets(value)} error={errItemSets} setError={(value) => setErrorItemSets(value)}  />
              </div>
            </Grid>
            <Grid item xs={12} sm={3} md={4} xl={4}>
              <div className="root7">
                <TextFieldMemi TextFieldClass="textFielditemdesc" LabelClass="lookuplabel" label="Item Description" length={15} id="Product Name" value={productDesc} error={errProductDesc} setTextValue={value => setProductDesc(value)} setError={value => setErrProductDesc(value)} textField="textField" input="input3"/>
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi TextFieldClass="textFieldsuppliername" LabelClass="lookuplabel" length={8} id="Product Category" label="Supplier Name" value={productCategory} error={errProductCategory} setTextValue={value => setProductCategory(value)} setError={value => setErrProductCategory(value)} textField="textField" input="input4" />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi TextFieldClass="textFieldsuppliernumber" LabelClass="lookuplabel" label="Supplier Number" length={10} id="Product Name" value={supplierNumber} error={errSupplierNumber} setTextValue={value => setSupplierNumber(value)} setError={value => setErrSupplierNumber(value)} textField="textfield" input="input12" />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi TextFieldClass="textFieldplu" label="PLU" LabelClass="lookuplabel" length={10} id="Product Name" value={supplierName} error={errSupplierName} setTextValue={value => setSupplierName(value)} setError={value => setErrSupplierName(value)} textField="textField" input="input5" />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <DropDownMemi DropDownClass="conversiondrop" label='Conversion Status' LabelClass="lookuplabel" options={[20, 21, 22]} value={age} setValue={value => setAge(value)} error={errAge} setError={(value) => setErrorAge(value)}  />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi TextFieldClass="textFieldcorpitemcode" LabelClass="lookuplabel" label="Corp Item Code" length={25} id="Product Hierarchy" variant="outlined" value={productHierarchy} error={errProductHierarchy} setTextValue={value => setProductHierarchy(value)} setError={value => setErrProductHierarchy(value)} textField="textField" input="input6" />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <DropDownMemi DropDownClass="supplytypedrop" LabelClass="lookuplabel" label='Supply Type' options={['Type1', 'Type2', 'Type3', 'Type4']} value={productType} setValue={value => setProductType(value)} error={errProductType} setError={(value) => setErrorProductType(value)}/>
              </div>
            </Grid>
            
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root1">
                <TextFieldMemi TextFieldClass="textFieldhierarcyname" LabelClass="lookuplabel" label="Product Hierarchy Name" length={25} id="Product Hierarchy" variant="outlined" value={productHierarchy} error={errProductHierarchy} setTextValue={value => setProductHierarchy(value)} setError={value => setErrProductHierarchy(value)} textField="textField" input="input6" />
              </div>
            </Grid>
            
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root3">
                <TextFieldMemi  TextFieldClass="textFieldhierarcylevel" LabelClass="lookuplabel"  label="Hierarchy Level" length={25} placeholderMemi="Level1" id="Product Hierarchy Level" variant="outlined" value={productHierarchyLevel} error={errProductHierarchyLevel} setTextValue={value => setProductHierarchyLevel(value)} setError={value => setErrProductHierarchyLevel(value)} defaultValue="Level1" textField="textField" input="input7" />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root4">
                <TextFieldMemi length={25} TextFieldClass="textFieldhierarcylevel2" placeholderMemi="Level2" id="Product Hierarchy Level2" variant="outlined" value={productHierarchyLevel2} error={errProductHierarchyLevel2} setTextValue={value => setProductHierarchyLevel2(value)} setError={value => setErrProductHierarchyLevel2(value)} defaultValue="Level2" textField="textField" input="input8"/>
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root12">
                <TextFieldMemi length={25}
                  placeholderMemi="Level3" TextFieldClass="textFieldhierarcylevel3"  id="Product Hierarchy Level 3" variant="outlined" value={productHierarchyLevel3} error={errProductHierarchyLevel3} setTextValue={value => setProductHierarchyLevel3(value)} setError={value => setErrProductHierarchyLevel3(value)} placeholder="Level3" textField="textField" input="input9"  />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root13">
                <TextFieldMemi length={25} TextFieldClass="textFieldhierarcylevel4" placeholderMemi="Level4" id="Product Hierarchy Level 3" variant="outlined" value={productHierarchyLevel3} error={errProductHierarchyLevel3} setTextValue={value => setProductHierarchyLevel3(value)} setError={value => setErrProductHierarchyLevel3(value)} placeholder="Level3" textField="textField" input="input10" />
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={2} xl={2}>
              <div className="root14">
                <TextFieldMemi length={25} TextFieldClass="textFieldhierarcylevel5" placeholderMemi="Level5" id="Product Hierarchy Level 3" variant="outlined" value={productHierarchyLevel3} error={errProductHierarchyLevel3} setTextValue={value => setProductHierarchyLevel3(value)} setError={value => setErrProductHierarchyLevel3(value)} placeholder="Level3" textField="textField" input="input11"  />
              
              
              </div>
              <ButtonMemi btnvariant="contained" btnval ="Sort" classNameMemi="lookupSort" />
                 
                <ButtonMemi btnvariant="contained"  btnval ="Apply" btncolor="primary" onClick={validateData1} classNameMemi="lookupApply"/>
                  
               
                <ButtonMemi btnvariant="contained"  btnval ="Cancel All" btncolor="primary" classNameMemi="lookupCancel"/>
                 
                
                <ButtonMemi btnvariant="contained"  btnval ="Reset All" btncolor="secondary" classNameMemi="lookupReset"/>
                  
               
            </Grid>
            
            <Grid item xs={12} sm={2} md={1} xl={3}>
              <div className="roo">
               
                
              </div>
            </Grid>
            <Grid item xs={12} sm={2} md={1} xl={3}>
              <div className="roo">
               
                
              </div>
            </Grid>
          </Grid>
        
  );
}

export default LookupQuery