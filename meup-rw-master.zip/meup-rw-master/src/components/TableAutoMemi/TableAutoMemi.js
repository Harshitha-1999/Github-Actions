import React from "react";
import { makeStyles} from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import { DataGrid } from "@mui/x-data-grid";

import "../../css/App.css";
//Generic Table
const useStyles = makeStyles((theme) => ({
  root: {
    "& .super-app.positive": {
      color: "#50C878",
      fontWeight: "600",
    },
  },
  root1: {
    "& > *": {
      margin: theme.spacing(3),

      width: "40ch",
    },
  },
}));

function TableAutoMemi(props) {
  // console.log("AutoTableMemi props.data: ", props.data);

  const { columns, rowsPerPage } = props;

  const classes  = useStyles(); 

  return (
    <Grid
      container
      spacing={2}
      direction="row"
      justifyContent="flex-start"
      alignItems="flex-start"
    >
      <Grid item xs={12}>
        <div style={{ height: 400, width: "100%" }} className={classes.root}>
          <DataGrid
            rows={props.data}
            className={props.classnameMemi}
            rowHeight={props.rowheight}
            columns={columns}
            pageSize={10}
            rowsPerPageOptions={rowsPerPage}
            checkboxSelection
            disableSelectionOnClick
          />
        </div>
      </Grid>
    </Grid>
  );
}

export default TableAutoMemi;
