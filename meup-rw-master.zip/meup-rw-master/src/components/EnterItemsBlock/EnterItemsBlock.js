import React, { useContext } from 'react';
import { Grid } from "@material-ui/core";
import { useHistory } from 'react-router-dom';

import TableMemi from "../TableMemi/TableMemi";
import ButtonMemi from "../ButtonMemi/ButtonMemi"
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';
import { RouteBase } from 'routes/constants';
import ApplicationContext from "../../context/ApplicationContext";

// var itemsToBlockArray = [];

function EnterItemsBlock(props) {

  const history = useHistory();
  // const location = useLocation();
  const AppData = useContext(ApplicationContext);

  const meup57Res = AppData.meup52BlockItemsAndStores !== undefined ? AppData.meup52BlockItemsAndStores : "";

  let columns = [

    {
      field: "cicupc",
      headerName: "Item CIC/UPC",
      sortable: true,
      width: 240,
      headerAlign: "center",
      headerClassName: "headerStoreItemHistory"
    },
    {
      field: "storeNo",
      headerName: "Store",
      sortable: true,
      width: 231,
      headerAlign: "center",
      headerClassName: "headerStoreItemHistory"
    },
    {
      field: "errorMessage",
      headerName: "Reason",
      sortable: true,
     width: 240,
      headerAlign: "center",
      headerClassName: "headerStoreItemHistory"
    }
  ];

  let meup57Array = [];

  if (meup57Res[0] !== "" && meup57Res[0] !== undefined) {

    meup57Array = meup57Res[0].map((value, index) => {
      return {
        id: index, cicupc: value.cicupc, storeNo: value.storeNo, errorMessage: value.errorMessage
      };
    });

  }


  return (

    <Grid container>
      {/* {console.log(meup57Res[1])} */}

      <Grid item xs={12}>
        {<ErrorListMeup
          errors={[meup57Res[1]]} />}
      </Grid>
      <Grid container style={{ height: "100%", width: "45rem" }}>
        <TableMemi
        data={meup57Array}
        columns={columns}
        classnameMemi="tableStoreItemHistory"
        showCellRightBorder={true}
        showColumnRightBorder={true}
        hideFooterPagination={true}
        hideFooterSelectedRowCount={true}
        autoHeight
        density="compact"
      />

    </Grid>
    <Grid item xs={12} style={{ marginBottom: "1rem" }}>

      <ButtonMemi
        btnval="Main Menu"
        btnvariant="contained"
        classNameMemi="btnmemiupload"
        onClick={() => history.push(RouteBase.MEUP50)}
      />


      <ButtonMemi
        btnval="Block Another Item"
        btnvariant="contained"
        classNameMemi="btnmemiupload blockItemsButtonMarginLeft"
        onClick={() => history.push(RouteBase.MEUP52)}

      />
    </Grid>
    </Grid >

  );
}

export default EnterItemsBlock;
