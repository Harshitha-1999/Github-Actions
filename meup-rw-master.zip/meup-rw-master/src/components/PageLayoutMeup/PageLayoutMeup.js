import React, { useContext, useEffect } from "react";
import { Grid } from "@material-ui/core";
// import { Environment } from '../../utils';

import ApplicationContext from "../../context/ApplicationContext";
import { RouteBase } from "routes/constants";
import { initialState } from "providers";
import LoaderMeup from "components/LoaderMeup/LoaderMeup";


export default function PageLayoutMeup(props) {
  // console.log("Environment.getAppName()");
  // console.log(Environment.getAppName());
  const AppData = useContext(ApplicationContext)
  const { pathname } = window.location
  const { MEUP50 } = RouteBase

  
  useEffect(() => {
    if (pathname === MEUP50) {
      AppData.resetApplicationContext(initialState)
    }
    AppData.setLoader(0);
  }, [MEUP50, pathname])


  return (
    <Grid container style={{ marginTop: "1px", border: "1px solid" }} >
      <Grid item xs={12} className="pageLayoutContentGridMeup">
        <Grid item xs={12} className="contentOutlineMeup">
          <LoaderMeup />
          <Grid item sm={12}>
            {props.header}
          </Grid>
          {/* <Grid item sm={1} style={{ marginTop: "15px", fontSize: "22px" }}>
              {Environment.getAppName()}
            </Grid> */}
          <br />
          <Grid className={"containerBorder"} container>
            <Grid item sm={12} >
              {/* { <NavigationBarMeup/> } */}
              {props.mainContentMeup}
            </Grid>
            <Grid item sm={12} component="footer">
              {props.footerMeup}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  )
};
