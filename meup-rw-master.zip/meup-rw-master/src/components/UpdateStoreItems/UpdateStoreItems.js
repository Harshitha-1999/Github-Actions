import React, { useState, useEffect, useContext } from "react";

import { Grid } from "@material-ui/core";
import { useHistory } from "react-router-dom";
// import { MEUP_APIs } from "../../service/apiUrls";
import { DateUtility } from "utils";
import {
  validateCicUpcStore,
  formatDate,
  generateUserLevel,
} from "../CommonFunctionsMeup/CommonFunctionsMeup";
import { RouteBase } from "routes/constants";
import { meupServices } from "./../../api/meup/meupServices";
// import { ApiMemi } from "../../components/ApiCallsMemi/ApiCallsMemi";
import CalendarMeup from "components/CalendarMeup/CalendarMeup";
// import { meupServices } from "../../api/meup/meupServices";

import ApplicationContext from "../../context/ApplicationContext";
import RadioMemi from "components/RadioMemi/RadioMemi";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ListSelectMeup from "components/ListSelectMeup/ListSelectMeup";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";
import TextFieldMemi from "components/TextField/TextFieldMemi";
import { authTokenCookie } from "utils";
import { usePersistState } from "hooks/usePersistState";

function UpdateStoreItems(props) {
  const history = useHistory();
  const AppData = useContext(ApplicationContext);
  const userId = authTokenCookie().userId ? authTokenCookie().userId : "";
  const userRole = generateUserLevel();
  const [optionSearch, setOptionSearch] = usePersistState(
    "Unblock",
    "radioVal"
  );
  const [country, setCountry] = useState("001");
  const [selectedDivisions, setSelectedDivisions] = usePersistState(
    [],
    "meup59selectedDivisions"
  );
  const [selectedGroups, setSelectedGroups] = usePersistState(
    [],
    "meup59selectedGroups"
  );
  const [selectedCategories, setSelectedCategories] = usePersistState(
    [],
    "meup59selectedCategories"
  );
  const [cic, setCic] = usePersistState("", "meup59cic");
  const [upc, setUpc] = usePersistState("", "meup59upc");
  const [store, setStore] = usePersistState("", "meup59store");
  const [deleteDateTo, setDeleteDateTo] = usePersistState(
    null,
    "meup59deleteDateTo"
  );
  const [deleteDateFrom, setDeleteDateFrom] = usePersistState(
    null,
    "meup59deleteDateFrom"
  );
  const [state, setState] = usePersistState("", "meup59state");
  /*  const [selectedDivisions, setSelectedDivisions] = useState([]);
  const [selectedGroups, setSelectedGroups] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [cic, setCic] = useState("");
  const [upc, setUpc] = useState("");
  const [store, setStore] = useState("");
  const [deleteDateTo, setDeleteDateTo] = useState(null);
  const [deleteDateFrom, setDeleteDateFrom] = useState(null); */

  const [errors, setErrors] = useState([]);
  const [errorCic, setErrorCic] = useState(false);
  const [errorUpc, setErrorUpc] = useState(false);
  const [errorStore, setErrorStore] = useState(false);

  useEffect(() => {
    // AppData.addLoader(1)
    meupServices
      .getDivisionListForUSMEUP53(country)
      .then((res) => {
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispDivision, value: data.divisionNumber };
        });
        AppData.setMeup53Divisions(data);
        // AppData.addLoader(-1)
      })
      .catch((error) => {
        // AppData.addLoader(-1)
        AppData.setMeup53Groups([]);
        AppData.setMeup53CategoryList([]);
      });
  }, [country]);

  const onChangeDivision = (val) => {
    setSelectedDivisions(val);
    setSelectedCategories([]);
    AppData.setMeup53CategoryList([]);
    setSelectedGroups([]);
    AppData.setMeup53Groups([]);
    // AppData.addLoader(1)
    // http://localhost:8080/meup/v1/groups?corp=001&divisionNumbers=05
    meupServices
      .getGroupListForDivision(country, val)
      .then((res) => {
        // AppData.addLoader(-1)
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispGroup.trim(), value: data.groupCd };
        });
        AppData.setMeup53Groups(data);
      })
      .catch((error) => {
        // AppData.addLoader(-1)
        AppData.setMeup53Groups([]);
      });
  };
  /* useEffect(() => {
    setSelectedCategories([]);
    AppData.setMeup53CategoryList([]);
    setSelectedGroups([]);
    AppData.setMeup53Groups([]);
    // http://localhost:8080/meup/v1/groups?corp=001&divisionNumbers=05
    meupServices
      .getGroupListForDivision(country, selectedDivisions)
      .then((res) => {
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispGroup.trim(), value: data.groupCd };
        });
        AppData.setMeup53Groups(data);
      })
      .catch((error) => {
        AppData.setMeup53Groups([]);
      });
  }, [selectedDivisions]); */
  const onChangeGroup = (val) => {
    setSelectedGroups(val);
    // AppData.addLoader(1)
    // http://localhost:8080/meup/v1/categories?corp=001&groupCds=01
    meupServices
      .getCategoryListForGroup(country, val)
      .then((res) => {
        // AppData.addLoader(-1)
        let finalData = res.data.data.REST_RETURNED_DATA;
        const data = finalData.map((data) => {
          return { label: data.dispCategory.trim(), value: data.categoryCd };
        });
        AppData.setMeup53CategoryList(data);
      })
      .catch((error) => {
        // AppData.addLoader(-1)
        AppData.setMeup53CategoryList([]);
      });
  };
  /*  useEffect(() => {
    if (selectedGroups.length > 0) {
      // http://localhost:8080/meup/v1/categories?corp=001&groupCds=01
      meupServices
        .getCategoryListForGroup(country, selectedGroups)
        .then((res) => {
          let finalData = res.data.data.REST_RETURNED_DATA;
          const data = finalData.map((data) => {
            return { label: data.dispCategory.trim(), value: data.categoryCd };
          });
          AppData.setMeup53CategoryList(data);
        })
        .catch((error) => {
          AppData.setMeup53CategoryList([]);
        });
    } else {
      console.log(selectedGroups);
    }
  }, [selectedGroups]); */
  const onChangeCategory = (value) => {
    setSelectedCategories(value);
    setCic("");
    setUpc("");
  };

  const handleSubmit = (e) => {
    e.preventDefault()
    let errorList = [];
    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);

    console.log(deleteDateFrom < deleteDateTo);
    if (
      selectedDivisions.length === 0 &&
      selectedCategories.length === 0 &&
      selectedGroups.length === 0 &&
      cic === "" &&
      upc === "" &&
      store === "" &&
      deleteDateTo === null &&
      deleteDateFrom === null && state === ""
    ) {
      errorList.push(
        "Please specify at least one parameter other than Country"
      );
    }
    else if (deleteDateTo === null && deleteDateFrom !== null) {
      alert("Please enter 'To' Date");
      document.getElementById("storeItemTo").focus();
      return;
    } else if (deleteDateFrom === null && deleteDateTo !== null) {
      alert("Please enter 'From' Date");
      document.getElementById("storeItemFrom").focus();
      return;
    }

    else if (DateUtility.compareDates(deleteDateTo, deleteDateFrom, "<=") &&  deleteDateTo  && deleteDateFrom) {
      alert("'To' date should be greater than 'From' date");
      setDeleteDateTo(null)
      setDeleteDateFrom(null)
      return;
    }

    else if ((!DateUtility.validateDate(deleteDateTo) && !(deleteDateTo == null)) || (!DateUtility.validateDate(deleteDateFrom) && !(deleteDateFrom == null))) {
      alert("The date entry is not in an acceptable format.\n \n  You can enter date only in the following format: mm/dd/yyyy.")
      return;
    }



    else {
      validateCicUpcStore(
        "CIC",
        cic,
        7,
        (error) => setErrorCic(error),
        errorList
      );
      validateCicUpcStore(
        "UPC",
        upc,
        10,
        (error) => setErrorUpc(error),
        errorList
      );
      validateCicUpcStore(
        "Store number",
        store,
        4,
        (error) => setErrorStore(error),
        errorList
      );
    }

    if (errorList.length === 0) {
      // AppData.addLoader(1)
      meupServices
        .getAllItems(
          userId,
          country,
          selectedDivisions,
          selectedGroups,
          selectedCategories,
          cic,
          store,
          upc,
          deleteDateTo ? formatDate(deleteDateTo) : "",
          deleteDateFrom ? formatDate(deleteDateFrom) : "",
          state
        )
        .then((res) => {
          // AppData.addLoader(-1)
          let finalData = res.data.data.REST_RETURNED_DATA.map((data, index) => { return { ...data, id: index } });
          AppData.setOptionSearch(optionSearch);
          //to retrieve value use AppData.radioVal;
          if (optionSearch === "Unblock") {
            AppData.setUnblockResponse(finalData);
            if (finalData.length == 0) {
              setErrors(['No result found'])
            }
            else {
              history.push({
                pathname: RouteBase.MEUP59,
              })
            };
          } else if (optionSearch === "modifyDelete") {
            AppData.setUnblockResponse(finalData);
            if (finalData.length == 0) {
              setErrors(['No result found'])
            }
            else {
              history.push(RouteBase.MEUP59);
            }

          } else {
            console.log("no radio button is selected");
          }
        })
        .catch((err) => {
          // AppData.addLoader(-1)
          errorList.push(`An Exception occurred while retrieving the data.`);
          setErrors(errorList);
          window.scrollTo(0, 0);
          AppData.setUnblockResponse([]);
        });
    } else {
      setErrors(errorList);
      window.scrollTo(0, 0);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
    <Grid container>
      <Grid item xs={12}>
        {
          errors.length > 0 ? <ErrorListMeup errors={errors} /> :
            props.success ? <div className="uploadItemsSuccessMsg"> {props.success} </div>
              : ""
        }
      </Grid>
      <Grid item xs={12}>
        <div
          style={{
            color: "rgb(0, 0, 128)",
            fontSize: "medium",
          }}
        >
          <strong>
            {" "}
            Specify the search criteria. In addition to country, at least one
            other parameter should be specified.{" "}
          </strong>
        </div>
      </Grid>

      <Grid
        container
        style={{ width: "80rem" }}
        className="blockItemsMarginTop"
      >
        {/* <Button>Save</Button> */}
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label={
              <>
                {" "}
                Country <font color="red">*</font>{" "}
              </>
            }
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={[{ label: "US", value: "001" }]}
            DropDownClass="blockItemsDropDown"
            value={country}
            disableNone={true}
            setValue={(value) => setCountry(value)}
            errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <ListSelectMeup
            label="Division"
            LabelClass="labelClassStoreItems"
            options={
              AppData && AppData.meup53Divisions !== undefined
                ? AppData.meup53Divisions
                : []
            }
            value={selectedDivisions}
            setValue={onChangeDivision}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <ListSelectMeup
            label="Group"
            LabelClass="labelClassStoreItems"
            options={
              AppData && AppData.meup53Groups !== undefined
                ? AppData.meup53Groups
                : []
            }
            value={selectedGroups}
            setValue={onChangeGroup}
            alignItems="row"
            classNameMeup="listStoreItems"
            disabled={cic.length > 0 && upc.length > 0}
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <ListSelectMeup
            label="Category"
            LabelClass="labelClassStoreItems"
            options={
              AppData && AppData.meup53CategoryList !== undefined
                ? AppData.meup53CategoryList
                : []
            }
            value={selectedCategories}
            setValue={(value) => onChangeCategory(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
            disabled={cic.length > 0 && upc.length > 0}
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="CIC"
            value={cic}
            LabelClass="labelClassStoreItems"
            setTextValue={(value) => setCic(value)}
            alignItems="row"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            limit={8}
            disabled={selectedCategories.length > 0}
            error={errorCic}
            errorText=""
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="UPC"
            value={upc}
            setTextValue={(value) => setUpc(value)}
            alignItems="row"
            LabelClass="labelClassStoreItems"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            limit={12}
            error={errorUpc}
            disabled={selectedCategories.length > 0}
            errorText=""
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="Store #"
            value={store}
            setTextValue={(value) => setStore(value)}
            alignItems="row"
            LabelClass="labelClassStoreItems"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            limit={4}
            error={errorStore}
            errorText=""
          />
        </Grid>
        {
          userRole === "meup-admin" ?
            <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
              <DropDownMemi
                label="State"
                disabled={optionSearch == 'modifyDelete'}
                LabelClass="labelClassStoreItems"
                alignItems="row"
                options={[
                  { label: "Allocated", value: "A" },
                  { label: "Unallocated", value: "U" },
                ]}
                DropDownClass="blockItemsDropDown"
                value={state}
                setValue={(value) => setState(value)}
              />
            </Grid>
            : null}

        <Grid item xs={6} className="storeItemsInnerDiv">
          <Grid container>
            <Grid item xs={4} className="updateStoreCalendar">
              <label className="labelClassStoreItems"> Delete Date</label>
            </Grid>
            <Grid item xs={8} className="updateStoreCalendar">
              <label> From </label>
              &nbsp;
              <CalendarMeup
                meupcal="storeItemscal"
                LabelClass="labelClassUpdateStoreItems"
                alignItems="col"
                value={deleteDateFrom}
                id="storeItemFrom"
                setValue={(value) => setDeleteDateFrom(value)}
              />
              &nbsp;
              <label> To </label>
              &nbsp;
              <CalendarMeup
                meupcal="storeItemscal"
                LabelClass="labelClassUpdateStoreItems"
                alignItems="col"
                id="storeItemTo"
                value={deleteDateTo}
                setValue={(value) => setDeleteDateTo(value)}
              />
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      <Grid item xs={12} className="blockItemsMarginTop">
        <RadioMemi
          classnameMemi="blockItemsSearchItems"
          radioclassmemi="radioBlockItemsSearchItems"
          Mainlabel=" Please select an option before search."
          label={[
            { value: "Unblock", label: "Unblock" },
            { value: "modifyDelete", label: "Modify Delete Date" },
          ]}
          value={optionSearch}
          setValue={(value) => setOptionSearch(value)}
        />
      </Grid>

      <Grid
        item
        xs={12}
        className="blockItemsMarginTop"
        style={{ marginBottom: "1rem" }}
      >
        <ButtonMemi
          btnval="Search Store Items"
          btnvariant="contained"
          classNameMemi="blockItemsButtons"
          type="submit"
          onClick={handleSubmit}
          type="submit"
        />

        <ButtonMemi
          btnval="Reset"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            window.location.reload();
          }}
        />

        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            history.push(RouteBase.MEUP50);
          }}
        />
      </Grid>
    </Grid>
  </form>
  );
}

export default UpdateStoreItems;
