import React from 'react';

import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';

import FormLabel from '@material-ui/core/FormLabel';
function RadioMemi(props) {
    return (
        <div  className={props.classnameMemi}>
      <FormLabel component="legend">{props.Mainlabel}</FormLabel>
      <RadioGroup row aria-label="gender" name="row-radio-buttons-group" value={props.value} onChange={(e) => props.setValue(e.target.value)}>
      {props.label.map((option, index) => (
<FormControlLabel
  value={option.value}
  control={<Radio />}
  label={option.label}
  id={index}
  className={props.radioclassmemi}
/>
))}
        
      </RadioGroup>
    </div>
    );
}

export default RadioMemi;