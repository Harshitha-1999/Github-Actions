import React, { useContext, useEffect, useState } from "react";

import { useHistory } from "react-router-dom";

import TableMemi from "../../components/TableMemi/TableMemi";

import Box from "@mui/material/Box";
import {formatdate} from "components/CommonFunctionsMeup/CommonFunctionsMeup"
import Moment from "moment";

import ButtonMemi from "../../components/ButtonMemi/ButtonMemi";

import TextAreaAutosizeMemi from "components/TextAreaAutosizeMemi/TextAreaAutosizeMemi";

import ApplicationContext from "context/ApplicationContext";

import { meupServices } from "api/meup/meupServices";

import CalendarMeup from "components/CalendarMeup/CalendarMeup";

import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";

import {

  formatDate,

  generateUserLevel,

} from "components/CommonFunctionsMeup/CommonFunctionsMeup";
import { schematic, 
  unBlockingReasonError, 
  characterAboveLimitError, 
  noItemSelectedUnblockError, 
  confirmUnblock, 
  invalidDate, 
  invalidDateFormat, 
  invalidPastIncludingPresentDateError, 
  modifyDeleteDateReasonError,
  noItemSelctedModifyDateReasonError,
  confirmModify
} from "utils/Constants";
import { DateUtility } from "utils";
import { RouteBase } from "routes/constants";
import { initialState } from "providers";





function UpdateStoreItemUnblock(props) {

  const history = useHistory();

  const AppData = useContext(ApplicationContext);
const [pageSize, setPageSize] = useState(100);


  const userRole = generateUserLevel();

  const [errors, setErrors] = useState([]);

  const [textArea, setTextAreaVal] = useState("");

  const [selectedRows, setSelectionModel] = React.useState([]);

  const [deleteDateTo, setDeleteDateTo] = useState(null);

  const routedForScreen = AppData.radioVal;
  

  const [hasSchematic, setHasSchematic] = useState(false);
  const mapResponse = AppData && AppData.unblockRes  ? AppData.unblockRes : [];

  useEffect(() => {
    mapResponse.forEach((data) => {
     
      if(data.schematicData) {
        setHasSchematic(true);
        return
      }
    })
  }, [mapResponse])
  let columnsUnblockTable = [

    /*  {

       field: "index",

       headerName: "indexCount",

       width: 50,

       headerAlign: "center",

       headerClassName: "headerCss",

     }, */

    {

      field: "divisionNumber",

      headerName: "DV",

      sortable: true,

      width: 53,

      headerAlign: "center",

      headerClassName: "headerCss",
      type:"number",

    },

    {

      field: "storeNumber",

      headerName: "Store#",



      width: 69,

      headerAlign: "center",

      headerClassName: "headerCss",
      type:"number",
    },

    {

      field: "smicCategoryDto",

      headerName: "Category",

      flex: 1.9,

      headerAlign: "center",

      headerClassName: "headerCss",
      valueGetter: (params) => { return params.value.dispCategory},
      

    },

    {

      field: "upc",

      headerName: "UPC",

      width: 90,

      headerAlign: "center",

      headerClassName: "headerCss",
      valueGetter: (params) => { return params.row.itemDto.dispUpc},
      type:"number",

    },

    {

      field: "cic",

      headerName: "CIC",

      width: 70,

      headerAlign: "center",

      headerClassName: "headerCss",
      valueGetter: (params) => { return params.row.itemDto.cic},
      type:"number",
    },

    {

      field: "description",

      headerName: "Description",

      flex:1.3,

      headerAlign: "center",

      headerClassName: "headerCss",

    },

    {

      field: "sizeUOMForDisplay",

      headerName: "Size",

      width: 60,

      headerAlign: "center",

      headerClassName: "headerCss",
      sortComparator: (v1, v2) => {return parseFloat(v1.split(" ")[0]) - parseFloat(v2.split(" ")[0])}

    },

    {

      field: "uom",

      headerName: "UOM",

      width: 67,

      headerAlign: "center",

      headerClassName: "headerCss",

    },

    {

      field: "casePkForDisplay",

      headerName: "Case Pk",

      width: 85,

      headerAlign: "center",
      // valueGetter: (params) => {return params.value.casePk},
      headerClassName: "headerCss",
      type:"number",
      

    },

    {

    field: "dispState",

     headerName: "State",

     width: 78,

     headerAlign: "center",

  headerClassName: "headerCss",

  hide: userRole === "meup-admin" && routedForScreen === "Unblock" ? false : true,

   },

    {

    field: "stateEffectiveDateForDisplayResult",

     headerName: "State Effective Date",

    width: 100,

    headerAlign: "center",

     headerClassName: "headerCss",

     hide: userRole === "meup-admin" && routedForScreen === "Unblock" ? false : true,
     sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}

    }, 

    {

      field: "blockedTargetDate",

      headerName: "Delete Date",

      headerAlign: "center",

      headerClassName: "headerCss",
      valueGetter: (params) => {
        return formatdate(params.value)
      },
      sortComparator: (v1, v2) => {return DateUtility.datesComparator(v1,v2)}

    },

    {

      field: "lastUpdatedUser",

      headerName: "Last Update User",

      width: 100,

      headerAlign: "center",

      headerClassName: "headerCss",

    },

  ];








  const rows = AppData.rowData;



  const setSelectionCriteria = (params) => {

    if (routedForScreen === "modifyDelete") {

      return !params.row.schematicData;

    } else if (routedForScreen === "Unblock") {

      return (

        params.row.schematicData&&

        userRole === "meup-admin" ||params.row.schematicData==false

      );

    }
   

  };



  const unblockAction = () => {

    
    if (textArea.trim().length === 0) {
      alert(unBlockingReasonError);
    } else if (textArea.trim().length > 100) {
      alert(characterAboveLimitError);
    } else if (selectedRows.length === 0) {
      setErrors([noItemSelectedUnblockError])
    }

    else {
      let isConfirm = window.confirm(confirmUnblock)
      if (!isConfirm) { return }

      let otherData = [];

      mapResponse.filter((y, index) => {

        return selectedRows.forEach((x) => {

          if (index === x) otherData.push(y);

        });

      });



      meupServices

        .unblockUpdateStoreItems(rows, otherData, textArea, deleteDateTo)

        .then((res) => {
          setSelectionModel([]);
          AppData.resetApplicationContext(initialState)
          history.push({ pathname: RouteBase.MEUP53, state: { success: res.data.data.REST_RETURNED_DATA } });
          
        })

        .catch((err) => {

          setErrors(["An unexpected Application error occured"])


        });

    }

  };

  const updateDeleteDate = () => {

    let errorTemp = [];



    if (!deleteDateTo) {
      alert(invalidDate);
      return;

    } else if (!DateUtility.validateDate(deleteDateTo)) {
      alert(invalidDateFormat)
      return;

    } else if (formatDate(deleteDateTo) <= Moment().format("YYYY-MM-DD")) {
      alert(invalidPastIncludingPresentDateError);
      return;

    } else {

      if (textArea.trim().length === 0) {
        errorTemp.push(modifyDeleteDateReasonError);
      }

      if (textArea.trim().length > 100) {
        errorTemp.push(characterAboveLimitError)
      }

      if (selectedRows.length === 0) {
        errorTemp.push(noItemSelctedModifyDateReasonError)
      }

    }



    setErrors(errorTemp);



    if (errorTemp.length > 0) { return }

    else {
      let isConfirm = window.confirm(confirmModify)
      if (!isConfirm) { return }

      let otherData = [];

      mapResponse.filter((y, index) => {

        return selectedRows.forEach((x) => {

          if (index === x) otherData.push(y);

        });

      });



      meupServices

        .unblockUpdateStoreItems(

          rows,

          otherData,

          textArea,

          formatDate(deleteDateTo)

        )

        .then((res) => {
          setSelectionModel([]);

          AppData.resetApplicationContext(initialState)
          history.push({ pathname: RouteBase.MEUP53, state: { success: res.data.data.REST_RETURNED_DATA} });
          
        })

        .catch((err) => {

          setErrors(["An unexpected Application error occured"])

        });

    }

  };



  const searchAgain = () => {

    history.push("/MEUP53");

  };

  const cancel = () => {

    history.push("/");

  };

  // console.log(textArea.trim().length);

  return (

    <Box>

      <Box>



        {<ErrorListMeup

          errors={errors} />}



        <div

          style={{

            color: "rgb(0, 0, 128)",

            marginTop: "22px",

            fontSize: "small",

          }}

        >

          <strong>



            {(routedForScreen === "Unblock" &&

              userRole === "meup-admin") || !hasSchematic

              ? ""

              : routedForScreen === "Unblock"

                ? "All greyed cells indicate schematic data. A SCHEMATIC item can only be unblocked by the system administrator."

                : "All greyed cells indicate schematic data. A SCHEMATIC item cannot be modified by you."}

          </strong>

        </div>

      </Box>

      <Box

        sx={{

          display: "flex",

          marginBlockStart: 2,

          marginBlockEnd: 6,

        }}

      >

        <div>
        
          {routedForScreen === "Unblock" ? (

            <ButtonMemi

              customStyle={{ margin: "1px" }}

              btnval={"Unblock"}

              idCss="buttonMEUP"
             
                
              onClick={unblockAction}

            />

          ) : (

            <Box

              sx={{

                display: "flex",

                width: "auto",

                justifyContent: "space-between",
                

              }}

            >

              <CalendarMeup
                meupcal="blockItemsCal"
                classblock="block"
                label={

                  <div>

                    Change Delete Date To <font color="red">* </font>

                  </div>

                }

                alignItems="row"

                value={deleteDateTo}

                setValue={(value) => setDeleteDateTo(value)}

                LabelClass="labelClassBlockedItems"
                



              />

              <ButtonMemi

                btnval="Update"

                btnvariant="contained"

                classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"

                onClick={updateDeleteDate}

              />

            </Box>

          )}

        </div>

        <div className="labelSpace">

          <TextAreaAutosizeMemi

            alignItems="row"

            value={textArea}

            setTextValue={(value) => setTextAreaVal(value)}
            LabelClass="textarealabel"
            label={

              <>

                Enter Comment<font color="red">*</font>

              </>

            }

            minrow={3}

          />

        </div>

      </Box>

      <Box sx={{ display: "flex" }}>

        <TableMemi

          data={mapResponse ? mapResponse : []}

          autoHeight={true}

          rowheight={60}

          selectionType="checkbox"

          selectedRows={selectedRows}

          setSelectionModel={(selectedRows) => setSelectionModel(selectedRows)}

          columns={columnsUnblockTable}

          classnameMemi="tableModifyDeleteDate"
          pageSize={pageSize}
          onPageSizeChange={(num) => setPageSize(num)}
          
          showCellRightBorder={true}

          showColumnRightBorder={true}

          hideFooter={false}

          hideFooterPagination={false}

          hideFooterSelectedRowCount={true}

          selectionCriteria={setSelectionCriteria}





        />

      </Box>

      <Box

        sx={{

          display: "flex",

          justifyContent: "flex-start",

          marginBottom: "1rem",

        }}

      >

        <ButtonMemi

          customStyle={{ marginBlockStart: "10px", marginRight: "10px" }}

          btnval={"Search Again"}

          idCss="buttonMEUP"

          onClick={searchAgain}

        />

        <ButtonMemi

          customStyle={{ marginBlockStart: "10px" }}

          btnval={"Cancel"}

          idCss="buttonMEUP"

          onClick={cancel}

        />

      </Box>

    </Box>

  );

}



export default UpdateStoreItemUnblock;

