import React from "react";
import PropTypes from "prop-types";
import TextareaAutosize from "@material-ui/core/TextareaAutosize";
import { Grid } from "@material-ui/core";

function TextAreaAutosizeMemi(props) {
  const onChangeText = (text) => {
    props.setTextValue(text);
  };

  return (
    <Grid container>
      <Grid item md={props.alignItems === "row" ? 5 : 12}>
        <label className={props.LabelClass}>{props.label}</label>
      </Grid>
      <Grid item md={props.alignItems === "row" ? 7 : 12}>
        <TextareaAutosize
          className={props.classNameMemi}
          minRows={props.minrow}
          maxRows={props.maxrow}
          value={props.value}
          onChange={(e) => onChangeText(e.target.value)}
          disabled={props.disabled}
        />
      </Grid>
    </Grid>
  );
}

export default TextAreaAutosizeMemi;

TextAreaAutosizeMemi.propTypes = {
  minrow: PropTypes.number,
  maxrow: PropTypes.number,
  value: PropTypes.string || PropTypes.number,
  error: PropTypes.bool,
  disabled: PropTypes.bool,
  classNameMemi: PropTypes.string,
  setTextValue: PropTypes.string,
  LabelClass: PropTypes.string,
  label: PropTypes.string || PropTypes.object,
  alignItems: PropTypes.string
};
