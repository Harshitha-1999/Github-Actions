import React, { useCallback, useState, useContext } from "react";
import { Grid } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { styled } from '@material-ui/core/styles';
import { useHistory } from 'react-router';
import { DateUtility, authTokenCookie } from "utils";
import { Link } from 'react-router-dom';
import "../../css/App.css";

import CalendarMeup from "../CalendarMeup/CalendarMeup"
import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";

import { meupServices } from "../../api/meup/meupServices";
import ApplicationContext from "../../context/ApplicationContext";

function UploaditemBlockMeup() {

  const history = useHistory();

  const AppData = useContext(ApplicationContext);

  const Input = styled('input')({
    display: 'none',
  });

  const [errors, setErrors] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState("");
  const [fieldedErrors, setFieldErrors] = useState({ calenderError: false, uploadError: false, isSuccess: false });
  let { userId } = authTokenCookie();

  const [date, setDate] = useState(null);
  const selectFile = (event) => {
    setSelectedFiles(event.target.files[0]);
    document.getElementsByClassName("btnmemiupload")[0].focus()
    };

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault()
    let errorList = [];
    setFieldErrors({ calenderError: false, uploadError: false, isSuccess: false });

    if (!date) {
      alert("Please enter a valid date");
      setDate("");
      document.getElementById("uploadCalender").focus()
      setFieldErrors(preState => ({ ...preState, calenderError: true }))
    }
    else if (date - new Date() <= 0) {
      alert("Delete date must be set at least one day the future");
      setDate("");
      document.getElementById("uploadCalender").focus()
      setFieldErrors(preState => ({ ...preState, calenderError: true }))
    }
    else if (selectedFiles.length === 0) {
      setFieldErrors(preState => ({ ...preState, uploadError: true }));
      setSelectedFiles("");
      errorList = ["The CSV file is not specified for upload. Use the Browse button to locate the file."];
    } else {

      let idxDot = selectedFiles.name.lastIndexOf(".") + 1;
      let extFile = selectedFiles.name.substr(idxDot, selectedFiles.length).toLowerCase();

      if (extFile.toLowerCase() !== "csv") {
        setFieldErrors(preState => ({ ...preState, uploadError: true }));
        setSelectedFiles("");
        errorList = ["The selected file is invalid. Please select a valid file and upload again."];
      } else {

        let formData = new FormData();
        // formData.append("deleteDate", DateUtility.convertDate(date))
        formData.append("itemsFile", selectedFiles)
        // formData.append("userID", userId);

        meupServices.getUploadItems(formData, DateUtility.convertDate(date), userId)
          .then((res) => {
            if (res.hasOwnProperty('data')) {
              var { data } = res;

              if (data.status === "SUCCESS") {

                if (data.hasOwnProperty('data')) {
                  var { data } = data;
                  if (data.hasOwnProperty('REST_RETURNED_DATA')) {
                    setSelectedFiles("");
                    setFieldErrors(preState => ({ ...preState, isSuccess: true }))
                    AppData.setMeup51UploadItem(data.REST_RETURNED_DATA);
                  }
                }
              } else if (data.hasOwnProperty('errorDTOList')) {
                setFieldErrors(preState => ({ ...preState, isSuccess: false, uploadError: true }))
                setErrors([data.errorDTOList[0].message]);
                setSelectedFiles("");
                window.scrollTo(0, 0);
              }
            }
          }).catch((error) => {
            AppData.setMeup51UploadItem([]);
            setErrors(["An Exception occurred while retrieving the data."]);
            window.scrollTo(0, 0);
          })
        }
      }


      setErrors(errorList);
      window.scrollTo(0, 0);

    }, [date, selectedFiles, errors, fieldedErrors, date])

  return (
<form onSubmit={handleSubmit}>

    <Grid container>

      <Grid item xs={12} >
        {fieldedErrors.isSuccess ? <div className="uploadItemsSuccessMsg"> {AppData.meup51UploadItem} </div> : <ErrorListMeup errors={errors} />}
      </Grid>

      <Grid item xs={12}>
        <div className="uploadItemsInfo">
          <strong> You can upload maximum of 1500 items for a file. </strong>
        </div>
      </Grid>



      <Grid item xs={12} className="">
        <div style={{ width: "47rem" }} className="blockItemsMarginTop">
          <CalendarMeup
            meupcal="blockItemsCal"
            label={<div> Set Delete Date <font color="red">*</font> </div>}
            LabelClass="labelClassBlockedItems"
            alignItems="row"
            value={date}
            setValue={(value) => setDate(value)}
            disablePastDays={true}
            alignItems={"row"}
            id={"uploadCalender"}
          />
        </div>
      </Grid>

      <Grid item xs={12} container className="uploadItemsCsvFileGrid">
        <Grid item xs={5} style={{ display: "flex", alignItems: "center" }}>
          Select CSV File <font color="red">*</font>
        </Grid>
        <Grid item xs={7} style={{ fontSize: "small !important" }}>
          <label htmlFor="contained-button-file">

            <Button variant="contained" component="span" className="uploadItemsChooseFileBtn">
              Browse
            </Button>
            <Input id="contained-button-file" type="file" onChange={selectFile} />
            <label style={{ fontSize: "12px" }}> {selectedFiles !== "" ? selectedFiles.name : "No file chosen"} </label>
          </label>
        </Grid>
      </Grid>

      {/* <Grid item xs={12} className="uploadItemsCsvFileGrid"> */}
      {/* <div className="uploadItemsCsvFileDiv">
          <TextFieldMemi
            LabelClass="labelclass1"
            length={15}
            label={<> Select CSV File <font color="red">*</font> </>}
            alignItems="row"
            id="Vcf outlined-disabled"
            value={selectedFiles !== "" ? selectedFiles.name : ""}
            labelLeft={true}
            errorText={''}
            error={fieldedErrors.uploadError}
            TextFieldClass="textFieldupload"
            input="inputupload"
          />
        </div> */}

      {/* <label htmlFor="contained-button-file" className="browser uploadItemsLabel">
          <Button variant="contained" component="span" className="uploadItemsChooseFileBtn">
            Choose File
          </Button>
          <Input id="contained-button-file" accept={".csv"} type="file" onChange={selectFile} />
        </label> */}

      <Grid item xs={12} className="uploadItemsSubmitBtn">      
        <ButtonMemi
          btnval="Upload"
          btnvariant="contained"
          classNameMemi="btnmemiupload"
          type="submit"
          onClick={handleSubmit}
        />
        
        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="btnmemicancel"
          onClick={() => {
            history.push('/');
          }}
        />
      </Grid>

      <Grid item xs={12} style={{ marginTop: "5.12rem", marginBottom: "1rem" }}>
        <div>
          ** To download a CSV template, click {<Link to={`/csvTemplate.csv`} target="_blank" download>here</Link>} Use the Help link above for more information.{" "}
        </div>
      </Grid>
    </Grid>
 </form>
 );
}

export default UploaditemBlockMeup;