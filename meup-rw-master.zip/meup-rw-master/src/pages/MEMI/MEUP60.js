import React from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"

import ModifyDeleteDate from "components/ModifyDeleteDate/ModifyDeleteDate";





export const MEUP60 = () => {
  

  return (
  <PageLayoutMeup
    mainContentMeup={<ModifyDeleteDate/>}
    header={<HeaderMeup title="Update Store Items"/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP60;
