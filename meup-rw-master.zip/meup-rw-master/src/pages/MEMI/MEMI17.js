import React, { useEffect, useContext} from "react";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Footer from "../../components/Footer/Footer";
import AugmentationTable from "../../components/AugmentationTable/AugmentationTable";
import ApplicationContext from "../../context/ApplicationContext";
import { MEMI17Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";

import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
import {apiUrl} from "../../service/apiUrls"

export const MEMI17 = () => {
  const AppData = useContext(ApplicationContext);
  
  const url=apiUrl.augmentation
  useEffect(() => {
    ApiMemi(url,"GET").then((res) => {
      // console.log(res)
      // AppData.setMemi20(res.data)
      let response=res.data.map((data,index)=>{return {id:index,...data}})
      AppData.setMemi17(response);
     
    }).catch(error => {
      // console.log(error)
      //return the default data found in db.json. 
      MEMI17Axios.get("/").then((res) => {
        AppData.setMemi17(res.data);
      });
      
    });
  }); //removed array [] to avoid warnings

  return (
    <PageLayoutMemi
      pageTitle="Augmentation"
      mainContent={<AugmentationTable AppData={AppData} />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default MEMI17;
