import FooterMeup from 'components/FooterMeup/FooterMeup'
import HeaderMeup from 'components/HeaderMeup/HeaderMeup'
import PageLayoutMeup from 'components/PageLayoutMeup/PageLayoutMeup'
import StoreItemsHoldStoreItem from 'components/StoreItemsOnHoldStoreItem/StoreItemsOnHoldStoreItem'
import React, {useEffect, useContext, useState} from 'react'
import { meupServices } from 'api/meup/meupServices';
import { MEUP63_LABEL_NAME } from 'utils'
import ApplicationContext from "../../context/ApplicationContext";
export default function MEUP63(props) {
  const AppData = useContext(ApplicationContext);
    
    const {state} = props.location
    
    const [errors, setErrors] = useState([])
    useEffect(() => {
        
        const stockSectnBr = state ? state.stockSectnBr : []
        const storeID = state ? state.storeID :[]

        AppData.setMeup63([]);
        
        meupServices.getStoreStockingSection(storeID, stockSectnBr)
            .then((res) => {
                let data = res.data.data.REST_RETURNED_DATA.map((data,index) => {
                  return {...data, id:index,accept:false, reject:false, hold:data.status==="H"}

                });
            
                AppData.setMeup63(data);
                
            })
            .catch((error) => {
              setErrors(["An Exception occurred while retrieving the data"])
              AppData.setMeup63([]);
            })
    }, [state])
  return (
    <PageLayoutMeup
        mainContentMeup={<StoreItemsHoldStoreItem errors={errors} />}
        header={<HeaderMeup title="Update Store Items" subTitle={MEUP63_LABEL_NAME} fullWidth/>}
        footerMeup={<FooterMeup />}
    />
  )
}
