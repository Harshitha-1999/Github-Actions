import React from "react";

import PageLayoutMeup from "../../components/PageLayoutMeup/PageLayoutMeup"
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"
import MenuMeup from "../../components/MenuMeup/MenuMeup"

export const MEUP50 = () => {
 
  return (<PageLayoutMeup
   
    mainContentMeup={<MenuMeup/>}
    header={<HeaderMeup title="Welcome" />}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP50;

