import React  from "react";


import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import BakeryMapping from "../../components/BakeryMapping/BakeryMapping"

export const MEMI19 = () => {
 


  return (
    <PageLayoutMemi
    pageTitle="MEMI19"
      mainContent={<BakeryMapping/>}
      navigationBar={<NavigationBar />}
      // footer={<Footer />}
    />
  );
};

export default MEMI19;
