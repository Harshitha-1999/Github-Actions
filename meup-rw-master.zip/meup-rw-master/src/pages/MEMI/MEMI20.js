import React, { useEffect, useContext } from "react";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Footer from "../../components/Footer/Footer";

import TableMemi from "../../components/TableMemi/TableMemi";

import ApplicationContext from "../../context/ApplicationContext";
import { MEMI20Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";
// import APIMemi from "../../components/APIMEMI/APImemi"
import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
import {apiUrl} from "../../service/apiUrls"

export const MEMI20 = () => {
  const AppData = useContext(ApplicationContext);
const url=apiUrl.targetsource
  useEffect(() => {
    ApiMemi(url,"GET").then((res) => {
      // console.log(res)
      // AppData.setMemi20(res.data)
      let response=res.data.map((data,index)=>{return {id:index,...data}})
      AppData.setMemi20(response);
     
    }).catch(error => {
      // console.log(error)
      //return the default data found in db.json. 
      MEMI20Axios.get("/").then((res) => {
        AppData.setMemi20(res.data);
      });
      
    });
  });

  


  return (
    <PageLayoutMemi
      pageTitle="Override Process - API Version"
      mainContent={
        <TableMemi
        data={AppData.memi20}
        classnameMemi="table27"
        rowheight={40}
        selectionType="radio"
      /> 
        
      }
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};
export default MEMI20;
