import React from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';

import FooterMeup from "../../components/FooterMeup/FooterMeup"


import NoGroupAccessMeup from "components/NoGroupAccessMeup/NoGroupAccessMeup";
import HeaderErrorMeup from "components/HeaderErrorMeup/HeaderErrorMeup";





export const MEUP61 = () => {
  

  return (
  <PageLayoutMeup
    mainContentMeup={<NoGroupAccessMeup/>}
    header={<HeaderErrorMeup/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP61;
