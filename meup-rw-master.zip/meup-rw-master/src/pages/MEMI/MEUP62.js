import React, {  useContext, useState } from 'react'

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import ApplicationContext from "../../context/ApplicationContext";
import FooterMeup from "../../components/FooterMeup/FooterMeup";
import HeaderMeup from "components/HeaderMeup/HeaderMeup";
import StoreItemsHoldStoreCount from 'components/StoreItemsHoldStoreCount/StoreItemsHoldStoreCount';
import { MEUP62_LABEL_NAME } from 'utils';
export default function MEUP62(props) {
    const AppData = useContext(ApplicationContext);
    
    const [errors, setErrors] = useState([])
    
   
    return (
        <PageLayoutMeup
            mainContentMeup={<StoreItemsHoldStoreCount errors={errors} />}
            header={<HeaderMeup title="Update Store Items" subTitle={MEUP62_LABEL_NAME} fullWidth/>}
            footerMeup={<FooterMeup />}
        />
    );
}
