import React from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"
import EnterItemsBlock from "../../components/EnterItemsBlock/EnterItemsBlock"


export const MEUP57 = () => {
  

  return (
  <PageLayoutMeup
    mainContentMeup={<EnterItemsBlock />}
    header={<HeaderMeup title="Block Items" subTitle="Enter Items to Block"/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP57;
