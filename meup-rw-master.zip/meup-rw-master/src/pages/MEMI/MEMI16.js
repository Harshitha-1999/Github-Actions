import React from "react";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Footer from "../../components/Footer/Footer";
import LookupQuery from "../../components/LookupQuery/LookupQuery";

export const MEMI16 = () => {
  

  return (
    <PageLayoutMemi
      pageTitle="Displayer Screen Cont"
      mainContent={<LookupQuery />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default MEMI16;

