import React from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"
import SearchStoreItems from "components/SearchStoreItems/SearchStoreItems";

export const MEUP54 = () => {
  
  return (
  <PageLayoutMeup
    mainContentMeup={
    
    <SearchStoreItems />}
    header={<HeaderMeup title="Reports" subTitle="Search Store Items"/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP54;
