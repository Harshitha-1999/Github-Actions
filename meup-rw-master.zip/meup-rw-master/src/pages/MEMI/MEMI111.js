import React from "react";

import { Grid } from "@material-ui/core";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Footer from "../../components/Footer/Footer";
import RefreshTokenMemi from "../../components/RefreshTokenMemi/RefreshTokenMemi";
import ApplicationData from "../../components/ApplicationData/ApplicationData";

export const MEMI111 = () => {
 

  return (
    <PageLayoutMemi
      pageTitle="Application Data"
      mainContent={<Grid><Grid item> <RefreshTokenMemi/></Grid><Grid item > <ApplicationData /></Grid></Grid>}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default MEMI111;
