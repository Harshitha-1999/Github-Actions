import React from "react";
import PageLayoutMeup from "../../components/PageLayoutMeup/PageLayoutMeup"
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"
import UploaditemBlockMeup from "../../components/UploadItemBlockMeup/UploaditemBlockMeup"

const MEUP51 = () => {

 
  return (<PageLayoutMeup
   
    header={
      <HeaderMeup 
        title="Block Items" 
        subTitle="Upload Items to Block"
      />
    }
    mainContentMeup={<UploaditemBlockMeup />}
    footerMeup={<FooterMeup />}
  />);

 
};

export default MEUP51;

