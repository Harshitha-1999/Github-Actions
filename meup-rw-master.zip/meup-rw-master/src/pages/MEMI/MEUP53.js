import React from "react";
import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';

import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"
import UpdateStoreItems from '../../components/UpdateStoreItems/UpdateStoreItems'


export const MEUP53 = (props) => {

  return (
    <PageLayoutMeup
      
      mainContentMeup={<UpdateStoreItems success={props.location.state && props.location.state.success ? props.location.state.success : ""}/>}
      header={<HeaderMeup title="Update Store Items" subTitle="Enter Items to Block"/>}
      footerMeup={<FooterMeup />}
    />
  );
};

export default MEUP53;
