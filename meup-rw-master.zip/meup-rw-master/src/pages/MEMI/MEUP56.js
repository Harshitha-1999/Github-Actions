import React from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"

import StoreItemsHistory from "components/StoreItemsHistory/StoreItemsHistory";





export const MEUP56 = (props) => {
  
  const item = props.location.state ? props.location.state.item : []
  return (
  <PageLayoutMeup
    mainContentMeup={<StoreItemsHistory item={item}/>}
    header={<HeaderMeup title="Reports"  subTitle={"Store Item History"} fullWidth/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP56;
