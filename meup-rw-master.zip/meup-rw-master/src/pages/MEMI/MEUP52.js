import React from "react";
import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';



import BlockItems from "components/BlockItems/BlockItems";
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"




const MEUP52 = () => {


  return (<PageLayoutMeup

    mainContentMeup={<BlockItems />}
    header={
      <HeaderMeup
        title="Block Items"
        subTitle="Enter Items to Block"
      />
    }
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP52;
