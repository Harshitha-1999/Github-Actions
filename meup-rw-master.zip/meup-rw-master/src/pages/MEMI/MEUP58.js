import React, {useEffect, useContext, useState} from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import FooterMeup from "../../components/FooterMeup/FooterMeup"

import ApplicationContext from "../../context/ApplicationContext";
import StoreItemsOnHoldSearch from "components/StoreItemsOnHoldSearch/StoreItemsOnHoldSearch";
import { meupServices } from "api/meup/meupServices";





export const MEUP58 = () => {
  const AppData = useContext(ApplicationContext)
 
  const [errors, setErrors] = useState([])
  useEffect(() => {
    // AppData.addLoader(1)
    meupServices.getStoreItemsOnHold()
      .then((res) => {
        // AppData.addLoader(-1)
        let divisionList = res.data.data.REST_RETURNED_DATA.divisionList.map((data) => {
          return {label: `${data.divisionNumber}-${data.divisionName}`, value:data.divisionNumber}
        })

        let stockingSectionList = res.data.data.REST_RETURNED_DATA.stockingSectionList.map((data) => {
          return {label: `${data.stockingSectionNumber}-${data.stockingSectionDesc}`, value: data.stockingSectionNumber}
        })

        AppData.setMeup58({divisionList, stockingSectionList})
        setErrors([])
        
      })
      .catch((error) => {
        // AppData.setLoader(-1);
        setErrors(["An Exception occurred while retrieving the data"])
        AppData.setMeup58({divisionList:[], stockingSectionList:[]});
        
      })
  }, [])
  return (
  <PageLayoutMeup
    mainContentMeup={<StoreItemsOnHoldSearch errors={errors}/>}
    header={<HeaderMeup title="Update Store Items" subTitle="Store Items On Hold - Search" fullWidth/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP58;
