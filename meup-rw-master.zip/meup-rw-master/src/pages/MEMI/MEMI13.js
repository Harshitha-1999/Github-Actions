import React, { useEffect, useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";


import TableMemi from "../../components/TableMemi/TableMemi";

import ApplicationContext from "../../context/ApplicationContext";
import { MEMI13Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";
import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
import {apiUrl} from "../../service/apiUrls"

const custom_columns = [
  {
    field: "id",
    headerName: "SKU",
    width: 150,
  
      hide:true
  },
  {
    field: "deptName",
    headerName: " ",
    width: 150,
    headerAlign: 'center',
  
      
  },

  {
    field: "totalWHSERecords",
    headerName: "WHSE",
    width: 150,
    editable: true,
    headerAlign: 'center',
  },
  {
    field: "totalDSDRecords",
    headerName: "DSD",
    width: 150,
    editable: true,
    headerAlign: 'center',
  },
  {
    field: "totalRecord",
    headerName: "Total",
    type: "number",
    width: 150,
    editable: true,
    headerAlign: 'center',
  },
  {
    field: "completedWHSEItmCnt",
    headerName: "WHSE",
    sortable: false,
    width: 150,
    headerAlign: 'center',
    
  },
  {
    field: "completedDSDItmCnt",
    headerName: "DSD",
    type: "number",
    width: 150,
    editable: true,
    headerAlign: 'center',

  },
  {
    field: "completedItmCnt",
    headerName: "TOTAL",
    width: 190,
    editable: true,
    headerAlign: 'center',
  },
 
];

export const MEMI13 = () => {
  const AppData = useContext(ApplicationContext);

  
  const url=apiUrl.overrideprocess
  useEffect(() => {
    ApiMemi(url,"GET").then((res) => {
      // console.log(res)
      // AppData.setMemi20(res.data)
      let response=res.data.map((data,index)=>{return {id:index,...data}})
      AppData.setMemi13(response);
     
    }).catch(error => {
      // console.log(error)
      //return the default data found in db.json. 
      MEMI13Axios.get("/").then((res) => {
        AppData.setMemi13(res.data);
      });
      
    });
  });

  
  return (
    <PageLayoutMemi
      pageTitle="Override Process"
      mainContent={
        <TableMemi
        data={AppData.memi13}
        columns={custom_columns}
        classnameMemi="table27"
        rowheight={40}
        selectionType="checkbox"
      /> 
      }
      navigationBar={<NavigationBar />}
      // footer={<Footer />}
    />
  );
};
export default MEMI13;