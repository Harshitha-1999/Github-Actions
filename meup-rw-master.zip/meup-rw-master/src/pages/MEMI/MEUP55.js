import React, { useEffect, useContext } from "react";

import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup";
import FooterMeup from "../../components/FooterMeup/FooterMeup";
import StoreItemsReport from "components/StoreItemsReport/StoreItemsReport";

export const MEUP55 = () => {

  return (
  <PageLayoutMeup
    mainContentMeup={
    
    <StoreItemsReport />}
    header={<HeaderMeup title="Reports"  subTitle={"Store Items Report"}/>}
    footerMeup={<FooterMeup />}
  />);
};

export default MEUP55;
