import PageLayoutMeup from '../../components/PageLayoutMeup/PageLayoutMeup';
import HeaderMeup from "../../components/HeaderMeup/HeaderMeup"
import UpdateStoreItemUnblock from '../../components/UpdateStoreItemUnblock/UpdateStoreItemUnblock';
import React from 'react';
import FooterMeup from 'components/FooterMeup/FooterMeup';

export default function MEUP59() {
 return (
     <PageLayoutMeup
     mainContentMeup={<UpdateStoreItemUnblock/>}
     header={<HeaderMeup title="Update Store Item" subTitle="Update Store Items" fullWidth/>}
     footerMeup={<FooterMeup />}
     />
 )
}