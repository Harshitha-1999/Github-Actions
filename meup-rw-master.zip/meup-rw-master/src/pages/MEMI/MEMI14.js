import React, {
  useEffect,
  useContext,
} from "react";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Footer from "../../components/Footer/Footer";

import OverrideProcessCont from "../../components/OverrideProcessCont/OverrideProcessCont";
import ApplicationContext from "../../context/ApplicationContext";
import {
  MEMI14_AAxios,
} from "../../api/memiuAxiosInstances/memiuAxiosInstances";

export const MEMI14 = () => {
  const AppData = useContext(ApplicationContext);
  // console.log("AppData: ", AppData);

  useEffect(() => {
    MEMI14_AAxios.get("/").then((res) => {
      AppData.setMemi14_A(res.data);
    });
  });


  return (
    <PageLayoutMemi
      pageTitle="Override Process Cont"
      mainContent={<OverrideProcessCont AppData={AppData} />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default MEMI14;
