import React, { useEffect, useContext} from "react";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Footer from "../../components/Footer/Footer";
//import AugmentationTable from "../../components/AugmentationTable/AugmentationTable";
import ApplicationContext from "../../context/ApplicationContext";
import { MEMI23Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";

import DisplayerScreen from "components/DisplayerScreen/DisplayerScreen";
import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
import {apiUrl} from "../../service/apiUrls"

export const MEMI23 = () => {
  const AppData = useContext(ApplicationContext);
 
  const url=apiUrl.Displayer
  useEffect(() => {
    ApiMemi(url,"GET").then((res) => {
      // console.log(res)
      // AppData.setMemi20(res.data)
      let response=res.data.map((data,index)=>{return {id:index,...data}})
      AppData.setMemi23(response);
     
    }).catch(error => {
      // console.log(error)
      //return the default data found in db.json. 
      MEMI23Axios.get("/").then((res) => {
        AppData.setMemi23(res.data);
      });
      
    });
  });
  // console.log("ApData: ", AppData);
  return (
    <PageLayoutMemi
      pageTitle="Displayer"
      mainContent={<DisplayerScreen AppData={AppData} />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default MEMI23;
