import React from "react";

import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Mapped from "../../components/Mapped/Mapped"
export const MEMI04 = () => {
 

  return (
    <PageLayoutMemi
      pageTitle="Mapped"
      mainContent={<Mapped />}
      navigationBar={<NavigationBar />}
      // footer={<Footer />}
    />
  );
};

export default MEMI04;
