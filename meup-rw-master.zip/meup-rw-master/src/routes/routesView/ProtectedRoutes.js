import { ErrorBoundary } from "providers";
import React, { useCallback } from "react";
import { Route } from "react-router-dom";
import { authTokenCookie } from 'utils'
import {Environment} from '../../utils'
const ProtectedRoutes = (props) => {
  const { authCookie} = authTokenCookie();
 
  const { component: Component, label,...rest } = props;
  
  const handleAuthenticate = useCallback(() => {
    //Clear browser session storage on logout.
    sessionStorage.clear();
    // console.log("LOGIN_ROOT:");
    // console.log(process.env.REACT_APP_LOGIN_ROOT);
    window.location.replace(Environment.getLoginUrl());
  }, []);

  return (
    <Route
      {...rest}
      render={prop =>
          authCookie && authCookie.name ? <ErrorBoundary label={label}> <Component {...prop} /> </ErrorBoundary> :handleAuthenticate()
      }
    />
  );
}

export default ProtectedRoutes;