import React from "react";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Error404 } from "components";
import ProtectedRoutes from './ProtectedRoutes';
import routes from "../routes";
import { Environment } from '../../utils';
import { ErrorBoundary } from "providers";

// console.log("RoutesView:"+ Date.now()+":REACT_APP_LOGOUT_URL:");
// console.log(process.env.REACT_APP_LOGOUT_URL);

// console.log("RoutesView:"+ Date.now()+":window.location.href:");
// console.log(window.location.href);

// console.log("RoutesView:"+ Date.now()+":REACT_APP_CONSOLELOG_ON:");
// console.log(process.env.REACT_APP_CONSOLELOG_ON);

export const RoutesView = () => {
    return (
        <Router basename={Environment.getAppContextPath()}>
            <Switch>
                {routes.map((route, index) => {
                    
                    if (route.level === 'ProtectedRoutes') {
                        return <ProtectedRoutes key={index} {...route}></ProtectedRoutes>;
                    }
                    return <ErrorBoundary label={route.label}> <Route key={index} {...route}></Route> </ErrorBoundary>;
                })}
                <Route component={Error404} />
            </Switch>
        </Router>
    )
}

export default RoutesView;