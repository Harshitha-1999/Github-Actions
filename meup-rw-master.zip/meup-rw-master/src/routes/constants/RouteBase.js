import { Environment } from "utils";

export const RouteBase = {
//  ROOT: "/",
  ISC010: "/azureAdRedirectClientSideUrl",
  ISC020: "/storeSystemUserDefaults",
  PSC700: "/productInquiryMenu",
  PSC710: "/productInquiryInfoUpc",
  PSC720: "/productInquiryInfoPlu",
  PSC730: "/productInquiryDetail",
  LookupPage: "/lu",
  MEMI01: "/lookupPage",
  MEMI02: "/Mapping",
  MEMI03: "/MEMI03",
  MEMI04: "/MEMI04",
  MEMI05: "/MEMI05",
  MEMI06: "/",
  MEMI07: "/MEMI07",
  MEMI08: "/MEMI08",
  MEMI09: "/MEMI09",
  MEMI10: "/MEMI10",
  MEMI11: "/MEMI11",
  MEMI111: "/MEMI111",
  MEMI12: "/MEMI12",
  MEMI13: "/MEMI13",
  MEMI14: "/MEMI14",
  MEMI15: "/MEMI15",

  MEMI16: "/MEMI16",
  MEMI17: "/MEMI17",
  MEMI18: "/MEMI18",
  MEMI19: "/MEMI19",
  MEMI20: "/MEMI20",

  MEMI21: "/MEMI21",
  MEMI22: "/MEMI22",
  MEMI23: "/MEMI23",
  MEMI24: "/MEMI24",
  MEMI25: "/MEMI25",


  MEUP50: Environment.getReactAppCode() === "MEUP" ? "/" : "/MEUP50",
  MEUP51: "/MEUP51",
  MEUP52: "/MEUP52",
  MEUP53: "/MEUP53",
  MEUP54: "/MEUP54",
  MEUP56: "/MEUP56",
  
  MEUP55: "/MEUP55",
  MEUP57: "/MEUP57",
  MEUP58: "/MEUP58",
  MEUP59: '/MEUP59',
  MEUP60: "/MEUP60",
  MEUP61:"/MEUP61",
  MEUP62:"/MEUP62",
  MEUP63: "/MEUP63"

};