import { RouteBase } from './constants';
import { 
  MEUP50_LABEL_NAME,
  MEUP51_LABEL_NAME, 
  MEUP52_LABEL_NAME, 
  MEUP53_LABEL_NAME, 
  MEUP54_LABEL_NAME, 
  MEUP57_LABEL_NAME, 
  MEUP58_LABEL_NAME, 
  MEUP59_LABEL_NAME, 
  MEUP60_LABEL_NAME, 
  MEUP61_LABEL_NAME, 
  MEUP62_LABEL_NAME,
  MEUP63_LABEL_NAME 
} from '../utils/Constants';

// import MEMI01 from "pages/MEMI/MEMI01";
// import MEMI02 from "pages/MEMI/MEMI02";
// import MEMI03 from "pages/MEMI/MEMI03";
// import MEMI04 from "pages/MEMI/MEMI04";
// import MEMI05 from "pages/MEMI/MEMI05";
// import MEMI06 from "pages/MEMI/MEMI06";
// import MEMI07 from "pages/MEMI/MEMI07";
// import MEMI08 from "pages/MEMI/MEMI08";
// import MEMI09 from "pages/MEMI/MEMI09";
// import MEMI10 from "pages/MEMI/MEMI10";
// import MEMI11 from "pages/MEMI/MEMI11";
// import MEMI111 from "pages/MEMI/MEMI111";
// import MEMI12 from "pages/MEMI/MEMI12";
// import MEMI13 from "pages/MEMI/MEMI13";
// import MEMI14 from "pages/MEMI/MEMI14";
// import MEMI15 from "pages/MEMI/MEMI15";
// import MEMI16 from "pages/MEMI/MEMI16";
// import MEMI17 from "pages/MEMI/MEMI17";
// import MEMI18 from "pages/MEMI/MEMI18";
// import MEMI19 from "pages/MEMI/MEMI19";
// import MEMI20 from "pages/MEMI/MEMI20";
// import MEMI21 from "pages/MEMI/MEMI21";
// import MEMI22 from "pages/MEMI/MEMI22";
// import MEMI23 from "pages/MEMI/MEMI23";
// import MEMI24 from "pages/MEMI/MEMI24";
// import MEMI25 from "pages/MEMI/MEMI25";
import MEUP50 from "pages/MEMI/MEUP50";
import MEUP51 from "pages/MEMI/MEUP51";
import MEUP52 from "pages/MEMI/MEUP52";
import MEUP53 from "pages/MEMI/MEUP53";
import MEUP54 from "pages/MEMI/MEUP54";
import MEUP56 from "pages/MEMI/MEUP56";
import MEUP55 from "pages/MEMI/MEUP55";
import MEUP57 from "pages/MEMI/MEUP57";
import MEUP60 from "pages/MEMI/MEUP60";
import MEUP61 from 'pages/MEMI/MEUP61'
import ButtonLogout from 'components/ButtonLogout/ButtonLogout';
import { Environment } from 'utils';

import MEUP58 from 'pages/MEMI/MEUP58';
import MEUP59 from 'pages/MEMI/MEUP59';
import MEUP62 from 'pages/MEMI/MEUP62'
import MEUP63 from 'pages/MEMI/MEUP63'
import { generateUserLevel } from 'components/CommonFunctionsMeup/CommonFunctionsMeup'

const routes = [
  // {
  //   path: `${RouteBase.MEMI10}`,
  //   component: MEMI10,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI06}`,
  //   component: MEMI06,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: <Menu />,
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI13}`,
  //   component: MEMI13,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "UPC Match / Model Like Item",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI17}`,
  //   component: MEMI17,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "New UPC / No Item Match",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },

  // {
  //   path: `${RouteBase.MEMI23}`,
  //   component: MEMI23,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "Displayer",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI21}`,
  //   component: MEMI21,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "Multi Unit Type",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  
  // {
  //   path: `${RouteBase.LookupPage}`,
  //   component: LookupPage,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: false,
  //   navNames: ["main", "memi"],
  // },
  // {
  //   path: `${RouteBase.MEMI01}`,
  //   component: MEMI01,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI02}`,
  //   component: MEMI02,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI03}`,
  //   component: MEMI03,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "ManualMapping MEMII03",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI04}`,
  //   component: MEMI04,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: 'yes', label: "Mapped MEMI04",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI05}`,
  //   component: MEMI05,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "Bakery MEMI05",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },

  // {
  //   path: `${RouteBase.MEMI07}`,
  //   component: MEMI07,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI08}`,
  //   component: MEMI08,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI15}`,
  //   component: MEMI15,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no", label: "Displayer",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI09}`,
  //   component: MEMI09,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI11}`,
  //   component: MEMI11,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no", label: "ManualMapping MI11",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI12}`,
  //   component: MEMI12,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI14}`,
  //   component: MEMI14,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "OverrideProcessCont MI14",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI16}`,
  //   component: MEMI16,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI18}`,
  //   component: MEMI18,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "AugmentationCont MI18",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI19}`,
  //   component: MEMI19,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI20}`,
  //   component: MEMI20,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no", label: "OverrideProcess MI20",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI22}`,
  //   component: MEMI22,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "MultiUnitCont MI22",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI24}`,
  //   component: MEMI24,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes", label: "Displayer Cont MEMI24",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  // {
  //   path: `${RouteBase.MEMI25}`,
  //   component: MEMI25,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "no", label: "MEMI25",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },
  {
    path: `${RouteBase.MEUP50}`,
    component: MEUP50,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: MEUP50_LABEL_NAME,
    navNames: ["main", "meup", "home", "meup-standard", "meup-holduser"],
    appcode: "MEUP"
  },
  {
    path: `${RouteBase.MEUP51}`,
    component: MEUP51,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: MEUP51_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP52}`,
    component: MEUP52,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: MEUP52_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP53}`,
    component: MEUP53,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: MEUP53_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP54}`,
    component: MEUP54,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: MEUP54_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP55}`,
    component: MEUP55,
    exact: true,
    level: "ProtectedRoutes",
    navigationBar: "no",
    label: "MEUP55",
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    label: "MEUP56",
    component: MEUP56,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    path: `${RouteBase.MEUP56}`,
    navNames: ["main", "meup", "meup-standard", "home"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP57}`,
    component: MEUP57,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: MEUP57_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP58}`,
    component: MEUP58,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: MEUP58_LABEL_NAME,
    navNames: ["main", "meup", "meup-holduser"],
    appcode: "MEUP"

  },
  {
    path: RouteBase.MEUP59,
    component: MEUP59,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "No", label: MEUP59_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"
  },
  {
    path: `${RouteBase.MEUP60}`,
    component: MEUP60,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: MEUP60_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP61}`,
    component: MEUP61,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: MEUP61_LABEL_NAME,
    navNames: ["main", "meup", "meup-standard", "meup-holduser"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP62}`,
    component: MEUP62,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: MEUP62_LABEL_NAME,
    navNames: ["main", "meup", "meup-holduser"],
    appcode: "MEUP"

  },
  {
    path: `${RouteBase.MEUP63}`,
    component: MEUP63,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: MEUP63_LABEL_NAME,
    navNames: ["main", "meup", "meup-holduser"],
    appcode: "MEUP"

  },

  // {
  //   path: `${RouteBase.MEMI111}`,
  //   component: MEMI111,
  //   exact: true,
  //   level: "ProtectedRoutes", navigationBar: "yes",
  //   navNames: ["main", "memi"],
  //   appcode: "MEMI"
  // },

];

///////////////////////////////////
// Buttons that are duplicate, or not routes, for later.
//////////////////////////////////
export const Buttons = [
  {
    path: `${RouteBase.MEUP50}`,
    navNames: ["main", "meup-standard", "home", "meup-holduser", "meup"],
    label: 'Home'
  },
  {
    component: <ButtonLogout classNameMemi="HeaderMeupButton" />,
    navNames: ["main", "meup-standard", "home", "meup-holduser", "meup"],
    label: 'Logout'
  },
];

////////////////////////////////////////////////////////////
// console.log("RoutesView:" + Date.now() + "routes:");
// console.log(routes);

/* Function that builds routes array - @Params - Array of strings of route */
const buildRoutes = (routesArray) => {


  const userLevel = generateUserLevel();


  let finalRoute = routesArray.filter((route) => {

    const validateAppCode = route.appcode === Environment.getReactAppCode() || Environment.getReactAppCode() === "TATA";

    if (Environment.getReactAppCode() === "MEUP") {

      //sample AD group for testing this functionality

      const validateAccessLevel = route.navNames.includes(userLevel) || userLevel === "meup-admin";
      return validateAppCode && validateAccessLevel
    }

    return validateAppCode;
  })

  if(finalRoute.length === 0) {
    finalRoute.push({
      path: `${RouteBase.MEUP61}`,
      component: MEUP61,
      exact: true,
      level: "ProtectedRoutes", navigationBar: "no", label: "No group access page",
      navNames: ["main", "meup", "meup-standard", "meup-holduser"],
      appcode: "MEUP"
  
    },
  )
  }
  
  
  

  return finalRoute;
}

export default buildRoutes(routes);
