import React, { useLayoutEffect, useContext } from "react";
import { RoutesView } from 'routes/routesView';
import { Environment } from "utils";
import { generateUserLevel } from "components/CommonFunctionsMeup/CommonFunctionsMeup";
import ApplicationContext from "./context/ApplicationContext";
import axios from "axios";
function App() {
  const appContext = Environment.getAppContextPath();

  const AppData = useContext(ApplicationContext)

 

  if (window.location.pathname !== `${appContext}/MEUP61` && generateUserLevel() === "") {
    window.location.replace(`${appContext}/MEUP61`)
  }

  useLayoutEffect(() => {
    axios.interceptors.request.use(function (config) {
      // spinning start to show
      AppData.setLoader(1);
      return config
    }, function (error) {
      return Promise.reject(error);
    });
  
    axios.interceptors.response.use(function (response) {
      // spinning hide
      AppData.setLoader(0);
  
      return response;
    }, function (error) {
      AppData.setLoader(-1)
      return Promise.reject(error);
    });
    document.title = Environment.getReactAppTitle()
  }, []);

  return (
    <>
      <RoutesView />
    </>
  );
}

export default App;