// Utility file to contain the various input behaviors and functions for the app

// default error message for paste action
const pasteOverLimitErrorMessageDefault = "Pasted value cannot exceed input max length";

/**
 * Sets the current focus and move the cursor position to the beginning of the target input
 * @param {string} target - The id of the input to set the window focus on 
 */
export const setFocus = (target) => {
    let el = document.getElementById(target);
    if(el) {
        el.focus();
        el.setSelectionRange(0,0);
    }
}

/**
 * Utility function to parse an Event Object and get a sanitized key string value, mostly to handle the case where
 * the user is holding the Shift or Ctrl keys down
 * @param {Object} ev - Event Object 
 * @returns {string} - Parsed key string
 */
export const keyCodeParser = (ev) => {
    let key = ev.key;
    if(ev.shiftKey){
        return `Shift+${key}`
    }
    if(ev.ctrlKey){
        return `Ctrl+${key}`
    }

    return key;
}


/**
 * Utility for handling Tab and Arrow key behavior
 * @param {Object} ev - Event Object
 * @param {string} nextInput - id of the input you want to go to next
 * @param {string} prevInput - id of the input you want to go back to
 */
export const tabAndArrowNavigationUtil = (ev, nextInput, prevInput) => {
    // only run when nextInput and prevInput are given
    if(nextInput && prevInput){
        switch(keyCodeParser(ev)){
            case "Tab":
            case "Down":
            case "ArrowDown":
                ev.preventDefault();
                ev.stopPropagation();
                setFocus(nextInput);
                break;
            case 'Shift+Tab':
            case "Up":
            case "ArrowUp":
                ev.preventDefault();
                ev.stopPropagation();
                setFocus(prevInput);
                break;
            default:
                break;
        }
    }
}

/**
 * Clears the current character and subs a space character while moving the cursor to the next character
 * on spacebar keydown
 * @function clearNextCharacterOnSpacebarPress
 * @param {object} event - The keydown event when the spacebar is pressed
 * @param {function} setFieldValue - The setFieldValue function from the formIk form for the associated form
 */
export const replaceNextCharacterOnKeyPress = (ev,setFieldValue, nextInput = "") => {

    // Prevent Default Spacebar behavior and stop event bubbling
    ev.preventDefault();
    ev.stopPropagation();

    let {id,value} = ev.target;
    let element = document.getElementById(id);
    let position = element.selectionStart;

    if(position === element.maxLength - 1 && nextInput){
        setFocus(nextInput);
    }
    if (position >= element.maxLength && nextInput){
        setFocus(nextInput);
        return;
    }
    
    let valueArray = value.split("");
    valueArray[position] = ev.key;
    setFieldValue(id, valueArray.join(""));

    window.requestAnimationFrame(() => {
        element.setSelectionRange(++position,position);
    })
}

// uat suggestion to disable backspace feature
/**
 * Move's the input caret to the left on Backspace key press
 * @param {Object} ev - Event Object 
 */

/**
export const moveCaretBackOnBackSpacePress = (ev) => {
    if(ev.key === "Backspace"){
        ev.preventDefault();
        ev.stopPropagation();
        let {id} = ev.target;
        let element = document.getElementById(id);
        let position = element.selectionStart;

        if(position === 0){
            return;
        }

        window.requestAnimationFrame(() => {
            element.setSelectionRange(--position,position);
        });
    }
}
*/

/**
 * Sanitize a form value, for now set an asterisk to a blank string
 * @param {string} value - Form value from formIk form
 * @returns {number} - Returns a sanitized value
 */
export const sanitizeFormValue = (value) => {
    if(value === "*"){
        return ""
    }
    return value;
}

/**
 * Sets an error message for the page level error box
 * @param {string} message - Error message text to set in the page level error field
 */
export const setPageLevelErrorMessage = (message) => {
    const ele = document.getElementById('txtError');
    ele.value = message;
    ele.style.color = 'red';
    ele.style.borderColor = 'red';
}

/**
 * Replaces characters in an input onPaste starting from the input's current caret position
 * @param {Object} ev - Event Object
 * @param {function} setFieldValue - The setFieldValue function from the formIk form for the associated form
 * @param {string} nextInput - id of the input you want to go to next
 */
export const replaceCharactersOnPaste = (ev,setFieldValue, nextInput = "", errorMsg = pasteOverLimitErrorMessageDefault) => {

    // Prevent Default Spacebar behavior and stop event bubbling
    ev.preventDefault();
    ev.stopPropagation();

    const pasteText = ev.clipboardData.getData('text');
    const {id,value} = ev.target;
    const element = document.getElementById(id);
    const position = element.selectionStart;
    const maxLength = element.maxLength;

    if(position + pasteText.length > maxLength){
        setPageLevelErrorMessage(errorMsg);
        return;
    }

    const preText = value.slice(0,position);
    const postText = value.slice(position + pasteText.length);

    const updatedTxt = preText + pasteText + postText;
    setFieldValue(id,updatedTxt.slice(0,maxLength));

    if(position + pasteText.length >= maxLength){
        setFocus(nextInput);
    }

    window.requestAnimationFrame(() => {
        element.setSelectionRange(position + pasteText.length + 1,position + pasteText.length);
    });
}
