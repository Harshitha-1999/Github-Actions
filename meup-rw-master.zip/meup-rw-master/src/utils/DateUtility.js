import moment from "moment-timezone";
import {formatdate} from "components/CommonFunctionsMeup/CommonFunctionsMeup"

export class DateUtility {

  static datesComparator(date1, date2) {
  var ms = moment(date1,"MM/DD/yyyy").diff(moment(date2,"MM/DD/yyyy"));
    return ms;
  }

  static getFormattedDate(dateValue) {
    let date = new Date(dateValue);
    // let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    let year = date.getFullYear().toString();
    year = year.length === 1 ? '000' + year : year.length === 2 ? '00' + year : year.length === 3 ? '0' + year : year;

    return month + '/' + day + '/' + year;
  }

  static convertDate(dateValue) {
    let date = new Date(dateValue);
    let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    return year + '-' + month + '-' + day;
  }

  static convertFormattedDate(dateValue) {
    let date = new Date(dateValue+" ");
    return moment(date).format('MM/DD/YYYY')
  }

  static stringToDate(_date)
{
            var formatLowerCase="MM/dd/yyyy".toLowerCase();
            var formatItems=formatLowerCase.split("/");
            var dateItems=_date.split("/");
            var monthIndex=formatItems.match("MM");
            var dayIndex=formatItems.match("dd");
            var yearIndex=formatItems.match("yyyy");
            var month=parseInt(dateItems[monthIndex]);
            month-=1;
            var formatedDate = new Date(dateItems[yearIndex],month,dateItems[dayIndex]);
            return formatedDate;
}

  static getWeekDay(dayNum) {
    let weekday = new Array(7);
    weekday[1] = "Sunday";
    weekday[2] = "Monday";
    weekday[3] = "Tuesday";
    weekday[4] = "Wednesday";
    weekday[5] = "Thursday";
    weekday[6] = "Friday";
    weekday[7] = "Saturday";
    return weekday[dayNum];
  }

  static getSalesDateStatus(code) {
    switch (code) {
      case "O":
        return "Open";
      case "C":
        return "Closed";
      case "S":
        return "Setup is required";
      default:
        return " ";
    }
  }

  static compareDates(date1, date2, condition) {

    const date1Formatted = this.getFormattedDate(date1);
    const date2Formatted = this.getFormattedDate(date2);
    if ((condition === "<=" || condition === ">=" || condition === "==") && date1Formatted === date2Formatted) {
      return true;
    }
    switch (condition) {
      case "<=":
        return (date1 < date2);
      case "<":
        return (date1 < date2);
      case ">=":
        return (date1 > date2);
      case ">":
        return (date1 > date2);
      default:
        return true;

    }
  }

  static diffDates(dateValue1, dateValue2) {
    let date1 = moment(dateValue1);
    let date2 = moment(dateValue2);
    return date1.diff(date2, 'days');
  }

  static getWeekNumber(dateValue) {
    return moment(dateValue).isoWeek();

  }

  static addDays(dateValue, days) {
    return this.getFormattedDate(new Date(dateValue).getTime() + days * 24 * 60 * 60 * 1000);
  }

  static subDays(dateValue, days) {
    return this.getFormattedDate(new Date(dateValue).getTime() - days * 24 * 60 * 60 * 1000);
  }

  static getCurrentDate() {
    return this.convertDate(moment().format('MM/DD/YYYY'));
  }

  static getMountainStdTime() {
    return moment(new Date()).tz('America/Denver').format('HH:mm:ss');
  }

  static getMountainStdDate() {
    return moment(new Date()).tz('America/Denver').format('YYYY-MM-DD');
  }

  static getMountainStdDateTime() {
    return moment(new Date()).tz('America/Denver').format('YYYY-MM-DD HH:mm:ss');
  }

  static validateDate(date) {
    return moment(date, 'MM/DD/YYYY', true).isValid()
  }
}

export default DateUtility;

