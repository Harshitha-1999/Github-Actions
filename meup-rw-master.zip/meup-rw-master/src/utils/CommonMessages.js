
export  class CommonMessages {
    static extractErrorMessage(data,systemCode,msgName){
        let filteredObject = data ? data.filter(object => object.systemCode === systemCode) : [];
        let filteredMessage = filteredObject.length ? filteredObject[0].messages.filter(message => message.name === msgName) : []
        return filteredMessage.length ? `${filteredMessage[0].screenMessage} ` : 'Error message not found'
    }

}


export default CommonMessages;
