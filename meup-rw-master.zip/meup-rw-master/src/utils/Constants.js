//constants
import Environment from "../utils/Environment";


export const corpCd = "001";

export const invalidDate = "Please enter a valid date";

export const invalidDateFormat = "The date entry is not in an acceptable format.\n \n  You can enter date only in the following format: mm/dd/yyyy.";

export const invalidPastIncludingPresentDateError = "Please set the Delete Date to at least one day in the future";

export const pastDate = "Delete date should be a future date";

export const selectDivision = "Please select a division";

export const emptyData = "Data is not entered";

export const noItem = "Please enter an item."

export const noStore = "Please enter a Store number.";

export const incompleteStoreItemDetails = "CIC/UPC not entered";

export const invalidStoreItemLength = "CIC should be minimum 7 digits./UPC should be minimum 10 digits./Store number should be 4 digits";

export const duplicate = "Duplicate entries found for CIC/store"

export const nonNumeric = "CIC/UPC/Store number should be numeric and a non-decimal value.";

export const MEUP50_LABEL_NAME = "Home";
export const MEUP51_LABEL_NAME = "Upload Warehouse Items for Blocking";
export const MEUP52_LABEL_NAME = "Enter Items and Stores for Blocking";
export const MEUP53_LABEL_NAME = "Update Store Items";
export const MEUP54_LABEL_NAME = "View Store Items Report";
export const MEUP57_LABEL_NAME = "Block Items";
export const MEUP58_LABEL_NAME = "Review Items In Hold Status";
export const MEUP59_LABEL_NAME = 'Update Store Item-Unblock';
export const MEUP60_LABEL_NAME = "Update Store Items - Modify and Delete Date";
export const MEUP61_LABEL_NAME = "No group access page";
export const MEUP62_LABEL_NAME = "Store Items On Hold - Store Counts";
export const MEUP63_LABEL_NAME = "Store Items On Hold - Store Items";

export const footerWarning   = "Warning: Authorized users only.";

export const footerInfoOne   = "All information herein is proprietary and confidential. Usage is monitored. Copyright Safeway Inc.";
export const footerInfoTwo   = "2022. All rights reserved. MEUP-Ver: " + Environment.getReactAppVersion();

export const schematic = "SCHEMATIC"

export const  unBlockingReasonError = "Please give a reason for unblocking."
export const characterAboveLimitError = "Comments should be less than or equal to 100 characters";
export const noItemSelectedUnblockError = "Atleast one store item must be selected to unblock" ;
export const confirmUnblock = "Are you sure you want to unblock the selected items?";

export const modifyDeleteDateReasonError = "Please give a reason for delete date change.";
export const noItemSelctedModifyDateReasonError = "Atleast one store item must be selected to modify delete date."
export const confirmModify = "Are you sure you want to modify the date?";