import React from "react";
import { Environment } from 'utils';


describe('<Environment />', () => {
    it('get public url test', () => {
        expect(Environment.getPublicUrl()).toBe("");
    });

    it('get node environment url test', () => {
        expect(Environment.getNodeEnvironment()).toBeTruthy();
    });

    it('get api url test', () => {
        expect(Environment.getApiUrl()).toBe("");
    })

    it('get azure redirect Uri test', () => {
        expect(Environment.getAzureRedirectUri()).toBe("");
    })

    it('get FOC redirect Uri url test', () => {
        expect(Environment.getFOCRedirectUri()).toBe("");
    });

    it('get help screen api url test', () => {
        expect(Environment.getHelpScreenApiUri()).toBe("");
    });
});