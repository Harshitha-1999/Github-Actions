import React from "react";
import { Provider } from "react-redux";
import { render, screen, fireEvent, waitFor, cleanup } from "@testing-library/react";
import { DateUtility } from './DateUtility'
import { CommonMessages } from './CommonMessages';

describe('test date utility', () => {
    it('common msg testing', () => {
        expect(CommonMessages.extractErrorMessage()).toBe('Error message not found')
    })
    it('date utility getMountainStdTime test', () => {
        expect(DateUtility.getMountainStdTime()).toHaveLength(8);
    })
    it('date utility getMountainStdDate test', () => {
        expect(DateUtility.getMountainStdDate()).toHaveLength(10);
    })
    // it('date utility checkDate test', () => {
    //     expect(DateUtility.checkDate('12/11/2021')).toBe(true);
    // }) 
    it('date utility getFormattedDate test', () => {
        expect(DateUtility.getFormattedDate('12/11/2021')).toBe('12/11/2021');
    })
    it('date utility convertDate test', () => {
        expect(DateUtility.convertDate('12/11/2021')).toBe('2021-12-11');
    })
    it('date utility getWeekDay test', () => {
        expect(DateUtility.getWeekDay(1)).toBe('Sunday');
    })
    it('date utility getSalesDateStatus test open', () => {
        expect(DateUtility.getSalesDateStatus('O')).toBe('Open');
    });
    it('date utility getSalesDateStatus test close', () => {
        expect(DateUtility.getSalesDateStatus('C')).toBe('Closed');
    })
    it('date utility getSalesDateStatus test setup required', () => {
        expect(DateUtility.getSalesDateStatus('S')).toBe('Setup is required');
    })
    it('date utility getSalesDateStatus test', () => {
        expect(DateUtility.getSalesDateStatus('')).toBe(' ');
    })
    it('date utility compareDates test <', () => {
        expect(DateUtility.compareDates('11/11/2021', '12/11/2021', '<')).toBe(true);
    })
    it('date utility compareDates test >', () => {
        expect(DateUtility.compareDates('12/11/2021', '11/11/2021', '>')).toBe(true);
    });
    it('date utility compareDates test =', () => {
        expect(DateUtility.compareDates('12/11/2021', '12/11/2021', '=')).toBe(true);
    });
    it('date utility compareDates test <=', () => {
        expect(DateUtility.compareDates('11/11/2021', '12/11/2021', '<=')).toBe(true);
    });
    it('date utility compareDates test >=', () => {
        expect(DateUtility.compareDates('12/11/2021', '11/11/2021', '>=')).toBe(true);
    });
    it('date utility compareDates test', () => {
        expect(DateUtility.compareDates('12/11/2021', '11/11/2021', '')).toBe(true);
    })
    it('date utility diffDates test', () => {
        expect(DateUtility.diffDates('12/11/2021', '12/10/2021')).toBe(1);
    })
    // it('date utility getConvertedMountainStdTime test', () => {
    //     expect(DateUtility.getConvertedMountainStdTime()).toHaveLength(6);
    // })
    // it('date utility getMSTCurrentDate test', () => {
    //     expect(DateUtility.getMSTCurrentDate()).toHaveLength(10);
    // })
    it('date utility getCurrentDate test', () => {
        expect(DateUtility.getCurrentDate()).toHaveLength(10);
    });

    it('date utility getweeknumber test', () => {
        expect(DateUtility.getWeekNumber('02/04/2022')).toBe(5);
    })

    it('date utility addday test', () => {
        expect(DateUtility.addDays('12/11/2021', 55)).toBe('02/04/2022');
    });

    it('date utility sub day test', () => {
        expect(DateUtility.subDays('12/11/2021', 55)).toBe('10/17/2021');
    })


})