import { incompleteStoreItemDetails, noStore, invalidStoreItemLength, nonNumeric } from 'utils/Constants';

export function hasDuplicates(array) {
    return (new Set(array)).size !== array.length;
}

export function isNumber(num) {

    return !isNaN(parseFloat(num)) && isFinite(num)
}

export function isValidDate(date) {

    return !date || isNaN(date.getTime())
}

export function isPastDate(date) {
    return date - new Date() <= 0
}

export const validateStores = (stores) => {
    let error = "";
    if (stores.length === 0) {
        error = noStore;
    }
    for (let i = 0; i < stores.length; i++) {
        if (!isNumber(stores[i])) {
            error = nonNumeric
            break;
        }
        else if (stores[i].trim().length !== 4) {
            error = invalidStoreItemLength;
            break;
        }
    }
    return error === "" ? false : error;

}

export const validateItems = (items) => {
    let error = ""
    for (let i = 0; i < items.length; i++) {
        if (items[i]["UPC"].trim() === "" || items[i]["CIC"].trim() === "") {
            error = incompleteStoreItemDetails;
            break;
        }
        else if (!isNumber(items[i]["UPC"].trim()) || !isNumber(items[i]["CIC"].trim())) {
            error = nonNumeric
            break;
        }
        else if (items[i]["UPC"].trim().length < 10 || items[i]["CIC"].trim().length < 7) {
            error = invalidStoreItemLength;
            break;
        }
    }
    return error === "" ? false : error;
}

export function getSelectedRowData(data, currPage, rowsPerPage) {
    return data.slice((currPage-1) * rowsPerPage, Math.min((currPage-1) * rowsPerPage + rowsPerPage, data.length))
}