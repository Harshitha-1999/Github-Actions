import React from "react";
import { ServiceError } from 'components';
import { Header, Footer } from 'layouts';


export const ContentWrapper = ({ children, programName, foNumber, screenName, pageNumber, error, pfKeys, onHotKeyPress }) => {
    
    return (
        <React.Fragment>
            {error ?
                <ServiceError programName={programName} error={error} />
                :
                    <>
                        <Header programName={programName}  foNumber={foNumber} screenName={screenName} pageNumber={pageNumber} />
                        {children}
                        <Footer pfKeys={pfKeys} onHotKeyPress={onHotKeyPress} />
                    </>
            }
        </React.Fragment>
    );
};

export default ContentWrapper;