import React, { useState, useEffect } from 'react';
import "./Footer.scss";

export const Footer = ({ pfKeys, onHotKeyPress }) => {
    const [error, setError] = useState(undefined);

    useEffect(() => {
        let el = document.getElementById("txtError");
        el && setError(error);
    }, [error]);

    return (
        <footer>
            <input id="txtError" type="text" readOnly value={error} />
            <ul >
                {pfKeys.map((keys, index) => (
                     <li id={keys.key} key={keys.key}><button onClick={(event) => onHotKeyPress(event,keys.key)}>{keys.label}</button></li>
                ))}
            </ul>
        </footer>

    );
}

export default Footer;