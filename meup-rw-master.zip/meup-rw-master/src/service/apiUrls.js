import { corpCd } from "utils";
import Environment from "../utils/Environment";

const BASE_URL = Environment.getAppREACTAppAPIBASEURL();
// const BASE_URL = "http://localhost:8080/meup-services"
export const apiUrl = {}
export const MEUP_APIs = {
    "getDivisionListForUS":`${BASE_URL}/v1/divisions`,
    "getGroupListForDivision":`${BASE_URL}/v1/groups`,
    "getCategoryListForGroup":`${BASE_URL}/v1/categories`,
    "getStoreItems":`${BASE_URL}/v1/items`,
    "postblockItemsAndStores":`${BASE_URL}/v1/items/block`,
    "uploadStoreItems": `${BASE_URL}/v1/items/upload`,
    "getStoreItemsForReport":`${BASE_URL}/v1/report/items`,
    "getStoreCountsStoreItemsOnHold":`${BASE_URL}/v1/items/hold/storeCount?`,
    "getStoreItemsOnHold":`${BASE_URL}/v1/items/hold/`,
    "getItemsReport": `${BASE_URL}/v1/items/report`,
    "updateStoreItems":`${BASE_URL}/v1/items/update`,
    "getStoreStockingSection":`${BASE_URL}/v1/items/storeStockSection`,
    "postUpdateHoldStatus":`${BASE_URL}/v1/items/hold/updateStatus?groupId=`,
    "getAllGroupsInHoldStatus":`${BASE_URL}/v1/groupsByStatus?corp=${corpCd}`,
    "postUpdateHoldStatusStoreLevel":`${BASE_URL}/v1/items/hold/updateStoreLevel`,
    "getItemHistory":`${BASE_URL}/v1/report/item/history`
}
