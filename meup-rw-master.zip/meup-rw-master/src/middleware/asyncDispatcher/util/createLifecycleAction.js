export const createLifecycleAction = ({
  type,
  payload,
  error,
  lifecycle,
}) => ({
  type,
  payload,
  error,
  lifecycle,
});

export default createLifecycleAction;
