import { PROMISE_TYPE } from '../constants';
import { createAxiosDispatchPromiseHandle } from '../plugin/axios';

import { createDispatchPromiseHandle } from './createDispatchPromiseHandle';

export const handleDispatchLifecycle = (
  dispatch,
  action
) => {
  if(action.promiseType === PROMISE_TYPE){
    return createAxiosDispatchPromiseHandle(dispatch, action);
  }
  else{
    return createDispatchPromiseHandle(dispatch, action);
  }
};

export default handleDispatchLifecycle;
