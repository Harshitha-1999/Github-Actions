import {
  createAsyncDispatcher,
  createAction,
} from 'middleware/asyncDispatcher';
import createDispatchPromiseHandle from 'middleware/asyncDispatcher/util/createDispatchPromiseHandle';
import { PROMISE_TYPE } from 'middleware/asyncDispatcher/constants';



export const createAxiosAction = ({
  type,
  promise,
}) =>
  createAction({
    type,
    promise,
    promiseType: PROMISE_TYPE.AXIOS,
  });

export const createAxiosAsyncDispatcher = (hook,extendedState) =>
  createAsyncDispatcher(hook, extendedState);

export const createAxiosDispatchPromiseHandle = (
  dispatch,
  action
) => createDispatchPromiseHandle(dispatch, action);
