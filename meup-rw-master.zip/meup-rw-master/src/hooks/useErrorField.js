export const useErrorField = () => {

    const setErrorField = (message,widgetId=null,color="red") => {
        let txtError = document.getElementById("txtError");
        if(txtError){
            txtError.value=message;
            txtError.style.color = color;
            txtError.style.borderColor = color;

        }
        if (widgetId) {
            let elementId = document.getElementById(widgetId);
            if(elementId){
                elementId.style.color = color;
                elementId.style.borderColor = color;
            }
            else{
                return null;
            }
        }
    }

    const clearErrorField = (widgetId) => {
        let txtError = document.getElementById("txtError");
        if(txtError){
            txtError.value="";
            txtError.style.removeProperty("color");
            txtError.style.removeProperty("border-color");
        }
        if (widgetId) {
            let elementId = document.getElementById(widgetId);
            if(elementId){
                elementId.style.removeProperty("color");
                elementId.style.removeProperty("border-color");
            }
            else{
                return null;
            }
        }
    }
    return {
        setErrorField,
        clearErrorField
    };
}