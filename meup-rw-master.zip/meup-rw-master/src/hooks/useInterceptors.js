import { useState, useCallback } from 'react';
import {
  getDefaultResponseInterceptors,
  getDefaultRequestInterceptors,
  DefaultAxios,
} from 'api/util';

export const useInterceptors = () => {
  // disabling these lines because I need to maintain state, but just using the previous functionality within the set state since I need at instant state
  // so these variables aren't really 'unused'
  // eslint-disable-next-line
  const [
    // eslint-disable-next-line
    defaultResponseInterceptors,
    setDefaultResponseInterceptors,
  ] = useState([]);

  const [
    // eslint-disable-next-line
    defaultRequestInterceptors,
    setDefaultRequestInterceptors,
  ] = useState([]);

  const clearRequestInterceptors = useCallback(() => {
    setDefaultRequestInterceptors(prev => {
      prev.forEach(id => DefaultAxios.interceptors.request.eject(id));
      return [];
    });
  }, []);

  const clearResponseInterceptors = useCallback(() => {
    setDefaultResponseInterceptors(prev => {
      prev.forEach(id => DefaultAxios.interceptors.response.eject(id));
      return [];
    });
  }, []);

  const setupResponseInterceptors = useCallback(() => {
    setDefaultResponseInterceptors(
      getDefaultResponseInterceptors()
    );
  }, []);

  const setupRequestInterceptors = useCallback(() => {
    setDefaultRequestInterceptors(getDefaultRequestInterceptors());
  }, []);


  return {
    defaultResponseInterceptors,
    defaultRequestInterceptors,
    setupResponseInterceptors,
    setupRequestInterceptors,
    clearResponseInterceptors,
    clearRequestInterceptors,
  };
};
