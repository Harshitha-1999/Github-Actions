import { useHistory } from 'react-router-dom';
import {useCallback} from 'react';


export const useNavigate  = () => {
    const history = useHistory();
    const navigate = useCallback( (path) => {
        history.push(path);
    },[history]);

    return {
        navigate
    }
}

export default useNavigate;