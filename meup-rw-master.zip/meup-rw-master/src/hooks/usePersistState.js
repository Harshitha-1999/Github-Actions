import {useState, useContext} from 'react';
import ApplicationContext from "../context/ApplicationContext";


//custom hook to persist data even after page change
export const usePersistState = (initalState=null, uniqueKey) => {
   
    const AppData = useContext(ApplicationContext)
   
    const localState = AppData.appState[uniqueKey];
    const [state, setState] = useState(localState ? localState : initalState);

   
    function handleStateChange(value) {
       
        if(typeof(value) === "function") {
            const valueOf = value(state)
            AppData.setAppState(uniqueKey, valueOf);
            setState(value)
            return
        }
        AppData.setAppState(uniqueKey, value);
        setState(value)
    }

    return [
        state,
        handleStateChange
    ]
}