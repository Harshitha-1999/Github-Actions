import { renderHook, act } from '@testing-library/react-hooks'
import { usePagination } from './usePagination';

describe("usePagination hook", () => {
    test('getStartOfClientPageNo', () => {
        // const { result } = renderHook(() => usePagination())
        // expect(result.current.getStartOfClientPageNo()).toEqual(0);
    });

//     test('createArrayChunks page data is an empty array', () => {
//         const { result } = renderHook(() => usePagination());
//         act(() => {
//             result.current.createArrayChunks([]);
//         });
//         expect(result.current.pageData).toEqual([]);
//     });

//     test('createArrayChunks page data has length of 2', () => {
//         const { result } = renderHook(() => usePagination());
//         act(() => {
//             result.current.createArrayChunks([1,2],1,1);
//         });
//         expect(result.current.pageData).toEqual([1]);
//     });

//     test('createArrayChunks page data has length of 2, nextPage is 0', () => {
//         const { result } = renderHook(() => usePagination());
//         act(() => {
//             result.current.createArrayChunks([1,2],1,0);
//         });
//         expect(result.current.pageData).toEqual([1]);
//     });

//     test('getSelectedRecords', () => {
//         const { result } = renderHook(() => usePagination());
//         act(() => {
//            let k = result.current.getSelectedRecords(1);
//            expect(k).toEqual([]);
//         });
//     });

//     test('getSelectedRecords setPageData', () => {
//         const { result } = renderHook(() => usePagination());

//         act(() => {
//             result.current.setPageData([1,2]);
//         })

//         act(() => {
//             let k = result.current.getSelectedRecords(1);
//             expect(k).toEqual([1,2]);
//          });
//     });

//     test('getPageData', () => {
//         const { result } = renderHook(() => usePagination());

//         act(() => {
//             result.current.setPageNo(2)
//         })
//         act(() => {
//            result.current.createArrayChunks([-1,0,1,2],1,1);
//            result.current.setPageNo(2)
//            result.current.getPageData("F7");
//            expect(result.current.pageNo).toEqual(2)
//            result.current.getPageData("F8");
//            expect(result.current.pageNo).toEqual(2)
//         });
//     });

//     test('checkEndofRecords', () => {
//         const { result } = renderHook(() => usePagination());

//         act(() => {
//             result.current.setPageNo(2);
//             result.current.createArrayChunks([-1,0,1,2],1,1);
//         });
//         act(() => {
//            let k = result.current.checkEndofRecords("F8");
//            expect(k).toEqual(false);
//         });
//     });

//     test('handleSelection if path', () => {
//         //stub out document.getElementById
//         jest.spyOn(document, 'getElementById').mockReturnValue({
//             selectionStart: 0,
//             maxLength: 1,
//             focus: jest.fn(),
//             setSelectionRange: jest.fn()
//         });

//         //stub window.requestAnimationFrame

//         jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
//             console.log('CALLED');
//             cb();
//         });

//         const { result } = renderHook(() => usePagination());
//         const ev = {
//             target: {
//                 value: 'S'
//             },
//             preventDefault: jest.fn(),
//             stopPropagation: jest.fn(),
//             key: 's'
//         }

//         act(() => {
//             let data = [
//                 {'S': "s", "test": 's'},
//                 {'S': "s", 'isValid': true, "test": "s"},
//                 {'S': "", 'isValid': true, "test": ""}
//             ]
//             result.current.createArrayChunks(data);
//         });
        
//         act(() => {
//             result.current.handleSelection(ev,0,'S',true, 'next')
//         });

//         expect(result.current.pageDataWithProperty[0].isValid).toEqual(true);

//         act(() => {
//             result.current.handleSelection(ev,0,'test',false)
//         });

//         expect(result.current.pageDataWithProperty[0].isValid).toEqual(false);

//     });

//     test('handleSelection else path', () => {
//         //stub out document.getElementById
//         jest.spyOn(document, 'getElementById').mockReturnValue({
//             selectionStart: 2,
//             maxLength: 2,
//             focus: jest.fn(),
//             setSelectionRange: jest.fn()
//         })

//         const { result } = renderHook(() => usePagination());
//         let ev = {
//             target: {
//                 value: 'X'
//             },
//             preventDefault: jest.fn(),
//             stopPropagation: jest.fn()
//         }

//         act(() => {
//             let data = [
//                 {'test': 1},
//                 {'test-field': 'S', 'isValid': true}
//             ]
//             result.current.createArrayChunks(data);
            
//         });
        
//         act(() => {
//             result.current.handleSelection(ev,0,'test-field',true, 'next')
//         });

//         expect(result.current.pageDataWithProperty[0].isValid).toEqual(false);

//         act(() => {
//             result.current.handleSelection(ev,0,'test-field',false)
//         });

//         expect(result.current.pageDataWithProperty[0].isValid).toEqual(false);
//     });

//     test('resetSelections', () => {
//         const { result } = renderHook(() => usePagination());

//         act(() => {
//             let data = [
//                 {'test': 1, 'isValid': true},
//                 {'test': 1}
//             ]
//             result.current.createArrayChunks(data);
//         });
//         act(() => {
//            result.current.resetSelections("test-field");
//         });
//     });

//     test('changeToUpperCase', () => {
//         const { result } = renderHook(() => usePagination());

//         act(() => {
//             let data = [
//                 {'test': 'ret', 'isValid': true},
//                 {'test': 'set'}
//             ]
//             result.current.createArrayChunks(data);
//         });
//         act(() => {
//            result.current.changeToUpperCase("test");
//         });
//     });
 })
