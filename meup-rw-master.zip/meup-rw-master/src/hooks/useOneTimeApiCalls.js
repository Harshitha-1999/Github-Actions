import {useEffect} from 'react';
import { useAccessDetails } from 'hooks';

export const useOneTimeApiCalls = () => {
    const { fetchAccessDetails } = useAccessDetails();

    useEffect(() => {
        fetchAccessDetails();
    },[fetchAccessDetails]);

}

export default useOneTimeApiCalls;