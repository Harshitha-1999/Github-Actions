#note-lkg
ls
npm run buildsrv
npm run startsrv & npm start
#


#npm run buildsrv
#npm run startsrv&
#npm run build 
#serve -s build

#npm start
#npm run startsrv & npm run build && serve -s build


############# IS01 Ref App Above
#cd /app && npm run buildsrv && npm run startsrv &
#npm run build && npm run start

#echo start.sh v02102022
#cd /app 
#npm run buildsrv 
#npm run startsrv 
#################################################


#npm run build && serve -s build &
#npm run start





