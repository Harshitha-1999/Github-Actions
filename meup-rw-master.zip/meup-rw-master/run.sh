
#Installing
rm -rf node_modules
npm install 
#npm rebuild node-sass
#Running build
npm run build
#Removing .eslintcache
#rm -r .eslintcache

#starting the application
npm start
