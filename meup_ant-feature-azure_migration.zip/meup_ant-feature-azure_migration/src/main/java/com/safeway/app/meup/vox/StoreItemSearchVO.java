package com.safeway.app.meup.vox;

import java.util.Date;
import java.util.List;

public class StoreItemSearchVO {

    /**
     * List of divisions.
     */
    private List<DivisionVO> divisionList;

    /**
     * List of groups.
     */
    private List<SmicGroupVO> smicGroupList;

    /**
     * List of categorys.
     */
    private List<SmicCategoryVO> smicCategoryList;

    /**
     * holds cic.
     */
    private String cic;

    /**
     * holds upc_manuf.
     */
    private String upcManuf;

    /**
     * holds upc_sales.
     */
    private String upcSales;

    /**
     * holds upc_country.
     */
    private String upcCountry;

    /**
     * holds upc_system.
     */
    private String upcSystem;

    /**
     * holds storeNumber.
     */
    private String storeNumber;

    /**
     * holds deleteDateStart.
     */
    private Date deleteDateStart;

    /**
     * holds deleteDateEnd.
     */
    private Date deleteDateEnd;

    /**
     * holds user.
     */
    private UserVO userVO;

    /**
     * holds state.
     */
    private String state;

    /**
     * holds corp.
     */
    private String corp;

    /**
     * holds the status unblocked/blocked.
     */
    private String status;

    /**
     * Flag for indicating that the change in DeleteDate is required.
     */
    private boolean isDeleteDateChange;

    /**
     * @return Returns the isDeleteDateChange.
     */
    public boolean isDeleteDateChange() {
        return isDeleteDateChange;
    }

    /**
     * @param isDeleteDateChange The isDeleteDateChange to set.
     */
    public void setDeleteDateChange(boolean isDeleteDateChange) {
        this.isDeleteDateChange = isDeleteDateChange;
    }

    /**
     * @return Returns the corp.
     */
    public String getCorp() {
        return corp;
    }

    /**
     * @param corp The corp to set.
     */
    public void setCorp(String corp) {
        this.corp = corp;
    }

    /**
     * @return Returns the smicGroupList.
     */
    public List getSmicGroupList() {
        return smicGroupList;
    }

    /**
     * @param groupList The smicGroupList to set.
     */
    public void setSmicGroupList(List<SmicGroupVO> groupList) {
        this.smicGroupList = groupList;
    }

    /**
     * @return Returns the state.
     */
    public String getState() {
        return state;
    }

    /**
     * @param state The state to set.
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @return Returns the smicCategoryList.
     */
    public List getSmicCategoryList() {
        return smicCategoryList;
    }

    /**
     * @param categoryList The smicCategoryList to set.
     */
    public void setSmicCategoryList(List<SmicCategoryVO> categoryList) {
        this.smicCategoryList = categoryList;
    }

    /**
     * @return Returns the cic.
     */
    public String getCic() {
        return cic;
    }

    /**
     * @param cic The cic to set.
     */
    public void setCic(String cic) {
        this.cic = cic;
    }

    /**
     * @return Returns the deleteDateEnd.
     */
    public Date getDeleteDateEnd() {
        return deleteDateEnd;
    }

    /**
     * @param deleteDateEnd The deleteDateEnd to set.
     */
    public void setDeleteDateEnd(Date deleteDateEnd) {
        this.deleteDateEnd = deleteDateEnd;
    }

    /**
     * @return Returns the deleteDateStart.
     */
    public Date getDeleteDateStart() {
        return deleteDateStart;
    }

    /**
     * @param deleteDateStart The deleteDateStart to set.
     */
    public void setDeleteDateStart(Date deleteDateStart) {
        this.deleteDateStart = deleteDateStart;
    }

    /**
     * @return Returns the divisionList.
     */
    public List getDivisionList() {
        return divisionList;
    }

    /**
     * @param divisionList The divisionList to set.
     */
    public void setDivisionList(List divisionList) {
        this.divisionList = divisionList;
    }

    /**
     * @return Returns the storeNumber.
     */
    public String getStoreNumber() {
        return storeNumber;
    }

    /**
     * @param storeNumber The storeNumber to set.
     */
    public void setStoreNumber(String storeNumber) {
        this.storeNumber = storeNumber;
    }

    /**
     * @return Returns the user.
     */
    public UserVO getUserVOX() {
        return userVO;
    }

    /**
     * @param userVO The user to set.
     */
    public void setUserVOX(UserVO userVO) {
        this.userVO = userVO;
    }

    /**
     * @return Returns the upcCountry.
     */
    public String getUpcCountry() {
        return upcCountry;
    }

    /**
     * @param upcCountry The upcCountry to set.
     */
    public void setUpcCountry(String upcCountry) {
        this.upcCountry = upcCountry;
    }

    /**
     * @return Returns the upcManuf.
     */
    public String getUpcManuf() {
        return upcManuf;
    }

    /**
     * @param upcManuf The upcManuf to set.
     */
    public void setUpcManuf(String upcManuf) {
        this.upcManuf = upcManuf;
    }

    /**
     * @return Returns the upcSales.
     */
    public String getUpcSales() {
        return upcSales;
    }

    /**
     * @param upcSales The upcSales to set.
     */
    public void setUpcSales(String upcSales) {
        this.upcSales = upcSales;
    }

    /**
     * @return Returns the upcSystem.
     */
    public String getUpcSystem() {
        return upcSystem;
    }

    /**
     * @param upcSystem The upcSystem to set.
     */
    public void setUpcSystem(String upcSystem) {
        this.upcSystem = upcSystem;
    }

    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        this.status = status;
    }
}
