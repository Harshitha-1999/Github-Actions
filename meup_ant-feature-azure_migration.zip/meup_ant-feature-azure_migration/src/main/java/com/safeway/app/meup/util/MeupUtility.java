
package com.safeway.app.meup.util;



import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.CharacterIterator;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.dto.UserDTO;
import com.safeway.app.meup.exceptions.LogErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;



public class MeupUtility {

    public UserDTO getUser(String OAM_REMOTE_USER, String APP_GROUPS, String DIVISION){

        String roleName=null;
        String div=null;

        String userId = OAM_REMOTE_USER;
        log.debug(userId);
        log.debug("App groups are : " +APP_GROUPS);
        boolean isAdmin = isUserInRole(MeupConstant.MEUP_ADMIN_GROUP,APP_GROUPS);
        if (isAdmin){
            roleName = MeupConstant.ADMIN_ROLE;
        }

        else {
            if (isUserInRole(MeupConstant.MEUP_HOLD_GROUP,APP_GROUPS))
            {
                roleName = MeupConstant.HOLD_ROLE;
            }
            else{
                if (isUserInRole(MeupConstant.MEUP_DIV_GROUP,APP_GROUPS))
                {
                    roleName = MeupConstant.DIV_ROLE;
                    if(null!=DIVISION){
                        div=DIVISION;
                    }
                }

                else
                {
                    roleName = MeupConstant.NONADMIN_ROLE;
                }
            }
        }


        /*Add the userid and rolename to UserDto*/
        log.debug("Role of the user is "+roleName);
        log.debug("DIVISION of the user is "+div);
        UserDTO userDto = new UserDTO();
        userDto.setRole(roleName);
        userDto.setUserId(userId);
        userDto.setDivision(div);
        return userDto;
    }

    private boolean isUserInRole(String oamGroup, String allGroups) {
        oamGroup = oamGroup.toLowerCase();
        log.debug("Group names :"+ allGroups);
        String[] groupArray = null;
        if (null!=allGroups && !allGroups.isEmpty()) {
            groupArray = allGroups.trim().split(":");
            for(String group:groupArray){
                log.debug("Group name:"+ group);
                if(oamGroup.equalsIgnoreCase(group.trim())){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * defining the logging framework.
     */
    private static final Log log = LogFactory.getLog(MeupUtility.class);

    /**
     * Declaring the resource manager
     */
    //temp comment
   // private static final TypecastResourceManager tMgr = new TypecastResourceManager(
     //       MeupUtility.class);

    /**
     * Get current Timestamp.
     *
     * @return Timestamp
     */
    public static Timestamp getCurrentTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * This methods returns true if all chars in the
     * String passed are decimal
     * digits else returns false. It will return false if String with first
     * character as ASCII minus sign '-' (\u002D') (to indicate a negative
     * value) is passed.
     *
     * @param str String
     * @return boolean
     */
    public static boolean isAllDecimalDigit(String str) {

        boolean isDigit = true;
        long longVal = 0;

        try {
            longVal = Long.parseLong(str);
        } catch (NumberFormatException ne) {

            /*return false if not all are decimal digits*/
            isDigit = false;
        }

        /*CIC/UPC cannot be negative values*/
        if (longVal < 0) {

            /*return false if first character is minus sign '-'*/
            isDigit = false;
        }

        return isDigit;
    }

    /**
     * This methods returns the size of the String
     * after omitting the leading
     * and trailing whitespace.
     *
     * @param str String
     * @return int
     */
    public static int getTrimmedStringSize(String str) {

        int trimmedStrSize = 0;

        if (str != null) {
            String trimmedStr = str.trim();
            trimmedStrSize = trimmedStr.length();
        }

        return trimmedStrSize;
    }

    /**
     * This method returns the date formatted as "MM/dd/yyyy" String.
     *
     * @param date Date
     * @return String
     */
    public static String dateFormatter(Date date) {
        SimpleDateFormat df = new SimpleDateFormat(MeupConstant.DATE_FORMAT);
        String dtStr = df.format(date);
        return dtStr;
    }

    /**
     * This method returns the current date.
     *
     * @return Date
     */
    public static Date getCurrentDate() {
        return new Date();
    }


    /**
     * To get today's Date as String object.
     *
     * @return String
     */
    public static String getCurrentDateAsString() {
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        DateFormat dateFormat = new SimpleDateFormat(MeupConstant.DATE_FORMAT);
        String currentDate = dateFormat.format(date);
        return currentDate;
    }

    /**
     * This method checks if the year passed is a leap year.
     *
     * @param year year
     * @return boolean
     */
    public static boolean isLeapYear(int year) {
        boolean y4 = ((year % 4) == 0);
        boolean y100 = ((year % 100) == 0);
        boolean y400 = ((year % 400) == 0);
        return (y400 || (y4 && !y100));
    }


    /**
     * This method is for converting a Date object to String.
     *
     * @param date date
     * @return String
     * @throws ParseException
     */
    public static String getDateFormat(Date date) {

        SimpleDateFormat dateFormatter = new SimpleDateFormat(
                MeupConstant.DATE_FORMAT);
        String dateNewFormat = dateFormatter.format(date);
        return dateNewFormat;
    }

    /**
     * This method is for converting a Date object to String.
     *
     * @param date date
     * @return String
     * @throws ParseException
     */
    public static String getDateFormat(LocalDate date) {

        SimpleDateFormat dateFormatter = new SimpleDateFormat(
                MeupConstant.DATE_FORMAT);
        String dateNewFormat = dateFormatter.format(date);
        return dateNewFormat;
    }

    /**
     * Utility method to check if given date is in the given date format.
     *
     * @param date       date
     * @param dateFormat date format
     * @return isValidDate
     */
    public static boolean isValidDate(Date date, String dateFormat) {
        boolean isValidDate = false;
        if (date != null && dateFormat != null) {
            DateFormat df = new SimpleDateFormat(dateFormat);
            try {

                df.parse(df.format(date));
                isValidDate = true;

            } catch (ParseException e) {
                isValidDate = false;
            }
        }
        return isValidDate;
    }

    /**
     * This method returns the list of objects that need to be in session.
     *
     * @param sessionKeys sessions
     * @return objectsReq
     */
    public static List getObjectsReqInSession(String sessionKeys) {
        List objectsReq = null;
        objectsReq = Arrays.asList(sessionKeys.split("[|]"));
        return objectsReq;
    }


    /**
     * This method sorts the List on the sortField passed in
     * based on whether it is ascending or descending sort
     * depending on asc boolean argument.
     *
     * @param displayList List to be sorted
     * @param sortField   Field on which the List is to be sorted
     * @param asc         boolean argument to decide whether asecding or
     *                    descending sort
     */
    public static void sortDisplayList(List displayList, String sortField,
                                       boolean asc) {

        /*check for null condidtion and empty list before sorting */
        if (displayList != null && displayList.size() != 0) {
            Comparator comparator = new MeupComparator(sortField, asc);
            Collections.sort(displayList, comparator);
        }
    }

    /**
     * This method returns boolean value for deciding on the sort type. i.e.
     * true for ascending and false for descending.
     *
     * @param obj       Object
     * @param sortField String
     * @return boolean the sort type
     */
    public static boolean getSortType(Object obj, String sortField) {
        boolean sortType = false;
        Class c = obj.getClass();
        String methodNameSet = "setAsc" + sortField;
        String methodNameGet = "isAsc" + sortField;

        try {
            Method methodSetter = c.getMethod(methodNameSet,
                    boolean.class);
            Method methodGetter = c.getMethod(methodNameGet);
            Object value = methodGetter.invoke(obj);

            sortType = new Boolean(value.toString()).booleanValue();

            if (!sortType) {
                methodSetter.invoke(obj, new Boolean(true));
            } else {
                methodSetter.invoke(obj, new Boolean(false));
            }
            Method[] methods = c.getDeclaredMethods();
            for (int i = 0; i < methods.length; i++) {
                if (methods[i].getName().startsWith("setAsc") &&
                        !methods[i].getName().equals(methodNameSet)) {
                    methods[i].invoke(obj, new Boolean(false));
                }
            }

            value = methodGetter.invoke(obj);

            sortType = new Boolean(value.toString()).booleanValue();

        } catch (IllegalArgumentException e1) {

            /*no action*/
        } catch (IllegalAccessException e1) {

            /*no action*/
        } catch (InvocationTargetException e1) {

            /*no action*/
        } catch (SecurityException e) {

            /*no action*/
        } catch (NoSuchMethodException e) {

            /*no action*/
        }

        return sortType;
    }

    /**
     * Method used to format the date into yyyy-MM-dd format.
     *
     * @param tempDate
     * @return String date in required format as a string.
     */
    public static String formatDateForSql(Date tempDate) {
        String date = null;
        SimpleDateFormat formatter = new SimpleDateFormat(
                MeupConstant.SQL_DATE_FORMAT);
        date = formatter.format(tempDate);
        return date;
    }

    /**
     * Method used to get comma separated string.
     *
     * @param divisionDTOList
     * @return comma separated string.
     */
    public static String getCommaSeparatedStringForDivision(List<DivisionDTO> divisionDTOList) {
        StringBuffer dataStrBuf = new StringBuffer();
        DivisionDTO divisionDTO = null;
        int listSize = divisionDTOList.size();
        for (int index = 0; index < listSize; index++) {
            dataStrBuf.append(MeupConstant.SINGLE_QUOTE);
            divisionDTO = divisionDTOList.get(index);
            dataStrBuf.append(divisionDTO.getDivisionNumber());
            dataStrBuf.append(MeupConstant.SINGLE_QUOTE);
            if (index < listSize - 1) {
                dataStrBuf.append(MeupConstant.COMMA);
            }
        }
        return dataStrBuf.toString();
    }

    /**
     * Method used to get comma separated string.
     *
     * @param divisionNumber -String.
     * @param dataStrBuf     - StringBuffer.
     * @return StringBuffer
     */
    public static StringBuffer getCommaSeparatedStringForDivision(String divisionNumber, StringBuffer dataStrBuf) {
        dataStrBuf.append(MeupConstant.SINGLE_QUOTE);
        dataStrBuf.append(divisionNumber);
        dataStrBuf.append(MeupConstant.SINGLE_QUOTE);
        dataStrBuf.append(MeupConstant.COMMA);
        return dataStrBuf;
    }


    /**
     * Method used to get comma separated string.
     *
     * @param categoryDTOList
     * @return comma separated string.
     */
    public static String getCommaSeparatedStringForCategory(List<SmicCategoryDTO> categoryDTOList) {
        SmicCategoryDTO categoryDTO = null;
        StringBuffer dataStrBuf = new StringBuffer();
        int listSize = categoryDTOList.size();
        for (int index = 0; index < listSize; index++) {
            categoryDTO = categoryDTOList.get(index);
            dataStrBuf.append(categoryDTO.getCategoryCd(), 2, 4);
            if (index < listSize - 1) {
                dataStrBuf.append(MeupConstant.COMMA);
            }
        }
        return dataStrBuf.toString();
    }

    /**
     * Method used to get comma separated string.
     *
     * @param groupCode
     * @return StringBuffer with comma separated strings.
     */
    public static StringBuffer getCommaSeparatedStringForGroup(String groupCode, StringBuffer dataStrBuf) {
        dataStrBuf.append(groupCode);
        dataStrBuf.append(MeupConstant.COMMA);
        return dataStrBuf;
    }

    /**
     * Method used to get comma separated string.
     *
     * @param categoryCodeList containing SmicGroupDTO.
     * @return comma separated string.
     */
    public static String getCommaSeparatedStringForCategoryCode(
            List categoryCodeList) {

        StringBuffer dataStrBuf = new StringBuffer();
        int listSize = categoryCodeList.size();
        for (int index = 0; index < listSize; index++) {
            dataStrBuf.append((String) categoryCodeList.get(index));
            if (index < listSize - 1) {
                dataStrBuf.append(MeupConstant.COMMA);
            }
        }
        return dataStrBuf.toString();
    }

    /**
     * Method used to get comma separated string.
     *
     * @param groupCodeList containing SmicGroupDTO.
     * @return comma separated string.
     */
    public static String getCommaSeparatedStringForGroupCode(
            List groupCodeList) {

        StringBuffer dataStrBuf = new StringBuffer();
        int listSize = groupCodeList.size();
        for (int index = 0; index < listSize; index++) {
            dataStrBuf.append((String) groupCodeList.get(index));
            if (index < listSize - 1) {
                dataStrBuf.append(MeupConstant.COMMA);
            }
        }
        return dataStrBuf.toString();
    }

    /**
     * Method used to get the group code from smicGroupDTO .
     *
     * @param groupDTOList smicGroupDTO list
     * @return List groupCodeList.
     */
    public static List getGroupCodesFromDto(List groupDTOList) {
        List groupCodeList = new ArrayList();
        Iterator iterator = groupDTOList.iterator();
        while (iterator.hasNext()) {
            SmicGroupDTO smicGroupDTO = (SmicGroupDTO) iterator.next();
            groupCodeList.add(smicGroupDTO.getGroupCd());
        }
        return groupCodeList;
    }

    /**
     * Method used to check whether state effective date is greater than the
     * current date.
     * If State effective date is at least one day past the current
     * date then it returns null
     *
     * @param stateEffDt state effective date in yyyy-MM-dd
     * @return Date state effective date.
     */
    public static Date checkStateEffDt(Date stateEffDt) {
        Date currentDate = getCurrentDate();
        if (!stateEffDt.after(currentDate)) {
            stateEffDt = null;
        }
        return stateEffDt;
    }

    //	jteta01: INC0576505 Modify date

    /**
     * A java.sql.Date version
     */
    public static java.sql.Date checkStateEffDt(java.sql.Date stateEffDt) {
        java.sql.Date currentDate = new java.sql.Date(new Date().getTime());
        if (!stateEffDt.after(currentDate)) {
            stateEffDt = null;
        }
        return stateEffDt;
    }

    /**
     * To get the list of buyerCommentCodes for identifying as Speciality Items.
     *
     * @return List
     */
    //temp comment
    /*public static List getSpecialityItems() {
        List items = new ArrayList();
        int itemSplSize = tMgr.getInt("list.size");

        *//*iterating the splItemcomment keys*//*
        for (int index = 1; index <= itemSplSize; index++) {
            items.add(tMgr.getString("spl.items.cmt." + index));
        }
        return items;

    }*/

    /**
     * To get the check if the item is a DSD item.
     *
     * @param dstCenter dstCenter
     * @return boolean flag
     */
    public static boolean checkForDsdItem(String dstCenter) {
        boolean flag = false;
        dstCenter = dstCenter.trim();
        if (null != dstCenter && !("").equals(dstCenter)) {
            char firstChar = dstCenter.charAt(0);
            if (MeupConstant.DSD_SPECIFICATION.charAt(0)==(firstChar)) {
                flag = true;
            }
        } else {
            log.debug("dst center is empty or null");
        }
        return flag;
    }


    /**
     * To get the check if the item is a Warehouse item.
     *
     * @param dstCenter dstCenter
     * @return boolean flag
     */
    public static boolean checkForWarehouseItem(String dstCenter) {
        boolean flag = false;
        dstCenter = dstCenter.trim();
        if (null != dstCenter && !("").equals(dstCenter)) {
            char firstChar = dstCenter.charAt(0);
            if (MeupConstant.WAREHOUSE_SPECIFICATION.equals(firstChar)) {
                flag = true;
            }
        } else {
            log.debug("dst center is empty or null");
        }
        return flag;
    }

    /**
     * To get the check if the item is a Speciality item.
     *
     * @param commentBuyer commentBuyer
     * @return boolean flag
     */
    //temp comment
    /*public static boolean checkForSpecialityItem(String commentBuyer) {
        boolean flag = false;
        commentBuyer = commentBuyer.trim();
        if (commentBuyer.length() > 1) {
            String startingLetters = commentBuyer.substring(0, 2);
            if (getSpecialityItems().contains(startingLetters)) {
                flag = true;
            }
        } else {

            flag = false;
        }
        return flag;
    }*/


    /**
     * To get the check if the item is a Cps item.
     *
     * @param dstCenter
     * @return boolean flag
     */
    public static boolean checkForCpsItem(String dstCenter) {
        boolean flag = false;
        dstCenter = dstCenter.trim();
        if (null != dstCenter && !("").equals(dstCenter)) {
            if (dstCenter.equals(MeupConstant.CPS_ITEM_TYPE_1.trim()) ||
                    dstCenter.equals(MeupConstant.CPS_ITEM_TYPE_2.trim())) {
                flag = true;
            }
        } else {
            log.debug("dst center is empty or null while chhecking for " +
                    "cps item");
        }

        return flag;
    }

    /**
     * This method returns a Calendar object for the date passed in String
     * format.
     *
     * @param dateString
     * @return Calendar
     * @throws MeupException
     */
    public static Calendar getCalendarForStringDate(String dateString)
            throws MeupException {
        Calendar cal = null;
        if (dateString != null && dateString.length() == 10) {
            cal = Calendar.getInstance();
            int[] dt = getYearMonthDayFromDate(dateString);

            cal.set(Calendar.MONTH, dt[1]);
            cal.set(Calendar.DAY_OF_MONTH, dt[2]);
            cal.set(Calendar.YEAR, dt[0]);
            cal.set(Calendar.HOUR, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            cal.set(Calendar.HOUR_OF_DAY, 0);

        } else {
            throw new MeupException(LogErrorMessage.INVALID_DATE_EXCEPTION);
        }

        return cal;
    }

    /**
     * Converts the date string of the format MM/DD/YYYY to an int array
     * containing year, month, day as the first, second, third element of the
     * array respectively.
     *
     * @param dateString
     * @return int array containing year, month, day respectively
     */
    public static int[] getYearMonthDayFromDate(String dateString)
            throws MeupException {
        int[] dt = new int[]{0, 0, 0};
        if (dateString != null && dateString.length() == 10) {

            /* set month as second element. Month value is 0-based */
            dt[1] = Integer.parseInt(dateString.substring(0, 2)) - 1;

            /* set day as third element */
            dt[2] = Integer.parseInt(dateString.substring(3, 5));

            /* set year as first element */
            dt[0] = Integer.parseInt(dateString.substring(6, 10));

            if (dt[1] > 11) {
                throw new MeupException(LogErrorMessage.INVALID_DATE_EXCEPTION);
            }
            if (dt[1] == 1) {/* February month */
                if (isLeapYear(dt[0])) {
                    if (dt[2] > 29) {
                        throw new MeupException(
                                LogErrorMessage.INVALID_DATE_EXCEPTION);
                    }
                } else {
                    if (dt[2] > 28) {
                        throw new MeupException(
                                LogErrorMessage.INVALID_DATE_EXCEPTION);
                    }
                }
            } else {
                /* months with 30 days */
                if (dt[1] == 3 || dt[1] == 5 || dt[1] == 8 || dt[1] == 10) {
                    if (dt[2] > 30) {
                        throw new MeupException(
                                LogErrorMessage.INVALID_DATE_EXCEPTION);
                    }
                } else {
                    if (dt[2] > 31) {
                        throw new MeupException(
                                LogErrorMessage.INVALID_DATE_EXCEPTION);
                    }
                }
            }
        }

        return dt;
    }

    /**
     * Method to create the low date
     *
     * @return Date
     */
    public static Date createLowDate() {
        Date date = null;
        try {
            date = MeupUtility.getCalendarForStringDate(MeupConstant.LOW_DATE).getTime();
        } catch (MeupException me) {

            /*date creation failed*/
            /*use deprecated method to create date*/
            date = new Date(MeupConstant.LOW_DATE);
        }
        return date;
    }

    /**
     * This method checks whether the given strind is an alphabet
     *
     * @param inString value to hold the any Sring value which is passed as arguments.
     * @return true if all the characters in the String are digits.
     */
    public static boolean isAlphabet(String inString) {
        boolean returnValue = true;
        CharacterIterator theIterator = new StringCharacterIterator(inString);
        for (char ch = theIterator.first(); ch != CharacterIterator.DONE; ch =
                theIterator
                        .next()) {
            if (!Character.isLetter(ch)) {
                returnValue = false;
            }
        }
        return returnValue;
    }

    /**
     * This method is used to append Zeros
     *
     * @param stringValue value to hold the any Sring value which is passed as arguments.
     * @param length
     * @return appended String
     */
    public static String appendZeros(String stringValue, int length) {
        int stringLength;
        StringBuffer sbuff = new StringBuffer();
        stringLength = stringValue.length();
        for (; stringLength < length; stringLength++) {
            sbuff.append("0");
        }
        sbuff.append(stringValue);
        return sbuff.toString();
    }

    /**
     * This method is used get all divisions for US and Canada
     *
     * @return DivisionDto List
     */
    //temp comment
    /*public static List getAllDivisions() {
        List divisionList = new ArrayList();
        divisionList.addAll(getDivisionsForUS());
        return divisionList;
    }*/

    /**
     * This method is used get all divisions for US
     *
     * @return DivisionDto List
     */
    //temp comment
    /*public static List getDivisionsForUS() {

        List divisionListForUS = null;
        String division = tMgr.get("division.us");
        String corp = MeupConstant.CORP_US;
        divisionListForUS = setValuesToDto(corp, division);
        return divisionListForUS;

    }*/

    /**
     * This method is used get all divisions for Canada
     *
     * @return DivisionDto List
     */
    //temp comment
    /*public static List getDivisionsForCanada() {

        List divisionListForCanada = null;
        String division = tMgr.get("division.canada");
        String corp = MeupConstant.CORP_CANADA;
        divisionListForCanada = setValuesToDto(corp, division);
        return divisionListForCanada;
    }*/

    /**
     * This method creates the Division Dto
     *
     * @param corp
     * @param valuesForDivision
     * @return
     */
    //temp comment
    /*private static List setValuesToDto(String corp, String valuesForDivision) {
        List divisionDtoList = new ArrayList();

        String divNumName = null;
        int counter;
        String[] divDetatil = new String[tMgr.getInt("array.size")];
        StringTokenizer stringToken = null, divisionDetails = null;
        stringToken = new StringTokenizer(valuesForDivision, MeupConstant.PIPE);
        while (stringToken.hasMoreTokens()) {
            divNumName = stringToken.nextToken().trim();
			*//*	divisionDetails=new StringTokenizer(divNumName,MeupConstant.HYPHEN_FOR_TOKENIZER);
			counter=tMgr.getInt("initial.size");
			while(divisionDetails.hasMoreTokens()){
				divDetatil[counter]=divisionDetails.nextToken().trim();
				counter ++;
			}*//*
            divDetatil = divNumName.split(MeupConstant.HYPHEN_FOR_TOKENIZER, 2);
            DivisionDTO divisionDTO = new DivisionDTO();
            divisionDTO.setCorp(corp);
            divisionDTO.setDivisionNumber(divDetatil[tMgr.getInt("initial.size")]);
            divisionDTO.setDivisionName(divDetatil[tMgr.getInt("size")]);
            divisionDtoList.add(divisionDTO);
        }
        return divisionDtoList;
    }*/

    /**
     * The method returns true if the code passed as the argument represents a
     * negative number when converted to a Long.
     *
     * @param code value to hold the any Sring value which is passed as arguments.
     * @return true if the String parsed is negative.
     */

    public static boolean isNegative(String code) {
        return (Long.parseLong(code) < 0);
    }

    /**
     * This method returns the first index of the delimiter present in
     * the String.
     *
     * @param data
     * @param delimiter say ','.
     * @return the integer obtained as the index.
     */
    public static int indexSeparator(String data, char delimiter) {

        /**Index variable to find the position of delimiter say ',' */
        return (data.indexOf(delimiter));
    }

    /**
     * Returns the String which is the substring of the String original.
     *
     * @param original which holds original String value for any string value.
     * @param start    which indicates the to starting character to separate the string value.
     * @param end      which indicates the end of character to separate the string value.
     * @return String value.
     */
    public static String getSubString(String original, int start, int end) {
        return original.substring(start, end);
    }

    /**
     * Returns the String which is the substring of the String original.
     *
     * @param original which holds original String value for any string value.
     * @param start    which indicates the to starting character to separate the string value.
     * @return String value.
     */
    public static String getSubString(String original, int start) {
        return original.substring(start);
    }

    /**
     * This method validates if the String
     * which is passed as the argument contains only numbers.
     *
     * @param inString value to hold the any Sring value which is passed as arguments.
     * @return true if all the characters in the String are digits.
     */
    public static boolean isNumeric(String inString) {
        boolean returnValue = true;
        CharacterIterator theIterator = new StringCharacterIterator(inString);
        for (char ch = theIterator.first(); ch != CharacterIterator.DONE; ch = theIterator
                .next()) {
            if (!Character.isDigit(ch)) {
                returnValue = false;
            }
        }
        return returnValue;
    }
    /**
     * To get the check if the item is a Speciality item.
     * @param  commentBuyer
     * @return boolean flag
     */
    public static boolean checkForSpecialityItem(String commentBuyer){
        boolean flag=false;
        commentBuyer=commentBuyer.trim();
        if(commentBuyer.length()>1){
            String startingLetters=commentBuyer.substring(0,2);
            if(getSpecialityItems().contains(startingLetters)){
                flag=true;
            }
        }else{

            flag=false;
        }
        return flag;
    }

    /**
     * To get the list of buyerCommentCodes for identifying as Speciality Items.
     *
     * @return List
     */
    public static List getSpecialityItems(){
        List items = new ArrayList();
        int itemSplSize = MeupConstant.LIST_SIZE;

        /*iterating the splItemcomment keys*/
        for(int index=1; index<=itemSplSize;index++){
            int spl_items_cmt=0;
            if(index==1)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_1;
            }else if(index==2)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_2;
            }else if(index==3)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_3;
            }else if(index==4)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_4;
            }else if(index==5)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_5;
            }else if(index==6)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_6;
            }else if(index==7)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_7;
            }else if(index==8)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_8;
            }else if(index==9)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_9;
            }else if(index==10)
            {
                spl_items_cmt=MeupConstant.SPL_ITEMS_CMT_10;
            }
            items.add(spl_items_cmt);
        }
        return items;

    }

}
