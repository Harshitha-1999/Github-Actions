package com.safeway.app.meup.controller;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.SmicGroupService;

@RestController
public class SmicGroupController extends BaseController {
	private static final Logger log = LoggerFactory.getLogger(SmicGroupController.class);

	@Autowired
	SmicGroupService smicGroupService;

	/**
	 * Method for getting the Group list for Selected Divisions
	 *
	 * @param divisionNumbers
	 * @return
	 * @throws MeupException
	 */
	@GetMapping("/v1/groups")
	public ResponseDTO getGroupListForDivision(@RequestParam(name = "divisionNumbers") List<String> divisionNumbers,
			@RequestParam(name = "corp") String corp) {
		log.info("--> SmicGroupController.getGroupListForDivision");
		List<SmicGroupDTO> smicGroupList = smicGroupService.getSmicGroupsForDivision(divisionNumbers, corp);
		ResponseDTO responseDTO = getResponseDTO(smicGroupList);
		return responseDTO;
	}

	/**
	 * Method for getting the Group list for Selected Divisions
	 *
	 * @param groupCds
	 * @return
	 * @throws MeupException
	 */
	@GetMapping("/v1/categories")
	public ResponseDTO getCategoryListForGroup(@RequestParam(name = "groupCds") List<Integer> groupCds,
			@RequestParam(name = "corp") String corp) {
		log.info("--> SmicGroupController.getCategoryListForGroup");
		List<SmicCategoryDTO> smicCategoryList = smicGroupService.getSmicCategoriesForGroups(groupCds, corp);
		ResponseDTO responseDTO = getResponseDTO(smicCategoryList);
		return responseDTO;
	}

	@GetMapping("/v1/groupsByStatus")
	public ResponseDTO getGroupsByStatus(@RequestParam String corp) throws SQLException, MeupException {
		log.info("--> SmicGroupController.getGroupsByStatus");
		List<SmicGroupDTO> list = smicGroupService.getGroupsByStatus(corp);
		ResponseDTO responseDTO = getResponseDTO(list);
		return responseDTO;
	}
}
