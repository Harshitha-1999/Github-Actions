
package com.safeway.app.meup.dto;

public class ColumnDTO {
	
	/**Holds the column index*/
    private int columnIndex;
    
    /**Holds the column name*/
    private String columnName;
    
    /**Flag for column visibility*/
    private boolean isVisible;
    
    /**Flag for column resizablity*/
    private boolean isResizable;
    
    /**Holds the column width*/
    private int width;
    
    /**Holds the column alignment*/
    private String alignment;
    
    /**Holds the column value type*/
    private String type;
    
    /**Holds the column value*/
    private String value;
    
    /**
     * @return Returns the columnIndex.
     */
    public int getColumnIndex() {
        return columnIndex;
    }
    
    /**
     * @param columnIndex The columnIndex to set.
     */
    public void setColumnIndex(int columnIndex) {
        this.columnIndex = columnIndex;
    }
    
    /**
     * @return Returns the columnName.
     */
    public String getColumnName() {
        return columnName;
    }
    
    /**
     * @param columnName The columnName to set.
     */
    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }
    
    /**
     * @return Returns the isresizable.
     */
    public boolean isResizable() {
        return isResizable;
    }
    
    /**
     * @param isresizable The isresizable to set.
     */
    public void setResizable(boolean isResizable) {
        this.isResizable = isResizable;
    }
    
    /**
     * @return Returns the isVisible.
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    /**
     * @param isVisible The isVisible to set.
     */
    public void setVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }

    /**
     * @return Returns the width.
     */
    public int getWidth() {
        return width;
    }
    
    /**
     * @param width The width to set.
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * @return Returns the align.
     */
    public String getAlignment() {
        return alignment;
    }
    
    /**
     * @param align The align to set.
     */
    public void setAlignment(String align) {
        this.alignment = align;
    }
    
    /**
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }
    
    /**
     * @param type The type to set.
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /**
     * @return Returns the value of the column.
     */
    public String getValue() {
        return value;
    }
    
    /**
     * @param value The value of the column to be set.
     */
    public void setValue(String value) {
        this.value = value;
    }
}

