package com.safeway.app.meup.vox;

public class ItemCountsByStoreVO {
    /**
     * variable userID
     *
     */
    private String userID;
    /**
     * variable to hold corp
     */
    private String corporationId;

    /**
     * variable to hold storeId
     */
    private String storeId;

    /**
     * variable to hold divisionId
     */
    private String divisionId;

    /**
     * variable to hold stockSectnbr
     */
    private String stockSectnbr;

    /**
     * variable to hold itemCount
     */
    private Integer itemCount;

    /**
     * variable to hold oldPogName
     */
    private String oldPogName;

    /**
     * variable to hold newPogName
     */
    private String newPogName;

    /**
     * variable to hold groupCd
     */
    private String groupCd;

    /**
     * variable to hold groupDesc
     */
    private String groupDesc;

    /**
     * variable to hold status
     */
    private String status;
    private long UpcID;

    private String temp;

    public String getTemp() {
		return temp;
	}

	public void setTemp(String temp) {
		this.temp = temp;
	}

	public void setUpcID(long upcID) {
		UpcID = upcID;
	}

	/**
     * @return the userID
     */
    public String getUserID() {
        return userID;
    }

    /**
     * @param userID the userID to set
     */
    public void setUserID(String userID) {
        this.userID = userID;
    }

    /**
     * @return the corporationId
     */
    public String getCorporationId() {
        return corporationId;
    }

    /**
     * @param corporationId the corporationId to set
     */
    public void setCorporationId(String corporationId) {
        this.corporationId = corporationId;
    }

    /**
     * @return the divisionId
     */
    public String getDivisionId() {
        return divisionId;
    }

    /**
     * @param divisionId the divisionId to set
     */
    public void setDivisionId(String divisionId) {
        this.divisionId = divisionId;
    }

    /**
     * @return the groupCd
     */
    public String getGroupCd() {
        return groupCd;
    }

    /**
     * @param groupCd the groupCd to set
     */
    public void setGroupCd(String groupCd) {
        this.groupCd = groupCd;
    }

    /**
     * @return the groupDesc
     */
    public String getGroupDesc() {
        return groupDesc;
    }

    /**
     * @param groupDesc the groupDesc to set
     */
    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    /**
     * @return the itemCount
     */
    public Integer getItemCount() {
        return itemCount;
    }

    /**
     * @param itemCount the itemCount to set
     */
    public void setItemCount(Integer itemCount) {
        this.itemCount = itemCount;
    }

    /**
     * @return the newPogName
     */
    public String getNewPogName() {
        return newPogName;
    }

    /**
     * @param newPogName the newPogName to set
     */
    public void setNewPogName(String newPogName) {
        this.newPogName = newPogName;
    }

    /**
     * @return the oldPogName
     */
    public String getOldPogName() {
        return oldPogName;
    }

    /**
     * @param oldPogName the oldPogName to set
     */
    public void setOldPogName(String oldPogName) {
        this.oldPogName = oldPogName;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        if (null != status) {
            temp = status;
            this.status = temp;
        }
        if (null == status && "A".equals(temp)) {
            this.status = temp;
        }
    }

    /**
     * @return the stockSectnbr
     */
    public String getStockSectnbr() {
        return stockSectnbr;
    }

    /**
     * @param stockSectnbr the stockSectnbr to set
     */
    public void setStockSectnbr(String stockSectnbr) {
        this.stockSectnbr = stockSectnbr;
    }

    /**
     * @return the storeId
     */
    public String getStoreId() {
        return storeId;
    }

    /**
     * @param storeId the storeId to set
     */
    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

	public long getUpcID() {
		// TODO Auto-generated method stub
		return 0;
	}
}
