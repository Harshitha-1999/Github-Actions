/* ****************************************************************************
 *
 * Copyright 2008, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */
package com.safeway.app.meup.dao;

import java.util.List;

/* *****************************************************************************
 *
 * NAME : StoreItemHistoryDAO.java
 *
 * SYSTEM : Unallocated Item Blocking
 *
 * REVISION HISTORY
 *
 * Revision 1.0
 * Dinesh Rajamony Jan 9, 2008.
 * Initial version
 *************************************************************************** */

//MEUP

import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.vox.StoreItemHistoryVO;
import com.safeway.app.meup.vox.StoreItemVO;

/*****************************************************************************
 * StoreItemHistoryDAO Interface.
 *
 * @author Sankar Madhavan Pillai.
 * @version 1.0
 *************************************************************************** */

public interface StoreItemHistoryDAO {


    /**
     * Method used to get a list of StoreItemHistory business objects.
     *
     * @param corp     - corp value
     * @param division - division number
     * @param fac      - fac value
     * @param cic      - corp_item_cd value
     * @return List containing StoreItemHistory business objects
     * @throws MeupException
     */
	List<StoreItemHistoryVO>  getStoreItemsForHistory(String corp, String division, String fac,
                                                     String cic) throws MeupException;

	void insertBlockedItemHistory(List<StoreItemVO> storeItemVOList) throws MeupException;
}

