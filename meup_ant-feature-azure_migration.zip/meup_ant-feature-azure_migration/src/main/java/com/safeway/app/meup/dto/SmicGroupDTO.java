
package com.safeway.app.meup.dto;



public class SmicGroupDTO {

    /**
     * holds the group code.
     */
    private String groupCd;

    /**
     * holds the group name.
     */
    private String groupName;

    /**
     * holds the corp.
     */
    private String corp;

    /**
     * @return Returns the dispGroup.
     */
    public String getDispGroup() {
        return groupCd + "-" + groupName;
    }

    /**
     * @return Returns the groupCd.
     */
    public String getGroupCd() {
        return groupCd;
    }

    /**
     * @param groupCd The groupCd to set.
     */
    public void setGroupCd(String groupCd) {
        this.groupCd = groupCd;
    }

    /**
     * @return Returns the groupName.
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * @param groupName The groupName to set.
     */
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    /**
     * @return Returns the corp.
     */
    public String getCorp() {
        return corp;
    }

    /**
     * @param corp The corp to set.
     */
    public void setCorp(String corp) {
        this.corp = corp;
    }
}
