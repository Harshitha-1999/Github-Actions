
package com.safeway.app.meup.dto;


import java.sql.Timestamp;



public class CommentDTO extends SerializableDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**String to store comments.*/
	private String comment;

	/**String to store last updated userid.*/
	private String lastUpdatedUser;

	/**String to store last updated timestamp.*/
	private Timestamp lastUpdatedTimeStamp;

	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment The comment to set.
	 */
	public void setComment(String comment) {
		//accept single quote --> csori00 11/17/2012
		//this.comment = comment;
		this.comment = comment.replaceAll("\'","\'\'");
	}

	/**
	 * @return Returns the lastUpdatedTimeStamp.
	 */
	public Timestamp getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	/**
	 * @param lastUpdatedTimeStamp The lastUpdatedTimeStamp to set.
	 */
	public void setLastUpdatedTimeStamp(Timestamp lastUpdateTs) {
		this.lastUpdatedTimeStamp = lastUpdateTs;
	}

	/**
	 * @return Returns the lastUpdatedUser.
	 */
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	/**
	 * @param lastUpdatedUser The lastUpdatedUser to set.
	 */
	public void setLastUpdatedUser(String lastUpdUserId) {
		this.lastUpdatedUser = lastUpdUserId;
	}
}