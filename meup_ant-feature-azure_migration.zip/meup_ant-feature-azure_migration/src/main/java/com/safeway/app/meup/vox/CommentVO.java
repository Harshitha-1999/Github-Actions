package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "MEUPCOMM")
public class CommentVO {

    @EmbeddedId
    CommentVOID commentVOID;
    /**
     * Comment inserted by the user.
     */
    @Column(name = "comm_dsc")
    String commentDesc = null;

    /**
     * @return Returns the commentDesc.
     */
    public String getCommentDesc() {
        return commentDesc;
    }

    /**
     * @param commentDesc The commentDesc to set.
     */
    public void setCommentDesc(String commentDesc) {
        this.commentDesc = commentDesc;
    }

    /**
     * @return Returns the lastUpdatedTimeStamp.
     */
    public String getLastUpdatedTimeStamp() {
        return commentVOID.getLastUpdatedTimeStamp();
    }

    /**
     * @param lastUpdatedTimeStamp The lastUpdatedTimeStamp to set.
     */
    public void setLastUpdatedTimeStamp(String lastUpdatedTimeStamp) {
        commentVOID.setLastUpdatedTimeStamp(lastUpdatedTimeStamp);
    }

    /**
     * @return Returns the lastUpdatedUser.
     */
    public String getLastUpdatedUser() {
        return commentVOID.getLastUpdatedUser();
    }

    /**
     * @param lastUpdatedUser The lastUpdatedUser to set.
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        commentVOID.setLastUpdatedUser(lastUpdatedUser);
    }

}
