package com.safeway.app.meup.vox;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "MEUPSTGI")
public class StagingItemVO {
    @EmbeddedId
    private StagingItemVOID stagingItemVOID;

    public StagingItemVOID getStagingItemVOID() {
        return stagingItemVOID;
    }

    public void setStagingItemVOID(StagingItemVOID stagingItemVOID) {
        this.stagingItemVOID = stagingItemVOID;
    }
}
