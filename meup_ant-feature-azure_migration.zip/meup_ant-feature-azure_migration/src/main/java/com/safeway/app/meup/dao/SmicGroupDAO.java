package com.safeway.app.meup.dao;

import java.sql.SQLException;
import java.util.List;

import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.exceptions.MeupException;



public interface SmicGroupDAO {

	List<SmicGroupDTO> selectSmicGroupsForDivision(String corp, List<String> divisionNumbers);

	List<SmicCategoryDTO> selectSmicCategoriesForGroups(String corp,  List<Integer> groupCode);

	List<SmicGroupDTO> getGroupsByStatus(String corp, char c, char d) throws SQLException, MeupException;

}
