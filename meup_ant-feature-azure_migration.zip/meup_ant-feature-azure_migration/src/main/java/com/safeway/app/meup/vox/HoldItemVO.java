
package com.safeway.app.meup.vox;



import java.io.Serializable;
import java.util.Date;


public class HoldItemVO implements Serializable {

    private HoldItemVOXId holdItemVOXId;
    /**
     * variable corp
     */
    private String corp;

    /**
     * variable groupId
     */
    private int groupId;

    /**
     * variable upcID
     */
    private long upcID;

    /**
     * variable cic
     */
    private int cic;

    /**
     * variable desc
     */
    private String desc;

    /**
     * variable stockSectionNbr
     */
    private int stockSectionNbr;

    /**
     * variable schematicEffectiveDate
     */
    private Date schematicEffectiveDate;

    /**
     * variable storeID
     */
    private int storeID;

    /**
     * variable divisionNbr
     */
    private int divisionNbr;

    /**
     * variable status
     */
    private String status;

    /**
     * variable status
     */
    private String itemStateCd;

    /**
     * variable status
     */
    private String blockedStatCd;

    /**
     * @return the cic
     */
  
    
  
    public int getCic() {
        return cic;
    }

    /**
     * @param cic the cic to set
     */
    public void setCic(int cic) {
        this.cic = cic;
    }

    /**
     * @return the corp
     */
    public String getCorp() {
        return corp;
    }

    /**
     * @param corp the corp to set
     */
    public void setCorp(String corp) {
        this.corp = corp;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the divisionNbr
     */
    public int getDivisionNbr() {
        return divisionNbr;
    }

    /**
     * @param divisionNbr the divisionNbr to set
     */
    public void setDivisionNbr(int divisionNbr) {
        this.divisionNbr = divisionNbr;
    }

    /**
     * @return the schematicEffectiveDate
     */
    public Date getSchematicEffectiveDate() {
        return schematicEffectiveDate;
    }

    /**
     * @param schematicEffectiveDate the schematicEffectiveDate to set
     */
    public void setSchematicEffectiveDate(Date schematicEffectiveDate) {
        this.schematicEffectiveDate = schematicEffectiveDate;
    }

    /**
     * @return the storeID
     */
    public int getStoreID() {
        return storeID;
    }

    /**
     * @param storeID the storeID to set
     */
    public void setStoreID(int storeID) {
        this.storeID = storeID;
    }

    /**
     * @return the upcID
     */
    public long getUpcID() {
        return upcID;
    }

    /**
     * @param upcID the upcID to set
     */
    public void setUpcID(long upcID) {
        this.upcID = upcID;
    }

    /**
     * @return the stockSectionNbr
     */
    public int getStockSectionNbr() {
        return stockSectionNbr;
    }

    /**
     * @param stockSectionNbr the stockSectionNbr to set
     */
    public void setStockSectionNbr(int stockSectionNbr) {
        this.stockSectionNbr = stockSectionNbr;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the blockedStatCSd
     */
    public String getBlockedStatCd() {
        return blockedStatCd;
    }

    /**
     * @param blockedStatCd the blockedStatCSd to set
     */
    public void setBlockedStatCd(String blockedStatCd) {
        this.blockedStatCd = blockedStatCd;
    }

    /**
     * @return the itemStateCd
     */
    public String getItemStateCd() {
        return itemStateCd;
    }

    /**
     * @param itemStateCd the itemStateCd to set
     */
    public void setItemStateCd(String itemStateCd) {
        this.itemStateCd = itemStateCd;
    }

    /**
     * @return the groupId
     */
    public int getGroupId() {
        return groupId;
    }

    /**
     * @param groupId the groupId to set
     */
    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }
}
