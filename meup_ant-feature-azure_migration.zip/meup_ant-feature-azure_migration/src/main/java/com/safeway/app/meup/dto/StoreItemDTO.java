
package com.safeway.app.meup.dto;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.safeway.app.meup.util.MeupConstant;
import com.safeway.app.meup.util.MeupUtility;

public class StoreItemDTO {

	/**
	 * holds the smiccategoryDTo.
	 */
	private SmicCategoryDTO smicCategoryDto;

	private String upc;

	/**
	 * holds the divisiondto.
	 */
	private DivisionDTO divisionDto;

	/**
	 * holds the itemDTo.
	 */
	private ItemDTO itemDto;

	/**
	 * holds the store number.
	 */
	private String storeNumber;

	/**
	 * holds the state of the item.
	 */
	private String state;

	/**
	 * holds the effective date.
	 */
	//private Date stateEffectiveDate;
	private String stateEffectiveDate;

	/**
	 * holds the delete date.
	 */
	private String blockedTargetDate;

	/**
	 * holds the blocked status of the item.
	 */
	private String blockedStatus;

	/**
	 * holds the last updated u ser id.
	 */
	private String lastUpdatedUser;

	/**
	 * holds the last updated time stamp.
	 */
	private Timestamp lastUpdatedTimeStamp;

	/**
	 * holds the comments entered.
	 */
	private String commentDesc;

	/**
	 * holds the description of the item.
	 */
	private String description;

	/**
	 * holds the size.
	 */
	private float size;

	/**
	 * holds the uom.
	 */
	private String uom;

	/**
	 * holds the case pack.
	 */
	private float casePk;

	/**
	 * holds the smicgroupDTo.
	 */
	private SmicGroupDTO smicGroupDto;

	/**
	 * holds the value selected/not.
	 */
	private boolean selected;

	/**
	 * holds the item type.
	 */
	private String itemType;

	/**
	 * holds the blocked/unblocked status.
	 */
	private String status;

	/**
	 * holds the status for disabling checkbox.
	 */
	private boolean schematicData;

	private List historyInfo;

	/**
	 * @return Returns the schematicData.
	 */
	public List getHistoryInfo() {
		return historyInfo;
	}

	/**
	 * @param historyInfo The schematicData to set.
	 */
	public void setHistoryInfo(List historyInfo) {
		this.historyInfo = historyInfo;
	}

	/**
	 * @return Returns the schematicData.
	 */
	public boolean isSchematicData() {
		return schematicData;
	}

	/**
	 * @param schematicData The schematicData to set.
	 */
	public void setSchematicData(boolean schematicData) {
		this.schematicData = schematicData;
	}

	/**
	 * @return Returns the dispBlockedStatus.
	 */
	public String getDispBlockedStatus() {
		if (MeupConstant.BLOCKED_STATE.equals(blockedStatus)
				|| MeupConstant.BLOCKED_STATUS_CODE.equals(blockedStatus)) {
			return MeupConstant.BLOCKED_STATE;
		}
		return MeupConstant.UNBLOCKED_STATE;
	}

	/**
	 * @return Returns the selectionCode.
	 */
	public int getUniqueSelectionCode() {
		return this.hashCode();
	}

	/**
	 * @return Returns the itemType.
	 */
	public String getItemType() {
		return itemType;
	}

	/**
	 * @param itemType The itemType to set.
	 */
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return Returns the dispState.
	 */
	public String getDispState() {
		if (MeupConstant.UNALLOCATED_STATE.equals(state) || MeupConstant.STATE_UNALLOCATED.equals(state)) {
			return MeupConstant.UNALLOCATED_STATE;
		}
		return MeupConstant.ALLOCATED_STATE;
	}

	/**
	 * @return Returns the size and uom for display.
	 */
	public String getCasePkForDisplay() {
		String sizeStr = String.valueOf(casePk);
		return (sizeStr);
	}

	public String getSizeUOMForDisplay() {
		String sizeStr = String.valueOf(size);
		return (sizeStr + " " + uom);
	}

	/**
	 * @return Returns the selected.
	 */
	public boolean isSelected() {
		return selected;
	}

	/**
	 * @param selected The selected to set.
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	/**
	 * @return Returns the categoryCd.
	 */
	@JsonIgnore
	public String getCategoryCd() {
		return smicCategoryDto.getGroupCd() + smicCategoryDto.getCategoryCd();
	}

	/**
	 * @return Returns the divisionNumber.
	 */
	public String getDivisionNumber() {
		return divisionDto.getDivisionNumber();
	}

	/**
	 * @return Returns the cic.
	 */
	public String getCic() {
		return itemDto.getCic();
	}

	/**
	 * @return Returns the upc.
	 */
	public String getUpcItemDTo() {
		return itemDto.getUpcCountry() + itemDto.getUpcSystem() + itemDto.getUpcManuf() + itemDto.getUpcSales();
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	/**
	 * @return Returns the blockedStatus.
	 */
	public String getBlockedStatus() {
		return blockedStatus;
	}

	/**
	 * @param blockedStatus The blockedStatus to set.
	 */
	public void setBlockedStatus(String blockedStatus) {
		this.blockedStatus = blockedStatus;
	}

	/**
	 * @return Returns the blockedTargetDate.
	 */
	public String getBlockedTargetDate() {
		return blockedTargetDate;
	}

	/**
	 * @param blockedTargetDate The blockedTargetDate to set.
	 */
	public void setBlockedTargetDate(String blockedTargetDate) {
		this.blockedTargetDate = blockedTargetDate;
	}

	/**
	 * @return Returns the casePk.
	 */
	public float getCasePk() {
		return casePk;
	}

	/**
	 * @param casePk The casePk to set.
	 */
	public void setCasePk(float casePk) {
		this.casePk = casePk;
	}

	/**
	 * @return Returns the commentDesc.
	 */
	public String getCommentDesc() {
		return commentDesc;
	}

	/**
	 * @param commentDesc The commentDesc to set.
	 */
	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}

	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return Returns the divisionDto.
	 */
	public DivisionDTO getDivisionDto() {
		return divisionDto;
	}

	/**
	 * @param divisionDto The divisionDto to set.
	 */
	public void setDivisionDto(DivisionDTO divisionDto) {
		this.divisionDto = divisionDto;
	}

	/**
	 * @return Returns the itemDto.
	 */
	public ItemDTO getItemDto() {
		return itemDto;
	}

	/**
	 * @param itemDto The itemDto to set.
	 */
	public void setItemDto(ItemDTO itemDto) {
		this.itemDto = itemDto;
	}

	/**
	 * @return Returns the lastUpdatedTimeStamp.
	 */
	public Timestamp getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	/**
	 * @param lastUpdateTs The lastUpdatedTimeStamp to set.
	 */
	public void setLastUpdatedTimeStamp(Timestamp lastUpdateTs) {
		this.lastUpdatedTimeStamp = lastUpdateTs;
	}

	/**
	 * @return Returns the lastUpdUserId.
	 */
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	/**
	 * @param lastUpdatedUser The lastUpdUserId to set.
	 */
	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	/**
	 * @return Returns the size.
	 */
	public float getSize() {
		return size;
	}

	/**
	 * @param size The size to set.
	 */
	public void setSize(float size) {
		this.size = size;
	}

	/**
	 * @return Returns the smicCategoryDto.
	 */
	public SmicCategoryDTO getSmicCategoryDto() {
		return smicCategoryDto;
	}

	/**
	 * @param smicCategoryDto The smicCategoryDto to set.
	 */
	public void setSmicCategoryDto(SmicCategoryDTO smicCategoryDto) {
		this.smicCategoryDto = smicCategoryDto;
	}

	/**
	 * @return Returns the smicGroupDto.
	 */
	public SmicGroupDTO getSmicGroupDto() {
		return smicGroupDto;
	}

	/**
	 * @param smicGroupDto The smicGroupDto to set.
	 */
	public void setSmicGroupDto(SmicGroupDTO smicGroupDto) {
		this.smicGroupDto = smicGroupDto;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the stateEffectiveDate.
	 */
	public String getStateEffectiveDate() {
		return stateEffectiveDate;
	}

	/**
	 * @param stateEffectiveDate The stateEffectiveDate to set.
	 */
	public void setStateEffectiveDate(String stateEffectiveDate) {
		this.stateEffectiveDate = stateEffectiveDate;
	}

	/**
	 * @return Returns the stateEffectiveDate.
	 */
	public String getStateEffectiveDateForDisplayResult() throws ParseException {
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = formatter.parse(stateEffectiveDate);
		java.util.Date stateEffDate = null;
		String stateEffDateDisplay = "";
		if (null != stateEffectiveDate) {
			stateEffDate = MeupUtility.checkStateEffDt(date);
			if (stateEffDate == null) {
				stateEffDateDisplay = ".";
			} else {
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				stateEffDateDisplay = sdf.format(stateEffDate);
			}
		}
		//return stateEffDateDisplay;
		return stateEffDateDisplay;
	}

	/**
	 * @return Returns the storeNumber.
	 */
	public String getStoreNumber() {
		return storeNumber;
	}

	/**
	 * @param storeNumber The storeNumber to set.
	 */
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}

	/**
	 * @return Returns the uom.
	 */
	public String getUom() {
		return uom;
	}

	/**
	 * @param uom The uom to set.
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}

	/**
	 * Method to print the object details
	 *
	 * @return String
	 */
	public String toString() {
		StringBuffer sbuff = new StringBuffer();
		sbuff.append("CategoryDto: " + this.getSmicCategoryDto() + (" "));
		sbuff.append("divDto: " + this.getDivisionDto() + (" "));
		sbuff.append("itemDto: " + this.getItemDto() + " ");
		sbuff.append("storeNumber: " + this.getStoreNumber() + " ");
		sbuff.append("state: " + this.getState() + " ");
		sbuff.append("effectiveDate: " + this.getStateEffectiveDate() + " \n");
		sbuff.append("blockedTargetDate: " + this.getBlockedTargetDate() + " ");
		sbuff.append("description: " + this.getDescription() + " \n");
		sbuff.append("size: " + this.getSize() + " ");
		sbuff.append("uom: " + this.getUom() + " ");
		sbuff.append("casePack: " + this.getCasePk() + " \n");
		return sbuff.toString();
	}
}
