package com.safeway.app.meup.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.safeway.app.meup.dao.SmicGroupDAO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.SmicGroupService;

@Service
public class SmicGroupServiceImpl implements SmicGroupService {

	@Autowired
	private SmicGroupDAO smicGroupDAO;

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<SmicGroupDTO> getSmicGroupsForDivision(List<String> divisionStringList, String corp) {

		List<SmicGroupDTO> groupVOXList = smicGroupDAO.selectSmicGroupsForDivision(corp,divisionStringList);

		return groupVOXList;

	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<SmicCategoryDTO> getSmicCategoriesForGroups(List<Integer> groupList, String corp) {

		List<SmicCategoryDTO> CategoryVOXList = smicGroupDAO.selectSmicCategoriesForGroups(corp, groupList);

		return CategoryVOXList;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<SmicGroupDTO> getGroupsByStatus(String corp) throws SQLException, MeupException {

		List<SmicGroupDTO> groupList = smicGroupDAO.getGroupsByStatus(corp, 'H', 'H');
		return groupList;
	}

}
