package com.safeway.app.meup.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.safeway.app.meup.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.dao.StoreItemHistoryDAO;
import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.CommentDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.dto.JsonErrorDTO;
import com.safeway.app.meup.dto.ReportDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.StoreItemBusinessResult;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemExcelViewerDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.dto.UpdateStoreItemDTO;
import com.safeway.app.meup.exceptions.ErrorMessage;
import com.safeway.app.meup.exceptions.LogErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.DivisionService;
import com.safeway.app.meup.util.HoldItemMgrHelper;
import com.safeway.app.meup.service.StagingHdrService;
import com.safeway.app.meup.service.StoreItemService;
import com.safeway.app.meup.service.ValidationService;
import com.safeway.app.meup.vox.CommentVO;
import com.safeway.app.meup.vox.StoreItemHistoryVO;
import com.safeway.app.meup.vox.StoreItemVO;
import com.safeway.app.meup.vox.StoreItemVOID;

@Service
public class StoreItemServiceImpl implements StoreItemService {
	private static final Logger log = LoggerFactory.getLogger(StoreItemServiceImpl.class);

	@Autowired
	private StoreItemDAO storeItemDAO;
	@Autowired
	private DivisionService divisionService;
	@Autowired
	private HoldItemMgrHelper holdItemMgrHelper;
	@Autowired
	private ValidationService validationService;
	@Autowired
	private StoreItemHistoryDAO storeItemHistoryDAO;

	@Autowired
	private StagingHdrService stagingHdrService;

	public static void createExcelReport(List<StoreItemDTO> items, HttpServletResponse response) {
		exportToExcel(createExcelViewerList(items), StoreItemExcelViewerDTO.class, response);
	}

	/**
	 * The method is used to export the data provided to an excel file.
	 *
	 * @param dataList List of items
	 * @param objClass Class
	 */
	public static void exportToExcel(List<StoreItemExcelViewerDTO> dataList, Class objClass,
			HttpServletResponse response) {

		log.info("|---> Beginning Method StoreItemService.exportToExcel");

		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog("ExcelExporter", "exportToExcel"));
		ExcelBuilder reportBuilder = new ExcelBuilder();
		try {
			ReportGenerator reportGen = new ReportGenerator(objClass);

			ReportDTO excelReport = reportGen.createReport(dataList);

			reportBuilder.buildReport(excelReport, response);
		} catch (MeupException | IOException exp) {
			log.error(LogErrorMessage.MEUP_ITEM_EXCEL_DOWNLOAD_ERROR + exp.getMessage());
		}

		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog("ExcelExporter", "exportToExcel", endTime - startTime));

		log.info("<---| Completed Method StoreItemService.exportToExcel");
	}

	/**
	 * To create the list of items to be populated in the excel report.
	 *
	 * @param items list of items
	 * @return uiList
	 */
	public static List<StoreItemExcelViewerDTO> createExcelViewerList(List<StoreItemDTO> items) {
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog("StoreItemServiceImpl", "createExcelViewerList"));
		List<StoreItemExcelViewerDTO> uiList = new ArrayList();

		/** Loop that adds each row data to the list */
		for (int i = 0; i < items.size(); ++i) {
			StoreItemExcelViewerDTO ui = new StoreItemExcelViewerDTO();
			StoreItemDTO dto = (StoreItemDTO) items.get(i);
			ui.setDivisionNumber(dto.getDivisionNumber());
			ui.setStoreNumber(dto.getStoreNumber());
			ui.setCategoryName(dto.getSmicCategoryDto().getCategoryCd() + dto.getSmicCategoryDto().getcategoryDesc());
			ui.setUpc(dto.getUpc());
			ui.setCic(dto.getCic());
			ui.setDescription(dto.getDescription());
			ui.setItemType(dto.getItemType());
			ui.setSize(dto.getSize());
			ui.setUom(dto.getUom());
			ui.setCasePk(dto.getCasePk());
			ui.setState(dto.getDispState());
			if (dto.getStateEffectiveDate() != null) {
				//ui.setStateEffectiveDate(MeupUtility.getDateFormat(dto.getStateEffectiveDate()));
				ui.setStateEffectiveDate((dto.getStateEffectiveDate()));
			} else {
				ui.setStateEffectiveDate("");
			}
			ui.setBlockedStatus(dto.getDispBlockedStatus());
			// ui.setBlockedTargetDate(MeupUtility.getDateFormat(dto.getBlockedTargetDate()));
			ui.setBlockedTargetDate((dto.getBlockedTargetDate()));
			uiList.add(ui);
		}
		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog("StoreItemServiceImpl", "createExcelViewerList", endTime - startTime));
		return uiList;

	}

	public String createExcelExport(List<StoreItemDTO> storeItemSearchDtoList, HttpServletResponse response)
			throws MeupException, ParseException {
		log.info("|---> Beginning method StoreItemServiceImpl.createExcelReport");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), "createExcelExport"));
		for (StoreItemDTO storeItemDTO: storeItemSearchDtoList)
		{
			String stateEffectiveDate=storeItemDTO.getStateEffectiveDate();
			String processstateEffectiveDate=processtateEffectiveDateResult(stateEffectiveDate);
			storeItemDTO.setStateEffectiveDate(processstateEffectiveDate);
		}
		createExcelReport(storeItemSearchDtoList, response);

		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog(this.getClass().getName(), "createExcelExport", endTime - startTime));
		log.info("<---| Completed method StoreItemServiceImpl.createExcelReport");
		return "success";
	}

	public String processtateEffectiveDateResult(String stateEffectiveDate) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = formatter.parse(stateEffectiveDate);
		java.util.Date stateEffDate = null;
		String stateEffDateDisplay = "";
		if (null != stateEffectiveDate) {
			stateEffDate = MeupUtility.checkStateEffDt(date);
			if (stateEffDate == null) {
				stateEffDateDisplay = "";
			} else {
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				stateEffDateDisplay = sdf.format(stateEffDate);
			}
		}
		//return stateEffDateDisplay;
		return stateEffDateDisplay;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO getStoreItemsForReport(StoreItemSearchDTO storeItemSearchDTO)
			throws MeupException, SQLException {
		List<String> validationResult = validationService.validateFieldsForReportStoreItems(storeItemSearchDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		if (validationResult.size() == 0) {
			responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
			HashMap<String, Object> mapData = new HashMap<>();
			setStoreItemUpcValues(storeItemSearchDTO);
			List<StoreItemDTO> result = storeItemDAO.selectStoreItemsForReport(storeItemSearchDTO);
			/*
			 * for (StoreItemDTO eachItem : result) { List<StoreItemHistoryVO> history =
			 * getStoreItemsForHistory(eachItem); eachItem.setHistoryInfo(history); }
			 */
			if (result.size() >= Integer.parseInt(MeupConstant.RESULTSET_SIZE)) {
				JsonErrorDTO jsonErrorDto = new JsonErrorDTO();
				jsonErrorDto.setMessage(LogErrorMessage.TIMEOUT_EXCEPTION);
				List<JsonErrorDTO> jsonErrorDtolist = new ArrayList<>();
				jsonErrorDtolist.add(jsonErrorDto);
				mapData.put(ResponseDTO.FAILURE_OPERATION, jsonErrorDtolist);
			} else {
				mapData.put(ResponseDTO.REST_DATA, result);
			}
			responseDTO.setData(mapData);
			return responseDTO;
		} else {
			Iterator validationErrorIterator = validationResult.iterator();
			responseDTO.setStatus(ResponseDTO.FAILURE_OPERATION);
			while (validationErrorIterator.hasNext()) {
				JsonErrorDTO jsonErrorDTO = new JsonErrorDTO();
				String errorMessage = (String) validationErrorIterator.next();
				jsonErrorDTO.setMessage(errorMessage);
				responseDTO.addErrorDTO(jsonErrorDTO);
			}
			return responseDTO;
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO getStoreItemsForUpdate(StoreItemSearchDTO storeItemSearchDTO) throws MeupException {
		log.info("-->Beginning- StoreItemServiceImpl.getStoreItemsForUpdate");
		String state = storeItemSearchDTO.getState();
		if (state != null && !"".equals(state)) {
			if (MeupConstant.UNALLOCATED_STATE.equalsIgnoreCase(state)
					|| MeupConstant.STATE_UNALLOCATED.equalsIgnoreCase(state)) {
				storeItemSearchDTO.setState(MeupConstant.STATE_UNALLOCATED);
			} else if (MeupConstant.ALLOCATED_STATE.equalsIgnoreCase(state)
					|| MeupConstant.STATE_ALLOCATED.equalsIgnoreCase(state)) {
				storeItemSearchDTO.setState(MeupConstant.STATE_ALLOCATED);
			}

		}
		if (!MeupConstant.ADMIN_ROLE.equals(storeItemSearchDTO.getUserDto().getRole())) {
			storeItemSearchDTO.setState(MeupConstant.STATE_UNALLOCATED);
		}
		log.info("Validation Start StoreItemServiceImpl.getStoreItemsForUpdate");
		List<String> validationResult = validationService.validateFieldsForUpdateStoreItems(storeItemSearchDTO);
		log.info("Validation End StoreItemServiceImpl.getStoreItemsForUpdate");
		ResponseDTO responseDTO = new ResponseDTO();
		if (validationResult.size() == 0) {
			setStoreItemUpcValues(storeItemSearchDTO);
			// return getStoreItemDAO().selectBlockedWhStoreItems(storeItemSearchDTO);
			responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
			HashMap<String, Object> mapData = new HashMap<>();
			List<StoreItemDTO> result = storeItemDAO.selectBlockedWhStoreItems(storeItemSearchDTO);
			if (result.size() >= Integer.parseInt(MeupConstant.RESULTSET_SIZE)) {
				JsonErrorDTO jsonErrorDto = new JsonErrorDTO();
				jsonErrorDto.setMessage(LogErrorMessage.TIMEOUT_EXCEPTION);
				List<JsonErrorDTO> jsonErrorDtolist = new ArrayList<>();
				jsonErrorDtolist.add(jsonErrorDto);
				mapData.put(ResponseDTO.FAILURE_OPERATION, jsonErrorDtolist);
			} else {
				mapData.put(ResponseDTO.REST_DATA, result);
			}
			responseDTO.setData(mapData);
			log.info("-->Completed- StoreItemServiceImpl.getStoreItemsForUpdate");
			return responseDTO;
		} else {
			Iterator validationErrorIterator = validationResult.iterator();
			responseDTO.setStatus(ResponseDTO.FAILURE_OPERATION);
			while (validationErrorIterator.hasNext()) {
				JsonErrorDTO jsonErrorDTO = new JsonErrorDTO();
				String errorMessage = (String) validationErrorIterator.next();
				jsonErrorDTO.setMessage(errorMessage);
				responseDTO.addErrorDTO(jsonErrorDTO);
			}
			log.info("-->Completed- StoreItemServiceImpl.getStoreItemsForUpdate");
			return responseDTO;
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO updateStoreItems(UpdateStoreItemDTO updateStoreItemDTO) throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemService" + ".updateStoreItems");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), " updateStoreItems "));
		if (updateStoreItemDTO.getDeleteDate() != null) {
			ResponseDTO modifyDeleteDateResult = modifyDeleteDate(updateStoreItemDTO);
			log.info("<---| Completed Method StoreItemService." + "updateStoreItems");
			return modifyDeleteDateResult;
		} else {
			ResponseDTO unblockStoreItemsResult = unblockStoreItems(updateStoreItemDTO);
			log.info("<---| Completed Method StoreItemService." + "updateStoreItems");
			return unblockStoreItemsResult;
		}

	}

	public StoreItemDAO getStoreItemDAO() {
		return storeItemDAO;
	}

	public void setStoreItemDAO(StoreItemDAO storeItemDAO) {
		this.storeItemDAO = storeItemDAO;
	}

	public StoreItemSearchDTO setStoreItemUpcValues(StoreItemSearchDTO storeItemSearchDTO) {
		if (storeItemSearchDTO.getUpc() != null && !"".equals(storeItemSearchDTO.getUpc())) {
			StoreItemHelper helper = new StoreItemHelper();
			int[] upcTokens = helper.getUPCTokens(storeItemSearchDTO.getUpc());
			storeItemSearchDTO.setUpcCountry(Integer.toString(upcTokens[0]));
			storeItemSearchDTO.setUpcSystem(Integer.toString(upcTokens[1]));
			storeItemSearchDTO.setUpcManuf(Integer.toString(upcTokens[2]));
			storeItemSearchDTO.setUpcSales(Integer.toString(upcTokens[3]));
		}
		return storeItemSearchDTO;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<StoreItemHistoryVO> getStoreItemsForHistory(StoreItemDTO storeItemDto) throws MeupException {
		log.info("-->Beginning- StoreItemServiceImpl.getStoreItemsForHistory");
		String corp = storeItemDto.getDivisionDto().getCorp();
		String division = storeItemDto.getDivisionDto().getDivisionNumber();
		String fac = storeItemDto.getStoreNumber();
		String cic = storeItemDto.getItemDto().getCic();

		List<StoreItemHistoryVO> storeItemHistoryList = storeItemHistoryDAO.getStoreItemsForHistory(corp, division, fac,
				cic);

		if (null == storeItemHistoryList && storeItemHistoryList.isEmpty()) {
			log.debug("No records retrieved from database");
		}
		storeItemHistoryList.forEach(storeItemHistory -> {
			if (storeItemHistory.getBlockedStatus().equals(MeupConstant.BLOCKED_STATUS_CODE)
					|| storeItemHistory.getBlockedStatus().equals(MeupConstant.BLOCKED_STATE)) {
				storeItemHistory.setBlockedStatus(MeupConstant.BLOCKED_STATE);
			} else {
				storeItemHistory.setBlockedStatus(MeupConstant.UNBLOCKED_STATE);
			}

			if (storeItemHistory.getState().equals(MeupConstant.STATE_ALLOCATED)
					|| storeItemHistory.getBlockedStatus().equals(MeupConstant.ALLOCATED_STATE)) {
				storeItemHistory.setState(MeupConstant.ALLOCATED_STATE);
			} else {
				storeItemHistory.setState(MeupConstant.UNALLOCATED_STATE);
			}
		});
		log.info("-->Completed- StoreItemServiceImpl.getStoreItemsForHistory");
		return storeItemHistoryList;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO unblockStoreItems(UpdateStoreItemDTO updateStoreItemDTO) throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemService" + ".unblockStoreItems");
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), " unblockStoreItems "));
		List<StoreItemDTO> selectedItemList = new ArrayList();
		ResponseDTO responseDTO = new ResponseDTO();
		CommentDTO commentDto = new CommentDTO();
		boolean isUnblock = true;
		StoreItemBusinessResult storeItemResult = new StoreItemBusinessResult();
		try {

			Iterator itemListItr = updateStoreItemDTO.getStoreItemDTOList().iterator();
			while (itemListItr.hasNext()) {
				StoreItemDTO storeItemDto = (StoreItemDTO) itemListItr.next();
				if ((storeItemDto.isSelected())) {
					storeItemDto.setSelected(false);
					selectedItemList.add(storeItemDto);
				}
			}

			commentDto.setComment(updateStoreItemDTO.getComment());
			storeItemResult = unblockStoreItemsSetValues(selectedItemList, updateStoreItemDTO.getUserId(), commentDto);
			if (null != storeItemResult.getInfoMessages() && !storeItemResult.getInfoMessages().isEmpty()) {
				Iterator resultIterator = storeItemResult.getInfoMessages().iterator();
				List<String> resultMessage = new ArrayList<String>();
				while (resultIterator.hasNext()) {
					String infoMessage = (String) resultIterator.next();
					log.error(infoMessage);
					resultMessage.add(infoMessage);
				}
				responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
				HashMap<String, Object> mapData = new HashMap<>();
				mapData.put(ResponseDTO.REST_DATA, resultMessage);
				responseDTO.setData(mapData);
				return responseDTO;
			}

		} catch (MeupException | SQLException me) {
			if (me.getMessage().indexOf(ErrorMessage.DEADLOCK_MESSAGE) > -1) {
				log.error(ErrorMessage.DEADLOCK_MESSAGE);
				// deadlock
			} else if (me.getMessage().indexOf(ErrorMessage.DB_DEADLOCK_913) > -1) {
				log.error(ErrorMessage.DB_DEADLOCK_913);
				// message from db
			} else if (me.getMessage().indexOf(MeupConstant.DEADLOCK_TOKEN) > -1) {
				log.error(ErrorMessage.DEADLOCK_MESSAGE);
			} else if (me.getMessage().indexOf(MeupConstant.RESOURCE_LIMIT) > -1) {
				log.error(ErrorMessage.DEADLOCK_MESSAGE);
			} else {
				log.error(LogErrorMessage.UNBLOCK_ITEM_EXCEPTION + me.getMessage());
			}
			throw me;
		}

		return responseDTO;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO modifyDeleteDate(UpdateStoreItemDTO updateStoreItemDTO) throws MeupException {
		log.info("|---> Beginning Method StoreItemService" + ".modifyDeleteDate");
		// long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), " modifyDeleteDate "));
		boolean isUnblock = false;
		ResponseDTO responseDTO = new ResponseDTO();
		List<StoreItemDTO> selectedItemList = new ArrayList();
		CommentDTO commentDto = new CommentDTO();
		StoreItemBusinessResult storeItemResult = new StoreItemBusinessResult();
		// log.info("|---> Beginning Method StoreItemService" + ".modifyDeleteDate" +
		// "StoreItemList" + updateStoreItemDTO.getStoreItemDTOList());
		try {

			Iterator itemListItr = updateStoreItemDTO.getStoreItemDTOList().iterator();
			while (itemListItr.hasNext()) {
				StoreItemDTO storeItemDto = (StoreItemDTO) itemListItr.next();
				if ((storeItemDto.isSelected())) {
					// storeItemDto.setBlockedTargetDate(new
					// java.sql.Date(updateStoreItemDTO.getDeleteDate().getTime()));
					storeItemDto.setBlockedTargetDate((updateStoreItemDTO.getDeleteDate()));
					selectedItemList.add(storeItemDto);
				}

			}
			commentDto.setComment(updateStoreItemDTO.getComment());
			storeItemResult = modifyDeleteDateSetValues(selectedItemList, updateStoreItemDTO.getUserId(), commentDto);
			if (null != storeItemResult.getInfoMessages() && !storeItemResult.getInfoMessages().isEmpty()) {
				Iterator resultIterator = storeItemResult.getInfoMessages().iterator();
				List<String> resultMessage = new ArrayList<>();
				while (resultIterator.hasNext()) {
					String infoMessage = (String) resultIterator.next();
					log.error(infoMessage);
					resultMessage.add(infoMessage);
				}

				responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
				HashMap<String, Object> mapData = new HashMap<>();
				mapData.put(ResponseDTO.REST_DATA, resultMessage);
				responseDTO.setData(mapData);
				return responseDTO;
			}
			// removing backend validation
			/*
			 * } else{ Iterator validationErrorIterator = validationResult.iterator();
			 * 
			 * responseDTO.setStatus(ResponseDTO.FAILURE_OPERATION); while
			 * (validationErrorIterator.hasNext()) { JsonErrorDTO jsonErrorDTO = new
			 * JsonErrorDTO(); String errorMessage = (String)
			 * validationErrorIterator.next(); jsonErrorDTO.setMessage(errorMessage);
			 * responseDTO.addErrorDTO(jsonErrorDTO); }
			 * log.info("<---| Completed Method StoreItemService." + "unblockStoreItems");
			 * return responseDTO; }
			 */

		} catch (MeupException me) {
			// for ejb exception and more than 4000 items
			if (me.getMessage().indexOf(ErrorMessage.DEADLOCK_MESSAGE) > -1) {
				log.error(ErrorMessage.DEADLOCK_MESSAGE);

				// deadlock
			} else if (me.getMessage().indexOf(ErrorMessage.DB_DEADLOCK_913) > -1) {
				log.error(ErrorMessage.DB_DEADLOCK_913);
				// message from db
			} else if (me.getMessage().indexOf(MeupConstant.DEADLOCK_TOKEN) > -1) {
				log.error(ErrorMessage.DEADLOCK_MESSAGE);
			} else if (me.getMessage().indexOf(MeupConstant.RESOURCE_LIMIT) > -1) {
				log.error(ErrorMessage.DEADLOCK_MESSAGE);
			} else {
				log.error(LogErrorMessage.MODIFY_DATE_EXCEPTION + me.getMessage());
			}
			throw me;
		}
		return responseDTO;
	}

	public StoreItemBusinessResult unblockStoreItemsSetValues(List<StoreItemDTO> storeItemDtoList, String userId,
			CommentDTO commentDto) throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemServiceImpl" + ".unblockStoreItemsSetValues");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), " unblockStoreItemsSetValues"));
		boolean unblock = true;
		List infoList = new ArrayList();
		StoreItemBusinessResult storeItemBusinessResult = null;
		int numberOfItems = 0;
		int storeItemDtoListSize = storeItemDtoList.size();
		Iterator iter = storeItemDtoList.iterator();
		String errorMessage = null;
		CommentVO commentVo = holdItemMgrHelper.convertToCommentVO(commentDto);
		/* to get timestamp */
		Timestamp lastUpdTs = new Timestamp(System.currentTimeMillis());

		numberOfItems = getStoreItemDAO().updateBlockedItem(storeItemDtoList, userId, commentVo, unblock, lastUpdTs);

		if (numberOfItems > 0) {
			errorMessage = numberOfItems + " " + ErrorMessage.UNBLOCK_ITEMS;
			infoList.add(errorMessage);
		}

		/* Number of Items not Unblocked. */
		int unblockErrorItems = storeItemDtoListSize - numberOfItems;

		if (unblockErrorItems > 0) {
			infoList.add(unblockErrorItems + " " + ErrorMessage.DB_DEADLOCK_UNBLOCK_ERROR);
		}

		storeItemBusinessResult = new StoreItemBusinessResult();
		storeItemBusinessResult.setInfoMessages(infoList);

		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog(this.getClass().getName(), "unblockStoreItems", endTime - startTime));
		log.info("<---| Completed Method StoreItemServiceImpl" + ".unblockStoreItemsSetValues");

		return storeItemBusinessResult;
	}

	public StoreItemBusinessResult modifyDeleteDateSetValues(List<StoreItemDTO> storeItemDtoList, String userId,
			CommentDTO commentDto) throws MeupException {

		log.info("|---> Beginning Method StoreItemServiceImpl" + ".modifyDeleteDateSetValues");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), " modifyDeleteDate"));

		StoreItemBusinessResult storeItemBusinessResult = null;
		List infoList = new ArrayList();
		boolean unblock = false;
		int numberOfItems = 0;
		int storeItemDtoListSize = storeItemDtoList.size();

		/* to get timestamp */
		Timestamp lastUpdTs = new Timestamp(System.currentTimeMillis());
		CommentVO commentVo = holdItemMgrHelper.convertToCommentVO(commentDto);
		try {
			numberOfItems = getStoreItemDAO().updateBlockedItem(storeItemDtoList, userId, commentVo, unblock,
					lastUpdTs);
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		infoList.add(ErrorMessage.MODIFY_DELETEDATE_ITEM + " " + numberOfItems + " "
				+ ErrorMessage.MODIFY_DELETEDATE_ITEMS_CONFIRM_MESSAGE);

		/* Number of Items not Unblocked. */
		int unblockErrorItems = storeItemDtoListSize - numberOfItems;

		if (unblockErrorItems > 0) {
			infoList.add(unblockErrorItems + " " + ErrorMessage.DB_DEADLOCK_UNBLOCK_ERROR);
		}

		/* setting infoList to storeItemBusinessResult */
		storeItemBusinessResult = new StoreItemBusinessResult();
		storeItemBusinessResult.setInfoMessages(infoList);

		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog(this.getClass().getName(), "modifyDeleteDate", endTime - startTime));
		log.info("<---| Completed Method StoreItemServiceImpl" + ".modifyDeleteDateSetValues");

		return storeItemBusinessResult;
	}

	@Override
	public void uploadCSVFile(BlockItemRequestDTO blockItemRequestDto) throws MeupException {
		log.info("|---> Beginning Method StoreItemServiceImpl.uploadCSVFile.");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), "uploadCSVFile"));

		/** create new time stamp */
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		/** Get the value of division from blockItemRequestDTO. */
		String div = blockItemRequestDto.getDivisionNumber();

		/**
		 * get the corp value by calling the DAOFactory class. Through this method,get
		 * the value of corp corresponding to the division number.
		 **/
		String corpValue = divisionService.getCorpForDiv(div);

	}

	@Override
	public ResponseDTO uploadCSVFile(MultipartFile itemsFile, String userID, Date deleteDate) throws MeupException {
		log.info("|---> Beginning Method StoreItemServiceImpl.uploadCSVfile");
		long startTime = MeupLogUtil.currentTime();
		ResponseDTO responseDTO = new ResponseDTO();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(), "uploadItems"));
		try {
			/** list value to get the content and to read through this content. */
			/** read the contens of the file. */
			List<String> content = extractFileData(itemsFile);
			BlockItemRequestDTO requestDTO = new BlockItemRequestDTO();

			/**
			 * string value to hold the error message if file not found exception occurred.
			 */
			String action = "uploadCSVfile";

			/** validate for the uploaded file is empty. */
			validationService.validateBlockItemCSVFile(itemsFile, responseDTO, requestDTO);
			if (!CollectionUtils.isEmpty(responseDTO.getErrorDTOList()) && responseDTO.getErrorDTOList().size() > 0) {
				return responseDTO;
			}

			/**
			 * call the method which will add the cic and upc into the itemDto when all the
			 * validation passes.
			 */
			List<ItemDTO> itemDTOList = parseContentCICUPC(content);

			/** set the userId into blockItemRequestDTO. */
			// ECMM-6321 defect fixed
			requestDTO.setUserid(userID.toLowerCase());
			requestDTO.setDeleteDate(String.valueOf(deleteDate));
			requestDTO.setItemDtoList(itemDTOList);

			/**
			 * call the method which will upload the file and will put into the staging
			 * table
			 */
			/** Get the value of division from blockItemRequestDTO. */
			String corpValue = divisionService.getCorpForDiv(requestDTO.getDivisionNumber());
			stagingHdrService.uploadCSVFile(requestDTO, corpValue);

			/**
			 * set the message if all the validation passes and it will upload the items
			 */
			Map<String, Object> data = new HashMap<>();
			data.put(ResponseDTO.REST_DATA, ErrorMessage.SUCCESS);
			responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
			responseDTO.setData(data);
			log.info(ErrorMessage.SUCCESS);
		} catch (FileNotFoundException fileNotFoundException) {
			log.error(LogErrorMessage.UPLOAD_FAILURE + ":" + fileNotFoundException.getMessage());
			throw new MeupException("Exception while uploading file :" + fileNotFoundException.getStackTrace());

		} catch (IOException ioException) {
			log.error(LogErrorMessage.UPLOAD_FAILURE + ":" + ioException.getMessage());
			throw new MeupException("Exception while uploading file :" + ioException.getStackTrace());
		} catch (MeupException | ParseException meupException) {
			String exceptionMessage = meupException.getMessage();
			if (exceptionMessage.indexOf(MeupConstant.UPLOAD_TIMEOUT) >= 0) {// for EJB time out exception
				log.error(ErrorMessage.UPLOAD_TIMEOUT_MESSAGE);
			} else if (exceptionMessage.indexOf(MeupConstant.RESOURCE_LIMIT) >= 0) {// for AUST time limit
				log.info(ErrorMessage.RESOURCE_LIMIT_MESSAGE);
			} else if (exceptionMessage.indexOf(MeupConstant.DEADLOCK_TOKEN) >= 0) {
				log.info(ErrorMessage.DEADLOCK_MESSAGE);
			} else {
				log.error(LogErrorMessage.UPLOAD_FAILURE + ":" + meupException.getMessage());
			}
			log.error(LogErrorMessage.UPLOAD_FAILURE + ":" + meupException.getMessage());
			log.error(LogErrorMessage.UPLOAD_FAILURE + ":" + meupException.getMessage());
		}
		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog(this.getClass().getName(), "storeItems", endTime - startTime));
		log.info("<---| Completed Method StoreItemServiceImpl.uploadCSVfile");
		return responseDTO;
	}

	public List<String> extractFileData(MultipartFile itemsFile) throws IOException {
		/** declare the bufferReader to read the file. */
		BufferedReader bufferedReader = null;

		/** list which will hold the content of the file. */
		List content = new ArrayList();

		/** String value to hold the temporary content. */
		String temporaryContent = null;

		/** Read the content of the file and get the list value as content. */
		/*
		 * bufferedReader = new BufferedReader(new InputStreamReader( new
		 * ByteArrayInputStream(file)));
		 */
		// added by U26910
		bufferedReader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(itemsFile.getBytes())));

		int recordCount = 0;
		while ((temporaryContent = bufferedReader.readLine()) != null) {
			if (!(temporaryContent.equals(""))) {
				recordCount++;
				content.add(temporaryContent);
			}
		}
		bufferedReader.close();
		return content;
	}

	/**
	 * This method will parse the contents of the file i.e UPC and CIC and add it
	 * into the list that is this method will get the value of all the values of CIC
	 * and UPC and it will add into the list which will be further added into the
	 * DTO list.
	 *
	 * @param contents which contains the contents inisde the file.
	 * @return list of contents from the file.
	 */
	public List<ItemDTO> parseContentCICUPC(List<String> contents) throws ParseException {

		log.debug("-->Beginning method StoreItemServiceImpl.parseContentCICUPC()");

		/** string value to hold upc and cic. */
		String upc = null;
		String cic = null;

		/** string value to hold the data from the file. */
		String content = null;

		/** list to hold the all the upc and cic in form of itemDtoList. */
		List<ItemDTO> itemDTOList = new ArrayList<>();
		/**
		 * read the contents and get the UPC and CIC value and add them into the list.
		 */
		for (int indexOfList = MeupConstant.CONTENT_SIZE; indexOfList < contents.size(); indexOfList++) {
			content = contents.get(indexOfList);
			/** create an object of itemDto which consist of all upc. */
			ItemDTO itemDto = new ItemDTO();
			if (!("").equals(content.trim())) {
				int index = MeupUtility.indexSeparator(content, MeupConstant.comma);
				upc = MeupUtility.getSubString(content, 0, index).replaceAll(",", "").trim();
				cic = MeupUtility.getSubString(content, index + 1).replaceAll(",", "").trim();

				/**
				 * if the length of the upc entered is 10 then add two leading zeroes.
				 */
				if (MeupUtility.getTrimmedStringSize(upc) == MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {
					upc = "00" + upc;
				}

				/**
				 * if the length of the cic entered is 11 then add one leading zero.
				 */
				if (MeupUtility.getTrimmedStringSize(upc) == 11) {
					upc = "0" + upc;
				}

				/** add all the cic and upc to the itemDto. */
				itemDto = storeToItemDto(cic, upc);

				/** add to the itemDtoList. */
				itemDTOList.add(itemDto);
			}
		}
		log.info("<---| Completed Method StoreItemServiceImpl.parseContentCICUPC");
		return itemDTOList;
	}

	/**
	 * To store the valid item to the ItemDto. this method will set all the items
	 * that is CIC and UPC value into the itemDto .
	 *
	 * @param cic, upc.
	 * @return an itemDto object whihc contains all the upc values..
	 */
	public ItemDTO storeToItemDto(String cic, String upc) throws ParseException {
		ItemDTO itemDto = new ItemDTO();
		StoreItemHelper helper = new StoreItemHelper();
		int[] upcTokens = helper.getUPCTokens(upc);
		itemDto.setCic(cic);
		itemDto.setUpcCountry(Integer.toString(upcTokens[0]));
		itemDto.setUpcSystem(Integer.toString(upcTokens[1]));
		itemDto.setUpcManuf(Integer.toString(upcTokens[2]));
		itemDto.setUpcSales(Integer.toString(upcTokens[3]));
		return itemDto;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<StoreItemHelper> blockItemsAndStores(BlockItemRequestDTO blockItemRequestDTO)
			throws MeupException, ParseException {
		StoreItemBusinessResult storeItemBusinessResult = validationService.validateItemsAndStores(blockItemRequestDTO);
		/* step 2. creating and updating the storeItem business objects. */
		List<StoreItemVO> storeItemVOList = new ArrayList<>();
		java.util.Date blockDate = new java.util.Date();
		Timestamp blockTimeStamp = new Timestamp(System.currentTimeMillis());
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		try {
			blockDate = dateFormat.parse(dateFormat.format(calendar.getTime()));
		} catch (ParseException pe) {
			log.error(pe.toString());
			throw new MeupException(pe.toString());
		}
		storeItemVOList = converToStoreItemVO(storeItemVOList, storeItemBusinessResult.getValidStoreItemList(),
				blockDate, blockTimeStamp);
		storeItemDAO.updateBlockStoreItems(storeItemVOList);

		/* step 3. Creating and updating StoreItemHistory objects */
		storeItemHistoryDAO.insertBlockedItemHistory(storeItemVOList);
		List<StoreItemHelper> storeItemErrorList = new ArrayList<>();
		int flag = 0;
		String errorMessage = null;
		if (storeItemBusinessResult.getErrorMessages().size() != 0) {
			for (Object errorMessage1 : storeItemBusinessResult.getErrorMessages()) {
				StoreItemHelper storeHelper = new StoreItemHelper();
				storeHelper.setCicupc(" ");
				storeHelper.setStoreNo("");
				storeHelper.setErrorMessage(errorMessage1.toString());
				storeItemErrorList.add(storeHelper);
			}
			return storeItemErrorList;

		}
		if (null != storeItemBusinessResult.getInvalidStoreList()
				&& !storeItemBusinessResult.getInvalidStoreList().isEmpty()) {
			errorMessage = ErrorMessage.INVALID_STORE;
			flag = 1;
			Iterator errorIter = storeItemBusinessResult.getInvalidStoreList().iterator();
			while (errorIter.hasNext()) {
				String storeNumber = (String) errorIter.next();
				StoreItemHelper storeHelper = new StoreItemHelper();
				storeHelper.setCicupc(" ");
				storeHelper.setStoreNo(storeNumber);
				storeHelper.setErrorMessage(errorMessage);
				storeItemErrorList.add(storeHelper);
			}
		}
		if (null != storeItemBusinessResult.getDiscontinuedStoreItemList()
				&& !storeItemBusinessResult.getDiscontinuedStoreItemList().isEmpty()) {
			errorMessage = ErrorMessage.DISCONTINUED_ITEM;
			flag = 1;
			storeItemErrorList = iterateAndSetItem(storeItemBusinessResult.getDiscontinuedStoreItemList(), errorMessage,
					storeItemErrorList);
		}
		if (null != storeItemBusinessResult.getDsdAndWhStoreItemList()
				&& !storeItemBusinessResult.getDsdAndWhStoreItemList().isEmpty()) {
			errorMessage = ErrorMessage.DSD_WH_ITEM;
			flag = 1;
			storeItemErrorList = iterateAndSetItem(storeItemBusinessResult.getDsdAndWhStoreItemList(), errorMessage,
					storeItemErrorList);
		}
		if (null != storeItemBusinessResult.getDsdStoreItemList()
				&& !storeItemBusinessResult.getDsdStoreItemList().isEmpty()) {
			errorMessage = ErrorMessage.DSD_STORE_ITEM;
			flag = 1;
			storeItemErrorList = iterateAndSetItem(storeItemBusinessResult.getDsdStoreItemList(), errorMessage,
					storeItemErrorList);
		}
		if (null != storeItemBusinessResult.getDuplicateItemList()
				&& !storeItemBusinessResult.getDuplicateItemList().isEmpty()) {
			errorMessage = ErrorMessage.DUPLICATE_ITEM;
			flag = 1;
			storeItemErrorList = iterateAndSetItem(storeItemBusinessResult.getDuplicateItemList(), errorMessage,
					storeItemErrorList);
		}
		if (null != storeItemBusinessResult.getInvalidStoreItemList()
				&& !storeItemBusinessResult.getInvalidStoreItemList().isEmpty()) {
			errorMessage = ErrorMessage.INVALID_STORE_ITEM;
			flag = 1;
			storeItemErrorList = iterateAndSetItem(storeItemBusinessResult.getInvalidStoreItemList(), errorMessage,
					storeItemErrorList);
		}
		if (flag == 1) {
			StoreItemHelper storeHelper = new StoreItemHelper();
			storeHelper.setErrorMessage(ErrorMessage.ENTRY_SUBMITTED_ERROR_LIST);
			storeItemErrorList.add(storeHelper);

		} else {
			StoreItemHelper storeHelper = new StoreItemHelper();
			storeHelper.setErrorMessage(ErrorMessage.ALL_ENTRY_SUBMITTED);
			storeItemErrorList.add(storeHelper);
		}
		long endTime = MeupLogUtil.currentTime();
		return storeItemErrorList;
	}

	/**
	 * To iterate through the StoreItemBusinessResult returned and set the
	 * corresponding error Message.
	 *
	 * @param errorList    list having errors
	 * @param errorMessage String to disply errorMessage
	 *
	 */
	public List<StoreItemHelper> iterateAndSetItem(List<StoreItemDTO> errorList, String errorMessage,
			List<StoreItemHelper> storeItemErrorList) {
		log.info("|---> Beginning Method StoreItemForm." + "iterateAndSetItem");
		String cic = null;
		String upc = null;
		String storeNo = null;
		StoreItemDTO storeItem = null;
		ItemDTO item = null;
		StoreItemHelper storeHelper = null;

		/*
		 * Iterate the list and sets the errormessage and item details
		 * StoreItemHelperList for the error in blocking.
		 */
		Iterator errorIter = errorList.iterator();
		while (errorIter.hasNext()) {
			storeItem = (StoreItemDTO) errorIter.next();
			item = storeItem.getItemDto();
			cic = item.getCic();
			upc = item.getUpcCountry() + item.getUpcSystem() + item.getUpcManuf() + item.getUpcSales();
			storeNo = storeItem.getStoreNumber();
			storeHelper = new StoreItemHelper();
			storeHelper.setCicupc(cic + " / " + upc);
			storeHelper.setStoreNo(storeNo);
			storeHelper.setErrorMessage(errorMessage);
			storeItemErrorList.add(storeHelper);
		}
		log.info("<---| Completed Method StoreItemForm." + "iterateAndSetItem");
		return storeItemErrorList;

	}

	public List<StoreItemVO> converToStoreItemVO(List<StoreItemVO> storeItemVOList, List<StoreItemDTO> storeItemDTOList,
			java.util.Date blockDate, Timestamp blockTimeStamp) throws ParseException {
		if (!CollectionUtils.isEmpty(storeItemDTOList)) {
			for (StoreItemDTO storeItemDTO : storeItemDTOList) {
				StoreItemVO storeItem = new StoreItemVO();
				StoreItemVOID itemVOID = new StoreItemVOID();
				itemVOID.setCorp(storeItemDTO.getDivisionDto().getCorp());
				itemVOID.setDivision(storeItemDTO.getDivisionDto().getDivisionNumber());
				itemVOID.setStoreNumber(storeItemDTO.getStoreNumber());
				itemVOID.setCic(getBigDecimal(storeItemDTO.getItemDto().getCic()));
				itemVOID.setDc(storeItemDTO.getItemDto().getDc());
				storeItem.setStoreItemVOID(itemVOID);
				storeItem.setUpcCountry(getBigDecimal(storeItemDTO.getItemDto().getUpcCountry()));
				storeItem.setUpcSystem(getBigDecimal(storeItemDTO.getItemDto().getUpcSystem()));
				storeItem.setUpcManuf(getBigDecimal(storeItemDTO.getItemDto().getUpcManuf()));
				storeItem.setUpcSales(getBigDecimal(storeItemDTO.getItemDto().getUpcSales()));
				storeItem.blockItem();
				storeItem.setLastUpdatedTimeStamp(blockTimeStamp);
				storeItem.setLastUpdatedUser(storeItemDTO.getLastUpdatedUser());
				storeItem.setState(MeupConstant.STATE_UNALLOCATED);
				// storeItem.setBlockedTargetDate(new
				// Date(storeItemDTO.getBlockedTargetDate().getTime()));
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
				java.util.Date blockTargetDate = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
						.parse(storeItemDTO.getBlockedTargetDate());
				storeItem.setBlockedTargetDate((blockTargetDate));
				storeItem.setStateEffectiveDate(new Date(blockDate.getTime()));
				storeItemVOList.add(storeItem);
			}
		}
		return storeItemVOList;
	}

	public static BigDecimal getBigDecimal(String value) {
		return (value == null || value.equals("")) ? BigDecimal.ZERO : new BigDecimal(value);
	}
}