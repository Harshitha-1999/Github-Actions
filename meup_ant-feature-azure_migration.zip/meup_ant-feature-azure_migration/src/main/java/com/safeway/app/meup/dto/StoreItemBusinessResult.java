
package com.safeway.app.meup.dto;

import com.safeway.app.meup.dto.BusinessResult;
import lombok.Data;

import java.util.List;

@Data
public class StoreItemBusinessResult extends BusinessResult {

    /**
     * all divisionDto List.
     */
    private List<String> divisionList;

    /**
     * Contains all invalid Store Numbers - String.
     */
    private List<String> invalidStoreList;

    /**
     * Contains all Items passed validation - StoreItemDto.
     */
    private List<StoreItemDTO> validStoreItemList;

    /**
     * Contains all invalid Store Items - StoreItemDto.
     */
    private List<StoreItemDTO> invalidStoreItemList;

    /**
     * Contains all duplicate Store Items - StoreItemDto.
     */
    private List<StoreItemDTO> duplicateItemList;

    /**
     * Contains all discontinued Store Items - StoreItemDto.
     */
    private List<StoreItemDTO> discontinuedStoreItemList;

    /**
     * Contains all DSD Store Items - StoreItemDto.
     */
    private List<StoreItemDTO> dsdStoreItemList;

    /**
     * Contains all DSD and Warehouse Itemsn - StoreItemDto.
     */
    private List<StoreItemDTO> dsdAndWhStoreItemList;

    /**
     * Contains all schematic data.
     */
    private List<StoreItemDTO> schematicDataList;

}
