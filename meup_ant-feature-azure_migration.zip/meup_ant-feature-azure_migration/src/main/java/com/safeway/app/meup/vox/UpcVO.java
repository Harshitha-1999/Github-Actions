package com.safeway.app.meup.vox;

import com.safeway.app.meup.util.MeupConstant;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;

@Entity
@Immutable
@Table(name = "SSITMURX")
@Polymorphism(type = PolymorphismType.IMPLICIT)
public class UpcVO {

    @EmbeddedId
    UpcVOID upcVOID;

    /*** rog refernece. */
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "CORP_ITEM_CD", referencedColumnName = "CORP_ITEM_CD", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "CORP", referencedColumnName = "CORP", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "ROG", referencedColumnName = "ROG", nullable = false, insertable = false, updatable = false)
    private RogVO rog;

    /*** sto reference. */
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "CORP", referencedColumnName = "CORP", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "ROG", referencedColumnName = "ROG", nullable = false, insertable = false, updatable = false)
    private StoreVO sto;

    /**
     * @return Returns the cic.
     */
    public String getCic() {
        return upcVOID.getCic();
    }

    /**
     * @param cic The cic to set.
     */
    public void setCic(String cic) {
        upcVOID.setCic(cic);
    }

    /**
     * @return Returns the corp.
     */
    public String getCorp() {
        return upcVOID.getCorp();
    }

    /**
     * @param corp The corp to set.
     */
    public void setCorp(String corp) {
        upcVOID.setCorp(corp);
    }

    /**
     * @return Returns the rog.
     */
    public RogVO getRog() {
        return rog;
    }

    /**
     * @param rog The rog to set.
     */
    public void setRog(RogVO rog) {
        this.rog = rog;
    }

    /**
     * @return Returns the upcCountry.
     */
    public String getUpcCountry() {
        return upcVOID.getUpcCountry();
    }

    /**
     * @param upcCountry The upcCountry to set.
     */
    public void setUpcCountry(String upcCountry) {
        upcVOID.setUpcCountry(upcCountry);
    }

    /**
     * @return Returns the upcManuf.
     */
    public String getUpcManuf() {
        return upcVOID.getUpcManuf();
    }

    /**
     * @param upcManuf The upcManuf to set.
     */
    public void setUpcManuf(String upcManuf) {
        upcVOID.setUpcManuf(upcManuf);
    }

    /**
     * @return Returns the upcSales.
     */
    public String getUpcSales() {
        return upcVOID.getUpcSales();
    }

    /**
     * @param upcSales The upcSales to set.
     */
    public void setUpcSales(String upcSales) {
        upcVOID.setUpcSales(upcSales);
    }

    /**
     * @return Returns the upcSystem.
     */
    public String getUpcSystem() {
        return upcVOID.getUpcSystem();
    }

    /**
     * @param upcSystem The upcSystem to set.
     */
    public void setUpcSystem(String upcSystem) {
        upcVOID.setUpcSystem(upcSystem);
    }

    /**
     * @return Returns the sto.
     */
    public StoreVO getSto() {
        return sto;
    }

    /**
     * @param sto The sto to set.
     */
    public void setSto(StoreVO sto) {
        this.sto = sto;
    }

    /**
     * Checks whether the Item is DSD Item or not.
     *
     * @return boolean
     */
    public boolean isDSDItem() {

        String productSourceInd = this.getRog().getProductSourceInd().trim();

        return productSourceInd.equals(MeupConstant.PRODUCT_SOURCE_IND_DSD);

    }

    /**
     * Checks whether the Item is DSD and Warehouse Item or not.
     *
     * @return boolean
     */
    public boolean isDSDAndWhseItem() {
        String productSourceInd = this.getRog().getProductSourceInd().trim();
        return productSourceInd.equals(MeupConstant.PRODUCT_SOURCE_IND_DSDWHSE);
    }

    /**
     * Check whether the item is Discontinued or not.
     *
     * @return boolean
     */
    public boolean isDiscontinuedItem() {

        String statusDst = this.getRog().getWds().getStatusDst().trim();
        return statusDst.equals(MeupConstant.DISCONTINUED_PROCESS_STATUS_KEY) ||
                statusDst.equals(MeupConstant.DISCONTINUED_STATUS_KEY);
    }
}
