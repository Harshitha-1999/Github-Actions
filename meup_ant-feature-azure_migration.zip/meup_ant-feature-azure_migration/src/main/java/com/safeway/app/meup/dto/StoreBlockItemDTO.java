package com.safeway.app.meup.dto;

import com.safeway.app.meup.dto.SerializableDTO;

import java.sql.Date;
import java.util.List;

public class StoreBlockItemDTO extends SerializableDTO {
    private String userID;
    private String divisionNumber;
    private Date deleteDate;
    List<StoreItemDTO> storeItems;

    /**
     * @return Returns the userID.
     */
    public String getuserID() {
        return userID;
    }

    /**
     * @param userID The userID to set.
     */
    public void setuserID(String userID) {
        this.userID = userID;
    }

        /**
         * @return Returns the divisionNumber.
         */
    public String getdivisionNumber() {
        return divisionNumber;
    }

    /**
     * @param divisionNumber The divisionNumber to set.
     */
    public void setdivisionNumber(String divisionNumber) {
        this.divisionNumber = divisionNumber;
    }

    /**
     * @return Returns the deleteDate.
     */
    public Date getdeleteDate() {
        return deleteDate;
    }

    /**
     * @param deleteDate The deleteDate to set.
     */
    public void setdeleteDate(Date deleteDate) {
        this.deleteDate = deleteDate;
    }


}
