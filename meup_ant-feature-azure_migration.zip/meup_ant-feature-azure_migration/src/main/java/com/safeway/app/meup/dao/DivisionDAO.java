package com.safeway.app.meup.dao;

import java.sql.SQLException;
import java.util.List;

import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.vox.StockingSectionVO;

public interface DivisionDAO {

	public List<DivisionDTO> getDivisionList();

	public String getCorp(String div);


	public List<DivisionDTO> getDivisionListByStatus(String corp, String groupCode,
			List<StockingSectionVO> stockingSectionList, char itemStateCode, char blockedStatusCode) throws MeupException, SQLException;

	public List<DivisionDTO> getDivisionListByCorp(String corp);

	boolean isValidDivision(String divisionNumber) throws MeupException;

}
