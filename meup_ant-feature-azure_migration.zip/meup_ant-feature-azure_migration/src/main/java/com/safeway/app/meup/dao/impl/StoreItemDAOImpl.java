package com.safeway.app.meup.dao.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.jdbc.ReturningWork;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.ItemCountsByStoreDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.exceptions.LogErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.util.MeupConstant;
import com.safeway.app.meup.util.MeupLogUtil;
import com.safeway.app.meup.util.MeupUtility;
import com.safeway.app.meup.vox.CommentVO;
import com.safeway.app.meup.vox.StoreItemVO;
import com.safeway.app.meup.vox.UpcVO;

@Repository
@PropertySource(value = { "classpath:/sql.properties" })
public class StoreItemDAOImpl implements StoreItemDAO {
	private static final Logger log = LoggerFactory.getLogger(StoreItemDAOImpl.class);

	@Autowired
	@Qualifier("db2DS")
	NamedParameterJdbcTemplate namedParameterjdbcTemplate;

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	@Qualifier("defaultSession")
	SessionFactory defaultsessionFactory;

	@Autowired
	@Qualifier("snowFlakDatasource")
	JdbcTemplate snowflakejdbctemplate;

	@Value("${sql.getItemCountsOnHold}")
	private String getItemCountsOnHoldQuery;

	@Value("${sql.getstockingSectionCondition}")
	private String getstockingSectionConditionQuery;

	@Value("${sql.getdivisionListCondition}")
	private String getdivisionListConditionQuery;

	@Value("${sql.getgroupByCondtion}")
	private String getgroupByCondtionQuery;

	@Value("${sql.getorderByCondition}")
	private String getorderByConditionQuery;

	@Value("${sql.getitemListForStoreStockSection}")
	private String getitemListForStoreStockSection;

	@Value("${sql.getSearchQueryUs1}")
	private String getSearchQueryUs;

	@Value("${sql.getSearchQueryCanada}")
	private String getSearchQueryCanada;

	@Value("${sql.getqueryForGroupGroupCodeList}")
	private String getqueryForGroupGroupCodeList;

	@Value("${sql.getSqlQueryCorp}")
	private String getSqlQueryCorp;

	@Value("${sql.getSqlQueryDivisionList}")
	private String getSqlQueryDivisionList;

	@Value("${sql.getSqlQueryBlocked}")
	private String getSqlQueryBlocked;

	@Value("${sql.getSqlQueryLastUpdatedUserId}")
	private String getSqlQueryLastUpdatedUserId;

	@Value("${sql.getSqlQueryUpcCountry}")
	private String getSqlQueryUpcCountry;

	@Value("${sql.getSqlQueryUpcSales}")
	private String getSqlQueryUpcSales;

	@Value("${sql.getSqlQueryUpcManuf}")
	private String getSqlQueryUpcManuf;

	@Value("${sql.getSqlQueryUpcSystem}")
	private String getSqlQueryUpcSystem;

	@Value("${sql.getSqlQueryCic}")
	private String getSqlQueryCic;

	@Value("${sql.getSqlQueryStoreNumber}")
	private String getSqlQueryStoreNumber;

	@Value("${sql.getSqlQueryDeleteDate}")
	private String getSqlQueryDeleteDate;

	@Value("${sql.getSqlQueryState}")
	private String getSqlQueryState;

	@Value("${sql.getQuerySqlSortAsc}")
	private String getQuerySqlSortAsc;

	@Value("${sql.getFetchRowsQuery}")
	private String getFetchRowsQuery;

	@Value("${sql.queryForGroupGroupCode}")
	private String queryForGroupGroupCode;

	@Value("${sql.queryForCategory_CategoryCodeList}")
	private String queryForCategory_CategoryCodeList;

	@Value("${sql.queryForGroup_groupCodeWithNoCtgry}")
	private String queryForGroup_groupCodeWithNoCtgry;

	@Value("${sql.updateStoreItemOnHold}")
	private String getupdateStoreItemOnHold;

	@Value("${sql.updateItemsCountsOnHold}")
	private String updateItemsCountsOnHold;

	@Value("${sql.updateQuery}")
	private String updateQuery;

	@Value("${sql.insertHistory}")
	private String insertHistory;

	@Value("${sql.insertComment}")
	private String insertComment;

	@Value("${sql.QueryForForViewingReport}")
	private String queryForForViewingReport;

	@Value("${sql.QueryForForViewingReport.subQuery}")
	private String queryForForViewingReportsubQuery;

	@Value("${sql.QueryForForViewingReport.sortingAsc}")
	private String queryForForViewingReportsortingAsc;

	@Value("${hql.getItemDetail}")
	private String hqlgetItemDetail;

	private int insertCount = 0;
	private int updatedRecords = 0;
	private PreparedStatement insertItm = null;

	public static BigDecimal getBigDecimal(String value) {
		return (value == null || value.equals("")) ? BigDecimal.ZERO : new BigDecimal(value);
	}

	public List<ItemCountsByStoreDTO> getItemCountsOnHold(String corp, List<String> stockingSectionList,
			List<String> divisionList) throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".getItemCountsOnHold");
		log.debug("---->StoreItemDAOImpl.getItemCountsOnHold");
		StringBuilder sb = new StringBuilder();
		String stockingSection = "";
		String division = "";
		char itemStateCode = 'H';
		char blockedStatusCode = 'H';
		// String sql = "" + getItemCountsOnHoldQuery;

		sb.append(getItemCountsOnHoldQuery);

		if (null != stockingSectionList && !stockingSectionList.isEmpty()) {
			sb.append(" ");
			sb.append(getstockingSectionConditionQuery);
			sb.append(" ( ");

			Iterator<?> stockingSectionListIterator = stockingSectionList.iterator();
			while (stockingSectionListIterator.hasNext()) {
				if (!"".equals(stockingSection)) {
					stockingSection = stockingSection + ", " + stockingSectionListIterator.next();
				} else {
					stockingSection = stockingSection + stockingSectionListIterator.next();
				}
			}

			sb.append(stockingSection);
			sb.append(") ");
		}
		if (null != divisionList && !divisionList.isEmpty()) {
			sb.append(" ");
			sb.append(getdivisionListConditionQuery);
			sb.append(" ( ");
			Iterator<?> divisionListIterator = divisionList.iterator();
			while (divisionListIterator.hasNext()) {
				if (!"".equals(division)) {
					division = division + ", " + divisionListIterator.next();
				} else {
					division = division + divisionListIterator.next();
				}

			}
			sb.append(division);
			sb.append(") ");
		}

		sb.append(" ");
		sb.append(getgroupByCondtionQuery);
		sb.append(" ");
		sb.append(getorderByConditionQuery);

		List<ItemCountsByStoreDTO> itemCountsByStoreDTO = new ArrayList<>();

		itemCountsByStoreDTO = snowflakejdbctemplate.query(new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement stmnt = con.prepareStatement(sb.toString());
				stmnt.setString(1, corp);
				stmnt.setString(2, Character.toString(itemStateCode));
				stmnt.setString(3, Character.toString(blockedStatusCode));
				return stmnt;
			}
		}, new RowMapper<ItemCountsByStoreDTO>() {

			@Override
			public ItemCountsByStoreDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				ItemCountsByStoreDTO itemByStore = new ItemCountsByStoreDTO();

				itemByStore.setCorporationId(corp);
				itemByStore.setDivisionId(rs.getString("DIVISION_ID"));

				itemByStore.setStockSectnbr(rs.getString("STOCK_SECT_NBR"));
				itemByStore.setStoreId(rs.getString("STORE_ID"));
				itemByStore.setItemCount(rs.getInt("ITEM_COUNT"));
				itemByStore.setStatus("H");
				itemByStore.setOldPogName(rs.getString("OLD_POG_NM") == null ? " " : rs.getString("OLD_POG_NM"));
				itemByStore.setNewPogName(rs.getString("NEW_POG_NM") == null ? " " : rs.getString("NEW_POG_NM"));
				return itemByStore;
			}
		});
		log.info("<---| Completed Method StoreItemDAOImpl " + ". getItemCountsOnHold ");
		return itemCountsByStoreDTO;

	}

	@Override
	public void updateItemsByStoreStockingSection(List<HoldItemDTO> holdItemList, String userID)
			throws MeupException, SQLException {
		log.info("-->Beginning- StoreItemDAOImpl.updateItemsStoreLevel");
		log.info("-->DB call started for method StoreItemDAOImpl.updateItemsStoreLevel");
		int result[] = snowflakejdbctemplate.batchUpdate(updateItemsCountsOnHold, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				if (holdItemList.get(i).getStatus().equals("A")) {
					ps.setString(1, "U");
					ps.setString(2, "B");
				} else if (holdItemList.get(i).getStatus().equals("R")) {
					ps.setString(1, "A");
					ps.setString(2, "U");
				}
				ps.setString(3, userID);
				ps.setInt(4, holdItemList.get(i).getStockSectionNbr());
				ps.setInt(5, holdItemList.get(i).getDivisionNbr());
				ps.setInt(6, holdItemList.get(i).getStoreID());

			}

			@Override
			public int getBatchSize() {
				return holdItemList.size();
			}
		});
		log.info("-->DB call ended for method StoreItemDAOImpl.updateItemsStoreLevel");
		log.info("-->Completed- StoreItemDAOImpl.updateItemsStoreLevel");
		log.info("Item Update By Store Stocking sestion {} ", result.length);

	}

	@Override
	public void updateItemsByStoreStockSection(List<HoldItemDTO> holdItemList, String userID, String groupID)
			throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".updateItemsByStoreStockSection");
		log.info("|---> DB Call started for Method StoreItemDAOImpl" + ".updateItemsByStoreStockSection");
		int result[] = snowflakejdbctemplate.batchUpdate(getupdateStoreItemOnHold, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {

				if (holdItemList.get(i).getStatus().equals("A")) {
					ps.setString(1, "U");
					ps.setString(2, "B");
				} else if (holdItemList.get(i).getStatus().equals("R")) {
					ps.setString(1, "A");
					ps.setString(2, "U");
				}
				ps.setString(3, userID);
				ps.setInt(4, holdItemList.get(i).getStockSectionNbr());
				ps.setInt(5, holdItemList.get(i).getDivisionNbr());
				ps.setInt(6, holdItemList.get(i).getStoreID());
				ps.setLong(7, holdItemList.get(i).getUpcID());

			}

			@Override
			public int getBatchSize() {
				return holdItemList.size();
			}
		});
		log.info("|---> DB Call ended for Method StoreItemDAOImpl" + ".updateItemsByStoreStockSection");
		log.info("<---| Completed Method StoreItemDAOImpl " + ". updateItemsByStoreStockSection ");
		log.info("Number of records updated {}", result.length);

	}

	@Override
	public List<HoldItemDTO> getItemListForStoreStockSection(String corp, String storeID, String stockSectionNbr)
			throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".getItemListForStoreStockSection");
		List<HoldItemDTO> holdItemDTOList = new ArrayList<>();
		char itemStateCd = 'H';
		char blockedStateCd = 'H';

		if (null != corp && corp.trim().length() != 0 && null != storeID && storeID.trim().length() != 0
				&& null != stockSectionNbr && stockSectionNbr.trim().length() != 0) {

			holdItemDTOList = snowflakejdbctemplate.query(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement stmnt = con.prepareStatement(getitemListForStoreStockSection);

					stmnt.setString(1, corp);
					stmnt.setString(2, storeID);
					stmnt.setString(3, stockSectionNbr);
					stmnt.setString(4, Character.toString(itemStateCd));
					stmnt.setString(5, Character.toString(blockedStateCd));
					return stmnt;
				}
			}, new RowMapper<HoldItemDTO>() {

				@Override
				public HoldItemDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
					HoldItemDTO item = new HoldItemDTO();
					item.setCic(rs.getInt("CORP_ITEM_CD"));
					item.setCorp(rs.getInt("CORPORATION_ID"));
					item.setDesc(rs.getString("UPC_DSC"));
					item.setDivisionNbr(rs.getInt("DIVISION_ID"));
					item.setSchematicEffectiveDate(rs.getDate("ITEM_STATE_EFF_DT"));
					item.setStatus("H");
					item.setStockSectionNbr(rs.getInt("STOCK_SECT_NBR"));
					item.setStoreID(rs.getInt("STORE_ID"));
					item.setUpcID(rs.getLong("UPC_ID"));
					return item;
				}
			});

		} else {
			throw new MeupException("Invalid parameters");
		}
		log.info("<---| Completed Method StoreItemDAOImpl " + ". getItemListForStoreStockSection ");
		return holdItemDTOList;

	}

	@Override
	public List<StoreItemDTO> selectBlockedWhStoreItems(StoreItemSearchDTO storeItemSearchDto) throws MeupException {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".selectBlockedWhStoreItems");
		List<StoreItemDTO> storeItemDtoList = null;
		MapSqlParameterSource map = new MapSqlParameterSource();
		try {
			StringBuilder query = new StringBuilder();

			/* creating query for corp */
			String corp = storeItemSearchDto.getCountryCd();
			corp = corp.trim();
			query.append(getSearchQueryUs);
			List<DivisionDTO> divisionDTOList = storeItemSearchDto.getDivisions();
			if (null != divisionDTOList && divisionDTOList.size() != 0) {
				log.info("<---| Beginning Method StoreItemDAOImpl " + ". createQueryForGroupAndCategory ");
				List<SmicGroupDTO> smicGroupDtoList = storeItemSearchDto.getGroups();
				if (null == smicGroupDtoList || smicGroupDtoList.isEmpty()) {
				} else {
					log.info("<---| Beginning Method StoreItemDAOImpl " + ". createQueryForGroupAndCategory ");
					/* smicCategoryDtoList */
					List groupCodeList = MeupUtility.getGroupCodesFromDto(smicGroupDtoList);
					List smicCategoryDtoList = storeItemSearchDto.getCategories();
					Map groupCodeCategoryCodeMap = null;
					String group_Code_List = null;
					if (null == smicCategoryDtoList || smicCategoryDtoList.isEmpty()) {
						map.addValue("groupCodeList",
								smicGroupDtoList.stream().map(s -> s.getGroupCd()).collect(Collectors.toList()).stream()
										.map(Integer::parseInt).collect(Collectors.toList()));
						query.append(" AND ICD.GROUP_CD IN (:groupCodeList) ");

					} else {
						groupCodeCategoryCodeMap = new HashMap();
						Iterator iterator = smicCategoryDtoList.iterator();
						String groupCode = null;
						List categoryCodeList = null;
						SmicCategoryDTO smicCategoryDTO = null;
						while (iterator.hasNext()) {
							smicCategoryDTO = (SmicCategoryDTO) iterator.next();
							groupCode = smicCategoryDTO.getCategoryCd().substring(0, 2);

							if (null == groupCodeCategoryCodeMap.get(groupCode)) {
								categoryCodeList = new ArrayList();
								groupCodeCategoryCodeMap.put(groupCode, categoryCodeList);
							}
							categoryCodeList.add(smicCategoryDTO.getCategoryCd().substring(2, 4));
						} // while

						// generating query for group and category
						Iterator mapIterator = null;
						Map.Entry entry = null;
						String groupCd = null;
						String categoryCdForQuery = null;
						List categoryCdList = new ArrayList();

						if (null != groupCodeCategoryCodeMap) {

							query.append(" ");
							query.append(MeupConstant.AND_STRING);
							query.append(" ");
							query.append(MeupConstant.OPENING_BRACKET);
							query.append(" ");
							mapIterator = groupCodeCategoryCodeMap.entrySet().iterator();
							int i = 0;
							while (mapIterator.hasNext()) {
								entry = (Map.Entry) mapIterator.next();
								groupCd = (String) entry.getKey();
								groupCodeList.remove(groupCd);
								map.addValue("groupCd" + i, Integer.valueOf(groupCd.trim()));
								query.append(" ( ICD.GROUP_CD =:groupCd" + i);
								categoryCdList = (List) entry.getValue();
								// categoryCdForQuery =
								// MeupUtility.getCommaSeparatedStringForCategoryCode(categoryCdList);
								// map.addValue("category" + i,
								// Integer.valueOf(categoryCdForQuery.trim()).intValue());
								map.addValue("category" + i, categoryCdList);
								query.append(" AND CLF.CTGRY_CD IN (:category" + i);
								query.append(") ) ");
								query.append(" ");
								query.append(MeupConstant.OR_STRING);
								query.append(" ");
								i++;
							} // while

							String groupCodeFromIterator = null;
							i = 0;
							if (groupCodeList.size() > 0) {
								Iterator groupCodeIterator = groupCodeList.iterator();
								while (groupCodeIterator.hasNext()) {
									groupCodeFromIterator = (String) groupCodeIterator.next();
									map.addValue("groupcode" + i,
											Integer.valueOf(groupCodeFromIterator.trim()));
									query.append(" ");
									query.append("ICD.GROUP_CD =:groupcode" + i);
									query.append(" ");
									query.append(MeupConstant.OR_STRING);
									i++;
								}
							} // groupcode
						}
						int queryLength = query.length();
						query.delete(queryLength - MeupConstant.OR_LENGTH, queryLength);
						query.append(" ");
						query.append(MeupConstant.CLOSING_BRACKET);
					} // category dto list is null
				} // group dto list is null

				log.info("<---| Completed Method StoreItemDAOImpl " + ". createQueryForGroupAndCategory ");

			}
			query.append(MeupConstant.CLOSING_BRACKET);
			if (null != corp && !"".equals(corp)) {
				map.addValue("corp", corp);
				query.append(" AND MUI.CORP= :corp ");
			}

			if (null != divisionDTOList && divisionDTOList.size() != 0) {
				map.addValue("div",
						divisionDTOList.stream().map(s -> s.getDivisionNumber()).collect(Collectors.toList()));
				query.append(" AND MUI.DIV IN (:div) ");
			}

			query.append(" " + getSqlQueryBlocked);
			query.append(" " + getSqlQueryLastUpdatedUserId);
			String upcManuf = storeItemSearchDto.getUpcManuf();
			String upcSales = storeItemSearchDto.getUpcSales();
			String upcCountry = storeItemSearchDto.getUpcCountry();
			String upcSystem = storeItemSearchDto.getUpcSystem();

			if ((null == upcManuf || "".equals(upcManuf.trim())) || (null == upcSales || "".equals(upcSales.trim()))
					|| (null == upcCountry || "".equals(upcCountry.trim()))
					|| (null == upcSystem || "".equals(upcCountry.trim()))) {
			} else {
				map.addValue("upcCountry", upcCountry.trim());
				map.addValue("upcSystem", upcSystem.trim());
				map.addValue("upcManuf", upcManuf.trim());
				map.addValue("upcSales", upcSales.trim());
				query.append(" AND MUI.UPC_COUNTRY=:upcCountry ");
				query.append(" AND MUI.UPC_SALES=:upcSales ");
				query.append(" AND MUI.UPC_MANUF=:upcManuf ");
				query.append(" AND MUI.UPC_SYSTEM= :upcSystem ");

			}
			String cic = storeItemSearchDto.getCic();
			if (null != cic) {
				map.addValue("cic", cic.trim());
				query.append(" AND MUI.CORP_ITEM_CD=:cic ");
			}
			String storeNumber = storeItemSearchDto.getStoreNumber();
			if (null != storeNumber) {
				map.addValue("fac", storeNumber);
				query.append(" AND MUI.FAC=:fac ");
			}
			String deleteDateStart = storeItemSearchDto.getDeleteDateStart();
			String deleteDateEnd = storeItemSearchDto.getDeleteDateEnd();

			if (null != deleteDateStart && null != deleteDateEnd) {
				map.addValue("deleteDateEnd", deleteDateEnd.trim());
				map.addValue("deleteDateStart", deleteDateStart.trim());
				query.append(" AND MUI.BLOCKED_TARGET_DT<=:deleteDateEnd AND MUI.BLOCKED_TARGET_DT>=:deleteDateStart ");
			}

			if (storeItemSearchDto.getUserDto().getRole().equals(MeupConstant.ADMIN_ROLE)) {
				// * creating query for state *//*
				String state = storeItemSearchDto.getState();
				if (null != state) {
					map.addValue("stateInd", state.trim());
					query.append(" AND MUI.STATE_IND=:stateInd ");
				}
			}
			String userRole = storeItemSearchDto.getUserDto().getRole();
			if (null == userRole) {
			}

			query.append(MeupConstant.CLOSING_BRACKET);
			query.append(" " + getQuerySqlSortAsc.trim());
			query.append(" FETCH FIRST 4001 ROWS ONLY WITH UR ");

			log.info("<---| Completed Method StoreItemDAOImpl " + ". createQueryForSearchingStoreItem ");
			log.info("<---| DB call started for Method StoreItemDAOImpl " + ". createQueryForSearchingStoreItem ");
			storeItemDtoList = namedParameterjdbcTemplate.query(query.toString(), map,
					new ResultSetExtractor<List<StoreItemDTO>>() {
						@Override
						public List<StoreItemDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {

							List<StoreItemDTO> resultStoreItemDtoList = null;
							try {
								resultStoreItemDtoList = processResultSetUpdateStoreItems(rs);
							} catch (MeupException e) {
								e.printStackTrace();
							}
							return resultStoreItemDtoList;
						}
					});
			if (null == storeItemDtoList || storeItemDtoList.isEmpty()) {
				log.debug("No results returned from db");
			} else {
				log.debug("No. of rows returned: " + storeItemDtoList.size());
			}
			log.info("<---| DB call ended for Method StoreItemDAOImpl " + ". createQueryForSearchingStoreItem ");
		} catch (Exception sqlException) {
			log.error(LogErrorMessage.SEARCH_EXCEPTION + " : " + sqlException.getMessage());
			throw new MeupException(LogErrorMessage.SEARCH_EXCEPTION + " : " + sqlException.getMessage());
		}
		log.info("<---| Completed Method StoreItemDAOImpl " + ". selectBlockedWhStoreItems ");
		return storeItemDtoList;

	}

	/**
	 * Method used to generate the dynamic query based on the user role.
	 *
	 * @param storeItemSearchDto storeItemSearchDto object
	 * @return String -the dynamic query generated
	 */

	private String createQueryForSearchingStoreItem(StoreItemSearchDTO storeItemSearchDto) {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".createQueryForSearchingStoreItem");
		StringBuilder query = new StringBuilder();

		String corp = null;
		String storeNumber = null;
		String cic = null;
		String state = null;
		String userRole = null;
		String upcManuf = null;
		String upcSales = null;
		String upcCountry = null;
		String upcSystem = null;
		List<DivisionDTO> divisionDTOList = null;
		String deleteDateStart = null;
		String deleteDateEnd = null;

		/* creating query for corp */
		corp = storeItemSearchDto.getCountryCd();
		corp = corp.trim();
		query.append(getSearchQueryUs);
		divisionDTOList = storeItemSearchDto.getDivisions();
		if (null != divisionDTOList && divisionDTOList.size() != 0) {
			query.append(createQueryForGroupAndCategory(query, storeItemSearchDto));
		} else {
		}

		query.append(MeupConstant.CLOSING_BRACKET);
		if (null != corp && !"".equals(corp)) {
			query.append(" " + String.format(getSqlQueryCorp, corp).trim());
		}

		if (null != divisionDTOList && divisionDTOList.size() != 0) {
			String divisions = MeupUtility.getCommaSeparatedStringForDivision(divisionDTOList);
			query.append(" " + String.format(getSqlQueryDivisionList, divisions).trim());
		}

		query.append(" " + getSqlQueryBlocked);
		query.append(" " + getSqlQueryLastUpdatedUserId);
		upcManuf = storeItemSearchDto.getUpcManuf();
		upcSales = storeItemSearchDto.getUpcSales();
		upcCountry = storeItemSearchDto.getUpcCountry();
		upcSystem = storeItemSearchDto.getUpcSystem();

		if ((null == upcManuf || "".equals(upcManuf.trim())) || (null == upcSales || "".equals(upcSales.trim()))
				|| (null == upcCountry || "".equals(upcCountry.trim()))
				|| (null == upcSystem || "".equals(upcCountry.trim()))) {
		} else {
			query.append(" " + String.format(getSqlQueryUpcCountry, upcCountry.trim()).trim());

			query.append(" " + String.format(getSqlQueryUpcSales, upcSales.trim()).trim());
			query.append(" " + String.format(getSqlQueryUpcManuf, upcManuf.trim()).trim());
			query.append(" " + String.format(getSqlQueryUpcSystem, upcSystem.trim()).trim());

		}
		cic = storeItemSearchDto.getCic();
		if (null == cic || "".equals(cic.trim())) {
			log.info("cic has not been entered");
		} else {
			query.append(" " + String.format(getSqlQueryCic, cic.trim()).trim());
		}
		storeNumber = storeItemSearchDto.getStoreNumber();
		if (null == storeNumber || "".equals(storeNumber.trim())) {
			log.info("storeNumber has not been entered ");
		} else {
			query.append(" " + String.format(getSqlQueryStoreNumber, storeNumber.trim()).trim());
		}
		deleteDateStart = storeItemSearchDto.getDeleteDateStart();
		deleteDateEnd = storeItemSearchDto.getDeleteDateEnd();

		if (null == deleteDateStart || null == deleteDateEnd) {
			log.info("dates are null");
		} else {
			String[] dateStringArray = { deleteDateEnd.trim(), deleteDateStart.trim() };
			query.append(" " + String.format(getSqlQueryDeleteDate, dateStringArray[1], dateStringArray[0]));
		}

		if (storeItemSearchDto.getUserDto().getRole().equals(MeupConstant.ADMIN_ROLE)) {
			// * creating query for state *//*
			state = storeItemSearchDto.getState();
			if (null == state || "".equals(state.trim())) {

			} else {
				query.append(" " + String.format(getSqlQueryState, state.trim()).trim());
			}
		}
		userRole = storeItemSearchDto.getUserDto().getRole();
		if (null == userRole || "".equals(userRole.trim())) {
		}

		query.append(MeupConstant.CLOSING_BRACKET);
		query.append(" " + getQuerySqlSortAsc.trim());

		query.append(" " + String.format(getFetchRowsQuery, MeupConstant.MAX_RESULTSET_SIZE).trim());

		log.info("<---| Completed Method StoreItemDAOImpl " + ". createQueryForSearchingStoreItem ");
		return query.toString();
	}

	public String createQueryForGroupAndCategory(StringBuilder query, StoreItemSearchDTO storeItemSearchDto) {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".createQueryForGroupAndCategory");
		List<SmicGroupDTO> smicGroupDtoList = storeItemSearchDto.getGroups();
		if (null == smicGroupDtoList || smicGroupDtoList.isEmpty()) {
		} else {

			/* smicCategoryDtoList */
			List groupCodeList = MeupUtility.getGroupCodesFromDto(smicGroupDtoList);
			List smicCategoryDtoList = storeItemSearchDto.getCategories();
			Map groupCodeCategoryCodeMap = null;
			String group_Code_List = null;
			if (null == smicCategoryDtoList || smicCategoryDtoList.isEmpty()) {
				group_Code_List = MeupUtility.getCommaSeparatedStringForGroupCode(groupCodeList);
				query.append(" ( ICD.GROUP_CD = ");
				query.append(group_Code_List);
			} else {
				groupCodeCategoryCodeMap = new HashMap();
				Iterator iterator = smicCategoryDtoList.iterator();
				String groupCode = null;
				List categoryCodeList = null;
				SmicCategoryDTO smicCategoryDTO = null;
				while (iterator.hasNext()) {
					smicCategoryDTO = (SmicCategoryDTO) iterator.next();
					groupCode = smicCategoryDTO.getCategoryCd().substring(0, 2);

					if (null == groupCodeCategoryCodeMap.get(groupCode)) {
						categoryCodeList = new ArrayList();
						groupCodeCategoryCodeMap.put(groupCode, categoryCodeList);
					}
					categoryCodeList.add(smicCategoryDTO.getCategoryCd().substring(2, 4));
				} // while

				// generating query for group and category
				Iterator mapIterator = null;
				Map.Entry entry = null;
				String groupCd = null;
				String categoryCdForQuery = null;
				List categoryCdList = new ArrayList();

				if (null != groupCodeCategoryCodeMap) {

					query.append(" ");
					query.append(MeupConstant.AND_STRING);
					query.append(" ");
					query.append(MeupConstant.OPENING_BRACKET);
					query.append(" ");
					mapIterator = groupCodeCategoryCodeMap.entrySet().iterator();
					while (mapIterator.hasNext()) {
						entry = (Map.Entry) mapIterator.next();
						groupCd = (String) entry.getKey();
						groupCodeList.remove(groupCd);
						query.append(" ( ICD.GROUP_CD = ");
						query.append(groupCd.trim());
						categoryCdList = (List) entry.getValue();
						categoryCdForQuery = MeupUtility.getCommaSeparatedStringForCategoryCode(categoryCdList);
						query.append("AND CLF.CTGRY_CD IN (  ");
						query.append(categoryCdForQuery.trim());
						query.append(") ) ");
						query.append(" ");
						query.append(MeupConstant.OR_STRING);
						query.append(" ");
					} // while

					String groupCodeFromIterator = null;
					if (groupCodeList.size() > 0) {
						Iterator groupCodeIterator = groupCodeList.iterator();
						while (groupCodeIterator.hasNext()) {
							groupCodeFromIterator = (String) groupCodeIterator.next();
							query.append(" ");
							query.append("ICD.GROUP_CD = ");
							query.append(groupCodeFromIterator);
							query.append(" ");
							query.append(MeupConstant.OR_STRING);
						}
					} // groupcode
				}
				int queryLength = query.length();
				query.delete(queryLength - MeupConstant.OR_LENGTH, queryLength);
				query.append(" ");
				query.append(MeupConstant.CLOSING_BRACKET);
			} // category dto list is null
		} // group dto list is null

		log.info("<---| Completed Method StoreItemDAOImpl " + ". createQueryForGroupAndCategory ");
		return query.toString();
	}

	/**
	 * Method used to get all the storeItemDtos based on the dynamic query
	 * generated.
	 *
	 * @param resultSet resultSet
	 * @return List containing storeItemDtos.
	 * @throws MeupException
	 */
	private List<StoreItemDTO> processResultSetUpdateStoreItems(ResultSet resultSet) throws MeupException {

		String fac = null;
		String lastUpdUserId = null;
		String descItem = null;
		float size = 0;
		String unitOfMeasure = null;
		String categoryName = null;
		String categoryCd = null;
		String groupCd = null;
		String corp = null;
		String divisionNumber = null;
		String upcSales = null;
		String upcManuf = null;
		String upcSystem = null;
		String upcCountry = null;
		String stateInd;
		Date stateEffDt = null;
		Date blockedTargetDt = null;
		String cic = null;
		float packRetail = 0;
		String blockedStatus;
		String dc = null;
		int counter = 1;
		boolean isSchematic;
		List<StoreItemDTO> storeItemDtoList = null;
		try {
			if (null == storeItemDtoList) {
				storeItemDtoList = new ArrayList<>();
			}
			while (resultSet.next()) {
				isSchematic = false;
				/* getting blocked status from the resultSet */
				blockedStatus = resultSet.getString("BLOCKED_STAT_IND");

				/* getting group code from the resultSet */
				groupCd = resultSet.getString("GROUP_CD");
				if (null != groupCd) {
					groupCd = groupCd.trim();
					if (groupCd.length() == MeupConstant.GROUP_CD_LENGTH) {
						groupCd = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(groupCd);
					}
				}

				/* getting category code from the resultSet */
				categoryCd = resultSet.getString("CTGRY_CD");
				if (null != categoryCd) {
					categoryCd = categoryCd.trim();
					if (categoryCd.length() == MeupConstant.CTGRY_CD_LENGTH) {
						categoryCd = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(categoryCd);
					}
					categoryCd = groupCd + categoryCd;
				}

				/* getting category name from the resultSet */
				categoryName = resultSet.getString("CLSIFICATION_DESC");
				if (null != categoryName) {
					categoryName = categoryName.trim();
				} else {

					/* If the item has no category name and number,display blank */
					if (null == categoryCd && null == categoryName) {
						categoryCd = "";
						categoryName = "";
					}
				}

				/* getting corp value from the resultSet */
				corp = resultSet.getString("CORP");
				if (null != corp) {
					corp = corp.trim();
				}

				/* getting division number from the resultSet */
				divisionNumber = resultSet.getString("DIV");
				if (null != divisionNumber) {
					divisionNumber = divisionNumber.trim();
				}

				/* getting upc sales from the resultSet */
				upcSales = resultSet.getString("UPC_SALES");
				if (null != upcSales) {
					upcSales = upcSales.trim();
					if (upcSales.length() < MeupConstant.UPC_SALES_LENGTH) {
						upcSales = MeupUtility.appendZeros(upcSales, MeupConstant.UPC_SALES_LENGTH);
					}
				}

				/* getting upc manuf from the resultSet */
				upcManuf = resultSet.getString("UPC_MANUF");
				if (null != upcManuf) {
					upcManuf = upcManuf.trim();
					if (upcManuf.length() < MeupConstant.UPC_MANUF_LENGTH) {
						upcManuf = MeupUtility.appendZeros(upcManuf, MeupConstant.UPC_MANUF_LENGTH);
					}
				}

				/* getting upc system from the resultSet */
				upcSystem = resultSet.getString("UPC_SYSTEM");
				if (null != upcSystem) {
					upcSystem = upcSystem.trim();
				}

				/* getting upc country from the resultSet */
				upcCountry = resultSet.getString("UPC_COUNTRY");
				if (null != upcCountry) {
					upcCountry = upcCountry.trim();
				}

				/* getting corporate item code from the resultSet */
				cic = resultSet.getString("CORP_ITEM_CD");
				if (null != cic) {
					cic = cic.trim();
					if (cic.length() < 8) {
						cic = MeupUtility.appendZeros(cic, 8);
					}
				}
				/* getting fac from the resultSet */
				fac = resultSet.getString("FAC");
				if (null != fac) {
					fac = fac.trim();
				}

				/* getting state indicator from the resultSet */
				stateInd = resultSet.getString("STATE_IND");

				/* getting state effective date from the resultSet */
				stateEffDt = resultSet.getDate("STATE_EFF_DT");

				/*
				 * getting blocked target date from the resultSet its of the format yyyy-MM-dd
				 */
				blockedTargetDt = resultSet.getDate("BLOCKED_TARGET_DT");

				/* getting last updated user id from the resultSet */
				lastUpdUserId = resultSet.getString("LAST_UPD_USER_ID");
				if (null != lastUpdUserId) {
					lastUpdUserId = lastUpdUserId.trim();
					if (lastUpdUserId.equalsIgnoreCase(MeupConstant.SCHEMATIC_USERID)
							|| lastUpdUserId.equalsIgnoreCase(MeupConstant.SCHEMATIC_VALUE)) {
						lastUpdUserId = MeupConstant.SCHEMATIC_VALUE;
						isSchematic = true;
					}
				}

				/* getting last dc from the resultSet */
				dc = resultSet.getString("DST_CNTR");
				if (null != dc) {
					dc = dc.trim();
				}

				/* getting description of the item from the resultSet */
				descItem = resultSet.getString("DESC_ITEM");
				if (null != descItem) {
					descItem = descItem.trim();
				}

				/* getting size from the resultSet */
				size = resultSet.getFloat("SIZE_NUM");

				/* getting unit of measure from the resultSet */
				unitOfMeasure = resultSet.getString("SIZE_UOM");
				if (null != unitOfMeasure) {
					unitOfMeasure = unitOfMeasure.trim();
				}

				/* getting pack retail from the resultSet */
				packRetail = resultSet.getFloat("PACK_RETAIL");

				StoreItemDTO storeItemDto = new StoreItemDTO();
				SmicCategoryDTO smicCategoryDto = new SmicCategoryDTO();
				smicCategoryDto.setCategoryCd(categoryCd);
				smicCategoryDto.setcategoryDesc(categoryName);
				smicCategoryDto.setGroupCd(groupCd);

				/* setting to storeItemDto */
				storeItemDto.setSmicCategoryDto(smicCategoryDto);
				DivisionDTO divisionDto = new DivisionDTO();
				divisionDto.setDivisionNumber(divisionNumber);
				divisionDto.setCorp(corp);
				storeItemDto.setDivisionDto(divisionDto);
				storeItemDto.setBlockedStatus(blockedStatus);
				ItemDTO itemDto = new ItemDTO();
				itemDto.setDc(dc);
				itemDto.setCic(cic);
				itemDto.setUpcCountry(upcCountry);
				itemDto.setUpcManuf(upcManuf);
				itemDto.setUpcSales(upcSales);
				itemDto.setUpcSystem(upcSystem);
				storeItemDto.setItemDto(itemDto);
				storeItemDto.setStoreNumber(fac);
				storeItemDto.setState(stateInd);
				//storeItemDto.setStateEffectiveDate(new java.sql.Date(stateEffDt.getTime()));
				String stateEffectiveDateString=new SimpleDateFormat("yyyy-MM-dd").format(stateEffDt);
				storeItemDto.setStateEffectiveDate(stateEffectiveDateString);
				// storeItemDto.setBlockedTargetDate((new
				// java.sql.Date(blockedTargetDt.getTime())).toLocalDate());
				// storeItemDto.setBlockedTargetDate(new
				// java.sql.Date(blockedTargetDt.getTime()));
				storeItemDto.setBlockedTargetDate(String.valueOf((blockedTargetDt)));
				storeItemDto.setLastUpdatedUser(lastUpdUserId);
				storeItemDto.setDescription(descItem);
				storeItemDto.setSize(size);
				storeItemDto.setUom(unitOfMeasure);
				storeItemDto.setCasePk(packRetail);
				storeItemDto.setSchematicData(isSchematic);

				/* adding dto to list */
				storeItemDtoList.add(storeItemDto);
				counter++;
			}
		} catch (SQLException sqlException) {
			log.error(LogErrorMessage.SEARCH_EXCEPTION + " : " + sqlException.getMessage());
			throw new MeupException(LogErrorMessage.SEARCH_EXCEPTION + " : " + sqlException.getMessage());
		} catch (Exception exception) {
			log.error(LogErrorMessage.SEARCH_EXCEPTION + " : " + exception.getMessage());
			throw new MeupException(LogErrorMessage.SEARCH_EXCEPTION + " : " + exception.getMessage());
		}

		return (storeItemDtoList);
	}

	@Override
	public List<StoreItemDTO> selectStoreItemsForReport(StoreItemSearchDTO storeItemSearchDto)
			throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreItemDAOImpl" + ".selectStoreItemsForReport");
		List<StoreItemDTO> storeItemDtoList = null;
		MapSqlParameterSource map = new MapSqlParameterSource();
		try {
			StringBuilder query = new StringBuilder();
			/* creating query for corp */
			String corp = storeItemSearchDto.getCountryCd();
			if (null == corp || "".equals(corp.trim())) {
			} else {
				corp = corp.trim();
				query.append(queryForForViewingReport);
			}

			/* creating query for group and category */
			List<DivisionDTO> divisionDTOList = storeItemSearchDto.getDivisions();
			if (null != divisionDTOList && divisionDTOList.size() != 0) {

				List<SmicGroupDTO> smicGroupDtoList = storeItemSearchDto.getGroups();
				if (null == smicGroupDtoList || smicGroupDtoList.isEmpty()) {
				} else {

					/* smicCategoryDtoList */
					List groupCodeList = MeupUtility.getGroupCodesFromDto(smicGroupDtoList);
					List smicCategoryDtoList = storeItemSearchDto.getCategories();
					Map groupCodeCategoryCodeMap = null;
					String group_Code_List = null;
					if (null == smicCategoryDtoList || smicCategoryDtoList.isEmpty()) {
						group_Code_List = MeupUtility.getCommaSeparatedStringForGroupCode(groupCodeList);
						map.addValue("groupCodeList",
								smicGroupDtoList.stream().map(s -> s.getGroupCd()).collect(Collectors.toList()).stream()
										.map(Integer::parseInt).collect(Collectors.toList()));
						query.append(" AND ICD.GROUP_CD IN (:groupCodeList) ");

					} else {
						groupCodeCategoryCodeMap = new HashMap();
						Iterator iterator = smicCategoryDtoList.iterator();
						String groupCode = null;
						List categoryCodeList = null;
						SmicCategoryDTO smicCategoryDTO = null;
						while (iterator.hasNext()) {
							smicCategoryDTO = (SmicCategoryDTO) iterator.next();
							groupCode = smicCategoryDTO.getCategoryCd().substring(0, 2);

							if (null == groupCodeCategoryCodeMap.get(groupCode)) {
								categoryCodeList = new ArrayList();
								groupCodeCategoryCodeMap.put(groupCode, categoryCodeList);
							}
							categoryCodeList.add(smicCategoryDTO.getCategoryCd().substring(2, 4));
						} // while

						// generating query for group and category
						Iterator mapIterator = null;
						Map.Entry entry = null;
						String groupCd = null;
						String categoryCdForQuery = null;
						List categoryCdList = new ArrayList();

						if (null != groupCodeCategoryCodeMap) {

							query.append(" ");
							query.append(MeupConstant.AND_STRING);
							query.append(" ");
							query.append(MeupConstant.OPENING_BRACKET);
							query.append(" ");
							mapIterator = groupCodeCategoryCodeMap.entrySet().iterator();
							int i = 0;
							while (mapIterator.hasNext()) {
								entry = (Map.Entry) mapIterator.next();
								groupCd = (String) entry.getKey();
								groupCodeList.remove(groupCd);
								map.addValue("groupCd" + i, Integer.valueOf(groupCd.trim()));
								query.append(" ( ICD.GROUP_CD =:groupCd" + i);
								categoryCdList = (List) entry.getValue();
								map.addValue("category" + i, categoryCdList);
								query.append(" AND CLF.CTGRY_CD IN (:category" + i);
								query.append(") ) ");
								query.append(" ");
								query.append(MeupConstant.OR_STRING);
								query.append(" ");
								i++;
							} // while

							String groupCodeFromIterator = null;
							i = 0;
							if (groupCodeList.size() > 0) {
								Iterator groupCodeIterator = groupCodeList.iterator();
								while (groupCodeIterator.hasNext()) {
									groupCodeFromIterator = (String) groupCodeIterator.next();
									map.addValue("groupcode" + i, Integer.valueOf(groupCodeFromIterator));
									query.append(" ");
									query.append("ICD.GROUP_CD =:groupcode" + i);
									query.append(" ");
									query.append(MeupConstant.OR_STRING);
									i++;
								}
							} // groupcode
						}
						int queryLength = query.length();
						query.delete(queryLength - MeupConstant.OR_LENGTH, queryLength);
						query.append(" ");
						query.append(MeupConstant.CLOSING_BRACKET);
					} // category dto list is null
				} // group dto list is null

				log.info("<---| Completed Method StoreItemDAOImpl " + ". createQueryForGroupAndCategory ");

			} else {
				log.info("Division DTO list null");
			}

			query.append(MeupConstant.CLOSING_BRACKET);

			if (null != corp && !"".equals(corp)) {
				query.append(" AND MUH.CORP= :corp ");
				map.addValue("corp", corp);
			}
			if (null != divisionDTOList && divisionDTOList.size() != 0) {
				query.append("  AND MUH.DIV IN ( :div) ");
				map.addValue("div",
						divisionDTOList.stream().map(s -> s.getDivisionNumber()).collect(Collectors.toList()));
			}

			/* for getting all items whose last updated user id is not MEND */
			query.append(" AND ( MUH.LAST_UPD_USER_ID <'MEND' OR MUH.LAST_UPD_USER_ID >'MEND') ");

			/* creating query for cic */
			String cic = storeItemSearchDto.getCic();
			if ((null != cic)) {
				query.append(" AND MUH.CORP_ITEM_CD= :cic ");
				map.addValue("cic", cic.trim());
			}

			/* creating query for upc */
			String upcManuf = storeItemSearchDto.getUpcManuf();
			String upcSales = storeItemSearchDto.getUpcSales();
			String upcCountry = storeItemSearchDto.getUpcCountry();
			String upcSystem = storeItemSearchDto.getUpcSystem();

			if ((null == upcManuf || "".equals(upcManuf.trim())) || (null == upcSales || "".equals(upcSales.trim()))
					|| (null == upcCountry || "".equals(upcCountry.trim()))
					|| (null == upcSystem || "".equals(upcSystem.trim()))) {
				// log.info("upc has not been entered");
			} else {

				query.append(" AND MUH.UPC_COUNTRY= :upcCountry");
				query.append(" AND MUH.UPC_SYSTEM= :upcSystem");
				query.append(" AND MUH.UPC_MANUF= :upcManuf");
				query.append(" AND MUH.UPC_SALES=:upcSales");
				map.addValue("upcCountry", upcCountry.trim());
				map.addValue("upcSystem", upcSystem.trim());
				map.addValue("upcManuf", upcManuf.trim());
				map.addValue("upcSales", upcSales.trim());
			}

			/* creating query for store */
			String storeNumber = storeItemSearchDto.getStoreNumber();
			if (null != storeNumber) {
				query.append(" AND MUH.FAC= :fac");
				map.addValue("fac", storeNumber);
			}

			/* creating query for state */
			String state = storeItemSearchDto.getState();
			if (null != state) {
				query.append(" AND MUH.STATE_IND= :stateInd ");
				map.addValue("stateInd", state.trim());
			}

			/* creating query for status */
			String status = storeItemSearchDto.getStatus();
			if (null != status) {
				map.addValue("blockedStatus", status.trim());
				query.append("  AND MUH.BLOCKED_STAT_IND= :blockedStatus ");

			}

			query.append(" " + queryForForViewingReportsubQuery.trim());

			query.append(MeupConstant.CLOSING_BRACKET);
			query.append(" " + queryForForViewingReportsortingAsc.trim());
			query.append(" FETCH FIRST 4001 ROWS ONLY WITH UR ");
			log.info("<--Completed StoreItemDAOImpl.createQueryForViewingReport()");
			storeItemDtoList = namedParameterjdbcTemplate.query(query.toString(), map,
					new ResultSetExtractor<List<StoreItemDTO>>() {
						@Override
						public List<StoreItemDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
							List<StoreItemDTO> resultStoreItemDtoList = null;
							try {
								resultStoreItemDtoList = processResultSetForViewReport(rs);
							} catch (MeupException e) {
								e.printStackTrace();
							}
							return resultStoreItemDtoList;
						}
					});
			if (null == storeItemDtoList || storeItemDtoList.isEmpty()) {
				log.debug("No results returned from db");
			} else {
				log.debug("No. of rows returned: " + storeItemDtoList.size());
			}
		} catch (Exception sqlException) {
			log.error(LogErrorMessage.SEARCH_EXCEPTION + " : " + sqlException.getMessage());
			throw new MeupException(LogErrorMessage.SEARCH_EXCEPTION + " : " + sqlException.getMessage());
		}
		log.info("<---| Completed Method StoreItemDAOImpl " + ". selectStoreItemsForReport ");
		return storeItemDtoList;

	}

	@Override
	@Transactional
	public int updateBlockedItem(List<StoreItemDTO> storeItemDtoList, String userId, CommentVO commentDto,
			boolean unblock, Timestamp timestamp) throws MeupException, SQLException {
		log.info("-->Beginning StoreItemDAOImpl.updateBlockedItem()");
		Iterator<?> iterator = null; 
		iterator = storeItemDtoList.iterator();
		StoreItemDTO storeItemDTO = null;
		String corp = null;
		insertCount = 0;
		log.info("-->DB call started for method S toreItemDAOImpl.updateBlockedItem()");
		try (Connection con = namedParameterjdbcTemplate.getJdbcTemplate().getDataSource().getConnection(); 
				PreparedStatement ps = con.prepareStatement(updateQuery)){
			while (iterator.hasNext()) {
				storeItemDTO = (StoreItemDTO) iterator.next();
				if (null != storeItemDTO) {
					storeItemDTO.setLastUpdatedUser(userId);
					storeItemDTO.setLastUpdatedTimeStamp(timestamp);
					if (unblock) {
						storeItemDTO.setBlockedStatus(MeupConstant.UNBLOCKED_STATUS_KEY);
						storeItemDTO.setState(MeupConstant.STATE_ALLOCATED);
						//storeItemDTO.setStateEffectiveDate(new java.sql.Date(MeupUtility.getCurrentDate().getTime()));
						String stateEffectiveDateString=new SimpleDateFormat("yyyy-MM-dd").format(MeupUtility.getCurrentDate().getTime());
						storeItemDTO.setStateEffectiveDate(stateEffectiveDateString);
						storeItemDTO.setBlockedTargetDate(
								String.valueOf(new java.sql.Date(MeupUtility.createLowDate().getTime())));

					}
					corp = storeItemDTO.getDivisionDto().getCorp();
					// StoreItemVO prepareStoreItemVO = new StoreItemVO();
					if (null == corp || "".equals(corp.trim())) {
						log.debug("corp value null or empty");
					} else { /* Getting all the queries */
						String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
								.format(storeItemDTO.getLastUpdatedTimeStamp());
						ps.setString(1, storeItemDTO.getState());
						//ps.setString(2, MeupUtility.formatDateForSql(storeItemDTO.getStateEffectiveDate()));
						ps.setString(2,(storeItemDTO.getStateEffectiveDate()));
						ps.setString(3, storeItemDTO.getBlockedStatus());
						ps.setString(4, storeItemDTO.getBlockedTargetDate());
						ps.setString(5, timeStamp);
						ps.setString(6, storeItemDTO.getLastUpdatedUser());
						ps.setString(7, storeItemDTO.getDivisionDto().getCorp());
						ps.setString(8, storeItemDTO.getDivisionNumber());
						ps.setString(9, storeItemDTO.getCic());
						ps.setString(10, storeItemDTO.getItemDto().getDc());
						ps.setString(11, storeItemDTO.getStoreNumber());
						ps.addBatch();
					}
					insertCount++;

				}
				if (insertCount == MeupConstant.INSERT_COMMIT_SIZE) {
					ps.executeBatch();
					ps.clearBatch();
					insertCount = 0;
				}
				
			}
			if (insertCount < MeupConstant.INSERT_COMMIT_SIZE) {
				ps.executeBatch();
				ps.clearBatch();
			}
			log.info("-->DB call ended for method StoreItemDAOImpl.updateBlockedItem()");

			/* Performing bulk update to History Table */

			updatedRecords = updateHistory(corp, timestamp);
			log.info("<--Completed StoreItemDAOImpl.updateBlockedItem()");
		} catch (MeupException meupException) {
			log.error(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + meupException.getMessage());
			throw new MeupException(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + meupException.getMessage());

		} finally {
			if (updatedRecords > 0) {
				insertCommentInDBJPA(corp, commentDto, timestamp, userId);
			}
		}
		return updatedRecords;
	}

	private void insertCommentInDBJPA(String corp, CommentVO commentVo, Timestamp timestamp, String userId)
			throws MeupException, SQLException {
		log.info("-->Beginning StoreItemDAOImpl.insertCommentInDBJPA()");
		if (null == corp || "".equals(corp.trim())) {
			log.debug("corp value null or empty");
		} else {
			corp = corp.trim();
			String sql = String.format(insertComment, timestamp, userId, commentVo.getCommentDesc());

			try {
				Session session = defaultsessionFactory.openSession();
				session.doReturningWork(new ReturningWork<String>() {
					@Override
					public String execute(Connection con) throws SQLException {

						PreparedStatement pst = con.prepareStatement(sql);
						try {
							insertCount = pst.executeUpdate();
							return "sucessfully updated";
						} catch (Exception e) {
							throw new SQLException(e);
						} finally {
							session.close();
							pst.close();
						}
					}
				});
				log.info("<--Completed StoreItemDAOImpl.insertCommentInDBJPA()");
			} catch (Exception e) {
				log.error(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + e.getMessage());
				throw new MeupException(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + e.getMessage());
			} finally {
			}
		}
	}

	@Override
	public int updateHistory(String corp, Timestamp timestamp) throws MeupException {
		log.info("---->updateHistory(String corp,Timestamp timestamp)");
		try {

			insertCount = 0;
			if (null == corp || "".equals(corp.trim())) {
				log.debug("corp value null or empty");
			} else {
				MapSqlParameterSource map = new MapSqlParameterSource();
				String timeStampSec = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(timestamp);
				map.addValue("timeStampSec", timeStampSec);
				log.info("-->DB call started for method StoreItemDAOImpl.updateHistory()");
				insertCount = namedParameterjdbcTemplate.update(insertHistory, map);
				log.info("-->DB call ended for method StoreItemDAOImpl.updateHistory()");
			}

		} catch (Exception e) {
			log.error(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + e.getMessage());
			throw new MeupException(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + e.getMessage());
		} finally {
		}
		return insertCount;
	}

	private List<StoreItemDTO> processResultSetForViewReport(ResultSet resultSet) throws MeupException {

		/**
		 * fac - fac value
		 */
		String fac = null;

		/**
		 * lastUpdUserId - last updated user id
		 */
		String lastUpdUserId = null;

		/**
		 * descItem - description of the item
		 */
		String descItem = null;

		/**
		 * size
		 */
		float size = 0;

		/**
		 * unitOfMeasure - unit of measure
		 */
		String unitOfMeasure = null;

		/**
		 * categoryName - category name
		 */
		String categoryName = null;

		/**
		 * categoryCd - category code
		 */
		String categoryCd = null;

		/**
		 * groupCd - group code
		 */
		String groupCd = null;

		/**
		 * corp
		 */
		String corp = null;

		/**
		 * divNumberList - division number list
		 */
		String divisionNumber = null;

		/**
		 * upcSales - upc sales
		 */
		String upcSales = null;

		/**
		 * upcManuf - upc manuf
		 */
		String upcManuf = null;

		/**
		 * upcSystem - upc system
		 */
		String upcSystem = null;

		/**
		 * upcCountry - upc country
		 */
		String upcCountry = null;

		/**
		 * stateInd - Indicates the state of the item (allocated/unallocated)
		 */
		String stateInd;

		/**
		 * stateEffDt - state effective date
		 */
		Date stateEffDt = null;

		/**
		 * blockedTargetDt - blocked target date
		 */
		Date blockedTargetDt = null;

		/**
		 * cic - corporate item code
		 */
		String cic = null;

		/**
		 * packRetail
		 */
		float packRetail = 0;

		/**
		 * status - denotes if the item is blocked/unblocked
		 */
		String status;

		/**
		 * itemType - denotes if the item is wharehouse,DSD,CPS and Specialty
		 */
		StringBuffer itemType = null;

		/**
		 * dstCenter - denotes if the item is wharehouse or DSD
		 */
		String dstCenter = null;

		/**
		 * commentBuyer
		 */
		String commentBuyer = null;

		/**
		 * counter for checking the size of resultset
		 */
		int counter = 1;
		/**
		 * storeItemDtoList - List containing StoreItemDTOs
		 */
		List<StoreItemDTO> storeItemDtoList = null;
		try {
			if (null == storeItemDtoList) {
				storeItemDtoList = new ArrayList<>();
			}
			while (resultSet.next()) {

				itemType = new StringBuffer();

				/* getting group code from the resultSet */
				groupCd = resultSet.getString("GROUP_CD");
				if (null != groupCd) {
					groupCd = groupCd.trim();
					if (groupCd.length() == MeupConstant.GROUP_CD_LENGTH) {
						groupCd = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(groupCd);
					}
				}

				/*
				 * getting category code from the resultSet The category code set to the
				 * storeItemDto contains both group code and category code
				 */
				categoryCd = resultSet.getString("CTGRY_CD");
				if (null != categoryCd) {
					categoryCd = categoryCd.trim();
					if (categoryCd.length() == MeupConstant.CTGRY_CD_LENGTH) {
						categoryCd = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(categoryCd);
					}
					categoryCd = groupCd + categoryCd;
				}

				/* getting category name from the resultSet */
				categoryName = resultSet.getString("CLSIFICATION_DESC");
				if (null != categoryName) {
					categoryName = categoryName.trim();
				} else {

					/*
					 * If the item has no category name and number, display blank
					 */
					if (null == categoryCd && null == categoryName) {
						categoryCd = "";
						categoryName = "";
					}
				}

				/* getting corp value from the resultSet */
				corp = resultSet.getString("CORP");
				if (null != corp) {
					corp = corp.trim();
				}

				/* getting division number from the resultSet */
				divisionNumber = resultSet.getString("DIV");
				if (null != divisionNumber) {
					divisionNumber = divisionNumber.trim();
				}

				/* getting upc sales from the resultSet */
				upcSales = resultSet.getString("UPC_SALES");
				if (null != upcSales) {
					upcSales = upcSales.trim();
					if (upcSales.length() < MeupConstant.UPC_SALES_LENGTH) {
						upcSales = MeupUtility.appendZeros(upcSales, MeupConstant.UPC_SALES_LENGTH);
					}
				}

				/* getting upc manuf from the resultSet */
				upcManuf = resultSet.getString("UPC_MANUF");
				if (null != upcManuf) {
					upcManuf = upcManuf.trim();
					if (upcManuf.length() < MeupConstant.UPC_SALES_LENGTH) {
						upcManuf = MeupUtility.appendZeros(upcManuf, MeupConstant.UPC_SALES_LENGTH);
					}
				}

				/* getting upc system from the resultSet */
				upcSystem = resultSet.getString("UPC_SYSTEM");
				if (null != upcSystem) {
					upcSystem = upcSystem.trim();
				}

				/* getting upc country from the resultSet */
				upcCountry = resultSet.getString("UPC_COUNTRY");
				if (null != upcCountry) {
					upcCountry = upcCountry.trim();
				}

				/* getting corporate item code from the resultSet */
				cic = resultSet.getString("CORP_ITEM_CD");
				if (null != cic) {
					cic = cic.trim();
				}

				/* getting fac from the resultSet */
				fac = resultSet.getString("FAC");
				if (null != fac) {
					fac = fac.trim();
				}

				/* getting state indicator from the resultSet */
				stateInd = resultSet.getString("STATE_IND");

				/* getting state effective date from the resultSet */
				stateEffDt = resultSet.getDate("STATE_EFF_DT");

				/* getting blocked target date from the resultSet */
				blockedTargetDt = resultSet.getDate("BLOCKED_TARGET_DT");

				/* getting description of the item from the resultSet */
				descItem = resultSet.getString("DESC_ITEM");
				if (null != descItem) {
					descItem = descItem.trim();
				}

				/* getting size from the resultSet */
				size = resultSet.getFloat("SIZE_NUM");

				/* getting unit of measure from the resultSet */
				unitOfMeasure = resultSet.getString("SIZE_UOM");
				if (null != unitOfMeasure) {
					unitOfMeasure = unitOfMeasure.trim();
				}

				/* getting pack retail from the resultSet */
				packRetail = resultSet.getFloat("PACK_RETAIL");

				/* status */
				status = resultSet.getString("BLOCKED_STAT_IND");

				/* dstCenter */
				dstCenter = resultSet.getString("DST_CNTR");

				/* comment buyer */
				commentBuyer = resultSet.getString("COMMENT_BUYER");

				/*
				 * checking if the item is dsd,warehouse, speciality and cps
				 */

				if (MeupUtility.checkForDsdItem(dstCenter)) {
					itemType.append(MeupConstant.DSD_ITEM);

					if (null != commentBuyer && !("").equals(commentBuyer.trim())) {
						if (MeupUtility.checkForSpecialityItem(commentBuyer)) {
							itemType.append(" " + MeupConstant.HYPHEN + " " + MeupConstant.SPECIALITY_ITEM);
						}
					}
				} else {
					itemType.append(MeupConstant.WAREHOUSE_ITEM);

					if (MeupUtility.checkForCpsItem(dstCenter)) {
						itemType.append(" " + MeupConstant.HYPHEN + " " + MeupConstant.CPS_ITEM);
					}
					if (null != commentBuyer && !("").equals(commentBuyer.trim())) {
						if (MeupUtility.checkForSpecialityItem(commentBuyer)) {
							itemType.append(" " + MeupConstant.HYPHEN + " " + MeupConstant.SPECIALITY_ITEM);
						}
					}
				}

				StoreItemDTO storeItemDto = new StoreItemDTO();
				SmicCategoryDTO smicCategoryDto = new SmicCategoryDTO();
				smicCategoryDto.setCategoryCd(categoryCd);
				smicCategoryDto.setcategoryDesc(categoryName);
				smicCategoryDto.setGroupCd(groupCd);

				/* setting to storeItemDto */
				storeItemDto.setSmicCategoryDto(smicCategoryDto);

				DivisionDTO divisionDto = new DivisionDTO();
				divisionDto.setDivisionNumber(divisionNumber);
				divisionDto.setCorp(corp);
				storeItemDto.setDivisionDto(divisionDto);

				ItemDTO itemDto = new ItemDTO();
				itemDto.setCic(cic);

				itemDto.setUpcCountry(upcCountry);
				itemDto.setUpcManuf(upcManuf);
				itemDto.setUpcSales(upcSales);
				itemDto.setUpcSystem(upcSystem);
				storeItemDto.setItemDto(itemDto);
				storeItemDto.setStoreNumber(fac);
				storeItemDto.setState(stateInd);
				//storeItemDto.setStateEffectiveDate(new java.sql.Date(stateEffDt.getTime()));
				String stateEffectiveDateString=new SimpleDateFormat("yyyy-MM-dd").format(stateEffDt.getTime());
				storeItemDto.setStateEffectiveDate(stateEffectiveDateString);
				// storeItemDto.setBlockedTargetDate(new
				// java.sql.Date(blockedTargetDt.getTime()));
				storeItemDto.setBlockedTargetDate(String.valueOf((blockedTargetDt)));
				storeItemDto.setLastUpdatedUser(lastUpdUserId);
				storeItemDto.setDescription(descItem);

				storeItemDto.setSize(size);
				storeItemDto.setUom(unitOfMeasure);

				storeItemDto.setCasePk(packRetail);
				storeItemDto.setBlockedStatus(status);
				storeItemDto.setItemType(itemType.toString().trim());
				storeItemDtoList.add(storeItemDto);
				counter++;

			}
		} catch (SQLException sqlException) {
			log.error(LogErrorMessage.VIEW_REPORT_EXCEPTION + " : " + sqlException.getMessage());
			throw new MeupException(LogErrorMessage.VIEW_REPORT_EXCEPTION + " : " + sqlException.getMessage());
		} catch (Exception exception) {
			log.error(LogErrorMessage.VIEW_REPORT_EXCEPTION + " : " + exception.getMessage());
			throw new MeupException(LogErrorMessage.VIEW_REPORT_EXCEPTION + " : " + exception.getMessage());
		}
		return (storeItemDtoList);
	}

	@Override
	public void updateBlockStoreItems(List<StoreItemVO> storeItemVOList) throws MeupException {
		log.info("Beginning of method StoreItemDAOImpl.updateBlockStoreItems");

		Session session = sessionFactory.openSession();
		try {
			Transaction tx = session.beginTransaction();
			if (!CollectionUtils.isEmpty(storeItemVOList)) {
				for (StoreItemVO itemVO : storeItemVOList) {
					session.saveOrUpdate(itemVO);
					session.flush();
				}
				tx.commit();

			}
		} catch (HibernateException exception) {
			log.error(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + exception.getMessage());
			throw new MeupException(LogErrorMessage.MASTER_INSERT_EXCEPTION + " :" + exception.getMessage());
		} catch (Exception e) {
			log.error(LogErrorMessage.MASTER_INSERT_EXCEPTION, e);
			if (e.getCause() instanceof SQLException) {
				SQLException se = (SQLException) e.getCause();
				int errorCode = se.getErrorCode();
				if (errorCode == -913) {
					log.error(LogErrorMessage.DB_DEADLOCK_913, e);
					throw new MeupException(LogErrorMessage.DB_DEADLOCK_913);
				}
			}
		} finally {
			session.clear();
			session.close();
		}
		log.info("|<--- Completed Method StoreItemDAOImpl.updateBlockStoreItems");

	}

	@Override
	public UpcVO getItemDetails(String cic, String upcCountry, String upcSystem, String upcManuf, String upcSales,
			String facility, String corp, String division) throws MeupException {
		log.info("|---> Beginning Method StoreItemDAOImpl");

		log.debug(MeupLogUtil.startLog(this.getClass().getName(), "getItemDetails"));
		Integer cicValue = null;
		Integer upcCountryValue = null;
		Integer upcSystemValue = null;
		Integer upcManufValue = null;
		Integer upcSalesValue = null;
		Session session = null;
		/** Validations */
		if (cic == null || upcCountry == null || upcSystem == null || upcManuf == null || upcSales == null
				|| facility == null) {
			return null;
		}
		try {
			cicValue = Integer.parseInt(cic);
			upcCountryValue = Integer.parseInt(upcCountry);
			upcSystemValue = Integer.parseInt(upcSystem);
			upcManufValue = Integer.parseInt(upcManuf);
			upcSalesValue = Integer.parseInt(upcSales);
		} catch (NumberFormatException exception) {
			return null;
		}
		if (facility.length() > 4) {
			return null;
		}
		try {
			String getItemHQL = hqlgetItemDetail;
			session = sessionFactory.openSession();
			Query query = session.createQuery(getItemHQL);
			query.setInteger("cic", Integer.parseInt(cic));
			query.setInteger("upcCountry", Integer.parseInt(upcCountry));
			query.setInteger("upcSystem", Integer.parseInt(upcSystem));
			query.setInteger("upcSales", Integer.parseInt(upcSales));
			query.setInteger("upcManuf", Integer.parseInt(upcManuf));
			query.setString("corp", corp);
			query.setString("facility", facility);
			query.setString("division", division);

			Object obj = query.uniqueResult();
			UpcVO urx = null;
			if (null != obj) {
				urx = (UpcVO) ((Object[]) obj)[0];
			}
			session.close();
			log.info("|<--- Completed Method getItemDetails");
			return urx;
		} catch (HibernateException exception) {
			log.error(LogErrorMessage.ITEM_LOADING_EXCEPTION + " :" + exception.getMessage());
			throw new MeupException(LogErrorMessage.ITEM_LOADING_EXCEPTION + " :" + exception.getMessage());
		} finally {
			session.close();
		}
	}

	@Override
	public StoreItemVO getStoreItem(String corp, String divisionNumber, String cic, String dstCenter,
			String storeNumber) throws MeupException {
		log.info("|---> Beginning Method StoreItemDAOImpl.getStoreItem");

		if (null == corp || null == divisionNumber || null == cic || null == dstCenter || null == storeNumber) {
			return null;
		}
		if (corp.length() > 3 || divisionNumber.length() > 2 || dstCenter.length() > 4 || storeNumber.length() > 4) {
			return null;
		}
		try {
			Long.parseLong(cic);
		} catch (NumberFormatException exception) {
			return null;
		}
		try {
			Session session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(StoreItemVO.class)
					.add(Restrictions.eq("storeItemVOID.corp", corp))
					.add(Restrictions.eq("storeItemVOID.division", divisionNumber))
					.add(Restrictions.eq("storeItemVOID.cic", getBigDecimal(cic)))
					.add(Restrictions.eq("storeItemVOID.dc", dstCenter))
					.add(Restrictions.eq("storeItemVOID.storeNumber", storeNumber))
					.add(Restrictions.eq("blockedStatus", "B"));

			StoreItemVO storeItem = (StoreItemVO) criteria.uniqueResult();
			session.close();
			log.info("|<--- Completed Method StoreItemDAOImpl.getStoreItem");
			return storeItem;
		} catch (Exception exception) {
			log.error(LogErrorMessage.ITEM_LOADING_EXCEPTION + " :" + exception.getMessage());
			SQLException se = (SQLException) exception.getCause();
			int errorCode = se.getErrorCode();
			if (errorCode == -913) {
				log.error(LogErrorMessage.DB_DEADLOCK_913, exception);
				throw new MeupException(LogErrorMessage.DB_DEADLOCK_913);
			}
			throw new MeupException(LogErrorMessage.ITEM_LOADING_EXCEPTION + " :" + exception.getMessage());
		}
	}

}
