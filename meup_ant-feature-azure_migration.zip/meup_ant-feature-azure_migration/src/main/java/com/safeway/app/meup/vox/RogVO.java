
package com.safeway.app.meup.vox;




import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;


@Entity
@Immutable
@Table(name = "SSITMROG")
@Polymorphism(type = PolymorphismType.IMPLICIT)
public class RogVO {
    @EmbeddedId
    RogVOID rogVOID;

    /*** FAC value.*/
    @Column(name = "FACILITY")
    private String facility;

    /*** division value.*/
    @Column(name = "DIVISION")
    private String division;

    /*** divisionOrd value.*/
    @Column(name = "DIVISION_ORD")
    private String divisionOrd;

    /*** productSourceIndicator value.*/
    @Column(name = "PRODUCT_SOURCE_IND")
    private String productSourceInd;

    /*** wds value.*/
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "CORP_ITEM_CD", referencedColumnName = "CORP_ITEM_CD", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "CORP", referencedColumnName = "CORP", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "FACILITY", referencedColumnName = "FACILITY", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "DIVISION_ORD", referencedColumnName = "DIVISION", nullable = false, insertable = false, updatable = false)
    private ItemVO wds;


    /**
     * @return Returns the division.
     */
    public String getDivision() {
        return division;
    }

    /**
     * @param division The division to set.
     */
    public void setDivision(String division) {
        this.division = division;
    }

    /**
     * @return Returns the cic.
     */
    public String getCic() {
        return rogVOID.getCic();
    }

    /**
     * @param cic The cic to set.
     */
    public void setCic(String cic) {
        rogVOID.setCic(cic);
    }

    /**
     * @return Returns the corp.
     */
    public String getCorp() {
        return rogVOID.getCorp();
    }

    /**
     * @param corp The corp to set.
     */
    public void setCorp(String corp) {
        rogVOID.setCorp(corp);
    }

    /**
     * @return Returns the divisionOrd.
     */
    public String getDivisionOrd() {
        return divisionOrd;
    }

    /**
     * @param divisionOrd The divisionOrd to set.
     */
    public void setDivisionOrd(String divisionOrd) {
        this.divisionOrd = divisionOrd;
    }

    /**
     * @return Returns the facility.
     */
    public String getFacility() {
        return facility;
    }

    /**
     * @param facility The facility to set.
     */
    public void setFacility(String facility) {
        this.facility = facility;
    }

    /**
     * @return Returns the productSourceInd.
     */
    public String getProductSourceInd() {
        return productSourceInd;
    }

    /**
     * @param productSourceInd The productSourceInd to set.
     */
    public void setProductSourceInd(String productSourceInd) {
        this.productSourceInd = productSourceInd;
    }

    /**
     * @return Returns the rog.
     */
    public String getRog() {
        return rogVOID.getRog();
    }

    /**
     * @param rog The rog to set.
     */
    public void setRog(String rog) {
        rogVOID.setRog(rog);
    }

    /**
     * @return Returns the wds.
     */
    public ItemVO getWds() {
        return wds;
    }

    /**
     * @param wds The wds to set.
     */
    public void setWds(ItemVO wds) {
        this.wds = wds;
    }

    public RogVOID getRogVOID() {
        return rogVOID;
    }

    public void setRogVOID(RogVOID rogVOID) {
        this.rogVOID = rogVOID;
    }
}
