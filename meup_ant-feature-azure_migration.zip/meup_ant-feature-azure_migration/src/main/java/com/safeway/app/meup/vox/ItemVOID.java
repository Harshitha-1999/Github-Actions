package com.safeway.app.meup.vox;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
public class ItemVOID implements Serializable {
    private static final long serialVersionUID = 1L;
    /*** corp value.*/
    @Column(name = "CORP")
    private String corp;

    /*** division value.*/
    @Column(name = "DIVISION")
    private String division;

    /*** facility value.*/
    @Column(name = "FACILITY")
    private String facility;

    /*** CorpItemCode value. */
    @Column(name = "CORP_ITEM_CD")
    private String cic;
}
