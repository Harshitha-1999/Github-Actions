
package com.safeway.app.meup.util;


public class ReportGeneratorConstant {

    public static final int columns=14;
    public static final String name="MeupStoreItem";

//column matched to the getter method of DTO to obtain value
    public static final String [] column_method_names={"getDivisionNumber","getStoreNumber","getCategoryName",
        "getUpc","getCic","getDescription","getItemType","getSize","getUom","getCasePk","getState",
        "getStateEffectiveDate","getBlockedStatus","getBlockedTargetDate"};

    public static String returnColumnMethodName(int columnNumber)
    {
        return column_method_names[columnNumber];
    }

//excel column headers
    public static final String [] column_header_names={"Division","Store","Category","UPC","CIC",
        "Description","Item Type","Size","UOM","CasePk","State","State Effective Date","Status","Delete Date"};

    public static String returnColumnHeaderName (int columnNumber)
    {
        return column_header_names[columnNumber];
    }

    //defines the default width for columnXX
    public static final Integer [] column_widths={8,14,10,10,8,8,12,8,8,8,8,14,8,14};

    public static Integer returnColumnWidth (int columnNumber)
    {
        return column_widths[columnNumber];
    }

    //Defines column XX is resizable or not
    public static final Boolean [] column_resizables={true,true,false,false,false,false,false,false,false,false,false,false,false,false};

    public static Boolean returnColumnResizable (int columnNumber)
    {
        return column_resizables[columnNumber];
    }

    //Defines whether columnXX is visible or not
    public static final Boolean [] column_visibles={true,true,true,true,true,true,true,true,true,true,true,true,true,true};

    public static Boolean returnColumnVisible (int columnNumber)
    {
        return column_visibles[columnNumber];
    }

    //defines the aligment for dispalying in the web page
    public static final String [] column_align={"center","center","center","center","center","center","center","center","center","center","center","center","center","center",};

    public static String returnColumnAlign (int columnNumber)
    {
        return column_align[columnNumber];
    }
    //the data type of the content
    public static final String [] column_type={"string","string","string","string","string","string","string","string","string","string","string","string","string","string"};

    public static String returnColumnType (int columnNumber)
    {
        return column_type[columnNumber];
    }
}
