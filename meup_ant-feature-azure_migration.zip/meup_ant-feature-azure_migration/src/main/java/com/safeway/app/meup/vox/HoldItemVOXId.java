package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class HoldItemVOXId implements Serializable {

    @Column(name = "upc_id")
    private long upcID;

    @Column(name = "store_id")
    private int storeID;

    @Column(name = "division_id")
    private int divisionNbr;

    /**
     * @return the divisionNbr
     */
    public int getDivisionNbr() {
        return divisionNbr;
    }

    /**
     * @param divisionNbr the divisionNbr to set
     */
    public void setDivisionNbr(int divisionNbr) {
        this.divisionNbr = divisionNbr;
    }
    /**
     * @return the storeID
     */
    public int getStoreID() {
        return storeID;
    }

    /**
     * @param storeID the storeID to set
     */
    public void setStoreID(int storeID) {
        this.storeID = storeID;
    }

    /**
     * @return the upcID
     */
    public long getUpcID() {
        return upcID;
    }

    /**
     * @param upcID the upcID to set
     */
    public void setUpcID(long upcID) {
        this.upcID = upcID;
    }

    public HoldItemVOXId(long upcID, int storeID, int divisionNbr) {
        this.upcID = upcID;
        this.storeID = storeID;
        this.divisionNbr = divisionNbr;
    }
}
