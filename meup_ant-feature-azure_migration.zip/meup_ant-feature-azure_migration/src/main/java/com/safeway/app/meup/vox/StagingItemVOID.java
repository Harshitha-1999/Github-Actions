package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * The primary key class for the MEUPSTGI database table.
 *
 */
@Embeddable
public class StagingItemVOID implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "CORP")
    private String corp;
    @Column(name = "DIV")
    private String div;
    @Column(name = "UPLOAD_USER_ID")
    private String userId;
    @Column(name = "UPLOAD_TS")
    private Timestamp stageItemUploadTs;
    @Column(name = "CORP_ITEM_CD")
    private BigDecimal cic;
    @Column(name = "UPC_SALES")
    private BigDecimal upcSales;
    @Column(name = "UPC_MANUF")
    private BigDecimal upcManuf;
    @Column(name = "UPC_SYSTEM")
    private BigDecimal upcSystem;
    @Column(name = "UPC_COUNTRY")
    private BigDecimal upcCountry;

    public String getCorp() {
        return corp;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getStageItemUploadTs() {
        return stageItemUploadTs;
    }

    public void setStageItemUploadTs(Timestamp stageItemUploadTs) {
        this.stageItemUploadTs = stageItemUploadTs;
    }

    public BigDecimal getCic() {
        return cic;
    }

    public void setCic(BigDecimal cic) {
        this.cic = cic;
    }

    public BigDecimal getUpcSales() {
        return upcSales;
    }

    public void setUpcSales(BigDecimal upcSales) {
        this.upcSales = upcSales;
    }

    public BigDecimal getUpcManuf() {
        return upcManuf;
    }

    public void setUpcManuf(BigDecimal upcManuf) {
        this.upcManuf = upcManuf;
    }

    public BigDecimal getUpcSystem() {
        return upcSystem;
    }

    public void setUpcSystem(BigDecimal upcSystem) {
        this.upcSystem = upcSystem;
    }

    public BigDecimal getUpcCountry() {
        return upcCountry;
    }

    public void setUpcCountry(BigDecimal upcCountry) {
        this.upcCountry = upcCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StagingItemVOID that = (StagingItemVOID) o;

        if (!corp.equals(that.corp)) return false;
        if (!div.equals(that.div)) return false;
        if (!userId.equals(that.userId)) return false;
        if (!stageItemUploadTs.equals(that.stageItemUploadTs)) return false;
        if (!cic.equals(that.cic)) return false;
        if (!upcSales.equals(that.upcSales)) return false;
        if (!upcManuf.equals(that.upcManuf)) return false;
        if (!upcSystem.equals(that.upcSystem)) return false;
        return upcCountry.equals(that.upcCountry);
    }

    @Override
    public int hashCode() {
        int result = corp.hashCode();
        result = 31 * result + div.hashCode();
        result = 31 * result + userId.hashCode();
        result = 31 * result + stageItemUploadTs.hashCode();
        result = 31 * result + cic.hashCode();
        result = 31 * result + upcSales.hashCode();
        result = 31 * result + upcManuf.hashCode();
        result = 31 * result + upcSystem.hashCode();
        result = 31 * result + upcCountry.hashCode();
        return result;
    }
}
