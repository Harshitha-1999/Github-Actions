
package com.safeway.app.meup.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.safeway.app.meup.dao.DivisionDAO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.DivisionService;
import com.safeway.app.meup.vox.StockingSectionVO;

@Service
public class DivisionServiceImpl implements DivisionService {

	@Autowired
	private DivisionDAO divisionDAO;

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<DivisionDTO> getDivisionList() {
		List<DivisionDTO> divisionList = divisionDAO.getDivisionList();
		return divisionList;
	}

	/**
	 * Method to get the divisions for a group and stocking section that is in Hold
	 * status If the stocking section is not selected, tehn the divisions for a
	 * group must be selected
	 *
	 * @param corp                - contains the corp
	 * @param groupCode
	 * @param stockingSectionList - List of stocking sections
	 * @param itemStateCode       - char
	 * @param blockedStatusCode   - char
	 * @return divisionDtoList - List of divisionDTO
	 * @throws SQLException
	 * @throws MeupException that occurs
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<DivisionDTO> getDivisionListOnHold(String corp, String groupCode,
			List<StockingSectionVO> stockingSectionList, char itemStateCode, char blockedStatusCode)
			throws MeupException, SQLException {

		List<DivisionDTO> divisionList = divisionDAO.getDivisionListByStatus(corp, groupCode, stockingSectionList,
				itemStateCode, blockedStatusCode);

		return divisionList;

	}

	/**
	 * Get all the valid divisions available within the corp US and Cananda.
	 *
	 * @return the list of DivisionBO
	 * @throws MeupException when error occurs while fetching division details
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<DivisionDTO> createDivisions() {
		List<DivisionDTO> divisionList = divisionDAO.getDivisionList();

		return divisionList;
	}

	/**
	 * To get the corpValue for the given division.
	 *
	 * @param div
	 * @return corp the String
	 * @throws MeupException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public String getCorpForDiv(String div) {
		return divisionDAO.getCorp(div);
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<DivisionDTO> getDivisionListForUS(String corp) {

		List<DivisionDTO> divisionList = divisionDAO.getDivisionListByCorp(corp);

		return divisionList;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public boolean isValidDivision(String divisionNumber) throws MeupException {
		return divisionDAO.isValidDivision(divisionNumber);
	}
}
