package com.safeway.app.meup.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.safeway.app.meup.dto.CommentDTO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.dto.StockingSectionDTO;
import com.safeway.app.meup.dto.UserDTO;
import com.safeway.app.meup.vox.CommentVO;
import com.safeway.app.meup.vox.DivisionVO;
import com.safeway.app.meup.vox.HoldItemVO;
import com.safeway.app.meup.vox.SmicCategoryVO;
import com.safeway.app.meup.vox.SmicGroupVO;
import com.safeway.app.meup.vox.StockingSectionVO;
import com.safeway.app.meup.vox.UserVO;

@Service
public class HoldItemMgrHelper {
	

    public StockingSectionDTO convertToSectionDTO(StockingSectionVO stockingSection) {

        StockingSectionDTO stockingSectionDto = new StockingSectionDTO();
        stockingSectionDto.setStockingSectionNumber(stockingSection.getStockingSectionNumber());
        stockingSectionDto.setStockingSectionDesc(stockingSection.getStockingSectionDesc());

        return stockingSectionDto;
    }

    public DivisionDTO convertToDivisionDTO(DivisionVO division){
        DivisionDTO divisionDto = new DivisionDTO();
        divisionDto.setCorp(division.getCorp().trim());
        divisionDto.setDivisionName(division.getDivisionName().trim());
        divisionDto.setDivisionNumber(division.getDivisionNumber().trim());
        return divisionDto;
    }

    public DivisionVO convertToDivisionVO(DivisionDTO division){
        DivisionVO divisionVo = new DivisionVO();
        divisionVo.setCorp(division.getCorp().trim());
        divisionVo.setDivisionName(division.getDivisionName().trim());
        divisionVo.setDivisionNumber(division.getDivisionNumber().trim());
        return divisionVo;
    }

    public StockingSectionVO convertTostockingSectionVO(StockingSectionDTO stockingSection){
        StockingSectionVO stockingSectionVO = new StockingSectionVO();
        stockingSectionVO.setStockingSectionNumber(stockingSection.getStockingSectionNumber().trim());
        stockingSectionVO.setStockingSectionDesc(stockingSection.getStockingSectionDesc().trim());
        return stockingSectionVO;
    }

    public SmicGroupDTO convertToSmicGroupDTO(SmicGroupVO smicGroup){
        SmicGroupDTO smicGroupDTO = new SmicGroupDTO();
        smicGroupDTO.setCorp(smicGroup.getCorp());
        smicGroupDTO.setGroupName(smicGroup.getGroupName());
        smicGroupDTO.setGroupCd(
                smicGroup.getGroupCd());
        return smicGroupDTO;
    }

    /**
     * Method to convert SmicCategoryVOX to SmicCategoryDTO.
     *
     * @param smicCategory - VOX
     * @return SmicCategoryDTO
     */
    public SmicCategoryDTO convertToSmicCategoryDTO(SmicCategoryVO smicCategory) {
        SmicCategoryDTO smicCategoryDto = new SmicCategoryDTO();
        smicCategoryDto.setGroupCd(smicCategory.getGroupCd());
        smicCategoryDto.setCategoryCd(smicCategory.getCategoryCd());
        smicCategoryDto.setcategoryDesc(smicCategory.getCategoryName());
        return smicCategoryDto;
    }

    public UserVO convertToUserVO(UserDTO userDto) {
        UserVO userVo = new UserVO();
        userVo.setUserId(userDto.getUserId());
        userVo.setRole(userDto.getRole());
        userVo.setDivision(userDto.getDivision());
        return userVo;
    }

    public CommentVO convertToCommentVO(CommentDTO commentDto) {
        CommentVO commentVO = new CommentVO();
        commentVO.setCommentDesc(commentDto.getComment());
        return commentVO;
    }
    
 



	/**
	 * 
	 * @param holdItems
	 * @return
	 */
	public List convertToDTO(List holdItems) {
		List holdItemDTOList = new ArrayList();
		Iterator holdItemsItr = holdItems.iterator();
		while (holdItemsItr.hasNext()) {
			HoldItemVO item = (HoldItemVO) holdItemsItr.next();
			HoldItemDTO holdItemDTO = new HoldItemDTO();
			holdItemDTO.setCic(item.getCic());
			holdItemDTO.setCorp(Integer.parseInt(item.getCorp()));
			holdItemDTO.setDesc(item.getDesc());
			holdItemDTO.setDivisionNbr(item.getDivisionNbr());
			holdItemDTO.setStockSectionNbr(item.getStockSectionNbr());
			holdItemDTO.setSchematicEffectiveDate(item
					.getSchematicEffectiveDate());
			holdItemDTO.setStoreID(item.getStoreID());
			holdItemDTO.setUpcID(item.getUpcID());
			holdItemDTO.setStatus("H");

			holdItemDTOList.add(holdItemDTO);
		}
		return holdItemDTOList;
	}

}


