package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * The primary key class for the MEUPSTGF database table.
 *
 */
@Embeddable
public class StagingStoreItemVOID implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "CORP")
    private String corp;
    @Column(name = "DIV")
    private String div;
    @Column(name = "UPLOAD_USER_ID")
    private String userId;
    @Column(name = "UPLOAD_TS")
    private Timestamp itemUploadTs;
    @Column(name = "FAC")
    private String fac;

    public String getCorp() {
        return corp;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getItemUploadTs() {
        return itemUploadTs;
    }

    public void setItemUploadTs(Timestamp itemUploadTs) {
        this.itemUploadTs = itemUploadTs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StagingStoreItemVOID itemVOID = (StagingStoreItemVOID) o;

        if (!corp.equals(itemVOID.corp)) return false;
        if (!div.equals(itemVOID.div)) return false;
        if (!userId.equals(itemVOID.userId)) return false;
        if (!itemUploadTs.equals(itemVOID.itemUploadTs)) return false;
        return fac.equals(itemVOID.fac);
    }

    @Override
    public int hashCode() {
        int result = corp.hashCode();
        result = 31 * result + div.hashCode();
        result = 31 * result + userId.hashCode();
        result = 31 * result + itemUploadTs.hashCode();
        result = 31 * result + fac.hashCode();
        return result;
    }

    public String getFac() {
        return fac;
    }

    public void setFac(String fac) {
        this.fac = fac;
    }


}
