package com.safeway.app.meup.vox;

public class StockingSectionVO {

    private String stockingSectionDesc;

    private String stockingSectionNumber;

    /**
     * @return the stockingSectionDesc
     */
    public String getStockingSectionDesc() {
        return stockingSectionDesc;
    }

    /**
     * @param stockingSectionDesc the stockingSectionDesc to set
     */
    public void setStockingSectionDesc(String stockingSectionDesc) {
        this.stockingSectionDesc = stockingSectionDesc;
    }

    /**
     * @return the stockingSectionNumber
     */
    public String getStockingSectionNumber() {
        return stockingSectionNumber;
    }

    /**
     * @param stockingSectionNumber the stockingSectionNumber to set
     */
    public void setStockingSectionNumber(String stockingSectionNumber) {
        this.stockingSectionNumber = stockingSectionNumber;
    }
}
