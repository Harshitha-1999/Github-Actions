package com.safeway.app.meup.vox;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "MEUPSTGH")
public class StagingHdrVO implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private StagingHdrID stagingHdrID;

    @Temporal(TemporalType.DATE)
    @Column(name = "BLOCKED_TARGET_DT")
    private Date deleteDt;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "corp", referencedColumnName = "CORP", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "div", referencedColumnName = "DIV", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "userId", referencedColumnName = "UPLOAD_USER_ID", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "stageItemUploadTs", referencedColumnName = "UPLOAD_TS", nullable = false, insertable = false, updatable = false)
    private List<StagingItemVO> stagingItemList;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "corp", referencedColumnName = "CORP", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "div", referencedColumnName = "DIV", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "userId", referencedColumnName = "UPLOAD_USER_ID", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "itemUploadTs", referencedColumnName = "UPLOAD_TS", nullable = false, insertable = false, updatable = false)
    private List<StagingStoreItemVO> stagingStoreList;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "corp", referencedColumnName = "CORP", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "div", referencedColumnName = "DIV", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "userId", referencedColumnName = "UPLOAD_USER_ID", nullable = false, insertable = false, updatable = false)
    @JoinColumn(name = "errorUploadTimestamp", referencedColumnName = "UPLOAD_TS", nullable = false, insertable = false, updatable = false)
    private List<StagingErrorVO> stagingErrorList;

    public StagingHdrID getStagingHdrID() {
        return stagingHdrID;
    }

    public void setStagingHdrID(StagingHdrID stagingHdrID) {
        this.stagingHdrID = stagingHdrID;
    }

    public Date getDeleteDt() {
        return deleteDt;
    }

    public void setDeleteDt(Date deleteDt) {
        this.deleteDt = deleteDt;
    }

    public List<StagingItemVO> getStagingItemList() {
        return stagingItemList;
    }

    public void setStagingItemList(List<StagingItemVO> stagingItemList) {
        this.stagingItemList = stagingItemList;
    }

    public List<StagingStoreItemVO> getStagingStoreList() {
        return stagingStoreList;
    }

    public void setStagingStoreList(List<StagingStoreItemVO> stagingStoreList) {
        this.stagingStoreList = stagingStoreList;
    }

    public List<StagingErrorVO> getStagingErrorList() {
        return stagingErrorList;
    }

    public void setStagingErrorList(List<StagingErrorVO> stagingErrorList) {
        this.stagingErrorList = stagingErrorList;
    }
}
