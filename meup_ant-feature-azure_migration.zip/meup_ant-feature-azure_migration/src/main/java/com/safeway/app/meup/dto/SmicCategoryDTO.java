
package com.safeway.app.meup.dto;



public class SmicCategoryDTO {
	
	/**holds the category code.*/
	private String categoryCd;
	
	/**holds the category name.*/
	//TODO
	private String categoryDesc;
	
	/**holds the group code.*/
	private String groupCd;

	/**
	 * @return Returns the dispCategory.
	 */
	public String getDispCategory() {
		return categoryCd+"-"+categoryDesc;
	}
	
	/**
	 * @return Returns the categoryCd.
	 */
	public String getCategoryCd() {
		return categoryCd;
	}
	
	/**
	 * @param categoryCd The categoryCd to set.
	 */
	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}
	
	/**
	 * @return Returns the categoryDesc.
	 */
	public String getcategoryDesc() {
		return categoryDesc;
	}
	
	/**
	 * @param categoryDesc The categoryDesc to set.
	 */
	public void setcategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}
	
	/**
	 * @return Returns the groupCd.
	 */
	public Object getGroupCd() {
		return groupCd;
	}
	
	/**
	 * @param groupCd The groupCd to set.
	 */
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
}
