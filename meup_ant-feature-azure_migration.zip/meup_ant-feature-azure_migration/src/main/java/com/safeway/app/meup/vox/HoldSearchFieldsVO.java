package com.safeway.app.meup.vox;

import java.util.List;

import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.StockingSectionDTO;

public class HoldSearchFieldsVO {

    private List<DivisionDTO> divisionList;

    private List<StockingSectionDTO> stockingSectionList;

    private String groupCode;

    public List<DivisionDTO> getDivisionList() {
        return divisionList;
    }

    public void setDivisionList(List<DivisionDTO> divisionList) {
        this.divisionList = divisionList;
    }

    public List<StockingSectionDTO> getStockingSectionList() {
        return stockingSectionList;
    }

    public void setStockingSectionList(List<StockingSectionDTO> stockingSectionList) {
    	this.stockingSectionList = stockingSectionList;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }
}
