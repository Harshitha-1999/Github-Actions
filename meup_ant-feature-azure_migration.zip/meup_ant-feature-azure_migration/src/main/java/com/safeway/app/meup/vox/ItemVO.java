package com.safeway.app.meup.vox;

import lombok.Data;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Immutable
@Table(name = "SSITMWDS")
@Polymorphism(type = PolymorphismType.IMPLICIT)
public class ItemVO {

    @EmbeddedId
    ItemVOID itemVOID;

    /*** dstCenter value.*/
    @Column(name = "DST_CNTR")
    private String dstCenter;

    /*** statusDst value.*/
    @Column(name = "STATUS_DST")
    private String statusDst;
}
