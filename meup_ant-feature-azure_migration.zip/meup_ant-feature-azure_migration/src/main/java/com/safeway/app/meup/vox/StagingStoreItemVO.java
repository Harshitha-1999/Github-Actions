package com.safeway.app.meup.vox;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "MEUPSTGF")
public class StagingStoreItemVO {
    @EmbeddedId
    private StagingStoreItemVOID stagingStoreItemVOID;

    public StagingStoreItemVOID getStagingStoreItemVOID() {
        return stagingStoreItemVOID;
    }

    public void setStagingStoreItemVOID(StagingStoreItemVOID stagingStoreItemVOID) {
        this.stagingStoreItemVOID = stagingStoreItemVOID;
    }
}
