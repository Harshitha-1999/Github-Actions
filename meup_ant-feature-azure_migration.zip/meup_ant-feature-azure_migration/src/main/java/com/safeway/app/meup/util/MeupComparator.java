
package com.safeway.app.meup.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;

//APACHE
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//MEUP
import com.safeway.app.meup.exceptions.LogErrorMessage;



public class MeupComparator implements Comparator {

    /**declaring the logging framework.*/
    private static final Log log = LogFactory.getLog(MeupComparator.class);
    
    /**String to store the sortfield.*/
    private String sortField;
    
    /**to store ascending value.*/
    private boolean isAscending;

    /**
     * @param sortField String
     * @param isAscending boolean 
     */
    public MeupComparator(String sortField, boolean isAscending) {
        this.sortField = sortField;
        this.isAscending = isAscending;
    }

    /**
     * Overriding the compare method.
     *
     * @param o1 Object1
     * @param o2 Object2
     * @return int
     */
    public int compare(Object o1, Object o2) {
        Class className = o1.getClass();
        Object value1 = null;
        Object value2 = null;
        Method method = null;
        int returnValue = -1;

        try {
            method = className
                .getMethod("get" + this.sortField, new Class[] {});

        } catch (NoSuchMethodException nm) {
            try {
            	method = className.getMethod("is" + this.sortField,
                    new Class[] {});
            } catch (NoSuchMethodException e) {
                log.error(LogErrorMessage.NO_SUCH_METHOD_MSG +
                    "UnallocatedItemDtoComparator", nm);
            }
        }

        try {
        	
        	/** invoke the method using reflection */
            value1 = method.invoke(o1, new Object[] {});
            value2 = method.invoke(o2, new Object[] {});

        } catch (IllegalArgumentException ie) {
            log.error(LogErrorMessage.ILLEGAL_ARGUMENT_MSG + 
            		"UnallocatedItemDtoComparator", ie);
        } catch (IllegalAccessException ia) {
            log.error(LogErrorMessage.ILLEGAL_ACCESS_MSG +
                "UnallocatedItemDtoComparator", ia);
        } catch (InvocationTargetException it) {
            log.error(LogErrorMessage.INVOCATION_TARGET_MSG +
               "UnallocatedItemDtoComparator", it);
        }

        if (value1 != null && value2 != null) {

        	/** since java.lang.Boolean does not implement Comparable interface */
            if (value1.getClass().getName().equalsIgnoreCase(
                "java.lang.Boolean")) {
            	
            	/** if values are boolean */
                Boolean boolValue1 = (Boolean)value1;
                Boolean boolValue2 = (Boolean)value2;
                returnValue = compareBoolean(boolValue1, boolValue2,
                    isAscending);
            }

            /** for all other objects which implement Comparable interface */
            if (value1 instanceof Comparable) {
                Comparable cmp = (Comparable)value1;
                returnValue = cmp.compareTo(value2);
                if (!this.isAscending) {
                	
                	/** descending sort */
                    returnValue = ((Comparable)value2).compareTo(value1);
                }
            }
        }
        return returnValue;
    }

    /**
     * To compare Boolean values since Comparable interface is not implemented
     * in the Boolean class.
     *
     * @param value1 Boolean
     * @param value2 Boolean
     * @param ascending boolean
     * @return returnValue int
     */
    private int compareBoolean(Boolean value1, Boolean value2, 
    		boolean ascending) {
    	
    	/**  returns 0 by default */
        int returnValue = 0;
        if (ascending) {
        	
        	/**  ascending */
            if (value1.booleanValue() != value2.booleanValue() &&
            		!value1.booleanValue()) {
                returnValue = 1;
            }else{
                returnValue=-1;
            }
        } else {
        	
        	/** descending */
            if (value1.booleanValue() != value2.booleanValue() && 
            		value1.booleanValue()) {
                returnValue = 1;
            }else{
                returnValue=-1;
            }
        }
        return returnValue; 
    }
}
