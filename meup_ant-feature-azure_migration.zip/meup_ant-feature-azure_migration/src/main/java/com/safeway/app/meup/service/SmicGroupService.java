package com.safeway.app.meup.service;

import java.sql.SQLException;
import java.util.List;

import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.exceptions.MeupException;



public interface SmicGroupService {
	List<SmicGroupDTO> getSmicGroupsForDivision(List<String> divisionStringList, String corp);

	List<SmicCategoryDTO> getSmicCategoriesForGroups( List<Integer> groupStringList, String corp);

	List<SmicGroupDTO> getGroupsByStatus(String corp) throws SQLException, MeupException;

}
