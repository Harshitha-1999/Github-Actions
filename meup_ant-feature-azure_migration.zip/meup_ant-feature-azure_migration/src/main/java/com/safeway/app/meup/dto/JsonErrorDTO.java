package com.safeway.app.meup.dto;

import java.io.Serializable;

public class JsonErrorDTO  implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code;
    private String message;
    private String fieldName;

    public JsonErrorDTO() {
    }
    public JsonErrorDTO(String message, String fieldName) {
        this.message = message;
        this.fieldName = fieldName;
    }

    public JsonErrorDTO(String code, String message, String fieldName) {
        this.code = code;
        this.message = message;
        this.fieldName = fieldName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }
}
