package com.safeway.app.meup.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class SnowFlakeDatasourceConfiguration {
	Logger logger = LoggerFactory.getLogger(SnowFlakeDatasourceConfiguration.class);

	@Value("${spring.datasource-snowflake.driver-class-name}")
	private String driverClassName;

	@Value("${spring.datasource-snowflake.jdbcUrl}")
	private String jdbcUrl;

	@Value("${spring.datasource-snowflake.username}")
	private String username;

	@Value("${spring.datasource-snowflake.password}")
	private String password;

	@Value("${spring.datasource-snowflake.warehouse}")
	private String warehouse;

	@Value("${spring.datasource-snowflake.db}")
	private String dbName;

	@Value("${spring.datasource-snowflake.schema}")
	private String schema;

	@Bean(name = "snowFlakDatasource")
	JdbcTemplate jdbcTemplateSnowFlake() {
		logger.info("-----Configuring snowFlake Data Source------");
		String url = jdbcUrl + "?warehouse=" + warehouse + "&db=" + dbName + "&schema=" + schema;
		HikariConfig config = new HikariConfig();
		config.setDriverClassName(driverClassName);
		config.setJdbcUrl(url);
		config.setUsername(username);
		config.setPassword(password);
		config.setMaximumPoolSize(40);
		HikariDataSource ds = new HikariDataSource(config);

		return new JdbcTemplate(ds);
	}
	
//	@Bean(name = "snowFlakeNamedParameterDatasource")
//	NamedParameterJdbcTemplate jdbcTemplateSnowFlake1() {
//		logger.info("-----Configuring snowFlake Data Source------");
//		String url = jdbcUrl + "?warehouse=" + warehouse + "&db=" + dbName + "&schema=" + schema;
//		HikariConfig config = new HikariConfig();
//		config.setDriverClassName(driverClassName);
//		config.setJdbcUrl(url);
//		config.setUsername(username);
//		config.setPassword(password);
//		HikariDataSource ds = new HikariDataSource(config);
//
//		return new NamedParameterJdbcTemplate(ds);
//	}
}
