
package com.safeway.app.meup.util;



import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.safeway.app.meup.dto.ColumnDTO;
import com.safeway.app.meup.dto.ReportDTO;
import com.safeway.app.meup.dto.RowDTO;
import com.safeway.app.meup.dto.StoreItemExcelViewerDTO;
import com.safeway.app.meup.exceptions.LogErrorMessage;


public class ReportGenerator {
	private static final Logger log = LoggerFactory.getLogger(ReportGenerator.class);
	/**Holds the total number of columns*/
	private int totalColumns;

	/**Holds the object of class*/
	private Class objectClass;

	/**Holds the report name*/
	private String reportName;

	/**Holds the list of method names for the columns*/
	private List methodNamesForColumns = new ArrayList();

	/**
	 * Constructor overridden for setting the getter for each column.
	 *
	 * @param objClass
	 */
	public ReportGenerator(Class objClass){
		this.objectClass = objClass;
		reportName=ReportGeneratorConstant.name;
		totalColumns = ReportGeneratorConstant.columns;
		for(int index=0;index<totalColumns;index++){
			this.methodNamesForColumns.add(ReportGeneratorConstant.returnColumnMethodName(index));

		}
	}


	/**
	 * gets the value for the methodName of the object object.
	 *
	 * @param object
	 * @param methodName
	 * @return - value as an Object
	 */
	private String getValue(Object object, String methodName) {
		String value = "";
		try {
			Method method = objectClass.getMethod(methodName, null);
			if(method != null) {
				value = method.invoke(object, new String[]{}).toString();
			} else {
				log.info(methodName + " is not defined for " + objectClass);
			}
		} catch (Throwable e) {
			log.error(LogErrorMessage.FAIL_LOAD_EXCEL +" " + e.getMessage(), e);
			log.info("Failed to invoke the method "+ methodName);
		}
		return value;
	}

	/**
	 * generates the report object for the input list.
	 *
	 * @param  - list of objects
	 * @return - ReportDTO - instacne of com.safeway.app.pphi.dto.ReportDTO
	 */
	public ReportDTO createReport(List<StoreItemExcelViewerDTO> createReportList){

		/*create report*/
		ReportDTO report = new ReportDTO();
		List rows = new ArrayList();
		List columnHeaders = new ArrayList();

		/*create the row of column headers*/
		for(int index=0;index<totalColumns;index++){
			ColumnDTO column = new ColumnDTO();
			column.setValue(ReportGeneratorConstant.returnColumnHeaderName(index));
			column.setWidth(ReportGeneratorConstant.returnColumnWidth(index));
			columnHeaders.add(column);
			column = null;
		}
		report.setColumnHeaders(columnHeaders);

        /*create rows according to the no of items in the list
        attributes of each object in the list corresponds to columns in a row*/
		for(int count=0;count<createReportList.size();count++){
			Object reportObject = createReportList.get(count);
			RowDTO row = createRow(reportObject);
			reportObject=null;
			rows.add(row);
		}

		report.setRows(rows);
		report.setReportName(reportName);
		return report;
	}

	/**
	 * Creates a column in a row of the report with the given object
	 * modify this method to set the various formatting parameters
	 * on the report.
	 *
	 * @param methodName name of the method
	 * @param object Object
	 * @param index integer
	 * @return column - the created column
	 */
	private ColumnDTO createColumn(int index,Object object, String methodName){
		ColumnDTO column = new ColumnDTO();
		column.setColumnIndex(index);
		column.setColumnName(ReportGeneratorConstant.returnColumnHeaderName(index));
		column.setResizable((ReportGeneratorConstant.returnColumnResizable(index)));
		column.setVisible(ReportGeneratorConstant.returnColumnVisible(index));
		column.setWidth(ReportGeneratorConstant.returnColumnWidth(index));
		column.setAlignment(ReportGeneratorConstant.returnColumnAlign(index));
		column.setType(ReportGeneratorConstant.returnColumnType(index));
		column.setValue(getValue(object,methodName));
		return column;
	}

	/**
	 * creates a row with the specified columns.
	 *
	 * @param object - Object
	 * @return - RowDTO - instance of com.sample.excel.model
	 */
	private RowDTO createRow(Object object){
		RowDTO row = new RowDTO();
		List columns = new ArrayList();
		for(int index=0;index<this.methodNamesForColumns.size();index++){
			String methodName = this.methodNamesForColumns.get(index).toString();
			ColumnDTO column = createColumn(index,object,methodName);
			columns.add(column);
		}
		row.setColumns(columns);
		columns = null;
		return row;
	}
}
