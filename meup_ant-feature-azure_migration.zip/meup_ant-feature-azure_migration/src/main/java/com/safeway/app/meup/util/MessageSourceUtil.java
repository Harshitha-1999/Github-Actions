package com.safeway.app.meup.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
public class MessageSourceUtil {

    @Autowired
    private MessageSource messageSource;

    public static MessageSource messageSourceUtil;

    public MessageSourceUtil(){
        setMessageSourceUtil();
    }
    public void setMessageSourceUtil(){
        messageSourceUtil=messageSource;
    }

    public static MessageSource getMessageSourceUtil(){
        return messageSourceUtil;
    }

    public static String getMessage(String messageKey) {
        String messageValue = messageSourceUtil.getMessage(messageKey, null, Locale.ENGLISH);
        return messageValue;
    }

    public static String getMessageWithParams(String messageKey, Object[] object) {
        String messageValue = messageSourceUtil.getMessage(messageKey, object, Locale.ENGLISH);
        return messageValue;
    }

    public static Integer getIntegerMessage(String messageKey) {
        String messageValue = messageSourceUtil.getMessage(messageKey, null, Locale.ENGLISH);
        return Integer.valueOf(messageValue);
    }
}
