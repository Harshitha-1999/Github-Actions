package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "MEUPSTGE")
public class StagingErrorVO {
    @EmbeddedId
    private StagingErrorVOID stagingErrorVOID;

    @Column(name = "ERR_DSC")
    private String errDesc;

    public StagingErrorVOID getStagingErrorVOID() {
        return stagingErrorVOID;
    }

    public void setStagingErrorVOID(StagingErrorVOID stagingErrorVOID) {
        this.stagingErrorVOID = stagingErrorVOID;
    }

    public String getErrDesc() {
        return errDesc;
    }

    public void setErrDesc(String errDesc) {
        this.errDesc = errDesc;
    }
}
