
package com.safeway.app.meup.dto;


import java.util.List;


public class ReportDTO {

	/**Holds the list of column headers*/
    private List columnHeaders;
    
    /**Holds the list of rows*/
    private List rows;
    
    /**Holds the maximum width of report*/
    private int maximumWidth;
    
    /**Holds the report name*/
    private String reportName;

    /**
     * @return Returns the rows.
     */
    public List getRows() {
        return rows;
    }
    
    /**
     * @param rows The rows to set.
     */
    public void setRows(List rows) {
        this.rows = rows;
    }

    /**
     * @return Returns the maximumWidth.
     */
    public int getMaximumWidth() {
        return maximumWidth;
    }
    
    /**
     * @param maximumWidth The maximumWidth to set.
     */
    public void setMaximumWidth(int maximumWidth) {
        this.maximumWidth = maximumWidth;
    }

    /**
     * Combine the id columns and custom view columns
     * @return - List
     */
    public List getColumnHeaders(){
        return this.columnHeaders;
    }
    
    /**
     * @param columnHeaders The columnHeaders to set.
     */
    public void setColumnHeaders(List columnHeaders) {
        this.columnHeaders = columnHeaders;
    }
    
	/**
	 * @return Returns the reportName.
	 */
	public String getReportName() {
		return reportName;
	}
	
	/**
	 * @param reportName The reportName to set.
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
}


