
package com.safeway.app.meup.dto;

import java.util.List;

public class BusinessResult extends SerializableDTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**to store the expected result.*/
	private Object expectedResult;
	
	/**to store the list of error messages.*/
	private List errorMessages;
	
	/**to store a list of info messages.*/
	private List infoMessages;
	
	/**to store if a failure has occured.*/
	private boolean failureOccured;

	/**
	 * default constructor.
	 *
	 */
	public BusinessResult() {}

    /**
     * @return
     */
	public List getAllMessages() {
        return null;
    }

	/**
	 * @return Returns the errorMessages.
	 */
	public List getErrorMessages() {
		return errorMessages;
	}

	/**
	 * @param errorMessages The errorMessages to set.
	 */
	public void setErrorMessages(List errorMessages) {
		this.errorMessages = errorMessages;
	}

	/**
	 * @return Returns the expectedResult.
	 */
	public Object getExpectedResult() {
		return expectedResult;
	}

	/**
	 * @param expectedResult The expectedResult to set.
	 */
	public void setExpectedResult(Object expectedResult) {
		this.expectedResult = expectedResult;
	}

	/**
	 * @return Returns the infoMessages.
	 */
	public List getInfoMessages() {
		return infoMessages;
	}

	/**
	 * @param infoMessages The infoMessages to set.
	 */
	public void setInfoMessages(List infoMessages) {
		this.infoMessages = infoMessages;
	}

	/**
	 * @return Returns the isFailureOccured.
	 */
	public boolean isFailureOccured() {
		return failureOccured;
	}

	/**
	 * @param failureOccured The isFailureOccured to set.
	 */
	public void setFailureOccured(boolean failureOccured) {
		this.failureOccured = failureOccured;
	}

}
