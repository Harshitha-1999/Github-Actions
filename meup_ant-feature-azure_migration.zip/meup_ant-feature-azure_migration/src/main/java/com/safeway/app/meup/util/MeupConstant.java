
package com.safeway.app.meup.util;





import java.math.BigDecimal;

public class MeupConstant {

    public static final int SPL_ITEMS_CMT_1 =99;
    public static final int SPL_ITEMS_CMT_2 =88;
    public static final int SPL_ITEMS_CMT_3 =77;
    public static final int SPL_ITEMS_CMT_4 =66;
    public static final int SPL_ITEMS_CMT_5 =55;
    public static final int SPL_ITEMS_CMT_6 =44;
    public static final int SPL_ITEMS_CMT_7 =33;
    public static final int SPL_ITEMS_CMT_8 =22;
    public static final int SPL_ITEMS_CMT_9 =11;
    public static final int SPL_ITEMS_CMT_10 =00;

    public static final int LIST_SIZE =10;
    /** declaring the resource manager framework. */
    /*private static final TypecastResourceManager rMgr = new TypecastResourceManager(
            MeupConstant.class);*/

    /** declaring the field size of cic. */
    public static final int CIC_FIELD_DATA_SIZE =8;
            //("cic.field.data.size");

    /** declaring the field size of upc. */
    /*public static final int UPC_FIELD_DATA_SIZE = rMgr
            .getInt("upc.field.data.size");*/
    public static final int UPC_FIELD_DATA_SIZE =12;

    /** declaring the minimum field size of cic. */
    /*public static final int CIC_FIELD_MIN_DATA_SIZE = rMgr
            .getInt("cic.field.min.data.size");*/
    public static final int CIC_FIELD_MIN_DATA_SIZE =7;

    /** declaring the minimum field size of upc. */
    /*public static final int UPC_FIELD_MIN_DATA_SIZE = rMgr
            .getInt("upc.field.min.data.size");*/
    public static final int UPC_FIELD_MIN_DATA_SIZE = 10;

    /** declaring date format. */
    public static final String DATE_FORMAT ="MM/dd/yyyy";
            //("date.format");

    /** declaring low date format. */
    public static final String LOW_DATE ="01/01/0001";
            //rMgr.get("low.date");

    /**declaring the unallocated state character.*/
    public static final String STATE_UNALLOCATED ="U";
            //rMgr.getString("state.unallocated");

    /**declaring the allocated state character.*/
    public static final String STATE_ALLOCATED = "A";


    /** declaring the admin role. */
    //public static final String ADMIN_ROLE = rMgr.get("admin.role");
    public static final String ADMIN_ROLE ="ADMIN";
    public static final String HOLD_ROLE ="HOLD";
            //rMgr.get("hold.role");

    public static final String DIV_ROLE ="DIV";
            //rMgr.get("div.role");


    /** declaring the admin role. */
    public static final String MEUP_HOLD_ROLE ="MEUPHold";
            //rMgr.get("meup.hold.role");

    /** declaring the Meup admin role. */
    public static final String MEUP_ADMIN_ROLE ="MEUPAdmin";
            //rMgr.get(" meup.admin.role");

    /** declaring the non admin role. */
    public static final String NONADMIN_ROLE ="NON-ADMIN";
            //rMgr.get("nonadmin.role");

    /** declaring the divisional role. */
    public static final String MEUP_DIV_ROLE = "meup.divisionmgr";
            //rMgr.get("meup.divisionmgr");


    /** declaring the required objects in session. */
    public static final String REQ_OBJ_IN_SESSION ="StoreItemBean|SearchBean|ReportBean|UploadItemBean|UpdateBean";
            //rMgr
            //.get("objects.req.session");

    /** declaring the meup user role. */
    public static final String MEUP_USER_ROLE ="MEUPUsers";
            //rMgr.get("meup.user.role");

	/* MEUP LDAP groups added for migration purpose
	 userId:vnell00
	Date:07/14/2014 */


    /** declaring the admin group. */
    public static final String MEUP_HOLD_GROUP ="meup.schematicmgr";
            //rMgr.get("meup.hold.group");

    /** declaring the Meup admin group. */
    public static final String MEUP_ADMIN_GROUP ="meup.admin";
            //rMgr.get("meup.admin.group");

    /** declaring the meup user group. */
    public static final String MEUP_USER_GROUP = "meup.all";
        //rMgr.get("meup.user.group");

    /** declaring the meup user group. */
    public static final String MEUP_DIV_GROUP = "meup.divisionmgr";
            //rMgr.get("meup.div.group");


    /** declaring the number of rows. */
    public static final int NO_OF_ROWS = 4;
            //rMgr.getInt("no.of.rows");

    /** declaring the unallocated state. */
    public static final String UNALLOCATED_STATE ="Unallocated";
            //rMgr
            //.get("unallocated.state");

    /** declaring the allocated state. */
    public static final String ALLOCATED_STATE ="Allocated";
            //rMgr.get("allocated.state");

    /** declaring the country: US. */
    public static final String COUNTRY_US ="US";
            //rMgr.get("country.us");

    /** declaring the country: Canada. */
    public static final String COUNTRY_CANADA ="Canada";
            //rMgr.get("country.canada");

    /** declaring the code: US. */
    public static final String US_CODE = "001";

    //temp comment
    /** declaring the code: TD. *//*
    public static final String TD_CODE = rMgr.get("td.code");*/

    /** declaring the code: Canada. */
    public static final String CANADA_CODE = "002";

    /** To get comma */
    //public static final String COMMA = rMgr.get("comma");
    public static final String COMMA = ",";

    /** to get single quote */
    //public static final String SINGLE_QUOTE = rMgr.get("singlequote");
    public static final String SINGLE_QUOTE = "'";

    /** to get smic group category length */
    public static final String SMIC_GROUP_CATEGORY_LENGTH = "0";

    /** Schematic data. */
    /*public static final String SCHEMATIC_USERID = rMgr.get("Schematic.userId");*/
    public static final String SCHEMATIC_USERID = "SCHMATIC";


    /** Schematic value */
    /*public static final String SCHEMATIC_VALUE = rMgr.get("schematic.value");*/
    public static final String SCHEMATIC_VALUE = "SCHEMATIC";


    /** mend items. */
    public static final String MEND_USERID ="MEND";
            //rMgr.get("Mend.userId");

    /** to get unblocked status key */
    public static String UNBLOCKED_STATUS_KEY = "U";
            //rMgr
            //.getString("unBlocked.status.key");

    /** to get unblocked status key */
    public static String BLOCKED_STATUS_KEY = "B";
            //rMgr
            //.getString("blocked.status.key");


    /** declaring sql date format . */
    //public static final String SQL_DATE_FORMAT = rMgr.get("sql.date.format");
    public static final String SQL_DATE_FORMAT = "yyyy-MM-dd";

    /** Speciatliy item */
    public static String SPECIALITY_ITEM ="Specialty Item";
            //rMgr.getString("speciality.item");

    /** DSD item */
    public static String DSD_ITEM ="DSD";
            //rMgr.getString("dsd.item");

    /** warehouse item */
    public static String WAREHOUSE_ITEM = "Warehouse";
            //rMgr.getString("warehouse.item");

    /** CPS item */
    public static String CPS_ITEM = "CPS item";
            //rMgr.getString("cps.item");

    /** DSD ITEM SPECIFICATION */
    public static String DSD_SPECIFICATION = "D";
            //rMgr.getString("dsd.specification");

    /** WAREHOUSE ITEM SPECIFICATION */
    public static String WAREHOUSE_SPECIFICATION ="W";
            //rMgr.getString("warehouse.specification");

    /** CPS item */
    public static String CPS_ITEM_TYPE_1 ="WCPS";
            //rMgr.getString("cps.item.type.1");

    /** CPS item */
    public static String CPS_ITEM_TYPE_2 = "WCPE";
            //rMgr.getString("cps.item.type.2");

    /** hyphen */
    public static String HYPHEN = "-";
            //rMgr.getString("hyphen");

    /** corp position */
    public static int CORP_POSITION =0;
            //rMgr.getInt("corp.position");

    /** division position */
    public static int DIVISION_POSITION = 1;
            //rMgr.getInt("division.position");

    /** fac position */
    public static int FAC_POSITION = 2;
            //rMgr.getInt("fac.position");

    /** cic position */
    public static int CIC_POSITION =3;
            //rMgr.getInt("cic.position");

    //* Return code for a valid file.
    public static final int FILE_VALID = 0;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.FormatValid"));*/

    /**
     * Variable to hold the comma Missing error code read from the properties
     * file.
     */
    public static final int COMMA_MISSING = 99;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.commaMissing"));*/

    /**comma value to represent comma (,).*/
    public static final String COMMAVALUE =",";
            //rMgr.get("commaValue");

    /**
     * Variable to hold the negative number/non number entry error code read
     * from the properties file.
     */
    public static final int NON_NUMBER_OR_NEGATIVE = 98;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.nonNumericorNegative"));*/

    /**
     * Variable array to hold the character comma read from the Properties file.
     */
    public static char[] characterComma = ",".toCharArray();;
            /*rMgr.get(
            "uploadCSVFile.character.comma")*/


    /**
     * Variable to hold the character comma read .
     */
    public static char comma = characterComma[0];

    /**
     * Variable to hold the character fileSeparator read from the properties
     * file.
     */
    public static String fileSeparator = "\\";
            /*rMgr
            .get("uploadCSVFile.character.fileSeparator");*/

    /**
     * Variable to hold the type of items file read from the properties file.
     * Used to validate the type of file entered by the user
     */
    public static final String TYPE = ".csv";
            /*rMgr.get("uploadCSVFile.attribute.type");*/

    /**
     * Return code invalid store id.
     */
    public static final int DIVISION_INVALID = 1;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.RowDivisionNoInvalid"));*/

    /**
     * Variable to hold the header initial format of the items file read from
     * the properties file. Used to validate the header of the file entered by
     * the user
     */
    public static final String INITIAL_FORMAT ="Division";
            /*rMgr
            .get("uploadCSVFile.attribute.initialFormat");*/

    /**variables to hold teh duplicate store id value.*/
    public static final String DUPLICATE_STORE_ID = "Duplicate Stores";
            /*rMgr
            .get("stagingErrorDuplicateStoreID");*/

    /**
     * Variable to hold the header store format of the items file read from the
     * properties file. Used to validate the header of the file entered by the
     * user
     */
    public static final String STOREID_FORMAT ="Store #";
            /*rMgr
            .get("uploadCSVFile.attribute.storeIDFormat");*/

    /**
     * Variable to hold the column format of the items file read from the
     * properties file. Used to validate the header of the file entered by the
     * user
     */
    public static final String COLUMN_FORMAT = "UPC,CIC";
            /*rMgr
            .get("uploadCSVFile.attribute.columnFormat");*/

    /**
     * Return code for invalid item header.
     */
    public static final int ITEM_HEADER_INVALID = 5;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.ItemHeaderInvalid"));*/

    /**
     * Return code for invalid division number.
     */
    public static final int IN_DIVISIONNO_INVALID = 2;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.InDivisionNoInvalid"));*/

    /**
     * Return code for invalid store id.
     */
    public static final int IN_STORE_ID_INVALID =4;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.InStoreIdInvalid"));*/

    /**
     * Return code invalid CIC and UPC
     */
    public static final int NO_CIC_UPC = 97;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.InvalidCICUPC"));*/

    /**
     * Return code error in CIC and UPC
     */
    public static final int CIC_UPC_INVALID = 13;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.ErrorInCICUPC"));*/

    /**
     * Return code invalid store id.
     */
    public static final int STORE_ID_INVALID =3;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.RowStoreIdInvalid"));*/

    /** specifies the value of -1 for index. */
    public static final int INDEXOFSLASH =1;
            /*rMgr
            .getInt("uploadCSVFile.indexOfSlash");*/

    /** for validating file. */
    public static final int INITIAL_INDEX = 0;
            /*rMgr
            .getInt("uploadCSVFile.initialIndex");*/

    /** for validating file,size of content in the file. */
    public static final int CONTENT_SIZE =3;
            /*rMgr
            .getInt("uploadCSVFile.contentSize");*/

    /** for validating file,size of content in the file,whihc will validate
     * whether file contains cic and upc values. */
    public static final int FILE_CONTENT_SIZE = 4;
            /*rMgr
            .getInt("uploadCSVFile.fileContentSize");*/

    /** for validating file,declaring fro index of list. */
    public static final int INDEX_LIST = 1;
            /*rMgr
            .getInt("uploadCSVFile.indexOfList");*/

    /** for validating store id inside the file. */
    public static final int STORE_LENGTH = 4;
            /*rMgr
            .getInt("uploadCSVFile.storeLength");*/

    /** for validating file header inside the file for second row. */
    public static final int INDEX_SECOND_ROW =2;
            /*rMgr
            .getInt("uploadCSVFile.indexSecondRow");*/

    /** for validating division number inside the file. */
    public static final int DIVISION_NUM = 2;
            /*rMgr.getInt("div.field.data.size");*/

    /** for error description if duplication of cic is found. */
    public static final String ERROR_DESCRIPTION = "Duplicate entry - CIC/UPC";
            /*rMgr
            .get("stagingErrorDuplicateCIC");*/

    public static final BigDecimal UPC_VALUES_DUPLICATE_STORE =BigDecimal.ZERO;
           /* Integer.parseInt(rMgr
            .get("UpcValuesForDuplicateStrore"));*/


    /**
     * Default schema for hibernate configuration
     */
    public static final String DB_DEFAULT="DEFAULT";
            /*rMgr.get("db.default");*/

    /**
     *  Canada schema for hibernate configuration
     */
    public static final String DB_CANADA="CANADA";
            /*rMgr.get("db.canada");*/
    /**
     *  Canada schema for hibernate configuration
     */
    public static final String DB_TD ="TERADATA";
            /*rMgr.get("db.teradata");*/

    /**
     * CorpId for US
     */
    public static final String CORP_US="001";
            //rMgr.get("corpId.US");

    /**
     * CorpId for Canada
     */
    public static final String CORP_CANADA="020";
            //rMgr.get("corpId.Canada");

    /**declaring the blocked status.*/
    public static final String BLOCKED_STATE ="Blocked";
            /*rMgr.
            get("blocked.state");*/

    /**declaring the unblocked status.*/
    public static final String UNBLOCKED_STATE="Unblocked";
            /*rMgr.
            get("unblocked.state");*/

    /**declaring the unblocked status.*/
    /*public static final int UPCCOUNTRY_START_LENGTH=rMgr.
            getInt("upccountry.start.length");*/
    public static final int UPCCOUNTRY_START_LENGTH=0;

    /**declaring the unblocked status.*/
    /*public static final int UPCSYSTEM_START_LENGTH=rMgr.
            getInt("upcsystem.start.length");*/
    public static final int UPCSYSTEM_START_LENGTH=1;

    /**declaring the unblocked status.*/
    /*public static final int UPCMANUF_START_LENGTH=rMgr.
            getInt("upcmanuf.start.lenght");*/
    public static final int UPCMANUF_START_LENGTH=2;

    /**declaring the unblocked status.*/
    /*public static final int UPCSALES_START_LENGTH =rMgr.
            getInt("upcsales.start.lenght");*/
    public static final int UPCSALES_START_LENGTH =7;

    /** 	Product Source Ind for DSD Item	*/
    public static String PRODUCT_SOURCE_IND_DSD ="D";
           // rMgr.get("product.source.ind.DSD");

    /**	Product Source Ind for DSD and Warehouse Item	*/
    public static String PRODUCT_SOURCE_IND_DSDWHSE	="B";
            //rMgr.get("product.source.ind.DSDWhse");

    /**	Mend discontinued Item Status 	*/
    public static String DISCONTINUED_STATUS_KEY ="D";
            //rMgr.get("discontinued.status.key");

    /**	Mend discontinution process Status */
    public static String DISCONTINUED_PROCESS_STATUS_KEY="X";
           //rMgr.get("discontinued.status.process.key");

    /**	AND  STRING*/
    public static String AND_STRING= "AND";

    /**	OPENING BRACKET*/
    public static String OPENING_BRACKET=
            "(";//<![CDATA[(]]>

    /**	CLOSING BRACKET*/
    public static String CLOSING_BRACKET=
            ")";//<![CDATA[)]]>

    /**	OR  STRING*/
    public static String OR_STRING=
            "OR";

    /**	OR  length*/
    public static int OR_LENGTH=
            3;

    /**	UPC_MANUF  length*/
    /*public static int UPC_MANUF_LENGTH=
            rMgr.getInt("upc.manuf.length");*/
    public static int UPC_MANUF_LENGTH=
            5;

    /**	UPC_SALES  length*/
    /*public static int UPC_SALES_LENGTH=
            rMgr.getInt("upc.sales.length");*/
    public static int UPC_SALES_LENGTH=
           5;

    /**	Resultset size*/

    public static String RESULTSET_SIZE =
            "4000";

    /**	Maximum Resultset size*/
    /*public static String MAX_RESULTSET_SIZE =
            rMgr.getString("max_resultset.size");*/
    public static String MAX_RESULTSET_SIZE =
            "4001";

    //temp comment
    /**	Error Message for timeout *//*
    public static String ERROR_MESSAGE_FOR_TIMEOUT = rMgr.get("error.message.for.timeout",MeupConstant.RESULTSET_SIZE);*/

    /**	length of category code*/
    /*public static int CTGRY_CD_LENGTH= rMgr.getInt("ctgry.cd.length");*/
    public static int CTGRY_CD_LENGTH= 1;

    /**	length of category code*/
    /*public static int GROUP_CD_LENGTH= rMgr.getInt("group.cd.length");*/
    public static int GROUP_CD_LENGTH= 1;

    /**
     * Return code invalid division number.
     */
    public static final int INVALID_DIVISIONNO = 6;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.InvalidDivisionNumber"));*/

    /**variables to hold the division number format for file.*/
    public static final String DIVISION_FORMAT ="Div";
            /*rMgr
            .get("uploadCSVFile.attribute.DivisionFormat");*/

    /**
     *value to hold splitted file name length.
     */
    public static final int SPLIT_FILE_NAME_LENGTH = 5;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.SplitFileNameLength"));*/

    /**
     *value to hold to check valid division number.
     */
    public static final int CHECK_VALID_DIVISION = 8;
            /*Integer.parseInt(rMgr
            .get("uploadCSVFile.returnCode.CheckValidDivision"));*/

    /**
     * PIPE
     */
    public static final String PIPE ="|";
            //rMgr.get("pipe");

    /**
     * HYPHEN
     */
    public static final String HYPHEN_FOR_TOKENIZER ="-";
            /*rMgr
            .get("hyphen.tokenizer");*/


    public static final String DEADLOCK_TOKEN ="DEADLOCK";
            //rMgr.get("deadlock.error.message");

    public static final String RESOURCE_LIMIT = "RESOURCE LIMIT";
            //rMgr.get("resource.limit");
    public static final int MAX_UPLOAD_LIMIT=1503;
            //Integer.parseInt(rMgr.get("uploadCSVFile.upload.count"));


    public static final String UPLOAD_TIMEOUT = "The selected file size is huge, try uploading smaller files.";
            //rMgr.get("uploadCSVFile.upload.timeout");

    public static final String BLOCK_TIMEOUT = "Please block ...";
            //rMgr.get("block.timeout");
    public static final int INSERT_COMMIT_SIZE = 500;

    public static final int UPLOAD_COUNT_INFO=1500;



    /**
     * Message for Invalid Item.
     */
    public static final String INVALID_ITEM_MSG = "CIC/UPC invalid in store";
            /*rMgr.
            get("item.invalid.message");*/

    /**
     * Message for DSD Item.
     */
    public static final String DSD_ITEM_MSG ="DSD item";
            /*rMgr.
            get("item.DSD.message");*/

    /**
     * Message for DSD and Warehouse Item.
     */
    public static final String DSD_WHSE_ITEM_MSG= "Item blocked from Whse still authorized for DSD";
            /*rMgr.
            get("item.DSDAndWhse.message");*/

    /**
     * Message for Discontinued Item.
     */
    public static final String DISCO_ITEM_MSG = "Discontinued item";
            /*rMgr.
            get("item.disco.message");*/

    /**
     * Message for Blocked Item.
     */
    public static final String ITEM_BLOCKED_MSG="Duplicate item - already blocked";
            /*rMgr.
            get("item.blocked.message");*/

    /**
     * Message for Invalid Store
     */
    public static final String INVALID_STORE_MSG ="Invalid store number";
            /*rMgr.
            get("invalid.store.message");*/

    /**
     * Sql index  for CORP in Staging tables
     */
    public static final int CORP=1;

    /**
     * Sql index  for Division in Staging tables
     */
    public static final int DIV=2;

    /**
     * Sql index  for Upload user id in Staging tables
     */
    public static final int UPLOAD_USER_ID=3;

    /**
     * Sql index  for Upload timestamp in Staging tablesmp
     */
    public static final int UPLOAD_TS=4;

    /**
     * Blocked status of Item in table MEUPITM
     */
    public static final String BLOCKED_STATUS_CODE="B";
            /*rMgr.
            get("blocked.status.code");*/

    /**
     * Blocked status of Item in table MEUPITM
     */
    public static final String UNBLOCKED_STATUS_CODE= "U";
            /*rMgr.
            get("unblocked.status.code");*/

    /**
     * Discontinue Process Code of Item
     */
    public static final String DISCONTINUE_PROCESS_CODE= "X";
            /*rMgr.
            get("discontinue.process.code");*/

    /**
     * Discontinued Item Code
     */
    public static final String DISCONTINUED_CODE="D";
            /*rMgr.
            get("discontinued.code");*/

    /**
     * User id of MEND
     */
    //public static final String MEND_USERID= rMgr.get("mend.userid");

    /**
     * DSD Item code
     */
    public static final String DSD_ITEM_CODE="D";
            /*rMgr.get("dsd.item.code");*/

    /**
     * DSD and Warehouse Item code
     */
    public static final String DSD_WHSE_ITEM_CODE = "B";
            /*rMgr.
            get("dsd.whse.item.code");*/

    /**
     * Duplicate Item Message
     */
    public static final String DUPLICATE_ITEM_MSG="Duplicate entry - CIC/UPC";
            /*rMgr.
            get("duplicate.item.message");*/

    public static final String DUPLICATE_ITEM_IN_STORE_MSG ="Duplicate entry - CIC/store";
            /*rMgr.get("duplicate.item.store.message");*/

}
