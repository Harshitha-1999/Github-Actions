
package com.safeway.app.meup.dto;


import java.util.Date;
import java.util.List;



public class StoreItemSearchDTO {

    private String countryCd;
    private List<DivisionDTO> divisions;
    private List<SmicGroupDTO> groups;
    private List<SmicCategoryDTO> categories;
    private UserDTO userDto;
    private String cic;
    private String upc;
    private String upcManuf;
    private String upcSales;
    private String upcCountry;
    private String upcSystem;
    private String storeNumber;
    private String deleteDateStart;
    private String deleteDateEnd;
    private String state;
    private boolean stateNeeded;
    private boolean dateSelected;
    private String status;
    private String countryName;
    private String schematicMessage;

    public String getCountryCd() {
        return countryCd;
    }

    public void setCountryCd(String countryCd) {
        this.countryCd = countryCd;
    }

    public List<DivisionDTO> getDivisions() {
        return divisions;
    }

    public void setDivisions(List<DivisionDTO> divisions) {
        this.divisions = divisions;
    }

    public List<SmicGroupDTO> getGroups() {
        return groups;
    }

    public void setGroups(List<SmicGroupDTO> groups) {
        this.groups = groups;
    }

    public List<SmicCategoryDTO> getCategories() {
        return categories;
    }

    public void setCategories(List<SmicCategoryDTO> categories) {
        this.categories = categories;
    }

    public String getCic() {
        return cic;
    }

    public void setCic(String cic) {
        this.cic = cic;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public String getUpcManuf() {
        return upcManuf;
    }

    public void setUpcManuf(String upcManuf) {
        this.upcManuf = upcManuf;
    }

    public String getUpcSales() {
        return upcSales;
    }

    public void setUpcSales(String upcSales) {
        this.upcSales = upcSales;
    }

    public String getUpcCountry() {
        return upcCountry;
    }

    public void setUpcCountry(String upcCountry) {
        this.upcCountry = upcCountry;
    }

    public String getUpcSystem() {
        return upcSystem;
    }

    public void setUpcSystem(String upcSystem) {
        this.upcSystem = upcSystem;
    }

    public String getStoreNumber() {
        return storeNumber;
    }

    public void setStoreNumber(String storeNumber) {
        this.storeNumber = storeNumber;
    }

    public String getDeleteDateStart() {
        return deleteDateStart;
    }

    public void setDeleteDateStart(String deleteDateStart) {
        this.deleteDateStart = deleteDateStart;
    }

    public String getDeleteDateEnd() {
        return deleteDateEnd;
    }

    public void setDeleteDateEnd(String deleteDateEnd) {
        this.deleteDateEnd = deleteDateEnd;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public boolean isStateNeeded() {
        return stateNeeded;
    }

    public void setStateNeeded(boolean stateNeeded) {
        this.stateNeeded = stateNeeded;
    }

    public boolean isDateSelected() {
        return dateSelected;
    }

    public void setDateSelected(boolean dateSelected) {
        this.dateSelected = dateSelected;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getSchematicMessage() {
        return schematicMessage;
    }

    public void setSchematicMessage(String schematicMessage) {
        this.schematicMessage = schematicMessage;
    }

    /**
     * @return Returns the userDto.
     */
    public UserDTO getUserDto() {
        return userDto;
    }

    /**
     * @param userDto The userDto to set.
     */
    public void setUserDto(UserDTO userDto) {
        this.userDto = userDto;
    }


}
