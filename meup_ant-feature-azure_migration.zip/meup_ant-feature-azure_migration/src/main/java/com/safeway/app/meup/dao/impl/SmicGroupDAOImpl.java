package com.safeway.app.meup.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.safeway.app.meup.dao.SmicGroupDAO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.exceptions.LogErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.util.MeupConstant;

@Repository
@PropertySource(value = { "classpath:/sql.properties" })
public class SmicGroupDAOImpl implements SmicGroupDAO {

	@Autowired
	@Qualifier("db2DS")
	NamedParameterJdbcTemplate db2NamedJDBCTemplate;

	@Autowired
	@Qualifier("snowFlakDatasource")
	JdbcTemplate snowflakejdbctemplate;

	@Value("${sql.selectSmicGroupsForDivision.default}")
	private String defaultselectSmicGroupsForDivision;

	@Value("${sql.selectSmicCategoriesForGroups.default}")
	private String defaultselectSmicCategoriesForGroups;

	@Value("${sql.getGroupsByStatus}")
	private String getGroupsByStatus;
	private static final Logger log = LoggerFactory.getLogger(SmicGroupDAOImpl.class);

	@Override
	public List<SmicGroupDTO> selectSmicGroupsForDivision(String corp, List<String> divisionNumbers) {
		log.info("|---> Beginning Method SmicGroupDAOImpl." + "selectSmicCategoriesForGroups");
		MapSqlParameterSource map = new MapSqlParameterSource();
		map.addValue("division", divisionNumbers);

		String query = defaultselectSmicGroupsForDivision;

		List<SmicGroupDTO> smicGroupList = new ArrayList<>();
		smicGroupList = db2NamedJDBCTemplate.query(query, map, new RowMapper<SmicGroupDTO>() {
			@Override
			public SmicGroupDTO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
				SmicGroupDTO smicGroup = new SmicGroupDTO();
				String groupCode = resultSet.getString("GROUP_CD");
				if (groupCode.length() == 1) {
					groupCode = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(groupCode);
				}
				smicGroup.setCorp(corp);
				smicGroup.setGroupCd(groupCode);
				smicGroup.setGroupName(resultSet.getString("CLSIFICATION_DESC"));
				return smicGroup;

			}

		});
		log.info("<---| Completed Method SmicGroupDAOImpl " + ". selectSmicGroupsForDivision ");
		return smicGroupList;
	}

	@Override
	public List<SmicCategoryDTO> selectSmicCategoriesForGroups(String corp, List<Integer> groupCode) {
		log.info("|---> Beginning Method SmicGroupDAOImpl." + "selectSmicCategoriesForGroups");
		MapSqlParameterSource map = new MapSqlParameterSource();
		map.addValue("groupCode", groupCode);

		String query = defaultselectSmicCategoriesForGroups;

		List<SmicCategoryDTO> smicCategoryList = new ArrayList<>();

		smicCategoryList = db2NamedJDBCTemplate.query(query, map, new RowMapper<SmicCategoryDTO>() {
			@Override
			public SmicCategoryDTO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
				SmicCategoryDTO smicCategory = new SmicCategoryDTO();
				String categoryCode = resultSet.getString("CTGRY_CD");
				String groupCd = resultSet.getString("GROUP_CD");
				if (groupCd.length() == 1) {
					groupCd = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(groupCd);
				}
				if (categoryCode.length() == 1) {
					categoryCode = MeupConstant.SMIC_GROUP_CATEGORY_LENGTH.concat(categoryCode);
				}
				categoryCode = groupCd + categoryCode;
				smicCategory.setGroupCd(groupCd);
				smicCategory.setCategoryCd(categoryCode);
				smicCategory.setcategoryDesc(resultSet.getString("CLSIFICATION_DESC"));
				return smicCategory;

			}

		});
		log.info("<---| Completed Method SmicGroupDAOImpl " + ". selectSmicCategoriesForGroups ");
		return smicCategoryList;

	}

	@Override
	public List<SmicGroupDTO> getGroupsByStatus(String corp, char itemState, char blockedStatusCode)
			throws MeupException, SQLException {
		log.info("|---> Beginning Method SmicGroupDAOImpl." + "getGroupsByStatus");
		List<SmicGroupDTO> smicGroupList = new ArrayList<>();

		Connection con = snowflakejdbctemplate.getDataSource().getConnection();
		try {
			PreparedStatement stmnt = con.prepareStatement(getGroupsByStatus);

			stmnt.setString(1, corp);
			stmnt.setString(2, Character.toString(itemState));
			stmnt.setString(3, Character.toString(blockedStatusCode));
			ResultSet resultSet = stmnt.executeQuery();
			while (resultSet.next()) {
				SmicGroupDTO smicGroup = new SmicGroupDTO();
				smicGroup.setCorp(corp);
				smicGroup.setGroupCd(resultSet.getString("GROUP_ID"));
				smicGroup.setGroupName(resultSet.getString("GROUP_NM"));
				smicGroupList.add(smicGroup);
			}
			log.info("<---| Completed Method SmicGroupDAOImpl " + ". getGroupsByStatus ");
			stmnt.close();
		}

		catch (SQLException sqlException) {
			throw new MeupException(LogErrorMessage.SMICGROUP_EXCEPTION + ":" + sqlException.getMessage());

		} finally {

			con.close();
		}

		return smicGroupList;

	}
}
