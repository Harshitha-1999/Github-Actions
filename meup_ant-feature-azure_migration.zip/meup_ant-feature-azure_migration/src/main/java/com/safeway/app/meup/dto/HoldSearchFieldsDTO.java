

package com.safeway.app.meup.dto;

import java.util.List;



public class HoldSearchFieldsDTO {
	/**
	 * holds the divisiondto list
	 */
	private List<DivisionDTO> divisionList;

	/**
	 * holds the stockingsectiondto list
	 */
	private List<StockingSectionDTO> stockingSectionList;

	/**
	 * holds the groupcode
	 */
	private String groupCode;
	/**
	 * holds the corp
	 */
	private String corp;
	/**
	 *
	 * @return divisionList
	 */
	public List<DivisionDTO> getDivisionList() {
		return divisionList;
	}

	/**
	 *
	 * @param divisionList
	 */
	public void setDivisionList(List divisionList) {
		this.divisionList = divisionList;
	}

	/**
	 *
	 * @return groupCode
	 */
	public String getGroupCode() {
		return groupCode;
	}

	/**
	 *
	 * @param groupCode
	 */
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	/**
	 *
	 * @return corp
	 */
	public String getCorp() {
		return corp;
	}

	/**
	 *
	 * @param corp
	 */
	public void setCorp(String corp) {
		this.corp = corp;
	}

	/**
	 *
	 * @return stockingSectionList
	 */
	public List<StockingSectionDTO> getStockingSectionList() {
		return stockingSectionList;
	}

	/**
	 *
	 * @param stockingSectionList
	 */
	public void setStockingSectionList(List stockingSectionList) {
		this.stockingSectionList = stockingSectionList;
	}

}
