/* ****************************************************************************
 *
 * Copyright 2008, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */
package com.safeway.app.meup.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.JsonErrorDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.StoreItemBusinessResult;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.exceptions.MeupException;

/* ***************************************************************************
 *
 * NAME : DivisionMgr.java
 *
 * SYSTEM : Unallocated Item Blocking
 *
 * REVISION HISTORY
 *
 * Revision 1.0
 * sankar Madhavan Pillai Jan 17, 2008.
 * Initial version
 *************************************************************************** */

/*****************************************************************************
 * Interface with the methods to laod the divisions.
 *
 * @version 1.0
 * @author Sankar Madhavan Pillai.
 *************************************************************************** */
public interface ValidationService {

    /**
     * Method to check validations on BlockItemsPage
     *
     * @throws MeupException
     *             when error occurs while fetching the divisions
     */

    public List<String> validateFieldsForReportStoreItems(StoreItemSearchDTO storeItemSearchDTO) throws MeupException;

    List<String> validateFieldsForUpdateStoreItems(StoreItemSearchDTO storeItemSearchDTO);

    List<JsonErrorDTO> validateBlockItemCSVFile(MultipartFile itemsFile, ResponseDTO responseDTO, BlockItemRequestDTO requestDTO) throws MeupException;

	public StoreItemBusinessResult validateItemsAndStores(BlockItemRequestDTO blockItemRequestDTO) throws MeupException;
}

