/* ****************************************************************************
 *
 * Copyright 2008, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */

package com.safeway.app.meup.dao;


/* ***************************************************************************
 *
 * NAME : StagingHdrDAO.java
 *
 * SYSTEM : Unallocated Item Blocking
 *
 * REVISION HISTORY
 *
 * Revision 1.0
 * Ajit Kumar Jan 10,2008.
 * Initial version
 *************************************************************************** */

//SAFEWAY

import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.vox.StagingHdrVO;

/*****************************************************************************
 * Interface as StagingHdrDAO.
 *
 * @author Ajit Kumar.
 * @version 1.0
 *************************************************************************** */

public interface StagingHdrDAO {

    /**
     * This method will be called in the implementation class
     * of StagingHdrDAO by which it will call the method updateStagingHdr
     * from the DAO Implmentation class.
     *
     * @param stagingHdr which is a business object for StagingHdr.
     * @throws MeupException
     */
	void insertStagingHdr(StagingHdrVO stagingHdr) throws MeupException;

}
