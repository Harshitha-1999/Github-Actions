package com.safeway.app.meup.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
public class DB2DataSourceConfiguration {
	Logger logger = LoggerFactory.getLogger(DB2DataSourceConfiguration.class);

	@Autowired
	Environment env;

	@Value("${schema.default}")
	private String schemaUS;

	@Value("${schema.canada}")
	private String schemaCanada;
	
	@Value("${spring.datasource-db2.jdbcUrl}")
	String dataSourceURL;
	@Value("${spring.datasource-db2.driverClassName}")
	String driverClassName;
	@Value("${spring.datasource-db2.username}")
	String userName;
	@Value("${spring.datasource-db2.password}")
	String password;
	@Value("${spring.datasource-db2.hikari.maximum-pool-size}")
	Integer connectionPoolMaxSize;
	@Value("${spring.datasource-db2.hikari.idle-timeout}")
	Integer idleTimeoutMs;

	@Bean
	@Primary
	public DataSource defaultDataSource() {
		HikariConfig config = new HikariConfig();
		config.setDriverClassName(driverClassName);
		config.setJdbcUrl(dataSourceURL);
		config.setUsername(userName);
		config.setPassword(password);
		config.setMaximumPoolSize(connectionPoolMaxSize);
		config.setIdleTimeout(idleTimeoutMs);
		return new HikariDataSource(config);
	}

	@Bean(name = "db2DS")
	public NamedParameterJdbcTemplate namedjdbcTemplateDefaultDB2(@Qualifier("defaultDataSource") DataSource ds) {
		logger.info("-----Configuring jdbcTemplateDefaultDB2------");
		return new NamedParameterJdbcTemplate(ds);
	}

	@Bean(name = "defaultSession")
	@Primary
	public LocalSessionFactoryBean defaultSessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(defaultDataSource());
		sessionFactory.setPackagesToScan("com.safeway.app.meup.vox");
		Properties hibernateProperties = new Properties();
		hibernateProperties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		hibernateProperties.put("hibernate.show_sql", true);
		hibernateProperties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
		hibernateProperties.put("hibernate.default_schema", schemaUS);
		sessionFactory.setHibernateProperties(hibernateProperties);

		return sessionFactory;
	}

	@Bean(name = "canadaSession")
	public LocalSessionFactoryBean canadaSessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(defaultDataSource());
		sessionFactory.setPackagesToScan("com.safeway.app.meup.vox");
		Properties hibernateProperties = new Properties();
		hibernateProperties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		hibernateProperties.put("hibernate.show_sql", true);
		hibernateProperties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
		hibernateProperties.put("hibernate.default_schema", schemaCanada);
		sessionFactory.setHibernateProperties(hibernateProperties);

		return sessionFactory;
	}

	@Bean
	public HibernateTransactionManager transactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(defaultSessionFactory().getObject());
		return transactionManager;
	}
}
