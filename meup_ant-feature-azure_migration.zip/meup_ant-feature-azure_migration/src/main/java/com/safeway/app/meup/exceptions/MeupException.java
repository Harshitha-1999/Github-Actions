
package com.safeway.app.meup.exceptions;


import java.util.ArrayList;
import java.util.List;

public class MeupException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**To store the error messages.*/
	private List<String> errorMessages = new ArrayList<>();
	
	/**
	 * default constructor.
	 */
	public MeupException(){
		super();
		errorMessages.add("Unexpected Error.");
	}
	
	/**
	 * parameterised constructor.
	 * @param ex string
	 */
	public MeupException(String ex){
		super(ex);
		errorMessages.add(ex);
	}
	
	/**
	 * parameterised constructor.
	 * @param ex string 
	 * @param e exception
	 */
	public MeupException(String ex, Exception e){
		super(ex,e);
		errorMessages.add(ex);
	}
	
	/**
	 * @return Returns the errorMessages.
	 */
	public List<String> getErrorMessages() {
		return errorMessages;
	}
	/**
	 * @param errorMessages The errorMessages to set.
	 */
	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	
}
