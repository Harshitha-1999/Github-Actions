package com.safeway.app.meup.vox;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "OMDIV")
public class DivisionVO implements Serializable {
    /**
     * Corp.
     */
    @Column(name = "CORP")
    private String corp;

    /**
     * divisionName.
     */
    @Column(name = "DIV_NAME")
    private String divisionName;
    /**
     * divisionNumber.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DIV")
    private String divisionNumber;

    /**
     * @return Returns the corp.
     */
    public String getCorp() {
        return corp;
    }

    /**
     * @param corp The corp to set.
     */
    public void setCorp(String corp) {
        this.corp = corp;
    }

    /**
     * @return Returns the divisionName.
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     * @param divisionName The divisionName to set.
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    /**
     * @return Returns the divisionNumber.
     */
    public String getDivisionNumber() {
        return divisionNumber;
    }

    /**
     * @param divisionNumber The divisionNumber to set.
     */
    public void setDivisionNumber(String divisionNumber) {
        this.divisionNumber = divisionNumber;
    }


    /**
     * Overriding the toString method.
     *
     * @return String
     */
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("corp = " + this.corp + "\n");
        buffer.append("divisionName = " + this.divisionName + "\n");
        buffer.append("divisionNumber = " + this.divisionNumber + "\n");
        return buffer.toString();
    }

    /**
     * Overriding the equals method.
     */
    public boolean equals(Object obj) {

        if (this == obj) return true;
        if (null == obj || this.getClass() != obj.getClass()) {
            return false;
        }
        DivisionVO div = (DivisionVO) obj;
        return ((this.corp + this.divisionNumber).equals(div.getCorp() + div.getDivisionNumber()));
    }

    /**
     * Overriding the hashCode method.
     */
    public int hashCode() {
        return Integer.parseInt(this.corp + this.divisionNumber);
    }
}
