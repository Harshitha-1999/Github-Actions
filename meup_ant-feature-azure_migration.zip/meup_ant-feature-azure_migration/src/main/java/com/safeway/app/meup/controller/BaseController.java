package com.safeway.app.meup.controller;

import java.util.HashMap;

import com.safeway.app.meup.dto.ResponseDTO;

public class BaseController {

	protected ResponseDTO getResponseDTO(Object data) {
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
		HashMap<String, Object> mapData = new HashMap<>();
		mapData.put(ResponseDTO.REST_DATA, data);
		responseDTO.setData(mapData);
		return responseDTO;
	}

}
