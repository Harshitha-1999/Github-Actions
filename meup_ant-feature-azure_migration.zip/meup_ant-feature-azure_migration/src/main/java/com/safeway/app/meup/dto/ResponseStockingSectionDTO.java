package com.safeway.app.meup.dto;

import java.util.List;

public class ResponseStockingSectionDTO {

	
	private List<HoldItemDTO> acceptList;
	private List<HoldItemDTO> rejectList;
	private String userID;

	
	
	public List<HoldItemDTO> getAcceptList() {
		return acceptList;
	}
	public void setAcceptList(List<HoldItemDTO> acceptList) {
		this.acceptList = acceptList;
	}
	public List<HoldItemDTO> getRejectList() {
		return rejectList;
	}
	public void setRejectList(List<HoldItemDTO> rejectList) {
		this.rejectList = rejectList;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}

	
	
}
