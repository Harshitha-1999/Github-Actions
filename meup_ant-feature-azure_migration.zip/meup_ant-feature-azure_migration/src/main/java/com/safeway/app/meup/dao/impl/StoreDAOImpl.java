package com.safeway.app.meup.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.safeway.app.meup.dao.StoreDAO;
import com.safeway.app.meup.exceptions.MeupException;

@Repository
public class StoreDAOImpl implements StoreDAO {

	private static final Logger log = LoggerFactory.getLogger(StoreDAOImpl.class);

	@Autowired
	@Qualifier("db2DS")
	NamedParameterJdbcTemplate namedParameterjdbcTemplate;
	
	

	@Value("${sql.getStoreInDivsionQuery}")
	private String getStoreInDivsionQuery;

	/**
	 * Gets all the Store available in a given Division.
	 *
	 * @param divisionNumber keep the division number
	 * @param corp           to keep the corp number
	 * @return List of storesBO
	 * @throws MeupException when error occurs while fetching storeDetails
	 */
	@Override
	public List<String> getStoresInDivision(String divisionNumber, String corp) throws MeupException {
		log.info("|---> Beginning Method StoreDAOImpl." + "getStoresInDivision(String divisionNumber, String corp)");

		if (null == divisionNumber || divisionNumber.length() > 2) {
			return new ArrayList<>();
		}
		MapSqlParameterSource map = new MapSqlParameterSource();
		map.addValue("div", divisionNumber);
		List<String> storeList = new ArrayList<>();

		storeList = namedParameterjdbcTemplate.query(getStoreInDivsionQuery, map, new RowMapper<String>() {

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString("FAC");

			}

		});
		return storeList;
	}
}
