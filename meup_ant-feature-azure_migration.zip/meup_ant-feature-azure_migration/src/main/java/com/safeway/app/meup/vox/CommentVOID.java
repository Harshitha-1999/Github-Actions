package com.safeway.app.meup.vox;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class CommentVOID implements Serializable {
    /**
     * lastUpdatedUser holds the last updated user Id.
     */
    @Column(name = "last_upd_user_id")
    String lastUpdatedUser = null ;

    /**
     * lastUpdatedTimeStamp holds the last updated time stamp.
     */
    @Column(name = "last_upd_ts")
    String lastUpdatedTimeStamp = null;


}
