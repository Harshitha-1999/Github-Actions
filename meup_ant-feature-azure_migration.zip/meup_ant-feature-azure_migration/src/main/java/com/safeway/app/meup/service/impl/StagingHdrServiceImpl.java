package com.safeway.app.meup.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.safeway.app.meup.dao.StagingHdrDAO;
import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.StagingHdrService;
import com.safeway.app.meup.util.MeupConstant;
import com.safeway.app.meup.util.MeupLogUtil;
import com.safeway.app.meup.vox.StagingErrorVO;
import com.safeway.app.meup.vox.StagingErrorVOID;
import com.safeway.app.meup.vox.StagingHdrID;
import com.safeway.app.meup.vox.StagingHdrVO;
import com.safeway.app.meup.vox.StagingItemVO;
import com.safeway.app.meup.vox.StagingItemVOID;
import com.safeway.app.meup.vox.StagingStoreItemVO;
import com.safeway.app.meup.vox.StagingStoreItemVOID;

@Service
public class StagingHdrServiceImpl implements StagingHdrService {

    private static final Logger log = LoggerFactory.getLogger(StoreItemServiceImpl.class);
    @Autowired
    StagingHdrDAO stagingHdrDAO;

    /**
     * Method to validate the BigDecimal object and return the DB2 default value
     * if its null
     *
     * @param value
     * @return
     */
    public static BigDecimal getBigDecimal(String value) {
        return (value == null || value.equals("")) ? BigDecimal.ZERO : new BigDecimal(value);
    }

    public StagingHdrDAO getStagingHdrDAO() {
        return stagingHdrDAO;
    }

    public void setStagingHdrDAO(StagingHdrDAO stagingHdrDAO) {
        this.stagingHdrDAO = stagingHdrDAO;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
    public void uploadCSVFile(BlockItemRequestDTO requestDTO, String corpValue) throws MeupException, ParseException {
        StagingHdrVO hdrVO = new StagingHdrVO();
        processBlockItemRequest(hdrVO, requestDTO, corpValue);
        stagingHdrDAO.insertStagingHdr(hdrVO);
    }

    public void processBlockItemRequest(StagingHdrVO hdrVO, BlockItemRequestDTO requestDTO, String corpValue) throws ParseException {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        StagingHdrID hdrVOID = new StagingHdrID();
        hdrVO.setStagingHdrID(hdrVOID);
        /**Get the value of division from blockItemRequestDTO.*/
        String div = requestDTO.getDivisionNumber();

        /**Get the value of userId from the blockItemRequestDTO.*/
        String userId = requestDTO.getUserid();

        /**get the store list in storeItemList.*/
        List<String> storeItemList = requestDTO.getStoreList();

        /**List value to hold the itemList to get from ltemDTOList from blockItemRequestDTO.*/
        List<ItemDTO> itemList = requestDTO.getItemDtoList();

        /**String value to hold the cic value.*/
        String cic = null;

        /**String value to hold the UPC value */
        String upc = null;

        /**itemValidSet to check for the duplicate value of cic and upc.*/
        Set itemValidSet = new HashSet();

        /**itemInValidSet  for the duplicate value of cic and upc.*/
        Set itemInValidSet = new HashSet();

        /**storeValidSet to check for duplicate value of store Id.*/
        Set storeValidSet = new HashSet();

        /**storeInvalidSet for duplicate store ID.*/
        Set storeInvalidSet = new HashSet();

        /**List value to hold the staging store business.*/
        List<StagingStoreItemVO> stagingStoreList = new ArrayList<>();

        /**List value to hold the staging item business.*/
        List<StagingItemVO> stagingItemList = new ArrayList<>();

        /**List value to hold the staging Error business.*/
        List<StagingErrorVO> stagingErrorList = new ArrayList<>();

        /**Iterate the store item list and set one by one
         * all the store number into business object
         * by calling the method create through which it will
         * be calling the update method of DAOImplementation class.*/
        if (!CollectionUtils.isEmpty(storeItemList)) {
            for (String storeNumber : storeItemList) {
                /**store number does not contains duplicate.*/
                if (storeValidSet.add(storeNumber)) {

                    /** get the business object as stagingStore.*/
                    StagingStoreItemVO stagingStore = createStagingStoreItemVO(corpValue, div, userId,
                            timestamp, storeNumber);
                    stagingStoreList.add(stagingStore);
                } else if (storeInvalidSet.add(storeNumber)) {

                    /**if store number contains duplicate value.*/
                    StagingErrorVO stagingError = createStagingErrorVO(corpValue, div, userId,
                            timestamp, storeNumber);
                    stagingErrorList.add(stagingError);
                }
            }
        }

        /**crete an object of itemDTO,Iterate the itemList and get the
         * value of cic from itemDTO and pass this to create
         * method by whihc updateion will.*/
        if (!CollectionUtils.isEmpty(itemList)) {
            for (ItemDTO itemDTO : itemList) {
                cic = itemDTO.getCic();
                upc = itemDTO.getUpcCountry() + itemDTO.getUpcManuf() +
                        itemDTO.getUpcSales() + itemDTO.getUpcSystem();

                if (itemValidSet.add(cic + upc)) {
                    /** get the business object as stagingItem and call the insert method to insert the valid item.*/
                    StagingItemVO stagingItem = createStagingItemVO(corpValue, div, userId,
                            timestamp, itemDTO);
                    stagingItemList.add(stagingItem);
                } else if (itemInValidSet.add(cic + upc)) {

                    /**call the insert method to insert duplicate cic value into error staging table.*/
                    StagingErrorVO stagingError = createStagingItemErrorVO(div, userId,
                            corpValue, timestamp, itemDTO);
                    stagingErrorList.add(stagingError);
                }
            }
        }
        /**call the method which will set all the items into the business object stagingHdr.*/

        /**set the corp value to business object StagingHdr.*/
        hdrVOID.setCorp(corpValue);

        /**set the division number into the business object.*/
        hdrVOID.setDiv(requestDTO.getDivisionNumber());

        /**set the upload user id into business object. */
        hdrVOID.setUserId(requestDTO.getUserid());

        /**set timestamp into the business object.*/
        hdrVOID.setUploadTs(timestamp);

        /**set delete date into the business object.*/
       // hdrVO.setDeleteDt(requestDTO.getDeleteDate());
        Date date1=new SimpleDateFormat("yyyy-MM-dd",Locale.ENGLISH).parse(requestDTO.getDeleteDate());
        hdrVO.setDeleteDt(date1);
        /**set the stagingStoreList to staging hdr business object.*/
        hdrVO.setStagingStoreList(stagingStoreList);

        /**set the stagingItemList to staging hdr business object.*/
        hdrVO.setStagingItemList(stagingItemList);

        /**set the stagingErrorList to staging hdr business object.*/
        hdrVO.setStagingErrorList(stagingErrorList);
    }

    public StagingStoreItemVO createStagingStoreItemVO(String corpValue, String div, String userId, Timestamp timestamp, String storeNumber) {

        log.info("|---> Beginning Method StagingStoreFactory.create().");
        long startTime = MeupLogUtil.currentTime();
        log.debug(MeupLogUtil.startLog(this.getClass().getName(), "storeItems"));
        StagingStoreItemVO stagingStore = new StagingStoreItemVO();
        StagingStoreItemVOID itemVOID = new StagingStoreItemVOID();
        stagingStore.setStagingStoreItemVOID(itemVOID);
        /**set the corp value to business object stagingStore.*/
        itemVOID.setCorp(corpValue);
        /**set the division number into the business object.*/
        itemVOID.setDiv(div);
        /**set the upload user id into business object.*/
        itemVOID.setUserId(userId);
        /**set timestamp into the business object.*/
        itemVOID.setItemUploadTs(timestamp);
        /**set the facility that is store number to the business object.*/
        itemVOID.setFac(storeNumber);

        long endTime = MeupLogUtil.currentTime();
        log.debug(MeupLogUtil.endLog(this.getClass().getName(), "storeItems",
                endTime - startTime));
        log.info("<---| Completed Method StagingStoreFactory.create.");
        return stagingStore;
    }

    /***
     * this method will upload the data with duplicate store number.
     * @param corpValue to get the corp value for the corresponding divison number.
     * @param div
     * @param userId
     * @param timestamp
     * @param storeNumber
     * @throws MeupException
     */
    public StagingErrorVO createStagingErrorVO(String corpValue, String div, String userId, Timestamp timestamp, String storeNumber) {

        /**get the business object as stagingError.*/
        StagingErrorVO stagingError = new StagingErrorVO();
        StagingErrorVOID errorVOID = new StagingErrorVOID();

        /**set the corp value to business object stagingItem.*/
        errorVOID.setCorp(corpValue);
        /**set the division number into the business object.*/
        errorVOID.setDiv(div);
        /**set the upload user id into business object.*/
        errorVOID.setUserId(userId);
        /**set timestamp into the business object.*/
        errorVOID.setErrorUploadTs(timestamp);
        /**set the fac value as duplicate store number.*/
        errorVOID.setFac(storeNumber);
        /**set the cic value.*/
        errorVOID.setCic(BigDecimal.ZERO);
        /**set the UpcCountry .*/
        errorVOID.setUpcCountry(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
        /**set the UpcManuf.*/
        errorVOID.setUpcManuf(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
        /**set the UPcSales.*/
        errorVOID.setUpcSales(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
        /**set the UpcSystem.*/
        errorVOID.setUpcSystem(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
        /**set the error dscription as string value.*/
        stagingError.setErrDesc(MeupConstant.DUPLICATE_STORE_ID);
        return stagingError;
    }

    /**
     * this method will convert all the DTO into the business object
     * and it will set all the duplicate item from the dto to business object
     * and will return the business object.The item which will be get in the form of
     * list and for each iteration will set the the item into the business object.
     *
     * @param div       through which will get all the
     *                  like duplicate cic and upc value in the form of itemDTOList.
     * @param corpValue to get the corp value for the corresponding divison number.
     * @param timestamp the current timestamp whihc will be same for all the staging table.
     * @return
     */

    public StagingErrorVO createStagingItemErrorVO(String div, String userId, String corpValue, Timestamp timestamp, ItemDTO itemDTO) {

        /**Integer value to hold the CIC.*/
        BigDecimal cic, upcSales, upcManuf, upcCountry, upcSystem;

        /**create the business object.*/
        StagingErrorVO stagingError = new StagingErrorVO();
        StagingErrorVOID errorVOID = new StagingErrorVOID();
        stagingError.setStagingErrorVOID(errorVOID);

        /**set the corp value to business object stagingItem.*/
        errorVOID.setCorp(corpValue);

        /**set the division number into the business object.*/
        errorVOID.setDiv(div);

        /**set the upload user id into business object.*/
        errorVOID.setUserId(userId);

        /**set timestamp into the business object.*/
        errorVOID.setErrorUploadTs(timestamp);

        /**get the cic value from the itemDTO and set it into business object.*/
        cic = getBigDecimal(itemDTO.getCic());
        errorVOID.setCic(cic);

        /**get the upcCountry value from the itemDTO and set it into business object.*/
        upcCountry = getBigDecimal(itemDTO.getUpcCountry());
        errorVOID.setUpcCountry(upcCountry);

        /**get the upcManuf value from the itemDTO and set it into business object.*/
        upcManuf = getBigDecimal(itemDTO.getUpcManuf());
        errorVOID.setUpcManuf(upcManuf);

        /**get the upcSales value from the itemDTO and set it into business object.*/
        upcSales = getBigDecimal(itemDTO.getUpcSales());
        errorVOID.setUpcSales(upcSales);

        /**get the upcSystem value from the itemDTO and set it into business object.*/
        upcSystem = getBigDecimal(itemDTO.getUpcSystem());
        errorVOID.setUpcSystem(upcSystem);

        /**set the fac value as empty.*/
        errorVOID.setFac("");

        /**set the error dscription as string value.*/
        stagingError.setErrDesc(MeupConstant.ERROR_DESCRIPTION);

        return stagingError;
    }

    /**
     * this method will convert all the DTO into the business object
     * and it will set all the item from the dto to business object
     * and will return the business object.The item whihc will be get in the form of
     * list and for each iteration will set the the item into the business object.
     *
     * @param div       through which will get all the
     *                  like cic and upc in the form of itemDTOList.
     * @param corpValue to get the corp value for the corresponding divison number.
     * @param timestamp the current timestamp whihc will be same for all the staging table.
     * @return
     */
    public StagingItemVO createStagingItemVO(String corpValue, String div, String userId, Timestamp timestamp, ItemDTO itemDTO) {

        /**Integer value to hold the CIC.*/
        BigDecimal cic, upcSales, upcManuf, upcSystem, upcCountry;

        /**create the business object.*/
        StagingItemVO stagingItem = new StagingItemVO();
        StagingItemVOID stagingItemVOID = new StagingItemVOID();
        stagingItem.setStagingItemVOID(stagingItemVOID);

        /**set the corp value to business object stagingItem.*/
        stagingItemVOID.setCorp(corpValue);

        /**set the division number into the business object.*/
        stagingItemVOID.setDiv(div);

        /**set the upload user id into business object.*/
        stagingItemVOID.setUserId(userId);

        /**set timestamp into the business object.*/
        stagingItemVOID.setStageItemUploadTs(timestamp);

        /**get the cic value from the itemDTO and set it into business object.*/
        cic = getBigDecimal(itemDTO.getCic());
        stagingItemVOID.setCic(cic);

        /**get the upcCountry value from the itemDTO and set it into business object.*/
        upcCountry = getBigDecimal(itemDTO.getUpcCountry());
        stagingItemVOID.setUpcCountry(upcCountry);

        /**get the upcManuf value from the itemDTO and set it into business object.*/
        upcManuf = getBigDecimal(itemDTO.getUpcManuf());
        stagingItemVOID.setUpcManuf(upcManuf);

        /**get the upcSales value from the itemDTO and set it into business object.*/
        upcSales = getBigDecimal(itemDTO.getUpcSales());
        stagingItemVOID.setUpcSales(upcSales);

        /**get the upcSystem value from the itemDTO and set it into business object.*/
        upcSystem = getBigDecimal(itemDTO.getUpcSystem());
        stagingItemVOID.setUpcSystem(upcSystem);

        return stagingItem;
    }
}
