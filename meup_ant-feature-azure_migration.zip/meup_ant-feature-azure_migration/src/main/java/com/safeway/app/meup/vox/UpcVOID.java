package com.safeway.app.meup.vox;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
public class UpcVOID implements Serializable {
    /*** corp value.*/
    @Column(name = "CORP")
    private String corp;

    /*** CorpItemCode value.*/
    @Column(name = "CORP_ITEM_CD")
    private String cic;

    /*** upcManuf value.*/
    @Column(name = "UPC_MANUF")
    private String upcManuf;

    /*** upcSales value.*/
    @Column(name = "UPC_SALES")
    private String upcSales;

    /*** upcCountry value.*/
    @Column(name = "UPC_COUNTRY")
    private String upcCountry;

    /*** upcSystem value.*/
    @Column(name = "UPC_SYSTEM")
    private String upcSystem;

}
