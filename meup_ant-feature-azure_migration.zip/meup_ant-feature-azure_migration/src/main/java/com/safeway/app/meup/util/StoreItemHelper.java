package com.safeway.app.meup.util;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.safeway.app.meup.util.MeupConstant;

@Service
public class StoreItemHelper {

    /**Holds cic.*/
    private String cic;

    /**Holds upc.*/
    private String upc;

    /**Holds storeNo.*/
    private String storeNo;

    /**Holds errorMessage.*/
    private String errorMessage;

    /**Holds cic upc combination.*/
    private String cicupc;

    /**Holds divisionNumber.*/
    private String divisionNumber;

    /**Holds category.*/
    private String category;

    /**Holds description.*/
    private String dsc;

    /**Holds size.*/
    private String size;

    /**Holds uom.*/
    private String uom;

    /**Holds case pk.*/
    private String casePk;

    /**Holds pk.*/
    private String pk;

    /**Holds state.*/
    private String state;

    /**Holds effective date.*/
    private Date stateEffectiveDate;

    /**Holds deleteDate.*/
    private Date deleteDate;

    /**Holds last updated user id.*/
    private String lstUpdtUser;

    private String displayErrorMessage;

    /**
     * @return Returns the displayErrorMessage.
     */
    public String getdisplayErrorMessage() {
        return displayErrorMessage;
    }
    /**
     * @param displayErrorMessage The displayErrorMessage to set.
     */
    public void setdisplayErrorMessage(String displayErrorMessage) {
        this.displayErrorMessage = displayErrorMessage;
    }
    /**
     * @return Returns the casePk.
     */
    public String getCasePk() {
        return casePk;
    }
    /**
     * @param casePk The casePk to set.
     */
    public void setCasePk(String casePk) {
        this.casePk = casePk;
    }
    /**
     * @return Returns the category.
     */
    public String getCategory() {
        return category;
    }
    /**
     * @param category The category to set.
     */
    public void setCategory(String category) {
        this.category = category;
    }
    /**
     * @return Returns the deleteDate.
     */
    public Date getDeleteDate() {
        return deleteDate;
    }
    /**
     * @param deleteDate The deleteDate to set.
     */
    public void setDeleteDate(Date deleteDate) {
        this.deleteDate = deleteDate;
    }
    /**
     * @return Returns the divisionNumber.
     */
    public String getDivisionNumber() {
        return divisionNumber;
    }
    /**
     * @param divisionNumber The divisionNumber to set.
     */
    public void setDivisionNumber(String divisionNumber) {
        this.divisionNumber = divisionNumber;
    }
    /**
     * @return Returns the dsc.
     */
    public String getDsc() {
        return dsc;
    }
    /**
     * @param dsc The dsc to set.
     */
    public void setDsc(String dsc) {
        this.dsc = dsc;
    }
    /**
     * @return Returns the lstUpdtUser.
     */
    public String getLstUpdtUser() {
        return lstUpdtUser;
    }
    /**
     * @param lstUpdtUser The lstUpdtUser to set.
     */
    public void setLstUpdtUser(String lstUpdtUser) {
        this.lstUpdtUser = lstUpdtUser;
    }
    /**
     * @return Returns the pk.
     */
    public String getPk() {
        return pk;
    }
    /**
     * @param pk The pk to set.
     */
    public void setPk(String pk) {
        this.pk = pk;
    }
    /**
     * @return Returns the size.
     */
    public String getSize() {
        return size;
    }
    /**
     * @param size The size to set.
     */
    public void setSize(String size) {
        this.size = size;
    }
    /**
     * @return Returns the state.
     */
    public String getState() {
        return state;
    }
    /**
     * @param state The state to set.
     */
    public void setState(String state) {
        this.state = state;
    }
    /**
     * @return Returns the stateEffectiveDate.
     */
    public Date getStateEffectiveDate() {
        return stateEffectiveDate;
    }
    /**
     * @param stateEffectiveDate The stateEffectiveDate to set.
     */
    public void setStateEffectiveDate(Date stateEffectiveDate) {
        this.stateEffectiveDate = stateEffectiveDate;
    }
    /**
     * @return Returns the uom.
     */
    public String getUom() {
        return uom;
    }
    /**
     * @param uom The uom to set.
     */
    public void setUom(String uom) {
        this.uom = uom;
    }
    /**
     * @return Returns the cicupc.
     */
    public String getCicupc() {
        return cicupc;
    }
    /**
     * @param cicupc The cicupc to set.
     */
    public void setCicupc(String cicupc) {
        this.cicupc = cicupc;
    }
    /**
     * @return Returns the errorMessage.
     */
    public String getErrorMessage() {
        return errorMessage;
    }
    /**
     * @param errorMessage The errorMessage to set.
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    /**
     * @return Returns the cic.
     */
    public String getCic() {
        return cic;
    }
    /**
     * @param cic The cic to set.
     */
    public void setCic(String cic) {
        this.cic = cic;
    }

    /**
     * @return Returns the storeNo.
     */
    public String getStoreNo() {
        return storeNo;
    }
    /**
     * @param storeNo The storeNo to set.
     */
    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }
    /**
     * @return Returns the upc.
     */
    public String getUpc() {
        return upc;
    }
    /**
     * @param upc The upc to set.
     */
    public void setUpc(String upc) {
        this.upc = upc;
    }

    /**
     * Method which returns the tokens for the given 12 digit UPC.
     *  The tokens are created by breaking up UPC as
     *  Token 1: Country code - 1st digit of UPC.
     *  Token 2: Numbering system code - 2nd digit of UPC.
     *  Token 3: Manufacture code - 3rd to 7th digit of UPC.
     *  Token 4: Sales code - 8th to 12th digit of UPC.
     *
     * @param upcValue String
     * @return int[]
     */
    public int[] getUPCTokens(String upcValue) {

        /** Break Point for EAN-UCC-13(13 digit) format. */
        int[] upcBreakPoints =
                {MeupConstant.UPCCOUNTRY_START_LENGTH,
                MeupConstant.UPCSYSTEM_START_LENGTH,
                MeupConstant.UPCMANUF_START_LENGTH,
                MeupConstant.UPCSALES_START_LENGTH,
                MeupConstant.UPC_FIELD_DATA_SIZE};

        /** Parsed UPC tokens. */
        int[] upcTokens = null;
        upcTokens = getTokens(upcBreakPoints, upcValue);
        return upcTokens;
    }

    /**
     * Method which splits a given upc to tokens based on the breakpoints.
     *
     * @param breakPoints int[]
     * @param upcValue String
     * @return String[]
     */
    public int[] getTokens(int[] breakPoints, String upcValue) {

        int breakPointLength = breakPoints.length - 1;
        int[] upcTokens = new int[breakPointLength];
        for (int i = 0; i < breakPointLength;) {
            upcTokens[i] = Integer.parseInt(upcValue.substring(breakPoints[i],
                    breakPoints[++i]));
        }
        return upcTokens;
    }
}
