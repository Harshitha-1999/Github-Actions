
package com.safeway.app.meup.dto;


public class UserDTO extends SerializableDTO{
	
	/**To store the userId.*/
	private String userId;
	
	/**To store the role of the user.*/
	private String role;
	
	/**To store the division of the user.*/
	private String division;
	
	/**
	 * @return Returns the role.
	 */
	public String getRole() {
		return role;
	}
	
	/**
	 * @param role The role to set.
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	/**
	 * @return Returns the userId.
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * @param userId The userId to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * constructor
	 */
	public UserDTO() {
		super();
	}
	
	/**
	 * @param userId
	 * @param role
	 */
	public UserDTO(String userId, String role) {
		super();
		this.userId = userId;
		this.role = role;
	}
	
	
	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	/**
     * Method to print the object details
     *
     * @return String
     */
    public String toString() {
        StringBuffer sbuff=new StringBuffer();
        sbuff.append("userId: "+this.getUserId()+" ");
        sbuff.append("role: "+this.getRole()+"\n ");
        return sbuff.toString();
    }
}
