package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * The primary key class for the MEUPSTGH database table.
 *
 */
@Embeddable
public class StagingHdrID implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "CORP",unique = true, nullable = false)
    private String corp;

    @Column(name = "DIV",unique = true, nullable = false)
    private String div;

    @Column(name = "UPLOAD_USER_ID",unique = true, nullable = false)
    private String userId;

    @Column(name = "UPLOAD_TS",unique = true, nullable = false)
    private Timestamp uploadTs;

    public String getCorp() {
        return corp;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getUploadTs() {
        return uploadTs;
    }

    public void setUploadTs(Timestamp uploadTs) {
        this.uploadTs = uploadTs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StagingHdrID that = (StagingHdrID) o;

        if (!corp.equals(that.corp)) return false;
        if (!div.equals(that.div)) return false;
        if (!userId.equals(that.userId)) return false;
        return uploadTs.equals(that.uploadTs);
    }

    @Override
    public int hashCode() {
        int result = corp.hashCode();
        result = 31 * result + div.hashCode();
        result = 31 * result + userId.hashCode();
        result = 31 * result + uploadTs.hashCode();
        return result;
    }
}
