/* ****************************************************************************
 *
 * Copyright 2008, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */
package com.safeway.app.meup.service;

import java.sql.SQLException;
import java.util.List;

import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.vox.StockingSectionVO;

public interface DivisionService {

	List<DivisionDTO> getDivisionList();

	List<DivisionDTO> getDivisionListOnHold(String corp, String groupCode, List<StockingSectionVO> stockingSectionList,
			char itemstateCode, char blockedStatusCode) throws MeupException, SQLException;



	String getCorpForDiv(String div);

	List<DivisionDTO> getDivisionListForUS(String corp);

	boolean isValidDivision(String divisionNumber) throws MeupException;
}
