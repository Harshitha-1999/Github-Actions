
package com.safeway.app.meup.util;



import java.net.InetAddress;
import java.sql.Timestamp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.safeway.app.meup.exceptions.LogErrorMessage;



public class MeupLogUtil {

	/**Logging framework.*/
	private static final Log log = LogFactory.getLog(MeupLogUtil.class);



	@Autowired
	private static LogErrorMessage errorMessage;
	private static String stringBeginning="*** Beginning -";
	private static String stringCompleted="*** Completed - ";
	private static String stringDot=" .";
	private static String stringDash=" -";
	private static String stringEnd=" ***";
	private static String host = "";

	/**
	 * Default constructor.
	 */
	public MeupLogUtil(){

	}
	/**
	 *  Method called at the beginning of a method excecution.
	 *
	 * @param className class name
	 * @param methodName method name
	 * @return string
	 */
	public static String startLog(String className, String methodName) {

		StringBuffer sb = new StringBuffer();
		synchronized(sb){
			try {
				Timestamp ts = new Timestamp(
						System.currentTimeMillis());
				sb.append(stringBeginning);
				sb.append(className);
				sb.append(stringDot);
				sb.append(methodName);
				sb.append(stringDash);
				if ("".equals(host)){
					host=InetAddress.getLocalHost().
					getHostName();
				}
				sb.append(host);
				sb.append(stringDash);
				sb.append(ts);
				sb.append(stringDash);
				sb.append(stringEnd);
			} catch(Exception ex) {
				log.info(ex);
				log.error((errorMessage.START_LOG_ERR +
						className + "." + methodName), ex);
			}
		}
		return sb.toString();
	}

	/**
	 * Method called at the end of the method execution.
	 *
	 * @param className
	 * @param methodName
	 * @param time
	 * @return string
	 */
	public static String endLog(String className,
								String methodName, long time) {

		StringBuffer sb = new StringBuffer();
		synchronized(sb){
			try {
				Timestamp ts = new Timestamp(
						System.currentTimeMillis());
				sb.append(stringCompleted);
				sb.append(className);
				sb.append(stringDot);
				sb.append(methodName);
				sb.append(stringDash);
				if ("".equals(host)){
					host=InetAddress.getLocalHost().
					getHostName();
				}
				sb.append(host);
				sb.append(stringDash);
				sb.append(ts);
				sb.append(stringDash);
				sb.append(stringDash);
				sb.append(String.valueOf(time));
				sb.append(stringEnd);
			} catch(Exception ex) {
				log.error((errorMessage.END_LOG_ERR +  className + "."
						+ methodName), ex);
			}
		}
		return sb.toString();
	}

	/**
	 * Gives the current time.
	 *
	 * @return current time
	 */
	public static long currentTime(){
		return System.currentTimeMillis();
	}
}