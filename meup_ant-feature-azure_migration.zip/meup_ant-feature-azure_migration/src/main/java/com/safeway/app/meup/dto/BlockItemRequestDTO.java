
package com.safeway.app.meup.dto;

import java.sql.Timestamp;
import java.util.List;

import com.safeway.app.meup.util.StoreItemHelper;

public class BlockItemRequestDTO extends SerializableDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<StoreItemHelper> storeItemHelperList;
	/**String to store corp.*/
	private String corp;
	
	/**String to store Timestamp.*/
	private Timestamp uploadTs;
	
	/**String to store userid.*/
	private String userid;
	
	/**String to store delete date.*/
	private String deleteDate;
	
	/**String to store division number.*/
	private String divisionNumber;
	
	/**String to store list of stores.*/
	private List<String> storeList;
	
	/**String to store List of itemDTo.*/
	private List<ItemDTO> itemDtoList;

	public List<StoreItemHelper> getStoreItemHelperList() {
		return storeItemHelperList;
	}

	public void setStoreItemHelperList(List<StoreItemHelper> storeItemHelperList) {
		this.storeItemHelperList = storeItemHelperList;
	}

	public String getCorp() {
		return corp;
	}

	public void setCorp(String corp) {
		this.corp = corp;
	}

	public Timestamp getUploadTs() {
		return uploadTs;
	}

	public void setUploadTs(Timestamp uploadTs) {
		this.uploadTs = uploadTs;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(String deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getDivisionNumber() {
		return divisionNumber;
	}

	public void setDivisionNumber(String divisionNumber) {
		this.divisionNumber = divisionNumber;
	}

	public List<String> getStoreList() {
		return storeList;
	}

	public void setStoreList(List<String> storeList) {
		this.storeList = storeList;
	}

	public List<ItemDTO> getItemDtoList() {
		return itemDtoList;
	}

	public void setItemDtoList(List<ItemDTO> itemDtoList) {
		this.itemDtoList = itemDtoList;
	}
}