package com.safeway.app.meup.service;

import java.text.ParseException;

import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.exceptions.MeupException;

public interface StagingHdrService {

    void uploadCSVFile(BlockItemRequestDTO requestDTO, String corpValue) throws MeupException, ParseException;
}
