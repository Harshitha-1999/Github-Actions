package com.safeway.app.meup.dao;

import java.util.List;

import com.safeway.app.meup.exceptions.MeupException;

public interface StoreDAO {
    List<String> getStoresInDivision(String divisionNumber, String corp) throws MeupException;
}
