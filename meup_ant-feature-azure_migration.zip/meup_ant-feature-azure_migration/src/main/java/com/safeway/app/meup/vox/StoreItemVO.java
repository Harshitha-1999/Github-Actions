package com.safeway.app.meup.vox;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.safeway.app.meup.util.MeupConstant;

@Entity
@Table(name = "MEUPITM")
public class StoreItemVO implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    StoreItemVOID storeItemVOID;

    /**
     * upcSales holds upc sales value.
     */
    @Column(name = "UPC_SALES")
    BigDecimal upcSales;

    /**
     * upcManuf holds upc manufacture value.
     */
    @Column(name = "UPC_MANUF")
    BigDecimal upcManuf;

    /**
     * upcSystem holds upc system value.
     */
    @Column(name = "UPC_SYSTEM")
    BigDecimal upcSystem;

    /**
     * upcCountry holds upc country value.
     */
    @Column(name = "UPC_COUNTRY")
    BigDecimal upcCountry;


    /**
     * state holds the state of an item
     */
    @Column(name = "state_ind")
    String state;

    /**
     * stateEffectiveDate holds the blocked on date.
     */
    @Temporal(TemporalType.DATE)
    @Column(name = "state_eff_dt")
    Date stateEffectiveDate;

    /**
     * blockedStatus holds the blocked status of an item.
     */
    @Column(name = "blocked_stat_ind")
    String blockedStatus;

    /**
     * blockedTargetDate holds the deletedate as a value.
     */
    @Temporal(TemporalType.DATE)
    @Column(name = "blocked_target_dt")
    Date blockedTargetDate;

    /**
     * lastUpdatedUser holds the last updated user Id.
     */
    @Column(name = "last_upd_user_id")
    String lastUpdatedUser;

    /**
     * lastUpdatedTimeStamp holds the last updated time stamp.
     */
    @Column(name = "last_upd_ts")
    Timestamp lastUpdatedTimeStamp;


    /**
     * @return Returns the blockedStatus.
     */
    public String getBlockedStatus() {
        return blockedStatus;
    }

    /**
     * @param blockedStatus The blockedStatus to set.
     */
    public void setBlockedStatus(String blockedStatus) {
        this.blockedStatus = blockedStatus;
    }

    /**
     * @return Returns the blockedTargetDate.
     */
    public Date getBlockedTargetDate() {
        return blockedTargetDate;
    }

    /**
     * @param blockedTargetDate The blockedTargetDate to set.
     */
    public void setBlockedTargetDate(Date blockedTargetDate) {
        this.blockedTargetDate = blockedTargetDate;
    }


    /**
     * @return Returns the lastUpdatedTimeStamp.
     */
    public Timestamp getLastUpdatedTimeStamp() {
        return lastUpdatedTimeStamp;
    }

    /**
     * @param lastUpdatedTimeStamp The lastUpdatedTimeStamp to set.
     */
    public void setLastUpdatedTimeStamp(Timestamp lastUpdatedTimeStamp) {
        this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
    }

    /**
     * @return Returns the lastUpdatedUser.
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * @param lastUpdatedUser The lastUpdatedUser to set.
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * @return Returns the state.
     */
    public String getState() {
        return state;
    }

    /**
     * @param state The state to set.
     */
    public void setState(String state) {
        this.state = state;
    }


    /**
     * @return Returns the stateEffectiveDate.
     */
    public Date getStateEffectiveDate() {
        return stateEffectiveDate;
    }

    /**
     * @param stateEffectiveDate The stateEffectiveDate to set.
     */
    public void setStateEffectiveDate(Date stateEffectiveDate) {
        this.stateEffectiveDate = stateEffectiveDate;
    }


    /**
     * @return Returns the upcCountry.
     */
    public BigDecimal getUpcCountry() {
        return upcCountry;
    }

    /**
     * @param upcCountry The upcCountry to set.
     */
    public void setUpcCountry(BigDecimal upcCountry) {
        this.upcCountry = upcCountry;
    }

    /**
     * @return Returns the upcManuf.
     */
    public BigDecimal getUpcManuf() {
        return upcManuf;
    }

    /**
     * @param upcManuf The upcManuf to set.
     */
    public void setUpcManuf(BigDecimal upcManuf) {
        this.upcManuf = upcManuf;
    }

    /**
     * @return Returns the upcSales.
     */
    public BigDecimal getUpcSales() {
        return upcSales;
    }

    /**
     * @param upcSales The upcSales to set.
     */
    public void setUpcSales(BigDecimal upcSales) {
        this.upcSales = upcSales;
    }

    /**
     * @return Returns the upcSystem.
     */
    public BigDecimal getUpcSystem() {
        return upcSystem;
    }

    /**
     * @param upcSystem The upcSystem to set.
     */
    public void setUpcSystem(BigDecimal upcSystem) {
        this.upcSystem = upcSystem;
    }

    /**
     * Method to set the blockStatus of the item.
     */
    public void blockItem() {
        this.setBlockedStatus(MeupConstant.BLOCKED_STATUS_KEY);
    }

    /**
     * Checks whether the item is in the process of discontinuation.
     *
     * @return boolean value
     */
    public boolean isItemDiscontinued() {
        return this.getBlockedStatus().equals(
                MeupConstant.BLOCKED_STATUS_KEY) &&
                MeupConstant.MEND_USERID.equals(this.getLastUpdatedUser());
    }

    /**
     * Checks whether the item is blocked.
     *
     * @return boolean value
     */
    public boolean isItemBlocked() {
        return this.getBlockedStatus().equals(MeupConstant.BLOCKED_STATUS_KEY);
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("ID = " + this.storeItemVOID + "\n");
        return buffer.toString();
    }

    public StoreItemVOID getStoreItemVOID() {
        return storeItemVOID;
    }

    public void setStoreItemVOID(StoreItemVOID storeItemVOID) {
        this.storeItemVOID = storeItemVOID;
    }
}
