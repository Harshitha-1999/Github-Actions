package com.safeway.app.meup.dao.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.safeway.app.meup.dao.StoreItemHistoryDAO;
import com.safeway.app.meup.exceptions.LogErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.impl.StoreItemServiceImpl;
import com.safeway.app.meup.vox.StoreItemHistoryVO;
import com.safeway.app.meup.vox.StoreItemHistoryVOID;
import com.safeway.app.meup.vox.StoreItemVO;

@Repository
public class StoreItemHistoryDAOImpl implements StoreItemHistoryDAO {
	private static final Logger log = LoggerFactory.getLogger(StoreItemServiceImpl.class);

	@Value("${sql.StoreItemHistroyDAO}")
	private String getStoreItemHistroyDAO;

	@Autowired
	StoreItemDAOImpl storeItemDAOImpl;

	@Autowired
	@Qualifier("defaultSession")
	SessionFactory sfDefault;

	@Autowired
	@Qualifier("canadaSession")
	SessionFactory sfCanada;

	@Override
	public List<StoreItemHistoryVO> getStoreItemsForHistory(String corp, String division, String fac, String cic)
			throws MeupException {
		log.info("|---> Beginning Method StoreItemHistoryDAOImpl" + ".getStoreItemsForHistory");
		Session session = null;
		List<StoreItemHistoryVO> storeItemHistoryBOList = null;

		try {
			log.info("|---> DB call started for Method StoreItemHistoryDAOImpl" + ".getStoreItemsForHistory");
			session = sfDefault.openSession();
			Query queryForViewReport = session.createQuery(getStoreItemHistroyDAO);
			queryForViewReport.setString("corp", "001");
			queryForViewReport.setString("division", division);
			queryForViewReport.setString("fac", fac);
			queryForViewReport.setString("cic", cic);
			storeItemHistoryBOList = queryForViewReport.list();
			session.close();
			log.info("|---> DB call ended for Method StoreItemHistoryDAOImpl" + ".getStoreItemsForHistory");
		} catch (HibernateException hibernateException) {
			log.error(LogErrorMessage.HISTORY_REPORT_EXCEPTION + " : " + hibernateException.getMessage());
			throw new MeupException(LogErrorMessage.HISTORY_REPORT_EXCEPTION + " : " + hibernateException.getMessage());
		}
		log.info("<--- |Completed Method " + "Method StoreItemHistoryDAOImpl" + ".getStoreItemsForHistory");
		return storeItemHistoryBOList;

	}

	@Override
	public void insertBlockedItemHistory(List<StoreItemVO> storeItemVO) throws MeupException {
		log.info("|---> Beginning Method StoreItemHistoryDAOImpl" + ".insertBlockedItemHistory");

		//Session session = sfDefault.openSession();
		try {

			if (!CollectionUtils.isEmpty(storeItemVO)) {
				/*for (StoreItemVO itemVO : storeItemVO) {
					//StoreItemHistoryVO historyVO = createItemHistoryVO(itemVO);
					Timestamp timeStampSec=itemVO.getLastUpdatedTimeStamp();
					String corp=itemVO.getStoreItemVOID().getCorp();
					storeItemDAOImpl.updateHistory(corp,timeStampSec);
					//session.save(historyVO);
					//session.flush();
				}*/

				StoreItemVO itemVO= storeItemVO.get(0);
				Timestamp timeStampSec=itemVO.getLastUpdatedTimeStamp();
				String corp=itemVO.getStoreItemVOID().getCorp();
				storeItemDAOImpl.updateHistory(corp,timeStampSec);
			}
		} catch (HibernateException exception) {
			log.error("Exception while saving history record of Store Item" + exception.getMessage());
			throw new MeupException("Exception while saving history record of Store Item" + exception.getMessage());
		} finally {
		//	session.close();
		}

		log.info("<--- |Completed Method " + "Method StoreItemHistoryDAOImpl" + ".insertBlockedItemHistory");

	}

	/**
	 * Method creates the StoreItemHistory BO from StoreItem BO.
	 *
	 * @param storeItem domain object.
	 * @return StoreItemHistory domain object generated from storeItem BO
	 */
	public StoreItemHistoryVO createItemHistoryVO(StoreItemVO storeItem) {
		log.info("|---> Beginning Method createItemHistoryVO.");

		StoreItemHistoryVO storeItemHistoryImpl = new StoreItemHistoryVO();
		StoreItemHistoryVOID historyVOID = new StoreItemHistoryVOID();
		storeItemHistoryImpl.setStoreItemHistoryVOID(historyVOID);
		historyVOID.setCorp(storeItem.getStoreItemVOID().getCorp());
		historyVOID.setDivision(storeItem.getStoreItemVOID().getDivision());
		historyVOID.setStoreNumber(storeItem.getStoreItemVOID().getStoreNumber());
		historyVOID.setCic(storeItem.getStoreItemVOID().getCic());
		historyVOID.setDc(storeItem.getStoreItemVOID().getDc());
		historyVOID.setLastUpdatedTimeStamp(storeItem.getLastUpdatedTimeStamp().toString());
		storeItemHistoryImpl.setUpcCountry(storeItem.getUpcCountry());
		storeItemHistoryImpl.setUpcSystem(storeItem.getUpcSystem());
		storeItemHistoryImpl.setUpcManuf(storeItem.getUpcManuf());

		storeItemHistoryImpl.setUpcSales(storeItem.getUpcSales());
		storeItemHistoryImpl.setBlockedStatus(storeItem.getBlockedStatus());
		//storeItemHistoryImpl.setBlockedTargetDate(storeItem.getBlockedTargetDate().toString());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = formatter.format(storeItem.getBlockedTargetDate());
		storeItemHistoryImpl.setBlockedTargetDate(formattedDate);
		storeItemHistoryImpl.setLastUpdatedUser(storeItem.getLastUpdatedUser());
		storeItemHistoryImpl.setState(storeItem.getState());
		storeItemHistoryImpl.setStateEffectiveDate(storeItem.getStateEffectiveDate().toString());
		;
		log.info("|<--- Completed Method " + "StoreItemHistoryFactory.create(StoreItem storeItem)");
		return storeItemHistoryImpl;
	}

}
