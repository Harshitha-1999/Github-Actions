/* ****************************************************************************
 *
 * Copyright 2008, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */

package com.safeway.app.meup.dao;


import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.ItemCountsByStoreDTO;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.vox.CommentVO;
import com.safeway.app.meup.vox.StoreItemVO;
import com.safeway.app.meup.vox.UpcVO;

public interface StoreItemDAO {


     
    List<ItemCountsByStoreDTO> getItemCountsOnHold(String corp,  List<String> stockingSectionList, List<String> divisionList)
            throws MeupException, SQLException;


//   void updateBlockStoreItems(List<StoreItemDTO> validStoreItemDtoList) throws MeupException;

    List<HoldItemDTO> getItemListForStoreStockSection(String corp, String storeID, String stockSectionNbr) throws MeupException, SQLException;
    
    void updateItemsByStoreStockingSection(List<HoldItemDTO> holdItemList, String userID) throws MeupException, SQLException;

	List<StoreItemDTO> selectBlockedWhStoreItems(StoreItemSearchDTO storeItemSearchDTO) throws MeupException;


	void updateItemsByStoreStockSection(List<HoldItemDTO> acceptList, String userID, String groupID) throws MeupException, SQLException;


	List<StoreItemDTO> selectStoreItemsForReport(StoreItemSearchDTO storeItemSearchDTO) throws MeupException, SQLException;

	void updateBlockStoreItems(List<StoreItemVO> storeItemVOList) throws MeupException;



	UpcVO getItemDetails(String cic, String upcCountry, String upcSystem, String upcManuf, String upcSales,
			String storeNumber, String corp, String divisionNumber) throws MeupException;



	StoreItemVO getStoreItem(String corp, String divisionNumber, String cic, String dc, String storeNumber) throws MeupException;


	 int updateBlockedItem(List<StoreItemDTO> storeItemList, String userId, CommentVO commentDto, boolean unblock, Timestamp timestamp)
            throws MeupException, SQLException;


	int updateHistory(String corp, Timestamp timestamp) throws MeupException;




	
}