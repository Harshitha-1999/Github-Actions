package com.safeway.app.meup.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.safeway.app.meup.dao.DivisionDAO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.exceptions.MeupException;

@Repository
@PropertySource(value = { "classpath:/sql.properties" })
public class DivisionDAOImpl implements DivisionDAO {

	private static final Logger log = LoggerFactory.getLogger(DivisionDAOImpl.class);
	@Autowired
	@Qualifier("defaultSession")
	SessionFactory defaultsessionFactory;

	@Autowired
	@Qualifier("db2DS")
	NamedParameterJdbcTemplate namedParameterjdbcTemplate;

	@Autowired
	@Qualifier("snowFlakDatasource")
	JdbcTemplate snowflakejdbctemplate;

	@Value("${sql.getDivisions}")
	private String getDivisionQuery;

	@Value("${sql.getCorp}")
	private String getCorp;

	@Value("${sql.getDivisionsListByStatus}")
	private String getDivisionByStatusQuery;

	@Value("${sql.getDivisionListByCorp}")
	private String getDivisionListByCorp;

	@Override
	public List<DivisionDTO> getDivisionList() {
		log.info("|--> Beginning of DivisionDAOImpl.getDivisionList()");
		List<DivisionDTO> divisionList = namedParameterjdbcTemplate.query(getDivisionQuery,
				new RowMapper<DivisionDTO>() {
					@Override
					public DivisionDTO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
						DivisionDTO division = new DivisionDTO();
						division.setCorp(resultSet.getString("CORP"));
						division.setDivisionNumber(resultSet.getString("DIV"));
						division.setDivisionName(resultSet.getString("DIV_NAME"));
						return division;

					}
				});
		log.info("<---| Completed Method DivisionDAOImpl " + ". getDivisionList ");
		return divisionList;

	}

	@Override
	public String getCorp(String div) {
		log.info("|--> Beginning of DivisionDAOImpl.getCorp");
		MapSqlParameterSource map = new MapSqlParameterSource();
		map.addValue("div", div);
		String corpResult = namedParameterjdbcTemplate.queryForObject(getCorp, map, String.class);
		log.info("<---| Completed Method DivisionDAOImpl getCorp " + ". getCorp ");
		return corpResult;

	}

	public List<DivisionDTO> getDivisionListByStatus(String corp, String groupCode, List stockingSectionList,
			char itemStateCode, char blockedStatusCode) throws MeupException, SQLException {
		log.info("|--> Beginning of DivisionDAOImpl.getDivisionListByStatus");
		String stockingSections = "";
		String stockingSectionSql = "AND c.stock_sect_nbr IN (:stockingSection)";

		String STOCKINGSECTION = ":stockingSection";
		StringBuilder divisionByStatusQuery = new StringBuilder();
		divisionByStatusQuery.append(getDivisionByStatusQuery);

		List<DivisionDTO> divisionListByStatus = new ArrayList<>();

		if (stockingSectionList != null && stockingSectionList.size() > 0) {
			for (Iterator<?> itr = stockingSectionList.iterator(); itr.hasNext();) {
				if (!"".equals(stockingSections)) {
					stockingSections = stockingSections + "," + itr.next();

				} else {
					stockingSections = stockingSections + itr.next();

				}
			}
			stockingSectionSql = stockingSectionSql.replaceAll(STOCKINGSECTION, stockingSections);

		}

		if (null != stockingSectionList && stockingSectionList.size() > 0) {
			divisionByStatusQuery.append(" ");
			divisionByStatusQuery.append(stockingSectionSql);

		}
		log.info("<---| DB Call started for Method DivisionDAOImpl.getDivisionListByStatus " + ". getDivisionListByStatus ");
		divisionListByStatus = snowflakejdbctemplate.query(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement stmnt = con.prepareStatement(divisionByStatusQuery.toString());
				stmnt.setString(1, corp);
				stmnt.setString(2, Character.toString(itemStateCode));
				stmnt.setString(3, Character.toString(blockedStatusCode));
				return stmnt;
			}
		}, new RowMapper<DivisionDTO>() {

			@Override
			public DivisionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				DivisionDTO division = new DivisionDTO();
				division.setDivisionNumber(rs.getString("DIVISION_ID"));
				division.setDivisionName(rs.getString("DIVISION_NM"));
				return division;
			}

		});
		log.info("<---| DB Call ended for Method DivisionDAOImpl.getDivisionListByStatus " + ". getDivisionListByStatus ");
		log.info("<---| Completed Method DivisionDAOImpl.getDivisionListByStatus " + ". getDivisionListByStatus ");
		return divisionListByStatus;

	}

	@Override
	public List<DivisionDTO> getDivisionListByCorp(String corp) {
		log.info("|--> Beginning of DivisionDAOImpl.getDivisionListByCorp");
		MapSqlParameterSource map = new MapSqlParameterSource();
		map.addValue("corpCode", corp);

		List<DivisionDTO> divisionList = namedParameterjdbcTemplate.query(getDivisionQuery, map,
				new RowMapper<DivisionDTO>() {
					@Override
					public DivisionDTO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
						DivisionDTO division = new DivisionDTO();
						division.setCorp(resultSet.getString("CORP"));
						division.setDivisionNumber(resultSet.getString("DIV"));
						division.setDivisionName(resultSet.getString("DIV_NAME"));
						return division;

					}
				});
		log.info("<---| Completed Method DivisionDAOImpl.getDivisionListByCorp " + ". getDivisionListByCorp ");
		return divisionList;

	}

	@Override
	public boolean isValidDivision(String divisionNumber) throws MeupException {
		log.info("|--> Beginning of DivisionDAOImpl.isValidDivision");
		try {

			MapSqlParameterSource map = new MapSqlParameterSource();
			map.addValue("divisionNumber", divisionNumber);
			boolean isValidDivision = false;
			DivisionDTO divisionDTO = new DivisionDTO();
			List<DivisionDTO> divisionList = getDivisionList();
			/** Iterate all the list for divisionDTO. */
			Iterator<?> getDivisionDto = divisionList.iterator();

			while (getDivisionDto.hasNext()) {
				divisionDTO = (DivisionDTO) getDivisionDto.next();
				String divNum = divisionDTO.getDivisionNumber();

				/** check whether the division number is valid. */
				if (divNum.equals(divisionNumber)) {
					isValidDivision = true;
					break;
				}
			}
			log.info("<---| Completed Method DivisionDAOImpl.isValidDivision " + ". isValidDivision ");
			return isValidDivision;
		} catch (Exception exception) {
			throw new MeupException("Failed to get division");
		} finally {
		}
	}
}
