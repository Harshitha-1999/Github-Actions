package com.safeway.app.meup.service;


import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.dto.UpdateStoreItemDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.vox.StoreItemHistoryVO;


public interface StoreItemService {

	/*
	 * ResponseDTO getStoreItemsForReport(StoreItemSearchDTO storeItemSearchDTO)
	 * throws MeupException;
	 */

	ResponseDTO getStoreItemsForUpdate(StoreItemSearchDTO storeItemSearchDto) throws MeupException;

	ResponseDTO getStoreItemsForReport(StoreItemSearchDTO storeItemSearchDTO) throws MeupException, SQLException;

	ResponseDTO updateStoreItems(UpdateStoreItemDTO updateStoreItemDTO) throws MeupException, SQLException;

	ResponseDTO modifyDeleteDate(UpdateStoreItemDTO updateStoreItemDTO) throws MeupException;

	ResponseDTO unblockStoreItems(UpdateStoreItemDTO updateStoreItemDTO) throws MeupException, SQLException;

	String createExcelExport(List<StoreItemDTO> storeItemSearchDtoList, HttpServletResponse response) throws MeupException, ParseException;

	
	void uploadCSVFile(BlockItemRequestDTO blockItemRequestDto) throws MeupException;

	List<StoreItemHistoryVO> getStoreItemsForHistory(StoreItemDTO selectedStoreItemDTO) throws MeupException;

	ResponseDTO uploadCSVFile(MultipartFile itemsFile, String userID, Date deleteDate) throws MeupException;

	List blockItemsAndStores(BlockItemRequestDTO blockItemRequestDTO) throws MeupException, ParseException;
}
