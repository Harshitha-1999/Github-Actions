package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "MEPRDCLF")
public class SmicGroupVO implements Serializable {
    @Id
    @Column(name = "GROUP_CD")
    private String groupCd;
    @Column(name = "CLSIFICATION_DESC")
    private String groupName;
    @Column(name = "CORP")
    private String corp;
    @Column(name = "ctgry_cd")
    private String categoryCode;
    @Column(name = "class_cd")
    private String classCode;
    @Column(name = "sub_class_cd")
    private String subClassCode;
    @Column(name = "sub_class")
    private String subClass;

    public String getGroupCd() {
        return groupCd;
    }

    public void setGroupCd(String groupCd) {
        this.groupCd = groupCd;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getCorp() {
        return corp;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getSubClassCode() {
        return subClassCode;
    }

    public void setSubClassCode(String subClassCode) {
        this.subClassCode = subClassCode;
    }

    public String getSubClass() {
        return subClass;
    }

    public void setSubClass(String subClass) {
        this.subClass = subClass;
    }
}
