
package com.safeway.app.meup.vox;



import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Immutable
@Table(name = "SSSTOCTL")
@Polymorphism(type = PolymorphismType.IMPLICIT)
public class StoreVO {
    @EmbeddedId
    StoreOptionsVOID storeOptionsVOID;

    @Column(name = "FAC")
    private String fac;

    @Column(name = "DIV")
    private String div;

    public String getCorp() {
        return storeOptionsVOID.getCorp();
    }

    /**
     * @param corp The corp to set.
     */
    public void setCorp(String corp) {
        storeOptionsVOID.setCorp(corp);
    }

    /**
     * @return Returns the fac.
     */
    public String getFac() {
        return fac;
    }

    /**
     * @param fac The fac to set.
     */
    public void setFac(String fac) {
        this.fac = fac;
    }

    /**
     * @return Returns the rog.
     */
    public String getRog() {
        return storeOptionsVOID.getRog();
    }

    /**
     * @param rog The rog to set.
     */
    public void setRog(String rog) {
        storeOptionsVOID.setRog(rog);
    }

    public StoreOptionsVOID getStoreOptionsVOID() {
        return storeOptionsVOID;
    }

    public void setStoreOptionsVOID(StoreOptionsVOID storeOptionsVOID) {
        this.storeOptionsVOID = storeOptionsVOID;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }
}
