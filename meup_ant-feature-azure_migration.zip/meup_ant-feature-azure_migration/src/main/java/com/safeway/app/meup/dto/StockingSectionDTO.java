

package com.safeway.app.meup.dto;



import com.safeway.app.meup.dto.SerializableDTO;

public class StockingSectionDTO extends SerializableDTO {

	/**
	 * holds the stocking section description
	 */
	private String stockingSectionDesc;

	/**
	 * holds the stocking section number
	 */
	private String stockingSectionNumber;

	/**
	 * 
	 * @return stockingSectionDesc
	 */
	public String getStockingSectionDesc() {
		return stockingSectionDesc;
	}

	/**
	 * 
	 * @param stockingSectionDesc
	 */
	public void setStockingSectionDesc(String stockingSectionDesc) {
		this.stockingSectionDesc = stockingSectionDesc;
	}

	/**
	 * 
	 * @return stockingSectionNumber
	 */
	public String getStockingSectionNumber() {
		return stockingSectionNumber;
	}

	/**
	 * 
	 * @param stockingSectionNumber
	 */
	public void setStockingSectionNumber(String stockingSectionNumber) {
		this.stockingSectionNumber = stockingSectionNumber;
	}

}
