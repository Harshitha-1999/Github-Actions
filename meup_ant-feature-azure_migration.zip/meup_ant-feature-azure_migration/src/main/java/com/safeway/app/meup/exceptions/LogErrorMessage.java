
package com.safeway.app.meup.exceptions;

public class LogErrorMessage {



    /**
     * Logging error.
     */
    public static final String START_LOG_ERR = "An error occurred while logging the information at the start of";

    /**
     * Logging error.
     */
    public static final String END_LOG_ERR = "An error occurred while logging the information at the end of";

    /**
     * Exception while blocking an item.
     */
    public static final String BLOCK_ITEM_EXCEPTION ="An Exception Occured while Blocking the items.";

    /**
     * While accessing unallocated delegate exception.
     */
    public static final String UNALLOCATED_DELEGATE = "Failed to create unallocated Controller";
    /**
     * No such method exists.
     */
    public static final String NO_SUCH_METHOD_MSG = "NoSuchMethodException occurred in comparator";
    public static final String NO_SEARCH_CRITERIA = "No groups selected for search";

    /**
     * For illegal arguments.
     */
    public static final String ILLEGAL_ARGUMENT_MSG = "IllegalArgumentException occurred in comparator";

    /**
     * For illegal access.
     */
    public static final String ILLEGAL_ACCESS_MSG = "IllegalAccessException occurred in comparator";

    /**
     * Comparator invocation exception.
     */
    public static final String INVOCATION_TARGET_MSG = "InvocationTargetException occurred in comparator";

    /**
     * Modify date exception.
     */
    public static final String MODIFY_DATE_EXCEPTION = "An Exception occured while Modifying the delete date.";

    /**
     * Unblock item exception.
     */
    public static final String UNBLOCK_ITEM_EXCEPTION = "An Exception occured while Unblocking the items.";

    /**
     * Getting the items exception.
     */
    public static final String GET_STOREITEMS_EXCEPTION = "An Exception occured while retrieving storeitems to update.";

    /**
     * Fetching smicgroup exception.
     */
    public static final String GET_SMICGROUP_EXCEPTION = "An Exception occured while retrieving the smicgroup.";

    /**
     * Fetching smic category exception.
     */
    public static final String GET_SMICCATEGORY_EXCEPTION = "An Exception occurred while retrieving the SmicCategory.";

    /**
     * Fetching divisions exception.
     */
    public static final String GET_DIVISIONS_EXCEPTION = "An Exception Occurred While Getting the Divisions.";

    public static final String ERROR_LOADING_PAGE = "An Exception occured while loading the page";

    public static final String GET_STOCKDIV_EXCEPTION = "An Exception Occured While Getting the Divisions and Stockingsections";

    public static final String FAIL_LOAD_EXCEL = "Failed to load the excel";

    public static final String CLASS_NOT_FOUND = "Class Not Found Exception when trying to load";

    public static final String MEUP_ITEM_EXCEL_DOWNLOAD_ERROR = "An unexpected error occurred while retrieving data for store items for Excel Download.";

    public static final String ROW_LIMIT_EXCEEDED = "Row limit exceeded";

    public static final String FAIL_ADD_ROW = "Failed to add row";

    public static final String FAIL_WRITE_RESPONSE = "Failed to write response";

    public static final String FAIL_CREATE_WORKBOOK = "Failed to create workBook";

    public static final String DIVISION_LOADING_EXCEPTION = "Failed to load the divisions";

    /**
     * failed to get the statement.
     */
    public static final String CLOSE_STATEMENT_EXCEPTION = "Failed to close statement";

    /**
     * failed to get the result set.
     */
    public static final String CLOSE_RESULTSET_EXCEPTION = "Failed to close ResultSet";

    /**
     * failed to get the connection.
     */
    public static final String GET_CONNECTION_EXCEPTION = "Failed to getConnection";

    public static final String SMICGROUP_EXCEPTION = "An Exception occured while retrieving the smicgroup.";

    public static final String SMICCATEGORY_EXCEPTION = "An Exception occured while retrieving the SmicCategory.";

    /**
     * failed to close the hibernate session.
     */
    public static final String SESSION_CLOSE_EXCEPTION = "Failed to close session";

    public static final String INSERT_COMMENT_EXCEPTION = "Failed to insert comments";

    public static final String UPDATE_BLOCKEDITEM_EXCEPTION = "Failed to update the Blocked item";

    public static final String SEARCH_EXCEPTION = "Failed to update the Blocked item";

    public static final String VIEW_REPORT_EXCEPTION = "Failed to view report";

    public static final String CREATE_REPORT_EXCEPTION = "Failed to create report";

    public static final String HISTORY_REPORT_EXCEPTION = "Failed to create history repor";

    /**
     * Invalid date
     */
    public static final String INVALID_DATE_EXCEPTION = "invalid date exception";

    /**
     * failed to upload the file.
     */
    public static final String UPLOAD_FAILURE = "Exception occurred while uploading file.";
    /**
     * failed to download the file.
     */
    public static final String DOWNLOAD_FAILURE = "Exception occurred while downloading file.";

    /**
     * failed to update the staging header table.
     */
    public static final String UPDATE_STAGING_HEADER_EXCEPTION = "Failed to update staging header.";

    /**
     * failed to get the corp value for the corresponding division.
     */
    public static final String GET_CORP_EXCEPTION = "Failed to get the corp value";

    /**
     * failed to update the staging store table.
     */
    public static final String UPDATE_STAGING_STORE_EXCEPTION = "Failed to update staging Store.";

    /**
     * failed to update the staging item table.
     */
    public static final String UPDATE_STAGING_ITEM_EXCEPTION = "Failed to update staging Item.";

    /**
     * failed to update the staging error table.
     */
    public static final String UPDATE_STAGING_ERROR_EXCEPTION ="Failed to update staging Error.";

    /**
     * Failed to insert to history table .
     */
    public static final String HISTORY_INSERT_EXCEPTION = "Failed to insert history data";

    /**
     * EXception while fetching the history
     */
    public static final String GET_HISTORY_EXCEPTION = "An Exception occured while retrieving the history.";

    /**
     * Exception while fetching the report.
     */
    public static final String GET_REPORT_EXCEPTION = "An Exception occured while retrieving the report.";

    /**
     * Exception while inserting into the master table
     */
    public static final String MASTER_INSERT_EXCEPTION = "Failed to insert master data";

    /**
     * Exception while fetching the items
     */
    public static final String ITEM_LOADING_EXCEPTION =" Failed to fetch the Items ";

    /**
     * Exception while fetching the stores
     */
    public static final String STORE_FETCH_EXCEPTION ="Failed to fetch the stores for the division ";

    /**
     * Exception to handle Deadlock in Update StoreItems.
     */
    public static final String DB_DEADLOCK_913 = "Please revisit the changes. It has been modified by another user.";

    /**
     * Exception to handle time out condition for Update store items and
     * View Store Items Report .
     */
    //TODO
    public static final String TIMEOUT_EXCEPTION = "More than 4000 items have been fetched.Please refine your search.";
    /**
     * The variable which holds the message while unblocking data.
     */
    public static final String DEADLOCK_MESSAGE = "Please try after some time.";

}
