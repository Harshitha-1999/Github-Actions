package com.safeway.app.meup.vox;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@Embeddable
public class StoreItemHistoryVOID implements Serializable {
    /**
     * lastUpdatedTimeStamp holds the last updated time stamp.
     */
    @Column(name = "last_upd_ts", insertable = false, nullable = false)
    String lastUpdatedTimeStamp;
    /**
     * corp value.
     */
    @Column(name = "corp")
    private String corp;
    /**
     * division holds the division number.
     */
    @Column(name = "div")
    private String division;
    /**
     * storeNumber holds the store number.
     */
    @Column(name = "fac")
    private String storeNumber;
    /**
     * cic holds CIC value.
     */
    @Column(name = "corp_item_cd")
    private BigDecimal cic;
    /**
     * dc holds the distribution center value.
     */
    @Column(name = "dst_cntr")
    private String dc;

}
