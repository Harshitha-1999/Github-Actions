package com.safeway.app.meup.controller;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.DivisionService;
import com.safeway.app.meup.vox.StockingSectionVO;

@RestController
public class UnallocatedController extends BaseController {
	private static final Logger log = LoggerFactory.getLogger(UnallocatedController.class);

	@Autowired
	DivisionService divisionService;

	/**
	 * method for getting the divisions.
	 *
	 * @return a List having divisionDto
	 * @throws MeupException exception
	 */
	@GetMapping("/v1/divisions/us")
	public ResponseDTO getDivisionList() {
		log.info("--> UnallocatedController.getDivisionList");
		List<DivisionDTO> divisionList = divisionService.getDivisionList();
		ResponseDTO responseDTO = getResponseDTO(divisionList);
		return responseDTO;
	}

	/**
	 * Method for getting the division list on hold
	 *
	 * @param corp
	 * @param groupCode
	 * @param stockingSectionList
	 * @param itemStateCode
	 * @param blockedStatusCode
	 * @return
	 * @throws SQLException
	 * @throws MeupException
	 */
	@GetMapping("/v1/divisions/hold")
	public ResponseDTO getDivisionListOnHold(@RequestParam String corp, @RequestParam String groupCode,
			@RequestParam List<StockingSectionVO> stockingSectionList, @RequestParam char itemStateCode,
			@RequestParam char blockedStatusCode) throws MeupException, SQLException {
		log.info("--> UnallocatedController.getDivisionListOnHold");
		List<DivisionDTO> divisionList = divisionService.getDivisionListOnHold(corp, groupCode, stockingSectionList,
				itemStateCode, blockedStatusCode);

		ResponseDTO responseDTO = getResponseDTO(divisionList);
		return responseDTO;

	}

	/**
	 * Method for getting the division list for US code
	 *
	 * @param corp
	 * @return
	 */
	@GetMapping("/v1/divisions")
	public ResponseDTO getDivisionListForUS(@RequestParam("corpCd") String corp) {
		log.info("--> UnallocatedController.getDivisionListForUS");
		List<DivisionDTO> divisionList = divisionService.getDivisionListForUS(corp);
		ResponseDTO responseDTO = getResponseDTO(divisionList);
		return responseDTO;
	}

	@RequestMapping(value = "/healthCheck", method = RequestMethod.GET)
	public String health() {
		log.info("Request recieved for health check, Application is UP");
		return "MEUP App is up.";
	}

}
