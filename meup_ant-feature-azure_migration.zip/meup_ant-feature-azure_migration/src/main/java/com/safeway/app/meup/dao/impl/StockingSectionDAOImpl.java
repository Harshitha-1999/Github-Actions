package com.safeway.app.meup.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.safeway.app.meup.dao.StockingSectionDAO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.StockingSectionDTO;
import com.safeway.app.meup.exceptions.LogErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;

@Repository
@PropertySource(value = { "classpath:/sql.properties" })
public class StockingSectionDAOImpl implements StockingSectionDAO {

	@Autowired
	@Qualifier("snowFlakDatasource")
	JdbcTemplate snowflakejdbctemplate;

	@Value("${sql.getStockingSection}")
	private String getStockingSection;

	private static final Logger log = LoggerFactory.getLogger(StockingSectionDAOImpl.class);

	public List<StockingSectionDTO> getStockSectionListByGroupStatus(String corp, String groupCode, char itemStateCode,
			char blockedStatusCode) throws MeupException, SQLException {
		log.info("|---> Beginning Method StoreDAOImpl.getStockSectionListByGroupStatus" + "getStockSectionListByGroupStatus");
		List<StockingSectionDTO> stockSectionListByGroupStatus = new ArrayList<>();
		log.info("|---> DB Call Started for Method StoreDAOImpl.getStockSectionListByGroupStatus" + "getStockSectionListByGroupStatus");
		stockSectionListByGroupStatus = snowflakejdbctemplate.query(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement stmnt = con.prepareStatement(getStockingSection);
				stmnt.setString(1, corp);
				stmnt.setString(2, Character.toString(itemStateCode));
				stmnt.setString(3, Character.toString(blockedStatusCode));
				return stmnt;
			}
		}, new RowMapper<StockingSectionDTO>() {

			@Override
			public StockingSectionDTO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
				StockingSectionDTO stockingSectionDTO = new StockingSectionDTO();
				stockingSectionDTO.setStockingSectionNumber(resultSet.getString("STOCK_SECT_NBR"));
				stockingSectionDTO.setStockingSectionDesc(resultSet.getString("STOCK_SECT_NM"));
				return stockingSectionDTO;
			}

		});
		log.info("|---> DB Call ended for Method StoreDAOImpl.getStockSectionListByGroupStatus" + "getStockSectionListByGroupStatus");
		log.info("|---> End of Method StoreDAOImpl.getStockSectionListByGroupStatus" + "getStockSectionListByGroupStatus");

		return stockSectionListByGroupStatus;

	}

}
