package com.safeway.app.meup.vox;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * The primary key class for the MEUPSTGE database table.
 */
@Embeddable
public class StagingErrorVOID implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "CORP")
    private String corp;
    @Column(name = "DIV")
    private String div;
    @Column(name = "UPLOAD_USER_ID")
    private String userId;
    @Column(name = "UPLOAD_TS")
    private Timestamp errorUploadTs;
    @Column(name = "CORP_ITEM_CD")
    private BigDecimal cic;
    @Column(name = "FAC")
    private String fac;
    @Column(name = "UPC_SALES")
    private BigDecimal upcSales;
    @Column(name = "UPC_MANUF")
    private BigDecimal upcManuf;
    @Column(name = "UPC_SYSTEM")
    private BigDecimal upcSystem;
    @Column(name = "UPC_COUNTRY")
    private BigDecimal upcCountry;

    public String getCorp() {
        return corp;
    }

    public void setCorp(String corp) {
        this.corp = corp;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getErrorUploadTs() {
        return errorUploadTs;
    }

    public void setErrorUploadTs(Timestamp errorUploadTs) {
        this.errorUploadTs = errorUploadTs;
    }

    public BigDecimal getCic() {
        return cic;
    }

    public void setCic(BigDecimal cic) {
        this.cic = cic;
    }

    public String getFac() {
        return fac;
    }

    public void setFac(String fac) {
        this.fac = fac;
    }

    public BigDecimal getUpcSales() {
        return upcSales;
    }

    public void setUpcSales(BigDecimal upcSales) {
        this.upcSales = upcSales;
    }

    public BigDecimal getUpcManuf() {
        return upcManuf;
    }

    public void setUpcManuf(BigDecimal upcManuf) {
        this.upcManuf = upcManuf;
    }

    public BigDecimal getUpcSystem() {
        return upcSystem;
    }

    public void setUpcSystem(BigDecimal upcSystem) {
        this.upcSystem = upcSystem;
    }

    public BigDecimal getUpcCountry() {
        return upcCountry;
    }

    public void setUpcCountry(BigDecimal upcCountry) {
        this.upcCountry = upcCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StagingErrorVOID errorVOID = (StagingErrorVOID) o;

        if (!corp.equals(errorVOID.corp)) return false;
        if (!div.equals(errorVOID.div)) return false;
        if (!userId.equals(errorVOID.userId)) return false;
        if (!errorUploadTs.equals(errorVOID.errorUploadTs)) return false;
        if (!cic.equals(errorVOID.cic)) return false;
        if (!fac.equals(errorVOID.fac)) return false;
        if (!upcSales.equals(errorVOID.upcSales)) return false;
        if (!upcManuf.equals(errorVOID.upcManuf)) return false;
        if (!upcSystem.equals(errorVOID.upcSystem)) return false;
        return upcCountry.equals(errorVOID.upcCountry);
    }

    @Override
    public int hashCode() {
        int result = corp.hashCode();
        result = 31 * result + div.hashCode();
        result = 31 * result + userId.hashCode();
        result = 31 * result + errorUploadTs.hashCode();
        result = 31 * result + cic.hashCode();
        result = 31 * result + fac.hashCode();
        result = 31 * result + upcSales.hashCode();
        result = 31 * result + upcManuf.hashCode();
        result = 31 * result + upcSystem.hashCode();
        result = 31 * result + upcCountry.hashCode();
        return result;
    }
}
