package com.safeway.app.meup.dao.impl;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.safeway.app.meup.dao.StagingHdrDAO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.util.MeupLogUtil;
import com.safeway.app.meup.vox.StagingErrorVO;
import com.safeway.app.meup.vox.StagingHdrVO;
import com.safeway.app.meup.vox.StagingItemVO;

@Repository
public class StagingHdrDAOImpl implements StagingHdrDAO {

	 private static final Logger log = LoggerFactory.getLogger(StagingHdrDAOImpl.class);


    @Autowired
    @Qualifier("defaultSession")
    SessionFactory defaultsessionFactory;
    
    @Autowired
	@Qualifier("db2DS")
	NamedParameterJdbcTemplate namedParameterjdbcTemplate;
    
    @Value("${schema.default}")
    private String schemaUS;
    
    
    public Session getSession() {
        return defaultsessionFactory.getCurrentSession();
    }

    /**
     * This method will get the hibernate connection.
     * Method will upload the items for the header part
     * into the the table staging header and call the method saveOrUpdate.
     *
     * @param stagingHdr business object for the StagingHdr.
     * @throws MeupException
     */
    @Override
    @Transactional
    public void insertStagingHdr(StagingHdrVO stagingHdr) throws MeupException {
        log.info("|---> Beginning Method StagingHdrDaoImpl.insertStagingHdr");
        long startTime = MeupLogUtil.currentTime();
        log.debug(MeupLogUtil.startLog(this.getClass().getName(), "storeItems"));
        try {
            List<StagingItemVO> stagingItemVOList = stagingHdr.getStagingItemList();
            stagingHdr.setStagingItemList(null);
            List<StagingErrorVO> stagingErrorVOList = stagingHdr.getStagingErrorList();
            stagingHdr.setStagingErrorList(null);
            insertStagingStoreList(stagingHdr);
            insertStagingItems(stagingItemVOList);
            insertStagingErrorItems(stagingErrorVOList);
            long endTime = MeupLogUtil.currentTime();
            log.debug(MeupLogUtil.endLog(this.getClass().getName(), "storeItems", endTime - startTime));
            log.info("<---| Completed Method StagingHdrDaoImpl.insertStagingHdr.");
        } catch (Exception exception) {
            log.error("Error while insertStagingHdr : " + exception.getMessage());
            throw new MeupException("Error while insertStagingHdr : " + exception.getMessage());
        } finally {
            getSession().clear();
        }
    }

    protected void insertStagingStoreList(StagingHdrVO stagingHdr) throws MeupException {
        log.info("|---> Beginning Method StagingHdrDaoImpl.insertStagingStoreList");
        int result[] = namedParameterjdbcTemplate.getJdbcTemplate().batchUpdate(
                "insert into "+schemaUS+".MEUPSTGH (BLOCKED_TARGET_DT, CORP, DIV, UPLOAD_TS, UPLOAD_USER_ID) values (?, ?, ?, ?, ?)",
                new BatchPreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        ps.setDate(1, new java.sql.Date (stagingHdr.getDeleteDt().getTime()));
                        ps.setString(2, stagingHdr.getStagingHdrID().getCorp());
                        ps.setString(3, stagingHdr.getStagingHdrID().getDiv());
                        ps.setTimestamp(4, stagingHdr.getStagingHdrID().getUploadTs());
                        ps.setString(5, stagingHdr.getStagingHdrID().getUserId());
                    }
                    @Override
                    public int getBatchSize() {
                        return 1;
                    }
                });
        int result1[] = namedParameterjdbcTemplate.getJdbcTemplate().batchUpdate(
                "insert into "+schemaUS+".MEUPSTGF (CORP, DIV, FAC, UPLOAD_TS, UPLOAD_USER_ID) values (?, ?, ?, ?, ?)",
                new BatchPreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        ps.setString(1, stagingHdr.getStagingHdrID().getCorp());
                        ps.setString(2, stagingHdr.getStagingHdrID().getDiv());
                        ps.setString(3, stagingHdr.getStagingStoreList().get(0).getStagingStoreItemVOID().getFac());
                        ps.setTimestamp(4, stagingHdr.getStagingHdrID().getUploadTs());
                        ps.setString(5, stagingHdr.getStagingHdrID().getUserId());
                    }
                    @Override
                    public int getBatchSize() {
                        return 1;
                    }
                });
    }


    protected void insertStagingItems(List<StagingItemVO> stagingItemVOList) throws MeupException {
        log.info("|---> Beginning Method StagingHdrDaoImpl.insertStagingItems {}",stagingItemVOList.get(0).getStagingItemVOID().getStageItemUploadTs());
        int result[] = namedParameterjdbcTemplate.getJdbcTemplate().batchUpdate(
                "insert into "+schemaUS+".MEUPSTGI (CORP_ITEM_CD, CORP, DIV, UPLOAD_TS, UPC_COUNTRY, UPC_MANUF, UPC_SALES, UPC_SYSTEM, UPLOAD_USER_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                new BatchPreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        ps.setBigDecimal(1, stagingItemVOList.get(i).getStagingItemVOID().getCic());
                        ps.setString(2, stagingItemVOList.get(i).getStagingItemVOID().getCorp());
                        ps.setString(3, stagingItemVOList.get(i).getStagingItemVOID().getDiv());
                        ps.setTimestamp(4, stagingItemVOList.get(i).getStagingItemVOID().getStageItemUploadTs());
                        ps.setBigDecimal(5, stagingItemVOList.get(i).getStagingItemVOID().getUpcCountry());
                        ps.setBigDecimal(6, stagingItemVOList.get(i).getStagingItemVOID().getUpcManuf());
                        ps.setBigDecimal(7, stagingItemVOList.get(i).getStagingItemVOID().getUpcSales());
                        ps.setBigDecimal(8, stagingItemVOList.get(i).getStagingItemVOID().getUpcSystem());
                        ps.setString(9, stagingItemVOList.get(i).getStagingItemVOID().getUserId());
                    }
                    @Override
                    public int getBatchSize() {
                        return stagingItemVOList.size();
                    }
                });
        log.info("StagingItemVO result size : {}", result.length);
    }

    protected void insertStagingErrorItems(List<StagingErrorVO> stagingErrorVOList) {
    	
    	int result[] = namedParameterjdbcTemplate.getJdbcTemplate().batchUpdate(
                "insert into "+schemaUS+".MEUPSTGE (ERR_DSC, CORP_ITEM_CD, CORP, DIV, UPLOAD_TS, FAC, UPC_COUNTRY, UPC_MANUF, UPC_SALES, UPC_SYSTEM, UPLOAD_USER_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                new BatchPreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        ps.setString(1, stagingErrorVOList.get(i).getErrDesc());
                        ps.setBigDecimal(2, stagingErrorVOList.get(i).getStagingErrorVOID().getCic());
                        ps.setString(3, stagingErrorVOList.get(i).getStagingErrorVOID().getCorp());
                        ps.setString(4, stagingErrorVOList.get(i).getStagingErrorVOID().getDiv());
                        ps.setTimestamp(5, stagingErrorVOList.get(i).getStagingErrorVOID().getErrorUploadTs());
                        ps.setString(6,stagingErrorVOList.get(i).getStagingErrorVOID().getFac());
                        ps.setBigDecimal(7, stagingErrorVOList.get(i).getStagingErrorVOID().getUpcCountry());
                        ps.setBigDecimal(8, stagingErrorVOList.get(i).getStagingErrorVOID().getUpcManuf());
                        ps.setBigDecimal(9, stagingErrorVOList.get(i).getStagingErrorVOID().getUpcSales());
                        ps.setBigDecimal(10, stagingErrorVOList.get(i).getStagingErrorVOID().getUpcSystem());
                        ps.setString(11, stagingErrorVOList.get(i).getStagingErrorVOID().getUserId());
                    }
                    @Override
                    public int getBatchSize() {
                        return stagingErrorVOList.size();
                    }
                });
        log.info("StagingErrorVO result size : {}", result.length);
    }
}
