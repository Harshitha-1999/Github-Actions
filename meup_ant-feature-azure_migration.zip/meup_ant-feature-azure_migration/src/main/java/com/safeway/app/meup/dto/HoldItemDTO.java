
package com.safeway.app.meup.dto;

import java.util.Date;


public class HoldItemDTO extends SerializableDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * variable corp
	 */
	private int corp;

	/**
	 * variable upcID
	 */
	private long upcID;

	/**
	 * variable cic
	 */
	private int cic;

	/**
	 * variable desc
	 */

	private String desc;

	/**
	 * variable stockSectionNbr
	 */

	private int stockSectionNbr;

	/**
	 * variable schematicEffectiveDate
	 */
	private Date schematicEffectiveDate;

	/**
	 * variable storeID
	 */
	private int storeID;

	/**
	 * variable divisionNbr
	 */
	private int divisionNbr;

	/**
	 * variable status
	 */
	private String status;

	
	private String temp;
	
	
	/**
	 * @return the cic
	 */
	public int getCic() {
		return cic;
	}

	/**
	 * @param cic
	 *            the cic to set
	 */
	public void setCic(int cic) {
		this.cic = cic;
	}

	/**
	 * @return the corp
	 */
	public int getCorp() {
		return corp;
	}

	/**
	 * @param corp
	 *            the corp to set
	 */
	public void setCorp(int corp) {
		this.corp = corp;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the divisionNbr
	 */
	public int getDivisionNbr() {
		return divisionNbr;
	}

	/**
	 * @param divisionNbr
	 *            the divisionNbr to set
	 */
	public void setDivisionNbr(int divisionNbr) {
		this.divisionNbr = divisionNbr;
	}

	/**
	 * @return the schematicEffectiveDate
	 */
	public Date getSchematicEffectiveDate() {
		return schematicEffectiveDate;
	}

	/**
	 * @param schematicEffectiveDate
	 *            the schematicEffectiveDate to set
	 */
	public void setSchematicEffectiveDate(Date schematicEffectiveDate) {
		this.schematicEffectiveDate = schematicEffectiveDate;
	}

	/**
	 * @return the stockSectionNbr
	 */
	public int getStockSectionNbr() {
		return stockSectionNbr;
	}

	/**
	 * @param stockSectionNbr
	 *            the stockSectionNbr to set
	 */
	public void setStockSectionNbr(int stockSectionNbr) {
		this.stockSectionNbr = stockSectionNbr;
	}

	/**
	 * @return the storeID
	 */
	public int getStoreID() {
		return storeID;
	}

	/**
	 * @param storeID
	 *            the storeID to set
	 */
	public void setStoreID(int storeID) {
		this.storeID = storeID;
	}

	/**
	 * @return the upcID
	 */
	public long getUpcID() {
		return upcID;
	}

	/**
	 * @param upcID
	 *            the upcID to set
	 */
	public void setUpcID(long upcID) {
		this.upcID = upcID;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		if(null!=status){
			temp=status;
			this.status = temp;
		}
		if(null==status && "A".equals(temp)){
			this.status = temp;
		}
	}

}
