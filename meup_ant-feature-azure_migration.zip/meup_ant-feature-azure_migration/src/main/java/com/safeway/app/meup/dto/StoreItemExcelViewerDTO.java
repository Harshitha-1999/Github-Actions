
package com.safeway.app.meup.dto;


import com.safeway.app.meup.dto.SerializableDTO;



public class StoreItemExcelViewerDTO extends SerializableDTO{

	/**To store the division Number.*/
	private String divisionNumber;

	/**Holds the store Number.*/
	private String storeNumber;

	/**Holdse the category Name. */
	private String categoryName;

	/**Holds the upc */
	private String upc;

	/**Holds the cic */
	private String cic;

	/**Holds the description */
	private String description;

	/**Holds the itemType */
	private String itemType;

	/**Holds the size */
	private float size;

	/**Holds the uom */
	private String uom;

	/**Holds the casePk */
	private float casePk;

	/**Holds the state */
	private String state;

	/**Holds the stateEffectiveDate */
	private String stateEffectiveDate;

	/**Holds the status */
	private String blockedStatus;

	/**Holds the blockedTargetDate */
	private String blockedTargetDate;

	/**
	 * @return Returns the blockedTargetDate.
	 */
	public String getBlockedTargetDate() {
		return blockedTargetDate;
	}
	/**
	 * @param blockedTargetDate The blockedTargetDate to set.
	 */
	public void setBlockedTargetDate(String blockedTargetDate) {
		this.blockedTargetDate = blockedTargetDate;
	}
	/**
	 * @return Returns the casePk.
	 */
	public float getCasePk() {
		return casePk;
	}
	/**
	 * @param casePk The casePk to set.
	 */
	public void setCasePk(float casePk) {
		this.casePk = casePk;
	}
	/**
	 * @return Returns the categoryName.
	 */
	public String getCategoryName() {
		return categoryName;
	}
	/**
	 * @param categoryName The categoryName to set.
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	/**
	 * @return Returns the cic.
	 */
	public String getCic() {
		return cic;
	}
	/**
	 * @param cic The cic to set.
	 */
	public void setCic(String cic) {
		this.cic = cic;
	}
	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return Returns the divisionNumber.
	 */
	public String getDivisionNumber() {
		return divisionNumber;
	}
	/**
	 * @param divisionNumber The divisionNumber to set.
	 */
	public void setDivisionNumber(String divisionNumber) {
		this.divisionNumber = divisionNumber;
	}
	/**
	 * @return Returns the itemType.
	 */
	public String getItemType() {
		return itemType;
	}
	/**
	 * @param itemType The itemType to set.
	 */
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	/**
	 * @return Returns the size.
	 */
	public float getSize() {
		return size;
	}
	/**
	 * @param size The size to set.
	 */
	public void setSize(float size) {
		this.size = size;
	}
	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return Returns the stateEffectiveDate.
	 */
	public String getStateEffectiveDate() {
		return stateEffectiveDate;
	}
	/**
	 * @param stateEffectiveDate The stateEffectiveDate to set.
	 */
	public void setStateEffectiveDate(String stateEffectiveDate) {
		this.stateEffectiveDate = stateEffectiveDate;
	}

	/**
	 * @return Returns the blockedStatus.
	 */
	public String getBlockedStatus() {
		return blockedStatus;
	}
	/**
	 * @param blockedStatus The blockedStatus to set.
	 */
	public void setBlockedStatus(String blockedStatus) {
		this.blockedStatus = blockedStatus;
	}
	/**
	 * @return Returns the storeNumber.
	 */
	public String getStoreNumber() {
		return storeNumber;
	}
	/**
	 * @param storeNumber The storeNumber to set.
	 */
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}
	/**
	 * @return Returns the uom.
	 */
	public String getUom() {
		return uom;
	}
	/**
	 * @param uom The uom to set.
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}
	/**
	 * @return Returns the upc.
	 */
	public String getUpc() {
		return upc;
	}
	/**
	 * @param upc The upc to set.
	 */
	public void setUpc(String upc) {
		this.upc = upc;
	}
	/**
	 * @return Returns the log.
	 */


}
