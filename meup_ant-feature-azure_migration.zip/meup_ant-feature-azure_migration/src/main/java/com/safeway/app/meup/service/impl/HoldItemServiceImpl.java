
package com.safeway.app.meup.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/*******************************************************************************
 *
 * NAME : HoldItemMgrImpl.java
 *
 * SYSTEM : Unallocated Item Blocking
 *
 * REVISION HISTORY
 *
 * Revision 1.0 Balu Nair Initial version
 *
 ******************************************************************************/

import com.safeway.app.meup.dao.DivisionDAO;
import com.safeway.app.meup.dao.StockingSectionDAO;
import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.HoldSearchFieldsDTO;
import com.safeway.app.meup.dto.ItemCountsByStoreDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.ResponseStockingSectionDTO;
import com.safeway.app.meup.dto.StockingSectionDTO;
import com.safeway.app.meup.exceptions.ErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.HoldItemsService;
import com.safeway.app.meup.util.MeupLogUtil;

@Service
public class HoldItemServiceImpl implements HoldItemsService {

	private static final Log log = LogFactory.getLog(HoldItemServiceImpl.class);
	@Autowired
	private DivisionDAO divisionDAO;
	@Autowired
	private StockingSectionDAO stockingSectionDao;

	@Autowired
	private StoreItemDAO storeItemDAO;

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public HoldSearchFieldsDTO getStockSectionDivisionOnHold(String corp, String groupCode)
			throws MeupException, SQLException {
		log.info("|---> Beginning Method HoldItemServiceImpl" + ".getStockSectionDivisionOnHold");

		log.debug(MeupLogUtil.startLog(this.getClass().getName(), " getStockSectionDivisionOnHold"));
		HoldSearchFieldsDTO fieldsVOX = new HoldSearchFieldsDTO();
		if (corp != null && !"".equals(corp)) {
			// && groupCode != null && !"".equals(groupCode)) {
			List<StockingSectionDTO> stockingSectionList = stockingSectionDao.getStockSectionListByGroupStatus(corp,
					groupCode, 'H', 'H');

			List<DivisionDTO> divisionList = divisionDAO.getDivisionListByStatus(corp, groupCode, null, 'H', 'H');
			fieldsVOX.setGroupCode(groupCode);
			fieldsVOX.setStockingSectionList(stockingSectionList);
			fieldsVOX.setDivisionList(divisionList);
		}
		log.info("|---> End of Method HoldItemServiceImpl" + ".getStockSectionDivisionOnHold");
		return fieldsVOX;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO getItemCountsOnHold(String corp, List<String> stockingSectionList, List<String> divisionList)
			throws MeupException, SQLException {
		log.debug("--> HoldItemServiceImpl.getItemCountsOnHold");

		// String userID = null;
		List<ItemCountsByStoreDTO> itemCountsByStoreDtoList = storeItemDAO.getItemCountsOnHold(corp,
				stockingSectionList, divisionList);

		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
		HashMap<String, Object> mapData = new HashMap<>();
		mapData.put(ResponseDTO.REST_DATA, itemCountsByStoreDtoList);
		responseDTO.setData(mapData);
		return responseDTO;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<HoldItemDTO> getItemListForStoreStockSection(String corp, String storeID, String stockSectionNbr)
			throws MeupException, SQLException {
		log.debug("--> HoldItemServiceImpl.getItemListForStoreStockSection");
		List<HoldItemDTO> holdItemList = storeItemDAO.getItemListForStoreStockSection(corp, storeID, stockSectionNbr);

		return holdItemList;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO updateItemsStoreLevel(ResponseStockingSectionDTO responseStockingSectionDTO)
			throws MeupException, SQLException {
		log.info("-->Beginning- HoldItemServiceImpl.updateItemsStoreLevel");
		ResponseDTO responseDTO = new ResponseDTO();
		List<HoldItemDTO> acceptList = new ArrayList<>();
		List<HoldItemDTO> rejectList = new ArrayList<>();
		String userID = responseStockingSectionDTO.getUserID();
		responseStockingSectionDTO.getAcceptList().stream().forEach(accept -> {
			acceptList.add(accept);
		});
		responseStockingSectionDTO.getRejectList().stream().forEach(reject -> {
			rejectList.add(reject);
		});

		if (null != acceptList && !acceptList.isEmpty()) {
			storeItemDAO.updateItemsByStoreStockingSection(acceptList, userID);
		}
		if (null != rejectList && !rejectList.isEmpty()) {
			storeItemDAO.updateItemsByStoreStockingSection(rejectList, userID);
		}

		log.info("-->Completed- HoldItemServiceImpl.updateItemsStoreLevel");
		Map<String, Object> data = new HashMap<>();
		data.put(ResponseDTO.REST_DATA, ErrorMessage.UPDATE_SUCCESSFUL);
		responseDTO.setStatus("SUCCESS");
		responseDTO.setData(data);

		return responseDTO;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public ResponseDTO updateItemsByStoreStockSection(ResponseStockingSectionDTO responseStockingSectionDTO,
			String groupID) throws MeupException, SQLException {
		log.info("<--Beginning- HoldItemServiceImpl.updateItemsByStoreStockSection");
		log.debug("<-- HoldItemServiceImpl.updateItemsByStoreStockSection");
		ResponseDTO responseDTO = new ResponseDTO();
		List<HoldItemDTO> acceptList = new ArrayList<>();
		List<HoldItemDTO> rejectList = new ArrayList<>();
		String userID = responseStockingSectionDTO.getUserID();
		Iterator itemListItr = responseStockingSectionDTO.getAcceptList().iterator();
		while (itemListItr.hasNext()) {
			HoldItemDTO holdItemDto = (HoldItemDTO) itemListItr.next();

			acceptList.add(holdItemDto);
		}
		Iterator itemListItr2 = responseStockingSectionDTO.getRejectList().iterator();
		while (itemListItr2.hasNext()) {
			HoldItemDTO holdItemDto = (HoldItemDTO) itemListItr2.next();

			rejectList.add(holdItemDto);
		}
		if (null != acceptList && !acceptList.isEmpty()) {
			storeItemDAO.updateItemsByStoreStockSection(acceptList, userID, groupID);
		}
		if (null != rejectList && !rejectList.isEmpty()) {
			storeItemDAO.updateItemsByStoreStockSection(rejectList, userID, groupID);
		}
		log.debug("<-- HoldItemServiceImpl.updateItemsByStoreStockSection");

		Map<String, Object> data = new HashMap<>();
		data.put(ResponseDTO.REST_DATA, ErrorMessage.UPDATE_SUCCESSFUL);
		responseDTO.setStatus("SUCCESS");
		responseDTO.setData(data);
		log.info("<--Completed- HoldItemServiceImpl.updateItemsByStoreStockSection");

		return responseDTO;
	}

}
