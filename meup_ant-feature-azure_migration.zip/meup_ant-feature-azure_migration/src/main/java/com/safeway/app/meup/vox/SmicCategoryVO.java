
package com.safeway.app.meup.vox;



public class SmicCategoryVO {

	/**holds the category code.*/
	private String categoryCd;

	/**holds the category name.*/
	private String categoryName;

	/**holds the group code.*/
	private String groupCd;

	/**
	 * @return Returns the dispCategory.
	 */
	public String getDispCategory() {
		return categoryCd+"-"+categoryName;
	}

	/**
	 * @return Returns the categoryCd.
	 */
	public String getCategoryCd() {
		return categoryCd;
	}

	/**
	 * @param categoryCd The categoryCd to set.
	 */
	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}

	/**
	 * @return Returns the categoryName.
	 */
	public String getCategoryName() {
		return categoryName;
	}

	/**
	 * @param categoryName The categoryName to set.
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	/**
	 * @return Returns the groupCd.
	 */
	public String getGroupCd() {
		return groupCd;
	}

	/**
	 * @param groupCd The groupCd to set.
	 */
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
}
