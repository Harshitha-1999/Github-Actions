package com.safeway.app.meup.vox;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import lombok.Data;


@Entity(name = "StoreItemHistoryVO")
@Table(name = "MEUPITMH")
@Data
public class StoreItemHistoryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	StoreItemHistoryVOID storeItemHistoryVOID;

	/**
	 * upcSales holds upc sales value.
	 */
	@Column(name = "UPC_SALES")
	BigDecimal upcSales;

	/**
	 * upcManuf holds upc manufacture value.
	 */
	@Column(name = "UPC_MANUF")
	BigDecimal upcManuf;

	/**
	 * upcSystem holds upc system value.
	 */
	@Column(name = "UPC_SYSTEM")
	BigDecimal upcSystem;

	/**
	 * upcCountry holds upc country value.
	 */
	@Column(name = "UPC_COUNTRY")
	BigDecimal upcCountry;

	/**
	 * state holds the state of an item
	 */
	@Column(name = "state_ind")
	String state;

	/**
	 * stateEffectiveDate holds the blocked on date.
	 */
	@Column(name = "state_eff_dt")
	String stateEffectiveDate;

	/**
	 * blockedStatus holds the blocked status of an item.
	 */
	@Column(name = "blocked_stat_ind")
	String blockedStatus;

	/**
	 * blockedTargetDate holds the deletedate as a value.
	 */
	@Column(name = "blocked_target_dt")
	String blockedTargetDate;

	/**
	 * lastUpdatedUser holds the last updated user Id.
	 */
	@Column(name = "last_upd_user_id")
	String lastUpdatedUser;

	/*
	 * commentImpl holds the CommentImpl.
	 */
	@ManyToOne
	// (cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.ALL})
	@JoinColumn(name = "LAST_UPD_TS", referencedColumnName = "LAST_UPD_TS", nullable = true, insertable = false, updatable = false)
	// , nullable = false, insertable = false, updatable = false
	@JoinColumn(name = "LAST_UPD_USER_ID", referencedColumnName = "LAST_UPD_USER_ID", insertable = false, updatable = false, nullable = true)
	@NotFound(action = NotFoundAction.IGNORE)
	CommentVO comment;
	

}
