package com.safeway.app.meup.vox;




import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Embeddable
public class StoreItemVOID implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * corp value.
     */
    @Column(name = "CORP")
    private String corp;

    /**
     * division holds the division number.
     */
    @Column(name = "div")
    private String division;

    /**
     * storeNumber holds the store number.
     */
    @Column(name = "fac")
    private String storeNumber;

    /**
     * cic holds CIC value.
     */
    @Column(name = "CORP_ITEM_CD")
    private BigDecimal cic;

    /**
     * dc holds the distribution center value.
     */
    @Column(name = "dst_cntr")
    private String dc;

    public StoreItemVOID(String corp, String division, String storeNumber,BigDecimal cic,String dc) {
        this.corp = corp;
        this.division = division;
        this.storeNumber = storeNumber;
        this.cic = cic;
        this.dc = dc;
    }
    public StoreItemVOID(){}


}

