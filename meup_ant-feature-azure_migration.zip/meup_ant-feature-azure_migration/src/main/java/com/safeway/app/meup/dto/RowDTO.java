
package com.safeway.app.meup.dto;

import java.util.ArrayList;
import java.util.List;


public class RowDTO {
	
	/**Holds the list of columns*/
    private List columns = new ArrayList();


    /**
     * @return Returns the columns.
     */
    public List getColumns() {
        return columns;
    }
    
    /**
     * @param columns The columns to set.
     */
    public void setColumns(List columns) {
        this.columns = columns;
    }
}


