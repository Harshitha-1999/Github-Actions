/* ****************************************************************************
 *
 * Copyright 2007, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */
package com.safeway.app.meup.dto;

import java.io.Serializable;
import java.util.Objects;



public class DivisionDTO implements Serializable {


	private static final long serialVersionUID = 1L;

	/** holds the division name. */
	private String divisionName;

	/** holds the division code. */
	private String divisionNumber;

	/** holds the country code. */
	private String corp;

	/**
	 * @return Returns the dispDivision.
	 */
	public String getDispDivision() {
		return divisionNumber + "-" + divisionName;
	}

	/**
	 * @return Returns the corp.
	 */
	public String getCorp() {
		return corp;
	}

	/**
	 * @param corp The corp to set.
	 */
	public void setCorp(String corp) {
		this.corp = corp;
	}

	/**
	 * @return Returns the divisionName.
	 */
	public String getDivisionName() {
		return divisionName;
	}

	/**
	 * @param divisionName The divisionName to set.
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

	/**
	 * @return Returns the divisionNumber.
	 */
	public String getDivisionNumber() {
		return divisionNumber;
	}

	/**
	 * @param divisionNumber The divisionNumber to set.
	 */
	public void setDivisionNumber(String divisionNumber) {
		this.divisionNumber = divisionNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(corp, divisionName, divisionNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DivisionDTO other = (DivisionDTO) obj;
		return Objects.equals(corp, other.corp) && Objects.equals(divisionName, other.divisionName)
				&& Objects.equals(divisionNumber, other.divisionNumber);
	}
	
	
}
