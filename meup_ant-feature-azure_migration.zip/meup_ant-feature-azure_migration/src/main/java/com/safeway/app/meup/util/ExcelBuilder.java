/* ****************************************************************************
 *
 * Copyright 2007, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */
package com.safeway.app.meup.util;


import com.safeway.app.meup.dto.ColumnDTO;
import com.safeway.app.meup.dto.ReportDTO;
import com.safeway.app.meup.dto.RowDTO;
import com.safeway.app.meup.exceptions.MeupException;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

@Component
public class ExcelBuilder {
	private static final Logger LOG = LoggerFactory
			.getLogger(ExcelBuilder.class);


	Workbook wb;
	Sheet dataSheet;

	public void buildReport(ReportDTO report, HttpServletResponse response) throws IOException, MeupException {
		LOG.info("Execution started for writeIntoExcel");
		try {
			wb = new XSSFWorkbook();
			List rows = report.getRows();
			int rowCount = rows.size();
			wb.setMissingCellPolicy(MissingCellPolicy.CREATE_NULL_AS_BLANK);
			dataSheet = wb.createSheet(report.getReportName());
			List headerColumns = report.getColumnHeaders();
			int rowIndex = 0;
			int colIndex = 0;
			int columnSize = headerColumns.size();
			Row headerRow = dataSheet.createRow(0);
			for (int columnIndex = 0; columnIndex < columnSize; columnIndex++) {
				ColumnDTO column = (ColumnDTO) headerColumns.get(columnIndex);
				createCell(headerRow, colIndex++, getHeaderRowStyleTemplate(), column.getValue());
			}
			rowIndex++;
			/* Converts each row from the report Object to Excel Rows*/
			//starting count at 1 to excluse header row
			//getting the row at 0 to get values from first row of DTO
			for (int count = 1; count <= rowCount; count++) {
				RowDTO rowDTO = (RowDTO) rows.get(count - 1);
				List columnList = rowDTO.getColumns();
				int idColumnsCount = columnList.size();
				Row row = dataSheet.createRow(rowIndex++);
				colIndex = 0;
				for (int columnIndex = 0; columnIndex < idColumnsCount; columnIndex++) {

					ColumnDTO column = (ColumnDTO) columnList.get(columnIndex);
					CellStyle rowStyle = getRowStyle(rowIndex);
					/*setting the category/type of the cell*/
					String columnType = "number";
					if (columnType.equals(column.getType())) {
						createCell(row, colIndex++, rowStyle, Double.parseDouble(column.getValue()));
					} else
						createCell(row, colIndex++, rowStyle, column.getValue());
				}
			}

			//setting column width
			for (int columnIndex = 0; columnIndex < columnSize; columnIndex++) {
				ColumnDTO column = (ColumnDTO) headerColumns.get(columnIndex);
				dataSheet.setColumnWidth(columnIndex, column.getWidth() * 256);
			}
			//writing workbook with response
			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			wb.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();
			response.setContentType("application/vnd.ms-excel");
			response.setHeader(("Content-Disposition"),
					"attachment; filename=" + report.getReportName()+ ".xls");
			response.setContentLength(outArray.length);
			OutputStream outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();
			LOG.info("Execution completed for writeIntoExcel");
		}
		catch (Exception e) {
			LOG.info("Failed to build the excel report - " + e.getMessage());
			throw new MeupException("Failed to build the excel report");
		}
		LOG.info("<--buildReport(Report report, HttpServletResponse response)");
	}



	private CellStyle getRowStyle(int rowIndex) {
		LOG.debug("Execution started for getRowStyle");
		CellStyle template = wb.createCellStyle();
		Font f = wb.createFont();
		f.setFontName("ARIAL");
		f.setFontHeightInPoints((short) 8);
		template.setFont(f);
		template.setAlignment(HorizontalAlignment.RIGHT);
		template.setWrapText(true);
		LOG.debug("Execution completed for getHeaderRowStyleTemplate");
		return template;
	}

	private CellStyle getHeaderRowStyleTemplate() {
		LOG.debug("Execution started for getHeaderRowStyleTemplate");
		CellStyle template = wb.createCellStyle();
		Font f = wb.createFont();
		f.setFontName("ARIAL");
		f.setBold(true);
		f.setFontHeightInPoints((short) 8);
		template.setFont(f);
		template.setAlignment(HorizontalAlignment.CENTER);
		template.setFillBackgroundColor(IndexedColors.WHITE.getIndex());
		template.setBorderBottom(BorderStyle.THIN);
		template.setWrapText(true);
		LOG.debug("Execution completed for getHeaderRowStyleTemplate");
		return template;
	}

	public Cell createCell(Row row, int index, CellStyle cs, String value) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cs);
		cell.setCellValue(value);
		return cell;
	}
	public Cell createCell(Row row, int index, CellStyle cs, Double value) {
		Cell cell = row.createCell(index);
		cell.setCellStyle(cs);
		cell.setCellValue(value);
		return cell;
	}

}