
package com.safeway.app.meup.exceptions;



import com.safeway.app.meup.util.MeupConstant;


public class ErrorMessage {



    /**
     * To show if no data is entered to block.
     */
    public static final String NO_DATA_ENTERED = "Data is not Entered.";

    /**
     * To show if decimal value is not entered.
     */
    public static final String NO_DECIMAL_VALUE = "CIC/UPC/Store number should be numeric and a non-decimal value.";

    /**
     * To show if the wrong length is entered for cic/upc/store.
     */
    public static final String WRONG_DATA_ENTERED = "CIC should be minimum 7 digits./UPC should be minimum 10\n" +
            "\t\tdigits./Store number should be 4 digits.";

    /**
     * To show if the no items are entered to block.
     */
    public static final String NO_ITEM_ENTERED = "Please enter an item.";

    /**
     * To show if no store number is entered to block.
     */
    public static final String NO_STORE_ENTERED = "Please enter a Store number.";

    /**
     * To show if the cic/upc is not entered.
     */
    public static final String NO_CIC_UPC_ENTERED = "CIC/UPC not Entered.";

    /**
     * To show if the division is not selected to block.
     */
    public static final String DIVISION_NOT_SELECTED = "Please select a division.";

    /**
     * To show if there is a duplicate entries while blocking.
     */
    public static final String DUPLICATE_ENTRIES = "Duplicate entries found for CIC/store.";

    /**
     * To show if the item is a discontinued item.
     */
    public static final String DISCONTINUED_ITEM = "Discontinued item.";

    /**
     * To show if the item is both dsd and warehouse item.
     */
    public static final String DSD_WH_ITEM = "Item is blocked from warehouse, but still authorized for DSD.";

    /**
     * To show if the item is dsd item.
     */
    public static final String DSD_STORE_ITEM = "DSD item.";

    /**
     * To show if the item is a duplicate itemr.
     */
    public static final String DUPLICATE_ITEM = "Duplicate entry - CIC/UPC.";

    /**
     * To show if there is some invalid store number entered.
     */
    public static final String INVALID_STORE = "Invalid store number.";

    /**
     * To show the message entry submitted and errors.
     */
    public static final String ENTRY_SUBMITTED_ERROR_LIST = "Entry submitted.See results below for invalid items.";

    /**
     * To show if all the entries are blocked.
     */
    public static final String ALL_ENTRY_SUBMITTED = "Entry submitted.All items submitted successfully.";

    /**
     * To show if the login is invalid.
     */
    public static final String INVALID_LOGIN = "Invalid user-id and/or password. Please try again or contact\n" +
            "\t\tthe Help Desk.";

    /**
     * To show if the item is invalid for the store.
     */
    public static final String INVALID_STORE_ITEM = "CIC/UPC invalid in store.";

    /**
     * To show if no parameters are selected to search than country.
     */
    public static final String OTHER_PARAMETER_THAN_COUNTRY = "Please specify at least one parameter other than Country.";

    /**
     * To show if no option is selected to search.
     */
    public static final String OPTION_TO_SEARCH = "Please specify one option to search.";

    public static final String NO_SEARCH_CRITERIA = "Please select a group";
    /**
     * To show if wrond cic is entered.
     */
    public static final String WRONG_CIC = "CIC must be numeric.";

    /**
     * To show if wrong upc is entered.
     */
    public static final String WRONG_UPC = "UPC must be numeric.";

    /**
     * To show if wrong store is entered.
     */
    public static final String WRONG_STORE = "Store number must be numeric.";

    /**
     * To show if the lenght of cic is wrong.
     */
    public static final String WRONG_DATA_CIC = "CIC should be minimum 7 digits.";

    /**
     * To show if the lenght of upc is wrong.
     */
    public static final String WRONG_DATA_UPC = "UPC should be minimum 10 digits.";

    /**
     * To show if the lenght of store number is wrong.
     */
    public static final String WRONG_DATA_STORE = "Store number should be 4 digits.";

    /**
     * To show if there are no search results.
     */
    public static final String NO_SEARCH_RESULTS = "No results found.";

    /**
     * To show the comment error.
     */
    public static final String COMMENT_BEFORE_UNBLOCK = "Please give a reason for unblocking.";
    /**
     * To show the comment error.
     */
    public static final String COMMENT_BEFORE_MODIFY = "Please give a reason for delete date change.";

    /**
     * To show the length of the comment error.
     */
    public static final String COMMENTS_SIZE = "Comments should be less than or equal to 100 characters.";

    /**
     * To show select item to modify error.
     */
    public static final String SELECT_ITEM_TO_MODIFY = "Atleast one store item must be selected to modify delete date.";

    /**
     * To show select item to modify error.
     */
    public static final String SELECT_ITEM_TO_UNBLOCK = "Atleast one store item must be selected to unblock.";

    /**
     * Fetching smicgroup exception.
     */
    public static final String GET_SMICGROUP_EXCEPTION = "An Exception occured while retrieving the smicgroup.";

    /**
     * Fetching smic category exception.
     */
    public static final String GET_SMICCATEGORY_EXCEPTION = "An Exception occured while retrieving the SmicCategory.";

    /**
     * Fetching divisions exception.
     */
    public static final String GET_DIVISIONS_EXCEPTION = "An Exception Occurred While Getting the Divisions.";
    public static final String NO_GROUPS_SELECTED = "Please Select a Group ";

    public static final String ERROR_LOADING_PAGE = "An Exception occured while loading the page";

    public static final String GET_STOCKDIV_EXCEPTION = "An exception occured while getting the stocking section and division";

    public static final String GET_GROUP_EXCEPTION = "An exception occured while retrieving the groups";

    /**
     * Fetching information if there is no group for the divisions.
     */
    public static final String NO_GROUPS_FOR_DIVISION = "No groups for the divisions selected.";

    /**
     * Fetching divisions exception.
     */
    public static final String NO_CATEGORIES_FOR_GROUP = "No categories for the group selected.";

    /**
     * Info message for unblocking an item
     */
    public static final String UNBLOCK_ITEMS ="item(s) unblocked. ";

    /**
     * Info message for modifying delete date of an item
     */
    public static final String MODIFY_DELETEDATE_ITEM = "Delete date changed for ";


    /**
     * Info message for modifying delete date of an item
     */
    public static final String MODIFY_DELETEDATE_ITEMS_CONFIRM_MESSAGE ="item(s).";
    /**
     * The variable which holds the value of return String for failure
     * condition, required in page navigation.
     */
    public static final String FAILURE_UPLOAD = "The CSV file is not specified for upload. Use the Browse button to locate the file";

    /**
     * Exception to handle Deadlock in Update StoreItems.
     */
    public static final String DB_DEADLOCK_913 = "Please revisit the changes. It has been modified by another user.";

    /**
     * Exception to handle Deadlock in Unblock StoreItems.
     */
    public static final String DB_DEADLOCK_UNBLOCK_ERROR = "item(s) has been unblocked by another user.";

    /**
     * The variable which holds the value of return String for failure condition
     * if the CSV file contains invalid path or file will not exists.
     */
    public static final String INVALID_FILE_PATH = "Path is incorrect or file doesn't exist.";


    /**
     * The variable which holds the value of return String for failure condition
     * if the CSV file content is empty.
     */
    public static final String CSV_CONTENT_FAILURE = "The CSV file is empty/invalid file path";


    /**
     * The variable which holds the value of return String for failure
     * condition, required in page navigation.
     */

    public static final String FAILURE_FORMAT = "The CSV file is not in specified format or error occurred\n" +
            "\t\t\twhile entering division number or store number.";


    /**
     * The variable which holds the value of return String for failure
     * condition, required in page navigation.
     */
    public static final String FAILURE_UPC_CIC = "The CSV file contains error in UPC/CIC.Please specify\n" +
            "\t\t\tthe correct format for CIC/UPC.";

    /**
     * The variable which holds the value of return String for success
     * condition, required in page navigation.
     */
    public static final String SUCCESS ="Upload successful. Invalid items will be emailed to you.";

    /**
     * To show if the logout is successful.
     */
    public static final String SUCCESSFUL_LOGOUT = "You have successfully logged out of the application.";

    /**
     * To show if the logout is successful.
     */
    public static final String TIMEOUT_MESSAGE =String.format("More than %s items have been fetched.Please refine your search.", new Object[]{MeupConstant.RESULTSET_SIZE});

    /**
     * The variable which holds the value for validating file extension.
     */
    public static final String NON_CSV_FILE = "The selected file is invalid. Please select a valid file and upload again.";

    /**
     * The variable which holds the value of return String for failure
     * condition,if multiple division number is found.
     */
    public static final String MULTIPLE_DIVISION = "Multiple division names exist in the file.  Please correct the error and upload again.";

    /**
     * The variable which holds the value of return String for failure condition
     * if the CSV file content is having wrong didvision number if it is mismatched with file division number..
     */
    public static final String INVALID_DIV_NUM = "Division number in csv filename does not match the division number in the file.";

    /**
     * The variable which holds the value for validating division number from database.
     */
    public static final String INVALID_DIVISION_FROM_DB = "Division number in file is Invalid. Please correct the error and upload again.";

    /**
     * The variable which holds the timeout exception message.
     */
    public static final String UPLOAD_TIMEOUT_MESSAGE = "The selected file size is huge, try uploading smaller files.";

    /**
     * The variable which holds the message while modifying schematic data.
     */
    public static final String MODIFY_SCHEMATIC = "All greyed cells indicate schematic data. A SCHEMATIC item cannot be modified by you.";

    /**
     * The variable which holds the message while unblocking schematic data.
     */
    public static final String UNBLOCK_SCHEMATIC = "All greyed cells indicate schematic data. A SCHEMATIC item can only be unblocked by the system administrator.";


    /**
     * The variable which holds the message while unblocking schematic data.
     */
    public static final String DEADLOCK_MESSAGE = "Please try after some time.";

    public static final String RESOURCE_LIMIT_MESSAGE = "Please reduce the number of records which you are trying to upload.";

    public static final String MAX_UPLOAD_COUNT = String.format(
            "The csv file has more than %s items. Please limit the number of items to %s or less.", new String[]{"" + MeupConstant.
                    UPLOAD_COUNT_INFO, "" + MeupConstant.UPLOAD_COUNT_INFO});

    public static final String MAX_UPLOAD_INFO = String.format(
            "You can upload maximum of %s items for a file.", new Object[]{MeupConstant.UPLOAD_COUNT_INFO});

    public static final String NO_DIVISIONS_FOR_STOCKINGSECTION = "No divisions for the stocking sections selected";

    public static final String NO_STOCKDIV_FOR_GROUP = "No stocking section and divisions for the group selected";

    public static final String UPDATE_SUCCESSFUL = "Update Successful";
    public static final String NO_ITEMS = "No Items On Hold";
    public static final String UPDATE_ERROR = "An Error Occured While Updating the Records";
    public static final String NO_CHANGE = "No status change for items selected";
    public static final String SMIC_GROUP_EXCEPTION = "An Exception occured while retrieving the smicgroup.";

    /**
     * default constructor.
     */
    private ErrorMessage() {
        super();
    }

}
