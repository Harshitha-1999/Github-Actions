/* ****************************************************************************
 *
 * Copyright 2008, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 **************************************************************************** */
package com.safeway.app.meup.dao;

import java.sql.SQLException;
import java.util.List;

import com.safeway.app.meup.dto.StockingSectionDTO;
import com.safeway.app.meup.exceptions.MeupException;

public interface StockingSectionDAO {

	List<StockingSectionDTO> getStockSectionListByGroupStatus(String corp, String groupCode, char itemStateCode,
			char blockedStatusCode) throws MeupException, SQLException;

}
