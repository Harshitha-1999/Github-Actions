
package com.safeway.app.meup.vox;



import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;


@Data
@Embeddable
public class StoreOptionsVOID implements Serializable {

    /*** corp value.*/
    @Column(name = "CORP")
    private String corp;

    /*** rog value.*/
    @Column(name = "ROG")
    private String rog;
}
