
package com.safeway.app.meup.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import com.safeway.app.meup.util.StoreItemHelper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dao.StoreDAO;
import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.dto.JsonErrorDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.StoreItemBusinessResult;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.exceptions.ErrorMessage;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.DivisionService;
import com.safeway.app.meup.service.ValidationService;
import com.safeway.app.meup.util.MeupConstant;
import com.safeway.app.meup.util.MeupLogUtil;
import com.safeway.app.meup.util.MeupUtility;
import com.safeway.app.meup.vox.StoreItemVO;
import com.safeway.app.meup.vox.UpcVO;

@Service
public class ValidationServiceImpl implements ValidationService {

	/**
	 * declaring the logging framework.
	 */
	private static final Log log = LogFactory.getLog(ValidationServiceImpl.class);

	@Autowired
	private DivisionService divisionService;
	@Autowired
	private StoreDAO storeDAO;
	@Autowired
	private StoreItemDAO storeItemDAO;

	/**
	 * Method to check validations on BlockItemsPage
	 *
	 * @throws MeupException when error occurs while fetching the divisions
	 */
	public void blockItemsPageValidations() throws MeupException {

	}

	public ItemDTO storeToItemDto(String cic, String upc) {
		log.info("|---> Beginning Method ValidationServiceImpl.storeToItemDto");

		ItemDTO itemDto = new ItemDTO();
		StoreItemHelper helper = new StoreItemHelper();
		int[] upcTokens = helper.getUPCTokens(upc);
		itemDto.setCic(cic);
		itemDto.setUpcCountry(Integer.toString(upcTokens[0]));
		itemDto.setUpcSystem(Integer.toString(upcTokens[1]));
		itemDto.setUpcManuf(Integer.toString(upcTokens[2]));
		itemDto.setUpcSales(Integer.toString(upcTokens[3]));
		itemDto.setUpc(upc);
		log.info("<---| Completed Method ValidationServiceImpl.storeToItemDto");
		return itemDto;
	}

	public int validateItemFormat(List<String> contents) {
		log.debug("-->Beginning method UploadCSVForm.validateItemFormat()");

		/** *String variable to read the data from the file. */
		String content = null;
		int indexOfList;

		/** return after validating the file content. */
		int code = MeupConstant.FILE_VALID;

		/** get the size of the contents list. */
		int contentSize = contents.size();

		/**
		 * check if size of content is less than 4,if it so then value of upc and cic
		 * doesn't contain anything,as it is empty.
		 */
		if (contentSize < MeupConstant.FILE_CONTENT_SIZE) {
			code = MeupConstant.CIC_UPC_INVALID;
			return code;
		}
		for (indexOfList = MeupConstant.CONTENT_SIZE; indexOfList < contentSize; indexOfList++) {
			/** Loops till the end of file. */

			content = contents.get(indexOfList);

			/**
			 * get the value of code from the method which will validate for the UPC and
			 * CIC.
			 */
			if (!("").equals(content.trim())) {
				code = isItemFormatValid(content);
			}
			if (code == MeupConstant.CIC_UPC_INVALID) {
				break;
			}

			/** retrun if retrun value is comma missing. */
			if (code == MeupConstant.COMMA_MISSING) {
				return MeupConstant.COMMA_MISSING;
			} else if (code == MeupConstant.NON_NUMBER_OR_NEGATIVE) {
				return MeupConstant.NON_NUMBER_OR_NEGATIVE;
			} else if (code == MeupConstant.NO_CIC_UPC) {
				return MeupConstant.NO_CIC_UPC;
			}
		}
		log.debug("<---| Completed Method UploadCSVForm.validateItemFormat");
		return code;
	}

	/**
	 * The method which validates the item format UPC and CIC are separated with a
	 * comma in each line and UPC and CIC is numeric .
	 *
	 * @param content string value to hold the cic and upc value inside the file.
	 * @return code which indiactes the item format to be valid.
	 */
	public int isItemFormatValid(String content) {
		log.debug("-->Beginning method UploadCSVForm.isItemFormatValid()");

		/** int variable to hold the return value of the method. */
		int code = 0;

		/**
		 * If there is no comma in the data read, then its an invalid file format and
		 * hence the file is rejected.
		 */
		int index = MeupUtility.indexSeparator(content, MeupConstant.comma);
		String upc = null;
		String cic = null;
		if (index == MeupConstant.INDEXOFSLASH) {
			code = MeupConstant.COMMA_MISSING;
			return code;
		}
		upc = MeupUtility.getSubString(content, MeupConstant.INITIAL_INDEX, index);
		upc = upc.replaceAll(",", "");
		upc = upc.trim();
		cic = MeupUtility.getSubString(content, index + MeupConstant.INDEX_LIST);
		cic = cic.replaceAll(",", "");
		cic = cic.trim();
		if (upc.length() != MeupConstant.INITIAL_INDEX) {
			if ((!MeupUtility.isNumeric(upc)) || MeupUtility.isNegative(upc)) {
				code = MeupConstant.NON_NUMBER_OR_NEGATIVE;
				return code;
			}
		}
		if (cic.length() != 0) {
			if ((!MeupUtility.isNumeric(cic)) || MeupUtility.isNegative(cic)) {
				code = MeupConstant.NON_NUMBER_OR_NEGATIVE;
				return code;
			}
		}

		/** validate UPC and CIC against null values,decimal and digits. */
		if ((cic != null && !"".equals(cic)) && (upc != null && !"".equals(upc))) {
			if (MeupUtility.isAllDecimalDigit(cic) && MeupUtility.isAllDecimalDigit(upc)) {
				if ((MeupUtility.getTrimmedStringSize(cic) >= MeupConstant.CIC_FIELD_MIN_DATA_SIZE
						&& MeupUtility.getTrimmedStringSize(upc) >= MeupConstant.UPC_FIELD_MIN_DATA_SIZE)
						&& ((MeupUtility.getTrimmedStringSize(cic) <= MeupConstant.CIC_FIELD_DATA_SIZE
								&& MeupUtility.getTrimmedStringSize(upc) <= MeupConstant.UPC_FIELD_DATA_SIZE))) {
					code = MeupConstant.FILE_VALID;
					return code;
				}
				code = MeupConstant.CIC_UPC_INVALID;
				return code;

			}
		} else {
			code = MeupConstant.CIC_UPC_INVALID;
			return code;
		}
		log.debug("<---| Completed Method UploadCSVForm.isItemFormatValid");
		return code;
	}

	public List<JsonErrorDTO> getErrorMessage(String message, String fieldName, List<JsonErrorDTO> errorDTOList) {
		JsonErrorDTO errorDTO = new JsonErrorDTO(message, fieldName);
		errorDTOList.add(errorDTO);
		return errorDTOList;
	}

	/**
	 * This method will converts the byte contents of the input file to a list that
	 * is it will read the content of the file that will further validate the
	 * content inside the file after reading.
	 *
	 * @return List that contains all the contents inside the file.
	 * @throws MeupException
	 */
	public List<String> extractFileData(MultipartFile file) throws MeupException {

		List<String> content = new ArrayList<>();
		/** String value to hold the temporary content. */
		String temporaryContent = null;
		try {
			/** Read the content of the file and get the list value as content. */
			BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(new ByteArrayInputStream(file.getBytes())));
			int recordCount = 0;
			while ((temporaryContent = bufferedReader.readLine()) != null) {
				if (!(temporaryContent.equals(""))) {
					recordCount++;
					content.add(temporaryContent);
				}
			}
			bufferedReader.close();
		} catch (IOException e) {
			log.error("Error while reading file content", e);
			throw new MeupException(e.getMessage());
		}
		return content;
	}

	/**
	 * This method validates if the file name whether the division number matches
	 * inside the file with the file name is valid.
	 *
	 * @param fileName which will read the correct file name
	 * @return true if the file name format is correct
	 */
	public boolean isDivisionNumberInvalid(String fileName, String divisionNumber) {
		log.debug("|--->Beginning Method UploadCSVForm.isDivisionNumberInvalid");

		/** String variable to hold the value of unallocated file name. */
		String unallocatedItemsFileName = null;

		/** integer to hold the position of file separator. */
		int indexOfSlash = fileName.lastIndexOf(MeupConstant.fileSeparator);

		/** boolean variable to return the value from the method. */
		boolean isDivisionNumberInvalid = false;

		if (indexOfSlash != MeupConstant.INDEXOFSLASH) {
			unallocatedItemsFileName = MeupUtility.getSubString(fileName, indexOfSlash + MeupConstant.INDEX_LIST);

			/** To check the filename is valid one */
			if (unallocatedItemsFileName.indexOf(".") < 3) {
				return false;
			}

			String splitFileName = unallocatedItemsFileName.substring(3, unallocatedItemsFileName.indexOf("."));

			/**
			 * check whether the division number inside the file matches with the file name.
			 */
			isDivisionNumberInvalid = unallocatedItemsFileName.startsWith(MeupConstant.DIVISION_FORMAT + divisionNumber)
					&& splitFileName.equals(divisionNumber);
		}
		log.debug("<---| Completed Method UploadCSVForm.isDivisionNumberInvalid");
		return isDivisionNumberInvalid;
	}

	/**
	 * This method validates if the file name is valid. Checks if the file name is
	 * of the form DivN.csv that is CSV file extension should be followed by the
	 * division number.
	 *
	 * @param fileName which will read the correct file name
	 * @return true if the file name format is correct
	 */
	public boolean isFileNameValid(String fileName) {
		log.debug("|--->Beginning Method UploadCSVForm.isFileNameValid");

		/** String variable to hold the value of unallocated file name. */
		String unallocatedItemsFileName = null;

		/** integer to hold the position of file separator. */
		int indexOfSlash = fileName.lastIndexOf(MeupConstant.fileSeparator);

		/** boolean variable to return the value from the method. */
		boolean isFileNameValid = false;
		if (indexOfSlash != MeupConstant.INDEXOFSLASH) {
			unallocatedItemsFileName = MeupUtility.getSubString(fileName, indexOfSlash + MeupConstant.INDEX_LIST);

			String splitFileName = unallocatedItemsFileName.substring(0, unallocatedItemsFileName.indexOf("."));

			/** check whether the file name is in correct format. */
			if (unallocatedItemsFileName.endsWith(".csv")) {
				if (splitFileName.length() == MeupConstant.SPLIT_FILE_NAME_LENGTH) {
					isFileNameValid = true;
				}
			} else {
				isFileNameValid = false;
			}
		}
		log.debug("<---| Completed Method UploadCSVForm.isFileNameValid");
		return isFileNameValid;
	}

	public List<String> validateStoreItemUpdate(List storeList, boolean isUnblock, String comment) {
		log.info("|---> Beginning Method StoreItemUpdateForm."
				+ "validateStoreItemUpdate((List storeList, boolean isUnblock, String comment)");
		List selectedStoreItemList = new ArrayList();
		List<String> errorList = new ArrayList<>();
		boolean isCommentGiven = false;
		boolean isValid = false;
		boolean isCommentSized = false;
		Iterator itemListItr = storeList.iterator();
		while (itemListItr.hasNext()) {
			StoreItemDTO storeItemDto = (StoreItemDTO) itemListItr.next();
			if ((storeItemDto.isSelected())) {
				selectedStoreItemList.add(storeItemDto);
			}
		}
		// log.info("|---> Beginning Method validateStoreItemUpdate" + "storeList" +
		// storeList.size());
		// log.info("|---> Beginning Method validateStoreItemUpdate" +
		// "selectedStoreItemList" + selectedStoreItemList);
		if (comment.trim().length() == 0) {
			if (isUnblock) {
				isValid = false;
				log.error(ErrorMessage.COMMENT_BEFORE_UNBLOCK);
				errorList.add(ErrorMessage.COMMENT_BEFORE_UNBLOCK);

			} else {
				isValid = false;
				log.error(ErrorMessage.COMMENT_BEFORE_MODIFY);
				errorList.add(ErrorMessage.COMMENT_BEFORE_MODIFY);

			}
		} else {
			isCommentGiven = true;
		}
		if (comment.trim().length() <= 100) {
			isCommentSized = true;
		}
		if (!isCommentSized) {
			isValid = false;
			log.error(ErrorMessage.COMMENTS_SIZE);
			errorList.add(ErrorMessage.COMMENTS_SIZE);

		}
		if (selectedStoreItemList.size() == 0) {
			if (isUnblock) {
				isValid = false;
				log.error(ErrorMessage.SELECT_ITEM_TO_UNBLOCK);
				errorList.add(ErrorMessage.SELECT_ITEM_TO_UNBLOCK);

			} else {
				isValid = false;
				log.error(ErrorMessage.SELECT_ITEM_TO_MODIFY);
				errorList.add(ErrorMessage.SELECT_ITEM_TO_MODIFY);

			}
		}
		if (isCommentGiven && isCommentSized && selectedStoreItemList.size() > 0) {
			isValid = true;
		}
		log.info("<---| Completed Method StoreItemUpdateForm."
				+ "validateStoreItemUpdate((List storeList, boolean isUnblock, String comment)");
		return errorList;
	}

	public String validateStoreItemUpdate(List storeList, boolean isUnblock) {
		log.info("|---> Beginning Method StoreItemUpdateForm." + "validateFields(List storeList)");
		List selectedStoreItemList = new ArrayList();
		boolean isCommentGiven = false;
		boolean isValid = false;
		boolean isCommentSized = false;
		Iterator itemListItr = storeList.iterator();
		while (itemListItr.hasNext()) {
			StoreItemDTO storeItemDto = (StoreItemDTO) itemListItr.next();
			if ((storeItemDto.isSelected())) {
				selectedStoreItemList.add(storeItemDto);
			}
		}
		if (selectedStoreItemList.size() == 0) {
			if (isUnblock) {
				isValid = false;
				return (ErrorMessage.SELECT_ITEM_TO_UNBLOCK);

			} else {
				isValid = false;
				return (ErrorMessage.SELECT_ITEM_TO_MODIFY);

			}
		}
		if (selectedStoreItemList.size() > 0) {
			isValid = true;
			return "true";
		}
		log.info("<---| Completed Method StoreItemUpdateForm." + "validateFields(List storeList)");
		return null;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.SERIALIZABLE)
	public List<String> getCorrectStoresInDivision(String divisionNumber, List<String> storeList, String corp)
			throws MeupException {

		log.info("|---> Beginning Method getCorrectStoresInDivision");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(),
				"getCorrectStoresInDivision(String divisionNumber," + "List storeList, String corp)"));

		ArrayList<String> storeValidList = new ArrayList(storeList);
		List<String> storeVOList = storeDAO.getStoresInDivision(divisionNumber, corp);
		if (!CollectionUtils.isEmpty(storeVOList)) {
			storeValidList.retainAll(storeVOList);
		}
		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog(this.getClass().getName(),
				"getCorrectStoresInDivision(String divisionNumber," + "List storeList, String corp)",
				endTime - startTime));

		log.info("|<--- Completed Method " + "StoreFactory.getCorrectStoresInDivision(String divisionNumber,"
				+ "List storeList, String corp)");
		return storeValidList;
	}

	/**
	 * Method filters out the invalid Store Numbers.
	 *
	 * @param storesList     holds the list of stores
	 * @param validStoreList holds the list of valid stores
	 * @return List of type String
	 */
	public List<String> filterInvalidStoreList(List<String> storesList, List<String> validStoreList) {
		log.info("|---> Beginning Method DivisionDAOImpl.filterInvalidStoreList");

		List<String> invalidStoresList = new ArrayList();
		String storeNumber = null;
		for (Iterator it = storesList.iterator(); it.hasNext();) {
			storeNumber = (String) it.next();
			if (!validStoreList.contains(storeNumber)) {
				invalidStoresList.add(storeNumber);
			}
		}
		log.info("|<--- Completed Method filterInvalidStoreList");
		return invalidStoresList;
	}

	public List<String> validateFieldsForReportStoreItems(StoreItemSearchDTO storeItemSearchDTO) {
		log.info("|--> Beginning method  ValidationServiceImpl." + "validateFieldsForReportStoreItems");
		boolean isCicValid = true;
		boolean isUpcValid = true;
		boolean isStoreValid = true;
		boolean isValid = true;
		List<String> errorList = new ArrayList<>();
		if (null != storeItemSearchDTO.getCountryCd() && !"".equals(storeItemSearchDTO.getCountryCd())
				&& ((null != storeItemSearchDTO.getDivisions() && !storeItemSearchDTO.getDivisions().isEmpty())
						|| (null != storeItemSearchDTO.getGroups() && !storeItemSearchDTO.getGroups().isEmpty())
						|| (null != storeItemSearchDTO.getCategories() && !storeItemSearchDTO.getCategories().isEmpty())
						|| (storeItemSearchDTO.getCic() != null && !"".equals(storeItemSearchDTO.getCic()))
						|| (storeItemSearchDTO.getUpc() != null && !"".equals(storeItemSearchDTO.getUpc()))
						|| (storeItemSearchDTO.getStoreNumber() != null
								&& !"".equals(storeItemSearchDTO.getStoreNumber()))
						|| ((null != storeItemSearchDTO.getStatus() && !"Select".equals(storeItemSearchDTO.getStatus()))
								|| (null != storeItemSearchDTO.getState()
										&& !"Select".equals(storeItemSearchDTO.getState()))))) {

			// check for valid cic
			if ((storeItemSearchDTO.getCic() != null && !"".equals(storeItemSearchDTO.getCic()))) {
				if (MeupUtility.isAllDecimalDigit(storeItemSearchDTO.getCic())) {
					if (MeupUtility.getTrimmedStringSize(
							storeItemSearchDTO.getCic()) >= MeupConstant.CIC_FIELD_MIN_DATA_SIZE) {
						isCicValid = true;
					} else {
						isCicValid = false;
						log.error(ErrorMessage.WRONG_DATA_CIC);
						errorList.add(ErrorMessage.WRONG_DATA_CIC);
					}
				} else {
					isCicValid = false;
					log.error(ErrorMessage.WRONG_CIC);
					errorList.add(ErrorMessage.WRONG_CIC);
				}
			}

			// Check for Valid UPC
			if ((storeItemSearchDTO.getUpc() != null && !"".equals(storeItemSearchDTO.getUpc()))) {
				if (MeupUtility.isAllDecimalDigit(storeItemSearchDTO.getUpc())) {
					if (MeupUtility.getTrimmedStringSize(
							storeItemSearchDTO.getUpc()) >= MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {
						isUpcValid = true;
						if (MeupUtility.getTrimmedStringSize(
								storeItemSearchDTO.getUpc()) == MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {
							storeItemSearchDTO.setUpc("00" + storeItemSearchDTO.getUpc());
						}
						if (MeupUtility.getTrimmedStringSize(storeItemSearchDTO.getUpc()) == 11) {
							storeItemSearchDTO.setUpc("0" + storeItemSearchDTO.getUpc());
						}
					} else {
						isUpcValid = false;
						log.error(ErrorMessage.WRONG_DATA_UPC);
						errorList.add(ErrorMessage.WRONG_DATA_UPC);
					}
				} else {
					isUpcValid = false;
					log.error(ErrorMessage.WRONG_UPC);
					errorList.add(ErrorMessage.WRONG_UPC);
				}
			}

			// Check for Valid Store Number
			if (storeItemSearchDTO.getStoreNumber() != null && !"".equals(storeItemSearchDTO.getStoreNumber())) {
				if (MeupUtility.isAllDecimalDigit(storeItemSearchDTO.getStoreNumber())) {
					if (MeupUtility.getTrimmedStringSize(storeItemSearchDTO.getStoreNumber()) == 4) {
						isStoreValid = true;
					} else {
						isStoreValid = false;
						log.error(ErrorMessage.WRONG_DATA_STORE);
						errorList.add(ErrorMessage.WRONG_DATA_STORE);
					}
				} else {
					isStoreValid = false;
					log.error(ErrorMessage.WRONG_STORE);
					errorList.add(ErrorMessage.WRONG_STORE);
				}
			}
			isValid = isCicValid && isUpcValid && isStoreValid;
		} else {
			isValid = false;
			log.error(ErrorMessage.OTHER_PARAMETER_THAN_COUNTRY);
			errorList.add(ErrorMessage.OTHER_PARAMETER_THAN_COUNTRY);
		}

		log.info("<---| Completed method ValidationServiceImpl." + " validateFieldsForReportStoreItems");
		return errorList;
	}

	public List<String> validateFieldsForUpdateStoreItems(StoreItemSearchDTO storeItemSearchDTO) {
		log.info("|---> Beginning method ValidationServiceImpl." + "validateFieldsForUpdateStoreItems");
		boolean isCicValid = true;
		boolean isUpcValid = true;
		boolean isStoreValid = true;
		boolean isValid = true;
		List<String> errorList = new ArrayList<>();
		if (null != storeItemSearchDTO.getCountryCd() && !"".equals(storeItemSearchDTO.getCountryCd())
				&& ((null != storeItemSearchDTO.getDivisions() && !storeItemSearchDTO.getDivisions().isEmpty())
						|| (null != storeItemSearchDTO.getGroups() && !storeItemSearchDTO.getGroups().isEmpty())
						|| (null != storeItemSearchDTO.getCategories() && !storeItemSearchDTO.getCategories().isEmpty())
						|| (storeItemSearchDTO.getCic() != null && !"".equals(storeItemSearchDTO.getCic()))
						|| (storeItemSearchDTO.getUpc() != null && !"".equals(storeItemSearchDTO.getUpc()))
						|| (storeItemSearchDTO.getStoreNumber() != null
								&& !"".equals(storeItemSearchDTO.getStoreNumber()))
						|| ((null != storeItemSearchDTO.getDeleteDateStart()
								&& !"".equals(storeItemSearchDTO.getDeleteDateStart()))
								&& (null != storeItemSearchDTO.getDeleteDateEnd()
										&& !"".equals(storeItemSearchDTO.getDeleteDateEnd())))
						|| !"".equals(storeItemSearchDTO.getState()))) {

			// check for valid cic
			if ((storeItemSearchDTO.getCic() != null && !"".equals(storeItemSearchDTO.getCic()))) {
				if (MeupUtility.isAllDecimalDigit(storeItemSearchDTO.getCic())) {
					if (MeupUtility.getTrimmedStringSize(
							storeItemSearchDTO.getCic()) >= MeupConstant.CIC_FIELD_MIN_DATA_SIZE) {
						isCicValid = true;
					} else {
						isCicValid = false;
						log.error(ErrorMessage.WRONG_DATA_CIC);
						errorList.add(ErrorMessage.WRONG_DATA_CIC);
					}
				} else {
					isCicValid = false;
					log.error(ErrorMessage.WRONG_CIC);
					errorList.add(ErrorMessage.WRONG_CIC);
				}

			}

			// Check for Valid UPC
			if ((storeItemSearchDTO.getUpc() != null && !"".equals(storeItemSearchDTO.getUpc()))) {
				if (MeupUtility.isAllDecimalDigit(storeItemSearchDTO.getUpc())) {
					if (MeupUtility.getTrimmedStringSize(
							storeItemSearchDTO.getUpc()) >= MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {
						isUpcValid = true;
						if (MeupUtility.getTrimmedStringSize(
								storeItemSearchDTO.getUpc()) == MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {
							storeItemSearchDTO.setUpc("00" + storeItemSearchDTO.getUpc());
						}
						if (MeupUtility.getTrimmedStringSize(storeItemSearchDTO.getUpc()) == 11) {
							storeItemSearchDTO.setUpc("0" + storeItemSearchDTO.getUpc());
						}
					} else {
						isUpcValid = false;
						log.error(ErrorMessage.WRONG_DATA_UPC);
						errorList.add(ErrorMessage.WRONG_DATA_UPC);
					}

				} else {
					isUpcValid = false;
					log.error(ErrorMessage.WRONG_UPC);
					errorList.add(ErrorMessage.WRONG_UPC);
				}

			}

			/* Check for Valid Store Number */
			if (storeItemSearchDTO.getStoreNumber() != null && !"".equals(storeItemSearchDTO.getStoreNumber())) {
				if (MeupUtility.isAllDecimalDigit(storeItemSearchDTO.getStoreNumber())) {
					if (MeupUtility.getTrimmedStringSize(storeItemSearchDTO.getStoreNumber()) == 4) {
						isStoreValid = true;
					} else {
						isStoreValid = false;
						log.error(ErrorMessage.WRONG_DATA_STORE);
						errorList.add(ErrorMessage.WRONG_DATA_STORE);
					}

				} else {
					isStoreValid = false;
					log.error(ErrorMessage.WRONG_STORE);
					errorList.add(ErrorMessage.WRONG_STORE);
				}

			}
			isValid = isCicValid && isUpcValid && isStoreValid;
		} else {
			isValid = false;
			log.error(ErrorMessage.OTHER_PARAMETER_THAN_COUNTRY);
			errorList.add(ErrorMessage.OTHER_PARAMETER_THAN_COUNTRY);
		}
		log.info("<---| Completed Method ValidationServiceImpl." + "validateFieldsForUpdateStoreItems");
		return errorList;
	}

	@Override
	public List<JsonErrorDTO> validateBlockItemCSVFile(MultipartFile itemsFile, ResponseDTO responseDTO,
			BlockItemRequestDTO requestDTO) throws MeupException {
		List<String> content = new ArrayList<>();
		List<JsonErrorDTO> errorDTOList = responseDTO.getErrorDTOList();
		String uploadField = "uploadCSVFile";
		/** check whether the file is selected. */
		if (null == itemsFile) {
			return getErrorMessage(ErrorMessage.FAILURE_UPLOAD, uploadField, errorDTOList);
		}
		/** check whether file is empty. */
		String fileName = itemsFile.getOriginalFilename();
		if (!fileName.endsWith(".csv")) {
			return getErrorMessage(ErrorMessage.FAILURE_UPLOAD, uploadField, errorDTOList);
		}
		/** read the contens of the file. */
		content = extractFileData(itemsFile);

		/** Checking whether the file is empty */
		if (content.isEmpty()) {
			return getErrorMessage(ErrorMessage.CSV_CONTENT_FAILURE, uploadField, errorDTOList);
		}

		/** Checking the item count > 1500 */
		if (content.size() > MeupConstant.MAX_UPLOAD_LIMIT) {
			return getErrorMessage(ErrorMessage.MAX_UPLOAD_COUNT, uploadField, errorDTOList);
		}

		/**
		 * call the method which will validate the file format inside the file.
		 */
		int returnCode = isFileFormatValid(fileName, content, requestDTO);

		/**
		 * get the value of return code as in the form of integer value and if the value
		 * of return code is not equal to zero set the error message value of return
		 * code=0 states that file will upload successfully
		 */
		if (returnCode == MeupConstant.CHECK_VALID_DIVISION) {
			log.error(ErrorMessage.INVALID_DIVISION_FROM_DB);
			return getErrorMessage(ErrorMessage.INVALID_DIVISION_FROM_DB, uploadField, errorDTOList);

		}

		if (returnCode == MeupConstant.IN_DIVISIONNO_INVALID) {
			log.error(ErrorMessage.MULTIPLE_DIVISION);
			return getErrorMessage(ErrorMessage.MULTIPLE_DIVISION, uploadField, errorDTOList);
		}
		if (returnCode == MeupConstant.INVALID_DIVISIONNO) {
			log.error(ErrorMessage.INVALID_DIV_NUM);
			return getErrorMessage(ErrorMessage.INVALID_DIV_NUM, uploadField, errorDTOList);
		}
		if (returnCode != MeupConstant.FILE_VALID) {
			log.error(ErrorMessage.FAILURE_FORMAT);
			return getErrorMessage(ErrorMessage.FAILURE_FORMAT, uploadField, errorDTOList);
		}

		/**
		 * call the method which will validate the contents of the CSV file for UPC and
		 * CIC.
		 */
		returnCode = validateItemFormat(content);

		/**
		 * check for whether the upc and contains non number or negative value.
		 */
		if (returnCode == MeupConstant.NON_NUMBER_OR_NEGATIVE) {
			log.error(ErrorMessage.FAILURE_UPC_CIC);
			return getErrorMessage(ErrorMessage.FAILURE_UPC_CIC, uploadField, errorDTOList);
		}

		/** check for the comma missing. */
		if (returnCode == MeupConstant.COMMA_MISSING) {
			log.error(ErrorMessage.FAILURE_UPC_CIC);
			return getErrorMessage(ErrorMessage.FAILURE_UPC_CIC, uploadField, errorDTOList);
		}
		/** check whether the cic and upc value is invalid. */
		if (returnCode == MeupConstant.CIC_UPC_INVALID) {
			log.error(ErrorMessage.FAILURE_UPC_CIC);
			return getErrorMessage(ErrorMessage.FAILURE_UPC_CIC, uploadField, errorDTOList);
		}

		return errorDTOList;
	}

	public int isFileFormatValid(String fileName, List<String> contents, BlockItemRequestDTO requestDTO)
			throws MeupException {
		log.debug("|--->Beginning Method UploadCSVForm.isFileFormatValid");
		/** initialize the return code as 0.File valid will return 0 value. */
		int returnCode = MeupConstant.FILE_VALID;
		/** String value to hold teh content. */
		String content = null;
		/** List to hold the store number. */
		List<String> storeNumberList = new ArrayList<>();
		/** string value to hold the storeID. */
		String storeID;
		/** int value to hold the indexOfList to iterate each row. */
		int indexOfList = MeupConstant.INITIAL_INDEX;
		/** int value to hold to get the content separated with comma. */
		int index = MeupConstant.INITIAL_INDEX;
		/** get the size of file content. */
		int contentSize = contents.size();

		/**
		 * check whether contentSize is less than 3,if it so then there is no upc, cic
		 * header or store # header.
		 */
		if (contentSize < MeupConstant.CONTENT_SIZE) {
			returnCode = MeupConstant.ITEM_HEADER_INVALID;
			return returnCode;
		}
		/**
		 * Read the first three line in the file and returns true if the file content is
		 * as defined with correct format.
		 */
		for (indexOfList = MeupConstant.INITIAL_INDEX; indexOfList < MeupConstant.CONTENT_SIZE; indexOfList++) {
			content = contents.get(indexOfList);
			/**
			 * check if the first row of the content is as per as format that in the form of
			 * Division.
			 */
			index = MeupUtility.indexSeparator(content, MeupConstant.comma);
			if (indexOfList == MeupConstant.INITIAL_INDEX) {
				if (index == MeupConstant.INDEXOFSLASH) {
					returnCode = MeupConstant.DIVISION_INVALID;
					return returnCode;
				}

				/* get the header string value as Division which is first header format */
				String headerString = MeupUtility.getSubString(content, MeupConstant.INITIAL_INDEX, index);
				headerString = headerString.trim();
				if (headerString.indexOf(MeupConstant.comma) != MeupConstant.INDEXOFSLASH) {
					headerString = headerString.replaceAll(",", "");
					headerString = headerString.trim();
				}
				if (!headerString.equals(MeupConstant.INITIAL_FORMAT)) {
					returnCode = MeupConstant.ITEM_HEADER_INVALID;
					break;
				}
				String divisionNumber = MeupUtility.getSubString(content, index + MeupConstant.INDEX_LIST);
				divisionNumber = divisionNumber.replaceAll(",", "");
				divisionNumber = divisionNumber.trim();

				/**
				 * *validate whether the file is in .csv format and it matches with the division
				 * number.
				 */
				if (isFileNameValid(fileName) == false) {
					returnCode = MeupConstant.ITEM_HEADER_INVALID;
					break;
				}

				/**
				 * *validate whether the file matches with the division number.
				 */
				if (isDivisionNumberInvalid(fileName, divisionNumber) == false) {
					returnCode = MeupConstant.INVALID_DIVISIONNO;
					break;
				}

				/** validate for division number insid ethe file content. */
				if (validateDivisionNumber(divisionNumber) == false) {
					returnCode = MeupConstant.CHECK_VALID_DIVISION;
					break;
				}

				/**
				 * check for the division number as it should be of two character only.
				 */
				if (divisionNumber.length() > MeupConstant.DIVISION_NUM) {
					returnCode = MeupConstant.IN_DIVISIONNO_INVALID;
					break;
				}

				/** check if division number is null then retrun invalid message. */
				if (divisionNumber == null) {
					returnCode = MeupConstant.IN_DIVISIONNO_INVALID;
					break;
				}
				/**
				 * set the division number to blockItemRequestDto when all the validation
				 * passes.
				 */
				requestDTO.setDivisionNumber(divisionNumber);
				/**
				 * check if the second row of the content is as per as format that is with store
				 * #.
				 */
			} else if (indexOfList == MeupConstant.INDEX_LIST) {
				if (index == MeupConstant.INDEXOFSLASH) {
					returnCode = MeupConstant.STORE_ID_INVALID;
					break;
				}

				/** get the header string value as in the format store #. */
				String headerString = MeupUtility.getSubString(content, MeupConstant.INITIAL_INDEX, index);
				headerString = headerString.trim();
				if (headerString.indexOf(MeupConstant.comma) != MeupConstant.INDEXOFSLASH) {
					headerString = headerString.replaceAll(",", "");
					headerString = headerString.trim();
				}
				if (!headerString.equals(MeupConstant.STOREID_FORMAT)) {
					returnCode = MeupConstant.ITEM_HEADER_INVALID;
					break;
				}
				storeID = MeupUtility.getSubString(content, index + MeupConstant.INDEX_LIST);
				StringTokenizer getStoreIDStringTokenizer = new StringTokenizer(storeID, MeupConstant.COMMAVALUE);

				/** validate for each store number as with the character of four. */
				while (getStoreIDStringTokenizer.hasMoreTokens()) {
					storeID = getStoreIDStringTokenizer.nextToken();
					storeID = storeID.trim();
					if (storeID.length() == MeupConstant.STORE_LENGTH) {
						returnCode = MeupConstant.FILE_VALID;
					} else {
						returnCode = MeupConstant.IN_STORE_ID_INVALID;
						break;
					}
				}
				if (storeID.indexOf(MeupConstant.comma) != MeupConstant.INDEXOFSLASH) {
					storeID = storeID.replaceAll(",", "");
					storeID = storeID.trim();
				}
				if (storeID == null) {
					returnCode = MeupConstant.IN_STORE_ID_INVALID;
					break;
				}

				/**
				 * check if third row contents as per as format that is with UPC,CIC.
				 */
			} else if (indexOfList == MeupConstant.INDEX_SECOND_ROW) {

				/**
				 * check for index is -1,if it so it does not contain in UPC,CIC format.
				 */
				if (index == MeupConstant.INDEXOFSLASH) {
					returnCode = MeupConstant.ITEM_HEADER_INVALID;
					return returnCode;
				}

				/** String value to get the upc format and cic format. */
				String upcFormat = content.substring(MeupConstant.INITIAL_INDEX, content.indexOf(MeupConstant.comma));
				String cicFormat = content.substring(content.indexOf(MeupConstant.comma) + MeupConstant.INDEX_LIST);
				if (cicFormat.indexOf(MeupConstant.comma) != MeupConstant.INDEXOFSLASH) {
					cicFormat = cicFormat.replaceAll(",", "");
					cicFormat = cicFormat.trim();
				}
				content = upcFormat + MeupConstant.comma + cicFormat;
				content = content.trim();
				if (!content.equals(MeupConstant.COLUMN_FORMAT)) {
					returnCode = MeupConstant.ITEM_HEADER_INVALID;
				}
			}
		}

		/**
		 * to set the store number in form of list into BlockItemRequestDTO.
		 */
		content = contents.get(MeupConstant.INDEX_LIST);
		index = MeupUtility.indexSeparator(content, MeupConstant.comma);
		storeID = MeupUtility.getSubString(content, index + MeupConstant.INDEX_LIST);

		/**
		 * get the list array for the storing the store number and add it into the list.
		 */

		/** Tokenize all the values of storeID. */
		StringTokenizer getStoreIDStringTokenizer = new StringTokenizer(storeID, MeupConstant.COMMAVALUE);
		while (getStoreIDStringTokenizer.hasMoreTokens()) {
			storeID = getStoreIDStringTokenizer.nextToken();
			storeID = storeID.trim();

			/** add all the storeID into storeNumberList. */
			storeNumberList.add(storeID);
		}

		/** add the storeList into the BlockItemRequestDto. */
		requestDTO.setStoreList(storeNumberList);
		log.debug("<---| Completed Method UploadCSVForm.isFileFormatValid");
		return returnCode;
	}

	/**
	 * check for validate division number from the data base and from the file
	 * content.
	 */
	public boolean validateDivisionNumber(String divisionNumber) throws MeupException {
		/** boolean value to hold for validating teh division. */
		boolean isValidDivision = divisionService.isValidDivision(divisionNumber);
		return isValidDivision;
	}

	/**
	 * This method performs the validation by co-ordinating all the business
	 * methods.
	 *
	 * @param blockItemRequestDTO requestDto
	 * @return StoreItemBusinessResult with details of valid and invalid storeItems
	 * @throws MeupException when error occurs in creating StoreItemBusinessResult
	 */
	@Override
	public StoreItemBusinessResult validateItemsAndStores(BlockItemRequestDTO blockItemRequestDTO)
			throws MeupException {
		// validate block store items fileds
		List<String> storeList = new ArrayList<>();
		List<ItemDTO> itemDtoList = new ArrayList<>();
		StoreItemBusinessResult businessResult = new StoreItemBusinessResult();
		List errorMessages = new ArrayList();
		List<StoreItemHelper> storeItemHelperList = blockItemRequestDTO.getStoreItemHelperList();
		String divisionNumber1 = blockItemRequestDTO.getDivisionNumber();

		List errorNonIntList = new ArrayList();
		List errorSizelist = new ArrayList();
		List errorEmptyItemList = new ArrayList();
		List errorNoStoreList = new ArrayList();
		List duplicateList = new ArrayList();
		Set itemSet = new HashSet();
		String upc = null;
		String cic = null;
		String store = null;
		StoreItemHelper storeItem1 = null;

		if ("Select".equals(divisionNumber1)) {
			errorMessages.add(ErrorMessage.DIVISION_NOT_SELECTED);
		} else {
			Iterator listIter = storeItemHelperList.iterator();
			while (listIter.hasNext()) {
				storeItem1 = (StoreItemHelper) listIter.next();
				upc = storeItem1.getUpc();
				cic = storeItem1.getCic();
				store = storeItem1.getStoreNo();
				/*
				 * validate CIC and UPC against null values, decimal and number of digits.
				 */
				if ((cic != null && !"".equals(cic)) && (upc != null && !"".equals(upc))) {
					if (MeupUtility.isAllDecimalDigit(cic) && MeupUtility.isAllDecimalDigit(upc)) {
						if (MeupUtility.getTrimmedStringSize(cic) >= MeupConstant.CIC_FIELD_MIN_DATA_SIZE
								&& MeupUtility.getTrimmedStringSize(upc) >= MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {

							/*
							 * if the length od upc entered is 10, then add 2 leading zeroes.
							 */
							if (MeupUtility.getTrimmedStringSize(upc) == MeupConstant.UPC_FIELD_MIN_DATA_SIZE) {
								upc = "00" + upc;
							}

							/*
							 * if the length od upc entered is 11, then add 1 leading zeroes.
							 */
							if (MeupUtility.getTrimmedStringSize(upc) == 11) {
								upc = "0" + upc;
							}

							/* check for duplicate entries. */
							if (itemSet.add(cic)) {

								/*
								 * If all the validation passes, Store the values to itemDto.
								 */
								ItemDTO item = storeToItemDto(cic, upc);

								// Add the itemDto to itemDtoList.
								itemDtoList.add(item);
							} else {

								// populate the list to store duplicate values.
								duplicateList.add(cic);
							}
						} else {
							// else add to the appropriate error Lists.
							errorSizelist.add(cic);
						}
					} else {
						errorNonIntList.add(cic);
					}
				}

				// If any one of the field CIC/ UPC is empty,
				// then add to another error List.
				else if ((("".equals(cic)) && (!"".equals(upc))) || ((!"".equals(cic)) && ("".equals(upc)))) {
					errorEmptyItemList.add(cic);

				}

				// validate storeNo entered against null value,
				// decimal and number of digits.
				if (store != null && !"".equals(store)) {
					if (MeupUtility.isAllDecimalDigit(store)) {
						if (MeupUtility.getTrimmedStringSize(store) == 4) {
							if (itemSet.add(store)) {

								// If all the validation passes,
								// Add to storeList
								storeList.add(store);
							} else {
								duplicateList.add(cic);
							}
						} else {

							// else add to appropriate error List.
							errorSizelist.add(cic);
						}
					} else {
						errorNonIntList.add(cic);
					}
				} else {
					errorNoStoreList.add(cic);
				}
			}

			// After the entire rows are validated,
			// check for the error messages.
			if (!errorSizelist.isEmpty()) {
				// return ErrorMessage.WRONG_DATA_ENTERED;
				errorMessages.add(ErrorMessage.WRONG_DATA_ENTERED);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;

			} else if (!errorNonIntList.isEmpty()) {
				// return ErrorMessage.NO_DECIMAL_VALUE;
				errorMessages.add(ErrorMessage.NO_DECIMAL_VALUE);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;
			} else if (!errorEmptyItemList.isEmpty()) {
				// return ErrorMessage.NO_CIC_UPC_ENTERED;
				errorMessages.add(ErrorMessage.NO_CIC_UPC_ENTERED);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;
			} else if (itemDtoList.isEmpty() && storeList.isEmpty()) {
				// return ErrorMessage.NO_DATA_ENTERED;
				errorMessages.add(ErrorMessage.NO_DATA_ENTERED);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;
			} else if (itemDtoList.isEmpty() && !storeList.isEmpty()) {
				// return ErrorMessage.NO_ITEM_ENTERED;
				errorMessages.add(ErrorMessage.NO_ITEM_ENTERED);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;
			} else if (!itemDtoList.isEmpty() && storeList.isEmpty()) {
				// return ErrorMessage.NO_STORE_ENTERED;
				errorMessages.add(ErrorMessage.NO_STORE_ENTERED);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;
			} else if (!duplicateList.isEmpty()) {
				// return ErrorMessage.DUPLICATE_ENTRIES;
				errorMessages.add(ErrorMessage.DUPLICATE_ENTRIES);
				businessResult.setErrorMessages(errorMessages);
				return businessResult;
			}

			// If all the items and stores entered are valid, add to
			// BlockRequestItemItemDto.
			else if (!itemDtoList.isEmpty() && !storeList.isEmpty()) {
				blockItemRequestDTO.setItemDtoList(itemDtoList);
				blockItemRequestDTO.setStoreList(storeList);
				// return "setItemsToBlockItemRequestDto";

			}
			/*
			 * else { businessResult.setErrorMessages(errorMessages); return businessResult;
			 * }
			 */
		}
		// end of validate block store items fields
		log.info("|---> Beginning Method Validator.validateItemsAndStores");
		long startTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.startLog(this.getClass().getName(),
				"validateItemsAndStores(BlockItemRequestDTO requestDto)"));

		/* Contains the valid stores from input - String */
		List<String> validStoresList;

		/* Contains all discontinued Item - StoreItemDTO */
		List<StoreItemDTO> discontinuedStoreItemList = new ArrayList<>();
		/* Contains all items already blocked - StoreItemDTO */
		List<StoreItemDTO> duplicateItemList = new ArrayList<>();
		/* Contains all Invalid Store Items - StoreItemDTO */
		List<StoreItemDTO> invalidStoreItemList = new ArrayList<>();
		/* Contains all DSD Store Items - StoreItemDTO */
		List<StoreItemDTO> dsdStoreItemList = new ArrayList<>();
		/* Contains all DSD and Warehouse Items - StoreItemDTO */
		List<StoreItemDTO> dsdAndWhStoreItemList = new ArrayList<>();
		/* Contains all Valid Items to be inserted */
		List<StoreItemDTO> validStoreItemList = new ArrayList<>();
		// Holds the division Selected
		String divisionNumber = blockItemRequestDTO.getDivisionNumber();
		/* Hold the corp selected */
		String corp = blockItemRequestDTO.getCorp();
		/* initializing StoreItemBusinessResult for return */
		// StoreItemBusinessResult businessResult = new StoreItemBusinessResult();

		try {
			/* Filtering out the valid stores */
			validStoresList = getCorrectStoresInDivision(divisionNumber, blockItemRequestDTO.getStoreList(), corp);		
			log.debug("Valid Stores found : " + validStoresList.size());
			List<ItemDTO> itemDtoLists = blockItemRequestDTO.getItemDtoList();

			if (null != itemDtoLists && null != validStoresList) {
				Iterator itemIt = itemDtoLists.iterator();
				String storeNumber = null;
				Iterator storesIter = null;
				ItemDTO itemDto = null;
				UpcVO urx = null;
				StoreItemVO storeItem = null;
				StoreItemDTO storeItemDto = null;
				DivisionDTO divisionDto = null;

				/* Taking each Item */
				while (itemIt.hasNext()) {
					itemDto = (ItemDTO) itemIt.next();
					// log.debug("Validating for Item :" + itemDto.getCic() +
					// " : Start");
					storesIter = validStoresList.iterator();

					/* Validating against each Store */
					while (storesIter.hasNext()) {

						storeNumber = (String) storesIter.next();
						// log.debug("Validation for Item : " + itemDto.getCic() +
						// " Store : " + storeNumber);

						/*
						 * Creating the StoreItemDTO with the current Item and Store
						 */
						storeItemDto = new StoreItemDTO();
						storeItemDto.setItemDto(itemDto);
						storeItemDto.setStoreNumber(storeNumber);
						storeItemDto.setUpc(itemDto.getUpc());
						divisionDto = new DivisionDTO();
						divisionDto.setDivisionNumber(divisionNumber);
						divisionDto.setCorp(corp);

						storeItemDto.setLastUpdatedUser(blockItemRequestDTO.getUserid());
						storeItemDto.setDivisionDto(divisionDto);
						storeItemDto.setStoreNumber(storeNumber);
						// jteta01: INC0576505 Modify date
						// storeItemDto.setBlockedTargetDate(requestDto.getDeleteDate());
						/*
						 * storeItemDto .setBlockedTargetDate(blockItemRequestDTO.getDeleteDate());
						 */
						storeItemDto.setBlockedTargetDate(String.valueOf(blockItemRequestDTO.getDeleteDate()));
						StoreItemHelper helper = new StoreItemHelper();
						int[] upcTokens = helper.getUPCTokens(itemDto.getUpc());
						itemDto.setUpcCountry(Integer.toString(upcTokens[0]));
						itemDto.setUpcSystem(Integer.toString(upcTokens[1]));
						itemDto.setUpcManuf(Integer.toString(upcTokens[2]));
						itemDto.setUpcSales(Integer.toString(upcTokens[3]));
						urx = storeItemDAO.getItemDetails(itemDto.getCic(), itemDto.getUpcCountry(),
								itemDto.getUpcSystem(), itemDto.getUpcManuf(), itemDto.getUpcSales(), storeNumber, corp,
								divisionNumber);
						/* Checking for valid store Item */
						if (null == urx) {
							// log.debug("Validation for Item :" + itemDto.getCic() + " Is Not a Valid Store
							// Item --> True");
							invalidStoreItemList.add(storeItemDto);
							//errorMessages.add(ErrorMessage.INVALID_STORE);
							continue;
						}
						// log.info("Validation for Item :" + itemDto.getCic() + " Is Not a Valid Store
						// Item --> False");

						/* Checking for DSD Item */
						if (urx.isDSDItem()) {
							// log.debug("Validation for Item :" + itemDto.getCic() + " DSD Item --> True");
							dsdStoreItemList.add(storeItemDto);
							//errorMessages.add(ErrorMessage.DSD_STORE_ITEM);
							continue;
						}
						// log.info("Validation for Item :" + itemDto.getCic() + " DSD Item --> False");

						/* Checking for Discontinued Item */
						if (urx.isDiscontinuedItem()) {
							// log.debug("Validation for Item :" +
							// itemDto.getCic() + " Discontinued Item --> True");
							discontinuedStoreItemList.add(storeItemDto);
							//errorMessages.add(ErrorMessage.DISCONTINUED_ITEM);
							continue;
						}
						// log.info("Validation for Item :" + itemDto.getCic() +
						// " Discontinued Item --> False");

						/* Checking for Warehouse as well as DSD Item */
						if (urx.isDSDAndWhseItem()) {
//                            log.debug("Validation for Item :" + itemDto.getCic() + " DSD and Warehouse Item --> True");
							dsdAndWhStoreItemList.add(storeItemDto);
							//errorMessages.add(ErrorMessage.DSD_WH_ITEM);
						}
						// log.info("Validation for Item :" + itemDto.getCic() + " DSD and Warehouse
						// Item --> False");

						/*
						 * Updating the DstCenter,ProductSourceInd,StatusDst to StoreItemDTO
						 */
						itemDto.setDc(urx.getRog().getWds().getDstCenter());
						itemDto.setProductSource(urx.getRog().getProductSourceInd());
						itemDto.setStatusDst(urx.getRog().getWds().getStatusDst());

						storeItemDto.setItemDto(itemDto);

						storeItem = storeItemDAO.getStoreItem(corp, divisionNumber, itemDto.getCic(), itemDto.getDc(),
								storeItemDto.getStoreNumber());
						/*
						 * Checking whether the Item in the process of discontinuation
						 */
						if (null != storeItem) {
							if (storeItem.isItemDiscontinued()) {
								// log.debug("Validation for Item :" + itemDto.getCic() +
								// " Item in the process of Discontinuation --> True");
								discontinuedStoreItemList.add(storeItemDto);
								//errorMessages.add(ErrorMessage.DISCONTINUED_ITEM);
								continue;
							}
							// log.info("Validation for Item :" + itemDto.getCic() +
							// "Item in the process of Discontinuation --> False");

							if (storeItem.isItemBlocked()) {
								// log.debug("Validation for Item :" + itemDto.getCic() +
								// " Duplicate Store Item --> True");
								duplicateItemList.add(storeItemDto);
								//errorMessages.add(ErrorMessage.DUPLICATE_ENTRIES);
								continue;
							}
							// log.info("Validation for Item :" + itemDto.getCic() +
							// " Duplicate Store Item --> False");
						}

						/*
						 * Passed all validation and putting the item into the valid list
						 */
						validStoreItemList.add(storeItemDto);

					} // Store
				} // Item

				/* Creating the BusinessResult */
				businessResult.setDiscontinuedStoreItemList(discontinuedStoreItemList);
				businessResult.setDsdAndWhStoreItemList(dsdAndWhStoreItemList);
				businessResult.setDsdStoreItemList(dsdStoreItemList);
				businessResult.setDuplicateItemList(duplicateItemList);
				businessResult.setInvalidStoreItemList(invalidStoreItemList);
				businessResult.setValidStoreItemList(validStoreItemList);
				businessResult.setErrorMessages(errorMessages);
				if (blockItemRequestDTO.getStoreList().size() != validStoresList.size()) {
					businessResult.setInvalidStoreList(
							filterInvalidStoreList(blockItemRequestDTO.getStoreList(), validStoresList));
					if (!businessResult.getInvalidStoreList().isEmpty()) {
//						 errorMessages.add(ErrorMessage.INVALID_STORE);
//						 businessResult.setErrorMessages(errorMessages);
					}
				} else {
					businessResult.setInvalidStoreList(new ArrayList());
				}
			} else {
				businessResult.setInvalidStoreList(
						filterInvalidStoreList(blockItemRequestDTO.getStoreList(), validStoresList));
				if (!businessResult.getInvalidStoreList().isEmpty()) {
//					 errorMessages.add(ErrorMessage.INVALID_STORE);
//					 businessResult.setErrorMessages(errorMessages);
				}
			}
			/*
			 * discontinuedStoreItemList.clear(); dsdAndWhStoreItemList .clear();
			 * dsdStoreItemList.clear(); duplicateItemList.clear();
			 * invalidStoreItemList.clear(); validStoreItemList.clear();
			 * errorMessages.clear();
			 */
		} catch (MeupException e) {
			log.error("Error in Validator." + "validateItemsAndStores " + e.getMessage());
			throw new MeupException("Error in " + "Validator.validateItemsAndStores " + e.getMessage());
		}

		long endTime = MeupLogUtil.currentTime();
		log.debug(MeupLogUtil.endLog(this.getClass().getName(),
				"validateItemsAndStores(BlockItemRequestDTO requestDto)", endTime - startTime));

		log.info("|<--- Completed Method Validator.validateItemsAndStores(" + "BlockItemRequestDTO requestDto)");
		return businessResult;
	}

}
