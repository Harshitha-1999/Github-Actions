/* ****************************************************************************
 *
 * Copyright 2007, Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of
 * Safeway, Inc.  Information contained herein may not be used,
 * copied or disclosed in whole or in part except as permitted by a
 * written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ************************************************************************** */

package com.safeway.app.meup.service;

import java.sql.SQLException;
import java.util.List;

import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.HoldSearchFieldsDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.ResponseStockingSectionDTO;
import com.safeway.app.meup.exceptions.MeupException;


public interface HoldItemsService {

	
	HoldSearchFieldsDTO getStockSectionDivisionOnHold(String corp, String groupCode) throws MeupException, SQLException;


	ResponseDTO getItemCountsOnHold(String corp, List<String> stockingSectionList, List<String> divisionList)
			throws MeupException, SQLException;


	 ResponseDTO updateItemsStoreLevel(ResponseStockingSectionDTO responseStockingSectionDTO)
	 throws MeupException,SQLException;


	List<HoldItemDTO> getItemListForStoreStockSection(String corp, String storeID, String stockSectionNbr)
			throws MeupException, SQLException;

	ResponseDTO updateItemsByStoreStockSection(ResponseStockingSectionDTO responseStockingSectionDTO, String groupId) throws MeupException, SQLException;

}
