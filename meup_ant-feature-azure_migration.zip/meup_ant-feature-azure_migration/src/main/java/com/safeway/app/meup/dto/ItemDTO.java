
package com.safeway.app.meup.dto;



public class ItemDTO {

    private String upc;
    /**
     * delcaring productSource.
     */
    private String productSource;

    /**
     * delcaring statusDst.
     */
    private String statusDst;

    /**
     * holds the distribution center code.
     */
    private String dc;

    /**
     * holds the upc_country code.
     */
    private String upcCountry;

    /**
     * holds the upc_manuf code.
     */
    private String upcManuf;

    /**
     * holds the upc_sales code.
     */
    private String upcSales;

    /**
     * holds the upc_system code.
     */
    private String upcSystem;
    /**
     * holds the cic.
     */
    private String cic;

    public ItemDTO() {
        super();

    }

    /**
     * @param upc_sales
     * @param upc_manuf
     * @param upc_system
     * @param upc_country
     * @param cic
     */
    public ItemDTO(String upc_sales, String upc_manuf, String upc_system,
                   String upc_country, String cic) {
        super();
        this.upcSales = upc_sales;
        this.upcManuf = upc_manuf;
        this.upcSystem = upc_system;
        this.upcCountry = upc_country;
        this.cic = cic;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    /**
     * @return Returns the dispUpc.
     */
    public String getDispUpc() {
        return upcCountry + upcSystem + upcManuf + upcSales;
    }

    /**
     * @return Returns the dc.
     */
    public String getDc() {
        return dc;
    }

    /**
     * @param dc The dc to set.
     */
    public void setDc(String dc) {
        this.dc = dc;
    }

    /**
     * @return Returns the upcCountry.
     */
    public String getUpcCountry() {
        return upcCountry;
    }

    /**
     * @param upcCountry The upcCountry to set.
     */
    public void setUpcCountry(String upcCountry) {
        this.upcCountry = upcCountry;
    }

    /**
     * @return Returns the upcManuf.
     */
    public String getUpcManuf() {
        return upcManuf;
    }

    /**
     * @param upcManuf The upcManuf to set.
     */
    public void setUpcManuf(String upcManuf) {
        this.upcManuf = upcManuf;
    }

    /**
     * @return Returns the upcSales.
     */
    public String getUpcSales() {
        return upcSales;
    }

    /**
     * @param upcSales The upcSales to set.
     */
    public void setUpcSales(String upcSales) {
        this.upcSales = upcSales;
    }

    /**
     * @return Returns the upcSystem.
     */
    public String getUpcSystem() {
        return upcSystem;
    }

    /**
     * @param upcSystem The upcSystem to set.
     */
    public void setUpcSystem(String upcSystem) {
        this.upcSystem = upcSystem;
    }

    /**
     * @return Returns the cic.
     */
    public String getCic() {
        return cic;
    }

    /**
     * @param cic The cic to set.
     */
    public void setCic(String cic) {
        this.cic = cic;
    }

    /**
     * Method to print the object details
     *
     * @return String
     */
    public String toString() {
        StringBuffer sbuff = new StringBuffer();
        sbuff.append("dc: " + this.getDc() + " ");
        sbuff.append("upc_sales: " + this.getUpcSales() + " ");
        sbuff.append("upc_manuf: " + this.getUpcManuf() + " ");
        sbuff.append("upc_system: " + this.getUpcSystem() + " ");
        sbuff.append("upc_country: " + this.getUpcCountry() + " ");
        sbuff.append("cic: " + this.getCic() + " ");
        return sbuff.toString();
    }

    /**
     * @return Returns the productSource.
     */
    public String getProductSource() {
        return productSource;
    }

    /**
     * @param productSource The productSource to set.
     */
    public void setProductSource(String productSource) {
        this.productSource = productSource;
    }

    /**
     * @return Returns the statusDst.
     */
    public String getStatusDst() {
        return statusDst;
    }

    /**
     * @param statusDst The statusDst to set.
     */
    public void setStatusDst(String statusDst) {
        this.statusDst = statusDst;
    }


}
