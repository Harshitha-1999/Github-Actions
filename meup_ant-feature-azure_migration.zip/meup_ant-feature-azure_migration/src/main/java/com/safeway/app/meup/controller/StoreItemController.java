package com.safeway.app.meup.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.HoldSearchFieldsDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.ResponseStockingSectionDTO;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.dto.UpdateStoreItemDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.HoldItemsService;
import com.safeway.app.meup.service.StoreItemService;
import com.safeway.app.meup.vox.StoreItemHistoryVO;

@RestController
public class StoreItemController extends BaseController {
	private static final Logger log = LoggerFactory.getLogger(StoreItemController.class);

	@Autowired
	private HoldItemsService holdItemsService;

	@Autowired
	private StoreItemService storeItemService;

	@GetMapping("/v1/items/hold")
	public ResponseDTO getStoreItemsOnHold(@RequestParam String corp, @RequestParam String groupCode)
			throws MeupException, SQLException {
		log.info("--> Beginning- StoreItemController.getStoreItemsOnHold");
		HoldSearchFieldsDTO holdSearchFields = holdItemsService.getStockSectionDivisionOnHold(corp, groupCode);
		ResponseDTO responseDTO = getResponseDTO(holdSearchFields);
		log.info("--> Completed- StoreItemController.getStoreItemsOnHold");
		return responseDTO;
	}

	@GetMapping("/v1/items/hold/storeCount")
	public ResponseDTO getStoreCountsStoreItemsOnHold(@RequestParam String corp,
			@RequestParam List<String> stockingSectionList, @RequestParam List<String> divisionList)
			throws MeupException, SQLException {
		log.info("--> StoreItemController.getStoreCountsStoreItemsOnHold");
		ResponseDTO countsByStoreDto = holdItemsService.getItemCountsOnHold(corp, stockingSectionList, divisionList);
		return countsByStoreDto;
	}

	@GetMapping("/v1/items/storeStockSection")
	public ResponseDTO getItemListForStoreStockSection(@RequestParam String corp, @RequestParam String storeID,
			@RequestParam String stockSectionNbr) throws MeupException, SQLException {
		log.info("--> StoreItemController.getItemListForStoreStockSection");
		List<HoldItemDTO> list = holdItemsService.getItemListForStoreStockSection(corp, storeID, stockSectionNbr);
		ResponseDTO responseDTO = getResponseDTO(list);
		return responseDTO;
	}

	@PostMapping("/v1/items")
	public ResponseDTO getStoreItems(@RequestBody StoreItemSearchDTO storeItemSearchDTO) throws MeupException {
		log.info("-->Beginning- StoreItemController.getStoreItems");
		ResponseDTO storeItemDTOList = storeItemService.getStoreItemsForUpdate(storeItemSearchDTO);
		log.info("-->Completed- StoreItemController.getStoreItems");
		return storeItemDTOList;
	}

	@PostMapping("v1/items/hold/updateStatus")
	public ResponseDTO blockItemsStatus(@RequestBody ResponseStockingSectionDTO responseStockingSectionDTO,
			@RequestParam String groupId) throws MeupException, SQLException {
		log.info("-->Beginning- StoreItemController.blockItemsStatus");
		ResponseDTO responseDTO = holdItemsService.updateItemsByStoreStockSection(responseStockingSectionDTO, groupId);
		log.info("-->Completed- StoreItemController.blockItemsStatus");
		return responseDTO;
	}

	@PostMapping("v1/items/hold/updateStoreLevel")
	public ResponseDTO updateItemsStoreLevel(@RequestBody ResponseStockingSectionDTO responseStockingSectionDTO)
			throws MeupException, SQLException {
		log.info("--> Beginning- StoreItemController.updateItemsStoreLevel");
		ResponseDTO responseDTO = holdItemsService.updateItemsStoreLevel(responseStockingSectionDTO);
		log.info("--> Completed- StoreItemController.updateItemsStoreLevel");
		return responseDTO;

	}

	@RequestMapping(value = "/v1/items/update", method = RequestMethod.POST)
	public ResponseDTO updateStoreItems(@RequestBody UpdateStoreItemDTO updateStoreItemDTO)
			throws MeupException, SQLException {
		log.info("-->Beginning- StoreItemController.updateStoreItems");
		ResponseDTO storeItemUpdateStatusList = storeItemService.updateStoreItems(updateStoreItemDTO);
		log.info("-->Completed- StoreItemController.updateStoreItems");
		return storeItemUpdateStatusList;
	}

	@PostMapping("/v1/report/item/history")
	public ResponseDTO getStoreItemReportHistory(@RequestBody StoreItemDTO selectedStoreItemDTO) throws MeupException {
		log.info("-->Beginning- StoreItemController.getStoreItemReportHistory");
		List<StoreItemHistoryVO> storeItemDTOList = storeItemService.getStoreItemsForHistory(selectedStoreItemDTO);
		log.info("-->Completed- StoreItemController.getStoreItemReportHistory");
		return getResponseDTO(storeItemDTOList);
	}

	/**
	 * Method to get report for items
	 *
	 * @return
	 * @throws MeupException
	 * @throws SQLException
	 */
	@PostMapping("/v1/report/items")
	public ResponseDTO getStoreItemsForReport(@RequestBody StoreItemSearchDTO storeItemSearchDTO)
			throws MeupException, SQLException {
		log.info("--> StoreItemController.getStoreItemsForReport");
		ResponseDTO storeItemDTOList = storeItemService.getStoreItemsForReport(storeItemSearchDTO);
		return storeItemDTOList;
	}

	/**
	 * Method to get report for items
	 *
	 * @param storeItemDtoList -List of store Items
	 * @return
	 * @throws MeupException
	 * @throws IOException
	 */
	@PostMapping("v1/items/report")
	public void getItemsReport(@RequestBody List<StoreItemDTO> storeItemDtoList, HttpServletResponse response)
			throws MeupException, IOException, ParseException {
		log.info("-->Begin StoreItemController.getItemsReport");
		storeItemService.createExcelExport(storeItemDtoList, response);
		log.info("-->Completed StoreItemController.getItemsReport");
	}

	/**
	 * Method to upload block items
	 *
	 * @param itemsFile  -File to block store items
	 * @param userID     -User uploading the file
	 * @param deleteDate -Delete date for items
	 * @return result
	 * @throws MeupException
	 */
	@PostMapping("/v1/items/upload")
	public ResponseDTO uploadStoreItems(@RequestParam(value = "itemsFile") final MultipartFile itemsFile,
			@RequestParam(value = "userID") final String userID,
			@RequestParam(value = "deleteDate") final Date deleteDate) throws MeupException {
		log.info("--> StoreItemController.uploadStoreItems");
		ResponseDTO responseDTO = storeItemService.uploadCSVFile(itemsFile, userID, deleteDate);
		return responseDTO;
	}

	/**
	 * @param blockItemRequestDTO
	 * @return
	 * @throws MeupException
	 */
	@PostMapping("v1/items/block")
	public ResponseDTO blockItemsAndStores(@RequestBody BlockItemRequestDTO blockItemRequestDTO)
			throws MeupException, ParseException {
		log.info("--> StoreItemController.blockItemsAndStores");
		List<?> blockedList = storeItemService.blockItemsAndStores(blockItemRequestDTO);
		ResponseDTO responseDTO = getResponseDTO(blockedList);
		return responseDTO;
	}

}
