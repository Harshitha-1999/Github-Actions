

package com.safeway.app.meup.dto;



import com.safeway.app.meup.dto.SerializableDTO;

import java.sql.Date;
import java.util.List;



public class UpdateStoreItemDTO extends SerializableDTO {

	private List<StoreItemDTO> storeItemDTOList;

	/**holds the delete date.*/
	private String deleteDate;

	/**holds the comments entered.*/
	private String comment;

	private String userId;

	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId The commentDesc to set.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}


	/**
	 * @return Returns the blockedTargetDate.
	 */
	public String getDeleteDate() {
		return deleteDate;
	}
	
	/**
	 * @param deleteDate The blockedTargetDate to set.
	 */
	public void setDeleteDate(String deleteDate) {
		this.deleteDate = deleteDate;
	}
	

	public String getComment() {
		return comment;
	}
	
	/**
	 * @param comment The commentDesc to set.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return Returns the divisionDto.
	 */
	public List<StoreItemDTO> getStoreItemDTOList() {
		return storeItemDTOList;
	}
	
	/**
	 * @param storeItemDTOList The divisionDto to set.
	 */
	public void setStoreItemDTO(List<StoreItemDTO> storeItemDTOList) {
		this.storeItemDTOList = storeItemDTOList;
	}

	
	/**
	 * Method to print the object details
	 *
	 * @return String
	 */
	public String toString() {
		StringBuffer sbuff = new StringBuffer();
		sbuff.append("StoreItemDTOLidt: " + this.getStoreItemDTOList() + (" "));
		sbuff.append("comment: " + this.getComment() + (" "));
		sbuff.append("deleteDate: " + this.getDeleteDate() + " ");
		return sbuff.toString();
	}
}
