
package com.safeway.app.meup.dto;


public class StoreItemHistoryDTO extends StoreItemDTO {
	
    /**
	 * Commment String 
	 */
	private String  comment;

	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment The comment to set.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
}
