package com.safeway.app.meup.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ResponseDTO implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String SUCCESS_OPERATION = "SUCCESS";
    public static final String FAILURE_OPERATION = "FAILED";
    public static final String REST_DATA = "REST_RETURNED_DATA";

    private String status;
    private Map<String, Object> data;
    private List<JsonErrorDTO> errorDTOList;
    private List<JsonErrorDTO> warningsDTOList;

    public ResponseDTO() {
        errorDTOList = new ArrayList<>();
        warningsDTOList = new ArrayList<>();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public List<JsonErrorDTO> getErrorDTOList() {
        return errorDTOList;
    }

    public void setErrorDTOList(List<JsonErrorDTO> errorDTOList) {
        this.errorDTOList = errorDTOList;
    }

    public void addErrorDTO(JsonErrorDTO errorDTO) {
        if(null!=errorDTOList){
            errorDTOList.add(errorDTO);
        }
    }

    public List<JsonErrorDTO> getWarningsDTOList() {
        return warningsDTOList;
    }

    public void setWarningsDTOList(List<JsonErrorDTO> warningsDTOList) {
        this.warningsDTOList = warningsDTOList;
    }
}
