package com.safeway.app.meup.controller;


import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dto.HoldItemDTO;
import com.safeway.app.meup.dto.HoldSearchFieldsDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.dto.UpdateStoreItemDTO;
import com.safeway.app.meup.service.HoldItemsService;
import com.safeway.app.meup.service.StoreItemService;
import com.safeway.app.meup.vox.StoreItemHistoryVO;

@WebMvcTest(StoreItemController.class)
class StoreItemControllerTest {

    @Autowired
    private MockMvc mockmvc;

    @MockBean
    private StoreItemService storeItemService;

    @MockBean
    private HoldItemsService holdItemsService;

    StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
    ResponseDTO responseDTO=new ResponseDTO();
    UpdateStoreItemDTO updateStoreItemDTO= new UpdateStoreItemDTO();
    MultipartFile itemsFile;
    HoldSearchFieldsDTO holdSearchFieldsDTO=new HoldSearchFieldsDTO();

    @Test
    void getStoreItemsTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/items").accept(MediaType.APPLICATION_JSON)
                .content("{\"StoreItemSearchDTO\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(storeItemService.getStoreItemsForUpdate(storeItemSearchDTO)).thenReturn(responseDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void getStoreItemsForReportTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/report/items").accept(MediaType.APPLICATION_JSON)
                .content("{\"StoreItemSearchDTO\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(storeItemService.getStoreItemsForReport(storeItemSearchDTO)).thenReturn(responseDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void updateStoreItemsTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/items/update").accept(MediaType.APPLICATION_JSON)
                .content("{\"UpdateStoreItemDTO\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(storeItemService.updateStoreItems(updateStoreItemDTO)).thenReturn(responseDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void uploadStoreItemsTest() throws Exception {
        String str="2022-04-30";
        Date deleteDate=Date.valueOf(str);
        byte[] json = "{\"UPC\":\"upcValue\"\"CIC\":\"cicValue\"}".getBytes(StandardCharsets.UTF_8);
        Mockito.when(storeItemService.uploadCSVFile(itemsFile,"SMURA16", deleteDate)).thenReturn(responseDTO);
        mockmvc.perform(MockMvcRequestBuilders.multipart("/v1/items/upload")
                .file("itemsFile",json)
                .param("userID", "SMURA16")
                .param("deleteDate","2022-04-30"))
                .andExpect(status().isOk()).andReturn();
    }

    @Test
    void getItemsReportTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/items/report").accept(MediaType.APPLICATION_JSON)
                .content("[{\"StoreItemDtoList\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}]")
                .contentType(MediaType.APPLICATION_JSON);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
        verify(storeItemService).createExcelExport(Mockito.any(),Mockito.any());

    }

    @Test
    void blockItemsAndStoresTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/items/block").accept(MediaType.APPLICATION_JSON)
                .content("{\"BlockItemRequestDTO\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}")
                .contentType(MediaType.APPLICATION_JSON);
        List storeItemBusinessResult=new ArrayList();
        Mockito.when(storeItemService.blockItemsAndStores(Mockito.any())).thenReturn(storeItemBusinessResult);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void getStoreItemsOnHoldTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/items/hold").param("corp","001").param("groupCode","05");
        Mockito.when(holdItemsService.getStockSectionDivisionOnHold("001","05")).thenReturn(holdSearchFieldsDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }


    @Test
    void getStoreCountsStoreItemsOnHoldTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/items/hold/storeCount").accept(MediaType.APPLICATION_JSON)
                .param("corp","001").param("stockingSectionList","{05}")
                .param("divisionList","{05}")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(holdItemsService.getItemCountsOnHold(Mockito.any(),Mockito.anyList(),Mockito.anyList())).thenReturn(responseDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

@Test
	void blockItemsStatusTest() throws Exception {
		RequestBuilder request = MockMvcRequestBuilders.post("/v1/items/hold/updateStatus").accept(MediaType.APPLICATION_JSON)
				.content("{\"ResponseStockingSectionDTO\":{\r\n" +
						"\"DTOfields\":\"fieldValues\"\r\n" +
						"}}").param("groupId","05")
				.contentType(MediaType.APPLICATION_JSON);
    Mockito.when(holdItemsService.updateItemsByStoreStockSection(Mockito.any(),Mockito.anyString())).thenReturn(responseDTO);
		mockmvc.perform(request).andExpect(status().isOk()).andReturn();
	}

    @Test
    void getItemListForStoreStockSectionTest() throws Exception {
        List<HoldItemDTO> list =new ArrayList<>();
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/items/storeStockSection").accept(MediaType.APPLICATION_JSON)
                .param("corp","001").param("storeID","05").param("stockSectionNbr","05")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(holdItemsService.getItemListForStoreStockSection(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(list);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void updateItemsStoreLevelTest() throws Exception {
        List<HoldItemDTO> list =new ArrayList<>();
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/items/hold/updateStoreLevel").accept(MediaType.APPLICATION_JSON)
                .content("{\"ResponseStockingSectionDTO\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(holdItemsService.updateItemsStoreLevel(Mockito.any())).thenReturn(responseDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void getStoreItemReportHistoryTest() throws Exception {
        List<StoreItemHistoryVO> storeItemDTOList=new ArrayList<>();
        RequestBuilder request = MockMvcRequestBuilders.post("/v1/report/item/history").accept(MediaType.APPLICATION_JSON)
                .content("{\"StoreItemDTO\":{\r\n" +
                        "\"DTOfields\":\"fieldValues\"\r\n" +
                        "}}")
                .contentType(MediaType.APPLICATION_JSON);
        Mockito.when(storeItemService.getStoreItemsForHistory(Mockito.any())).thenReturn(storeItemDTOList);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }




}
