package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.safeway.app.meup.dao.SmicGroupDAO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.impl.SmicGroupServiceImpl;


@ExtendWith(MockitoExtension.class)
class SmicGroupServiceImplTest {
	
	@Mock
	private SmicGroupDAO smicGroupDAO;

	@InjectMocks
	private SmicGroupServiceImpl service;
	
	@Test
	void getSmicGroupsForDivisionTest() throws MeupException {
		List<SmicGroupDTO> expectedGroupDTOList = new ArrayList<>();
		Mockito.when(smicGroupDAO.selectSmicGroupsForDivision(Mockito.any(),Mockito.any())).thenReturn(expectedGroupDTOList);
		List<SmicGroupDTO> actualdGroupVOXList=service.getSmicGroupsForDivision(Mockito.anyList(),Mockito.any());
		assertEquals(expectedGroupDTOList, actualdGroupVOXList);
	}

	@Test
	void getSmicCategoriesForGroupsTest() throws MeupException {
		List<SmicCategoryDTO> expectedCategoryDTOList = new ArrayList<>();
		Mockito.when(smicGroupDAO.selectSmicCategoriesForGroups(Mockito.any(),Mockito.any())).thenReturn(expectedCategoryDTOList);
		List<SmicCategoryDTO> actualCategoryVOXList=service.getSmicCategoriesForGroups(Mockito.anyList(),Mockito.any());
		assertEquals(expectedCategoryDTOList, actualCategoryVOXList);
	}

	@Test
	void getGroupsByStatusTest() throws MeupException, SQLException {
		List<SmicGroupDTO> expectedCategoryDTOList = new ArrayList<>();
		Mockito.when(smicGroupDAO.getGroupsByStatus("001",'H','H')).thenReturn(expectedCategoryDTOList);
		List<SmicGroupDTO> actualCategoryVOXList=service.getGroupsByStatus("001");
		assertEquals(expectedCategoryDTOList, actualCategoryVOXList);
	}


}
