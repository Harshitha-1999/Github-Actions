package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.dao.StoreItemHistoryDAO;
import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.StoreItemBusinessResult;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemExcelViewerDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.dto.UpdateStoreItemDTO;
import com.safeway.app.meup.dto.UserDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.impl.StoreItemServiceImpl;
import com.safeway.app.meup.util.HoldItemMgrHelper;
import com.safeway.app.meup.util.MeupConstant;
import com.safeway.app.meup.util.StoreItemHelper;
import com.safeway.app.meup.vox.StoreItemHistoryVO;
import com.safeway.app.meup.vox.StoreItemVO;


@ExtendWith(MockitoExtension.class)
class StoreItemServiceImplTest {
	@Mock
	private StoreItemDAO storeItemDAO;
	@Mock
	private DivisionService divisionService;
	@Mock
	private StagingHdrService stagingHdrService;
	@Mock
	private HoldItemMgrHelper holdItemMgrHelper;
	@Mock
	private ValidationService validationService;
	@Mock
	private StoreItemHistoryDAO storeItemHistoryDAO;
	@Mock
	private 
	StoreItemServiceImpl storeItemServiceImpl;


	@InjectMocks
	private StoreItemServiceImpl service;

	@Test
	void createExcelViewerListTest() throws MeupException {
		List<StoreItemDTO> items=new ArrayList<>();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		DivisionDTO divisionDTO=new DivisionDTO();
		divisionDTO.setDivisionNumber(" ");
		storeItemDTO.setDivisionDto(divisionDTO);
		storeItemDTO.setStoreNumber(" ");
		SmicCategoryDTO smicCategoryDTO=new SmicCategoryDTO();
		smicCategoryDTO.setCategoryCd(" ");
		smicCategoryDTO.setcategoryDesc(" ");
		smicCategoryDTO.setGroupCd(" ");
		storeItemDTO.setSmicCategoryDto(smicCategoryDTO);
		storeItemDTO.setUpc(" ");
		ItemDTO itemDTO=new ItemDTO();
		itemDTO.setCic(" ");
		storeItemDTO.setItemDto(itemDTO);
		storeItemDTO.setDescription(" ");
		storeItemDTO.setItemType(" ");
		storeItemDTO.setSize(243245);
		storeItemDTO.setUom(" ");
		storeItemDTO.setCasePk(23423);
		storeItemDTO.setState(" ");
		//Mockito.when(storeItemDTO.getDispBlockedStatus()).thenReturn(" ");
		storeItemDTO.setBlockedStatus(" ");
		storeItemDTO.setBlockedTargetDate(" ");
		items.add(storeItemDTO);
		List<StoreItemExcelViewerDTO> uiList=service.createExcelViewerList(items);
		assertNotNull(uiList);
	}



	@Test
	void createExcelExportTest() throws MeupException, ParseException {
		List<StoreItemDTO> items=new ArrayList<>();
		StoreItemDTO storeItemDTO = new StoreItemDTO();
		storeItemDTO.setBlockedStatus("A");
		storeItemDTO.setCasePk(1.0f);
		storeItemDTO.setItemType("Any");
		storeItemDTO.setStatus("Success");
		storeItemDTO.setStateEffectiveDate("2022-05-22");
		DivisionDTO divisionDTO = new DivisionDTO();
		divisionDTO.setDivisionNumber("1");
		divisionDTO.setDivisionName("TCS");
		divisionDTO.setCorp("ABS");
		storeItemDTO.setDivisionDto(divisionDTO);
		SmicCategoryDTO smicCategoryDTO = new SmicCategoryDTO();
		smicCategoryDTO.setcategoryDesc("Desc");
		storeItemDTO.setSmicCategoryDto(smicCategoryDTO);
		ItemDTO itemDTO = new ItemDTO();
		itemDTO.setCic("CIC");
		storeItemDTO.setItemDto(itemDTO);
		items.add(storeItemDTO);
		
		HttpServletResponse response=new HttpServletResponse() {
			@Override
			public String getCharacterEncoding() {
				return null;
			}
			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public ServletOutputStream getOutputStream() throws IOException {
				return null;
			}

			@Override
			public PrintWriter getWriter() throws IOException {
				return null;
			}

			@Override
			public void setCharacterEncoding(String charset) {

			}

			@Override
			public void setContentLength(int len) {

			}

			@Override
			public void setContentLengthLong(long length) {

			}

			@Override
			public void setContentType(String type) {

			}

			@Override
			public void setBufferSize(int size) {

			}

			@Override
			public int getBufferSize() {
				return 0;
			}

			@Override
			public void flushBuffer() throws IOException {

			}

			@Override
			public void resetBuffer() {

			}

			@Override
			public boolean isCommitted() {
				return false;
			}

			@Override
			public void reset() {

			}

			@Override
			public void setLocale(Locale loc) {

			}

			@Override
			public Locale getLocale() {
				return null;
			}

			@Override
			public void addCookie(Cookie cookie) {

			}

			@Override
			public boolean containsHeader(String name) {
				return false;
			}

			@Override
			public String encodeURL(String url) {
				return null;
			}

			@Override
			public String encodeRedirectURL(String url) {
				return null;
			}

			@Override
			public String encodeUrl(String url) {
				return null;
			}

			@Override
			public String encodeRedirectUrl(String url) {
				return null;
			}

			@Override
			public void sendError(int sc, String msg) throws IOException {

			}

			@Override
			public void sendError(int sc) throws IOException {

			}

			@Override
			public void sendRedirect(String location) throws IOException {

			}

			@Override
			public void setDateHeader(String name, long date) {

			}

			@Override
			public void addDateHeader(String name, long date) {

			}

			@Override
			public void setHeader(String name, String value) {

			}

			@Override
			public void addHeader(String name, String value) {

			}

			@Override
			public void setIntHeader(String name, int value) {

			}

			@Override
			public void addIntHeader(String name, int value) {

			}

			@Override
			public void setStatus(int sc) {

			}

			@Override
			public void setStatus(int sc, String sm) {

			}

			@Override
			public int getStatus() {
				return 0;
			}

			@Override
			public String getHeader(String name) {
				return null;
			}

			@Override
			public Collection<String> getHeaders(String name) {
				return null;
			}

			@Override
			public Collection<String> getHeaderNames() {
				return null;
			}
		};
		String message=service.createExcelExport(items,response);
		assertNotNull(message);
	}
	@Test
	void updateStoreItemsTest() throws MeupException, SQLException {
		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDto =new StoreItemDTO();
		storeItemDTOList.add(storeItemDto);
		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
		updateStoreItemDTO.setComment("");
		ResponseDTO responseDTO=service.updateStoreItems(updateStoreItemDTO);
		assertNotNull(responseDTO);
	}

	@Test
	void updateStoreItemsTest_DeleteDateNOtNull() throws MeupException, SQLException {
		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDto =new StoreItemDTO();
		storeItemDTOList.add(storeItemDto);
		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
		updateStoreItemDTO.setComment("");
		updateStoreItemDTO.setDeleteDate(" ");
		ResponseDTO responseDTO=service.updateStoreItems(updateStoreItemDTO);
		assertNotNull(responseDTO);
	}

	@Test
	void modifyDeleteDateTest_ValidationPass() throws MeupException, SQLException {
		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDto =new StoreItemDTO();
		storeItemDTOList.add(storeItemDto);
		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
		updateStoreItemDTO.setComment("");
		ResponseDTO responseDTO=service.modifyDeleteDate(updateStoreItemDTO);
		assertNotNull(responseDTO);
	}

	@Test
	void modifyDeleteDateTest() throws MeupException, SQLException {
		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDto =new StoreItemDTO();
		storeItemDto.setSelected(true);
		storeItemDTOList.add(storeItemDto);
		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
		updateStoreItemDTO.setComment("");
		ResponseDTO responseDTO=service.modifyDeleteDate(updateStoreItemDTO);
		assertNotNull(responseDTO);
	}

//	@Test
//	void modifyDeleteDateTest_ValidationFail() throws MeupException, SQLException {
//		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
//		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
//		StoreItemDTO storeItemDto =new StoreItemDTO();
//		storeItemDTOList.add(storeItemDto);
//		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
//		updateStoreItemDTO.setComment("");
//		List<String> validationResult=new ArrayList<>();
//		validationResult.add(" ");
//		Boolean isUnblock=false;
//		Mockito.when(validationService.validateStoreItemUpdate(updateStoreItemDTO.getStoreItemDTOList(), isUnblock, updateStoreItemDTO.getComment())).thenReturn(validationResult);
//		ResponseDTO responseDTO=service.modifyDeleteDate(updateStoreItemDTO);
//		assertNotNull(responseDTO);
//	}

	@Test
	void unblockStoreItemsTest_ValidationPass() throws MeupException, SQLException {
		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDto =new StoreItemDTO();
		storeItemDTOList.add(storeItemDto);
		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
		updateStoreItemDTO.setComment("");
		ResponseDTO responseDTO=service.unblockStoreItems(updateStoreItemDTO);
		assertNotNull(responseDTO);
	}

	@Test
	void unblockStoreItemsTest() throws MeupException, SQLException {
		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDto =new StoreItemDTO();
		storeItemDto.setSelected(true);
		storeItemDto.setCommentDesc("Test");
		storeItemDTOList.add(storeItemDto);
		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
		updateStoreItemDTO.setComment("");
		ResponseDTO responseDTO=service.unblockStoreItems(updateStoreItemDTO);
		assertNotNull(responseDTO);
	}

//	@Test
//	void unblockStoreItemsTest_ValidationFail() throws MeupException, SQLException {
//		UpdateStoreItemDTO updateStoreItemDTO=new UpdateStoreItemDTO();
//		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
//		StoreItemDTO storeItemDto =new StoreItemDTO();
//		storeItemDTOList.add(storeItemDto);
//		updateStoreItemDTO.setStoreItemDTO(storeItemDTOList);
//		updateStoreItemDTO.setComment("");
//		List<String> validationResult=new ArrayList<>();
//		validationResult.add(" ");
//		Boolean isUnblock=true;
//		Mockito.when(validationService.validateStoreItemUpdate(updateStoreItemDTO.getStoreItemDTOList(), isUnblock, updateStoreItemDTO.getComment())).thenReturn(validationResult);
//		ResponseDTO responseDTO=service.unblockStoreItems(updateStoreItemDTO);
//		assertNotNull(responseDTO);
//	}

	@Test
	void getStoreItemsForReportTest_ValidationPass() throws MeupException, SQLException {
		List<String> validationResult=new ArrayList<>();
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		ResponseDTO responseDTO=service.getStoreItemsForReport(storeItemSearchDTO);
		verify(storeItemDAO).selectStoreItemsForReport(Mockito.any());
		verify(validationService).validateFieldsForReportStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}

	@Test
	void getStoreItemsForReportTest_ValidationFail() throws MeupException, SQLException {
		List<String> validationResult=new ArrayList<>();
		validationResult.add(" ");
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCic("candy");
		Mockito.when(validationService.validateFieldsForReportStoreItems(storeItemSearchDTO)).thenReturn(validationResult);
		ResponseDTO responseDTO=service.getStoreItemsForReport(storeItemSearchDTO);
		verify(validationService).validateFieldsForReportStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}

//	@Test
//	void getStoreItemsForUpdateTest_ValidationPass() throws MeupException {
//		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
//		storeItemSearchDTO.setState("CA");
//		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
//		verify(storeItemDAO).selectBlockedWhStoreItems(storeItemSearchDTO);
//		verify(validationService).validateFieldsForUpdateStoreItems(Mockito.any());
//		assertNotNull(responseDTO);
//	}
//
//	@Test
//	void getStoreItemsForUpdateTest_ValidationFail() throws MeupException {
//		List<String> validationResult=new ArrayList<>();
//		validationResult.add(" ");
//		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
//		storeItemSearchDTO.setCic("candy");
//		Mockito.when(validationService.validateFieldsForUpdateStoreItems(storeItemSearchDTO)).thenReturn(validationResult);
//		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
//		assertNotNull(responseDTO);
//	}

	@Test
	void getStoreItemsForUpdateTest_ValidationPass() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		UserDTO userDto=new UserDTO();
		userDto.setRole(" ");
		storeItemSearchDTO.setUserDto(userDto);
		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
		verify(storeItemDAO).selectBlockedWhStoreItems(storeItemSearchDTO);
		verify(validationService).validateFieldsForUpdateStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}

	@Test
	void getStoreItemsForUpdateTest_ValidationPass_stateNotNull() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setState(" ");
		UserDTO userDto=new UserDTO();
		userDto.setRole(" ");
		storeItemSearchDTO.setUserDto(userDto);
		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
		verify(storeItemDAO).selectBlockedWhStoreItems(storeItemSearchDTO);
		verify(validationService).validateFieldsForUpdateStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}

	@Test
	void getStoreItemsForUpdateTest_ValidationPass_stateUnallocated() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setState("Unallocated");
		UserDTO userDto=new UserDTO();
		userDto.setRole(" ");
		storeItemSearchDTO.setUserDto(userDto);
		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
		verify(storeItemDAO).selectBlockedWhStoreItems(storeItemSearchDTO);
		verify(validationService).validateFieldsForUpdateStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}

	@Test
	void getStoreItemsForUpdateTest_ValidationFail() throws MeupException {
		List<String> validationResult=new ArrayList<>();
		validationResult.add(" ");
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		UserDTO userDto=new UserDTO();
		userDto.setRole(" ");
		storeItemSearchDTO.setUserDto(userDto);
		storeItemSearchDTO.setCic("candy");
		Mockito.when(validationService.validateFieldsForUpdateStoreItems(storeItemSearchDTO)).thenReturn(validationResult);
		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
		assertNotNull(responseDTO);
	}




	@Test
	void uploadCSVFileTest() throws MeupException, ParseException {
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return null;
			}

			@Override
			public String getOriginalFilename() {
				return null;
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[0];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		String userID="";
		long millis=System.currentTimeMillis();
		Date deleteDate=new Date(millis);
		ResponseDTO responseDTO=service.uploadCSVFile(itemsFile,userID, deleteDate);
		verify(validationService).validateBlockItemCSVFile(Mockito.any(),Mockito.any(),Mockito.any());
		verify(divisionService).getCorpForDiv(Mockito.any());
		stagingHdrService.uploadCSVFile(Mockito.any(),Mockito.any());
		assertNotNull(responseDTO);
	}

	@Test
	void extractFileDataTest() throws MeupException, IOException {
		List expectedContent = new ArrayList();
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return null;
			}

			@Override
			public String getOriginalFilename() {
				return null;
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[0];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		List actualContent =service.extractFileData(itemsFile);
		assertEquals(expectedContent, actualContent);
	}

	@Test
	void extractFileDataTest_FileNotEmpty() throws MeupException, IOException {
		List expectedContent = new ArrayList();
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return null;
			}

			@Override
			public String getOriginalFilename() {
				return null;
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[200];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		List actualContent =service.extractFileData(itemsFile);
		assertNotNull(actualContent);
	}

	@Test
	void parseContentCICUPCTest() throws  ParseException {
		List<ItemDTO> expectedItemDTOList = new ArrayList<>();
		List<String> contents=new ArrayList<>();
		List<ItemDTO> actualItemDTOList =service.parseContentCICUPC(contents);
		assertEquals(expectedItemDTOList, actualItemDTOList);
	}

	@Test
	void parseContentCICUPCTest1() throws  ParseException {
		List<ItemDTO> expectedItemDTOList = new ArrayList<>();
		List<String> contents=new ArrayList<>();
		contents.add(" 085981500201,1010123");
		contents.add("  ");
		contents.add("  ");
		contents.add(" 085981500201,1010123");
		contents.add(" 085981500201,1010123");
		contents.add(" 085981500201,1010123");
		contents.add(" 085981500201,1010123");
		contents.add(" 085981500201,1010123");
		List<ItemDTO> actualItemDTOList =service.parseContentCICUPC(contents);
		assertNotNull( actualItemDTOList);
	}

	@Test
	void parseContentCICUPCTest2() throws  ParseException {
		List<ItemDTO> expectedItemDTOList = new ArrayList<>();
		List<String> contents=new ArrayList<>();
		contents.add(" 085981500201,1010123");
		contents.add("  ");
		contents.add("  ");
		contents.add(" 0859815002,1010123");
		contents.add(" 0859815002,1010123");
		contents.add(" 0859815002,1010123");
		contents.add(" 0859815002,1010123");
		contents.add(" 0859815002,1010123");
		List<ItemDTO> actualItemDTOList =service.parseContentCICUPC(contents);
		assertNotNull( actualItemDTOList);
	}

	@Test
	void parseContentCICUPCTest3() throws  ParseException {
		List<ItemDTO> expectedItemDTOList = new ArrayList<>();
		List<String> contents=new ArrayList<>();
		contents.add(" 085981500201,1010123");
		contents.add("  ");
		contents.add("  ");
		contents.add(" 08598150021,1010123");
		contents.add(" 08598150021,1010123");
		contents.add(" 08598150021,1010123");
		contents.add(" 08598150021,1010123");
		contents.add(" 08598150021,1010123");
		List<ItemDTO> actualItemDTOList =service.parseContentCICUPC(contents);
		assertNotNull( actualItemDTOList);
	}

	@Test
	void storeToItemDtoTest() throws ParseException {
		String cic="1010123";
		String upc="085981500201";
		ItemDTO actualitemDto=service.storeToItemDto( cic,  upc);
		assertNotNull( actualitemDto);
	}

	@Test
	void getStoreItemsForHistoryTest() throws MeupException {
		StoreItemDTO storeItemDto=new StoreItemDTO();
		DivisionDTO divisionDTO=new DivisionDTO();
		divisionDTO.setCorp(" ");
		divisionDTO.setDivisionNumber(" ");
		storeItemDto.setDivisionDto(divisionDTO);
		storeItemDto.setStoreNumber(" ");
		ItemDTO itemDTO=new ItemDTO();
		itemDTO.setCic(" ");
		storeItemDto.setItemDto(itemDTO);
		List<StoreItemHistoryVO> storeItemHistoryList=service.getStoreItemsForHistory(storeItemDto);
		verify(storeItemHistoryDAO).getStoreItemsForHistory(" "," "," "," ");
		assertNotNull(storeItemHistoryList);
	}

	@Test
	void getStoreItemsForHistoryTest_NotNull() throws MeupException {
		StoreItemDTO storeItemDto=new StoreItemDTO();
		DivisionDTO divisionDTO=new DivisionDTO();
		divisionDTO.setCorp(" ");
		divisionDTO.setDivisionNumber(" ");
		storeItemDto.setDivisionDto(divisionDTO);
		storeItemDto.setStoreNumber(" ");
		ItemDTO itemDTO=new ItemDTO();
		itemDTO.setCic(" ");
		storeItemDto.setItemDto(itemDTO);
		List<StoreItemHistoryVO> storeItemHistoryList1=new ArrayList<>();
		StoreItemHistoryVO storeItemHistoryVO=new StoreItemHistoryVO();
		storeItemHistoryVO.setBlockedStatus(MeupConstant.BLOCKED_STATUS_CODE);
		storeItemHistoryVO.setState(MeupConstant.STATE_ALLOCATED);
		storeItemHistoryList1.add(storeItemHistoryVO);
		Mockito.when(storeItemHistoryDAO.getStoreItemsForHistory(Mockito.any(),Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(storeItemHistoryList1);
		List<StoreItemHistoryVO> storeItemHistoryList=service.getStoreItemsForHistory(storeItemDto);
		verify(storeItemHistoryDAO).getStoreItemsForHistory(" "," "," "," ");
		assertNotNull(storeItemHistoryList);
	}

	@Test
	void getStoreItemsForHistoryTest_NotNull1() throws MeupException {
		StoreItemDTO storeItemDto=new StoreItemDTO();
		DivisionDTO divisionDTO=new DivisionDTO();
		divisionDTO.setCorp(" ");
		divisionDTO.setDivisionNumber(" ");
		storeItemDto.setDivisionDto(divisionDTO);
		storeItemDto.setStoreNumber(" ");
		ItemDTO itemDTO=new ItemDTO();
		itemDTO.setCic(" ");
		storeItemDto.setItemDto(itemDTO);
		List<StoreItemHistoryVO> storeItemHistoryList1=new ArrayList<>();
		StoreItemHistoryVO storeItemHistoryVO=new StoreItemHistoryVO();
		storeItemHistoryVO.setBlockedStatus(" ");
		storeItemHistoryVO.setState(" ");
		storeItemHistoryList1.add(storeItemHistoryVO);
		Mockito.when(storeItemHistoryDAO.getStoreItemsForHistory(Mockito.any(),Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(storeItemHistoryList1);
		List<StoreItemHistoryVO> storeItemHistoryList=service.getStoreItemsForHistory(storeItemDto);
		verify(storeItemHistoryDAO).getStoreItemsForHistory(" "," "," "," ");
		assertNotNull(storeItemHistoryList);
	}

	@Test
	void uploadCSVFileBlockRequestDTOTest() throws MeupException {
		BlockItemRequestDTO blockItemRequestDto=new BlockItemRequestDTO();
		blockItemRequestDto.setDivisionNumber(" ");
		service.uploadCSVFile(blockItemRequestDto);

	}

	@Test
	void blockItemsAndStoresTest() throws MeupException, ParseException {
		BlockItemRequestDTO storeBlockItemDTO=new BlockItemRequestDTO();
		List<StoreItemVO> storeItemVOList = new ArrayList<>();
		StoreItemBusinessResult storeItemBusinessResult=new StoreItemBusinessResult();
		String error="invalid";
		List errorMessages=new ArrayList();
		errorMessages.add(error);
		storeItemBusinessResult.setErrorMessages(errorMessages);
		Mockito.when(validationService.validateItemsAndStores(Mockito.any())).thenReturn(storeItemBusinessResult);
		List<StoreItemHelper> result=service.blockItemsAndStores(storeBlockItemDTO);
		verify(storeItemDAO).updateBlockStoreItems(storeItemVOList);
		verify(validationService).validateItemsAndStores(Mockito.any());
		assertNotNull(result);
	}

	@Test
	void blockItemsAndStoresTest1() throws MeupException, ParseException {
		BlockItemRequestDTO storeBlockItemDTO=new BlockItemRequestDTO();
		List<StoreItemVO> storeItemVOList = new ArrayList<>();
		StoreItemBusinessResult storeItemBusinessResult=new StoreItemBusinessResult();
		String error="invalid";
		List errorMessages=new ArrayList();
		//errorMessages.add(error);
		storeItemBusinessResult.setErrorMessages(errorMessages);
		List<String> err=new ArrayList<>();
		err.add("erro");
		List<StoreItemDTO> err1=new ArrayList<>();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		ItemDTO  itemDTO=new ItemDTO();
		itemDTO.setCic(" ");
		itemDTO.setUpcCountry(" ");
		itemDTO.setUpcSystem(" ");
		itemDTO.setUpcManuf(" ");
		itemDTO.setUpcSales(" ");
		storeItemDTO.setStoreNumber(" ");
		storeItemDTO.setItemDto(itemDTO);
		err1.add(storeItemDTO);
		storeItemBusinessResult.setDsdStoreItemList(err1);
		storeItemBusinessResult.setDiscontinuedStoreItemList(err1);
		storeItemBusinessResult.setInvalidStoreList(err);
		storeItemBusinessResult.setInvalidStoreItemList(err1);
		storeItemBusinessResult.setDsdAndWhStoreItemList(err1);
		storeItemBusinessResult.setDuplicateItemList(err1);
		Mockito.when(validationService.validateItemsAndStores(Mockito.any())).thenReturn(storeItemBusinessResult);
		List<StoreItemHelper> result=service.blockItemsAndStores(storeBlockItemDTO);
		verify(storeItemDAO).updateBlockStoreItems(storeItemVOList);
		verify(validationService).validateItemsAndStores(Mockito.any());
		assertNotNull(result);
	}

	@Test
	void blockItemsAndStoresTest2() throws MeupException, ParseException {
		BlockItemRequestDTO storeBlockItemDTO=new BlockItemRequestDTO();
		List<StoreItemVO> storeItemVOList = new ArrayList<>();
		StoreItemBusinessResult storeItemBusinessResult=new StoreItemBusinessResult();
		String error="invalid";
		List errorMessages=new ArrayList();
		//errorMessages.add(error);
		storeItemBusinessResult.setErrorMessages(errorMessages);
		Mockito.when(validationService.validateItemsAndStores(Mockito.any())).thenReturn(storeItemBusinessResult);
		List<StoreItemHelper> result=service.blockItemsAndStores(storeBlockItemDTO);
		verify(storeItemDAO).updateBlockStoreItems(storeItemVOList);
		verify(validationService).validateItemsAndStores(Mockito.any());
		assertNotNull(result);
	}
	@Test
	void iterateAndSetItemTest() throws MeupException, ParseException {
		List<StoreItemDTO> errorList=new ArrayList<>();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		ItemDTO  itemDTO=new ItemDTO();
		itemDTO.setCic(" ");
		itemDTO.setUpcCountry(" ");
		itemDTO.setUpcSystem(" ");
		itemDTO.setUpcManuf(" ");
		itemDTO.setUpcSales(" ");
		storeItemDTO.setStoreNumber(" ");
		storeItemDTO.setItemDto(itemDTO);
		errorList.add(storeItemDTO);
		String errorMessage=" ";
		List<StoreItemHelper> storeItemErrorList=new ArrayList<>();
		List<StoreItemHelper> result=service.iterateAndSetItem(errorList,errorMessage,storeItemErrorList);
		assertNotNull(result);
	}

	@Test
	void converToStoreItemVOTest() throws MeupException, ParseException {
		List<StoreItemVO> storeItemVOList=new ArrayList<>();
		List<StoreItemDTO> storeItemDTOList=new ArrayList<>();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		DivisionDTO divisionDTO=new DivisionDTO();
		divisionDTO.setDivisionNumber(" ");
		divisionDTO.setCorp(" ");
		storeItemDTO.setDivisionDto(divisionDTO);
		ItemDTO  itemDTO=new ItemDTO();
		itemDTO.setCic("234234");
		itemDTO.setDc("23423423");
		itemDTO.setUpcCountry("234234");
		itemDTO.setUpcSystem("234234");
		itemDTO.setUpcManuf("23423423");
		itemDTO.setUpcSales("234234");
		storeItemDTO.setStoreNumber("234324");
		storeItemDTO.setItemDto(itemDTO);
		storeItemDTO.setLastUpdatedUser(" ");
		storeItemDTO.setBlockedTargetDate("2022-05-21");
		storeItemDTOList.add(storeItemDTO);
		java.util.Date blockDate=new java.util.Date();
		Timestamp blockTimeStamp=new Timestamp(System.currentTimeMillis());
		List<StoreItemVO> result=service.converToStoreItemVO(storeItemVOList,storeItemDTOList,blockDate,blockTimeStamp);
		assertNotNull(result);
	}

	@Test
	void setStoreItemUpcValuesTest() {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setUpc("227969109612");
		service.setStoreItemUpcValues(storeItemSearchDTO);
	}

	@Test
	void getStoreItemsForReportTest_IfCheck() throws MeupException, SQLException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		List<StoreItemDTO> result = Arrays.asList(new StoreItemDTO[4001]);
		when(storeItemDAO.selectStoreItemsForReport
				(Mockito.any())).thenReturn(result);
		ResponseDTO responseDTO=service.getStoreItemsForReport(storeItemSearchDTO);
		verify(validationService).validateFieldsForReportStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}

	@Test
	void getStoreItemsForUpdateTest_ResultSize() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		UserDTO userDto=new UserDTO();
		userDto.setRole(" ");
		storeItemSearchDTO.setUserDto(userDto);
		List<StoreItemDTO> result = Arrays.asList(new StoreItemDTO[4001]);
		when(storeItemDAO.selectBlockedWhStoreItems
				(Mockito.any())).thenReturn(result);
		ResponseDTO responseDTO=service.getStoreItemsForUpdate(storeItemSearchDTO);
		verify(validationService).validateFieldsForUpdateStoreItems(Mockito.any());
		assertNotNull(responseDTO);
	}
	
}
