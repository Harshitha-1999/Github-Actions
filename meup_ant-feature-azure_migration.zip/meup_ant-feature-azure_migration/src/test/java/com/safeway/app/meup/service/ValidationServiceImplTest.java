package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import com.safeway.app.meup.dao.StoreDAO;
import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.dto.JsonErrorDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.dto.StoreItemBusinessResult;
import com.safeway.app.meup.dto.StoreItemDTO;
import com.safeway.app.meup.dto.StoreItemSearchDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.util.StoreItemHelper;
import com.safeway.app.meup.service.impl.ValidationServiceImpl;


@ExtendWith(MockitoExtension.class)
class ValidationServiceImplTest {

	@Mock
	private DivisionService divisionService;
	@Mock
	private StoreDAO storeDAO;
	@Mock
	private StoreItemDAO storeItemDAO;

	@InjectMocks
	private ValidationServiceImpl service;



	@Test
	void storeToItemDtoTest() throws MeupException {
		String cic="1010123";
		String upc="085981500201";
		ItemDTO actualitemDto=service.storeToItemDto( cic,  upc);
		assertNotNull( actualitemDto);
	}

	@Test
	void validateBlockItemCSVFileTest() throws MeupException {
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return "";
			}

			@Override
			public String getOriginalFilename() {
				return "Div33.csv";
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[10];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		ResponseDTO responseDTO=new ResponseDTO();
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		List<String> content = new ArrayList<>();
		content.add(" ");
	//	Mockito.when(service.extractFileData(itemsFile)).thenReturn(content);
		List<JsonErrorDTO> errorDTOList=service.validateBlockItemCSVFile( itemsFile,  responseDTO,  requestDTO);
		assertNotNull(errorDTOList);
	}

	@Test
	void validateBlockItemCSVFileTest1() throws MeupException {
		MultipartFile itemsFile=null;
		ResponseDTO responseDTO=new ResponseDTO();
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		List<String> content = new ArrayList<>();
		content.add(" ");
		//	Mockito.when(service.extractFileData(itemsFile)).thenReturn(content);
		List<JsonErrorDTO> errorDTOList=service.validateBlockItemCSVFile( itemsFile,  responseDTO,  requestDTO);
		assertNotNull(errorDTOList);
	}

	@Test
	void validateBlockItemCSVFileTest2() throws MeupException {
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return "";
			}

			@Override
			public String getOriginalFilename() {
				return "Div33.csd";
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[10];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		ResponseDTO responseDTO=new ResponseDTO();
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		List<String> content = new ArrayList<>();
		content.add(" ");
		List<JsonErrorDTO> errorDTOList=service.validateBlockItemCSVFile( itemsFile,  responseDTO,  requestDTO);
		assertNotNull(errorDTOList);
	}

	@Test
	void validateBlockItemCSVFileTest3() throws MeupException {
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return "";
			}

			@Override
			public String getOriginalFilename() {
				return "Div33.csv";
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[0];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		ResponseDTO responseDTO=new ResponseDTO();
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		List<JsonErrorDTO> errorDTOList=service.validateBlockItemCSVFile( itemsFile,  responseDTO,  requestDTO);
		assertNotNull(errorDTOList);
	}

	@Test
	void validateBlockItemCSVFileTest4() throws MeupException {
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return "";
			}

			@Override
			public String getOriginalFilename() {
				return "Div33.csv";
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[100000];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		ResponseDTO responseDTO=new ResponseDTO();
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		List<String> content = new ArrayList<>();
		content.add(" ");
		//	Mockito.when(service.extractFileData(itemsFile)).thenReturn(content);
		List<JsonErrorDTO> errorDTOList=service.validateBlockItemCSVFile( itemsFile,  responseDTO,  requestDTO);
		assertNotNull(errorDTOList);
	}

	@Test
	void validateItemFormatTestCorrectFormat() throws MeupException {
		List<String> contents=new ArrayList<>();
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1,0101,0859815");
		int code =service.validateItemFormat(contents);
		String content="";

		assertNotNull(code);
	}

	@Test
	void validateItemFormatTestCorrectFormat2() throws MeupException {
		List<String> contents=new ArrayList<>();
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		int code =service.validateItemFormat(contents);
		assertNotNull(code);
	}

	@Test
	void validateItemFormatTestCorrectFormat1() throws MeupException {
		List<String> contents=new ArrayList<>();
		int code =service.validateItemFormat(contents);
		String content="";

		assertNotNull(code);
	}

	@Test
	void validateItemFormatTestUPCCICLessLength() throws MeupException {
		List<String> contents=new ArrayList<>();
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010,08598");
		contents.add("1,0101,0859815");
		int code =service.validateItemFormat(contents);
		String content="";

		assertNotNull(code);
	}

	@Test
	void validateItemFormatTestCommaMissing() throws MeupException {
		List<String> contents=new ArrayList<>();
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1,0101,0859815");
		contents.add("1,0101,0859815");
		int code =service.validateItemFormat(contents);
		String content="";

		assertNotNull(code);
	}

	@Test
	void validateItemFormatTestNegative() throws MeupException {
		List<String> contents=new ArrayList<>();
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("-1010123,-085981500201");
		int code =service.validateItemFormat(contents);
		String content="";

		assertNotNull(code);
	}

	@Test
	void validateItemFormatTestNonNumeric() throws MeupException {
		List<String> contents=new ArrayList<>();
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("1010123,085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("-1010123,-085981500201");
		int code =service.validateItemFormat(contents);
		String content="";

		assertNotNull(code);
	}


	@Test
	void isItemFormatValidTest() throws MeupException {
		String content="1010123,085981500201";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest1() throws MeupException {
		String content="1010121,-08598150020a";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest2() throws MeupException {
		String content="085981500201,1010123";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}


	@Test
	void isItemFormatValidTest3() throws MeupException {
		String content=",";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest4() throws MeupException {
		String content="085981500201,";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest5() throws MeupException {
		String content=",1010123";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest6() throws MeupException {
		String content="08598150020a,1010123";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest7() throws MeupException {
		String content="085981500201,101012a";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest8() throws MeupException {
		String content="08598150020,101012333";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}

	@Test
	void isItemFormatValidTest9() throws MeupException {
		String content="1108598150020,1010123";
		int code =service.isItemFormatValid(content);
		assertNotNull(code);
	}



	@Test
	void extractFileDataTest() throws MeupException {
		MultipartFile itemsFile=new MultipartFile() {
			@Override
			public String getName() {
				return "";
			}

			@Override
			public String getOriginalFilename() {
				return "";
			}

			@Override
			public String getContentType() {
				return null;
			}

			@Override
			public boolean isEmpty() {
				return false;
			}

			@Override
			public long getSize() {
				return 0;
			}

			@Override
			public byte[] getBytes() throws IOException {
				return new byte[0];
			}

			@Override
			public InputStream getInputStream() throws IOException {
				return null;
			}

			@Override
			public void transferTo(File dest) throws IOException, IllegalStateException {

			}
		};
		List<String> content =service.extractFileData(itemsFile);
		assertNotNull(content);
	}

	@Test
	void isFileFormatValidTest() throws MeupException {
		String fileName="Div33.csv";
		List<String> contents=new ArrayList<>();
		contents.add("Division,33");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		Mockito.when(service.validateDivisionNumber("33")).thenReturn(true);
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}


	@Test
	void isFileFormatValidTestDivNumberNull() throws MeupException {
		String fileName="Div33.csv";
		List<String> contents=new ArrayList<>();
		contents.add("Division,");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}

	@Test
	void isFileFormatValidTestDivLengthInvalid() throws MeupException {
		String fileName="Div345.csv";
		List<String> contents=new ArrayList<>();
		contents.add("Division,345");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}

	@Test
	void isFileFormatValidTestInvalidDivision() throws MeupException {
		String fileName="Div33.csv";
		List<String> contents=new ArrayList<>();
		contents.add("Division,33");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}

	@Test
	void isFileFormatValidTestDivFileMismatch() throws MeupException {
		String fileName="Div33.csv";
		List<String> contents=new ArrayList<>();
		contents.add("Division,34");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}

	@Test
	void isFileFormatValidTestDivHeaderInvalid() throws MeupException {
		String fileName="Div33.csv";
		List<String> contents=new ArrayList<>();
		contents.add("Division123,33");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}

	@Test
	void isFileFormatValidTestFileNameInvalid() throws MeupException {
		String fileName="Divc.sv";
		List<String> contents=new ArrayList<>();
		contents.add("Division,33");
		contents.add("Store #,,91,284");
		contents.add("UPC,CIC");
		contents.add("1010123,085981500201");
		contents.add("-1010123,-085981500201");
		contents.add("10156gh,08598157fg");
		contents.add("1,0101,0859815");
		contents.add(",0101,0859815");
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		int code =service.isFileFormatValid( fileName,  contents,  requestDTO);
		assertNotNull(code);
	}

	@Test
	void isDivisionNumberInvalidTest() throws MeupException {
		String fileName=" ";
		String divisionNumber=" ";
		boolean isDivisionNumberInvalid =service.isDivisionNumberInvalid(  fileName,  divisionNumber);
		assertNotNull(isDivisionNumberInvalid);
	}

	@Test
	void isDivisionNumberInvalidTestCorrectName() throws MeupException {
		String fileName="Div33.csv";
		String divisionNumber="33";
		boolean isDivisionNumberInvalid =service.isDivisionNumberInvalid(  fileName,  divisionNumber);
		assertNotNull(isDivisionNumberInvalid);
	}

	@Test
	void isFileNameValidTest() throws MeupException {
		String fileName="Div33.csv";
		boolean isFileNameValid =service.isFileNameValid(  fileName);
		assertNotNull(isFileNameValid);
	}

	@Test
	void isFileNameValidTestMissingcsv() throws MeupException {
		String fileName="Div33.";
		boolean isFileNameValid =service.isFileNameValid(  fileName);
		assertNotNull(isFileNameValid);
	}

	@Test
	void validateDivisionNumberTest() throws MeupException {
		String divisionNumber="05";
		boolean isValidDivision =service.validateDivisionNumber(  divisionNumber);
		verify(divisionService).isValidDivision(divisionNumber);
		assertNotNull(isValidDivision);
	}

	@Test
	void validateStoreItemUpdateTest() throws MeupException {
		List storeList= new ArrayList();
		boolean isUnblock=false;
		String comment=" ";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdateTestWithStoreList() throws MeupException {
		List storeList= new ArrayList();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		storeItemDTO.setStoreNumber("0057");
		storeItemDTO.setSelected(true);
		storeList.add(storeItemDTO);
		boolean isUnblock=false;
		String comment=" ";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdateTestUnblockIsTrue() throws MeupException {
		List storeList= new ArrayList();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		storeItemDTO.setStoreNumber("0057");
		storeItemDTO.setSelected(true);
		storeList.add(storeItemDTO);
		boolean isUnblock=true;
		String comment=" ";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdateTestValidCase() throws MeupException {
		List storeList= new ArrayList();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		storeItemDTO.setStoreNumber("0057");
		storeItemDTO.setSelected(true);
		storeList.add(storeItemDTO);
		boolean isUnblock=true;
		String comment="Test";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdateTestValidCase2() throws MeupException {
		List storeList= new ArrayList();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		storeItemDTO.setStoreNumber("0057");
		storeItemDTO.setSelected(true);
		storeList.add(storeItemDTO);
		boolean isUnblock=true;
		String comment="TestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTestsTests";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdateTestValidCase1() throws MeupException {
		List storeList= new ArrayList();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		storeItemDTO.setStoreNumber("0057");
		storeItemDTO.setSelected(true);
		boolean isUnblock=true;
		String comment="Test";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdateTestCommentLengthNotZero() throws MeupException {
		List storeList= new ArrayList();
		boolean isUnblock=false;
		String comment="Test";
		List<String> errorList =service.validateStoreItemUpdate(  storeList,  isUnblock,  comment);
		assertNotNull(errorList);
	}

	@Test
	void validateStoreItemUpdate_Test() throws MeupException {
		List storeList= new ArrayList();
		boolean isUnblock=false;
		String result =service.validateStoreItemUpdate(  storeList,  isUnblock);
		assertNotNull(result);
	}

	@Test
	void validateStoreItemUpdate_TestStoreSelected() throws MeupException {
		List storeList= new ArrayList();
		StoreItemDTO storeItemDTO=new StoreItemDTO();
		storeItemDTO.setStoreNumber("0057");
		storeItemDTO.setSelected(true);
		storeList.add(storeItemDTO);
		boolean isUnblock=false;
		String result =service.validateStoreItemUpdate(  storeList,  isUnblock);
		assertNotNull(result);
	}

	@Test
	void validateStoreItemUpdate_TestStoreNotSelected() throws MeupException {
		List storeList= new ArrayList();
		boolean isUnblock=true;
		String result =service.validateStoreItemUpdate(  storeList,  isUnblock);
		assertNotNull(result);
	}



	@Test
	void getCorrectStoresInDivisionTest() throws MeupException {
		List storeList= new ArrayList();
		String divisionNumber=" ";
		String corp=" ";
		List<String> result =service.getCorrectStoresInDivision( divisionNumber,  storeList, corp);
		assertNotNull(result);
	}

	@Test
	void getCorrectStoresInDivisionTest1() throws MeupException {
		List storeList= new ArrayList();
		String divisionNumber="33";
		String corp="001";
		List<String> storeVOList=new ArrayList<>();
		storeVOList.add(" ");
		Mockito.when(storeDAO.getStoresInDivision(Mockito.any(), Mockito.any())).thenReturn(storeVOList);
		List<String> result =service.getCorrectStoresInDivision( divisionNumber,  storeList, corp);
		assertNotNull(result);
	}

	@Test
	void filterInvalidStoreListTest() throws MeupException {
		List storesList= new ArrayList();
		storesList.add("0057");
		List<String> validStoreList=new ArrayList<>();
		validStoreList.add("0057");
		List<String> result =service.filterInvalidStoreList( storesList,  validStoreList);
		assertNotNull(result);
	}

	@Test
	void filterInvalidStoreListTestInvalidStoresPresent() throws MeupException {
		List storesList= new ArrayList();
		storesList.add("0057");
		List<String> validStoreList=new ArrayList<>();
		validStoreList.add("0056");
		List<String> result =service.filterInvalidStoreList( storesList,  validStoreList);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTest() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestDTOPresent() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		DivisionDTO division=new DivisionDTO();
		division.setDivisionNumber("05");
		List<DivisionDTO> divisions=new ArrayList<>();
		divisions.add(division);
		storeItemSearchDTO.setDivisions(divisions);
		SmicGroupDTO group= new SmicGroupDTO();
		group.setGroupCd("05");
		List<SmicGroupDTO> groups=new ArrayList<>();
		groups.add(group);
		storeItemSearchDTO.setGroups(groups);
		SmicCategoryDTO category=new SmicCategoryDTO();
		category.setCategoryCd("005");
		List<SmicCategoryDTO> categories=new ArrayList<>();
		categories.add(category);
		storeItemSearchDTO.setCategories(categories);
		storeItemSearchDTO.setCic("1011146");
		storeItemSearchDTO.setUpc("0213464671");
		storeItemSearchDTO.setStoreNumber("0057");
		storeItemSearchDTO.setStatus("Allocated");
		storeItemSearchDTO.setState("Blocked");
		storeItemSearchDTO.setCountryCd("001");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestCicInvalid() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setCic("10111");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestCicInvalidNonNumeric() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setCic("10111asdf");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestUPC11() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setUpc("10213464671");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestUPCInvalidSize() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setUpc("1021346");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestUPCNonNumeric() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setUpc("1021346sdfsd");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestStoreNumberInvalidSize() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setStoreNumber("005");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsTestStoreNumberNonNumeric() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setStoreNumber("005asda");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForReportStoreItemsStatePresent() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setState("Blocked");
		List<String> result =service.validateFieldsForReportStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTest() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		DivisionDTO division=new DivisionDTO();
		division.setDivisionNumber("05");
		List<DivisionDTO> divisions=new ArrayList<>();
		divisions.add(division);
		storeItemSearchDTO.setDivisions(divisions);
		SmicGroupDTO group= new SmicGroupDTO();
		group.setGroupCd("05");
		List<SmicGroupDTO> groups=new ArrayList<>();
		groups.add(group);
		storeItemSearchDTO.setGroups(groups);
		SmicCategoryDTO category=new SmicCategoryDTO();
		category.setCategoryCd("005");
		List<SmicCategoryDTO> categories=new ArrayList<>();
		categories.add(category);
		storeItemSearchDTO.setCategories(categories);
		storeItemSearchDTO.setCic("1011146");
		storeItemSearchDTO.setUpc("0213464671");
		storeItemSearchDTO.setStoreNumber("0057");
		storeItemSearchDTO.setStatus("Allocated");
		storeItemSearchDTO.setState("Blocked");
		storeItemSearchDTO.setCountryCd("001");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTestCicInvalid() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setCic("10111");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTestCicInvalidNonNumeric() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setCic("10111asdf");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsItemsTestUPC11() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setUpc("10213464671");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTestUPCInvalidSize() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setUpc("1021346");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTestUPCNonNumeric() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setUpc("1021346sdfsd");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTestStoreNumberInvalidSize() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setStoreNumber("005");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsTestStoreNumberNonNumeric() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setStoreNumber("005asda");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsStatePresent() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setState("Blocked");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateFieldsForUpdateStoreItemsDeleteDateStartPresent() throws MeupException {
		StoreItemSearchDTO storeItemSearchDTO=new StoreItemSearchDTO();
		storeItemSearchDTO.setCountryCd("001");
		storeItemSearchDTO.setDeleteDateStart("2022-03-10");
		storeItemSearchDTO.setDeleteDateEnd("2022-03-25");
		List<String> result =service.validateFieldsForUpdateStoreItems( storeItemSearchDTO);
		assertNotNull(result);
	}

	@Test
	void validateItemsAndStoresTest() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		//blockItemRequestDTO.setDeleteDate(new Timestamp(System.currentTimeMillis()));
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("0033");
		storeItemHelper.setCic("30011186");
		storeItemHelper.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper);
		StoreItemHelper storeItemHelper1=new StoreItemHelper();
		storeItemHelper1.setStoreNo("0033");
		storeItemHelper1.setCic("30011186");
		storeItemHelper1.setUpc("360004");
		storeItemHelperList.add(storeItemHelper1);
		StoreItemHelper storeItemHelper2=new StoreItemHelper();
		storeItemHelper2.setStoreNo("");
		storeItemHelper2.setCic("30011186");
		storeItemHelper2.setUpc("3600047805");
		storeItemHelperList.add(storeItemHelper2);
		StoreItemHelper storeItemHelper3=new StoreItemHelper();
		storeItemHelper3.setStoreNo("003a");
		storeItemHelper3.setCic("300111sdf");
		storeItemHelper3.setUpc("36000478sdf");
		storeItemHelperList.add(storeItemHelper3);
		StoreItemHelper storeItemHelper4=new StoreItemHelper();
		storeItemHelper4.setStoreNo("0033");
		storeItemHelper4.setCic("");
		storeItemHelper4.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper4);
		StoreItemHelper storeItemHelper5=new StoreItemHelper();
		storeItemHelper5.setStoreNo("003");
		storeItemHelper5.setCic("30011186");
		storeItemHelper5.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper5);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTestDivNotSelected() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("Select");
		blockItemRequestDTO.setCorp("001");
		//blockItemRequestDTO.setDeleteDate(new Timestamp(System.currentTimeMillis()));
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("0033");
		storeItemHelper.setCic("30011186");
		storeItemHelper.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper);
		StoreItemHelper storeItemHelper1=new StoreItemHelper();
		storeItemHelper1.setStoreNo("0033");
		storeItemHelper1.setCic("30011186");
		storeItemHelper1.setUpc("360004");
		storeItemHelperList.add(storeItemHelper1);
		StoreItemHelper storeItemHelper2=new StoreItemHelper();
		storeItemHelper2.setStoreNo("");
		storeItemHelper2.setCic("30011186");
		storeItemHelper2.setUpc("3600047805");
		storeItemHelperList.add(storeItemHelper2);
		StoreItemHelper storeItemHelper3=new StoreItemHelper();
		storeItemHelper3.setStoreNo("003a");
		storeItemHelper3.setCic("300111sdf");
		storeItemHelper3.setUpc("36000478sdf");
		storeItemHelperList.add(storeItemHelper3);
		StoreItemHelper storeItemHelper4=new StoreItemHelper();
		storeItemHelper4.setStoreNo("0033");
		storeItemHelper4.setCic("");
		storeItemHelper4.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper4);
		StoreItemHelper storeItemHelper5=new StoreItemHelper();
		storeItemHelper5.setStoreNo("003");
		storeItemHelper5.setCic("30011186");
		storeItemHelper5.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper5);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest1() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("0033");
		storeItemHelper.setCic("30011186");
		storeItemHelper.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest2() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper1=new StoreItemHelper();
		storeItemHelper1.setStoreNo("0033");
		storeItemHelper1.setCic("30011186");
		storeItemHelper1.setUpc("360004");
		storeItemHelperList.add(storeItemHelper1);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest3() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper2=new StoreItemHelper();
		storeItemHelper2.setStoreNo("");
		storeItemHelper2.setCic("30011186");
		storeItemHelper2.setUpc("3600047805");
		storeItemHelperList.add(storeItemHelper2);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest4() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper3=new StoreItemHelper();
		storeItemHelper3.setStoreNo("003a");
		storeItemHelper3.setCic("300111sdf");
		storeItemHelper3.setUpc("36000478sdf");
		storeItemHelperList.add(storeItemHelper3);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest5() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper4=new StoreItemHelper();
		storeItemHelper4.setStoreNo("0033");
		storeItemHelper4.setCic("");
		storeItemHelper4.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper4);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest6() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper5=new StoreItemHelper();
		storeItemHelper5.setStoreNo("003");
		storeItemHelper5.setCic("30011186");
		storeItemHelper5.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper5);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest7() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("0033");
		storeItemHelper.setCic("30011186");
		storeItemHelper.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper);
		StoreItemHelper storeItemHelper1=new StoreItemHelper();
		storeItemHelper1.setStoreNo("0033");
		storeItemHelper1.setCic("30011186");
		storeItemHelper1.setUpc("36000478058");
		storeItemHelperList.add(storeItemHelper1);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest8() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("0033");
		storeItemHelper.setCic("");
		storeItemHelper.setUpc("");
		storeItemHelperList.add(storeItemHelper);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTest9() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("");
		storeItemHelper.setCic("");
		storeItemHelper.setUpc("");
		storeItemHelperList.add(storeItemHelper);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void validateItemsAndStoresTestVakid() throws MeupException {
		BlockItemRequestDTO blockItemRequestDTO=new BlockItemRequestDTO();
		blockItemRequestDTO.setDivisionNumber("33");
		blockItemRequestDTO.setCorp("001");
		//blockItemRequestDTO.setDeleteDate(new Date());
		List<String> StoreList=new ArrayList<>();
		blockItemRequestDTO.setStoreList( StoreList);
		List<ItemDTO> itemList=new ArrayList<>();
		List<StoreItemHelper> storeItemHelperList=new ArrayList<>();
		StoreItemHelper storeItemHelper=new StoreItemHelper();
		storeItemHelper.setStoreNo("0033");
		storeItemHelper.setCic("30011186");
		storeItemHelper.setUpc("3600047805");
		storeItemHelperList.add(storeItemHelper);
		blockItemRequestDTO.setStoreItemHelperList( storeItemHelperList);
		blockItemRequestDTO.setItemDtoList( itemList);
		StoreItemBusinessResult businessResult  =service.validateItemsAndStores( blockItemRequestDTO);
		assertNotNull(businessResult);
	}

	@Test
	void blockItemsPageValidationsTest() throws MeupException {
		service.blockItemsPageValidations( );
	}


}
