package com.safeway.app.meup.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.ResponseDTO;
import com.safeway.app.meup.service.DivisionService;
import com.safeway.app.meup.vox.DivisionVO;

@WebMvcTest(UnallocatedController.class)
class UnallocatedControllerTest {

    @Autowired
    private MockMvc mockmvc;

    @MockBean
    private DivisionService divisionService;
    @Autowired
    private UnallocatedController unallocatedController;



    List<DivisionVO> divisionVOList=new ArrayList<>();
    List<DivisionDTO> divisionDTOList=new ArrayList<>();
    ResponseDTO responseDTO=new ResponseDTO();

    @Test
    void getDivisionListTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/divisions/us");
        Mockito.when(divisionService.getDivisionList()).thenReturn(divisionDTOList);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }
//
//    @Test
//    void getDivisionListOnHoldTest() throws Exception {
//        StockingSectionVO stockingSectionVO= new StockingSectionVO();
//        RequestBuilder request = MockMvcRequestBuilders.get("/v1/divisions/hold").param("corp","001").
//                param("groupCode","05").param("stockingSectionList", String.valueOf(stockingSectionVO)).
//                param("itemStateCode","R").param("blockedStatusCode","B");
//        Mockito.when(divisionService.getDivisionListOnHold(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyChar(),Mockito.anyChar())).thenReturn(divisionDTOList);
//        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
//    }

    @Test
    void getDivisionListForUSTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/divisions").param("corpCd","001");
        Mockito.when(divisionService.getDivisionListForUS("001")).thenReturn(divisionDTOList);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }
    @Test
    void healthTest() throws Exception {
    	String result = unallocatedController.health();
    	assertEquals("MEUP App is up.", result);
        
    }
}
