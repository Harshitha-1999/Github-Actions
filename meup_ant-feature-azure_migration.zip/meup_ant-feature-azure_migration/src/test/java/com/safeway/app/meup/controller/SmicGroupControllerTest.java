package com.safeway.app.meup.controller;


import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.service.SmicGroupService;

@WebMvcTest(SmicGroupController.class)
class SmicGroupControllerTest {

    @Autowired
    private MockMvc mockmvc;
    @MockBean
    SmicGroupService smicGroupService;

    List<SmicGroupDTO> smicGroupDTOList=new ArrayList<>();
    List<SmicCategoryDTO> smicCategoryDTOList=new ArrayList<>();
    List<SmicGroupDTO> smicGroupDTO=new ArrayList<>();

    @Test
    void getGroupListForDivisionTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/groups").param("divisionNumbers","divisionNumbers")
                .param("corp","corp");
        Mockito.when(smicGroupService.getSmicGroupsForDivision(Mockito.anyList(),Mockito.anyString())).thenReturn(smicGroupDTOList);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void getCategoryListForGroupTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/categories").param("groupCds","05")
                .param("corp","corp");
        Mockito.when(smicGroupService.getSmicCategoriesForGroups(Mockito.anyList(),Mockito.anyString())).thenReturn(smicCategoryDTOList);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    @Test
    void getGroupsByStatusTest() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.get("/v1/groupsByStatus")
                .param("corp","corp");
        Mockito.when(smicGroupService.getGroupsByStatus(Mockito.anyString())).thenReturn(smicGroupDTO);
        mockmvc.perform(request).andExpect(status().isOk()).andReturn();
    }

}
