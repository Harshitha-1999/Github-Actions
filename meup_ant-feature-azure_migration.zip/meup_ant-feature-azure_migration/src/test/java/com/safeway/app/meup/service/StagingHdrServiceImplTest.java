package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.safeway.app.meup.dao.StagingHdrDAO;
import com.safeway.app.meup.dto.BlockItemRequestDTO;
import com.safeway.app.meup.dto.ItemDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.impl.StagingHdrServiceImpl;
import com.safeway.app.meup.util.MeupConstant;
import com.safeway.app.meup.vox.StagingErrorVO;
import com.safeway.app.meup.vox.StagingErrorVOID;
import com.safeway.app.meup.vox.StagingHdrVO;
import com.safeway.app.meup.vox.StagingItemVO;
import com.safeway.app.meup.vox.StagingItemVOID;
import com.safeway.app.meup.vox.StagingStoreItemVO;
import com.safeway.app.meup.vox.StagingStoreItemVOID;


@ExtendWith(MockitoExtension.class)
class StagingHdrServiceImplTest {
	
	@Mock
	StagingHdrDAO stagingHdrDAO;


	@InjectMocks
	private StagingHdrServiceImpl service;

	
	@Test
	void uploadCSVFileTest() throws MeupException, ParseException {
		StagingHdrVO hdrVO = new StagingHdrVO();
		BlockItemRequestDTO requestDTO=new BlockItemRequestDTO();
		requestDTO.setDeleteDate("2021-12-31");
		List<String> storeItemList =new ArrayList<>();
		storeItemList.add(" ");
		storeItemList.add(" ");
		ItemDTO itemDTO=new ItemDTO();
		List<ItemDTO> itemList=new ArrayList<>();
		itemList.add(itemDTO);
		itemList.add(itemDTO);
		requestDTO.setStoreList(storeItemList);
		requestDTO.setItemDtoList(itemList);
		service.uploadCSVFile(requestDTO,"");
		verify(stagingHdrDAO).insertStagingHdr(Mockito.any());
	}


	@Test
	void createStagingStoreItemVOTest() throws MeupException {
		StagingStoreItemVO stagingStore = new StagingStoreItemVO();
		StagingStoreItemVOID itemVOID = new StagingStoreItemVOID();
		itemVOID.setCorp("");
		itemVOID.setDiv("");
		itemVOID.setFac("");
		itemVOID.setUserId("");
		itemVOID.setItemUploadTs(new Timestamp(System.currentTimeMillis()));
		stagingStore.setStagingStoreItemVOID(itemVOID);
		StagingStoreItemVO actualStagingStore=service.createStagingStoreItemVO("","","",new Timestamp(System.currentTimeMillis()),"");
	 assertNotNull(actualStagingStore);
		//assertEquals(stagingStore,actualStagingStore);
	}

	@Test
	void createStagingErrorVOTest() throws MeupException {
		StagingErrorVO stagingError = new StagingErrorVO();
		StagingErrorVOID errorVOID = new StagingErrorVOID();
		errorVOID.setCorp("");
		errorVOID.setDiv("");
		errorVOID.setUserId("");
		errorVOID.setErrorUploadTs(new Timestamp(System.currentTimeMillis()));
		errorVOID.setFac("");
		errorVOID.setCic(BigDecimal.ZERO);
		errorVOID.setUpcCountry(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
		errorVOID.setUpcManuf(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
		errorVOID.setUpcSales(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
		errorVOID.setUpcSystem(MeupConstant.UPC_VALUES_DUPLICATE_STORE);
		stagingError.setErrDesc(MeupConstant.DUPLICATE_STORE_ID);
		StagingErrorVO actualStagingError=service.createStagingErrorVO("","","",new Timestamp(System.currentTimeMillis()),"");
		assertNotNull(actualStagingError);
		//assertEquals(stagingError,actualStagingError);
	}

	@Test
	void createStagingItemErrorVOTest() throws MeupException {
		BigDecimal cic, upcSales, upcManuf, upcCountry, upcSystem;
		StagingErrorVO stagingError = new StagingErrorVO();
		StagingErrorVOID errorVOID = new StagingErrorVOID();
		stagingError.setStagingErrorVOID(errorVOID);
		errorVOID.setCorp("");
		errorVOID.setDiv("");
		errorVOID.setUserId("");
		errorVOID.setErrorUploadTs(new Timestamp(System.currentTimeMillis()));
		cic = getBigDecimal("");
		errorVOID.setCic(cic);
		upcCountry = getBigDecimal("");
		errorVOID.setUpcCountry(upcCountry);
		upcManuf = getBigDecimal("");
		errorVOID.setUpcManuf(upcManuf);
		upcSales = getBigDecimal("");
		errorVOID.setUpcSales(upcSales);
		upcSystem = getBigDecimal("");
		errorVOID.setUpcSystem(upcSystem);
		errorVOID.setFac("");
		stagingError.setErrDesc(MeupConstant.ERROR_DESCRIPTION);
		ItemDTO itemDTO=new ItemDTO();
		StagingErrorVO actualStagingError=service.createStagingItemErrorVO("","","",new Timestamp(System.currentTimeMillis()),itemDTO);
		assertNotNull(actualStagingError);
		//assertEquals(stagingError,actualStagingError);
	}

	@Test
	void createStagingItemVOTest() throws MeupException {
		BigDecimal cic, upcSales, upcManuf, upcSystem, upcCountry;
		StagingItemVO stagingItem = new StagingItemVO();
		StagingItemVOID stagingItemVOID = new StagingItemVOID();
		stagingItem.setStagingItemVOID(stagingItemVOID);
		stagingItemVOID.setCorp("");
		stagingItemVOID.setDiv("");
		stagingItemVOID.setUserId("");
		stagingItemVOID.setStageItemUploadTs(new Timestamp(System.currentTimeMillis()));
		cic = getBigDecimal("");
		stagingItemVOID.setCic(cic);
		upcCountry = getBigDecimal("");
		stagingItemVOID.setUpcCountry(upcCountry);
		upcManuf = getBigDecimal("");
		stagingItemVOID.setUpcManuf(upcManuf);
		upcSales = getBigDecimal("");
		stagingItemVOID.setUpcSales(upcSales);
		upcSystem = getBigDecimal("");
		stagingItemVOID.setUpcSystem(upcSystem);
		ItemDTO itemDTO=new ItemDTO();
		StagingItemVO actualStagingItemVO=service.createStagingItemVO("","","",new Timestamp(System.currentTimeMillis()),itemDTO);
		assertNotNull(actualStagingItemVO);
		//assertEquals(stagingItem,actualStagingItemVO);
	}

	public static BigDecimal getBigDecimal(String value) {
		return (value == null || value.equals("")) ? BigDecimal.ZERO : new BigDecimal(value);
	}

	@Test
	void getStagingHdrDAOTest() throws MeupException, ParseException {
		service.getStagingHdrDAO();
	}

}
