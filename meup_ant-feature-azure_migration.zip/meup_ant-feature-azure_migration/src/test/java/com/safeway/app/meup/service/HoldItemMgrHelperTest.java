package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.safeway.app.meup.dto.CommentDTO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.dto.SmicCategoryDTO;
import com.safeway.app.meup.dto.SmicGroupDTO;
import com.safeway.app.meup.dto.StockingSectionDTO;
import com.safeway.app.meup.dto.UserDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.util.HoldItemMgrHelper;
import com.safeway.app.meup.vox.CommentVO;
import com.safeway.app.meup.vox.DivisionVO;
import com.safeway.app.meup.vox.HoldItemVO;
import com.safeway.app.meup.vox.SmicCategoryVO;
import com.safeway.app.meup.vox.SmicGroupVO;
import com.safeway.app.meup.vox.StockingSectionVO;
import com.safeway.app.meup.vox.UserVO;


@ExtendWith(MockitoExtension.class)
class HoldItemMgrHelperTest {

	@InjectMocks
	private HoldItemMgrHelper service;


	@Test
	void convertToSectionDTOTest() throws MeupException {
		StockingSectionVO stockingSection=new StockingSectionVO();
		StockingSectionDTO stockingSectionDto =service.convertToSectionDTO( stockingSection);
		assertNotNull(stockingSectionDto);
	}

	@Test
	void convertToDivisionDTOTest() throws MeupException {
		DivisionVO division=new DivisionVO();
		division.setDivisionNumber(" ");
		division.setDivisionName(" ");
		division.setCorp(" ");
		DivisionDTO divisionDto =service.convertToDivisionDTO( division);
		assertNotNull(divisionDto);
	}

	@Test
	void convertToDivisionVOTest() throws MeupException {
		DivisionDTO division=new DivisionDTO();
		division.setDivisionNumber(" ");
		division.setDivisionName(" ");
		division.setCorp(" ");
		DivisionVO divisionVo =service.convertToDivisionVO( division);
		assertNotNull(divisionVo);
	}

	@Test
	void convertTostockingSectionVOTest() throws MeupException {
		StockingSectionDTO stockingSection=new StockingSectionDTO();
		stockingSection.setStockingSectionDesc(" ");
		stockingSection.setStockingSectionNumber(" ");
		StockingSectionVO stockingSectionVO  =service.convertTostockingSectionVO( stockingSection);
		assertNotNull(stockingSectionVO);
	}

	@Test
	void convertToSmicGroupDTOTest() throws MeupException {
		SmicGroupVO smicGroup=new SmicGroupVO();
		smicGroup.setCorp(" ");
		smicGroup.setGroupCd(" ");
		smicGroup.setGroupName(" ");
		SmicGroupDTO smicGroupDTO =service.convertToSmicGroupDTO( smicGroup);
		assertNotNull(smicGroupDTO);
	}

	@Test
	void convertToSmicCategoryDTOTest() throws MeupException {
		SmicCategoryVO smicCategory=new SmicCategoryVO();
		smicCategory.setCategoryCd(" ");
		smicCategory.setCategoryName(" ");
		smicCategory.setGroupCd(" ");
		SmicCategoryDTO smicCategoryDto =service.convertToSmicCategoryDTO( smicCategory);
		assertNotNull(smicCategoryDto);
	}

	@Test
	void convertToUserVOTest() throws MeupException {
		UserDTO userDto=new UserDTO();
		userDto.setUserId(" ");
		userDto.setRole(" ");
		userDto.setDivision(" ");
		UserVO userVo  =service.convertToUserVO( userDto);
		assertNotNull(userVo);
	}

	@Test
	void convertToCommentVOTest() throws MeupException {
		CommentDTO commentDto=new CommentDTO();
		commentDto.setComment(" ");
		CommentVO commentVO = service.convertToCommentVO( commentDto);
		assertNotNull(commentVO);
	}

	@Test
	void convertToDTOTest() throws MeupException {
		HoldItemVO holdItemVO = new HoldItemVO();
		List<HoldItemVO> holdItems = new ArrayList();
		holdItemVO.setBlockedStatCd("blockedStatCd");
		holdItemVO.setCic(1);
		holdItemVO.setCorp("1");
		holdItemVO.setDesc("Testing");
		holdItemVO.setDivisionNbr(106);
		holdItemVO.setGroupId(10);
		holdItemVO.setStoreID(001);
		holdItemVO.setUpcID(4);
		holdItemVO.setStatus("Completed");
		holdItemVO.setSchematicEffectiveDate(new Date());
		holdItems.add(holdItemVO);
		List holdItemDTOList   =service.convertToDTO( holdItems);
		assertNotNull(holdItemDTOList);
	}


}
