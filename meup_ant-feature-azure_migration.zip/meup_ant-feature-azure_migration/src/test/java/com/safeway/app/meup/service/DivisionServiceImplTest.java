package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.safeway.app.meup.util.HoldItemMgrHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.safeway.app.meup.dao.DivisionDAO;
import com.safeway.app.meup.dto.DivisionDTO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.impl.DivisionServiceImpl;
import com.safeway.app.meup.vox.DivisionVO;
import com.safeway.app.meup.vox.StockingSectionVO;


@ExtendWith(MockitoExtension.class)
class DivisionServiceImplTest {
	
	@Mock
	private DivisionDAO divisionDAO;
	@Mock
	private HoldItemMgrHelper holdItemMgrHelper;

	@InjectMocks
	private DivisionServiceImpl service;

	
	@Test
	void getDivisionListTest() throws MeupException {
		List<DivisionDTO> expectedDivisionList=new ArrayList<>();
		Mockito.when(divisionDAO.getDivisionList()).thenReturn(expectedDivisionList);
		List<DivisionDTO> actualDivisionVoList=service.getDivisionList();
		assertEquals(expectedDivisionList, actualDivisionVoList);
	}

	@Test
	void getDivisionListOnHoldTest() throws MeupException, SQLException {
		List<DivisionDTO> expectedDivisionList=new ArrayList<>();
		List<StockingSectionVO> stockingSectionList=new ArrayList<>();
		Mockito.when(divisionDAO.getDivisionListByStatus("001","05",stockingSectionList,'A','B')).thenReturn(expectedDivisionList);
		List<DivisionDTO> actualDivisionVoList=service.getDivisionListOnHold("001","05",stockingSectionList,'A','B');
		assertEquals(expectedDivisionList, actualDivisionVoList);
	}

	@Test
	void createDivisionsTest() throws MeupException {
		List<DivisionDTO> expectedDivisionList=new ArrayList<>();
		Mockito.when(divisionDAO.getDivisionList()).thenReturn(expectedDivisionList);
		List<DivisionDTO> divisionDtoList = new ArrayList();
		Iterator it = expectedDivisionList.iterator();
		DivisionVO division = null;
		DivisionDTO divisionDto = null;
		while (it.hasNext()) {
			division = (DivisionVO) it.next();
			divisionDto = holdItemMgrHelper.convertToDivisionDTO(division);
			divisionDtoList.add(divisionDto);
		}
		List<DivisionDTO> actualDivisionDTOList=service.createDivisions();
		assertEquals(expectedDivisionList, actualDivisionDTOList);
	}

	@Test
	void getCorpForDivTest() throws MeupException {
		service.getCorpForDiv(Mockito.any());
		verify(divisionDAO).getCorp(Mockito.any());
	}

	@Test
	void getDivisionListForUSTest() throws MeupException {
		List<DivisionDTO> expectedDivisionList=new ArrayList<>();
		Mockito.when(divisionDAO.getDivisionListByCorp("001")).thenReturn(expectedDivisionList);
		List<DivisionDTO> actualDivisionVoList=service.getDivisionListForUS("001");
		assertEquals(expectedDivisionList, actualDivisionVoList);
	}

	@Test
	void isValidDivisionTest() throws MeupException {
		service.isValidDivision(Mockito.any());
		verify(divisionDAO).isValidDivision(Mockito.any());
	}
}
