package com.safeway.app.meup.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.safeway.app.meup.dto.*;
import com.safeway.app.meup.util.HoldItemMgrHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.safeway.app.meup.dao.DivisionDAO;
import com.safeway.app.meup.dao.StockingSectionDAO;
import com.safeway.app.meup.dao.StoreItemDAO;
import com.safeway.app.meup.exceptions.MeupException;
import com.safeway.app.meup.service.impl.HoldItemServiceImpl;


@ExtendWith(MockitoExtension.class)
class HoldItemServiceImplTest {
	
	@Mock
	private DivisionDAO divisionDAO;
	@Mock
	private StockingSectionDAO stockingSectionDao;
	@Mock
	private HoldItemMgrHelper holdItemMgrHelper;
	@Mock
	private StoreItemDAO storeItemDAO;


	@InjectMocks
	private HoldItemServiceImpl service;

	@Test
	void getStockSectionDivisionOnHoldTest() throws MeupException, SQLException {
		HoldSearchFieldsDTO expectedFieldsDTO = new HoldSearchFieldsDTO();
		List<StockingSectionDTO> stockingSectionList=new ArrayList<>();
		List<DivisionDTO> divisionList=new ArrayList<>();
		expectedFieldsDTO.setGroupCode("05");
		expectedFieldsDTO.setStockingSectionList(stockingSectionList);
		expectedFieldsDTO.setDivisionList(divisionList);
		HoldSearchFieldsDTO actualFieldsDTO =service.getStockSectionDivisionOnHold(" "," ");
		assertNotNull(actualFieldsDTO);
	}


	@Test
	void getItemCountsOnHoldTest() throws MeupException, SQLException {
		ResponseDTO expectedrResponseDTO = new ResponseDTO();
		List<ItemCountsByStoreDTO> itemCountsByStoreList =new LinkedList<>();
		expectedrResponseDTO.setStatus(ResponseDTO.SUCCESS_OPERATION);
		HashMap<String, Object> mapData = new HashMap<>();
		mapData.put(ResponseDTO.REST_DATA,itemCountsByStoreList );
		expectedrResponseDTO.setData(mapData);
		List<String> stockingSectionStringList=new ArrayList<>();
		List<String> divisionStringList=new ArrayList<>();
		ResponseDTO actualResponseDTO =service.getItemCountsOnHold("001",stockingSectionStringList,divisionStringList);
		assertNotNull( actualResponseDTO);
	}

	@Test
	void updateItemsStoreLevelTest() throws MeupException, SQLException {
		ResponseStockingSectionDTO responseStockingSectionDTO=new ResponseStockingSectionDTO();
		String userID =" ";
		responseStockingSectionDTO.setUserID(userID);
		HoldItemDTO holdItemDTO= new HoldItemDTO();
		List<HoldItemDTO> acceptList = new ArrayList<>();
		acceptList.add(holdItemDTO);
		List<HoldItemDTO> rejectList = new ArrayList<>();
		rejectList.add(holdItemDTO);
		responseStockingSectionDTO.setAcceptList(acceptList);
		responseStockingSectionDTO.setRejectList(rejectList);
		service.updateItemsStoreLevel(responseStockingSectionDTO);
		verify(storeItemDAO,times(2)).updateItemsByStoreStockingSection(acceptList,userID);
	}


	@Test
	void getItemListForStoreStockSectionTest() throws MeupException, SQLException {
		List<HoldItemDTO> actualItemDTOList=service.getItemListForStoreStockSection(Mockito.any(),Mockito.any(),Mockito.any());
		assertNotNull(actualItemDTOList);
	}

	@Test
	void updateItemsByStoreStockSection_AccpetListTest() throws MeupException, SQLException {
		HoldItemDTO item=new HoldItemDTO();
		List<HoldItemDTO> acceptList=new ArrayList<>();
		acceptList.add(item);
		List<HoldItemDTO> rejectList=new ArrayList<>();
		ResponseStockingSectionDTO responseStockingSectionDTO=new ResponseStockingSectionDTO();
		responseStockingSectionDTO.setAcceptList(acceptList);
		responseStockingSectionDTO.setRejectList(rejectList);
		responseStockingSectionDTO.setUserID(" ");
		service.updateItemsByStoreStockSection(responseStockingSectionDTO, " ");
		if (null != acceptList && !acceptList.isEmpty()) {

			verify(storeItemDAO).updateItemsByStoreStockSection(Mockito.anyList(),Mockito.any(),Mockito.any());
		}
		if (null != rejectList && !rejectList.isEmpty()) {
			verify(storeItemDAO).updateItemsByStoreStockSection(Mockito.anyList(),Mockito.any(),Mockito.any());
		}
	}

	@Test
	void updateItemsByStoreStockSection_RejectListTest() throws MeupException, SQLException {
		HoldItemDTO item=new HoldItemDTO();
		List<HoldItemDTO> acceptList=new ArrayList<>();
		List<HoldItemDTO> rejectList=new ArrayList<>();
		rejectList.add(item);
		ResponseStockingSectionDTO responseStockingSectionDTO=new ResponseStockingSectionDTO();
		responseStockingSectionDTO.setAcceptList(acceptList);
		responseStockingSectionDTO.setRejectList(rejectList);
		responseStockingSectionDTO.setUserID(" ");
		service.updateItemsByStoreStockSection(responseStockingSectionDTO, " ");
		if (null != acceptList && !acceptList.isEmpty()) {

			verify(storeItemDAO).updateItemsByStoreStockSection(Mockito.anyList(),Mockito.any(),Mockito.any());
		}
		if (null != rejectList && !rejectList.isEmpty()) {
			verify(storeItemDAO).updateItemsByStoreStockSection(Mockito.anyList(),Mockito.any(),Mockito.any());
		}
	}





}
