(function () {
	'use strict';
	myApp.factory('PagerService', PagerService),
		myApp.controller('LookupController', ['$scope', '$http', '$location', '$document', 'blockUI', 'service', '$timeout', 'PagerService',
			function LookupController($scope, $http, $location, $document,
				blockUI, service, $timeout, PagerService) {

				$scope.displayResultDiv = false;
				$scope.noResultPage = false;
				$scope.restrictLoadMore = false;
				$scope.itemSets = [];
				$scope.itemSetsFilter = [];
				$scope.conversionStatus = [];
				$scope.conversionStatusFilter = [];
				$scope.departmentList = [];
				$scope.departmentListFilter = [];
				$scope.searchRequest = {};
				$scope.searchRequest.filter = {};
				$scope.sortLkpOrder = { name: 'A' };

				$scope.availableList = [];
				$scope.columnList = [];
				$scope.availableListJson = [];
				$scope.columnListJson = [];
				$scope.masterListJson = [];
				$scope.savedList = [];
				$scope.repeatList = [];
				$scope.finalizedList = [];
				$scope.finalizedListNo = [];
				$scope.markedLkpSkus = [];

				$scope.models = {
					selected: null,
					lists: {
						"Additional": [],
						"Viewable": []
					}
				};
				$scope.resizeMode = "OverflowResizer";

				$scope.paginate = this;
				$scope.markedItems = [];
				var startIndex = 1;
				var endIndex = 500;
				var isDeptValid = true;
				var isConvStatValid = true;
				var isValid = true;
				var windowHeight = $(window).innerHeight();
				var windowwidth = $(window).innerWidth();

				/**
				 *  Initialise
				 */



				$('.lookuppanel').css('height', windowHeight - 80);
				$('.resultPanel').css('width', windowwidth - 100 + " !important");
				$('.resultPanel').css('height', windowHeight - 400);

				$scope.$watch('selectedCompany', function (value) {
					if (value) {
						$scope.availableList = [];
						$scope.columnList = [];
						$scope.savedList = [];
						$scope.finalizedList = [];
						$scope.models.lists.Additional = [];
						$scope.models.lists.Viewable = [];
					}
				});
				$scope.$watch('selectedDivision', function (value) {
					if (value && value.divisionID) {
						$scope.availableList = [];
						$scope.columnList = [];
						$scope.savedList = [];
						$scope.finalizedList = [];
						$scope.models.lists.Additional = [];
						$scope.models.lists.Viewable = [];

						
						if (service.baseUrlFunction() != undefined) {
							service.baseUrlFunction().then(function (url) {
								$scope.baseUrl = url;
								//				});
								//			}
								service.getHeaders().then(function (header) {

									var config = header
									if(header) {
										var extractedHeader = header.headers['Ocp-Apim-Subscription-Key'];
									} else {
										extractedHeader = '';
									}
									
									//      });


									if (service.selectedDivision.divisionID) {
										$scope.companyID = service.selectedCompany.companyID;
										$scope.divisionID = service.selectedDivision.divisionID;
										$scope.userId = service.userId;
										//$scope.loadColumn($scope.companyID, $scope.divisionID, $scope.userId);
									}


									$http.get('lookup/lookup-properties.json').then(function (response) {
										if (response && response.data) {
											$scope.availableListJson = response.data[0].customVO.availableList;
											$scope.columnListJson = response.data[0].customVO.columnList;
											$scope.masterListJson = response.data[0].customVO.masterList;
										}
									});

									$("#sortLkpSectionExpand").hide();
									$("#sortLookupBy").click(function () {
										$("#sortLkpSectionExpand").show();
									});

									$scope.loadLkpSortModels();
									/**
									 *  Load the columns with desired data
									 */
									// $scope.loadColumn = function (selectedCompanyID, selectedDivisionID, selectUserId) {

									var listResults = $scope.baseUrl + "lookUp/loadScreen/" + $scope.companyID + "/" + $scope.divisionID + "/" + $scope.userId;
									var searchRequest = {};
									$http.post(listResults,searchRequest,config)
										.then(function (response) {
											//function handles success condition
											if (response.data) {
												$scope.itemSets = response.data.itemSets;
												$scope.itemSetsFilter.push("Select");
												if ($scope.itemSets) {
													angular.forEach($scope.itemSets, function (set) {
														if (set) {
															var itSet = set.itemTypeName;
															$scope.itemSetsFilter.push(itSet);
														}
													});
												}
												$scope.selectedItemTypeName = $scope.itemSetsFilter[0];
												//LOAD CONVERSION STATUS
												$scope.conversionStatus = response.data.conversionStatus;
												$scope.conversionStatusFilter.push("Select");
												if ($scope.conversionStatus) {
													angular.forEach($scope.conversionStatus, function (set) {
														if (set) {
															var itSet = set.convStatName;
															$scope.conversionStatusFilter.push(itSet);
														}
													});
												}
												$scope.selectedConversionStatus = $scope.conversionStatusFilter[0];
												//LOAD DEPARTMENTS
												$scope.departmentList = response.data.departmentList;
												$scope.departmentListFilter.push("Select");
												if ($scope.departmentList) {
													angular.forEach($scope.departmentList, function (set) {
														if (set) {
															var itSet = set.convGrpName;
															$scope.departmentListFilter.push(itSet);
														}
													});
												}
												$scope.selectedDepartmentList = $scope.departmentListFilter[0];

												//LOAD CUSTOM TABLE STRUCTURE
												if (response.data.customVOS) {
													if (response.data.customVO.availableList && response.data.customVO.columnList) {
														$scope.availableList = response.data.customVO.availableList;
														$scope.columnList = response.data.customVO.columnList;

														//COMPARE AND LOAD COLUMN
														for (var i = 0; i < $scope.columnList.length; i++) {
															for (var j = 0; j < $scope.masterListJson.length; j++) {
																if ($scope.columnList[i].id == $scope.masterListJson[j].id) {
																	$scope.models.lists.Viewable.push({
																		label: $scope.masterListJson[j].label,
																		width: $scope.masterListJson[j].width,
																		product: $scope.masterListJson[j].product,
																		id: $scope.masterListJson[j].id
																	});

																	$scope.masterListJson.splice(j, 1);
																}
															}
														}
														

														for (var i = 0; i < $scope.masterListJson.length; i++) {
															$scope.models.lists.Additional.push({
																label: $scope.masterListJson[i].label,
																width: $scope.masterListJson[i].width,
																product: $scope.masterListJson[i].product,
																id: $scope.masterListJson[i].id
															});
														}
													} else {
														$scope.loadJsonData();
													}
												} else {
													$scope.loadJsonData();
												}
											}
										}, function (response1) {
											//function handles error condition
										});
									// };

									/**
									 * Load json data on initial load
									 */
									$scope.loadJsonData = function () {
										if ($scope.availableListJson && $scope.columnListJson) {
											for (var i = 0; i < $scope.availableListJson.length; i++) {
												$scope.models.lists.Additional.push({
													label: $scope.availableListJson[i].label,
													width: $scope.availableListJson[i].width,
													product: $scope.availableListJson[i].product,
													id: $scope.availableListJson[i].id
												});
											}
											for (var j = 0; j < $scope.columnListJson.length; j++) {
												$scope.models.lists.Viewable.push({
													label: $scope.columnListJson[j].label,
													width: $scope.columnListJson[j].width,
													product: $scope.columnListJson[j].product,
													id: $scope.columnListJson[j].id
												});

											}
											$scope.availableList = $scope.models.lists.Additional;
											$scope.columnList = $scope.models.lists.Viewable;
										}
									};

									/**
									 * method to set the department in filter
									 */
									$scope.changeFilterDepartment = function (filterdept) {
										if ($scope.departmentList && filterdept) {
											angular.forEach($scope.departmentList, function (set) {
												if (set && set.convGrpName === filterdept) {
													$scope.searchRequest.filter.prodHierarchyLvl4Cd = set.convGrpCode;
													$scope.searchRequest.filter.conversionGroupCd = set.convGrpCode;
												}
											});
										}

										if (filterdept && filterdept == "Select") {
											$scope.searchRequest.filter.department = null;
										}
									};

									/**
									 * method to set the itemset in filter
									 */
									$scope.changeItemset = function (item) {
										if ($scope.itemSets && item) {
											angular.forEach($scope.itemSets, function (set) {
												if (set && set.itemTypeName === item) {
													$scope.searchRequest.filter.itemType = set.itemTypeCode;
												}
											});
										}

										if (item && item == "Select") {
											$scope.searchRequest.filter.itemType = null;
										}
									};

									/**
									 * method to set the conversion status in filter
									 */
									$scope.changeConvStatus = function (status) {
										if ($scope.conversionStatus && status) {
											angular.forEach($scope.conversionStatus, function (set) {
												if (set && set.convStatName === status) {
													$scope.searchRequest.filter.conversionStatus = set.convStatCode;
												}
											});
										}

										if (status && status == "Select") {
											$scope.searchRequest.filter.conversionStatus = null;
										}
									};

									/**
									 * method to set the supply type in filter
									 */
									$scope.changeSupplyType = function (type) {
										if (type == "D" || type == "W" || type == "P") {
											$scope.searchRequest.filter.supplyType = type;
										}
										else {
											$scope.searchRequest.filter.supplyType = null;
										}
									};

									/**
									 * method to check department validation
									 */
									$scope.deptValidation = function () {
										if ($scope.departmentList != null || $scope.departmentList.length != 0) {
											if ($scope.selectedDepartmentList == (null || "Select")) {
												isDeptValid = false;
												document.getElementById('deptSelection').style.borderColor = "red";
												return isDeptValid;
											}
											else {
												isDeptValid = true;
												document.getElementById('deptSelection').style.removeProperty('border');
												return isDeptValid;
											}
										}
									};

									/**
									 * method to check conv status validation
									 */
									$scope.convStatusValidation = function () {
										if ($scope.conversionStatus != null || $scope.conversionStatus.length != 0) {
											if ($scope.selectedConversionStatus == (null || "Select")) {
												isConvStatValid = false;
												document.getElementById('convStatusSelection').style.borderColor = "red";
												return isConvStatValid;
											}
											else {
												isConvStatValid = true;
												document.getElementById('convStatusSelection').style.removeProperty('border');
												return isConvStatValid;
											}
										}
									};

									/**
									 * Apply filter and fetch result
									 */
									$scope.applyFilter = function (filterCriteria) {
										$scope.deptValidation();
										$scope.convStatusValidation();

										if (isDeptValid == false || isConvStatValid == false) {
											isValid = false;
											alertify.alert("Highlighted fields are Mandatory.");
											return;
										}
										else {
											isValid = true;
										}

										if (isValid) {
											if (filterCriteria.filter.companyId == ("" || undefined)) {
												filterCriteria.filter.companyId = service.selectedCompany.companyID;
											}
											if (filterCriteria.filter.divisionId == ("" || undefined)) {
												filterCriteria.filter.divisionId = service.selectedDivision.divisionID;
											}
											if (filterCriteria.filter.conversionGroupCd == ("" || undefined) || filterCriteria.filter.conversionGroupCd == "Select") {
												filterCriteria.filter.conversionGroupCd = null;
											}
											if (filterCriteria.filter.productSKU === "" || filterCriteria.filter.productSKU == undefined) {
												filterCriteria.filter.productSKU = null;
											}
											if (filterCriteria.filter.itemDescription === "" || filterCriteria.filter.itemDescription == undefined) {
												filterCriteria.filter.itemDescription = null;
											}
											if (filterCriteria.filter.supplierNum === "" || filterCriteria.filter.supplierNum == undefined) {
												filterCriteria.filter.supplierNum = null;
											}
											if (filterCriteria.filter.supplierName === "" || filterCriteria.filter.supplierName == undefined) {
												filterCriteria.filter.supplierName = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl1Cd === "" || filterCriteria.filter.prodHierarchyLvl1Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl1Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl2Cd === "" || filterCriteria.filter.prodHierarchyLvl2Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl2Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl3Cd === "" || filterCriteria.filter.prodHierarchyLvl3Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl3Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl4Cd === "" || filterCriteria.filter.prodHierarchyLvl4Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl4Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl5Cd === "" || filterCriteria.filter.prodHierarchyLvl5Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl5Cd = null;
											}
											if (filterCriteria.filter.producthierarchyName === "" || filterCriteria.filter.producthierarchyName == undefined) {
												filterCriteria.filter.producthierarchyName = null;
											}
											if (filterCriteria.filter.upc === "" || filterCriteria.filter.upc == undefined) {
												filterCriteria.filter.upc = null;
											}
											if (filterCriteria.filter.plu === "" || filterCriteria.filter.plu == undefined) {
												filterCriteria.filter.plu = null;
											}
											if (filterCriteria.filter.corpItemCd === "" || filterCriteria.filter.corpItemCd == undefined) {
												filterCriteria.filter.corpItemCd = null;
											}
											if (filterCriteria.filter.conversionStatus === "" || filterCriteria.filter.conversionStatus == undefined || filterCriteria.filter.conversionStatus == "Select") {
												filterCriteria.filter.conversionStatus = null;
											}
											if (filterCriteria.filter.itemType === "" || filterCriteria.filter.itemType == undefined || filterCriteria.filter.itemType == "Select") {
												filterCriteria.filter.itemType = null;
											}
											if (filterCriteria.filter.supplyType === "" || filterCriteria.filter.supplyType == undefined || filterCriteria.filter.supplyType == "Select") {
												filterCriteria.filter.supplyType = null;
											}
											startIndex = 1;
											endIndex = 500;
											filterCriteria.filter.startIndex = startIndex;
											filterCriteria.filter.endIndex = endIndex;
											$scope.finalizedList = [];
											$scope.searchFilterBasedOnCond(filterCriteria);
										}
									};

									/**
									 *  Get new set of data and append
									 */
									$scope.loadMore = function (filterCriteria) {
										$scope.deptValidation();
										$scope.convStatusValidation();

										if (isDeptValid == false || isConvStatValid == false) {
											isValid = false;
											alertify.alert("Highlighted fields are Mandatory.");
											return;
										}
										else {
											isValid = true;
										}

										if (isValid) {
											if (filterCriteria.filter.companyId == ("" || undefined)) {
												filterCriteria.filter.companyId = service.selectedCompany.companyID;
											}
											if (filterCriteria.filter.divisionId == ("" || undefined)) {
												filterCriteria.filter.divisionId = service.selectedDivision.divisionID;
											}
											if (filterCriteria.filter.conversionGroupCd === "" || filterCriteria.filter.conversionGroupCd == undefined || filterCriteria.filter.conversionGroupCd == "Select") {
												filterCriteria.filter.conversionGroupCd = null;
											}
											if (filterCriteria.filter.productSKU === "" || filterCriteria.filter.productSKU == undefined) {
												filterCriteria.filter.productSKU = null;
											}
											if (filterCriteria.filter.itemDescription === "" || filterCriteria.filter.itemDescription == undefined) {
												filterCriteria.filter.itemDescription = null;
											}
											if (filterCriteria.filter.supplierNum === "" || filterCriteria.filter.supplierNum == undefined) {
												filterCriteria.filter.supplierNum = null;
											}
											if (filterCriteria.filter.supplierName === "" || filterCriteria.filter.supplierName == undefined) {
												filterCriteria.filter.supplierName = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl1Cd === "" || filterCriteria.filter.prodHierarchyLvl1Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl1Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl2Cd === "" || filterCriteria.filter.prodHierarchyLvl2Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl2Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl3Cd === "" || filterCriteria.filter.prodHierarchyLvl3Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl3Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl4Cd === "" || filterCriteria.filter.prodHierarchyLvl4Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl4Cd = null;
											}
											if (filterCriteria.filter.prodHierarchyLvl5Cd === "" || filterCriteria.filter.prodHierarchyLvl5Cd == undefined) {
												filterCriteria.filter.prodHierarchyLvl5Cd = null;
											}
											if (filterCriteria.filter.producthierarchyName === "" || filterCriteria.filter.producthierarchyName == undefined) {
												filterCriteria.filter.producthierarchyName = null;
											}
											if (filterCriteria.filter.upc === "" || filterCriteria.filter.upc == undefined) {
												filterCriteria.filter.upc = null;
											}
											if (filterCriteria.filter.plu === "" || filterCriteria.filter.plu == undefined) {
												filterCriteria.filter.plu = null;
											}
											if (filterCriteria.filter.corpItemCd === "" || filterCriteria.filter.corpItemCd == undefined) {
												filterCriteria.filter.corpItemCd = null;
											}
											if (filterCriteria.filter.conversionStatus === "" || filterCriteria.filter.conversionStatus == undefined || filterCriteria.filter.conversionStatus == "Select") {
												filterCriteria.filter.conversionStatus = null;
											}
											if (filterCriteria.filter.itemType === "" || filterCriteria.filter.itemType == undefined || filterCriteria.filter.itemType == "Select") {
												filterCriteria.filter.itemType = null;
											}
											if (filterCriteria.filter.supplyType === "" || filterCriteria.filter.supplyType == undefined || filterCriteria.filter.supplyType == "Select") {
												filterCriteria.filter.supplyType = null;
											}
											startIndex = endIndex + 1;
											endIndex = endIndex + 500;
											filterCriteria.filter.startIndex = startIndex;
											filterCriteria.filter.endIndex = endIndex;

											$scope.searchFilterBasedOnCond(filterCriteria);
										}
									};

									/**
									 *  Save the reordering list and get new data
									 */
									$scope.searchFilterBasedOnCond = function (filterCri) {

										var listResults = $scope.baseUrl + "lookUp/loadSearchData";

										$http.post(listResults, filterCri.filter, config)
											.then(function (response) {
												if (response && response.data) {
													$scope.finalizedListNo = response.data.serchResults;
													if ($scope.finalizedListNo && $scope.finalizedListNo.length > 0) {
														$scope.displayResultDiv = true;
														$scope.noResultPage = false;
														$scope.repeatList = [];
														for (var k = 0; k < $scope.finalizedListNo.length; k++) {
															for (var j = 0; j < $scope.columnList.length; j++) {
																angular.forEach($scope.finalizedListNo[k], function (value, key) {
																	if ($scope.columnList[j].id == key) {
																		$scope.repeatList.push({
																			label: key,
																			itemVal: value
																		});
																	}
																});
															}
															$scope.finalizedList.push($scope.repeatList);
															$scope.repeatList = [];
														}

														var saveList = [];
														saveList = $scope.models.lists.Viewable;
														$scope.savedList = saveList;

														if (response.data.count < 500) {
															$scope.restrictLoadMore = true;
														} else {
															$scope.restrictLoadMore = false;
														}
														endIndex = $scope.finalizedList.length;
														$scope.paginate.itemsCount = range(1, $scope.finalizedList.length + 1); // array of items to be paged
														$scope.paginate.pager = {};

														$scope.paginate.setPage = function (page) {
															if (page < 1 || page > $scope.paginate.pager.totalPages) {
																return;
															}
															//CLEAR SELECTED ITEMS LIST
															$scope.markedLkpSkus = [];
															// get pager object from service
															$scope.paginate.pager = PagerService.GetPager($scope.paginate.itemsCount.length, page);
															// get current page of items
															$scope.paginate.items = $scope.finalizedList.slice($scope.paginate.pager.startIndex, $scope.paginate.pager.endIndex + 1);
														};
														$scope.paginate.setPage(1);
													} else {
														$scope.displayResultDiv = false;
														$scope.noResultPage = true;
													}
													var excelRequest = filterCri;
													$scope.excelSearchRequest = angular.copy(excelRequest);
												}
											}, function (response1) {
												//function handles error condition
											});

									};

									/**
									 *  Selecting items in the pagination tab
									 */
									$scope.selectChkBox = function (pageNo, index) {
										var item = $scope.paginate.items[index];
										var tempItem = {};
										var isRepeated = false;
										if ($("#targetchkbox_" + index).is(':checked')) {


											tempItem.companyId = $scope.companyID;
											tempItem.divisionId = $scope.divisionID;
											for (var i = 0; i < item.length; i++) {
												if (item[i].label == "src_prod_sku") {
													tempItem.productSKU = item[i].itemVal;
												}
												if (item[i].label == "src_upc") {
													tempItem.upc = item[i].itemVal;
												}
												if (item[i].label == "src_conv_st_cd") {
													tempItem.currentStatusCd = item[i].itemVal;
												}
												if (item[i].label == "src_conv_st_sb_cd") {
													tempItem.currentStatusSubCd = item[i].itemVal;
												}
											}
											$scope.markedLkpSkus.push(tempItem);
										}
										else {
											for (var j = 0; j < $scope.markedLkpSkus.length; j++) {
												for (var k = 0; k < item.length; k++) {
													if (item[k].label == "src_prod_sku") {
														if (item[k].itemVal == $scope.markedLkpSkus[j].productSKU) {
															isRepeated = true;
														}
													}
													if (isRepeated && item[k].label == "src_upc") {
														if (item[k].itemVal == $scope.markedLkpSkus[j].upc) {
															$scope.markedLkpSkus.splice(j, 1);
														}
													}
												}
											}
										}
										
									};

									/**
									 *  Mark as Dead function
									 */
									$scope.markAsDead = function (searchRequest) {
										if ($scope.markedLkpSkus && $scope.markedLkpSkus.length > 0) {
											alertify.prompt("Selected item(s) will be marked as dead. Provide a reason for it.", function (e, str) {
												if (e) {
													$scope.btnAction(searchRequest, "DEAD", str);
												} else {
													//code incase of cancel
												}
											});
										}
										else {
											alertify.alert("Select any items to proceed.");
											return;
										}
									};

									/**
									 *  Convert status from Completed to Ready
									 */
									$scope.convertToReady = function (searchRequest) {
										$scope.btnAction(searchRequest, "READY", null);
									};

									/**
									 *  Common method for all Button actions
									 */
									$scope.btnAction = function (searchRequest, type, comments) {
										var statusCode = 0;
										searchRequest.filter.sortOrder = $scope.sortLkpOrder.name;
										searchRequest.filter.sortItems = $scope.sortItems;

										$scope.saveLookupRequests = [];
										if ($scope.markedLkpSkus && $scope.markedLkpSkus.length > 0) {
											$scope.LookUpActionWrapper = {};
											$scope.LookUpActionWrapper.searchInputs = {};
											$scope.LookUpActionWrapper.searchInputs = searchRequest.filter;
											$scope.LookUpActionWrapper.actionsRequests = [];

											angular.forEach($scope.markedLkpSkus, function (item) {
												$scope.saveLkpRequest = {};
												$scope.saveLkpRequest.companyId = item.companyId;
												$scope.saveLkpRequest.divisionId = item.divisionId;
												$scope.saveLkpRequest.productSKU = item.productSKU;
												$scope.saveLkpRequest.upc = item.upc;
												$scope.saveLkpRequest.currentStatusCd = item.currentStatusCd;
												$scope.saveLkpRequest.currentStatusSubCd = item.currentStatusSubCd;
												$scope.saveLkpRequest.changestatusCd = type;
												$scope.saveLkpRequest.statusReasonComments = comments;
												if (type == "DEAD") {
													if (item.currentStatusCd == "C") {
														statusCode = 1;
													}
													if (item.currentStatusCd == "D") {
														statusCode = 2;
													}
												}
												//					if(type == "READY"){
												//						if(item.currentStatusCd != "C"){
												//							alertify.alert("These items can't be marked as Dead.");
												//							return;
												//							
												//						}
												//						if(item.currentStatusCd == "D"){
												//							alertify.alert("Dead items can't be marked Ready.");
												//							return;
												//						}
												//					}
												$scope.saveLookupRequests.push($scope.saveLkpRequest);
											});

											if (statusCode == 1) {
												alertify.alert("Completed items can't be marked as Dead.");
												return;
											} else if (statusCode == 2) {
												alertify.alert("Dead items can't be marked as Dead again.");
												return;
											}

											$scope.LookUpActionWrapper.actionsRequests = $scope.saveLookupRequests;


											var listResults = $scope.baseUrl + "lookUp/performButtonAction";

											$http.post(listResults, $scope.LookUpActionWrapper, config)
												.then(function (response) {
													if (response && response.data) {
														$scope.finalizedList = [];
														$scope.finalizedListNo = response.data.serchResults;
														if ($scope.finalizedListNo && $scope.finalizedListNo.length > 0) {
															$scope.displayResultDiv = true;
															$scope.noResultPage = false;
															$scope.repeatList = [];
															for (var k = 0; k < $scope.finalizedListNo.length; k++) {
																for (var j = 0; j < $scope.columnList.length; j++) {
																	angular.forEach($scope.finalizedListNo[k], function (value, key) {
																		if ($scope.columnList[j].id == key) {
																			$scope.repeatList.push({
																				label: key,
																				itemVal: value
																			});
																		}
																	});
																}
																$scope.finalizedList.push($scope.repeatList);
																$scope.repeatList = [];
															}

															var saveList = [];
															saveList = $scope.models.lists.Viewable;
															$scope.savedList = saveList;

															if (response.data.count < 500) {
																$scope.restrictLoadMore = true;
															} else {
																$scope.restrictLoadMore = false;
															}
															endIndex = $scope.finalizedList.length;
															$scope.paginate.itemsCount = range(1, $scope.finalizedList.length + 1); // array of items to be paged
															$scope.paginate.pager = {};

															$scope.paginate.setPage = function (page) {
																if (page < 1 || page > $scope.paginate.pager.totalPages) {
																	return;
																}
																//CLEAR SELECTED ITEMS LIST
																$scope.markedLkpSkus = [];
																// get pager object from service
																$scope.paginate.pager = PagerService.GetPager($scope.paginate.itemsCount.length, page);
																// get current page of items
																$scope.paginate.items = $scope.finalizedList.slice($scope.paginate.pager.startIndex, $scope.paginate.pager.endIndex + 1);
															};
															$scope.paginate.setPage(1);
														} else {
															$scope.displayResultDiv = false;
															$scope.noResultPage = true;
														}
													}
												}, function (response1) {
													//function handles error condition
												});
										}
										else {
											alertify.alert("Select any items to proceed.");
											return;
										}
									};

									/**
									 *  Save the reordering list and get new data
									 */
									$scope.saveChangelist = function () {
										$scope.finalizedList = [];
										$scope.repeatList = [];
										$scope.savedList = [];
										$scope.savedList = $scope.models.lists.Viewable;
										$scope.columnList = $scope.models.lists.Viewable;
										$scope.availableList = $scope.models.lists.Additional;

										for (var k = 0; k < $scope.finalizedListNo.length; k++) {
											for (var j = 0; j < $scope.savedList.length; j++) {
												angular.forEach($scope.finalizedListNo[k], function (value, key) {
													if ($scope.savedList[j].id == key) {
														$scope.repeatList.push({
															label: key,
															itemVal: value
														});
													}
												});
											}

											$scope.finalizedList.push($scope.repeatList);
											$scope.repeatList = [];
										}

										$scope.returnList = {};
										$scope.returnList.columnList = $scope.savedList;
										$scope.returnList.availableList = $scope.availableList;
										$scope.returnList.userId = service.userId;
										//$scope.modelAsJson = angular.toJson($scope.returnList, true);
									



										var listResults = $scope.baseUrl + "lookUp/saveColumnCustomization";

										$http.post(listResults, $scope.returnList, config)
											.then(function (response) {
												//alertify.success("Saved successfully!");
											}, function (response1) {
												//function handles error condition
											});
										$scope.paginate.setPage(1);
										$('#rearrangediv').modal('hide');
									};

									/**
									 *  Cancel the filter to default view
									 */
									$scope.cancelFilter = function () {
										$scope.excelSearchRequest = {};
										$scope.searchRequest.filter = {};
										$scope.selectedDepartmentList = "Select";
										$scope.selectedItemTypeName = "Select";
										$scope.selectedSupplyType = "";
										$scope.selectedConversionStatus = "Select";

									};

									/**
									 *  Reset the filter to default view and hide result
									 */
									$scope.resetFilter = function () {
										$scope.cancelFilter();
										$scope.displayResultDiv = false;
										$scope.noResultPage = false;
										$scope.resetLkpSortModels();
									};

									/**
									 *  Reset the reordering data to default view
									 */
									$scope.resetChangelist = function () {
										$scope.availableList = [];
										$scope.columnList = [];
										$scope.savedList = [];
										$scope.finalizedList = [];
										$scope.models.lists.Additional = [];
										$scope.models.lists.Viewable = [];
										$scope.loadColumn($scope.companyID, $scope.divisionID, $scope.userId);
										$scope.paginate.setPage(1);
									};

									/**
									 * Toggle arrow for expanded view
									 */
									$scope.toggleArrow = function ($event, tabid) {
										var msie = $document[0].documentMode;
										if (msie) {
											$(event.target).toggleClass('glyphicon-menu-up glyphicon-menu-down');
										} else {
											$(event.target).toggleClass('glyphicon-menu-up glyphicon-menu-down');
										}
										var classname = (event.target.className).toString();

										if (classname.indexOf("collapsed") !== -1) {
											$('.resultPanel').css('height', windowHeight - 430);
										} else {
											$('.resultPanel').css('height', windowHeight - 240);
										}
									};

									/**
									 *  Show/Hide re-ordering popup
									 */
									$scope.popup = function (buttonValue) {
										if (buttonValue == "Rearrange") {
											$("#rearrangediv").modal({ backdrop: 'static', keyboard: false }, "show");
										}
									};

									/**
									 *  U63178
									 *  Function to toggle all sub menu when a dropdown item is selected.
									 */
									$scope.filterSubToggle = function (key) {
										if (key) {
											switch (key) {
												case 'sort':
													$("#ascendingSort").hide();
													$("#descendingSort").hide();
													break;

												case 'ascendingSortAction':
													$("#ascendingSort").show();
													$("#descendingSort").hide();
													break;

												case 'descendingSortAction':
													$("#ascendingSort").hide();
													$("#descendingSort").show();
													break;

												default:
													break;
											}
										}
									};

									/**
									 * U63178
									 * Export excel
									 */
									$scope.exportExcel = function () {
										
										if ($scope.excelSearchRequest && $scope.finalizedListNo && $scope.finalizedListNo.length > 0) {
											$scope.excelSearchRequest.filter.sortOrder = $scope.sortLkpOrder.name;
											$scope.excelSearchRequest.filter.sortItems = $scope.sortItems;
											var date = Date.now();
											$http({
												url: $scope.baseUrl + "lookUp/exportIntoExcel",
												method: "POST",
												data: $scope.excelSearchRequest.filter, //this is your json data string
												headers: {
													'Content-type': 'application/json',
													'Ocp-Apim-Subscription-Key': extractedHeader
												},
												responseType: 'arraybuffer'
											}).success(function (data, status, headers, config) {
												var blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8" });
												if (window.navigator.msSaveOrOpenBlob) { // For IE:
													navigator.msSaveBlob(blob, date + "_LookupResult_" + $scope.selectedDepartmentList + ".xls");
												} else { // For other browsers:
													var link = document.createElement('a');
													link.href = window.URL.createObjectURL(blob);
													link.download = date + "_LookupResult_" + $scope.selectedDepartmentList + ".xls";
													link.click();
													window.URL.revokeObjectURL(link.href);
												}
											}).error(function (data, status, headers, config) {
												//download failed
												console.log("Service out of memory!!!");
											});
										}
									};

								});
							});
						}
						else {
							$scope.companyID = null;
							$scope.divisionID = null;
						}
					}

					/**
				 * U63178
				 * Apply sorting on source items
				 */
					$scope.applyLkpSort = function (searchRequest) {
						$scope.sortItems = [];
						if ($scope.sortlkpmodels) {
							for (var i = 0; i < $scope.sortlkpmodels[0].items.length; i++) {
								if ($scope.sortlkpmodels[0].items[i].selected == true) {
									$scope.sortItems.push($scope.sortlkpmodels[0].items[i].value);
								}
							}

							searchRequest.filter.sortOrder = $scope.sortLkpOrder.name;
							searchRequest.filter.sortItems = $scope.sortItems;

							$scope.applyFilter(searchRequest);
							$("#sortLkpSectionExpand").hide();
						}
					};


					$scope.closeLkpSort = function () {
						$("#sortLkpSectionExpand").hide();
					};

					/**
					 *  U63178
					 *  Source Sort Order
					 */
					$scope.loadLkpSortModels = function () {
						$scope.sortlkpmodels = [{ listName: "A", items: [], dragging: false }];

						// Generate the initial model
						angular.forEach($scope.sortlkpmodels, function (list) {
							for (var i = 0; i < 1; i++) {
								list.items.push({ label: "Conv GroupCode", value: "LKPCONGP" });
								list.items.push({ label: "Hierarchy 1", value: "LKPHIER1" });
								list.items.push({ label: "Hierarchy 2", value: "LKPHIER2" });
								list.items.push({ label: "Hierarchy 3", value: "LKPHIER3" });
								list.items.push({ label: "Supplier No", value: "LKPSUPNO" });
								list.items.push({ label: "Supplier Name", value: "LKPSUPNM" });
								list.items.push({ label: "Item Description", value: "LKPITMDS" });
							}
						});
					};

					$scope.resetLkpSortModels = function () {
						$scope.sortlkpmodels = [];
						$scope.sortLkpOrder = { name: 'A' };
						$scope.loadLkpSortModels();
					};

					/**
					 * dnd-dragging determines what data gets serialized and send to the receiver
					 * of the drop. While we usually just send a single object, we send the array
					 * of all selected items here.
					 */
					$scope.getSelectedItemsIncluding = function (list, item) {
						item.selected = true;
						return list.items.filter(function (item) { return item.selected; });
					};

					/**
					 * In the dnd-drop callback, we now have to handle the data array that we
					 * sent above. We handle the insertion into the list ourselves. By returning
					 * true, the dnd-list directive won't do the insertion itself.
					 */
					$scope.onDrop = function (list, items, index) {
						angular.forEach(items, function (item) { item.selected = false; });
						list.items = list.items.slice(0, index)
							.concat(items)
							.concat(list.items.slice(index));
						return true;
					};

					/**
					 * Last but not least, we have to remove the previously dragged items in the
					 * dnd-moved callback.
					 */
					$scope.onMoved = function (list) {
						list.items = list.items.filter(function (item) { return !item.selected; });
					};
				});




			}
		]);

	function range(start, edge, step) {
		// If only one number was passed in make it the edge and 0 the start.
		if (arguments.length == 1) {
			edge = start;
			start = 0;
		}

		// Validate the edge and step numbers.
		edge = edge || 0;
		step = step || 1;

		// Create the array of numbers, stopping befor the edge.
		for (var ret = [];
			(edge - start) * step > 0; start += step) {
			ret.push(start);
		}
		return ret;
	}

	function PagerService() {
		// service definition
		var service = {};

		service.GetPager = GetPager;

		return service;

		// service implementation
		function GetPager(totalItems, currentPage, pageSize) {
			// default to first page
			currentPage = currentPage || 1;

			// default page size is 10
			pageSize = pageSize || 50;

			// calculate total pages
			var totalPages = Math.ceil(totalItems / pageSize);

			var startPage, endPage;
			if (totalPages <= 10) {
				// less than 10 total pages so show all
				startPage = 1;
				endPage = totalPages;
			} else {
				// more than 10 total pages so calculate start and end pages
				if (currentPage <= 6) {
					startPage = 1;
					endPage = 10;
				} else if (currentPage + 4 >= totalPages) {
					startPage = totalPages - 9;
					endPage = totalPages;
				} else {
					startPage = currentPage - 5;
					endPage = currentPage + 4;
				}
			}

			// calculate start and end item indexes
			var startIndex = (currentPage - 1) * pageSize;
			var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

			// create an array of pages to ng-repeat in the pager control
			var pages = range(startPage, endPage + 1);

			// return object with all pager properties required by the view
			return {
				totalItems: totalItems,
				currentPage: currentPage,
				pageSize: pageSize,
				totalPages: totalPages,
				startPage: startPage,
				endPage: endPage,
				startIndex: startIndex,
				endIndex: endIndex,
				pages: pages
			};
		}
	}

})();