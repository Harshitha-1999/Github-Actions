(function () {
	'use strict';

	myApp.controller('MappedController', ['$scope', '$http', '$location', '$document', 'blockUI', 'service', '$timeout',
		function MappedController($scope, $http, $location, $document, blockUI, service, $timeout) {

			$scope.displayMappedpage = false;
			$scope.displayMappedAlert = true;
			$scope.displayNoResultAlert = false;
			// varables for sorting //
			var sortBySku = 'source.sourceSKU/1';
			var SortByItemDesc = '-source.itemDesc';
			var SortByVcf = '-source.vcf';
			var SortByPack = '-source.pack';
			var SortByUpc = '-source.upc';
			var SortBySize = '-source.size';


			/** 
			 * U63178 
			 * Initialise - Service loading 
			 * */
			
			if (service.baseUrlFunction() != undefined) {
				service.baseUrlFunction().then(function (url) {
					$scope.baseUrl = url;

					service.getHeaders().then(function (header) {
						var config = header
						//    });
						$('[data-toggle="expandedView"]').tooltip();
						//Set default 'sort by' value for CIC and SKU list	
						$scope.mappedSortVal = sortBySku;

						var windowHeight = $(window).innerHeight();
						$('.mappedScrollDiv').css('height', windowHeight - 165);

						$scope.$watch('selectedCompany', function (value) {
							if (value && value.companyID) {
								$scope.searchMappedRequest = {};
								$scope.searchMappedRequest.companyID = service.selectedCompany.companyID;
								$scope.displayMappedpage = false;
								$scope.displayMappedAlert = false;
							}
						});
						$scope.$watch('selectedDivision', function (value) {
							if (value && value.divisionID) {
								$scope.searchMappedRequest.divisionID = service.selectedDivision.divisionID;
								$scope.displayMappedpage = true;
								$scope.displayMappedAlert = true;
								$scope.displayNoResultAlert = false;
								if ($scope.displayMappedpage == true) {
									$scope.searchMappedRequest.filterAvail = false;
									$scope.searchMappedRequest.filter = {};
									$scope.searchMappedRequest.mappingStatus = "BOTH";
									$scope.mappedsearchCriteriaValue = null;
									$scope.sourceSearchCriteriaDepartments = [];
									$scope.targetSearchCriteriaDepartments = [];
									$scope.selectedRequests = [];
									$scope.unselectedMapRequests = [];
									$scope.unMappingRequests = [];
									$scope.mappedResults = [];
									$scope.upcClicked = false;
									$scope.checkedUPC = true;
									$scope.buyerItem = false;
									$scope.sellerItem = false;
									$scope.setSourceDepartmentCriterias();
									$scope.setTargetDepartmentCriterias();
									$scope.selectAll = false;
									$scope.selectedAll = false;
									$scope.actionButton = false;
									$scope.selectButtonVal = "Select All";
									$scope.selectedMappedSearchCriteria = "Select";
									$scope.selectedStatus = "Mapped";
									$scope.colorSelected = "bgGreen";
									$scope.mappedColors = [];
									$scope.returnLists = [];
								}
							} else {
								$scope.displayMappedpage = false;
								$scope.displayMappedAlert = false;
							}

							/**
							 * U62615
							 * getting data like status/departments/search criterias from mapped.properties file and setting into variables
							 */
							$http.get('perishables/json/mapped-properties.json').then(function (response) {
								if (response && response.data) {
									$scope.mappedStatuses = response.data[0].mappedStatuses; //Filter By Status Values
									$scope.mappedColors = response.data[0].colors;   //Filter By Status Colors
									$scope.searchSourceMappedCriterias = response.data[0].searchSourceMappedCriterias; //search criterias for Mapped source subdropdown
									$scope.searchTargetMappedCriterias = response.data[0].searchTargetMappedCriterias; //search criterias for Mapped target subdropdown
								}
							});
						});

						// ----------------------------SEARCH DROPDOWN------------DO NOT CHANGE----------------------------------------------------------------

						$('.dropdown-submenu a.maptest').on("click", function (e) {
							if (!$(this).next().hasClass('show')) {
								$(this).parents('.dropdown-menu').first().find('.show').removeClass('show');
							}
							var $subMenu = $(this).next('.dropdown-menu');
							$subMenu.toggleClass('show');


							$(this).parents('div.dropdown.pull-left.col-md-4.p0.open').on('hidden.bs.dropdown', function (e) {
								$('ul.dropdown-menu .show').removeClass('show');
							});
							return false;
						});

						// ------------------------------------------------------------------------------------------------------------------

						/**
						 * U62615
						 * Common method to set itemType to default "All" in each search/status action initially
						 */
						$scope.setItemType = function (request) {
							if (!request.itemType) {
								request.itemType = {};
								request.itemType.all = true;
								request.itemType.system2 = false;
								request.itemType.system4 = false;
								request.itemType.plu = false;
							}
						};

						/**
						 * U62615
						 * Load the mapped result data according to search request
						 */

						$scope.listResults = function (searchRequest) {

							var listMappedResults = $scope.baseUrl + "perishable/mappedList";

							$http.post(listMappedResults, searchRequest, config)
								.then(function (response) {
									//function handles success condition
									if (response.data && response.data.mappedResultWrapper && response.data.mappedResultWrapper.length > 0) {
										$scope.mappedResults = response.data.mappedResultWrapper;
										if ((!$scope.mappedResults) || ($scope.mappedResults && $scope.mappedResults.length < 1)) {
											$scope.displayNoResultAlert = true;
										} else {
											$scope.displayNoResultAlert = false;
										}
										if ($scope.mappedResults && $scope.mappedResults.length > 0) {
											if ($scope.mappedResults instanceof Object) {
												var mappedCount = $scope.mappedResults.length;
												$scope.displayMappedAlert = false;
												for (var i = 0; i < mappedCount; i++) {
													$scope.mappedResults[i].expBtnClass = "bgGreen";
													if ($scope.mappedResults[i].mappedStatus == 'CONVERTED') {
														$scope.mappedResults[i].expBtnClass = "bgBlue";
													}
													if ($scope.mappedResults[i].mappedStatus == 'SHOW_ALL') {
														$scope.mappedResults[i].expBtnClass = "bgYellow";
													}
													if ($scope.mappedResults[i].mappedStatus == 'MAPPED') {
														$scope.mappedResults[i].expBtnClass = "bgGreen";
													}
												}
											}
										}
									} else {
										$scope.mappedResults = [];
										$scope.displayMappedAlert = false;
										$scope.displayNoResultAlert = true;
									}
									$scope.returnLists = [];
									$scope.selectedRequests = [];
									$scope.unselectedMapRequests = [];
									$scope.unMappingRequests = [];
									$scope.upcClicked = false;
								}, function (response1) {
									//function handles error condition
								});
						};



						/**
						 *  U62615
						 * Method to display Sales date details
						 */
						$scope.showSalesDate = function (skuClicked) {
							$scope.enteredEqual = false;

							$scope.detailsPassing = [];
							$scope.detailsPassing.push($scope.searchMappedRequest.companyID);
							$scope.detailsPassing.push($scope.searchMappedRequest.divisionID);
							$scope.detailsPassing.push(skuClicked);
							if ($scope.searchMappedRequest.mappingStatus == "ADD_MAP" || $scope.searchMappedRequest.mappingStatus == "INHERIT_MAP" || $scope.searchMappedRequest.mappingStatus == "BOTH") {
								$scope.detailsPassing.push("MAPPED");
							} else {
								$scope.detailsPassing.push($scope.searchMappedRequest.mappingStatus);
							}
							$scope.detailsPassing.push("ALL");

							if ($scope.returnLists && $scope.returnLists.length > 0) {
								for (var i = 0; i < $scope.returnLists.length; i++) {
									if ($scope.returnLists[i].sku == skuClicked && $scope.returnLists[i].upcList && $scope.returnLists[i].upcList.length > 0 && $scope.returnLists[i].settedItemType == $scope.itemTypeSelected) {
										$scope.skuOpted.upcSalesDetails = [];
										$scope.skuOpted.upcSalesDetails = $scope.returnLists[i].upcList;
										$scope.enteredEqual = true;
										break;
									}
								}
								if (!$scope.enteredEqual) {
									$scope.upcLoadFunction(skuClicked);
								}
							} else if ($scope.returnLists && $scope.returnLists.length == 0) {
								$scope.upcLoadFunction(skuClicked);
							}
						};

						/**
						 *  U62615
						 * Store the UPC list in temp array
						 */
						$scope.upcLoadFunction = function (skuClicked) {
							$scope.skuOpted = {};
							$scope.skuOpted.upcSalesDetails = [];

							var listResults = $scope.baseUrl + "perishable/mappedUpcListDetails";

							$http.post(listResults, $scope.detailsPassing, config)
								.then(function (response) {
									//function handles success condition
									if (response.data) {
										$scope.skuOpted.upcSalesDetails = response.data;

										$scope.returnList = {};
										$scope.returnList.sku = "";
										$scope.returnList.upcList = [];
										$scope.returnList.sku = skuClicked;
										$scope.returnList.upcList = $scope.skuOpted.upcSalesDetails;
										$scope.returnLists.push($scope.returnList);

									}
								}, function (response1) {
									//function handles error condition
								});
						};

						/**
						 * U62615
						 * Set Source Department Criteria
						 */
						$scope.setSourceDepartmentCriterias = function () {
							var sourceDepartmentsURL = $scope.baseUrl + "perishable/listDepartmentSource/" + $scope.searchMappedRequest.companyID + "/" + $scope.searchMappedRequest.divisionID;

							$http.get(sourceDepartmentsURL, config)
								.then(function (response) {
									//function handles success condition
									if (response.data) {
										$scope.sourceDepartments = response.data;
										if ($scope.sourceDepartments) {
											angular.forEach($scope.sourceDepartments, function (dept) {
												if (dept) {
													var sourceDept = dept[1];
													$scope.sourceSearchCriteriaDepartments.push(sourceDept);
												}
											});
										}

									}


								}, function (response1) {
									//function handles error condition
								});
						};

						/**
						 * U62615
						 * Set Target Department Criteria
						 */
						$scope.setTargetDepartmentCriterias = function () {
							var targetDepartmentsURL = $scope.baseUrl + "perishable/listDepartmentTarget/" + $scope.searchMappedRequest.companyID + "/" + $scope.searchMappedRequest.divisionID;

							$http.get(targetDepartmentsURL, config)
								.then(function (response) {
									//function handles success condition
									if (response.data) {
										$scope.targetDepartments = response.data;
										if ($scope.targetDepartments) {
											angular.forEach($scope.targetDepartments, function (dept) {
												if (dept) {
													var targetDept = dept[0];
													$scope.targetSearchCriteriaDepartments.push(targetDept);
												}
											});
										}

									}


								}, function (response1) {
									//function handles error condition
								});
						};

						/**
						 * U62615
						 * Method to set the selected search criteria and value when each criteria is selected
						 */
						$scope.setSourceSearchCriteria = function (criteria, value) {
							// $("#srcFilterForSource").hide();
							// $("#srcFilterForTarget").hide();
							/* $scope.srcFilterForSource = false;
							$scope.srcFilterForTarget = false; */
							
							$scope.selectedMappedSearchCriteria = null;
							$scope.searchMappedRequest.searchCriteriaValue = null;
							
							$scope.mappedsearchCriteriaValue = null;
							$scope.searchMappedRequest.searchIndicator = "SOURCE_INDICATOR";
							switch (criteria) {
								case 'SKU':
									$scope.searchMappedRequest.searchCriteria = "SKU_VAL";
									break;
								case 'Item Description':
									$scope.searchMappedRequest.searchCriteria = "ITEM_DESC";
									break;
								case 'UPC':
									$scope.searchMappedRequest.searchCriteria = "UPC_VAL";
									break;
								case 'Display-Y':
									$scope.searchMappedRequest.searchCriteria = "DISP";
									$scope.searchMappedRequest.searchCriteriaValue = "Y";
									$scope.mappedsearchCriteriaValue = "Y";
									break;
								case 'Display-N':
									$scope.searchMappedRequest.searchCriteria = "DISP";
									$scope.searchMappedRequest.searchCriteriaValue = "N";
									$scope.mappedsearchCriteriaValue = "N";
									break;
								case 'WHSE':
									$scope.searchMappedRequest.searchCriteria = "WHSE";
									$scope.searchMappedRequest.searchCriteriaValue = "Y";
									$scope.mappedsearchCriteriaValue = "Y";
									break;
								case 'DSD':
									$scope.searchMappedRequest.searchCriteria = "DSD";
									$scope.searchMappedRequest.searchCriteriaValue = "Y";
									$scope.mappedsearchCriteriaValue = "Y";
									break;
								case 'Select':
									$scope.searchMappedRequest.searchCriteria = null;
									$scope.searchMappedRequest.searchIndicator = null;
									value = null;
									break;
								case 'Usage':
									$scope.searchMappedRequest.searchCriteria = "USAGE_TYPE";
									$scope.searchMappedRequest.searchCriteriaValue = value;
									$scope.mappedsearchCriteriaValue = value;
									break;
								default:
									$scope.searchMappedRequest.searchCriteria = null;
							}

							if ($scope.sourceDepartments) {
								angular.forEach($scope.sourceDepartments, function (dept) {
									if (dept) {
										if (dept[1] === criteria) {
											$scope.searchMappedRequest.searchCriteria = "DEPT_NAME";
											$scope.searchMappedRequest.searchCriteriaValue = dept[0];
											$scope.mappedsearchCriteriaValue = criteria;
										}

									}
								});
							}

							if ($scope.searchMappedRequest.searchCriteria == "DISP") {
								$scope.selectedMappedSearchCriteria = "Display";
							} else if ($scope.searchMappedRequest.searchCriteria == "DEPT_NAME") {
								$scope.selectedMappedSearchCriteria = "Department";
							} else if ($scope.searchMappedRequest.searchCriteria == "USAGE_TYPE") {
								$scope.selectedMappedSearchCriteria = "Usage Ind";
							} else {
								$scope.selectedMappedSearchCriteria = criteria;
							}
						};

						/**
						 * U62615
						 * Method to set the selected search criteria and value when each criteria is selected
						 */
						$scope.setTargetSearchCriteria = function (criteria, value) {
							// $("#srcFilterForSource").hide();
							// $("#srcFilterForTarget").hide();
							/* $scope.srcFilterForSource = false;
							$scope.srcFilterForTarget = false; */

							$scope.selectedMappedSearchCriteria = null;
							$scope.searchMappedRequest.searchCriteriaValue = null;
							$scope.mappedsearchCriteriaValue = null;
							$scope.searchMappedRequest.searchIndicator = "TARGET_INDICATOR";
							switch (criteria) {
								case 'CIC':
									$scope.searchMappedRequest.searchCriteria = "CIC_VAL";
									break;
								case 'Item Description':
									$scope.searchMappedRequest.searchCriteria = "ITEM_DESC";
									break;
								case 'Display-Y':
									$scope.searchMappedRequest.searchCriteria = "DISP";
									$scope.searchMappedRequest.searchCriteriaValue = "Y";
									$scope.mappedsearchCriteriaValue = "Y";
									break;
								case 'Display-N':
									$scope.searchMappedRequest.searchCriteria = "DISP";
									$scope.searchMappedRequest.searchCriteriaValue = "N";
									$scope.mappedsearchCriteriaValue = "N";
									break;
								case 'WHSE':
									$scope.searchMappedRequest.searchCriteria = "WHSE";
									$scope.searchMappedRequest.searchCriteriaValue = "Y";
									$scope.mappedsearchCriteriaValue = "Y";
									break;
								case 'DSD':
									$scope.searchMappedRequest.searchCriteria = "DSD";
									$scope.searchMappedRequest.searchCriteriaValue = "Y";
									$scope.mappedsearchCriteriaValue = "Y";
									break;
								case 'Select':
									$scope.searchMappedRequest.searchCriteria = null;
									value = null;
									break;
								case 'Usage':
									$scope.searchMappedRequest.searchCriteria = "USAGE_TYPE";
									$scope.searchMappedRequest.searchCriteriaValue = value;
									$scope.mappedsearchCriteriaValue = value;
									break;
								default:
									$scope.searchMappedRequest.searchCriteria = null;
							}

							if ($scope.targetDepartments) {
								angular.forEach($scope.targetDepartments, function (dept) {
									if (dept) {
										if (dept[0] === criteria) {
											$scope.searchMappedRequest.searchCriteria = "DEPT_NAME";
											$scope.searchMappedRequest.searchCriteriaValue = dept[1];
											$scope.mappedsearchCriteriaValue = criteria;
										}

									}
								});
							}

							if ($scope.searchMappedRequest.searchCriteria == "DISP") {
								$scope.selectedMappedSearchCriteria = "Display";
							} else if ($scope.searchMappedRequest.searchCriteria == "DEPT_NAME") {
								$scope.selectedMappedSearchCriteria = "Department";
							} else if ($scope.searchMappedRequest.searchCriteria == "USAGE_TYPE") {
								$scope.selectedMappedSearchCriteria = "Usage Type";
							} else {
								$scope.selectedMappedSearchCriteria = criteria;
							}

						};

						/**
						 * U62615
						 * Method to search based on the dropdown selection and input
						 */
						$scope.searchByDropdown = function (criteria, value) {

							if (criteria != "Department") {
								$scope.searchMappedRequest.searchCriteriaValue = value;
							}

							$scope.setItemType($scope.searchMappedRequest);//setting itemType to default "All" if this is the initial action after load 
							$scope.listResults($scope.searchMappedRequest);
						};


						/**
						 * U62615
						 * Method to disable source search criteria value if select/department/display given
						 */
						$scope.disableSearchCriteriaVal = function (criteria) {
							if (criteria == "Select" || criteria == "Display" || criteria == "WHSE" || criteria == "DSD" || criteria == "Department" || criteria == "Usage Ind") {
								return true;
							} else {
								return false;
							}
						};

						/**
						 * U62615
						 * Method to search based on status selected
						 */
						$scope.filterByStatus = function (status, color) {
							switch (status) {
								case 'Add Map':
									$scope.searchMappedRequest.mappingStatus = "ADD_MAP";
									break;
								case 'Inherit Map':
									$scope.searchMappedRequest.mappingStatus = "INHERIT_MAP";
									break;
								case 'Both':
									$scope.searchMappedRequest.mappingStatus = "BOTH";
									break;
								case 'Converted':
									$scope.searchMappedRequest.mappingStatus = "CONVERTED";
									break;
								case 'Show All':
									$scope.searchMappedRequest.mappingStatus = "SHOW_ALL";
									break;
								default:
									$scope.searchMappedRequest.mappingStatus = "BOTH";
							}
							if (status == "Add Map" || status == "Inherit Map" || status == "Both") {
								$scope.selectedStatus = "Mapped";
							} else {
								$scope.selectedStatus = status;
							}
							$scope.colorSelected = color;
							$scope.setItemType($scope.searchMappedRequest);//setting itemType to default "All" if this is the initial action after load 
							if ($scope.selectedMappedSearchCriteria != "Department") {
								$scope.searchMappedRequest.searchCriteriaValue = $scope.mappedsearchCriteriaValue;
							}
							$scope.listResults($scope.searchMappedRequest);
						};


						/** 
						 * U63178
						 * Function for sorting  
						 *   
						 * */
						function mappedSetSortVal(sortParam) {
							if (sortParam == "source.sourceSKU" || sortParam == "source.vcf" || sortParam == "source.pack") {
								sortParam = sortParam + "/1";
							}
							if (sortParam.charAt(0) === '-') {
								sortParam = sortParam.slice(1);
							} else {
								sortParam = "-" + sortParam;
							}
							return sortParam;
						}

						/**  
						 * U63178
						 * Function to sort Mapped item  list 
						 * 
						 * */
						$scope.sortMappedTable = function (mapsortVal) {
							if ("source.itemDesc" == mapsortVal) {
								$(event.target).toggleClass('glyphicon-sort-by-alphabet').toggleClass('glyphicon-sort-by-alphabet-alt');
							} else {
								$(event.target).toggleClass('glyphicon-sort-by-order').toggleClass('glyphicon-sort-by-order-alt');
							}
							switch (mapsortVal) {
								case 'source.sourceSKU':
									mapsortVal = mappedSetSortVal(sortBySku);
									sortBySku = mapsortVal;
									break;
								case 'source.itemDesc':
									mapsortVal = mappedSetSortVal(SortByItemDesc);
									SortByItemDesc = mapsortVal;
									break;
								case 'source.vcf':
									mapsortVal = mappedSetSortVal(SortByVcf);
									SortByVcf = mapsortVal;
									break;
								case 'source.pack':
									mapsortVal = mappedSetSortVal(SortByPack);
									SortByPack = mapsortVal;
									break;
								case 'source.upc':
									mapsortVal = mappedSetSortVal(SortByUpc);
									SortByUpc = mapsortVal;
									break;
								case 'source.size':
									mapsortVal = mappedSetSortVal(SortBySize);
									SortBySize = mapsortVal;
									break;
								default:
									mapsortVal = sortBySku;
							}
							$scope.mappedSortVal = mapsortVal;
						};

						/**
						 *  U63178
						 *  Method to clear the Mapped criteria value when Mapped search criteria is changed
						 */
						$scope.clearSearchCriteriaValue = function () {
							if ($scope.searchMappedRequest && $scope.searchMappedRequest.searchCriteriaValue) {
								$scope.searchMappedRequest.searchCriteriaValue = "";
								$scope.mappedsearchCriteriaValue = "";
							}
						};

						/**
						 *  U63178
						 *  method to set/unset all results into selectedRequests based on the action on Select All button
						 */
						$scope.setAllRows = function (action, mappedResults) {
							$scope.selectedRequests = [];
							if ($scope.selectedAll == true) {
								angular.forEach(mappedResults, function (unMapReq) {
									if (unMapReq) {
										$scope.selectedRequests.push(unMapReq);
									}
								});

								for (var i = 0; i < mappedResults.length; i++) {
									$("#highlightMappedList_" + i).addClass('rowcolorchange');
									$("#highlightTargetMappedList_" + i).addClass('rowcolorchange');
									$("#mappedchkbox_" + i).prop('checked', true);
								}
							} else {
								for (var j = 0; j < mappedResults.length; j++) {
									$("#highlightMappedList_" + j).removeClass('rowcolorchange');
									$("#highlightTargetMappedList_" + j).removeClass('rowcolorchange');
									$("#mappedchkbox_" + j).prop('checked', false);
								}
								$scope.selectedRequests = [];
							}
						};

						/**
						 *  U63178
						 *  Toggle Selection/De-selection
						 */
						$scope.response = { value: true };
						$scope.toggleResponseValue = function (response) {
							if (response.value) {
								$scope.selectButtonVal = "De-Select All";
								$scope.actionButton = true;
								$scope.selectedAll = true;
								$scope.selectedRow = true;
							} else {
								response.value = false;//Assume it's not clicked if there's no existing value
								$scope.selectedRequests = [];
								$scope.selectButtonVal = "Select All";
								$scope.actionButton = false;
								$scope.selectedAll = false;
								$scope.selectedRow = false;
							}
							$scope.selectAll = !$scope.selectAll;
							response.value = !response.value;
							$scope.actionButton = !response.value;
							$scope.selectButtonVal = !response.value ? "De-Select All" : "Select All";
						};

						/**
						 *  U63178
						 *  Button State
						 */
						$scope.buttonState = function (response) {
							if (response) {
								if (response.value == true) {
									return ['checked'];
								}
							}
						};

						/**
						 * 	U63178
						 *  Function to highlight the entire row
						 */
						$scope.selectEntireRow = function (id, mappeditem) {
							if ($("#mappedchkbox_" + id).is(':checked')) {
								$("#highlightMappedList_" + id).removeClass('rowcolorchange');
								$("#highlightTargetMappedList_" + id).removeClass('rowcolorchange');
								$("#mappedchkbox_" + id).prop('checked', false);
								$scope.setSelectedData(mappeditem, false);
							}
							else {
								$("#highlightMappedList_" + id).addClass('rowcolorchange');
								$("#highlightTargetMappedList_" + id).addClass('rowcolorchange');
								$("#mappedchkbox_" + id).prop('checked', true);
								$scope.setSelectedData(mappeditem, true);
							}
						};

						/**
						 * 	U63178
						 *  Function to make the checkbox selected on highlight
						 */
						$scope.setChkbox = function (id) {
							if ($("#mappedchkbox_" + id).is(':checked')) {
								$("#mappedchkbox_" + id).prop('checked', false);
							}
							else {
								$("#mappedchkbox_" + id).prop('checked', true);
							}
						};

						/**
						 * U62615
						 * open action for UPC drop down at source
						 */
						$scope.openUPC = function (index) {
							$("#openMapped_" + index).show();
						};

						/**
						 * U62615
						 * close action for UPC drop down at source
						 */
						$scope.closeUPC = function (index) {
							$("#openMapped_" + index).hide();
						};

						/**
						 *  U62615
						 *  method to get the selected rows for unmap action
						 */
						$scope.setSelectedData = function (data, selectedData) {
							if (selectedData === true) {
								$scope.selectedRequests.push(data);
							} else {
								for (var j = 0; j < $scope.selectedRequests.length; j++) {
									if (data && data.source && $scope.selectedRequests[j] && $scope.selectedRequests[j].source) {
										if (data.source.sourceSKU === $scope.selectedRequests[j].source.sourceSKU) {
											$scope.selectedRequests.splice(j, 1);
										}
									}
								}
							}
							if ($scope.selectedRequests && $scope.selectedRequests.length > 0) {
								$scope.actionButton = true;
							} else {
								$scope.selectButtonVal = "Select All";
								$scope.actionButton = false;
							}
						};

						/**
						 *  U62615
						 * method to get unchecked upcs of an sku 
						 */
						$scope.checkUPC = function (mappeditem, upc, checkedUPC) {
							$scope.upcClicked = true;
							if (upc && checkedUPC === true) {
								if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
									for (var j = 0; j < $scope.unselectedMapRequests.length; j++) {
										if (upc && $scope.unselectedMapRequests[j]) {
											if (upc === $scope.unselectedMapRequests[j].upc) {
												$scope.unselectedMapRequests.splice(j, 1);
											}
										}
									}
								}
							} else if (upc && checkedUPC === false) {
								$scope.unselectedMapReq = {};
								$scope.unselectedMapReq.sku = mappeditem.source.sourceSKU;
								$scope.unselectedMapReq.upc = upc;
								$scope.unselectedMapRequests.push($scope.unselectedMapReq);
							}
						};

						/**
						 * U62615
						 * common method for creating unmapping requests for each sku, when sku alone selected
						 */
						$scope.createBaseMappingRequests = function (selectedItems) {
							$scope.buyerItem = false;
							$scope.sellerItem = false;
							$scope.unMappingRequests = [];
							$scope.buyerSellerValidationRequests = [];
							angular.forEach(selectedItems, function (unMapReq) {
								if (unMapReq && unMapReq.source && unMapReq.target) {
									if (unMapReq.source.upcList && unMapReq.source.upcList.length > 0) {
										angular.forEach(unMapReq.source.upcList, function (upc) {
											if (upc) {
												$scope.unMappingRequest = {};
												$scope.unMappingRequest.companyID = service.selectedCompany.companyID;
												$scope.unMappingRequest.divisionID = service.selectedDivision.divisionID;
												$scope.unMappingRequest.upc = upc;
												$scope.unMappingRequest.sku = unMapReq.source.sourceSKU;
												$scope.unMappingRequest.cic = unMapReq.target.targetCIC;
												$scope.unMappingRequest.mappingType = unMapReq.mappingType;

												if (unMapReq.mappedItemIndicator == "B" || unMapReq.mappedItemIndicator == "S") {
													if (unMapReq.mappedItemIndicator == "B") {
														$scope.buyerItem = true;
													} else if (unMapReq.mappedItemIndicator == "S") {
														$scope.sellerItem = true;
													}
												}
												$scope.unMappingRequests.push($scope.unMappingRequest);
											}
										});
									}
								}
							});
						};

						/**
						 * U62615
						 * common method for seperating unmapping requests based based on upc check
						 */
						$scope.createSubMappingRequests = function (unselectedRequests, allUnMappingRequests) {
							$scope.unMappingRequests = [];
							$scope.unMappingRequests = allUnMappingRequests;
							if (unselectedRequests && unselectedRequests.length > 0) {
								for (var j = 0; j < unselectedRequests.length; j++) {
									for (var i = 0; i < $scope.unMappingRequests.length; i++) {
										if ($scope.unMappingRequests[i] && unselectedRequests[j]) {
											if ($scope.unMappingRequests[i].sku === unselectedRequests[j].sku && $scope.unMappingRequests[i].upc === unselectedRequests[j].upc) {
												$scope.unMappingRequests.splice(i, 1);

											}
										}
									}
								}
							}
						};

						/**
						 * U62615
						 * Un Map Functionality
						 */
						$scope.unMapAction = function () {
							if ($scope.selectedRequests && $scope.selectedRequests.length > 0) {
								$scope.unMappingRequests = [];
								$scope.createBaseMappingRequests($scope.selectedRequests);
								if ($scope.unMappingRequests && $scope.unMappingRequests.length > 0 && !$scope.upcClicked) {
									$scope.validationFuncBuyerOrSeller($scope.unMappingRequests);
								}
								if ($scope.upcClicked && $scope.unselectedMapRequests) {
									$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.unMappingRequests);
									$scope.validationFuncBuyerOrSeller($scope.unMappingRequests);
								}
							} else {
								alertify.alert("Please select any row to proceed.");
								return;
							}
						};

						/**
						 * U62615
						 * Validating and throwing prompt on clicking either seller/buyer item in mapped
						 */
						$scope.validationFuncBuyerOrSeller = function (requests) {

							if (($scope.buyerItem == true && $scope.sellerItem == true) || ($scope.buyerItem == false && $scope.sellerItem == false)) {
								$scope.action($scope.unMappingRequests);
							} else if ($scope.buyerItem == true || $scope.sellerItem == true) {
								var msg = "";
								if ($scope.buyerItem == true) {
									msg = "The associated seller item will also be unmapped.";
								} else if ($scope.sellerItem == true) {
									msg = "The associated buyer item will also be unmapped.";
								}
								alertify.confirm(msg, function (e) {
									if (e) {
										$scope.action($scope.unMappingRequests);
									}
								});
							}
						};

						/**
						 * U62615
						 * common method for all actions 
						 */
						$scope.action = function (mappingRequests) {

							var actionResults = $scope.baseUrl + "perishable/actions";
							$scope.wrapperRequest = {};
							$scope.wrapperRequest.mappedSearchRequest = {};
							$scope.wrapperRequest.mappedSearchRequest = $scope.searchMappedRequest;
							$scope.wrapperRequest.mappingrequest = [];
							$scope.wrapperRequest.mappingrequest = mappingRequests;
							$scope.wrapperRequest.fromMappedScreen = true;
							$http.post(actionResults, $scope.wrapperRequest, config)
								.then(function (response) {
									//function handles success condition
									if (response && response.data && response.data.mappedSearchRequest) {
										$scope.mappedResults = response.data.mappedSearchRequest.mappedResultWrapper;
										if ((!$scope.mappedResults) || ($scope.mappedResults && $scope.mappedResults.length < 1)) {
											$scope.displayNoResultAlert = true;
										} else {
											$scope.displayNoResultAlert = false;
										}
										if ($scope.mappedResults && $scope.mappedResults.length > 0) {
											if ($scope.mappedResults instanceof Object) {
												var mappedCount = $scope.mappedResults.length;
												$scope.displayMappedAlert = false;
												for (var i = 0; i < mappedCount; i++) {
													$scope.mappedResults[i].expBtnClass = "bgGreen";
													if ($scope.mappedResults[i].mappedStatus == 'CONVERTED') {
														$scope.mappedResults[i].expBtnClass = "bgBlue";
													}
													if ($scope.mappedResults[i].mappedStatus == 'SHOW_ALL') {
														$scope.mappedResults[i].expBtnClass = "bgYellow";
													}
													if ($scope.mappedResults[i].mappedStatus == 'MAPPED') {
														$scope.mappedResults[i].expBtnClass = "bgGreen";
													}
												}
											}
										}
									}
									$scope.selectedRequests = [];
									$scope.unselectedMapRequests = [];
									$scope.unMappingRequests = [];
									$scope.upcClicked = false;
									$scope.returnLists = [];
									$scope.actionButton = false;
									alertify.alert("The conversion has been processed successfully.");
									return;
								}, function (response1) {
									//function handles error condition
									alertify.alert("There was an issue during the conversion.");
									return;
								});
						};
					});
				});
				/**
				 *  U63180
				 *  Function to toggle all sub menu when a dropdown item is selected.
				 */

				// -----------------------------------------------DISCARDED FUNCTION REMOVED FROM HTML -------------------------------------
				$scope.filterSubmenuToggle = function (key) {
					if (key) {
						switch (key) {
							case 'mappedDropdown':
								{
									// $("#srcFilterForSource").hide();
									// $("#srcFilterForTarget").hide();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mappedFilterby").hide();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").hide();
									break;
								}
							case 'srcfilterSourceAction':
								{
									// $("#srcFilterForSource").show();
									// $("#srcFilterForTarget").hide();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").hide();

									break;
								}
							case 'srcfilterTargetAction':
								{
									// $("#srcFilterForTarget").show();
									// $("#srcFilterForSource").hide();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").hide();
									break;
								}
							case 'srcfilterDepClckAction':
								{
									// $("#srcFilterForSource").show();
									// $("#srcFilterForTarget").hide();
									// $("#mpdsrcFilterByDep").show();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").hide();
									break;
								}
							case 'tgtfilterDepClckAction':
								{
									// $("#srcFilterForSource").hide();
									// $("#srcFilterForTarget").show();
									// $("#mpdtgtFilterByDep").show();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").hide();
									break;
								}
							case 'srcfilterUsageTypeAction':
								{

									// $("#srcFilterForSource").show();
									// $("#srcFilterForTarget").hide();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdsrcFilterByUsage").show();
									// $("#mpdtgtFilterByUsage").hide();
									break;
								}
							case 'tgtfilterUsageTypeAction':
								{

									$scope.srcFilterForSource = false;
									$scope.mpdtgtFilterByDep = false;
									$scope.mpdsrcFilterByDep = false;
									$scope.srcFilterForTarget = true;
									$scope.mpdtgtFilterByUsage = true;
									// $("#srcFilterForSource").hide();
									// $("#srcFilterForTarget").show();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").show();
									break;
								}
							case 'mappedSubmenu':
								{
									// $("#srcFilterForSource").hide();
									// $("#srcFilterForTarget").hide();
									// $("#mpdsrcFilterByDep").hide();
									// $("#mpdtgtFilterByDep").hide();
									// $("#mappedFilterby").show();
									// $("#mpdsrcFilterByUsage").hide();
									// $("#mpdtgtFilterByUsage").hide();
									break;
								}
							default:
								break;
						}
					}
				};

			}


		}]);

})();