(function () {
	'use strict';

	myApp.controller('BakeryController', ['$scope', '$http', '$location', '$document', 'blockUI', 'service', 'AugmentedDisplayerService', 'OverrideMappingService', '$timeout',
		function BakeryController($scope, $http, $location, $document, blockUI, service, AugmentedDisplayerService, OverrideMappingService, $timeout) {

			$scope.displayBakerypage = false;
			$scope.displayBuyingAlert = true;
			$scope.displaySellingAlert = true;
			$scope.displaySourceAlert = true;
			$scope.displayNoResultBakeryAlert = false;
			$scope.displayNoResultBuyingAlert = false;
			$scope.displayNoResultSellingAlert = false;
			$scope.postBakFilterVal = {};
			$scope.postSellingFilterVal = {};
			$scope.postBuyingFilterVal = {};
			$scope.bakeryFilterApplied = false;
			$scope.sellingFilterApplied = false;
			$scope.buyingFilterApplied = false;
			$scope.searchBakeryRequest = {};
			$scope.markedSKUs = [];
			$scope.markedBuyingCICs = [];
			$scope.markedSellingCICs = [];

			//Variables for sorting Bakery.
			var bakerySortBySku = 'sku/1';
			var bakerySortByItemDesc = '-itemDesc';
			var bakerySortByVcf = '-vcf';
			var bakerySortByUpc = '-upc';

			//Variables for sorting Buying.
			var buyingSortByCic = 'cic/1';
			var buyingSortByItemDesc = '-itemDesc';
			var buyingSortByVcf = '-vcf';
			var buyingSortByUpc = '-upc';

			//Variables for sorting Selling.
			var sellingSortByCic = 'cic/1';
			var sellingSortByItemDesc = '-itemDesc';
			var sellingSortByVcf = '-vcf';
			var sellingSortByUpc = '-upc';
			var systemArray = [];



			$scope.init = function () {
				$('[data-toggle="expandedView"]').tooltip();
				//Set default 'sort by' value for CIC and SKU list	
				$scope.bakerySortVal = bakerySortBySku;
				$scope.buyingSortVal = buyingSortByCic;
				$scope.sellingSortVal = sellingSortByCic;

				var windowHeight = $(window).innerHeight();
				var cicHeight = (windowHeight - 340) / 2;
				$('.bakeryScrollDiv').css('height', windowHeight - 225);
				$('.buyingScrollDiv').css('height', cicHeight);
				$('.sellingScrollDiv').css('height', cicHeight);

				//CONTEXT-MENU restrict right click
				$(function () {
					$.contextMenu({
						selector: '.context-menu-baksource',
						callback: function (key, options) {
							$scope.redirectToFunction(key);
						},
						items: {
							"forcenew": {
								name: "Force New",
								icon: null
							},
							"letautomatch": {
								name: "Let Auto Match",
								icon: null
							},
							"markasdead": {
								name: "Mark as Dead",
								icon: null
							},
							"matchingtarget": {
								name: "Suggested CIC",
								icon: null
							},
							"reserve": {
								name: "Reserve",
								icon: null
							}
						}
					});

					$.contextMenu({
						selector: '.context-menu-baktarget',
						callback: function (key, options) {
							$scope.redirectToFunction(key);
						},
						items: {
							"inheritmap": {
								name: "Inherit Map",
								icon: null
							},
							"addmap": {
								name: "Add Map",
								icon: null,
								disabled: function (key, opt) {
									// this references the trigger element
								}
							}
						}
					});

				});
				//CONTEXT-MENU restrict right click - END

				$scope.$watch('selectedCompany', function (value) {
					if (value) {
						if (value.companyID) {
							if ((value.companyID != service.selectedCompany.companyID) ||
								($scope.companyID && $scope.companyID != service.selectedCompany.companyID)) {
								service.bakerySourceSearch = null;
							}
							$scope.companyID = service.selectedCompany.companyID;
						} else {
							$scope.companyID = null;
						}
						$scope.displayBakerypage = false;
						$scope.displayBuyingAlert = false;
						$scope.displaySourceAlert = false;
						$scope.displaySellingAlert = false;


					}
				});
				$scope.$watch('selectedDivision', function (value) {
					if (value && value.divisionID) {
						if ((value.divisionID != service.selectedDivision.divisionID) ||
							($scope.divisionID && $scope.divisionID != service.selectedDivision.divisionID)) {
							service.bakerySourceSearch = null;
						}
						$scope.searchBakeryRequest = {};
						$scope.searchBuyingRequest = {};
						$scope.searchSellingRequest = {};
						$scope.searchBakeryRequest.companyID = $scope.companyID;
						$scope.searchBuyingRequest.companyID = $scope.companyID;
						$scope.searchSellingRequest.companyID = $scope.companyID;
						if (service.selectedDivision.divisionID) {
							$scope.searchBakeryRequest.divisionID = service.selectedDivision.divisionID;
							$scope.searchBuyingRequest.divisionID = service.selectedDivision.divisionID;
							$scope.searchSellingRequest.divisionID = service.selectedDivision.divisionID;
						} else {
							$scope.searchBakeryRequest.divisionID = null;
							$scope.searchBuyingRequest.divisionID = null;
							$scope.searchSellingRequest.divisionID = null;
						}
						$scope.displayBakerypage = true;
						$scope.displayBuyingAlert = true;
						$scope.displaySellingAlert = true;
						$scope.displaySourceAlert = true;
						$scope.displayNoResultBakeryAlert = false;
						$scope.displayNoResultBuyingAlert = false;
						$scope.displayNoResultSellingAlert = false;
						$scope.validateBakAddMapFunc = false;
						$scope.bakeryFilterAppliedAfterPageDirect = false;

						$scope.upcClicked = false;
						$scope.bakeryResults = [];
						$scope.buyingResults = [];
						$scope.sellingResults = [];
						$scope.markedSKUs = [];
						$scope.markedBkPLUs = [];
						$scope.markedBuyingCICs = [];
						$scope.markedSellingCICs = [];
						$scope.disableBuyChkBox = false;
						$scope.disableSellChkBox = false;
						$scope.selectedMPD = [];
						$scope.unselectedBakeryRequests = [];
						$scope.selectedBakeryRequests = [];
						$scope.selectedMapRequests = [];
						$scope.unselectedMapRequests = [];

						$scope.finalRequests = [];
						$scope.buyingMappingRequests = [];
						$scope.sellingMappingRequests = [];
						$scope.bakeryRequests = [];
						$scope.bakeryDepartmentName = 'Bakery';
						$scope.returnLists = [];
						$scope.sourceBakCount = 0;
						$scope.sourceBakShowCount = 0;
						$scope.targetBuyCount = 0;
						$scope.targetBuyShowCount = 0;
						$scope.targetSellCount = 0;
						$scope.targetSellShowCount = 0;
						$scope.isBakeryFilterApplied = "filterUnapplied";
						$scope.isBuyingFilterApplied = "filterUnapplied";
						$scope.isSellingFilterApplied = "filterUnapplied";
						$scope.selectedBakerySearchCriteria = "Select";
						$scope.selectedBuyingSearchCriteria = "Select";
						$scope.selectedSellingSearchCriteria = "Select";
						$scope.selectedBakerySearchCriteriaValue = null;
						$scope.selectedBuyingSearchCriteriaValue = null;
						$scope.selectedSellingSearchCriteriaValue = null;

						if ($scope.displayBakerypage == true) {
							$scope.searchBuyingRequest = initSearchData($scope.searchBuyingRequest, 'B');
							$scope.searchBuyingRequest.targetTypeIndicator = 'B';

							$scope.searchSellingRequest = initSearchData($scope.searchSellingRequest, 'S');
							$scope.searchSellingRequest.targetTypeIndicator = 'S';

							$scope.searchBakeryRequest = initSearchData($scope.searchBakeryRequest, 'BAKERY');

							$scope.searchBakeryRequest.filter = {};
							$scope.searchBuyingRequest.filter = {};
							$scope.searchSellingRequest.filter = {};
							$scope.selectedBakeryStatus = "To be Mapped";
							$scope.colorSelectedBakery = "bgBlue";
							$scope.selectedBuyingStatus = "Show All";
							$scope.colorSelectedBuying = "bgYellow";
							$scope.selectedSellingStatus = "Show All";
							$scope.colorSelectedSelling = "bgYellow";
							$scope.bakeryitemtype = "All";
						}

						/**
						 * U62615
						 * getting data like status/search criterias from bakery.properties file and setting into variables
						 */
						$http.get('perishables/json/bakery-properties.json').then(function (response) {
							if (response && response.data) {
								$scope.sourceStatuses = response.data[0].sourceStatuses; //Filter by status values for source
								$scope.sourceColors = response.data[0].sourceColors; //Filter by status colors for source
								$scope.buyingSellingStatuses = response.data[0].buyingSellingStatuses; //Filter by status values for buying/selling
								$scope.buyingSellingColors = response.data[0].buyingSellingColors; //Filter by status colors for buying/selling
								$scope.searchSourceCriterias = response.data[0].searchSourceCriterias; //search criterias for source
								$scope.buyingSellingSearchCriterias = response.data[0].buyingSellingSearchCriterias; //search criterias for buying/selling

							}
						});

					} else {
						$scope.displayBakerypage = false;
						$scope.displayBuyingAlert = false;
						$scope.displaySourceAlert = false;
						$scope.displaySellingAlert = false;
					}

					if (service.bakerySourceSearch != null) {
						$scope.searchBakeryRequest = {};
						$scope.searchBakeryRequest.filter = {};
						$scope.searchBakeryRequest = angular.copy(service.bakerySourceSearch);
						if (service.bakerySourceSearch.mappingStatus === "RESERVED") {
							$scope.selectedBakeryStatus = "Reserved";
							$scope.colorSelectedBakery = "bgLimeBlue";
						}
						$scope.bakeryFilterAppliedAfterPageDirect = true;
						$timeout(function () {
							$scope.listBakery($scope.searchBakeryRequest);
						}, 3000);
					}
				});

				// filter for bakery	
				$("#filterBakerySectionExpand").hide();
				$("#filterBakeryBy").click(function () {
					$("#filterBakerySectionExpand").show();
				});

				// filter for buying
				$("#filterBuyingSectionExpand").hide();
				$("#filterBuyingBy").click(function () {
					$("#filterBuyingSectionExpand").show();
				});

				// filter for selling	
				$("#filterSellingSectionExpand").hide();
				$("#filterSellingBy").click(function () {
					$("#filterSellingSectionExpand").show();
				});

				$('.dropdown-submenu a.bakeryTest').on("click", function (e) {
					$(this).next('ul').toggle();
					e.stopPropagation();
					e.preventDefault();
				});

			};
			// init ends here
			/** 
			 * U63180
			 * Function to initialize search data.  
			 *   
			**/
			function initSearchData(searchData, from) {
				if (from == 'BAKERY') {
					searchData.mappingStatus = 'TO_BE_MAPPED';
				} else {
					searchData.mappingStatus = 'SHOW_ALL';
				}
				searchData.filterAvail = false;
				searchData.filter = {};
				return searchData;
			}
			
			
			if (service.baseUrlFunction() != undefined) {
				service.baseUrlFunction().then(function (url) {
					$scope.baseUrl = url;

					service.getHeaders().then(function (header) {
						var config = header
						//  });

						/**
						 *  Load the Bakery data according to search request
						 */
						$scope.listBakery = function (searchRequest) {

							var listBakeryResults = $scope.baseUrl + "mapping/bakerySourceList";
							if (searchRequest.filterAvail == false) {
								$scope.clearBakeryFilter();
							}
							$http.post(listBakeryResults, searchRequest, config)
								.then(function (response1) {
									//function handles success condition
									if (response1.data) {
										$scope.bakeryResults = response1.data.bakerySkuSearchResults;
										if ((!$scope.bakeryResults) || ($scope.bakeryResults && $scope.bakeryResults.length < 1)) {
											$scope.displayNoResultBakeryAlert = true;
										} else {
											$scope.displayNoResultBakeryAlert = false;
										}
										$scope.trimPLUFunc($scope.bakeryResults);
										if (response1.data.sourceCount && response1.data.bakerySkuSearchResults) {
											$scope.sourceBakCount = response1.data.sourceCount;
											$scope.sourceBakShowCount = response1.data.bakerySkuSearchResults.length;

											if ($scope.sourceBakCount <= $scope.sourceBakShowCount) {
												$scope.sourceBakCount = $scope.sourceBakShowCount;
											}
										} else {
											$scope.sourceBakCount = 0;
											$scope.sourceBakShowCount = 0;
										}
									}
									$scope.validateBakAddMapFunc = false;
									$scope.unselectedBakeryRequests = [];
									$scope.selectedMapRequests = [];
									$scope.selectedBakeryRequests = [];
									$scope.returnLists = [];
									$scope.setResultRowColors($scope.bakeryResults, "source");
									$scope.closeBakeryFilter();
								}, function (response1) {
									//function handles error condition
								});

							$scope.disableBuyChkBox = false;
							$scope.disableSellChkBox = false;

						};

						/**
						 * U62615
						 * function to set the trimmed plu num in the upc column 
						 */
						$scope.trimPLUFunc = function (results) {
							if (results && results.length > 0) {
								angular.forEach(results, function (sku) {
									if (sku && sku.absUPCNo) {
										if (sku.absUPCNo < 99999) {
											var s = sku.absUPCNo;
											while (s.charAt(0) === '0') {
												s = s.substr(1);
											}
											sku.absUPCNo = s;
										}
									}
								});
							}
						};

						/**
						 * U62615
						 * to restrict service call of upc badge if once loaded
						 */
						$scope.showUPCs = function (skuDetails) {
							var skuClicked = skuDetails.sku;
							$scope.enteredEqual = false;
							if ($scope.searchBakeryRequest.itemType) {
								if ($scope.searchBakeryRequest.itemType.all == true) {
									$scope.itemTypeSelected = "ALL";
								} else if ($scope.searchBakeryRequest.itemType.system2 == true) {
									$scope.itemTypeSelected = "System2";
								} else if ($scope.searchBakeryRequest.itemType.system4 == true) {
									$scope.itemTypeSelected = "System4";
								} else if ($scope.searchBakeryRequest.itemType.plu == true) {
									$scope.itemTypeSelected = "PLU";
								}
							}
							$scope.detailsPassing = [];
							$scope.detailsPassing.push($scope.searchBakeryRequest.companyID);
							$scope.detailsPassing.push($scope.searchBakeryRequest.divisionID);
							$scope.detailsPassing.push(skuClicked);
							$scope.detailsPassing.push(skuDetails.mappingStatus);
							$scope.detailsPassing.push($scope.itemTypeSelected);

							if ($scope.returnLists && $scope.returnLists.length > 0) {
								for (var i = 0; i < $scope.returnLists.length; i++) {
									if ($scope.returnLists[i].sku == skuClicked && $scope.returnLists[i].upcList && $scope.returnLists[i].upcList.length > 0) {
										$scope.skuOpted.upcSalesDetails = [];
										$scope.skuOpted.upcSalesDetails = $scope.returnLists[i].upcList;
										$scope.enteredEqual = true;
										break;
									}
								}
								if (!$scope.enteredEqual) {
									$scope.upcLoadFunction(skuClicked);
								}
							} else if ($scope.returnLists && $scope.returnLists.length == 0) {
								$scope.upcLoadFunction(skuClicked);
							}
						};

						$scope.upcLoadFunction = function (skuClicked) {
							$scope.skuOpted = {};
							$scope.skuOpted.upcSalesDetails = [];

							var listResults = $scope.baseUrl + "perishable/upcList";

							$http.post(listResults, $scope.detailsPassing, config)
								.then(function (response) {
									//function handles success condition
									if (response.data) {
										$scope.skuOpted.upcSalesDetails = response.data;

										$scope.returnList = {};
										$scope.returnList.sku = "";
										$scope.returnList.upcList = [];
										$scope.returnList.sku = skuClicked;
										$scope.returnList.upcList = $scope.skuOpted.upcSalesDetails;
										$scope.returnLists.push($scope.returnList);

									}
								}, function (response1) {
									//function handles error condition
								});
						};



						/**
						 * U62615
						 * Common method to set itemType to default "All" in target side if no itemType selected after load
						 */
						$scope.setItemType = function (request) {
							if (!request.itemType) {
								request.itemType = {};
								request.itemType.all = true;
								request.itemType.system2 = false;
								request.itemType.system4 = false;
								request.itemType.plu = false;
							}
						};

						/**
						 *  U63180 
						 *  Load the Bakery data - buying data according to search request.
						 */
						$scope.listBakeryBuyingData = function (searchRequest) {

							searchRequest.targetTypeIndicator = 'B';
							var listBakeryResults = $scope.baseUrl + "mapping/bakeryTargetList";
							if (searchRequest.filterAvail == false) {
								$scope.clearBuyingFilter();
							}
							$http.post(listBakeryResults, searchRequest, config)
								.then(function (response1) {
									//function handles success condition
									if (response1.data) {
										$scope.buyingResults = response1.data.bakeryCicSearchResults;
										if ((!$scope.buyingResults) || ($scope.buyingResults && $scope.buyingResults.length < 1)) {
											$scope.displayNoResultBuyingAlert = true;
										} else {
											$scope.displayNoResultBuyingAlert = false;
										}
										if (response1.data.targetCount && response1.data.bakeryCicSearchResults) {
											$scope.targetBuyCount = response1.data.targetCount;
											$scope.targetBuyShowCount = response1.data.bakeryCicSearchResults.length;

											if ($scope.targetBuyCount <= $scope.targetBuyShowCount) {
												$scope.targetBuyCount = $scope.targetBuyShowCount;
											}
										} else {
											$scope.targetBuyCount = 0;
											$scope.targetBuyShowCount = 0;
										}
									}
									$scope.unselectedBakeryRequests = [];
									$scope.selectedBakeryRequests = [];
									$scope.setResultRowColors($scope.buyingResults, "buying");
									$scope.closeBuyingFilter();
									//$scope.setTargetChkBoxAction();
								}, function (response1) {
									//function handles error condition
								});
						};

						/**
						 *  U63180 
						 *  Load the Bakery data - selling data according to search request.
						 */
						$scope.listBakerySellingData = function (searchRequest) {

							searchRequest.targetTypeIndicator = 'S';
							var listBakeryResults = $scope.baseUrl + "mapping/bakeryTargetList";
							if (searchRequest.filterAvail == false) {
								$scope.clearSellingFilter();
							}
							$http.post(listBakeryResults, searchRequest, config)
								.then(function (response1) {
									//function handles success condition
									if (response1.data) {
										$scope.sellingResults = response1.data.bakeryCicSearchResults;
										if ((!$scope.sellingResults) || ($scope.sellingResults && $scope.sellingResults.length < 1)) {
											$scope.displayNoResultSellingAlert = true;
										} else {
											$scope.displayNoResultSellingAlert = false;
										}
										if (response1.data.targetCount && response1.data.bakeryCicSearchResults) {
											$scope.targetSellCount = response1.data.targetCount;
											$scope.targetSellShowCount = response1.data.bakeryCicSearchResults.length;

											if ($scope.targetSellCount <= $scope.targetSellShowCount) {
												$scope.targetSellCount = $scope.targetSellShowCount;
											}
										} else {
											$scope.targetSellCount = 0;
											$scope.targetSellShowCount = 0;
										}
									}
									$scope.unselectedBakeryRequests = [];
									$scope.selectedBakeryRequests = [];
									$scope.setResultRowColors($scope.sellingResults, "selling");
									$scope.closeSellingFilter();
									//$scope.setTargetChkBoxAction();
								}, function (response1) {
									//function handles error condition
								});
						};



						/**
						 * U62615
						 * function to list matched CIC based on selected SKU UPC's
						 */
						$scope.bakeryMatchingTargetListing = function () {
							$scope.matchingTargetInputRequest = {};
							if ($scope.markedSKUs && $scope.markedSKUs.length > 1) {
								alertify.alert("More than one SKUs has been selected.");
								return;
							} else if (!$scope.markedSKUs || $scope.markedSKUs.length < 1) {
								alertify.alert("Select any items from SKU.");
								return;
							} else if ($scope.markedBuyingCICs && $scope.markedBuyingCICs.length > 0) {
								alertify.alert("Unselect Buying CIC and proceed.");
								return;
							} else if ($scope.markedSellingCICs && $scope.markedSellingCICs.length > 0) {
								alertify.alert("Unselect Selling CIC and proceed.");
								return;
							} else {
								if ($scope.markedSKUs) {
									angular.forEach($scope.markedSKUs, function (sku) {
										$scope.matchingTargetInputRequest.upcs = sku.upc;
										if (sku.absDSDWhse == "WHSE") {
											$scope.matchingTargetInputRequest.whseDsd = "W";
										} else if (sku.absDSDWhse == "DSD") {
											$scope.matchingTargetInputRequest.whseDsd = "D";
										}
										$scope.matchingTargetInputRequest.dept = sku.deptName;
									});


									var listMatchingTargetResults = $scope.baseUrl + "mapping/matchingBakeryTargetList";

									$http.post(listMatchingTargetResults, $scope.matchingTargetInputRequest, config)
										.then(function (response) {
											//function handles success condition
											if (response.data) {
												$scope.sellingResults = response.data.bakeryCicSearchResults;
												$scope.buyingResults = response.data.bakeryCicSearchResults;
												if ((!$scope.sellingResults) || ($scope.sellingResults && $scope.sellingResults.length < 1)) {
													$scope.displayNoResultSellingAlert = true;
												} else {
													$scope.displayNoResultSellingAlert = false;
												}
												if ((!$scope.buyingResults) || ($scope.buyingResults && $scope.buyingResults.length < 1)) {
													$scope.displayNoResultBuyingAlert = true;
												} else {
													$scope.displayNoResultBuyingAlert = false;
												}
												if (response.data.bakeryCicSearchResults) {
													$scope.targetSellCount = response.data.bakeryCicSearchResults.length;
													$scope.targetSellShowCount = response.data.bakeryCicSearchResults.length;
													$scope.targetBuyCount = response.data.bakeryCicSearchResults.length;
													$scope.targetBuyShowCount = response.data.bakeryCicSearchResults.length;
												} else {
													$scope.targetSellCount = 0;
													$scope.targetSellShowCount = 0;
													$scope.targetBuyCount = 0;
													$scope.targetBuyShowCount = 0;
												}
												$scope.buyingSortVal = null;
												$scope.sellingSortVal = null;
											}
											$scope.unselectedBakeryRequests = [];
											$scope.selectedBakeryRequests = [];
											$scope.setResultRowColors($scope.buyingResults, "buying");
											$scope.closeBuyingFilter();
											$scope.setResultRowColors($scope.sellingResults, "selling");
											$scope.closeSellingFilter();
										}, function (response1) {
											//function handles error condition
										});
								}
							}
						};



						/** 
						 * U63180
						 * Function for set color as per status.  
						 *   
						 **/
						$scope.setResultRowColors = function (results, from) {
							if (results && results.length > 0) {
								if (results instanceof Object) {
									var bakCount = results.length;
									for (var i = 0; i < bakCount; i++) {

										if (from != null && from == "source") {
											results[i].collapseIndex = "targetSkuDetails" + i;
											$scope.displaySourceAlert = false;
										} else if (from != null && from == "buying") {
											results[i].collapseIndex = "targetDetails" + i;
											$scope.displayBuyingAlert = false;
										} else {
											results[i].collapseIndex = "targetDetail" + i;
											$scope.displaySellingAlert = false;
										}

										results[i].expBtnClass = "bgBlack";
										if (results[i].mappingStatus === 'TO_BE_MAPPED') {
											results[i].expBtnClass = "bgBlue";
										}
										if (results[i].mappingStatus === 'MARK_AS_DEAD') {
											results[i].expBtnClass = "bgGrey";
										}
										if (results[i].mappingStatus === 'LET_AUTO_MATCH') {
											results[i].expBtnClass = "bgViolet";
										}
										if (results[i].mappingStatus === 'FORCE_NEW') {
											results[i].expBtnClass = "bgDarkPink";
										}
										if (results[i].mappingStatus === 'SHOW_ALL') {
											results[i].expBtnClass = "bgYellow";
										}
										if (results[i].mappingStatus === 'OTHERS') {
											results[i].expBtnClass = "bgLimeBlue";
										}
										if (results[i].mappingStatus === 'AWAITING_NEW_CIC') {
											results[i].expBtnClass = "bgLimeBlue";
										}
										if (results[i].mappingStatus === 'AWAITING_DIVISION_INPUT') {
											results[i].expBtnClass = "bgLimeBlue";
										}
										if (results[i].mappingStatus === 'RESERVED') {
											results[i].expBtnClass = "bgLimeBlue";
										}
										if (results[i].mappingStatus == 'MAPPED') {
											results[i].expBtnClass = "bgGreen";
										}
										if (results[i].mappingStatus == '') {
											results[i].expBtnClass = "bgBlack";
										}
										if (results[i].mappingStatus == null) {
											results[i].expBtnClass = "bgBlack";
										}
									}
								}
							} else {
								if (from == "source") {
									$scope.displayNoResultBakeryAlert = true;
									$scope.displaySourceAlert = false;
								} else if (from == "buying") {
									$scope.displayNoResultBuyingAlert = true;
									$scope.displayBuyingAlert = false;
								} else if (from == "selling") {
									$scope.displayNoResultSellingAlert = true;
									$scope.displaySellingAlert = false;
								}
							}
						};

						/** 
						 *  Function to set sort value.
						 */
						function setSortVal(sortParam) {
							if (sortParam == "sku" || sortParam == "cic" || sortParam == "vcf" || sortParam == "pack") {
								sortParam = sortParam + "/1";
							}
							if (sortParam.charAt(0) === '-') {
								sortParam = sortParam.slice(1);
							} else {
								sortParam = "-" + sortParam;
							}

							return sortParam;
						}


						/**  
						 * function to sort Bakery item  list 
						 * 
						 * */
						$scope.sortBakeryTable = function (sortVal) {
							if ("itemDesc" == sortVal) {
								$(event.target).toggleClass('glyphicon-sort-by-alphabet').toggleClass('glyphicon-sort-by-alphabet-alt');
							} else {
								$(event.target).toggleClass('glyphicon-sort-by-order').toggleClass('glyphicon-sort-by-order-alt');
							}

							switch (sortVal) {
								case 'sku':
									sortVal = setSortVal(bakerySortBySku);
									bakerySortBySku = sortVal;
									break;
								case 'itemDesc':
									sortVal = setSortVal(bakerySortByItemDesc);
									bakerySortByItemDesc = sortVal;
									break;
								case 'vcf':
									sortVal = setSortVal(bakerySortByVcf);
									bakerySortByVcf = sortVal;
									break;
								case 'upc':
									sortVal = setSortVal(bakerySortByUpc);
									bakerySortByUpc = sortVal;
									break;
								default:
									sortVal = bakerySortBySku;
							}

							$scope.bakerySortVal = sortVal;
						};


						/**  
						 * function to sort Buying item  list 
						 * 
						 * */
						$scope.sortBuyingTable = function (sortVal) {
							if ("itemDesc" == sortVal) {
								$(event.target).toggleClass('glyphicon-sort-by-alphabet').toggleClass('glyphicon-sort-by-alphabet-alt');
							} else {
								$(event.target).toggleClass('glyphicon-sort-by-order').toggleClass('glyphicon-sort-by-order-alt');
							}

							switch (sortVal) {
								case 'cic':
									sortVal = setSortVal(buyingSortByCic);
									buyingSortByCic = sortVal;
									break;
								case 'itemDesc':
									sortVal = setSortVal(buyingSortByItemDesc);
									buyingSortByItemDesc = sortVal;
									break;
								case 'vcf':
									sortVal = setSortVal(buyingSortByVcf);
									buyingSortByVcf = sortVal;
									break;
								case 'upc':
									sortVal = setSortVal(buyingSortByUpc);
									buyingSortByUpc = sortVal;
									break;
								default:
									sortVal = buyingSortByCic;
							}

							$scope.buyingSortVal = sortVal;
						};

						/**  
						 * function to sort Selling item  list 
						 * 
						 * */
						$scope.sortSellingTable = function (sortVal) {
							if ("itemDesc" == sortVal) {
								$(event.target).toggleClass('glyphicon-sort-by-alphabet').toggleClass('glyphicon-sort-by-alphabet-alt');
							} else {
								$(event.target).toggleClass('glyphicon-sort-by-order').toggleClass('glyphicon-sort-by-order-alt');
							}

							switch (sortVal) {
								case 'cic':
									sortVal = setSortVal(sellingSortByCic);
									sellingSortByCic = sortVal;
									break;
								case 'itemDesc':
									sortVal = setSortVal(sellingSortByItemDesc);
									sellingSortByItemDesc = sortVal;
									break;
								case 'vcf':
									sortVal = setSortVal(sellingSortByVcf);
									sellingSortByVcf = sortVal;
									break;
								case 'upc':
									sortVal = setSortVal(sellingSortByUpc);
									sellingSortByUpc = sortVal;
									break;
								default:
									sortVal = sellingSortByCic;
							}

							$scope.sellingSortVal = sortVal;
						};

						/**
						 * 
						 * Filter close action of Bakery
						 */
						$scope.closeBakeryFilter = function () {
							if ($scope.bakeryFilterApplied == true) {
								$scope.searchBakeryRequest.filter = angular.copy($scope.postBakFilterVal);
							} else if ($scope.bakeryFilterAppliedAfterPageDirect == true && service.bakerySourceSearch.filter != null) {
								$scope.searchBakeryRequest.filter = angular.copy(service.bakerySourceSearch.filter);
								if (service.bakerySourceSearch.filter.department) {
									$scope.bakeryDepartmentName = angular.copy(service.bakerySourceSearch.filter.department);
								}
								$scope.selectedSourceFilterShipment = angular.copy(service.bakerySourceSearch.filter.shipSearchValue);
								$scope.selectedSourceFilterUsagetype = angular.copy(service.bakerySourceSearch.filter.usageType);
								$scope.selectedSourceFilterTotalsales = angular.copy(service.bakerySourceSearch.filter.totalSalesOperator);

								if (service.bakerySourceSearch.filter.corpItemCD || service.bakerySourceSearch.filter.department || service.bakerySourceSearch.filter.divisionNum || service.bakerySourceSearch.filter.hierarchy ||
									service.bakerySourceSearch.filter.itemNum || service.bakerySourceSearch.filter.itemDescription || service.bakerySourceSearch.filter.productSKU || service.bakerySourceSearch.filter.plu ||
									service.bakerySourceSearch.filter.supplierName || service.bakerySourceSearch.filter.supplierNum || service.bakerySourceSearch.filter.slu || service.bakerySourceSearch.filter.upc ||
									service.bakerySourceSearch.filter.smicGroupCd || service.bakerySourceSearch.filter.smicCtgryCd || service.bakerySourceSearch.filter.smicClassCd ||
									service.bakerySourceSearch.filter.smicSubClassCd || service.bakerySourceSearch.filter.smicSubSubClassCd || service.bakerySourceSearch.filter.prodhierarchyLevel1 ||
									service.bakerySourceSearch.filter.prodhierarchyLevel2 || service.bakerySourceSearch.filter.prodhierarchyLevel3 ||
									service.bakerySourceSearch.filter.smicGroupCd == 0 || service.bakerySourceSearch.filter.smicCtgryCd == 0 || service.bakerySourceSearch.filter.smicClassCd == 0 ||
									service.bakerySourceSearch.filter.smicSubClassCd == 0 || service.bakerySourceSearch.filter.smicSubSubClassCd == 0 || service.bakerySourceSearch.filter.prodhierarchyLevel1 == 0 ||
									service.bakerySourceSearch.filter.prodhierarchyLevel2 == 0 || service.bakerySourceSearch.filter.prodhierarchyLevel3 == 0 ||
									service.bakerySourceSearch.filter.totalSalesFilter || service.bakerySourceSearch.filter.totalSalesOperator || service.bakerySourceSearch.filter.totalSalesvalue ||
									service.bakerySourceSearch.filter.usageFilter || service.bakerySourceSearch.filter.usageType || service.bakerySourceSearch.filter.shipped || service.bakerySourceSearch.filter.shipSearchValue ||
									service.bakerySourceSearch.filter.vendorCode || service.bakerySourceSearch.filter.vendorName) {
									$scope.isBakeryFilterApplied = "filterApplied";
								} else {
									$scope.isBakeryFilterApplied = "filterUnapplied";
									$scope.searchBakeryRequest.filterAvail = false;
									$scope.searchBakeryRequest.filter = {};

								}
							} else {
								$scope.searchBakeryRequest.filter = {};
								$scope.isBakeryFilterApplied = "filterUnapplied";
								$scope.searchBakeryRequest.filterAvail = false;
							}
							$("#actionicons").show();
							$("#filterBakerySectionExpand").hide();
						};

						/**
						 *
						 * Filter close action of Buying
						 */
						$scope.closeBuyingFilter = function () {
							if ($scope.buyingFilterApplied == true) {
								$scope.searchBuyingRequest.filter = angular.copy($scope.postBuyingFilterVal);
							} else {
								$scope.searchBuyingRequest.filter = {};
							}
							$("#actionicons").show();
							$("#filterBuyingSectionExpand").hide();
						};

						/**
						 * Filter close action of Selling
						 */
						$scope.closeSellingFilter = function () {
							if ($scope.sellingFilterApplied == true) {
								$scope.searchSellingRequest.filter = angular.copy($scope.postSellingFilterVal);
							} else {
								$scope.searchSellingRequest.filter = {};
							}
							$("#actionicons").show();
							$("#filterSellingSectionExpand").hide();
						};

						/**
						 * 
						 * Filter close action of Target
						 */
						$scope.clearBakeryFilter = function ($event) {
							$scope.selectedSourceFilterShipment = "";
							$scope.selectedSourceFilterUsagetype = "";
							$scope.selectedSourceFilterTotalsales = "";
							$scope.changeSourceFilterShipment("");
							$scope.changeSourceFilterSales("");
							$scope.changeSourceFilterUsage("");
							document.getElementById("hierarchyfirst").value = null;
							document.getElementById("hierarchysecond").value = null;
							document.getElementById("hierarchythird").value = null;
							$scope.searchBakeryRequest.filterAvail = false;
							$scope.searchBakeryRequest.filter = {};
							$scope.isBakeryFilterApplied = "filterUnapplied";
							$scope.bakeryFilterApplied = false;
						};
						$scope.clearBuyingFilter = function ($event) {
							$scope.searchBuyingRequest.filter = {};
							$scope.selectedBuyingFilterUsageInd = "";
							$scope.selectedBuyingFilterUsagetype = "";
							document.getElementById("b_smic_grp").value = null;
							document.getElementById("b_smic_ctgry").value = null;
							document.getElementById("b_smic_class").value = null;
							document.getElementById("b_smic_sub_class").value = null;
							document.getElementById("b_smic_sub_sb_class").value = null;
							document.getElementById("voc_pckind").value = null;
							document.getElementById("voc_country").value = null;
							document.getElementById("voc_numsys").value = null;
							document.getElementById("voc_upcmanuf").value = null;
							document.getElementById("voc_upcitm").value = null;
							$scope.searchBuyingRequest.filterAvail = false;
							$scope.isBuyingFilterApplied = "filterUnapplied";
							$scope.buyingFilterApplied = false;
						};
						$scope.clearSellingFilter = function ($event) {
							$scope.searchSellingRequest.filter = {};
							$scope.selectedSellingFilterUsageInd = "";
							$scope.selectedSellingFilterUsagetype = "";
							document.getElementById("s_smic_grp").value = null;
							document.getElementById("s_smic_ctgry").value = null;
							document.getElementById("s_smic_class").value = null;
							document.getElementById("s_smic_sub_class").value = null;
							document.getElementById("s_smic_sub_sb_class").value = null;
							document.getElementById("svoc_pckind").value = null;
							document.getElementById("svoc_country").value = null;
							document.getElementById("svoc_numsys").value = null;
							document.getElementById("svoc_upcmanuf").value = null;
							document.getElementById("svoc_upcitm").value = null;
							$scope.searchSellingRequest.filterAvail = false;
							$scope.isSellingFilterApplied = "filterUnapplied";
							$scope.sellingFilterApplied = false;
						};


						/**  Toggle arrow for expanded view
						 * 
						 * */
						$scope.toggleArrow = function ($event, tabid) {
							var msie = $document[0].documentMode;
							if (msie) {
								$(event.target).toggleClass('glyphicon-menu-up glyphicon-menu-down');
							} else {
								$(event.target).toggleClass('glyphicon-menu-up glyphicon-menu-down');
							}
						};

						/**
						 * U62615
						 * Open and close action for UPC drop down at source
						 */
						$scope.closeUPC = function (index) {
							$("#openBakeryUPC_" + index).hide();
						};

						$scope.openUPC = function (index) {
							$("#openBakeryUPC_" + index).show();
						};
						$scope.closeBakStatusUPC = function (index) {
							$("#openbakbadge_" + index).hide();
						};

						$scope.openBakStatusUPC = function (index) {
							$("#openbakbadge_" + index).show();
						};


						/**
						 * U62615
						 * open action for UPC drop down at buying
						 */
						$scope.openBuyingUPC = function (index) {
							$("#openbuying_" + index).show();
						};


						/**
						 * U62615
						 * close action for UPC drop down at buying
						 */
						$scope.closeBuyingUPC = function (index) {
							$("#openbuying_" + index).hide();
						};

						/**
						 * U62615
						 * open action for UPC drop down at selling
						 */
						$scope.openSellingUPC = function (index) {
							$("#openselling_" + index).show();
						};


						/**
						 * U62615
						 * close action for UPC drop down at selling
						 */
						$scope.closeSellingUPC = function (index) {
							$("#openselling_" + index).hide();
						};

						/**
						 * U63178
						 * method to set and search with the itemType selected
						 */
						$scope.searchWithItemType = function (searchRequest, searchFrom, type) {
							if (searchRequest) {
								searchRequest.itemType = {};
								searchRequest.itemType.all = false;
								searchRequest.itemType.system2 = false;
								searchRequest.itemType.system4 = false;
								searchRequest.itemType.plu = false;
								switch (type) {
									case 'all':
										searchRequest.itemType.all = true;
										break;
									case 'system2':
										searchRequest.itemType.system2 = true;
										break;
									case 'system4':
										searchRequest.itemType.system4 = true;
										break;
									case 'plu':
										searchRequest.itemType.plu = true;
										break;
									default:
										searchRequest.itemType.all = true;
								}

								if (searchFrom && searchFrom == "bakery") {
									$scope.markedSKUs = [];
									$scope.searchBakeryRequest.searchCriteriaValue = $scope.selectedBakerySearchCriteriaValue;
									service.bakerySourceSearch = searchRequest;
									$scope.listBakery(searchRequest);
								} else if (searchFrom && searchFrom == "buying") {
									$scope.markedBuyingCICs = [];
									$scope.searchBuyingRequest.searchCriteriaValue = $scope.selectedBuyingSearchCriteriaValue;
									$scope.listBakeryBuyingData(searchRequest);
								} else if (searchFrom && searchFrom == "selling") {
									$scope.markedSellingCICs = [];
									$scope.searchSellingRequest.searchCriteriaValue = $scope.selectedSellingSearchCriteriaValue;
									$scope.listBakerySellingData(searchRequest);
								}
							}
						};

						/**
						 * U63178
						 * method to set the Shipment in source filter
						 */
						$scope.changeSourceFilterShipment = function (sourceFilterVal) {
							if (sourceFilterVal == "Y" || sourceFilterVal == "N") {
								$scope.searchBakeryRequest.filter.shipped = true;
								$scope.searchBakeryRequest.filter.shipSearchValue = sourceFilterVal;
							} else {
								$scope.searchBakeryRequest.filter.shipped = false;
								$scope.searchBakeryRequest.filter.shipSearchValue = null;
							}
						};

						/**
						 * U63178
						 * method to set the Total sales in source filter
						 */
						$scope.changeSourceFilterSales = function (sourceFilterVal) {
							if (sourceFilterVal == "GREATER_THAN" || sourceFilterVal == "LESS_THAN" || sourceFilterVal == "EQUALS") {
								$scope.searchBakeryRequest.filter.totalSalesFilter = true;
								$scope.searchBakeryRequest.filter.totalSalesOperator = sourceFilterVal;
							} else {
								$scope.searchBakeryRequest.filter.totalSalesFilter = false;
								$scope.searchBakeryRequest.filter.totalSalesOperator = null;
								$scope.searchBakeryRequest.filter.totalSalesvalue = null;
							}
						};

						/**
						 * U63178
						 * method to set the Usage type in source filter
						 */
						$scope.changeSourceFilterUsage = function (sourceFilterVal) {
							if (sourceFilterVal == "R" || sourceFilterVal == "M" || sourceFilterVal == "E") {
								$scope.searchBakeryRequest.filter.usageTypeIndFilter = true;
								$scope.searchBakeryRequest.filter.usageTypeInd = sourceFilterVal;
							} else {
								$scope.searchBakeryRequest.filter.usageTypeIndFilter = false;
								$scope.searchBakeryRequest.filter.usageTypeInd = null;
							}
						};

						/**
						 * U63178
						 * method to set the Usage type in buying filter
						 */
						$scope.changeBuyingFilterUsage = function (targetFilterVal) {
							if (!targetFilterVal == "") {
								$scope.searchBuyingRequest.filter.usageFilter = true;
								$scope.searchBuyingRequest.filter.usageType = targetFilterVal;
							} else {
								$scope.searchBuyingRequest.filter.usageFilter = false;
								$scope.searchBuyingRequest.filter.usageType = null;
							}
						};

						/**
						 * U63178
						 * method to set the Usage Ind in buying filter
						 */
						$scope.changeBuyingFilterUsageInd = function (targetFilterVal) {
							if (!targetFilterVal == "") {
								$scope.searchBuyingRequest.filter.usageTypeIndFilter = true;
								$scope.searchBuyingRequest.filter.usageTypeInd = targetFilterVal;
							} else {
								$scope.searchBuyingRequest.filter.usageTypeIndFilter = false;
								$scope.searchBuyingRequest.filter.usageTypeInd = null;
							}
						};

						/**
						 * U63178
						 * method to set the Usage type in selling filter
						 */
						$scope.changeSellingFilterUsage = function (targetFilterVal) {
							if (!targetFilterVal == "") {
								$scope.searchSellingRequest.filter.usageFilter = true;
								$scope.searchSellingRequest.filter.usageType = targetFilterVal;
							} else {
								$scope.searchSellingRequest.filter.usageFilter = false;
								$scope.searchSellingRequest.filter.usageType = null;
							}
						};

						/**
						 * U63178
						 * method to set the Usage Ind in selling filter
						 */
						$scope.changeSellingFilterUsageInd = function (targetFilterVal) {
							if (!targetFilterVal == "") {
								$scope.searchSellingRequest.filter.usageTypeIndFilter = true;
								$scope.searchSellingRequest.filter.usageTypeInd = targetFilterVal;
							} else {
								$scope.searchSellingRequest.filter.usageTypeIndFilter = false;
								$scope.searchSellingRequest.filter.usageTypeInd = null;
							}
						};

						/** 
						 * Apply Filter Function
						 */
						$scope.applyFilter = function (filterCriteria, searchRequest, searchFrom) {
							if (filterCriteria && filterCriteria.filter) {
								var count = 0;
								if (filterCriteria.filter.corpItemCD == "") {
									filterCriteria.filter.corpItemCD = null;
								}

								if (filterCriteria.filter.divisionNum == "") {
									filterCriteria.filter.divisionNum = null;
								}
								if (filterCriteria.filter.prodhierarchyLevel1 === "") {
									filterCriteria.filter.prodhierarchyLevel1 = null;
								}
								if (filterCriteria.filter.prodhierarchyLevel2 === "") {
									filterCriteria.filter.prodhierarchyLevel2 = null;
								}
								if (filterCriteria.filter.prodhierarchyLevel3 === "") {
									filterCriteria.filter.prodhierarchyLevel3 = null;
								}
								if (filterCriteria.filter.itemNum == "") {
									filterCriteria.filter.itemNum = null;
								}
								if (filterCriteria.filter.itemDescription == "") {
									filterCriteria.filter.itemDescription = null;
								}
								if (filterCriteria.filter.productSKU == "") {
									filterCriteria.filter.productSKU = null;
								}
								if (filterCriteria.filter.plu == "") {
									filterCriteria.filter.plu = null;
								}
								if (filterCriteria.filter.supplierName == "") {
									filterCriteria.filter.supplierName = null;
								}
								if (filterCriteria.filter.supplierNum == "") {
									filterCriteria.filter.supplierNum = null;
								}
								if (filterCriteria.filter.slu == "") {
									filterCriteria.filter.slu = null;
								}
								if (filterCriteria.filter.upc == "") {
									filterCriteria.filter.upc = null;
								}
								if (filterCriteria.filter.smicGroupCd === "") {
									filterCriteria.filter.smicGroupCd = null;
								}
								if (filterCriteria.filter.smicCtgryCd === "") {
									filterCriteria.filter.smicCtgryCd = null;
								}
								if (filterCriteria.filter.smicClassCd === "") {
									filterCriteria.filter.smicClassCd = null;
								}
								if (filterCriteria.filter.smicSubClassCd === "") {
									filterCriteria.filter.smicSubClassCd = null;
								}
								if (filterCriteria.filter.smicSubSubClassCd === "") {
									filterCriteria.filter.smicSubSubClassCd = null;
								}
								if (filterCriteria.filter.vendUpcPackInd == undefined) {
									filterCriteria.filter.vendUpcPackInd = null;
									count = count + 1;
								}
								if (filterCriteria.filter.vendUpcCountry == undefined) {
									filterCriteria.filter.vendUpcCountry = null;
									count = count + 1;
								}
								if (filterCriteria.filter.vendUpcNumSys == undefined) {
									filterCriteria.filter.vendUpcNumSys = null;
									count = count + 1;
								}
								if (filterCriteria.filter.vendUpcManuf == undefined) {
									filterCriteria.filter.vendUpcManuf = null;
									count = count + 1;
								}
								if (filterCriteria.filter.vendUpcItem == undefined) {
									filterCriteria.filter.vendUpcItem = null;
									count = count + 1;
								}
								if (filterCriteria.filter.totalSalesvalue === "") {
									filterCriteria.filter.totalSalesFilter = false;
									filterCriteria.filter.totalSalesOperator = null;
									filterCriteria.filter.totalSalesvalue = null;
								}
								if (filterCriteria.filter.usageType === "") {
									filterCriteria.filter.usageType = null;
									filterCriteria.filter.usageFilter = false;
								}
								if (filterCriteria.filter.shipSearchValue === "") {
									filterCriteria.filter.shipSearchValue = null;
									filterCriteria.filter.shipped = false;
								}
								if (filterCriteria.filter.vendorCode === "") {
									filterCriteria.filter.vendorCode = null;
								}
								if (filterCriteria.filter.vendorName === "") {
									filterCriteria.filter.vendorName = null;
								}
								if (count == 5) {
									filterCriteria.filter.vendorOrderFilter = false;
								} else {
									filterCriteria.filter.vendorOrderFilter = true;
								}
								if (filterCriteria.filter.corpItemCD || filterCriteria.filter.divisionNum || filterCriteria.filter.prodhierarchyLevel1 ||
									filterCriteria.filter.prodhierarchyLevel2 || filterCriteria.filter.prodhierarchyLevel3 ||
									filterCriteria.filter.itemNum || filterCriteria.filter.itemDescription || filterCriteria.filter.productSKU || filterCriteria.filter.plu ||
									filterCriteria.filter.supplierName || filterCriteria.filter.supplierNum || filterCriteria.filter.slu || filterCriteria.filter.upc ||
									filterCriteria.filter.smicGroupCd || filterCriteria.filter.smicCtgryCd || filterCriteria.filter.smicClassCd ||
									filterCriteria.filter.smicSubClassCd || filterCriteria.filter.smicSubSubClassCd ||
									filterCriteria.filter.smicGroupCd == 0 || filterCriteria.filter.smicCtgryCd == 0 || filterCriteria.filter.smicClassCd == 0 ||
									filterCriteria.filter.smicSubClassCd == 0 || filterCriteria.filter.smicSubSubClassCd == 0 || filterCriteria.filter.prodhierarchyLevel1 == 0 ||
									filterCriteria.filter.prodhierarchyLevel2 == 0 || filterCriteria.filter.prodhierarchyLevel3 == 0 ||
									filterCriteria.filter.totalSalesFilter || filterCriteria.filter.totalSalesOperator || filterCriteria.filter.totalSalesvalue ||
									filterCriteria.filter.usageFilter || filterCriteria.filter.usageType || filterCriteria.filter.shipped || filterCriteria.filter.shipSearchValue ||
									filterCriteria.filter.vendorCode || filterCriteria.filter.vendorName || filterCriteria.filter.usageTypeIndFilter || filterCriteria.filter.usageTypeInd ||
									filterCriteria.filter.vendUpcPackInd || filterCriteria.filter.vendUpcCountry || filterCriteria.filter.vendUpcNumSys || filterCriteria.filter.vendUpcManuf ||
									filterCriteria.filter.vendUpcItem || filterCriteria.filter.vendUpcPackInd == 0 || filterCriteria.filter.vendUpcCountry == 0 || filterCriteria.filter.vendUpcNumSys == 0 ||
									filterCriteria.filter.vendUpcManuf == 0 || filterCriteria.filter.vendUpcItem == 0) {
									searchRequest.filterAvail = true;
									if (searchFrom && searchFrom == "bakery") {
										$scope.isBakeryFilterApplied = "filterApplied";
									} else if (searchFrom && searchFrom == "buying") {
										$scope.isBuyingFilterApplied = "filterApplied";
									} else if (searchFrom && searchFrom == "selling") {
										$scope.isSellingFilterApplied = "filterApplied";
									}

								} else {
									searchRequest.filterAvail = false;
									if (searchFrom && searchFrom == "bakery") {
										$scope.isBakeryFilterApplied = "filterUnapplied";
									} else if (searchFrom && searchFrom == "buying") {
										$scope.isBuyingFilterApplied = "filterUnapplied";
									} else if (searchFrom && searchFrom == "selling") {
										$scope.isSellingFilterApplied = "filterUnapplied";
									}
								}
								$scope.setItemType(searchRequest); //setting itemType to default "All" in source side if no itemType selected after load
								if (searchFrom && searchFrom == "bakery") {
									$scope.bakeryFilterApplied = true;
									$scope.postBakFilterVal = angular.copy(filterCriteria.filter);
									$scope.markedSKUs = [];
									service.bakerySourceSearch = searchRequest;
									$scope.listBakery(searchRequest);
								} else if (searchFrom && searchFrom == "buying") {
									$scope.buyingFilterApplied = true;
									$scope.postBuyingFilterVal = angular.copy(filterCriteria.filter);
									$scope.markedBuyingCICs = [];
									$scope.listBakeryBuyingData(searchRequest);
								} else if (searchFrom && searchFrom == "selling") {
									$scope.sellingFilterApplied = true;
									$scope.postSellingFilterVal = angular.copy(filterCriteria.filter);
									$scope.markedSellingCICs = [];
									$scope.listBakerySellingData(searchRequest);
								}
							}
						};


						/** 
						 * Method to set the selected source/target status to search request   
						 * 
						 * */
						$scope.filterByStatus = function (status, color, type) {
							if (type == "bakery") {
								switch (status) {
									case 'To Be Mapped':
										$scope.searchBakeryRequest.mappingStatus = "TO_BE_MAPPED";
										break;
									case 'Mark As Dead':
										$scope.searchBakeryRequest.mappingStatus = "MARK_AS_DEAD";
										break;
									case 'Mapped':
										$scope.searchBakeryRequest.mappingStatus = "MAPPED";
										break;
									case 'Force New':
										$scope.searchBakeryRequest.mappingStatus = "FORCE_NEW";
										break;
									case 'Let Auto Match':
										$scope.searchBakeryRequest.mappingStatus = "LET_AUTO_MATCH";
										break;
									case 'Reserved':
										$scope.searchBakeryRequest.mappingStatus = "RESERVED";
										break;
									case 'Show All':
										$scope.searchBakeryRequest.mappingStatus = "SHOW_ALL";
										break;
									default:
										$scope.searchBakeryRequest.mappingStatus = "TO_BE_MAPPED";
								}
								$scope.selectedBakeryStatus = status;
								$scope.colorSelectedBakery = color;
								$scope.markedSKUs = [];
								$scope.setItemType($scope.searchBakeryRequest); //setting itemType to default "All" in source side if no itemType selected after load
								$scope.searchBakeryRequest.searchCriteriaValue = $scope.selectedBakerySearchCriteriaValue;
								service.bakerySourceSearch = $scope.searchBakeryRequest;
								$scope.listBakery($scope.searchBakeryRequest);
							} else if (type == "buying") {
								switch (status) {
									case 'To Be Mapped':
										$scope.searchBuyingRequest.mappingStatus = "TO_BE_MAPPED";
										break;
									case 'Mark As Dead':
										$scope.searchBuyingRequest.mappingStatus = "MARK_AS_DEAD";
										break;
									case 'Mapped':
										$scope.searchBuyingRequest.mappingStatus = "MAPPED";
										break;
									case 'Un Mapped':
										$scope.searchBuyingRequest.mappingStatus = "UNMAPPED";
										break;
									case 'Show All':
										$scope.searchBuyingRequest.mappingStatus = "SHOW_ALL";
										break;
									default:
										$scope.searchBuyingRequest.mappingStatus = "TO_BE_MAPPED";
								}
								$scope.selectedBuyingStatus = status;
								$scope.colorSelectedBuying = color;
								$scope.markedBuyingCICs = [];
								$scope.setItemType($scope.searchBuyingRequest); //setting itemType to default "All" in source side if no itemType selected after load
								$scope.searchBuyingRequest.searchCriteriaValue = $scope.selectedBuyingSearchCriteriaValue;
								$scope.listBakeryBuyingData($scope.searchBuyingRequest);
							} else {
								switch (status) {
									case 'To Be Mapped':
										$scope.searchSellingRequest.mappingStatus = "TO_BE_MAPPED";
										break;
									case 'Mark As Dead':
										$scope.searchSellingRequest.mappingStatus = "MARK_AS_DEAD";
										break;
									case 'Mapped':
										$scope.searchSellingRequest.mappingStatus = "MAPPED";
										break;
									case 'Un Mapped':
										$scope.searchSellingRequest.mappingStatus = "UNMAPPED";
										break;
									case 'Show All':
										$scope.searchSellingRequest.mappingStatus = "SHOW_ALL";
										break;
									default:
										$scope.searchSellingRequest.mappingStatus = "TO_BE_MAPPED";
								}
								$scope.selectedSellingStatus = status;
								$scope.colorSelectedSelling = color;
								$scope.markedSellingCICs = [];
								$scope.setItemType($scope.searchSellingRequest); //setting itemType to default "All" in source side if no itemType selected after load
								$scope.searchSellingRequest.searchCriteriaValue = $scope.selectedSellingSearchCriteriaValue;
								$scope.listBakerySellingData($scope.searchSellingRequest);
							}
						};

						/**
						 * 
						 * Method to disable Bakery search criteria value if select/department/display given
						 */
						$scope.disableBakerySearchCriteriaVal = function (criteria) {
							if (criteria == "Select" || criteria == "Display" || criteria == "WHSE vs DSD" || criteria == "Usage Ind") {
								return true;
							} else {
								return false;
							}
						};

						/**
						 * 
						 *Method to disable Buying search criteria value if select/department/display given
						 */
						$scope.disableBuyingSearchCriteriaVal = function (criteria) {
							if (criteria == "Select" || criteria == "Display" || criteria == "WHSE vs DSD" || criteria == "Usage Ind") {
								return true;
							} else {
								return false;
							}
						};

						/** 
						 *Method to disable Selling search criteria value if select/department/display given
						 */
						$scope.disableSellingSearchCriteriaVal = function (criteria) {
							if (criteria == "Select" || criteria == "Display" || criteria == "WHSE vs DSD" || criteria == "Usage Ind") {
								return true;
							} else {
								return false;
							}
						};

						/**
						 *  Function to toggle all sub menu when a dropdown item is selected.
						 */
						$scope.filterSubmenuToggle = function (key) {
							if (key) {
								switch (key) {
									case 'bakery':
										$("#bakeryFilterByDep").hide();
										$("#bakeryFilterByWhse").hide();
										$("#bakeryFilterByDisplay").hide();
										$("#bakeryFilterByTotalsales").hide();
										$("#bakeryFilterByUsage").hide();
										break;

									case 'bakeryfilterDepClckAction':
										$("#bakeryFilterByWhse").hide();
										$("#bakeryFilterByDisplay").hide();
										$("#bakeryFilterByTotalsales").hide();
										$("#bakeryFilterByDep").show();
										$("#bakeryFilterByUsage").hide();
										break;

									case 'bakeryfilterWhseClckAction':
										$("#bakeryFilterByDep").hide();
										$("#bakeryFilterByDisplay").hide();
										$("#bakeryFilterByTotalsales").hide();
										$("#bakeryFilterByWhse").show();
										$("#bakeryFilterByUsage").hide();
										break;

									case 'bakeryfilterDispClckAction':
										$("#bakeryFilterByDep").hide();
										$("#bakeryFilterByWhse").hide();
										$("#bakeryFilterByTotalsales").hide();
										$("#bakeryFilterByDisplay").show();
										$("#bakeryFilterByUsage").hide();
										break;

									case 'bakeryfilterTotalsaleClckAction':
										$("#bakeryFilterByDep").hide();
										$("#bakeryFilterByWhse").hide();
										$("#bakeryFilterByDisplay").hide();
										$("#bakeryFilterByTotalsales").show();
										$("#bakeryFilterByUsage").hide();
										break;

									case 'bakeryfilterUsageTypeAction':
										$("#bakeryFilterByDep").hide();
										$("#bakeryFilterByWhse").hide();
										$("#bakeryFilterByDisplay").hide();
										$("#bakeryFilterByTotalsales").hide();
										$("#bakeryFilterByUsage").show();
										break;

									case 'buying':
										$("#buyingFilterByDep").hide();
										$("#buyingFilterByWhse").hide();
										$("#buyingFilterByDisplay").hide();
										$("#buyingFilterByUsage").hide();
										break;

									case 'buyingfilterDepClckAction':
										$("#buyingFilterByWhse").hide();
										$("#buyingFilterByDisplay").hide();
										$("#buyingFilterByDep").show();
										$("#buyingFilterByUsage").hide();
										break;

									case 'buyingfilterWhseClckAction':
										$("#buyingFilterByDep").hide();
										$("#buyingFilterByDisplay").hide();
										$("#buyingFilterByWhse").show();
										$("#buyingFilterByUsage").hide();
										break;

									case 'buyingfilterDispClckAction':
										$("#buyingFilterByDep").hide();
										$("#buyingFilterByWhse").hide();
										$("#buyingFilterByDisplay").show();
										$("#buyingFilterByUsage").hide();
										break;

									case 'buyingfilterUsageTypeAction':
										$("#buyingFilterByDep").hide();
										$("#buyingFilterByWhse").hide();
										$("#buyingFilterByDisplay").hide();
										$("#buyingFilterByUsage").show();
										break;

									case 'selling':
										$("#sellingFilterByDep").hide();
										$("#sellingFilterByWhse").hide();
										$("#sellingFilterByDisplay").hide();
										$("#sellingFilterByUsage").hide();
										break;

									case 'sellingfilterDepClckAction':
										$("#sellingFilterByWhse").hide();
										$("#sellingFilterByDisplay").hide();
										$("#sellingFilterByDep").show();
										$("#sellingFilterByUsage").hide();
										break;

									case 'sellingfilterWhseClckAction':
										$("#sellingFilterByDep").hide();
										$("#sellingFilterByDisplay").hide();
										$("#sellingFilterByWhse").show();
										$("#sellingFilterByUsage").hide();
										break;

									case 'sellingfilterDispClckAction':
										$("#sellingFilterByDep").hide();
										$("#sellingFilterByWhse").hide();
										$("#sellingFilterByDisplay").show();
										$("#sellingFilterByUsage").hide();
										break;

									case 'sellingfilterUsageTypeAction':
										$("#sellingFilterByDep").hide();
										$("#sellingFilterByWhse").hide();
										$("#sellingFilterByDisplay").hide();
										$("#sellingFilterByUsage").show();
										break;

									default:
										break;
								}
							}
						};
						$scope.setSearchCriteria = function (criteria, type) {

							if (type == "bakery") {
								$("#bakeryFilterByDep").hide();
								$("#bakeryFilterByWhse").hide();
								$("#bakeryFilterByDisplay").hide();
								$("#bakeryFilterByTotalsales").hide();
								$("#bakeryFilterByUsage").hide();

								$scope.searchBakeryRequest.searchCriteria = null;
								$scope.selectedBakerySearchCriteria = null;
								$scope.searchBakeryRequest.searchCriteriaValue = null;
								$scope.selectedBakerySearchCriteriaValue = null;
								$scope.searchBakeryRequest.totalSalesOperator = null;
								switch (criteria) {
									case 'SKU':
										$scope.searchBakeryRequest.searchCriteria = "SKU_VAL";
										break;
									case 'Item Description':
										$scope.searchBakeryRequest.searchCriteria = "ITEM_DESC";
										break;
									case 'UPC':
										$scope.searchBakeryRequest.searchCriteria = "UPC_VAL";
										break;
									case 'PLU':
										$scope.searchBakeryRequest.searchCriteria = "PLU_VAL";
										break;
									case 'Select':
										$scope.searchBakeryRequest.searchCriteria = null;
										$scope.searchBakeryRequest.searchCriteriaValue = null;
										break;
									default:
										$scope.searchBakeryRequest.searchCriteria = null;
										$scope.searchBakeryRequest.searchCriteriaValue = null;
								}

								if (criteria == "N" || criteria == "Y") {
									$scope.searchBakeryRequest.searchCriteria = "DISP";
									$scope.searchBakeryRequest.searchCriteriaValue = criteria;
									$scope.selectedBakerySearchCriteriaValue = criteria;
									$scope.selectedBakerySearchCriteria = "Display";
								} else if (criteria == "WHSE" || criteria == "DSD") {
									$scope.searchBakeryRequest.searchCriteria = "WHSE_DSD";
									$scope.searchBakeryRequest.searchCriteriaValue = criteria;
									$scope.selectedBakerySearchCriteriaValue = criteria;
									$scope.selectedBakerySearchCriteria = "WHSE vs DSD";
								} else if (criteria == "GREATER_THAN" || criteria == "LESS_THAN" || criteria == "EQUALS") {
									$scope.searchBakeryRequest.searchCriteria = "TOTAL_SALES";
									$scope.searchBakeryRequest.totalSalesOperator = criteria;
									if (criteria == "GREATER_THAN") {
										$scope.selectedBakerySearchCriteria = "Total Sales >";
									} else if (criteria == "LESS_THAN") {
										$scope.selectedBakerySearchCriteria = "Total Sales <";
									} else if (criteria == "EQUALS") {
										$scope.selectedBakerySearchCriteria = "Total Sales =";
									}
								} else if (criteria == "R" || criteria == "M" || criteria == "E") {
									$scope.searchBakeryRequest.searchCriteria = "USAGE_TYPE";
									$scope.searchBakeryRequest.searchCriteriaValue = criteria;
									$scope.selectedBakerySearchCriteriaValue = criteria;
									$scope.selectedBakerySearchCriteria = "Usage Ind";
								}

								if ($scope.selectedBakerySearchCriteria != "Display" && $scope.selectedBakerySearchCriteria != "WHSE vs DSD" &&
									$scope.searchBakeryRequest.searchCriteria != "TOTAL_SALES" && $scope.searchBakeryRequest.searchCriteria != "USAGE_TYPE") {
									$scope.selectedBakerySearchCriteria = criteria;
								}

							} else if (type == "buying") {
								$("#buyingFilterByDep").hide();
								$("#buyingFilterByWhse").hide();
								$("#buyingFilterByDisplay").hide();
								$("#buyingFilterByUsage").hide();

								$scope.searchBuyingRequest.searchCriteria = null;
								$scope.selectedBuyingSearchCriteria = null;
								$scope.searchBuyingRequest.searchCriteriaValue = null;
								$scope.selectedBuyingSearchCriteriaValue = null;
								switch (criteria) {
									case 'CIC':
										$scope.searchBuyingRequest.searchCriteria = "CIC_VAL";
										break;
									case 'Item Description':
										$scope.searchBuyingRequest.searchCriteria = "ITEM_DESC";
										break;
									case 'UPC':
										$scope.searchBuyingRequest.searchCriteria = "UPC_VAL";
										break;
									case 'PLU':
										$scope.searchBuyingRequest.searchCriteria = "PLU_VAL";
										break;
									case 'Select':
										$scope.searchBuyingRequest.searchCriteria = null;
										$scope.searchBuyingRequest.searchCriteriaValue = null;
										break;
									default:
										$scope.searchBuyingRequest.searchCriteria = null;
										$scope.searchBuyingRequest.searchCriteriaValue = null;
								}

								if (criteria == "N" || criteria == "Y") {
									$scope.searchBuyingRequest.searchCriteria = "DISP";
									$scope.searchBuyingRequest.searchCriteriaValue = criteria;
									$scope.selectedBuyingSearchCriteriaValue = criteria;
									$scope.selectedBuyingSearchCriteria = "Display";
								} else if (criteria == "WHSE" || criteria == "DSD") {
									$scope.searchBuyingRequest.searchCriteria = "WHSE_DSD";
									$scope.searchBuyingRequest.searchCriteriaValue = criteria;
									$scope.selectedBuyingSearchCriteria = "WHSE vs DSD";
									$scope.selectedBuyingSearchCriteriaValue = criteria;
								} else if (criteria == "R" || criteria == "M" || criteria == "E") {
									$scope.searchBuyingRequest.searchCriteria = "USAGE_TYPE";
									$scope.searchBuyingRequest.searchCriteriaValue = criteria;
									$scope.selectedBuyingSearchCriteriaValue = criteria;
									$scope.selectedBuyingSearchCriteria = "Usage Ind";
								}

								if ($scope.selectedBuyingSearchCriteria != "Display" && $scope.selectedBuyingSearchCriteria != "WHSE vs DSD" &&
									$scope.selectedBuyingSearchCriteria != "Department" && $scope.searchBuyingRequest.searchCriteria != "USAGE_TYPE") {
									$scope.selectedBuyingSearchCriteria = criteria;
								}
							} else {
								$("#sellingFilterByDep").hide();
								$("#sellingFilterByWhse").hide();
								$("#sellingFilterByDisplay").hide();

								$scope.searchSellingRequest.searchCriteria = null;
								$scope.selectedSellingSearchCriteria = null;
								$scope.searchSellingRequest.searchCriteriaValue = null;
								$scope.selectedSellingSearchCriteriaValue = null;
								switch (criteria) {
									case 'CIC':
										$scope.searchSellingRequest.searchCriteria = "CIC_VAL";
										break;
									case 'Item Description':
										$scope.searchSellingRequest.searchCriteria = "ITEM_DESC";
										break;
									case 'UPC':
										$scope.searchSellingRequest.searchCriteria = "UPC_VAL";
										break;
									case 'PLU':
										$scope.searchSellingRequest.searchCriteria = "PLU_VAL";
										break;
									case 'Select':
										$scope.searchSellingRequest.searchCriteria = null;
										$scope.searchSellingRequest.searchCriteriaValue = null;
										break;
									default:
										$scope.searchSellingRequest.searchCriteria = null;
										$scope.searchSellingRequest.searchCriteriaValue = null;
								}

								if (criteria == "N" || criteria == "Y") {
									$scope.searchSellingRequest.searchCriteria = "DISP";
									$scope.searchSellingRequest.searchCriteriaValue = criteria;
									$scope.selectedSellingSearchCriteriaValue = criteria;
									$scope.selectedSellingSearchCriteria = "Display";
								} else if (criteria == "WHSE" || criteria == "DSD") {
									$scope.searchSellingRequest.searchCriteria = "WHSE_DSD";
									$scope.searchSellingRequest.searchCriteriaValue = criteria;
									$scope.selectedSellingSearchCriteria = "WHSE vs DSD";
									$scope.selectedSellingSearchCriteriaValue = criteria;
								} else if (criteria == "R" || criteria == "M" || criteria == "E") {
									$scope.searchSellingRequest.searchCriteria = "USAGE_TYPE";
									$scope.searchSellingRequest.searchCriteriaValue = criteria;
									$scope.selectedSellingSearchCriteriaValue = criteria;
									$scope.selectedSellingSearchCriteria = "Usage Ind";
								}

								if ($scope.selectedSellingSearchCriteria != "Display" && $scope.selectedSellingSearchCriteria != "WHSE vs DSD" &&
									$scope.selectedSellingSearchCriteria != "Department" && $scope.searchSellingRequest.searchCriteria != "USAGE_TYPE") {
									$scope.selectedSellingSearchCriteria = criteria;
								}
							}
						};

						/**
						 * 
						 * Method to search based on the dropdown selection and input
						 */
						$scope.searchByDropdown = function (criteria, value, type) {
							if (criteria && criteria != "Select" && !value) {
								alertify.alert("Enter any value to search.");
								return;
							} else {
								if (type == "bakery") {
									$scope.searchBakeryRequest.searchCriteriaValue = value;
									$scope.markedSKUs = [];
									$scope.setItemType($scope.searchBakeryRequest); //setting itemType to default "All" in source side if no itemType selected after load
									service.bakerySourceSearch = $scope.searchBakeryRequest;
									$scope.listBakery($scope.searchBakeryRequest);
								} else if (type == "buying") {
									$scope.searchBuyingRequest.searchCriteriaValue = value;
									$scope.markedBuyingCICs = [];
									$scope.setItemType($scope.searchBuyingRequest); //setting itemType to default "All" in target side if no itemType selected after load
									$scope.listBakeryBuyingData($scope.searchBuyingRequest);
								} else {
									$scope.searchSellingRequest.searchCriteriaValue = value;
									$scope.markedSellingCICs = [];
									$scope.setItemType($scope.searchSellingRequest); //setting itemType to default "All" in target side if no itemType selected after load
									$scope.listBakerySellingData($scope.searchSellingRequest);
								}
							}
						};


						/**
						 * 
						 * method to clear the bakery search criteria value when  search criteria is changed
						 */
						$scope.clearSearchBakeryCriteriaValue = function () {
							if ($scope.searchBakeryRequest.searchCriteriaValue) {
								$scope.searchBakeryRequest.searchCriteriaValue = "";
							}
						};

						/**
						 * 
						 * method to clear the buying search criteria value when  search criteria is changed
						 */
						$scope.clearSearchBuyingCriteriaValue = function () {
							if ($scope.selectedBuyingSearchCriteriaValue) {
								$scope.selectedBuyingSearchCriteriaValue = "";
							}
						};

						/** 
						 * method to clear the selling search criteria value when  search criteria is changed
						 */
						$scope.clearSearchSellingCriteriaValue = function () {
							if ($scope.selectedBuyingSearchCriteriaValue) {
								$scope.selectedBuyingSearchCriteriaValue = "";
							}
						};

						/**
						 *  method to get checkbox
						 */
						$scope.setMPD = function (sourceSKU, selectMPD) {
							if (selectMPD === true) {
								$scope.selectedMPD.push(sourceSKU);
							} else {
								for (var j = 0; j < $scope.selectedMPD.length; j++) {
									if (sourceSKU && $scope.selectedMPD[j]) {
										if (sourceSKU.sourceSKU === $scope.selectedMPD[j].sourceSKU) {
											$scope.selectedMPD.splice(j, 1);
										}
									}
								}
							}
						};

						/**
						 * 	U63178
						 *  Function to highlight the entire row
						 */
						$scope.selectEntireRow = function (id, type, item, status) {

							if (type == "bakery" && (status == 'bgBlue' || status == 'bgLimeBlue')) {

								if ($("#baksourcechkbox_" + id).is(':checked')) {
									$("#baksourcerow_" + id).removeClass('rowcolorchange');
									$("#baksourcechkbox_" + id).prop('checked', false);
									$scope.setSKU(item, false);
								} else {
									$("#baksourcerow_" + id).addClass('rowcolorchange');
									$("#baksourcechkbox_" + id).prop('checked', true);
									$scope.setSKU(item, true);

								}
							} else if (type == "buying") {
								if (!$scope.disableBuyChkBox) {
									if ($("#buytargetchkbox_" + id).is(':checked')) {
										$("#buytargetrow_" + id).removeClass('rowcolorchange');
										$("#buytargetchkbox_" + id).prop('checked', false);
										$scope.setBuyingCIC(item, false);

									} else {
										$("#buytargetrow_" + id).addClass('rowcolorchange');
										$("#buytargetchkbox_" + id).prop('checked', true);
										$scope.setBuyingCIC(item, true);
									}
								}
							} else if (type == "selling") {
								if (!$scope.disableSellChkBox) {
									if ($("#selltargetchkbox_" + id).is(':checked')) {
										$("#selltargetrow_" + id).removeClass('rowcolorchange');
										$("#selltargetchkbox_" + id).prop('checked', false);
										$scope.setSellingCIC(item, false);
									} else {
										$("#selltargetrow_" + id).addClass('rowcolorchange');
										$("#selltargetchkbox_" + id).prop('checked', true);
										$scope.setSellingCIC(item, true);
									}
								}
							}
						};

						/**
						 * 	U63178
						 *  Function to highlight the entire row
						 */
						$scope.selectEntireRowBadgeClick = function (id, type, item, status) {
							if (type == "bakery") {
								if ($("#baksourcechkbox_" + id).is(':checked')) {
									//dont do anything
								} else {
									$("#baksourcerow_" + id).addClass('rowcolorchange');
									$("#baksourcechkbox_" + id).prop('checked', true);
									$scope.setSKU(item, true);
								}
							} else if (type == "buying") {
								if ($("#buytargetchkbox_" + id).is(':checked')) {
									//dont do anything
								} else {
									$("#buytargetrow_" + id).addClass('rowcolorchange');
									$("#buytargetchkbox_" + id).prop('checked', true);
									$scope.setBuyingCIC(item, true);
								}
							} else if (type == "selling") {
								if ($("#selltargetchkbox_" + id).is(':checked')) {
									//dont do anything
								} else {
									$("#selltargetrow_" + id).addClass('rowcolorchange');
									$("#selltargetchkbox_" + id).prop('checked', true);
									$scope.setSellingCIC(item, true);
								}
							}
						};

						/**
						 * 	U63178
						 *  Function to make the checkbox selected on highlight
						 */
						$scope.setChkbox = function (id, type) {
							if (type == "bakery") {
								if ($("#baksourcechkbox_" + id).is(':checked')) {
									$("#baksourcechkbox_" + id).prop('checked', false);
								} else {
									$("#baksourcechkbox_" + id).prop('checked', true);
								}
							} else if (type == "buying") {
								if ($("#buytargetchkbox_" + id).is(':checked')) {
									$("#buytargetchkbox_" + id).prop('checked', false);
								} else {
									$("#buytargetchkbox_" + id).prop('checked', true);
								}
							} else if (type == "selling") {
								if ($("#selltargetchkbox_" + id).is(':checked')) {
									$("#selltargetchkbox_" + id).prop('checked', false);
								} else {
									$("#selltargetchkbox_" + id).prop('checked', true);
								}
							}
						};

						/**
						 *  U62615
						 *  method to get the selected SKU's for any action
						 */
						$scope.setSKU = function (sku, selectSKU) {
							$scope.disableReserved = false;
							if (selectSKU === true) {
								$scope.markedSKUs.push(sku);
							} else {
								for (var j = 0; j < $scope.markedSKUs.length; j++) {
									if (sku && $scope.markedSKUs[j]) {
										if (sku.sku === $scope.markedSKUs[j].sku) {
											$scope.markedSKUs.splice(j, 1);
										}
									}
								}
							}
							angular.forEach($scope.markedSKUs, function (item) {
								if (item.mappingStatus === "OTHERS" || item.mappingStatus === "AWAITING_NEW_CIC" || item.mappingStatus === "AWAITING_DIVISION_INPUT" || item.mappingStatus === "RESERVED") {
									$scope.disableReserved = true;
								}
							});
						};

						/**
						 *  U63180
						 *  Function to enable/disable target checkboxes.
						 */
						$scope.setTargetChkBoxAction = function () {
							if ($scope.markedSKUs.length >= 2) {
								$scope.disableBuyChkBox = true;
								$scope.disableSellChkBox = true;
							} else {
								$scope.disableBuyChkBox = false;
								$scope.disableSellChkBox = false;
							}
						};

						/**
						 *  U62615
						 *  method to validate if any selected SKU's contain UPC of System 2 / System 4 and disable add map
						 */
						$scope.validateAddMapBasedOnUPCSystem = function (selectedDatas, from) {
							var requests = selectedDatas;
							for (var k = 0; k < requests.length; k++) {
								if (requests[k] && requests[k].upc) {
									var upc = requests[k].upc;
									if (from == "bakery") {
										if (upc && (upc[1] == "2" || upc[1] == "4")) {
											$scope.validateBakAddMapFunc = true;
											break;
										} else {
											$scope.validateBakAddMapFunc = false;
											break;
										}
									}
								}
							}
						};

						/**
						 *  U62615
						 * method to get unchecked upcs of an sku 
						 */
						$scope.checkUPC = function (skuitem, upc, checkedUPC) {
							$scope.upcClicked = true;
							if (upc && checkedUPC === true) {
								$scope.selectedMapReq = {};
								$scope.selectedMapReq.sku = skuitem.sku;
								$scope.selectedMapReq.upc = upc;
								$scope.selectedMapReq.matchedItemTypeCd = skuitem.usage;
								if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
									for (var j = 0; j < $scope.unselectedMapRequests.length; j++) {
										if (upc && $scope.unselectedMapRequests[j]) {
											if (upc === $scope.unselectedMapRequests[j].upc) {
												$scope.unselectedMapRequests.splice(j, 1);
											}
										}
									}
								}
								$scope.selectedMapRequests.push($scope.selectedMapReq);
							} else if (upc && checkedUPC === false) {
								$scope.unselectedMapReq = {};
								$scope.unselectedMapReq.sku = skuitem.sku;
								$scope.unselectedMapReq.upc = upc;
								$scope.unselectedMapReq.matchedItemTypeCd = skuitem.usage;
								$scope.unselectedMapRequests.push($scope.unselectedMapReq);
							}
						};

						/**
						 *  U62615
						 *  method to get the selected Buying CIC's for any action
						 */
						$scope.setBuyingCIC = function (cic, selectCIC) {
							if (selectCIC === true) {
								$scope.markedBuyingCICs.push(cic);
							} else {
								for (var j = 0; j < $scope.markedBuyingCICs.length; j++) {
									if (cic && $scope.markedBuyingCICs[j]) {
										if (cic.cic === $scope.markedBuyingCICs[j].cic) {
											$scope.markedBuyingCICs.splice(j, 1);
										}
									}
								}
							}
						};


						/**
						 *  U62615
						 *  method to get the selected Selling CIC's for any action
						 */
						$scope.setSellingCIC = function (cic, selectCIC) {
							if (selectCIC === true) {
								$scope.markedSellingCICs.push(cic);
							} else {
								for (var j = 0; j < $scope.markedSellingCICs.length; j++) {
									if (cic && $scope.markedSellingCICs[j]) {
										if (cic.cic === $scope.markedSellingCICs[j].cic) {
											$scope.markedSellingCICs.splice(j, 1);
										}
									}
								}
							}
						};

						//////////////////BUTTON ACTIONS
						/**
						 *  U63180
						 *  Function to redirect context menu choice to corresponding functionality.
						 */
						$scope.redirectToFunction = function (key) {
							if (key) {
								switch (key) {
									case 'forcenew':
										$scope.forceNew();
										break;
									case 'letautomatch':
										$scope.letAutoMatch();
										break;
									case 'markasdead':
										$scope.markAsDead();
										break;
									case 'addmap':
										{
											if (0 != systemArray.length) {
												alertify.alert("SKU/CIC of System 2 or 4 can't be selected for add map.");
												return;
											} else {
												$scope.addOrInheritMap("addMap");
											}
											break;
										}
									case 'inheritmap':
										$scope.addOrInheritMap("inheritMap");
										break;
									case 'matchingtarget':
										$scope.bakeryMatchingTargetListing();
										break;
									case 'reserve':
										$scope.markAsReserve();
										break;
									default:
										break;
								}
							}
						};

						/**
						 *  U62615
						 *  Add  Map and Inherit Map Function 
						 */
						$scope.addOrInheritMap = function (clickedAction) {
							$scope.fromMarkAsdead = false;
							$scope.addBkPLU = false;
							var markedBuyingSrc = "";
							var markedSellingSrc = "";
							if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedBuyingCICs &&
								$scope.markedBuyingCICs.length > 0 && $scope.markedSellingCICs && $scope.markedSellingCICs.length > 0) {
								for (var i = 0; i < $scope.markedSKUs.length; i++) {
									if ($scope.markedSKUs[i].absDSDWhse != $scope.markedSKUs[$scope.markedSKUs.length - 1].absDSDWhse) {
										alertify.alert("Different type of SKUs has been selected.");
										return;
									}
									if ($scope.markedBuyingCICs[0].whseDsd != ("WHSE-DSD" || "whse-dsd")) {
										if ($scope.markedSKUs[i].absDSDWhse != $scope.markedBuyingCICs[0].whseDsd) {
											alertify.alert("Select same product source items for SKU and Buying CIC.");
											return;
										}
									}
									if ($scope.markedSellingCICs[0].whseDsd != ("WHSE-DSD" || "whse-dsd")) {
										if ($scope.markedSKUs[i].absDSDWhse != $scope.markedSellingCICs[0].whseDsd) {
											alertify.alert("Select same product source items for SKU and Selling CIC.");
											return;
										}
									}
									if ($scope.markedSKUs[i].usage != $scope.markedSKUs[$scope.markedSKUs.length - 1].usage) {
										alertify.alert("Different usage ind SKUs has been selected.");
										return;
									}
									if (($scope.markedSKUs[i].usage != $scope.markedBuyingCICs[0].itemUSageInd) &&
										($scope.markedSKUs[i].usage != $scope.markedSellingCICs[0].itemUSageInd)) {
										alertify.alert("SKU's Usage ind and Buying/Selling CIC's Item usage ind should be same.");
										return;
									}
									if (($scope.markedSKUs[i].absDSDWhse == $scope.markedBuyingCICs[0].whseDsd) || $scope.markedBuyingCICs[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
										//check for similar values and store in a boolean string
										markedBuyingSrc = $scope.markedSKUs[i].absDSDWhse;
									}

									if (($scope.markedSKUs[i].absDSDWhse == $scope.markedSellingCICs[0].whseDsd) || $scope.markedSellingCICs[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
										//check for similar values and store in a boolean string
										markedSellingSrc = $scope.markedSKUs[i].absDSDWhse;
									}
								}
							}
							var validationMsg = "System 2 & 4 UPC's cannot be processed in add map. Do you want to proceed?";
							if (markedBuyingSrc == "WHSE" && markedSellingSrc == "WHSE" &&
								(($scope.markedSKUs && $scope.markedSKUs.length > 1) ||
									($scope.markedBuyingCICs && $scope.markedBuyingCICs.length > 1) ||
									($scope.markedSellingCICs && $scope.markedSellingCICs.length > 1))) {
								alertify.alert("Invalid selection. WHSE item only allows mapping of one SKU with one Buying CIC & Selling CIC.");
								return;
							} else {
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0) {
									if (($scope.markedBuyingCICs && $scope.markedBuyingCICs.length < 1) ||
										($scope.markedSellingCICs && $scope.markedSellingCICs.length < 1)) {
										alertify.alert("Atleast one CIC must be selected from Buying & Selling.");
										return;
									}
									if (($scope.markedBuyingCICs && $scope.markedBuyingCICs.length > 1) ||
										($scope.markedSellingCICs && $scope.markedSellingCICs.length > 1)) {
										alertify.alert("Only one CIC must be selected from Buying & Selling.");
										return;
									}
									if ((markedBuyingSrc == "WHSE" && $scope.markedBuyingCICs && $scope.markedBuyingCICs[0].expBtnClass == "bgGreen") ||
										(markedSellingSrc == "WHSE" && $scope.markedSellingCICs && $scope.markedSellingCICs[0].expBtnClass == "bgGreen")) {
										alertify.alert("WHSE items cannot be mapped again.");
										return;
									}


									$scope.buyingMappingRequests = [];
									$scope.sellingMappingRequests = [];
									if (clickedAction === "addMap") {
										$scope.createBaseMappingRequests($scope.markedSKUs, $scope.markedBuyingCICs, $scope.markedSellingCICs, "ADD_MAP");
									} else if (clickedAction === "inheritMap") {
										$scope.createBaseMappingRequests($scope.markedSKUs, $scope.markedBuyingCICs, $scope.markedSellingCICs, "INHERIT_MAP");
									}

									if ($scope.buyingMappingRequests && $scope.buyingMappingRequests.length > 0 && $scope.sellingMappingRequests &&
										$scope.sellingMappingRequests.length > 0 && !$scope.upcClicked) {
										if (clickedAction === "addMap") {
											$scope.validateAddMapBasedOnUPCSystem($scope.buyingMappingRequests, "bakery");
											if ($scope.validateBakAddMapFunc) {
												alertify.confirm(validationMsg, function (e) {
													if (e) {
														//$scope.action($scope.buyingMappingRequests,$scope.sellingMappingRequests);
														$scope.validatePLU($scope.buyingMappingRequests);
													} else {
														//code incase of cancel
														$scope.upcClicked = false;
													}
												});
											} else {
												//$scope.action($scope.buyingMappingRequests,$scope.sellingMappingRequests);
												$scope.validatePLU($scope.buyingMappingRequests);
											}
										} else if (clickedAction === "inheritMap") {
											//$scope.action($scope.buyingMappingRequests,$scope.sellingMappingRequests);
											$scope.additionalBakPLUpopup("INHERITMAP");
										}
									}

									if ($scope.upcClicked) {
										if (clickedAction === "addMap") {
											if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
												$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.buyingMappingRequests, $scope.sellingMappingRequests);

												if ($scope.buyingMappingRequests && $scope.buyingMappingRequests.length > 0) {
													$scope.validateAddMapBasedOnUPCSystem($scope.buyingMappingRequests, "bakery");
												} else {
													$scope.validateBakAddMapFunc = false;
												}
												if ($scope.validateBakAddMapFunc) {
													alertify.confirm(validationMsg, function (e) {
														if (e) {
															$scope.markAsDeadPrompt($scope.unselectedMapRequests, "addmap");
														}
													});
												} else {
													$scope.markAsDeadPrompt($scope.unselectedMapRequests, "addmap");
												}
											} else {
												$scope.validateAddMapBasedOnUPCSystem($scope.buyingMappingRequests, "bakery");
												if ($scope.validateBakAddMapFunc) {
													alertify.confirm(validationMsg, function (e) {
														if (e) {
															//$scope.action($scope.buyingMappingRequests,$scope.sellingMappingRequests);
															$scope.validatePLU($scope.buyingMappingRequests);
														}
													});
												} else {
													//$scope.action($scope.buyingMappingRequests,$scope.sellingMappingRequests);
													$scope.validatePLU($scope.buyingMappingRequests);
												}
											}
										} else if (clickedAction === "inheritMap") {
											if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
												$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.buyingMappingRequests, $scope.sellingMappingRequests);
												$scope.markAsDeadPrompt($scope.unselectedMapRequests, "inheritmap");
											} else {
												//$scope.action($scope.buyingMappingRequests,$scope.sellingMappingRequests);
												$scope.additionalBakPLUpopup("INHERITMAP");
											}
										}
									}
								} else {
									alertify.alert("Select item from SKU, Buying CIC and Selling CIC to proceed.");
									return;
								}
							}
						};

						/**
						 *  U62615
						 *  mark as dead function 
						 */
						$scope.markAsDead = function () {
							if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedBuyingCICs && $scope.markedBuyingCICs.length < 1 && $scope.markedSellingCICs && $scope.markedSellingCICs.length < 1) {
								$scope.buyingMappingRequests = [];
								$scope.createBaseMappingRequests($scope.markedSKUs, null, null, "MARK_AS_DEAD");
								if ($scope.buyingMappingRequests && $scope.buyingMappingRequests.length > 0 && !$scope.upcClicked) {
									$scope.markAsDeadPrompt($scope.buyingMappingRequests, "markasdead");
								}

								if ($scope.upcClicked && $scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
									$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.buyingMappingRequests, null);
									$scope.markAsDeadPrompt($scope.buyingMappingRequests, "upcmarkasdead");
								}
							} else {
								alertify.alert("Select only SKU to proceed");
								return;
							}
						};

						/**
						 * U62615
						 * Functionality for auto match action.
						 */
						$scope.letAutoMatch = function () {
							if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedBuyingCICs && $scope.markedBuyingCICs.length < 1 && $scope.markedSellingCICs && $scope.markedSellingCICs.length < 1) {
								if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
									alertify.alert("UPCs cannot be unselected for this action");
									return;
								} else {
									$scope.createBaseMappingRequests($scope.markedSKUs, null, null, "LET_AUTO_MATCH");
									$scope.action($scope.buyingMappingRequests, $scope.sellingMappingRequests);
								}
							} else {
								alertify.alert("Select only SKU to proceed.");
								return;
							}
						};

						/**
						 * U62615
						 * common method for creating mapping requests for each sku, when sku alone selected
						 */
						$scope.createBaseMappingRequests = function (selectedSources, selectedBuyingItems, selectedSellingItems, mappingType) {
							$scope.mappingRequests = [];
							$scope.buyingMappingRequests = [];
							$scope.sellingMappingRequests = [];
							var updatedUserID = null;
							updatedUserID = service.userId;
							angular.forEach(selectedSources, function (sku) {
								if (sku.upc && sku.upc.length > 0) {
									angular.forEach(sku.upc, function (upc1) {
										if (upc1) {
											$scope.buyingmaprequest = {};
											$scope.buyingmaprequest.companyID = service.selectedCompany.companyID;
											$scope.buyingmaprequest.divisionID = service.selectedDivision.divisionID;
											$scope.buyingmaprequest.upc = upc1;
											$scope.buyingmaprequest.sku = sku.sku;
											$scope.buyingmaprequest.mappingType = mappingType;
											$scope.buyingmaprequest.targetTypeIndicator = "B";
											$scope.buyingmaprequest.updatedUserId = updatedUserID;
											//$scope.buyingmaprequest.matchedItemTypeCd =  sku.usage;

											if (selectedBuyingItems && (mappingType === "ADD_MAP" || mappingType === "INHERIT_MAP")) {
												$scope.buyingmaprequest.mappingstatus = "MAPPED";
												angular.forEach(selectedBuyingItems, function (cic) {
													$scope.buyingmaprequest.cic = cic.cic;
												});
											}

											if (mappingType === "FORCE_NEW") {
												$scope.buyingmaprequest.mappingstatus = "FORCE_NEW";
											}
											if (mappingType === "RESERVED") {
												$scope.buyingmaprequest.mappingstatus = "RESERVED";
											}
											$scope.buyingMappingRequests.push($scope.buyingmaprequest);

											if (mappingType === "ADD_MAP" || mappingType === "INHERIT_MAP") {
												$scope.sellingmaprequest = {};
												$scope.sellingmaprequest.companyID = service.selectedCompany.companyID;
												$scope.sellingmaprequest.divisionID = service.selectedDivision.divisionID;
												$scope.sellingmaprequest.upc = upc1;
												$scope.sellingmaprequest.sku = sku.sku;
												$scope.sellingmaprequest.mappingType = mappingType;
												$scope.sellingmaprequest.mappingstatus = "MAPPED";
												$scope.sellingmaprequest.targetTypeIndicator = "S";
												$scope.sellingmaprequest.updatedUserId = updatedUserID;
												//$scope.sellingmaprequest.matchedItemTypeCd =  sku.usage;

												if (selectedSellingItems) {
													angular.forEach(selectedSellingItems, function (cic) {
														$scope.sellingmaprequest.cic = cic.cic;
													});
												}
												$scope.sellingMappingRequests.push($scope.sellingmaprequest);
											}
										}
									});
								}
							});
						};

						/**
						 * U62615
						 * common method for seperating mapping requests based based on upc check
						 */
						$scope.createSubMappingRequests = function (unselectedRequests, buyingRequests, sellingRequests) {
							$scope.buyingMappingRequests = [];
							$scope.sellingMappingRequests = [];
							if (buyingRequests) {
								$scope.buyingMappingRequests = buyingRequests;
								for (var j = 0; j < unselectedRequests.length; j++) {
									for (var i = 0; i < $scope.buyingMappingRequests.length; i++) {
										if ($scope.buyingMappingRequests[i] && unselectedRequests[j]) {
											if ($scope.buyingMappingRequests[i].sku === unselectedRequests[j].sku && $scope.buyingMappingRequests[i].upc === unselectedRequests[j].upc) {
												$scope.buyingMappingRequests.splice(i, 1);

											}
										}
									}
								}
							}
							if (sellingRequests) {
								$scope.sellingMappingRequests = sellingRequests;
								for (var j = 0; j < unselectedRequests.length; j++) {
									for (var i = 0; i < $scope.sellingMappingRequests.length; i++) {
										if ($scope.sellingMappingRequests[i] && unselectedRequests[j]) {
											if ($scope.sellingMappingRequests[i].sku === unselectedRequests[j].sku && $scope.sellingMappingRequests[i].upc === unselectedRequests[j].upc) {
												$scope.sellingMappingRequests.splice(i, 1);

											}
										}
									}
								}
							}
						};


						/**
						 * U62615
						 * common method for prompt for mark as dead from add map/inherit map/mark as dead
						 */
						$scope.markAsDeadPrompt = function (mappingRequestsForMAD, from) {
							if (mappingRequestsForMAD && mappingRequestsForMAD.length > 0) {
								var markAsDeadReason = null;
								var updatedUserID = null;
								updatedUserID = service.userId;
								if (from === "addmap" || from === 'inheritmap') {
									alertify.prompt("Some UPC's were unselected which will be marked as dead. Provide a reason for it.", function (e, str) {
										if (e) {
											$scope.finalRequests = [];
											markAsDeadReason = str;
											if (markAsDeadReason == null || markAsDeadReason.length == 0) { } else if (markAsDeadReason != null || markAsDeadReason.length != 0) {
												angular.forEach(mappingRequestsForMAD, function (mapReq) {
													if (mapReq) {
														mapReq.comments = markAsDeadReason;
														mapReq.mappingType = "MARK_AS_DEAD";
														mapReq.updatedUserId = updatedUserID;
														mapReq.companyID = service.selectedCompany.companyID;
														mapReq.divisionID = service.selectedDivision.divisionID;
														mapReq.targetTypeIndicator = "B";
														$scope.finalRequests.push(mapReq);
													}
												});
												angular.forEach($scope.buyingMappingRequests, function (addMapBuyRequest) {
													$scope.finalRequests.push(addMapBuyRequest);
												});
												$scope.fromMarkAsdead = true;
												$scope.action($scope.finalRequests, $scope.sellingMappingRequests);
											}
										} else {
											//code incase of cancel
											$scope.upcClicked = false;
										}
									});
								} else {
									var msg = "";
									if (from === "upcmarkasdead") {
										msg = "The selected UPC's will be marked as dead. Enter the reason for marking as dead";
									} else {
										msg = "The selected SKU's will be marked as dead. Enter the reason for marking as dead";
									}
									alertify.prompt(msg, function (e, str) {
										if (e) {
											$scope.finalRequests = [];
											markAsDeadReason = str;
											if (markAsDeadReason == null || markAsDeadReason.length == 0) { } else if (markAsDeadReason != null || markAsDeadReason.length != 0) {
												angular.forEach(mappingRequestsForMAD, function (mapReq) {
													if (mapReq) {
														mapReq.comments = markAsDeadReason;
														mapReq.mappingType = "MARK_AS_DEAD";
														mapReq.updatedUserId = updatedUserID;
														mapReq.companyID = service.selectedCompany.companyID;
														mapReq.divisionID = service.selectedDivision.divisionID;
														$scope.finalRequests.push(mapReq);
													}
												});
												$scope.action($scope.finalRequests, null);
											}
										} else {
											//code incase of cancel
											$scope.upcClicked = false;
										}
									});
								}
							}
						};


						/**
						 *  U62615
						 *  mark as reserve function 
						 */
						$scope.markAsReserve = function () {
							if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedBuyingCICs && $scope.markedBuyingCICs.length < 1 && $scope.markedSellingCICs && $scope.markedSellingCICs.length < 1) {
								$scope.buyingMappingRequests = [];
								if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
									alertify.alert("UPCs cannot be unselected for this action");
									return;
								}
								$scope.createBaseMappingRequests($scope.markedSKUs, null, null, "RESERVED");

								if ($scope.buyingMappingRequests && $scope.buyingMappingRequests.length > 0 && !$scope.upcClicked) {
									$scope.makeItReserve($scope.buyingMappingRequests, "markasreserve");
								}
								if ($scope.upcClicked && $scope.unselectedMapRequests) {
									$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.buyingMappingRequests, null);
									if ($scope.buyingMappingRequests && $scope.buyingMappingRequests.length > 0) {
										$scope.makeItReserve($scope.buyingMappingRequests, "upcmarkasreserve");
									} else {
										alertify.alert("Select any UPC from the SKU to mark as Reserve.");
										return;
									}
								}
							} else {
								alertify.alert("Select only SKU to proceed.");
								return;
							}
						};

						/**
						 *  U62615
						 *  make it as reserve function 
						 */
						$scope.makeItReserve = function (mappingRequestsForReserve, from) {
							var updatedUserID = null;
							var mappingStatus = "OTHERS";
							updatedUserID = service.userId;
							if (mappingRequestsForReserve && mappingRequestsForReserve.length > 0) {
								alertify.radioprompt("Provide suitable reasons for marking it as reserved.", function (e, str) {
									if (e) {
										var needCic = $('#alertify-radio1:checked').val();
										var needInp = $('#alertify-radio2:checked').val();
										var resComments = $('#alertify-text').val();

										if (needCic) {
											mappingStatus = needCic;
										}
										if (needInp) {
											mappingStatus = needInp;
										}

										angular.forEach(mappingRequestsForReserve, function (mapReq) {
											if (mapReq) {
												mapReq.mappingType = "RESERVED";
												mapReq.mappingstatus = mappingStatus;
												mapReq.comments = resComments;
												mapReq.companyID = service.selectedCompany.companyID;
												mapReq.divisionID = service.selectedDivision.divisionID;
												mapReq.updatedUserId = updatedUserID;
												$scope.finalRequests.push(mapReq);
											}
										});
										$scope.action($scope.finalRequests, null);
									} else {
										//code incase of cancel
									}
								});
								return;
							}
						};

						/**
						 * U63178
						 * function to set the trimmed plu num in the upc column 
						 */
						$scope.validatePLU = function (results) {
							if (results && results.length > 0) {
								angular.forEach(results, function (sku) {
									if (sku && sku.upc) {
										if (sku.upc <= 99999 && sku.mappingType != "MARK_AS_DEAD") {
											$scope.addBkPLU = true;
										}
									}
								});
							}
							if ($scope.addBkPLU && $scope.addBkPLU == true) {
								$scope.additionalBakPLUpopup("ADDMAP");
							} else {
								$scope.fromMarkAsdead = false;
								$scope.additionalBakPLUpopup("INHERITMAP");
							}
						};

						/**
						 * U62615
						 * common method for all actions 
						 */
						$scope.action = function (buyingMappingRequests, sellingMappingRequests) {
							if ($scope.fromMarkAsdead && $scope.fromMarkAsdead == true) {
								$scope.validatePLU(buyingMappingRequests);
							} else {
								var disableTargetRefresh = false;
								var reserveAlertMsg = false;
								$scope.wrapperRequest = {};
								$scope.wrapperRequest.sourceSearchRequest = {};
								$scope.wrapperRequest.sourceSearchRequest = $scope.searchBakeryRequest;
								$scope.wrapperRequest.targetBuyerSearchRequest = {};
								$scope.wrapperRequest.targetBuyerSearchRequest = $scope.searchBuyingRequest;
								$scope.wrapperRequest.targetSellerSearchRequest = {};
								$scope.wrapperRequest.targetSellerSearchRequest = $scope.searchSellingRequest;
								$scope.wrapperRequest.mappingrequestBuyer = [];
								$scope.wrapperRequest.mappingrequestSeller = [];
								$scope.wrapperRequest.mappingrequestBuyer = buyingMappingRequests;
								$scope.wrapperRequest.mappingrequestSeller = sellingMappingRequests;


								var actionResults = $scope.baseUrl + "bakery/bakeryactions";
								$http.post(actionResults, $scope.wrapperRequest, config)
									.then(function (response) {
										//function handles success condition
										if (response.data) {
											if (response.data.actionSuccessStatus == 0) {
												alertify.alert(response.data.errorMessages[0]);
												return;
											} else {
												if (response.data.bakerySKUSearchResults) {
													$scope.bakeryResults = response.data.bakerySKUSearchResults;
													if ((!$scope.bakeryResults) || ($scope.bakeryResults && $scope.bakeryResults.length < 1)) {
														$scope.displayNoResultBakeryAlert = true;
													} else {
														$scope.displayNoResultBakeryAlert = false;
													}
													$scope.trimPLUFunc($scope.bakeryResults);
													if (response.data.sourceCount && response.data.bakerySKUSearchResults) {
														$scope.sourceBakCount = response.data.sourceCount;
														$scope.sourceBakShowCount = response.data.bakerySKUSearchResults.length;

														if ($scope.sourceBakCount <= $scope.sourceBakShowCount) {
															$scope.sourceBakCount = $scope.sourceBakShowCount;
														}
													} else {
														$scope.sourceBakCount = 0;
														$scope.sourceBakShowCount = 0;
													}
												} else {
													$scope.bakeryResults = [];
												}

												for (var i = 0; i < response.data.mappingrequestBuyer.length; i++) {
													if (response.data.mappingrequestBuyer[i].mappingType == "ADD_MAP" ||
														response.data.mappingrequestBuyer[i].mappingType == "INHERIT_MAP") {
														disableTargetRefresh = false;
														break;
													} else {
														if (response.data.mappingrequestBuyer[i].mappingType == "RESERVED") {
															reserveAlertMsg = true;
														}
														disableTargetRefresh = true;
													}
												}

												if (!disableTargetRefresh) {
													if (response.data.bakeryBuyerCICSearchResults) {
														$scope.setItemType($scope.searchBuyingRequest);
														$scope.buyingResults = response.data.bakeryBuyerCICSearchResults;
														if ((!$scope.buyingResults) || ($scope.buyingResults && $scope.buyingResults.length < 1)) {
															$scope.displayNoResultBuyingAlert = true;
														} else {
															$scope.displayNoResultBuyingAlert = false;
														}
														if (response.data.targetBuyerCount && response.data.bakeryBuyerCICSearchResults) {
															$scope.targetBuyCount = response.data.targetBuyerCount;
															$scope.targetBuyShowCount = response.data.bakeryBuyerCICSearchResults.length;

															if ($scope.targetBuyCount <= $scope.targetBuyShowCount) {
																$scope.targetBuyCount = $scope.targetBuyShowCount;
															}
														} else {
															$scope.targetBuyCount = 0;
															$scope.targetBuyShowCount = 0;
														}
													} else {
														$scope.buyingResults = [];
													}
													if (response.data.bakerySellerCICSearchResults) {
														$scope.setItemType($scope.searchSellingRequest);
														$scope.sellingResults = response.data.bakerySellerCICSearchResults;
														if ((!$scope.sellingResults) || ($scope.sellingResults && $scope.sellingResults.length < 1)) {
															$scope.displayNoResultSellingAlert = true;
														} else {
															$scope.displayNoResultSellingAlert = false;
														}
														if (response.data.targetSellerCount && response.data.bakerySellerCICSearchResults) {
															$scope.targetSellCount = response.data.targetSellerCount;
															$scope.targetSellShowCount = response.data.bakerySellerCICSearchResults.length;

															if ($scope.targetSellCount <= $scope.targetSellShowCount) {
																$scope.targetSellCount = $scope.targetSellShowCount;
															}
														} else {
															$scope.targetSellCount = 0;
															$scope.targetSellShowCount = 0;
														}
													} else {
														$scope.sellingResults = [];
													}
												}
											}
											$scope.markedSKUs = [];
											$scope.markedBuyingCICs = [];
											$scope.markedSellingCICs = [];
											$scope.finalRequests = [];
											$scope.unselectedMapRequests = [];
											$scope.buyingMappingRequests = [];
											$scope.sellingMappingRequests = [];
											$scope.returnLists = [];
											$scope.upcClicked = false;
											$scope.disableReserved = false;
											$scope.validateBakAddMapFunc = false;
											$scope.setResultRowColors($scope.bakeryResults, "source");
											if (!disableTargetRefresh) {
												$scope.setResultRowColors($scope.buyingResults, "buying");
												$scope.setResultRowColors($scope.sellingResults, "selling");
											}
											if (reserveAlertMsg) {
												alertify.alert("Selected Items moved to Reserve category.");
												return;
											} else {
												alertify.alert(response.data.errorMessages[0]);
												return;
											}
										}
									}, function (response1) {
										//function handles error condition
										alertify.alert("There was an issue during the conversion.");
										return;
									});
							}
						};

						/**
						 *  U62615
						 *  force new function 
						 */
						$scope.forceNew = function () {
							var updatedUserID = null;
							updatedUserID = service.userId;
							if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedBuyingCICs && $scope.markedBuyingCICs.length < 1 && $scope.markedSellingCICs && $scope.markedSellingCICs.length < 1) {
								if ($scope.markedSKUs.length > 1) {
									alertify.alert("Select single SKU to proceed.");
									return;
								} else if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
									alertify.alert("UPCs cannot be unselected for this action.");
								} else {
									angular.forEach($scope.markedSKUs, function (sku) {
										$scope.saveRequest = {};
										$scope.saveRequest.sourceComponentUpc = [];
										$scope.saveRequest.companyId = service.selectedCompany.companyID;
										$scope.saveRequest.divisionId = service.selectedDivision.divisionID;
										$scope.saveRequest.productSku = sku.sku;
										$scope.saveRequest.cost = 0;
										$scope.saveRequest.displayFlag = sku.display;
										$scope.saveRequest.pack = sku.packNum;
										$scope.saveRequest.vendorConvFactor = sku.vcf;
										$scope.saveRequest.updatedUserId = updatedUserID;
										$scope.skuSelected = $scope.saveRequest.productSku;
										$scope.matchedUsageType = sku.usage;
										angular.forEach(sku.upc, function (upc) {
											$scope.src = {};
											$scope.src.upc = {};
											$scope.src.upc = upc;
											$scope.saveRequest.sourceComponentUpc.push($scope.src);
										});
									});

									var listResults = $scope.baseUrl + "perishable/checkForceNewCategory";

									$http.post(listResults, $scope.saveRequest, config)
										.then(function (response) {
											//function handles success condition
											service.bakerySourceSearch = $scope.searchBakeryRequest;
											if (response.data.ForceNewCategory == "A") {
												AugmentedDisplayerService.setCompanyID(service.selectedCompany.companyID);
												AugmentedDisplayerService.setDivisionID(service.selectedDivision.divisionID);
												AugmentedDisplayerService.setProductSku($scope.skuSelected);
												AugmentedDisplayerService.setUsageType($scope.matchedUsageType);
												AugmentedDisplayerService.setKey("bakery");
												$.contextMenu('destroy');
												$location.path('Augmented');
											} else if (response.data.ForceNewCategory == "O") {
												OverrideMappingService.setCompanyID(service.selectedCompany.companyID);
												OverrideMappingService.setDivisionID(service.selectedDivision.divisionID);
												OverrideMappingService.setProductSku($scope.skuSelected);
												OverrideMappingService.setUsageType($scope.matchedUsageType);
												OverrideMappingService.setKey("bakery");
												$.contextMenu('destroy');
												$location.path('UpdateOverride');
											}
										}, function (response1) {
											//function handles error condition
										});
								}
							} else {
								alertify.alert("Select only SKU to proceed.");
								return;
							}
						};


						/**
						 * U62615
						 * open action for ROG count display
						 */
						$scope.openBuyROG = function (index, cicval) {

							$scope.rogDetailsPassing = cicval;
							$scope.rogDetailsObtained = [];

							var listResults = $scope.baseUrl + "mapping/additionalTargetRetailsScanBakeryList";

							$http.post(listResults, $scope.rogDetailsPassing, config)
								.then(function (response) {
									//function handles success condition
									if (response.data) {
										$scope.rogDetailsObtained = response.data;
										//							document.getElementById("testbuyingrog_" + index).innerHTML = response.data.rogCount;
										var idNo = document.getElementById("testbuyingrog_" + index);
										idNo = response.data.rogCount;
										$scope.rogBuy_count = idNo;
										if (response.data.rogCount > 0)
											$("#buyROGlist_" + index).show();
									}
								}, function (response1) {
									//function handles error condition
								});
						};
						$scope.closeBuyROG = function (index) {
							$("#buyROGlist_" + index).hide();
						};

						/**
						 * U62615
						 * open action for ROG count display
						 */
						$scope.openSellROG = function (index, cicval) {

							$scope.rogDetailsPassing = cicval;
							$scope.rogDetailsObtained = [];

							var listResults = $scope.baseUrl + "mapping/additionalTargetRetailsScanBakeryList";

							$http.post(listResults, $scope.rogDetailsPassing, config)
								.then(function (response) {
									//function handles success condition
									if (response.data) {
										$scope.rogDetailsObtained = response.data;
										//							document.getElementById("testsellingrog_" + index).innerHTML = response.data.rogCount;
										var idNo = document.getElementById("testsellingrog_" + index);
										idNo = response.data.rogCount;
										$scope.rogSell_count = idNo;
										if (response.data.rogCount > 0)
											$("#sellROGlist_" + index).show();
									}
								}, function (response1) {
									//function handles error condition
								});
						};
						$scope.closeSellROG = function (index) {
							$("#sellROGlist_" + index).hide();
						};

						/**
						 * Change the shelf life count
						 */
						$scope.changeMapBuyDaysCount = function () {
							var selldays = Number($scope.editbuy_selldt);
							if (selldays) {
								$scope.editbuy_usedt = selldays + 1;
								$scope.editbuy_pulldt = selldays;
							}
						};

						/**
						 * Change the shelf life count
						 */
						$scope.changeMapSellDaysCount = function () {
							var selldays = Number($scope.editsell_selldt);
							if (selldays) {
								$scope.editsell_usedt = selldays + 1;
								$scope.editsell_pulldt = selldays;
							}
						};

						/**
						 *  U63178
						 *  Open PLU popup for mapping
						 */
						$scope.additionalBakPLUpopup = function (type) {
							if ($scope.markedBuyingCICs && $scope.markedBuyingCICs.length == 1 &&
								$scope.markedSellingCICs && $scope.markedSellingCICs.length == 1) {
								$scope.editbk_skus = [];
								$scope.enableCheckbox = false;
								$scope.editbuy_dcPackDesc = "";
								$scope.editbuy_dcSizeDesc = "";
								$scope.editbuy_autoCostInv = "";
								$scope.editbuy_billingType = "";
								$scope.editbuy_buyerNum = "";
								$scope.editbuy_dstCntr = "";
								$scope.editbuy_handlingCode = "";
								$scope.editbuy_randomWtCd = "";
								$scope.editbuy_costall = "";
								$scope.editbuy_costib = "";
								$scope.editbuy_costinv = "";
								$scope.editbuy_costven = "";
								$scope.editbuy_shelfLife = "";
								$scope.editbuy_selldt = "";
								$scope.editbuy_usedt = "";
								$scope.editbuy_pulldt = "";
								$scope.editbuy_hicone = "";
								$scope.editbuy_rup = "";
								$scope.editbuy_ring = "";
								$scope.editbuy_foodstamp = "";
								$scope.editbuy_tagNo = "";
								$scope.editbuy_tagSize = "";
								$scope.editbuy_tareCd = "";
								$scope.editbuy_sgncount1 = "";
								$scope.editbuy_sgncount2 = "";
								$scope.editbuy_sgncount3 = "";
								$scope.editbuy_prodWt = "";

								$scope.editsell_dcPackDesc = "";
								$scope.editsell_dcSizeDesc = "";
								$scope.editsell_autoCostInv = "";
								$scope.editsell_billingType = "";
								$scope.editsell_buyerNum = "";
								$scope.editsell_dstCntr = "";
								$scope.editsell_handlingCode = "";
								$scope.editsell_randomWtCd = "";
								$scope.editsell_costall = "";
								$scope.editsell_costib = "";
								$scope.editsell_costinv = "";
								$scope.editsell_costven = "";
								$scope.editsell_shelfLife = "";
								$scope.editsell_selldt = "";
								$scope.editsell_usedt = "";
								$scope.editsell_pulldt = "";
								$scope.editsell_hicone = "";
								$scope.editsell_rup = "";
								$scope.editsell_ring = "";
								$scope.editsell_foodstamp = "";
								$scope.editsell_tagNo = "";
								$scope.editsell_tagSize = "";
								$scope.editsell_tareCd = "";
								$scope.editsell_sgncount1 = "";
								$scope.editsell_sgncount2 = "";
								$scope.editsell_sgncount3 = "";
								$scope.editsell_prodWt = "";

								var loadOnMapURL = $scope.baseUrl + "mapping/loadOnMapEditFields";
								var loadRequest = {};

								loadRequest.companyId = service.selectedCompany.companyID;
								loadRequest.divisionId = service.selectedDivision.divisionID;
								loadRequest.buyingCic = $scope.markedBuyingCICs[0].cic;
								loadRequest.sellingCic = $scope.markedSellingCICs[0].cic;
								loadRequest.whseDsd = $scope.markedSKUs[0].absDSDWhse;
								loadRequest.productSKUs = [];
								loadRequest.productSKUs.push($scope.markedSKUs[0].sku);

								$scope.editbuy_cic = $scope.markedBuyingCICs[0].cic;
								$scope.editbuy_cicDesc = $scope.markedBuyingCICs[0].itemDesc;
								$scope.editsell_cic = $scope.markedSellingCICs[0].cic;
								$scope.editsell_cicDesc = $scope.markedSellingCICs[0].itemDesc;

								for (var i = 0; i < $scope.markedSKUs.length; i++) {
									$scope.editbk_skus.push($scope.markedSKUs[i].sku + ' / ' + $scope.markedSKUs[i].itemDesc);
								}

								$http.post(loadOnMapURL, loadRequest, config)
									.then(function (response) {
										//function handles success condition
										if (response.data) {
											if (response.data.buyDto) {
												$scope.editbuy_sizeDetails = [];
												$scope.editbuy_rogDetails = [];
												$scope.editbuy_sourceWeight = [];
												for (var i = 0; i < response.data.buyDto.sizeDetails.length; i++) {
													var sizd = response.data.buyDto.sizeDetails[i].dstCntr + " - " + response.data.buyDto.sizeDetails[i].dcPackDesc + " - " + response.data.buyDto.sizeDetails[i].dcSizeDesc;
													$scope.editbuy_sizeDetails.push(sizd);
													if (i == 0) {
														$scope.editbuy_dcPackDesc = response.data.buyDto.sizeDetails[0].dcPackDesc.toString();
														$scope.editbuy_dcSizeDesc = response.data.buyDto.sizeDetails[0].dcSizeDesc.toString();
														$scope.editbuy_autoCostInv = response.data.buyDto.sizeDetails[0].autoCostInv.toString();
														$scope.editbuy_billingType = response.data.buyDto.sizeDetails[0].billingType.toString();
														$scope.editbuy_buyerNum = response.data.buyDto.sizeDetails[0].buyerNum.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_dstCntr = response.data.buyDto.sizeDetails[0].dstCntr.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_handlingCode = response.data.buyDto.sizeDetails[0].handlingCode.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_randomWtCd = response.data.buyDto.sizeDetails[0].randomWtCd.toString();
														$scope.editbuy_costall = response.data.buyDto.sizeDetails[0].costAllow.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_costib = response.data.buyDto.sizeDetails[0].costIb.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_costinv = response.data.buyDto.sizeDetails[0].costInv.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_costven = response.data.buyDto.sizeDetails[0].costVendor.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_shelfLife = response.data.buyDto.sizeDetails[0].shelfLife.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_selldt = Number(response.data.buyDto.sizeDetails[0].shelfLife);
														$scope.editbuy_usedt = (Number(response.data.buyDto.sizeDetails[0].shelfLife) + 1);
														$scope.editbuy_pulldt = Number(response.data.buyDto.sizeDetails[0].shelfLife);
														$scope.editbuy_prcFlag = response.data.buyDto.sizeDetails[0].prcTypeCd.toString().replace(/^\s+|\s+$/gm, '');
													}
												}

												for (var j = 0; j < response.data.buyDto.rogDetail.length; j++) {
													var rogd = response.data.buyDto.rogDetail[j];
													var arrnaming = Object.keys(rogd);
													var val = rogd[arrnaming[0]].rog + " - " + rogd[arrnaming[0]].retailUnitPack + " - " + rogd[arrnaming[0]].ring + " - " + rogd[arrnaming[0]].hicone;
													$scope.editbuy_rogDetails.push(val);
													if (rogd[arrnaming[0]].topRank == true) {
														$scope.editbuy_hicone = rogd[arrnaming[0]].hicone.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_rup = rogd[arrnaming[0]].retailUnitPack.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_ring = rogd[arrnaming[0]].ring.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_foodstamp = rogd[arrnaming[0]].foodStamp.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_tagNo = rogd[arrnaming[0]].tagNumber.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_tagSize = rogd[arrnaming[0]].tagSize.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_tareCd = rogd[arrnaming[0]].tareCd.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_sgncount1 = rogd[arrnaming[0]].sgnCount1.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_sgncount2 = rogd[arrnaming[0]].sgnCount2.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editbuy_sgncount3 = rogd[arrnaming[0]].sgnCount3.toString().replace(/^\s+|\s+$/gm, '');
													}
												}

												for (var i = 0; i < response.data.buyDto.sourceWieght.length; i++) {
													var wtd = response.data.buyDto.sourceWieght[i].prodWt;
													$scope.editbuy_sourceWeight.push(wtd);
													if (i == 0) {
														$scope.editbuy_prodWt = response.data.buyDto.sourceWieght[0].prodWt.toString().replace(/^\s+|\s+$/gm, '');
													}
												}
											}
											if (response.data.sellDto == null) {
												response.data.sellDto = response.data.buyDto;
											}
											if (response.data.sellDto) {
												$scope.editsell_sizeDetails = [];
												$scope.editsell_rogDetails = [];
												$scope.editsell_sourceWeight = [];
												for (var i = 0; i < response.data.sellDto.sizeDetails.length; i++) {
													var sizsd = response.data.sellDto.sizeDetails[i].dstCntr + " - " + response.data.sellDto.sizeDetails[i].dcPackDesc + " - " + response.data.sellDto.sizeDetails[i].dcSizeDesc;
													$scope.editsell_sizeDetails.push(sizsd);
													if (i == 0) {
														$scope.editsell_dcPackDesc = response.data.sellDto.sizeDetails[0].dcPackDesc.toString();
														$scope.editsell_dcSizeDesc = response.data.sellDto.sizeDetails[0].dcSizeDesc.toString();
														$scope.editsell_autoCostInv = response.data.sellDto.sizeDetails[0].autoCostInv.toString();
														$scope.editsell_billingType = response.data.sellDto.sizeDetails[0].billingType.toString();
														$scope.editsell_buyerNum = response.data.sellDto.sizeDetails[0].buyerNum.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_dstCntr = response.data.sellDto.sizeDetails[0].dstCntr.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_handlingCode = response.data.sellDto.sizeDetails[0].handlingCode.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_randomWtCd = response.data.sellDto.sizeDetails[0].randomWtCd.toString();
														$scope.editsell_costall = response.data.sellDto.sizeDetails[0].costAllow.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_costib = response.data.sellDto.sizeDetails[0].costIb.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_costinv = response.data.sellDto.sizeDetails[0].costInv.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_costven = response.data.sellDto.sizeDetails[0].costVendor.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_shelfLife = response.data.sellDto.sizeDetails[0].shelfLife.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_selldt = Number(response.data.sellDto.sizeDetails[0].shelfLife);
														$scope.editsell_usedt = (Number(response.data.sellDto.sizeDetails[0].shelfLife) + 1);
														$scope.editsell_pulldt = Number(response.data.sellDto.sizeDetails[0].shelfLife);
														$scope.editsell_prcFlag = response.data.sellDto.sizeDetails[0].prcTypeCd.toString().replace(/^\s+|\s+$/gm, '');
													}
												}

												for (var j = 0; j < response.data.sellDto.rogDetail.length; j++) {
													var rogd = response.data.sellDto.rogDetail[j];
													var arrnaming = Object.keys(rogd);
													var val = rogd[arrnaming[0]].rog + " - " + rogd[arrnaming[0]].retailUnitPack + " - " + rogd[arrnaming[0]].ring + " - " + rogd[arrnaming[0]].hicone;
													$scope.editsell_rogDetails.push(val);
													if (rogd[arrnaming[0]].topRank == true) {
														$scope.editsell_hicone = rogd[arrnaming[0]].hicone.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_rup = rogd[arrnaming[0]].retailUnitPack.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_ring = rogd[arrnaming[0]].ring.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_foodstamp = rogd[arrnaming[0]].foodStamp.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_tagNo = rogd[arrnaming[0]].tagNumber.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_tagSize = rogd[arrnaming[0]].tagSize.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_tareCd = rogd[arrnaming[0]].tareCd.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_sgncount1 = rogd[arrnaming[0]].sgnCount1.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_sgncount2 = rogd[arrnaming[0]].sgnCount2.toString().replace(/^\s+|\s+$/gm, '');
														$scope.editsell_sgncount3 = rogd[arrnaming[0]].sgnCount3.toString().replace(/^\s+|\s+$/gm, '');
													}
												}

												for (var i = 0; i < response.data.sellDto.sourceWieght.length; i++) {
													var wtd = response.data.sellDto.sourceWieght[i].prodWt;
													$scope.editsell_sourceWeight.push(wtd);
													if (i == 0) {
														$scope.editsell_prodWt = response.data.sellDto.sourceWieght[0].prodWt.toString().replace(/^\s+|\s+$/gm, '');
													}
												}
											}
											$scope.markedBkPLUs = [];
											if (type == "ADDMAP") {
												for (var i = 0; i < $scope.markedSKUs.length; i++) {
													for (var j = 0; j < $scope.markedSKUs[i].upc.length; j++) {
														if ($scope.markedSKUs[i].upc[j] <= 99999 && $scope.markedBkPLUs.indexOf($scope.markedSKUs[i].upc[j])) {
															$scope.markedBkPLUs.push($scope.markedSKUs[i].upc[j]);
														}
													}
												}

												if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
													for (var k = 0; k < $scope.unselectedMapRequests.length; k++) {
														for (var l = 0; l < $scope.markedBkPLUs.length; l++) {
															if ($scope.unselectedMapRequests[k].upc == $scope.markedBkPLUs[l]) {
																$scope.markedBkPLUs.splice(l, 1);
															}
														}
													}
												}
											}

											document.getElementById('editbuy_dcPackDescID').style.removeProperty('border');
											document.getElementById('editbuy_dcSizeDescID').style.removeProperty('border');
											document.getElementById('editbuy_rupID').style.removeProperty('border');
											document.getElementById('editbuy_ringID').style.removeProperty('border');
											document.getElementById('editbuy_hiconeID').style.removeProperty('border');
											document.getElementById('editbuy_handlingCodeID').style.removeProperty('border');
											document.getElementById('editbuy_buyerNumID').style.removeProperty('border');
											document.getElementById('editbuy_randomWtCdID').style.removeProperty('border');
											document.getElementById('editbuy_autoCostInvID').style.removeProperty('border');
											document.getElementById('editbuy_billingTypeID').style.removeProperty('border');
											document.getElementById('editbuy_foodstampID').style.removeProperty('border');
											document.getElementById('editbuy_tareCdID').style.removeProperty('border');
											document.getElementById('editbuy_tagSizeID').style.removeProperty('border');
											document.getElementById('editbuy_tagNoID').style.removeProperty('border');
											document.getElementById('editbuy_sgncount1ID').style.removeProperty('border');
											document.getElementById('editbuy_sgncount2ID').style.removeProperty('border');
											document.getElementById('editbuy_sgncount3ID').style.removeProperty('border');
											document.getElementById('editbuy_prcFlagID').style.removeProperty('border');
											document.getElementById('editbuy_costallID').style.removeProperty('border');
											document.getElementById('editbuy_costibID').style.removeProperty('border');
											document.getElementById('editbuy_costinvID').style.removeProperty('border');
											document.getElementById('editbuy_costvenID').style.removeProperty('border');
											document.getElementById('editbuy_selldtID').style.removeProperty('border');
											document.getElementById('editbuy_usedtID').style.removeProperty('border');
											document.getElementById('editbuy_pulldtID').style.removeProperty('border');

											document.getElementById('editsell_dcPackDescID').style.removeProperty('border');
											document.getElementById('editsell_dcSizeDescID').style.removeProperty('border');
											document.getElementById('editsell_rupID').style.removeProperty('border');
											document.getElementById('editsell_ringID').style.removeProperty('border');
											document.getElementById('editsell_hiconeID').style.removeProperty('border');
											document.getElementById('editsell_handlingCodeID').style.removeProperty('border');
											document.getElementById('editsell_buyerNumID').style.removeProperty('border');
											document.getElementById('editsell_randomWtCdID').style.removeProperty('border');
											document.getElementById('editsell_autoCostInvID').style.removeProperty('border');
											document.getElementById('editsell_billingTypeID').style.removeProperty('border');
											document.getElementById('editsell_foodstampID').style.removeProperty('border');
											document.getElementById('editsell_tareCdID').style.removeProperty('border');
											document.getElementById('editsell_tagSizeID').style.removeProperty('border');
											document.getElementById('editsell_tagNoID').style.removeProperty('border');
											document.getElementById('editsell_sgncount1ID').style.removeProperty('border');
											document.getElementById('editsell_sgncount2ID').style.removeProperty('border');
											document.getElementById('editsell_sgncount3ID').style.removeProperty('border');
											document.getElementById('editsell_prcFlagID').style.removeProperty('border');
											document.getElementById('editsell_costallID').style.removeProperty('border');
											document.getElementById('editsell_costibID').style.removeProperty('border');
											document.getElementById('editsell_costinvID').style.removeProperty('border');
											document.getElementById('editsell_costvenID').style.removeProperty('border');
											document.getElementById('editsell_selldtID').style.removeProperty('border');
											document.getElementById('editsell_usedtID').style.removeProperty('border');
											document.getElementById('editsell_pulldtID').style.removeProperty('border');

											$("#plubakupload").modal("show");
											for (var k = 0; k < $scope.markedBkPLUs.length; k++) {
												if (document.getElementById('tgtBkPLU_' + k)) {
													document.getElementById('tgtBkPLU_' + k).value = "";
													document.getElementById('tgtBkPLU_' + k).style.removeProperty('border');
												}
											}
										}
									}, function (response1) {
										//function handles error condition
									});
							} else {
								alertify.alert("Select item from SKU, Buying CIC and Selling CIC to proceed.");
								return;
							}
						};

						/**
						 *  U63178
						 *  Submission on PLU popup
						 */
						$scope.mappingWithbkPLU = function () {
							var errorDetected = false;
							var pluBuyRequest = [];
							var pluSellRequest = [];

							if ($scope.finalRequests.length > 0) {
								pluBuyRequest = $scope.finalRequests;
							} else {
								pluBuyRequest = $scope.buyingMappingRequests;
							}
							pluSellRequest = $scope.sellingMappingRequests;

							if (pluBuyRequest) {
								if (!$scope.editbuy_dcPackDesc) {
									document.getElementById('editbuy_dcPackDescID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_dcPackDescID').style.removeProperty('border');
								}
								if (!$scope.editbuy_dcSizeDesc) {
									document.getElementById('editbuy_dcSizeDescID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_dcSizeDescID').style.removeProperty('border');
								}
								if (!$scope.editbuy_rup) {
									document.getElementById('editbuy_rupID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_rupID').style.removeProperty('border');
								}
								if (!$scope.editbuy_ring) {
									document.getElementById('editbuy_ringID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_ringID').style.removeProperty('border');
								}
								if (!$scope.editbuy_hicone) {
									document.getElementById('editbuy_hiconeID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_hiconeID').style.removeProperty('border');
								}
								if (!$scope.editbuy_prodWt) {
									document.getElementById('editbuy_prodWtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_prodWtID').style.removeProperty('border');
								}
								if (!$scope.editbuy_handlingCode) {
									document.getElementById('editbuy_handlingCodeID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_handlingCodeID').style.removeProperty('border');
								}
								if (!$scope.editbuy_buyerNum) {
									document.getElementById('editbuy_buyerNumID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_buyerNumID').style.removeProperty('border');
								}
								if (!$scope.editbuy_autoCostInv) {
									document.getElementById('editbuy_autoCostInvID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_autoCostInvID').style.removeProperty('border');
								}
								if (!$scope.editbuy_foodstamp) {
									document.getElementById('editbuy_foodstampID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_foodstampID').style.removeProperty('border');
								}
								if (!$scope.editbuy_tareCd) {
									document.getElementById('editbuy_tareCdID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_tareCdID').style.removeProperty('border');
								}
								if (!$scope.editbuy_tagSize) {
									document.getElementById('editbuy_tagSizeID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_tagSizeID').style.removeProperty('border');
								}
								if (!$scope.editbuy_tagNo) {
									document.getElementById('editbuy_tagNoID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_tagNoID').style.removeProperty('border');
								}
								if (!$scope.editbuy_sgncount1 || !$scope.editbuy_sgncount2 || !$scope.editbuy_sgncount3) {
									document.getElementById('editbuy_sgncount1ID').style.borderColor = "red";
									document.getElementById('editbuy_sgncount2ID').style.borderColor = "red";
									document.getElementById('editbuy_sgncount3ID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_sgncount1ID').style.removeProperty('border');
									document.getElementById('editbuy_sgncount2ID').style.removeProperty('border');
									document.getElementById('editbuy_sgncount3ID').style.removeProperty('border');
								}
								if (!$scope.editbuy_prcFlag) {
									document.getElementById('editbuy_prcFlagID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_prcFlagID').style.removeProperty('border');
								}
								if (!$scope.editbuy_costall) {
									document.getElementById('editbuy_costallID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_costallID').style.removeProperty('border');
								}
								if (!$scope.editbuy_costib) {
									document.getElementById('editbuy_costibID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_costibID').style.removeProperty('border');
								}
								if (!$scope.editbuy_costinv) {
									document.getElementById('editbuy_costinvID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_costinvID').style.removeProperty('border');
								}
								if (!$scope.editbuy_costven) {
									document.getElementById('editbuy_costvenID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_costvenID').style.removeProperty('border');
								}
								if ($scope.editbuy_selldt === "") {
									document.getElementById('editbuy_selldtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_selldtID').style.removeProperty('border');
								}
								if ($scope.editbuy_usedt === "") {
									document.getElementById('editbuy_usedtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_usedtID').style.removeProperty('border');
								}
								if ($scope.editbuy_pulldt === "") {
									document.getElementById('editbuy_pulldtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editbuy_pulldtID').style.removeProperty('border');
								}

								if (!$scope.editsell_dcPackDesc) {
									document.getElementById('editsell_dcPackDescID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_dcPackDescID').style.removeProperty('border');
								}
								if (!$scope.editsell_dcSizeDesc) {
									document.getElementById('editsell_dcSizeDescID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_dcSizeDescID').style.removeProperty('border');
								}
								if (!$scope.editsell_rup) {
									document.getElementById('editsell_rupID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_rupID').style.removeProperty('border');
								}
								if (!$scope.editsell_ring) {
									document.getElementById('editsell_ringID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_ringID').style.removeProperty('border');
								}
								if (!$scope.editsell_hicone) {
									document.getElementById('editsell_hiconeID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_hiconeID').style.removeProperty('border');
								}
								if (!$scope.editsell_prodWt) {
									document.getElementById('editsell_prodWtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_prodWtID').style.removeProperty('border');
								}
								if (!$scope.editsell_handlingCode) {
									document.getElementById('editsell_handlingCodeID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_handlingCodeID').style.removeProperty('border');
								}
								if (!$scope.editsell_buyerNum) {
									document.getElementById('editsell_buyerNumID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_buyerNumID').style.removeProperty('border');
								}
								if (!$scope.editsell_autoCostInv) {
									document.getElementById('editsell_autoCostInvID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_autoCostInvID').style.removeProperty('border');
								}
								if (!$scope.editsell_foodstamp) {
									document.getElementById('editsell_foodstampID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_foodstampID').style.removeProperty('border');
								}
								if (!$scope.editsell_tareCd) {
									document.getElementById('editsell_tareCdID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_tareCdID').style.removeProperty('border');
								}
								if (!$scope.editsell_tagSize) {
									document.getElementById('editsell_tagSizeID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_tagSizeID').style.removeProperty('border');
								}
								if (!$scope.editsell_tagNo) {
									document.getElementById('editsell_tagNoID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_tagNoID').style.removeProperty('border');
								}
								if (!$scope.editsell_sgncount1 || !$scope.editsell_sgncount2 || !$scope.editsell_sgncount3) {
									document.getElementById('editsell_sgncount1ID').style.borderColor = "red";
									document.getElementById('editsell_sgncount2ID').style.borderColor = "red";
									document.getElementById('editsell_sgncount3ID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_sgncount1ID').style.removeProperty('border');
									document.getElementById('editsell_sgncount2ID').style.removeProperty('border');
									document.getElementById('editsell_sgncount3ID').style.removeProperty('border');
								}
								if (!$scope.editsell_prcFlag) {
									document.getElementById('editsell_prcFlagID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_prcFlagID').style.removeProperty('border');
								}
								if (!$scope.editsell_costall) {
									document.getElementById('editsell_costallID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_costallID').style.removeProperty('border');
								}
								if (!$scope.editsell_costib) {
									document.getElementById('editsell_costibID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_costibID').style.removeProperty('border');
								}
								if (!$scope.editsell_costinv) {
									document.getElementById('editsell_costinvID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_costinvID').style.removeProperty('border');
								}
								if (!$scope.editsell_costven) {
									document.getElementById('editsell_costvenID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_costvenID').style.removeProperty('border');
								}
								if ($scope.editsell_selldt === "") {
									document.getElementById('editsell_selldtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_selldtID').style.removeProperty('border');
								}
								if ($scope.editsell_usedt === "") {
									document.getElementById('editsell_usedtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_usedtID').style.removeProperty('border');
								}
								if ($scope.editsell_pulldt === "") {
									document.getElementById('editsell_pulldtID').style.borderColor = "red";
									errorDetected = true;
								} else {
									document.getElementById('editsell_pulldtID').style.removeProperty('border');
								}

								if ($scope.markedBkPLUs && $scope.markedBkPLUs.length > 0) {
									angular.forEach(pluSellRequest, function (mapSelReq) {
										if (mapSelReq && mapSelReq.mappingType != "MARK_AS_DEAD") {
											for (var i = 0; i < $scope.markedBkPLUs.length; i++) {
												if (mapSelReq.upc == $scope.markedBkPLUs[i]) {
													if (document.getElementById('tgtBkPLU_' + i).value != "" && document.getElementById('tgtBkPLU_' + i).value.length < 6) {
														mapSelReq.targetPLU = document.getElementById('tgtBkPLU_' + i).value;
														document.getElementById('tgtBkPLU_' + i).style.removeProperty('border');
													} else {
														mapSelReq.targetPLU = null;
														document.getElementById('tgtBkPLU_' + i).style.borderColor = "red";
														errorDetected = true;
													}
												}
											}
										}
									});

									$scope.fromMarkAsdead = false;
									$scope.addBkPLU = false;
								}
								if (errorDetected == true)
									return;

								angular.forEach(pluBuyRequest, function (mapReq) {
									if (mapReq && mapReq.mappingType != "MARK_AS_DEAD") {
										mapReq.targetEdited = true;
										mapReq.dcPackDesc = $scope.editbuy_dcPackDesc;
										mapReq.dcSizeDsc = $scope.editbuy_dcSizeDesc;
										mapReq.retailUnitPack = $scope.editbuy_rup;
										mapReq.ring = $scope.editbuy_ring;
										mapReq.hicone = $scope.editbuy_hicone;
										mapReq.autoCostInv = $scope.editbuy_autoCostInv;
										mapReq.billingType = $scope.editbuy_billingType;
										mapReq.buyerNum = $scope.editbuy_buyerNum;
										mapReq.prcTypeCd = $scope.editbuy_prcFlag;
										mapReq.handlingCode = $scope.editbuy_handlingCode;
										mapReq.randomWtCd = $scope.editbuy_randomWtCd;
										mapReq.costAllow = $scope.editbuy_costall;
										mapReq.costIb = $scope.editbuy_costib;
										mapReq.costInv = $scope.editbuy_costinv;
										mapReq.costVend = $scope.editbuy_costven;
										mapReq.sellByDays = $scope.editbuy_selldt;
										mapReq.useByDays = $scope.editbuy_usedt;
										mapReq.pullBydays = $scope.editbuy_pulldt;
										mapReq.fdStmp = $scope.editbuy_foodstamp;
										mapReq.labelNumbers = $scope.editbuy_tagNo;
										mapReq.labelSize = $scope.editbuy_tagSize;
										mapReq.tareCd = $scope.editbuy_tareCd;
										mapReq.sgnCount1 = $scope.editbuy_sgncount1;
										mapReq.sgnCount2 = $scope.editbuy_sgncount2;
										mapReq.sgnCount3 = $scope.editbuy_sgncount3;
										mapReq.prodwght = $scope.editbuy_prodWt;
									}
								});
								angular.forEach(pluSellRequest, function (mapReq) {
									if (mapReq && mapReq.mappingType != "MARK_AS_DEAD") {
										mapReq.targetEdited = true;
										mapReq.dcPackDesc = $scope.editsell_dcPackDesc;
										mapReq.dcSizeDsc = $scope.editsell_dcSizeDesc;
										mapReq.retailUnitPack = $scope.editsell_rup;
										mapReq.ring = $scope.editsell_ring;
										mapReq.hicone = $scope.editsell_hicone;
										mapReq.autoCostInv = $scope.editsell_autoCostInv;
										mapReq.billingType = $scope.editsell_billingType;
										mapReq.buyerNum = $scope.editsell_buyerNum;
										mapReq.prcTypeCd = $scope.editsell_prcFlag;
										mapReq.handlingCode = $scope.editsell_handlingCode;
										mapReq.randomWtCd = $scope.editsell_randomWtCd;
										mapReq.costAllow = $scope.editsell_costall;
										mapReq.costIb = $scope.editsell_costib;
										mapReq.costInv = $scope.editsell_costinv;
										mapReq.costVend = $scope.editsell_costven;
										mapReq.sellByDays = $scope.editsell_selldt;
										mapReq.useByDays = $scope.editsell_usedt;
										mapReq.pullBydays = $scope.editsell_pulldt;
										mapReq.fdStmp = $scope.editsell_foodstamp;
										mapReq.labelNumbers = $scope.editsell_tagNo;
										mapReq.labelSize = $scope.editsell_tagSize;
										mapReq.tareCd = $scope.editsell_tareCd;
										mapReq.sgnCount1 = $scope.editsell_sgncount1;
										mapReq.sgnCount2 = $scope.editsell_sgncount2;
										mapReq.sgnCount3 = $scope.editsell_sgncount3;
										mapReq.prodwght = $scope.editsell_prodWt;
									}
								});
								$("#plubakupload").modal("hide");
								$scope.action(pluBuyRequest, pluSellRequest);
							};
						};
					});
				});
			}
		}
	]);

})();