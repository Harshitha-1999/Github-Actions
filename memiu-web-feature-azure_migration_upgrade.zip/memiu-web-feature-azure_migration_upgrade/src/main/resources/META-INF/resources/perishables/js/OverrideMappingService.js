(function(){
	'use strict';
	
	myApp.service('OverrideMappingService', function() {
		
		var savedDeptName="";
		var savedDeptCode="";
		var savedCompanyID="";
		var savedDivisionID="";
		var savedProductSku="";
		var savedDisplayFlag="";
		var savedStatus="";
		var savedType="";
		var savedKey="";
		var savedUsageType="";
		
		var setDeptName = function(deptName){
			savedDeptName = deptName;
		};
		
		var getDeptName = function(){
			return savedDeptName;
		};
		
	    var setDeptCode = function(deptcode) {
	    	savedDeptCode = deptcode;
	    };

	    var getDeptCode = function(){
	        return savedDeptCode;
	    };
	    
	    var setCompanyID = function(companyid) {
	    	savedCompanyID = companyid;
	    };

	    var getCompanyID = function(){
	        return savedCompanyID;
	    };
	    
	    var setDivisionID = function(divisionid) {
	    	savedDivisionID = divisionid;
	    };

	    var getDivisionID = function(){
	        return savedDivisionID;
	    };
	    
	    var setProductSku = function(productsku) {
	    	savedProductSku = productsku;
	    };

	    var getProductSku = function(){
	        return savedProductSku;
	    };
	    
	    var setDisplayFlag = function(displayflag) {
	    	savedDisplayFlag = displayflag;
	    };

	    var getDisplayFlag = function(){
	        return savedDisplayFlag;
	    };
	    
	    var setStatus = function(status) {
	    	savedStatus = status;
	    };

	    var getStatus = function(){
	        return savedStatus;
	    };
	    
	    var setType = function(type) {
	    	savedType = type;
	    };

	    var getType = function(){
	        return savedType;
	    };
	    
	    var setKey = function(key) {
	    	savedKey = key;
	    };

	    var getKey = function(){
	        return savedKey;
	    };
	    
	    var setUsageType = function(usage) {
	    	savedUsageType = usage;
	    };

	    var getUsageType = function(){
	        return savedUsageType;
	    };
	    
	    return {
	    	setDeptName : setDeptName,
	    	getDeptName : getDeptName,
	    	setDeptCode : setDeptCode,
	    	getDeptCode : getDeptCode,
	    	setCompanyID : setCompanyID,
	    	getCompanyID : getCompanyID,
	    	setDivisionID : setDivisionID,
	    	getDivisionID : getDivisionID,
	    	setProductSku : setProductSku,
	    	getProductSku : getProductSku,
	    	setDisplayFlag : setDisplayFlag,
	    	getDisplayFlag : getDisplayFlag,
	    	setStatus : setStatus,
	    	getStatus : getStatus,
	    	setType : setType,
	    	getType : getType,
	    	setKey : setKey,
	    	getKey : getKey,
	    	setUsageType : setUsageType,
	    	getUsageType : getUsageType
	    };
	});
	
})();