(function () {
	'use strict';
	myApp.factory('PagerMService', PagerMService),
		myApp.controller('MappingController', ['$scope', '$http', '$location', '$document', 'blockUI', 'service', 'AugmentedDisplayerService', 'OverrideMappingService', '$timeout', 'PagerMService',
			function MappingController($scope, $http, $location, $document, blockUI, service, AugmentedDisplayerService, OverrideMappingService, $timeout, PagerMService) {

				$scope.displayMappingpage = false;
				$scope.displayTargetAlert = true;
				$scope.displaySourceAlert = true;
				$scope.displayTargetNoResult = false;
				$scope.displaySourceNoResult = false;
				$scope.postSourceFilterVal = {};
				$scope.postTargetFilterVal = {};
				$scope.lastSourceDepartment = null;
				$scope.lastTargetDepartment = null;
				$scope.sourceFilterApplied = false;
				$scope.targetFilterApplied = false;
				$scope.searchSourceRequest = {};
				$scope.markedSKUs = [];
				$scope.markedCICs = [];
				$scope.paginate = this;
				$scope.sortOrder = {
					name: 'A'
				};

				//Variables for sorting.
				var skuSortBySku = 'sku/1';
				var skuSortByItemDesc = '-itemDesc';
				var skuSortByVcf = '-vcf';
				var skuSortByPack = '-pack';
				var skuSortByUpc = '-upc';

				var cicSortByCic = 'cic/1';
				var cicSortByItemDesc = '-itemDesc';
				var cicSortByVcf = '-vcf';
				var cicSortByPack = '-pack';
				var cicSortByUpc = '-upc';


				
				if (service.baseUrlFunction() != undefined) {
					service.baseUrlFunction().then(function (url) {
						$scope.baseUrl = url;

						service.getHeaders().then(function (header) {
							var config = header
							//      });
					$('[data-toggle="expandedView"]').tooltip();

					//Set default 'sort by' value for CIC and SKU list	
					$scope.skuSortVal = null;
					$scope.cicSortVal = cicSortByCic;
					var windowHeight = $(window).innerHeight();
					$('.skuScrollDiv').css('height', windowHeight - 270);
					$('.cicScrollDiv').css('height', windowHeight - 225);

					//CONTEXT-MENU restrict right click
					$(function () {
						$.contextMenu({
							selector: '.context-menu-source',
							callback: function (key, options) {
								$scope.redirectToFunction(key);
							},
							items: {
								"forcenew": {
									name: "Force New",
									icon: null
								},
								"letautomatch": {
									name: "Let Auto Match",
									icon: null
								},
								"markasdead": {
									name: "Mark as Dead",
									icon: null
								},
								"matchingtarget": {
									name: "Suggested CIC",
									icon: null
								},
								"reserve": {
									name: "Reserve",
									icon: null
								}
							}
						});

						$.contextMenu({
							selector: '.context-menu-target',
							callback: function (key, options) {
								$scope.redirectToFunction(key);
							},
							items: {
								"inheritmap": {
									name: "Inherit Map",
									icon: null
								},
								"addmap": {
									name: "Add Map",
									icon: null,
									disabled: function (key, opt) {
										// this references the trigger element
									}
								}
							}
						});
					});
					//CONTEXT-MENU restrict right click - END

					$scope.$watch('selectedCompany', function (value) {
						if (value) {
							if (value.companyID) {
								if ((value.companyID != service.selectedCompany.companyID) ||
									($scope.companyID && $scope.companyID != service.selectedCompany.companyID)) {
									service.mappingSourceSearch = null;
									service.mappingTargetSearch = null;
								}
								$scope.companyID = service.selectedCompany.companyID;
							} else {
								$scope.companyID = null;
							}
							$scope.displayMappingpage = false;
							$scope.displayTargetAlert = false;
							$scope.displaySourceAlert = false;
						}
					});
					$scope.$watch('selectedDivision', function (value) {
						if (value && value.divisionID) {
							if ((value.divisionID != service.selectedDivision.divisionID) ||
								($scope.divisionID && $scope.divisionID != service.selectedDivision.divisionID)) {
								service.mappingSourceSearch = null;
								service.mappingTargetSearch = null;
							}
							$scope.searchSourceRequest = {};
							$scope.searchTargetRequest = {};
							$scope.searchSourceRequest.companyID = $scope.companyID;
							if (service.selectedDivision.divisionID) {
								$scope.searchSourceRequest.divisionID = service.selectedDivision.divisionID;
								$scope.divisionID = service.selectedDivision.divisionID;
							} else {
								$scope.divisionID = null;
							}
							$scope.displayMappingpage = true;
							$scope.displayTargetAlert = true;
							$scope.displaySourceAlert = true;
							$scope.displayTargetNoResult = false;
							$scope.displaySourceNoResult = false;
							$scope.sourceFilterAppliedAfterPageDirect = false;
							$scope.targetFilterAppliedAfterPageDirect = false;

							$scope.SKUResult = [];
							$scope.CICResult = [];
							$scope.markedSKUs = [];
							$scope.markedCICs = [];
							$scope.disableCicChkBox = false;
							$scope.unselectedMapRequests = [];
							$scope.selectedMapRequests = [];
							$scope.finalRequests = [];
							$scope.mappingRequests = [];
							$scope.upcClicked = false;
							$scope.validateSourceAddMapFunc = false;
							$scope.sourceStatuses = [];
							$scope.targetStatuses = [];
							$scope.sourceSearchCriterias = [];
							$scope.targetSearchCriterias = [];
							$scope.departments = [];
							$scope.sourceColors = [];
							$scope.targetColors = [];
							$scope.returnLists = [];
							$scope.sourceCount = 0;
							$scope.sourceShowCount = 0;
							$scope.targetCount = 0;
							$scope.targetShowCount = 0;
							$scope.markedPlus = [];
							$scope.isSourceFilterApplied = "filterUnapplied";
							$scope.isTargetFilterApplied = "filterUnapplied";
							$scope.isSourceSorted = "filterUnapplied";
							$scope.selectedSourceSearchCriteria = "Select";
							$scope.selectedTargetSearchCriteria = "Select";
							$scope.selectedTargetSearchCriteriaValue = null;
							$scope.selectedSourceSearchCriteriaValue = null;
							$scope.paginate.pager = PagerMService.GetPager(0, 1);
							$scope.paginate.items = [];

							if ($scope.displayMappingpage == true) {
								////LOAD TARGET DATA
								$scope.searchTargetRequest.mappingStatus = 'SHOW_ALL';
								$scope.searchTargetRequest.filterAvail = false;
								$scope.searchTargetRequest.filter = {};

								////LOAD SOURCE DATA
								$scope.searchSourceRequest.mappingStatus = 'TO_BE_MAPPED';
								$scope.searchSourceRequest.filterAvail = false;
								$scope.searchSourceRequest.filter = {};

								$scope.selectedSourceStatus = "To be Mapped";
								$scope.colorSelectedSource = "bgBlue";
								$scope.selectedTargetStatus = "Show All";
								$scope.colorSelectedTarget = "bgYellow";
								$scope.sourceitemtype = "All";
							}
							$scope.sourceDepartments = [];
							$scope.sourceSearchCriteriaDepartments = [];
							$scope.setSourceDepartmentCriterias();

							$scope.targetDepartments = [];
							$scope.targetSearchCriteriaDepartments = [];
							$scope.setTargetDepartmentCriterias();

							/**
							 * U62615
							 * getting data like status/departments/search criterias from mapping.properties file and setting into variables
							 */
							$http.get('perishables/json/mapping-properties.json').then(function (response) {
								if (response && response.data) {
									$scope.sourceStatuses = response.data[0].sourceStatuses; //Filter by status values for source
									$scope.targetStatuses = response.data[0].targetStatuses; //Filter by status values for target
									$scope.sourceSearchCriterias = response.data[0].sourceSearchCriterias; //search criterias for source 
									$scope.targetSearchCriterias = response.data[0].targetSearchCriterias; //search criterias for target 
									$scope.departments = response.data[0].departments; // departments submenu values for source/target in search and filter
									$scope.sourceColors = response.data[0].sourceColors; // filter by status color values for source
									$scope.targetColors = response.data[0].targetColors; // filter by status color values for target

								}
							});
						} else {
							$scope.displayMappingpage = false;
							$scope.displayTargetAlert = false;
							$scope.displaySourceAlert = false;

						}
						if (service.mappingSourceSearch != null) {
							$scope.searchSourceRequest = {};
							$scope.searchSourceRequest.filter = {};
							$scope.searchSourceRequest = angular.copy(service.mappingSourceSearch);
							if (service.mappingSourceSearch.mappingStatus === "RESERVED") {
								$scope.selectedSourceStatus = "Reserved";
								$scope.colorSelectedSource = "bgLimeBlue";
							}

							$scope.sourceFilterAppliedAfterPageDirect = true;
							$timeout(function () {
								$scope.listSources($scope.searchSourceRequest);
							}, 3000);
						}

						$scope.resetSortModels();
					});

					$("#filterSoruceSectionExpand").hide();
					$("#filterTargetSectionExpand").hide();
					$("#sortSourceSectionExpand").hide();

					$("#filterSourceBy").click(function () {
						$("#filterSoruceSectionExpand").show();
					});

					$("#filterTargetBy").click(function () {
						$("#filterTargetSectionExpand").show();
					});

					$("#sortSourceBy").click(function () {
						$("#sortSourceSectionExpand").show();
					});

					$("#pluupload").modal("hide");

					$('.dropdown-submenu a.manualSubMenu').on("click", function (e) {
						$(this).next('ul').toggle();
						e.stopPropagation();
						e.preventDefault();
					});
				
				// init ends here

				/**
				*  U63178
				*  Reset Sort Order
				 */
				 $scope.resetSortModels = function () {
					$scope.sortmodels = [];
					$scope.sortOrder = {
						name: 'A'
					};
					$scope.isSourceSorted = "filterUnapplied";
					$scope.loadSortModels();
				};
				/**
							 *  U63178
							 *  Source Sort Order
							 */
				 $scope.loadSortModels = function () {
					$scope.sortmodels = [{
						listName: "A",
						items: [],
						dragging: false
					}];
					angular.forEach($scope.sortmodels, function (list) {
						for (var i = 0; i < 1; i++) {
							list.items.push({
								label: "Department",
								value: "DEPT"
							});
							list.items.push({
								label: "Hierarchy 1",
								value: "HIER1"
							});
							list.items.push({
								label: "Hierarchy 2",
								value: "HIER2"
							});
							list.items.push({
								label: "Hierarchy 3",
								value: "HIER3"
							});
							list.items.push({
								label: "Supplier",
								value: "SUPPL"
							});
							list.items.push({
								label: "Product SKU",
								value: "PSKU"
							});
							list.items.push({
								label: "Item Description",
								value: "ITDS"
							});
						}
					});
				};
				/**
				 * U62615
				 * Set Source Department Criteria
				 */
				
							$scope.setSourceDepartmentCriterias = function () {
								var sourceDepartmentsURL = $scope.baseUrl + "perishable/listDepartmentSource/" + $scope.companyID + "/" + $scope.divisionID;

								$http.get(sourceDepartmentsURL, config)
									.then(function (response) {
										//function handles success condition
										if (response.data) {
											$scope.sourceSearchCriteriaDepartments.push("Select");
											$scope.sourceDepartments = response.data;
											if ($scope.sourceDepartments) {
												angular.forEach($scope.sourceDepartments, function (dept) {
													if (dept) {
														var sourceDept = dept[1];
														$scope.sourceSearchCriteriaDepartments.push(sourceDept);
													}
												});
											}

										}
										$scope.selectedSourceFilterDepartment = $scope.sourceSearchCriteriaDepartments[0];

									}, function (response1) {
										//function handles error condition
									});

							};

							/**
							 * U62615
							 * Set Target Department Criteria
							 */
							$scope.setTargetDepartmentCriterias = function () {
								var targetDepartmentsURL = $scope.baseUrl + "perishable/listDepartmentTarget/" + $scope.companyID + "/" + $scope.divisionID;

								$http.get(targetDepartmentsURL, config)
									.then(function (response) {
										//function handles success condition
										if (response.data) {
											$scope.targetSearchCriteriaDepartments.push("Select");
											$scope.targetDepartments = response.data;
											if ($scope.targetDepartments) {
												angular.forEach($scope.targetDepartments, function (dept) {
													if (dept) {
														var targetDept = dept[0];
														$scope.targetSearchCriteriaDepartments.push(targetDept);
													}
												});
											}

										}
										$scope.selectedTargetFilterDepartment = $scope.targetSearchCriteriaDepartments[0];
									}, function (response1) {
										//function handles error condition
									});

							};


							/**
							 * U62615
							 * Common method to set itemType to default "All" in target side if no itemType selected after load
							 */
							$scope.setItemType = function (request) {
								if (!request.itemType) {
									request.itemType = {};
									request.itemType.all = true;
									request.itemType.system2 = false;
									request.itemType.system4 = false;
									request.itemType.plu = false;
								}
							};

							/**
							 * U62615
							 * Method to set the selected source/target status to search request 
							 */
							$scope.filterByStatus = function (status, color, type) {
								if (type == "source") {
									switch (status) {
										case 'To Be Mapped':
											$scope.searchSourceRequest.mappingStatus = "TO_BE_MAPPED";
											break;
										case 'Mark As Dead':
											$scope.searchSourceRequest.mappingStatus = "MARK_AS_DEAD";
											break;
										case 'Mapped':
											$scope.searchSourceRequest.mappingStatus = "MAPPED";
											break;
										case 'Force New':
											$scope.searchSourceRequest.mappingStatus = "FORCE_NEW";
											break;
										case 'Let Auto Match':
											$scope.searchSourceRequest.mappingStatus = "LET_AUTO_MATCH";
											break;
										case 'Show All':
											$scope.searchSourceRequest.mappingStatus = "SHOW_ALL";
											break;
										case 'Reserved':
											$scope.searchSourceRequest.mappingStatus = "RESERVED";
											break;
										default:
											$scope.searchSourceRequest.mappingStatus = "TO_BE_MAPPED";
									}
									$scope.selectedSourceStatus = status;
									$scope.colorSelectedSource = color;
									$scope.markedSKUs = [];
									$scope.setItemType($scope.searchSourceRequest); //setting itemType to default "All" in source side if no itemType selected after load
									if ($scope.selectedSourceSearchCriteria != "Department") {
										$scope.searchSourceRequest.searchCriteriaValue = $scope.selectedSourceSearchCriteriaValue;
									}
									service.mappingSourceSearch = $scope.searchSourceRequest;
									$scope.listSources($scope.searchSourceRequest);
								} else {
									switch (status) {
										case 'To Be Mapped':
											$scope.searchTargetRequest.mappingStatus = "TO_BE_MAPPED";
											break;
										case 'Mark As Dead':
											$scope.searchTargetRequest.mappingStatus = "MARK_AS_DEAD";
											break;
										case 'Mapped':
											$scope.searchTargetRequest.mappingStatus = "MAPPED";
											break;
										case 'Un Mapped':
											$scope.searchTargetRequest.mappingStatus = "UNMAPPED";
											break;
										case 'Show All':
											$scope.searchTargetRequest.mappingStatus = "SHOW_ALL";
											break;
										default:
											$scope.searchTargetRequest.mappingStatus = "TO_BE_MAPPED";
									}
									$scope.selectedTargetStatus = status;
									$scope.colorSelectedTarget = color;
									$scope.markedCICs = [];
									$scope.setItemType($scope.searchTargetRequest); //setting itemType to default "All" in target side if no itemType selected after load
									if ($scope.selectedTargetSearchCriteria != "Department") {
										$scope.searchTargetRequest.searchCriteriaValue = $scope.selectedTargetSearchCriteriaValue;
									}
									service.mappingTargetSearch = $scope.searchTargetRequest;
									$scope.listTargets($scope.searchTargetRequest);
								}
								$scope.disableCicChkBox = false;
							};

							/**
							 * U62615
							 * Method to disable source search criteria value if select/department/display given
							 */
							$scope.disableSourceSearchCriteriaVal = function (criteria) {
								if (criteria == "Select" || criteria == "Department" || criteria == "Display" || criteria == "WHSE vs DSD" || criteria == "Usage Ind") {
									return true;
								} else {
									return false;
								}
							};

							/**
							 * U62615
							 *Method to disable target search criteria value if select/department/display given
							 */
							$scope.disableTargetSearchCriteriaVal = function (criteria) {
								if (criteria == "Select" || criteria == "Department" || criteria == "Display" || criteria == "WHSE vs DSD" || criteria == "Usage Ind") {
									return true;
								} else {
									return false;
								}
							};

							/**
							 * U62615
							 * Method to set the selected search criteria and value when each criteria is selected
							 */
							$scope.setSearchCriteria = function (criteria, type) {

								if (type == "source") {
									$("#srcFilterByDep").hide();
									$("#srcFilterByWhse").hide();
									$("#srcFilterByDisplay").hide();
									$("#srcFilterByTotalsales").hide();
									$("#srcFilterByUsageType").hide();

									$scope.searchSourceRequest.searchCriteria = null;
									$scope.selectedSourceSearchCriteria = null;
									$scope.searchSourceRequest.searchCriteriaValue = null;
									$scope.selectedSourceSearchCriteriaValue = null;
									$scope.searchSourceRequest.totalSalesOperator = null;
									switch (criteria) {
										case 'SKU':
											$scope.searchSourceRequest.searchCriteria = "SKU_VAL";
											break;
										case 'Item Description':
											$scope.searchSourceRequest.searchCriteria = "ITEM_DESC";
											break;
										case 'UPC':
											$scope.searchSourceRequest.searchCriteria = "UPC_VAL";
											break;
										case 'PLU':
											$scope.searchSourceRequest.searchCriteria = "PLU_VAL";
											break;
										case 'Select':
											$scope.searchSourceRequest.searchCriteria = null;
											$scope.searchSourceRequest.searchCriteriaValue = null;
											break;
										default:
											$scope.searchSourceRequest.searchCriteria = null;
											$scope.searchSourceRequest.searchCriteriaValue = null;
									}

									if ($scope.sourceDepartments) {
										angular.forEach($scope.sourceDepartments, function (dept) {
											if (dept) {
												if (dept[1] === criteria) {
													$scope.searchSourceRequest.searchCriteria = "DEPT_NAME";
													$scope.searchSourceRequest.searchCriteriaValue = dept[0];
													$scope.selectedSourceSearchCriteria = "Department";
													$scope.selectedSourceSearchCriteriaValue = criteria;
												}

											}
										});
									}
									if (criteria == "N" || criteria == "Y") {
										$scope.searchSourceRequest.searchCriteria = "DISP";
										$scope.searchSourceRequest.searchCriteriaValue = criteria;
										$scope.selectedSourceSearchCriteriaValue = criteria;
										$scope.selectedSourceSearchCriteria = "Display";
									} else if (criteria == "WHSE" || criteria == "DSD") {
										$scope.searchSourceRequest.searchCriteria = "WHSE_DSD";
										$scope.searchSourceRequest.searchCriteriaValue = criteria;
										$scope.selectedSourceSearchCriteriaValue = criteria;
										$scope.selectedSourceSearchCriteria = "WHSE vs DSD";
									} else if (criteria == "GREATER_THAN" || criteria == "LESS_THAN" || criteria == "EQUALS") {
										$scope.searchSourceRequest.searchCriteria = "TOTAL_SALES";
										$scope.searchSourceRequest.totalSalesOperator = criteria;
										if (criteria == "GREATER_THAN") {
											$scope.selectedSourceSearchCriteria = "Total Sales >";
										} else if (criteria == "LESS_THAN") {
											$scope.selectedSourceSearchCriteria = "Total Sales <";
										} else if (criteria == "EQUALS") {
											$scope.selectedSourceSearchCriteria = "Total Sales =";
										}
									} else if (criteria == "R" || criteria == "M" || criteria == "E") {
										$scope.searchSourceRequest.searchCriteria = "USAGE_TYPE";
										$scope.searchSourceRequest.searchCriteriaValue = criteria;
										$scope.selectedSourceSearchCriteriaValue = criteria;
										$scope.selectedSourceSearchCriteria = "Usage Ind";
									}

									if ($scope.selectedSourceSearchCriteria != "Display" && $scope.selectedSourceSearchCriteria != "WHSE vs DSD" &&
										$scope.selectedSourceSearchCriteria != "Department" && $scope.searchSourceRequest.searchCriteria != "TOTAL_SALES" &&
										$scope.searchSourceRequest.searchCriteria != "USAGE_TYPE") {
										$scope.selectedSourceSearchCriteria = criteria;
									}

								} else {
									$("#tgtFilterByDep").hide();
									$("#tgtFilterByWhse").hide();
									$("#tgtFilterByDisplay").hide();
									$("#tgtFilterByUsageType").hide();

									$scope.searchTargetRequest.searchCriteria = null;
									$scope.selectedTargetSearchCriteria = null;
									$scope.searchTargetRequest.searchCriteriaValue = null;
									$scope.selectedTargetSearchCriteriaValue = null;
									switch (criteria) {
										case 'CIC':
											$scope.searchTargetRequest.searchCriteria = "CIC_VAL";
											break;
										case 'Item Description':
											$scope.searchTargetRequest.searchCriteria = "ITEM_DESC";
											break;
										case 'UPC':
											$scope.searchTargetRequest.searchCriteria = "UPC_VAL";
											break;
										case 'PLU':
											$scope.searchTargetRequest.searchCriteria = "PLU_VAL";
											break;
										case 'Select':
											$scope.searchTargetRequest.searchCriteria = null;
											$scope.searchTargetRequest.searchCriteriaValue = null;
											break;
										default:
											$scope.searchTargetRequest.searchCriteria = null;
											$scope.searchTargetRequest.searchCriteriaValue = null;
									}

									if ($scope.targetDepartments) {
										angular.forEach($scope.targetDepartments, function (dept) {
											if (dept) {
												if (dept[0] === criteria) {
													$scope.searchTargetRequest.searchCriteria = "DEPT_NAME";
													$scope.searchTargetRequest.searchCriteriaValue = dept[1];
													$scope.selectedTargetSearchCriteria = "Department";
													$scope.selectedTargetSearchCriteriaValue = criteria;
												}

											}
										});
									}
									if (criteria == "N" || criteria == "Y") {
										$scope.searchTargetRequest.searchCriteria = "DISP";
										$scope.searchTargetRequest.searchCriteriaValue = criteria;
										$scope.selectedTargetSearchCriteriaValue = criteria;
										$scope.selectedTargetSearchCriteria = "Display";
									} else if (criteria == "WHSE" || criteria == "DSD") {
										$scope.searchTargetRequest.searchCriteria = "WHSE_DSD";
										$scope.searchTargetRequest.searchCriteriaValue = criteria;
										$scope.selectedTargetSearchCriteria = "WHSE vs DSD";
										$scope.selectedTargetSearchCriteriaValue = criteria;
									} else if (criteria == "R" || criteria == "M" || criteria == "E") {
										$scope.searchTargetRequest.searchCriteria = "USAGE_TYPE";
										$scope.searchTargetRequest.searchCriteriaValue = criteria;
										$scope.selectedTargetSearchCriteriaValue = criteria;
										$scope.selectedTargetSearchCriteria = "Usage Ind";
									}
									if ($scope.selectedTargetSearchCriteria != "Display" && $scope.selectedTargetSearchCriteria != "WHSE vs DSD" &&
										$scope.selectedTargetSearchCriteria != "Department" && $scope.searchTargetRequest.searchCriteria != "USAGE_TYPE") {
										$scope.selectedTargetSearchCriteria = criteria;
									}
								}
							};


							/**
							 * U63178
							 * Method to search based on the dropdown selection and input
							 */
							$scope.searchByDropdown = function (criteria, value, type) {
								if (criteria && criteria != "Select" && !value) {
									alertify.alert("Enter any value to search.");
									return;
								} else {
									if (type == "source") {
										if (criteria != "Department") {
											$scope.searchSourceRequest.searchCriteriaValue = value;
										}
										$scope.markedSKUs = [];
										$scope.setItemType($scope.searchSourceRequest); //setting itemType to default "All" in source side if no itemType selected after load
										service.mappingSourceSearch = $scope.searchSourceRequest;
										$scope.listSources($scope.searchSourceRequest);
									} else {
										if (criteria != "Department") {
											$scope.searchTargetRequest.searchCriteriaValue = value;
										}
										$scope.markedCICs = [];
										$scope.setItemType($scope.searchTargetRequest); //setting itemType to default "All" in target side if no itemType selected after load
										service.mappingTargetSearch = $scope.searchTargetRequest;
										$scope.listTargets($scope.searchTargetRequest);
									}
									$scope.disableCicChkBox = false;
								}

							};

							/**
							 * U62615
							 * method to set the department in source filter
							 */
							$scope.changeSourceFilterDepartment = function (sourcefilterdept) {
								if ($scope.sourceDepartments && sourcefilterdept) {
									angular.forEach($scope.sourceDepartments, function (dept) {
										if (dept && dept[1] === sourcefilterdept) {
											$scope.searchSourceRequest.filter.department = dept[0];
										}
									});
								}
								if (sourcefilterdept && sourcefilterdept == "Select") {
									$scope.searchSourceRequest.filter.department = null;
								}
							};

							/**
							 * U62615
							 * method to set the department in target filter
							 */
							$scope.changeTargetFilterDepartment = function (targetfilterdept) {
								if ($scope.targetDepartments && targetfilterdept) {
									angular.forEach($scope.targetDepartments, function (dept) {
										if (dept && dept[0] === targetfilterdept) {
											$scope.searchTargetRequest.filter.department = dept[1];
										}
									});
								}
								if (targetfilterdept && targetfilterdept == "Select") {
									$scope.searchTargetRequest.filter.department = null;
								}
							};

							/**
							 * U63178
							 * Sort source items
							 */
							$scope.applySrcSort = function (searchRequest) {
								$scope.sortItems = [];
								if ($scope.sortmodels) {
									for (var i = 0; i < $scope.sortmodels[0].items.length; i++) {
										if ($scope.sortmodels[0].items[i].selected == true) {
											$scope.sortItems.push($scope.sortmodels[0].items[i].value);
										}
									}
									$scope.skuSortVal = null;
									$scope.searchSourceRequest.sortOrder = $scope.sortOrder.name;
									$scope.searchSourceRequest.sortItems = $scope.sortItems;

									$scope.applyFilter(searchRequest, searchRequest, 'source');
									$("#sortSourceSectionExpand").hide();
								}
								$scope.isSourceSorted = "filterApplied";
							};

							$scope.closeSourceSort = function () {
								$("#sortSourceSectionExpand").hide();
							};

							/**
							 * U63178
							 * method to set the Shipment in source filter
							 */
							$scope.changeSourceFilterShipment = function (sourceFilterVal) {
								if (sourceFilterVal == "Y" || sourceFilterVal == "N") {
									$scope.searchSourceRequest.filter.shipped = true;
									$scope.searchSourceRequest.filter.shipSearchValue = sourceFilterVal;
								} else {
									$scope.searchSourceRequest.filter.shipped = false;
									$scope.searchSourceRequest.filter.shipSearchValue = null;
								}
							};

							/**
							 * U63178
							 * method to set the Total sales in source filter
							 */
							$scope.changeSourceFilterSales = function (sourceFilterVal) {
								if (sourceFilterVal == "GREATER_THAN" || sourceFilterVal == "LESS_THAN" || sourceFilterVal == "EQUALS") {
									$scope.searchSourceRequest.filter.totalSalesFilter = true;
									$scope.searchSourceRequest.filter.totalSalesOperator = sourceFilterVal;
								} else {
									$scope.searchSourceRequest.filter.totalSalesFilter = false;
									$scope.searchSourceRequest.filter.totalSalesOperator = null;
									$scope.searchSourceRequest.filter.totalSalesvalue = null;
								}
							};

							/**
							 * U63178
							 * method to set the Usage Ind in source filter
							 */
							$scope.changeSourceFilterUsage = function (sourceFilterVal) {
								if (sourceFilterVal == "R" || sourceFilterVal == "M" || sourceFilterVal == "E") {
									$scope.searchSourceRequest.filter.usageTypeIndFilter = true;
									$scope.searchSourceRequest.filter.usageTypeInd = sourceFilterVal;
								} else {
									$scope.searchSourceRequest.filter.usageTypeIndFilter = false;
									$scope.searchSourceRequest.filter.usageTypeInd = null;
								}
							};

							/**
							 * U63178
							 * method to set the Usage type in source filter
							 */
							$scope.changeTargetFilterUsage = function (targetFilterVal) {
								if (!targetFilterVal == "") {
									$scope.searchTargetRequest.filter.usageFilter = true;
									$scope.searchTargetRequest.filter.usageType = targetFilterVal;
								} else {
									$scope.searchTargetRequest.filter.usageFilter = false;
									$scope.searchTargetRequest.filter.usageType = null;
								}
							};

							/**
							 * U63178
							 * method to set the Usage Ind in source filter
							 */
							$scope.changeTargetFilterUsageInd = function (targetFilterVal) {
								if (!targetFilterVal == "") {
									$scope.searchTargetRequest.filter.usageTypeIndFilter = true;
									$scope.searchTargetRequest.filter.usageTypeInd = targetFilterVal;
								} else {
									$scope.searchTargetRequest.filter.usageTypeIndFilter = false;
									$scope.searchTargetRequest.filter.usageTypeInd = null;
								}
							};

							/**
							 * U62615
							 * Apply Filter Function
							 */
							$scope.applyFilter = function (filterCriteria, searchRequest, searchFrom) {
								if (filterCriteria && filterCriteria.filter) {
									var count = 0;
									if (filterCriteria.filter.corpItemCD == "") {
										filterCriteria.filter.corpItemCD = null;
									}
									if (filterCriteria.filter.department == "" || filterCriteria.filter.department == "Select") {
										filterCriteria.filter.department = null;
									}
									if (filterCriteria.filter.divisionNum == "") {
										filterCriteria.filter.divisionNum = null;
									}
									if (filterCriteria.filter.hierarchy == "") {
										filterCriteria.filter.hierarchy = null;
									}
									if (filterCriteria.filter.itemNum == "") {
										filterCriteria.filter.itemNum = null;
									}
									if (filterCriteria.filter.itemDescription == "") {
										filterCriteria.filter.itemDescription = null;
									}
									if (filterCriteria.filter.productSKU == "") {
										filterCriteria.filter.productSKU = null;
									}
									if (filterCriteria.filter.plu == "") {
										filterCriteria.filter.plu = null;
									}
									if (filterCriteria.filter.supplierName == "") {
										filterCriteria.filter.supplierName = null;
									}
									if (filterCriteria.filter.supplierNum == "") {
										filterCriteria.filter.supplierNum = null;
									}
									if (filterCriteria.filter.slu == "") {
										filterCriteria.filter.slu = null;
									}
									if (filterCriteria.filter.upc == "") {
										filterCriteria.filter.upc = null;
									}
									if (filterCriteria.filter.smicGroupCd === "") {
										filterCriteria.filter.smicGroupCd = null;
									}
									if (filterCriteria.filter.smicCtgryCd === "") {
										filterCriteria.filter.smicCtgryCd = null;
									}
									if (filterCriteria.filter.smicClassCd === "") {
										filterCriteria.filter.smicClassCd = null;
									}
									if (filterCriteria.filter.smicSubClassCd === "") {
										filterCriteria.filter.smicSubClassCd = null;
									}
									if (filterCriteria.filter.smicSubSubClassCd === "") {
										filterCriteria.filter.smicSubSubClassCd = null;
									}
									if (filterCriteria.filter.vendUpcPackInd == undefined) {
										filterCriteria.filter.vendUpcPackInd = null;
										count = count + 1;
									}
									if (filterCriteria.filter.vendUpcCountry == undefined) {
										filterCriteria.filter.vendUpcCountry = null;
										count = count + 1;
									}
									if (filterCriteria.filter.vendUpcNumSys == undefined) {
										filterCriteria.filter.vendUpcNumSys = null;
										count = count + 1;
									}
									if (filterCriteria.filter.vendUpcManuf == undefined) {
										filterCriteria.filter.vendUpcManuf = null;
										count = count + 1;
									}
									if (filterCriteria.filter.vendUpcItem == undefined) {
										filterCriteria.filter.vendUpcItem = null;
										count = count + 1;
									}
									if (filterCriteria.filter.prodhierarchyLevel1 === "") {
										filterCriteria.filter.prodhierarchyLevel1 = null;
									}
									if (filterCriteria.filter.prodhierarchyLevel2 === "") {
										filterCriteria.filter.prodhierarchyLevel2 = null;
									}
									if (filterCriteria.filter.prodhierarchyLevel3 === "") {
										filterCriteria.filter.prodhierarchyLevel3 = null;
									}
									if (filterCriteria.filter.totalSalesvalue === "") {
										filterCriteria.filter.totalSalesFilter = false;
										filterCriteria.filter.totalSalesOperator = null;
										filterCriteria.filter.totalSalesvalue = null;
									}
									if (filterCriteria.filter.usageType === "") {
										filterCriteria.filter.usageType = null;
										filterCriteria.filter.usageFilter = false;
									}
									if (filterCriteria.filter.usageTypeInd === "") {
										filterCriteria.filter.usageTypeInd = null;
										filterCriteria.filter.usageTypeIndFilter = false;
									}
									if (filterCriteria.filter.shipSearchValue === "") {
										filterCriteria.filter.shipSearchValue = null;
										filterCriteria.filter.shipped = false;
									}
									if (filterCriteria.filter.vendorCode === "") {
										filterCriteria.filter.vendorCode = null;
									}
									if (filterCriteria.filter.vendorName === "") {
										filterCriteria.filter.vendorName = null;
									}
									if (count == 5) {
										filterCriteria.filter.vendorOrderFilter = false;
									} else {
										filterCriteria.filter.vendorOrderFilter = true;
									}
									if (filterCriteria.filter.corpItemCD || filterCriteria.filter.department || filterCriteria.filter.divisionNum || filterCriteria.filter.hierarchy ||
										filterCriteria.filter.itemNum || filterCriteria.filter.itemDescription || filterCriteria.filter.productSKU || filterCriteria.filter.plu ||
										filterCriteria.filter.supplierName || filterCriteria.filter.supplierNum || filterCriteria.filter.slu || filterCriteria.filter.upc ||
										filterCriteria.filter.smicGroupCd || filterCriteria.filter.smicCtgryCd || filterCriteria.filter.smicClassCd ||
										filterCriteria.filter.smicSubClassCd || filterCriteria.filter.smicSubSubClassCd || filterCriteria.filter.prodhierarchyLevel1 ||
										filterCriteria.filter.prodhierarchyLevel2 || filterCriteria.filter.prodhierarchyLevel3 ||
										filterCriteria.filter.smicGroupCd == 0 || filterCriteria.filter.smicCtgryCd == 0 || filterCriteria.filter.smicClassCd == 0 ||
										filterCriteria.filter.smicSubClassCd == 0 || filterCriteria.filter.smicSubSubClassCd == 0 || filterCriteria.filter.prodhierarchyLevel1 == 0 ||
										filterCriteria.filter.prodhierarchyLevel2 == 0 || filterCriteria.filter.prodhierarchyLevel3 == 0 ||
										filterCriteria.filter.totalSalesFilter || filterCriteria.filter.totalSalesOperator || filterCriteria.filter.totalSalesvalue ||
										filterCriteria.filter.usageFilter || filterCriteria.filter.usageType || filterCriteria.filter.shipped || filterCriteria.filter.shipSearchValue ||
										filterCriteria.filter.vendorCode || filterCriteria.filter.vendorName || filterCriteria.filter.usageTypeIndFilter || filterCriteria.filter.usageTypeInd ||
										filterCriteria.filter.vendUpcPackInd || filterCriteria.filter.vendUpcCountry || filterCriteria.filter.vendUpcNumSys || filterCriteria.filter.vendUpcManuf ||
										filterCriteria.filter.vendUpcItem || filterCriteria.filter.vendUpcPackInd == 0 || filterCriteria.filter.vendUpcCountry == 0 || filterCriteria.filter.vendUpcNumSys == 0 ||
										filterCriteria.filter.vendUpcManuf == 0 || filterCriteria.filter.vendUpcItem == 0) {

										searchRequest.filterAvail = true;
										if (searchFrom && searchFrom == "source") {
											$scope.isSourceFilterApplied = "filterApplied";
										} else if (searchFrom && searchFrom == "target") {
											$scope.isTargetFilterApplied = "filterApplied";
										}
									} else {
										searchRequest.filterAvail = false;
										if (searchFrom && searchFrom == "source") {
											$scope.isSourceFilterApplied = "filterUnapplied";
										} else if (searchFrom && searchFrom == "target") {
											$scope.isTargetFilterApplied = "filterUnapplied";
										}
									}

									if (searchFrom && searchFrom == "source") {
										$scope.sourceFilterApplied = true;
										$scope.postSourceFilterVal = angular.copy(filterCriteria.filter);
										$scope.lastSourceDepartment = angular.copy($scope.selectedSourceFilterDepartment);
										if ($scope.selectedSourceSearchCriteria != "Display" && $scope.selectedSourceSearchCriteria != "WHSE vs DSD" && $scope.selectedSourceSearchCriteria != "Department") {
											if ($scope.selectedSourceSearchCriteriaValue) {
												searchRequest.searchCriteriaValue = $scope.selectedSourceSearchCriteriaValue;
											} else {
												searchRequest.searchCriteriaValue = null;
											}
										}
										$scope.markedSKUs = [];
										$scope.setItemType(searchRequest); //setting itemType to default "All" in source side if no itemType selected after load
										service.mappingSourceSearch = searchRequest;
										$scope.listSources(searchRequest);
									} else if (searchFrom && searchFrom == "target") {
										$scope.targetFilterApplied = true;
										$scope.postTargetFilterVal = angular.copy(filterCriteria.filter);
										$scope.lastTargetDepartment = angular.copy($scope.selectedTargetFilterDepartment);
										if ($scope.selectedTargetSearchCriteria != "Display" && $scope.selectedTargetSearchCriteria != "WHSE vs DSD" && $scope.selectedTargetSearchCriteria != "Department") {
											if ($scope.selectedTargetSearchCriteriaValue) {
												searchRequest.searchCriteriaValue = $scope.selectedTargetSearchCriteriaValue;
											} else {
												searchRequest.searchCriteriaValue = null;
											}
										}
										$scope.markedCICs = [];
										$scope.setItemType(searchRequest); //setting itemType to default "All" in target side if no itemType selected after load
										service.mappingTargetSearch = searchRequest;
										$scope.listTargets(searchRequest);
									}
									$scope.disableCicChkBox = false;
								}
							};

							/**
							 * U62615
							 * method to set and search with the itemType selected
							 */
							$scope.searchWithItemType = function (searchRequest, searchFrom, type) {
								if (searchRequest) {
									//var isDisableAddbtn = false;
									searchRequest.itemType = {};
									searchRequest.itemType.all = false;
									searchRequest.itemType.system2 = false;
									searchRequest.itemType.system4 = false;
									searchRequest.itemType.plu = false;

									switch (type) {
										case 'all':
											searchRequest.itemType.all = true;
											break;
										case 'system2':
											searchRequest.itemType.system2 = true;
											//	isDisableAddbtn = true;
											break;
										case 'system4':
											searchRequest.itemType.system4 = true;
											//	isDisableAddbtn = true;
											break;
										case 'plu':
											searchRequest.itemType.plu = true;
											break;
										default:
											searchRequest.itemType.all = true;
									}
									if (searchFrom && searchFrom === "source") {
										$scope.markedSKUs = [];
										if ($scope.selectedSourceSearchCriteria != "Department") {
											$scope.searchSourceRequest.searchCriteriaValue = $scope.selectedSourceSearchCriteriaValue;
										}
										service.mappingSourceSearch = searchRequest;
										$scope.listSources(searchRequest);
									} else if (searchFrom && searchFrom === "target") {
										$scope.markedCICs = [];
										if ($scope.selectedTargetSearchCriteria != "Department") {
											$scope.searchTargetRequest.searchCriteriaValue = $scope.selectedTargetSearchCriteriaValue;
										}
										service.mappingTargetSearch = searchRequest;
										$scope.listTargets(searchRequest);
									}
									$scope.disableCicChkBox = false;
								}
							};

							/**
							 * U62615
							 * Load the Source data according to search request
							 */
							$scope.listSources = function (searchRequest) {

								var listSourceResults = $scope.baseUrl + "perishable/sourceList";
								if (searchRequest.filterAvail == false) {
									$scope.clearSourceFilter();
								}
								searchRequest.startIndex = 1;
								searchRequest.endIndex = 1000;
								$scope.searchSourceRequest.startIndex = 1;
								$scope.searchSourceRequest.endIndex = 1000;

								$http.post(listSourceResults, searchRequest, config)
									.then(function (response1) {
										//function handles success condition
										if (response1.data) {
											$scope.SKUResult = response1.data.skuSearchResults;

											if ((!$scope.SKUResult) || ($scope.SKUResult && $scope.SKUResult.length < 1)) {
												$scope.displaySourceNoResult = true;
											} else {
												$scope.displaySourceNoResult = false;
											}
											$scope.trimPLUFunc($scope.SKUResult);
											if (response1.data.sourceCount && response1.data.skuSearchResults) {
												$scope.sourceCount = response1.data.sourceCount;
												$scope.sourceShowCount = response1.data.skuSearchResults.length;

												if ($scope.sourceCount <= $scope.sourceShowCount) {
													$scope.sourceCount = $scope.sourceShowCount;
												}
											} else {
												$scope.sourceCount = 0;
												$scope.sourceShowCount = 0;
											}
										}
										$scope.validateSourceAddMapFunc = false;
										$scope.unselectedMapRequests = [];
										$scope.selectedMapRequests = [];
										$scope.returnLists = [];
										$scope.setResultRowColors($scope.SKUResult, "source");
										$scope.closeSourceFilter();
										$scope.setPaginate($scope.SKUResult);

									}, function (response1) {
										//function handles error condition
									});
							};

							/**
							 * U63178
							 * Load the Source data according to search request
							 */
							$scope.loadMoreSources = function (searchRequest) {

								var listSourceResults = $scope.baseUrl + "perishable/sourceList";
								if (searchRequest.filterAvail == false) {
									$scope.clearSourceFilter();
								}
								searchRequest.startIndex = $scope.searchSourceRequest.endIndex + 1;
								searchRequest.endIndex = $scope.searchSourceRequest.endIndex + 1000;
								$scope.searchSourceRequest.startIndex = searchRequest.startIndex;
								$scope.searchSourceRequest.endIndex = searchRequest.endIndex;

								$http.post(listSourceResults, searchRequest, config)
									.then(function (response1) {
										//function handles success condition
										if (response1.data) {
											$scope.SKUResult = $scope.SKUResult.concat(response1.data.skuSearchResults);

											if ((!$scope.SKUResult) || ($scope.SKUResult && $scope.SKUResult.length < 1)) {
												$scope.displaySourceNoResult = true;
											} else {
												$scope.displaySourceNoResult = false;
											}
											$scope.trimPLUFunc($scope.SKUResult);
											if (response1.data.sourceCount && $scope.SKUResult) {
												$scope.sourceCount = response1.data.sourceCount;
												$scope.sourceShowCount = $scope.SKUResult.length;

												if ($scope.sourceCount <= $scope.sourceShowCount) {
													$scope.sourceCount = $scope.sourceShowCount;
												}
											} else {
												$scope.sourceCount = 0;
												$scope.sourceShowCount = 0;
											}
										}
										$scope.validateSourceAddMapFunc = false;
										$scope.unselectedMapRequests = [];
										$scope.selectedMapRequests = [];
										$scope.returnLists = [];
										$scope.setResultRowColors($scope.SKUResult, "source");
										$scope.closeSourceFilter();
										$scope.setPaginate($scope.SKUResult);

									}, function (response1) {
										//function handles error condition
									});
							};

							/**
							 * U63178
							 * Disable load more based on the count
							 */
							$scope.disableLoadMore = function (showCount, totalCount) {
								if (showCount == totalCount) {
									return true;
								} else {
									return false;
								}
							};

							/**
							 * U62615
							 * function to list matched CIC based on selected SKU UPC's
							 */
							$scope.matchingTargetListing = function () {
								$scope.matchingTargetInputRequest = {};
								if ($scope.markedSKUs && $scope.markedSKUs.length > 1) {
									alertify.alert("More than one SKU has been selected!");
									return;
								} else if (!$scope.markedSKUs || $scope.markedSKUs.length < 1) {
									alertify.alert("Select any items from SKU.");
									return;
								} else if ($scope.markedCICs && $scope.markedCICs.length > 0) {
									alertify.alert("Unselect CIC and proceed.");
									return;
								} else {
									if ($scope.markedSKUs) {
										angular.forEach($scope.markedSKUs, function (sku) {
											$scope.matchingTargetInputRequest.upcs = sku.upc;
											if (sku.absDSDWhse == "WHSE") {
												$scope.matchingTargetInputRequest.whseDsd = "W";
											} else if (sku.absDSDWhse == "DSD") {
												$scope.matchingTargetInputRequest.whseDsd = "D";
											}
											$scope.matchingTargetInputRequest.dept = sku.deptName;
										});


										var listMatchingTargetResults = $scope.baseUrl + "perishable/matchingTargetList";

										$http.post(listMatchingTargetResults, $scope.matchingTargetInputRequest, config)
											.then(function (response) {
												//function handles success condition
												if (response.data) {
													$scope.CICResult = response.data.cicSearchResults;
													if ((!$scope.CICResult) || ($scope.CICResult && $scope.CICResult.length < 1)) {
														$scope.displayTargetNoResult = true;
													} else {
														$scope.displayTargetNoResult = false;
													}
													if (response.data.cicSearchResults) {
														$scope.targetCount = response.data.cicSearchResults.length;
														$scope.targetShowCount = response.data.cicSearchResults.length;

														if ($scope.targetCount <= $scope.targetShowCount) {
															$scope.targetCount = $scope.targetShowCount;
														}
													} else {
														$scope.targetCount = 0;
														$scope.targetShowCount = 0;
													}
													$scope.cicSortVal = null;
												}
												$scope.setResultRowColors($scope.CICResult, "target");
												$scope.closeTargetFilter();
											}, function (response1) {
												//function handles error condition
											});
									}
								}
							};

							/**
							 * U62615
							 * function to set the trimmed plu num in the upc column 
							 */
							$scope.trimPLUFunc = function (results) {
								if (results && results.length > 0) {
									angular.forEach(results, function (sku) {
										if (sku && sku.absUPCNo) {
											if (sku.absUPCNo <= 99999) {
												var s = sku.absUPCNo;
												while (s.charAt(0) === '0') {
													s = s.substr(1);
												}
												sku.absUPCNo = s;
											}
										}
									});
								}
							};


							/**
							 * U62615
							 * set the color of result rows based on status of each
							 */
							$scope.setResultRowColors = function (results, from) {
								if (results && results.length > 0) {
									if (results instanceof Object) {
										var count = results.length;

										for (var i = 0; i < count; i++) {
											if (from != null && from == "source") {
												results[i].collapseIndex = "targetSkuDetails" + i;
												$scope.displaySourceAlert = false;
											} else {
												results[i].collapseIndex = "targetDetails" + i;
												$scope.displayTargetAlert = false;
											}
											results[i].expBtnClass = "bgBlack";
											if (results[i].mappingStatus === 'TO_BE_MAPPED') {
												results[i].expBtnClass = "bgBlue";
											}
											if (results[i].mappingStatus === 'MARK_AS_DEAD') {
												results[i].expBtnClass = "bgGrey";
											}
											if (results[i].mappingStatus === 'LET_AUTO_MATCH') {
												results[i].expBtnClass = "bgViolet";
											}
											if (results[i].mappingStatus === 'FORCE_NEW') {
												results[i].expBtnClass = "bgDarkPink";
											}
											if (results[i].mappingStatus === 'SHOW_ALL') {
												results[i].expBtnClass = "bgYellow";
											}
											if (results[i].mappingStatus === 'MAPPED') {
												results[i].expBtnClass = "bgGreen";
											}
											if (results[i].mappingStatus === 'OTHERS') {
												results[i].expBtnClass = "bgLimeBlue";
											}
											if (results[i].mappingStatus === 'AWAITING_NEW_CIC') {
												results[i].expBtnClass = "bgLimeBlue";
											}
											if (results[i].mappingStatus === 'AWAITING_DIVISION_INPUT') {
												results[i].expBtnClass = "bgLimeBlue";
											}
											if (results[i].mappingStatus === 'RESERVED') {
												results[i].expBtnClass = "bgLimeBlue";
											}
											if (results[i].mappingStatus == '') {
												results[i].expBtnClass = "bgBlack";
											}
											if (results[i].mappingStatus == null) {
												results[i].expBtnClass = "bgBlack";
											}
										}
									}
								} else {
									if (from == "source") {
										$scope.displaySourceNoResult = true;
										$scope.displaySourceAlert = false;
									} else {
										$scope.displayTargetNoResult = true;
										$scope.displayTargetAlert = false;
									}
								}
							};


							/**
							 * U62615
							 * Load the Target data according to search request
							 */
							$scope.listTargets = function (searchRequest) {

								var listTargetResults = $scope.baseUrl + "perishable/targetList";
								if (searchRequest.filterAvail == false) {
									$scope.clearTargetFilter();
								}
								$http.post(listTargetResults, searchRequest, config)
									.then(function (responseTarget) {
										//function handles success condition
										if (responseTarget.data) {
											$scope.CICResult = responseTarget.data.cicSearchResults;
											if ((!$scope.CICResult) || ($scope.CICResult && $scope.CICResult.length < 1)) {
												$scope.displayTargetNoResult = true;
											} else {
												$scope.displayTargetNoResult = false;
											}
											if (responseTarget.data.targetCount && responseTarget.data.cicSearchResults) {
												$scope.targetCount = responseTarget.data.targetCount;
												$scope.targetShowCount = responseTarget.data.cicSearchResults.length;

												if ($scope.targetCount <= $scope.targetShowCount) {
													$scope.targetCount = $scope.targetShowCount;
												}
											} else {
												$scope.targetCount = 0;
												$scope.targetShowCount = 0;
											}
										}
										$scope.setResultRowColors($scope.CICResult, "target");
										$scope.closeTargetFilter();

									}, function (response1) {
										//function handles error condition
									});
							};

							/**
							 * U62615
							 * Filter close action of Source
							 */
							$scope.closeSourceFilter = function () {
								if ($scope.sourceFilterApplied == true) {
									$scope.searchSourceRequest.filter = angular.copy($scope.postSourceFilterVal);
								} else if ($scope.sourceFilterAppliedAfterPageDirect == true && service.mappingSourceSearch.filter != null) {
									$scope.searchSourceRequest.filter = angular.copy(service.mappingSourceSearch.filter);
									$scope.selectedSourceFilterDepartment = "Select";
									$scope.selectedSourceFilterShipment = angular.copy(service.mappingSourceSearch.filter.shipSearchValue);
									$scope.selectedSourceFilterUsagetype = angular.copy(service.mappingSourceSearch.filter.usageType);
									$scope.selectedSourceFilterTotalsales = angular.copy(service.mappingSourceSearch.filter.totalSalesOperator);
									$scope.selectedSourceSearchCriteriaValue = angular.copy(service.mappingSourceSearch.searchCriteriaValue);

									if (service.mappingSourceSearch.filter.corpItemCD || service.mappingSourceSearch.filter.department || service.mappingSourceSearch.filter.divisionNum || service.mappingSourceSearch.filter.hierarchy ||
										service.mappingSourceSearch.filter.itemNum || service.mappingSourceSearch.filter.itemDescription || service.mappingSourceSearch.filter.productSKU || service.mappingSourceSearch.filter.plu ||
										service.mappingSourceSearch.filter.supplierName || service.mappingSourceSearch.filter.supplierNum || service.mappingSourceSearch.filter.slu || service.mappingSourceSearch.filter.upc ||
										service.mappingSourceSearch.filter.smicGroupCd || service.mappingSourceSearch.filter.smicCtgryCd || service.mappingSourceSearch.filter.smicClassCd ||
										service.mappingSourceSearch.filter.smicSubClassCd || service.mappingSourceSearch.filter.smicSubSubClassCd || service.mappingSourceSearch.filter.prodhierarchyLevel1 ||
										service.mappingSourceSearch.filter.prodhierarchyLevel2 || service.mappingSourceSearch.filter.prodhierarchyLevel3 ||
										service.mappingSourceSearch.filter.smicGroupCd == 0 || service.mappingSourceSearch.filter.smicCtgryCd == 0 || service.mappingSourceSearch.filter.smicClassCd == 0 ||
										service.mappingSourceSearch.filter.smicSubClassCd == 0 || service.mappingSourceSearch.filter.smicSubSubClassCd == 0 || service.mappingSourceSearch.filter.prodhierarchyLevel1 == 0 ||
										service.mappingSourceSearch.filter.prodhierarchyLevel2 == 0 || service.mappingSourceSearch.filter.prodhierarchyLevel3 == 0 ||
										service.mappingSourceSearch.filter.totalSalesFilter || service.mappingSourceSearch.filter.totalSalesOperator || service.mappingSourceSearch.filter.totalSalesvalue ||
										service.mappingSourceSearch.filter.usageFilter || service.mappingSourceSearch.filter.usageType || service.mappingSourceSearch.filter.shipped || service.mappingSourceSearch.filter.shipSearchValue ||
										service.mappingSourceSearch.filter.vendorCode || service.mappingSourceSearch.filter.vendorName || service.mappingSourceSearch.filter.usageTypeIndFilter || service.mappingSourceSearch.filter.usageTypeInd) {
										$scope.isSourceFilterApplied = "filterApplied";
									} else {
										$scope.isSourceFilterApplied = "filterUnapplied";
										$scope.searchSourceRequest.filterAvail = false;
										$scope.searchSourceRequest.filter = {};

									}
								} else {
									$scope.searchSourceRequest.filter = {};
									$scope.isSourceFilterApplied = "filterUnapplied";
									$scope.searchSourceRequest.filterAvail = false;
								}

								$("#actionicons").show();
								$("#filterSoruceSectionExpand").hide();
							};

							/**
							 * U62615
							 * Filter close action of Target
							 */
							$scope.closeTargetFilter = function () {
								if ($scope.targetFilterApplied == true) {
									$scope.searchTargetRequest.filter = angular.copy($scope.postTargetFilterVal);
									$scope.selectedTargetFilterDepartment = angular.copy($scope.lastTargetDepartment);
								} else if ($scope.targetFilterAppliedAfterPageDirect == true && service.mappingTargetSearch.filter != null) {
									$scope.searchTargetRequest.filter = angular.copy(service.mappingTargetSearch.filter);
									$scope.selectedTargetFilterDepartment = "Select";
									if (service.mappingTargetSearch.filter.corpItemCD || service.mappingTargetSearch.filter.department || service.mappingTargetSearch.filter.divisionNum || service.mappingTargetSearch.filter.hierarchy ||
										service.mappingTargetSearch.filter.itemNum || service.mappingTargetSearch.filter.itemDescription || service.mappingTargetSearch.filter.productSKU || service.mappingTargetSearch.filter.plu ||
										service.mappingTargetSearch.filter.supplierName || service.mappingTargetSearch.filter.supplierNum || service.mappingTargetSearch.filter.slu || service.mappingTargetSearch.filter.upc ||
										service.mappingTargetSearch.filter.smicGroupCd || service.mappingTargetSearch.filter.smicCtgryCd || service.mappingTargetSearch.filter.smicClassCd ||
										service.mappingTargetSearch.filter.smicSubClassCd || service.mappingTargetSearch.filter.smicSubSubClassCd || service.mappingTargetSearch.filter.prodhierarchyLevel1 ||
										service.mappingTargetSearch.filter.prodhierarchyLevel2 || service.mappingTargetSearch.filter.prodhierarchyLevel3 ||
										service.mappingTargetSearch.filter.smicGroupCd == 0 || service.mappingTargetSearch.filter.smicCtgryCd == 0 || service.mappingTargetSearch.filter.smicClassCd == 0 ||
										service.mappingTargetSearch.filter.smicSubClassCd == 0 || service.mappingTargetSearch.filter.smicSubSubClassCd == 0 || service.mappingTargetSearch.filter.prodhierarchyLevel1 == 0 ||
										service.mappingTargetSearch.filter.prodhierarchyLevel2 == 0 || service.mappingTargetSearch.filter.prodhierarchyLevel3 == 0 ||
										service.mappingTargetSearch.filter.totalSalesFilter || service.mappingTargetSearch.filter.totalSalesOperator || service.mappingTargetSearch.filter.totalSalesvalue ||
										service.mappingTargetSearch.filter.usageFilter || service.mappingTargetSearch.filter.usageType || service.mappingTargetSearch.filter.shipped || service.mappingTargetSearch.filter.shipSearchValue ||
										service.mappingTargetSearch.filter.vendorCode || service.mappingTargetSearch.filter.vendorName || service.mappingTargetSearch.filter.usageTypeIndFilter || service.mappingTargetSearch.filter.usageTypeInd ||
										service.mappingTargetSearch.filter.vendUpcPackInd || service.mappingTargetSearch.filter.vendUpcCountry || service.mappingTargetSearch.filter.vendUpcNumSys || service.mappingTargetSearch.filter.vendUpcManuf ||
										service.mappingTargetSearch.filter.vendUpcItem) {
										$scope.isTargetFilterApplied = "filterApplied";
									} else {
										$scope.isTargetFilterApplied = "filterUnapplied";

									}
								} else {
									$scope.searchTargetRequest.filter = {};
								}
								$("#actionicons").show();
								$("#filterTargetSectionExpand").hide();
							};

							/**
							 * U63178
							 * Clear all action in source filter
							 */
							$scope.clearSourceFilter = function ($event) {

								$scope.selectedSourceFilterDepartment = "Select";
								$scope.selectedSourceFilterShipment = "";
								$scope.selectedSourceFilterUsagetype = "";
								$scope.selectedSourceFilterTotalsales = "";
								$scope.changeSourceFilterShipment("");
								$scope.changeSourceFilterSales("");
								$scope.changeSourceFilterUsage("");
								document.getElementById("hierarchyfirst").value = null;
								document.getElementById("hierarchysecond").value = null;
								document.getElementById("hierarchythird").value = null;
								$scope.searchSourceRequest.filterAvail = false;
								$scope.searchSourceRequest.filter = {};
								$scope.isSourceFilterApplied = "filterUnapplied";
								$scope.sourceFilterApplied = false;
							};

							/**
							 * U63178
							 * Clear all action in target filter
							 */
							$scope.clearTargetFilter = function ($event) {

								$scope.selectedTargetFilterDepartment = "Select";
								$scope.selectedTargetFilterUsagetype = "";
								$scope.selectedTargetFilterUsageInd = "";
								document.getElementById("smic_grp").value = null;
								document.getElementById("smic_ctgry").value = null;
								document.getElementById("smic_class").value = null;
								document.getElementById("smic_sub_class").value = null;
								document.getElementById("smic_sub_sb_class").value = null;
								document.getElementById("voc_pckind").value = null;
								document.getElementById("voc_country").value = null;
								document.getElementById("voc_numsys").value = null;
								document.getElementById("voc_upcmanuf").value = null;
								document.getElementById("voc_upcitm").value = null;
								$scope.searchTargetRequest.filterAvail = false;
								$scope.searchTargetRequest.filter = {};
								$scope.isTargetFilterApplied = "filterUnapplied";
								$scope.targetFilterApplied = false;
							};

							/**
							 * U63178
							 * Toggle arrow for expanded view
							 */
							$scope.toggleArrow = function ($event, tabid) {
								var msie = $document[0].documentMode;
								if (msie) {
									$(event.target).toggleClass('glyphicon-menu-up glyphicon-menu-down');
								} else {
									$(event.target).toggleClass('glyphicon-menu-up glyphicon-menu-down');
								}
							};

							/**
							 * U62615
							 * open action for UPC drop down at source
							 */
							$scope.openUPC = function (index) {
								$("#open_" + index).show();
							};
							$scope.openStatusUPC = function (index) {
								$("#openbadge_" + index).show();
							};


							/**
							 * U62615
							 * close action for UPC drop down at source
							 */
							$scope.closeUPC = function (index) {
								$("#open_" + index).hide();
							};
							$scope.closeStatusUPC = function (index) {
								$("#openbadge_" + index).hide();
							};

							/**
							 * U62615
							 * open action for UPC drop down at target
							 */
							$scope.openTargetUPC = function (index) {
								$("#opentarget_" + index).show();
							};

							/**
							 * U62615
							 * close action for UPC drop down at target
							 */
							$scope.closetargetUPC = function (index) {
								$("#opentarget_" + index).hide();
							};

							/**
							 * U63178
							 * open action for ROG count display
							 */
							$scope.openROG = function (index, cicval) {

								$scope.rogDetailsPassing = cicval;
								$scope.rogDetailsObtained = [];

								var listResults = $scope.baseUrl + "perishable/additionalTargetRetailsScanList";

								$http.post(listResults, $scope.rogDetailsPassing, config)
									.then(function (response) {
										//function handles success condition
										if (response.data) {
											$scope.rogDetailsObtained = response.data;
											//								document.getElementById("testrog_" + index).innerHTML = response.data.rogCount;
											var idNo = document.getElementById("testrog_" + index);
											idNo = response.data.rogCount;
											$scope.rogOpen_count = idNo;
											if (response.data.rogCount > 0) {
												$("#ROGlist_" + index).show();
											}
										}
									}, function (response1) {
										//function handles error condition
									});
							};
							$scope.closeROG = function (index) {
								$("#ROGlist_" + index).hide();
							};

							/**
							 *  U62615
							 * Method to display UPC with details
							 */
							$scope.showUPCs = function (skuitem) {
								var skuClicked = skuitem.sku;
								$scope.enteredEqual = false;
								if ($scope.searchSourceRequest.itemType) {
									if ($scope.searchSourceRequest.itemType.all == true) {
										$scope.itemTypeSelected = "ALL";
									} else if ($scope.searchSourceRequest.itemType.system2 == true) {
										$scope.itemTypeSelected = "System2";
									} else if ($scope.searchSourceRequest.itemType.system4 == true) {
										$scope.itemTypeSelected = "System4";
									} else if ($scope.searchSourceRequest.itemType.plu == true) {
										$scope.itemTypeSelected = "PLU";
									}
								}
								$scope.detailsPassing = [];
								$scope.detailsPassing.push($scope.searchSourceRequest.companyID);
								$scope.detailsPassing.push($scope.searchSourceRequest.divisionID);
								$scope.detailsPassing.push(skuClicked);
								$scope.detailsPassing.push(skuitem.mappingStatus);
								$scope.detailsPassing.push($scope.itemTypeSelected);

								if ($scope.returnLists && $scope.returnLists.length > 0) {
									for (var i = 0; i < $scope.returnLists.length; i++) {
										if ($scope.returnLists[i].sku == skuClicked && $scope.returnLists[i].upcList && $scope.returnLists[i].upcList.length > 0 && $scope.returnLists[i].settedItemType == $scope.itemTypeSelected) {
											$scope.skuOpted.upcSalesDetails = [];
											$scope.skuOpted.upcSalesDetails = $scope.returnLists[i].upcList;
											$scope.enteredEqual = true;
											break;
										}
									}
									if (!$scope.enteredEqual) {
										$scope.upcLoadFunction(skuClicked, $scope.itemTypeSelected);
									}
								} else if ($scope.returnLists && $scope.returnLists.length == 0) {
									$scope.upcLoadFunction(skuClicked, $scope.itemTypeSelected);
								}
							};

							/**
							 *  U62615
							 * Store the UPC list in temp array
							 */
							$scope.upcLoadFunction = function (skuClicked, selectedItemType) {
								$scope.skuOpted = {};
								$scope.skuOpted.upcSalesDetails = [];

								var listResults = $scope.baseUrl + "perishable/upcList";

								$http.post(listResults, $scope.detailsPassing, config)
									.then(function (response) {
										//function handles success condition
										if (response.data) {
											$scope.skuOpted.upcSalesDetails = response.data;

											$scope.returnList = {};
											$scope.returnList.sku = "";
											$scope.returnList.settedItemType = "";
											$scope.returnList.upcList = [];
											$scope.returnList.sku = skuClicked;
											$scope.returnList.settedItemType = selectedItemType;
											$scope.returnList.upcList = $scope.skuOpted.upcSalesDetails;
											$scope.returnLists.push($scope.returnList);

										}
									}, function (response1) {
										//function handles error condition
									});
							};

							/**
							 *  U62615
							 * method to get unchecked upcs of an sku - to be reviewed
							 */
							$scope.checkUPC = function (skuitem, upc, checkedUPC) {
								$scope.upcClicked = true;
								if (upc && checkedUPC === true) {
									$scope.selectedMapReq = {};
									$scope.selectedMapReq.sku = skuitem.sku;
									$scope.selectedMapReq.upc = upc;
									$scope.selectedMapReq.matchedItemTypeCd = skuitem.usage;
									if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
										for (var j = 0; j < $scope.unselectedMapRequests.length; j++) {
											if (upc && $scope.unselectedMapRequests[j]) {
												if (upc === $scope.unselectedMapRequests[j].upc) {
													$scope.unselectedMapRequests.splice(j, 1);
												}
											}
										}
									}
									$scope.selectedMapRequests.push($scope.selectedMapReq);
								} else if (upc && checkedUPC === false) {
									$scope.unselectedMapReq = {};
									$scope.unselectedMapReq.sku = skuitem.sku;
									$scope.unselectedMapReq.upc = upc;
									$scope.unselectedMapReq.matchedItemTypeCd = skuitem.usage;
									$scope.unselectedMapRequests.push($scope.unselectedMapReq);
								}
							};

							/**
							 *  U62615
							 *  method to get the selected SKU's for any action
							 */
							$scope.setSKU = function (sku, selectSKU) {
								$scope.disableReserved = false;
								if (selectSKU === true) {
									$scope.markedSKUs.push(sku);
								} else {
									for (var j = 0; j < $scope.markedSKUs.length; j++) {
										if (sku && $scope.markedSKUs[j]) {
											if (sku.sku === $scope.markedSKUs[j].sku) {
												$scope.markedSKUs.splice(j, 1);
											}
										}
									}
								}
								angular.forEach($scope.markedSKUs, function (item) {
									if (item.mappingStatus === "OTHERS" || item.mappingStatus === "AWAITING_NEW_CIC" || item.mappingStatus === "AWAITING_DIVISION_INPUT" || item.mappingStatus === "RESERVED") {
										$scope.disableReserved = true;
									}
								});
							};

							/**
							 *  U62615
							 *  method to validate if any selected SKU's contain UPC of System 2 / System 4 and disable add map
							 */
							$scope.validateAddMapBasedOnUPCSystem = function (selectedDatas, from) {
								var requests = selectedDatas;
								for (var k = 0; k < requests.length; k++) {
									if (requests[k] && requests[k].upc) {
										var upc = requests[k].upc;
										if (from == "source") {
											if (upc && (upc[1] == "2" || upc[1] == "4")) {
												$scope.validateSourceAddMapFunc = true;
												break;
											} else {
												$scope.validateSourceAddMapFunc = false;
												break;
											}
										}
									}
								}
							};


							/**
							 *  U62615
							 *  method to get the selected CIC's for any action
							 */
							$scope.setCIC = function (cic, selectCIC) {
								if (selectCIC === true) {
									$scope.markedCICs.push(cic);
								} else {
									for (var j = 0; j < $scope.markedCICs.length; j++) {
										if (cic && $scope.markedCICs[j]) {
											if (cic.cic === $scope.markedCICs[j].cic) {
												$scope.markedCICs.splice(j, 1);
											}
										}
									}
								}
							};

							/**
							 *  U62615
							 *  add  map function 
							 */
							$scope.addMap = function () {
								$scope.addPLU = false;
								$scope.fromMarkAsdead = false;
								var markedProductSrc = "";
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedCICs && $scope.markedCICs.length > 0) {
									for (var i = 0; i < $scope.markedSKUs.length; i++) {
										if ($scope.markedSKUs[i].absDSDWhse != $scope.markedSKUs[$scope.markedSKUs.length - 1].absDSDWhse) {
											alertify.alert("Different product source SKUs has been selected.");
											return;
										}
										if ($scope.markedCICs[0].whseDsd != ("WHSE-DSD" || "whse-dsd")) {
											if ($scope.markedSKUs[i].absDSDWhse != $scope.markedCICs[0].whseDsd) {
												alertify.alert("Select same product source items for SKU and CIC.");
												return;
											}
										}
										if ($scope.markedSKUs[i].usage != $scope.markedSKUs[$scope.markedSKUs.length - 1].usage) {
											alertify.alert("Different usage ind SKUs has been selected.");
											return;
										}
										if ($scope.markedSKUs[i].usage != $scope.markedCICs[0].itemUSageInd) {
											alertify.alert("SKU's Usage ind and CIC's Item usage should be same.");
											return;
										}
										if (($scope.markedSKUs[i].absDSDWhse == $scope.markedCICs[0].whseDsd) || $scope.markedCICs[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
											//check for similar values and store in a boolean string
											markedProductSrc = $scope.markedSKUs[i].absDSDWhse;
										}
									}
								}
								var validationMsg = "System 2 & 4 UPC's cannot be processed in add map. Do you want to proceed?";
								if (markedProductSrc == "WHSE" && ($scope.markedSKUs.length > 1 || $scope.markedCICs.length > 1)) {
									alertify.alert("Invalid selection. WHSE item only allows mapping of one SKU with one CIC.");
									return;
								} else {
									if ($scope.markedSKUs && $scope.markedSKUs.length > 0) {
										if ($scope.markedCICs && $scope.markedCICs.length < 1) {
											alertify.alert("Atleast one CIC must be selected.");
											return;
										}
										if ($scope.markedCICs && $scope.markedCICs.length > 1) {
											alertify.alert("Only one CIC must be selected.");
											return;
										}
										if (markedProductSrc == "WHSE" && $scope.markedCICs && $scope.markedCICs[0].expBtnClass == "bgGreen") {
											alertify.alert("WHSE items cannot be mapped again.");
											return;
										}
										$scope.mappingRequests = [];
										if ($scope.markedSKUs) {
											$scope.createBaseMappingRequests($scope.markedSKUs, $scope.markedCICs, "ADD_MAP");
											if ($scope.mappingRequests && $scope.mappingRequests.length > 0 && !$scope.upcClicked) {
												$scope.validateAddMapBasedOnUPCSystem($scope.mappingRequests, "source");
												if ($scope.validateSourceAddMapFunc) {
													alertify.confirm(validationMsg, function (e) {
														if (e) {
															$scope.validatePLU($scope.mappingRequests);
														} else {
															//code incase of cancel
															$scope.upcClicked = false;
														}
													});
												} else {
													$scope.validatePLU($scope.mappingRequests);
												}
											}
										}
										if ($scope.upcClicked) {
											if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
												$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.mappingRequests);
												if ($scope.mappingRequests && $scope.mappingRequests.length > 0) {
													$scope.validateAddMapBasedOnUPCSystem($scope.mappingRequests, "source");
												} else {
													$scope.validateSourceAddMapFunc = false;
												}
												if ($scope.validateSourceAddMapFunc) {
													alertify.confirm(validationMsg, function (e) {
														if (e) {
															$scope.markAsDeadPrompt($scope.unselectedMapRequests, "addmap");
														} else {
															//code incase of cancel
															$scope.upcClicked = false;
														}
													});
												} else {
													$scope.markAsDeadPrompt($scope.unselectedMapRequests, "addmap");
												}
											} else {
												$scope.validateAddMapBasedOnUPCSystem($scope.mappingRequests, "source");
												if ($scope.validateSourceAddMapFunc) {
													alertify.confirm(validationMsg, function (e) {
														if (e) {
															$scope.validatePLU($scope.mappingRequests);
														} else {
															//code incase of cancel
															$scope.upcClicked = false;
														}
													});
												} else {
													$scope.validatePLU($scope.mappingRequests);
												}
											}
										}
									} else {
										alertify.alert("Select SKU and CIC to proceed.");
										return;
									}
								}
							};


							/**
							 * U63180
							 * Functionality for inherit map action.
							 */
							$scope.inheritMap = function () {
								var markedProductSrc = "";
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedCICs && $scope.markedCICs.length > 0) {
									for (var i = 0; i < $scope.markedSKUs.length; i++) {
										if ($scope.markedSKUs[i].absDSDWhse != $scope.markedSKUs[$scope.markedSKUs.length - 1].absDSDWhse) {
											alertify.alert("Different type of SKUs has been selected.");
											return;
										}
										if ($scope.markedCICs[0].whseDsd != ("WHSE-DSD" || "whse-dsd")) {
											if (($scope.markedSKUs[i].absDSDWhse != $scope.markedCICs[0].whseDsd)) {
												alertify.alert("Select same product source items for SKU and CIC.");
												return;
											}
										}
										if ($scope.markedSKUs[i].usage != $scope.markedSKUs[$scope.markedSKUs.length - 1].usage) {
											alertify.alert("Different usage ind SKUs has been selected.");
											return;
										}
										if ($scope.markedSKUs[i].usage != $scope.markedCICs[0].itemUSageInd) {
											alertify.alert("SKU's Usage ind and CIC's Item usage ind should be same.");
											return;
										}
										if (($scope.markedSKUs[i].absDSDWhse == $scope.markedCICs[0].whseDsd) || $scope.markedCICs[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
											//check for similar values and store in a boolean string
											markedProductSrc = $scope.markedSKUs[i].absDSDWhse;
										}
									}
								}

								if (markedProductSrc == "WHSE" && ($scope.markedSKUs.length > 1 || $scope.markedCICs.length > 1)) {
									alertify.alert("Invalid selection. WHSE item only allows mapping of one SKU with one CIC.");
									return;
								} else {
									if ($scope.markedSKUs && $scope.markedSKUs.length > 0) {
										if ($scope.markedCICs && $scope.markedCICs.length < 1) {
											alertify.alert("Atleast one CIC must be selected.");
											return;
										}
										if ($scope.markedCICs && $scope.markedCICs.length > 1) {
											alertify.alert("Only one CIC must be selected.");
											return;
										}
										if (markedProductSrc == "WHSE" && $scope.markedCICs && $scope.markedCICs[0].expBtnClass == "bgGreen") {
											alertify.alert("WHSE items cannot be mapped again.");
											return;
										}
										$scope.mappingRequests = [];
										if ($scope.markedSKUs) {
											$scope.createBaseMappingRequests($scope.markedSKUs, $scope.markedCICs, "INHERIT_MAP");
											if ($scope.mappingRequests && $scope.mappingRequests.length > 0 && !$scope.upcClicked) {
												$scope.additionalPLUpopup("INHERITMAP");
											}
										}
										if ($scope.upcClicked) {
											if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
												$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.mappingRequests);
												$scope.markAsDeadPrompt($scope.unselectedMapRequests, "inheritmap");
											} else {
												$scope.additionalPLUpopup("INHERITMAP");
											}
										}

									} else {
										alertify.alert("Select SKU and CIC to proceed.");
										return;
									}
								}
							};

							/**
							 * U63180
							 * Functionality for auto match action.
							 */
							$scope.letAutoMatch = function () {
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedCICs && $scope.markedCICs.length < 1) {
									if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
										alertify.alert("UPC's cannot be unselected for this action.");
										return;
									} else {
										$scope.createBaseMappingRequests($scope.markedSKUs, null, "LET_AUTO_MATCH");
										$scope.action($scope.mappingRequests);
									}
								} else {
									alertify.alert("Select only SKU to proceed.");
									return;
								}
							};

							/**
							 *  U62615
							 *  force new function 
							 */
							$scope.forceNew = function () {
								$scope.saveRequests = [];
								var updatedUserID = null;
								updatedUserID = service.userId;
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0 &&
									$scope.markedCICs && $scope.markedCICs.length < 1) {
									if ($scope.markedSKUs.length > 1) {
										alertify.alert("Select single SKU to proceed.");
										return;
									} else if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
										alertify.alert("UPC's cannot be unselected for this action.");
										return;
									} else {
										angular.forEach($scope.markedSKUs, function (sku) {
											$scope.saveRequest = {};
											$scope.saveRequest.sourceComponentUpc = [];
											$scope.saveRequest.companyId = service.selectedCompany.companyID;
											$scope.saveRequest.divisionId = service.selectedDivision.divisionID;
											$scope.saveRequest.productSku = sku.sku;
											$scope.saveRequest.cost = 0;
											$scope.saveRequest.displayFlag = sku.display;
											$scope.saveRequest.pack = sku.packNum;
											$scope.saveRequest.vendorConvFactor = sku.vcf;
											$scope.saveRequest.updatedUserId = updatedUserID;
											$scope.skuSelected = $scope.saveRequest.productSku;
											$scope.matchedUsageType = sku.usage;
											angular.forEach(sku.upc, function (upc) {
												$scope.src = {};
												$scope.src.upc = {};
												$scope.src.upc = upc;
												$scope.saveRequest.sourceComponentUpc.push($scope.src);
											});
											$scope.saveRequests.push($scope.saveRequest);

										});

										var listResults = $scope.baseUrl + "perishable/checkForceNewCategory";

										$http.post(listResults, $scope.saveRequest, config)
											.then(function (response) {

												service.mappingSourceSearch = $scope.searchSourceRequest;
												//service.mappingTargetSearch = $scope.searchTargetRequest;
												//function handles success condition
												if (response.data.ForceNewCategory == "A") {
													AugmentedDisplayerService.setCompanyID(service.selectedCompany.companyID);
													AugmentedDisplayerService.setDivisionID(service.selectedDivision.divisionID);
													AugmentedDisplayerService.setProductSku($scope.skuSelected);
													AugmentedDisplayerService.setUsageType($scope.matchedUsageType);
													AugmentedDisplayerService.setDeptName($scope.markedSKUs[0].deptName);
													AugmentedDisplayerService.setKey("perishables");
													$.contextMenu('destroy');
													$location.path('Augmented');
												} else if (response.data.ForceNewCategory == "O") {
													OverrideMappingService.setCompanyID(service.selectedCompany.companyID);
													OverrideMappingService.setDivisionID(service.selectedDivision.divisionID);
													OverrideMappingService.setProductSku($scope.skuSelected);
													OverrideMappingService.setUsageType($scope.matchedUsageType);
													OverrideMappingService.setKey("perishables");
													$.contextMenu('destroy');
													$location.path('UpdateOverride');
												}
											}, function (response1) {
												//function handles error condition
											});
									}
								} else {
									alertify.alert("Select only SKU to proceed.");
									return;
								}
							};

							/**
							 *  U63178
							 *  mark as reserve function 
							 */
							$scope.markAsReserve = function () {
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedCICs && $scope.markedCICs.length < 1) {
									$scope.mappingRequests = [];
									if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
										alertify.alert("UPC's cannot be unselected for this action.");
										return;
									}
									$scope.createBaseMappingRequests($scope.markedSKUs, null, "RESERVED");
									if ($scope.mappingRequests && $scope.mappingRequests.length > 0 && !$scope.upcClicked) {
										$scope.makeItReserve($scope.mappingRequests, "markasreserve");
									}
									if ($scope.upcClicked && $scope.unselectedMapRequests) {
										$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.mappingRequests);
										if ($scope.mappingRequests && $scope.mappingRequests.length > 0) {
											$scope.makeItReserve($scope.mappingRequests, "upcmarkasreserve");
										} else {
											alertify.alert("Select any UPC from the SKU to mark as Reserve.");
											return;
										}
									}
								} else {
									alertify.alert("Select only SKU to proceed.");
									return;
								}
							};

							/**
							 *  U63178
							 *  make it as reserve function 
							 */
							$scope.makeItReserve = function (mappingRequestsForReserve, from) {
								var updatedUserID = null;
								var mappingStatus = "OTHERS";
								updatedUserID = service.userId;
								if (mappingRequestsForReserve && mappingRequestsForReserve.length > 0) {
									alertify.radioprompt("Provide suitable reasons for marking it as reserved.", function (e, str) {
										if (e) {
											$scope.finalRequests = [];
											var needCic = $('#alertify-radio1:checked').val();
											var needInp = $('#alertify-radio2:checked').val();
											var resComments = $('#alertify-text').val();

											if (needCic) {
												mappingStatus = needCic;
											}
											if (needInp) {
												mappingStatus = needInp;
											}
											angular.forEach(mappingRequestsForReserve, function (mapReq) {
												if (mapReq) {
													mapReq.mappingType = "RESERVED";
													mapReq.mappingstatus = mappingStatus;
													mapReq.comments = resComments;
													mapReq.companyID = service.selectedCompany.companyID;
													mapReq.divisionID = service.selectedDivision.divisionID;
													mapReq.updatedUserId = updatedUserID;
													$scope.finalRequests.push(mapReq);
												}
											});
											$scope.action($scope.finalRequests);
										} else {
											//code incase of cancel
											$scope.upcClicked = false;
										}
									});
									return;
								}
							};

							/**
							 *  U62615
							 *  mark as dead function 
							 */
							$scope.markAsDead = function () {
								if ($scope.markedSKUs && $scope.markedSKUs.length > 0 && $scope.markedCICs && $scope.markedCICs.length < 1) {
									$scope.mappingRequests = [];
									$scope.createBaseMappingRequests($scope.markedSKUs, null, "MARK_AS_DEAD");
									if ($scope.mappingRequests && $scope.mappingRequests.length > 0 && !$scope.upcClicked) {
										$scope.markAsDeadPrompt($scope.mappingRequests, "markasdead");
									}
									if ($scope.upcClicked && $scope.unselectedMapRequests) {
										$scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.mappingRequests);
										if ($scope.mappingRequests && $scope.mappingRequests.length > 0) {
											$scope.markAsDeadPrompt($scope.mappingRequests, "upcmarkasdead");
										} else {
											alertify.alert("Select any UPC from the SKU to mark as dead.");
											return;
										}
									}
								} else {
									alertify.alert("Select only SKU to proceed.");
									return;
								}
							};

							/**
							 * U62615
							 * common method for creating mapping requests for each sku, when sku alone selected
							 */
							$scope.createBaseMappingRequests = function (selectedSources, selectedTargets, mappingType) {
								$scope.mappingRequests = [];
								var updatedUserID = null;
								updatedUserID = service.userId;
								angular.forEach(selectedSources, function (sku) {
									if (sku.upc && sku.upc.length > 0) {
										angular.forEach(sku.upc, function (upc1) {
											if (upc1) {
												$scope.mappingrequest = {};
												$scope.mappingrequest.companyID = service.selectedCompany.companyID;
												$scope.mappingrequest.divisionID = service.selectedDivision.divisionID;
												$scope.mappingrequest.upc = upc1;
												$scope.mappingrequest.sku = sku.sku;
												$scope.mappingrequest.mappingType = mappingType;
												$scope.mappingrequest.mappingstatus = "TO_BE_MAPPED";
												$scope.mappingrequest.updatedUserId = updatedUserID;
												$scope.mappingrequest.matchedItemTypeCd = sku.usage;
												$scope.mappingrequest.targetPLU = null;
												$scope.mappingrequest.targetEdited = false;
												$scope.mappingrequest.dcPackDesc = null;
												$scope.mappingrequest.dcSizeDsc = null;
												$scope.mappingrequest.retailUnitPack = null;
												$scope.mappingrequest.ring = null;
												$scope.mappingrequest.hicone = null;

												if (selectedTargets && (mappingType === "ADD_MAP" || mappingType === "INHERIT_MAP")) {
													$scope.mappingrequest.mappingstatus = "MAPPED";
													angular.forEach(selectedTargets, function (cic) {
														$scope.mappingrequest.cic = cic.cic;
													});
												}

												if (mappingType === "FORCE_NEW") {
													$scope.mappingrequest.mappingstatus = "FORCE_NEW";
												}
												if (mappingType === "RESERVED") {
													$scope.mappingrequest.mappingstatus = "RESERVED";
												}
												$scope.mappingRequests.push($scope.mappingrequest);
											}
										});
									}
								});
							};

							/**
							 * U62615
							 * common method for seperating mapping requests based based on upc check
							 */
							$scope.createSubMappingRequests = function (unselectedRequests, allRequests) {
								$scope.mappingRequests = [];
								$scope.mappingRequests = allRequests;
								for (var j = 0; j < unselectedRequests.length; j++) {
									for (var i = 0; i < $scope.mappingRequests.length; i++) {
										if ($scope.mappingRequests[i] && unselectedRequests[j]) {
											if ($scope.mappingRequests[i].sku === unselectedRequests[j].sku && $scope.mappingRequests[i].upc === unselectedRequests[j].upc) {
												$scope.mappingRequests.splice(i, 1);

											}
										}
									}
								}
							};


							/**
							 * U62615
							 * common method for prompt for mark as dead from add map/inherit map/mark as dead
							 */
							$scope.markAsDeadPrompt = function (mappingRequestsForMAD, from) {
								if (mappingRequestsForMAD && mappingRequestsForMAD.length > 0) {
									var markAsDeadReason = null;
									var updatedUserID = null;
									updatedUserID = service.userId;
									if (from === "addmap" || from === 'inheritmap') {
										alertify.prompt("Some UPC's were unselected which will be marked as dead. Provide a reason for it.", function (e, str) {
											if (e) {
												$scope.finalRequests = [];
												markAsDeadReason = str;
												if (markAsDeadReason == null || markAsDeadReason.length == 0) { } else if (markAsDeadReason != null || markAsDeadReason.length != 0) {
													angular.forEach(mappingRequestsForMAD, function (mapReq) {
														if (mapReq) {
															mapReq.comments = markAsDeadReason;
															mapReq.mappingType = "MARK_AS_DEAD";
															mapReq.companyID = service.selectedCompany.companyID;
															mapReq.divisionID = service.selectedDivision.divisionID;
															mapReq.updatedUserId = updatedUserID;
															$scope.finalRequests.push(mapReq);
														}
													});
													angular.forEach($scope.mappingRequests, function (addMapReq) {
														$scope.finalRequests.push(addMapReq);
													});
													$scope.fromMarkAsdead = true;

													$scope.action($scope.finalRequests);
												}
											} else {
												//code incase of cancel
												$scope.upcClicked = false;
											}
										});
									} else {
										var msg = "";
										if (from === "upcmarkasdead") {
											msg = "The selected UPC's will be marked as dead. Enter the reason for marking as dead";
										} else {
											msg = "The selected SKU's will be marked as dead. Enter the reason for marking as dead";
										}
										alertify.prompt(msg, function (e, str) {
											if (e) {
												$scope.finalRequests = [];
												markAsDeadReason = str;
												if (markAsDeadReason == null || markAsDeadReason.length == 0) { } else if (markAsDeadReason != null || markAsDeadReason.length != 0) {
													angular.forEach(mappingRequestsForMAD, function (mapReq) {
														if (mapReq) {
															mapReq.comments = markAsDeadReason;
															mapReq.mappingType = "MARK_AS_DEAD";
															mapReq.companyID = service.selectedCompany.companyID;
															mapReq.divisionID = service.selectedDivision.divisionID;
															mapReq.updatedUserId = updatedUserID;
															$scope.finalRequests.push(mapReq);
														}
													});
													$scope.action($scope.finalRequests);
												}
											} else {
												//code incase of cancel
												$scope.upcClicked = false;
											}
										});
									}
								}
							};

							/**
							 * U62615
							 * function to set the trimmed plu num in the upc column 
							 */
							$scope.validatePLU = function (results) {
								if (results && results.length > 0) {
									angular.forEach(results, function (sku) {
										if (sku && sku.upc) {
											if (sku.upc <= 99999 && sku.mappingType != "MARK_AS_DEAD") {
												$scope.addPLU = true;
											}
										}
									});
								}
								if ($scope.addPLU && $scope.addPLU == true) {
									$scope.additionalPLUpopup("ADDMAP");
								} else {
									$scope.fromMarkAsdead = false;
									$scope.additionalPLUpopup("INHERITMAP");
								}
							};

							/**
							 * U62615
							 * common method for all actions 
							 */
							$scope.action = function (mappingRequests) {
								if ($scope.fromMarkAsdead && $scope.fromMarkAsdead == true) {
									$scope.validatePLU(mappingRequests);
								} else {
									var reserveAlertMsg = false;

									var disableTargetRefresh = false;
									var actionResults = $scope.baseUrl + "perishable/actions";
									$scope.wrapperRequest = {};
									$scope.wrapperRequest.sourceSearchRequest = {};
									$scope.wrapperRequest.sourceSearchRequest = $scope.searchSourceRequest;
									$scope.wrapperRequest.targetSearchRequest = {};
									$scope.wrapperRequest.targetSearchRequest = $scope.searchTargetRequest;
									$scope.wrapperRequest.mappingrequest = [];
									$scope.wrapperRequest.mappingrequest = mappingRequests;

									$http.post(actionResults, $scope.wrapperRequest, config)
										.then(function (response) {
											//function handles success condition
											if (response.data) {
												if (response.data.actionSuccessStatus == 0) {
													alertify.alert(response.data.errorMessages[0]);
													return;
												} else {
													if (response.data.sourceSearchRequest) {
														$scope.SKUResult = response.data.sourceSearchRequest.skuSearchResults;
														if ((!$scope.SKUResult) || ($scope.SKUResult && $scope.SKUResult.length < 1)) {
															$scope.displaySourceNoResult = true;
														} else {
															$scope.displaySourceNoResult = false;
														}
														$scope.trimPLUFunc($scope.SKUResult);
														if (response.data.sourceSearchRequest.sourceCount && response.data.sourceSearchRequest.skuSearchResults) {
															$scope.sourceCount = response.data.sourceSearchRequest.sourceCount;
															$scope.sourceShowCount = response.data.sourceSearchRequest.skuSearchResults.length;

															if ($scope.sourceCount <= $scope.sourceShowCount) {
																$scope.sourceCount = $scope.sourceShowCount;
															}
														} else {
															$scope.sourceCount = 0;
															$scope.sourceShowCount = 0;
														}
													}
													for (var i = 0; i < response.data.mappingrequest.length; i++) {
														if (response.data.mappingrequest[i].mappingType == "ADD_MAP" ||
															response.data.mappingrequest[i].mappingType == "INHERIT_MAP") {
															disableTargetRefresh = false;
															break;
														} else {
															if (response.data.mappingrequest[i].mappingType == "RESERVED") {
																reserveAlertMsg = true;
															}
															disableTargetRefresh = true;
														}
													}

													if (!disableTargetRefresh) {
														if (response.data.targetSearchRequest) {
															$scope.setItemType($scope.searchTargetRequest);
															$scope.CICResult = response.data.targetSearchRequest.cicSearchResults;
															if ((!$scope.CICResult) || ($scope.CICResult && $scope.CICResult.length < 1)) {
																$scope.displayTargetNoResult = true;
															} else {
																$scope.displayTargetNoResult = false;
															}
															if (response.data.targetSearchRequest.targetCount && response.data.targetSearchRequest.cicSearchResults) {
																$scope.targetCount = response.data.targetSearchRequest.targetCount;
																$scope.targetShowCount = response.data.targetSearchRequest.cicSearchResults.length;

																if ($scope.targetCount <= $scope.targetShowCount) {
																	$scope.targetCount = $scope.targetShowCount;
																}
															} else {
																$scope.targetCount = 0;
																$scope.targetShowCount = 0;
															}

														}
													}

													$scope.markedSKUs = [];
													$scope.markedCICs = [];
													$scope.finalRequests = [];
													$scope.unselectedMapRequests = [];
													$scope.mappingRequests = [];
													$scope.validateSourceAddMapFunc = false;
													$scope.upcClicked = false;
													$scope.disableReserved = false;
													$scope.returnLists = [];
													$scope.setResultRowColors($scope.SKUResult, "source");
													$scope.setPaginate($scope.SKUResult);
													if (!disableTargetRefresh) {
														$scope.setResultRowColors($scope.CICResult, "target");
													}
													if (reserveAlertMsg) {
														alertify.alert("Selected Items moved to Reserve category.");
														return;
													} else {
														alertify.alert(response.data.errorMessages[0]);
														return;
													}
												}
											}
										}, function (response1) {
											//function handles error condition
											alertify.alert("There was an issue during the conversion.");
											return;
										});
								}
							};

							/**
							 *  U63178
							 *  Function to change usage type
							 */
							$scope.changeUsageType = function (type) {
								var isSameUsageType = false;
								$scope.wrapperRequest = {};
								$scope.wrapperRequest.expenseChangeRequest = [];

								if (!$scope.markedSKUs || $scope.markedSKUs.length < 1) {
									alertify.alert("Select any items from SKU.");
									return;
								} else if ($scope.markedCICs && $scope.markedCICs.length > 0) {
									alertify.alert("Unselect CIC and proceed.");
									return;
								} else {
									if ($scope.markedSKUs) {
										angular.forEach($scope.markedSKUs, function (sku) {
											$scope.expenseRequest = {};
											$scope.expenseRequest.companyID = $scope.companyID;
											$scope.expenseRequest.divisionID = $scope.divisionID;
											$scope.expenseRequest.sku = sku.sku;
											$scope.expenseRequest.expenseTypeCurrent = sku.usage;
											$scope.expenseRequest.expeseTypeChange = type;
											$scope.expenseRequest.updatedbyUser = service.userId;
											if (type != sku.usage) {
												$scope.wrapperRequest.expenseChangeRequest.push($scope.expenseRequest);
											} else {
												isSameUsageType = true;
											}
										});
										$scope.wrapperRequest.sourceSearchRequest = {};
										$scope.wrapperRequest.sourceSearchRequest = $scope.searchSourceRequest;

										if (isSameUsageType) {
											alertify.alert("Conversion to same Usage Ind will be omitted.");
											isSameUsageType = false;
										}
										if ($scope.wrapperRequest.expenseChangeRequest.length == 0)
											return;


										var setUsageTypeUrl = $scope.baseUrl + "perishable/changeExpenseType";

										$http.post(setUsageTypeUrl, $scope.wrapperRequest, config)
											.then(function (response) {
												//function handles success condition
												if (response.data) {
													if (response.data.sourceSearchRequest) {
														$scope.SKUResult = response.data.sourceSearchRequest.skuSearchResults;
														if ((!$scope.SKUResult) || ($scope.SKUResult && $scope.SKUResult.length < 1)) {
															$scope.displaySourceNoResult = true;
														} else {
															$scope.displaySourceNoResult = false;
														}
														$scope.trimPLUFunc($scope.SKUResult);
														if (response.data.sourceSearchRequest.sourceCount && response.data.sourceSearchRequest.skuSearchResults) {
															$scope.sourceCount = response.data.sourceSearchRequest.sourceCount;
															$scope.sourceShowCount = response.data.sourceSearchRequest.skuSearchResults.length;

															if ($scope.sourceCount <= $scope.sourceShowCount) {
																$scope.sourceCount = $scope.sourceShowCount;
															}
														} else {
															$scope.sourceCount = 0;
															$scope.sourceShowCount = 0;
														}
													}
													$scope.markedSKUs = [];
													$scope.validateSourceAddMapFunc = false;
													$scope.unselectedMapRequests = [];
													$scope.selectedMapRequests = [];
													$scope.returnLists = [];
													$scope.setResultRowColors($scope.SKUResult, "source");
													$scope.setPaginate($scope.SKUResult);
												}
											}, function (response1) {
												//function handles error condition
											});
									}
								}
							};

							/**
							 *  U63178
							 *  Function to set sort value.
							 */
							function setSortVal(sortParam) {
								if (sortParam == "sku" || sortParam == "cic" || sortParam == "vcf" || sortParam == "pack") {
									sortParam = sortParam + "/1";
								}
								if (sortParam.charAt(0) === '-') {
									sortParam = sortParam.slice(1);
								} else {
									sortParam = "-" + sortParam;
								}

								return sortParam;
							}

							/**
							 *  U63178
							 *  Function to sort SKU item list.
							 */
							$scope.sortSkuTable = function (sortVal) {
								if ("itemDesc" == sortVal) {
									$(event.target).toggleClass('glyphicon-sort-by-alphabet').toggleClass('glyphicon-sort-by-alphabet-alt');
								} else {
									$(event.target).toggleClass('glyphicon-sort-by-order').toggleClass('glyphicon-sort-by-order-alt');
								}

								switch (sortVal) {
									case 'sku':
										sortVal = setSortVal(skuSortBySku);
										skuSortBySku = sortVal;
										break;
									case 'itemDesc':
										sortVal = setSortVal(skuSortByItemDesc);
										skuSortByItemDesc = sortVal;
										break;
									case 'vcf':
										sortVal = setSortVal(skuSortByVcf);
										skuSortByVcf = sortVal;
										break;
									case 'pack':
										sortVal = setSortVal(skuSortByPack);
										skuSortByPack = sortVal;
										break;
									case 'upc':
										sortVal = setSortVal(skuSortByUpc);
										skuSortByUpc = sortVal;
										break;
									default:
										sortVal = skuSortBySku;
								}

								$scope.skuSortVal = sortVal;
							};

							/**
							 * 	U63178
							 *  Function to sort CIC item list
							 */
							$scope.sortCicTable = function (sortVal) {
								if ("itemDesc" == sortVal) {
									$(event.target).toggleClass('glyphicon-sort-by-alphabet').toggleClass('glyphicon-sort-by-alphabet-alt');
								} else {
									$(event.target).toggleClass('glyphicon-sort-by-order').toggleClass('glyphicon-sort-by-order-alt');
								}

								switch (sortVal) {
									case 'cic':
										sortVal = setSortVal(cicSortByCic);
										cicSortByCic = sortVal;
										break;
									case 'itemDesc':
										sortVal = setSortVal(cicSortByItemDesc);
										cicSortByItemDesc = sortVal;
										break;
									case 'vcf':
										sortVal = setSortVal(cicSortByVcf);
										cicSortByVcf = sortVal;
										break;
									case 'pack':
										sortVal = setSortVal(cicSortByPack);
										cicSortByPack = sortVal;
										break;
									case 'upc':
										sortVal = setSortVal(cicSortByUpc);
										cicSortByUpc = sortVal;
										break;
									default:
										sortVal = cicSortByCic;
								}

								$scope.cicSortVal = sortVal;
							};

							/**
							 * 	U63178
							 *  Function to highlight the entire row
							 */
							$scope.selectEntireRow = function (id, type, item, status) {

								if (type == "source" && (status == 'bgBlue' || status == 'bgLimeBlue')) {

									if ($("#sourcechkbox_" + id).is(':checked')) {
										$("#sourcerow_" + id).removeClass('rowcolorchange');
										$("#sourcechkbox_" + id).prop('checked', false);
										$scope.setSKU(item, false);

									} else {
										$("#sourcerow_" + id).addClass('rowcolorchange');
										$("#sourcechkbox_" + id).prop('checked', true);
										$scope.setSKU(item, true);

									}
								} else {
									if (!$scope.disableCicChkBox) {
										if ($("#targetchkbox_" + id).is(':checked')) {
											$("#targetrow_" + id).removeClass('rowcolorchange');
											$("#targetchkbox_" + id).prop('checked', false);
											$scope.setCIC(item, false);
										} else {
											$("#targetrow_" + id).addClass('rowcolorchange');
											$("#targetchkbox_" + id).prop('checked', true);
											$scope.setCIC(item, true);
										}
									}
								}

							};

							/**
							 * 	U63178
							 *  Function to highlight the entire row
							 */
							$scope.selectEntireRowBadgeClick = function (id, type, item, status) {
								if (type == "source") {
									if ($("#sourcechkbox_" + id).is(':checked')) {
										//dont do anything
									} else {
										$("#sourcerow_" + id).addClass('rowcolorchange');
										$("#sourcechkbox_" + id).prop('checked', true);
										$scope.setSKU(item, true);
									}
								} else if (type == "target") {
									if ($("#targetchkbox_" + id).is(':checked')) {
										//dont do anything
									} else {
										$("#targetrow_" + id).addClass('rowcolorchange');
										$("#targetchkbox_" + id).prop('checked', true);
										$scope.setCIC(item, true);
									}
								}
							};

							/**
							 * 	U63178
							 *  Function to make the checkbox selected on highlight
							 */
							$scope.setChkbox = function (id, type) {
								if (type == "source") {
									if ($("#sourcechkbox_" + id).is(':checked')) {
										$("#sourcechkbox_" + id).prop('checked', false);
									} else {
										$("#sourcechkbox_" + id).prop('checked', true);
									}
								} else {
									if ($("#targetchkbox_" + id).is(':checked')) {
										$("#targetchkbox_" + id).prop('checked', false);
									} else {
										$("#targetchkbox_" + id).prop('checked', true);
									}
								}
							};

							/**
							 *  U63180
							 *  Function to redirect context menu choice to corresponding functionality.
							 */
							$scope.redirectToFunction = function (key) {
								if (key) {
									switch (key) {
										case 'forcenew':
											$scope.forceNew();
											break;
										case 'letautomatch':
											$scope.letAutoMatch();
											break;
										case 'markasdead':
											$scope.markAsDead();
											break;
										case 'addmap':
											$scope.addMap();
											break;
										case 'inheritmap':
											$scope.inheritMap();
											break;
										case 'matchingtarget':
											$scope.matchingTargetListing();
											break;
										case 'reserve':
											$scope.markAsReserve();
											break;
										default:
											break;
									}
								}
							};

							/**
							 *  U63180
							 *  Function to toggle all sub menu when a dropdown item is selected.
							 */
							$scope.filterSubmenuToggle = function (key) {
								if (key) {
									switch (key) {
										case 'source':
											$("#srcFilterByDep").hide();
											$("#srcFilterByWhse").hide();
											$("#srcFilterByDisplay").hide();
											$("#srcFilterByTotalsales").hide();
											$("#srcFilterByUsageType").hide();
											break;

										case 'srcfilterDepClckAction':
											$("#srcFilterByWhse").hide();
											$("#srcFilterByDisplay").hide();
											$("#srcFilterByDep").show();
											$("#srcFilterByTotalsales").hide();
											$("#srcFilterByUsageType").hide();
											break;

										case 'srcfilterWhseClckAction':
											$("#srcFilterByDep").hide();
											$("#srcFilterByDisplay").hide();
											$("#srcFilterByWhse").show();
											$("#srcFilterByTotalsales").hide();
											$("#srcFilterByUsageType").hide();
											break;

										case 'srcfilterDispClckAction':
											$("#srcFilterByDep").hide();
											$("#srcFilterByWhse").hide();
											$("#srcFilterByDisplay").show();
											$("#srcFilterByTotalsales").hide();
											$("#srcFilterByUsageType").hide();
											break;

										case 'srcfilterTotalsaleClckAction':
											$("#srcFilterByDep").hide();
											$("#srcFilterByWhse").hide();
											$("#srcFilterByDisplay").hide();
											$("#srcFilterByTotalsales").show();
											$("#srcFilterByUsageType").hide();
											break;

										case 'srcfilterUsageTypeAction':
											$("#srcFilterByDep").hide();
											$("#srcFilterByWhse").hide();
											$("#srcFilterByDisplay").hide();
											$("#srcFilterByTotalsales").hide();
											$("#srcFilterByUsageType").show();
											break;

										case 'target':
											$("#tgtFilterByDep").hide();
											$("#tgtFilterByWhse").hide();
											$("#tgtFilterByDisplay").hide();
											$("#tgtFilterByUsageType").hide();
											break;

										case 'tgtfilterDepClckAction':
											$("#tgtFilterByWhse").hide();
											$("#tgtFilterByDisplay").hide();
											$("#tgtFilterByDep").show();
											$("#tgtFilterByUsageType").hide();
											break;

										case 'tgtfilterWhseClckAction':
											$("#tgtFilterByDep").hide();
											$("#tgtFilterByDisplay").hide();
											$("#tgtFilterByWhse").show();
											$("#tgtFilterByUsageType").hide();
											break;

										case 'tgtfilterDispClckAction':
											$("#tgtFilterByDep").hide();
											$("#tgtFilterByWhse").hide();
											$("#tgtFilterByDisplay").show();
											$("#tgtFilterByUsageType").hide();
											break;

										case 'tgtfilterUsageTypeAction':
											$("#tgtFilterByDep").hide();
											$("#tgtFilterByWhse").hide();
											$("#tgtFilterByDisplay").hide();
											$("#tgtFilterByUsageType").show();
											break;

										default:
											break;
									}
								}
							};

							/**
							 *  U63178
							 *  SetPaginate for Source
							 */
							$scope.setPaginate = function (result) {
								if (result != null) {
									$scope.paginate.itemsCount = range(1, result.length + 1); // array of items to be paged
									$scope.paginate.pager = {};

									$scope.paginate.setPage = function (page) {
										if (page < 1 || page > $scope.paginate.pager.totalPages) {
											return;
										}

										// get pager object from service
										$scope.paginate.pager = PagerMService.GetPager($scope.paginate.itemsCount.length, page);
										// get current page of items
										$scope.paginate.items = result.slice($scope.paginate.pager.startIndex, $scope.paginate.pager.endIndex + 1);
									};
									$scope.paginate.setPage(1);
								} else {
									$scope.paginate.pager = PagerMService.GetPager(0, 1);
									$scope.paginate.items = [];
								}

							};

							

							

							/**
							 * Change the shelf life count
							 */
							$scope.changeMapDaysCount = function () {
								var selldays = Number($scope.edit_selldt);
								if (selldays) {
									$scope.edit_usedt = selldays + 1;
									$scope.edit_pulldt = selldays;
								}
							};

							/**
							 *  U63178
							 *  Open PLU popup for mapping
							 */
							$scope.additionalPLUpopup = function (type) {
								if ($scope.markedCICs && $scope.markedCICs.length == 1) {
									$scope.edit_skus = [];
									$scope.enableCheckbox = false;
									$scope.edit_dcPackDesc = "";
									$scope.edit_dcSizeDesc = "";
									$scope.edit_hicone = "";
									$scope.edit_rup = "";
									$scope.edit_ring = "";

									var loadOnMapURL = $scope.baseUrl + "perishable/loadOnMapEditFields";
									var loadRequest = {};

									loadRequest.companyId = service.selectedCompany.companyID;
									loadRequest.divisionId = service.selectedDivision.divisionID;
									loadRequest.buyingCic = $scope.markedCICs[0].cic;
									loadRequest.sellingCic = null;
									loadRequest.whseDsd = $scope.markedSKUs[0].absDSDWhse;
									loadRequest.productSKUs = [];
									loadRequest.productSKUs.push($scope.markedSKUs[0].sku);

									$scope.edit_cic = $scope.markedCICs[0].cic;
									$scope.edit_cicDesc = $scope.markedCICs[0].itemDesc;

									for (var i = 0; i < $scope.markedSKUs.length; i++) {
										$scope.edit_skus.push($scope.markedSKUs[i].sku + ' / ' + $scope.markedSKUs[i].itemDesc);
									}

									$http.post(loadOnMapURL, loadRequest, config)
										.then(function (response) {
											//function handles success condition
											$scope.edit_sizeDetails = [];
											$scope.edit_rogDetails = [];
											$scope.edit_sourceWeight = [];
											if (response.data) {
												for (var i = 0; i < response.data.sizeDetails.length; i++) {
													var sizd = response.data.sizeDetails[i].dstCntr + " - " + response.data.sizeDetails[i].dcPackDesc + " - " + response.data.sizeDetails[i].dcSizeDesc;
													$scope.edit_sizeDetails.push(sizd);
													if (i == 0) {
														$scope.edit_dcPackDesc = response.data.sizeDetails[0].dcPackDesc.toString();
														$scope.edit_dcSizeDesc = response.data.sizeDetails[0].dcSizeDesc.toString();
														$scope.edit_autoCostInv = response.data.sizeDetails[0].autoCostInv.toString();
														$scope.edit_billingType = response.data.sizeDetails[0].billingType.toString();
														$scope.edit_buyerNum = response.data.sizeDetails[0].buyerNum.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_dstCntr = response.data.sizeDetails[0].dstCntr.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_handlingCode = response.data.sizeDetails[0].handlingCode.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_randomWtCd = response.data.sizeDetails[0].randomWtCd.toString();
														$scope.edit_costall = response.data.sizeDetails[0].costAllow.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_costib = response.data.sizeDetails[0].costIb.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_costinv = response.data.sizeDetails[0].costInv.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_costven = response.data.sizeDetails[0].costVendor.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_selldt = Number(response.data.sizeDetails[0].shelfLife);
														$scope.edit_usedt = (Number(response.data.sizeDetails[0].shelfLife) + 1);
														$scope.edit_pulldt = Number(response.data.sizeDetails[0].shelfLife);
														$scope.edit_prcFlag = response.data.sizeDetails[0].prcTypeCd.toString().replace(/^\s+|\s+$/gm, '');
													}
												}

												for (var j = 0; j < response.data.rogDetail.length; j++) {
													var rogd = response.data.rogDetail[j];
													var arrnaming = Object.keys(rogd);
													var val = rogd[arrnaming[0]].rog + " - " + rogd[arrnaming[0]].retailUnitPack + " - " + rogd[arrnaming[0]].ring + " - " + rogd[arrnaming[0]].hicone;
													$scope.edit_rogDetails.push(val);
													if (rogd[arrnaming[0]].topRank == true) {
														$scope.edit_hicone = rogd[arrnaming[0]].hicone.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_rup = rogd[arrnaming[0]].retailUnitPack.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_ring = rogd[arrnaming[0]].ring.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_foodstamp = rogd[arrnaming[0]].foodStamp.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_tagNo = rogd[arrnaming[0]].tagNumber.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_tagSize = rogd[arrnaming[0]].tagSize.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_tareCd = rogd[arrnaming[0]].tareCd.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_sgncount1 = rogd[arrnaming[0]].sgnCount1.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_sgncount2 = rogd[arrnaming[0]].sgnCount2.toString().replace(/^\s+|\s+$/gm, '');
														$scope.edit_sgncount3 = rogd[arrnaming[0]].sgnCount3.toString().replace(/^\s+|\s+$/gm, '');
													}
												}

												for (var i = 0; i < response.data.sourceWieght.length; i++) {
													var wtd = response.data.sourceWieght[i].prodWt;
													$scope.edit_sourceWeight.push(wtd);
													if (i == 0) {
														$scope.edit_prodWt = response.data.sourceWieght[0].prodWt.toString().replace(/^\s+|\s+$/gm, '');
													}
												}
												$scope.markedPlus = [];
												if (type == "ADDMAP") {
													for (var i = 0; i < $scope.markedSKUs.length; i++) {
														for (var j = 0; j < $scope.markedSKUs[i].upc.length; j++) {
															if ($scope.markedSKUs[i].upc[j] <= 99999 && $scope.markedPlus.indexOf($scope.markedSKUs[i].upc[j])) {
																$scope.markedPlus.push($scope.markedSKUs[i].upc[j]);
															}
														}
													}

													if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
														for (var k = 0; k < $scope.unselectedMapRequests.length; k++) {
															for (var l = 0; l < $scope.markedPlus.length; l++) {
																if ($scope.unselectedMapRequests[k].upc == $scope.markedPlus[l]) {
																	$scope.markedPlus.splice(l, 1);
																}
															}
														}
													}
												}

												document.getElementById('edit_dcPackDescID').style.removeProperty('border');
												document.getElementById('edit_dcSizeDescID').style.removeProperty('border');
												document.getElementById('edit_rupID').style.removeProperty('border');
												document.getElementById('edit_ringID').style.removeProperty('border');
												document.getElementById('edit_hiconeID').style.removeProperty('border');
												document.getElementById('edit_handlingCodeID').style.removeProperty('border');
												document.getElementById('edit_buyerNumID').style.removeProperty('border');
												document.getElementById('edit_randomWtCdID').style.removeProperty('border');
												document.getElementById('edit_autoCostInvID').style.removeProperty('border');
												document.getElementById('edit_billingTypeID').style.removeProperty('border');
												document.getElementById('edit_foodstampID').style.removeProperty('border');
												document.getElementById('edit_tareCdID').style.removeProperty('border');
												document.getElementById('edit_tagSizeID').style.removeProperty('border');
												document.getElementById('edit_tagNoID').style.removeProperty('border');
												document.getElementById('edit_sgncount1ID').style.removeProperty('border');
												document.getElementById('edit_sgncount2ID').style.removeProperty('border');
												document.getElementById('edit_sgncount3ID').style.removeProperty('border');
												document.getElementById('edit_prcFlagID').style.removeProperty('border');
												document.getElementById('edit_costallID').style.removeProperty('border');
												document.getElementById('edit_costibID').style.removeProperty('border');
												document.getElementById('edit_costinvID').style.removeProperty('border');
												document.getElementById('edit_costvenID').style.removeProperty('border');
												document.getElementById('edit_selldtID').style.removeProperty('border');
												document.getElementById('edit_usedtID').style.removeProperty('border');
												document.getElementById('edit_pulldtID').style.removeProperty('border');

												$("#pluupload").modal("show");
												for (var k = 0; k < $scope.markedPlus.length; k++) {
													if (document.getElementById('tgtPLU_' + k)) {
														document.getElementById('tgtPLU_' + k).value = "";
														document.getElementById('tgtPLU_' + k).style.removeProperty('border');
													}
												}
											}
										}, function (response1) {
											//function handles error condition
										});
								} else {
									alertify.alert("Select one CIC item.");
									return;
								}
							};

							/**
							 *  U63178
							 *  Submission on PLU popup
							 */
							$scope.mappingWithPLU = function () {
								var errorDetected = false;
								var pluRequest = [];

								if ($scope.finalRequests.length > 0) {
									pluRequest = $scope.finalRequests;
								} else {
									pluRequest = $scope.mappingRequests;
								}

								if (pluRequest) {
									if (!$scope.edit_dcPackDesc) {
										document.getElementById('edit_dcPackDescID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_dcPackDescID').style.removeProperty('border');
									}
									if (!$scope.edit_dcSizeDesc) {
										document.getElementById('edit_dcSizeDescID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_dcSizeDescID').style.removeProperty('border');
									}
									if (!$scope.edit_rup) {
										document.getElementById('edit_rupID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_rupID').style.removeProperty('border');
									}
									if (!$scope.edit_ring) {
										document.getElementById('edit_ringID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_ringID').style.removeProperty('border');
									}
									if (!$scope.edit_hicone) {
										document.getElementById('edit_hiconeID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_hiconeID').style.removeProperty('border');
									}
									if (!$scope.edit_prodWt) {
										document.getElementById('edit_prodWtID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_prodWtID').style.removeProperty('border');
									}
									if (!$scope.edit_handlingCode) {
										document.getElementById('edit_handlingCodeID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_handlingCodeID').style.removeProperty('border');
									}
									if (!$scope.edit_buyerNum) {
										document.getElementById('edit_buyerNumID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_buyerNumID').style.removeProperty('border');
									}
									if (!$scope.edit_autoCostInv) {
										document.getElementById('edit_autoCostInvID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_autoCostInvID').style.removeProperty('border');
									}
									if (!$scope.edit_foodstamp) {
										document.getElementById('edit_foodstampID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_foodstampID').style.removeProperty('border');
									}
									if (!$scope.edit_tareCd) {
										document.getElementById('edit_tareCdID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_tareCdID').style.removeProperty('border');
									}
									if (!$scope.edit_tagSize) {
										document.getElementById('edit_tagSizeID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_tagSizeID').style.removeProperty('border');
									}
									if (!$scope.edit_tagNo) {
										document.getElementById('edit_tagNoID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_tagNoID').style.removeProperty('border');
									}
									if (!$scope.edit_sgncount1 || !$scope.edit_sgncount2 || !$scope.edit_sgncount3) {
										document.getElementById('edit_sgncount1ID').style.borderColor = "red";
										document.getElementById('edit_sgncount2ID').style.borderColor = "red";
										document.getElementById('edit_sgncount3ID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_sgncount1ID').style.removeProperty('border');
										document.getElementById('edit_sgncount2ID').style.removeProperty('border');
										document.getElementById('edit_sgncount3ID').style.removeProperty('border');
									}
									if (!$scope.edit_prcFlag) {
										document.getElementById('edit_prcFlagID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_prcFlagID').style.removeProperty('border');
									}
									if (!$scope.edit_costall) {
										document.getElementById('edit_costallID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_costallID').style.removeProperty('border');
									}
									if (!$scope.edit_costib) {
										document.getElementById('edit_costibID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_costibID').style.removeProperty('border');
									}
									if (!$scope.edit_costinv) {
										document.getElementById('edit_costinvID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_costinvID').style.removeProperty('border');
									}
									if (!$scope.edit_costven) {
										document.getElementById('edit_costvenID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_costvenID').style.removeProperty('border');
									}
									if ($scope.edit_selldt === "") {
										document.getElementById('edit_selldtID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_selldtID').style.removeProperty('border');
									}
									if ($scope.edit_usedt === "") {
										document.getElementById('edit_usedtID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_usedtID').style.removeProperty('border');
									}
									if ($scope.edit_pulldt === "") {
										document.getElementById('edit_pulldtID').style.borderColor = "red";
										errorDetected = true;
									} else {
										document.getElementById('edit_pulldtID').style.removeProperty('border');
									}

									if ($scope.markedPlus && $scope.markedPlus.length > 0) {
										angular.forEach(pluRequest, function (mapReq) {
											if (mapReq && mapReq.mappingType != "MARK_AS_DEAD") {
												for (var i = 0; i < $scope.markedPlus.length; i++) {
													if (mapReq.upc == $scope.markedPlus[i]) {
														if (document.getElementById('tgtPLU_' + i).value != "" && document.getElementById('tgtPLU_' + i).value.length < 6) {
															mapReq.targetPLU = document.getElementById('tgtPLU_' + i).value;
															document.getElementById('tgtPLU_' + i).style.removeProperty('border');
														} else {
															mapReq.targetPLU = null;
															document.getElementById('tgtPLU_' + i).style.borderColor = "red";
															errorDetected = true;

														}
													}
												}
											}
										});

										$scope.fromMarkAsdead = false;
										$scope.addPLU = false;
									}
									if (errorDetected == true)
										return;

									angular.forEach(pluRequest, function (mapReq) {
										if (mapReq && mapReq.mappingType != "MARK_AS_DEAD") {
											mapReq.targetEdited = true;
											mapReq.dcPackDesc = $scope.edit_dcPackDesc;
											mapReq.dcSizeDsc = $scope.edit_dcSizeDesc;
											mapReq.retailUnitPack = $scope.edit_rup;
											mapReq.ring = $scope.edit_ring;
											mapReq.hicone = $scope.edit_hicone;
											mapReq.autoCostInv = $scope.edit_autoCostInv;
											mapReq.billingType = $scope.edit_billingType;
											mapReq.buyerNum = $scope.edit_buyerNum;
											mapReq.prcTypeCd = $scope.edit_prcFlag;
											mapReq.handlingCode = $scope.edit_handlingCode;
											mapReq.randomWtCd = $scope.edit_randomWtCd;
											mapReq.costAllow = $scope.edit_costall;
											mapReq.costIb = $scope.edit_costib;
											mapReq.costInv = $scope.edit_costinv;
											mapReq.costVend = $scope.edit_costven;
											mapReq.sellByDays = $scope.edit_selldt;
											mapReq.useByDays = $scope.edit_usedt;
											mapReq.pullBydays = $scope.edit_pulldt;
											mapReq.fdStmp = $scope.edit_foodstamp;
											mapReq.labelNumbers = $scope.edit_tagNo;
											mapReq.labelSize = $scope.edit_tagSize;
											mapReq.tareCd = $scope.edit_tareCd;
											mapReq.sgnCount1 = $scope.edit_sgncount1;
											mapReq.sgnCount2 = $scope.edit_sgncount2;
											mapReq.sgnCount3 = $scope.edit_sgncount3;
											mapReq.prodwght = $scope.edit_prodWt;
										}
									});
									$("#pluupload").modal("hide");
									$scope.action(pluRequest);
								};
							};

							/**
							 * dnd-dragging determines what data gets serialized and send to the receiver
							 * of the drop. While we usually just send a single object, we send the array
							 * of all selected items here.
							 */
							$scope.getSelectedItemsIncluding = function (list, item) {
								item.selected = true;
								return list.items.filter(function (item) {
									return item.selected;
								});
							};

							/**
							 * In the dnd-drop callback, we now have to handle the data array that we
							 * sent above. We handle the insertion into the list ourselves. By returning
							 * true, the dnd-list directive won't do the insertion itself.
							 */
							$scope.onDrop = function (list, items, index) {
								angular.forEach(items, function (item) {
									item.selected = false;
								});
								list.items = list.items.slice(0, index)
									.concat(items)
									.concat(list.items.slice(index));
								return true;
							};

							/**
							 * Last but not least, we have to remove the previously dragged items in the
							 * dnd-moved callback.
							 */
							$scope.onMoved = function (list) {
								list.items = list.items.filter(function (item) {
									return !item.selected;
								});
							};

						});
					});
				}
			}
		]);


	function range(start, edge, step) {
		// If only one number was passed in make it the edge and 0 the start.
		if (arguments.length == 1) {
			edge = start;
			start = 0;
		}

		// Validate the edge and step numbers.
		edge = edge || 0;
		step = step || 1;

		// Create the array of numbers, stopping befor the edge.
		for (var ret = [];
			(edge - start) * step > 0; start += step) {
			ret.push(start);
		}
		return ret;
	}

	function PagerMService() {
		// service definition
		var service = {};

		service.GetPager = GetPager;

		return service;

		// service implementation
		function GetPager(totalItems, currentPage, pageSize) {
			// default to first page
			currentPage = currentPage || 1;

			// default page size is 200
			pageSize = pageSize || 200;

			// calculate total pages
			var totalPages = Math.ceil(totalItems / pageSize);

			var startPage, endPage;
			if (totalPages <= 5) {
				// less than 10 total pages so show all
				startPage = 1;
				endPage = totalPages;
			} else {
				// more than 10 total pages so calculate start and end pages
				if (currentPage < 6) {
					startPage = 1;
					endPage = 5;
				} else if (currentPage + 4 >= totalPages) {
					startPage = totalPages - 4;
					endPage = totalPages;
				} else {
					startPage = currentPage - 2;
					endPage = currentPage + 2;
				}
			}

			// calculate start and end item indexes
			var startIndex = (currentPage - 1) * pageSize;
			var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

			// create an array of pages to ng-repeat in the pager control
			var pages = range(startPage, endPage + 1);

			// return object with all pager properties required by the view
			return {
				totalItems: totalItems,
				currentPage: currentPage,
				pageSize: pageSize,
				totalPages: totalPages,
				startPage: startPage,
				endPage: endPage,
				startIndex: startIndex,
				endIndex: endIndex,
				pages: pages
			};
		}
	}

})();