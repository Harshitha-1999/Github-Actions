(function(){
	'use strict';
	
	myApp.config(['$routeProvider','$httpProvider', function($routeProvider, $httpProvider){
		$routeProvider
		.when("/",{
			templateUrl : "Home.html",
			controller : "HomeController"
		})
		.when("/UpdateOverride",{
			templateUrl : "UpdateOverride.html",
			controller : "UpdateOverrideController"
		})
		.when("/Augmented",{
			templateUrl : "Augmented.html",
			controller : "AugmentedController"
		})
		.when("/ManualMapping",{
			templateUrl : "ManualMapping.html",
			controller : "ManualMappingController"
		})
		.when("/DisplayerItems",{
			templateUrl : "DisplayerItems.html",
			controller : "DisplayerItemsController"
		})
		.when("/MultiUnitType",{
			templateUrl : "MultiUnitTypeItems.html",
			controller : "MultiUnitTypeController"
		})
		.when("/Lookup",{
			templateUrl : "lookup/Lookup.html",
			controller : "LookupController"
		});
		
		 //initialize get if not there
	    if (!$httpProvider.defaults.headers.get) {
	        $httpProvider.defaults.headers.get = {};    
	    }
	    //disable IE ajax request caching
	    $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
	}]);
	

})();