(function(){
	'use strict';

	myApp.controller('MultiUnitTypeController',['$scope', '$filter', '$http', '$location', '$timeout', 'blockUI','service',
	        function MultiUnitTypeController($scope, $filter, $http, $location, $timeout, blockUI, service){
		


		$scope.totalDisplayedSource = 0;
		$scope.totalDisplayedTarget = 0;
		$scope.sourceLength = 0;
		$scope.targetLength = 0;
		
		/**
		 * Initialise
		 */
		
		if(service.baseUrlFunction() != undefined ) {
			service.baseUrlFunction().then(function(url){
				$scope.baseUrl =  url;
		
				service.getHeaders().then(function(header) {
					var config = header
	//      });
		
		$scope.init = function (companyID, divisionID) {
			$scope.departmentIncludesSource = [];
			$scope.departmentIncludesTarget = [];
			$scope.whsedsdIncludesSource = [];
			$scope.whsedsdIncludesTarget = [];
			$scope.searchSource = {};
			$scope.searchTarget = {};
			
			$scope.departmentIncludesSourceManual = [];
			$scope.departmentIncludesTargetManual = [];
			$scope.whsedsdIncludesSourceManual = [];
			$scope.conversionIncludesSourceManual = [];
			$scope.whsedsdIncludesTargetManual = [];
			$scope.searchSourceManual = {};
			$scope.searchTargetManual = {};

			$scope.departmentIncludesSourceAuto = [];
			$scope.departmentIncludesTargetAuto = [];
			$scope.whsedsdIncludesSourceAuto = [];
			$scope.conversionIncludesSourceAuto = [];
			$scope.whsedsdIncludesTargetAuto = [];
			$scope.searchSourceAuto = {};
			$scope.searchTargetAuto = {};

			$scope.isTBMSourceApplied = "mufilterUnapplied";
			$scope.isMMMSourceApplied = "mufilterUnapplied";
			$scope.isAAMSourceApplied = "mufilterUnapplied";
			$scope.isTBMTargetApplied = "mufilterUnapplied";
			$scope.isMMMTargetApplied = "mufilterUnapplied";
			$scope.isAAMTargetApplied = "mufilterUnapplied";
			
			$scope.companyId = companyID;
			$scope.divisionId = divisionID;
			if(companyID && divisionID){
				$scope.displayMultiUnitpage = true;
				$scope.openDetails ("tobematchedradio");
				document.getElementById("tobematchedmultiunittypeyes").checked = true;
				document.getElementById("tobematchedmultiunittypeno").checked = false;
				$scope.multiUnitTypeButtonValue = 'Y';
			}
			var windowHeight = $(window).innerHeight();
            $('.muttdDiv').css('height', windowHeight/4);
		};
		
		/**
		 * Method to load each tab details
		 */
		$scope.openDetails=function (tabID){
			$scope.totalDisplayedSource = 0;
			$scope.totalDisplayedTarget = 0;
			if(tabID+'contents' == "tobematchedradiocontents"){
				document.getElementById('tobematchedradiocontents').style.display = "block";
				document.getElementById('manuallymatchedradiocontents').style.display = "none";
				document.getElementById('automatchedradiocontents').style.display = "none";
				document.getElementById("tobematchedradio").checked = true;
				document.getElementById("manuallymatchedradio").checked = false;
				document.getElementById("automatchedradio").checked = false;
				$scope.tobematchedsourcedropdownvalue = "tobematchedsourceitemdescription";
				$scope.tobematchedtargetdropdownvalue = "tobematchedtargetitemdescription";
				$scope.loadMultiUnitTypeSourceTargetData($scope.companyId, $scope.divisionId);
			}
			else if(tabID+'contents' == "manuallymatchedradiocontents"){
				document.getElementById('manuallymatchedradiocontents').style.display = "block";
				document.getElementById('tobematchedradiocontents').style.display = "none";
				document.getElementById('automatchedradiocontents').style.display = "none";
				document.getElementById("tobematchedradio").checked = false;
				document.getElementById("manuallymatchedradio").checked = true;
				document.getElementById("automatchedradio").checked = false;
				$scope.manuallymatchedsourcedropdownvalue = "manuallymatchedsourceitemdescription";
				$scope.manuallymatchedtargetdropdownvalue = "manuallymatchedtargetitemdescription";
				$scope.loadMultiUnitTypeManuallyMatchedSourceTargetData($scope.companyId, $scope.divisionId);
			}
			else if(tabID+'contents' == "automatchedradiocontents"){
				document.getElementById('automatchedradiocontents').style.display = "block";
				document.getElementById('tobematchedradiocontents').style.display = "none";
				document.getElementById('manuallymatchedradiocontents').style.display = "none";
				document.getElementById("tobematchedradio").checked = false;
				document.getElementById("manuallymatchedradio").checked = false;
				document.getElementById("automatchedradio").checked = true;
				$scope.automatchedsourcedropdownvalue = "automatchedsourceitemdescription";
				$scope.automatchedtargetdropdownvalue = "automatchedtargetitemdescription";
				$scope.loadMultiUnitTypeAutoMatchedSourceTargetData($scope.companyId, $scope.divisionId);
			}
		};


		/**
		 * Method to load more source data in each tab
		 */
		$scope.loadMoreSource = function () {
			$scope.currentTotalDisplayedValueSource = $scope.totalDisplayedSource;
			$scope.totalDisplayedSource = $scope.totalDisplayedSource + 200;
			if($scope.totalDisplayedSource >= $scope.sourceLength){
				$scope.totalDisplayedSource = $scope.currentTotalDisplayedValueSource + ($scope.sourceLength - $scope.currentTotalDisplayedValueSource);
			}
		};

		/**
		 * Method to load more target data in each tab
		 */
		$scope.loadMoreTarget = function (){
			$scope.currentTotalDisplayedValueTarget = $scope.totalDisplayedTarget;
			$scope.totalDisplayedTarget = $scope.totalDisplayedTarget + 200;
			if($scope.totalDisplayedTarget >= $scope.targetLength){
				$scope.totalDisplayedTarget = $scope.currentTotalDisplayedValueTarget + ($scope.targetLength - $scope.currentTotalDisplayedValueTarget);
			}
		};

		$scope.openUPC= function (index, status){
			if(status == 'P'){
				$("#multiUnitTypeModal_"+index).show();
			}
			else if(status == 'M'){
				$("#multiUnitTypeModalManuallyMap_"+index).show();
			}
			else{
				$("#multiUnitTypeModalAutoMap_"+index).show();
			}
		};

		/**
		 * Close UPC popup action for source items under each tab
		 */
		$scope.closeUPC= function (index, status){
			if(status == 'P'){
				$("#multiUnitTypeModal_"+index).hide();
			}
			else if(status == 'M'){
				$("#multiUnitTypeModalManuallyMap_"+index).hide();
			}
			else{
				$("#multiUnitTypeModalAutoMap_"+index).hide();
			}
		};

		/**
		 * Open UPC popup action for target items under each tab
		 */
		$scope.openUPCTarget= function (index, status){
			if(status == 'P'){
				$("#multiUnitTypeModalTarget_"+index).show();
			}
			else if(status == 'M'){
				$("#multiUnitTypeModalTargetManuallyMap_"+index).show();
			}
			else{
				$("#multiUnitTypeModalTargetAutoMap_"+index).show();
			}
		};

		/**
		 * Close UPC popup action for target items under each tab
		 */
		$scope.closeUPCTarget= function (index, status){
			if(status == 'P'){
				$("#multiUnitTypeModalTarget_"+index).hide();
			}
			else if(status == 'M'){
				$("#multiUnitTypeModalTargetManuallyMap_"+index).hide();
			}
			else{
				$("#multiUnitTypeModalTargetAutoMap_"+index).hide();
			}
		};

		$scope.openSKU= function (index, status){
			if(status == 'P'){
				$("#multiUnitTypeModalsku_"+index).show();
			}
			else if(status == 'M'){
				$("#multiUnitTypeModalManuallyMapsku_"+index).show();
			}
			else{
				$("#multiUnitTypeModalAutoMapsku_"+index).show();
			}
		};

		/**
		 * Close UPC popup action for source items under each tab
		 */
		$scope.closeSKU= function (index, status){
			if(status == 'P'){
				$("#multiUnitTypeModalsku_"+index).hide();
			}
			else if(status == 'M'){
				$("#multiUnitTypeModalManuallyMapsku_"+index).hide();
			}
			else{
				$("#multiUnitTypeModalAutoMapsku_"+index).hide();
			}
		};

		/**
		 * Refresh data based upon the mapping status
		 */
		
		$scope.resetData = function(status,type,drop)
		{
			var companyID = $scope.companyId;
			var divisionID = $scope.divisionId;

			if(status == 'P'){
				if(type == 'S'){
					$scope.clearTBMSourceFilter();
					$scope.totalDisplayedSource = 0;
					$scope.resetTBMSource(drop);
					
					var loadMultiUnitTypeSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitSourceRefresh/"+companyID+"/"+divisionID+"/"+"P";
					var multiUnitSourceSplitString = " ";
					$http.get(loadMultiUnitTypeSourceTargetDataUrl, config)
					.then(function(response){
						if(response.data.multiUnitSource != null){
							for(var i=0; i<response.data.multiUnitSource.length; i++){
								multiUnitSourceSplitString = response.data.multiUnitSource[i].productHierarchy.split("-");
								response.data.multiUnitSource[i].productHierarchyFirst = multiUnitSourceSplitString[0];
								response.data.multiUnitSource[i].productHierarchySecond = multiUnitSourceSplitString[1];
								response.data.multiUnitSource[i].productHierarchyThird = multiUnitSourceSplitString[2];
							}
							$scope.multiUnitTypeSourceData = response.data.multiUnitSource;
							$scope.sourceLength = response.data.multiUnitSource.length;
							$scope.loadMoreSource();
							$scope.multiUnitTypeSouceDepartmentNames = response.data.multiUnitSource[0].deptNames;
						}
					});

				}
				else if(type == 'T'){
					$scope.clearTBMTargetFilter();
					$scope.totalDisplayedTarget = 0;
					$scope.resetTBMTarget(drop);
					
					var loadMultiUnitTypeSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitTargetRefresh/"+companyID+"/"+divisionID+"/"+"P";
					var multiUnitTargetSplitString = " ";
					$http.get(loadMultiUnitTypeSourceTargetDataUrl, config)
					.then(function(response){
						if(response.data.multiUnitTarget != null){
							for(var i=0; i<response.data.multiUnitTarget.length; i++){
								multiUnitTargetSplitString = response.data.multiUnitTarget[i].smicCode.split("-");
								response.data.multiUnitTarget[i].smicFirst = multiUnitTargetSplitString[0];
								response.data.multiUnitTarget[i].smicSecond = multiUnitTargetSplitString[1];
								response.data.multiUnitTarget[i].smicThird = multiUnitTargetSplitString[2];
								response.data.multiUnitTarget[i].smicFourth = multiUnitTargetSplitString[3];
								response.data.multiUnitTarget[i].smicFifth = multiUnitTargetSplitString[4];
							}
							$scope.multiUnitTypeTargetData = response.data.multiUnitTarget;
							$scope.targetLength = response.data.multiUnitTarget.length;
							$scope.loadMoreTarget();
							$scope.multiUnitTypeTargetDepartmentNames = response.data.multiUnitTarget[0].deptNameList;
						}
					});
				}
			}
			else if(status == 'M'){
				if(type == 'S'){
					$scope.clearMMMSourceFilter();
					$scope.totalDisplayedSource = 0;
					$scope.resetMMMSource(drop);
					
					var loadMultiUnitTypeManuallyMatchedSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitSourceRefresh/"+companyID+"/"+divisionID+"/"+"M";
					var multiUnitManuallyMatchedSourceSplitString = " ";
					$http.get(loadMultiUnitTypeManuallyMatchedSourceTargetDataUrl, config)
					.then(function(response){
						if(response.data.multiUnitSource != null){
							for(var i=0; i<response.data.multiUnitSource.length; i++){
								multiUnitManuallyMatchedSourceSplitString = response.data.multiUnitSource[i].productHierarchy.split("-");
								response.data.multiUnitSource[i].productHierarchyFirst = multiUnitManuallyMatchedSourceSplitString[0];
								response.data.multiUnitSource[i].productHierarchySecond = multiUnitManuallyMatchedSourceSplitString[1];
								response.data.multiUnitSource[i].productHierarchyThird = multiUnitManuallyMatchedSourceSplitString[2];
							}
							$scope.multiUnitTypeManuallyMatchedSourceData = response.data.multiUnitSource;
							$scope.sourceLength = response.data.multiUnitSource.length;
							$scope.loadMoreSource();
							$scope.multiUnitTypeManuallyMatchedSouceDepartmentNames = response.data.multiUnitSource[0].deptNames;
						}
						else{
							$scope.multiUnitTypeManuallyMatchedSourceData = null;
							$scope.sourceLength = 0;
							$scope.loadMoreSource();
						}
					}, function(response){

					});
				}
				else if(type == 'T'){
					$scope.clearMMMTargetFilter();
					$scope.totalDisplayedTarget = 0;
					$scope.resetMMMTarget(drop);
					
					var loadMultiUnitTypeManuallyMatchedSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitTargetRefresh/"+companyID+"/"+divisionID+"/"+"M";
					var multiUnitManuallyMatchedTargetSplitString = " ";
					$http.get(loadMultiUnitTypeManuallyMatchedSourceTargetDataUrl, config)
					.then(function(response){
						if(response.data.multiUnitTarget != null){
							for(var i=0; i<response.data.multiUnitTarget.length; i++){
								multiUnitManuallyMatchedTargetSplitString = response.data.multiUnitTarget[i].smicCode.split("-");
								response.data.multiUnitTarget[i].smicFirst = multiUnitManuallyMatchedTargetSplitString[0];
								response.data.multiUnitTarget[i].smicSecond = multiUnitManuallyMatchedTargetSplitString[1];
								response.data.multiUnitTarget[i].smicThird = multiUnitManuallyMatchedTargetSplitString[2];
								response.data.multiUnitTarget[i].smicFourth = multiUnitManuallyMatchedTargetSplitString[3];
								response.data.multiUnitTarget[i].smicFifth = multiUnitManuallyMatchedTargetSplitString[4];
							}
							$scope.multiUnitTypeManuallyMatchedTargetData = response.data.multiUnitTarget;
							$scope.targetLength = response.data.multiUnitTarget.length;
							$scope.loadMoreTarget();
							$scope.multiUnitTypeManuallyMatchedTargetDepartmentNames = response.data.multiUnitTarget[0].deptNameList;
						}
						else{
							$scope.multiUnitTypeManuallyMatchedTargetData = null;
							$scope.targetLength = 0;
							$scope.loadMoreTarget();
						}
					}, function(response){

					});
				}
			}
			else if(status == 'A'){
				if(type == 'S'){
					$scope.clearAAMSourceFilter();
					$scope.totalDisplayedSource = 0;
					$scope.resetAAMSource(drop);
					
					var loadMultiUnitTypeAutoMatchedSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitSourceRefresh/"+companyID+"/"+divisionID+"/"+"A";
					var multiUnitAutoMatchedSourceSplitString = " ";
					$http.get(loadMultiUnitTypeAutoMatchedSourceTargetDataUrl, config)
					.then(function(response){
						if(response.data.multiUnitSource != null){
							for(var i=0; i<response.data.multiUnitSource.length; i++){
								multiUnitAutoMatchedSourceSplitString = response.data.multiUnitSource[i].productHierarchy.split("-");
								response.data.multiUnitSource[i].productHierarchyFirst = multiUnitAutoMatchedSourceSplitString[0];
								response.data.multiUnitSource[i].productHierarchySecond = multiUnitAutoMatchedSourceSplitString[1];
								response.data.multiUnitSource[i].productHierarchyThird = multiUnitAutoMatchedSourceSplitString[2];
							}
							$scope.multiUnitTypeAutoMatchedSourceData = response.data.multiUnitSource;
							$scope.sourceLength = response.data.multiUnitSource.length;
							$scope.loadMoreSource();
							$scope.multiUnitTypeAutoMatchedSouceDepartmentNames = response.data.multiUnitSource[0].deptNames;
						}
						else{
							$scope.multiUnitTypeAutoMatchedSourceData = null;
							$scope.sourceLength = 0;
							$scope.loadMoreSource();
						}
					}, function(response){

					});
				}
				else if(type == 'T'){
					$scope.clearAAMTargetFilter();
					$scope.totalDisplayedTarget = 0;
					$scope.resetAAMTarget(drop);
					
					var loadMultiUnitTypeAutoMatchedSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitTargetRefresh/"+companyID+"/"+divisionID+"/"+"A";
					var multiUnitAutoMatchedTargetSplitString = " ";
					$http.get(loadMultiUnitTypeAutoMatchedSourceTargetDataUrl, config)
					.then(function(response){
						if(response.data.multiUnitTarget != null){
							for(var i=0; i<response.data.multiUnitTarget.length; i++){
								multiUnitAutoMatchedTargetSplitString = response.data.multiUnitTarget[i].smicCode.split("-");
								response.data.multiUnitTarget[i].smicFirst = multiUnitAutoMatchedTargetSplitString[0];
								response.data.multiUnitTarget[i].smicSecond = multiUnitAutoMatchedTargetSplitString[1];
								response.data.multiUnitTarget[i].smicThird = multiUnitAutoMatchedTargetSplitString[2];
								response.data.multiUnitTarget[i].smicFourth = multiUnitAutoMatchedTargetSplitString[3];
								response.data.multiUnitTarget[i].smicFifth = multiUnitAutoMatchedTargetSplitString[4];
							}
							$scope.multiUnitTypeAutoMatchedTargetData = response.data.multiUnitTarget;
							$scope.targetLength = response.data.multiUnitTarget.length;
							$scope.loadMoreTarget();
							$scope.multiUnitTypeAutoMatchedTargetDepartmentNames = response.data.multiUnitTarget[0].deptNameList;
						}
						else{
							$scope.multiUnitTypeAutoMatchedTargetData = null;
							$scope.targetLength = 0;
							$scope.loadMoreTarget();
						}
					}, function(response){

					});
				}
			}
		};

		/**
		 * Reset to be matched source
		 */
		$scope.resetTBMSource = function(drop){
			document.getElementById("tobematchedmultiunittypeyes").checked = true;
			document.getElementById("tobematchedmultiunittypeno").checked = false;
			$scope.multiUnitTypeButtonValue = 'Y';
			$scope.tobematchedsourcedropdownvalue = "tobematchedsourceitemdescription";
			if(drop == "tobematchedsourceitemdescription"){
				document.getElementById("tobematchedsourcesearchbox").value = null;
			}
			else if(drop == "tobematchedsourcevendorname"){
				document.getElementById("tobematchedsourcesearchbox").value = null;
			}
			else if(drop == "tobematchedsourcehierarchy"){
				document.getElementById("tobematchedsourcehierarchyfirst").value = null;	
				document.getElementById("tobematchedsourcehierarchysecond").value = null;	
				document.getElementById("tobematchedsourcehierarchythird").value = null;
			}
			else if(drop == "tobematchedsourceprodsku"){
				document.getElementById("tobematchedsourcesearchbox").value = null;
			}

		};

		/**
		 * Reset to be matched target
		 */
		$scope.resetTBMTarget = function(drop){
			$scope.tobematchedtargetdropdownvalue = "tobematchedtargetitemdescription";
			if(drop == "tobematchedtargetitemdescription"){
				document.getElementById("tobematchedtargetsearchbox").value = null;
			}
			else if(drop == "tobematchedtargetvendorname"){
				document.getElementById("tobematchedsourcesearchbox").value = null;
			}
			else if(drop == "tobematchedtargetcic"){
				document.getElementById("tobematchedtargetsearchbox").value = null;
			}
			else if(drop == "tobematchedtargetsmic"){
				document.getElementById("tobematchedsmicfirst").value = null;	
				document.getElementById("tobematchedsmicsecond").value = null;	
				document.getElementById("tobematchedsmicthird").value = null;
				document.getElementById("tobematchedsmicfourth").value = null;
				document.getElementById("tobematchedsmicfifth").value = null;
			}
		};

		/**
		 * Reset manually matched source
		 */
		$scope.resetMMMSource = function(drop){
			$scope.multiUnitTypeButtonValue = 'Y';
			$scope.manuallymatchedsourcedropdownvalue = "manuallymatchedsourceitemdescription";
			if(drop == "manuallymatchedsourceitemdescription"){
				document.getElementById("manuallymatchedsourcesearchbox").value = null;
			}
			else if(drop == "manuallymatchedsourcevendorname"){
				document.getElementById("manuallymatchedsourcesearchbox").value = null;
			}
			else if(drop == "manuallymatchedsourcehierarchy"){
				document.getElementById("manuallymatchedsourcehierarchyfirst").value = null;	
				document.getElementById("manuallymatchedsourcehierarchysecond").value = null;	
				document.getElementById("manuallymatchedsourcehierarchythird").value = null;
			}
			else if(drop == "manuallymatchedsourceprodsku"){
				document.getElementById("manuallymatchedsourcesearchbox").value = null;
			}
		};

		/**
		 * Reset manually matched target
		 */
		$scope.resetMMMTarget = function(drop){
			$scope.manuallymatchedtargetdropdownvalue = "manuallymatchedtargetitemdescription";
			if(drop == "manuallymatchedtargetitemdescription"){
				document.getElementById("manuallymatchedtargetsearchbox").value = null;
			}
			else if(drop == "manuallymatchedtargetvendorname"){
				document.getElementById("manuallymatchedtargetsearchbox").value = null;
			}
			else if(drop == "manuallymatchedtargetcic"){
				document.getElementById("manuallymatchedtargetsearchbox").value = null;
			}
			else if(drop == "manuallymatchedtargetsmic"){
				document.getElementById("manuallymatchedsmicfirst").value = null;	
				document.getElementById("manuallymatchedsmicsecond").value = null;	
				document.getElementById("manuallymatchedsmicthird").value = null;
				document.getElementById("manuallymatchedsmicfourth").value = null;
				document.getElementById("manuallymatchedsmicfifth").value = null;
			}
		};

		/**
		 * Reset auto matched source
		 */
		$scope.resetAAMSource = function(drop){
			$scope.multiUnitTypeButtonValue = 'Y';
			$scope.automatchedsourcedropdownvalue = "automatchedsourceitemdescription";

			if(drop == "automatchedsourceitemdescription"){
				document.getElementById("automatchedsourcesearchbox").value = null;
			}
			else if(drop == "automatchedsourcevendorname"){
				document.getElementById("automatchedsourcesearchbox").value = null;
			}
			else if(drop == "automatchedsourcehierarchy"){
				document.getElementById("automatchedsourcehierarchyfirst").value = null;	
				document.getElementById("automatchedsourcehierarchysecond").value = null;	
				document.getElementById("automatchedsourcehierarchythird").value = null;
			}
			else if(drop == "automatchedsourceprodsku"){
				document.getElementById("automatchedsourcesearchbox").value = null;
			}
		};

		/**
		 * Reset auto matched target
		 */
		$scope.resetAAMTarget = function(drop){
			$scope.automatchedtargetdropdownvalue = "automatchedtargetitemdescription";
			if(drop == "automatchedtargetitemdescription"){
				document.getElementById("automatchedtargetsearchbox").value = null;
			}
			else if(drop == "automatchedtargetvendorname"){
				document.getElementById("automatchedtargetsearchbox").value = null;
			}
			else if(drop == "automatchedtargetcic"){
				document.getElementById("automatchedtargetsearchbox").value = null;
			}
			else if(drop == "automatchedtargetsmic"){
				document.getElementById("automatchedsmicfirst").value = null;	
				document.getElementById("automatchedsmicsecond").value = null;	
				document.getElementById("automatchedsmicthird").value = null;
				document.getElementById("automatchedsmicfourth").value = null;
				document.getElementById("automatchedsmicfifth").value = null;
			}
		};


//		-------------------------------------------------- START OF FILTER BY

		/**
		 * Apply Filter for TBM Source
		 */
		$scope.applyTBMSourceFilter = function(){
			$scope.isTBMSourceApplied = "mufilterApplied";
			$scope.departmentIncludesSource = [];
			$scope.whsedsdIncludesSource = [];
			$scope.searchSource = {};

			$scope.totalDisplayedSource = $scope.sourceLength;
			if($scope.multiUnitTypeSouceDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeSouceDepartmentNames.length;i++)
				{
					if(document.getElementById("tobematchedsourcedepartmentname_"+i).checked)
					{
						$scope.departmentIncludesSource.push($scope.multiUnitTypeSouceDepartmentNames[i]);
					}
				}
			}
			if(document.getElementById("sdsdcheckbox").checked)
			{
				$scope.whsedsdIncludesSource.push('DSD');
			}
			if(document.getElementById("swhsecheckbox").checked)
			{
				$scope.whsedsdIncludesSource.push('WHSE');
			}
			var ph1 = document.getElementById("producthierarchyfirst").value;
			var ph2 = document.getElementById("producthierarchysecond").value;
			var ph3 = document.getElementById("producthierarchythird").value;

			if(ph1)
				$scope.searchSource.productHierarchyFirst = Number(ph1);
			if(ph2)
				$scope.searchSource.productHierarchySecond = Number(ph2);
			if(ph3)
				$scope.searchSource.productHierarchyThird = Number(ph3);
		};

		/**
		 * Set Filter for TBM Source
		 */
		$scope.departmentFilterSource = function(multiUnitTypeSourceData){
			if ($scope.departmentIncludesSource.length > 0) {
				if ($.inArray(multiUnitTypeSourceData.deptName, $scope.departmentIncludesSource) < 0)
					return;
			}        
			if ($scope.whsedsdIncludesSource.length > 0) {
				if ($.inArray(multiUnitTypeSourceData.prodSourceCd, $scope.whsedsdIncludesSource) < 0)
					return;
			} 

			return multiUnitTypeSourceData;
		};

		/**
		 * Clear Filter for TBM Source
		 */
		$scope.clearTBMSourceFilter = function(){
			if($scope.multiUnitTypeSouceDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeSouceDepartmentNames.length;i++)
				{
					document.getElementById("tobematchedsourcedepartmentname_"+i).checked = false;
				}
			}
			document.getElementById("sdsdcheckbox").checked = false;
			document.getElementById("swhsecheckbox").checked = false;
			document.getElementById("producthierarchyfirst").value = null;
			document.getElementById("producthierarchysecond").value = null;
			document.getElementById("producthierarchythird").value = null;
			$scope.departmentIncludesSource = [];
			$scope.whsedsdIncludesSource = [];
			$scope.applyTBMSourceFilter();
			$scope.totalDisplayedSource = 200;
			$scope.isTBMSourceApplied = "mufilterUnapplied";
		};

		/**
		 * Apply Filter for TBM Target
		 */
		$scope.applyTBMTargetFilter = function(){
			$scope.isTBMTargetApplied = "mufilterApplied";
			$scope.departmentIncludesTarget = [];
			$scope.whsedsdIncludesTarget = [];
			$scope.searchTarget = {};

			$scope.totalDisplayedTarget = $scope.targetLength;
			if($scope.multiUnitTypeTargetDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeTargetDepartmentNames.length;i++)
				{
					if(document.getElementById("tobematchedtargetdepartmentname_"+i).checked)
					{
						$scope.departmentIncludesTarget.push($scope.multiUnitTypeTargetDepartmentNames[i]);
					}
				}
			}
			if(document.getElementById("tdsdcheckbox").checked)
			{
				$scope.whsedsdIncludesTarget.push('DSD');
			}
			if(document.getElementById("twhsecheckbox").checked)
			{
				$scope.whsedsdIncludesTarget.push('WHSE');
			}
			var ts1 = document.getElementById("smicfirst").value;
			var ts2 = document.getElementById("smicsecond").value;
			var ts3 = document.getElementById("smicthird").value;
			var ts4 = document.getElementById("smicfourth").value;
			var ts5 = document.getElementById("smicfifth").value;

			if(ts1)
				$scope.searchTarget.smicFirst = Number(ts1);
			if(ts2)
				$scope.searchTarget.smicSecond = Number(ts2);
			if(ts3)
				$scope.searchTarget.smicThird = Number(ts3);
			if(ts4)
				$scope.searchTarget.smicFourth = Number(ts4);
			if(ts5)
				$scope.searchTarget.smicFifth = Number(ts5);
		};

		/**
		 * Set Filter for TBM Target
		 */
		$scope.departmentFilter = function(multiUnitTypeTargetData) {
			if ($scope.departmentIncludesTarget.length > 0) {
				if ($.inArray(multiUnitTypeTargetData.targetDepartment, $scope.departmentIncludesTarget) < 0)
					return;
			}   
			if ($scope.whsedsdIncludesTarget.length > 0) {
				if ($.inArray(multiUnitTypeTargetData.itemTypeWhseDsd, $scope.whsedsdIncludesTarget) < 0)
					return;
			} 
			return multiUnitTypeTargetData;
		};

		/**
		 * Clear Filter for TBM Target
		 */
		$scope.clearTBMTargetFilter = function(){
			if($scope.multiUnitTypeTargetDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeTargetDepartmentNames.length;i++)
				{
					document.getElementById("tobematchedtargetdepartmentname_"+i).checked = false;
				}
			}
			document.getElementById("tdsdcheckbox").checked = false;
			document.getElementById("twhsecheckbox").checked = false;
			document.getElementById("smicfirst").value = null;
			document.getElementById("smicsecond").value = null;
			document.getElementById("smicthird").value = null;
			document.getElementById("smicfourth").value = null;
			document.getElementById("smicfifth").value = null;
			$scope.departmentIncludesTarget = [];
			$scope.whsedsdIncludesTarget = [];
			$scope.applyTBMTargetFilter();
			$scope.totalDisplayedTarget = 200;
			$scope.isTBMTargetApplied = "mufilterUnapplied";
		};

//		-------------------------------------------------
		/**
		 * Apply Filter for Manual Source
		 */
		$scope.applyMMMSourceFilter = function(){
			$scope.isMMMSourceApplied = "mufilterApplied";
			$scope.departmentIncludesSourceManual = [];
			$scope.whsedsdIncludesSourceManual = [];
			$scope.conversionIncludesSourceManual = [];
			$scope.searchSourceManual = {};

			$scope.totalDisplayedSource = $scope.sourceLength;
			if($scope.multiUnitTypeManuallyMatchedSouceDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeManuallyMatchedSouceDepartmentNames.length;i++)
				{
					if(document.getElementById("manuallymatchedsourcedepartmentname_"+i).checked)
					{
						$scope.departmentIncludesSourceManual.push($scope.multiUnitTypeManuallyMatchedSouceDepartmentNames[i]);
					}
				}
			}
			if(document.getElementById("msdsdcheckbox").checked)
			{
				$scope.whsedsdIncludesSourceManual.push('DSD');
			}
			if(document.getElementById("mswhsecheckbox").checked)
			{
				$scope.whsedsdIncludesSourceManual.push('WHSE');
			}
			if(document.getElementById("mspending").checked)
			{
				$scope.conversionIncludesSourceManual.push('R');
				$scope.conversionIncludesSourceManual.push('Q');
			}
			if(document.getElementById("msconverted").checked)
			{
				$scope.conversionIncludesSourceManual.push('C');
			}
			var ph1 = document.getElementById("manuallymatchedproducthierarchyfirst").value;
			var ph2 = document.getElementById("manuallymatchedproducthierarchysecond").value;
			var ph3 = document.getElementById("manuallymatchedproducthierarchythird").value;

			if(ph1)
				$scope.searchSourceManual.productHierarchyFirst = Number(ph1);
			if(ph2)
				$scope.searchSourceManual.productHierarchySecond = Number(ph2);
			if(ph3)
				$scope.searchSourceManual.productHierarchyThird = Number(ph3);
		};

		/**
		 * Set Filter for Manual Source
		 */
		$scope.departmentFilterManuallySource = function (multiUnitTypeManuallyMatchedSourceData){
			if ($scope.departmentIncludesSourceManual.length > 0) {
				if ($.inArray(multiUnitTypeManuallyMatchedSourceData.deptName, $scope.departmentIncludesSourceManual) < 0)
					return;
			} 
			if ($scope.whsedsdIncludesSourceManual.length > 0) {
				if ($.inArray(multiUnitTypeManuallyMatchedSourceData.prodSourceCd, $scope.whsedsdIncludesSourceManual) < 0)
					return;
			} 
			if ($scope.conversionIncludesSourceManual.length > 0) {
				if ($.inArray(multiUnitTypeManuallyMatchedSourceData.convStatusCode, $scope.conversionIncludesSourceManual) < 0)
					return;
			} 
			return multiUnitTypeManuallyMatchedSourceData;
		};
		/**
		 * Clear Filter for Manual Source
		 */
		$scope.clearMMMSourceFilter = function(){
			if($scope.multiUnitTypeManuallyMatchedSouceDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeManuallyMatchedSouceDepartmentNames.length;i++)
				{
					document.getElementById("manuallymatchedsourcedepartmentname_"+i).checked = false;
				}
			}
			document.getElementById("msdsdcheckbox").checked = false;
			document.getElementById("mswhsecheckbox").checked = false;
			document.getElementById("mspending").checked = false;
			document.getElementById("msconverted").checked = false;
			document.getElementById("manuallymatchedproducthierarchyfirst").value = null;
			document.getElementById("manuallymatchedproducthierarchysecond").value = null;
			document.getElementById("manuallymatchedproducthierarchythird").value = null;
			$scope.departmentIncludesSourceManual = [];
			$scope.whsedsdIncludesSourceManual = [];
			$scope.conversionIncludesSourceManual = [];
			$scope.applyMMMSourceFilter();
			$scope.totalDisplayedSource = 200;
			$scope.isMMMSourceApplied = "mufilterUnapplied";
		};


		/**
		 * Apply Filter for Manual Target
		 */
		$scope.applyMMMTargetFilter = function(){
			$scope.isMMMTargetApplied = "mufilterApplied";
			$scope.departmentIncludesTargetManual = [];
			$scope.whsedsdIncludesTargetManual = [];
			$scope.searchTargetManual = {};

			$scope.totalDisplayedTarget = $scope.targetLength;
			if($scope.multiUnitTypeManuallyMatchedTargetDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeManuallyMatchedTargetDepartmentNames.length;i++)
				{
					if(document.getElementById("manuallymatchedtargetdepartmentname_"+i).checked)
					{
						$scope.departmentIncludesTargetManual.push($scope.multiUnitTypeManuallyMatchedTargetDepartmentNames[i]);
					}
				}
			}
			if(document.getElementById("mtdsdcheckbox").checked)
			{
				$scope.whsedsdIncludesTargetManual.push('DSD');
			}
			if(document.getElementById("mtwhsecheckbox").checked)
			{
				$scope.whsedsdIncludesTargetManual.push('WHSE');
			}
			var ts1 = document.getElementById("mmtsmicfirst").value;
			var ts2 = document.getElementById("mmtsmicsecond").value;
			var ts3 = document.getElementById("mmtsmicthird").value;
			var ts4 = document.getElementById("mmtsmicfourth").value;
			var ts5 = document.getElementById("mmtsmicfifth").value;

			if(ts1)
				$scope.searchTargetManual.smicFirst = Number(ts1);
			if(ts2)
				$scope.searchTargetManual.smicSecond = Number(ts2);
			if(ts3)
				$scope.searchTargetManual.smicThird = Number(ts3);
			if(ts4)
				$scope.searchTargetManual.smicFourth = Number(ts4);
			if(ts5)
				$scope.searchTargetManual.smicFifth = Number(ts5);
		};

		/**
		 * Set Filter for Manual Target
		 */
		$scope.departmentFilterManually = function(multiUnitTypeManuallyMatchedTargetData) {
			if ($scope.departmentIncludesTargetManual.length > 0) {
				if ($.inArray(multiUnitTypeManuallyMatchedTargetData.targetDepartment, $scope.departmentIncludesTargetManual) < 0)
					return;
			}        
			if ($scope.whsedsdIncludesTargetManual.length > 0) {
				if ($.inArray(multiUnitTypeManuallyMatchedTargetData.itemTypeWhseDsd, $scope.whsedsdIncludesTargetManual) < 0)
					return;
			} 
			return multiUnitTypeManuallyMatchedTargetData;
		};

		/**
		 * Clear Filter for Manual Target
		 */
		$scope.clearMMMTargetFilter = function(){
			if($scope.multiUnitTypeManuallyMatchedTargetDepartmentNames){
				for(var i=0;i<$scope.multiUnitTypeManuallyMatchedTargetDepartmentNames.length;i++)
				{
					document.getElementById("manuallymatchedtargetdepartmentname_"+i).checked = false;
				}
			}
			document.getElementById("mtdsdcheckbox").checked = false;
			document.getElementById("mtwhsecheckbox").checked = false;
			document.getElementById("mmtsmicfirst").value = null;
			document.getElementById("mmtsmicsecond").value = null;
			document.getElementById("mmtsmicthird").value = null;
			document.getElementById("mmtsmicfourth").value = null;
			document.getElementById("mmtsmicfifth").value = null;
			$scope.departmentIncludesTargetManual = [];
			$scope.whsedsdIncludesTargetManual = [];
			$scope.applyMMMTargetFilter();
			$scope.totalDisplayedTarget = 200;
			$scope.isMMMTargetApplied = "mufilterUnapplied";
		};

//		-------------------------------------------------
		/**
		 * Apply Filter for Auto Source
		 */
		$scope.applyAAMSourceFilter = function(){
			$scope.isAAMSourceApplied = "mufilterApplied";
			$scope.departmentIncludesSourceAuto = [];
			$scope.whsedsdIncludesSourceAuto = [];
			$scope.conversionIncludesSourceAuto = [];
			$scope.searchSourceAuto = {};

			$scope.totalDisplayedSource = $scope.sourceLength;
			for(var i=0;i<$scope.multiUnitTypeAutoMatchedSouceDepartmentNames.length;i++)
			{
				if(document.getElementById("automatchedsourcedepartmentname_"+i).checked)
				{
					$scope.departmentIncludesSourceAuto.push($scope.multiUnitTypeAutoMatchedSouceDepartmentNames[i]);
				}
			}
			if(document.getElementById("asdsdcheckbox").checked)
			{
				$scope.whsedsdIncludesSourceAuto.push('DSD');
			}
			if(document.getElementById("aswhsecheckbox").checked)
			{
				$scope.whsedsdIncludesSourceAuto.push('WHSE');
			}
			if(document.getElementById("aspending").checked)
			{
				$scope.conversionIncludesSourceAuto.push('R');
				$scope.conversionIncludesSourceAuto.push('Q');
			}
			if(document.getElementById("asconverted").checked)
			{
				$scope.conversionIncludesSourceAuto.push('C');
			}
			var ph1 = document.getElementById("asproducthierarchyfirst").value;
			var ph2 = document.getElementById("asproducthierarchysecond").value;
			var ph3 = document.getElementById("asproducthierarchythird").value;

			if(ph1)
				$scope.searchSourceAuto.productHierarchyFirst = Number(ph1);
			if(ph2)
				$scope.searchSourceAuto.productHierarchySecond = Number(ph2);
			if(ph3)
				$scope.searchSourceAuto.productHierarchyThird = Number(ph3);
		};

		/**
		 * Set Filter for Auto Source
		 */
		$scope.departmentFilterAutoSource = function (multiUnitTypeAutoMatchedSourceData){
			if ($scope.departmentIncludesSourceAuto.length > 0) {
				if ($.inArray(multiUnitTypeAutoMatchedSourceData.deptName, $scope.departmentIncludesSourceAuto) < 0)
					return;
			}  
			if ($scope.whsedsdIncludesSourceAuto.length > 0) {
				if ($.inArray(multiUnitTypeAutoMatchedSourceData.prodSourceCd, $scope.whsedsdIncludesSourceAuto) < 0)
					return;
			} 
			if ($scope.conversionIncludesSourceAuto.length > 0) {
				if ($.inArray(multiUnitTypeAutoMatchedSourceData.convStatusCode, $scope.conversionIncludesSourceAuto) < 0)
					return;
			} 
			return multiUnitTypeAutoMatchedSourceData;
		};
		/**
		 * Clear Filter for Auto Source
		 */
		$scope.clearAAMSourceFilter = function(){
			for(var i=0;i<$scope.multiUnitTypeAutoMatchedSouceDepartmentNames.length;i++)
			{
				document.getElementById("automatchedsourcedepartmentname_"+i).checked = false;
			}

			document.getElementById("asdsdcheckbox").checked = false;
			document.getElementById("aswhsecheckbox").checked = false;
			document.getElementById("aspending").checked = false;
			document.getElementById("asconverted").checked = false;
			document.getElementById("asproducthierarchyfirst").value = null;
			document.getElementById("asproducthierarchysecond").value = null;
			document.getElementById("asproducthierarchythird").value = null;
			$scope.departmentIncludesSourceAuto = [];
			$scope.whsedsdIncludesSourceAuto = [];
			$scope.conversionIncludesSourceAuto = [];
			$scope.applyAAMSourceFilter();
			$scope.totalDisplayedSource = 200;
			$scope.isAAMSourceApplied = "mufilterUnapplied";
		};
		/**
		 * Apply Filter for Auto Target
		 */
		$scope.applyAAMTargetFilter = function(){
			$scope.isAAMTargetApplied = "mufilterApplied";
			$scope.departmentIncludesTargetAuto = [];
			$scope.whsedsdIncludesTargetAuto = [];
			$scope.searchTargetAuto = {};

			$scope.totalDisplayedTarget = $scope.targetLength;
			for(var i=0;i<$scope.multiUnitTypeAutoMatchedTargetDepartmentNames.length;i++)
			{
				if(document.getElementById("automatchedtargetdepartmentname_"+i).checked)
				{
					$scope.departmentIncludesTargetAuto.push($scope.multiUnitTypeAutoMatchedTargetDepartmentNames[i]);
				}
			}
			if(document.getElementById("atdsdcheckbox").checked)
			{
				$scope.whsedsdIncludesTargetAuto.push('DSD');
			}
			if(document.getElementById("atwhsecheckbox").checked)
			{
				$scope.whsedsdIncludesTargetAuto.push('WHSE');
			}
			var ts1 = document.getElementById("atsmicfirst").value;
			var ts2 = document.getElementById("atsmicsecond").value;
			var ts3 = document.getElementById("atsmicthird").value;
			var ts4 = document.getElementById("atsmicfourth").value;
			var ts5 = document.getElementById("atsmicfifth").value;

			if(ts1)
				$scope.searchTargetAuto.smicFirst = Number(ts1);
			if(ts2)
				$scope.searchTargetAuto.smicSecond = Number(ts2);
			if(ts3)
				$scope.searchTargetAuto.smicThird = Number(ts3);
			if(ts4)
				$scope.searchTargetAuto.smicFourth = Number(ts4);
			if(ts5)
				$scope.searchTargetAuto.smicFifth = Number(ts5);
		};

		/**
		 * Set Filter for Auto Target
		 */
		$scope.departmentFilterAuto = function (multiUnitTypeAutoMatchedTargetData){
			if ($scope.departmentIncludesTargetAuto.length > 0) {
				if ($.inArray(multiUnitTypeAutoMatchedTargetData.targetDepartment, $scope.departmentIncludesTargetAuto) < 0)
					return;
			}   
			if ($scope.whsedsdIncludesTargetAuto.length > 0) {
				if ($.inArray(multiUnitTypeAutoMatchedTargetData.itemTypeWhseDsd, $scope.whsedsdIncludesTargetAuto) < 0)
					return;
			}
			return multiUnitTypeAutoMatchedTargetData;
		};

		/**
		 * Clear Filter for Auto Target
		 */
		$scope.clearAAMTargetFilter = function(){

			for(var i=0;i<$scope.multiUnitTypeAutoMatchedTargetDepartmentNames.length;i++)
			{
				document.getElementById("automatchedtargetdepartmentname_"+i).checked = false;
			}
			document.getElementById("atdsdcheckbox").checked = false;
			document.getElementById("atwhsecheckbox").checked = false;
			document.getElementById("atsmicfirst").value = null;
			document.getElementById("atsmicsecond").value = null;
			document.getElementById("atsmicthird").value = null;
			document.getElementById("atsmicfourth").value = null;
			document.getElementById("atsmicfifth").value = null;
			$scope.departmentIncludesTargetAuto = [];
			$scope.whsedsdIncludesTargetAuto = [];
			$scope.applyAAMTargetFilter();
			$scope.totalDisplayedTarget = 200;
			$scope.isAAMTargetApplied = "mufilterUnapplied";
		};

//		-------------------------------------------------- END OF FILTER BY


		/**
		 * Load data based upon the mapping status - TBM
		 */
		$scope.loadMultiUnitTypeSourceTargetData = function (companyID, divisionID){
			blockUI.start();
			var loadMultiUnitTypeSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnit/"+companyID+"/"+divisionID+"/"+"P";
			var multiUnitSourceSplitString = " ";
			var multiUnitTargetSplitString = " ";
			$http.get(loadMultiUnitTypeSourceTargetDataUrl, config)
			.then(function(response){
				if(response.data.multiUnitSource != null){
					blockUI.stop();
					for(var i=0; i<response.data.multiUnitSource.length; i++){
						multiUnitSourceSplitString = response.data.multiUnitSource[i].productHierarchy.split("-");
						response.data.multiUnitSource[i].productHierarchyFirst = multiUnitSourceSplitString[0];
						response.data.multiUnitSource[i].productHierarchySecond = multiUnitSourceSplitString[1];
						response.data.multiUnitSource[i].productHierarchyThird = multiUnitSourceSplitString[2];
					}
					$scope.multiUnitTypeSourceData = response.data.multiUnitSource;
					$scope.sourceLength = response.data.multiUnitSource.length;
					$scope.loadMoreSource();
					$scope.multiUnitTypeSouceDepartmentNames = response.data.multiUnitSource[0].deptNames;
				}
				else{
					blockUI.stop();
					$scope.multiUnitTypeSourceData = null;
					$scope.sourceLength = 0;
					$scope.loadMoreSource();
				}

				if(response.data.multiUnitTarget != null){
					blockUI.stop();
					for(var i=0; i<response.data.multiUnitTarget.length; i++){
						multiUnitTargetSplitString = response.data.multiUnitTarget[i].smicCode.split("-");
						response.data.multiUnitTarget[i].smicFirst = multiUnitTargetSplitString[0];
						response.data.multiUnitTarget[i].smicSecond = multiUnitTargetSplitString[1];
						response.data.multiUnitTarget[i].smicThird = multiUnitTargetSplitString[2];
						response.data.multiUnitTarget[i].smicFourth = multiUnitTargetSplitString[3];
						response.data.multiUnitTarget[i].smicFifth = multiUnitTargetSplitString[4];
					}
					$scope.multiUnitTypeTargetData = response.data.multiUnitTarget;
					$scope.targetLength = response.data.multiUnitTarget.length;
					$scope.loadMoreTarget();
					$scope.multiUnitTypeTargetDepartmentNames = response.data.multiUnitTarget[0].deptNameList;
				}
				else{
					blockUI.stop();
					$scope.multiUnitTypeTargetData = null;
					$scope.targetLength = 0;
					$scope.loadMoreTarget();
				}
			}, function(response){

			});
		};

		/**
		 * Load data based upon the mapping status - MANUALLY
		 */
		$scope.loadMultiUnitTypeManuallyMatchedSourceTargetData = function (companyID, divisionID){
			var loadMultiUnitTypeManuallyMatchedSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnit/"+companyID+"/"+divisionID+"/"+"M";
			var multiUnitManuallyMatchedSourceSplitString = " ";
			var multiUnitManuallyMatchedTargetSplitString = " ";
			$http.get(loadMultiUnitTypeManuallyMatchedSourceTargetDataUrl, config)
			.then(function(response){
				if(response.data.multiUnitSource != null){
					for(var i=0; i<response.data.multiUnitSource.length; i++){
						multiUnitManuallyMatchedSourceSplitString = response.data.multiUnitSource[i].productHierarchy.split("-");
						response.data.multiUnitSource[i].productHierarchyFirst = multiUnitManuallyMatchedSourceSplitString[0];
						response.data.multiUnitSource[i].productHierarchySecond = multiUnitManuallyMatchedSourceSplitString[1];
						response.data.multiUnitSource[i].productHierarchyThird = multiUnitManuallyMatchedSourceSplitString[2];
					}
					$scope.multiUnitTypeManuallyMatchedSourceData = response.data.multiUnitSource;
					$scope.sourceLength = response.data.multiUnitSource.length;
					$scope.loadMoreSource();
					$scope.multiUnitTypeManuallyMatchedSouceDepartmentNames = response.data.multiUnitSource[0].deptNames;
				}
				else{
					$scope.multiUnitTypeManuallyMatchedSourceData = null;
					$scope.sourceLength = 0;
					$scope.loadMoreSource();
				}

				if(response.data.multiUnitTarget != null){
					for(var i=0; i<response.data.multiUnitTarget.length; i++){
						multiUnitManuallyMatchedTargetSplitString = response.data.multiUnitTarget[i].smicCode.split("-");
						response.data.multiUnitTarget[i].smicFirst = multiUnitManuallyMatchedTargetSplitString[0];
						response.data.multiUnitTarget[i].smicSecond = multiUnitManuallyMatchedTargetSplitString[1];
						response.data.multiUnitTarget[i].smicThird = multiUnitManuallyMatchedTargetSplitString[2];
						response.data.multiUnitTarget[i].smicFourth = multiUnitManuallyMatchedTargetSplitString[3];
						response.data.multiUnitTarget[i].smicFifth = multiUnitManuallyMatchedTargetSplitString[4];
					}
					$scope.multiUnitTypeManuallyMatchedTargetData = response.data.multiUnitTarget;
					$scope.targetLength = response.data.multiUnitTarget.length;
					$scope.loadMoreTarget();
					$scope.multiUnitTypeManuallyMatchedTargetDepartmentNames = response.data.multiUnitTarget[0].deptNameList;
				}
				else{
					$scope.multiUnitTypeManuallyMatchedTargetData = null;
					$scope.targetLength = 0;
					$scope.loadMoreTarget();
				}
			}, function(response){

			});
		};

		/**
		 * Load data based upon the mapping status - AUTO_MATCHED
		 */
		$scope.loadMultiUnitTypeAutoMatchedSourceTargetData = function (companyID, divisionID){
			var loadMultiUnitTypeAutoMatchedSourceTargetDataUrl = $scope.baseUrl+"multiUnitType/loadMultiUnit/"+companyID+"/"+divisionID+"/"+"A";
			var multiUnitAutoMatchedSourceSplitString = " ";
			var multiUnitAutoMatchedTargetSplitString = " ";
			$http.get(loadMultiUnitTypeAutoMatchedSourceTargetDataUrl, config)
			.then(function(response){
				if(response.data.multiUnitSource != null){
					for(var i=0; i<response.data.multiUnitSource.length; i++){
						multiUnitAutoMatchedSourceSplitString = response.data.multiUnitSource[i].productHierarchy.split("-");
						response.data.multiUnitSource[i].productHierarchyFirst = multiUnitAutoMatchedSourceSplitString[0];
						response.data.multiUnitSource[i].productHierarchySecond = multiUnitAutoMatchedSourceSplitString[1];
						response.data.multiUnitSource[i].productHierarchyThird = multiUnitAutoMatchedSourceSplitString[2];
					}
					$scope.multiUnitTypeAutoMatchedSourceData = response.data.multiUnitSource;
					$scope.sourceLength = response.data.multiUnitSource.length;
					$scope.loadMoreSource();
					$scope.multiUnitTypeAutoMatchedSouceDepartmentNames = response.data.multiUnitSource[0].deptNames;
				}
				else{
					$scope.multiUnitTypeAutoMatchedSourceData = null;
					$scope.sourceLength = 0;
					$scope.loadMoreSource();
				}

				if(response.data.multiUnitTarget != null){
					for(var i=0; i<response.data.multiUnitTarget.length; i++){
						multiUnitAutoMatchedTargetSplitString = response.data.multiUnitTarget[i].smicCode.split("-");
						response.data.multiUnitTarget[i].smicFirst = multiUnitAutoMatchedTargetSplitString[0];
						response.data.multiUnitTarget[i].smicSecond = multiUnitAutoMatchedTargetSplitString[1];
						response.data.multiUnitTarget[i].smicThird = multiUnitAutoMatchedTargetSplitString[2];
						response.data.multiUnitTarget[i].smicFourth = multiUnitAutoMatchedTargetSplitString[3];
						response.data.multiUnitTarget[i].smicFifth = multiUnitAutoMatchedTargetSplitString[4];
					}
					$scope.multiUnitTypeAutoMatchedTargetData = response.data.multiUnitTarget;
					$scope.targetLength = response.data.multiUnitTarget.length;
					$scope.loadMoreTarget();
					$scope.multiUnitTypeAutoMatchedTargetDepartmentNames = response.data.multiUnitTarget[0].deptNameList;
				}
				else{
					$scope.multiUnitTypeAutoMatchedTargetData = null;
					$scope.targetLength = 0;
					$scope.loadMoreTarget();
				}
			}, function(response){

			});
		};

		$scope.filters = {
				DSD : false,
				WHSE : false,
				pending : false,
				converted : false,
				convStatusCode : '',
				prodSourceCd : '',
				itemTypeWhseDsd : ''
		};

		/**
		 * Sorting arrow action in source of all three sections for department, prod hierarchy and retail vendor name
		 */
		$scope.setOrderPropertySource = function(propertyName, event) {
			var id = event.target.id;
			var value = event.target.attributes[4].value;
			if(value == ">"){
				event.target.attributes[4].value = "^";
				document.getElementById(id).src="img/down.png";
			}
			else {
				event.target.attributes[4].value = ">";
				document.getElementById(id).src="img/up.png";
			}

			if ($scope.orderPropertySource === propertyName) {
				$scope.orderPropertySource = '-' + propertyName;
			} 
			else if ($scope.orderPropertySource === '-' + propertyName) {
				$scope.orderPropertySource = propertyName;
			} 
			else {
				$scope.orderPropertySource = propertyName;
			}
		};

		/**
		 * Sorting arrow action in target of all three sections for department, prod hierarchy and retail vendor name
		 */
		$scope.setOrderProperty = function(propertyName, event) {
			var id = event.target.id;
			var value = event.target.attributes[4].value;
			if(value == ">"){
				event.target.attributes[4].value = "^";
				document.getElementById(id).src="img/down.png";
			}
			else {
				event.target.attributes[4].value = ">";
				document.getElementById(id).src="img/up.png";
			}

			if ($scope.orderProperty === propertyName) {
				$scope.orderProperty = '-' + propertyName;
			} 
			else if ($scope.orderProperty === '-' + propertyName) {
				$scope.orderProperty = propertyName;
			} 
			else {
				$scope.orderProperty = propertyName;
			}
		};

		$scope.selectedSourceUpc = function (){
			var count = 0;
			var upcs = null;
			var multiUnitTargetSplitString = " ";
			var formData = [];
			angular.forEach($scope.multiUnitTypeSourceData, function(multiUnitTypeSource){
				if (multiUnitTypeSource.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else{
				for (var i = 0; i < $scope.multiUnitTypeSourceData.length; i++) {
					if ($scope.multiUnitTypeSourceData[i].Selected) {
						upcs = $scope.multiUnitTypeSourceData[i].upcs;
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"upcs" : upcs,
							"matchIndicator" : "P"
						}); 
					}
				}

				

				var selectedSourceUpcUrl = $scope.baseUrl+"multiUnitType/listTargetOnSrcSel";

				$http.post(selectedSourceUpcUrl, formData, config)
				.then(function(response){
					//function handles success condition
					if(response.data.length != 0){
						for(var i=0; i<response.data.length; i++){
							multiUnitTargetSplitString = response.data[i].smicCode.split("-");
							response.data[i].smicFirst = multiUnitTargetSplitString[0];
							response.data[i].smicSecond = multiUnitTargetSplitString[1];
							response.data[i].smicThird = multiUnitTargetSplitString[2];
							response.data[i].smicFourth = multiUnitTargetSplitString[3];
							response.data[i].smicFifth = multiUnitTargetSplitString[4];
						}
						$scope.multiUnitTypeTargetData = response.data;
						$scope.targetLength = response.data.length;
						$scope.loadMoreTarget();
					}
					else{
						$scope.multiUnitTypeTargetData = null;
						$scope.targetLength = 0;
						$scope.loadMoreTarget();
						alertify.alert("No CIC details from Target Items.");
						return;
					}

				}, function(response){
					//function handles error condtion
				});
			}
		};

		$scope.selectedSourceUpcMauallyMap = function (){
			var count = 0;
			var upcs = null;
			var multiUnitTargetSplitString = " ";
			var formData = [];
			angular.forEach($scope.multiUnitTypeManuallyMatchedSourceData, function(multiUnitTypeManuallyMatchedSource){
				if (multiUnitTypeManuallyMatchedSource.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else{
				for (var i = 0; i < $scope.multiUnitTypeManuallyMatchedSourceData.length; i++) {
					if ($scope.multiUnitTypeManuallyMatchedSourceData[i].Selected) {
						upcs = $scope.multiUnitTypeManuallyMatchedSourceData[i].upcs;
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"upcs" : upcs,
							"matchIndicator" : "M"
						}); 
					}
				}

				

				var selectedSourceUpcUrl = $scope.baseUrl+"multiUnitType/listTargetOnSrcSel";

				$http.post(selectedSourceUpcUrl, formData, config)
				.then(function(response){
					//function handles success condition
					if(response.data.length != 0){
						for(var i=0; i<response.data.length; i++){
							multiUnitTargetSplitString = response.data[i].smicCode.split("-");
							response.data[i].smicFirst = multiUnitTargetSplitString[0];
							response.data[i].smicSecond = multiUnitTargetSplitString[1];
							response.data[i].smicThird = multiUnitTargetSplitString[2];
							response.data[i].smicFourth = multiUnitTargetSplitString[3];
							response.data[i].smicFifth = multiUnitTargetSplitString[4];
						}
						$scope.multiUnitTypeManuallyMatchedTargetData = response.data;
						$scope.targetLength = response.data.length;
						$scope.loadMoreTarget();
					}
					else{
						$scope.multiUnitTypeManuallyMatchedTargetData = null;
						$scope.targetLength = 0;
						$scope.loadMoreTarget();
						alertify.alert("No CIC details from Target Items.");
						return;
					}

				}, function(response){
					//function handles error condtion
				});
			}
		};

		$scope.selectedSourceUpcAuto = function (){
			var count = 0;
			var upcs = null;
			var multiUnitTargetSplitString = " ";
			var formData = [];
			angular.forEach($scope.multiUnitTypeAutoMatchedSourceData, function(multiUnitTypeAutoMatchedSource){
				if (multiUnitTypeAutoMatchedSource.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else{
				for (var i = 0; i < $scope.multiUnitTypeAutoMatchedSourceData.length; i++) {
					if ($scope.multiUnitTypeAutoMatchedSourceData[i].Selected) {
						upcs = $scope.multiUnitTypeAutoMatchedSourceData[i].upcs;
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"upcs" : upcs,
							"matchIndicator" : "A"
						}); 
					}
				}

				

				var selectedSourceUpcUrl = $scope.baseUrl+"multiUnitType/listTargetOnSrcSel";

				$http.post(selectedSourceUpcUrl, formData, config)
				.then(function(response){
					//function handles success condition
					if(response.data.length != 0){
						for(var i=0; i<response.data.length; i++){
							multiUnitTargetSplitString = response.data[i].smicCode.split("-");
							response.data[i].smicFirst = multiUnitTargetSplitString[0];
							response.data[i].smicSecond = multiUnitTargetSplitString[1];
							response.data[i].smicThird = multiUnitTargetSplitString[2];
							response.data[i].smicFourth = multiUnitTargetSplitString[3];
							response.data[i].smicFifth = multiUnitTargetSplitString[4];
						}
						$scope.multiUnitTypeAutoMatchedTargetData = response.data;
						$scope.targetLength = response.data.length;
						$scope.loadMoreTarget();
					}
					else{
						$scope.multiUnitTypeAutoMatchedTargetData = null;
						$scope.targetLength = 0;
						$scope.loadMoreTarget();
						alertify.alert("No CIC details from Target Items.");
						return;
					}

				}, function(response){
					//function handles error condtion
				});
			}
		};

		$scope.selectedTargetUpcsearch = function (){
			var count = 0;
			var upcs = null;
			var multiUnitSourceSplitString = " ";
			var formData = [];
			angular.forEach($scope.multiUnitTypeTargetData, function(multiUnitTypeTarget){
				if (multiUnitTypeTarget.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any CIC from Target Items.");
				return;
			}
			else{
				for (var i = 0; i < $scope.multiUnitTypeTargetData.length; i++) {
					if ($scope.multiUnitTypeTargetData[i].Selected) {
						upcs = $scope.multiUnitTypeTargetData[i].upcList;
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"upcList" : upcs,
							"matchIndicator" : "P"
						}); 
					}
				}

				

				var selectedSourceUpcUrl = $scope.baseUrl+"multiUnitType/listSrcOnTarSel";

				$http.post(selectedSourceUpcUrl, formData, config)
				.then(function(response){
					//function handles success condition
					if(response.data.length != 0){
						for(var i=0; i<response.data.length; i++){
							multiUnitSourceSplitString = response.data[i].productHierarchy.split("-");
							response.data[i].productHierarchyFirst = multiUnitSourceSplitString[0];
							response.data[i].productHierarchySecond = multiUnitSourceSplitString[1];
							response.data[i].productHierarchyThird = multiUnitSourceSplitString[2];
						}
						$scope.multiUnitTypeSourceData = response.data;
						$scope.sourceLength = response.data.length;
						$scope.loadMoreSource();
					}
					else{
						$scope.multiUnitTypeSourceData = null;
						$scope.sourceLength = 0;
						$scope.loadMoreSource();
						alertify.alert("No Product SKU details from Source Items.");
						return;
					}
				}, function(response){
					//function handles error condtion
				});
			}
		};

		$scope.selectedTargetUpcsearchManuallyMap = function (){
			var count = 0;
			var upcs = null;
			var multiUnitSourceSplitString = " ";
			var formData = [];
			angular.forEach($scope.multiUnitTypeManuallyMatchedTargetData, function(multiUnitTypeManuallyMatchedTarget){
				if (multiUnitTypeManuallyMatchedTarget.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any CIC from Target Items.");
				return;
			}
			else{
				for (var i = 0; i < $scope.multiUnitTypeManuallyMatchedTargetData.length; i++) {
					if ($scope.multiUnitTypeManuallyMatchedTargetData[i].Selected) {
						upcs = $scope.multiUnitTypeManuallyMatchedTargetData[i].upcList;
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"upcList" : upcs,
							"matchIndicator" : "M"
						}); 
					}
				}

				

				var selectedSourceUpcUrl = $scope.baseUrl+"multiUnitType/listSrcOnTarSel";

				$http.post(selectedSourceUpcUrl, formData, config)
				.then(function(response){
					//function handles success condition
					if(response.data.length != 0){
						for(var i=0; i<response.data.length; i++){
							multiUnitSourceSplitString = response.data[i].productHierarchy.split("-");
							response.data[i].productHierarchyFirst = multiUnitSourceSplitString[0];
							response.data[i].productHierarchySecond = multiUnitSourceSplitString[1];
							response.data[i].productHierarchyThird = multiUnitSourceSplitString[2];
						}
						$scope.multiUnitTypeManuallyMatchedSourceData = response.data;
						$scope.sourceLength = response.data.length;
						$scope.loadMoreSource();
					}
					else{
						$scope.multiUnitTypeManuallyMatchedSourceData = null;
						$scope.sourceLength = 0;
						$scope.loadMoreSource();
						alertify.alert("No Product SKU details from Source Items.");
						return;
					}
				}, function(response){
					//function handles error condtion
				});
			}
		};

		$scope.selectedTargetUpcsearchAutoMap = function (){
			var count = 0;
			var upcs = null;
			var multiUnitSourceSplitString = " ";
			var formData = [];
			angular.forEach($scope.multiUnitTypeAutoMatchedTargetData, function(multiUnitTypeAutoMatchedTarget){
				if (multiUnitTypeAutoMatchedTarget.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any CIC from Target Items.");
				return;
			}
			else{
				for (var i = 0; i < $scope.multiUnitTypeAutoMatchedTargetData.length; i++) {
					if ($scope.multiUnitTypeAutoMatchedTargetData[i].Selected) {
						upcs = $scope.multiUnitTypeAutoMatchedTargetData[i].upcList;
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"upcList" : upcs,
							"matchIndicator" : "A"
						}); 
					}
				}

				

				var selectedSourceUpcUrl = $scope.baseUrl+"multiUnitType/listSrcOnTarSel";

				$http.post(selectedSourceUpcUrl, formData, config)
				.then(function(response){
					//function handles success condition
					if(response.data.length != 0){
						for(var i=0; i<response.data.length; i++){
							multiUnitSourceSplitString = response.data[i].productHierarchy.split("-");
							response.data[i].productHierarchyFirst = multiUnitSourceSplitString[0];
							response.data[i].productHierarchySecond = multiUnitSourceSplitString[1];
							response.data[i].productHierarchyThird = multiUnitSourceSplitString[2];
						}
						$scope.multiUnitTypeAutoMatchedSourceData = response.data;
						$scope.sourceLength = response.data.length;
						$scope.loadMoreSource();
					}
					else{
						$scope.multiUnitTypeAutoMatchedSourceData = null;
						$scope.sourceLength = 0;
						$scope.loadMoreSource();
						alertify.alert("No Product SKU details from Source Items.");
						return;
					}
				}, function(response){
					//function handles error condtion
				});
			}
		};

		$scope.mapItems = function (){
			var sourceCount = 0;
			var targetCount = 0;
			var updatedUserID = null;
			var multiUnitSource = [];
			var multiUnitSourceProductSourceCode = [];
			var multiUnitSourceUpcs = [];
			var multiUnitSourceProductSourceCodeNoDuplicates = [];
			var multiUnitTargetProductSourceCode = [];
			var multiUnitTargetUpcs = [];
			var multiUnitTarget = [];
			var formData = [];
			var returnValue = false;
			var productSourceCodeWhse = true;
			var isSourceWhse = true;
			var targetProductSourceCodeWhse = true;

			angular.forEach($scope.multiUnitTypeSourceData, function(multiUnitTypeSource){
				if (multiUnitTypeSource.Selected) {
					sourceCount = sourceCount+1;
				}
			});
			if(sourceCount == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else {
				for (var i = 0; i < $scope.multiUnitTypeSourceData.length; i++) {
					if ($scope.multiUnitTypeSourceData[i].Selected) {
						updatedUserID = service.userId;	
						multiUnitSource.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"productSku" : $scope.multiUnitTypeSourceData[i].productSku,
							"convProductSku" : $scope.multiUnitTypeSourceData[i].convProductSku,
							"srcItemDesc" : $scope.multiUnitTypeSourceData[i].srcItemDesc,
							"srcPackWhse" : $scope.multiUnitTypeSourceData[i].srcPackWhse,
							"srcVendConvFctr" : $scope.multiUnitTypeSourceData[i].srcVendConvFctr,
							"srcSize" : $scope.multiUnitTypeSourceData[i].srcSize,
							"srcUpc" : $scope.multiUnitTypeSourceData[i].upcs[0],
							"prodSourceCd" : $scope.multiUnitTypeSourceData[i].prodSourceCd,
							"productHierarchy" : $scope.multiUnitTypeSourceData[i].productHierarchy,
							"deptName" : $scope.multiUnitTypeSourceData[i].deptName,
							"productSkuSet" : $scope.multiUnitTypeSourceData[i].productSkuSet,
							"caseUpc" : $scope.multiUnitTypeSourceData[i].caseUpc,
							"srcCost" : $scope.multiUnitTypeSourceData[i].srcCost,
							"srcVendNum" : $scope.multiUnitTypeSourceData[i].srcVendNum,
							"srcVendName" : $scope.multiUnitTypeSourceData[i].srcVendName,
							"upcs" : $scope.multiUnitTypeSourceData[i].upcs,
							"updatedUserId" : updatedUserID
						});

						multiUnitSourceProductSourceCode.push({
							"prodSourceCd" : $scope.multiUnitTypeSourceData[i].prodSourceCd
						});

						multiUnitSourceUpcs.push({
							"upcs": $scope.multiUnitTypeSourceData[i].upcs
						});

					}
				}

				angular.forEach(multiUnitSourceProductSourceCode, function(value, key) {
					var exists = false;
					angular.forEach(multiUnitSourceProductSourceCodeNoDuplicates, function(value2, key) {
						if(angular.equals(value.prodSourceCd, value2.prodSourceCd)){ 
							exists = true; 
						}; 
					});
					if(exists == false && value.prodSourceCd != "") { 
						multiUnitSourceProductSourceCodeNoDuplicates.push(value); 
					}
				});

				angular.forEach($scope.multiUnitTypeTargetData, function(multiUnitTypeTarget){
					if (multiUnitTypeTarget.Selected){
						targetCount = targetCount+1;
					}
				});

				if(targetCount == 0){
					alertify.alert("Select any CIC from Target Items.");
					return;
				}
				else if(targetCount > 1){
					alertify.alert("More than one selection of cic from target not allowed.");
					return;
				}

				else{
					for (var i = 0; i < $scope.multiUnitTypeTargetData.length; i++) {
						if ($scope.multiUnitTypeTargetData[i].Selected) {
							multiUnitTarget.push({
								"corpItemCd" : $scope.multiUnitTypeTargetData[i].corpItemCd
							});

							multiUnitTargetProductSourceCode.push({
								"prodSourceCd" : $scope.multiUnitTypeTargetData[i].itemTypeWhseDsd
							});

							multiUnitTargetUpcs.push({
								"upcs" : $scope.multiUnitTypeTargetData[i].upcList
							});

							formData.push({
								"multiUnitSource" : multiUnitSource,
								"multiUnitTarget" : multiUnitTarget,
								"srcMultiUnitFlag" : $scope.multiUnitTypeButtonValue
							});
							break;
						}
					}
				}

				for(var i=0;i<multiUnitSourceUpcs.length;i++){
					if(multiUnitTargetUpcs[0] && multiUnitSourceUpcs[i]){
						if(includes(multiUnitTargetUpcs[0].upcs, multiUnitSourceUpcs[i].upcs[0]) == false){
							break;
						}
					}
				}

				function includes(container, value) {
					var pos = container.indexOf(value);
					if (pos >= 0) {
						returnValue = true;
					}
					else{
						returnValue = false;
					}
					return returnValue;
				}

				if(multiUnitSourceProductSourceCodeNoDuplicates.length == 1){
					isSameProductSourceCodeWhse();
				}

				if(multiUnitSourceProductSourceCodeNoDuplicates.length == 2){
					isSourceWhseChecking();
					isTargetProductSourceCodeWhse();
				}

				function isSameProductSourceCodeWhse(){
					if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "WHSE" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE" 
							&& multiUnitSource.length > 1){
						productSourceCodeWhse = false;
						alertify.alert("Multiple WHSE to WHSE mapping not allowed.");
						return;
					}
					else if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "DSD" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"){
						productSourceCodeWhse = false;
						alertify.alert("DSD to WHSE mapping not allowed.");
						return;
					}
					else if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "WHSE" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "DSD"){
						productSourceCodeWhse = false;
						alertify.alert("WHSE to DSD mapping not allowed.");
						return;
					}
					else{
						productSourceCodeWhse = true;
					}
				}

				function isSourceWhseChecking(){
					for(var i=0;i<multiUnitSourceProductSourceCodeNoDuplicates.length;i++){
						if(multiUnitSourceProductSourceCodeNoDuplicates[i].prodSourceCd == "WHSE"){
							isSourceWhse = true;
							break;
						}
					}
				}

				function isTargetProductSourceCodeWhse(){
					if(isSourceWhse == true){
						if(multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"){
							targetProductSourceCodeWhse = true;
						}
						else{
							targetProductSourceCodeWhse = false;
							alertify.alert("Mapping to DSD not allowed.");
							return;
						}
					}
				}

				var formDataObject = JSON.parse(JSON.stringify(formData[0]));

				

				var multiUnitMapUrl = $scope.baseUrl+"multiUnitType/mapMultiUnitItem";
				if(productSourceCodeWhse == true && targetProductSourceCodeWhse == true){
					if(returnValue == true){
						$http.post(multiUnitMapUrl, formDataObject, config)
						.then(function(response){
							//function handles success condition
							$scope.totalDisplayedSource = 0;
							$scope.totalDisplayedTarget = 0;
							$scope.loadMultiUnitTypeSourceTargetData($scope.companyId, $scope.divisionId);
							$scope.matchedMultiUnitTypeYes();
						}, function(response){
							//function handles error condtion
						});
					}
					else{
						alertify.alert("Imperfect UPC matching.");
						return;
					}
				}
			}
		};

		/**
		 * UnMap Items Button action after selecting an SKU and CIC in 'Manually Matched'
		 */
		$scope.unMapManuallyMatchedItems = function (){
			var sourceCount = 0;
			var targetCount = 0;
			var updatedUserID = null;
			var multiUnitSource = [];
			var multiUnitSourceProductSourceCode = [];
			var multiUnitSourceUpc = [];
			var multiUnitTargetProductSourceCode = [];
			var multiUnitSourceProductSourceCodeNoDuplicates = [];
			var multiUnitTarget = [];
			var multiUnitTargetUpc = [];
			var formData = [];
			var returnValue = false;
			var productSourceCodeWhse = true;
			var isSourceWhse = true;
			var targetProductSourceCodeWhse = true;

			angular.forEach($scope.multiUnitTypeManuallyMatchedSourceData, function(multiUnitTypeManuallyMatchedSource){
				if (multiUnitTypeManuallyMatchedSource.Selected) {
					sourceCount = sourceCount+1;
				}
			});
			
			if(sourceCount == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else {
				for (var i = 0; i < $scope.multiUnitTypeManuallyMatchedSourceData.length; i++) {
					if ($scope.multiUnitTypeManuallyMatchedSourceData[i].Selected) {
						updatedUserID = service.userId;	
						multiUnitSource.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"productSku" : $scope.multiUnitTypeManuallyMatchedSourceData[i].productSku,
							"convProductSku" : $scope.multiUnitTypeManuallyMatchedSourceData[i].convProductSku,
							"srcItemDesc" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcItemDesc,
							"srcPackWhse" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcPackWhse,
							"srcVendConvFctr" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcVendConvFctr,
							"srcSize" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcSize,
							"srcUpc" : $scope.multiUnitTypeManuallyMatchedSourceData[i].upcs[0],
							"prodSourceCd" : $scope.multiUnitTypeManuallyMatchedSourceData[i].prodSourceCd,
							"productHierarchy" : $scope.multiUnitTypeManuallyMatchedSourceData[i].productHierarchy,
							"deptName" : $scope.multiUnitTypeManuallyMatchedSourceData[i].deptName,
							"productSkuSet" : $scope.multiUnitTypeManuallyMatchedSourceData[i].productSkuSet,
							"caseUpc" : $scope.multiUnitTypeManuallyMatchedSourceData[i].caseUpc,
							"srcCost" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcCost,
							"srcVendNum" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcVendNum,
							"srcVendName" : $scope.multiUnitTypeManuallyMatchedSourceData[i].srcVendName,
							"upcs" : $scope.multiUnitTypeManuallyMatchedSourceData[i].upcs,
							"updatedUserId" : updatedUserID
						});

						multiUnitSourceProductSourceCode.push({
							"prodSourceCd" : $scope.multiUnitTypeManuallyMatchedSourceData[i].prodSourceCd
						});

						multiUnitSourceUpc.push({
							"upcs" : $scope.multiUnitTypeManuallyMatchedSourceData[i].upcs
						});
					}
				}

				angular.forEach(multiUnitSourceProductSourceCode, function(value, key) {
					var exists = false;
					angular.forEach(multiUnitSourceProductSourceCodeNoDuplicates, function(value2, key) {
						if(angular.equals(value.prodSourceCd, value2.prodSourceCd)){ 
							exists = true; 
						}; 
					});
					if(exists == false && value.prodSourceCd != "") { 
						multiUnitSourceProductSourceCodeNoDuplicates.push(value); 
					}
				});

				angular.forEach($scope.multiUnitTypeManuallyMatchedTargetData, function(multiUnitTypeManuallyMatchedTarget){
					if (multiUnitTypeManuallyMatchedTarget.Selected){
						targetCount = targetCount+1;
					}
				});

				if(targetCount == 0){
					alertify.alert("Select any CIC from Target Items.");
					return;
				}
				else if(targetCount > 1){
					alertify.alert("More than one selection of cic from target not allowed.");
					return;
				}

				else{
					for (var i = 0; i < $scope.multiUnitTypeManuallyMatchedTargetData.length; i++) {
						if ($scope.multiUnitTypeManuallyMatchedTargetData[i].Selected) {
							multiUnitTarget.push({
								"corpItemCd" : $scope.multiUnitTypeManuallyMatchedTargetData[i].corpItemCd,
								"matchIndicator" : "M"
							});

							multiUnitTargetProductSourceCode.push({
								"prodSourceCd" : $scope.multiUnitTypeManuallyMatchedTargetData[i].itemTypeWhseDsd
							});

							multiUnitTargetUpc.push({
								"upcs" : $scope.multiUnitTypeManuallyMatchedTargetData[i].upcList
							});

							formData.push({
								"multiUnitSource" : multiUnitSource,
								"multiUnitTarget" : multiUnitTarget
							});
							break;
						}
					}
				}

				for(var i=0;i<multiUnitSourceUpc.length;i++){
					if(multiUnitTargetUpc[0] && multiUnitSourceUpc[i]){
						if(includes(multiUnitTargetUpc[0].upcs, multiUnitSourceUpc[i].upcs[0]) == false){
							break;
						}
					}
				}

				function includes(container, value) {
					var pos = container.indexOf(value);
					if (pos >= 0) {
						returnValue = true;
					}
					else{
						returnValue = false;
					}
					return returnValue;
				}

				if(multiUnitSourceProductSourceCodeNoDuplicates.length == 1){
					isSameProductSourceCodeWhse();
				}

				if(multiUnitSourceProductSourceCodeNoDuplicates.length == 2){
					isSourceWhseChecking();
					isTargetProductSourceCodeWhse();
				}

				function isSameProductSourceCodeWhse(){
					if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "WHSE" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"
							&& multiUnitSource.length > 1){
//						productSourceCodeWhse = false;
//						alertify.alert("Multiple WHSE to WHSE unmapping not allowed.");
//						return;
					}
					else if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "DSD" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"){
						productSourceCodeWhse = false;
						alertify.alert("DSD to WHSE unmapping not allowed.");
						return;
					}
					else if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "WHSE" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "DSD"){
						productSourceCodeWhse = false;
						alertify.alert("WHSE to DSD unmapping not allowed.");
						return;
					}
					else{
						productSourceCodeWhse = true;
					}
				}

				function isSourceWhseChecking(){
					for(var i=0;i<multiUnitSourceProductSourceCodeNoDuplicates.length;i++){
						if(multiUnitSourceProductSourceCodeNoDuplicates[i].prodSourceCd == "WHSE"){
							isSourceWhse = true;
							break;
						}
					}
				}

				function isTargetProductSourceCodeWhse(){
					if(isSourceWhse == true){
						if(multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"){
							targetProductSourceCodeWhse = true;
						}
						else{
							targetProductSourceCodeWhse = false;
							alertify.alert("Unmapping not allowed.");
							return;
						}
					}
				}

				var formDataObject = JSON.parse(JSON.stringify(formData[0]));

			

				var multiUnitUnmapUrl = $scope.baseUrl+"multiUnitType/unMapMultiUnitItem";

				if(productSourceCodeWhse == true && targetProductSourceCodeWhse == true){
					if(returnValue == true){
						$http.post(multiUnitUnmapUrl, formDataObject, config)
						.then(function(response){
							//function handles success condition
							$scope.totalDisplayedSource = 0;
							$scope.totalDisplayedTarget = 0;
							$scope.loadMultiUnitTypeManuallyMatchedSourceTargetData($scope.companyId, $scope.divisionId);
						}, function(response){
							//function handles error condtion
						});
					}
					else{
						alertify.alert("Imperfect upc unmatching");
						return;
					}	
				}
			}
		};

		/**
		 * UnMap Items Button action after selecting an SKU and CIC in 'Auto Matched'
		 */
		$scope.unMapAutoMatchedItems = function (){
			var sourceCount = 0;
			var targetCount = 0;
			var updatedUserID = null;
			var multiUnitSource = [];
			var multiUnitSourceUpc = [];
			var multiUnitSourceUpcNoDuplicates = [];
			var multiUnitSourceProductSourceCode = [];
			var multiUnitSourceProductSourceCodeNoDuplicates = [];
			var multiUnitTarget = [];
			var multiUnitTargetUpc = [];
			var multiUnitTargetUpcNoDuplicates = [];
			var multiUnitTargetProductSourceCode = [];
			var formData = [];
			var productSourceCodeWhse = true;
			var isSourceWhse = true;
			var targetProductSourceCodeWhse = true;

			angular.forEach($scope.multiUnitTypeAutoMatchedSourceData, function(multiUnitTypeAutoMatchedSource){
				if (multiUnitTypeAutoMatchedSource.Selected) {
					sourceCount = sourceCount+1;
				}
			});
			if(sourceCount == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else {
				for (var i = 0; i < $scope.multiUnitTypeAutoMatchedSourceData.length; i++) {
					if ($scope.multiUnitTypeAutoMatchedSourceData[i].Selected) {
						updatedUserID = service.userId;	
						multiUnitSource.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"productSku" : $scope.multiUnitTypeAutoMatchedSourceData[i].productSku,
							"convProductSku" : $scope.multiUnitTypeAutoMatchedSourceData[i].convProductSku,
							"srcItemDesc" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcItemDesc,
							"srcPackWhse" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcPackWhse,
							"srcVendConvFctr" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcVendConvFctr,
							"srcSize" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcSize,
							"srcUpc" : $scope.multiUnitTypeAutoMatchedSourceData[i].upcs[0],
							"prodSourceCd" : $scope.multiUnitTypeAutoMatchedSourceData[i].prodSourceCd,
							"productHierarchy" : $scope.multiUnitTypeAutoMatchedSourceData[i].productHierarchy,
							"deptName" : $scope.multiUnitTypeAutoMatchedSourceData[i].deptName,
							"productSkuSet" : $scope.multiUnitTypeAutoMatchedSourceData[i].productSkuSet,
							"caseUpc" : $scope.multiUnitTypeAutoMatchedSourceData[i].caseUpc,
							"srcCost" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcCost,
							"srcVendNum" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcVendNum,
							"srcVendName" : $scope.multiUnitTypeAutoMatchedSourceData[i].srcVendName,
							"upcs" : $scope.multiUnitTypeAutoMatchedSourceData[i].upcs,
							"updatedUserId" : updatedUserID
						});

						multiUnitSourceProductSourceCode.push({
							"prodSourceCd" : $scope.multiUnitTypeAutoMatchedSourceData[i].prodSourceCd
						});

						multiUnitSourceUpc.push({
							"upcs" : $scope.multiUnitTypeAutoMatchedSourceData[i].upcs
						});
					}
				}

				angular.forEach(multiUnitSourceProductSourceCode, function(value, key) {
					var exists = false;
					angular.forEach(multiUnitSourceProductSourceCodeNoDuplicates, function(value2, key) {
						if(angular.equals(value.prodSourceCd, value2.prodSourceCd)){ 
							exists = true; 
						}; 
					});
					if(exists == false && value.prodSourceCd != "") { 
						multiUnitSourceProductSourceCodeNoDuplicates.push(value); 
					}
				});

				angular.forEach($scope.multiUnitTypeAutoMatchedTargetData, function(multiUnitTypeAutoMatchedTarget){
					if (multiUnitTypeAutoMatchedTarget.Selected){
						targetCount = targetCount+1;
					}
				});

				if(targetCount == 0){
					alertify.alert("Select any CIC from Target Items.");
					return;
				}
				else if(targetCount > 1){
					alertify.alert("More than one selection of cic from target not allowed.");
					return;
				}

				else{
					for (var i = 0; i < $scope.multiUnitTypeAutoMatchedTargetData.length; i++) {
						if ($scope.multiUnitTypeAutoMatchedTargetData[i].Selected) {
							multiUnitTarget.push({
								"corpItemCd" : $scope.multiUnitTypeAutoMatchedTargetData[i].corpItemCd,
								"matchIndicator" : "A"
							});

							multiUnitTargetProductSourceCode.push({
								"prodSourceCd" : $scope.multiUnitTypeAutoMatchedTargetData[i].itemTypeWhseDsd
							});

							multiUnitTargetUpc.push({
								"upcs" : $scope.multiUnitTypeAutoMatchedTargetData[i].upcList
							});

							formData.push({
								"multiUnitSource" : multiUnitSource,
								"multiUnitTarget" : multiUnitTarget
							});
							break;
						}
					}
				}

				for(var i=0;i<multiUnitTargetUpc[0].upcs.length;i++){
					multiUnitTargetUpcNoDuplicates.push({
						"upcs" : multiUnitTargetUpc[0].upcs[i]
					});
				}

				for(var i=0;i<multiUnitSourceUpc.length;i++){
					multiUnitSourceUpcNoDuplicates.push({
						"upcs" : multiUnitSourceUpc[i].upcs[0]
					});
				}

				if(multiUnitSourceProductSourceCodeNoDuplicates.length == 1){
					isSameProductSourceCodeWhse();
				}

				if(multiUnitSourceProductSourceCodeNoDuplicates.length == 2){
					isSourceWhseChecking();
					isTargetProductSourceCodeWhse();
				}

				function isSameProductSourceCodeWhse(){
					if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "WHSE" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"
							&& multiUnitSource.length > 1){
//						productSourceCodeWhse = false;
//						alertify.alert("Multiple WHSE to WHSE unmapping not allowed.");
//						return;
					}
					else if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "DSD" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"){
						productSourceCodeWhse = false;
						alertify.alert("DSD to WHSE unmapping not allowed.");
						return;
					}
					else if(multiUnitSourceProductSourceCodeNoDuplicates[0].prodSourceCd == "WHSE" 
						&& multiUnitTargetProductSourceCode[0].prodSourceCd == "DSD"){
						productSourceCodeWhse = false;
						alertify.alert("WHSE to DSD unmapping not allowed.");
						return;
					}
					else{
						productSourceCodeWhse = true;
					}
				}

				function isSourceWhseChecking(){
					for(var i=0;i<multiUnitSourceProductSourceCodeNoDuplicates.length;i++){
						if(multiUnitSourceProductSourceCodeNoDuplicates[i].prodSourceCd == "WHSE"){
							isSourceWhse = true;
							break;
						}
					}
				}

				function isTargetProductSourceCodeWhse(){
					if(isSourceWhse == true){
						if(multiUnitTargetProductSourceCode[0].prodSourceCd == "WHSE"){
							targetProductSourceCodeWhse = true;
						}
						else{
							targetProductSourceCodeWhse = false;
							alertify.alert("Unmapping not allowed.");
							return;
						}
					}
				}

				var formDataObject = JSON.parse(JSON.stringify(formData[0]));

				

				var multiUnitUnmapUrl = $scope.baseUrl+"multiUnitType/unMapMultiUnitItem";

				if(productSourceCodeWhse == true && targetProductSourceCodeWhse == true){
					if(angular.equals(multiUnitSourceUpcNoDuplicates, multiUnitTargetUpcNoDuplicates)){
						$http.post(multiUnitUnmapUrl, formDataObject, config)
						.then(function(response){
							//function handles success condition
							$scope.totalDisplayedSource = 0;
							$scope.totalDisplayedTarget = 0;
							$scope.loadMultiUnitTypeAutoMatchedSourceTargetData($scope.companyId, $scope.divisionId);
						}, function(response){
							//function handles error condtion
						});
					}
					else{
						alertify.alert("Imperfect upc unmatching.");
						return;
					}

				}
			}
		};

		/**
		 * Not A Multi-Unit button action. Marking a source not a multi unit in 'To be matched'
		 */
		$scope.unmarkMultiUnitItems = function (){
			var count = 0;
			var productSku = null;
			var convProductSku = null;
			var companyId = null;
			var divisionId = null;
			var updatedUserID = null;
			var formData = [];
			angular.forEach($scope.multiUnitTypeSourceData, function(multiUnitTypeSource){
				if (multiUnitTypeSource.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else if($scope.multiUnitTypeButtonValue == 'N'){
				alertify.alert("Item already in not a multi unit status.");
				return;
			}
			else {
				for (var i = 0; i < $scope.multiUnitTypeSourceData.length; i++) {
					if ($scope.multiUnitTypeSourceData[i].Selected) {
						companyId = $scope.companyId;
						divisionId = $scope.divisionId;
						productSku = $scope.multiUnitTypeSourceData[i].productSku;
						convProductSku = $scope.multiUnitTypeSourceData[i].convProductSku;
						updatedUserID = service.userId;
						formData.push({
							"companyId" : companyId,
							"divisionId" : divisionId,
							"productSku" : productSku,
							"convProductSku" : convProductSku,
							"updatedUserId" : updatedUserID
						});
					}
				}
				

				var unmarkMultiUnitItemsUrl = $scope.baseUrl+"multiUnitType/markNotAMultiUnit";

				$http.post(unmarkMultiUnitItemsUrl, formData, config)
				.then(function(response){
					//function handles success condition
					$scope.loadMultiUnitTypeSourceTargetData($scope.companyId, $scope.divisionId);
					$scope.matchedMultiUnitTypeYes();
				}, function(response){
					//function handles error condtion
				});
			}
		};

		/**
		 * Mark Multi-Unit button action. Marking a source as a multi unit in 'To be matched'
		 */
		$scope.markMultiUnitItems = function(){
			var count = 0;
			var formData = [];
			angular.forEach($scope.multiUnitTypeSourceData, function(multiUnitTypeSource){
				if (multiUnitTypeSource.Selected) {
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else if($scope.multiUnitTypeButtonValue == 'Y'){
				alertify.alert("Item already in multi unit status.");
				return;
			}
			else {
				for (var i = 0; i < $scope.multiUnitTypeSourceData.length; i++) {
					if ($scope.multiUnitTypeSourceData[i].Selected) {
						formData.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"productSku" : $scope.multiUnitTypeSourceData[i].productSku,
							"convProductSku" : $scope.multiUnitTypeSourceData[i].convProductSku,
							"srcItemDesc" : $scope.multiUnitTypeSourceData[i].srcItemDesc,
							"srcPackWhse" : $scope.multiUnitTypeSourceData[i].srcPackWhse,
							"srcVendConvFctr" : $scope.multiUnitTypeSourceData[i].srcVendConvFctr,
							"srcSize" : $scope.multiUnitTypeSourceData[i].srcSize,
							"srcUpc" : $scope.multiUnitTypeSourceData[i].upcs[0],
							"prodSourceCd" : $scope.multiUnitTypeSourceData[i].prodSourceCd,
							"productHierarchy" : $scope.multiUnitTypeSourceData[i].productHierarchy,
							"deptName" : $scope.multiUnitTypeSourceData[i].deptName,
							"productSkuSet" : $scope.multiUnitTypeSourceData[i].productSkuSet,
							"caseUpc" : $scope.multiUnitTypeSourceData[i].caseUpc,
							"srcCost" : $scope.multiUnitTypeSourceData[i].srcCost,
							"maxRetail" : $scope.multiUnitTypeSourceData[i].maxRetail,
							"srcVendNum" : $scope.multiUnitTypeSourceData[i].srcVendNum,
							"srcVendName" : $scope.multiUnitTypeSourceData[i].srcVendName,
							"upcs" : $scope.multiUnitTypeSourceData[i].upcs,
							"updatedUserId" : service.userId
						});
					}
				}
				

				var markMultiUnitItemsUrl = $scope.baseUrl+"multiUnitType/markItemAsMultiUnit";

				$http.post(markMultiUnitItemsUrl, formData, config)
				.then(function(response){
					//function handles success condition
					$scope.loadMultiUnitTypeSourceTargetData($scope.companyId, $scope.divisionId);
					$scope.matchedMultiUnitTypeYes();
				}, function(response){
					//function handles error condtion
				});
			}
		};

		/**
		 * Marking a source item as dead in 'To be matched'
		 */
		$scope.markDead = function (){
			var count = 0;
			var productSku = null;
			var prodSourceCd = null;
			var convProductSku = null;
			var companyId = null;
			var divisionId = null;
			var markAsDeadReason = null;
			var updatedUserID = null;
			var formData = [];

			angular.forEach($scope.multiUnitTypeSourceData, function(multiUnitTypeSource){
				if (multiUnitTypeSource.Selected){
					count = count+1;
				}
			});
			if(count == 0){
				alertify.alert("Select any Product SKU from Source Items.");
				return;
			}
			else {
				alertify.prompt("Enter the reason for marking this item as dead.", function(e, str){
					if(e){
						markAsDeadReason = str;
						updatedUserID = service.userId;
						if(markAsDeadReason == null || markAsDeadReason.length == 0){
							$scope.markDead();
						}
						else if(markAsDeadReason != null || markAsDeadReason.length != 0){
							var whiteSpace = new RegExp(/^\s+$/);
							if(whiteSpace.test(str)) {
								$scope.markDead();
							}
							else {
								for (var i = 0; i < $scope.multiUnitTypeSourceData.length; i++) {
									if ($scope.multiUnitTypeSourceData[i].Selected) {
										companyId = $scope.companyId;
										divisionId = $scope.divisionId;
										productSku = $scope.multiUnitTypeSourceData[i].productSku;
										convProductSku = $scope.multiUnitTypeSourceData[i].convProductSku;
										prodSourceCd = $scope.multiUnitTypeSourceData[i].prodSourceCd,
										formData.push({
											"companyId" : companyId,
											"divisionId" : divisionId,
											"productSku" : productSku,
											"convProductSku" : convProductSku,
											"prodSourceCd" : prodSourceCd,
											"markAsDeadReason" : markAsDeadReason,
											"updatedUserId" : updatedUserID
										});
									}
								}
								

								var markDeadUrl = $scope.baseUrl+"multiUnitType/markMultiUnitDead";

								$http.post(markDeadUrl, formData, config)
								.then(function(response){
									//function handles success condition
									$scope.loadMultiUnitTypeSourceTargetData($scope.companyId, $scope.divisionId);
									$scope.matchedMultiUnitTypeYes();
								}, function(response){
									//function handles error condtion
								});
							}
						}
					}
					else {

					}
				});
			}
		};

		/**
		 * Multi-Unit radio button action(Yes) in source under 'To be matched'
		 */
		$scope.matchedMultiUnitTypeYes = function (){
			document.getElementById("tobematchedmultiunittypeyes").checked = true;
			document.getElementById("tobematchedmultiunittypeno").checked = false;
			$scope.multiUnitTypeButtonValue = 'Y';
		};

		/**
		 * Multi-Unit radio button action(No) in source under 'To be matched'
		 */
		$scope.matchedMultiUnitTypeNo = function (){
			document.getElementById("tobematchedmultiunittypeyes").checked = false;
			document.getElementById("tobematchedmultiunittypeno").checked = true;
			$scope.multiUnitTypeButtonValue = 'N';
		};

		/**
		 * U62615 - code optimized
		 * Source Search action in To Be Matched, Manually Matched and Auto Matched
		 */
		$scope.multiUnitTypeSourceSearch = function (sourceDropDownValue){
			//$scope.totalDisplayedSource = 0;
			var formDataSearch = [];
			var whiteSpace = new RegExp(/^\s+$/);
			if(sourceDropDownValue == ""){
				alertify.alert("Please select any option");
				return;
			}else{
				if(sourceDropDownValue){
					if(sourceDropDownValue == "tobematchedsourceitemdescription"){
						if(document.getElementById("tobematchedsourcesearchbox").value == "" || whiteSpace.test(document.getElementById("tobematchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Item Desc.");
							return;
						}else{
							$scope.totalDisplayed = 200;
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcItemDesc" : document.getElementById("tobematchedsourcesearchbox").value,
								"srcMultiUnitFlag" : $scope.multiUnitTypeButtonValue,
								"itemDescFlag" : "Y",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "N",
								"matchIndicator" : "P"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}else if(sourceDropDownValue == "manuallymatchedsourceitemdescription"){
						if(document.getElementById("manuallymatchedsourcesearchbox").value == "" || whiteSpace.test(document.getElementById("manuallymatchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Item Desc.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcItemDesc" : document.getElementById("manuallymatchedsourcesearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"itemDescFlag" : "Y",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "N",
								"matchIndicator" : "M"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}else if(sourceDropDownValue == "automatchedsourceitemdescription"){
						if(document.getElementById("automatchedsourcesearchbox").value == "" || whiteSpace.test(document.getElementById("automatchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Item Desc.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcItemDesc" : document.getElementById("automatchedsourcesearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"itemDescFlag" : "Y",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "N",
								"matchIndicator" : "A"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}else if(sourceDropDownValue == "tobematchedsourcevendorname"){
						if(document.getElementById("tobematchedsourcesearchbox").value == "" || whiteSpace.test(document.getElementById("tobematchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Vendor Name.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcVendName" : document.getElementById("tobematchedsourcesearchbox").value,
								"srcMultiUnitFlag" : $scope.multiUnitTypeButtonValue,
								"itemDescFlag" : "N",
								"venderNameFlag" : "Y",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "N",
								"matchIndicator" : "P"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}
					else if(sourceDropDownValue == "manuallymatchedsourcevendorname"){
						if(document.getElementById("manuallymatchedsourcesearchbox").value == "" || whiteSpace.test(document.getElementById("manuallymatchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Vendor Name.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcVendName" : document.getElementById("manuallymatchedsourcesearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "Y",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "N",
								"matchIndicator" : "M"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}else if(sourceDropDownValue == "automatchedsourcevendorname"){
						if(document.getElementById("automatchedsourcesearchbox").value == "" || whiteSpace.test(document.getElementById("automatchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Vendor Name.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcVendName" : document.getElementById("automatchedsourcesearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "Y",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "N",
								"matchIndicator" : "A"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}else if(sourceDropDownValue == "tobematchedsourcehierarchy"){
						formDataSearch.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"srcprodHierarchyLvl1Cd" : document.getElementById("tobematchedsourcehierarchyfirst").value,
							"srcprodHierarchyLvl2Cd" : document.getElementById("tobematchedsourcehierarchysecond").value,
							"srcprodHierarchyLvl3Cd" : document.getElementById("tobematchedsourcehierarchythird").value,
							"srcMultiUnitFlag" : $scope.multiUnitTypeButtonValue,
							"itemDescFlag" : "N",
							"venderNameFlag" : "N",
							"hierarchyOrSmicFlag" : "Y",
							"productSKUsearchFlag" : "N",
							"matchIndicator" : "P"
						});
						$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
					}else if(sourceDropDownValue == "manuallymatchedsourcehierarchy"){
						formDataSearch.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"srcprodHierarchyLvl1Cd" : document.getElementById("manuallymatchedsourcehierarchyfirst").value,
							"srcprodHierarchyLvl2Cd" : document.getElementById("manuallymatchedsourcehierarchysecond").value,
							"srcprodHierarchyLvl3Cd" : document.getElementById("manuallymatchedsourcehierarchythird").value,
							"srcMultiUnitFlag" : "Y",
							"itemDescFlag" : "N",
							"venderNameFlag" : "N",
							"hierarchyOrSmicFlag" : "Y",
							"productSKUsearchFlag" : "N",
							"matchIndicator" : "M"
						});
						$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
					}else if(sourceDropDownValue == "automatchedsourcehierarchy"){
						formDataSearch.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"srcprodHierarchyLvl1Cd" : document.getElementById("automatchedsourcehierarchyfirst").value,
							"srcprodHierarchyLvl2Cd" : document.getElementById("automatchedsourcehierarchysecond").value,
							"srcprodHierarchyLvl3Cd" : document.getElementById("automatchedsourcehierarchythird").value,
							"srcMultiUnitFlag" : "Y",
							"itemDescFlag" : "N",
							"venderNameFlag" : "N",
							"hierarchyOrSmicFlag" : "Y",
							"productSKUsearchFlag" : "N",
							"matchIndicator" : "A"
						});
						$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
					}else if(sourceDropDownValue == "tobematchedsourceprodsku"){
						if(document.getElementById("tobematchedsourcesearchbox").value == "" 
							|| whiteSpace.test(document.getElementById("tobematchedsourcesearchbox").value)
							|| isNaN(document.getElementById("tobematchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Product SKU.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcProductSKU" : document.getElementById("tobematchedsourcesearchbox").value,
								"srcMultiUnitFlag" : $scope.multiUnitTypeButtonValue,
								"itemDescFlag" : "N",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "Y",
								"matchIndicator" : "P"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}
					else if(sourceDropDownValue == "manuallymatchedsourceprodsku"){
						if(document.getElementById("manuallymatchedsourcesearchbox").value == "" 
							|| whiteSpace.test(document.getElementById("manuallymatchedsourcesearchbox").value)
							|| isNaN(document.getElementById("manuallymatchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Product SKU.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcProductSKU" : document.getElementById("manuallymatchedsourcesearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "Y",
								"matchIndicator" : "M"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}else if(sourceDropDownValue == "automatchedsourceprodsku"){
						if(document.getElementById("automatchedsourcesearchbox").value == "" 
							|| whiteSpace.test(document.getElementById("automatchedsourcesearchbox").value)
							|| isNaN(document.getElementById("automatchedsourcesearchbox").value)){
							alertify.alert("Please enter a Valid Product SKU.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"srcProductSKU" : document.getElementById("automatchedsourcesearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"productSKUsearchFlag" : "Y",
								"matchIndicator" : "A"
							});
							$scope.multiUnitTypeSourceSearchCommonService(sourceDropDownValue,formDataSearch);
						}
					}
				}
			}
		};

		/**
		 * U62615 - code optimized
		 * Common Source Search service call in To Be Matched, Manually Matched and Auto Matched
		 */
		$scope.multiUnitTypeSourceSearchCommonService = function (sourceDropDownValue,formDataSearch){
			var multiUnitSourceSplitString = " ";
			
			var multiUnitTypeSourceSearchUrl = $scope.baseUrl+"multiUnitType/multiUnitSourceSearch";

			$http.post(multiUnitTypeSourceSearchUrl, formDataSearch, config)
			.then(function(response){
				//function handles success condition
				if(response.data){
					for(var i=0; i<response.data.length; i++){
						if(response.data[i].productHierarchy){
							multiUnitSourceSplitString = response.data[i].productHierarchy.split("-");
						}
						response.data[i].productHierarchyFirst = multiUnitSourceSplitString[0];
						response.data[i].productHierarchySecond = multiUnitSourceSplitString[1];
						response.data[i].productHierarchyThird = multiUnitSourceSplitString[2];
					}
					if(sourceDropDownValue == "tobematchedsourceitemdescription" 
						|| sourceDropDownValue == "tobematchedsourcevendorname"
							||	sourceDropDownValue == "tobematchedsourcehierarchy"
								||	sourceDropDownValue == "tobematchedsourceprodsku"){
						$scope.multiUnitTypeSourceData = response.data;
					}
					else if(sourceDropDownValue == "manuallymatchedsourceitemdescription" 
						|| sourceDropDownValue == "manuallymatchedsourcevendorname"
							|| sourceDropDownValue == "manuallymatchedsourcehierarchy"
								|| sourceDropDownValue == "manuallymatchedsourceprodsku"){
						$scope.multiUnitTypeManuallyMatchedSourceData = response.data;
					}
					else if(sourceDropDownValue == "automatchedsourceitemdescription"
						|| sourceDropDownValue == "automatchedsourcevendorname"
							|| sourceDropDownValue == "automatchedsourcehierarchy"
								|| sourceDropDownValue == "automatchedsourceprodsku"){
						$scope.multiUnitTypeAutoMatchedSourceData = response.data;
					}
					$scope.sourceLength = response.data.length;
					$scope.loadMoreSource();
				}else{
					if(sourceDropDownValue == "tobematchedsourceitemdescription" 
						|| sourceDropDownValue == "tobematchedsourcevendorname"
							||	sourceDropDownValue == "tobematchedsourcehierarchy"
								||	sourceDropDownValue == "tobematchedsourceprodsku"){
						$scope.multiUnitTypeSourceData = null;
					}
					else if(sourceDropDownValue == "manuallymatchedsourceitemdescription" 
						|| sourceDropDownValue == "manuallymatchedsourcevendorname"
							|| sourceDropDownValue == "manuallymatchedsourcehierarchy"
								|| sourceDropDownValue == "manuallymatchedsourceprodsku"){
						$scope.multiUnitTypeManuallyMatchedSourceData = null;
					}
					else if(sourceDropDownValue == "automatchedsourceitemdescription"
						|| sourceDropDownValue == "automatchedsourcevendorname"
							|| sourceDropDownValue == "automatchedsourcehierarchy"
								|| sourceDropDownValue == "automatchedsourceprodsku"){
						$scope.multiUnitTypeAutoMatchedSourceData = null;
					}
					$scope.sourceLength = 0;
					$scope.loadMoreSource();
				}
			}, function(response){
				//function handles error condtion
			});
		};

		/**
		 * U62615 - code optimized
		 * Source Target action in To Be Matched, Manually Matched and Auto Matched
		 */
		$scope.multiUnitTypeTargetSearch = function (targetDropDownValue){
			//$scope.totalDisplayedTarget = 0;
			var formDataSearch = [];
			var whiteSpace = new RegExp(/^\s+$/);
			if(targetDropDownValue == ""){
				alertify.alert("Please select any option");
				return;
			}else{
				if(targetDropDownValue){
					if(targetDropDownValue == "tobematchedtargetitemdescription"){
						if(document.getElementById("tobematchedtargetsearchbox").value == "" || whiteSpace.test(document.getElementById("tobematchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid Item Desc.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"tarItemDesc" : document.getElementById("tobematchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "N",
								"itemDescFlag" : "Y",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "P"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "manuallymatchedtargetitemdescription"){
						if(document.getElementById("manuallymatchedtargetsearchbox").value == "" || whiteSpace.test(document.getElementById("manuallymatchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid Item Desc.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"tarItemDesc" : document.getElementById("manuallymatchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "N",
								"itemDescFlag" : "Y",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "M"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "automatchedtargetitemdescription"){
						if(document.getElementById("automatchedtargetsearchbox").value == "" || whiteSpace.test(document.getElementById("automatchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid Item Desc.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"tarItemDesc" : document.getElementById("automatchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "N",
								"itemDescFlag" : "Y",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "A"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "tobematchedtargetvendorname"){
						if(document.getElementById("tobematchedtargetsearchbox").value == "" || whiteSpace.test(document.getElementById("tobematchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid Vendor Name.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"tarVendorName" : document.getElementById("tobematchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "N",
								"itemDescFlag" : "N",
								"venderNameFlag" : "Y",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "P"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "manuallymatchedtargetvendorname"){
						if(document.getElementById("manuallymatchedtargetsearchbox").value == "" || whiteSpace.test(document.getElementById("manuallymatchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid Vendor Name.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"tarVendorName" : document.getElementById("manuallymatchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "N",
								"itemDescFlag" : "N",
								"venderNameFlag" : "Y",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "M"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "automatchedtargetvendorname"){
						if(document.getElementById("automatchedtargetsearchbox").value == "" || whiteSpace.test(document.getElementById("automatchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid Vendor Name.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"tarVendorName" : document.getElementById("automatchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "N",
								"itemDescFlag" : "N",
								"venderNameFlag" : "Y",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "A"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "tobematchedtargetsmic"){
						formDataSearch.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"tarGrpCd" : document.getElementById("tobematchedsmicfirst").value,
							"tarCtgryCd" : document.getElementById("tobematchedsmicsecond").value,
							"tarClsCd" : document.getElementById("tobematchedsmicthird").value,
							"tarSbClsCd" : document.getElementById("tobematchedsmicfourth").value,
							"tarSubSbClass" : document.getElementById("tobematchedsmicfifth").value,
							"srcMultiUnitFlag" : "Y",
							"targetCICsearchFlag" : "N",
							"itemDescFlag" : "N",
							"venderNameFlag" : "N",
							"hierarchyOrSmicFlag" : "Y",
							"matchIndicator" : "P"
						});
						$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
					}else if(targetDropDownValue == "manuallymatchedtargetsmic"){
						formDataSearch.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"tarGrpCd" : document.getElementById("manuallymatchedsmicfirst").value,
							"tarCtgryCd" : document.getElementById("manuallymatchedsmicsecond").value,
							"tarClsCd" : document.getElementById("manuallymatchedsmicthird").value,
							"tarSbClsCd" : document.getElementById("manuallymatchedsmicfourth").value,
							"tarSubSbClass" : document.getElementById("manuallymatchedsmicfifth").value,
							"srcMultiUnitFlag" : "Y",
							"targetCICsearchFlag" : "N",
							"itemDescFlag" : "N",
							"venderNameFlag" : "N",
							"hierarchyOrSmicFlag" : "Y",
							"matchIndicator" : "M"
						});
						$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
					}else if(targetDropDownValue == "automatchedtargetsmic"){
						formDataSearch.push({
							"companyId" : $scope.companyId,
							"divisionId" : $scope.divisionId,
							"tarGrpCd" : document.getElementById("automatchedsmicfirst").value,
							"tarCtgryCd" : document.getElementById("automatchedsmicsecond").value,
							"tarClsCd" : document.getElementById("automatchedsmicthird").value,
							"tarSbClsCd" : document.getElementById("automatchedsmicfourth").value,
							"tarSubSbClass" : document.getElementById("automatchedsmicfifth").value,
							"srcMultiUnitFlag" : "Y",
							"targetCICsearchFlag" : "N",
							"itemDescFlag" : "N",
							"venderNameFlag" : "N",
							"hierarchyOrSmicFlag" : "Y",
							"matchIndicator" : "A"
						});
						$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
					}else if(targetDropDownValue == "tobematchedtargetcic"){
						if(document.getElementById("tobematchedtargetsearchbox").value == "" 
							|| whiteSpace.test(document.getElementById("tobematchedtargetsearchbox").value) 
							|| isNaN(document.getElementById("tobematchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid CIC.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"targetCIC" : document.getElementById("tobematchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "P"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "manuallymatchedtargetcic"){
						if(document.getElementById("manuallymatchedtargetsearchbox").value == "" 
							|| whiteSpace.test(document.getElementById("manuallymatchedtargetsearchbox").value)
							|| isNaN(document.getElementById("manuallymatchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid CIC.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"targetCIC" : document.getElementById("manuallymatchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "M"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}else if(targetDropDownValue == "automatchedtargetcic"){
						if(document.getElementById("automatchedtargetsearchbox").value == "" 
							|| whiteSpace.test(document.getElementById("automatchedtargetsearchbox").value)
							|| isNaN(document.getElementById("automatchedtargetsearchbox").value)){
							alertify.alert("Please enter a Valid CIC.");
							return;
						}else{
							formDataSearch.push({
								"companyId" : $scope.companyId,
								"divisionId" : $scope.divisionId,
								"targetCIC" : document.getElementById("automatchedtargetsearchbox").value,
								"srcMultiUnitFlag" : "Y",
								"targetCICsearchFlag" : "Y",
								"itemDescFlag" : "N",
								"venderNameFlag" : "N",
								"hierarchyOrSmicFlag" : "N",
								"matchIndicator" : "A"
							});
							$scope.multiUnitTypeTargetSearchCommonService(targetDropDownValue,formDataSearch);
						}
					}
				}
			}
		};

		/**
		 * U62615 - code optimized
		 * Common Target Search service call in To Be Matched, Manually Matched and Auto Matched
		 */
		$scope.multiUnitTypeTargetSearchCommonService = function (targetDropDownValue,formDataSearch){
			var multiUnitTargetSplitString = " ";
			
			var multiUnitTypeTargetSearchUrl = $scope.baseUrl+"multiUnitType/multiUnitTargetSearch";

			$http.post(multiUnitTypeTargetSearchUrl, formDataSearch, config)
			.then(function(response){
				//function handles success condition
				if(response.data){
					for(var i=0; i<response.data.length; i++){
						if(response.data[i].smicCode){
							multiUnitTargetSplitString = response.data[i].smicCode.split("-");
						}
						response.data[i].smicFirst = multiUnitTargetSplitString[0];
						response.data[i].smicSecond = multiUnitTargetSplitString[1];
						response.data[i].smicThird = multiUnitTargetSplitString[2];
						response.data[i].smicFourth = multiUnitTargetSplitString[3];
						response.data[i].smicFifth = multiUnitTargetSplitString[4];
					}
					if(targetDropDownValue == "tobematchedtargetitemdescription"
						|| targetDropDownValue == "tobematchedtargetvendorname"
							|| targetDropDownValue == "tobematchedtargetsmic"
								|| targetDropDownValue == "tobematchedtargetcic"){
						$scope.multiUnitTypeTargetData = response.data;
					}
					else if(targetDropDownValue == "manuallymatchedtargetitemdescription"
						|| targetDropDownValue == "manuallymatchedtargetvendorname"
							|| targetDropDownValue == "manuallymatchedtargetsmic"
								|| targetDropDownValue == "manuallymatchedtargetcic"){
						$scope.multiUnitTypeManuallyMatchedTargetData = response.data;
					}
					else if(targetDropDownValue == "automatchedtargetitemdescription"
						|| targetDropDownValue == "automatchedtargetvendorname"
							|| targetDropDownValue == "automatchedtargetsmic"
								|| targetDropDownValue == "automatchedtargetcic"){
						$scope.multiUnitTypeAutoMatchedTargetData = response.data;
					}
					$scope.targetLength = response.data.length;
					$scope.loadMoreTarget();
				}else{
					if(targetDropDownValue == "tobematchedtargetitemdescription"
						|| targetDropDownValue == "tobematchedtargetvendorname"
							|| targetDropDownValue == "tobematchedtargetsmic"
								|| targetDropDownValue == "tobematchedtargetcic"){
						$scope.multiUnitTypeTargetData = null;
					}
					else if(targetDropDownValue == "manuallymatchedtargetitemdescription"
						|| targetDropDownValue == "manuallymatchedtargetvendorname"
							|| targetDropDownValue == "manuallymatchedtargetsmic"
								|| targetDropDownValue == "manuallymatchedtargetcic"){
						$scope.multiUnitTypeManuallyMatchedTargetData = null;
					}
					else if(targetDropDownValue == "automatchedtargetitemdescription"
						|| targetDropDownValue == "automatchedtargetvendorname"
							|| targetDropDownValue == "automatchedtargetsmic"
								|| targetDropDownValue == "automatchedtargetcic"){
						$scope.multiUnitTypeAutoMatchedTargetData = null;
					}
					$scope.targetLength = 0;
					$scope.loadMoreTarget();
				}
			}, function(response){
				//function handles error condtion
			});
		};
		
		/**
		 *  U63178
		 * Show the UPC in badge
		 */
		$scope.upcLoadFunction = function(cicClicked) {
			$scope.cicOpted = {};
			$scope.cicOpted.upcDetails = [];
			var upcLoadUrl = $scope.baseUrl+"multiUnitType/loadMultiUnitTargetUpcPopUp/"+cicClicked;

			$http.get(upcLoadUrl, config)
			.then(function(response){
				//function handles success condition
				if (response.data){
					$scope.cicOpted.upcDetails = response.data;
				}
			}, function(response1){
				//function handles error condition
			});
		};
			});
		}
			)};
	}]);	 
})();