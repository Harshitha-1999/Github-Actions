(function(){
	'use strict';
	
	myApp.controller('UpdateOverrideController',['$scope', '$http', '$location', '$timeout', 'blockUI', 'service','OverrideMappingService', 'UpdateOverrideService',
	function UpdateOverrideController($scope, $http, $location, $timeout, blockUI, service,OverrideMappingService, UpdateOverrideService){
		
		var retrievedData = localStorage.getItem("updateoverridesku");
		var UpdateOverridePrdskuValue = JSON.parse(retrievedData);
		if(UpdateOverridePrdskuValue != null){
			UpdateOverridePrdskuValue.sort(function(a, b) {return a-b;});
		}
		var UpdateOverrideInitialValue = UpdateOverrideService.getValue();
		var UpdateOverrideCompanyID = UpdateOverrideService.getCompanyID();
		var UpdateOverrideDivisionID = UpdateOverrideService.getDivisionID();
		var UpdateOverrideProductSkuSourceUpcDropDownvalue = UpdateOverrideService.getProductSkuSourceUpcDropDownvalue();
		var isValid = true;
		var isCharacterValid = true;
		var isNumberValid = true;
		var isSmicFirstValid = true;
		var isSmicSecondValid = true;
		var isPrivateLabelValid = true;
		var isDescSizeValid = true;
		var isNumSizeValid = true;
		var isSizeUomValid = true;
		var isUsageIndValid = true;
		var isUsageTypeValid = true;
		var isDisplayValid = true;
		var isItemDescValid = true;
		var isWhseDescValid = true;
		var isSsDescValid = true;
		var isInternetDescValid = true;
		var isPosDescValid = true;
		var isProductClassCodeValid = true;
		var UpdateOverrideLikeSrcEditDetailsTempString;
		var SmicTempString;
		var UpdateOverrideLikeSrcEditDetailsTempObject = null;
		var SmicTempObject = null;
		var currentUsageInd = null;
		var type = null;
		var OverrideMappingServiceKey = OverrideMappingService.getKey();
		var isProductClassCodeChecked = true;
		
		document.getElementById('backToPerishMappingBtn').style.visibility = 'hidden';
		
//		$scope.baseUrl=service.baseUrlFunction();
		
		if(service.baseUrlFunction() != undefined ) {
			service.baseUrlFunction().then(function(url){
				$scope.baseUrl =  url;

		service.getHeaders().then(function(header) {
			var config = header
//     });
				
		$scope.isPrdclscodeValid = true;
		$scope.uomCode = service.uomCodes;
		if($scope.uomCode)
			$scope.selectedUomCode = $scope.uomCode[0];

		/**
		 *  U63178
		 *  Initialise
		 */
		$scope.init = function () {
			document.getElementById('itemDesc').focus();
			var windowHeight = $(window).innerHeight();
            $('#editPanel1').css('height', windowHeight-330);
            $('#editPanel2').css('height', windowHeight-330);
		};
		
		/**
		 *  Load usage type combo
		 */
		$scope.loadUsageTypeCombo = function() {
			if(!$scope.UpdateOverrideLikeSrcEditDetails)
				return;
			
			/**Added by NFRAN for bug fix**/
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.innerPack == null){
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.innerPack = 1;
			}

			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.retailUnitPack == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.retailUnitPack == 0){
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.retailUnitPack = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
			}
			/**Added by NFRAN for bug fix**/
			
			if(currentUsageInd != null && currentUsageInd == $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd)
				return;
			
			var second = document.getElementById('second-select-input');

			var val = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd;
			currentUsageInd = val;
			empty(second);
			
			if (val == 'E') {
				addOption('L', second);
				addOption('O', second);
				addOption('W', second);
				if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd !== 'L' &&
				   $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd !== 'O' &&
				   $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd !== 'W')
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = 'L';
			}

			if (val == 'M') {
				addOption('M', second);
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = 'M';
			}

			if (val == 'Q') {
				addOption(' ', second);
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = ' ';
			}

			if (val == 'R') {
				addOption('C', second);
				addOption('R', second);
				addOption('S', second);
				if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd !== 'C' &&
				   $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd !== 'R' &&
				   $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd !== 'S')
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = 'C';
			}
			
			if (!val) {
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = ' ';
			}
		};
		
		function empty(select) {
			select.innerHTML = ' ';
		}
		
		function addOption(val, select) {
			var option = document.createElement('option');
			option.value = val;
			option.innerHTML = val;
			select.appendChild(option);
		}
		
		$scope.$on('$viewContentLoaded', function(){
			$scope.loadUsageTypeCombo();
		  });
		
		/**
		 *  Load SMIC Desc
		 */
		
		
		$scope.loadSMICDesc=function (){
			var uiEditObj = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto;
			var groupCode = 0;
			var categoryCode = 0;
			var classCode = 0;
			var subClassCode = 0;
			var subSubClassCode = 0;
			if(uiEditObj.grpCd == null || uiEditObj.ctgryCd == null || uiEditObj.grpCd.length == 0 || uiEditObj.ctgryCd.length == 0){
				$scope.smicDesc = null;
				return;
			}
			else {
				groupCode = uiEditObj.grpCd;
				categoryCode = uiEditObj.ctgryCd;
				if(uiEditObj.clsCd == null || uiEditObj.clsCd.length == 0)
					classCode = 0;
				else
					classCode = uiEditObj.clsCd;
				if(uiEditObj.sbClsCd == null || uiEditObj.sbClsCd.length == 0)
					subClassCode = 0;
				else
					subClassCode = uiEditObj.sbClsCd;
				if(uiEditObj.subSbClass == null || uiEditObj.subSbClass.length == 0)
					subSubClassCode = 0;
				else
					subSubClassCode = uiEditObj.subSbClass;
				var smicDetailsUrl=$scope.baseUrl+"smic/detail/"+groupCode+"/"+categoryCode+"/"+classCode+"/"+subClassCode+"/"+subSubClassCode;
					$http.get(smicDetailsUrl,config)
					.then(function (response) {
						if(response.data.length > 0){
							$scope.smicDesc = response.data[0].smicdesc;
						}
						else{
							alertify.alert("Invalid SMIC Code.");
							$scope.smicDesc = null;
							return;
						}
					}, function (response) {
						//function handles error condition
					});
			}
		};
		
		/**
		 *  Load UOM Code
		 */
		$scope.loadUOMCode = function (){
			if($scope.uomCode == null || $scope.UpdateOverrideLikeSrcEditDetails == null)
				return;
			var validUOM = false;
			for(var i=0;i<$scope.uomCode.length;i++){
				if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom == $scope.uomCode[i].uomCode){
					$scope.selectedUomCode = $scope.uomCode[i];
					validUOM = true;
					break;
				}
			}
			if(validUOM == false){
				$scope.selectedUomCode = null;
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom = null;
			}
		};
		
		/**
		 *  Selected table row
		 */
		$scope.selectedTableRow = function (row) {
			document.getElementById('checkboxid').checked = false;
			document.getElementById('chkUnhide').checked = false;
			var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify(row);
			var UpdateOverrideLikeSrcEditDetailsObject = JSON.parse(UpdateOverrideLikeSrcEditDetailsString);
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto = UpdateOverrideLikeSrcEditDetailsObject;
			$scope.loadSMICDesc();
			$scope.loadUsageTypeCombo();
			$scope.loadUOMCode();
			if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true || $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true || $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
				document.getElementById('manualMapChkBox').disabled = true;
			}
			else{
				document.getElementById('manualMapChkBox').disabled = false;
			}
		};
		
		/**
		 *  GENERAL CONDITION
		 */
		if(retrievedData!=null){
			OverrideMappingService.setKey(null);
			OverrideMappingServiceKey = null;
			UpdateOverrideProductSkuSourceUpcDropDownvalue = null;
			$scope.UpdateOverrideLikeSrcEditDetails = null;
			$scope.UpdateOverrideEditDetails = null;
			$scope.UpdateOverrideSrcDetails = null;
			$scope.likeItemsRecords = null;
			if(UpdateOverridePrdskuValue.length == 1){
				document.getElementById('prevProductSkuButton').style.visibility = 'hidden';
				document.getElementById('nextProductSkuButton').style.visibility = 'hidden';
			}
			var UpdateOverrideLikeSrcEditDetailsUrl=$scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
			$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
				.then(function (response) {
					//function handles success condition		    
						$scope.UpdateOverrideLikeSrcEditDetails = response.data;
						$scope.loadUOMCode();
						$scope.UpdateOverrideEditDetails = response.data.newItemDto;
						$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
						$scope.likeItemsRecords = response.data.likeItems;
						document.getElementById('alreadySavedItem').innerHTML="";
						document.getElementById('ChkBox').disabled = false;
						document.getElementById('ChkBox').checked = false;
						document.getElementById('mapChkBox').disabled = false;
						document.getElementById('mapChkBox').checked = false;
						document.getElementById('manualMapChkBox').disabled = false;
						document.getElementById('manualMapChkBox').checked = false;
						document.getElementById('saveAndNextBtn1').disabled = false;
						document.getElementById('saveBtn1').disabled = false;
						if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
							if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('ChkBox').checked = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
								document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('mapChkBox').checked = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
						 		document.getElementById('manualMapChkBox').disabled = true; 
								document.getElementById('manualMapChkBox').checked = true; 
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else{
								document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
							}
							document.getElementById('checkboxid').checked = false;
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
								document.getElementById('manualMapChkBox').disabled = true;
							}
						}
						else{
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
									$scope.selectedTableRow($scope.likeItemsRecords[i]);
								}
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
							}
						}
						$scope.loadUsageTypeCombo();
						$scope.loadSMICDesc();
				}, function (response) {
					//function handles error condition
				});
			localStorage.clear();
		}
		
		/**
		 *  GENERAL CONDITION
		 */
		if(UpdateOverrideProductSkuSourceUpcDropDownvalue=="updateoverrideproductsku" || UpdateOverrideProductSkuSourceUpcDropDownvalue=="updateoverridesourceupc"){
			retrievedData = null;
			var updateOverrideManualSearchRetrievedData = localStorage.getItem("UpdateOverrideManualSearch");
			$scope.UpdateOverrideLikeSrcEditDetails = JSON.parse(updateOverrideManualSearchRetrievedData);
			$scope.loadUOMCode();
			
			document.getElementById('ChkBox').disabled = false;
			document.getElementById('ChkBox').checked = false;
			document.getElementById('mapChkBox').disabled = false;
			document.getElementById('mapChkBox').checked = false;
			document.getElementById('manualMapChkBox').disabled = false;
			document.getElementById('manualMapChkBox').checked = false;
			document.getElementById('saveAndNextBtn1').disabled = false;
			document.getElementById('saveBtn1').disabled = false;
			if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
				if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
					document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = true;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
				else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
					document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = true;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
		 		else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
					document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = true; 
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true; 
				}
				else{
					document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
				}
				document.getElementById('checkboxid').checked = false;
				for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
					$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
					document.getElementById('manualMapChkBox').disabled = true;
				}
			}
			$scope.UpdateOverrideEditDetails = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto;
			$scope.UpdateOverrideSrcDetails = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[0];
			$scope.likeItemsRecords = $scope.UpdateOverrideLikeSrcEditDetails.likeItems;
			for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
				if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
					document.getElementById('checkboxid').checked = false;
					var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify($scope.likeItemsRecords[i]);
					var UpdateOverrideLikeSrcEditDetailsObject = JSON.parse(UpdateOverrideLikeSrcEditDetailsString);
					if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd != 'C'){
						$scope.UpdateOverrideLikeSrcEditDetails.newItemDto = UpdateOverrideLikeSrcEditDetailsObject;
					}
					if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true || $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true || $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
						document.getElementById('manualMapChkBox').disabled = true;
					}
					else{
						document.getElementById('manualMapChkBox').disabled = false;
					}
				}
				$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
			}
			$scope.loadSMICDesc();
			
			if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.productSrcCd == "WHSE"){
				type = 'W';
			}
			else{
				type = 'D';
			}
			
			var loadUpdateOverrideProductSku = $scope.baseUrl+"exsrc/loadProductSKUs/"+$scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.companyId+"/"+$scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.divisionId+"/"+$scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.hierLevel4+"/"+'O'+"/"+$scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd+"/"+type;
			$http.get(loadUpdateOverrideProductSku,config)
			.then (function(response){
				//function handles success condition
				if(response.data != null || response.data.length != 0){
					UpdateOverridePrdskuValue = (response.data).sort(function(a, b) {return a-b;});
					UpdateOverrideInitialValue = UpdateOverridePrdskuValue.indexOf($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.productSKU);
				}
			}, function (response){
				//function handles error condition
			});
			
			localStorage.clear();
			updateOverrideManualSearchRetrievedData = null;
		}
		
		/**
		 *  Set UOM Code
		 */
		$scope.setUomCode = function (){
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom = $scope.selectedUomCode.uomCode;
		};
		
		$scope.smicFieldFirstColumnValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.grpCd == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.grpCd.length == 0){
				isSmicFirstValid = false;
				document.getElementById('smic1').style.borderColor = "red";
				return isSmicFirstValid;
			}
			else {
				isSmicFirstValid = true;
				document.getElementById('smic1').style.removeProperty('border');
				return isSmicFirstValid;
			}
		};
			
		$scope.smicFieldSecondColumnValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.ctgryCd == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.ctgryCd.length == 0){
				isSmicSecondValid = false;
				document.getElementById('smic2').style.borderColor = "red";
				return isSmicSecondValid;
			}
			else {
				isSmicSecondValid = true;
				document.getElementById('smic2').style.removeProperty('border');
				return isSmicSecondValid;
			}
		};
		
		$scope.PrivateLabelFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updPtLabelInd == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updPtLabelInd.length == 0){
				isPrivateLabelValid = false;
				document.getElementById('privateLabel').style.borderColor = "red";
				return isPrivateLabelValid;
			}
			else {
				isPrivateLabelValid = true;
				document.getElementById('privateLabel').style.removeProperty('border');
				return isPrivateLabelValid;
			}
		};
		
		$scope.DescSizeFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSize == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSize.length == 0){
				isDescSizeValid = false;
				document.getElementById('SizeDesc').style.borderColor = "red";
				return isDescSizeValid;
			}
			else {
				isDescSizeValid = true;
				document.getElementById('SizeDesc').style.removeProperty('border');
				return isDescSizeValid;
			}
		};
		
		$scope.NumSizeFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr.length == 0){
				isNumSizeValid = false;
				document.getElementById('numSize').style.borderColor = "red";
				return isNumSizeValid;
			}
			else {
				isNumSizeValid = true;
				document.getElementById('numSize').style.removeProperty('border');
				return isNumSizeValid;
			}
		};

		$scope.SizeUOMFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom.length == 0){
				isSizeUomValid = false;
				document.getElementById('uom').style.borderColor = "red";
				return isSizeUomValid;
			}
			else {
				isSizeUomValid = true;
				document.getElementById('uom').style.removeProperty('border');
				return isSizeUomValid;
			}
		};
		
		$scope.UsageIndFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd.length ==  0){
				isUsageIndValid = false;
				document.getElementById('select-input').style.borderColor = "red";
				return isUsageIndValid;
			}
			else {
				isUsageIndValid = true;
				document.getElementById('select-input').style.removeProperty('border');
				return isUsageIndValid;
			}
		};
		
		$scope.UsageTypeFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd.length ==  0){
				isUsageTypeValid = false;
				document.getElementById('second-select-input').style.borderColor = "red";
				return isUsageTypeValid;
			}
			else {
				isUsageTypeValid = true;
				document.getElementById('second-select-input').style.removeProperty('border');
				return isUsageTypeValid;
			}
		};
		
		$scope.DisplayFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updDispFlag == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updDispFlag.length == 0){
				isDisplayValid = false;
				document.getElementById('display').style.borderColor = "red";
				return isDisplayValid;
			}
			else {
				isDisplayValid = true;
				document.getElementById('display').style.removeProperty('border');
				return isDisplayValid;
			}
		};
		
		$scope.ItemDescFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updItmDesc == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updItmDesc.length == 0){
				isItemDescValid = false;
				document.getElementById('itemDesc').style.borderColor = "red";
				return isItemDescValid;
			}
			else {
				isItemDescValid = true;
				document.getElementById('itemDesc').style.removeProperty('border');
				return isItemDescValid;
			}
		};
		
		$scope.WhseDescFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updWhseItmDesc == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updWhseItmDesc.length == 0){
				isWhseDescValid = false;
				document.getElementById('whseDesc').style.borderColor = "red";
				return isWhseDescValid;
			}
			else {
				isWhseDescValid = true;
				document.getElementById('whseDesc').style.removeProperty('border');
				return isWhseDescValid;
			}
		};
		
		$scope.SsDescFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updRtlItmDesc == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updRtlItmDesc.length == 0){
				isSsDescValid = false;
				document.getElementById('ssDesc').style.borderColor = "red";
				return isSsDescValid;
			}
			else {
				isSsDescValid = true;
				document.getElementById('ssDesc').style.removeProperty('border');
				return isSsDescValid;
			}
		};
		
		$scope.InternetDescFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updIntenetItemDesc == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updIntenetItemDesc.length == 0){
				isInternetDescValid = false;
				document.getElementById('internetDesc').style.borderColor = "red";
				return isInternetDescValid;
			}
			else {
				isInternetDescValid = true;
				document.getElementById('internetDesc').style.removeProperty('border');
				return isInternetDescValid;
			}
		};
		
		$scope.PosDescFieldValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updPosDesc == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updPosDesc.length == 0){
				isPosDescValid = false;
				document.getElementById('posDesc').style.borderColor = "red";
				return isPosDescValid;
			}
			else {
				isPosDescValid = true;
				document.getElementById('posDesc').style.removeProperty('border');
				return isPosDescValid;
			}
		};
		
		$scope.ProductClassCodeValidation = function(){
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd == null || $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd.length == 0){
				isProductClassCodeValid = false;
				document.getElementById('productClassCode').style.borderColor = "red";
				return isProductClassCodeValid;
			}
			else {
				isProductClassCodeValid = true;
				document.getElementById('productClassCode').style.removeProperty('border');
				return isProductClassCodeValid;
			}
		};
		
		/**
		 *  Reset validations error
		 */
		$scope.resetValidationErrors = function(){
			isValid = true;
			isCharacterValid = true;
			isNumberValid = true;
			isSmicFirstValid == true;
			isSmicSecondValid == true;
			isPrivateLabelValid = true;
			isDescSizeValid = true;
			isNumSizeValid = true;
			isSizeUomValid = true;
			isUsageIndValid = true;
			isUsageTypeValid = true;
			isDisplayValid = true;
			isItemDescValid = true;
			isWhseDescValid = true;
			isSsDescValid = true;
			isInternetDescValid = true;
			isPosDescValid = true;
			isProductClassCodeValid = true;
			document.getElementById('smic1').style.removeProperty('border');
			document.getElementById('smic2').style.removeProperty('border');
			document.getElementById('privateLabel').style.removeProperty('border');
			document.getElementById('SizeDesc').style.removeProperty('border');
			document.getElementById('numSize').style.removeProperty('border');
			document.getElementById('uom').style.removeProperty('border');
			document.getElementById('select-input').style.removeProperty('border');
			document.getElementById('second-select-input').style.removeProperty('border');
			document.getElementById('display').style.removeProperty('border');
			document.getElementById('itemDesc').style.removeProperty('border');
			document.getElementById('whseDesc').style.removeProperty('border');
			document.getElementById('ssDesc').style.removeProperty('border');
			document.getElementById('internetDesc').style.removeProperty('border');
			document.getElementById('posDesc').style.removeProperty('border');
			document.getElementById('productClassCode').style.removeProperty('border');
		};
		
		/**
		 *  Over validate save
		 */
		$scope.OverrideValidateSave = function(UpdateOverrideLikeSrcEditDetails, type){
			$scope.isPrdclscodeValid = true;
			document.getElementById('productClassCode').style.removeProperty('border');
			
			if($scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd){
				var prdclscode = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd.toString();
				var dummyGrpCode = "GC";
				if(prdclscode != "" && prdclscode != null && prdclscode.length != 0){
					var prdclscodeUrl=$scope.baseUrl+"newitem/targetProdValidate/"+prdclscode+"/"+dummyGrpCode;
					$http.get(prdclscodeUrl,config)
					.then(function (response) {
						//function handles success condition
						if(response.data == true){
							isProductClassCodeChecked = true;
							if(type == 'save'){
								$scope.UpdateOverride(UpdateOverrideLikeSrcEditDetails);
							}else{
								$scope.UpdateOverrideSaveNext();
							}
						}
						else{
							isProductClassCodeChecked = false;
							$scope.isPrdclscodeValid = false;
							document.getElementById('productClassCode').style.borderColor = "red";
							return;
						}
						
					}, function (response) {
						//function handles error condition
						document.getElementById('productClassCode').style.borderColor = "red";
						alertify.alert("Invalid Product Class Code."); 
						return;
					});
				}
				else{
					document.getElementById('productClassCode').style.borderColor = "red";
					alertify.alert("Highlighted fields are Mandatory."); 
					return;
				}
			}
		};
		
		/**
		 *  Update override
		 */
		$scope.UpdateOverride = function (UpdateOverrideLikeSrcEditDetails){
			$scope.smicFieldFirstColumnValidation();
			$scope.smicFieldSecondColumnValidation();
			$scope.PrivateLabelFieldValidation();
			$scope.DescSizeFieldValidation();
			$scope.NumSizeFieldValidation();
			$scope.SizeUOMFieldValidation();
			$scope.UsageIndFieldValidation();
			$scope.UsageTypeFieldValidation();
			$scope.DisplayFieldValidation();
			$scope.ItemDescFieldValidation();
			$scope.WhseDescFieldValidation();
			$scope.SsDescFieldValidation();
			$scope.InternetDescFieldValidation();
			$scope.PosDescFieldValidation();
			$scope.ProductClassCodeValidation();
			$scope.specialCharacterValidation(UpdateOverrideLikeSrcEditDetails);
			$scope.numberValidation(UpdateOverrideLikeSrcEditDetails);
			
			if(isSmicFirstValid == false || isSmicSecondValid == false || isPrivateLabelValid == false || isDescSizeValid == false || isNumSizeValid == false || isSizeUomValid == false || isUsageIndValid == false || isUsageTypeValid == false || isDisplayValid == false || isItemDescValid == false || isWhseDescValid == false || isSsDescValid == false || isInternetDescValid == false || isPosDescValid == false || isProductClassCodeValid == false || isProductClassCodeChecked == false){
				isValid = false;
				alertify.alert("Highlighted fields are mandatory."); 
				return;
			}
			else {
				isValid = true;
			}
			
			if(isValid == true && isCharacterValid == true && isNumberValid == true) {
				if(UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.itmUsgeInd != UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd || UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.itmUsgeTypInd != UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd){
					alertify.confirm("Usage Ind or Usage Type is different from incoming data. Do you want to proceed?", function(e){
						if (e) {
							$scope.save(UpdateOverrideLikeSrcEditDetails);
						}
						else {
		
						}
					});
				}
				else {
					$scope.save(UpdateOverrideLikeSrcEditDetails);
				}
			}
	    };
	    
	    /**
		 *  Save update override function
		 */
	    $scope.save = function (UpdateOverrideLikeSrcEditDetails){
	    	UpdateOverrideLikeSrcEditDetails.newItemDto.createId  = service.userId;
	    	UpdateOverrideLikeSrcEditDetails.newItemDto.augOverCmplnInd = 'Y';
	    	////////////
	    	UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
	    	UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
	    	UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
	    	UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
	    	////////////
			UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID  = service.userId;
			
			var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify(UpdateOverrideLikeSrcEditDetails);
			var UpdateOverrideLikeSrcEditDetailsSaveUrl=$scope.baseUrl+"newitem/override/save";
			
		
			$http.post(UpdateOverrideLikeSrcEditDetailsSaveUrl, UpdateOverrideLikeSrcEditDetailsString, config)
				.then(function (response) {
					//function handles success condition
					var saveStatus = response.data.status;
					
					if(saveStatus==1){
						$scope.triggerForceNewPerishables();
						if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
							OverrideMappingService.setKey(null);
							OverrideMappingServiceKey = null;
							$location.path('/');
						}
						alertify.success("Saved successfully!");
					}
					if(saveStatus == 2){
						var savedObject = response.data;
						var alertMsg = "<h4>Please correct the following errors and try again.</h4>";
						for (var i = 0; i < savedObject.errorMessages.length; i++) {
							alertMsg += "<div style='color:RED;BORDER: 1px solid #edf0f1;padding:3px;";
							if(i % 2 == 0){
								alertMsg += "background-color:#f9fafa;" + "'>";
							}
							else{
								alertMsg += "background-color:#ffffff;" + "'>";
							}
						    alertMsg += savedObject.errorMessages[i];
						    alertMsg += "</div>";
						}
						alertify.alert(alertMsg);
						return;
					}
					if(saveStatus == 0){
						$scope.triggerForceNewPerishables();
					}
				}, function (response) {
					//function handles error condition
				});
	    };
	    
	    /**
		 *  Save & Next update override function
		 */
		$scope.UpdateOverrideSaveNext = function(){
			$scope.smicFieldFirstColumnValidation();
			$scope.smicFieldSecondColumnValidation();
			$scope.PrivateLabelFieldValidation();
			$scope.DescSizeFieldValidation();
			$scope.NumSizeFieldValidation();
			$scope.SizeUOMFieldValidation();
			$scope.UsageIndFieldValidation();
			$scope.UsageTypeFieldValidation();
			$scope.DisplayFieldValidation();
			$scope.ItemDescFieldValidation();
			$scope.WhseDescFieldValidation();
			$scope.SsDescFieldValidation();
			$scope.InternetDescFieldValidation();
			$scope.PosDescFieldValidation();
			$scope.ProductClassCodeValidation();
			$scope.specialCharacterValidation($scope.UpdateOverrideLikeSrcEditDetails);
			$scope.numberValidation($scope.UpdateOverrideLikeSrcEditDetails);
			
			if(isSmicFirstValid == false || isSmicSecondValid == false || isPrivateLabelValid == false || isDescSizeValid == false || isNumSizeValid == false || isSizeUomValid == false || isUsageIndValid == false || isUsageTypeValid == false || isDisplayValid == false || isItemDescValid == false || isWhseDescValid == false || isSsDescValid == false || isInternetDescValid == false || isPosDescValid == false || isProductClassCodeValid == false  || isProductClassCodeChecked == false){
				isValid = false;
				alertify.alert("Highlighted fields are mandatory."); 
				return;
			}
			else {
				isValid = true;
			}
			
			if(isValid == true && isCharacterValid == true && isNumberValid == true) {
				if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.itmUsgeInd != $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd || $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.itmUsgeTypInd != $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd){
					alertify.confirm("Usage Ind or Usage Type is different from incoming data. Do you want to proceed?", function(e){
						if (e) {
							$scope.saveNext();
						}
						else {
							
						}
					});
				}
				else {
					$scope.saveNext();
				}
			}
		};
		
		/**
		 *  Save Next function
		 */
		$scope.saveNext = function () {
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.createId  = service.userId;
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.augOverCmplnInd = 'Y';
			$scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID  = service.userId;
			////////////
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = $scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
			$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
	    	////////////
	    	
			var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify($scope.UpdateOverrideLikeSrcEditDetails);
			var UpdateOverrideLikeSrcEditDetailsSaveUrl=$scope.baseUrl+"newitem/override/save";
		
		
			$http.post(UpdateOverrideLikeSrcEditDetailsSaveUrl, UpdateOverrideLikeSrcEditDetailsString, config)
				.then(function (response) {
					//function handles success condition
					var saveStatus = response.data.status;
					if(saveStatus==1){
						$scope.triggerForceNewPerishables();
						$scope.smicDesc = null;
						UpdateOverrideInitialValue = UpdateOverrideInitialValue+1;
						if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
							OverrideMappingService.setKey(null);
							OverrideMappingServiceKey = null;
							$location.path('/');
						}else if(UpdateOverrideInitialValue && UpdateOverrideInitialValue == UpdateOverridePrdskuValue.length) {
							alertify.alert("No more items under this department.");
							$location.path('/');
						}else{
							var UpdateOverrideLikeSrcEditDetailsUrl=$scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
							$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
								.then(function (response) {
									//function handles success condition
									$scope.disableSmicEdit();
									$scope.UpdateOverrideLikeSrcEditDetails=response.data;
									$scope.loadUOMCode();
									$scope.UpdateOverrideEditDetails=response.data.newItemDto;
									$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
									$scope.likeItemsRecords = response.data.likeItems;
									document.getElementById('alreadySavedItem').innerHTML="";
									document.getElementById('ChkBox').disabled = false;
									document.getElementById('ChkBox').checked = false;
									document.getElementById('mapChkBox').disabled = false;
									document.getElementById('mapChkBox').checked = false;
									document.getElementById('manualMapChkBox').disabled = false;
									document.getElementById('manualMapChkBox').checked = false; 
									document.getElementById('saveAndNextBtn1').disabled = false;
									document.getElementById('saveBtn1').disabled = false;
									if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
										if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
											document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('ChkBox').checked = true;
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('manualMapChkBox').disabled = true;
											document.getElementById('saveAndNextBtn1').disabled = true;
											document.getElementById('saveBtn1').disabled = true;
										}
										else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
											document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('mapChkBox').checked = true;
											document.getElementById('manualMapChkBox').disabled = true;
											document.getElementById('saveAndNextBtn1').disabled = true;
											document.getElementById('saveBtn1').disabled = true;
										}
										else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
											document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('manualMapChkBox').disabled = true;
											document.getElementById('manualMapChkBox').checked = true;
											document.getElementById('saveAndNextBtn1').disabled = true;
											document.getElementById('saveBtn1').disabled = true;
										}
										else{
											document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
										}
										document.getElementById('checkboxid').checked = false;
										for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
											$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
											$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
											document.getElementById('manualMapChkBox').disabled = true;
										}
									}
									else{
										for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
											if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
												$scope.selectedTableRow($scope.likeItemsRecords[i]);
											}
											$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
										}
									}
									
									$scope.loadUsageTypeCombo();
									$scope.loadSMICDesc();
								}, function (response) {
									//function handles error condition
								});
						}
					}
					if(saveStatus == 2){
						var savedObject = response.data;
						var alertMsg = "<h4>Please correct the following errors and try again.</h4>";
						for (var i = 0; i < savedObject.errorMessages.length; i++) {
							alertMsg += "<div style='color:RED;BORDER: 1px solid #edf0f1;padding:3px;";
						    if(i % 2 == 0){
								alertMsg += "background-color:#f9fafa;" + "'>";
							}
							else{
								alertMsg += "background-color:#ffffff;" + "'>";
							}
						    alertMsg += savedObject.errorMessages[i];
						    alertMsg += "</div>";
						}
						alertify.alert(alertMsg);
						return;
					}
					if(saveStatus == 0){
						$scope.triggerForceNewPerishables();
					}
				}, function (response) {
					//function handles error condition
				});
		};
		
		/**
		 *  Skip to next productSku
		 */
		$scope.skipToNextProductSku = function(){
			UpdateOverrideInitialValue = UpdateOverrideInitialValue+1;
			document.getElementById('ChkBox').checked = false;
			document.getElementById('mapChkBox').checked = false;
			document.getElementById('manualMapChkBox').checked = false;
			$scope.manualMapItemChkBox();
			$scope.CheckkBoxValidation();
			$scope.manualMapChkBox();
			if(UpdateOverrideInitialValue == UpdateOverridePrdskuValue.length) {
				alertify.alert("This is the last item under this department.");
				UpdateOverrideInitialValue = UpdateOverrideInitialValue - 1;
				if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = true;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = false;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
				else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = true;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = false; 
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
				else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = true;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
			}
			else{
				document.getElementById('alreadySavedItem').innerHTML="";
				document.getElementById('ChkBox').disabled = false;
				document.getElementById('ChkBox').checked = false;
				document.getElementById('mapChkBox').disabled = false;
				document.getElementById('mapChkBox').checked = false;
				document.getElementById('manualMapChkBox').disabled = false;
				document.getElementById('manualMapChkBox').checked = false;
				document.getElementById('saveAndNextBtn1').disabled = false;
				document.getElementById('saveBtn1').disabled = false;
				$scope.resetValidationErrors();
				var UpdateOverrideLikeSrcEditDetailsUrl=$scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
				$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
					.then(function (response) {
						//function handles success condition
						$scope.disableSmicEdit();
						$scope.UpdateOverrideLikeSrcEditDetails=response.data;
						$scope.loadUOMCode();
						$scope.UpdateOverrideEditDetails=response.data.newItemDto;
						$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
						$scope.likeItemsRecords = response.data.likeItems;
						if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
							if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('ChkBox').checked = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
								document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('mapChkBox').checked = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').checked = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else{
								document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
							}
							document.getElementById('checkboxid').checked = false;
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
								document.getElementById('manualMapChkBox').disabled = true;
							}
						}
						else{
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
									$scope.selectedTableRow($scope.likeItemsRecords[i]);
								}
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
							}
						}
						$scope.loadUsageTypeCombo();
						$scope.loadSMICDesc();
					}, function (response) {
						//function handles error condition
					});
			}
		};
		
		/**
		 *  Skip to previous productSku
		 */
		$scope.skipToPrevProductSku = function(){
			UpdateOverrideInitialValue = UpdateOverrideInitialValue - 1;
			document.getElementById('ChkBox').checked = false;
			document.getElementById('mapChkBox').checked = false;
			document.getElementById('manualMapChkBox').checked = false;
			$scope.manualMapItemChkBox();
			$scope.CheckkBoxValidation();
			$scope.manualMapChkBox();
			if(UpdateOverrideInitialValue < 0) {
				alertify.alert("This is the first item under this department.");
				UpdateOverrideInitialValue = 0;
				if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = true;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = false;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
				else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = true;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = false;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
				else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById('manualMapChkBox').checked = true;
					document.getElementById('saveAndNextBtn1').disabled = true;
					document.getElementById('saveBtn1').disabled = true;
				}
			}
			else{
				document.getElementById('alreadySavedItem').innerHTML="";
				document.getElementById('ChkBox').disabled = false;
				document.getElementById('ChkBox').checked = false;
				document.getElementById('mapChkBox').disabled = false;
				document.getElementById('mapChkBox').checked = false;
				document.getElementById('manualMapChkBox').disabled = false;
				document.getElementById('manualMapChkBox').checked = false; 
				document.getElementById('saveAndNextBtn1').disabled = false;
				document.getElementById('saveBtn1').disabled = false;
				$scope.resetValidationErrors();
				var UpdateOverrideLikeSrcEditDetailsUrl=$scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
				$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
					.then(function (response) {
						//function handles success condition
						$scope.disableSmicEdit();
						$scope.UpdateOverrideLikeSrcEditDetails=response.data;
						$scope.loadUOMCode();
						$scope.UpdateOverrideEditDetails=response.data.newItemDto;
						$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
						$scope.likeItemsRecords = response.data.likeItems;
						if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
							if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('ChkBox').checked = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
								document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('mapChkBox').checked = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;	
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').checked = true; 
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else{
								document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
							}
							document.getElementById('checkboxid').checked = false;
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
								document.getElementById('manualMapChkBox').disabled = true;
							}
						}
						else{
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
									$scope.selectedTableRow($scope.likeItemsRecords[i]);
								}
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
							}
						}
						$scope.loadUsageTypeCombo();
						$scope.loadSMICDesc();
					}, function (response) {
						//function handles error condition
					});
			}
		};
		
		/**
		 *  Dead prompt
		 */
		$scope.UpdateOverrideKillThisProductSku = function(UpdateOverrideLikeSrcEditDetails){
			alertify.prompt("Please enter a reason for marking this item as dead.", function (e, str) {
				if(e){
					UpdateOverrideLikeSrcEditDetails.markAsDeadReason = str;
					if(UpdateOverrideLikeSrcEditDetails.markAsDeadReason == null || UpdateOverrideLikeSrcEditDetails.markAsDeadReason.length == 0){
						$scope.UpdateOverrideKillThisProductSku(UpdateOverrideLikeSrcEditDetails);
					}
					else if(UpdateOverrideLikeSrcEditDetails.markAsDeadReason != null || UpdateOverrideLikeSrcEditDetails.markAsDeadReason.length != 0){
						var whiteSpace = new RegExp(/^\s+$/);
						if(whiteSpace.test(str)) {
							$scope.UpdateOverrideKillThisProductSku(UpdateOverrideLikeSrcEditDetails);
						}
						else {
							$scope.UpdateOverrideLikeSrcEditDetails.killProdSku=true;
							UpdateOverrideLikeSrcEditDetails.newItemDto.createId = service.userId;
							////////////
							UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
							UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
							UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
							UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
					    	////////////
							UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID  = service.userId;
							var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify(UpdateOverrideLikeSrcEditDetails);
							var UpdateOverrideLikeSrcEditDetailsSaveUrl=$scope.baseUrl+"newitem/override/save";
						
							
							$http.post(UpdateOverrideLikeSrcEditDetailsSaveUrl, UpdateOverrideLikeSrcEditDetailsString, config)
							.then(function (response) {
								//function handles success condition
								var saveStatus = response.data.status;
								if(saveStatus==1){
									UpdateOverrideInitialValue = UpdateOverrideInitialValue+1;
									if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
										OverrideMappingService.setKey(null);
										OverrideMappingServiceKey = null;
										$location.path('/');
									}else if(UpdateOverrideInitialValue == UpdateOverridePrdskuValue.length) {
										alertify.alert("No more items under this department.");
										$location.path('/');
									}else{
										var UpdateOverrideLikeSrcEditDetailsUrl=$scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
										$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
										.then(function (response) {
											//function handles success condition
											$scope.disableSmicEdit();
											$scope.UpdateOverrideLikeSrcEditDetails = response.data;
											$scope.loadUOMCode();
											$scope.UpdateOverrideEditDetails = response.data.newItemDto;
											$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
											$scope.likeItemsRecords = response.data.likeItems;
											document.getElementById('alreadySavedItem').innerHTML="";
											document.getElementById('ChkBox').disabled = false;
											document.getElementById('ChkBox').checked = false;
											document.getElementById('mapChkBox').disabled = false;
											document.getElementById('mapChkBox').checked = false;
											document.getElementById('manualMapChkBox').disabled = false;
											document.getElementById('manualMapChkBox').checked = false;
											document.getElementById('saveAndNextBtn1').disabled = false;
											document.getElementById('saveBtn1').disabled = false;
											if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
												if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
													document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
													document.getElementById('ChkBox').disabled = true;
													document.getElementById('ChkBox').checked = true;
													document.getElementById('mapChkBox').disabled = true;
													document.getElementById('manualMapChkBox').disabled = true;
													document.getElementById('saveAndNextBtn1').disabled = true;
													document.getElementById('saveBtn1').disabled = true;	
												}
												else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
													document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
													document.getElementById('ChkBox').disabled = true;
													document.getElementById('mapChkBox').disabled = true;
													document.getElementById('mapChkBox').checked = true;
													document.getElementById('manualMapChkBox').disabled = true;
													document.getElementById('saveAndNextBtn1').disabled = true;
													document.getElementById('saveBtn1').disabled = true;
												}
												else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
													document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
													document.getElementById('ChkBox').disabled = true;
													document.getElementById('mapChkBox').disabled = true;
													document.getElementById('manualMapChkBox').disabled = true;
													document.getElementById('manualMapChkBox').checked = true;
													document.getElementById('saveAndNextBtn1').disabled = true;
													document.getElementById('saveBtn1').disabled = true;
												}
												else{
													document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
												}
												document.getElementById('checkboxid').checked = false;
												for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
													$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
													$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
													document.getElementById('manualMapChkBox').disabled = true;
												}
											}
											else{
												for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
													if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
														$scope.selectedTableRow($scope.likeItemsRecords[i]);
													}
													$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
												}
											}
											$scope.loadUsageTypeCombo();
											$scope.loadSMICDesc();
										}, function (response) {
											//function handles error condition
										});
									}
								}
							}, function (response) {
								//function handles error condition
							});
							document.getElementById('ChkBox').checked = false;
							$scope.CheckkBoxValidation();
							$scope.UpdateOverrideLikeSrcEditDetails.killProdSku = false;
						}
					}
				}
				else {
					document.getElementById('ChkBox').checked = false;
					$scope.CheckkBoxValidation();
				}
			});
		};
		
		$scope.killItemChkBox = function(productSrcCd, productSKU){
			if(document.getElementById('ChkBox').checked){
				var pattern = new RegExp(/^W/);
				if(pattern.test(productSrcCd)){
					var ProductSrcCdUrl = $scope.baseUrl+"/exsrc/onhandStatus/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+productSKU;
					$http.get(ProductSrcCdUrl,config)
					.then(function (response) {
						if(response.data == true){
							alertify.confirm("This Warehouse Item is on hand as per the system. Do you want to proceed with marking it as dead?" , function (e){
								if (e) {
									$scope.CheckkBoxValidation();
								}
								else {
									document.getElementById('ChkBox').checked = false;
								}
							});
						}
						else {
							$scope.CheckkBoxValidation();
						}
					}, function (response) {
						//function handles error condition
					});
				}
				else {
					$scope.CheckkBoxValidation();
				}
			}
			else{
				document.getElementById('saveKillItemBtn').style.display = "none";
				document.getElementById('saveAndNextBtn1').disabled = false;
				document.getElementById('saveBtn1').disabled = false;
				document.getElementById('mapChkBox').disabled = false;
				document.getElementById('manualMapChkBox').disabled = false;
			}
		};
		
		/**
		 *  Manual map item
		 */
		$scope.UpdateOverrideManualMapItem = function (UpdateOverrideLikeSrcEditDetails){ // code for mark out of scope
			alertify.confirm("Do you really want to move this item out of automated process?", function (e){
				if (e){
					UpdateOverrideLikeSrcEditDetails.manualMap = true;
					UpdateOverrideLikeSrcEditDetails.newItemDto.createId = service.userId;
					////////////
					UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
					UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
					UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
					UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
			    	////////////
					UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID = service.userId;
					var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify(UpdateOverrideLikeSrcEditDetails);
					var UpdateOverrideLikeSrcEditDetailsSaveUrl = $scope.baseUrl+"newitem/override/save";
					
					
					$http.post(UpdateOverrideLikeSrcEditDetailsSaveUrl, UpdateOverrideLikeSrcEditDetailsString, config)
					.then(function (response) {
						//function handles success condition
						var saveStatus = response.data.status;
						if(saveStatus==1){
							UpdateOverrideInitialValue = UpdateOverrideInitialValue+1;
							if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
								OverrideMappingService.setKey(null);
								OverrideMappingServiceKey = null;
								$location.path('/');
							}else if(UpdateOverrideInitialValue == UpdateOverridePrdskuValue.length) {	
								alertify.alert("No more items under this department.");
								$location.path('/');
							}else{
								var UpdateOverrideLikeSrcEditDetailsUrl = $scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
								$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
								.then(function (response) {
									//function handles success condition
									$scope.disableSmicEdit();
									$scope.UpdateOverrideLikeSrcEditDetails = response.data;
									$scope.loadUOMCode();
									$scope.UpdateOverrideEditDetails = response.data.newItemDto;
									$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
									$scope.likeItemsRecords = response.data.likeItems;
									document.getElementById('alreadySavedItem').innerHTML="";
									document.getElementById('ChkBox').disabled = false;
									document.getElementById('ChkBox').checked = false;
									document.getElementById('mapChkBox').disabled = false;
									document.getElementById('mapChkBox').checked = false;
									document.getElementById('manualMapChkBox').disabled = false;
									document.getElementById('manualMapChkBox').checked = false;
									document.getElementById('saveAndNextBtn1').disabled = false;
									document.getElementById('saveBtn1').disabled = false;
									if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
										if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
											document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('ChkBox').checked = true;
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('manualMapChkBox').disabled = true;
											document.getElementById('saveAndNextBtn1').disabled = true;
											document.getElementById('saveBtn1').disabled = true;
										}
										else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
											document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('mapChkBox').checked = true;
											document.getElementById('manualMapChkBox').disabled = true;
											document.getElementById('saveAndNextBtn1').disabled = true;
											document.getElementById('saveBtn1').disabled = true;
										}
										else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
											document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('manualMapChkBox').disabled = true;
											document.getElementById('manualMapChkBox').checked = true;
											document.getElementById('saveAndNextBtn1').disabled = true;
											document.getElementById('saveBtn1').disabled = true;
										}
										else{
											document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
										}
										document.getElementById('checkboxid').checked = false;
										for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
											$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
											$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
											document.getElementById('manualMapChkBox').disabled = true;
										}
									}
									else{
										for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
											if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
												$scope.selectedTableRow($scope.likeItemsRecords[i]);
											}
											$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
										}
									}
									$scope.loadUsageTypeCombo();
									$scope.loadSMICDesc();
								}, function (response) {
									//function handles error condition
								});
							}
						}
					}, function(response){
						//function handles error condition
					});
					document.getElementById('mapChkBox').checked = false;
					$scope.manualMapItemChkBox();
					$scope.UpdateOverrideLikeSrcEditDetails.manualMap = false;
				}
				else {
					document.getElementById('mapChkBox').checked = false;
					$scope.manualMapItemChkBox();
				}
			});
		};
		
		/**
		 *  Manual map item data
		 */
		$scope.UpdateOverrideManualMapItemData = function (UpdateOverrideLikeSrcEditDetails){ // code for manual map
			UpdateOverrideLikeSrcEditDetails.moveToManualMap = true;
			UpdateOverrideLikeSrcEditDetails.newItemDto.createId = service.userId;
			////////////
			UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
			UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
			UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
			UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
	    	////////////
			UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID = service.userId;
			var UpdateOverrideLikeSrcEditDetailsString = JSON.stringify(UpdateOverrideLikeSrcEditDetails);
			var UpdateOverrideLikeSrcEditDetailsSaveUrl = $scope.baseUrl+"newitem/override/save";
			
			
			$http.post(UpdateOverrideLikeSrcEditDetailsSaveUrl, UpdateOverrideLikeSrcEditDetailsString, config)
			.then(function (response) {
				//function handles success condition
				var saveStatus = response.data.status;
				if(saveStatus==1){
					UpdateOverrideInitialValue = UpdateOverrideInitialValue+1;
					if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
						OverrideMappingService.setKey(null);
						OverrideMappingServiceKey = null;
						$location.path('/');
					}else if(UpdateOverrideInitialValue == UpdateOverridePrdskuValue.length) {
						alertify.alert("No more items under this department.");
						$location.path('/');
					}
					else{
						var UpdateOverrideLikeSrcEditDetailsUrl = $scope.baseUrl+"exsrc/loadOverrideData/"+UpdateOverrideCompanyID+"/"+UpdateOverrideDivisionID+"/"+UpdateOverridePrdskuValue[UpdateOverrideInitialValue];
						$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
						.then(function (response) {
							//function handles success condition
							$scope.disableSmicEdit();
							$scope.UpdateOverrideLikeSrcEditDetails = response.data;
							$scope.loadUOMCode();
							$scope.UpdateOverrideEditDetails = response.data.newItemDto;
							$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
							$scope.likeItemsRecords = response.data.likeItems;
							document.getElementById('alreadySavedItem').innerHTML="";
							document.getElementById('ChkBox').disabled = false;
							document.getElementById('ChkBox').checked = false;
							document.getElementById('mapChkBox').disabled = false;
							document.getElementById('mapChkBox').checked = false;
							document.getElementById('manualMapChkBox').disabled = false;
							document.getElementById('manualMapChkBox').checked = false;
							document.getElementById('saveAndNextBtn1').disabled = false;
							document.getElementById('saveBtn1').disabled = false;
							if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
								if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
									document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('ChkBox').checked = true;
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('manualMapChkBox').disabled = true;
									document.getElementById('saveAndNextBtn1').disabled = true;
									document.getElementById('saveBtn1').disabled = true;	
								}
								else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
									document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('mapChkBox').checked = true;
									document.getElementById('manualMapChkBox').disabled = true;
									document.getElementById('saveAndNextBtn1').disabled = true;
									document.getElementById('saveBtn1').disabled = true;	
								}
								else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
									document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('manualMapChkBox').disabled = true;
									document.getElementById('manualMapChkBox').checked = true;
									document.getElementById('saveAndNextBtn1').disabled = true;
									document.getElementById('saveBtn1').disabled = true;
								}
								else{
									document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
								}
								document.getElementById('checkboxid').checked = false;
								for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
									$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
									$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
									document.getElementById('manualMapChkBox').disabled = true;
								}
							}
							else{
								for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
									if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
										$scope.selectedTableRow($scope.likeItemsRecords[i]);
									}
									$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
								}
							}
							$scope.loadUsageTypeCombo();
							$scope.loadSMICDesc();
						}, function (response) {
							//function handles error condition
						});
					}
				}
			}, function(response){
				//function handles error condition
			});
			document.getElementById('manualMapChkBox').checked = false;
			$scope.manualMapChkBox();
			$scope.UpdateOverrideLikeSrcEditDetails.moveToManualMap = false;
		};
		
		$scope.manualMapItemChkBox = function(){ // validation code for mark out of scope
			if(document.getElementById('mapChkBox').checked){
				document.getElementById('manualMapItem').style.display = "block";
				document.getElementById('ChkBox').disabled = true;
				document.getElementById('manualMapChkBox').disabled = true;
				document.getElementById('saveAndNextBtn1').disabled = true;
				document.getElementById('saveBtn1').disabled = true;
			}
			else {
				document.getElementById('manualMapItem').style.display = "none";
				document.getElementById('ChkBox').disabled = false;
				document.getElementById('manualMapChkBox').disabled = false;
				document.getElementById('saveAndNextBtn1').disabled = false;
				document.getElementById('saveBtn1').disabled = false;
			}
		};
		
		$scope.manualMapChkBox = function(){ // validation code for maual map
			if(document.getElementById('manualMapChkBox').checked){
				document.getElementById('manualMapItemButton').style.display = "block";
				document.getElementById('ChkBox').disabled = true;
				document.getElementById('mapChkBox').disabled = true;
				document.getElementById('saveAndNextBtn1').disabled = true;
				document.getElementById('saveBtn1').disabled = true;
			}
			else{
				document.getElementById('manualMapItemButton').style.display = "none";
				document.getElementById('ChkBox').disabled = false;
				document.getElementById('mapChkBox').disabled = false;
				document.getElementById('saveAndNextBtn1').disabled = false;
				document.getElementById('saveBtn1').disabled = false;
			}
		};
		
		/**
		 *  Dont borrow any attributes
		 */
		$scope.dontBorrowAnyAttributes = function () {
			if(document.getElementById('checkboxid').checked){
				document.getElementById('manualMapChkBox').disabled = true;
				UpdateOverrideLikeSrcEditDetailsTempString = JSON.stringify($scope.UpdateOverrideLikeSrcEditDetails.newItemDto);
				UpdateOverrideLikeSrcEditDetailsTempObject = JSON.parse(UpdateOverrideLikeSrcEditDetailsTempString);
				SmicTempString = JSON.stringify($scope.smicDesc);
				SmicTempObject = JSON.parse(SmicTempString);
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto = $scope.UpdateOverrideSrcDetails;
				
				if(($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true || $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true ) && $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1] != null){
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].updUsgeInd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].updUsageTypInd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.grpCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].grpCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.ctgryCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].ctgryCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.clsCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].clsCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.sbClsCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].sbClsCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.subSbClass = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].subSbClass;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productionGrpCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].productionGrpCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productionCtgryCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].productionCtgryCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productionClsCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].productionClsCd;
					if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].grpCd.toString().length == 1){
						$scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].grpCd = '0'+$scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].grpCd;
					}
					if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].ctgryCd.toString().length == 1){
						$scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].ctgryCd = '0'+$scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].ctgryCd;
					}
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd = $scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].grpCd+''+$scope.UpdateOverrideLikeSrcEditDetails.likeItems[1].ctgryCd;
				}
				
				else{
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd = UpdateOverrideLikeSrcEditDetailsTempObject.updUsgeInd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd = UpdateOverrideLikeSrcEditDetailsTempObject.updUsageTypInd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.grpCd = UpdateOverrideLikeSrcEditDetailsTempObject.grpCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.ctgryCd = UpdateOverrideLikeSrcEditDetailsTempObject.ctgryCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.clsCd = UpdateOverrideLikeSrcEditDetailsTempObject.clsCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.sbClsCd = UpdateOverrideLikeSrcEditDetailsTempObject.sbClsCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.subSbClass = UpdateOverrideLikeSrcEditDetailsTempObject.subSbClass;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productionGrpCd = UpdateOverrideLikeSrcEditDetailsTempObject.productionGrpCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productionCtgryCd = UpdateOverrideLikeSrcEditDetailsTempObject.productionCtgryCd;
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productionClsCd = UpdateOverrideLikeSrcEditDetailsTempObject.productionClsCd;
					if(UpdateOverrideLikeSrcEditDetailsTempObject.grpCd.toString().length == 1){
						UpdateOverrideLikeSrcEditDetailsTempObject.grpCd = '0'+UpdateOverrideLikeSrcEditDetailsTempObject.grpCd;
					}
					if(UpdateOverrideLikeSrcEditDetailsTempObject.ctgryCd.toString().length == 1){
						UpdateOverrideLikeSrcEditDetailsTempObject.ctgryCd = '0'+UpdateOverrideLikeSrcEditDetailsTempObject.ctgryCd;
					}
					$scope.UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd = UpdateOverrideLikeSrcEditDetailsTempObject.grpCd+''+UpdateOverrideLikeSrcEditDetailsTempObject.ctgryCd;
				}
				
				$scope.loadSMICDesc();
				
				document.getElementById("smic1").disabled = true; 
                document.getElementById("smic2").disabled = true; 
                document.getElementById("smic3").disabled = true; 
                document.getElementById("smic4").disabled = true; 
                document.getElementById("smic5").disabled = true; 
                document.getElementById("editimage").disabled = false; 
                document.getElementById("editimage").style.visibility = "visible";
			}
			else {
				$scope.UpdateOverrideLikeSrcEditDetails.newItemDto = UpdateOverrideLikeSrcEditDetailsTempObject;
				$scope.smicDesc = SmicTempObject;
				for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
					if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
						document.getElementById('manualMapChkBox').disabled = false;
					}
					else{
						document.getElementById('manualMapChkBox').disabled = true;
					}
				}
				document.getElementById("smic1").disabled = true; 
                document.getElementById("smic2").disabled = true; 
                document.getElementById("smic3").disabled = true; 
                document.getElementById("smic4").disabled = true; 
                document.getElementById("smic5").disabled = true; 
                document.getElementById("editimage").disabled = false; 
                document.getElementById("editimage").style.visibility = "visible";
			}
			$scope.loadUOMCode();
		};
		
		$scope.hideLikeItem = function (cic) {
			var nextItemSelected = false;
			document.getElementById("chkUnhide").checked=false;
			for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
				if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].dtaOverCic == cic){
					$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = false;
					if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
						var enableSelection = false;
						for(var j=0;j<$scope.likeItemsRecords.length;j++){
							if(enableSelection == false && $scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].dtaOverCic == $scope.likeItemsRecords[j].dtaOverCic){
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
								enableSelection = true;
							}
							if(enableSelection == true && j <= $scope.likeItemsRecords.length - 2 && !isHidden($scope.likeItemsRecords[j + 1].dtaOverCic)){
								nextItemSelected = true;
								for(var k=0;k<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;k++){
									if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[k].dtaOverCic == $scope.likeItemsRecords[j + 1].dtaOverCic){
										$scope.UpdateOverrideLikeSrcEditDetails.likeItems[k].mostRecommendedItem = true;
										$scope.selectedTableRow($scope.UpdateOverrideLikeSrcEditDetails.likeItems[k]);
										nextItemSelected = true;
										enableSelection = false;
									}
								}
							}
						}
					}
				}
			}
			if(nextItemSelected == false){
				for(var l=1;l<$scope.likeItemsRecords.length;l++){
					if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[l].dtaOverCic == cic){
						if(l == ($scope.likeItemsRecords.length-1)){
							nextItemSelected == false;
							break;
						}
						else {
							if(!isHidden($scope.likeItemsRecords[l+1].dtaOverCic)){
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[l+1].mostRecommendedItem = true;
								$scope.selectedTableRow($scope.UpdateOverrideLikeSrcEditDetails.likeItems[l+1]);
								nextItemSelected = true;
								break;
							}
						}
					}
				}
				
				if(nextItemSelected == false){
					$scope.UpdateOverrideLikeSrcEditDetails.likeItems[0].mostRecommendedItem = true;
					$scope.selectedTableRow($scope.UpdateOverrideLikeSrcEditDetails.likeItems[0]);
					nextItemSelected = true;
					document.getElementById("checkboxid").checked = true;
					document.getElementById('manualMapChkBox').disabled = true;
					document.getElementById("manualMapChkBox").checked = false;
				}
			}
		};
		
		function isHidden(cic){
			for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
				if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].dtaOverCic == cic && $scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show == false)
					return true;
			}
			return false;
		}
		
		$scope.unhideLikeItems = function () {
			for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
				$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
			}
		};
		
		$scope.setOrderProperty = function(propertyName, event) {
			var id = event.target.id;
			var value = event.target.attributes[4].value;
			if(value == ">"){
				event.target.attributes[4].value = "^";
				document.getElementById(id).src="img/down.png";
			}
			else {
				event.target.attributes[4].value = ">";
				document.getElementById(id).src="img/up.png";
			}
			
		    if ($scope.orderProperty === propertyName) {
		        $scope.orderProperty = '-' + propertyName;
		    } 
		    else if ($scope.orderProperty === '-' + propertyName) {
		        $scope.orderProperty = propertyName;
		    } 
		    else {
		        $scope.orderProperty = propertyName;
		    }
		};
		
		$scope.specialCharacterValidation = function (UpdateOverrideLikeSrcEditDetails){
			var pattern = new RegExp(/[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/);
			var updSizePattern = new RegExp(/[~`!#$%\^&*+=\\[\]\\';,/{}|\\":<>\?]/);
			if ( updSizePattern.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr) || pattern.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom)) {
					isCharacterValid = false;
				alertify.alert("Special characters not allowed.");
				return isCharacterValid;
			}
			else {
				isCharacterValid = true;
				return isCharacterValid;
			}
		};
		
		$scope.numberValidation = function (UpdateOverrideLikeSrcEditDetails){
			var number = new RegExp(/^[0-9]*(\.[0-9]{1,20})?$/);
			if(number.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr)){
				isNumberValid = true;
				return isNumberValid;
			}
			else {
				isNumberValid = false;
				alertify.alert("Invalid number in Num Size field");
				return isNumberValid;
			}
		};
		
		/**
		 * Goto Home Page
		 */
		$scope.HomePage = function (){
			service.mappingSourceSearch = null;
			service.mappingTargetSearch = null;
			service.bakerySourceSearch = null;
			$location.path('/');
		};

		/**
		 * Goto Mapping Page
		 */
		$scope.MappingPage = function() {
			if(OverrideMappingServiceKey == "bakery"){
				service.mappingSourceSearch = null;
				service.mappingTargetSearch = null;
			}else{
				service.bakerySourceSearch = null;
			}
			$location.path('/');
		};
		
		$scope.CheckkBoxValidation = function() {
			if(document.getElementById('ChkBox').checked){
				document.getElementById('saveKillItemBtn').style.display = "block";
				document.getElementById('mapChkBox').disabled = true;
				document.getElementById('manualMapChkBox').disabled = true;
				document.getElementById('saveAndNextBtn1').disabled = true;
				document.getElementById('saveBtn1').disabled = true;
			}
			else {
				document.getElementById('saveKillItemBtn').style.display = "none";
				document.getElementById('mapChkBox').disabled = false;
				document.getElementById('manualMapChkBox').disabled = false;
				document.getElementById('saveAndNextBtn1').disabled = false;
				document.getElementById('saveBtn1').disabled = false;
			}
		};
		
		$scope.popup = function(buttonValue){
			if(buttonValue=="Btn1"){
				$("#myModal").modal("show");
			}
			
			if(buttonValue=="Btn7"){
				$("#myModal7").modal("show");
			}
		};
		
		$scope.editSmic = function(){
			alertify.confirm("Do you really want to edit SMIC?", function (e) {
				if (e){
					document.getElementById("smic1").disabled = false;
					document.getElementById("smic2").disabled = false;
					document.getElementById("smic3").disabled = false;
					document.getElementById("smic4").disabled = false;
					document.getElementById("smic5").disabled = false;
					document.getElementById("editimage").disabled = true;
				}
				else {
				}
			});
		};
		
		$scope.disableSmicEdit = function(){
			document.getElementById("smic1").disabled = true;
			document.getElementById("smic2").disabled = true;
			document.getElementById("smic3").disabled = true;
			document.getElementById("smic4").disabled = true;
			document.getElementById("smic5").disabled = true;
			document.getElementById("editimage").disabled = false;
		};
		
		
		
		if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
			document.getElementById('prevProductSkuButton').style.visibility = 'hidden';
			document.getElementById('nextProductSkuButton').style.visibility = 'hidden';
			document.getElementById('backToPerishMappingBtn').style.visibility = 'visible';
			//document.getElementById('saveNextCol1').style.visibility = 'hidden';
			//document.getElementById('saveNextCol2').style.visibility = 'hidden';
			document.getElementById('saveNextCol3').style.visibility = 'hidden';
			$scope.upcList = [];
			
			var overRidePerishablesCompanyID = OverrideMappingService.getCompanyID();
			var overRidePerishablesDivisionID = OverrideMappingService.getDivisionID();
			var overRidePerishablesProductSku = OverrideMappingService.getProductSku();
			
			var UpdateOverrideLikeSrcEditDetailsUrl=$scope.baseUrl+"exsrc/loadOverrideData/"+overRidePerishablesCompanyID+"/"+overRidePerishablesDivisionID+"/"+overRidePerishablesProductSku;
			$http.get(UpdateOverrideLikeSrcEditDetailsUrl,config)
				.then(function (response) {
					//function handles success condition		    
						$scope.UpdateOverrideLikeSrcEditDetails = response.data;
						
						if($scope.UpdateOverrideLikeSrcEditDetails && $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto && $scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.upcVoList){
							angular.forEach($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.upcVoList, function(upcObject){
								if(upcObject && upcObject.upc){
									$scope.upcList.push(upcObject.upc); 
								}
							});
						}
						
						$scope.loadUOMCode();
						$scope.UpdateOverrideEditDetails = response.data.newItemDto;
						$scope.UpdateOverrideSrcDetails = response.data.likeItems[0];
						$scope.likeItemsRecords = response.data.likeItems;
						document.getElementById('alreadySavedItem').innerHTML="";
						document.getElementById('ChkBox').disabled = false;
						document.getElementById('ChkBox').checked = false;
						document.getElementById('mapChkBox').disabled = false;
						document.getElementById('mapChkBox').checked = false;
						document.getElementById('manualMapChkBox').disabled = false;
						document.getElementById('manualMapChkBox').checked = false;
						document.getElementById('saveAndNextBtn1').disabled = false;
						document.getElementById('saveBtn1').disabled = false;
						if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C"){
							if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedAsDead == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been marked as dead.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('ChkBox').checked = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.manualMapped == true){
								document.getElementById('alreadySavedItem').innerHTML="Item marked for old conversion process.";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('mapChkBox').checked = true;
								document.getElementById('manualMapChkBox').disabled = true;
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else if($scope.UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.markedForManualMapping == true){
								document.getElementById('alreadySavedItem').innerHTML="Item has been manually mapped";
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('mapChkBox').disabled = true;
						 		document.getElementById('manualMapChkBox').disabled = true; 
								document.getElementById('manualMapChkBox').checked = true; 
								document.getElementById('saveAndNextBtn1').disabled = true;
								document.getElementById('saveBtn1').disabled = true;
							}
							else{
								document.getElementById('alreadySavedItem').innerHTML="Item has already been worked.";
							}
							document.getElementById('checkboxid').checked = false;
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
								document.getElementById('manualMapChkBox').disabled = true;
							}
						}
						else{
							for(var i=0;i<$scope.UpdateOverrideLikeSrcEditDetails.likeItems.length;i++){
								if($scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem == true){
									$scope.selectedTableRow($scope.likeItemsRecords[i]);
								}
								$scope.UpdateOverrideLikeSrcEditDetails.likeItems[i].show = true;
							}
						}
						$scope.loadUsageTypeCombo();
						$scope.loadSMICDesc();
				}, function (response) {
					//function handles error condition
				});
			localStorage.clear();
		}
		
		/**
		 * U62615
		 * common method called after 'save' and 'save & next' actions in augmented for updating force new action when triggered from perishables 
		 */
		  $scope.triggerForceNewPerishables = function(){
			  if(OverrideMappingServiceKey == "perishables" || OverrideMappingServiceKey == "bakery"){
			  	
	    		var forceNewAction = "";
	    		if(OverrideMappingServiceKey == "perishables"){
	    			forceNewAction = $scope.baseUrl+"perishable/forcenew";
	    		}else if(OverrideMappingServiceKey == "bakery"){
	    			forceNewAction = $scope.baseUrl+"bakery/forcenew";
	    		}
	    		$scope.createMapRequestsForForceNew(OverrideMappingServiceKey);
	    		$http.post(forceNewAction,$scope.mappingRequests,config)
	    		.then(function(response){
	    			//function handles success condition
	    			if (response){

	    			}

	    		}, function(response1){
	    			//function handles error condition
	    		});
			  }
		  };
		 
			
		  
		    /**
			 * U62615
			 * common method for creating mapping requests depending on number of upc's
			 */
		  $scope.createMapRequestsForForceNew = function (from){
			  $scope.mappingRequests = [];
			  var updatedUserID = null;
			  updatedUserID = service.userId;
			  angular.forEach($scope.upcList, function(upc){
				  if (upc){
					  $scope.mappingrequest = {};
					  $scope.mappingrequest.companyID = OverrideMappingService.getCompanyID();
					  $scope.mappingrequest.divisionID  = OverrideMappingService.getDivisionID();
					  $scope.mappingrequest.sku = OverrideMappingService.getProductSku();
					  $scope.mappingrequest.upc = upc;
					  $scope.mappingrequest.mappingstatus =  "FORCE_NEW";
					  $scope.mappingrequest.updatedUserId =  updatedUserID;
					  if(from == "perishables"){
							$scope.mappingrequest.matchedItemTypeCd =  OverrideMappingService.getUsageType();
						}else{
							$scope.mappingrequest.targetTypeIndicator =  OverrideMappingService.getUsageType();
						}
					  $scope.mappingRequests.push($scope.mappingrequest);
				  }
			  });
		  };
			});
		});
		}
			
	}]);
	
})();