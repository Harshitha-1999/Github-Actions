(function() {
	'use strict';

	myApp.controller('AugmentedController', ['$scope', '$http', '$location', '$timeout', 'blockUI', 'service', 'AugmentedService', 'AugmentedDisplayerService',
		function AugmentedController($scope, $http, $location, $timeout, blockUI, service, AugmentedService, AugmentedDisplayerService) {

			var retrievedData = localStorage.getItem("sku");
			var AugmentedprdskuValue = JSON.parse(retrievedData);
			if (AugmentedprdskuValue != null) {
				AugmentedprdskuValue.sort(function(a, b) {
					return a - b;
				});
			}
			var AugmentedInitialValue = AugmentedService.getValue();
			var AugmentedCompanyID = AugmentedService.getCompanyID();
			var AugmentedDivisionID = AugmentedService.getDivisionID();
			var AugmentedProductSkuSourceUpcDropDownvalue = AugmentedService.getProductSkuSourceUpcDropDownvalue();
			var AugmentedDisplayerServiceKey = AugmentedDisplayerService.getKey();
			var isValid = true;
			var isCharacterValid = true;
			var isNumberValid = true;
			var isPrivateLabelValid = true;
			var isDescSizeValid = true;
			var isNumSizeValid = true;
			var isUomValid = true;
			var isUsageIndValid = true;
			var isUsageTypeValid = true;
			var isDisplayValid = true;
			var isItemDescValid = true;
			var isWhseDescValid = true;
			var isSsDescValid = true;
			var isInternetDescValid = true;
			var isPosDescValid = true;
			var isGroupCodeValid = true;
			var isCategoryCodeValid = true;
			var isClassCodeValid = true;
			var isSubClassCodeValid = true;
			var isSubSubClassCodeValid = true;
			var isProductionGroupCodeValid = true;
			var isProductionCategoryCodeValid = true;
			var isProductionClassCodeValid = true;
			var isEthnicTypeCodeValid = true;
			var isPackageTypeCodeValid = true;
			var isInnerPackValid = true;
			var isRetailUnitPackValid = true;
			var isRetailUnitPackZero = true;
			var isPluCodeValid = true;
			var isProductClassCodeValid = true;
			var isProductClassCodeChecked = true;
			var currentUsageInd = null;
			var count = 0;
			var deptNameOriginal = null;
			var type = null;
			var fromDisplayersNewCic = false;
			var isDescPackValid = true;
			var isDescDLSizeValid = true;
			var isDescRingValid = true;
			var isDescHiconValid = true;
			var isPackVCFValid = true;
			var productClassCode = null;

			document.getElementById('backToDisplayerBtn').style.visibility = 'hidden';

//			$scope.baseUrl = service.baseUrlFunction();
			
			if(service.baseUrlFunction() != undefined ) {
				service.baseUrlFunction().then(function(url){
					$scope.baseUrl =  url;
//				});
//			}
			service.getHeaders().then(function(header) {
				var config = header
//      });
          
          
			$scope.uomCode = service.uomCodes;
			$scope.departmentDetail = service.departmentDetails;
			$scope.isPrdclscodeValid = true;
			$scope.selectedUomCode = {};
			$scope.isForcenewProduce = false;
			$scope.tempPackWhse = "";
			
			var windowHeight = $(window).innerHeight();
			$('.cardAug').css('height', windowHeight - 75);
			//$('.cardEdit').css('height', windowHeight - 75);

			if ($scope.uomCode) {
				$scope.selectedUomCode = $scope.uomCode[0];
			}

			if ($scope.departmentDetail) {
				$scope.selectedDepartmentName = deptNameOriginal;
			}
			
			

			/**
			 * Initialise
			 */
			$scope.init = function() {
				document.getElementById('SizeDesc').focus();
			};

			/**
			 * Load Usagetype
			 */
			$scope.loadUsageTypeCombo = function() {
				if (!$scope.AugmentedSrcEditDetails)
					return;
				if (currentUsageInd != null && currentUsageInd == $scope.AugmentedSrcEditDetails.newItemDto.updUsgeInd)
					return;

				var second = document.getElementById('second-select-input');

				var val = $scope.AugmentedSrcEditDetails.newItemDto.updUsgeInd;
				currentUsageInd = val;
				empty(second);

				if (val == 'E') {
					addOption('L', second);
					addOption('O', second);
					addOption('W', second);
					if ($scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd !== 'L' &&
						$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd !== 'O' &&
						$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd !== 'W')
						$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd = 'L';
				}

				if (val == 'M') {
					addOption('M', second);
					$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd = 'M';
				}

				if (val == 'Q') {
					addOption(' ', second);
					$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd = ' ';
				}

				if (val == 'R') {
					addOption('C', second);
					addOption('R', second);
					addOption('S', second);
					if ($scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd !== 'C' &&
						$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd !== 'R' &&
						$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd !== 'S')
						$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd = 'C';
				}

				if (!val) {
					$scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd = ' ';
				}
			};

			function empty(select) {
				select.innerHTML = ' ';
			}

			function addOption(val, select) {
				var option = document.createElement('option');
				option.value = val;
				option.innerHTML = val;
				select.appendChild(option);
			}

			$scope.$on('$viewContentLoaded', function() {
				$scope.loadUsageTypeCombo();
			});

			/**
			 * Method to Load SMIC Details
			 */
		
			$scope.loadSMICDesc = function() {
				var uiEditObj = $scope.AugmentedSrcEditDetails.newItemDto;
				var groupCode = 0;
				var categoryCode = 0;
				var classCode = 0;
				var subClassCode = 0;
				var subSubClassCode = 0;
				if (uiEditObj.grpCd == null || uiEditObj.ctgryCd == null || uiEditObj.grpCd.length == 0 || uiEditObj.ctgryCd.length == 0) {
					$scope.smicDesc = null;
					return;
				} else {
					groupCode = uiEditObj.grpCd;
					categoryCode = uiEditObj.ctgryCd;
					if (uiEditObj.clsCd == null || uiEditObj.clsCd.length == 0)
						classCode = 0;
					else
						classCode = uiEditObj.clsCd;
					if (uiEditObj.sbClsCd == null || uiEditObj.sbClsCd.length == 0)
						subClassCode = 0;
					else
						subClassCode = uiEditObj.sbClsCd;
					if (uiEditObj.subSbClass == null || uiEditObj.subSbClass.length == 0)
						subSubClassCode = 0;
					else
						subSubClassCode = uiEditObj.subSbClass;
					var smicDetailsUrl = $scope.baseUrl + "smic/detail/" + groupCode + "/" + categoryCode + "/" + classCode + "/" + subClassCode + "/" + subSubClassCode;
					$http.get(smicDetailsUrl,config)
						.then(function(response) {
							if (response.data.length > 0) {
								$scope.smicDesc = response.data[0].smicdesc;
							} else {
								alertify.alert("Invalid SMIC Code.");
								$scope.smicDesc = null;
								return;
							}
						}, function(response) {
							//function handles error condition
						});
				}
			};

			/**
			 * Method to Load SMIC Group
			 */
			$scope.loadSMICGroupCode = function() {
				productClassCode = $scope.AugmentedSrcEditDetails.newItemDto.productClsCd;
				$scope.SmicGroupCodeDetails = null;
				var SMICGroupCodeDetails = $scope.baseUrl + "smic/smicdetail";
				$http.get(SMICGroupCodeDetails,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.SmicGroupCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.SmicGroupCodeDetails.length; i++) {
									if ($scope.SmicGroupCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.grpCd) {
										$scope.selectedGroupCode = response.data[i];
										$scope.loadSMICCategoryCode($scope.selectedGroupCode.code);
										break;
									}
								}
								if ($scope.selectedGroupCode == null || $scope.selectedGroupCode == undefined) {
									// $scope.selectedGroupCode = 0;
									$scope.loadSMICCategoryCode(0);
								}
								if ($scope.selectedGroupCode != '84') {
									document.getElementById('productClassCode').disabled = true;
								} else {
									document.getElementById('productClassCode').disabled = false;
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load SMIC Category
			 */
			$scope.loadSMICCategoryCode = function(groupCode) {
				if (groupCode == null) {
					groupCode = 0;
					$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = "";
					document.getElementById('productClassCode').disabled = true;
				}

				$scope.SmicCategoryCodeDetails = null;
				var SMICCategoryCodeDetails = $scope.baseUrl + "smic/smicdetail/" + groupCode;
				$http.get(SMICCategoryCodeDetails,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.SmicCategoryCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.SmicCategoryCodeDetails.length; i++) {
									if ($scope.SmicCategoryCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.ctgryCd) {
										$scope.selectedCategoryCode = response.data[i];
										$scope.loadSMICClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code);
										//$scope.setProductClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code);
										if($scope.selectedGroupCode.code != '84'){
										$scope.setProductClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code);
									    }else{
									    	if((productClassCode == null || productClassCode == '' || productClassCode.length == 0)&& ( $scope.AugmentedSrcEditDetails.newItemDto.productClsCd == '' || $scope.AugmentedSrcEditDetails.newItemDto.productClsCd == null || $scope.AugmentedSrcEditDetails.newItemDto.productClsCd.length == 0) ){
									    		$scope.setProductClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code);
		      							    	}else if((productClassCode != null || productClassCode != '' || productClassCode.length != 0) && ($scope.AugmentedSrcEditDetails.newItemDto.productClsCd == '' || $scope.AugmentedSrcEditDetails.newItemDto.productClsCd == null || $scope.AugmentedSrcEditDetails.newItemDto.productClsCd.length == 0) ){
		      							    		$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = productClassCode;
		      							    	}
									    	document.getElementById('productClassCode').disabled = false;
									    }
										break;
									}
								}
								if ($scope.selectedCategoryCode == null || $scope.selectedCategoryCode == undefined) {
									// $scope.selectedCategoryCode = 0;
									$scope.loadSMICClassCode(0, 0);
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};
			
			/**
			 * Method to Load SMIC Category on change
			 */
			$scope.loadSMICCategoryCodeOnChange = function(groupCode) {
				if (groupCode == null) {
					groupCode = 0;
					$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = "";
					document.getElementById('productClassCode').disabled = true;
				}

				$scope.SmicCategoryCodeDetails = null;
				var SMICCategoryCodeDetails = $scope.baseUrl + "smic/smicdetail/" + groupCode;
				$http.get(SMICCategoryCodeDetails,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.SmicCategoryCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.SmicCategoryCodeDetails.length; i++) {
									if ($scope.SmicCategoryCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.ctgryCd) {
										$scope.selectedCategoryCode = response.data[i];
										$scope.loadSMICClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code);
										$scope.setProductClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code);
										break;
									}
								}
								if ($scope.selectedCategoryCode == null || $scope.selectedCategoryCode == undefined) {
									// $scope.selectedCategoryCode = 0;
									$scope.loadSMICClassCode(0, 0);
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load SMIC Class
			 */
			$scope.loadSMICClassCode = function(groupCode, categoryCode) {
				if (groupCode == null) {
					groupCode = 0;
				}
				if (categoryCode == null) {
					categoryCode = 0;
				}

				$scope.SmicClassCodeDetails = null;
				var SMICClassCodeDetails = $scope.baseUrl + "smic/smicdetail/" + groupCode + "/" + categoryCode;
				$http.get(SMICClassCodeDetails,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.SmicClassCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.SmicClassCodeDetails.length; i++) {
									if ($scope.SmicClassCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.clsCd) {
										$scope.selectedClassCode = response.data[i];
										$scope.loadSMICSubClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code, $scope.selectedClassCode.code);
										break;
									}
								}
								if ($scope.selectedClassCode == null || $scope.selectedClassCode == undefined) {
									// $scope.selectedClassCode = 0;
									$scope.loadSMICSubClassCode(0, 0, 0);
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load SMIC Sub Class
			 */
			$scope.loadSMICSubClassCode = function(groupCode, categoryCode, classCode) {
				if (groupCode == null) {
					groupCode = 0;
				}
				if (categoryCode == null) {
					categoryCode = 0;
				}
				if (classCode == null) {
					classCode = 0;
				}

				$scope.SmicSubClassCodeDetails = null;
				var SMICSubClassCodeDetails = $scope.baseUrl + "smic/smicdetail/" + groupCode + "/" + categoryCode + "/" + classCode;
				$http.get(SMICSubClassCodeDetails,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.SmicSubClassCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.SmicSubClassCodeDetails.length; i++) {
									if ($scope.SmicSubClassCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.sbClsCd) {
										$scope.selectedSubClassCode = response.data[i];
										$scope.loadSMICSubSubClassCode($scope.selectedGroupCode.code, $scope.selectedCategoryCode.code, $scope.selectedClassCode.code, $scope.selectedSubClassCode.code);
										break;
									}
								}
								if ($scope.selectedSubClassCode == null || $scope.selectedSubClassCode == undefined) {
									// $scope.selectedSubClassCode = 0;
									$scope.loadSMICSubSubClassCode(0, 0, 0, 0);
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load SMIC SubSub Class
			 */
			$scope.loadSMICSubSubClassCode = function(groupCode, categoryCode, classCode, subClassCode) {
				if (groupCode == null) {
					groupCode = 0;
				}
				if (categoryCode == null) {
					categoryCode = 0;
				}
				if (classCode == null) {
					classCode = 0;
				}
				if (subClassCode == null) {
					subClassCode = 0;
				}

				$scope.SmicSubSubClassCodeDetails = null;
				var SMICSubSubClassCodeDetails = $scope.baseUrl + "smic/smicdetail/" + groupCode + "/" + categoryCode + "/" + classCode + "/" + subClassCode;
				$http.get(SMICSubSubClassCodeDetails,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.SmicSubSubClassCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.SmicSubSubClassCodeDetails.length; i++) {
									if ($scope.SmicSubSubClassCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.subSbClass) {
										$scope.selectedSubSubClassCode = response.data[i];
										break;
									}
								}
								if ($scope.selectedSubSubClassCode == null || $scope.selectedSubSubClassCode == undefined) {
									// $scope.selectedSubSubClassCode = 0;
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load ProductionGroupCode
			 */
			$scope.loadProductionGroupCode = function() {
				$scope.ProductionGroupCodeDetails = null;
				var ProductionGroupCodeDetailsUrl = $scope.baseUrl + "prdctnCd/prdctnCdDetail";
				$http.get(ProductionGroupCodeDetailsUrl,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.ProductionGroupCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.ProductionGroupCodeDetails.length; i++) {
									if ($scope.ProductionGroupCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.productionGrpCd) {
										$scope.selectedProductionGroupCode = response.data[i];
										$scope.loadProductionCategoryCode($scope.selectedProductionGroupCode.code);
										break;
									}
								}
								if ($scope.selectedProductionGroupCode == null || $scope.selectedProductionGroupCode == undefined) {
									// $scope.selectedProductionGroupCode = 0;
									$scope.loadProductionCategoryCode(0);
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load ProductionCategoryCode
			 */
			$scope.loadProductionCategoryCode = function(productionGroupCode) {
				if (productionGroupCode == null) {
					productionGroupCode = 0;
				}

				$scope.ProductionCategoryCodeDetails = null;
				var ProductionCategoryCodeDetailsUrl = $scope.baseUrl + "prdctnCd/prdctnCdDetail/" + productionGroupCode;
				$http.get(ProductionCategoryCodeDetailsUrl,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.ProductionCategoryCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.ProductionCategoryCodeDetails.length; i++) {
									if ($scope.ProductionCategoryCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.productionCtgryCd) {
										$scope.selectedProductionCategoryCode = response.data[i];
										$scope.loadProductionClassCode($scope.selectedProductionGroupCode.code, $scope.selectedProductionCategoryCode.code);
										break;
									}
								}
								if ($scope.selectedProductionCategoryCode == null || $scope.selectedProductionCategoryCode == undefined) {
									// $scope.selectedProductionCategoryCode = 0;
									// alert('no response',ProductionCategoryCodeDetailsUrl)
									$scope.loadProductionClassCode(0, 0);
								}
							}
						} else {
							
						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load ProductionClassCode
			 */
			$scope.loadProductionClassCode = function(productionGroupCode, productionCategoryCode) {
				if (productionGroupCode == null) {
					productionGroupCode = 0;
				}
				if (productionCategoryCode == null) {
					productionCategoryCode = 0;
				}

				$scope.ProductionClassCodeDetails = null;
				var ProductionClassCodeDetailsUrl = $scope.baseUrl + "prdctnCd/prdctnCdDetail/" + productionGroupCode + "/" + productionCategoryCode;
				$http.get(ProductionClassCodeDetailsUrl,config)
					.then(function(response) {
						if (response.data != null) {
							$scope.ProductionClassCodeDetails = response.data;
							if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
								for (var i = 0; i < $scope.ProductionClassCodeDetails.length; i++) {
									if ($scope.ProductionClassCodeDetails[i].code == $scope.AugmentedSrcEditDetails.newItemDto.productionClsCd) {
										$scope.selectedProductionClassCode = response.data[i];
										break;
									}
								}
								if ($scope.selectedProductionClassCode == null || $scope.selectedProductionClassCode == undefined) {
									// $scope.selectedProductionClassCode = 0;
								}
							}
						} else {

						}
					}, function(response) {
						//function handles error condition
					});
			};

			/**
			 * Method to Load UOM Code
			 */
			$scope.loadUOMCode = function() {
				if ($scope.uomCode == null || $scope.AugmentedSrcEditDetails == null)
					return;
				var validUOM = false;
				for (var i = 0; i < $scope.uomCode.length; i++) {
					if ($scope.AugmentedSrcEditDetails.newItemDto.updSizeUom == $scope.uomCode[i].uomCode ||
						$scope.AugmentedSrcEditDetails.newItemDto.updSizeUom == ($scope.uomCode[i].uomCodeUS.replace(/[\s]/g, ''))) {
						$scope.selectedUomCode = $scope.uomCode[i];
						validUOM = true;
						break;
					}
				}
				if (validUOM == false) {
					$scope.selectedUomCode = null;
					$scope.AugmentedSrcEditDetails.newItemDto.updSizeUom = null;
				}
			};

			/**
			 * Set value to fields
			 */
			$scope.setValueToFileds = function() {
				if ($scope.AugmentedSrcEditDetails) {
					if($scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc == null){
						$scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc = $scope.AugmentedSrcEditDetails.newItemDto.updSize;
					}
					if($scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc == null){
						$scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc = $scope.AugmentedSrcEditDetails.newItemDto.packwhse;
					}
					if ($scope.AugmentedSrcEditDetails.newItemDto.innerPack == null) {
						$scope.AugmentedSrcEditDetails.newItemDto.innerPack = 1;
					}

					if ($scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack == null || $scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack == 0) {
						$scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack = $scope.AugmentedSrcEditDetails.newItemDto.packwhse;
					}

					if ($scope.AugmentedSrcEditDetails.newItemDto.pluCd == null) {
						$scope.AugmentedSrcEditDetails.newItemDto.pluCd = 0;
					}
					var tempVal = $scope.AugmentedSrcEditDetails.newItemDto.packwhse;
					$scope.tempPackWhse = tempVal;
					$scope.AugmentedSrcEditDetails.newItemDto.updpackwhse = tempVal;
						
					if ($scope.AugmentedSrcEditDetails.newItemDto.productClsCd == null) {
						$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = 0;
						if ($scope.AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
							if ($scope.AugmentedSrcEditDetails.newItemDto.grpCd &&
								$scope.AugmentedSrcEditDetails.newItemDto.grpCd.toString().length == 1) {
								$scope.AugmentedSrcEditDetails.newItemDto.grpCd = '0' + $scope.AugmentedSrcEditDetails.newItemDto.grpCd;
							}
							if ($scope.AugmentedSrcEditDetails.newItemDto.ctgryCd &&
								$scope.AugmentedSrcEditDetails.newItemDto.ctgryCd.toString().length == 1) {
								$scope.AugmentedSrcEditDetails.newItemDto.ctgryCd = '0' + $scope.AugmentedSrcEditDetails.newItemDto.ctgryCd;
							}
							if ($scope.AugmentedSrcEditDetails.newItemDto.grpCd != null && $scope.AugmentedSrcEditDetails.newItemDto.ctgryCd != null) {
								$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = $scope.AugmentedSrcEditDetails.newItemDto.grpCd + '' + $scope.AugmentedSrcEditDetails.newItemDto.ctgryCd;
							}
						}
					}
				}
			};

			/**
			 * Method to set Product Class Code
			 */
			$scope.setProductClassCode = function(groupCode, CategoryCode) {
				$scope.isPrdclscodeValid = true;
				document.getElementById('productClassCode').style.removeProperty('border');
				if (groupCode != null) {
					if (groupCode.toString().length == 1) {
						groupCode = '0' + groupCode;
					}
					$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = groupCode;
					if (groupCode != '84') {
						document.getElementById('productClassCode').disabled = true;
					} else {
						document.getElementById('productClassCode').disabled = false;
					}
				}
				if (CategoryCode != null) {
					if (CategoryCode.toString().length == 1) {
						CategoryCode = '0' + CategoryCode;
					}
					$scope.AugmentedSrcEditDetails.newItemDto.productClsCd = groupCode + '' + CategoryCode;
				}
			};

			/**
			 * Function to check Usage IndType
			 */
			$scope.usageIndTypeCheck = function(AugmentedSrcEditDetails) {
				if (AugmentedSrcEditDetails.newItemDto.borrowedUsageDetails == true) {
					document.getElementById('select-input').disabled = true;
					document.getElementById('second-select-input').disabled = true;
				} else {
					document.getElementById('select-input').disabled = false;
					document.getElementById('second-select-input').disabled = false;
				}
			};

			/**
			 * Function to check SMIC
			 */
			$scope.smicCheck = function(AugmentedSrcEditDetails) {
				if (AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true && AugmentedDisplayerServiceKey != "displayer" && AugmentedDisplayerServiceKey != "perishables" && AugmentedDisplayerServiceKey != "bakery") {
					document.getElementById("groupCode").disabled = true;
					document.getElementById("categoryCode").disabled = true;
					document.getElementById("classCode").disabled = true;
					document.getElementById("subClassCode").disabled = true;
					document.getElementById("subSubClassCode").disabled = true;
					document.getElementById("productionGroupCode").disabled = true;
					document.getElementById("productionCategoryCode").disabled = true;
					document.getElementById("productionClassCode").disabled = true;
				} else {
					document.getElementById("groupCode").disabled = false;
					document.getElementById("categoryCode").disabled = false;
					document.getElementById("classCode").disabled = false;
					document.getElementById("subClassCode").disabled = false;
					document.getElementById("subSubClassCode").disabled = false;
					document.getElementById("productionGroupCode").disabled = false;
					document.getElementById("productionCategoryCode").disabled = false;
					document.getElementById("productionClassCode").disabled = false;
				}
			};

			/**
			 * Function to set UOM Code
			 */
			$scope.setUomCode = function() {
				$scope.AugmentedSrcEditDetails.newItemDto.updSizeUom = $scope.selectedUomCode.uomCode;
			};

			/**
			 * Method to Assign Another Group
			 */
			$scope.assignAnotherGroup = function() {
				count++;
				$scope.departmentDetail = service.departmentDetails;
				if (count % 2 == 0) {
					document.getElementById('departmentNameUpdate').style.display = "none";
					document.getElementById('ChangeText').innerText = "Assign to another group";
					document.getElementById('departmentName').disabled = true;
					document.getElementById('mapChkBox').disabled = false;
					document.getElementById('ChkBox').disabled = false;
					document.getElementById('checkbox').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('saveAndNextBtn').disabled = false;
					$scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4 = $scope.deptCodeOriginal;
					$scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 = $scope.deptNameOriginal;
					for (var i = 0; i < $scope.departmentDetail.length; i++) {
						if ($scope.deptNameOriginal == $scope.departmentDetail[i].departmentName) {
							$scope.selectedDepartmentName = $scope.departmentDetail[i];
							break;
						}
					}
				} else {
					document.getElementById('departmentNameUpdate').style.display = "block";
					document.getElementById('ChangeText').innerText = "Cancel";
					document.getElementById('departmentName').disabled = false;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('checkbox').disabled = true;
					document.getElementById('saveBtn').disabled = true;
					document.getElementById('saveAndNextBtn').disabled = true;
				}
			};

			/**
			 * Method to set Department Details
			 */
			$scope.setDepartmentDetails = function() {
				$scope.departmentDetail = service.departmentDetails;
				for (var i = 0; i < $scope.departmentDetail.length; i++) {
					if ($scope.selectedDepartmentName.departmentName == $scope.departmentDetail[i].departmentName) {
						$scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4 = $scope.departmentDetail[i].departmentCode;
						$scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 = $scope.departmentDetail[i].departmentName;
						break;
					}
				}
			};

			/**
			 * Method to save Department Details
			 */
			$scope.saveDepartmentDetails = function() {
				var AugmentedSrcDetailsString = JSON.stringify($scope.AugmentedSrcEditDetails.uiEceptionSrcDto);
				var AugmentedSrcDetailsSaveUrl = $scope.baseUrl + "exsrc/exception";
				

				$http.post(AugmentedSrcDetailsSaveUrl, AugmentedSrcDetailsString, config)
					.then(function(response) {
						//function handles success condition
						$scope.smicDesc = null;
						AugmentedInitialValue = AugmentedInitialValue + 1;
						if (AugmentedDisplayerServiceKey == "displayer") {
							AugmentedDisplayerService.setKey(null);
							AugmentedDisplayerServiceKey = null;
							fromDisplayersNewCic = false;
							$location.path('DisplayerItems');
						} else if (AugmentedprdskuValue && AugmentedInitialValue == AugmentedprdskuValue.length) {
							alertify.alert("No more items under this department.");
							$location.path('/');
						} else {
							var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
							$http.get(AugmentedSrcEditDetailsUrl,config)
								.then(function(response) {
									//function handles success condition
									$scope.AugmentedSrcEditDetails = response.data;

									$scope.setValueToFileds();

									for (var i = 0; i < $scope.departmentDetail.length; i++) {
										if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
											$scope.selectedDepartmentName = $scope.departmentDetail[i];
											break;
										}
									}
									$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
									$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

									$scope.loadUOMCode();
									$scope.loadUsageTypeCombo();
									$scope.loadSMICGroupCode();
									$scope.loadProductionGroupCode();

									if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
										document.getElementById('checkbox').checked = true;
									}
									document.getElementById('alreadySavedItem').innerHTML = "";
									document.getElementById('mapChkBox').disabled = false;
									document.getElementById('mapChkBox').checked = false;
									document.getElementById('ChkBox').disabled = false;
									document.getElementById('ChkBox').checked = false;
									document.getElementById('checkbox').disabled = false;
									document.getElementById('saveAndNextBtn').disabled = false;
									document.getElementById('saveBtn').disabled = false;
									document.getElementById('ChangeText').disabled = false;
									if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
										if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
											document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('ChkBox').checked = true;
											document.getElementById('saveAndNextBtn').disabled = true;
											document.getElementById('saveBtn').disabled = true;
											document.getElementById('ChangeText').disabled = true;
										} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
											document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
											document.getElementById('mapChkBox').disabled = true;
											document.getElementById('mapChkBox').checked = true;
											document.getElementById('ChkBox').disabled = true;
											document.getElementById('saveAndNextBtn').disabled = true;
											document.getElementById('saveBtn').disabled = true;
											document.getElementById('ChangeText').disabled = true;
										} else {
											document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
										}
									}

									$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
									$scope.smicCheck($scope.AugmentedSrcEditDetails);

									count = 0;
									document.getElementById('departmentName').disabled = true;
									document.getElementById('departmentNameUpdate').style.display = "none";
									document.getElementById('ChangeText').innerText = "Assign to another group";
								}, function(response) {
									//function handles error condition
								});
						}

					}, function(response) {
						//function handles error condition
					});
			};

			////////////////////////------------- VALIDATION STARTS -----------------

			$scope.groupCodeValidation = function() {
				if ($scope.SmicGroupCodeDetails == null || $scope.SmicGroupCodeDetails.length == 0) {
					isGroupCodeValid = true;
					document.getElementById('groupCode').style.removeProperty('border');
					return isGroupCodeValid;

				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedGroupCode == null || $scope.selectedGroupCode.length == 0)) {
						isGroupCodeValid = false;
						document.getElementById('groupCode').style.borderColor = "red";
						return isGroupCodeValid;
					} else {
						isGroupCodeValid = true;
						document.getElementById('groupCode').style.removeProperty('border');
						return isGroupCodeValid;
					}
				}
			};

			$scope.categoryCodeValidation = function() {
				if ($scope.SmicCategoryCodeDetails == null || $scope.SmicCategoryCodeDetails.length == 0) {
					isCategoryCodeValid = true;
					document.getElementById('categoryCode').style.removeProperty('border');
					return isCategoryCodeValid;
				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedCategoryCode == null || $scope.selectedCategoryCode.length == 0)) {
						isCategoryCodeValid = false;
						document.getElementById('categoryCode').style.borderColor = "red";
						return isCategoryCodeValid;
					} else {
						isCategoryCodeValid = true;
						document.getElementById('categoryCode').style.removeProperty('border');
						return isCategoryCodeValid;
					}
				}
			};

			$scope.classCodeValidation = function() {
				if ($scope.SmicClassCodeDetails == null || $scope.SmicClassCodeDetails.length == 0) {
					isClassCodeValid = true;
					document.getElementById('classCode').style.removeProperty('border');
					return isClassCodeValid;
				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedClassCode == null || $scope.selectedClassCode.length == 0)) {
						isClassCodeValid = false;
						document.getElementById('classCode').style.borderColor = "red";
						return isClassCodeValid;
					} else {
						isClassCodeValid = true;
						document.getElementById('classCode').style.removeProperty('border');
						return isClassCodeValid;
					}
				}
			};

			$scope.subClassCodeValidation = function() {
				if ($scope.SmicSubClassCodeDetails == null || $scope.SmicSubClassCodeDetails.length == 0) {
					isSubClassCodeValid = true;
					document.getElementById('subClassCode').style.removeProperty('border');
					return isSubClassCodeValid;
				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedSubClassCode == null || $scope.selectedSubClassCode.length == 0)) {
						isSubClassCodeValid = false;
						document.getElementById('subClassCode').style.borderColor = "red";
						return isSubClassCodeValid;
					} else {
						isSubClassCodeValid = true;
						document.getElementById('subClassCode').style.removeProperty('border');
						return isSubClassCodeValid;
					}

				}
			};

			$scope.subSubClassValidation = function() {
				if ($scope.SmicSubSubClassCodeDetails == null || $scope.SmicSubSubClassCodeDetails.length == 0) {
					isSubSubClassCodeValid = true;
					document.getElementById('subSubClassCode').style.removeProperty('border');
					return isSubSubClassCodeValid;
				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedSubSubClassCode == null || $scope.selectedSubSubClassCode.length == 0)) {
						isSubSubClassCodeValid = false;
						document.getElementById('subSubClassCode').style.borderColor = "red";
						return isSubSubClassCodeValid;
					} else {
						isSubSubClassCodeValid = true;
						document.getElementById('subSubClassCode').style.removeProperty('border');
						return isSubSubClassCodeValid;
					}
				}
			};

			$scope.PrivateLabelFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updPtLabelInd == null || $scope.AugmentedSrcEditDetails.newItemDto.updPtLabelInd.length == 0)) {
					isPrivateLabelValid = false;
					document.getElementById('privateLabel').style.borderColor = "red";
					return isPrivateLabelValid;
				} else {
					isPrivateLabelValid = true;
					document.getElementById('privateLabel').style.removeProperty('border');
					return isPrivateLabelValid;
				}
			};

			$scope.DescSizeFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updSize == null || $scope.AugmentedSrcEditDetails.newItemDto.updSize.length == 0)) {
					isDescSizeValid = false;
					document.getElementById('SizeDesc').style.borderColor = "red";
					return isDescSizeValid;
				} else {
					isDescSizeValid = true;
					document.getElementById('SizeDesc').style.removeProperty('border');
					return isDescSizeValid;
				}
			};

			$scope.NumSizeFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updSizeNmbr == null || $scope.AugmentedSrcEditDetails.newItemDto.updSizeNmbr.length == 0)) {
					isNumSizeValid = false;
					document.getElementById('numSize').style.borderColor = "red";
					return isNumSizeValid;
				} else {
					isNumSizeValid = true;
					document.getElementById('numSize').style.removeProperty('border');
					return isNumSizeValid;
				}
			};

			$scope.UomFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updSizeUom == null || $scope.AugmentedSrcEditDetails.newItemDto.updSizeUom.length == 0)) {
					isUomValid = false;
					document.getElementById('uom').style.borderColor = "red";
					return isUomValid;
				} else {
					isUomValid = true;
					document.getElementById('uom').style.removeProperty('border');
					return isUomValid;
				}
			};

			$scope.UsageIndFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updUsgeInd == null || $scope.AugmentedSrcEditDetails.newItemDto.updUsgeInd.length == 0)) {
					isUsageIndValid = false;
					document.getElementById('select-input').style.borderColor = "red";
					return isUsageIndValid;
				} else {
					isUsageIndValid = true;
					document.getElementById('select-input').style.removeProperty('border');
					return isUsageIndValid;
				}
			};

			$scope.UsageTypeFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd == null || $scope.AugmentedSrcEditDetails.newItemDto.updUsageTypInd.length == 0)) {
					isUsageTypeValid = false;
					document.getElementById('second-select-input').style.borderColor = "red";
					return isUsageTypeValid;
				} else {
					isUsageTypeValid = true;
					document.getElementById('second-select-input').style.removeProperty('border');
					return isUsageTypeValid;
				}
			};

			$scope.DisplayFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updDispFlag == null || $scope.AugmentedSrcEditDetails.newItemDto.updDispFlag.length == 0)) {
					isDisplayValid = false;
					document.getElementById('display').style.borderColor = "red";
					return isDisplayValid;
				} else {
					isDisplayValid = true;
					document.getElementById('display').style.removeProperty('border');
					return isDisplayValid;
				}
			};

			$scope.ItemDescFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updItmDesc == null || $scope.AugmentedSrcEditDetails.newItemDto.updItmDesc.length == 0)) {
					isItemDescValid = false;
					document.getElementById('itemDesc').style.borderColor = "red";
					return isItemDescValid;
				} else {
					isItemDescValid = true;
					document.getElementById('itemDesc').style.removeProperty('border');
					return isItemDescValid;
				}
			};

			$scope.WhseDescFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updWhseItmDesc == null || $scope.AugmentedSrcEditDetails.newItemDto.updWhseItmDesc.length == 0)) {
					isWhseDescValid = false;
					document.getElementById('whseDesc').style.borderColor = "red";
					return isWhseDescValid;
				} else {
					isWhseDescValid = true;
					document.getElementById('whseDesc').style.removeProperty('border');
					return isWhseDescValid;
				}
			};

			$scope.SsDescFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updRtlItmDesc == null || $scope.AugmentedSrcEditDetails.newItemDto.updRtlItmDesc.length == 0)) {
					isSsDescValid = false;
					document.getElementById('ssDesc').style.borderColor = "red";
					return isSsDescValid;
				} else {
					isSsDescValid = true;
					document.getElementById('ssDesc').style.removeProperty('border');
					return isSsDescValid;
				}
			};

			$scope.InternetDescFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updIntenetItemDesc == null || $scope.AugmentedSrcEditDetails.newItemDto.updIntenetItemDesc.length == 0)) {
					isInternetDescValid = false;
					document.getElementById('internetDesc').style.borderColor = "red";
					return isInternetDescValid;
				} else {
					isInternetDescValid = true;
					document.getElementById('internetDesc').style.removeProperty('border');
					return isInternetDescValid;
				}
			};

			$scope.PosDescFieldValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.updPosDesc == null || $scope.AugmentedSrcEditDetails.newItemDto.updPosDesc.length == 0)) {
					isPosDescValid = false;
					document.getElementById('posDesc').style.borderColor = "red";
					return isPosDescValid;
				} else {
					isPosDescValid = true;
					document.getElementById('posDesc').style.removeProperty('border');
					return isPosDescValid;
				}
			};

			$scope.EthnicTypeCodeValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.ethnicTypeCd == null || $scope.AugmentedSrcEditDetails.newItemDto.ethnicTypeCd.length == 0)) {
					isEthnicTypeCodeValid = false;
					document.getElementById('ethnicTypeCode').style.borderColor = "red";
					return isEthnicTypeCodeValid;
				} else {
					isEthnicTypeCodeValid = true;
					document.getElementById('ethnicTypeCode').style.removeProperty('border');
					return isEthnicTypeCodeValid;
				}
			};

			$scope.PackageTypeCodeValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.pckTypeCd == null || $scope.AugmentedSrcEditDetails.newItemDto.pckTypeCd.length == 0)) {
					isPackageTypeCodeValid = false;
					document.getElementById('packageTypeCode').style.borderColor = "red";
					return isPackageTypeCodeValid;
				} else {
					isPackageTypeCodeValid = true;
					document.getElementById('packageTypeCode').style.removeProperty('border');
					return isPackageTypeCodeValid;
				}
			};

			$scope.ProductionGroupCodeValidation = function() {
				if ($scope.ProductionGroupCodeDetails == null || $scope.ProductionGroupCodeDetails.length == 0) {
					isProductionGroupCodeValid = true;
					document.getElementById('productionGroupCode').style.removeProperty('border');
					return isProductionGroupCodeValid;

				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedProductionGroupCode == null || $scope.selectedProductionGroupCode.length == 0)) {
						isProductionGroupCodeValid = false;
						document.getElementById('productionGroupCode').style.borderColor = "red";
						return isProductionGroupCodeValid;
					} else {
						isProductionGroupCodeValid = true;
						document.getElementById('productionGroupCode').style.removeProperty('border');
						return isProductionGroupCodeValid;
					}
				}
			};

			$scope.ProductionCategoryCodeValidation = function() {
				if ($scope.ProductionCategoryCodeDetails == null || $scope.ProductionCategoryCodeDetails.length == 0) {
					isProductionCategoryCodeValid = true;
					document.getElementById('productionCategoryCode').style.removeProperty('border');
					return isProductionCategoryCodeValid;

				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedProductionCategoryCode == null || $scope.selectedProductionCategoryCode.length == 0)) {
						isProductionCategoryCodeValid = false;
						document.getElementById('productionCategoryCode').style.borderColor = "red";
						return isProductionCategoryCodeValid;
					} else {
						isProductionCategoryCodeValid = true;
						document.getElementById('productionCategoryCode').style.removeProperty('border');
						return isProductionCategoryCodeValid;
					}
				}
			};

			$scope.ProductionClassCodeValidation = function() {
				if ($scope.ProductionClassCodeDetails == null || $scope.ProductionClassCodeDetails.length == 0) {
					isProductionClassCodeValid = true;
					document.getElementById('productionClassCode').style.removeProperty('border');
					return isProductionClassCodeValid;

				} else {
					if ((!document.getElementById('checkbox').checked) && ($scope.selectedProductionClassCode == null || $scope.selectedProductionClassCode.length == 0)) {
						isProductionClassCodeValid = false;
						document.getElementById('productionClassCode').style.borderColor = "red";
						return isProductionClassCodeValid;
					} else {
						isProductionClassCodeValid = true;
						document.getElementById('productionClassCode').style.removeProperty('border');
						return isProductionClassCodeValid;
					}
				}
			};

			$scope.InnerPackValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.innerPack == null || $scope.AugmentedSrcEditDetails.newItemDto.innerPack.length == 0)) {
					isInnerPackValid = false;
					document.getElementById('innerPack').style.borderColor = "red";
					return isInnerPackValid;
				} else {
					isInnerPackValid = true;
					document.getElementById('innerPack').style.removeProperty('border');
					return isInnerPackValid;
				}
			};

			$scope.RetailUnitPackValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack == null || $scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack.length == 0)) {
					isRetailUnitPackValid = false;
					document.getElementById('retailUnitPack').style.borderColor = "red";
					return isRetailUnitPackValid;
				} else {
					isRetailUnitPackValid = true;
					document.getElementById('retailUnitPack').style.removeProperty('border');
					return isRetailUnitPackValid;
				}
			};

			$scope.RetailUnitPackIsZero = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack == null || $scope.AugmentedSrcEditDetails.newItemDto.retailUnitPack == 0)) {
					isRetailUnitPackZero = false;
					document.getElementById('retailUnitPack').style.borderColor = "red";
					return isRetailUnitPackZero;
				} else {
					isRetailUnitPackZero = true;
					document.getElementById('retailUnitPack').style.removeProperty('border');
					return isRetailUnitPackZero;
				}
			};

			$scope.PluCodeValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.pluCd == null || $scope.AugmentedSrcEditDetails.newItemDto.pluCd.length == 0)) {
					isPluCodeValid = false;
					document.getElementById('pluCode').style.borderColor = "red";
					return isPluCodeValid;
				} else {
					isPluCodeValid = true;
					document.getElementById('pluCode').style.removeProperty('border');
					return isPluCodeValid;
				}
			};

			$scope.ProductClassCodeValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.productClsCd == null || $scope.AugmentedSrcEditDetails.newItemDto.productClsCd.length == 0)) {
					isProductClassCodeValid = false;
					document.getElementById('productClassCode').style.borderColor = "red";
					return isProductClassCodeValid;
				} else {
					isProductClassCodeValid = true;
					document.getElementById('productClassCode').style.removeProperty('border');
					return isProductClassCodeValid;
				}
			};

			$scope.DescPackValidation = function() {
				if ($scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc == null) {
					$scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc = document.getElementById('descPack0').value;
				} else {
					$scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc = document.getElementById('descPack').value;
				}

				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc == null || $scope.AugmentedSrcEditDetails.newItemDto.dcPackDesc.length == 0)) {
					isDescPackValid = false;
					document.getElementById('descPack').style.borderColor = "red";
					document.getElementById('descPack0').style.borderColor = "red";
					return isDescPackValid;
				} else {
					isDescPackValid = true;
					document.getElementById('descPack').style.removeProperty('border');
					document.getElementById('descPack0').style.removeProperty('border');
					return isDescPackValid;
				}
			};

			$scope.DescSizeValidation = function() {
				if ($scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc == null) {
					$scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc = document.getElementById('descSize0').value;
				} else {
					$scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc = document.getElementById('descSize').value;
				}

				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc == null || $scope.AugmentedSrcEditDetails.newItemDto.dcSizeDsc.length == 0)) {
					isDescDLSizeValid = false;
					document.getElementById('descSize').style.borderColor = "red";
					document.getElementById('descSize0').style.borderColor = "red";
					return isDescDLSizeValid;
				} else {
					isDescDLSizeValid = true;
					document.getElementById('descSize').style.removeProperty('border');
					document.getElementById('descSize0').style.removeProperty('border');
					return isDescDLSizeValid;
				}
			};

			$scope.DescRingValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.ring == null || $scope.AugmentedSrcEditDetails.newItemDto.ring.length == 0)) {
					isDescRingValid = false;
					document.getElementById('augedit_ringID').style.borderColor = "red";
					return isDescRingValid;
				} else {
					isDescRingValid = true;
					document.getElementById('augedit_ringID').style.removeProperty('border');
					return isDescRingValid;
				}
			};

			$scope.DescHiconValidation = function() {
				if ((!document.getElementById('checkbox').checked) && ($scope.AugmentedSrcEditDetails.newItemDto.hicone == null || $scope.AugmentedSrcEditDetails.newItemDto.hicone.length == 0)) {
					isDescHiconValid = false;
					document.getElementById('augedit_hiconeID').style.borderColor = "red";
					return isDescHiconValid;
				} else {
					isDescHiconValid = true;
					document.getElementById('augedit_hiconeID').style.removeProperty('border');
					return isDescHiconValid;
				}
			};

			$scope.PackwhseValidation = function() {
				if ($scope.isForcenewProduce == true) {
					if ((document.getElementById('packwhseop').value != "") && $scope.AugmentedSrcEditDetails.newItemDto.packwhse == null || $scope.AugmentedSrcEditDetails.newItemDto.packwhse == 0) {
						isPackVCFValid = false;
						document.getElementById('packwhseop').style.borderColor = "red";
						return isPackVCFValid;
					} else {
						isPackVCFValid = true;
						document.getElementById('packwhseop').style.removeProperty('border');
					}

					if ((document.getElementById('vcfop').value != "") && $scope.AugmentedSrcEditDetails.newItemDto.vendConvFactor == null || $scope.AugmentedSrcEditDetails.newItemDto.vendConvFactor == 0) {
						isPackVCFValid = false;
						document.getElementById('vcfop').style.borderColor = "red";
						return isPackVCFValid;
					} else {
						isPackVCFValid = true;
						document.getElementById('vcfop').style.removeProperty('border');
						return isPackVCFValid;
					}
				}

			};

			//////////////////////// ------------- VALIDATION ENDS -----------------

			/**
			 * Change the shelf life count
			 */
			$scope.changeDaysCount = function() {
				var selldays = Number($scope.AugmentedSrcEditDetails.newItemDto.sellByDays);
				if (selldays) {
					$scope.AugmentedSrcEditDetails.newItemDto.useByDays = selldays + 1;
					$scope.AugmentedSrcEditDetails.newItemDto.pullBydays = selldays;
				}
			};

			/**
			 * Method to reset Validation Errors
			 */
			$scope.resetValidationErrors = function() {
				isValid = true;
				isCharacterValid = true;
				isNumberValid = true;
				isGroupCodeValid = true;
				isCategoryCodeValid = true;
				isClassCodeValid = true;
				isSubClassCodeValid = true;
				isSubSubClassCodeValid = true;
				isPrivateLabelValid = true;
				isDescSizeValid = true;
				isNumSizeValid = true;
				isUomValid = true;
				isUsageIndValid = true;
				isUsageTypeValid = true;
				isDisplayValid = true;
				isItemDescValid = true;
				isWhseDescValid = true;
				isSsDescValid = true;
				isInternetDescValid = true;
				isPosDescValid = true;
				isEthnicTypeCodeValid = true;
				isPackageTypeCodeValid = true;
				isProductionGroupCodeValid = true;
				isProductionCategoryCodeValid = true;
				isProductionClassCodeValid = true;
				isInnerPackValid = true;
				isRetailUnitPackValid = true;
				isPluCodeValid = true;
				isProductClassCodeValid = true;
				isDescPackValid = true;
				isDescDLSizeValid = true;
				isDescRingValid = true;
				isDescHiconValid = true;
				isPackVCFValid = true;

				document.getElementById('groupCode').style.removeProperty('border');
				document.getElementById('categoryCode').style.removeProperty('border');
				document.getElementById('classCode').style.removeProperty('border');
				document.getElementById('subClassCode').style.removeProperty('border');
				document.getElementById('subSubClassCode').style.removeProperty('border');
				document.getElementById('privateLabel').style.removeProperty('border');
				document.getElementById('SizeDesc').style.removeProperty('border');
				document.getElementById('numSize').style.removeProperty('border');
				document.getElementById('uom').style.removeProperty('border');
				document.getElementById('select-input').style.removeProperty('border');
				document.getElementById('second-select-input').style.removeProperty('border');
				document.getElementById('display').style.removeProperty('border');
				document.getElementById('itemDesc').style.removeProperty('border');
				document.getElementById('whseDesc').style.removeProperty('border');
				document.getElementById('ssDesc').style.removeProperty('border');
				document.getElementById('internetDesc').style.removeProperty('border');
				document.getElementById('posDesc').style.removeProperty('border');
				document.getElementById('ethnicTypeCode').style.removeProperty('border');
				document.getElementById('packageTypeCode').style.removeProperty('border');
				document.getElementById('productionGroupCode').style.removeProperty('border');
				document.getElementById('productionCategoryCode').style.removeProperty('border');
				document.getElementById('productionClassCode').style.removeProperty('border');
				document.getElementById('innerPack').style.removeProperty('border');
				document.getElementById('retailUnitPack').style.removeProperty('border');
				document.getElementById('pluCode').style.removeProperty('border');
				document.getElementById('productClassCode').style.removeProperty('border');
				document.getElementById('descPack').style.removeProperty('border');
				document.getElementById('descSize').style.removeProperty('border');
				document.getElementById('descPack0').style.removeProperty('border');
				document.getElementById('descSize0').style.removeProperty('border');
				document.getElementById('augedit_ringID').style.removeProperty('border');
				document.getElementById('augedit_hiconeID').style.removeProperty('border');
				document.getElementById('vcfop').style.removeProperty('border');
				document.getElementById('packwhseop').style.removeProperty('border');
			};

			/**
			 * Method to SAVE based on type
			 */
			$scope.AugmentedValidateSave = function(AugmentedSrcEditDetails, type) {

				if (!document.getElementById('checkbox').checked && AugmentedSrcEditDetails.newItemDto.borrowedSMIC == false) {
					$scope.isPrdclscodeValid = true;
					document.getElementById('productClassCode').style.removeProperty('border');

					var prdclscode = $scope.AugmentedSrcEditDetails.newItemDto.productClsCd.toString();
					if (prdclscode != "" && prdclscode != null && prdclscode.length != 0 &&
						prdclscode.length > 2 && $scope.selectedGroupCode != null) {
						var tempGrpCode = $scope.selectedGroupCode.code ? $scope.selectedGroupCode.code : "GC";
						var prdclscodeUrl = $scope.baseUrl + "newitem/targetProdValidate/" + prdclscode + "/" + tempGrpCode;
						$http.get(prdclscodeUrl,config)
							.then(function(response) {
								//function handles success condition
								if (response.data == true) {
									$scope.selectedGroupCode.code = prdclscode.substring(0, 2);
					  //  			$scope.selectedCategoryCode.code = prdclscode.substring(2, 4);
									isProductClassCodeChecked = true;
									if (type == 'save') {
										$scope.Augmented(AugmentedSrcEditDetails);
									} else {
										$scope.AugmentedSaveNext();
									}
								} else {
									isProductClassCodeChecked = false;
									$scope.isPrdclscodeValid = false;
									document.getElementById('productClassCode').style.borderColor = "red";
									return;
								}

							}, function(response) {
								//function handles error condition
								document.getElementById('productClassCode').style.borderColor = "red";
								alertify.alert("Invalid Product Class Code.");
								return;
							});
					} else {
						document.getElementById('productClassCode').style.borderColor = "red";
						alertify.alert("Select group code & category code to generate product class code");
						return;
					}
				} else {
					if (type == 'save') {
						$scope.Augmented(AugmentedSrcEditDetails);
					} else {
						$scope.AugmentedSaveNext();
					}
				}
			};

			/**
			 * Method to save 
			 */
			$scope.Augmented = function(AugmentedSrcEditDetails) {
				if (!document.getElementById('checkbox').checked) {
					$scope.groupCodeValidation();
					$scope.categoryCodeValidation();
					if (!fromDisplayersNewCic) {
						$scope.classCodeValidation();
						$scope.subClassCodeValidation();
						$scope.subSubClassValidation();
					}
					$scope.PrivateLabelFieldValidation();
					$scope.DescSizeFieldValidation();
					$scope.NumSizeFieldValidation();
					$scope.UomFieldValidation();
					$scope.UsageIndFieldValidation();
					$scope.UsageTypeFieldValidation();
					$scope.DisplayFieldValidation();
					$scope.ItemDescFieldValidation();
					$scope.WhseDescFieldValidation();
					$scope.SsDescFieldValidation();
					$scope.InternetDescFieldValidation();
					$scope.PosDescFieldValidation();
					//$scope.ProductionGroupCodeValidation();
					//$scope.ProductionCategoryCodeValidation();
					//$scope.ProductionClassCodeValidation();
					//$scope.EthnicTypeCodeValidation();
					//$scope.PackageTypeCodeValidation();
					$scope.InnerPackValidation();
					$scope.RetailUnitPackValidation();
					$scope.RetailUnitPackIsZero();
					$scope.PluCodeValidation();
					$scope.ProductClassCodeValidation();
					$scope.DescPackValidation();
					$scope.DescSizeValidation();
					$scope.DescRingValidation();
					$scope.DescHiconValidation();
					$scope.PackwhseValidation();

					$scope.specialCharacterValidation(AugmentedSrcEditDetails);
					$scope.numberValidation(AugmentedSrcEditDetails);

					if (isRetailUnitPackZero == false) {
						isValid = false;
						alertify.alert("Retail Unit Pack cannot be Zero or Empty.");
						return;
					}

					if (isGroupCodeValid == false || isCategoryCodeValid == false || isClassCodeValid == false ||
						isSubClassCodeValid == false || isSubSubClassCodeValid == false ||
						isProductionGroupCodeValid == false || isProductionCategoryCodeValid == false ||
						isProductionClassCodeValid == false || isPrivateLabelValid == false ||
						isDescSizeValid == false || isNumSizeValid == false || isUomValid == false ||
						isUsageIndValid == false || isUsageTypeValid == false || isDisplayValid == false ||
						isItemDescValid == false || isWhseDescValid == false || isSsDescValid == false ||
						isInternetDescValid == false || isPosDescValid == false || isEthnicTypeCodeValid == false ||
						isPackageTypeCodeValid == false || isInnerPackValid == false || isRetailUnitPackValid == false ||
						isPluCodeValid == false || isProductClassCodeValid == false || isProductClassCodeChecked == false ||
						isDescPackValid == false || isDescDLSizeValid == false || isDescRingValid == false ||
						isDescHiconValid == false || isPackVCFValid == false) {
						isValid = false;
						alertify.alert("Highlighted fields are Mandatory.");
						return;
					} else {
						isValid = true;
					}
				} else {
					isValid = true;
					isCharacterValid = true;
					isNumberValid = true;
				}

				//			Additional edit UPC/PLU added
				$scope.editUpdUpc00 = [];
				$scope.editUpdUpc01 = [];
				$scope.editUpdUpc = [];
				var isUPC = false;

				if ($scope.AugmentedSrcEditDetails.newItemDto.updPlu) {
					for (var i = 0; i < $scope.AugmentedSrcEditDetails.newItemDto.updPlu.length; i++) {
						var upcObject00 = {};
						if (document.getElementById('pluUpcVal00_' + i).value != "") {
							upcObject00.sourceUpc = ($scope.AugmentedSrcEditDetails.newItemDto.updPlu[i].sourceUpc).replace(/\-/g, "");
							upcObject00.editedUpc = document.getElementById('pluUpcVal00_' + i).value;
							document.getElementById('pluUpcVal00_' + i).style.removeProperty('border');
						} else {
							document.getElementById('pluUpcVal00_' + i).style.borderColor = "red";
							isValid = false;
							return;
						}
						$scope.editUpdUpc00.push(upcObject00);
					}
					AugmentedSrcEditDetails.newItemDto.updPlu = $scope.editUpdUpc00;
				}
				if ($scope.AugmentedSrcEditDetails.newItemDto.updUpc) {
					for (var i = 0; i < $scope.AugmentedSrcEditDetails.newItemDto.updUpc.length; i++) {
						var upcObject01 = {};
						if (document.getElementById('pluUpcVal01_' + i).value != "") {
							upcObject01.sourceUpc = ($scope.AugmentedSrcEditDetails.newItemDto.updUpc[i].sourceUpc).replace(/\-/g, "");
							upcObject01.editedUpc = document.getElementById('pluUpcVal01_' + i).value;
							document.getElementById('pluUpcVal01_' + i).style.removeProperty('border');
						} else {
							document.getElementById('pluUpcVal01_' + i).style.borderColor = "red";
							isValid = false;
							return;
						}
						$scope.editUpdUpc01.push(upcObject01);
					}
					AugmentedSrcEditDetails.newItemDto.updUpc = $scope.editUpdUpc01;
				}

				if ($scope.AugmentedSrcEditDetails.newItemDto.updUpc == null && $scope.AugmentedSrcEditDetails.newItemDto.updPlu == null) {
					for (var i = 0; i < $scope.AugmentedSrcEditDetails.newItemDto.upcVoList.length; i++) {
						var upcObject = {};
						if (document.getElementById('pluUpcVal_' + i).value != "") {
							upcObject.sourceUpc = ($scope.AugmentedSrcEditDetails.newItemDto.upcVoList[i].upc).replace(/\-/g, "");
							upcObject.editedUpc = document.getElementById('pluUpcVal_' + i).value;
							document.getElementById('pluUpcVal_' + i).style.removeProperty('border');
							if (upcObject.sourceUpc > 99999) {
								isUPC = true;
							}
						} else {
							document.getElementById('pluUpcVal_' + i).style.borderColor = "red";
							isValid = false;
							return;
						}
						$scope.editUpdUpc.push(upcObject);
					}
					if (isUPC == true) {
						AugmentedSrcEditDetails.newItemDto.updUpc = $scope.editUpdUpc;
					} else {
						AugmentedSrcEditDetails.newItemDto.updPlu = $scope.editUpdUpc;
					}
				}

				//			Additional edit UPC/PLU added - END


				if (isValid == true && isCharacterValid == true && isNumberValid == true) {
					if (document.getElementById('checkbox').checked) {
						AugmentedSrcEditDetails.newItemDto.augOverCmplnInd = 'N';
						document.getElementById('checkbox').checked = false;
					} else {
						AugmentedSrcEditDetails.newItemDto.augOverCmplnInd = 'Y';
					}

					AugmentedSrcEditDetails.newItemDto.createId = service.userId;
					AugmentedSrcEditDetails.uiEceptionSrcDto.updatedUserID = service.userId;

					if ($scope.selectedGroupCode != null) {
						AugmentedSrcEditDetails.newItemDto.grpCd = $scope.selectedGroupCode.code;
						if ($scope.selectedGroupCode == 0) {
							AugmentedSrcEditDetails.newItemDto.grpCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.grpCd = 0;
					}
					if ($scope.selectedCategoryCode != null) {
						AugmentedSrcEditDetails.newItemDto.ctgryCd = $scope.selectedCategoryCode.code;
						if ($scope.selectedCategoryCode == 0) {
							AugmentedSrcEditDetails.newItemDto.ctgryCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.ctgryCd = 0;
					}
					if ($scope.selectedClassCode != null) {
						AugmentedSrcEditDetails.newItemDto.clsCd = $scope.selectedClassCode.code;
						if ($scope.selectedClassCode == 0) {
							AugmentedSrcEditDetails.newItemDto.clsCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.clsCd = 0;
					}
					if ($scope.selectedSubClassCode != null) {
						AugmentedSrcEditDetails.newItemDto.sbClsCd = $scope.selectedSubClassCode.code;
						if ($scope.selectedSubClassCode == 0) {
							AugmentedSrcEditDetails.newItemDto.sbClsCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.sbClsCd = 0;
					}

					if ($scope.selectedSubSubClassCode != null) {
						AugmentedSrcEditDetails.newItemDto.subSbClass = $scope.selectedSubSubClassCode.code;
						if ($scope.selectedSubSubClassCode == 0) {
							AugmentedSrcEditDetails.newItemDto.subSbClass = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.subSbClass = 0;
					}
					if ($scope.selectedProductionGroupCode != null) {
						AugmentedSrcEditDetails.newItemDto.productionGrpCd = $scope.selectedProductionGroupCode.code;
						if ($scope.selectedProductionGroupCode == 0) {
							AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
					}
					if ($scope.selectedProductionCategoryCode != null) {
						AugmentedSrcEditDetails.newItemDto.productionCtgryCd = $scope.selectedProductionCategoryCode.code;
						if ($scope.selectedProductionCategoryCode == 0) {
							AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
					}
					if ($scope.selectedProductionClassCode != null) {
						AugmentedSrcEditDetails.newItemDto.productionClsCd = $scope.selectedProductionClassCode.code;
						if ($scope.selectedProductionClassCode == 0) {
							AugmentedSrcEditDetails.newItemDto.productionClsCd = 0;
						}
					} else {
						AugmentedSrcEditDetails.newItemDto.productionClsCd = 0;
					}

					var AugmentedSrcEditDetailsString = JSON.stringify(AugmentedSrcEditDetails);
					var AugmentedSrcEditDetailsSaveUrl = $scope.baseUrl + "newitem/save";
					

					$http.post(AugmentedSrcEditDetailsSaveUrl, AugmentedSrcEditDetailsString, config)
						.then(function(response) {
							//function handles success condition
							var saveStatus = response.data.status;
							if (saveStatus == 1) {
								if (AugmentedDisplayerServiceKey == "displayer") {
									AugmentedDisplayerService.setKey(null);
									AugmentedDisplayerServiceKey = null;
									fromDisplayersNewCic = false;
									$location.path('DisplayerItems');
								} else if (AugmentedDisplayerServiceKey == "perishables" || AugmentedDisplayerServiceKey == "bakery") {
									$scope.triggerForceNewPerishables();
									AugmentedDisplayerService.setKey(null);
									AugmentedDisplayerServiceKey = null;
									$location.path('/');
								} else {
									alertify.success("Saved successfully!");
								}
							}
							if (saveStatus == 2) {
								var savedObject = response.data;
								var alertMsg = "<h4>Please correct the following errors and try again.</h4>";
								for (var i = 0; i < savedObject.errorMessages.length; i++) {
									alertMsg += "<div style='color:RED;BORDER: 1px solid #edf0f1;padding:3px;";
									if (i % 2 == 0) {
										alertMsg += "background-color:#f9fafa;" + "'>";
									} else {
										alertMsg += "background-color:#ffffff;" + "'>";
									}
									alertMsg += savedObject.errorMessages[i];
									alertMsg += "</div>";
								}
								alertify.alert(alertMsg);
								return;
							}
							if (saveStatus == 0) {
								$scope.triggerForceNewPerishables();
							}
						}, function(response) {
							//function handles error condition
						});
				}
			};

			/**
			 * Method to save next
			 */
			$scope.AugmentedSaveNext = function() {
				if (!document.getElementById('checkbox').checked) {
					$scope.groupCodeValidation();
					$scope.categoryCodeValidation();
					if (!fromDisplayersNewCic) {
						$scope.classCodeValidation();
						$scope.subClassCodeValidation();
						$scope.subSubClassValidation();
					}
					$scope.PrivateLabelFieldValidation();
					$scope.DescSizeFieldValidation();
					$scope.NumSizeFieldValidation();
					$scope.UomFieldValidation();
					$scope.UsageIndFieldValidation();
					$scope.UsageTypeFieldValidation();
					$scope.DisplayFieldValidation();
					$scope.ItemDescFieldValidation();
					$scope.WhseDescFieldValidation();
					$scope.SsDescFieldValidation();
					$scope.InternetDescFieldValidation();
					$scope.PosDescFieldValidation();
					//$scope.ProductionGroupCodeValidation();
					//$scope.ProductionCategoryCodeValidation();
					//$scope.ProductionClassCodeValidation();
					//$scope.EthnicTypeCodeValidation();
					//$scope.PackageTypeCodeValidation();
					$scope.InnerPackValidation();
					$scope.RetailUnitPackValidation();
					$scope.RetailUnitPackIsZero();
					$scope.PluCodeValidation();
					$scope.ProductClassCodeValidation();
					$scope.DescPackValidation();
					$scope.DescSizeValidation();
					$scope.DescRingValidation();
					$scope.DescHiconValidation();
					$scope.PackwhseValidation();

					$scope.specialCharacterValidation($scope.AugmentedSrcEditDetails);
					$scope.numberValidation($scope.AugmentedSrcEditDetails);

					if (isRetailUnitPackZero == false) {
						isValid = false;
						alertify.alert("Retail Unit Pack cannot be Zero or Empty.");
						return;
					}

					if (isGroupCodeValid == false || isCategoryCodeValid == false || isClassCodeValid == false ||
						isSubClassCodeValid == false || isSubSubClassCodeValid == false || isProductionGroupCodeValid == false ||
						isProductionCategoryCodeValid == false || isProductionClassCodeValid == false ||
						isPrivateLabelValid == false || isDescSizeValid == false || isNumSizeValid == false ||
						isUomValid == false || isUsageIndValid == false || isUsageTypeValid == false ||
						isDisplayValid == false || isItemDescValid == false || isWhseDescValid == false ||
						isSsDescValid == false || isInternetDescValid == false || isPosDescValid == false ||
						isEthnicTypeCodeValid == false || isPackageTypeCodeValid == false || isInnerPackValid == false ||
						isRetailUnitPackValid == false || isPluCodeValid == false || isProductClassCodeValid == false ||
						isProductClassCodeChecked == false || isDescPackValid == false || isDescDLSizeValid == false ||
						isDescRingValid == false || isDescHiconValid == false || isPackVCFValid == false) {
						isValid = false;
						alertify.alert("Highlighted fields are Mandatory.");
						return;
					} else {
						isValid = true;
					}
				} else {
					isValid = true;
					isCharacterValid = true;
					isNumberValid = true;
				}

				//			Additional edit UPC/PLU added
				$scope.editUpdUpc00 = [];
				$scope.editUpdUpc01 = [];
				$scope.editUpdUpc = [];
				var upcObject00 = {};
				var upcObject01 = {};
				var upcObject = {};
				var isUPC = false;

				if ($scope.AugmentedSrcEditDetails.newItemDto.updPlu) {
					for (var i = 0; i < $scope.AugmentedSrcEditDetails.newItemDto.updPlu.length; i++) {
						if (document.getElementById('pluUpcVal00_' + i).value != "") {
							upcObject00.sourceUpc = ($scope.AugmentedSrcEditDetails.newItemDto.updPlu[i].sourceUpc).replace(/\-/g, "");
							upcObject00.editedUpc = document.getElementById('pluUpcVal00_' + i).value;
							document.getElementById('pluUpcVal00_' + i).style.removeProperty('border');
						} else {
							document.getElementById('pluUpcVal00_' + i).style.borderColor = "red";
							isValid = false;
							return;
						}
						$scope.editUpdUpc00.push(upcObject00);
					}
					$scope.AugmentedSrcEditDetails.newItemDto.updPlu = $scope.editUpdUpc00;
				}
				if ($scope.AugmentedSrcEditDetails.newItemDto.updUpc) {
					for (var i = 0; i < $scope.AugmentedSrcEditDetails.newItemDto.updUpc.length; i++) {
						if (document.getElementById('pluUpcVal01_' + i).value != "") {
							upcObject01.sourceUpc = ($scope.AugmentedSrcEditDetails.newItemDto.updUpc[i].sourceUpc).replace(/\-/g, "");
							upcObject01.editedUpc = document.getElementById('pluUpcVal01_' + i).value;
							document.getElementById('pluUpcVal01_' + i).style.removeProperty('border');
						} else {
							document.getElementById('pluUpcVal01_' + i).style.borderColor = "red";
							isValid = false;
							return;
						}
						$scope.editUpdUpc01.push(upcObject01);
					}
					$scope.AugmentedSrcEditDetails.newItemDto.updUpc = $scope.editUpdUpc01;
				}

				if ($scope.AugmentedSrcEditDetails.newItemDto.updUpc == null && $scope.AugmentedSrcEditDetails.newItemDto.updPlu == null) {
					for (var i = 0; i < $scope.AugmentedSrcEditDetails.newItemDto.upcVoList.length; i++) {
						if (document.getElementById('pluUpcVal_' + i).value != "") {
							upcObject.sourceUpc = ($scope.AugmentedSrcEditDetails.newItemDto.upcVoList[i].upc).replace(/\-/g, "");
							upcObject.editedUpc = document.getElementById('pluUpcVal_' + i).value;
							document.getElementById('pluUpcVal_' + i).style.removeProperty('border');
							if (upcObject.sourceUpc > 99999) {
								isUPC = true;
							}
						} else {
							document.getElementById('pluUpcVal_' + i).style.borderColor = "red";
							isValid = false;
							return;
						}
						$scope.editUpdUpc.push(upcObject);
					}
					if (isUPC == true) {
						$scope.AugmentedSrcEditDetails.newItemDto.updUpc = $scope.editUpdUpc;
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.updPlu = $scope.editUpdUpc;
					}
				}
				//			Additional edit UPC/PLU added - END

				if (isValid == true && isCharacterValid == true && isNumberValid == true) {
					if (document.getElementById('checkbox').checked) {
						$scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd = 'N';
						document.getElementById('checkbox').checked = false;
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd = 'Y';
					}

					$scope.AugmentedSrcEditDetails.newItemDto.createId = service.userId;
					$scope.AugmentedSrcEditDetails.uiEceptionSrcDto.updatedUserID = service.userId;

					if ($scope.selectedGroupCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.grpCd = $scope.selectedGroupCode.code;
						if ($scope.selectedGroupCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.grpCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.grpCd = 0;
					}
					if ($scope.selectedCategoryCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.ctgryCd = $scope.selectedCategoryCode.code;
						if ($scope.selectedCategoryCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.ctgryCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.ctgryCd = 0;
					}
					if ($scope.selectedClassCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.clsCd = $scope.selectedClassCode.code;
						if ($scope.selectedClassCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.clsCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.clsCd = 0;
					}
					if ($scope.selectedSubClassCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.sbClsCd = $scope.selectedSubClassCode.code;
						if ($scope.selectedSubClassCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.sbClsCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.sbClsCd = 0;
					}
					if ($scope.selectedSubSubClassCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.subSbClass = $scope.selectedSubSubClassCode.code;
						if ($scope.selectedSubSubClassCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.subSbClass = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.subSbClass = 0;
					}
					if ($scope.selectedProductionGroupCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.productionGrpCd = $scope.selectedProductionGroupCode.code;
						if ($scope.selectedProductionGroupCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
					}
					if ($scope.selectedProductionCategoryCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.productionCtgryCd = $scope.selectedProductionCategoryCode.code;
						if ($scope.selectedProductionCategoryCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
					}
					if ($scope.selectedProductionClassCode != null) {
						$scope.AugmentedSrcEditDetails.newItemDto.productionClsCd = $scope.selectedProductionClassCode.code;
						if ($scope.selectedProductionClassCode == 0) {
							$scope.AugmentedSrcEditDetails.newItemDto.productionClsCd = 0;
						}
					} else {
						$scope.AugmentedSrcEditDetails.newItemDto.productionClsCd = 0;
					}

					var AugmentedSrcEditDetailsString = JSON.stringify($scope.AugmentedSrcEditDetails);
					var AugmentedSrcEditDetailsSaveUrl = $scope.baseUrl + "newitem/save";
					
					$http.post(AugmentedSrcEditDetailsSaveUrl, AugmentedSrcEditDetailsString, config)
						.then(function(response) {
							//function handles success condition
							var saveStatus = response.data.status;
							if (saveStatus == 1) {
								$scope.triggerForceNewPerishables();
								$scope.smicDesc = null;
								AugmentedInitialValue = AugmentedInitialValue + 1;
								if (AugmentedDisplayerServiceKey == "displayer") {
									AugmentedDisplayerService.setKey(null);
									AugmentedDisplayerServiceKey = null;
									fromDisplayersNewCic = false;
									$location.path('DisplayerItems');
								} else if (AugmentedDisplayerServiceKey == "perishables" || AugmentedDisplayerServiceKey == "bakery") {
									AugmentedDisplayerService.setKey(null);
									AugmentedDisplayerServiceKey = null;
									$location.path('/');
								} else if (AugmentedprdskuValue && AugmentedInitialValue == AugmentedprdskuValue.length) {
									alertify.alert("No more items under this department.");
									$location.path('/');
								} else {
									var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
									$http.get(AugmentedSrcEditDetailsUrl,config)
										.then(function(response) {
											//function handles success condition
											$scope.AugmentedSrcEditDetails = response.data;

											$scope.setValueToFileds();

											for (var i = 0; i < $scope.departmentDetail.length; i++) {
												if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
													$scope.selectedDepartmentName = $scope.departmentDetail[i];
													break;
												}
											}
											$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
											$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

											$scope.loadUOMCode();
											$scope.loadUsageTypeCombo();
											$scope.loadSMICGroupCode();
											$scope.loadProductionGroupCode();

											if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
												document.getElementById('checkbox').checked = true;
											}

											document.getElementById('alreadySavedItem').innerHTML = "";
											document.getElementById('mapChkBox').disabled = false;
											document.getElementById('mapChkBox').checked = false;
											document.getElementById('ChkBox').disabled = false;
											document.getElementById('ChkBox').checked = false;
											document.getElementById('saveAndNextBtn').disabled = false;
											document.getElementById('saveBtn').disabled = false;
											document.getElementById('ChangeText').disabled = false;
											if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
												if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
													document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
													document.getElementById('mapChkBox').disabled = true;
													document.getElementById('ChkBox').disabled = true;
													document.getElementById('ChkBox').checked = true;
													document.getElementById('saveAndNextBtn').disabled = true;
													document.getElementById('saveBtn').disabled = true;
													document.getElementById('ChangeText').disabled = true;
												} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
													document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
													document.getElementById('mapChkBox').disabled = true;
													document.getElementById('mapChkBox').checked = true;
													document.getElementById('ChkBox').disabled = true;
													document.getElementById('saveAndNextBtn').disabled = true;
													document.getElementById('saveBtn').disabled = true;
													document.getElementById('ChangeText').disabled = true;
												} else {
													document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
												}
											}

											$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
											$scope.smicCheck($scope.AugmentedSrcEditDetails);
										}, function(response) {
											//function handles error condition
										});
								}
							}
							if (saveStatus == 2) {
								var savedObject = response.data;
								var alertMsg = "<h4>Please correct the following errors and try again.</h4>";
								for (var i = 0; i < savedObject.errorMessages.length; i++) {
									alertMsg += "<div style='color:RED;BORDER: 1px solid #edf0f1;padding:3px;";
									if (i % 2 == 0) {
										alertMsg += "background-color:#f9fafa;" + "'>";
									} else {
										alertMsg += "background-color:#ffffff;" + "'>";
									}
									alertMsg += savedObject.errorMessages[i];
									alertMsg += "</div>";
								}
								alertify.alert(alertMsg);
								return;
							}
							if (saveStatus == 0) {
								$scope.triggerForceNewPerishables();
							}
						}, function(response) {
							//function handles error condition
						});
				}
			};

			/**
			 * U62615
			 * common method called after 'save' and 'save & next' actions in augmented for updating force new action when triggered from perishables 
			 */
			$scope.triggerForceNewPerishables = function() {
				if (AugmentedDisplayerServiceKey == "perishables" || AugmentedDisplayerServiceKey == "bakery") {
					
					var forceNewAction = "";
					if (AugmentedDisplayerServiceKey == "perishables") {
						forceNewAction = $scope.baseUrl + "perishable/forcenew";
					} else if (AugmentedDisplayerServiceKey == "bakery") {
						forceNewAction = $scope.baseUrl + "bakery/forcenew";
					}
					$scope.createMapRequestsForForceNew(AugmentedDisplayerServiceKey);
					$http.post(forceNewAction, $scope.mappingRequests, config)
						.then(function(response) {
							//function handles success condition
							if (response) {

							}

						}, function(response1) {
							//function handles error condition
						});
				}
			};


			/**
			 * U62615
			 * common method for creating mapping requests depending on number of upc's
			 */
			$scope.createMapRequestsForForceNew = function(from) {
				$scope.mappingRequests = [];
				var updatedUserID = null;
				updatedUserID = service.userId;
				angular.forEach($scope.upcList, function(upc) {
					if (upc) {
						$scope.mappingrequest = {};
						$scope.mappingrequest.companyID = AugmentedDisplayerService.getCompanyID();
						$scope.mappingrequest.divisionID = AugmentedDisplayerService.getDivisionID();
						$scope.mappingrequest.sku = AugmentedDisplayerService.getProductSku();
						$scope.mappingrequest.upc = upc;
						$scope.mappingrequest.mappingstatus = "FORCE_NEW";
						$scope.mappingrequest.mappingType = "FORCE_NEW";
						$scope.mappingrequest.updatedUserId = updatedUserID;
						if (from == "perishables") {
							$scope.mappingrequest.matchedItemTypeCd = AugmentedDisplayerService.getUsageType();
						} else {
							$scope.mappingrequest.targetTypeIndicator = AugmentedDisplayerService.getUsageType();
						}
						$scope.mappingRequests.push($scope.mappingrequest);
					}
				});
			};

			/**
			 * Function to skip to next SKU
			 */
			$scope.skipToNextProductSku = function() {
				AugmentedInitialValue = AugmentedInitialValue + 1;
				document.getElementById('ChkBox').checked = false;
				document.getElementById('mapChkBox').checked = false;
				$scope.manualMapItemChkBox();
				$scope.CheckkBoxValidation();
				if (AugmentedprdskuValue && AugmentedInitialValue == AugmentedprdskuValue.length) {
					alertify.alert("This is the last item under this department.");
					AugmentedInitialValue = AugmentedInitialValue - 1;
					if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
						document.getElementById('mapChkBox').disabled = true;
						document.getElementById('mapChkBox').checked = false;
						document.getElementById('ChkBox').disabled = true;
						document.getElementById('ChkBox').checked = true;
						document.getElementById('saveAndNextBtn').disabled = true;
						document.getElementById('saveBtn').disabled = true;
					} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
						document.getElementById('mapChkBox').disabled = true;
						document.getElementById('mapChkBox').checked = true;
						document.getElementById('ChkBox').disabled = true;
						document.getElementById('ChkBox').checked = false;
						document.getElementById('saveAndNextBtn').disabled = true;
						document.getElementById('saveBtn').disabled = true;
					}
					count = 0;
					document.getElementById('departmentName').disabled = true;
					document.getElementById('departmentNameUpdate').style.display = "none";
					document.getElementById('ChangeText').innerText = "Assign to another group";
				} else {
					count = 0;
					document.getElementById('alreadySavedItem').innerHTML = "";
					document.getElementById('mapChkBox').disabled = false;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('ChkBox').disabled = false;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('saveAndNextBtn').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('ChangeText').disabled = false;
					document.getElementById('departmentName').disabled = true;
					document.getElementById('departmentNameUpdate').style.display = "none";
					document.getElementById('ChangeText').innerText = "Assign to another group";
					$scope.resetValidationErrors();
					var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
					$http.get(AugmentedSrcEditDetailsUrl,config)
						.then(function(response) {
							//function handles success condition
							$scope.AugmentedSrcEditDetails = response.data;

							$scope.setValueToFileds();

							for (var i = 0; i < $scope.departmentDetail.length; i++) {
								if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
									$scope.selectedDepartmentName = $scope.departmentDetail[i];
									break;
								}
							}
							$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
							$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

							$scope.loadUOMCode();
							$scope.loadUsageTypeCombo();
							$scope.loadSMICGroupCode();
							$scope.loadProductionGroupCode();

							if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
								document.getElementById('checkbox').checked = true;
							}

							if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
								if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
									document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('ChkBox').checked = true;
									document.getElementById('saveAndNextBtn').disabled = true;
									document.getElementById('saveBtn').disabled = true;
									document.getElementById('ChangeText').disabled = true;
								} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
									document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('mapChkBox').checked = true;
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('saveAndNextBtn').disabled = true;
									document.getElementById('saveBtn').disabled = true;
									document.getElementById('ChangeText').disabled = true;
								} else {
									document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
								}
							}

							$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
							$scope.smicCheck($scope.AugmentedSrcEditDetails);

						}, function(response) {
							//function handles error condition
						});
				}
			};

			/**
			 * Function to skip to previous SKU
			 */
			$scope.skipToPrevProductSku = function() {
				AugmentedInitialValue = AugmentedInitialValue - 1;
				document.getElementById('ChkBox').checked = false;
				document.getElementById('mapChkBox').checked = false;
				$scope.manualMapItemChkBox();
				$scope.CheckkBoxValidation();
				if (AugmentedInitialValue < 0) {
					alertify.alert("This is the first item under this department.");
					AugmentedInitialValue = 0;
					if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
						document.getElementById('mapChkBox').disabled = true;
						document.getElementById('mapChkBox').checked = false;
						document.getElementById('ChkBox').disabled = true;
						document.getElementById('ChkBox').checked = true;
						document.getElementById('saveAndNextBtn').disabled = true;
						document.getElementById('saveBtn').disabled = true;
					} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
						document.getElementById('mapChkBox').disabled = true;
						document.getElementById('mapChkBox').checked = true;
						document.getElementById('ChkBox').disabled = true;
						document.getElementById('ChkBox').checked = false;
						document.getElementById('saveAndNextBtn').disabled = true;
						document.getElementById('saveBtn').disabled = true;
					}
					count = 0;
					document.getElementById('departmentName').disabled = true;
					document.getElementById('departmentNameUpdate').style.display = "none";
					document.getElementById('ChangeText').innerText = "Assign to another group";
				} else {
					count = 0;
					document.getElementById('alreadySavedItem').innerHTML = "";
					document.getElementById('mapChkBox').disabled = false;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('ChkBox').disabled = false;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('saveAndNextBtn').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('ChangeText').disabled = false;
					document.getElementById('departmentName').disabled = true;
					document.getElementById('departmentNameUpdate').style.display = "none";
					document.getElementById('ChangeText').innerText = "Assign to another group";
					$scope.resetValidationErrors();
					var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
					$http.get(AugmentedSrcEditDetailsUrl,config)
						.then(function(response) {
							//function handles success condition
							$scope.AugmentedSrcEditDetails = response.data;

							$scope.setValueToFileds();

							for (var i = 0; i < $scope.departmentDetail.length; i++) {
								if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
									$scope.selectedDepartmentName = $scope.departmentDetail[i];
									break;
								}
							}
							$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
							$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

							$scope.loadUOMCode();
							$scope.loadUsageTypeCombo();
							$scope.loadSMICGroupCode();
							$scope.loadProductionGroupCode();

							if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
								document.getElementById('checkbox').checked = true;
							}

							if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
								if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
									document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('ChkBox').checked = true;
									document.getElementById('saveAndNextBtn').disabled = true;
									document.getElementById('saveBtn').disabled = true;
									document.getElementById('ChangeText').disabled = true;
								} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
									document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
									document.getElementById('mapChkBox').disabled = true;
									document.getElementById('mapChkBox').checked = true;
									document.getElementById('ChkBox').disabled = true;
									document.getElementById('saveAndNextBtn').disabled = true;
									document.getElementById('saveBtn').disabled = true;
									document.getElementById('ChangeText').disabled = true;
								} else {
									document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
								}
							}

							$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
							$scope.smicCheck($scope.AugmentedSrcEditDetails);

						}, function(response) {
							//function handles error condition
						});
				}
			};

			/**
			 * Function to kill the SKU
			 */
			$scope.AugmentedKillThisProductSku = function(AugmentedSrcEditDetails) {
				alertify.prompt("Please enter a reason for marking this item as dead.", function(e, str) {
					if (e) {
						AugmentedSrcEditDetails.markAsDeadReason = str;
						if (AugmentedSrcEditDetails.markAsDeadReason == null || AugmentedSrcEditDetails.markAsDeadReason.length == 0) {
							$scope.AugmentedKillThisProductSku(AugmentedSrcEditDetails);
						} else if (AugmentedSrcEditDetails.markAsDeadReason != null || AugmentedSrcEditDetails.markAsDeadReason.length != 0) {
							var whiteSpace = new RegExp(/^\s+$/);
							if (whiteSpace.test(str)) {
								$scope.AugmentedKillThisProductSku(AugmentedSrcEditDetails);
							} else {
								$scope.AugmentedSrcEditDetails.killProdSku = true;
								AugmentedSrcEditDetails.newItemDto.createId = service.userId;
								AugmentedSrcEditDetails.uiEceptionSrcDto.updatedUserID = service.userId;
								var AugmentedSrcEditDetailsString = JSON.stringify(AugmentedSrcEditDetails);
								var AugmentedSrcEditDetailsSaveUrl = $scope.baseUrl + "newitem/save";
								

								$http.post(AugmentedSrcEditDetailsSaveUrl, AugmentedSrcEditDetailsString, config)
									.then(function(response) {
										//function handles success condition
										var saveStatus = response.data.status;
										if (saveStatus == 1) {
											AugmentedInitialValue = AugmentedInitialValue + 1;
											if (AugmentedDisplayerServiceKey == "displayer") {
												AugmentedDisplayerService.setKey(null);
												AugmentedDisplayerServiceKey = null;
												fromDisplayersNewCic = false;
												$location.path('DisplayerItems');
											} else if (AugmentedprdskuValue && AugmentedInitialValue == AugmentedprdskuValue.length) {
												alertify.alert("No more items under this department.");
												$location.path('/');
											} else {
												var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
												$http.get(AugmentedSrcEditDetailsUrl,config)
													.then(function(response) {
														//function handles success condition
														$scope.AugmentedSrcEditDetails = response.data;

														$scope.setValueToFileds();

														for (var i = 0; i < $scope.departmentDetail.length; i++) {
															if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
																$scope.selectedDepartmentName = $scope.departmentDetail[i];
																break;
															}
														}
														$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
														$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

														$scope.loadUOMCode();
														$scope.loadUsageTypeCombo();
														$scope.loadSMICGroupCode();
														$scope.loadProductionGroupCode();

														if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
															document.getElementById('checkbox').checked = true;
														}

														document.getElementById('alreadySavedItem').innerHTML = "";
														document.getElementById('ChkBox').disabled = false;
														document.getElementById('ChkBox').checked = false;
														document.getElementById('mapChkBox').disabled = false;
														document.getElementById('mapChkBox').checked = false;
														document.getElementById('saveAndNextBtn').disabled = false;
														document.getElementById('saveBtn').disabled = false;
														document.getElementById('ChangeText').disabled = false;
														if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
															if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
																document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
																document.getElementById('mapChkBox').disabled = true;
																document.getElementById('ChkBox').disabled = true;
																document.getElementById('ChkBox').checked = true;
																document.getElementById('saveAndNextBtn').disabled = true;
																document.getElementById('saveBtn').disabled = true;
																document.getElementById('ChangeText').disabled = true;
															} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
																document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
																document.getElementById('mapChkBox').disabled = true;
																document.getElementById('mapChkBox').checked = true;
																document.getElementById('ChkBox').disabled = true;
																document.getElementById('saveAndNextBtn').disabled = true;
																document.getElementById('saveBtn').disabled = true;
																document.getElementById('ChangeText').disabled = true;
															} else {
																document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
															}
														}

														$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
														$scope.smicCheck($scope.AugmentedSrcEditDetails);
													}, function(response) {
														//function handles error condition
													});
											}
										}
									}, function(response) {
										//function handles error condition
									});
								document.getElementById('ChkBox').checked = false;
								$scope.CheckkBoxValidation();
								$scope.AugmentedSrcEditDetails.killProdSku = false;
							}

						}
					} else {
						document.getElementById('ChkBox').checked = false;
						$scope.CheckkBoxValidation();
					}
				});
			};

			/**
			 * Function to kill the checkbox
			 */
			$scope.killItemChkBox = function(productSrcCd, productSKU) {
				if (document.getElementById('ChkBox').checked) {
					var pattern = new RegExp(/^W/);
					if (pattern.test(productSrcCd)) {
						var ProductSrcCdUrl = $scope.baseUrl + "/exsrc/onhandStatus/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + productSKU;
						$http.get(ProductSrcCdUrl,config)
							.then(function(response) {
								if (response.data == true) {
									alertify.confirm("This Warehouse Item is on hand as per the system. Do you want to proceed with marking it as dead?", function(e) {
										if (e) {
											$scope.CheckkBoxValidation();
										} else {
											document.getElementById('ChkBox').checked = false;
										}
									});
								} else {
									$scope.CheckkBoxValidation();
								}
							});
					} else {
						$scope.CheckkBoxValidation();
					}
				} else {
					document.getElementById('saveKillItemBtn').style.display = "none";
					document.getElementById('saveAndNextBtn').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('mapChkBox').disabled = false;
					document.getElementById('checkbox').disabled = false;
				}
			};

			/**
			 * Function to manual map item
			 */
			$scope.AugmentedManualMapItem = function(AugmentedSrcEditDetails) {
				alertify.confirm("Do you really want to move this item out of automated process?", function(e) {
					if (e) {
						AugmentedSrcEditDetails.manualMap = true;
						AugmentedSrcEditDetails.newItemDto.createId = service.userId;
						AugmentedSrcEditDetails.uiEceptionSrcDto.updatedUserID = service.userId;
						var AugmentedSrcEditDetailsString = JSON.stringify(AugmentedSrcEditDetails);
						var AugmentedSrcEditDetailsSaveUrl = $scope.baseUrl + "newitem/save";
						

						$http.post(AugmentedSrcEditDetailsSaveUrl, AugmentedSrcEditDetailsString, config)
							.then(function(response) {
								//function handles success condition
								var saveStatus = response.data.status;
								if (saveStatus == 1) {
									AugmentedInitialValue = AugmentedInitialValue + 1;
									if (AugmentedDisplayerServiceKey == "displayer") {
										AugmentedDisplayerService.setKey(null);
										AugmentedDisplayerServiceKey = null;
										fromDisplayersNewCic = false;
										$location.path('DisplayerItems');
									} else if (AugmentedprdskuValue && AugmentedInitialValue == AugmentedprdskuValue.length) {
										alertify.alert("No more items under this department.");
										$location.path('/');
									} else {
										var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
										$http.get(AugmentedSrcEditDetailsUrl,config)
											.then(function(response) {
												//function handles success condition
												$scope.AugmentedSrcEditDetails = response.data;

												$scope.setValueToFileds();

												for (var i = 0; i < $scope.departmentDetail.length; i++) {
													if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
														$scope.selectedDepartmentName = $scope.departmentDetail[i];
														break;
													}
												}
												$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
												$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

												$scope.loadUOMCode();
												$scope.loadUsageTypeCombo();
												$scope.loadSMICGroupCode();
												$scope.loadProductionGroupCode();

												if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
													document.getElementById('checkbox').checked = true;
												}

												document.getElementById('alreadySavedItem').innerHTML = "";
												document.getElementById('mapChkBox').disabled = false;
												document.getElementById('mapChkBox').checked = false;
												document.getElementById('ChkBox').disabled = false;
												document.getElementById('ChkBox').checked = false;
												document.getElementById('saveAndNextBtn').disabled = false;
												document.getElementById('saveBtn').disabled = false;
												document.getElementById('ChangeText').disabled = false;
												if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
													if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
														document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
														document.getElementById('mapChkBox').disabled = true;
														document.getElementById('ChkBox').disabled = true;
														document.getElementById('ChkBox').checked = true;
														document.getElementById('saveAndNextBtn').disabled = true;
														document.getElementById('saveBtn').disabled = true;
														document.getElementById('ChangeText').disabled = true;
													} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
														document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
														document.getElementById('mapChkBox').disabled = true;
														document.getElementById('mapChkBox').checked = true;
														document.getElementById('ChkBox').disabled = true;
														document.getElementById('saveAndNextBtn').disabled = true;
														document.getElementById('saveBtn').disabled = true;
														document.getElementById('ChangeText').disabled = true;
													} else {
														document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
													}
												}

												$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
												$scope.smicCheck($scope.AugmentedSrcEditDetails);
											}, function(response) {
												//function handles error condition
											});
									}
								}
							}, function(response) {
								//function handles error condition
							});

						document.getElementById('mapChkBox').checked = false;
						$scope.manualMapItemChkBox();
						$scope.AugmentedSrcEditDetails.manualMap = false;
					} else {
						document.getElementById('mapChkBox').checked = false;
						$scope.manualMapItemChkBox();
					}
				});
			};

			/**
			 * Function to manual map item checkbox
			 */
			$scope.manualMapItemChkBox = function() {
				if (document.getElementById('mapChkBox').checked) {
					document.getElementById('manualMapItem').style.display = "block";
					document.getElementById('saveAndNextBtn').disabled = true;
					document.getElementById('saveBtn').disabled = true;
					document.getElementById('ChkBox').disabled = true;
					document.getElementById('checkbox').disabled = true;
				} else {
					document.getElementById('manualMapItem').style.display = "none";
					document.getElementById('saveAndNextBtn').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('ChkBox').disabled = false;
					document.getElementById('checkbox').disabled = false;
				}
			};

			/**
			 * Function to validate the characters
			 */
			$scope.specialCharacterValidation = function(AugmentedSrcEditDetails) {
				var pattern = new RegExp(/[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/);
				var updSizePattern = new RegExp(/[~`!#$%\^&*+=\\[\]\\';,/{}|\\":<>\?]/);
				if (updSizePattern.test(AugmentedSrcEditDetails.newItemDto.cscDsc) || pattern.test(AugmentedSrcEditDetails.newItemDto.updSizeNmbr)) {
					isCharacterValid = false;
					alertify.alert("Special characters not allowed.");
					return isCharacterValid;
				} else {
					isCharacterValid = true;
					return isCharacterValid;
				}
			};

			/**
			 * Function to validate the numbers
			 */
			$scope.numberValidation = function(AugmentedSrcEditDetails) {
				var number = new RegExp(/^[0-9]*(\.[0-9]{1,20})?$/);
				if (number.test(AugmentedSrcEditDetails.newItemDto.updSizeNmbr)) {
					isNumberValid = true;
					return isNumberValid;
				} else {
					isNumberValid = false;
					alertify.alert("Invalid number in Num Size field");
					return isNumberValid;
				}
			};

			/**
			 * Goto Home Page
			 */
			$scope.HomePage = function() {
				AugmentedProductSkuSourceUpcDropDownvalue = null;
				service.mappingSourceSearch = null;
				service.mappingTargetSearch = null;
				service.bakerySourceSearch = null;
				$location.path('/');
			};

			/**
			 * Goto Mapping Page
			 */
			$scope.MappingPage = function() {
				if(AugmentedDisplayerServiceKey == "bakery"){
					service.mappingSourceSearch = null;
					service.mappingTargetSearch = null;
				}else{
					service.bakerySourceSearch = null;
				}
				$location.path('/');
			};

			/**
			 * Function to validate the checkbox
			 */
			$scope.CheckkBoxValidation = function() {
				if (document.getElementById('ChkBox').checked) {
					document.getElementById('saveKillItemBtn').style.display = "block";
					document.getElementById('saveAndNextBtn').disabled = true;
					document.getElementById('saveBtn').disabled = true;
					document.getElementById('mapChkBox').disabled = true;
					document.getElementById('checkbox').disabled = true;
				} else {
					document.getElementById('saveKillItemBtn').style.display = "none";
					document.getElementById('saveAndNextBtn').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('mapChkBox').disabled = false;
					document.getElementById('checkbox').disabled = false;
				}
			};

			$scope.popup = function(buttonValue) {
				if (buttonValue == "Btn1") {
					$("#myModal").modal("show");
				}

				if (buttonValue == "Btn2") {
					$("#myModal2").modal("show");
				}
			};

			/**
			 * Function to redirect to displayers
			 */
			$scope.backToDisplayer = function() {
				var formDataBackToDisplayer = [];
				formDataBackToDisplayer.push({
					"companyId": AugmentedDisplayerService.getCompanyID(),
					"divisionId": AugmentedDisplayerService.getDivisionID(),
					"productSku": AugmentedDisplayerService.getProductSku()
				});

				var formDataBackToDisplayerObject = JSON.parse(JSON.stringify(formDataBackToDisplayer[0]));

			

				var backToDisplayerUrl = $scope.baseUrl + "dsply/undoCreateNewCic";

				$http.post(backToDisplayerUrl, formDataBackToDisplayerObject, config)
					.then(function(response) {
						//function handles success condition
						fromDisplayersNewCic = false;
						service.mappingSourceSearch = null;
						service.mappingTargetSearch = null;
						service.bakerySourceSearch = null;
						$location.path('DisplayerItems');
					}, function(response) {
						//function handles error condition
					});
			};
			
			
			/**
			 * GENERAL CONDITIONS
			 */
			if (retrievedData != null) {
				AugmentedDisplayerService.setKey(null);
				AugmentedDisplayerServiceKey = null;
				AugmentedProductSkuSourceUpcDropDownvalue = null;
				$scope.AugmentedSrcEditDetails = null;
				if (AugmentedprdskuValue.length == 1) {
					document.getElementById('prevProductSkuButton').style.visibility = 'hidden';
					document.getElementById('nextProductSkuButton').style.visibility = 'hidden';
				}
				document.getElementById('backToDisplayerBtn').style.visibility = 'hidden';
				document.getElementById('backToMappingBtn').style.visibility = 'hidden';

				var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedCompanyID + "/" + AugmentedDivisionID + "/" + AugmentedprdskuValue[AugmentedInitialValue];
				$http.get(AugmentedSrcEditDetailsUrl,config)
					.then(function(response) {
						//function handles success condition
						$scope.AugmentedSrcEditDetails = response.data;

						$scope.setValueToFileds();

						for (var i = 0; i < $scope.departmentDetail.length; i++) {
							if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
								$scope.selectedDepartmentName = $scope.departmentDetail[i];
								break;
							}
						}
						$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
						$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

						$scope.loadUOMCode();
						$scope.loadUsageTypeCombo();
						$scope.loadSMICGroupCode();
						$scope.loadProductionGroupCode();

						if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
							document.getElementById('checkbox').checked = true;
						}

						document.getElementById('alreadySavedItem').innerHTML = "";
						document.getElementById('mapChkBox').disabled = false;
						document.getElementById('mapChkBox').checked = false;
						document.getElementById('ChkBox').disabled = false;
						document.getElementById('ChkBox').checked = false;
						document.getElementById('saveAndNextBtn').disabled = false;
						document.getElementById('saveBtn').disabled = false;
						document.getElementById('ChangeText').disabled = false;
						if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
							if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
								document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('ChkBox').checked = true;
								document.getElementById('saveAndNextBtn').disabled = true;
								document.getElementById('saveBtn').disabled = true;
								document.getElementById('ChangeText').disabled = true;
							} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
								document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('mapChkBox').checked = true;
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('saveAndNextBtn').disabled = true;
								document.getElementById('saveBtn').disabled = true;
								document.getElementById('ChangeText').disabled = true;
							} else {
								document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
							}
						}

						$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
						$scope.smicCheck($scope.AugmentedSrcEditDetails);
					}, function(response) {
						//function handles error condition
					});
				localStorage.clear();
			}

			/**
			 * GENERAL CONDITIONS in case of SEARCH from AUGMENT SCREEN
			 */
			if (AugmentedProductSkuSourceUpcDropDownvalue == "productsku" || AugmentedProductSkuSourceUpcDropDownvalue == "sourceupc") {
				document.getElementById('backToDisplayerBtn').style.visibility = 'hidden';
				document.getElementById('backToMappingBtn').style.visibility = 'hidden';
				var augmentedManualSearchRetrievedData = localStorage.getItem("AugmentedManualSearch");
				$scope.AugmentedSrcEditDetails = JSON.parse(augmentedManualSearchRetrievedData);

				if ($scope.AugmentedSrcEditDetails) {
					AugmentedDisplayerService.setKey(null);
					AugmentedDisplayerServiceKey = null;
					retrievedData = null;

					$scope.setValueToFileds();

					for (var i = 0; i < $scope.departmentDetail.length; i++) {
						if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
							$scope.selectedDepartmentName = $scope.departmentDetail[i];
							break;
						}
					}
					$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
					$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

					$scope.loadUOMCode();

					document.getElementById('alreadySavedItem').innerHTML = "";
					document.getElementById('mapChkBox').disabled = false;
					document.getElementById('mapChkBox').checked = false;
					document.getElementById('ChkBox').disabled = false;
					document.getElementById('ChkBox').checked = false;
					document.getElementById('saveAndNextBtn').disabled = false;
					document.getElementById('saveBtn').disabled = false;
					document.getElementById('ChangeText').disabled = false;
					if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
						if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
							document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
							document.getElementById('mapChkBox').disabled = true;
							document.getElementById('ChkBox').disabled = true;
							document.getElementById('ChkBox').checked = true;
							document.getElementById('saveAndNextBtn').disabled = true;
							document.getElementById('saveBtn').disabled = true;
							document.getElementById('ChangeText').disabled = true;
						} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
							document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
							document.getElementById('mapChkBox').disabled = true;
							document.getElementById('mapChkBox').checked = true;
							document.getElementById('ChkBox').disabled = true;
							document.getElementById('saveAndNextBtn').disabled = true;
							document.getElementById('saveBtn').disabled = true;
							document.getElementById('ChangeText').disabled = true;
						} else {
							document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
						}
					}

					$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
					$scope.smicCheck($scope.AugmentedSrcEditDetails);

					$scope.loadSMICGroupCode();
					$scope.loadProductionGroupCode();

					if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.productSrcCd == "WHSE") {
						type = 'W';
					} else {
						type = 'D';
					}

					var loadAugmentedProductSku = $scope.baseUrl + "exsrc/loadProductSKUs/" + $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.companyId + "/" + $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.divisionId + "/" + $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4 + "/" + 'A' + "/" + $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd + "/" + type;
					$http.get(loadAugmentedProductSku,config)
						.then(function(response) {
							if (response.data != null || response.data.length != 0) {
								AugmentedprdskuValue = (response.data).sort(function(a, b) {
									return a - b;
								});
								AugmentedInitialValue = AugmentedprdskuValue.indexOf($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.productSKU);
							}
						}, function(response) {
							//function handles error condition	
						});
				}

				localStorage.clear();
				augmentedManualSearchRetrievedData = null;
			}

			/**
			 * Condition to alter the augmented screen based on the origin 
			 */
			if (AugmentedDisplayerServiceKey == "displayer" || AugmentedDisplayerServiceKey == "perishables" || AugmentedDisplayerServiceKey == "bakery") {
				document.getElementById('prevProductSkuButton').style.visibility = 'hidden';
				document.getElementById('nextProductSkuButton').style.visibility = 'hidden';
				document.getElementById('backToDisplayerBtn').style.visibility = 'visible';
				document.getElementById('saveNextCol').style.visibility = 'hidden';
				$scope.upcList = [];
				AugmentedProductSkuSourceUpcDropDownvalue = null;

				if (AugmentedDisplayerServiceKey == "perishables" || AugmentedDisplayerServiceKey == "bakery") {
					document.getElementById('backToMappingBtn').style.visibility = 'visible';
					document.getElementById('backToDisplayerBtn').style.visibility = 'hidden';
					$scope.fromMapping = true;
					fromDisplayersNewCic = false;
				} else {
					$scope.fromMapping = false;
					fromDisplayersNewCic = true;
				}

				var AugmentedDisplayerCompanyID = AugmentedDisplayerService.getCompanyID();
				var AugmentedDisplayerDivisionID = AugmentedDisplayerService.getDivisionID();
				var AugmentedDisplayerProductSku = AugmentedDisplayerService.getProductSku();
				var AugmentedDisplayerDisplayFlag = AugmentedDisplayerService.getDisplayFlag();
				var AugmentedDisplayerDeptName = AugmentedDisplayerService.getDeptName();

				var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + AugmentedDisplayerCompanyID + "/" + AugmentedDisplayerDivisionID + "/" + AugmentedDisplayerProductSku;
				$http.get(AugmentedSrcEditDetailsUrl,config)
					.then(function(response) {
						//function handles success condition
						$scope.AugmentedSrcEditDetails = response.data;

						if ($scope.AugmentedSrcEditDetails && $scope.AugmentedSrcEditDetails.newItemDto && $scope.AugmentedSrcEditDetails.newItemDto.upcVoList) {
							if ($scope.AugmentedSrcEditDetails.newItemDto.upcVoList) {
								angular.forEach($scope.AugmentedSrcEditDetails.newItemDto.upcVoList, function(upcObject) {
									if (upcObject && upcObject.upc) {
										$scope.upcList.push(upcObject.upc);
									}
								});
							}
						}
						$scope.setValueToFileds();

						$scope.AugmentedSrcEditDetails.newItemDto.updDispFlag = AugmentedDisplayerDisplayFlag;

						for (var i = 0; i < $scope.departmentDetail.length; i++) {
							if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5 == $scope.departmentDetail[i].departmentName) {
								$scope.selectedDepartmentName = $scope.departmentDetail[i];
								break;
							}
						}
						$scope.deptCodeOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel4;
						$scope.deptNameOriginal = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.hierLevel5;

						//incase of FLPRD dont populate the SMIC values, enable pack and vcf to be editable
						if (AugmentedDisplayerDeptName == "FLPRD") {
							$scope.AugmentedSrcEditDetails.newItemDto.grpCd = 0;
							$scope.AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
							$scope.isForcenewProduce = true;
						} else {
							$scope.isForcenewProduce = false;
						}

						$scope.loadUOMCode();
						$scope.loadUsageTypeCombo();
						$scope.loadSMICGroupCode();
						$scope.loadProductionGroupCode();

						if (fromDisplayersNewCic) {
							$scope.AugmentedSrcEditDetails.newItemDto.packwhse = 1;
							$scope.AugmentedSrcEditDetails.newItemDto.innerPack = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.packWhse;
							$scope.AugmentedSrcEditDetails.newItemDto.updSizeUom = "EA";
							$scope.AugmentedSrcEditDetails.newItemDto.updSizeNmbr = "1.00";
							$scope.AugmentedSrcEditDetails.newItemDto.updSize = $scope.AugmentedSrcEditDetails.uiEceptionSrcDto.packWhse + " EA";
							if ($scope.selectedUomCode == null)
								$scope.selectedUomCode = {};
							$scope.selectedUomCode.uomCode = "EA";
							$scope.selectedUomCode.uomCodeUS = "EACH";
						}

						if ($scope.AugmentedSrcEditDetails.newItemDto.augOverCmplnInd == 'N') {
							document.getElementById('checkbox').checked = true;
						}

						document.getElementById('alreadySavedItem').innerHTML = "";
						document.getElementById('mapChkBox').disabled = false;
						document.getElementById('mapChkBox').checked = false;
						document.getElementById('ChkBox').disabled = false;
						document.getElementById('ChkBox').checked = false;
						document.getElementById('saveAndNextBtn').disabled = false;
						document.getElementById('saveBtn').disabled = false;
						document.getElementById('ChangeText').disabled = false;
						if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == "C") {
							if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead == true) {
								document.getElementById('alreadySavedItem').innerHTML = "Item has been marked as dead.";
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('ChkBox').checked = true;
								document.getElementById('saveAndNextBtn').disabled = true;
								document.getElementById('saveBtn').disabled = true;
								document.getElementById('ChangeText').disabled = true;
							} else if ($scope.AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped == true) {
								document.getElementById('alreadySavedItem').innerHTML = "Item has been marked for old conversion process.";
								document.getElementById('mapChkBox').disabled = true;
								document.getElementById('mapChkBox').checked = true;
								document.getElementById('ChkBox').disabled = true;
								document.getElementById('saveAndNextBtn').disabled = true;
								document.getElementById('saveBtn').disabled = true;
								document.getElementById('ChangeText').disabled = true;
							} else {
								document.getElementById('alreadySavedItem').innerHTML = "Item has already been worked.";
							}
						}

						$scope.usageIndTypeCheck($scope.AugmentedSrcEditDetails);
						$scope.smicCheck($scope.AugmentedSrcEditDetails);
						//}
					}, function(response) {
						//function handles error condition
					});
				localStorage.clear();
			}
				});
			
			});
			}
		}
	]);

	myApp.filter('removeHiphen', function() {
		return function(text) {
			if (text) {
				var str = text.replace(/\-/g, '');
				return str;
			}
		};
	});


})();