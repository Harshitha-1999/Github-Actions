(function() {
	'use strict';
	var companyNames = null;
	var divisions = null;
	var userId = null;
	var selectedCompany = null;
	var selectedDivision = null;
	var uomCodes = null;
	var departmentDetails = null;
	var currentTab = null;
	var mappingSourceSearch = null;
	var mappingTargetSearch = null;
	var bakerySourceSearch = null;

	myApp.service('service', ['$http', '$cookies', function($http, $cookies) {

		this.msalRedirectHost = function() {
			return $http({
				method: 'GET',
				url: 'msalRedirect.properties'
			}).then(function(response) {
				return response.data
				//	TO RUN ON LOCAL UNCOMMENT THE BELOW LINE AND COMMENT ABOVE LINE
				//return 'http://localhost:7000'
			}, function(error) {
				return error
			});

		};

		this.baseUrlFunction = function() {
			return $http({
				method: 'GET',
				url: 'service.properties'
			}).then(function(response) {
				return response.data;
				//	TO RUN ON LOCAL UNCOMMENT THE BELOW LINE AND COMMENT ABOVE LINE
				//	return "http://localhost:8081/memi-web/services/"; OR return "https://apim-dev-01.albertsons.com/abs/devint/memi-web/services/";
			}, function(error) {
				return error
			});

		};

		this.getHeaders = function() {
			return $http({
				method: 'GET',
				url: 'SubKeyHeader.properties'
			}).then(function(response) {
				// let itkn = $cookies.getObject('ent-abs-itkn')['idToken'];
				let auth = $cookies.getObject('ent-abs-auth')['accessToken'];
				var config = {
					  headers: {
						'Ocp-Apim-Subscription-Key': response.data,
						'Authorization': "Bearer " + auth
					}
				}
				return config;

			}, function(error) {
				return error
			});
		}

		if ($cookies.get('ent-abs-auth')) {
			let username = JSON.parse(atob($cookies.get('ent-abs-auth').split(".")[1])).upn;
			this.getUserId = username.substring(0, username.lastIndexOf("@"));
		} else {
			console.log("no cookie encountered");
		}


		this.getSupportMailID = function() {
			return "Midas.Support@albertsons.com";
		};

		this.getUOMCode = function() {
			return "uomCodes";
		};

		this.getDepartmentDetails = function() {
			return "departmentDetails";
		};

	}]);

})();
