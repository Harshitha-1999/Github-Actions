(function () {
	'use strict';

	myApp.controller('DisplayerItemsController', ['$scope', '$http', '$location', '$timeout', 'blockUI', 'service', 'DisplayerService', 'AugmentedDisplayerService', 'excelDownload',
		function DisplayerItemsController($scope, $http, $location, $timeout, blockUI, service, DisplayerService, AugmentedDisplayerService, excelDownload) {

			var DisplayerDeptName = DisplayerService.getDeptName();
			var DisplayerDeptCode = DisplayerService.getDeptCode();
			var DisplayerCompanyID = DisplayerService.getCompanyID();
			var DisplayerDivisionID = DisplayerService.getDivisionID();
			var DisplayerStatus = DisplayerService.getStatus();
			var DisplayerType = DisplayerService.getType();

			$scope.displayerStatus = null;
			$scope.displayerDeptName = null;
			$scope.displayerItems = null;
			$scope.displayerHeader = null;
			$scope.displayerSource = null;
			$scope.displayerSourceSsimsComponentDetails = null;
			$scope.displayerSourceComponentData = null;
			$scope.displayerSsimsHeaderData = null;
			$scope.displayerSsimsHeaderSelectedData = null;
			$scope.displayerSsimsHeaderDataSelected = null;

			$scope.displayerStatus = DisplayerStatus;

			$scope.DisplayerCompanyID = DisplayerCompanyID;
			$scope.DisplayerDivisionID = DisplayerDivisionID;
			$scope.DisplayerDeptCode = DisplayerDeptCode;
			$scope.DisplayerDeptName = DisplayerDeptName;
			$scope.DisplayerType = DisplayerType;


			
			if (service.baseUrlFunction() != undefined) {
				service.baseUrlFunction().then(function (url) {
					$scope.baseUrl = url;

					service.getHeaders().then(function (header) {
						var config = header;
						
						var extractedHeader = header.headers['Ocp-Apim-Subscription-Key'];
						var accessTkn = header.headers['Authorization'];
						
						//      }); do not uncomment it

						

						displayHeaderDetails();
						/**
						 * Getting displayer's data like based on company id, division id, department code, displayer status and displayer type
						 */
						function displayHeaderDetails() {
							var DisplayerLoadDataUrl = $scope.baseUrl + "dsply/loadDeptWiseDisplayItem/" + DisplayerCompanyID + "/" + DisplayerDivisionID + "/" + DisplayerDeptCode + "/" + 'Y' + "/" + DisplayerStatus + "/" + DisplayerType;
							$http.get(DisplayerLoadDataUrl, config)
								.then(function (response) {
									//function handles success condition
									if (response.data.length == 0) {
										$scope.displayerHeader = null;
										$scope.displayerSource = null;
										$scope.displayerSsimsHeaderData = null;
										$scope.displayerSsimsHeaderDataSelected = null;
										$scope.length = 0;
									}
									else {
										$scope.displayersDropDownvalue = "itemdescription";
										$scope.displayerDeptName = DisplayerDeptName;
										$scope.displayerHeader = response.data;
										$scope.length = response.data.length;
										$scope.totalDisplayed = 0;
										$scope.loadMore();
										for (var i = 0; i < $scope.displayerHeader.length; i++) {

											$scope.displayerHeader[i].Selected = false;
											if ($scope.displayerHeader[i].Selected === true) {
												$scope.displayerSource = $scope.displayerHeader[i];
												break;
											}
											else {
												$scope.displayerSource = null;
												$scope.displayerSsimsHeaderData = null;
												$scope.displayerSsimsHeaderDataSelected = null;
											}
											
										}

										for (var i = 0; i < $scope.displayerHeader.length; i++) {
											if ($scope.displayerHeader[i].caseUpc != null) {
												var caseUpcString = $scope.displayerHeader[i].caseUpc;
												var newCaseUpcString = caseUpcString.substring(0, 1) + "-" + caseUpcString.substring(1, 2) + "-" + caseUpcString.substring(2, 3) + "-" + caseUpcString.substring(3, 8) + "-" + caseUpcString.substring(8, 13);
												$scope.displayerHeader[i].caseUpcForDisplay = newCaseUpcString;
											}
											if ($scope.displayerHeader[i].caseUpc.length == 0) {
												$scope.displayerHeader[i].caseUpcForDisplay = 0;
											}
											if ($scope.displayerHeader[i].caseUpc == 0) {
												$scope.displayerHeader[i].caseUpcForDisplay = 0;
											}
										}
									}
								}, function (response) {
									//function handles error condtion
								});
						};

						/**
						 * Only loading 200 records at a time in UI.
						 */
						$scope.totalDisplayed = 0;

						$scope.loadMore = function () {
							$scope.currentTotalDisplayedValue = $scope.totalDisplayed;
							$scope.totalDisplayed = $scope.totalDisplayed + 200;
							if ($scope.totalDisplayed >= $scope.length) {
								$scope.totalDisplayed = $scope.currentTotalDisplayedValue + ($scope.length - $scope.currentTotalDisplayedValue);
							}
						};

						/**
						 * Hiding Search box, Displayer's drop down, Search button, Restore button, Match to SSIMS button, Create new CIC button and enabling Un map button under completed category.
						 */
						if ($scope.displayerStatus == "C") {
							//			document.getElementById("searchbox").style.visibility = 'hidden';
							//			document.getElementById("search").style.visibility = 'hidden';
							//			document.getElementById("restore").style.visibility = 'hidden';
							//			document.getElementById("displayersDropDownvalue").style.visibility = 'hidden';
							document.getElementById("matchToSsimsCicBtn").style.visibility = 'hidden';
							document.getElementById("createNewCicBtn").style.visibility = 'hidden';
							document.getElementById("uploadExcelLink").style.visibility = 'hidden';
							document.getElementById("downloadExcelLink").style.visibility = 'hidden';
							document.getElementById("unMapDisplayers").style.visibility = 'visible';
							$scope.displayerItems = "Reviewed";
						}

						/**
						 * Hiding Un map button under displayers's un-reviewed category.
						 */
						if ($scope.displayerStatus == "N") {
							document.getElementById("unMapDisplayers").style.visibility = 'hidden';
							$scope.displayerItems = "Un-reviewed";
						}

						$scope.exportExceptionsBtn = function (DisplayerCompanyID, DisplayerDivisionID, DisplayerDeptCode, DisplayerDeptName, DisplayerType) {
							// href="{{baseUrl}}dsply/displayersExceptionExcelDownload/{{DisplayerCompanyID}}/{{DisplayerDivisionID}}/{{DisplayerDeptCode}}/{{DisplayerDeptName}}/{{DisplayerType}}"
							
							let deptName = DisplayerDeptName.split(" ").join("");
							const urlExcelRedirect = $scope.baseUrl + "dsply/displayersExceptionExcelDownload/" + DisplayerCompanyID + "/" + DisplayerDivisionID + "/" + DisplayerDeptCode + "/" + deptName + "/" + DisplayerType;
							excelDownload.downloadFunc(urlExcelRedirect, header);
						}
						/**
						 * getting displayer's search on item description data based on company id, division id, department code, displayer item description and displayer type
						 */
						$scope.searchOnItemDesc = function (displayersDropDownvalue, displayersSearchValue) {
							var formDataSearch = [];
							if (displayersDropDownvalue == "" || displayersDropDownvalue == null) {
								alertify.alert("Please select any criteria");
								return;
							}
							else if (displayersSearchValue == "" || displayersSearchValue == null) {
								alertify.alert("Please enter any values to search");
								return;
							}
							else if (displayersDropDownvalue == "itemdescription" && $scope.displayerStatus == "N") {
								formDataSearch.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"deptCode": DisplayerDeptCode,
									"itemDesc": displayersSearchValue,
									"itemType": DisplayerType
								});

								var DisplayersSearchDetailsUrl = $scope.baseUrl + "dsply/displayersSearchOnItemDesc";
								dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config);
							}
							else if (displayersDropDownvalue == "productSku" && $scope.displayerStatus == "N") {
								formDataSearch.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"deptCode": DisplayerDeptCode,
									"productSku": displayersSearchValue,
									"itemType": DisplayerType
								});

								var DisplayersSearchDetailsUrl = $scope.baseUrl + "dsply/displayersSearchOnProductSku";
								dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config);
							}
							else if (displayersDropDownvalue == "oneitembuy" && $scope.displayerStatus == "N") {
								formDataSearch.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"deptCode": DisplayerDeptCode,
									"oneTimeBuyFlag": displayersSearchValue,
									"itemType": DisplayerType
								});

								var DisplayersSearchDetailsUrl = $scope.baseUrl + "dsply/displayersSearchOnOneTimeBuyFlag";
								dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config);
							}
							else if (displayersDropDownvalue == "itemdescription" && $scope.displayerStatus == "C") {
								formDataSearch.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"deptCode": DisplayerDeptCode,
									"itemDesc": displayersSearchValue,
									"itemType": DisplayerType
								});

								var DisplayersSearchDetailsUrl = $scope.baseUrl + "dsply/displayersSearchOnReviewedItemDesc";
								dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config);
							}
							else if (displayersDropDownvalue == "productSku" && $scope.displayerStatus == "C") {
								formDataSearch.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"deptCode": DisplayerDeptCode,
									"productSku": displayersSearchValue,
									"itemType": DisplayerType
								});

								var DisplayersSearchDetailsUrl = $scope.baseUrl + "dsply/displayersSearchOnReviewedProductSku";
								dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config);
							}
							else if (displayersDropDownvalue == "oneitembuy" && $scope.displayerStatus == "C") {
								formDataSearch.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"deptCode": DisplayerDeptCode,
									"oneTimeBuyFlag": displayersSearchValue,
									"itemType": DisplayerType
								});

								var DisplayersSearchDetailsUrl = $scope.baseUrl + "dsply/displayersSearchOnReviewedOneTimeBuyFlag";
								dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config);
							}
						};

						function dropdownServiceCall(DisplayersSearchDetailsUrl, formDataSearch, config) {
							$http.post(DisplayersSearchDetailsUrl, formDataSearch, config)
								.then(function (response) {
									//function handles success condition
									$scope.displayerHeader = response.data;
									$scope.length = response.data.length;
									$scope.totalDisplayed = 0;
									$scope.loadMore();
									for (var i = 0; i < $scope.displayerHeader.length; i++) {
										if ($scope.displayerHeader[i].caseUpc != null) {
											var caseUpcString = $scope.displayerHeader[i].caseUpc;
											var newCaseUpcString = caseUpcString.substring(0, 1) + "-" + caseUpcString.substring(1, 2) + "-" + caseUpcString.substring(2, 3) + "-" + caseUpcString.substring(3, 8) + "-" + caseUpcString.substring(8, 13);
											$scope.displayerHeader[i].caseUpcForDisplay = newCaseUpcString;
										}
										if ($scope.displayerHeader[i].caseUpc.length == 0) {
											$scope.displayerHeader[i].caseUpcForDisplay = 0;
										}
										if ($scope.displayerHeader[i].caseUpc == 0) {
											$scope.displayerHeader[i].caseUpcForDisplay = 0;
										}
									}
									$scope.displayerSource = null;
									$scope.displayerSsimsHeaderData = null;
									$scope.displayerSsimsHeaderDataSelected = null;
								}, function (response) {
									//function handles error condition
								});
						}

						/**
						 * U3178
						 * Method to disable search criteria value if oneitembuy
						 */
						$scope.disableSearchCriteriaVal = function (criteria) {
							if (criteria == "oneitembuy") {
								$scope.displayersSearchValue = 'Y';
								return true;
							} else {
								return false;
							}
						};

						$scope.setEmptySearchCriteria = function () {
							$scope.displayersSearchValue = "";
						};

						/**
						 * getting displayer's data when restore button clicks.
						 */
						$scope.restoreData = function () {
							document.getElementById("searchbox").value = "";
							$scope.totalDisplayed = 0;
							displayHeaderDetails();
						};

						/**
						 * Marking an non-displayer item to displayer item based on company id, division id, department code, product sku, case upc and updating corresponding user id in respective table.
						 */
						$scope.markDisplay = function () {
							var count = 0;
							var productSku = null;
							var caseUpc = null;
							var updatedUserID = null;
							var displayFlag = false;
							var formData = [];

							angular.forEach($scope.displayerHeader, function (x) {
								if (x.Selected) {
									count = count + 1;
								}
							});
							if (count == 0) {
								alertify.alert("Select any items from ProductSKU.");
								return;
							}
							else {
								for (var i = 0; i < $scope.displayerHeader.length; i++) {
									if ($scope.displayerHeader[i].Selected) {
										if ($scope.displayerHeader[i].multiComponentItemInd == 'Y') {
											displayFlag = true;
											break;
										}
										productSku = $scope.displayerHeader[i].productSku;
										caseUpc = $scope.displayerHeader[i].caseUpc;
										updatedUserID = service.userId;
										formData.push({
											"productSku": productSku,
											"caseUpc": caseUpc,
											"companyId": DisplayerCompanyID,
											"divisionId": DisplayerDivisionID,
											"deptCode": DisplayerDeptCode,
											"updatedUserID": updatedUserID
										});
									}
								}

								var markDisplayUrl = $scope.baseUrl + "dsply/markDisplay";

								if (displayFlag == true) {
									alertify.alert("Item already in display status.");
									return;
								}
								else {
									$http.post(markDisplayUrl, formData, config)
										.then(function (response) {
											//function handles success condition
											displayHeaderDetails();
										}, function (response) {
											//function handles error condtion
										});
								}
							}
						};

						/**
						 * Marking a displayer item to non-displayer item based on company id, division id, department code, product sku, case upc and updating corresponding user id in respective table.
						 */
						$scope.unMarkDisplay = function () {
							var count = 0;
							var productSku = null;
							var caseUpc = null;
							var updatedUserID = null;
							var displayFlag = false;
							var formData = [];

							angular.forEach($scope.displayerHeader, function (x) {
								if (x.Selected) {
									count = count + 1;
								}
							});
							if (count == 0) {
								alertify.alert("Select any items from ProductSKU.");
								return;
							}
							else {
								for (var i = 0; i < $scope.displayerHeader.length; i++) {
									if ($scope.displayerHeader[i].Selected) {
										if ($scope.displayerHeader[i].multiComponentItemInd == 'N') {
											displayFlag = true;
											break;
										}
										productSku = $scope.displayerHeader[i].productSku;
										caseUpc = $scope.displayerHeader[i].caseUpc;
										updatedUserID = service.userId;
										formData.push({
											"productSku": productSku,
											"caseUpc": caseUpc,
											"companyId": DisplayerCompanyID,
											"divisionId": DisplayerDivisionID,
											"deptCode": DisplayerDeptCode,
											"updatedUserID": updatedUserID
										});
									}
								}
								var unMarkDisplayUrl = $scope.baseUrl + "dsply/unMarkDisplay";

								if (displayFlag == true) {
									alertify.alert("Item already in non display status.");
									return;
								}
								else {
									$http.post(unMarkDisplayUrl, formData, config)
										.then(function (response) {
											//function handles success condition
											displayHeaderDetails();
										}, function (response) {
											//function handles error condtion
										});
								}
							}
						};

						/**
						 * Marking a displayer item as dead item based on company id, division id, product sku and updating corresponding user id, reason for mars as dead in respective table.
						 */
						$scope.markDead = function () {
							var count = 0;
							var productSku = null;
							var markAsDeadReason = null;
							var updatedUserID = null;
							var formData = [];
							angular.forEach($scope.displayerHeader, function (x) {
								if (x.Selected) {
									count = count + 1;
								}
							});
							if (count == 0) {
								alertify.alert("Select any items from ProductSKU.");
								return;
							}
							else {
								alertify.prompt("Enter the reason for marking this item as dead", function (e, str) {
									if (e) {
										markAsDeadReason = str;
										updatedUserID = service.userId;
										if (markAsDeadReason == null || markAsDeadReason.length == 0) {
											$scope.markDead();
										}
										else if (markAsDeadReason != null || markAsDeadReason.length != 0) {
											var whiteSpace = new RegExp(/^\s+$/);
											if (whiteSpace.test(str)) {
												$scope.markDead();
											}
											else {
												for (var i = 0; i < $scope.displayerHeader.length; i++) {
													if ($scope.displayerHeader[i].Selected) {
														productSku = $scope.displayerHeader[i].productSku;
														formData.push({
															"productSku": productSku,
															"companyId": DisplayerCompanyID,
															"divisionId": DisplayerDivisionID,
															"markAsDeadReason": markAsDeadReason,
															"updatedUserID": updatedUserID
														});
													}
												}
												var markDeadUrl = $scope.baseUrl + "dsply/markDead";

												$http.post(markDeadUrl, formData, config)
													.then(function (response) {
														//function handles success condition
														displayHeaderDetails();
													}, function (response) {
														//function handles error condtion
													});
											}
										}
									}
									else {

									}
								});
							}
						};

						/**
						 * Selecting which record from UI selected for displaying details from SSIMS side.
						 */

						$scope.selectedHeaderRow = function (row, selectedVal) {

							for (let i = 0; i < $scope.displayerHeader.length; i++) {
								if ($scope.displayerHeader[i].Selected === true) {
									// $scope.displayerSource = row;
									// $scope.displayerSourceComponent($scope.displayerSource.productSku, $scope.displayerSource.caseUpcForDisplay, $scope.displayerSource.cost, $scope.displayerSource.productSourceCode);
									$scope.displayerSource = $scope.displayerHeader[i];
									$scope.displayerSourceComponent($scope.displayerHeader[i].productSku, $scope.displayerHeader[i].caseUpcForDisplay, $scope.displayerHeader[i].cost, $scope.displayerHeader[i].productSourceCode);
									break;
								}
								else {
									$scope.displayerSource = null;
									$scope.displayerSourceComponentData = null;
									$scope.displayerSsimsHeaderData = null;
									$scope.displayerSsimsHeaderDataSelected = null;


								}
							}

						};

						/**
						 * Displaying Displayer's data from SSIMS side based on company id, division id, product sku, case upc and upc.
						 */
						$scope.displayerSourceComponent = function (productSku, caseUpc, srcCost, prdSrcCode) {
							var formDataCompleted = [];
							var formDataDisplayerSourceSsimsComponent = [];

							var DisplayerSourceSsimsComponentUrl = $scope.baseUrl + "dsply/loadSourceSimsItems";
							formDataDisplayerSourceSsimsComponent.push({
								"companyId": DisplayerCompanyID,
								"divisionId": DisplayerDivisionID,
								"productSku": productSku,
								"caseUpc": caseUpc,
								"cost": srcCost,
								"productSourceCode": prdSrcCode
							});

							var formDataDisplayerSourceSsimsComponentObject = JSON.parse(JSON.stringify(formDataDisplayerSourceSsimsComponent[0]));

							$http.post(DisplayerSourceSsimsComponentUrl, formDataDisplayerSourceSsimsComponentObject, config)
								.then(function (response) {
									//function handles success condition
									$scope.displayerSourceSsimsComponentDetails = response.data;
									$scope.displayerSourceComponentData = $scope.displayerSourceSsimsComponentDetails.displayItemSourceUPC;
									$scope.displayerSsimsHeaderData = $scope.displayerSourceSsimsComponentDetails.displaySimsLikeItems;

									if ($scope.displayerSsimsHeaderData != null && $scope.displayerSsimsHeaderData.length > 0) {
										if ($scope.displayerStatus == 'C') {
											for (var i = 0; i < $scope.displayerSsimsHeaderData.length; i++) {
												if ($scope.displayerSsimsHeaderData[i].cicAlreadyProcessed == 'Y') {
													formDataCompleted.push($scope.displayerSsimsHeaderData[i]);
													$scope.displayerSsimsHeaderDataSelected = formDataCompleted;
													break;
												}
											}
										}
										else {
											var displayerSsimsHeaderDataSelectedString = JSON.stringify($scope.displayerSsimsHeaderData);
											$scope.displayerSsimsHeaderDataSelected = JSON.parse(displayerSsimsHeaderDataSelectedString);
										}
									}
									else {
										$scope.displayerSsimsHeaderData = null;
										$scope.displayerSsimsHeaderDataSelected = null;
									}
								}, function (response) {
									//function handles error condtion
								});
						};

						/**
						 * Matching a displayer item from source to SSIMS side.
						 */
						$scope.matchToSsimsCic = function () {
							if ($scope.displayerSsimsHeaderDataSelected == null || $scope.displayerSsimsHeaderData == null) {
								alertify.alert("Match to SSIMS not allowed. No Match from SSIMS.");
								return;
							}
							else {
								var count = 0;
								var formDataMatchToSsimsCic = [];

								angular.forEach($scope.displayerSsimsHeaderDataSelected, function (displayerSsimsHeader) {
									if (displayerSsimsHeader.Selected) {
										count = count + 1;
									}
								});

								if (count == 0) {
									alertify.alert("Please select any item details from SSIMS.");
									return;
								}

								else if (count > 1) {
									alertify.alert("More than one selection of item details from SSIMS not allowed.");
									return;
								}

								else {
									for (var i = 0; i < $scope.displayerSsimsHeaderDataSelected.length; i++) {
										if ($scope.displayerSsimsHeaderDataSelected[i].Selected) {
											if ($scope.displayerSsimsHeaderDataSelected[i].cic == $scope.displayerSsimsHeaderData[i].cic) {
												$scope.displayerSsimsHeaderSelectedData = $scope.displayerSsimsHeaderData[i];
												formDataMatchToSsimsCic.push({
													"companyId": DisplayerCompanyID,
													"divisionId": DisplayerDivisionID,
													"productSku": $scope.displayerSource.productSku,
													"srcItemDesc": $scope.displayerSource.itemDesc,
													"caseUpc": $scope.displayerSource.caseUpc,
													"cic": $scope.displayerSsimsHeaderSelectedData.cic,
													"ssimsHeaderItemDesc": $scope.displayerSsimsHeaderSelectedData.itemDesc,
													"ssimsComponent": $scope.displayerSsimsHeaderSelectedData.displayItemUPC
												});
											}
										}

										var matchToSsimsCicUrl = $scope.baseUrl + "dsply/matchToSimsCic";

										$http.post(matchToSsimsCicUrl, formDataMatchToSsimsCic, config)
											.then(function (response) {
												//function handles success condition
												$scope.displayerSource = null;
												$scope.displayerSourceComponentData = null;
												$scope.displayerSsimsHeaderData = null;
												$scope.displayerSsimsHeaderDataSelected = null;
												displayHeaderDetails();
											}, function (response) {
												//function handles error condtion
											});
									}
								}
							}
						};

						/**
						 * Create a new CIC for a record from source side if there is no perfect match from SSIMS side.
						 */
						$scope.createNewCic = function () {
							var flag = 1;
							if ($scope.displayerSource == null) {
								alertify.alert("No item details on source side.");
								flag = 0;
							}
							else if ($scope.displayerSourceComponentData == null) {
								alertify.alert("Component details not available.");
								flag = 0;
							}
							else if ($scope.displayerSsimsHeaderData != null || $scope.displayerSsimsHeaderDataSelected != null) {
								for (var i = 0; i < $scope.displayerSsimsHeaderData.length; i++) {
									if (($scope.displayerSsimsHeaderData[i].caseUpcMatch == 'Y' && $scope.displayerSsimsHeaderData[i].qtyMatch == 'Y' && $scope.displayerSsimsHeaderData[i].costMatch == 'Y') || ($scope.displayerSsimsHeaderData[i].upcMatch == 'Y' && $scope.displayerSsimsHeaderData[i].qtyMatch == 'Y' && $scope.displayerSsimsHeaderData[i].costMatch == 'Y')) {
										alertify.alert("Create New CIC not allowed. Already match found from SSIMS Item.");
										flag = 0;
										break;
									}
								}

							}
							else {
								flag = 0;
								createNewCic();
							}
							if (flag == 1) {
								createNewCic();
							}
							function createNewCic() {
								var updatedUserID = null;
								var formDataCreateNewCic = [];
								updatedUserID = service.userId;
								formDataCreateNewCic.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"productSku": $scope.displayerSource.productSku,
									"srcItemDesc": $scope.displayerSource.itemDesc,
									"caseUpc": $scope.displayerSource.caseUpc,
									"displayFlag": $scope.displayerSource.multiComponentItemInd,
									"pack": $scope.displayerSource.shippingPackNumber,
									"vendorConvFactor": $scope.displayerSource.masterCasePackNumber,
									"cost": $scope.displayerSource.cost,
									"updatedUserId": updatedUserID,
									"sourceComponentUpc": $scope.displayerSourceComponentData

								});

								var createNewCicUrl = $scope.baseUrl + "dsply/createNewCic";

								$http.post(createNewCicUrl, formDataCreateNewCic, config)
									.then(function (response) {
										//function handles success condition
										if (response.data.Result == " New CIC created successfully") {
											AugmentedDisplayerService.setDeptName(DisplayerDeptName);
											AugmentedDisplayerService.setDeptCode(DisplayerDeptCode);
											AugmentedDisplayerService.setCompanyID(DisplayerCompanyID);
											AugmentedDisplayerService.setDivisionID(DisplayerDivisionID);
											AugmentedDisplayerService.setProductSku($scope.displayerSource.productSku);
											AugmentedDisplayerService.setDisplayFlag($scope.displayerSource.multiComponentItemInd);
											AugmentedDisplayerService.setStatus(DisplayerStatus);
											AugmentedDisplayerService.setType(DisplayerType);
											AugmentedDisplayerService.setKey("displayer");
											$location.path('Augmented');
										}
									}, function (response) {
										//function handles error condition
									});
							}
						};

						/**
						 * Un mapping already matched item from SSIMS.
						 */
						$scope.unMapDisplayers = function () {
							var cicType = null;
							var formDataUnMapDisplayers = [];
							if ($scope.displayerSource == null) {
								alertify.alert("Please select any item for unmap.");
								return;
							}
							else {
								if ($scope.displayerSsimsHeaderData != null || $scope.displayerSsimsHeaderDataSelected != null) {
									for (var i = 0; i < $scope.displayerSsimsHeaderData.length; i++) {
										if (($scope.displayerSsimsHeaderData[i].cicAlreadyProcessed == 'Y') || ($scope.displayerSsimsHeaderData[i].caseUpcMatch == 'Y' && $scope.displayerSsimsHeaderData[i].qtyMatch == 'Y' && $scope.displayerSsimsHeaderData[i].costMatch == 'Y') || ($scope.displayerSsimsHeaderData[i].upcMatch == 'Y' && $scope.displayerSsimsHeaderData[i].qtyMatch == 'Y' && $scope.displayerSsimsHeaderData[i].costMatch == 'Y')) {
											cicType = 'M';
											break;
										}
									}
								}
								else {
									cicType = 'C';
								}

								if (cicType == null) {
									cicType = 'C';
								}

								formDataUnMapDisplayers.push({
									"companyId": DisplayerCompanyID,
									"divisionId": DisplayerDivisionID,
									"productSku": $scope.displayerSource.productSku,
									"updatedUserId": service.userId,
									"cicType": cicType
								});

								var unMapDisplayersUrl = $scope.baseUrl + "dsply/undoDisplayersCompleted";

								var formDataUnMapDisplayersObject = JSON.parse(JSON.stringify(formDataUnMapDisplayers[0]));

								$http.post(unMapDisplayersUrl, formDataUnMapDisplayersObject, config)
									.then(function (response) {
										//function handles success condition
										if (response.data.Result == " Item Already Converted By ETL") {
											alertify.alert("This item is already in completed status. Not able to unmap.");
											return;
										}
										else {
											$scope.displayerSource = null;
											$scope.displayerSourceComponentData = null;
											$scope.displayerSsimsHeaderData = null;
											$scope.displayerSsimsHeaderDataSelected = null;
											displayHeaderDetails();
										}

									}, function (response) {
										//function handles error condtion
									});
							}
						};

						/**
						 * Return to home page.
						 */
						$scope.HomePage = function () {
							service.mappingSourceSearch = null;
							service.mappingTargetSearch = null;
							$location.path('/');
						};

						/**
						 * Upload file 
						 */
						$scope.popup = function (buttonValue) {
							$scope.popupErrorMsg = "";
							$scope.selectedDeptAug = null;
							document.getElementById('uploadedfile').value = "";
							if (buttonValue == "Upload") {
								$("#uploadDisp").modal("show");
							}
						};

						$scope.uploadDispFile = function () {
							var file = $scope.myDispFile;
							var uploadUrl = $scope.baseUrl + "dsply/uploadExceptionFile";

							if (DisplayerCompanyID && DisplayerDivisionID && file &&
								DisplayerDeptCode && DisplayerType && service.userId) {
								$scope.popupErrorMsg = "";
								$scope.uploadFileToUrl(file, uploadUrl);
							}
							else {
								$scope.fontColor_upload = "fontColor_WHSE";
								$scope.popupErrorMsg = "Error in uploading the file.";
							}
						};

						$scope.uploadFileToUrl = function (file, uploadUrl) {
							var fd = new FormData();
							var config = {
								transformRequest: angular.identity,
								headers: {
									'Content-Type': undefined,
									'Ocp-Apim-Subscription-Key': extractedHeader,
									'Authorization':accessTkn
									
								}
							};
							fd.append('file', file);
							fd.append('companyId', DisplayerCompanyID);
							fd.append('divisionId', DisplayerDivisionID);
							fd.append('deptCode', DisplayerDeptCode);
							fd.append('displayType', DisplayerType);
							fd.append('userId', service.userId);

							$http.post(uploadUrl, fd, config)
								.then(function (response1) {
									if (response1.data.status == "SUCCESS") {
										$scope.fontColor_upload = "fontColor_DSD";
										$scope.popupErrorMsg = "The file is being processed. You will be notified through an email when processing is complete.";
									} else if (response1.data.status == "NOT_EXCEL") {
										$scope.fontColor_upload = "fontColor_WHSE";
										$scope.popupErrorMsg = "Unsupported file format. Use the default template for uploading process.";
									} else if (response1.data.status == "STR_CHANGE") {
										$scope.fontColor_upload = "fontColor_WHSE";
										$scope.popupErrorMsg = "File structure has been changed. Use the default structure of the Excel.";
									} else if (response1.data.status == "FAILURE") {
										$scope.fontColor_upload = "fontColor_WHSE";
										$scope.popupErrorMsg = "File upload failed.";
									} else if (response1.data.status == "ERROR") {
										$scope.fontColor_upload = "fontColor_WHSE";
										$scope.popupErrorMsg = "Issues in uploading the file.";
									}
								}, function (response1) {
									//function handles error condition
									$scope.fontColor_upload = "fontColor_WHSE";
									$scope.popupErrorMsg = "Internal network error.";
								});

						};
					});
				});
			}
		}]);

})();