(function(){
	'use strict';
	
	myApp.service('DisplayerService', function() {
		
		var savedDeptName="";
		var savedDeptCode="";
		var savedCompanyID="";
		var savedDivisionID="";
		var savedStatus="";
		var savedType="";
		
		var setDeptName = function(deptName){
			savedDeptName = deptName;
		};
		
		var getDeptName = function(){
			return savedDeptName;
		};
		
	    var setDeptCode = function(deptcode) {
	    	savedDeptCode = deptcode;
	    };

	    var getDeptCode = function(){
	        return savedDeptCode;
	    };
	    
	    var setCompanyID = function(companyid) {
	    	savedCompanyID = companyid;
	    };

	    var getCompanyID = function(){
	        return savedCompanyID;
	    };
	    
	    var setDivisionID = function(divisionid) {
	    	savedDivisionID = divisionid;
	    };

	    var getDivisionID = function(){
	        return savedDivisionID;
	    };
	    
	    var setStatus = function(status) {
	    	savedStatus = status;
	    };

	    var getStatus = function(){
	        return savedStatus;
	    };
	    
	    var setType = function(type) {
	    	savedType = type;
	    };

	    var getType = function(){
	        return savedType;
	    };
	    
	    return {
	    	setDeptName : setDeptName,
	    	getDeptName : getDeptName,
	    	setDeptCode : setDeptCode,
	    	getDeptCode : getDeptCode,
	    	setCompanyID : setCompanyID,
	    	getCompanyID : getCompanyID,
	    	setDivisionID : setDivisionID,
	    	getDivisionID : getDivisionID,
	    	setStatus : setStatus,
	    	getStatus : getStatus,
	    	setType : setType,
	    	getType : getType
	    };
	});
	
})();