'use strict';

var myApp = angular.module('myApp', ['ngCookies', 'ngRoute', 'blockUI', 'dndLists', 'rzTable']);

/**
 *  U62615
 *  Directive for enter action. Can be used across the application
 */

myApp.controller('myAppcontroller', ['$window', '$cookies', 'service', function($window, $cookies, service) {
	var absCookie = $cookies.get('ent-abs-auth');
	
	if (absCookie) {
		console.log("token found send to homepage");
		service.userId = service.getUserId;
	} else {
		service.msalRedirectHost().then(function(msalUrl) {
			var urlTest = msalUrl + '/authenticate';
			$window.location.href = urlTest;
			//	$window.location.href = 'http://localhost:7000/authenticate';
			console.log("navigate to login 7000 port");
		}, function(error) {
			return console.log(error)
		})

	}
}]);

myApp.controller('logOutController', ['$scope', '$window', '$cookies', 'service', function($scope, $window, $cookies, service) {
	$scope.logout = function($event) {
		var absCookie = $cookies.get('ent-abs-auth');
		service.msalRedirectHost().then(function(msalUrl) {
			if (absCookie) {
				$cookies.remove('ent-abs-auth');
				//	$window.location.href = 'http://localhost:7000/azurelogout';
				$window.location.href = msalUrl + '/azurelogout';
			} else {
				console.log("no cookie encountered");
				//  uncomment below for test
				// $window.location.href = 'http://localhost:7000/azurelogout'
			}
		});

	}
}
]);

myApp.directive('ngEnter', function() {
	return function(scope, element, attrs) {
		element.bind("keydown keypress", function(event) {
			if (event.which === 13) {
				scope.$apply(function() {
					scope.$eval(attrs.ngEnter, { 'event': event });
				});

				event.preventDefault();
			}
		});
	};
});

myApp.directive('fileModel', ['$parse', function($parse) {
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function() {
				scope.$apply(function() {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

myApp.directive("moveNextOnMaxlength", function() {
	return {
		restrict: "A",
		link: function($scope, element) {
			element.on("input", function(e) {
				if (element.val().length == element.attr("maxlength")) {
					var $nextElement = element.next();
					if ($nextElement.length) {
						$nextElement[0].focus();
					}
				}
			});
		}
	};
});

myApp.directive('currency', function() {
	return {
		require: 'ngModel',
		link: function(elem, $scope, attrs, ngModel) {
			ngModel.$formatters.push(function(val) {
				return '$' + val;
			});
			ngModel.$parsers.push(function(val) {
				return val.replace(/^\$/, '');
			});
		}
	};
});

myApp.directive('convertToNumber', function() {
	return {
		require: 'ngModel',
		link: function($scope, element, attrs, ngModel) {
			ngModel.$parsers.push(function(val) {
				return parseInt(val, 10);
			});
			ngModel.$formatters.push(function(val) {
				return '' + val;
			});
		}
	};
});
