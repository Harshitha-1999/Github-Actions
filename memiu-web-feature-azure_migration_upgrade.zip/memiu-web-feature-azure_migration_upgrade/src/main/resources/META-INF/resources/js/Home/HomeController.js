(function () {
	'use strict';

	myApp.controller('HomeController', ['$scope', '$http', '$location', '$document', 'blockUI', 'service', 'AugmentedService', 'UpdateOverrideService', 'DisplayerService', 'excelDownload',
		function HomeController($scope, $http, $location, $document, blockUI, service,
			AugmentedService, UpdateOverrideService, DisplayerService, excelDownload) {
			//			APPROACH 3
			
			if (service.baseUrlFunction() != undefined) {
				service.baseUrlFunction().then(function (url) {
					$scope.baseUrl = url;


					service.getHeaders().then(function (header) {
						
						var config = header
					//      }); do not uncomment it


						var currentTab = null;
						/*var req = new XMLHttpRequest();
						req.open('GET', document.location, false);
						req.send(null);
						var user = req.getResponseHeader("USERID");  OBSTOLE CODE */
						
						service.userId = service.getUserId;

						$scope.displayMultiUnitpage = false;
						$scope.displayLookupPage = false;
						$scope.popupErrorMsg = " ";
						$scope.fontColor_upload = "fontColor_WHSE";
						$scope.companyNames = null;




						/**
						 *  Pre-initialise the setup
						 */
						if (service.companyNames) {
							$scope.companyNames = service.companyNames;
							$scope.selectedCompany = service.selectedCompany;
							$scope.divisions = service.divisions;
							$scope.selectedDivision = service.selectedDivision;

							$scope.overrideWhseUnreviewedItemsCount = 0;
							$scope.overrideDsdUnreviewedItemsCount = 0;
							$scope.overrideUnreviewedItemsCount = 0;
							$scope.overrideWhseCompletedItemsCount = 0;
							$scope.overrideDsdCompletedItemsCount = 0;
							$scope.overrideCompletedItemsCount = 0;

							$scope.augmentedWhseUnreviewedItemsCount = 0;
							$scope.augmentedDsdUnreviewedItemsCount = 0;
							$scope.augmentedUnreviewedItemsCount = 0;
							$scope.augmentedWhseNeedFurtherReviewedItemsCount = 0;
							$scope.augmentedDsdNeedFurtherReviewedItemsCount = 0;
							$scope.augmentedNeedFurtherReviewedItemsCount = 0;
							$scope.augmentedWhseCompletedItemsCount = 0;
							$scope.augmentedDsdCompletedItemsCount = 0;
							$scope.augmentedCompletedItemsCount = 0;

							$scope.displayerWhseUnreviewedItemsCount = 0;
							$scope.displayerDsdUnreviewedItemsCount = 0;
							$scope.displayerUnreviewedItemsCount = 0;
							$scope.displayerWhseCompletedItemsCount = 0;
							$scope.displayerDsdCompletedItemsCount = 0;
							$scope.displayerCompletedItemsCount = 0;

							if (service.currentTab == "tabOverride") {
								var departmentsInOverrideUrl = $scope.baseUrl + "exsrc/listOverRideData/" + service.selectedCompany.companyID + "/" + service.selectedDivision.divisionID;
								$http.get(departmentsInOverrideUrl, config)
									.then(function (response) {
										//function handles success condition
										$scope.departmentsOverride = response.data;
										for (var i = 0; i < $scope.departmentsOverride.length; i++) {
											$scope.overrideWhseUnreviewedItemsCount = $scope.overrideWhseUnreviewedItemsCount + $scope.departmentsOverride[i].totalWHSERecords;
											$scope.overrideDsdUnreviewedItemsCount = $scope.overrideDsdUnreviewedItemsCount + $scope.departmentsOverride[i].totalDSDRecords;
											$scope.overrideUnreviewedItemsCount = $scope.overrideUnreviewedItemsCount + $scope.departmentsOverride[i].totalRecord;
											$scope.overrideWhseCompletedItemsCount = $scope.overrideWhseCompletedItemsCount + $scope.departmentsOverride[i].completedWHSEItmCnt;
											$scope.overrideDsdCompletedItemsCount = $scope.overrideDsdCompletedItemsCount + $scope.departmentsOverride[i].completedDSDItmCnt;
											$scope.overrideCompletedItemsCount = $scope.overrideCompletedItemsCount + $scope.departmentsOverride[i].completedItmCnt;
										}
									}, function (response) {
										//function handles error condition
									});

								document.getElementById('tabOverrideContents').style.display = "block";
								setTimeout(function () {
									document.getElementById('tabOverride').click();
								}, 0);
							}

							if (service.currentTab == "tabAugmented") {
								var departmentsInAugmentedUrl = $scope.baseUrl + "exsrc/listAugData/" + service.selectedCompany.companyID + "/" + service.selectedDivision.divisionID;
								$http.get(departmentsInAugmentedUrl, config)
									.then(function (response) {
										//function handles success condition
										$scope.departmentsAugmented = response.data;
										for (var i = 0; i < $scope.departmentsAugmented.length; i++) {
											$scope.augmentedWhseUnreviewedItemsCount = $scope.augmentedWhseUnreviewedItemsCount + $scope.departmentsAugmented[i].totalWHSERecords;
											$scope.augmentedDsdUnreviewedItemsCount = $scope.augmentedDsdUnreviewedItemsCount + $scope.departmentsAugmented[i].totalDSDRecords;
											$scope.augmentedUnreviewedItemsCount = $scope.augmentedUnreviewedItemsCount + $scope.departmentsAugmented[i].totalRecord;
											$scope.augmentedWhseNeedFurtherReviewedItemsCount = $scope.augmentedWhseNeedFurtherReviewedItemsCount + $scope.departmentsAugmented[i].reviewWHSEItmCnt;
											$scope.augmentedDsdNeedFurtherReviewedItemsCount = $scope.augmentedDsdNeedFurtherReviewedItemsCount + $scope.departmentsAugmented[i].reviewDSDItmCnt;
											$scope.augmentedNeedFurtherReviewedItemsCount = $scope.augmentedNeedFurtherReviewedItemsCount + $scope.departmentsAugmented[i].reviewItmCnt;
											$scope.augmentedWhseCompletedItemsCount = $scope.augmentedWhseCompletedItemsCount + $scope.departmentsAugmented[i].completedWHSEItmCnt;
											$scope.augmentedDsdCompletedItemsCount = $scope.augmentedDsdCompletedItemsCount + $scope.departmentsAugmented[i].completedDSDItmCnt;
											$scope.augmentedCompletedItemsCount = $scope.augmentedCompletedItemsCount + $scope.departmentsAugmented[i].completedItmCnt;
										}
									}, function (response) {
										//function handles error condition
									});

								document.getElementById('tabAugmentedContents').style.display = "block";
								setTimeout(function () {
									document.getElementById('tabAugmented').click();
								}, 0);
							}

							if (service.currentTab == "tabDisplayItem") {
								var departmentsInDisplayerUrl = $scope.baseUrl + "dsply/listDisplayerData/" + service.selectedCompany.companyID + "/" + service.selectedDivision.divisionID;
								$http.get(departmentsInDisplayerUrl, config)
									.then(function (response) {
										//function handles success condition
										$scope.departmentsDisplayer = response.data;
										for (var i = 0; i < $scope.departmentsDisplayer.length; i++) {
											$scope.displayerWhseUnreviewedItemsCount = $scope.displayerWhseUnreviewedItemsCount + $scope.departmentsDisplayer[i].totalWHSERecords;
											$scope.displayerDsdUnreviewedItemsCount = $scope.displayerDsdUnreviewedItemsCount + $scope.departmentsDisplayer[i].totalDSDRecords;
											$scope.displayerUnreviewedItemsCount = $scope.displayerUnreviewedItemsCount + $scope.departmentsDisplayer[i].totalRecord;
											$scope.displayerWhseCompletedItemsCount = $scope.displayerWhseCompletedItemsCount + $scope.departmentsDisplayer[i].completedWHSEItmCnt;
											$scope.displayerDsdCompletedItemsCount = $scope.displayerDsdCompletedItemsCount + $scope.departmentsDisplayer[i].completedDSDItmCnt;
											$scope.displayerCompletedItemsCount = $scope.displayerCompletedItemsCount + $scope.departmentsDisplayer[i].completedItmCnt;
										}
									}, function (response) {
										//function handles error condition
									});

								document.getElementById('tabDisplayItemContents').style.display = "block";
								setTimeout(function () {
									document.getElementById('tabDisplayItem').click();
								}, 0);
							}

							if (service.currentTab == "tabMultiUnitType") {
								document.getElementById('tabMultiUnitTypeContents').style.display = "block";
								setTimeout(function () {
									document.getElementById('tabMultiUnitType').click();
								}, 0);
							}

							if (service.currentTab == "tabBakery" || service.currentTab == "tabMapped" || service.currentTab == "tabPerishable") {
								document.getElementById(service.currentTab + 'Contents').style.display = "block";
								setTimeout(function () {
									document.getElementById(service.currentTab).click();
								}, 0);
							}

							if (service.currentTab == "tabLookup") {
								document.getElementById('tabLookupContents').style.display = "block";
								setTimeout(function () {
									document.getElementById('tabLookup').click();
								}, 0);
							}

							var departmentNamesUrl = $scope.baseUrl + "exsrc/department/list/" + service.selectedCompany.companyID + "/" + service.selectedDivision.divisionID;
							$http.get(departmentNamesUrl, config)
								.then(function (response) {
									//function handles success condition
									service.departmentDetails = response.data;
								}, function (response) {
									//function handles error condition
								});
						} else {
							document.getElementById('tabOverrideContents').style.display = "block";
							setTimeout(function () {
								document.getElementById('tabOverride').click();
							}, 0);

							var companyNamesUrl = $scope.baseUrl + "company/list";
							$http.get(companyNamesUrl, config)
								.then(function (response) {
									//function handles success condition
									service.companyNames = response.data;
									$scope.companyNames = service.companyNames;
								}, function (response) {
									alertify.alert("Couldn't connect to server! Try again later.");
									//function handles error condition
								});
						}

						/////Load the UOM list and store it in the service
						if (service.uomCodes == null) {
							var uonCodesUrl = $scope.baseUrl + "exsrc/UOM/list";
							$http.get(uonCodesUrl, config)
								.then(function (response) {
									//function handles success condition
									service.uomCodes = response.data;
								}, function (response) {
									//function handles error condition
								});
						}

						/**
						 *  Open the tab based on the click
						 */
						$scope.openDetails = function ($event, tabID) {
							var i, tabcontent, tablinks;

							// Get all elements with class="tabcontent" and hide them
							tabcontent = document.getElementsByClassName("tabcontent");
							for (i = 0; i < tabcontent.length; i++) {
								tabcontent[i].style.display = "none";
							}

							// Get all elements with class="tablinks" and remove the class "active"
							tablinks = document.getElementsByClassName("tablinks");
							for (i = 0; i < tablinks.length; i++) {
								tablinks[i].className = tablinks[i].className.replace("active", "");
							}

							// Show the current tab, and add an "active" class to the button that opened the tab
							$document[0].getElementById(tabID + 'Contents').style.display = 'block';
							$(event.target).addClass("active");

							if (service.currentTab == tabID) {
								currentTab = null;
								if (service.selectedCompany && service.selectedDivision && $scope.selectedDivision) {
									if (service.selectedCompany.companyID != $scope.selectedDivision.companyID || service.selectedDivision.divisionID != $scope.selectedDivision.divisionID) {
										currentTab = service.currentTab;
									}
								}
							} else {
								currentTab = tabID;
								service.currentTab = tabID;
								$scope.clickedTabDetails();
							}
						};

						/**
						 *  Load the tab details
						 */
						$scope.clickedTabDetails = function () {
							$scope.displayMultiUnitpage = false;
							$scope.displayLookupPage = false;
							if (currentTab == null) {
								currentTab = service.currentTab;
							}
							if ($scope.selectedDivision == null || $scope.selectedDivision == null) {
								return;
							} else if (currentTab == "tabOverride" && $scope.selectedDivision.companyID != null && $scope.selectedDivision.divisionID != null) {
								$scope.departmentsInOverride($scope.selectedDivision.companyID, $scope.selectedDivision.divisionID);
							} else if (currentTab == "tabAugmented" && $scope.selectedDivision.companyID != null && $scope.selectedDivision.divisionID != null) {
								$scope.departmentsInAugmented($scope.selectedDivision.companyID, $scope.selectedDivision.divisionID);
							} else if (currentTab == "tabDisplayItem" && $scope.selectedDivision.companyID != null && $scope.selectedDivision.divisionID != null) {
								$scope.departmentsInDisplayer($scope.selectedDivision.companyID, $scope.selectedDivision.divisionID);
							} else if (currentTab == "tabMultiUnitType" && $scope.selectedDivision.companyID != null && $scope.selectedDivision.divisionID != null) {
								$scope.getInclude();
							} else if ((currentTab == "tabBakery" || currentTab == "tabMapped" || currentTab == "tabPerishable") && $scope.selectedDivision.companyID != null && $scope.selectedDivision.divisionID != null) {
								$scope.initialisePerishable(currentTab);
							} else {
								if (currentTab == "tabLookup" && $scope.selectedDivision.companyID != null && $scope.selectedDivision.divisionID != null) {
									$scope.loadLookupScreen();
								}
							}
						};

						$scope.getInclude = function () {
							if ($scope.selectedDivision) {
								service.selectedDivision = $scope.selectedDivision;
								service.selectedCompany.companyID = $scope.selectedDivision.companyID;
								service.selectedDivision.divisionID = $scope.selectedDivision.divisionID;
								$scope.displayMultiUnitpage = true;
							}
							if (currentTab == "tabMultiUnitType") {
								return "MultiUnitTypeItems.html";
								blockUI.start();
							}
						};
						$scope.loadLookupScreen = function () {
							if ($scope.selectedDivision) {
								service.selectedDivision = $scope.selectedDivision;
								service.selectedCompany.companyID = $scope.selectedDivision.companyID;
								service.selectedDivision.divisionID = $scope.selectedDivision.divisionID;
								$scope.displayLookupPage = true;
							}
							if (currentTab == "tabLookup") {
								return "lookup/Lookup.html";
								blockUI.start();
							}
						};

						///////////////////////////////////////PERISHABLES
						$scope.initialisePerishable = function (tabID) {
							service.selectedDivision = $scope.selectedDivision;
							service.selectedCompany.companyID = $scope.selectedDivision.companyID;
							service.selectedDivision.divisionID = $scope.selectedDivision.divisionID;
							document.getElementById(tabID + 'Contents').style.display = "block";
							setTimeout(function () {
								document.getElementById(tabID).click();
							}, 0);
						};
						///////////////////////////////////////PERISHABLES

						/**
						 *  Load department details
						 */



						$scope.loadDepartmentDetails = function (selectedCompanyID, selectedDivisionID) {
							var departmentNamesUrl = $scope.baseUrl + "exsrc/department/list/" + selectedCompanyID + "/" + selectedDivisionID;
							$http.get(departmentNamesUrl, config)
								.then(function (response) {
									//function handles success condition
									service.departmentDetails = response.data;
								}, function (response) {
									//function handles error condition
								});
						};

						/**
						 *  Load divisions in the dropdown
						 */

						$scope.division = function (selectedCompanyID) {
							$scope.divisions = null;
							service.selectedCompany = $scope.selectedCompany;
							var divisionUrl = $scope.baseUrl + "division/company/" + selectedCompanyID;
							$http.get(divisionUrl, config)
								.then(function (response) {
									//function handles success condition
									service.divisions = response.data;
									$scope.divisions = service.divisions;
								}, function (response) {
									//function handles error condition
								});
						};

						/**
						 *  Load departments list in override screen of HomePage
						 */
						$scope.departmentsInOverride = function (selectedCompanyID, selectedDivisionID) {
							$scope.departmentsOverride = null;
							$scope.overrideWhseUnreviewedItemsCount = 0;
							$scope.overrideDsdUnreviewedItemsCount = 0;
							$scope.overrideUnreviewedItemsCount = 0;
							$scope.overrideWhseCompletedItemsCount = 0;
							$scope.overrideDsdCompletedItemsCount = 0;
							$scope.overrideCompletedItemsCount = 0;
							service.selectedDivision = $scope.selectedDivision;
							$scope.selectedDivisionId = selectedDivisionID;
							var departmentsInOverrideUrl = $scope.baseUrl + "exsrc/listOverRideData/" + selectedCompanyID + "/" + selectedDivisionID;
							$http.get(departmentsInOverrideUrl, config)
								.then(function (response) {
									//function handles success condition
									$scope.departmentsOverride = response.data;
									for (var i = 0; i < $scope.departmentsOverride.length; i++) {
										$scope.overrideWhseUnreviewedItemsCount = $scope.overrideWhseUnreviewedItemsCount + $scope.departmentsOverride[i].totalWHSERecords;
										$scope.overrideDsdUnreviewedItemsCount = $scope.overrideDsdUnreviewedItemsCount + $scope.departmentsOverride[i].totalDSDRecords;
										$scope.overrideUnreviewedItemsCount = $scope.overrideUnreviewedItemsCount + $scope.departmentsOverride[i].totalRecord;
										$scope.overrideWhseCompletedItemsCount = $scope.overrideWhseCompletedItemsCount + $scope.departmentsOverride[i].completedWHSEItmCnt;
										$scope.overrideDsdCompletedItemsCount = $scope.overrideDsdCompletedItemsCount + $scope.departmentsOverride[i].completedDSDItmCnt;
										$scope.overrideCompletedItemsCount = $scope.overrideCompletedItemsCount + $scope.departmentsOverride[i].completedItmCnt;
									}
								}, function (response) {
									//function handles error condition
								});
						};

						/**
						 *  Load departments list in augmented screen of HomePage
						 */
						$scope.departmentsInAugmented = function (selectedCompanyID, selectedDivisionID) {
							$scope.departmentsAugmented = null;
							$scope.augmentedWhseUnreviewedItemsCount = 0;
							$scope.augmentedDsdUnreviewedItemsCount = 0;
							$scope.augmentedUnreviewedItemsCount = 0;
							$scope.augmentedWhseNeedFurtherReviewedItemsCount = 0;
							$scope.augmentedDsdNeedFurtherReviewedItemsCount = 0;
							$scope.augmentedNeedFurtherReviewedItemsCount = 0;
							$scope.augmentedWhseCompletedItemsCount = 0;
							$scope.augmentedDsdCompletedItemsCount = 0;
							$scope.augmentedCompletedItemsCount = 0;
							service.selectedDivision = $scope.selectedDivision;
							$scope.selectedDivisionId = selectedDivisionID;
							var departmentsInAugmentedUrl = $scope.baseUrl + "exsrc/listAugData/" + selectedCompanyID + "/" + selectedDivisionID;
							$http.get(departmentsInAugmentedUrl, config)
								.then(function (response) {
									//function handles success condition
									$scope.departmentsAugmented = response.data;
									for (var i = 0; i < $scope.departmentsAugmented.length; i++) {
										$scope.augmentedWhseUnreviewedItemsCount = $scope.augmentedWhseUnreviewedItemsCount + $scope.departmentsAugmented[i].totalWHSERecords;
										$scope.augmentedDsdUnreviewedItemsCount = $scope.augmentedDsdUnreviewedItemsCount + $scope.departmentsAugmented[i].totalDSDRecords;
										$scope.augmentedUnreviewedItemsCount = $scope.augmentedUnreviewedItemsCount + $scope.departmentsAugmented[i].totalRecord;
										$scope.augmentedWhseNeedFurtherReviewedItemsCount = $scope.augmentedWhseNeedFurtherReviewedItemsCount + $scope.departmentsAugmented[i].reviewWHSEItmCnt;
										$scope.augmentedDsdNeedFurtherReviewedItemsCount = $scope.augmentedDsdNeedFurtherReviewedItemsCount + $scope.departmentsAugmented[i].reviewDSDItmCnt;
										$scope.augmentedNeedFurtherReviewedItemsCount = $scope.augmentedNeedFurtherReviewedItemsCount + $scope.departmentsAugmented[i].reviewItmCnt;
										$scope.augmentedWhseCompletedItemsCount = $scope.augmentedWhseCompletedItemsCount + $scope.departmentsAugmented[i].completedWHSEItmCnt;
										$scope.augmentedDsdCompletedItemsCount = $scope.augmentedDsdCompletedItemsCount + $scope.departmentsAugmented[i].completedDSDItmCnt;
										$scope.augmentedCompletedItemsCount = $scope.augmentedCompletedItemsCount + $scope.departmentsAugmented[i].completedItmCnt;
									}
								}, function (response) {
									//function handles error condition
								});
						};

						/**
						 *  Load departments list in displayers screen of HomePage
						 */
						$scope.departmentsInDisplayer = function (selectedCompanyID, selectedDivisionID) {
							var deptName = null;
							var deptNameReplace = null;
							$scope.departmentsDisplayer = null;
							$scope.displayerWhseUnreviewedItemsCount = 0;
							$scope.displayerDsdUnreviewedItemsCount = 0;
							$scope.displayerUnreviewedItemsCount = 0;
							$scope.displayerWhseCompletedItemsCount = 0;
							$scope.displayerDsdCompletedItemsCount = 0;
							$scope.displayerCompletedItemsCount = 0;
							service.selectedDivision = $scope.selectedDivision;
							$scope.selectedDivisionId = selectedDivisionID;
							var departmentsInDisplayerUrl = $scope.baseUrl + "dsply/listDisplayerData/" + selectedCompanyID + "/" + selectedDivisionID;
							$http.get(departmentsInDisplayerUrl, config)
								.then(function (response) {
									//function handles success condition
									$scope.departmentsDisplayer = response.data;
									for (var i = 0; i < $scope.departmentsDisplayer.length; i++) {
										deptName = $scope.departmentsDisplayer[i].deptName;
										deptNameReplace = deptName.replace(/[/]/g, '');
										$scope.departmentsDisplayer[i].deptName = deptNameReplace;
										$scope.displayerWhseUnreviewedItemsCount = $scope.displayerWhseUnreviewedItemsCount + $scope.departmentsDisplayer[i].totalWHSERecords;
										$scope.displayerDsdUnreviewedItemsCount = $scope.displayerDsdUnreviewedItemsCount + $scope.departmentsDisplayer[i].totalDSDRecords;
										$scope.displayerUnreviewedItemsCount = $scope.displayerUnreviewedItemsCount + $scope.departmentsDisplayer[i].totalRecord;
										$scope.displayerWhseCompletedItemsCount = $scope.displayerWhseCompletedItemsCount + $scope.departmentsDisplayer[i].completedWHSEItmCnt;
										$scope.displayerDsdCompletedItemsCount = $scope.displayerDsdCompletedItemsCount + $scope.departmentsDisplayer[i].completedDSDItmCnt;
										$scope.displayerCompletedItemsCount = $scope.displayerCompletedItemsCount + $scope.departmentsDisplayer[i].completedItmCnt;
									}
								}, function (response) {
									//function handles error condition
								});
						};
						/**
						 * Method to open update override screen
						 */
						$scope.updateOverride2 = function (deptCode, selectedCompanyID, selectedDivisionID, status, type, count) {
							if (count == 0) {
								alertify.alert("No more item to view.");
								return;
							} else {
								$scope.i = 0;
								var updateOverrideLoadProductSkuUrl = $scope.baseUrl + "exsrc/loadProductSKUs/" + selectedCompanyID + "/" + selectedDivisionID + "/" + deptCode + "/" + 'O' + "/" + status + "/" + type;
								$http.get(updateOverrideLoadProductSkuUrl, config)
									.then(function (response) {
										//function handles success condition
										if (response.data.length == 0) {
											alertify.alert("No more item to view.");
											return;
										} else {
											localStorage.setItem("updateoverridesku", JSON.stringify(response.data));
											UpdateOverrideService.setValue($scope.i);
											UpdateOverrideService.setCompanyID(selectedCompanyID);
											UpdateOverrideService.setDivisionID(selectedDivisionID);
											$location.path('UpdateOverride');
										}
									}, function (response) {
										//function handles error condition
									});
							}
						};

						/**
						 * Method to open augmented screen
						 */
						$scope.AugmentedView = function (deptCode, selectedCompanyID, selectedDivisionID, status, type, count) {
							if (count == 0) {
								alertify.alert("No more item to view.");
								return;
							} else {
								$scope.i = 0;
								var AugmentedLoadProductSkuUrl = $scope.baseUrl + "exsrc/loadProductSKUs/" + selectedCompanyID + "/" + selectedDivisionID + "/" + deptCode + "/" + 'A' + "/" + status + "/" + type;
								$http.get(AugmentedLoadProductSkuUrl, config)
									.then(function (response) {
										//function handles success condition
										if (response.data.length == 0) {
											alertify.alert("No more item to view.");
											return;
										} else {
											localStorage.setItem("sku", JSON.stringify(response.data));
											AugmentedService.setValue($scope.i);
											AugmentedService.setCompanyID(selectedCompanyID);
											AugmentedService.setDivisionID(selectedDivisionID);
											$location.path('Augmented');
										}
									}, function (response) {
										//function handles error condition
									});
							}
						};

						/**
						 * Method to open displayers screen
						 */
						$scope.DisplayersView = function (deptName, deptCode, selectedCompanyID, selectedDivisionID, status, type, count) {
							if (count == 0) {
								alertify.alert("No more item to view.");
								return;
							} else {
								DisplayerService.setDeptName(deptName);
								DisplayerService.setDeptCode(deptCode);
								DisplayerService.setCompanyID(selectedCompanyID);
								DisplayerService.setDivisionID(selectedDivisionID);
								DisplayerService.setStatus(status);
								DisplayerService.setType(type);
								$location.path('DisplayerItems');
							}
						};

						/**
						 *  Override manual search
						 */
						$scope.UpdateOverrideManualSearch = function (UpdateOverrideProductSkuSourceUpcDropDownvalue, UpdateOverrideProductSkuSourceUpc, selectedCompanyID, selectedDivisionID) {
							if (selectedCompanyID == null || selectedDivisionID == null) {
								alertify.alert("Please select company and division.");
								return;
							} else if (UpdateOverrideProductSkuSourceUpcDropDownvalue == "" || UpdateOverrideProductSkuSourceUpcDropDownvalue == null) {
								alertify.alert("Please select Product SKU or Source UPC.");
								return;
							} else if (UpdateOverrideProductSkuSourceUpc == "" || UpdateOverrideProductSkuSourceUpc == null) {
								alertify.alert("Please enter a valid Product SKU or Source UPC.");
								return;
							} else if (UpdateOverrideProductSkuSourceUpcDropDownvalue == "updateoverridesourceupc") {
								if (UpdateOverrideProductSkuSourceUpc.length != 12 || UpdateOverrideProductSkuSourceUpc.match(/[^0-9]/)) {
									alertify.alert("Invalid Source UPC.");
									return;
								} else {
									UpdateOverrideManualSearch();
								}
							} else if (UpdateOverrideProductSkuSourceUpcDropDownvalue == "updateoverrideproductsku") {
								//		if (UpdateOverrideProductSkuSourceUpc.match(/[^0-9]/)) {
								//			alertify.alert("Invalid Product SKU.");
								//			return;
								//		} else {
								UpdateOverrideManualSearch();
								//		}
							}

							function UpdateOverrideManualSearch() {
								$scope.i = 0;
								UpdateOverrideService.setValue($scope.i);
								UpdateOverrideService.setCompanyID(selectedCompanyID);
								UpdateOverrideService.setDivisionID(selectedDivisionID);
								UpdateOverrideService.setProductSkuSourceUpcDropDownvalue(UpdateOverrideProductSkuSourceUpcDropDownvalue);
								UpdateOverrideService.setProductSkuSourceUpc(UpdateOverrideProductSkuSourceUpc);

								if (UpdateOverrideProductSkuSourceUpcDropDownvalue == "updateoverrideproductsku") {
									var UpdateOverrideLikeSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadOverrideData/" + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc;
									$http.get(UpdateOverrideLikeSrcEditDetailsUrl, config)
										.then(function (response) {
											//function handles success condition
											if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
												var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc;
												$http.get(AugmentedSrcEditDetailsUrl, config)
													.then(function (response) {
														//function handles success condition
														if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
															alertify.alert("Item details are empty for this Product SKU.");
															return;
														}
														UpdateOverrideProductSkuSourceUpcDropDownvalue = "productsku";
														$scope.i = 0;
														AugmentedService.setValue($scope.i);
														AugmentedService.setCompanyID(selectedCompanyID);
														AugmentedService.setDivisionID(selectedDivisionID);
														AugmentedService.setProductSkuSourceUpc(UpdateOverrideProductSkuSourceUpc);
														AugmentedService.setProductSkuSourceUpcDropDownvalue(UpdateOverrideProductSkuSourceUpcDropDownvalue);
														localStorage.setItem("AugmentedManualSearch", JSON.stringify(response.data));
														$location.path('Augmented');
													}, function (response) {
														//function handles error condition
													});

											} else {
												localStorage.setItem("UpdateOverrideManualSearch", JSON.stringify(response.data));
												$location.path('UpdateOverride');
											}
										}, function (response) {
											//function handles error condition
										});
								}

								if (UpdateOverrideProductSkuSourceUpcDropDownvalue == "updateoverridesourceupc") {
									var UpdateOverrideLikeSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadOverrideDataByUPC/" + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc;
									$http.get(UpdateOverrideLikeSrcEditDetailsUrl, config)
										.then(function (response) {
											//function handles success condition
											if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
												var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadDataByUpc/" + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc;
												$http.get(AugmentedSrcEditDetailsUrl, config)
													.then(function (response) {
														//function handles success condition
														if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
															alertify.alert("Item details are empty for this Source UPC.");
															return;
														}
														UpdateOverrideProductSkuSourceUpcDropDownvalue = "sourceupc";
														$scope.i = 0;
														AugmentedService.setValue($scope.i);
														AugmentedService.setCompanyID(selectedCompanyID);
														AugmentedService.setDivisionID(selectedDivisionID);
														AugmentedService.setProductSkuSourceUpc(UpdateOverrideProductSkuSourceUpc);
														AugmentedService.setProductSkuSourceUpcDropDownvalue(UpdateOverrideProductSkuSourceUpcDropDownvalue);
														localStorage.setItem("AugmentedManualSearch", JSON.stringify(response.data));
														$location.path('Augmented');
													}, function (response) {
														//function handles error condition
													});
											} else {
												localStorage.setItem("UpdateOverrideManualSearch", JSON.stringify(response.data));
												$location.path('UpdateOverride');
											}
										}, function (response) {
											//function handles error condition
										});
								}

							}
						};

						/**
						 *  Augmented screen manual search
						 */
						$scope.AugmentedManualSearch = function (ProductSkuSourceUpcDropDownvalue, ProductSkuSourceUpc, selectedCompanyID, selectedDivisionID) {
							if (selectedCompanyID == null || selectedDivisionID == null) {
								alertify.alert("Please select company and division.");
								return;
							} else if (ProductSkuSourceUpcDropDownvalue == "" || ProductSkuSourceUpcDropDownvalue == null) {
								alertify.alert("Please select Product SKU or Source UPC.");
								return;
							} else if (ProductSkuSourceUpc == "" || ProductSkuSourceUpc == null) {
								alertify.alert("Please enter a valid Product SKU or Source UPC.");
								return;
							} else if (ProductSkuSourceUpcDropDownvalue == "sourceupc") {
								if (ProductSkuSourceUpc.length != 12 || ProductSkuSourceUpc.match(/[^0-9]/)) {
									alertify.alert("Invalid Source UPC.");
									return;
								} else {
									AugmentedManualSearch();
								}
							} else if (ProductSkuSourceUpcDropDownvalue == "productsku") {
								//	if (ProductSkuSourceUpc.match(/[^0-9]/)) {
								//		alertify.alert("Invalid Product SKU.");
								//		return;
								//	} else {
								AugmentedManualSearch();
								//	}
							}

							function AugmentedManualSearch() {
								$scope.i = 0;
								AugmentedService.setValue($scope.i);
								AugmentedService.setCompanyID(selectedCompanyID);
								AugmentedService.setDivisionID(selectedDivisionID);
								AugmentedService.setProductSkuSourceUpcDropDownvalue(ProductSkuSourceUpcDropDownvalue);
								AugmentedService.setProductSkuSourceUpc(ProductSkuSourceUpc);

								if (ProductSkuSourceUpcDropDownvalue == "productsku") {
									var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadData/" + selectedCompanyID + "/" + selectedDivisionID + "/" + ProductSkuSourceUpc;
									$http.get(AugmentedSrcEditDetailsUrl, config)
										.then(function (response) {
											//function handles success condition
											if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
												var UpdateOverrideLikeSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadOverrideData/" + selectedCompanyID + "/" + selectedDivisionID + "/" + ProductSkuSourceUpc;
												$http.get(UpdateOverrideLikeSrcEditDetailsUrl, config)
													.then(function (response) {
														//function handles success condition
														if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
															alertify.alert("Item details are empty for this Product SKU.");
															return;
														}
														ProductSkuSourceUpcDropDownvalue = "updateoverrideproductsku";
														$scope.i = 0;
														UpdateOverrideService.setValue($scope.i);
														UpdateOverrideService.setCompanyID(selectedCompanyID);
														UpdateOverrideService.setDivisionID(selectedDivisionID);
														UpdateOverrideService.setProductSkuSourceUpc(ProductSkuSourceUpc);
														UpdateOverrideService.setProductSkuSourceUpcDropDownvalue(ProductSkuSourceUpcDropDownvalue);
														localStorage.setItem("UpdateOverrideManualSearch", JSON.stringify(response.data));
														$location.path('UpdateOverride');
													}, function (response) {
														//function handles error condition
													});
											} else {
												localStorage.setItem("AugmentedManualSearch", JSON.stringify(response.data));
												$location.path('Augmented');
											}
										}, function (response) {
											//function handles error condition
										});
								}

								if (ProductSkuSourceUpcDropDownvalue == "sourceupc") {
									var AugmentedSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadDataByUpc/" + selectedCompanyID + "/" + selectedDivisionID + "/" + ProductSkuSourceUpc;
									$http.get(AugmentedSrcEditDetailsUrl, config)
										.then(function (response) {
											//function handles success condition
											if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
												var UpdateOverrideLikeSrcEditDetailsUrl = $scope.baseUrl + "exsrc/loadOverrideDataByUPC/" + selectedCompanyID + "/" + selectedDivisionID + "/" + ProductSkuSourceUpc;
												$http.get(UpdateOverrideLikeSrcEditDetailsUrl, config)
													.then(function (response) {
														//function handles success condition
														if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
															alertify.alert("Item details are empty for this Source UPC.");
															return;
														}
														ProductSkuSourceUpcDropDownvalue = "updateoverridesourceupc";
														$scope.i = 0;
														UpdateOverrideService.setValue($scope.i);
														UpdateOverrideService.setCompanyID(selectedCompanyID);
														UpdateOverrideService.setDivisionID(selectedDivisionID);
														UpdateOverrideService.setProductSkuSourceUpc(ProductSkuSourceUpc);
														UpdateOverrideService.setProductSkuSourceUpcDropDownvalue(ProductSkuSourceUpcDropDownvalue);
														localStorage.setItem("UpdateOverrideManualSearch", JSON.stringify(response.data));
														$location.path('UpdateOverride');
													}, function (response) {
														//function handles error condition
													});

											} else {
												localStorage.setItem("AugmentedManualSearch", JSON.stringify(response.data));
												$location.path('Augmented');
											}
										}, function (response) {
											//function handles error condition
										});
								}
							}
						};

						/**
						 * File download to excel
						 */
						// export to excel functionality tab 1.1
						$scope.exportExelRedirect2 = function (companyId, divisionID, deptCode) {
							var redirectExcel = $scope.baseUrl + "exsrc/downloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/O/N";
							excelDownload.downloadFunc(redirectExcel,header);
							
						}
						$scope.exportExelRedirect3 = function (companyId, divisionID, deptCode) {
							var redirectExcel = $scope.baseUrl + "exsrc/downloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/O/C";
							// {{baseUrl}}exsrc/downloadExcel/{{selectedCompany.companyID}}/{{selectedDivision.divisionID}}/{{department.deptCode}}/O/C
							excelDownload.downloadFunc(redirectExcel,header);
							
								
						}
						$scope.exportExelRedirect4 = function (companyId, divisionID, deptCode) {
							var redirectExcel = $scope.baseUrl + "exsrc/downloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/A/N";
							// {{baseUrl}}exsrc/downloadExcel/{{selectedCompany.companyID}}/{{selectedDivision.divisionID}}/{{department.deptCode}}/A/N
							excelDownload.downloadFunc(redirectExcel,header);
							
						}
						$scope.exportExelRedirect5 = function (companyId, divisionID, deptCode) {
							var redirectExcel = $scope.baseUrl + "exsrc/downloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/A/R";
							// {{baseUrl}}exsrc/downloadExcel/{{selectedCompany.companyID}}/{{selectedDivision.divisionID}}/{{department.deptCode}}/A/R
							excelDownload.downloadFunc(redirectExcel,header);
							
						}
						$scope.exportExelRedirect6 = function (companyId, divisionID, deptCode) {
							var redirectExcel = $scope.baseUrl + "exsrc/downloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/A/C";
							// {{baseUrl}}exsrc/downloadExcel/{{selectedCompany.companyID}}/{{selectedDivision.divisionID}}/{{department.deptCode}}/A/C
							excelDownload.downloadFunc(redirectExcel,header);
							
						}
						$scope.exportExelRedirect7 = function (companyId, divisionID, deptCode, deptName) {
							var redirectExcel = $scope.baseUrl + "dsply/displayersDownloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/"+ deptName +"/N";
							// {{baseUrl}}dsply/displayersDownloadExcel/{{selectedCompany.companyID}}/{{selectedDivision.divisionID}}/{{department.deptCode}}/{{department.deptName}}/N
							excelDownload.downloadFunc(redirectExcel,header);
							
						}
						$scope.exportExelRedirect1 = function (companyId, divisionID, deptCode, deptName) {
							var redirectExcel = $scope.baseUrl + "dsply/displayersDownloadExcel/" + companyId + "/" + divisionID + "/" + deptCode + "/"+ deptName + "/C";
							// {{baseUrl}}dsply/displayersDownloadExcel/{{selectedCompany.companyID}}/{{selectedDivision.divisionID}}/{{department.deptCode}}/{{department.deptName}}/C
							excelDownload.downloadFunc(redirectExcel,header);
							
						}
						/**
						 *  U63178
						 *  File upload functionality
						 */
						var departmentName = "";
						var departmentCode = "";

						$scope.uploaddepartment = function (deptName, deptCode) {
							departmentName = deptName;
							departmentCode = deptCode;
						};

						$scope.popup = function (buttonValue) {
							$scope.popupErrorMsg = "";
							$scope.selectedDeptAug = null;
							document.getElementById('uploadedfile').value = "";
							if (buttonValue == "Upload") {
								$("#upload1").modal("show");
							}
						};

						$scope.uploadFile = function (deptName, deptCode) {
							var file = $scope.myFile;
							var uploadUrl = $scope.baseUrl + "exsrc/uploadFile";

							if (service.selectedCompany.companyID && service.selectedDivision.divisionID && file &&
								service.selectedDivision.divisionNm && departmentName && departmentCode && service.userId) {
								$scope.popupErrorMsg = "";
								$scope.uploadFileToUrl(file, uploadUrl, service.selectedCompany.companyID, service.selectedDivision.divisionID, service.selectedDivision.divisionNm, departmentName, departmentCode, service.userId);
							} else {
								$scope.fontColor_upload = "fontColor_WHSE";
								$scope.popupErrorMsg = "Error in uploading the file.";
							}

						};

						$scope.uploadFileToUrl = function (file, uploadUrl, companyId, divId, divName, deptName, deptCode, userId) {
							var fd = new FormData();
							var config = {
								transformRequest: angular.identity,
								headers: {
									'Content-Type': undefined
								}
							};
							fd.append('file', file);
							fd.append('companyId', companyId);
							fd.append('divisionId', divId);
							fd.append('divisionName', divName);
							fd.append('deptName', deptName);
							fd.append('deptCode', deptCode);
							fd.append('userId', userId);

							$http.post(uploadUrl, fd, config)
								.then(function (response1) {
									if (response1.data.status == "SUCCESS") {
										$scope.fontColor_upload = "fontColor_DSD";
										$scope.popupErrorMsg = "The file is being processed. You will be notified through an email when processing is complete.";
									} else if (response1.data.status == "FAILURE") {
										$scope.fontColor_upload = "fontColor_WHSE";
										$scope.popupErrorMsg = "File upload failed.";
									} else if (response1.data.status == "ERROR") {
										$scope.fontColor_upload = "fontColor_WHSE";
										$scope.popupErrorMsg = "Issues in uploading the file.";
									}
								}, function (response1) {
									//function handles error condition
									
									$scope.fontColor_upload = "fontColor_WHSE";
									$scope.popupErrorMsg = "Internal network error.";
								});

						};
					});
				});
			}
		}
	]);

})();
