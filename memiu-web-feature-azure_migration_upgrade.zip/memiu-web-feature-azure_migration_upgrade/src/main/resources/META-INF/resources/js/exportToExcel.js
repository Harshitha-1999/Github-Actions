myApp.service('excelDownload', ['$http', function($http) {

	this.downloadFunc = function(url, header) {
		
		const subKeyFilter = header.headers['Ocp-Apim-Subscription-Key'];
		const authHeader = header.headers['Authorization']
		
		config = {
			headers: {
				'Content-type': 'application/json',
				'Ocp-Apim-Subscription-Key': subKeyFilter,
				'Authorization': authHeader
			},
			responseType: 'arraybuffer'
		}
		$http.get(url, config)
			.then(function(response) {
				var headers = response.headers();
				const filename = headers['content-disposition'].split('filename=')[1];
				var blob = new Blob([response.data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
				if (window.navigator.msSaveOrOpenBlob) { // For IE:
					navigator.msSaveBlob(blob, filename);
				} else { // For other browsers:
					var link = document.createElement('a');
					link.href = window.URL.createObjectURL(blob);
					link.download = filename;
					link.click();
					window.URL.revokeObjectURL(link.href);
				}
			}, function(error) {
				console.log(error, 'excel download error');
			});
	};
}]);
