(function(){
	'use strict';
	
	myApp.service('AugmentedService', function() {
		
		var savedValue="";
		var savedCompanyID="";
		var savedDivisionID="";
		var savedProductSkuSourceUpc="";
		var savedProductSkuSourceUpcDropDownvalue="";

	    var setValue = function(value) {
	    	savedValue = value;
	    };

	    var getValue = function(){
	        return savedValue;
	    };
	    
	    var setCompanyID = function(companyid) {
	    	savedCompanyID = companyid;
	    };

	    var getCompanyID = function(){
	        return savedCompanyID;
	    };
	    
	    var setDivisionID = function(divisionid) {
	    	savedDivisionID = divisionid;
	    };

	    var getDivisionID = function(){
	        return savedDivisionID;
	    };
	    
	    var setProductSkuSourceUpc = function(productskusourceupc) {
	    	savedProductSkuSourceUpc = productskusourceupc;
	    };

	    var getProductSkuSourceUpc = function(){
	        return savedProductSkuSourceUpc;
	    };
	    
	    var setProductSkuSourceUpcDropDownvalue = function(productskusourceupcdropdownvalue) {
	    	savedProductSkuSourceUpcDropDownvalue = productskusourceupcdropdownvalue;
	    };

	    var getProductSkuSourceUpcDropDownvalue = function(){
	        return savedProductSkuSourceUpcDropDownvalue;
	    };

	    return {
	    	setValue : setValue,
	    	getValue : getValue,
	    	setCompanyID : setCompanyID,
	    	getCompanyID : getCompanyID,
	    	setDivisionID : setDivisionID,
	    	getDivisionID : getDivisionID,
	    	setProductSkuSourceUpc : setProductSkuSourceUpc,
	    	getProductSkuSourceUpc : getProductSkuSourceUpc,
	    	setProductSkuSourceUpcDropDownvalue : setProductSkuSourceUpcDropDownvalue,
	    	getProductSkuSourceUpcDropDownvalue : getProductSkuSourceUpcDropDownvalue
	    };
	});
	
})();