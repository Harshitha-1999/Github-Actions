package com.safeway.app.config;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LoadConfig {

	@Value("${spring.profiles.active}") 
	private String activeProfile;
	@Value("${service.url}") 
	private String serviceUrl;
	@Value("${service.subKey}") 
	private String subKey;
	@Value("${service.redirectMSAL}") 
	private String redirectMSAL;
	
	@Autowired
	ServletContext context;
	
	private static final Logger LOG = LoggerFactory.getLogger(LoadConfig.class);
	@PostConstruct
	public void init(){
		LOG.info("-----------------Loading Configurations----------------------------");
		try {
			LOG.info("------------ Active Profile------------------ : {}" , activeProfile);
			LOG.info("------------ Service Base URL------------------ :{}" , serviceUrl);
			LOG.info("------------ subkey ------------------ :{}" , subKey);
			LOG.info("------------ MSAL Redirect URL ------------------ :{}" , redirectMSAL);
			
			String absolutePath = context.getRealPath("/") ;
			
			PrintWriter writer = new PrintWriter(
					new File(absolutePath+"service.properties"));
			PrintWriter writer1 = new PrintWriter(
					new File(absolutePath+"SubKeyHeader.properties"));
			PrintWriter writer2 = new PrintWriter(
					new File(absolutePath+"msalRedirect.properties"));
			writer.print("");
			writer.print(serviceUrl);
			writer1.print("");
			writer1.print(subKey);
			writer2.print("");
			writer2.print(redirectMSAL);
			writer.close();
			writer1.close();
			writer2.close();
		} catch (Exception e) {
			LOG.error("Error Occurred while Loading configurations",e);
		}
	}

}
