package com.safeway.app;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
@Controller
public class MemiuWebPresentation {

	public static void main(String[] args) {
		SpringApplication.run(MemiuWebPresentation.class, args);
	}

	@GetMapping("/")
	public String home() {
		return "Index.html";
	}

	@PostConstruct
	public void init() {
		TimeZone.setDefault(TimeZone.getTimeZone("US/Mountain"));
	}

}
