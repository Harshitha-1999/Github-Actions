package com.safeway.app.health;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {
	private static final Logger LOG = LoggerFactory.getLogger(HealthController.class);

	@GetMapping("/healthCheck")
	public String health() {
		LOG.info("Request recieved for health check, Application is UP");
		return "MEMIU app is up.";
	}
}
