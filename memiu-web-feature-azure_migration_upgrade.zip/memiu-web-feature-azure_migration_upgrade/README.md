# For Local setup MEMIU -spring boot application
1. Navigate to > application.yml
    change active profile to Local
2. Navigate to > service.js
    follow the comments in underlying methods for local urls
    
# To run MSAL on Local - nodejs application
1.  Navigate to folder > msal-server in your system explorer
2.  Open powershell/cmd/bash and run command > npm install
3.  Start MSAL server with command > npm run startsrv
4.  Note - For MSAL secret values (client id and secret in .env.loc file>server folder) connect with AD team.

### launch application on browser url > http://localhost:8080/memiu-web
