java -jar /app/memiu-web-0.0.3-SNAPSHOT.jar &
cd /app && npm run buildsrv && cp -r /app/msal-server/node_modules /app/server && npm run startsrv
