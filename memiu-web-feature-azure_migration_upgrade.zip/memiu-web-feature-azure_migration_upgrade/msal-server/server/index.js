/**
 * Sample Node JS application
 */
const express = require("express");
const msal = require("@azure/msal-node");
const AlbertsonsMsal = require("@albertsons-authn/abs-node-authn");
//const testObj = require("./externalize.js")
var cookieParser = require("cookie-parser");
var path = require("path");
require("custom-env").env("loc");
// to remove dependency on dev

const SERVER_PORT = process.env.PORT || 7000;
const app = express();
app.use(cookieParser());

console.log("process.env.MEMIU_CLIENT_ID");
console.log(process.env.MEMIU_CLIENT_ID);

let SCOPE = "";
if (process.env.MEMIU_REDIRECT_URI === "https://memiu-prod.albertsons.com") {
  SCOPE = "api://az-absprodv2/memi";
} else {
  SCOPE = "api://az-absnonprodv2/memi";
}
console.log(SCOPE);
// Azure AD application configuration
const config = {
  scopes: [SCOPE],
  auth: {
    clientId: process.env.MEMIU_CLIENT_ID,
    authority: process.env.MEMIU_AUTHORITY,
    clientSecret: process.env.MEMIU_CLIENT_SECRET,
    validateAuthority: true,
    baseUri: process.env.MEMIU_REDIRECT_URI,
    redirectUri: process.env.MEMIU_REDIRECT_URI,
    postLogoutRedirectUri: process.env.MEMIU_POST_LOGOUT_REDIRECT_URI,
  },
  system: {
    loggerOptions: {
      loggerCallback(loglevel, message, containsPii) {
        console.log(message);
      },
      piiLoggingEnabled: false,
      logLevel: msal.LogLevel.Verbose,
    },
  },
};

AlbertsonsMsal.msalInitialize(config);

app.get("/loginError", (req, res) => {
  res.sendFile(path.join(__dirname + "/home.html"));
});

// requires corresponding changes for err call back in wcax
app.get("/azureAdRedirect", (req, res) => {
  try {
    console.log("in-azureAdRedirect");

    AlbertsonsMsal.msalExchangeCodeForToken(req, res, function (err) {
      //  console.log("token received in browser");
      // Once a token is obtained and msalExchangeCodeForToken() returns back to the calling handler function, the Application should redirect to desired location
      //
      // positive caseenv
      console.log("err:");
      console.log(err);
      if (err === undefined) {
        console.log("no-err: err is undefined9");
        res.redirect(process.env.BASE_URL);
      } else {
        console.log("err:" + err);
        console.log("redirectingto:" + process.env.LOGIN_ERROR_PAGE);
        res.redirect(process.env.LOGIN_ERROR_PAGE);
      }
    });
  } catch (err) {
    //error
    console.log(
      "ERROR CAUGHT: AlbertsonsMsal.msalExchangeCodeForToken:" + error
    );
    //console.log(res);
  }
});

app.get("/azurelogout", (req, res) => {
  AlbertsonsMsal.msalLogout(req, res);
});

app.get("/authenticate", (req, res) => {
  //console.log("authenticate called token  in browser");
  AlbertsonsMsal.msalCheckAuthStatus(res, req.cookies, function (authResult) {
    console.log("authResult:");
    console.log(authResult);

    console.log("in-authenticate-callback4");
    res.redirect(process.env.BASE_URL);
  });
});

app.listen(SERVER_PORT, () =>
  console.log(`APPID-MSAL-SERVER: listening on port ${SERVER_PORT}!`)
);
