#MSAL Poc on Angular JS v1.8.2, Msal-node.js library
Ref - https://confluence.safeway.com/pages/viewpage.action?spaceKey=SXP&title=RBAC+Library

## Getting Started

To get you started you can simply clone the `MSALpoc` repository and install the dependencies:

If you just want to start a new project without the `MSALpoc` commit history and MSAL server configuration then you can do:
git clone --depth=1 https://github.albertsons.com/gshar28/MSALpoc.git

## Prerequisites

1.Node.js
2.NPM
3.Vs code IDE

## Run the Application

1.npm install
2.open terminal in root of the project 
  npm start  { Client app runs on port 8000 }
3. new terminal in root of the project
  npm run startsrv { Msal server runs on port 7000 }
4. to launch the application navigate to `http://localhost:7000/authenticate` in browser

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
