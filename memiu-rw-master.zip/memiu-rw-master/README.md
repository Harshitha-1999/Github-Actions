# MEMIU-RW INSTALLATION

## Prerequisites
1. Download the env files from the email to the C:\Users\LDAPID\Downloads\env folder.
2. Copy your env files to the corresponding place server\env, and in the root directory.

### Installation
* ``` npm install ```
* ``` npm run buildsrv ```
* ```copy C:\%homepath%\Downloads\.env-loc.memi.txt .env /y```
* ```copy C:\%homepath%\Downloads\envs\.env.memi.dev.txt .\server\.env /y```
* ``` npm run build ```

#### Run Client App (port:3000)

* open new terminal window
* ``` npx serve -s -n build ```

#### Run MSAL Server (port:7000)

* open new terminal window
* cd server
* ``` npm run startsrv ```


### Test Servers: URL localhost:7000
1. First test: http://localhost:7000/loginError
2. Second test: http://localhost:3000


### Twistlock issues:  These are causing more twistlock issues

json-schema":"0.4.0"
ansi-regex:"6.0.1",
nth-check: "2.0.1"
