import React, { useEffect, useContext, useLayoutEffect } from "react";
import { RoutesView } from 'routes/routesView';
import { Environment } from "utils";
import ApplicationContext from "./context/ApplicationContext";
import axios from "axios";

function App() {
  const AppData = useContext(ApplicationContext)

  useEffect(() => {
    
    
    axios.interceptors.request.use(function (config) {
      // spinning start to show
      // console.log("Loader Spinning");
      AppData.addLoader(1);
      return config
    }, function (error) {
      return Promise.reject(error);
    });
  
    axios.interceptors.response.use(function (response) {
      // spinning hide
     // console.log("Loader Loaeded");
      AppData.addLoader(-1);
  
      return response;
    }, function (error) {
      AppData.setLoader(-1)
      //AppData.setLogStatusResult("Error")
      AppData.setLogStatus(error)
      return Promise.reject(error);
    });
    document.title = Environment.getReactAppTitle()
  }, []);
  return (
    <>
      <RoutesView />
    </>
  );
}

export default App;