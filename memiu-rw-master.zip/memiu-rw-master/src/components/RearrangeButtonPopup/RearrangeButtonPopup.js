import React, { useContext, useEffect, useRef, useState } from 'react'
import { Shuffle } from '@material-ui/icons'
import ButtonMemi from 'components/ButtonMemi/ButtonMemi'
import ModalPopup from 'components/ModalPopup/ModalPopup';
import { authTokenCookie } from 'utils';
import ApplicationContext from 'context/ApplicationContext';
import { memiuServices } from 'api/memiu/memiuService';

export default function RearrangeButtonPopup(props) {
    const [open, setOpen] = useState(false);
    const { additionalFields, viewableFields } = props;
    const AppData = useContext(ApplicationContext)
    // console.log(additionalFields, viewableFields)
    const [draggedIndex, setDraggedIndex] = useState(null)
    const [draggedType, setDraggedType] = useState(null)
    const [draggedId, setDraggedId] = useState(null)


    //For css hover effect
    const [draggedOverId, setDraggedOverId] = useState("");
    const [counter, setCounter] = useState(0)


    useEffect(() => {
        setDraggedId(null)
        setDraggedIndex(null)
        setDraggedType(null)

    }, [])

    const handleSubmit = () => {
        const { userId } = authTokenCookie()
        let returnList = {};
        returnList.columnList = AppData.memi06.customVO.columnList;
        returnList.availableList = AppData.memi06.customVO.availableList;
        returnList.userId = userId

        memiuServices.postSaveColumnCustomization(returnList)
            .finally(() => {
                setOpen(false);
            })
    }

    const handleDragStart = (index, type, id) => {
        setDraggedIndex(index);
        setDraggedType(type);
        setDraggedId(id)

        //set Counter to prevent removing run onDragLeave by child Elements
        setCounter((count) => { return count + 1 });
        const element = document.getElementById(id);
        setTimeout(() => element.classList.add("listDisplayNone"), 0)
    }

    const handleDrop = (droppedIndex, type) => {
        showHiddenDraggedId();
        setDraggedOverId("")
        setCounter(0)
        const getNewList = (list) => {
            let tempList = [];
            if (droppedIndex === list.length) {
                list.forEach((listItem, index) => {
                    if (index !== draggedIndex) {
                        tempList.push(listItem);
                    }
                })
                tempList.push(list[draggedIndex])
                return tempList
            }
            else if (droppedIndex < draggedIndex) {
                list.forEach((data, index) => {
                    // console.log(data, index)
                    if (index === draggedIndex) {
                        return;
                    }
                    else if (index < droppedIndex || index > draggedIndex) {
                        tempList.push(data)
                    }
                    else if (index === droppedIndex) {
                        tempList.push(list[draggedIndex])
                        tempList.push(list[droppedIndex])
                    }
                    else {
                        tempList.push(list[index])
                    }

                })

            }
            else {
                list.forEach((data, index) => {
                    // console.log(data,index)
                    if (index === draggedIndex) {
                        return;
                    }
                    else if (index > droppedIndex || index < draggedIndex) {
                        tempList.push(data)
                    }
                    else if (index === droppedIndex) {
                        tempList.push(list[draggedIndex])
                        tempList.push(list[droppedIndex])
                    }
                    else {
                        tempList.push(list[index])
                    }

                })
            }
            return tempList
        }
        if (type === draggedType) {
            if (type === "viewableField") {
                props.onChangeFields(additionalFields, getNewList(viewableFields))
            }
            else {
                props.onChangeFields(getNewList(additionalFields), viewableFields)
            }
        } else {
            if (type === "viewableField") {
                let additionalList = additionalFields.filter((field) => { return field.id !== draggedId })
                let viewableList = []
                for (let i = 0; i < viewableFields.length; i++) {
                    if (droppedIndex === i) {
                        viewableList.push(additionalFields[draggedIndex]);
                    }
                    viewableList.push(viewableFields[i])
                }
                if (droppedIndex === viewableList.length) {
                    viewableList.push(additionalFields[draggedIndex])
                }
                props.onChangeFields(additionalList, viewableList)
            } else if (type === "additionalField") {
                let viewableList = viewableFields.filter((field) => { return field.id !== draggedId })
                let additionalList = []
                for (let i = 0; i < additionalFields.length; i++) {
                    if (droppedIndex === i) {
                        additionalList.push(viewableFields[draggedIndex]);
                    }
                    additionalList.push(additionalFields[i])
                }
                if (droppedIndex === additionalList.length) {
                    additionalList.push(viewableFields[draggedIndex])
                }
                props.onChangeFields(additionalList, viewableList)

            }

        }
    }

    const handleDragOver = (e, id) => {
        e.preventDefault();
        setDraggedOverId(id);
    }

    const handleDragLeave = () => {
        setCounter((count) => { return count - 1 })
        if (counter <= 0) {
            setCounter(0)
            setDraggedOverId("");
        }
    }

    const showHiddenDraggedId = () => {
        const element = document.getElementById(draggedId);
        element.classList.remove("listDisplayNone")
    }

    const popupContent = (
        <div style={{ display: "flex" }}>
            <div className="rearrangePopupAdditionalField">
                <div style={{ backgroundColor: "lightgray", padding: "8px", color: "grey", fontWeight: 800 }}>
                    Additional Fields
                </div>
                <div style={{ padding: "0px 8px" }} onDragLeave={handleDragLeave}>
                    {

                        additionalFields ? additionalFields.map((data, index) => (
                            <div
                                id={data.id}
                                className={`listSortBy ${data.id === draggedOverId ? "listSortByDraggedOver" : ""}`}
                                // onClick={() => handleSelect(index)}
                                draggable={true}
                                onDrop={(e) => handleDrop(index, "additionalField", data.id)}
                                onDragStart={(e) => handleDragStart(index, "additionalField", data.id)}
                                onDragOver={(e) => handleDragOver(e, data.id)}
                                style={{ color: data.product }}
                                onDragEnd={showHiddenDraggedId}
                            >
                                {data.label}
                            </div>
                        )) : ""
                    }
                    {
                        <div
                            id={"blank-additional"}
                            className={`listSortBy ${draggedOverId === "blank-additional" ? "listSortByDraggedOver" : ""}`}
                            // onClick={() => handleSelect(index)}
                            onDrop={(e) => handleDrop(additionalFields.length, "additionalField", null)}
                            onDragOver={(e) => handleDragOver(e, "blank-additional")}
                        // style={{ color: data.product }}
                        // onDragEnd={showHiddenDraggedId}
                        >
                            { }
                        </div>
                    }

                </div>
            </div>
            <div style={{ width: "4%" }}> </div>
            <div className="rearrangePopupViewableField">
                <div style={{ backgroundColor: "rgb(221 241 216)", padding: "10px", color: "green", fontWeight: 600 }}>
                    Viewable Fields
                </div>
                <div style={{ padding: "0px 10px" }} onDragLeave={handleDragLeave}>
                    {
                        viewableFields ?
                            viewableFields.map((data, index) => (
                                <div
                                    id={data.id}
                                    className={`listSortBy viewableField ${data.id === draggedOverId ? "listSortByDraggedOver" : ""}`}
                                    // onClick={() => handleSelect(index)}
                                    draggable={true}
                                    onDrop={(e) => handleDrop(index, "viewableField", data.id)}
                                    onDragStart={(e) => handleDragStart(index, "viewableField", data.id)}
                                    onDragOver={(e) => handleDragOver(e, data.id)}
                                    style={{ color: data.product }}
                                    onDragEnd={showHiddenDraggedId}
                                >
                                    {data.label}
                                </div>
                            )) : ""
                    }
                    {
                        <div
                            id={"blank-viewable"}
                            className={`listSortBy ${draggedOverId === "blank-viewable" ? "listSortByDraggedOver" : ""}`}
                            // onClick={() => handleSelect(index)}
                            onDrop={(e) => handleDrop(viewableFields.length, "viewableField", null)}
                            onDragOver={(e) => handleDragOver(e, "blank-viewable")}
                        // style={{ color: data.product }}
                        // onDragEnd={showHiddenDraggedId}
                        >
                            { }
                        </div>
                    }

                </div>
            </div>
        </div>
    )
    return (
        <>
            <ButtonMemi
                btnval="Rearrange"
                startIcon={<Shuffle />}
                classNameMemi="lookUpRearrangeButton"
                onClick={() => setOpen(true)}
            />
            <ModalPopup
                classNameMemi="rearrangPopupClass"
                open={open}
                fullWidth
                popupTitle={
                    <div style={{ display: "flex", fontSize: "12px" }}>
                        <span style={{ fontWeight: "700" }}>
                            Drag & Drop (From Left to Right), ReOrder Column
                        </span>
                        <span style={{ backgroundColor: "#04a6d6", width: "15px", height: "15px", marginLeft: "auto", color: "grey" }}>
                        </span>
                        <span style={{ color: "grey" }}>-Source</span> &nbsp;
                        <span style={{ backgroundColor: "#ca6b09", width: "15px", height: "15px" }}>
                        </span>
                        <span style={{ color: "grey" }}>-Target</span>
                    </div>
                }
                popupContent={popupContent}
                popupTitleClass="rearrangePopupTitle"
                popupContentClass="rearrangePopupContent"
                popupActions={

                    <>
                        <ButtonMemi
                            btnval="Done"
                            classNameMemi="MultiUnitScreenButton"
                            onClick={handleSubmit}
                            btnvariant={"contained"}
                            btnsize="sm"
                        />
                    </>
                }
            />
        </>
    )
}
