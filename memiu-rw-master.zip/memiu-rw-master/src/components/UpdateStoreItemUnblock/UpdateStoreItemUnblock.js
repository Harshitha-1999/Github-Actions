import React, { useState } from "react";
import TableMemi from "../../components/TableMemi/TableMemi";
import { Grid } from "@material-ui/core";
import Box from "@mui/material/Box";
import ButtonMemi from "../../components/ButtonMemi/ButtonMemi";
import TextAreaAutosizeMemi from "components/TextAreaAutosizeMemi/TextAreaAutosizeMemi";

function UpdateStoreItemUnblock() {
  const [textArea, setTextAreaVal] = useState("");
  let updateTableData = [
    {
      id: 1,
      Apply: "",
      DV: 5,
      Store: 1585,
      Category: "0901-Salty Bagged Canister Snacks",
    },
  ];
  let columnsUnblockTable = [
    {
      field: "Apply",
      headerName: "Apply",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "DV",
      headerName: "DV",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Store",
      headerName: "Store",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Category",
      headerName: "Category",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "UPC",
      headerName: "UPC",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "CIC",
      headerName: "CIC",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Discription",
      headerName: "Discription",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss",
    },
    {
      field: "Size",
      headerName: "Size",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "UOM",
      headerName: "UOM",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Case Pk",
      headerName: "Case Pk",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "State",
      headerName: "State",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "State Effective Date",
      headerName: "State Effective Date",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Delete Date",
      headerName: "Delete Date",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
    {
      field: "Last Updated User",
      headerName: "Last Updated User",
      sortable: false,
      flex: 0.3,
      headerAlign: "center",
      headerClassName: "headerCss"
    },
  ];
  return (
    <Grid container>
      <Grid item xs={12}>
        <Box sx={{ display: "flex", justifyContent: "space-between", margin: 1 }}>
          <div>
            <ButtonMemi btnval={"Unblock"} idCss="buttonMEUP"></ButtonMemi>
          </div>
          <div className="labelSpace">
            <TextAreaAutosizeMemi
              alignItems="row"
              value={textArea}
              setTextValue={(value) => setTextAreaVal(value)}
              label="Enter Comments*"
              LabelClass=""
            ></TextAreaAutosizeMemi>
          </div>
        </Box>

        <TableMemi
          data={updateTableData}
          selectionType="checkbox"
          columns={columnsUnblockTable}
          classnameMemi="tableBlockedItem"
          showCellRightBorder={true}
          showColumnRightBorder={true}
          hideFooter={true}
          hideFooterPagination={true}
          hideFooterSelectedRowCount={true}
        />
      </Grid>
    </Grid>
  );
}

export default UpdateStoreItemUnblock;
