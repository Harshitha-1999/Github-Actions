import React from 'react';

function ErrorListMeup(props) {
    return (
        <div>
            {
                props.errors.map((error, index) => (
                    <div key={index} style={{ color: "red", fontSize: "small", marginTop: "15px" }}> {error} </div>
                ))
            }
        </div>
    )
}

export default ErrorListMeup;