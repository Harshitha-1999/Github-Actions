import React, { useState, useEffect } from 'react'
import { Grid } from '@material-ui/core';
import { meupServices } from "../../api/meup/meupServices";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { useHistory } from 'react-router';
import { RouteBase } from "routes/constants";
import ListSelectMeup from "components/ListSelectMeup/ListSelectMeup";
function StoreItemsOnHoldSearch(props) {

    const history = useHistory();
    const [divisions, setDivisions] = useState([]);
    const [selectedDivisions, setSelectedDivisions] = useState([]);
    const [stockingSections, setStockingSections] = useState([]);
    const [selectedStockingSections, setSelectedStockingSections] = useState([]);

    useEffect(() => {

        meupServices
            .getDivisions()
            .then((res) => {
                let data = res.data.map((x) => {
                    return { label: x.dispDivision, value: x.divisionNumber };
                });
                setDivisions(data);
            })
            .catch((error) => {
                setDivisions([]);
            });

        meupServices
            .getStockingSections()
            .then((res) => {
                let data = res.data.map((x) => {
                    return { label: x.dispDivision, value: x.divisionNumber };
                });
                setStockingSections(data);
            })
            .catch((error) => {
                setStockingSections([]);
            });


    }, []);
    return (
        <Grid container>
            <Grid item xs={12}>
                <div
                    style={{
                        backgroundColor: "#CFC3AD",
                        // width: "fit-content",
                        padding: "0.5rem 1rem 0rem 1rem",
                        height: "1.5rem",
                    }}
                >
                    <strong> Enter Items On Hold - Search </strong>
                </div>
                <div
                    style={{ border: "1px solid", width: "55rem" }}
                    className="blockItemsMarginTop"
                >

                    <div className="storeItemsInnerDiv">
                        <ListSelectMeup
                            label="Stocking Section"
                            LabelClass="labelClassStoreItems"
                            options={divisions}
                            value={selectedDivisions}
                            setValue={(value) => setSelectedDivisions(value)}
                            alignItems="row"
                            classNameMeup="listStoreItems"
                            selectAll
                        />
                    </div>
                    <div className="storeItemsInnerDiv">
                        <ListSelectMeup
                            label="Division"
                            LabelClass="labelClassStoreItems"
                            options={stockingSections}
                            value={selectedStockingSections}
                            setValue={(value) => setSelectedStockingSections(value)}
                            alignItems="row"
                            classNameMeup="listStoreItems"
                            selectAll
                        />
                    </div>


                </div>
            </Grid>
            <Grid
                item
                xs={12}
                className="blockItemsMarginTop"
                style={{ marginBottom: "3rem" }}
            >


                <ButtonMemi
                    btnval="Review"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    onClick={() => {

                    }}
                />

                <ButtonMemi
                    btnval="Cancel"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => {
                        history.push(RouteBase.MEUP50);
                    }}
                />
            </Grid>
        </Grid>
    )
}

export default StoreItemsOnHoldSearch;
