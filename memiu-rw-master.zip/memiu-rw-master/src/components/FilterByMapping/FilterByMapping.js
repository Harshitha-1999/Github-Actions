import React, { useContext, useState, useEffect, useMemo } from 'react'
import { Autorenew, FilterList, Check, Close } from '@material-ui/icons'
import { Popper, Grid, ClickAwayListener } from '@material-ui/core';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import ApplicationContext from ".../../context/ApplicationContext";
import TextFieldMemi from 'components/TextField/TextFieldMemi';
import DropDownMemi from '../DropDownMemi/DropDownMemi';
export default function FilterByMapping(props) {
    const [anchorEl, setAnchorEl] = useState(null);
    const AppData = useContext(ApplicationContext);

    const { filterCriteria } = props
    const [department, setDepartment] = useState("")
    const [productSku, setProductSku] = useState("")
    const [itemDescription, setItemDescription] = useState("");
    const [supplierNum, setSupplierNum] = useState("");
    const [supplierName, setSupplierName] = useState("");
    const [slu, setSlu] = useState("");
    const [hierachyLevel1, setHierachyLevel1] = useState("");
    const [hierachyLevel2, setHierachyLevel2] = useState("");
    const [hierachyLevel3, setHierachyLevel3] = useState("");
    const [plu, setPlu] = useState("");
    const [upc, setUpc] = useState("");
    const [shipment, setShipment] = useState("");
    const [usageInd, setUsageInd] = useState("");
    const [totalSales, setTotalSales] = useState("");
    const [sales, setSales] = useState("");
    const [corpItemCode, setCorpItemCode] = useState("");
    const [vendorCode, setVendorCode] = useState("");
    const [vendorName, setVendorName] = useState("");
    const [usageType, setUsageType] = useState("");
    const [vendorOrderCode, setVendorOrderCode] = useState("");
    const [numSys, setNumSys] = useState("");
    const [country, setCountry] = useState("");
    const [manuf, setManuf] = useState("");
    const [upcItem, setUpcItem] = useState("");
    const [group, setGroup] = useState("");
    const [category, setCategory] = useState("")
    const [classSmic, setClassSmic] = useState("");
    const [subClass, setSubClass] = useState("");
    const [subSubClass, setSubSubClass] = useState("");
    const handleApply = () => {

        let filterCriteria = {};
        let count = 0

        //method to set the Shipment in source filter
        if (shipment == "Y" || shipment == "N") {
            filterCriteria.shipped = true;
            filterCriteria.shipSearchValue = shipment;
        }

        //method to set the Usage Ind in source filter
        if (sales == "GREATER_THAN" || sales == "LESS_THAN" || sales == "EQUALS") {
            filterCriteria.totalSalesFilter = true;
            filterCriteria.totalSalesOperator = sales;
        }
        //method to set the Usage Ind in source filter
        if (usageInd !== "") {
            filterCriteria.usageTypeIndFilter = true;
            filterCriteria.usageTypeInd = usageInd;
        }

        if (department !== "") {
            filterCriteria.department = department
        }

        if (corpItemCode !== "") {
            filterCriteria.corpItemCD = corpItemCode
        }

        if (productSku !== "") {
            filterCriteria.productSKU = productSku
        }

        if (itemDescription !== "") {
            filterCriteria.itemDescription = itemDescription;
        }

        if (supplierNum !== "") {
            filterCriteria.supplierNum = supplierNum;
        }

        if (supplierName !== "") {
            filterCriteria.supplierName = supplierName;
        }
        if (slu !== "") {
            filterCriteria.slu = slu;
        }
        if (hierachyLevel1 !== "") {
            filterCriteria.prodhierarchyLevel1 = hierachyLevel1
        }
        if (hierachyLevel2 !== "") {
            filterCriteria.prodhierarchyLevel2 = hierachyLevel2

        }
        if (hierachyLevel3 !== "") {
            filterCriteria.prodhierarchyLevel3 = hierachyLevel3
        }
        if (plu !== "") {
            filterCriteria.plu = plu
        }
        if (upc !== "") {
            filterCriteria.upc = upc
        }
        if (totalSales !== "") {
            filterCriteria.totalSalesvalue = totalSales
        }
        if (group !== "") {
            filterCriteria.smicGroupCd = group;
        }
        if (category !== "") {
            filterCriteria.smicCtgryCd = category;
        }
        if (classSmic !== "") {
            filterCriteria.smicClassCd = classSmic;
        }
        if (subClass !== "") {
            filterCriteria.smicSubClassCd = subClass;
        }
        if (subSubClass !== "") {
            filterCriteria.smicSubSubClassCd = subSubClass;
        }
        if (vendorOrderCode === "") {
            filterCriteria.vendUpcPackInd = null;
            count = count + 1;
        }
        else {
            filterCriteria.vendUpcPackInd = vendorOrderCode;
        }
        if (country === "") {
            filterCriteria.vendUpcCountry = null;
            count = count + 1;
        }
        else {
            filterCriteria.vendUpcCountry = country;
        }
        if (numSys === "") {
            filterCriteria.vendUpcNumSys = null;
            count = count + 1;
        }
        else {
            filterCriteria.vendUpcNumSys = numSys;
        }
        if (manuf === "") {
            filterCriteria.vendUpcManuf = null;
            count = count + 1;
        }
        else {
            filterCriteria.vendUpcManuf = manuf;
        }
        if (upcItem === "") {
            filterCriteria.vendUpcItem = null;
            count = count + 1;
        }
        else {
            filterCriteria.vendUpcItem = upcItem
        }
        if (count === 5) {
            filterCriteria.vendorOrderFilter = false;
        }
        else {
            filterCriteria.vendorOrderFilter = true;
        }

        const isValidFilter = Object.values(filterCriteria).filter((value) => { return value }).length > 0;
        if (isValidFilter) {
            props.onClickApply(filterCriteria);
        }
        else {
            props.onClickApply(null);
        }


        setAnchorEl(null)
    }

    const handleReset = () => {
        setDepartment("")
        setProductSku("")
        setItemDescription("");
        setSupplierNum("");
        setSupplierName("");
        setSlu("");
        setHierachyLevel1("");
        setHierachyLevel2("");
        setHierachyLevel3("");
        setPlu("");
        setUpc("");
        setShipment("");
        setUsageInd("");
        setTotalSales("");
        setSales("");
        setCorpItemCode("");
        setVendorCode("");
        setVendorName("");
        setUsageType("");
        setVendorOrderCode("");
        setNumSys("");
        setCountry("");
        setManuf("");
        setUpcItem("");
        setGroup("");
        setCategory("")
        setClassSmic("");
        setSubClass("");
        setSubSubClass("");
        props.onClickApply(null)
    }

    const active = useMemo(() => {
        
        return !(filterCriteria === null) && Object.values(filterCriteria).filter((value) => { return value }).length > 0;
    }, [filterCriteria])

    const handleCancel = () => {
        if (!active) {
            handleReset()
        }
        setAnchorEl(false);
    }

    const open = Boolean(anchorEl);
    const id = open ? 'simple-popper' : undefined;
    const handleClick = (event) => {
        setAnchorEl(anchorEl ? null : event.currentTarget);
    };

    useEffect(() => {
        setDepartment(filterCriteria ? filterCriteria.department : "")
        setProductSku(filterCriteria ? filterCriteria.productSKU : "")
        setItemDescription(filterCriteria ? filterCriteria.itemDescription : "");
        setSupplierNum(filterCriteria ? filterCriteria.supplierNum : "");
        setSupplierName(filterCriteria ? filterCriteria.supplierName : "");
        setSlu(filterCriteria ? filterCriteria.slu : "");
        setHierachyLevel1(filterCriteria ? filterCriteria.prodhierarchyLevel1 : "");
        setHierachyLevel2(filterCriteria ? filterCriteria.prodhierarchyLevel2 : "");
        setHierachyLevel3(filterCriteria ? filterCriteria.prodhierarchyLevel3 : "");
        setPlu(filterCriteria ? filterCriteria.plu : "");
        setUpc(filterCriteria ? filterCriteria.upc : "");
        setShipment(filterCriteria ? filterCriteria.shipSearchValue : "");
        setUsageInd(filterCriteria ? filterCriteria.usageTypeInd : "");
        setTotalSales(filterCriteria ? filterCriteria.totalSalesvalue : "");
        setSales(filterCriteria ? filterCriteria.totalSalesOperator : "");
        setCorpItemCode(filterCriteria ? filterCriteria.corpItemCD : "");
        setVendorCode("");
        // setVendorName("");
        setUsageType(filterCriteria ? filterCriteria.usageTypeInd : "");
        setVendorOrderCode(filterCriteria ? filterCriteria.vendUpcPackInd : "");
        setNumSys(filterCriteria ? filterCriteria.vendUpcNumSys : "");
        setCountry(filterCriteria ? filterCriteria.vendUpcCountry : "");
        setManuf(filterCriteria ? filterCriteria.vendUpcManuf : "");
        setUpcItem(filterCriteria ? filterCriteria.vendUpcItem : "");
        setGroup(filterCriteria ? filterCriteria.smicGroupCd : "");
        setCategory(filterCriteria ? filterCriteria.smicCtgryCd : "")
        setClassSmic(filterCriteria ? filterCriteria.smicClassCd : "");
        setSubClass(filterCriteria ? filterCriteria.smicSubClassCd : "");
        setSubSubClass(filterCriteria ? filterCriteria.smicSubSubClassCd : "");
    }, [filterCriteria])

    const cic = (
        <Grid container>
            <Grid item xs={4} className="lookUpMenuPadding ">
                <DropDownMemi
                    value={department}
                    setValue={(value) => setDepartment(value)}
                    label="Department"
                    alignItems="columns"
                    DropDownClass="lookUpMenuDropdown"
                    LabelClass="filterByLabel"
                    options={AppData.listDepartmentTarget}
                    fullWidth={true}
                    errorText=""
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={corpItemCode}
                    setTextValue={(value) => setCorpItemCode(value)}
                    label="Corp Item Code"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Corp Item Code"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={plu}
                    setTextValue={(value) => setPlu(value)}
                    label="PLU"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="PLU"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={upc}
                    setTextValue={(value) => setUpc(value)}
                    label="UPC"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="UPC"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={itemDescription}
                    setTextValue={(value) => setItemDescription(value)}
                    label="Item Description"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Item Descriprtion"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <DropDownMemi
                    value={usageInd}
                    setValue={(value) => setUsageInd(value)}
                    label="Usage Ind"
                    alignItems="columns"
                    DropDownClass="lookUpMenuDropdown"
                    LabelClass="filterByLabel"
                    options={[{ label: "Resale", value: "R" }, { label: "Material", value: "M" }, { label: "Expense", value: "E" }]}
                    fullWidth={true}
                    errorText=""
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={vendorCode}
                    setTextValue={(value) => setVendorCode(value)}
                    label="Vendor Code"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Vendor Code"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={vendorName}
                    setTextValue={(value) => setVendorName(value)}
                    alignItems="columns"
                    label="Vendor Name"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Vendor Name"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <DropDownMemi
                    value={usageType}
                    setValue={(value) => setUsageType(value)}
                    label="Usage Type"
                    alignItems="columns"
                    DropDownClass="lookUpMenuDropdown"
                    LabelClass="filterByLabel"
                    options={[{ label: "W", value: "W" },
                    { label: "R", value: "R" },
                    { label: "P", value: "P" },
                    { label: "M", value: "M" },
                    { label: "C", value: "C" },
                    { label: "O", value: "O" },
                    { label: "S", value: "S" },
                    { label: "L", value: "L" }
                    ]}
                    fullWidth={true}
                    errorText=""
                />
            </Grid>
            <Grid item xs={3} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={vendorOrderCode}
                    setTextValue={(value) => setVendorOrderCode(value)}
                    label="Vendor Order Code"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Vendor Order Code"
                />
            </Grid>
            <Grid item xs={2} style={{ paddingLeft: "15px" }}>
                <TextFieldMemi
                    value={country}
                    setTextValue={(value) => setCountry(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Country"
                />
            </Grid>
            <Grid item xs={2} style={{ paddingLeft: "15px" }}>
                <TextFieldMemi
                    value={numSys}
                    setTextValue={(value) => setNumSys(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="NumSys"
                />
            </Grid>
            <Grid item xs={2} style={{ paddingLeft: "15px" }}>
                <TextFieldMemi
                    value={manuf}
                    setTextValue={(value) => setManuf(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Manuf"
                />
            </Grid>
            <Grid item xs={3} style={{ paddingLeft: "15px", paddingRight: "15px" }}>
                <TextFieldMemi
                    value={upcItem}
                    setTextValue={(value) => setUpcItem(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="UPCItem"
                />
            </Grid>
            <Grid item xs={8} className="lookUpMenuPadding " style={{ display: "flex" }}>
                <TextFieldMemi
                    value={group}
                    setTextValue={(value) => setGroup(value)}
                    alignItems="columns"
                    label="SMIC"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Group"
                    title="Group"
                    type="number"
                    min={0}
                    max={99}
                />
                &nbsp;&nbsp;

                <TextFieldMemi
                    value={category}
                    setTextValue={(value) => setCategory(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Category"
                    title="Category"
                    type="number"
                    min={0}
                    max={99}
                />
                &nbsp;&nbsp;
                <TextFieldMemi
                    value={classSmic}
                    setTextValue={(value) => setClassSmic(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Class"
                    title="Class"
                    type="number"
                    min={0}
                    max={99}

                />
                &nbsp;&nbsp;
                <TextFieldMemi
                    value={subClass}
                    setTextValue={(value) => setSubClass(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Sub Class"
                    title="Sub Class"
                    type="number"
                    min={0}
                    max={99}

                />
                &nbsp;&nbsp;
                <TextFieldMemi
                    value={subSubClass}
                    setTextValue={(value) => setSubSubClass(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Group"
                    title="Sub Sub Class"
                    type="number"
                    min={0}
                    max={99}

                />
            </Grid>


            <Grid item xs={4} style={{ paddingLeft: "15px", marginTop: "13px" }}>

                <ButtonMemi
                    btnval={<> <Check className="lookUpIcon" /> Apply </>}
                    classNameMemi="lookUpScreenButton filterByApplyButton"
                    btnsize="small"
                    onClick={handleApply}

                /> &nbsp;
                <ButtonMemi
                    btnval={<><Close className="lookUpIcon" /> Cancel</>}
                    classNameMemi="lookUpScreenButton lookUpResetButton"
                    btnsize="small"
                    onClick={handleCancel}

                />

            </Grid>


        </Grid>

    )
    const sku = (
        <Grid container>
            <Grid item xs={4} className="lookUpMenuPadding ">
                {props.bakery == true ?
                    <TextFieldMemi
                        value={"BAKERY"}
                        setValue={(value) => setDepartment(value)}
                        label="Department"
                        alignItems="columns"
                        TextFieldClass="lookUpMenuTextField"
                        LabelClass="filterByLabel"
                        placeholder="Department"
                        disabled="true"
                    /> :
                    <DropDownMemi
                        value={department}
                        setValue={(value) => setDepartment(value)}
                        label="Department"
                        alignItems="columns"
                        DropDownClass="lookUpMenuDropdown"
                        LabelClass="filterByLabel"

                        //{props.departmentMappingValue}
                        options={AppData.listDepartmentSource}
                        fullWidth={true}
                        errorText=""
                    />
                }
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={productSku}
                    setTextValue={(value) => setProductSku(value)}
                    label="Product SKU"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Product SKU"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={itemDescription}
                    setTextValue={(value) => setItemDescription(value)}
                    label="Item Description"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Item Descriprtion"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={supplierNum}
                    setTextValue={(value) => setSupplierNum(value)}
                    label="Supplier Num"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Supplier Num"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={supplierName}
                    setTextValue={(value) => setSupplierName(value)}
                    label="Supplier Name"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Supplier Name"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={slu}
                    setTextValue={(value) => setSlu(value)}
                    label="SLU"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="SLU"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={hierachyLevel1}
                    setTextValue={(value) => setHierachyLevel1(value)}
                    label="Hierachy Level"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Level 1"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={hierachyLevel2}
                    setTextValue={(value) => setHierachyLevel2(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Level 2"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={hierachyLevel3}
                    setTextValue={(value) => setHierachyLevel3(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Level 3"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding">
                <TextFieldMemi
                    value={plu}
                    setTextValue={(value) => setPlu(value)}
                    label="PLU"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="PLU"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding ">
                <TextFieldMemi
                    value={upc}
                    setTextValue={(value) => setUpc(value)}
                    label="UPC"
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="UPC"
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding ">
                <DropDownMemi
                    value={shipment}
                    setValue={(value) => setShipment(value)}
                    label="Shipment"
                    alignItems="columns"
                    DropDownClass="lookUpMenuDropdown"
                    LabelClass="filterByLabel"
                    options={[{ label: "Yes", value: "Y" }, { label: "No", value: "N" }]}
                    fullWidth={true}
                    errorText=""
                />
            </Grid>
            <Grid item xs={4} className="lookUpMenuPadding ">
                <DropDownMemi
                    value={usageInd}
                    setValue={(value) => setUsageInd(value)}
                    label="Usage Ind"
                    alignItems="columns"
                    DropDownClass="lookUpMenuDropdown"
                    LabelClass="filterByLabel"
                    options={[{ label: "Resale", value: "R" }, { label: "Material", value: "M" }, { label: "Expense", value: "E" }]}
                    fullWidth={true}
                    errorText=""
                />
            </Grid>
            <Grid item xs={2} style={{ paddingLeft: "15px" }}>
                <DropDownMemi
                    value={sales}
                    setValue={(value) => setSales(value)}
                    label="Total Sales"
                    alignItems="columns"
                    DropDownClass="lookUpMenuDropdown"
                    LabelClass="filterByLabel"
                    options={[{ label: "< Greater Than", value: "GREATER_THAN" }, { label: "> Lesser Than", value: "LESS_THAN" }, { label: "= Equals", value: "EQUALS" }]}
                    fullWidth={true}
                    errorText=""
                />
            </Grid>
            <Grid item xs={2} style={{ paddingRight: "15px" }} >
                <TextFieldMemi
                    value={totalSales}
                    setTextValue={(value) => setTotalSales(value)}
                    alignItems="columns"
                    TextFieldClass="lookUpMenuTextField"
                    LabelClass="filterByLabel"
                    placeholder="Sales"
                />
            </Grid>

            <Grid item xs={4} style={{ paddingLeft: "15px", marginTop: "13px" }}>

                <ButtonMemi
                    btnval={<> <Check className="lookUpIcon" /> Apply </>}
                    classNameMemi="lookUpScreenButton filterByApplyButton"
                    btnsize="small"
                    onClick={handleApply}

                /> &nbsp;
                <ButtonMemi
                    btnval={<><Close className="lookUpIcon" /> Cancel</>}
                    classNameMemi="lookUpScreenButton lookUpResetButton"
                    btnsize="small"
                    onClick={handleCancel}

                />

            </Grid>


        </Grid>

    )

    return (
        <ClickAwayListener onClickAway={() => setAnchorEl(null)}>
            <div style={props.style}>
                <ButtonMemi
                    btnval="Filter By"
                    classNameMemi={props.ButtonClass}
                    endIcon={<FilterList style={{ color: active ? "red" : "" }} />}
                    btnsize={props.btnsize}
                    onClick={handleClick}
                />
                <Popper id={id} open={open} anchorEl={anchorEl} className={props.sortByClass} placement={props.placement} style={{ marginRight: "5px", zIndex: "1000" }}>
                    <div style={{ display: "flex", alignItems: "center", float: "right", cursor: "pointer" }} className="mapItemsRadioLabel" onClick={handleReset}>

                        Clear All
                        <Autorenew style={{ transform: "scale(0.7)" }} />
                    </div>
                    {props.type === "cic" ? cic : sku}
                </Popper>
            </div>
        </ClickAwayListener>
    )
}
