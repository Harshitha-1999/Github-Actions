import React from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions } from '@material-ui/core'

function ModalPopup(props) {
    return (
        <Dialog
            open={props.open}
            maxWidth={props.maxWidth}
            fullWidth={props.fullWidth}
            className={props.classNameMemi}
             style={{ backgroundColor: 'rgba(0,0,0,0.0001)' }}
        >
            <DialogTitle className={props.popupTitleClass}>
                {props.popupTitle}
            </DialogTitle>
            <DialogContent className={props.popupContentClass}>
                {props.popupContent}

            </DialogContent>
            <DialogActions className={props.popupActionClass}>
                {props.popupActions}
            </DialogActions>

        </Dialog>
    )
}

export default ModalPopup;