import { FormControl, FormHelperText, ListItemIcon, MenuList, MenuItem, ListItemText, Box, Popper, ClickAwayListener } from '@material-ui/core'
import { ArrowDropDown,  KeyboardArrowRight } from '@material-ui/icons';
import IconsCircle from 'components/IconsCircle/IconsCircle';

import React, { useEffect, useState, memo } from 'react'

function FilterByStatus(props) {
    const [color, setColor] = useState("");
    const [label, setLabel] = useState("");
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);

    useEffect(() => {
        if (props.child) {
            setColor(props.color);
            setLabel(props.label)
        }
        else if (props.value) {
            props.options.forEach((option) => {
                if ((option.value === props.value) || (option.value === "MAPPED" && (props.value === "ADD_MAP" || props.value === "INHERIT_MAP" || props.value === "BOTH"))) {
                    setColor(option.color)
                    setLabel(option.label)
                }
            })
        }

    }, [props.value])

    const handleSelect = (item) => {
        props.setValue(item.value);
        handleAfterSelectClose();
    }

    const handleAfterSelectClose = () => {
        setAnchorEl(null)
        if(props.handleAfterSelectClose) {
            props.handleAfterSelectClose();
        }
    }

    const handleClose = () => {
        setAnchorEl(null)
    }

    return (
        <ClickAwayListener onClickAway={handleClose}>
            <FormControl>
                <div>
                    {
                        props.child ?
                            <MenuItem style={{ fontSize: "14px",fontFamily:"Calibri" }} onClick={(e) => setAnchorEl(e.currentTarget)}>
                                <div style={{ display: "flex", alignItems: "center" }}>
                                    <IconsCircle color={color} />
                                    {label}
                                    <KeyboardArrowRight style={{ transform: "scale(0.8)",marginLeft:"-6px" }} />
                                </div>
                            </MenuItem>
                            :
                            <>
                                <div style={{ display: "flex", alignItems: "center", cursor: "pointer",fontFamily:"Calibri",fontSize:"14px" }} onClick={(e) => setAnchorEl(e.currentTarget)}>
                                    <IconsCircle color={color} /> {label}
                                    <ArrowDropDown style={{ transform: "scale(0.8)",marginLeft:"-6px" }} />
                                </div>
                            </>
                    }
                </div>
                <Popper
                    open={open}
                    anchorEl={anchorEl}
                    className="filterByStatusBox"
                    placement={
                        props.child ? "right-start" : "bottom-start"

                    }
                    style={{width:"10rem"}}
                >
                    <Box>
                        <MenuList>
                            {
                                props.options.map((item, index) => (
                                    item.children ?
                                        <FilterByStatus
                                            {...props}
                                            child={true}
                                            color={item.color}
                                            label={item.label}
                                            options={item.children}
                                            handleAfterSelectClose={handleAfterSelectClose}
                                        /> :
                                        <MenuItem key={index} onClick={() => handleSelect(item)} style={{ fontSize: "14px", fontFamily:"Calibri" }}>
                                            <div style={{ display: "flex", alignItems: "center" }}>
                                                {
                                                    item.color ? <IconsCircle color={item.color} /> : ""
                                                }
                                                {item.label}
                                            </div>
                                        </MenuItem>
                                ))
                            }
                        </MenuList>
                    </Box>
                </Popper>
            </FormControl>
        </ClickAwayListener>
    )
}

export default memo(FilterByStatus)
