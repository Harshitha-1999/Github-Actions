import React from 'react';
import Form from "react-bootstrap/Form";
import { replaceNextCharacterOnKeyPress, tabAndArrowNavigationUtil, replaceCharactersOnPaste } from 'utils';
import "./TextBoxWidget.scss";

/**
 * 
 * @param {Object} props - Object props when the function is called
 * @param {string} props.placeholder - Placeholder text for the input
 * @param {boolean} props.horizontalForm - Boolean value whether the form is horizontally or vertically aligned
 * @param {boolean} props.disabled - Boolean value whether the input field is disabled or not
 * @param {boolean} props.readOnly - Boolean value whether the input should read only
 * @param {Number} props.maxLength - The max length the user's input can be
 * @param {string} props.inputType - The type of input i.e., text, number, date
 * @param {string} props.name - The name for the input, will also be used as the id for the input
 * @param {string} props.label - The label for the input
 * @param {string} props.value - The value of the input
 * @param {function} props.onChange - The callback function to fire when the onChange event is fired on the input
 * @param {function} props.onBlur - The callback function to fire when the onBlur event is fired on the input
 * @param {string} props.txtColor - The color for the input text
 * @param {function} props.setFieldValue - Formik setFieldValue function, updates form value for the input
 * @param {function} props.setFieldTouched - Formik setFieldTouched function, updates whether the input has been touched by the user
 * @param {string} props.nextInput - Id of the input to move to next when the user tabs or uses arrow keys
 * @param {string} props.prevInput - Id of the input to move back to when the user tabs or uses arrow keys
 * @param {boolean} - Boolean value whether the input is a required field for the associated form
 * @returns 
 */
export const TextBoxWidget = ({
    placeholder,
    horizontalForm,
    disabled,
    readOnly,
    maxLength,
    inputType,
    name,
    label,
    value,
    onChange,
    onBlur,
    txtColor,
    //pass in the setFieldValue function from the associated formik form for the field
    //otherwise null by default to not break existing input behavior
    setFieldValue = null,
    //pass in the setFieldTouched function from the associated formik form for the field
    //otherwise null by default to not break existing input behavior
    setFieldTouched = null,
    nextInput = "",
    prevInput = "",
    isMandatory = false
}) => {
    // clear input on the first key input after user has entered the field
    const onKeyDownHandler = (ev) => {
        if (setFieldTouched !== null) {
            setFieldTouched(ev.target.id);
        }
        // moveCaretBackOnBackSpacePress(ev);
        tabAndArrowNavigationUtil(ev, nextInput, prevInput);

        if (ev.key.length === 1 && !ev.ctrlKey && !ev.metaKey && setFieldValue !== null) {
            replaceNextCharacterOnKeyPress(ev, setFieldValue, nextInput);
        }
    }

    const onChangeHandler = (ev) => {
        /*
        if(ev.target.value.length === maxLength && nextInput){
            // we handle this scenario in the keydownhandler when replaceNextCharacterOnKeyPress is called
         // setFocus(nextInput);
        } */
        if (setFieldTouched !== null) {
            setFieldTouched(ev.target.id);
        }

        onChange(ev);
    }

    const onPasteHandler = (ev) => {
        // call the replaceCharactersOnPaste utility method when a paste action occurs
        replaceCharactersOnPaste(ev, setFieldValue, nextInput);
    }

    const hasError = document.getElementById(name) && document.getElementById(name).style.color === 'red';
    let textControl = (
        <Form.Control
            style={txtColor ? { color: txtColor, borderColor: txtColor } : null}
            placeholder={hasError ? isMandatory ? "*" : "" : placeholder}
            autoComplete={"off"}
            size={horizontalForm ? "" : "sm"}
            disabled={disabled}
            readOnly={readOnly}
            maxLength={maxLength}
            type={inputType}
            className={hasError ? "textboxWidgetClass input-has-error" : "textboxWidgetClass"}
            name={name}
            value={value}
            onChange={onChangeHandler}
            onBlur={onBlur}
            onKeyDown={onKeyDownHandler}
            onPaste={onPasteHandler}
        />
    );

    return (
        <Form.Group
            controlId={`${name}`}
            className={`${name}`}
        >

            {horizontalForm ? (
                <React.Fragment>
                    <Form.Label
                        className={horizontalForm ? "pt-1" : ""}
                    >
                        {label}
                    </Form.Label>
                    {textControl}
                </React.Fragment>
            ) : (
                <React.Fragment>
                    {textControl}
                </React.Fragment>
            )}
        </Form.Group>
    );
}
