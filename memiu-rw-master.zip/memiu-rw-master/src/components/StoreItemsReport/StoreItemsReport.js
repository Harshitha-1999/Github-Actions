import React from 'react';
import TableMemi from "../TableMemi/TableMemi";

function StoreItemsReport(props) {

    return (
        <div>
            <TableMemi
                data={props.AppData.meup54}
                classnameMemi="table29"
                rowheight={40}
                rowPerPageOptions={props.AppData.meup54.length - 1}
                selectionType="regular"
                columns={props.customcolumns}
            />
        </div>
    );
}

export default StoreItemsReport;