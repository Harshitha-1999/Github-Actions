import React from 'react';
import { Grid } from "@material-ui/core";
import TableMemi from "../TableMemi/TableMemi";
import ButtonMemi from "../ButtonMemi/ButtonMemi"

function EnterItemsBlock(props) {
  const handleSubmit = () => {

  }

  return (
    <div>
      <Grid container direction="row"  >
        <TableMemi
          data={props.AppData.meup54}
          classnameMemi="table29"
          rowheight={40}

          columns={props.customcolumns}
        />
        <Grid item xs={6} sm={4} md={6} xl={1} lg={1}>
          <ButtonMemi
            btnval="Main Menu"
            btnvariant="contained"
            classNameMemi="btnmemiupload"
            onClick={handleSubmit}
          />
        </Grid>
        <Grid item xs={6} sm={3} md={3} xl={3} lg={3}>
          <ButtonMemi
            btnval="Block AnotherItem"
            btnvariant="contained"
            classNameMemi="btnmemiupload"
            onClick={() => {
              alert("clicked");
            }}
          />
        </Grid>
      </Grid>
    </div>
  );
}

export default EnterItemsBlock;
