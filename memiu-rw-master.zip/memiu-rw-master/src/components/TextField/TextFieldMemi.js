import React from "react";
import TextField from "@material-ui/core/TextField";
import { Grid } from "@material-ui/core";

export default function TextFieldMemi(props) {

  const errorText = props.errorText
  const onChangeText = (text) => {

    if (props.limit && text.length > props.limit) {

      return;
    }
    props.setTextValue(text)

    if (props.setError) {
      if (text.length < props.length) {
        props.setError(true);
      } else {
        props.setError(false);
      }

    }

  };

  return (
    <Grid container>
      <Grid item xs={props.alignItems === "row" ? (props.labelXs ? props.labelXs : 5) : 12} style={{textAlign:props.alignLabel ? props.alignLabel : "left"}} >
        <label className={props.LabelClass}>{props.label}</label>
      </Grid>
      <Grid item xs={props.alignItems === "row" ? (props.textFieldXs ? props.textFieldXs : 7) : 12}>
        <TextField
          inputProps={{ maxLength: props.maxLength }}
          className={`${props.TextFieldClass} ${props.disabled ? 'disabledtextfield' : ""}`}
          id={props.id}
          variant="outlined"
          type={props.type}
          value={props.value!==null ? props.value : ""}
          placeholder={props.placeholder}
          onChange={(e) => onChangeText(e.target.value)}
          error={props.error}
          helperText={props.error ? errorText : ""}
          multiline={props.multiline}
          disabled={props.disabled}
          rows={2}
          required={props.required}
          fullWidth={props.fullWidth === false || props.fullWidth === true ? props.fullWidth : true}
          InputProps={{
            readOnly:props.read,
            classes: {
              input: props.input,
            },
            autoComplete: props.autoComplete
          }}
          title={props.title}
        />
      </Grid>
    </Grid>
  );
}
