import React from "react";
import TableMemi from "components/TableMemi/TableMemi";
import { Grid } from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import {
  makeStyles,
  ThemeProvider,
  createTheme,
} from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from "@material-ui/core/Container";
import "../../css/App.css";
import ButtonMemi from "../ButtonMemi/ButtonMemi";

const useStyles = makeStyles({
  root: {
    "& .super-app-theme--header": {
      backgroundColor: "rgba(255, 7, 0, 0.55)",
    },
  },
  divHeader: {
    backgroundColor: "#f5f5f5",
    height: "39px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "1rem",
  },
  addMarginRight: {
    marginRight: "200px",
  },
  addMarginLeft: {
    marginLeft: "10px",
  },
  gridMargin: {
    marginTop: "9px",
  },
});

function DisplayerScreenCont(props) {
  const theme = createTheme();
  const classes = useStyles();
  let customcolumns = [{ field: "id", hide: true }];

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container component="main" maxWidth="xl">
        <Grid item xs={12} sm={12} md={12} xl={12}>
          <Paper variant="outlined" elevation={12} className="override">
            <Typography
              component="h1"
              variant="h4"
              align="center"
              className="augheading"
            >
              Department: DELI
            </Typography>
            <TableMemi
              data={props.AppData.memi24_A}
              classnameMemi="tableDisplayerCont"
              rowheight={40}
              rowPerPageOptions={props.AppData.memi24_A.length - 1}
              selectionType="general"
              customcolumns={customcolumns}
            />
            <div className={classes.divHeader}>
              <h4 className={classes.addMarginLeft}>
                <ButtonMemi
                  btncolor="primary"
                  btnval="Mark Display"
                  btnvariant="contained"
                  classnameMemi="btnmemi1"
                  onClick={() => {
                    alert("clicked");
                  }}
                />
              </h4>
              <h4>
                <ButtonMemi
                  btncolor="primary"
                  btnval="Un Mark Display"
                  btnvariant="contained"
                  classnameMemi="btnmemi1"
                  onClick={() => {
                    alert("clicked");
                  }}
                />
              </h4>
              <h4>
                <ButtonMemi
                  btncolor="primary"
                  btnval="Mark As Dead"
                  btnvariant="contained"
                  classnameMemi="btnmemi1"
                  onClick={() => {
                    alert("clicked");
                  }}
                />
              </h4>
              <h4 className={classes.addMarginRight}>
                <ButtonMemi
                  btncolor="primary"
                  btnval="Export Exceptions"
                  btnvariant="contained"
                  classnameMemi="btnmemi1"
                  onClick={() => {
                    alert("clicked");
                  }}
                  style={{ backgroundColor: "fff" }}
                />
              </h4>
              <h4 className={classes.addMarginRight}>
                <ButtonMemi
                  btncolor="primary"
                  btnval="Import Components"
                  btnvariant="contained"
                  classnameMemi="btnmemi1"
                  onClick={() => {
                    alert("clicked");
                  }}
                />
              </h4>
            </div>
          </Paper>
        </Grid>
        <Grid container direction="row" spacing={0}>
          <Grid item xs={12} sm={12} md={6} xl={6}>
            <Paper variant="outlined" elevation={12} className="overrideTitle">
              <Typography
                component="h1"
                variant="h4"
                align="center"
                className="augheading"
              >
                Source
              </Typography>
              <TableMemi
                data={props.AppData.memi24_B}
                classnameMemi="tableDisplayerCont"
                rowheight={40}
                rowPerPageOptions={props.AppData.memi24_B.length - 1}
                selectionType="general"
                customcolumns={customcolumns}
              />
            </Paper>
          </Grid>
          <Grid item xs={12} sm={12} md={6} xl={6}>
            <Paper variant="outlined" elevation={12} className="override">
              <Typography
                component="h1"
                variant="h4"
                align="center"
                className="augheading"
              >
                SSIMS Item
              </Typography>
              <TableMemi
                data={props.AppData.memi24_C}
                classnameMemi="tableDisplayerCont"
                rowheight={40}
                rowPerPageOptions={props.AppData.memi24_C.length - 1}
                selectionType="general"
                customcolumns={customcolumns}
              />
              <div style={{ height: "400px" }}></div>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </ThemeProvider>
  );
}

export default DisplayerScreenCont;
