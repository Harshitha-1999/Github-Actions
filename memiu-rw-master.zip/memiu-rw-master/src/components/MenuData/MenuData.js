import { RouteBase } from '../../routes/constants/RouteBase'
export const MEMIMenu = [
  {
    id: 0,
    path: `${RouteBase.MEMI03}`,
    label: "Map Items",
  },
  {
    id: 1,
    path: `${RouteBase.MEMI04}`,
    label: "Mapped",

  },
  {
    id: 2,
    path: `${RouteBase.MEMI05}`,
    label: "Bakery Mapping",
  }

]
