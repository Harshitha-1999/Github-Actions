import React, { useContext, useEffect, useState } from 'react';
import ApplicationContext from "../../context/ApplicationContext";
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import ModalPopup from '../ModalPopup/ModalPopup';
import { CloseTwoTone } from '@material-ui/icons';
import { withStyles } from "@material-ui/core/styles";
import { Grid } from '@material-ui/core';
import ButtonMemi from '../ButtonMemi/ButtonMemi'

function LoaderStatusPanel(props) {

    const AppData = useContext(ApplicationContext);
    const { loader } = AppData;
    const { logStatus } = AppData;

    //status panel
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    //menu custom
    const StyledMenu = withStyles({
        minWidth: 180,

        paper: {
            backgroundColor: "whitesmoke",
            border: "1px solid rgba(0, 0, 0, .15) !important",
            // borderRradius: "2px !important",
            width: "7.6%",
            bottom: "100rem !important",
            height: "fit-content",
            top: "82% !important",
            boxShadow: "0 6px 12px rgb(0 0 0 / 18%) !important",

        },
        list: {

            backgroundColor: "",
            fontSize: 18,
            marginRight: 1.5,
        }

    })(props => (
        <Menu
            elevation={0}
            anchorOrigin={{
                vertical: "bottom"
            }}
            transformOrigin={{
                vertical: "top"
            }}
            {...props}
        />
    ));
    //menu custom
    //popup
    const [popUpOpen, setPopUpOpen] = React.useState(false);
    const handlePopUpOpen = () => setPopUpOpen(true);
    const handlePopUpClose = () => setPopUpOpen(false);
    const mappingContent = (<Grid container className="">
        <Grid item xs={6} className="">
            <span className={"bakeryMapHeading"}>LOGS</span>
        </Grid>
        <Grid item xs={6} className="" style={{ textAlign: "right" }}>
            <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={handlePopUpClose} />
        </Grid>
        <Grid item xs={12} className="">
            {logStatus}
        </Grid>
    </Grid>);
    //popup
    //status panel

    const [text, setText] = useState("Ok");
    const [textClass, setTextClass] = useState("meuploader");

    useEffect(() => {
        if (loader < 0) {
            // console.log("Loader MEUP Loader Spinning");
            setText("Error");
            setTextClass("meuploadererror");

        }
        else if (loader > 0) {
            // console.log("Loader MEUP Loader Loaded");
            setText("Loading");
            setTextClass("meuploaderloading");

        }
        else {
            setText("Ok");
            setTextClass("meuploader");

        }
    }, [loader])
    return (
        <>
            {/* button Elementt */}
            <div  className='loadingClass'  >
                <Button
                    id="basic-button"
                    aria-controls={open ? 'basic-menu' : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? 'true' : undefined}
                    onClick={handleClick}
                    onMouseOver={handleClick}
                    className={`${textClass} `}
                >
                    <Grid container>
                    <Grid  xs={1}><span>{text} </span></Grid>
                    <Grid  xs={10}></Grid>
                    <Grid   xs={1}  style={{float:"right", marginLeft: "auto"}}>
                        </Grid>
                    </Grid>
                </Button>
                <span style={{marginLeft: "auto"}} className={`${textClass} `}> &#9673; </span>
            </div>
            {/* Menu Elementt */}
            {/* <div > */}
                <StyledMenu

                    id="basic-menu"
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleClose}
                    MenuListProps={{
                        'aria-labelledby': 'basic-button',
                    },
                        { onMouseLeave: handleClose }
                    }
                >
                    <div container className='styledMenuClass'>
                        <ButtonMemi classNameMemi="statusPanelItem" btnval="Logs" onClick={handlePopUpOpen} />
                    </div>
                </StyledMenu>
            {/* </div> */}
            <ModalPopup open={popUpOpen}
                onClose={handlePopUpClose}
                maxWidth='md'
                fullWidth={true}
                className=''
                popupContent={mappingContent}
            />
        </>

    );
}

export default LoaderStatusPanel;