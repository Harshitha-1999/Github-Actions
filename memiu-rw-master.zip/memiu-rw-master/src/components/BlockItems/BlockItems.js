import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { useHistory } from 'react-router-dom'
import DropDownMemi from 'components/DropDownMemi/DropDownMemi';
import CalendarMeup from 'components/CalendarMeup/CalendarMeup';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import TableMemi from 'components/TableMemi/TableMemi';
import TextFieldMemi from 'components/TextField/TextFieldMemi'
import { meupServices } from "../../api/meup/meupServices";
import ErrorListMeup from 'components/ErrorListMeup/ErrorListMeup';
import { isNumber } from 'components/CommonFunctionsMeup/CommonFunctionsMeup';


function BlockItems() {
    const history = useHistory();
    const [divisions, setDivisions] = useState([]);
    const handleChange = (value, params) => {
        const newData = data.map((row) => {
            if (params.row.id === row.id) {
                return { ...row, [`${params.field}`]: value };
            }
            else {
                return row;
            }
        })
        setData(newData)
    }

    useEffect(() => {
        meupServices
            .getDivisions()
            .then((res) => {

                let data = res.data.data.REST_RETURNED_DATA.map((x) => {
                    return { label: x.dispDivision, value: x.divisionNumber };
                });

                setDivisions(data);
            })
            .catch((error) => {
                setDivisions([]);
            });
    }, [])

    const [data, setData] = useState([
        { "id": 0, "UPC": "", "CIC": "", " ": "" },
        { "id": 1, "UPC": "", "CIC": "", " ": "" },
        { "id": 2, "UPC": "", "CIC": "", " ": "" },
        { "id": 3, "UPC": "", "CIC": "", " ": "" },
        { "id": 4, "UPC": "", "CIC": "", " ": "" },
        { "id": 5, "UPC": "", "CIC": "", " ": "" }
    ]);

    // const [open, setOpen] = useState(false);   
    const [division, setDivision] = useState("");
    const [errDivision, setErrorDivision] = useState(false);
    const [date, setDate] = useState(null)

    const [errors, setErrors] = useState([]);
    let columns = [

        {
            field: "UPC",
            headerName: "UPC",
            sortable: false,
            flex: 0.3,
            renderCell: (params) => (
                <TextFieldMemi
                    alignItems="column"
                    value={params.value}
                    setTextValue={(value) => handleChange(value, params)}
                    TextFieldClass="textFieldBlockItems"
                    fullWidth={false}
                    limit={8}
                />
            ),
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "CIC",
            headerName: "CIC",
            sortable: false,
            flex: 0.3,
            renderCell: (params) => (
                <TextFieldMemi
                    alignItems="column"
                    value={params.value}
                    setTextValue={(value) => handleChange(value, params)}
                    TextFieldClass="textFieldBlockItems"
                    fullWidth={false}
                    limit={12}
                />

            ),
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: " ",
            headerName: " ",
            sortable: false,
            flex: 0.3,
            renderCell: (params) => (
                <TextFieldMemi
                    alignItems="column"
                    value={params.value}
                    setTextValue={(value) => handleChange(value, params)}
                    TextFieldClass="textFieldBlockItems"
                    fullWidth={false}
                    limit={4}
                />
            )
        }
    ];

    const handleSubmit = () => {
        let errorList = [];
        setErrorDivision(false);
        if (!date) {

            alert("Please enter a valid date");
            return
        }
        else if (date - new Date() <= 0) {
            alert("Delete date should be a future date")
            return
        }
        else if (division === "") {
            errorList.push("Please select a division");
            setErrorDivision(true)
        }
        else {
            let storeItems = [];
            for (let i = 0; i < data.length; i++) {
                let validData = false;

                Object.keys(data[i]).forEach((key) => {

                    if (key !== "id" && data[i][key].length > 0) {
                        validData = true;
                    }

                })
                if (validData) {
                    storeItems.push({ "upc": data[i]["UPC"], "cic": data[i]["CIC"], "storeNumber": data[i][" "] })
                }
            }

            if (storeItems.length === 0) {
                errorList.push("Data is not Entered.");
            }
            else {
                for (let i = 0; i < storeItems.length; i++) {

                    let storeItem = storeItems[i];
                    if (storeItem["upc"].length === 0 || storeItem["cic"].length === 0) {
                        errorList.push("CIC/UPC not Entered.")
                        break
                    }
                    else if (!isNumber(storeItem["upc"]) || !isNumber(storeItem["cic"]) || (storeItem["storeNumber"].length > 0 && !isNumber(storeItem["storeNumber"]))) {
                        errorList.push("CIC/UPC/Store number should be numeric and a non-decimal value.")
                        break
                    }
                    else if (storeItem["upc"].length < 10 || storeItem["cic"].length < 7 || (storeItem["storeNumber"].length > 0 && storeItem["storeNumber"].length < 4)) {
                        errorList.push("CIC should be minimum 7 digits./UPC should be minimum 10 digits./Store number should be 4 digits")
                        break
                    }

                }

            }

        }
        window.scrollTo(0, 0)
        setErrors(errorList);
    }
    return (
        <Grid container>

            <Grid item xs={12}>

                <div style={{ backgroundColor: "#CFC3AD", width: "15rem", padding: "0.3rem 0rem 0rem 0.3rem", height: "1.5rem" }}>
                    <strong> Enter Items to Block </strong>
                </div>
            </Grid>
            <Grid item xs={12}>
                <ErrorListMeup errors={errors} />
            </Grid>
            <Grid item xs={12}>
                <div style={{ color: 'rgb(0, 0, 128)', marginTop: "22px", fontSize: "medium" }}>
                    <strong> All UPC/CICs entered will be blocked in all stores entered. </strong>
                </div>

                <div style={{ width: "45rem" }} className="blockItemsMarginTop">
                    <DropDownMemi
                        label={<> Select Division <font color="red">*</font> </>}
                        LabelClass="labelClassBlockedItems"
                        alignItems="row"
                        options={divisions}
                        DropDownClass="blockItemsDropDown"
                        value={division}
                        error={errDivision}
                        setValue={(value) => setDivision(value)}
                        errorText=""
                    />
                </div>
                <div style={{ width: "45rem" }} className="blockItemsMarginTop">
                    <CalendarMeup
                        // meupcal="blockItemsCal" 

                        label={<> Set Delete Date  <font color="red">*</font> </>}
                        LabelClass="labelClassBlockedItems"
                        alignItems="row"
                        value={date}
                        setValue={(value) => setDate(value)}
                    />

                </div>

            </Grid>
            <Grid container style={{ width: "60%" }}>
                <Grid item xs={8} className="tableBlockItemsHeader blockedItems blockItemsMarginTop" >
                    <strong> Enter Items </strong>
                </Grid>
                <Grid item xs={4} className="tableBlockItemsHeader blockItemsMarginTop">
                    <strong> Enter Store # </strong>
                </Grid>
                <Grid item xs={12} style={{ height: "100%" }}>
                    <TableMemi
                        data={data}
                        columns={columns}
                        classnameMemi="tableBlockedItem"
                        showCellRightBorder={true}
                        showColumnRightBorder={true}
                        hideFooter={true}
                        hideFooterPagination={true}
                        hideFooterSelectedRowCount={true}
                    />
                </Grid>
            </Grid>
            <Grid item xs={12} className="blockItemsMarginTop" style={{ marginBottom: "3rem" }}>
                <ButtonMemi

                    btnval="Block Items"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    onClick={handleSubmit}
                />

                <ButtonMemi
                    btnval="Reset"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => {
                        window.location.reload()
                    }}

                />

                <ButtonMemi
                    btnval="Cancel"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
                    onClick={() => {
                        history.push("/")
                    }}

                />

            </Grid>

        </Grid>
    )
}

export default BlockItems;