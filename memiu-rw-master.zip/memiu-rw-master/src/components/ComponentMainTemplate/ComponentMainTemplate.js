import React, {
  useEffect,
  useContext,
  useState,
  useCallback,
  useRef,
} from "react";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import SearchForm from "../../components/SearchForm/SearchForm";
import Footer from "../../components/Footer/Footer";
import TableMemi from "../../components/TableMemi/TableMemi";
import DropDownMemi from "../../components/DropDownMemi/DropDownMemi";
import ApplicationContext from "../../context/ApplicationContext";
import clsx from "clsx";
import RadioMemi from "../../components/RadioMemi/RadioMemi";
//import RemoveRedEyeSharpIcon from '@material-ui/icons/RemoveRedEyeSharp';
//import EditIcon from '@material-ui/icons/Edit';
//import RemoveRedEyeIcon from '@material-ui/icons/RemoveRedEye';
//import SearchIcon from '@material-ui/icons/Search';
//import RoomIcon from '@material-ui/icons/Room';
import SearchFieldMemi from "../../components/SearchFieldMemi/SearchFieldMemi";
// import DoDisturbAltIcon from '@material-ui/icons/DoDisturbAlt';
// import DoNotDisturbIcon from '@mui/icons-material/DoNotDisturb';
// import DoDisturbIcon from '@material-ui/icons/DoDisturb';
//import AddIcon from '@material-ui/icons/Add';
//import LocalOfferIcon from '@material-ui/icons/LocalOffer';
import Avatar from "@material-ui/core/Avatar";
import "../../css/App.css";
import Radio from "@material-ui/core/Radio";
import ButtonMemi from "../../components/ButtonMemi/ButtonMemi";
import { MEMI08Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";

const useStyles = makeStyles((theme) => ({
  root: {
    "& .super-app.positive": {
      color: "#50C878",
      fontWeight: "600",
    },
  },
  root1: {
    "& > *": {
      margin: theme.spacing(3),

      width: "40ch",
    },
  },
}));

export const ComponentMainTemplate = (props) => {
  const classes = useStyles();
  const [pack, setPackType] = useState(" ");
  const [searchvalue, setSearchType] = useState(" ");
  const [productType, setSearchValue] = useState(" ");
  const [errPack, setErrPack] = useState(false);
  let columns = [];
  let customcolumns = [
    {
      field: "size",
      headerName: "size",
      description: "This column has a value getter and is not sortable.",
      sortable: false,
      width: 160,
      renderCell: (params) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <ButtonMemi
            btncolor="primary"
            btnval="Hide"
            btnvariant="contained"
            classnameMemi="btnmemi1"
            onClick={() => {
              alert("clicked");
            }}
          />
          &nbsp;
          {params.value}
        </div>
      ),
    },
  ];

  const AppData = useContext(ApplicationContext);

  useEffect(() => {
    MEMI08Axios.get("/").then((res) => {
      AppData.setMemi08(res.data);
    });

  }, []);

  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (

    <Grid
      container
      spacing={2}
      direction="row"
      className="MainContent"
      alignItems="flex-start"
    >
      <Grid item md={6} className={classes.root}>
        <ButtonMemi
          btncolor="primary"
          classNameMemi="edit"
          btnval="Let Auto Match"
          btnvariant="contained"
        />
        <ButtonMemi
          btncolor="secondary"
          classNameMemi="add"
          btnval="Force New"
          btnvariant="contained"
        />
        <ButtonMemi
          classNameMemi="localoffer"
          btnval="Reserve "
          btnvariant="contained"
        />
        <div className="search_field">
          {/* <DropDownMemi
                          label="Change Usage"
                          options={["Type1", "Type2", "Type3", "Type4"]}
                          alignItems="row"
                          value={pack}
                          setValue={(value) => setPackType(value)}
                          error={errPack}
                          setError={(value) => setErrPack(value)}
                          classnamebtn="cascadingbtn"
                          labelInline={true}
                          
                          
                        /> */}
          <RadioMemi
            radioclassmemi="radio1"
            classnameMemi="radclassbakery1 "
            Mainlabel="Item Type"
            label={[
              { value: "All", label: "All" },
              { value: "system2", label: "System2" },
              { value: "system4", label: "System4" },
              { value: "plu", label: "PLU" },
            ]}
          />

          <SearchFieldMemi
            selectedValue={productType}
            options={["Type1", "Type2", "Type3", "Type4"]}
            handleSelectChange={(value) => setSearchType(value)}
            searchValue={searchvalue}
            onChangeSearchValue={(value) => setSearchValue(value)}
            classNameMemi="searchBarClass"
          />
        </div>
        <TableMemi
          data={AppData.memi08}
          classnameMemi="table27"
          rowheight={40}
          selectionType="radio"
        />
      </Grid>
      <Grid item md={6} className={classes.root}>
        <ButtonMemi
          classNameMemi="suggestbakery"
          btnval="Suggest CIC"
          btnvariant="contained"
        />

        <ButtonMemi
          classNameMemi="reverse"
          btnval="Add Map "
          btnvariant="contained"
        />
        <ButtonMemi
          classNameMemi="removedeye"
          btnval="Inherit Map"
          btnvariant="contained"
        />
        <div className="search_field">
          <RadioMemi
            radioclassmemi="radio1"
            classnameMemi="radclassbakery2"
            Mainlabel="Item Type"
            label={[
              { value: "All", label: "All" },
              { value: "system2", label: "System2" },
              { value: "system4", label: "System4" },
              { value: "plu", label: "PLU" },
            ]}
          />
          <SearchFieldMemi
            selectedValue={productType}
            options={["Type1", "Type2", "Type3", "Type4"]}
            handleSelectChange={(value) => setSearchType(value)}
            searchValue={searchvalue}
            onChangeSearchValue={(value) => setSearchValue(value)}
            classNameMemi="searchBarClass"
          />
        </div>
        <TableMemi
          data={AppData.memi08}
          classnameMemi="table28"
          rowheight={40}
          selectionType="checkbox"
        />
      </Grid>
      <Grid item md={6} className={classes.root}></Grid>
      <Grid item md={6} className={classes.root}>

        <div className="search_field">
          <RadioMemi
            radioclassmemi="radio1"
            classnameMemi="radclassbakery3"
            Mainlabel="Item Type"
            label={[
              { value: "All", label: "All" },
              { value: "system2", label: "System2" },
              { value: "system4", label: "System4" },
              { value: "plu", label: "PLU" },
            ]}
          />
          <SearchFieldMemi
            selectedValue={productType}
            options={["Type1", "Type2", "Type3", "Type4"]}
            handleSelectChange={(value) => setSearchType(value)}
            searchValue={searchvalue}
            onChangeSearchValue={(value) => setSearchValue(value)}
            classNameMemi="searchBarClass"
          />
        </div>
        <TableMemi
          data={AppData.memi08}
          classnameMemi="table28"
          rowheight={40}
          selectionType="checkbox"
        />
      </Grid>
    </Grid>

  );

};

export default ComponentMainTemplate;

