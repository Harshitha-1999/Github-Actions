import React, { useEffect, useCallback, useState, useRef } from "react";
import { Grid } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import TextFieldMemi from "../TextField/TextFieldMemi";
import { styled } from '@material-ui/core/styles';
import { DateUtility } from "utils"
import "../../css/App.css";
import CalendarMeup from "../CalendarMeup/CalendarMeup"
import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";

function UploaditemBlockMeup(props) {


  const Input = styled('input')({
    display: 'none',
  });

  const [errors, setErrors] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState("")

  const [date, setDate] = useState(null);
  const selectFile = (event) => {
    setSelectedFiles(event.target.files[0]);
  };

  const handleSubmit = async () => {
    let errorList = []
    if (!date) {
      alert("Please enter a valid date");
    }
    else if (date - new Date() <= 0) {
      alert("Delete date must be set at least one day the future")
    }
    else if (selectedFiles.length === 0) {
      errorList.push("The CSV file is not specified for upload. Use the Browse button to locate the file.");
      setErrors(errorList)
    } else {

      let data = {
        deleteDate: DateUtility.convertDate(date),
        itemsFile: selectedFiles
      }
      // if(!meup51Error){
      // }
    }

  }



  return (

    <Grid container direction="row" className="uploadblockitemcscreenn" >
      <Grid item xs={12} >

        <ErrorListMeup errors={errors} />


      </Grid>
      <Grid item xs={12} style={{ maxWidth: "47rem" }}>


        <CalendarMeup meupcal="cal" label={<> Select Delete Date <font color="red">*</font> </>}
          LabelClass="labelmeup" alignItems="row" value={date}
          setValue={(value) => setDate(value)} />


      </Grid>
      <Grid item xs={12} style={{ display: "flex", flexDirection: "row", maxWidth: "70rem", marginTop: "1.5rem" }}>

        <div style={{ width: "50rem" }}>
          <TextFieldMemi
            LabelClass="labelclass1"
            length={15}
            label={<> Select CSV File <font color="red">*</font> </>}
            alignItems="row"
            id="Vcf outlined-disabled"
            value={selectedFiles !== "" ? selectedFiles.name : ""}
            labelLeft={true}
            TextFieldClass="textFieldupload"
            input="inputupload"
          />
        </div>



        <label htmlFor="contained-button-file" className="browser" style={{ width: "fitContent" }}>
          <Button variant="contained" component="span" style={{ whiteSpace: "nowrap" }}>
            Choose File
          </Button>
          <Input id="contained-button-file" type="file" onChange={selectFile} />

        </label>




      </Grid>


      <Grid item xs={12} style={{ display: "flex", flexDirection: "row", marginTop: "3rem" }}>

        <ButtonMemi
          btnval="Upload"
          btnvariant="contained"
          classNameMemi="btnmemiupload"
          onClick={handleSubmit}
        />



        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="btnmemicancel"
          onClick={() => {
            alert("clicked");
          }}
        />

      </Grid>
    </Grid>
  );
}

export default UploaditemBlockMeup;