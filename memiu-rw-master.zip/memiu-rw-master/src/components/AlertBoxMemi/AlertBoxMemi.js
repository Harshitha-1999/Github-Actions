import React, { useContext } from 'react';

import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";

export default function AlertBoxMemi(props) {

    const AppData = useContext(ApplicationContext);

    const handleSubmit = () => {
        AppData.setAlertBox(false)
    }

    return (
        <ModalPopup
            open={AppData.alertBox.open}
            classNameMemi="alertBoxMemi"
            popupContentClass="popupAlertBoxContent"
            popupActionClass="popupAlertBoxAction"
            maxWidth="xs"
            fullWidth
            popupContent={Array.isArray(AppData.alertBox.message) ? AppData.alertBox.message[0] : AppData.alertBox.message  }
            popupActions={

                <>
                    <ButtonMemi
                        btnval="Ok"
                        classNameMemi="submitButtonClass"
                        onClick={handleSubmit}
                        btnvariant={"contained"}
                        btnsize="small"
                    />
                </>
            }
        />

    )
}
