
import React, { memo, useEffect, useState } from 'react';
import SelectMenuMemi from 'components/SelectMenuMemi/SelectMenuMemi';
import SearchIcon from '@material-ui/icons/Search';

function SearchFieldMemi(props) {
  const [disabledInput, setDisabledInput] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [label, setLabel] = useState("-Select-")
  const handleSelect = (e) => {
    console.log(e)
    props.setSearchCriteria(e.searchCriteria)
    if (e.inputValue) {
      setInputValue(e.inputValue)
    }
    else {
      setInputValue(null);
    }
    if (e.value) {
      props.setSearchValue(e.value);
    }
    else {
      props.setSearchValue("");
    }
    if (e.searchLabel) {
      setLabel(e.searchLabel)
    }
    else {
      setLabel(e.label)
    }
    if (e.disabledInput) {
      setDisabledInput(true)
    } else {
      setDisabledInput(false)
    }

  }

  useEffect(() => {
    if (Array.isArray(props.options)) {
      props.options.forEach((option) => {
        if (option.searchCriteria === props.searchCriteria) {
          setLabel(option.searchLabel ? option.searchLabel : option.label)
          setInputValue(option.inputValue ? option.inputValue : option.value)
          setDisabledInput(option.disabledInput ? true : false)
          return
        }
      })
    }

  }, [props.searchCriteria, props.searchValue])

  const handleSearch = (e) => {
    e.preventDefault();
    if (props.disableSelectMenu) {
      props.onSearch(props.searchValue)
    }
    else {
      props.onSearch(props.searchValue, label)
    }
  }
  return (
    <form className={props.classNameMemi ? props.classNameMemi : "searchFieldClass"} onSubmit={handleSearch}>
      {
        props.disableSelectMenu ? ""
          :
          <SelectMenuMemi
            label={label}
            options={props.options ? props.options : []}
            classNameMemi="searchDropdownClass"
            onSelect={handleSelect}
            dense
            menuClass="searchFieldMenuClass"
            subMenuClass="searchFieldSubMenuClass"
          />
      }
      <input
        disabled={disabledInput}
        value={inputValue ? inputValue : props.searchValue}
        onChange={(e) => props.setSearchValue(e.target.value)}
        placeholder="Search"
        className={props.inputClass ? props.inputClass : "searchInputClass"}
        style={{ backgroundColor: disabledInput ? "" : "white" }}
      />
      <SearchIcon style={{ color: "white", padding: "5px", cursor: "pointer" }} onClick={handleSearch} />

    </form>
  );
}

export default memo(SearchFieldMemi);