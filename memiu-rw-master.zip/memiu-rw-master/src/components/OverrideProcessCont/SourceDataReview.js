import React, { useContext } from 'react'
import { Grid, Checkbox } from "@material-ui/core";
import ButtonMemi from '../ButtonMemi/ButtonMemi'
import ApplicationContext from "../../context/ApplicationContext";
import { Add } from "@material-ui/icons";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import { memiuServices } from 'api/memiu/memiuService';
import { authTokenCookie } from 'utils';
import { RouteBase } from 'routes/constants';
import { useHistory } from 'react-router';

export default function SourceDataReview({ disableManualMap, disableMarkOutOfScope, disableMarkAsDead, option, setOption, pageNumber, setPageNumber }) {

    const AppData = useContext(ApplicationContext);
    const { UpdateOverrideManualSearch, updateoverridesku } = AppData;
    const history = useHistory();
    const handleManualMap = () => {

        let UpdateOverrideLikeSrcEditDetails = UpdateOverrideManualSearch;
        const { userId } = authTokenCookie();

        UpdateOverrideLikeSrcEditDetails.moveToManualMap = true;
        UpdateOverrideLikeSrcEditDetails.newItemDto.createId = userId;
        UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
        UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
        UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
        UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
        UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID = userId;

        memiuServices.postSaveOverideDetails(UpdateOverrideLikeSrcEditDetails)
            .then((response) => {
                //function handles success condition
                let saveStatus = response.data.status;
                if (saveStatus == 1) {

                    if (pageNumber >= updateoverridesku.length - 1) {
                        AppData.setAlertBox(true, "No more items under this department.");
                        history.push(RouteBase.MEMI13);
                    }
                    else {
                        setPageNumber(pageNumber + 1)
                    }
                }
            })
            .catch((error) => {
                //function handles error condition
            })
        AppData.setConfirmationModal(false);


    }

    const handleMarkDead = (message) => {

        let whiteSpace = new RegExp(/^\s+$/);
        const { userId } = authTokenCookie();
        if (!whiteSpace.test(message)) {
            let UpdateOverrideLikeSrcEditDetails = UpdateOverrideManualSearch;
            UpdateOverrideLikeSrcEditDetails.createId = userId;
            UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
            UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
            UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
            UpdateOverrideLikeSrcEditDetails.markAsDeadReason = message
            UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
            UpdateOverrideLikeSrcEditDetails.killProdSku = true;

            UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID = userId;
            // let UpdateOverrideLikeSrcEditDetailsString = JSON.stringify(UpdateOverrideLikeSrcEditDetails);

            //service call
            memiuServices.postSaveOverideDetails(UpdateOverrideLikeSrcEditDetails)
                .then((response) => {
                    //function handles success condition
                    let saveStatus = response.data.status;
                    if (saveStatus == 1) {

                        if (pageNumber >= updateoverridesku.length - 1) {
                            AppData.setAlertBox(true, "No more items under this department.");
                            history.push(RouteBase.MEMI13);
                        }
                        else {
                            setPageNumber(pageNumber + 1)
                        }
                    }
                })
                .catch((error) => {
                    //function handles error condition
                })
            AppData.setConfirmationModal(false);

        }
        else {

            AppData.setConfirmationModal(true, handleMarkDead, "textBox", "Enter the reason for marking this item as dead")
        }

    }

    const handleMarkOutOfScope = () => {
        let UpdateOverrideLikeSrcEditDetails = UpdateOverrideManualSearch;
        const { userId } = authTokenCookie();
        UpdateOverrideLikeSrcEditDetails.manualMap = true;
        UpdateOverrideLikeSrcEditDetails.newItemDto.createId = userId;
        UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
        UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
        UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
        UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
        UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID = userId;
        //service call
        memiuServices.postSaveOverideDetails(UpdateOverrideLikeSrcEditDetails)
            .then((response) => {
                //function handles success condition
                let saveStatus = response.data.status;
                if (saveStatus == 1) {

                    if (pageNumber >= updateoverridesku.length - 1) {
                        AppData.setAlertBox(true, "No more items under this department.");
                        history.push(RouteBase.MEMI13);
                    }
                    else {
                        setPageNumber(pageNumber + 1)
                    }
                }
            })
            .catch((error) => {
                //function handles error condition
            })
        AppData.setConfirmationModal(false);
    }

    const options = ["MarkOutOfScope", "MarkAsDead", "ManualMap"]

    const handleChecked = (e, id) => {
        if (e.target.checked) {
            setOption(id);
            document.getElementById(id).style.display = "block"
        }
        else {
            setOption("")
            document.getElementById(id).style.display = "none"
        };

        options.forEach((option) => {
            if (option !== id) {
                document.getElementById(option).style.display = "none"
            }
        })
    }


    const handlePrev = () => {

        if (pageNumber <= 0) {
            AppData.setAlertBox(true, "This is the first item under this department.")
        }
        else {
            setPageNumber(pageNumber - 1)
            options.forEach((option) => {
                document.getElementById(option).style.display = "none"
            })
            setOption("")
        }
    }

    const handleNext = () => {
        if (pageNumber >= updateoverridesku.length - 1) {
            AppData.setAlertBox(true, "This is the last item under this department.")
        }
        else {
            setPageNumber(pageNumber + 1)
            options.forEach((option) => {
                document.getElementById(option).style.display = "none"
            })
            setOption("")
        }

    }

    const upcVd = UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.upcVoList.map((upcVo) => {
        return { label: `${upcVo.upc} ${upcVo.primaryUPCInd}`, value: "1" }
    }) : []

    const handleTableModel = (type = "source") => {
        const columnData = UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.upcVoList.map((data) => {
            return { "UPCs & Unit Type": data.upc }
        }) : []
        AppData.setTableModal(true, ["UPCs & Unit Type"], columnData)
    }

    return (
        <Grid item xs={4} className="overideProcessContainer overideProcessContainerBoxShadow">
            <Grid container>
                <Grid item xs={12} className="overideProcessTitle">
                    Source Data Review/Clean Up
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle">
                        Product SKU
                    </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle">
                        {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.productSKU : ""}
                    </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Primary UPC </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.primaryUPCVo.upc : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Item Desc </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.itmDescrbtn : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> WHSE Desc </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.whseItmDescrbtn : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> S &amp; S Desc </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.rtlItmDescrbtn : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Internet Desc </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.intenetItemDescrbtn : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> POS Desc </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.posDescrbtn : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Case UPC </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.caseUPC : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Pack </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.packWhse : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Desc Size </Grid>
                    <Grid item xs={9} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.szDesc : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> VCF </Grid>
                    <Grid item xs={2} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.vdCnvFactor : ""} </Grid>
                    <Grid item xs={2} className="overideProcessRowTitle"> Num Size </Grid>
                    <Grid item xs={5} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? `${UpdateOverrideManualSearch.uiEceptionSrcDto.sizeNbr} ${UpdateOverrideManualSearch.uiEceptionSrcDto.szUom}` : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Usage </Grid>
                    <Grid item xs={2} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.itmUsgeInd : ""} </Grid>
                    <Grid item xs={2} className="overideProcessRowTitle"> Product Src </Grid>
                    <Grid item xs={5} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.productSrcCd : ""} </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Display </Grid>
                    <Grid item xs={2} className="overideProcessRowSubTitle">
                        {
                            UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ?
                                UpdateOverrideManualSearch.uiEceptionSrcDto.dspFlag : ""
                        }
                    </Grid>
                    <Grid item xs={2} className="overideProcessRowTitle"> UPCs </Grid>
                    <Grid item xs={5} className="overideProcessRowSubTitle" style={{ display: "flex" }}>
                        <DropDownMemi
                            alignItems="inline"
                            label=""
                            options={upcVd}
                            value={"1"}
                            disableNone
                            classNameMemi="dropdownOverideProcessCont"
                        />
                        <Add
                            style={{ cursor: "pointer", fontSize: "15", color: "black" }}
                            onClick={handleTableModel}
                        />

                    </Grid>
                </Grid>
                <Grid container className="overideProcessRow">
                    <Grid item xs={3} className="overideProcessRowTitle"> Cost </Grid>
                    <Grid item xs={2} className="overideProcessRowSubTitle"> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? `$${UpdateOverrideManualSearch.uiEceptionSrcDto.costItm}` : ""} </Grid>
                    <Grid item xs={3} className="overideProcessRowTitle"> One Time Buy  Ind </Grid>
                    <Grid item xs={3}  style={{paddingLeft: "16px"}}> {UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto ? UpdateOverrideManualSearch.uiEceptionSrcDto.loglInd : "a"} </Grid>
                </Grid>
                <Grid item xs={12} style={{ display: 'flex', alignItems: "center", marginTop: "40px" }}>
                    <strong> Mark Out Of Scope </strong><input type="checkbox" size="small" color="default" checked={option === "MarkOutOfScope"} onChange={(e) => handleChecked(e, "MarkOutOfScope")} disabled={disableMarkOutOfScope} />
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenButton"
                        btnval="Save & Next"
                        onClick={() => AppData.setConfirmationModal(true, handleMarkOutOfScope, "confirmation", "Do you really wants to move this item out of automated process?")}
                        idCss="MarkOutOfScope"
                        btnsize="small"
                    />


                    <label style={{marginLeft:"auto"}}> <strong> Mark as Dead </strong> </label> <input type="checkbox" size="small" color="default" checked={option === "MarkAsDead"} onChange={(e) => handleChecked(e, "MarkAsDead")} disabled={disableMarkAsDead} />
                    <div style={{minWidth:"6rem"}}>
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenButton"
                            btnval="Save & Next"
                            onClick={() => AppData.setConfirmationModal(true, handleMarkDead, "textBox", "Enter the reason for marking this item as dead")}
                            idCss="MarkAsDead"
                        />
                    </div>
                </Grid>
                <Grid item xs={12} style={{ display: 'flex', alignItems: "center", marginTop: "10px" }}>
                    <strong>  Manual Map </strong> <input type="checkbox" size="small" color="default" checked={option === "ManualMap"} onChange={(e) => handleChecked(e, "ManualMap")} disabled={disableManualMap} />
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenButton"
                        btnval="Save & Next"
                        onClick={handleManualMap}
                        idCss="ManualMap"
                    />
                </Grid>
                <Grid item xs={12} style={{ paddingTop: "10px", display: `${updateoverridesku && updateoverridesku.length > 1 ? "flex" : "none"}` }}>
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenButton"
                        btnval="Prev"
                        onClick={handlePrev}
                    />
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenButton overideSaveButton"
                        btnval="Next"
                        onClick={handleNext}
                        btndisabled={false}
                    />
                </Grid>
            </Grid>
        </Grid>
    )
}
