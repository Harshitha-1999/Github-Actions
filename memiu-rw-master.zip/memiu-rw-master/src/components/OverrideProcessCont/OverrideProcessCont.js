import React, { useState, useContext, useEffect } from "react";
import ApplicationContext from "../../context/ApplicationContext";
import LikeItem from "./LikeItem";
import { Grid } from "@material-ui/core";
import SourceDataReview from "./SourceDataReview";
import BorrowCicAttributes from "./BorrowCicAttributes";
function OverrideProcessCont(props) {

  const AppData = useContext(ApplicationContext);
  const { UpdateOverrideManualSearch } = AppData;
  const [option, setOption] = useState("");
  const [disableManualMap, setDisableManualMap] = useState(false);
  const [disableMarkAsDead, setDisableMarkAsDead] = useState(false);
  const [disableMarkOutOfScope, setDisableMarkOutOfScope] = useState(false);
  const [newItemDto, setItemDto] = useState({})
  const [disableSave, setDisableSave] = useState(false);
  const [disableSaveNext, setDisableSaveNext] = useState(false)
  const [dontBorrow, setDontBorrow] = useState(false);
  const [alreadySavedItem, setAlreadySavedItem] = useState("")
  const [uomCode, setUomCode] = useState("")
  const [selectedId, setSelectedId] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [updUsgeInd, setUpdUsgeInd] = useState("")
  const [smicDetail, SetSmicDetail] = useState('')
  useEffect(() => {

    document.getElementById("MarkOutOfScope").style.display = "none";
    document.getElementById("MarkAsDead").style.display = "none";
    document.getElementById("ManualMap").style.display = "none"
    setSelectedId(null)
    setOption("");
    setDontBorrow(false)
    setDisableSave(false);
    setDisableSaveNext(false)
    setDisableManualMap(false);
    setDisableMarkAsDead(false);
    setDisableMarkOutOfScope(false);
    setAlreadySavedItem("")
    setItemDto({})
  
    setUpdUsgeInd(UpdateOverrideManualSearch && UpdateOverrideManualSearch.newItemDto ? UpdateOverrideManualSearch.newItemDto.updUsgeInd : "")
    setUomCode(UpdateOverrideManualSearch && UpdateOverrideManualSearch.newItemDto ? UpdateOverrideManualSearch.newItemDto.updSizeUom : "")
    if (!UpdateOverrideManualSearch || !UpdateOverrideManualSearch.uiEceptionSrcDto) { return }

    if (UpdateOverrideManualSearch.uiEceptionSrcDto.excptnProInd === "C") {

      if (UpdateOverrideManualSearch.uiEceptionSrcDto.markedAsDead === true) {
        setAlreadySavedItem("Item has been marked as dead.");
        setDisableMarkAsDead(true)
        setOption("MarkAsDead");
        setDisableManualMap(true);
        setDisableMarkOutOfScope(true);
        setDisableSave(true);
        setDisableSaveNext(true);
      }
      else if (UpdateOverrideManualSearch.uiEceptionSrcDto.manualMapped === true) {
        setAlreadySavedItem("Item marked for old conversion process.");
        setDisableMarkAsDead(true)
        setOption("MarkOutOfScope");
        setDisableManualMap(true);
        setDisableMarkOutOfScope(true);
        setDisableSaveNext(true);
        setDisableSave(true);
      }
      else if (UpdateOverrideManualSearch.uiEceptionSrcDto.markedForManualMapping === true) {
        setAlreadySavedItem("Item has been manually mapped.");
        setDisableMarkAsDead(true)
        setOption("ManualMap");
        setDisableManualMap(true);
        setDisableMarkOutOfScope(true);
        setDisableSaveNext(true);
        setDisableSave(true);
      }
      else {
        setAlreadySavedItem("Item has already been worked.");
      }
      for (let i = 0; i < UpdateOverrideManualSearch.likeItems.length; i++) {
        setDisableManualMap(true);
      }

    }
   
    setItemDto(UpdateOverrideManualSearch && UpdateOverrideManualSearch.newItemDto ? UpdateOverrideManualSearch.newItemDto : {})
    let data = [];
    if (UpdateOverrideManualSearch.uiEceptionSrcDto) {
      data.push({ id: 0, ...UpdateOverrideManualSearch.uiEceptionSrcDto, likeItem: true });
    }
    if (UpdateOverrideManualSearch.likeItems) {
      let index = 1
      UpdateOverrideManualSearch.likeItems.forEach((x) => {

        if (x.mostRecommendedItem && UpdateOverrideManualSearch.uiEceptionSrcDto.excptnProInd !== "C") {
          let newItemDtoTemp = props.loadUsageTypeCombo(x)
          console.log(newItemDtoTemp)
          setItemDto(x);
          setSelectedId(index);
        }
        data.push({ id: index, ...x, hide: false })
        index = index + 1;

      })
    }
    setTableData(data);

  }, [UpdateOverrideManualSearch])



  const handleDontBorrow = (checked, id = null) => {
    setDontBorrow(checked)
    if (checked) {
      setDisableManualMap(true)
      SetSmicDetail(AppData.smicDetails);
      let newItemDtoTemp = UpdateOverrideManualSearch.likeItems[0];

      if ((UpdateOverrideManualSearch.uiEceptionSrcDto.markedAsDead === true || UpdateOverrideManualSearch.uiEceptionSrcDto.manualMapped === true) && UpdateOverrideManualSearch.likeItems[1] !== null) {
        newItemDtoTemp.updUsgeInd = newItemDtoTemp.likeItems[1].updUsgeInd;
        newItemDtoTemp.updUsageTypInd = UpdateOverrideManualSearch.likeItems[1].updUsageTypInd;
        newItemDtoTemp.grpCd = UpdateOverrideManualSearch.likeItems[1].grpCd;
        newItemDtoTemp.ctgryCd = UpdateOverrideManualSearch.likeItems[1].ctgryCd;
        newItemDtoTemp.clsCd = UpdateOverrideManualSearch.likeItems[1].clsCd;
        newItemDtoTemp.sbClsCd = UpdateOverrideManualSearch.likeItems[1].sbClsCd;
        newItemDtoTemp.subSbClass = UpdateOverrideManualSearch.likeItems[1].subSbClass;
        newItemDtoTemp.productionGrpCd = UpdateOverrideManualSearch.likeItems[1].productionGrpCd;
        newItemDtoTemp.productionCtgryCd = UpdateOverrideManualSearch.likeItems[1].productionCtgryCd;
        newItemDtoTemp.productionClsCd = UpdateOverrideManualSearch.likeItems[1].productionClsCd;
        setUomCode(UpdateOverrideManualSearch.likeItems[1].updSizeUom);
        let likeItemsTemp = UpdateOverrideManualSearch.likeItems;

        if (likeItemsTemp[1].grpCd.toString().length == 1) {
          likeItemsTemp[1].grpCd = '0' + likeItemsTemp[1].grpCd;
        }
        if (likeItemsTemp[1].ctgryCd.toString().length == 1) {
          likeItemsTemp[1].ctgryCd = '0' + likeItemsTemp[1].ctgryCd;
        }
        
        newItemDtoTemp.productClsCd = UpdateOverrideManualSearch.likeItems[1].grpCd + '' + UpdateOverrideManualSearch.likeItems[1].ctgryCd;
        newItemDtoTemp = props.loadUsageTypeCombo(newItemDtoTemp)
        AppData.setMemi14({ UpdateOverrideManualSearch: { ...UpdateOverrideManualSearch, likeItems: likeItemsTemp } });
        setItemDto(newItemDtoTemp);
      }

      else {
        newItemDtoTemp.updUsgeInd = UpdateOverrideManualSearch.newItemDto.updUsgeInd;
        newItemDtoTemp.updUsageTypInd = UpdateOverrideManualSearch.newItemDto.updUsageTypInd;
        newItemDtoTemp.grpCd = UpdateOverrideManualSearch.newItemDto.grpCd;
        newItemDtoTemp.ctgryCd = UpdateOverrideManualSearch.newItemDto.ctgryCd;
        newItemDtoTemp.clsCd = UpdateOverrideManualSearch.newItemDto.clsCd;
        newItemDtoTemp.sbClsCd = UpdateOverrideManualSearch.newItemDto.sbClsCd;
        newItemDtoTemp.subSbClass = UpdateOverrideManualSearch.newItemDto.subSbClass;
        newItemDtoTemp.productionGrpCd = UpdateOverrideManualSearch.newItemDto.productionGrpCd;
        newItemDtoTemp.productionCtgryCd = UpdateOverrideManualSearch.newItemDto.productionCtgryCd;
        newItemDtoTemp.productionClsCd = UpdateOverrideManualSearch.newItemDto.productionClsCd;
        newItemDtoTemp.deptName = UpdateOverrideManualSearch.newItemDto.deptName
        setUomCode(UpdateOverrideManualSearch && UpdateOverrideManualSearch.newItemDto ? UpdateOverrideManualSearch.newItemDto.updSizeUom : "")

        let grpCd = "";
        let ctgryCd = "";
        if(UpdateOverrideManualSearch.newItemDto.grpCd && UpdateOverrideManualSearch.newItemDto.grpCd.length === 1) {
          grpCd = "0" + UpdateOverrideManualSearch.newItemDto.grpCd;
        }
        if(UpdateOverrideManualSearch.newItemDto.ctgryCd && UpdateOverrideManualSearch.newItemDto.ctgryCd.length === 1) {
          ctgryCd = "0" + UpdateOverrideManualSearch.newItemDto.ctgryCd;
        }
        newItemDtoTemp.productClsCd = (grpCd + ctgryCd).trim()
        setItemDto(newItemDtoTemp)
      }

      props.loadSmicDesc(newItemDtoTemp);
    }
    else {
      if (id) {
        setItemDto(tableData[id]);
      }
      else if (selectedId) {
        setItemDto(tableData[selectedId]);
      }
      else {
        setItemDto(UpdateOverrideManualSearch.newItemDto ? UpdateOverrideManualSearch.newItemDto : {})
      }

      // ASmicTempObject;
      for (var i = 0; i < UpdateOverrideManualSearch.likeItems.length; i++) {
        if (UpdateOverrideManualSearch.mostRecommendedItem == true) {
          setDisableManualMap(false)
        }
        else {
          setDisableManualMap(true)
        }
      }

    }
    props.loadUomList();
  }

  return (
    <Grid container>
      <LikeItem
        setItemDto={setItemDto}
        tableData={tableData}
        selectedId={selectedId}
        setOption={setOption}
        setSelectedId={setSelectedId}
        setTableData={setTableData}
        loadSmicDesc={props.loadSmicDesc}
        handleDontBorrow={handleDontBorrow}
        loadUsageTypeCombo={props.loadUsageTypeCombo}
      />
      <Grid item xs={12} className="overideProcessCheckBox">
        <input type="checkbox"
          size="small"
          color="default"
          checked={dontBorrow}
          onClick={(e) => handleDontBorrow(e.target.checked)}
        />
        &nbsp; &nbsp;
        Don't borrow any attributes
      </Grid>
      <SourceDataReview
        disableManualMap={disableManualMap}
        disableMarkAsDead={disableMarkAsDead}
        disableMarkOutOfScope={disableMarkOutOfScope}
        option={option}
        setOption={setOption}
        pageNumber={props.pageNumber}
        setPageNumber={props.setPageNumber}
      />
      <BorrowCicAttributes
        newItemDto={newItemDto}
        alreadySavedItem={alreadySavedItem}
        updUsgeInd={updUsgeInd}
        uomCode={uomCode}
        setUomCode={setUomCode}
        disableSave={disableSave || option!==""}
        disableSaveNext={disableSaveNext|| option!==""}
        updUsgeIndOptions2={props.updUsgeIndOptions2}
        pageNumber={props.pageNumber}
        setPageNumber={props.setPageNumber}
        option={option}
      />
    </Grid>
  );
}

export default OverrideProcessCont;
