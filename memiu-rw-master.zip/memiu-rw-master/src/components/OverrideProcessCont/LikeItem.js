import React, { useState, useContext } from 'react'
import { Grid } from "@material-ui/core";
import TableMemi from '../TableMemi/TableMemi';
import ButtonMemi from '../ButtonMemi/ButtonMemi'
import ApplicationContext from "../../context/ApplicationContext";

export default function LikeItem(props) {
    
    const { setItemDto, tableData, selectedId, setTableData, setSelectedId, loadSmicDesc, handleDontBorrow,loadUsageTypeCombo } = props;
    const [unhideChecked, setUnhideChecked] = useState(false)
    const AppData = useContext(ApplicationContext);
    const columns = [
        {
            field: " ",
            headerName: " ",
            width: 2,
            renderCell: (params) => (
                <input
                    type="radio"
                    style={{ display: `${params.row.id > 0 ? "block" : "none"}`, transform: "scale(1.1)" }}
                    name="radio-buttons"
                    checked={selectedId === params.row.id}
                    onClick={() => handleSelectRow(params)}
                />
            ),
            sortable:false
        },
        {
            field: 'updItmDesc',
            headerName: 'Item Description',
            width: 200,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => { return !params.value && params.row.id === 0 ? params.row.itmDescrbtn : params.value }
        },
        {
            field: 'updSize',
            headerName: 'Size',
            width: 60,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => {
                return !params.value && params.row.id === 0 ? params.row.updSizeNmbr : params.value
            }
        },
        {
            field: 'vendConvFactor',
            headerName: 'VCF',
            width: 60,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => { return !params.value && params.row.id === 0 ? params.row.vdCnvFactor : params.value }
        },
        {
            field: 'packwhse',
            headerName: 'Pack',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => { return !params.value && params.row.id === 0 ? params.row.packWhse : params.value }
        },
        {
            field: 'updUsgeInd',
            headerName: 'Usage',
            width: 80,
            headerClassName: "MultiUnitTableHeader",
            sortable: false,
            valueGetter: (params) => { return !params.value && params.row.id === 0 ? params.row.itmUsgeInd : params.value }
        },
        {
            field: 'smicCodeForDisplay',
            headerName: 'SMIC',
            width: 72,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",


        },
        {
            field: 'updDispFlag',
            headerName: 'Display',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => { return params.row.id === 0 && !params.value ? params.row.dspFlag : params.value }

        },
        {
            field: 'logicalInd',
            headerName: 'One Time Buy Ind',
            width: 80,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",

        },
        {
            field: 'innerPack',
            headerName: 'Inner Pack',
            width: 75,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
        },
        {
            field: 'productSrcCd',
            headerName: 'Product Src',
            width: 80,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => { return !params.value && params.row.id === 0 ? params.row.productSrcCd : params.value }

        },
        {
            field: 'trueDSDFlag',
            headerName: 'True DSD',
            width: 70,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            sortable: false,

        },
        {
            field: 'dcList',
            headerName: 'DC Count',
            width: 55,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => {
                return `${params.value ? params.value.length : ""}`
            }
        },
        {
            field: 'dtaOverCic',
            headerName: 'CIC',
            width: 80,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
        },
        {
            field: 'statusCorp',
            headerName: 'Corp Status',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",

        },
        {
            field: 'caseUPCForDisplay',
            headerName: 'Case UPC',
            width: 100,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            valueGetter: (params) => { return !params.value && params.row.id === 0 ? params.row.caseUPC : params.value }

        },
        {
            field: 'unhide',
            headerName: <div>Unhide <br /> <input type="checkbox" checked={unhideChecked} onChange={(e) => handleUnHide(e.target.checked)} style={{ transform: "scale(1.4)" }} /> </div>,
            width: 70,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                params.row.id !== 0 ?
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenButton"
                        btnval="Hide"
                        onClick={() => handleHide(params.row.id)}
                        btnsize="sm"
                    /> : ""
            )
        },
    ];

    const handleSelectRow = (params) => {
        setSelectedId(params.row.id);
        setUnhideChecked(false)
        loadSmicDesc(params.row)
        handleDontBorrow(false, params.row.id);

    }

    const handleHide = (id) => {

        setUnhideChecked(false);
        setTableData((prevState) => {
            return prevState.map((data) => {
                if (data.id === id) {
                    return { ...data, hide: true }
                }
                return data
            })
        })
        if (id + 1 < tableData.length) {
            setSelectedId(id + 1);
            let newItemDto = tableData[id+1];
            newItemDto = loadUsageTypeCombo(newItemDto)
            setItemDto(newItemDto);
        }
        else if (id + 1 >= tableData.length) {
            if (selectedId === id) {
                setSelectedId(null);
            }
            handleDontBorrow(true);
        }



    }

    const handleUnHide = (checked) => {
        setUnhideChecked(checked)
        if (checked) {
            setTableData((prevState) => {
                return prevState.map((data) => {
                    return { ...data, hide: false }
                })
            })
        }
    }


    return (
        <Grid item xs={12} className="overideProcessContainer overideProcessContainerBoxShadow">
            <div className="overideProcessTitle"> Like Items </div>
            <TableMemi
                classnameMemi="tableMultiScreen tableOverideProcess"
                data={tableData.filter((data) => { return !data.hide && data.likeItem })}
                columns={columns}
                selectionType="radio"
                autoHeight
                density="compact"
                hideFooter
            />
        </Grid >
    )
}
