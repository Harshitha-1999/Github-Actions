import React, { useState, useContext, useEffect } from 'react'
import { Grid, Checkbox, OutlinedInput } from "@material-ui/core";
import ApplicationContext from "../../context/ApplicationContext";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import TextFieldMemi from "components/TextField/TextFieldMemi";
import ButtonMemi from '../ButtonMemi/ButtonMemi'
import { Add } from "@material-ui/icons";
import { useHistory } from 'react-router';
import { RouteBase } from 'routes/constants';
import { memiuServices } from 'api/memiu/memiuService';
import { authTokenCookie } from 'utils';
import {
    smicFieldFirstColumnValidation,
    smicFieldSecondColumnValidation,
    PrivateLabelFieldValidation,
    DescSizeFieldValidation,
    NumSizeFieldValidation,
    SizeUOMFieldValidation,
    UsageIndFieldValidation,
    DisplayFieldValidation,
    ItemDescFieldValidation,
    WhseDescFieldValidation,
    SsDescFieldValidation,
    UsageTypeFieldValidation,
    InternetDescFieldValidation,
    PosDescFieldValidation,
    ProductClassCodeValidation,
    specialCharacterValidation,
    numberValidation
} from 'utils';

export default function BorrowCicAttributes(props) {
    const { newItemDto, alreadySavedItem, updUsgeInd, uomCode, setUomCode, disableSave, disableSaveNext, updUsgeIndOptions2, pageNumber, setPageNumber} = props
    const AppData = useContext(ApplicationContext);
    const { UpdateOverrideManualSearch, smicDetails, updateoverridesku, overideServiceKey, companyId, divisionId, overideServiceUsageType } = AppData
    const history = useHistory();
    const updUsgeIndOptions = [
        { value: "E", label: "E (Expense)" },
        { value: "M", label: "M (Material)" },
        { value: "Q", label: "Q (Coupons)" },
        { value: "R", label: "R (Resale)" }
    ]
    const [errorUomCode, setErrorUomCode] = useState(false);
    const uomCodeOption = AppData.uomList.map((data) => {
        return { label: data.uomCode, value: data.uomCode }
    })
    const upcVd = newItemDto && newItemDto.upcVoList ? newItemDto.upcVoList.map((upcVo) => {
        return { label: `${upcVo.upc} ${upcVo.primaryUPCInd}`, value: upcVo.upc }
    }) : []
    const [itemDesc, setItemDesc] = useState("");
    const [errorItemDesc, setErrorItemDesc] = useState(false);
    const [whseDesc, setWhseDesc] = useState("");
    const [errorWhseDesc, setErrorWhseDesc] = useState(false);
    const [ssDesc, setSsDesc] = useState("");
    const [errorSsDesc, setErrorSsDesc] = useState(false);
    const [internetDesc, setInternetDesc] = useState("");
    const [errorInternetDesc, setErrorInternetDesc] = useState(false)
    const [posDesc, setPosDesc] = useState("");
    const [errorPosDesc, setErrorPosDesc] = useState(false);
    const [descSize, setDescSize] = useState("");
    const [errorDescSize, setErrorDescSize] = useState(false);
    const [numSize, setNumSize] = useState("");
    const [errorNumSize, setErrorNum] = useState("");
    const [smicDesc, setSmicDesc] = useState("");
    const [errorSmicDesc, setErrorSmicDesc] = useState(false);
    const [convTeamComments, setConvTeamComments] = useState("");
    const [prodClassCode, setProdClassCode] = useState("");
    const [errorProdClassCode, setErrorProdClassCode] = useState(false)
    const [errorGroupCode, setErrorGroupCd] = useState(false);
    const [errorCategoryCd, setErrorCategoryCd] = useState(false)
    const [errorUsageInd, setErrorUsageInd] = useState(false);
    const [errorPrivateLabel, setErrorPrivateLabel] = useState(false);
    const [errorDisplayValid, setErrorDisplayValid] = useState(false);
    const [errorUsageType, setErrorUsageType] = useState(false);
    const [selectedUpc, setSelectedUpc] = useState("")

    // console.log(newItemDto)

    useEffect(() => {
        setItemDesc(newItemDto ? newItemDto.updItmDesc : "")
        setWhseDesc(newItemDto ? newItemDto.updWhseItmDesc : "")
        setSsDesc(newItemDto ? newItemDto.updRtlItmDesc : "")
        setInternetDesc(newItemDto ? newItemDto.updIntenetItemDesc : "")
        setPosDesc(newItemDto ? newItemDto.updPosDesc : "")
        setDescSize(newItemDto ? newItemDto.updSize : "")
        setNumSize(newItemDto ? newItemDto.updSizeNmbr : "")
        setSmicDesc(smicDetails ? smicDetails : "")
        setConvTeamComments(newItemDto ? newItemDto.covTeamComment : "")
        setProdClassCode(newItemDto ? newItemDto.productClsCd : "")

        setSelectedUpc(newItemDto && newItemDto.upcVoList ? newItemDto.upcVoList[0].upc : "")
    }, [newItemDto, smicDetails])

    const handleTableModel = () => {
        const columnData = newItemDto && newItemDto.upcVoList ? newItemDto.upcVoList.map((data) => {
            return { "UPCs & Unit Type": data.upc }
        }) : []
        AppData.setTableModal(true, ["UPCs & Unit Type"], columnData)
    }

    const UpdateOverride = (type) => {

        let UpdateOverrideLikeSrcEditDetails = UpdateOverrideManualSearch;
        UpdateOverrideLikeSrcEditDetails.newItemDto.updItmDesc = itemDesc;
        UpdateOverrideLikeSrcEditDetails.newItemDto.updRtlItmDesc = ssDesc;
        UpdateOverrideLikeSrcEditDetails.newItemDto.updIntenetItemDesc = internetDesc;
        UpdateOverrideLikeSrcEditDetails.newItemDto.updPosDesc = posDesc;
        UpdateOverrideLikeSrcEditDetails.newItemDto.updSize = descSize;
        UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr = numSize;
        UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd = prodClassCode;
        UpdateOverrideLikeSrcEditDetails.newItemDto.covTeamComment = convTeamComments
        UpdateOverrideLikeSrcEditDetails.newItemDto.updWhseItmDesc = whseDesc
        UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom = uomCode
        let isSmicFirstValid = smicFieldFirstColumnValidation(UpdateOverrideLikeSrcEditDetails, setErrorGroupCd);
        let isSmicSecondValid = smicFieldSecondColumnValidation(UpdateOverrideLikeSrcEditDetails, setErrorCategoryCd);
        let isPrivateLabelValid = PrivateLabelFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorPrivateLabel);
        let isDescSizeValid = DescSizeFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorDescSize);
        let isNumSizeValid = NumSizeFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorNum);
        let isSizeUomValid = SizeUOMFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorUomCode);
        let isUsageIndValid = UsageIndFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorUsageInd);
        let isUsageTypeValid = UsageTypeFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorUsageType);
        let isDisplayValid = DisplayFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorDisplayValid);;;
        let isItemDescValid = ItemDescFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorItemDesc);
        let isWhseDescValid = WhseDescFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorWhseDesc);
        let isSsDescValid = SsDescFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorSsDesc);
        let isInternetDescValid = InternetDescFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorInternetDesc);
        let isPosDescValid = PosDescFieldValidation(UpdateOverrideLikeSrcEditDetails, setErrorPosDesc);
        let isProductClassCodeValid = ProductClassCodeValidation(UpdateOverrideLikeSrcEditDetails, setErrorProdClassCode);

        let isCharacterValid = specialCharacterValidation(UpdateOverrideLikeSrcEditDetails);
        let isNumberValid = numberValidation(UpdateOverrideLikeSrcEditDetails);
        if (!isNumberValid) {
            AppData.setAlertBox(true, "Invalid number in Num Size field");
            return;
        }
        else if (!isCharacterValid) {
            AppData.setAlertBox(true, "Special characters not allowed.");
            return;
        }

        else if (isSmicFirstValid === false || isSmicSecondValid == false || isPrivateLabelValid == false || isDescSizeValid == false || isNumSizeValid == false || isSizeUomValid == false || isUsageIndValid == false || isUsageTypeValid == false || isDisplayValid == false || isItemDescValid == false || isWhseDescValid == false || isSsDescValid == false || isInternetDescValid == false || isPosDescValid == false || isProductClassCodeValid == false) {
            AppData.setAlertBox(true, "Highlighted fields are mandatory.");
            return;
        }

        else if (isCharacterValid == true && isNumberValid == true) {

            if (UpdateOverrideManualSearch.uiEceptionSrcDto.itmUsgeInd !== updUsgeInd || UpdateOverrideManualSearch.uiEceptionSrcDto.itmUsgeTypInd !== updUsgeInd) {
                AppData.setConfirmationModal(true, () => save(UpdateOverrideLikeSrcEditDetails), "confirm", "Usage Ind or Usage Type is different from incoming data. Do you want to proceed?")
            } else {
                save(UpdateOverrideLikeSrcEditDetails, type);
            }
        }


    }

    //save
    const save = (UpdateOverrideLikeSrcEditDetails, type) => {
        const { userId } = authTokenCookie();


        UpdateOverrideLikeSrcEditDetails.newItemDto.createId = userId;
        UpdateOverrideLikeSrcEditDetails.newItemDto.augOverCmplnInd = 'Y';
        ////////////
        UpdateOverrideLikeSrcEditDetails.newItemDto.dcPackDesc = UpdateOverrideLikeSrcEditDetails.newItemDto.packwhse;
        UpdateOverrideLikeSrcEditDetails.newItemDto.dcSizeDsc = UpdateOverrideLikeSrcEditDetails.newItemDto.updSize;
        UpdateOverrideLikeSrcEditDetails.newItemDto.ring = 0;
        UpdateOverrideLikeSrcEditDetails.newItemDto.hicone = 0;
        ////////////
        UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.updatedUserID = userId;

        memiuServices.postSaveOverideDetails(UpdateOverrideLikeSrcEditDetails)
            .then((response) => {
                //function handles success condition
                let saveStatus = response.data.status;
                if (saveStatus == 1) {
                    AppData.setAlertMessage(true, "success", "Saved successfully!");
                    if (overideServiceKey == "Perishables" || overideServiceKey == "Bakery") {
                        triggerForceNewPerishables();
                    }
                    if (type === "Next") {
                        if (pageNumber >= updateoverridesku.length - 1) {
                            AppData.setAlertBox(true, "No more items under this department.");
                            history.goBack();
                        }
                        else {
                            setPageNumber(pageNumber + 1)
                        }
                    }
                }
                if (saveStatus == 2) {
                    let savedObject = response.data;
                    let alertMsg = <div style={{ fontSize: "18px", textAlign: "center" }}>
                      Please correct the following errors and try again.
        
                      {
                        savedObject.errorMessages.map((message, index) => (
                          <div style={{ color: "red", fontSize: "15px", border: "1px solid #edf0f1", marginTop: "15px", backgrounColor: index % 2 === 0 ? "#f9fafa" : "#ffffff" }}>
                            {message}
                          </div>
                        ))
                      }
                    </div>
                    AppData.setAlertBox(true, alertMsg);
                }
                if (saveStatus == 0) {
                    triggerForceNewPerishables();
                }
            })
            .catch((error) => {
                //function handles error condition
                console.log(error)
            })
        AppData.setConfirmationModal(false);
    }

    const createMapRequestsForForceNew = () => {
        let mappingRequests = [];
        let updatedUserID = null;
        const { userId } = authTokenCookie();
        updatedUserID = userId;

        let upcList = newItemDto.upcVoList.map((upcVo) => {
            return upcVo.upc
        })

        upcList.forEach((upc) => {
            if (upc) {
                let mappingrequest = {};
                mappingrequest.companyID = companyId;
                mappingrequest.divisionID = divisionId;
                mappingrequest.sku = updateoverridesku[0]
                mappingrequest.upc = upc;
                mappingrequest.mappingstatus = "FORCE_NEW";
                mappingrequest.mappingType = "FORCE_NEW";
                mappingrequest.updatedUserId = updatedUserID;
                if (overideServiceKey == "Perishables") {
                    mappingrequest.matchedItemTypeCd = overideServiceUsageType;
                } else {
                    mappingrequest.targetTypeIndicator = overideServiceUsageType;
                }
                mappingRequests.push(mappingrequest);
            }
        });

        return mappingRequests
    }

    const triggerForceNewPerishables = () => {
        let request = createMapRequestsForForceNew();
        if (overideServiceKey === "Perishables") {
            memiuServices.perishableForceNew(request)
                .finally(() => {
                    AppData.setOverideServiceKey("")
                    history.goBack();
                })
        } else if (overideServiceKey === "Bakery") {
            memiuServices.bakeryForceNew(request)
                .finally(() => {
                    AppData.setOverideServiceKey("")
                    history.goBack();
                })
        }
        AppData.setAugmentationServiceKey("");
        AppData.setOverideServiceKey("");
    }


    /**
     *  Save update override function
     */

    const OverrideValidateSave = (type) => {
        if (prodClassCode) {
            let prdclscode = prodClassCode.toString();

            var dummyGrpCode = "GC";
            if (prdclscode !== "" && prdclscode !== null && prdclscode.length !== 0) {
                memiuServices.getTargetProdClassValidate(prdclscode, dummyGrpCode)
                    .then((response) => {
                        //function handles success condition
                        if (response.data === true) {
                            setErrorProdClassCode(false)
                            UpdateOverride(type);
                        }
                        else {
                            AppData.setAlertBox(true, "Invalid Product Class Code.")
                            setErrorProdClassCode(true);
                            return;
                        }

                    })
                    .catch((error) => {

                        //function handles error condition
                        setErrorProdClassCode(true);
                        AppData.setAlertBox(true, "Invalid Product Class Code.")
                        return;
                    });
            }
            else {

                setErrorProdClassCode(true);
                AppData.setAlertBox(true, "Invalid Product Class Code.")
                return;
            }
        }
    }

    const handleGoHome = () => {
        AppData.setMemi03SkuPayload({});
        history.goBack()
    }


    return (
        <Grid item xs={8} className="overideProcessContainer overideProcessContainerBoxShadow">
            <Grid item xs={12} className="overideProcessTitle">
                Borrow CIC Attributes
                <span style={{ fontWeight: "bold", color: "yellow", textAlign: "right" }}> [**Editable fields will be used for item conversion and other fields are only for reference]</span>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={2}></Grid>
                <Grid item xs={10} style={{ color: "red", fontWeight: "bold" }}>
                    {alreadySavedItem}
                </Grid>
            </Grid>
            <Grid item xs={12} className="overideProcessRow">
                <TextFieldMemi
                    // value={productHierarchyName}
                    // setTextValue={(value) => setProductHierarchyName(value)}
                    label="Primary UPC"
                    alignItems="row"
                    TextFieldClass="overideContDisabledTextField"
                    LabelClass="overideProcessRowTitle"
                    labelXs={2}
                    textFieldXs={10}
                    disabled
                    fullWidth={false}
                    value={newItemDto && newItemDto.primaryUPCVo ? newItemDto.primaryUPCVo.upc : ""}
                />
            </Grid>
            <Grid item xs={12} className="overideProcessRow">
                <TextFieldMemi
                    // value={productHierarchyName}
                    // setTextValue={(value) => setProductHierarchyName(value)}
                    label="Item Desc"
                    alignItems="row"
                    TextFieldClass="overideContTextField"
                    LabelClass="overideProcessRowTitle"
                    labelXs={2}
                    textFieldXs={6}
                    autoFill
                    value={itemDesc}
                    setTextValue={((value) => setItemDesc(value))}
                    error={errorItemDesc}
                />
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={8}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="WHSE Desc"
                        alignItems="row"
                        TextFieldClass="overideContTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={3}
                        textFieldXs={9}
                        value={whseDesc}
                        autoFill
                        setTextValue={(value) => setWhseDesc(value)}
                        error={errorWhseDesc}

                    />
                </Grid>

                <Grid item xs={4}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="True DSD"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle overideProcessRowPaddingLeft"
                        labelXs={3}
                        textFieldXs={5}
                        disabled
                        value={newItemDto && newItemDto.trueDSDFlag !== null ? newItemDto.trueDSDFlag : ""}
                    />
                </Grid>
            </Grid>

            <Grid item xs={12} className="overideProcessRow">
                <TextFieldMemi
                    // value={productHierarchyName}
                    // setTextValue={(value) => setProductHierarchyName(value)}
                    label="S&S Desc"
                    alignItems="row"
                    TextFieldClass="overideContTextField"
                    LabelClass="overideProcessRowTitle"
                    labelXs={2}
                    textFieldXs={9}
                    autoFill
                    value={ssDesc}
                    setTextValue={(value) => setSsDesc(value)}
                    error={errorSsDesc}
                />

            </Grid>
            <Grid item xs={12} className="overideProcessRow">
                <TextFieldMemi
                    // value={productHierarchyName}
                    // setTextValue={(value) => setProductHierarchyName(value)}
                    label="Internet Desc"
                    alignItems="row"
                    TextFieldClass="overideContTextField"
                    LabelClass="overideProcessRowTitle"
                    labelXs={2}
                    textFieldXs={9}
                    value={internetDesc}
                    autoFill
                    setTextValue={(value) => setInternetDesc(value)}
                    error={errorInternetDesc}
                />

            </Grid>

            <Grid item xs={12} className="overideProcessRow">
                <TextFieldMemi
                    // value={productHierarchyName}
                    // setTextValue={(value) => setProductHierarchyName(value)}
                    label="POS Desc"
                    alignItems="row"
                    TextFieldClass="overideContTextField"
                    LabelClass="overideProcessRowTitle"
                    labelXs={2}
                    textFieldXs={9}
                    autoFill
                    value={posDesc}
                    setTextValue={(value) => setPosDesc(value)}
                    error={errorPosDesc}
                />
            </Grid>
            <Grid item xs={12} className="overideProcessRow">
                <TextFieldMemi
                    // value={productHierarchyName}
                    // setTextValue={(value) => setProductHierarchyName(value)}
                    label="Case UPC"
                    alignItems="row"
                    TextFieldClass="overideContDisabledTextField"
                    LabelClass="overideProcessRowTitle"
                    labelXs={2}
                    textFieldXs={10}
                    fullWidth={false}
                    value={newItemDto && newItemDto.caseUPCForDisplay !== null ? newItemDto.caseUPCForDisplay : ""}
                    disabled
                    autoFill
                />

            </Grid>


            <Grid container className="overideProcessRow">
                <Grid item xs={6} >
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Pack"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={8}
                        fullWidth={false}
                        value={newItemDto && newItemDto.packwhse !== null ? newItemDto.packwhse : ""}
                        autoFill
                        disabled

                    />
                </Grid>
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Inner Pack"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={5}
                        disabled
                        value={newItemDto ? newItemDto.innerPack : ""} //Added 1 for bug fix
                    />
                </Grid>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={6}>
                </Grid>
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Desc Size"
                        alignItems="row"
                        TextFieldClass="overideContTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={5}
                        autoFill
                        value={descSize}
                        setTextValue={(value) => setDescSize(value)}
                        error={errorDescSize}
                        maxLength={10}
                    />
                </Grid>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={6} >
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="VCF"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={8}
                        fullWidth={false}
                        disabled
                        value={newItemDto && newItemDto.vendConvFactor !== null ? newItemDto.vendConvFactor : ""}

                    />
                </Grid>
                <Grid item xs={6} >
                    <Grid container>
                        <Grid item xs={4} className="overideProcessRowTitle">Num Size</Grid>
                        <Grid item xs={3}>
                            <TextFieldMemi
                                // value={productHierarchyName}
                                // setTextValue={(value) => setProductHierarchyName(value)}
                                alignItems="row"
                                TextFieldClass="overideContTextField"
                                LabelClass="overideProcessRowTitle"
                                textFieldXs={12}
                                labelXs={0}
                                value={numSize}
                                setTextValue={(value) => setNumSize(value)}
                                error={errorNumSize}
                                autoFill
                            />
                        </Grid>
                        <Grid item xs={1}>
                            <DropDownMemi
                                alignItems="inline"
                                label=""
                                options={uomCodeOption}
                                value={uomCode}
                                setValue={(value) => setUomCode(value)}
                                classNameMemi="dropdownOverideNumSize"
                                error={errorUomCode}
                                disableNone
                                dropdownStyle={{ marginLeft: "5px" }}
                            />
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={2} className="overideProcessRowTitle">Usage Ind & Type</Grid>
                <Grid item xs={2} style={{ display: "flex" }}>
                    <DropDownMemi
                        label=""
                        alignItems="inline"
                        LabelClass="overideProcessRowTitle"
                        options={updUsgeIndOptions}
                        value={updUsgeInd}
                        disabled
                        classNameMemi="dropdownOverideUsgInd usgeIndWidth"
                        error={errorUsageInd}
                    />
                    <DropDownMemi
                        alignItems="inline"
                        LabelClass="overideProcessRowTitle"
                        options={updUsgeIndOptions2}
                        value={updUsgeInd}
                        disabled
                        error={errorUsageType}
                        classNameMemi="dropdownOverideUsgInd usgeTypeWidth"

                    />
                </Grid>
                <Grid item xs={2}></Grid>
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Product Src"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={5}
                        disabled
                        value={newItemDto && newItemDto.productSrcCd !== null ? newItemDto.productSrcCd : ""}
                    />
                </Grid>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={6} style={{ display: "flex", width: "100%" }}>
                    <DropDownMemi
                        label="Display"
                        alignItems="row"
                        LabelClass="overideProcessRowTitle"
                        options={[{ value: "Y", label: "Y" }, { value: "N", label: "N" }]}
                        value={newItemDto && newItemDto.updDispFlag !== null ? newItemDto.updDispFlag : ""}
                        titleXs={8}
                        dropdownXs={4}
                        fullWidth
                        disabled
                        disableNone
                        classNameMemi="dropdownOverideProcessCont"
                        error={errorDisplayValid}
                    />
                    {/* <div style={{width:"50%"}}> */}
                    <TextFieldMemi
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={3}
                        fullWidth={false}
                        label="OTB"
                        textFieldXs={7}
                        disabled
                        alignLabel="center"
                        value={newItemDto && newItemDto.logicalInd !== null ? newItemDto.logicalInd : ""}

                    />
                    {/* </div> */}
                </Grid>
                <Grid item xs={6} style={{ display: "flex", width: "100%", alignItems: "flex-start" }}>
                    <Grid item xs={4} className="overideProcessRowTitle">UPCs</Grid>
                    <Grid item xs={6}>
                        <DropDownMemi
                            alignItems="inline"
                            label="UPCs"
                            options={upcVd}
                            setValue={(value) => setSelectedUpc(value)}
                            value={selectedUpc}
                            disableNone
                            fullWidth
                            titleXs={0}
                            dropdownXs={12}
                            classNameMemi="dropdownOverideProcessCont"
                        />
                    </Grid>
                    &nbsp; &nbsp;
                    <Add
                        style={{ cursor: "pointer", fontSize: "15", color: "black" }}
                        onClick={handleTableModel}
                    />
                </Grid>




            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={2} className="overideProcessRowTitle">
                    SMIC
                </Grid>
                <Grid item xs={4} style={{ display: "flex" }}>
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.grpCd !== null ? newItemDto.grpCd : ""}
                        error={errorGroupCode}
                    />
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.ctgryCd !== null ? newItemDto.ctgryCd : ""}
                        error={errorCategoryCd}
                    />
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.clsCd !== null ? newItemDto.clsCd : ""}
                    />
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.sbClsCd !== null ? newItemDto.sbClsCd : ""}
                    />
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.subSbClass !== null ? newItemDto.subSbClass : ""}
                    />
                </Grid>
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="SMIC Description"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={8}
                        autoFill
                        value={smicDesc}
                        setTextValue={(value) => setSmicDesc(value)}
                        error={errorSmicDesc}
                        disabled
                    />
                </Grid>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={2} className="overideProcessRowTitle">
                    Production Codes
                </Grid>
                <Grid item xs={4} style={{ display: "flex" }}>
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.productionGrpCd !== null ? newItemDto.productionGrpCd : ""}
                    />
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.productionCtgryCd !== null ? newItemDto.productionCtgryCd : ""}
                    />
                    <OutlinedInput
                        disabled
                        className="disabledOutlinedInput"
                        value={newItemDto && newItemDto.productionClsCd !== null ? newItemDto.productionClsCd : ""}
                    />
                </Grid>
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Prod Class Code"
                        alignItems="row"
                        TextFieldClass="overideContTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={5}
                        value={prodClassCode}
                        autoFill
                        setTextValue={(value) => setProdClassCode(value)}
                        error={errorProdClassCode}
                    />
                </Grid>
            </Grid>
            <Grid container className="overideProcessRow">
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Retail Sect Name"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={7}
                        disabled
                        value={newItemDto && newItemDto.deptName != null ? newItemDto.deptName : ""}
                    />
                </Grid>
                <Grid item xs={6}>
                    <TextFieldMemi
                        // value={productHierarchyName}
                        // setTextValue={(value) => setProductHierarchyName(value)}
                        label="Retail Sect Num"
                        alignItems="row"
                        TextFieldClass="overideContDisabledTextField"
                        LabelClass="overideProcessRowTitle"
                        labelXs={4}
                        textFieldXs={5}
                        disabled
                        value={newItemDto && newItemDto.deptCd != null ? newItemDto.deptCd : ""}
                    />
                </Grid>

            </Grid>

            <Grid container className="overideProcessRow">
                <Grid item xs={2} className="overideProcessRowTitle">
                    DC, Cost & Status
                </Grid>
                <Grid item xs={4} >
                    <select disabled multiple className="overideProcessDcCostSelect">
                        {
                            newItemDto && newItemDto.dcDetails ?
                                newItemDto.dcDetails.map((x) => (
                                    <optgroup label={`${x.dc}  $${x.cost} ${x.dcStatus}`}>
                                        {
                                            x.rogs.map((rog) => (
                                                <option> {rog} </option>
                                            ))
                                        }
                                    </optgroup>
                                )) : ""

                        }

                    </select>
                </Grid>
                <Grid item xs={6}>
                    <DropDownMemi
                        label="Private Label"
                        alignItems="row"
                        LabelClass="overideProcessRowTitle"
                        options={[{ label: "H", value: "H" }, { label: "N", value: "N" }, { label: "G", value: "G" }]}
                        value={updUsgeInd}
                        titleXs={4}
                        disabled
                        fullWidth
                        dropdownXs={2}
                        value={newItemDto && newItemDto.updPtLabelInd !== null ? newItemDto.updPtLabelInd : ""}
                        classNameMemi="dropdownOverideProcessCont"
                        disableNone
                        error={errorPrivateLabel}
                    />
                </Grid>
            </Grid>
            <br />
            <br />
            <br />
            <Grid item xs={12}>
                <TextFieldMemi
                    label="Conversion Team Comments"
                    value={convTeamComments}
                    setTextValue={(value) => setConvTeamComments(value)}
                    LabelClass="boldLabel"
                    TextFieldClass="overideContTextField"
                    labelXs={3}
                    textFieldXs={4}
                    autoFill
                    alignItems="row"
                />
            </Grid>

            <Grid item xs={12} style={{ display: "flex", marginTop: "20px" }}>
                <ButtonMemi
                    classNameMemi="MultiUnitScreenButton"
                    btnval="Home"
                    onClick={handleGoHome}
                />
                <ButtonMemi
                    classNameMemi="MultiUnitScreenButton overideSaveButton"
                    btnval="Save"
                    btndisabled={disableSave}
                    onClick={() => OverrideValidateSave("Save")}
                />

                {
                    overideServiceKey === "Perishables" || overideServiceKey === "Bakery" ?
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenButton overideSaveButton"
                            btnval="Back To Mapping"
                            onClick={() => history.goBack()}
                        /> : ""
                }
                {
                    overideServiceKey === "Perishables" || overideServiceKey === "Bakery" ? "" :
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenButton overideCancelButton"
                            btnval="Save & Next"
                            btndisabled={disableSaveNext}
                            onClick={() => OverrideValidateSave("Next")}
                        />
                }


            </Grid>
        </Grid >
    )
}
