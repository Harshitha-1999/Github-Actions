import React from 'react';
import HelpScreen from 'components/HelpScreen';
import { useHelp } from 'hooks';

export const SiteWideHelpScreen = () => {
  const { helpOptions, closeHelp } = useHelp();

  return (
    <HelpScreen
      open={helpOptions.isOpen}
      message={helpOptions.message}
      scope={helpOptions.scope}
      onClose={closeHelp}
    >
      {helpOptions.contents}
    </HelpScreen>
  );
};

export default SiteWideHelpScreen;
