import React from 'react';
import { render, screen } from "@testing-library/react";
import ReduxProvider from 'providers/ReduxProvider';
import SiteWideHelpScreen from './index';

describe('<SiteWideHelpScreen />', () => {

    it('Should render without errors', () => {
        const { debug, container } = render(
            <ReduxProvider>
                <SiteWideHelpScreen />
            </ReduxProvider>
        );
        expect(container).toBeTruthy();
        expect(screen.getByText('BOS-help help text display')).toBeTruthy();
        expect(screen.getByText('Message.. :')).toBeTruthy();
    });
})