
import React, { useEffect, useState, useCallback, useContext } from 'react';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ApplicationContext from "../../context/ApplicationContext";
import { Loop } from "@material-ui/icons";
import { Grid, OutlinedInput } from "@material-ui/core";
import FilterButtonMultiScreen from "components/FilterButtonMultiScreen/FilterButtonMultiScreen";
import { memiuServices } from "api/memiu/memiuService";
import { loadMore } from 'utils/CommonFunctions';
import { authTokenCookie } from 'utils';

export default function TargetItems(props) {

  const [criteria2P, setCriteria2P] = useState("tarItemDesc");
  const [search2P, setSearch2P] = useState("");
  const [search2P1, setsearch2P1] = useState("");
  const [search2P2, setsearch2P2] = useState("");
  const [search2P3, setsearch2P3] = useState("");
  const [search2P4, setsearch2P4] = useState("");
  const [search2P5, setsearch2P5] = useState("");
  const AppData = useContext(ApplicationContext);
  const { companyId, divisionId, memi21_targetItems, multiUnitTargetData, multiUnitTargetFilter } = AppData;
  const { MappingStatus, selectedSrcModelRows, setSelectionTargetModel } = props;
  const handleLoadMore = useCallback((previousDataLength, currentData) => {

    let currentSrcPageCount = loadMore(previousDataLength, currentData.length);
    let multiUnitTargetCurrentPgData = [];
    let multiUnitTargetDisplayData = [];

    if (currentData) {
      currentData.map((data, index) => {

        multiUnitTargetDisplayData.push({
          ...data, id: index, displayUpc: data.upcList[0].charAt(0) + "-" + data.upcList[0].charAt(1) + "-" + data.upcList[0].substring(2, 7) + "-" + data.upcList[0].substring(7, 12)
        });

        if (index < currentSrcPageCount) {

          multiUnitTargetCurrentPgData.push({
            ...data, id: index, displayUpc: data.upcList[0].charAt(0) + "-" + data.upcList[0].charAt(1) + "-" + data.upcList[0].substring(2, 7) + "-" + data.upcList[0].substring(7, 12)
          });

        }
      });
    } else {
      AppData.setAlertBox(true, "No record found");
    }
    AppData.setMultiUniTargetData(multiUnitTargetDisplayData);
    AppData.setMemi21_targetItems(multiUnitTargetCurrentPgData);

  }, [multiUnitTargetData, memi21_targetItems])

  const onTargetReset = useCallback(() => {

    AppData.setMemi21_targetItems([])

    memiuServices.loadMultiUnitTargetRefresh(companyId, divisionId, MappingStatus)
      .then((res) => {

        handleLoadMore(0, res.data.multiUnitTarget);
        AppData.setMultiUnitTargetFilter(undefined);

      })
      .catch((error) => {
        AppData.setMultiUniTargetData([]);
        AppData.setMemi21_targetItems([]);
      })
  }, [companyId, divisionId, MappingStatus])


  const onResetClick = useCallback(() => {

    setSearch2P("");
    setsearch2P1("");
    setsearch2P2("");
    setsearch2P3("");
    setsearch2P4("");
    setsearch2P5("");
    onTargetReset();

  }, [MappingStatus]);

  useEffect(() => {
    setCriteria2P("tarItemDesc");
    setSearch2P("");
    setsearch2P1("");
    setsearch2P2("");
    setsearch2P3("");
    setsearch2P4("");
    setsearch2P5("");
  }, [MappingStatus]);

  function CheckCategoryValueMatches(elementMain, productHierarchyResueArr, endResultArray) {

    var elementCatArray = elementMain.smicCode.split("-");

    for (var i = 0; i < elementCatArray.length; i++) {
      if (productHierarchyResueArr[i].length === 0) {
        elementCatArray[i] = '';
      }
      else if (productHierarchyResueArr[i].length === 1 || productHierarchyResueArr[i].length === 2) {
        if (i === 1) {
          if (elementCatArray[0] === "") {
            elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
          else {
            elementCatArray[i] = (elementCatArray[i].substr(0, productHierarchyResueArr[i].length) === productHierarchyResueArr[i]) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
        }
        else if (i === 2) {
          if (elementCatArray[0] === "" && elementCatArray[1] === "") {
            elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
          else {
            elementCatArray[i] = (elementCatArray[i].substr(0, productHierarchyResueArr[i].length) === productHierarchyResueArr[i]) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
        }
        if (i === 3) {
          if (elementCatArray[0] === "" && elementCatArray[1] === "" && elementCatArray[2] === "") {
            elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
          else {
            elementCatArray[i] = (elementCatArray[i].substr(0, productHierarchyResueArr[i].length) === productHierarchyResueArr[i]) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
        }
        if (i === 4) {
          if (elementCatArray[0] === "" && elementCatArray[1] === "" && elementCatArray[2] === "" && elementCatArray[3] === "") {
            elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
          else {
            elementCatArray[i] = (elementCatArray[i].substr(0, productHierarchyResueArr[i].length) === productHierarchyResueArr[i]) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
        }
        else {
          elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
        }
      }
    }

    if (JSON.stringify(elementCatArray) === JSON.stringify(productHierarchyResueArr))
      endResultArray.push(elementMain);
  }

  const onCLickApply = useCallback((deptData, whseData, dsdData, store1, store2, store3, store4, store5) => {

    let dsdWhseArray = [whseData, dsdData];
    let productHierarchyRes = [store1, store2, store3, store4, store5];

    let checkedDeptArray = [];
    let checkedDsdArray = [];


    deptData.map((value) => {
      if (value.isChecked) {
        checkedDeptArray.push(value.deptName)
      }
    });

    dsdWhseArray.map((value) => {
      if (value.isChecked) {
        checkedDsdArray.push(value.prodSourceCd)
      }
    });

    var hasproductHierarchyRes = false;

    productHierarchyRes.forEach((item) => {
      if (item !== "") {
        return hasproductHierarchyRes = true
      }
    })

    // if (productHierarchyRes.filter(str => str.trim().length > 0))
    //   hasproductHierarchyRes = true;

    var endResultArray = [];

    if (checkedDeptArray.length !== 0 && checkedDsdArray.length !== 0) {
      multiUnitTargetData.map(function (el) {
        if (checkedDeptArray.includes(el.targetDepartment) && checkedDsdArray.includes(el.itemTypeWhseDsd)) {
          (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
        }
      });
    }

    else if (checkedDeptArray.length !== 0 || checkedDsdArray.length !== 0) {
      if (checkedDeptArray.length !== 0) {
        multiUnitTargetData.map(function (el) {
          if (checkedDeptArray.includes(el.targetDepartment)) {
            (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
          }
        });
      }

      if (checkedDsdArray.length !== 0) {
        multiUnitTargetData.map(function (el) {
          if (checkedDsdArray.includes(el.itemTypeWhseDsd)) {
            (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
          }
        });
      }
    }
    else {
      if (hasproductHierarchyRes) {
        multiUnitTargetData.map(function (el) {
          CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
        });
      }
      else {
        endResultArray = multiUnitTargetData;
      }
    }

    const targetData = endResultArray ? endResultArray.map((data, index) => { return { ...data, id: index } }) : undefined;
    AppData.setMultiUnitTargetFilter(targetData);

  }, [multiUnitTargetData, multiUnitTargetFilter]);

  const onSearchClick = useCallback(() => {

    setSelectionTargetModel([]);

    if (criteria2P === "")
      AppData.setAlertBox(true, "Please   select any option")
    else if (criteria2P === "tarItemDesc" && search2P === "")
      AppData.setAlertBox(true, "Please enter a Valid Item Desc.")
    else if (criteria2P === "targetCIC" && (search2P === "" || !(/^\d+$/.test(search2P))))
      AppData.setAlertBox(true, "Please enter a Valid CIC.")
    else if (criteria2P === "tarVendorName" && search2P === "")
      AppData.setAlertBox(true, "Please enter a Valid Vendor Name.")
    else {

      let reqData = [];

      if (criteria2P === "tobematchedsourcehierarchy") {

        reqData = [{
          "companyId": "999",
          "divisionId": "2400",
          "tarGrpCd": search2P1,
          "tarCtgryCd": search2P2,
          "tarClsCd": search2P3,
          "tarSbClsCd": search2P4,
          "tarSubSbClass": search2P5,
          "srcMultiUnitFlag": "Y",
          "targetCICsearchFlag": "N",
          "itemDescFlag": "N",
          "venderNameFlag": "N",
          "hierarchyOrSmicFlag": "Y",
          "matchIndicator": MappingStatus
        }]
      } else {
        reqData = [{
          "companyId": companyId,
          "divisionId": divisionId,
          [criteria2P]: search2P,
          "srcMultiUnitFlag": "Y",
          "targetCICsearchFlag": criteria2P === "targetCIC" ? search2P === "" ? "N" : "Y" : "N",
          "itemDescFlag": criteria2P === "tarItemDesc" ? search2P === "" ? "N" : "Y" : "N",
          "venderNameFlag": criteria2P === "tarVendorName" ? search2P === "" ? "N" : "Y" : "N",
          "hierarchyOrSmicFlag": "N",
          "matchIndicator": MappingStatus
        }]
      }

      memiuServices.multiUnitTargetSearch(reqData).then((res) => {

        AppData.setMultiUniTargetData(res.data);
        handleLoadMore(0, res.data);
        AppData.setMultiUnitTargetFilter(undefined);

      })
        .catch((error) => {
          AppData.setMultiUniTargetData([]);
          AppData.setMemi21_targetItems([]);
        })


    }
  }, [search2P, companyId, divisionId, criteria2P, MappingStatus, search2P1, search2P2, search2P3, search2P4, search2P5, multiUnitTargetFilter]);

  const onClickSelectSourceUpc = useCallback(() => {

    // AppData.setMemi21_targetItems([]);

    if (selectedSrcModelRows.length > 0) {

      AppData.setMemi21_targetItems([]);
      AppData.setMultiUniTargetData([]);
      console.log(AppData.memi21_sourceItems)
      let requestData = selectedSrcModelRows.map((value) => {
        // let 
        return {
          companyId: companyId,
          divisionId: divisionId,
          matchIndicator: MappingStatus,
          upcs: AppData.memi21_sourceItems.find((item) => {return item.id === value.id}).upcs
        }
      });

      memiuServices.listTargetOnSrcSel(requestData).then((res) => {
        if (res.hasOwnProperty('data')) {
          let { data } = res;

          if (data.length > 0) {
            handleLoadMore(0, data);
            AppData.setMultiUnitTargetFilter(undefined);
          } else {
            AppData.setAlertBox(true, "No CIC details from Target Items.");
          }
        }
      }).catch((error) => {
        AppData.setMultiUniTargetData([]);
        AppData.setMemi21_targetItems([]);
      })

    } else {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
    }

  }, [selectedSrcModelRows, MappingStatus, companyId, divisionId])

  const handleSmicChange = (e, type) => {
      if(e.target.value.length === 2) {
        document.getElementById(`smic${type}`).blur();
        if(type+1 <6) {
          document.getElementById(`smic${type+1}`).focus()
        }
      }
      if(type===1) {
        setsearch2P1(e.target.value)
      } else if(type===2) {
        setsearch2P2(e.target.value)
      }
      else if(type===3) {
        setsearch2P3(e.target.value)
      } else if(type===4) {
        setsearch2P4(e.target.value)
      } else if(type === 5) {
        setsearch2P5(e.target.value);
      }
  }

  const MappingStatusPTarget = (
    <Grid item xs={12} style={{ display: "flex", flexDirection: "row", padding: "0.7rem 0 0.7rem 0rem", justifyContent: "center" }}>
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginRight"
        btnval="Selected Source UPC"
        onClick={onClickSelectSourceUpc}
      />
      <div>
        <DropDownMemi
          options={[
            { label: "Item Desc", value: "tarItemDesc" },
            { label: "CIC", value: "targetCIC" },
            { label: "SMIC", value: "tobematchedsourcehierarchy" },
            { label: "Vendor Name", value: "tarVendorName" },
          ]}
          label="-Criteria-"
          alignItems="inline"
          classNameMemi="MultiUnitScreenDropwdownButton MultiUnitScreenButtonMarginLeft"
          value={criteria2P}
          setValue={(value) => setCriteria2P(value)}
        />
      </div>

      {
        criteria2P === "tobematchedsourcehierarchy" ?
          <>
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "3.5rem", height:"25px" }}
              type="number"
              value={search2P1}
              maxLength={2}
              id="smic1"
              onChange={(e) => handleSmicChange(e, 1)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "3.5rem" , height:"25px"}}
              type="number"
              value={search2P2}
              maxLength={2}
              onChange={(e) => handleSmicChange(e, 2)}
              id="smic2"
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "3.5rem" , height:"25px" }}
              type="number"
              value={search2P3}
              onChange={(e) => handleSmicChange(e, 3)}
              id="smic3"
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "3.5rem" , height:"25px"}}
              type="number"
              value={search2P4}
              onChange={(e) => handleSmicChange(e, 4)}
              id="smic4"
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "3.5rem" , height:"25px"}}
              type="number"
              value={search2P5}
              onChange={(e) => handleSmicChange(e, 5)}
              id="smic5"
            />
          </> :
          <OutlinedInput
            placeholder="Search Target Items..."
            className="MultiUnitScreenButtonMarginLeft MultiUnitScreenTextField"
            style={{ fontSize: "12.5px" }}
            value={search2P}
            onChange={(e) => setSearch2P(e.target.value)}
          />
      }
      <ButtonMemi
        classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft"
        btnval="Search"
        onClick={onSearchClick}
      />
      <Loop
        className="MultiUnitScreenIconButton MultiUnitScreenButtonMarginLeft"
        onClick={onResetClick}
      />

      <FilterButtonMultiScreen
        ButtonClass={`MultiUnitScreenButton MultiUnitScreenButtonMarginLeft ${multiUnitTargetFilter === undefined ? "MultiUnitScreenFilterButton" : "MultiUnitScreenActiveFilterButton"}`}
        btnsize="small"
        RadioSortByLabelClass="RadioSortByLabel"
        sortByClass="sortByBox"
        onClick={onCLickApply}
        isMultiTarget={true}
        MappingStatus={MappingStatus}
        maxLength={2}
      />

      {/* <ButtonMemi
                classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginLeft2 MultiUnitScreenFilterButton"
                btnval="Filter By"
            /> */}
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginLeft2"
        btnval="Load More"
        onClick={() => handleLoadMore(memi21_targetItems.length, multiUnitTargetData)}
      />
    </Grid>
  )

  return (
    MappingStatusPTarget
  );
}
