import React, { useCallback, useState, useContext, useEffect } from 'react';
import RadioMemi from "../../components/RadioMemi/RadioMemi";
import { Grid, OutlinedInput } from "@material-ui/core";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import FilterButtonMultiScreen from "components/FilterButtonMultiScreen/FilterButtonMultiScreen";
import ApplicationContext from "../../context/ApplicationContext";
import { Loop } from "@material-ui/icons";
import { memiuServices } from "api/memiu/memiuService";
import { authTokenCookie } from 'utils';
import { loadMore } from 'utils/CommonFunctions';

export default function SourceItems(props) {
  const [criteriaP, setCriteriaP] = useState("srcItemDesc")
  const [searchP, setSearchP] = useState("");
  const [searchP1, setSearchP1] = useState("");
  const [searchP2, setSearchP2] = useState("");
  const [searchP3, setSearchP3] = useState("");
  const [multiUnit, setMultiUnit] = useState("Y");
  const { userId } = authTokenCookie();
  const AppData = useContext(ApplicationContext);
  const { companyId, divisionId, memi21_sourceItems, multiUnitSrcData, multiUnitSrcFilter } = AppData;
  const { MappingStatus, onLoadMultiUnit, selectedTargetModelRows, selectedSrcModelRows, setSelectionSrcModel } = props;
  const handleLoadMore = useCallback((previousDataLength, currentData) => {

    let currentSrcPageCount = loadMore(previousDataLength, currentData.length);
    let multiUnitSrcCurrentPgData = [];
    let multiUnitSrcDisplayData = [];

    if (currentData) {

      currentData.map((data, index) => {

        multiUnitSrcDisplayData.push({
          ...data, id: index, displayUpc: data.upcs[0].charAt(0) + "-" + data.upcs[0].charAt(1) + "-" + data.upcs[0].substring(2, 7) + "-" + data.upcs[0].substring(7, 12)
        });

        if (index < currentSrcPageCount) {

          multiUnitSrcCurrentPgData.push({
            ...data, id: index, displayUpc: data.upcs[0].charAt(0) + "-" + data.upcs[0].charAt(1) + "-" + data.upcs[0].substring(2, 7) + "-" + data.upcs[0].substring(7, 12)
          });

        }
      });
    } else {
      AppData.setAlertBox(true, "No record found")
    }

    AppData.setMultiUnitSrcData(multiUnitSrcDisplayData);
    AppData.setMemi21_sourceItems(multiUnitSrcCurrentPgData);

  }, [multiUnitSrcData, memi21_sourceItems])


  function 
  CheckCategoryValueMatches(elementMain, productHierarchyResueArr, endResultArray) {

    var elementCatArray = elementMain.productHierarchy.split("-");

    for (var i = 0; i < elementCatArray.length; i++) {
      if (productHierarchyResueArr[i].length === 0) {
        elementCatArray[i] = '';
      }
      else if (productHierarchyResueArr[i].length === 1 || productHierarchyResueArr[i].length === 2) {
        if (i === 1) {
          if (elementCatArray[0] === "") {
            elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
          else {
            elementCatArray[i] = (elementCatArray[i].substr(0, productHierarchyResueArr[i].length) === productHierarchyResueArr[i]) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
        }
        else if (i === 2) {
          if (elementCatArray[0] === "" && elementCatArray[1] === "") {
            elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
          else {
            elementCatArray[i] = (elementCatArray[i].substr(0, productHierarchyResueArr[i].length) === productHierarchyResueArr[i]) ? productHierarchyResueArr[i] : elementCatArray[i];
          }
        }
        else {
          elementCatArray[i] = (elementCatArray[i].includes(productHierarchyResueArr[i])) ? productHierarchyResueArr[i] : elementCatArray[i];
        }
      }
    }

    if (JSON.stringify(elementCatArray) === JSON.stringify(productHierarchyResueArr))
      endResultArray.push(elementMain);
  }

  const onCLickApply = useCallback((deptData, whseData, dsdData, store1, store2, store3, store4, store5, pendingData, convertedData) => {

    let dsdWhseArray = [whseData, dsdData];
    let convStatusCodeArray = [pendingData, convertedData];

    let productHierarchyRes = [store1, store2, store3];

    let checkedDeptArray = [];
    let checkedDsdArray = [];
    let checkedConvStatusCodeArray = [];


    deptData.map((value) => {
      if (value.isChecked) {
        checkedDeptArray.push(value.deptName)
      }
    });

    dsdWhseArray.map((value) => {
      if (value.isChecked) {
        checkedDsdArray.push(value.prodSourceCd)
      }
    });

    convStatusCodeArray.map((value) => {
      if (value.isChecked && value.prodSourceCd === "PENDING") {
        checkedConvStatusCodeArray.push("R", "Q");
      } else if (value.isChecked) {
        checkedConvStatusCodeArray.push("C")
      }
    });

    var hasproductHierarchyRes = false;

    productHierarchyRes.forEach((item) => {
      if (item !== "") {
        return hasproductHierarchyRes = true
      }
    })

    var endResultArray = [];

    if (checkedDeptArray.length !== 0 && checkedDsdArray.length !== 0) {
      multiUnitSrcData.map(function (el) {
        if (checkedDeptArray.includes(el.deptName) && checkedDsdArray.includes(el.prodSourceCd)) {
          (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
        }
      });
    }
    else if (checkedDeptArray.length !== 0 && checkedDsdArray.length !== 0 && checkedConvStatusCodeArray.length !== 0) {
      multiUnitSrcData.map(function (el) {
        if (checkedDeptArray.includes(el.deptName) && checkedDsdArray.includes(el.prodSourceCd) && checkedConvStatusCodeArray.includes(el.convStatusCode)) {
          (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
        }
      });
    }
    else if (checkedDeptArray.length !== 0 || checkedDsdArray.length !== 0 || checkedConvStatusCodeArray.length !== 0) {
      if (checkedDeptArray.length !== 0) {
        multiUnitSrcData.map(function (el) {
          if (checkedDeptArray.includes(el.deptName)) {
            (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
          }
        });
      }

      if (checkedDsdArray.length !== 0) {
        multiUnitSrcData.map(function (el) {
          if (checkedDsdArray.includes(el.prodSourceCd)) {
            (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
          }
        });
      }

      if (checkedConvStatusCodeArray.length !== 0) {
        multiUnitSrcData.map(function (el) {
          if (checkedConvStatusCodeArray.includes(el.convStatusCode)) {
            (!hasproductHierarchyRes) ? endResultArray.push(el) : CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
          }
        });
      }
    }
    else {
      if (hasproductHierarchyRes) {
        multiUnitSrcData.map(function (el) {
          CheckCategoryValueMatches(el, productHierarchyRes, endResultArray);
        });
      }
      else {
        endResultArray = multiUnitSrcData;
      }
    }

    const sourceData = endResultArray ? endResultArray.map((data, index) => { return { ...data, id: index } }) : undefined;
    AppData.setMultiUnitSrcFilter(sourceData);

  }, [multiUnitSrcData])


  const onSourceReset = useCallback(() => {

    AppData.setMemi21_sourceItems([])

    memiuServices.loadMultiUnitSourceRefresh(companyId, divisionId, MappingStatus)
      .then((res) => {

        handleLoadMore(0, res.data.multiUnitSource)
        AppData.setMultiUnitSrcFilter(undefined);

      })
      .catch((error) => {
        AppData.setMultiUnitSrcData([]);
        AppData.setMemi21_sourceItems([]);
      })
  }, [companyId, divisionId, MappingStatus])

  const onResetClick = useCallback(() => {

    setSearchP("");
    setSearchP1("");
    setSearchP2("")
    setSearchP3("");
    setMultiUnit("Y");

    onSourceReset();

  }, [MappingStatus]);

  const onClickMultiUnit = useCallback(() => {

    if (selectedSrcModelRows.length === 0) {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
      return;
    }

    if (multiUnit === "Y") {
      AppData.setAlertBox(true, "Item already in a multi unit status.");
      return;
    }

    if (selectedSrcModelRows.length > 0) {

      let reqData = selectedSrcModelRows.map((value, index) => {
        return {
          companyId: companyId,
          divisionId: divisionId,
          caseUpc: value.caseUpc,
          deptName: value.deptName,
          maxRetail: value.maxRetail,
          prodSourceCd: value.prodSourceCd,
          productHierarchy: value.productHierarchy,
          productSku: value.productSku,
          convProductSku: value.productSku,
          updatedUserId: userId,
          productSku: value.productSku,
          productSkuSet: value.productSkuSet,
          srcCost: value.srcCost,
          srcItemDesc: value.srcItemDesc,
          srcPackWhse: value.srcPackWhse,
          srcSize: value.srcSize,
          srcUpc: value.upcs[0],
          srcVendConvFctr: value.srcVendConvFctr,
          srcVendName: value.srcVendName,
          srcVendNum: value.srcVendNum,
          upcs: value.upcs
        }
      });

      memiuServices.markItemAsMultiUnit(reqData).then((res) => {
        if (res.hasOwnProperty('data')) {
          let { data } = res;
          onLoadMultiUnit();
        }
      }).catch((error) => {
        AppData.setMultiUnitSrcData([]);
        AppData.setMemi21_sourceItems([]);
      })
    }

  }, [onLoadMultiUnit, selectedSrcModelRows, multiUnit]);

  const onClickNotMultiUnit = useCallback(() => {

    if (selectedSrcModelRows.length === 0) {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
      return;
    }

    if (multiUnit === "N") {
      AppData.setAlertBox(true, "Item already in not a multi unit status.");
      return;
    }

    if (selectedSrcModelRows.length > 0) {

      let reqData = selectedSrcModelRows.map((value) => {
        return {
          companyId: companyId,
          divisionId: divisionId,
          convProductSku: value.productSku,
          updatedUserId: userId,
          productSku: value.productSku
        }
      });

      memiuServices.markNotAMultiUnit(reqData).then((res) => {
        if (res.hasOwnProperty('data')) {
          let { data } = res;
          onLoadMultiUnit();
        }
      }).catch((error) => {
        AppData.setMultiUnitSrcData([]);
        AppData.setMemi21_sourceItems([]);
      })
    }

  }, [onLoadMultiUnit, selectedSrcModelRows, multiUnit]);

  const onClickSelectTargetUpc = useCallback(() => {

    if (selectedTargetModelRows.length > 0) {

      AppData.setMemi21_sourceItems([]);
      AppData.setMultiUnitSrcData([]);

      let requestData = selectedTargetModelRows.map((value) => {
        return { companyId: companyId, divisionId: divisionId, matchIndicator: MappingStatus, upcList: value.upcList}
      });

      memiuServices.listSrcOnTarSel(requestData).then((res) => {
        if (res.hasOwnProperty('data')) {

          let { data } = res;

          if (data.length > 0) {
            handleLoadMore(0, res.data);
            AppData.setMultiUnitSrcFilter(undefined);
          } else {
            AppData.setAlertBox(true, "No Product SKU details from Source Items.");
          }
        }
      }).catch((error) => {
        AppData.setMultiUnitSrcData([]);
        AppData.setMemi21_sourceItems([]);
      })

    } else {
      AppData.setAlertBox(true, "Select any CIC from Target Items.");
    }

  }, [selectedTargetModelRows, companyId, divisionId])

  const onClickMarkDead = useCallback(() => {

    if (selectedSrcModelRows.length > 0) {
      AppData.setConfirmationModal(true, handleMarkDead, "textBox", "Enter the reason for marking this item as dead")
    } else {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
    }

  }, [selectedSrcModelRows]);

  const handleMarkDead = useCallback((textboxModalSearch) => {

    if (selectedSrcModelRows.length > 0) {

      let whiteSpace = new RegExp(/^\s+$/);

      if (!whiteSpace.test(textboxModalSearch)) {

        let reqData = selectedSrcModelRows.map((value) => {
          return {
            companyId: companyId,
            divisionId: divisionId,
            convProductSku: value.convProductSku,
            markAsDeadReason: textboxModalSearch.trim(),
            updatedUserID: userId,
            prodSourceCd: value.prodSourceCd,
            productSku: value.productSku
          }
        });

        memiuServices.markMultiUnitDead(reqData).then((res) => {
          if (res.hasOwnProperty('data')) {
            let { data } = res;
            onLoadMultiUnit();
          }
        }).catch((error) => {
          AppData.setMultiUnitSrcData([]);
          AppData.setMemi21_sourceItems([]);
        })

      }

      AppData.setConfirmationModal(false);
    }

  }, [selectedSrcModelRows])


  const onSearchClick = useCallback(() => {

    let whiteSpace = new RegExp(/^\s+$/);
    let isNum = new RegExp(/^\d+$/);
    setSelectionSrcModel([]);

    if (criteriaP === "")
      AppData.setAlertBox(true, "Please   select any option")
    else if (criteriaP === "srcItemDesc" && (searchP === "" || whiteSpace.test(searchP)))
      AppData.setAlertBox(true, "Please enter a Valid Item Desc.")
    else if (criteriaP === "srcProductSKU" && (searchP === "" || (searchP && !isNum.test(searchP.trim())) || whiteSpace.test(searchP)))
      AppData.setAlertBox(true, "Please enter a Valid Product SKU.")
    else if (criteriaP === "srcVendName" && (searchP === "" || whiteSpace.test(searchP)))
      AppData.setAlertBox(true, "Please enter a Valid Vendor Name.")
    else {

      let reqData = [];

      if (criteriaP !== "tobematchedsourcehierarchy") {

        reqData = [{
          "companyId": companyId,
          "divisionId": divisionId,
          [criteriaP]: searchP.trim(),
          "srcMultiUnitFlag": multiUnit,
          "itemDescFlag": criteriaP === "srcItemDesc" ? searchP === "" ? "N" : "Y" : "N",
          "venderNameFlag": criteriaP === "srcVendName" ? searchP === "" ? "N" : "Y" : "N",
          "hierarchyOrSmicFlag": "N",
          "productSKUsearchFlag": criteriaP === "srcProductSKU" ? searchP === "" ? "N" : "Y" : "N",
          "matchIndicator": props.MappingStatus
        }];
      } else {
        reqData = [{
          "companyId": companyId,
          "divisionId": divisionId,
          srcprodHierarchyLvl1Cd: searchP1.trim(),
          srcprodHierarchyLvl2Cd: searchP2.trim(),
          srcprodHierarchyLvl3Cd: searchP3.trim(),
          "srcMultiUnitFlag": multiUnit.trim(),
          "itemDescFlag": "N",
          "venderNameFlag": "N",
          "hierarchyOrSmicFlag": "Y",
          "productSKUsearchFlag": "N",
          "matchIndicator": props.MappingStatus
        }];
      }

      memiuServices.multiUnitSourceSearch(reqData).then((res) => {

        AppData.setMultiUnitSrcData(res.data);
        handleLoadMore(0, res.data);
        AppData.setMultiUnitSrcFilter(undefined);
      })
        .catch((error) => {

          AppData.setMultiUnitSrcData([]);
          AppData.setMemi21_sourceItems([]);

        })

    }
  }, [searchP, companyId, divisionId, criteriaP, multiUnit, searchP1, searchP2, searchP3])

  const MappingStatusPSource = (
    <Grid item xs={12} style={{ display: "flex", flexDirection: "row", padding: "0.7rem 0 0.7rem 0rem", justifyContent: "space-around" }}>
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton"
        btnval="Mark Dead"
        onClick={onClickMarkDead}
      />
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton"
        btnval="Not A Multi-Unit"
        onClick={onClickNotMultiUnit}
      />
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton"
        btnval="Mark Multi-Unit"
        onClick={onClickMultiUnit}
      />
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton"
        btnval="Selected Target UPC"
        onClick={onClickSelectTargetUpc}
      />
      <div>
        <DropDownMemi
          options={[
            { label: "Item Desc", value: "srcItemDesc" },
            { label: "Product SKU", value: "srcProductSKU" },
            { label: "Hierarchy", value: "tobematchedsourcehierarchy" },
            { label: "Vendor Name", value: "srcVendName" },

          ]}
          label="-Criteria-"
          alignItems="inline"
          classNameMemi="MultiUnitScreenDropwdownButton"
          value={criteriaP}
          setValue={(value) => setCriteriaP(value)}
        />
      </div>
      {
        criteriaP === "tobematchedsourcehierarchy" ?
          <>
            <OutlinedInput
              className="MultiUnitScreenTextField"
              style={{ width: "5rem" }}
              type="number"
              value={searchP1}
              onChange={(e) => setSearchP1(e.target.value)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField"
              style={{ width: "5rem" }}
              type="number"
              value={searchP2}
              onChange={(e) => setSearchP2(e.target.value)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField"
              style={{ width: "5rem" }}
              type="number"
              value={searchP3}
              onChange={(e) => setSearchP3(e.target.value)}
            />
          </> :
          <OutlinedInput
            placeholder="Search Source Items..."
            className="MultiUnitScreenTextField"
            value={searchP}
            style={{ fontSize: "12.5px" }}
            onChange={(e) => setSearchP(e.target.value)}
          />
      }
      <ButtonMemi
        classNameMemi="MultiUnitScreenSearchButton"
        btnval="Search"
        onClick={onSearchClick}
      />
      <Loop
        className="MultiUnitScreenIconButton"
        onClick={onResetClick}
      />
      <RadioMemi
        Mainlabel="Multi Unit"
        label={[{ label: "Y", value: "Y" }, { label: "N", value: "N" }]}
        classnameMemi="RadioMultiUnitScreenRadioClass2"
        labelClass="RadioMultiUnitScreenLabel2"
        radioGroupClass="RadioMultiUnitScreenRadioClass2"
        value={multiUnit}
        setValue={(value) => setMultiUnit(value)}
        size="small"
      />
      {/* <FilterButtonMultiScreen /> */}

      <FilterButtonMultiScreen
        ButtonClass={`MultiUnitScreenButton MultiUnitScreenButtonMarginLeft ${multiUnitSrcFilter === undefined ? "MultiUnitScreenFilterButton" : "MultiUnitScreenActiveFilterButton"}`}
        btnsize="small"
        RadioSortByLabelClass="RadioSortByLabel"
        sortByClass="sortByBox"
        onClick={onCLickApply}
        isMultiSrc={true}
        MappingStatus={MappingStatus}
        maxLength={3}
      />
      {/* <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenFilterButton"
        btnval="Filter By"
      /> */}
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton"
        btnval="Load More"
        onClick={() => handleLoadMore(memi21_sourceItems.length, multiUnitSrcData)}
      />
    </Grid>
  )

  const MappingStatusMSource = (
    <Grid item xs={12} style={{ display: "flex", flexDirection: "row", padding: "0.7rem 0 0.7rem 0rem", justifyContent: "center" }}>
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginRight"
        btnval="Selected Target UPC"
        onClick={onClickSelectTargetUpc}
      />
      <div>
        <DropDownMemi
          options={[
            { label: "Item Desc", value: "srcItemDesc" },
            { label: "Product SKU", value: "srcProductSKU" },
            { label: "Hierarchy", value: "tobematchedsourcehierarchy" },
            { label: "Vendor Name", value: "srcVendName" },

          ]}
          label="-Criteria-"
          alignItems="inline"
          classNameMemi="MultiUnitScreenButtonMarginLeft MultiUnitScreenDropwdownButton"
          value={criteriaP}
          setValue={(value) => setCriteriaP(value)}
        />
      </div>
      {
        criteriaP === "tobematchedsourcehierarchy" ?
          <>
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "5rem" }}
              type="number"
              value={searchP1}
              onChange={(e) => setSearchP1(e.target.value)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              type="number"
              style={{ width: "5rem" }}
              value={searchP2}
              onChange={(e) => setSearchP2(e.target.value)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "5rem" }}
              type="number"
              value={searchP3}
              onChange={(e) => setSearchP3(e.target.value)}
            />
          </> :
          <OutlinedInput
            placeholder="Search Source Items..."
            className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
            value={searchP}
            style={{ fontSize: "12.5px" }}
            onChange={(e) => setSearchP(e.target.value)}
          />
      }
      <ButtonMemi
        classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft"
        btnval="Search"
        onClick={onSearchClick}
      />
      <Loop
        className="MultiUnitScreenIconButton MultiUnitScreenButtonMarginLeft"
        onClick={onResetClick}
      />
      <FilterButtonMultiScreen
        ButtonClass={`MultiUnitScreenButton MultiUnitScreenButtonMarginLeft ${multiUnitSrcFilter === undefined ? "MultiUnitScreenFilterButton" : "MultiUnitScreenActiveFilterButton"}`}
        btnsize="small"
        RadioSortByLabelClass="RadioSortByLabel"
        sortByClass="sortByBox"
        onClick={onCLickApply}
        isMultiSrc={true}
        maxLength={3}
      />

      {/* <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginLeft2 MultiUnitScreenFilterButton"
        btnval="Filter By"
      /> */}
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginLeft2"
        btnval="Load More"
        onClick={() => handleLoadMore(memi21_sourceItems.length, multiUnitSrcData)}
      />
    </Grid>
  )

  const MappingStatusASource = (
    <Grid item xs={12} style={{ display: "flex", flexDirection: "row", padding: "0.7rem 0 0.7rem 0rem", justifyContent: "center" }}>
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginRight"
        btnval="Selected Target UPC"
        onClick={onClickSelectTargetUpc}
      />
      <div>
        <DropDownMemi
          options={[
            { label: "Item Desc", value: "srcItemDesc" },
            { label: "Product SKU", value: "srcProductSKU" },
            { label: "Hierarchy", value: "tobematchedsourcehierarchy" },
            { label: "Vendor Name", value: "srcVendName" },

          ]}
          label="-Criteria-"
          alignItems="inline"
          classNameMemi="MultiUnitScreenButtonMarginLeft MultiUnitScreenDropwdownButton"
          value={criteriaP}
          setValue={(value) => setCriteriaP(value)}
        />
      </div>
      {
        criteriaP === "tobematchedsourcehierarchy" ?
          <>

            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "5rem" }}
              type="number"
              value={searchP1}
              onChange={(e) => setSearchP1(e.target.value)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "5rem" }}
              type="number"
              value={searchP2}
              onChange={(e) => setSearchP2(e.target.value)}
            />
            <OutlinedInput
              className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
              style={{ width: "5rem" }}
              type="number"
              value={searchP3}
              onChange={(e) => setSearchP3(e.target.value)}
            />
          </> :
          <OutlinedInput
            placeholder="Search Source Items..."
            className="MultiUnitScreenTextField MultiUnitScreenButtonMarginLeft"
            value={searchP}
            style={{ fontSize: "12.5px" }}
            onChange={(e) => setSearchP(e.target.value)}
          />
      }
      <ButtonMemi
        classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft"
        btnval="Search"
        onClick={onSearchClick}
      />
      <Loop
        className="MultiUnitScreenIconButton MultiUnitScreenButtonMarginLeft"
        onClick={onResetClick}
      />

      <FilterButtonMultiScreen
        ButtonClass={`MultiUnitScreenButton MultiUnitScreenButtonMarginLeft ${multiUnitSrcFilter === undefined ? "MultiUnitScreenFilterButton" : "MultiUnitScreenActiveFilterButton"}`}
        btnsize="small"
        RadioSortByLabelClass="RadioSortByLabel"
        sortByClass="sortByBox"
        onClick={onCLickApply}
        isMultiSrc={true}
        MappingStatus={MappingStatus}
        maxLength={3}
      />

      {/* <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginLeft2 MultiUnitScreenFilterButton"
        btnval="Filter By"
      /> */}
      <ButtonMemi
        classNameMemi="MultiUnitScreenButton MultiUnitScreenButtonMarginLeft2"
        btnval="Load More"
        onClick={() => handleLoadMore(memi21_sourceItems.length, multiUnitSrcData)}
      />
    </Grid>
  );

  useEffect(() => {
    setSearchP("");
    setSearchP1("");
    setSearchP2("");
    setSearchP3("");
    setMultiUnit("Y");
    setCriteriaP("srcItemDesc");
  }, [MappingStatus])

  return (
    props.MappingStatus === "P" ?
      MappingStatusPSource : (
        props.MappingStatus === "M" ?
          MappingStatusMSource : MappingStatusASource
      )
  );
}
