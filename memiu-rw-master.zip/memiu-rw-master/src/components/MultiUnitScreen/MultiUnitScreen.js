import React, { useCallback, useContext, useEffect } from "react";
import { Grid } from "@material-ui/core";
import ApplicationContext from "../../context/ApplicationContext";
import TableMemi from '../TableMemi/TableMemi';
import { memiuServices } from "api/memiu/memiuService";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import SourceItems from "./SourceItems";
import TargetItems from "./TargetItems";
import { authTokenCookie } from 'utils';
import TableDisplayerCollapsible from "components/TableMemi/TableDisplayerCollapsible";

function MultiUnitScreen(props) {

  const AppData = useContext(ApplicationContext);
  const { memi21_sourceItems, memi21_targetItems, companyId, divisionId, multiUnitSrcFilter, multiUnitTargetFilter, multiUnitSrcData, multiUnitTargetData } = AppData;
  const { userId } = authTokenCookie();
  const [selectedSrcModelRows, setSelectionSrcModel] = React.useState([]);
  const [selectedTargetModelRows, setSelectionTargetModel] = React.useState([]);
  const { MappingStatus, onLoadMultiUnit } = props;
  const openTableModal = (data, column) => {

    let columnData = [];

    if (column === "UPC List") {
      columnData = data.map((x) => { return { [`${column}`]: x.charAt(0) + "-" + x.charAt(1) + "-" + x.substring(2, 7) + "-" + x.substring(7, 12) } });
    } else {
      columnData = data.map((x) => { return { [`${column}`]: x } });
    }
    AppData.setTableModal(true, [column], columnData);
  };

  const openUPCTableModal = (upcList, column) => {

    memiuServices.loadMultiUnitTargetUpcPopUp(upcList.corpItemCd).then((res) => {

      if (res.hasOwnProperty('data')) {

        if (res && res.data && res.data) {

          let columnData = res.data.map((x, i) => { return { [`${column[0]}`]: x[0].charAt(0) + "-" + x[0].charAt(1) + "-" + x[0].substring(2, 7) + "-" + x[0].substring(7, 12), [`${column[1]}`]: x[1], [`${column[2]}`]: x[2] } });
          AppData.setTableModal(true, column, columnData)

        }
      }
    }).catch((error) => {
      AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
    });

  }

  const onMapApiCall = useCallback(() => {
    let multiUnitSrcReturnData = selectedSrcModelRows.map((value, index) => {
      return {
        companyId: companyId,
        divisionId: divisionId,
        caseUpc: value.caseUpc,
        deptName: value.deptName,
        prodSourceCd: value.prodSourceCd,
        productHierarchy: value.productHierarchy,
        productSku: value.productSku,
        convProductSku: value.convProductSku,
        productSkuSet: value.productSkuSet,
        srcCost: value.srcCost,
        srcItemDesc: value.srcItemDesc,
        srcPackWhse: value.srcPackWhse,
        srcSize: value.srcSize,
        srcUpc: value.upcs[0],
        srcVendConvFctr: value.srcVendConvFctr,
        srcVendName: value.srcVendName,
        srcVendNum: value.srcVendNum,
        upcs: value.upcs,
        updatedUserId: userId
      }
    });

    let reqData = {
      multiUnitSource: multiUnitSrcReturnData,
      multiUnitTarget: [{ corpItemCd: selectedTargetModelRows[0].corpItemCd }],
      "srcMultiUnitFlag": "Y"
    }

    memiuServices.mapMultiUnitItem(reqData).then((res) => {

      if (res.hasOwnProperty('data')) {

        if (res && res.data && res.data.Result && res.data.Result === " Multi Unit type item mapped successfully") {
          setSelectionTargetModel([]);
          AppData.mapSelectedRowData([]);
          setSelectionSrcModel([]);
          onLoadMultiUnit();
        }
      }
    }).catch((error) => {
      AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
    });

  }, [selectedSrcModelRows, selectedTargetModelRows, companyId, divisionId, MappingStatus]);

  const onUnmapApiCall = useCallback(() => {

    let multiUnitSrcReturnData = selectedSrcModelRows.map((value) => {

      return {
        companyId: companyId,
        divisionId: divisionId,
        caseUpc: value.caseUpc,
        deptName:value.deptName,
        prodSourceCd: value.prodSourceCd,
        productHierarchy: value.productHierarchy,
        productSku: value.productSku,
        convProductSku: value.convProductSku,
        productSkuSet: value.productSkuSet,
        srcCost: value.srcCost,
        srcItemDesc: value.srcItemDesc,
        srcPackWhse: value.srcPackWhse,
        srcSize: value.srcSize,
        srcUpc: value.upcs[0],
        srcVendConvFctr: value.srcVendConvFctr,
        srcVendName: value.srcVendName,
        srcVendNum: value.srcVendNum,
        upcs: value.upcs,
        updatedUserId: userId
      }
    });

    let reqData = {
      multiUnitSource: multiUnitSrcReturnData,
      multiUnitTarget: [{ corpItemCd: selectedTargetModelRows[0].corpItemCd, matchIndicator: MappingStatus }],
    }

    memiuServices.unMapMultiUnitItem(reqData).then((res) => {

      if (res.hasOwnProperty('data')) {

        if (res && res.data && res.data.Result && res.data.Result === " Multi Unit type item un mapped successfully") {
          setSelectionTargetModel([]);
          AppData.mapSelectedRowData([]);
          setSelectionSrcModel([]);
          onLoadMultiUnit();
        }
      }
    }).catch((error) => {
      AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
    });

  }, [selectedSrcModelRows, selectedTargetModelRows, companyId, divisionId, MappingStatus])


  const onClickMapAndUnmapItems = useCallback(() => {

    let error = "";

    if (selectedSrcModelRows.length === 0) {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
      return;
    }

    if (selectedTargetModelRows.length === 0) {
      AppData.setAlertBox(true, "Select any CIC from Target Items.");
      return;
    }

    if (selectedTargetModelRows.length > 1) {
      AppData.setAlertBox(true, "More than one selection of cic from target not allowed.");
      return;
    }

    let uniqueProdSourceCd = [... new Set(selectedSrcModelRows.map(item => item.prodSourceCd))];

    if (uniqueProdSourceCd.length === 1) {

      if (MappingStatus === "P" && uniqueProdSourceCd[0] == "WHSE" && selectedTargetModelRows[0].itemTypeWhseDsd == "WHSE") {
        error = `Multiple WHSE to WHSE mapping not allowed.`;
        AppData.setAlertBox(true, error);
        return;
      }
      else if (uniqueProdSourceCd[0] == "DSD" && selectedTargetModelRows[0].itemTypeWhseDsd == "WHSE") {
        error = MappingStatus === "P" ? "DSD to WHSE mapping not allowed." : "DSD to WHSE unmapping not allowed.";
        AppData.setAlertBox(true, error);
        return;
      }
      else if (uniqueProdSourceCd[0] == "WHSE" && selectedTargetModelRows[0].itemTypeWhseDsd == "DSD") {
        error = MappingStatus === "P" ? "WHSE to DSD mapping not allowed." : "WHSE to DSD unmapping not allowed.";
        AppData.setAlertBox(true, error);
        return;
      }
    }

    if (uniqueProdSourceCd.length === 2) {

      let isSourceWhse = true;

      for (let i = 0; i < uniqueProdSourceCd.length; i++) {
        if (uniqueProdSourceCd[i] === "WHSE") {
          isSourceWhse = true;
          break;
        }
      }

      if (isSourceWhse && selectedTargetModelRows[0].itemTypeWhseDsd !== "WHSE") {
        error = MappingStatus === "P" ? "Mapping to DSD not allowed." : "Unmapping to DSD not allowed.";
        AppData.setAlertBox(true, error);
        return;
      }
    }

    if (error !== "") {
      AppData.setAlertBox(true, error);
    } else {

      let returnValue = false;

      function includes(container, value) {
        var pos = container.indexOf(value);
        if (pos >= 0) {
          returnValue = true;
        }
        else {
          returnValue = false;
        }
        return returnValue;
      }

      for (var i = 0; i < selectedSrcModelRows.length; i++) {
        // if (selectedTargetModelRows[0] && selectedSrcModelRows[i]) {
        if (includes(selectedTargetModelRows[0].upcList, selectedSrcModelRows[i].upcs[0]) == false) {
          break;
          // }
        }
      }

      if (returnValue) {

        if (MappingStatus === "P") {

          onMapApiCall();

        } else {
          onUnmapApiCall();
        }

      } else {
        AppData.setAlertBox(true, "Imperfect UPC matching.");
      }
    }

  }, [selectedSrcModelRows, selectedTargetModelRows, companyId, divisionId, MappingStatus])

  useEffect(() => {
    setSelectionSrcModel([]);
    AppData.mapSelectedRowData([]);
  }, [memi21_sourceItems, multiUnitSrcFilter])

  useEffect(() => {
    setSelectionTargetModel([]);
    AppData.mapSelectedRowData([]);
  }, [memi21_targetItems, multiUnitTargetFilter]);

  /* useEffect(() => {
     setSelectionSrcModel([]);
     setSelectionTargetModel([]);
     AppData.mapSelectedRowData([]);
   }, [memi21_sourceItems, memi21_targetItems])*/

  useEffect(() => {
    setSelectionTargetModel([]);
    setSelectionSrcModel([]);
  }, [MappingStatus]);

  const SourceItemsColumns = [
    {
      field: 'productSku',
      headerName: 'Product SKU',
      width: 180,
      sortable: false,
      headerClassName: "MultiUnitTableProductSku",
      renderCell: (params) => (
        <>
          {params.value}
          {/* <div className={"multiUnitIconDiv"}> */}
          <div className="MultiUnitScreenIconCircle" onClick={() => openTableModal(params.row.productSkuSet, "Product SKU list")} style={{ float: "right" }}>
            {params.row.productSkuSet.length}
          </div>

          {/* </div> */}
        </>
      )

    },

    {
      field: 'srcItemDesc',
      headerName: 'Item Description',
      width: 360,
      sortable: false,
      headerClassName: "MultiUnitTableHeader"

    },
    {
      field: 'srcPackWhse',
      headerName: 'Pack',
      width: 55,
      sortable: false,
      headerClassName: "MultiUnitTableHeader"
    },
    {
      field: 'srcVendConvFctr',
      headerName: 'VCF',
      width: 55,
      sortable: false,
      headerClassName: "MultiUnitTableHeader"

    },
    {
      field: 'srcSize',
      headerName: 'Size',
      sortable: false,
      width: 50,
      // sortable: false,
      headerClassName: "MultiUnitTableHeader"
    },
    {
      field: 'UPCs',
      headerName: "UPCs",
      width: 155,
      sortable: false,
      headerClassName: "MultiUnitTableHeader",
      renderCell: (params) => (
        <>
          {params.row.displayUpc}
          &nbsp;
          &nbsp;
          <div className="MultiUnitScreenIconCircle" onClick={() => openTableModal(params.row.upcs, "UPC List")}>
            {params.row.upcs.length}
          </div>
        </>
      )
    },
    {
      field: 'deptName',
      headerName: "Department",
      width: 130,
      sortable: true,
      headerClassName: "MultiUnitTableHeader"
    },
    {
      field: 'productHierarchy',
      headerName: "Product Hierachy",
      width: 110,
      sortable: true,
      headerClassName: "MultiUnitTableHeader"

    },
    {
      field: 'prodSourceCd',
      headerName: 'DSD/ WHSE',
      sortable: false,
      headerClassName: "MultiUnitTableHeader",
      width: 70,
    },
    {
      field: 'srcCost',
      headerName: 'Cost',
      sortable: false,
      headerClassName: "MultiUnitTableHeader",
      width: 70,
    },
    {
      field: 'maxRetail',
      headerName: 'Max Retail',
      headerClassName: "MultiUnitTableHeader",
      sortable: false,
      width: 70,
      headerAlign: "center"
    },
    {
      field: 'srcVendName',
      headerName: 'Vendor Name',
      headerClassName: "MultiUnitTableHeader",
      sortable: true,
      // width: 130,
      headerAlign: "left"
    }

  ];

  const targetItemsColumns = [
    {
      field: 'corpItemCd',
      headerName: 'CIC',
      sortable: false,
      headerClassName: "MultiUnitTableProductSku",
    },

    {
      field: 'itemDesc',
      headerName: 'Item Description',
      width: 350,
      sortable: false,
      headerClassName: "MultiUnitTableHeader"

    },
    {
      field: 'packWhse',
      headerName: 'Pack',
      width: 55,
      sortable: false,
      headerClassName: "MultiUnitTableHeader"
    },
    {
      field: 'vendConvFctr',
      headerName: 'VCF',
      width: 50,
      sortable: false,
      headerClassName: "MultiUnitTableHeader"

    },
    {
      field: 'size',
      headerName: 'Size',
      sortable: false,
      // width: 75,
      // sortable: false,
      headerClassName: "MultiUnitTableHeader"
    },
    {
      field: 'displayUpc',
      headerName: "UPCs",
      // width: 155,
      sortable: false,
      headerClassName: "MultiUnitTableHeader",
      renderCell: (params) => (
        <>
          {params.row.displayUpc}
          &nbsp;
          &nbsp;
          <div className="MultiUnitScreenIconCircle" onClick={() => openUPCTableModal(params.row, ["UPC List", "Unit Type", "RUP"])}>
            {params.row.upcList.length}
          </div>
        </>
      )
    },
    {
      field: 'targetDepartment',
      headerName: "Retail Section",
      width: 150,
      sortable: true,
      headerClassName: "MultiUnitTableHeader"
    },
    {
      field: 'smicCode',
      headerName: "SMIC",
      width: 110,
      sortable: true,
      headerClassName: "MultiUnitTableHeader"

    },
    {
      field: 'itemTypeWhseDsd',
      headerName: 'DSD/ WHSE',
      sortable: false,
      headerClassName: "MultiUnitTableHeader",
      width: 50,
    },
    {
      field: 'cost',
      headerName: 'Cost',
      sortable: false,
      headerClassName: "MultiUnitTableHeader",
      width: 50,
    },
    {
      field: 'vendorName',
      headerName: 'Vendor Name',
      sortable: true,
      headerClassName: "MultiUnitTableHeader",
      // width: 165,
    }


  ];

  const innerComponent = (rowData, column, index) => {
    const columns = [
      {
        field: '',
        headerName: '',
        sortable: false,
        headerClassName: "MultiUnitTableProductSku",
        width:80
      },
  
      {
        field: 'caseUpc',
        headerName: 'Case UPC',
        width: 350,
        sortable: false,
        headerClassName: "MultiUnitTableHeader"
  
      },
      {
        field: 'retailSection',
        headerName: 'Retail Section Number',
        sortable: false,
        headerClassName: "MultiUnitTableHeader",
        width:160
      },
      {
        field: 'corpStatus',
        headerName: 'Corp Status',
        width: 120,
        sortable: false,
        headerClassName: "MultiUnitTableHeader"
  
      },
      {
        field: 'innerPack',
        headerName: 'Inner pack',
        sortable: false,
        width: 150,
        // sortable: false,
        headerClassName: "MultiUnitTableHeader"
      },
      {
        field: 'vendorNumber',
        headerName: "Vendor Number",
        headerClassName: "MultiUnitTableHeader"
      },
      
    ]


    return (
      <TableDisplayerCollapsible
        disableSelection={true}
        columns={columns}
        data={rowData ? [rowData] : []}
        classNameMemi={`ssimSrcItemsCls multiUnitInnerTable ${index%2==0 ? "ssimSrcItemsRow" : "ssimSrcItemsOddRow"}`}
        disableCollapsible={() => { return true }}

      />
    )
  }

  return (
    <Grid
      container
      className="MainContent"
    >
      <Grid item xs={12} className="source" >
        Source Items
      </Grid >

      <SourceItems selectedTargetModelRows={selectedTargetModelRows} setSelectionSrcModel={setSelectionSrcModel} selectedSrcModelRows={selectedSrcModelRows} onLoadMultiUnit={props.onLoadMultiUnit} MappingStatus={props.MappingStatus} />
      <Grid item xs={12} style={{ height: "15rem" }}>
        <TableDisplayerCollapsible
          classNameMemi="ssimSrcItemsCls  ssimSrcItemsRow multiUnitScreenCollapsbile"
          data={multiUnitSrcFilter !== undefined ? multiUnitSrcFilter : memi21_sourceItems}
          columns={SourceItemsColumns}
          selectionType="checkbox"
          rowheight={22}
          hideFooter
          stickyHeader
          containerClass="MultiUniScreenTableHeight MultiUnitBackground"
          selectedRows={selectedSrcModelRows}
          setSelectedRows={(selectedSrcModelRows) => setSelectionSrcModel(selectedSrcModelRows)}
          rowCount={memi21_sourceItems.length < 400 ? memi21_sourceItems : 400}
          disableCollapsible={() => { return true }}
          setData={(data) => {AppData.setMemi21_sourceItems(data)}}

        />
      </Grid>
      <Grid item xs={12} className="multiUnitCountCls">
        Showing {multiUnitSrcFilter !== undefined ? multiUnitSrcFilter.length : memi21_sourceItems.length} out of {multiUnitSrcData && multiUnitSrcData.length} items.
        <br />

        {
          props.MappingStatus === "P" ?
            <ButtonMemi
              classNameMemi="MultiUnitScreenButton"
              btnval="Map Items"
              onClick={onClickMapAndUnmapItems}
            /> :
            <ButtonMemi
              classNameMemi="MultiUnitScreenButton"
              btnval="Unmap Items"
              onClick={onClickMapAndUnmapItems}
            />
        }

      </Grid>
      <Grid item xs={12} className="source">
        Target Items
      </Grid>

      <TargetItems onLoadMultiUnit={props.onLoadMultiUnit} setSelectionTargetModel={setSelectionTargetModel} selectedSrcModelRows={selectedSrcModelRows} MappingStatus={props.MappingStatus} />

      <Grid item xs={12} style={{ height: "15rem" }}>
        <TableDisplayerCollapsible
          classNameMemi="ssimSrcItemsCls  ssimSrcItemsRow multiUnitScreenCollapsbile"
          data={multiUnitTargetFilter !== undefined ? multiUnitTargetFilter : memi21_targetItems}
          columns={targetItemsColumns}
          selectionType="checkbox"
          rowheight={22}
          hideFooter
          stickyHeader
          containerClass="MultiUniScreenTableHeight"
          selectedRows={selectedTargetModelRows}
          setSelectedRows={(selectedSrcModelRows) => setSelectionTargetModel(selectedSrcModelRows)}
          rowCount={memi21_targetItems.length < 400 ? memi21_targetItems : 400}
          disableCollapsible={(row) => { return false }}
          collapsibleTabelContent={innerComponent}
          setData={(data) => {AppData.setMemi21_targetItems(data)}}
        />
      </Grid>
      <Grid item xs={12} className="multiUnitCountCls">

        Showing {multiUnitTargetFilter !== undefined ? multiUnitTargetFilter.length : memi21_targetItems.length} out of {multiUnitTargetData && multiUnitTargetData.length} items.
      </Grid>
    </Grid>



  )
}

export default MultiUnitScreen;

