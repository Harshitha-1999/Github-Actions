import React from 'react'
import ButtonLogout from 'components/ButtonLogout/ButtonLogout'
import { Grid } from '@material-ui/core'
function HeaderErrorMeup() {
    return (
        <Grid container direction="row" spacing={0}>
            <Grid item xs={3} className="logomeup">
                <div className="logo">
                    <img src="/logo_abs.gif" alt="" />
                </div>

            </Grid>
            <Grid item xs={6} className="headingmeup headcotext">

                Unallocated Item Management

            </Grid>
            <Grid item xs={3} className="logoutmeup">
                <ButtonLogout
                    classNameMemi="HeaderMeupButton"
                />
            </Grid>
        </Grid>
    )
}

export default HeaderErrorMeup
