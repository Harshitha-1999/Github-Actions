import React, { useState, useEffect, memo } from 'react'
import ButtonMemi from '../ButtonMemi/ButtonMemi'
import { Info, Sort, Sync, Check, Close } from "@material-ui/icons";
import { Box, Popper, Grid, ClickAwayListener } from '@material-ui/core';
import RadioMemi from "../../components/RadioMemi/RadioMemi";
function SortByMemi(props) {

    const [anchorEl, setAnchorEl] = useState(null);
    const [sortingOrder, setSortingOrder] = useState(props.sortOrder ? props.sortOrder : "A")
    const [draggedId, setDraggedId] = useState(null);
    const [active, setActive] = useState(props.sortOrder ? true : false);
    const handleClick = (event) => {
        setAnchorEl(anchorEl ? null : event.currentTarget);
    };

    // useEffect(() => {
    //     const sortListtemp = props.sortList.map((data, index) => {
    //         return { selected: false, label: data.label, value: data.value, id: index }
    //     })
    //     props.setSortList(sortListtemp)
    // }, [props.sortList])

    //For css hover effect
    const [draggedOverId, setDraggedOverId] = useState("");
    const [counter, setCounter] = useState(0)

    const handleSelect = (targetIndex) => {
        const newSortList = props.sortList.map((data, index) => {
            if (index === targetIndex) {
                return { ...data, selected: !data.selected }
            }
            return data
        })
        props.setSortList(newSortList)
    }

    const open = Boolean(anchorEl);
    const id = open ? 'simple-popper' : undefined;
    const handleApply = () => {
        let list = [];
        props.sortList.forEach((x) => {
            if (x.selected) {
                list.push(x.value);
            }
        })
        setActive(true)
        props.onClickApply(list, sortingOrder)
        setAnchorEl(null)

    }

    const handleReset = () => {
        const sortListtemp = props.sortList.map((data, index) => {
            return { ...data, selected: false, id: index }
        })
        console.log(sortListtemp)
        setActive(false)
        setSortingOrder("A")
        props.setSortList(sortListtemp)
    }

    const handleDrop = (droppedIndex) => {
        let tempList = [];
        setDraggedOverId("")
        if (droppedIndex < draggedId) {
            props.sortList.forEach((data) => {
                if (data.id === draggedId) {
                    return;
                }
                else if (data.id < droppedIndex || data.id > draggedId) {
                    tempList.push(data)
                }
                else if (data.id === droppedIndex) {
                    tempList.push({ ...props.sortList[draggedId], id: droppedIndex })
                    tempList.push({ ...props.sortList[droppedIndex], id: droppedIndex + 1 })
                }
                else {
                    tempList.push({ ...props.sortList[data.id], id: data.id + 1 })
                }

            })

        }
        else {
            props.sortList.forEach((data) => {
                if (data.id === draggedId) {
                    return;
                }
                else if (data.id > droppedIndex || data.id < draggedId) {
                    tempList.push(data)
                }
                else if (data.id === droppedIndex) {
                    tempList.push({ ...props.sortList[draggedId], id: droppedIndex })
                    tempList.push({ ...props.sortList[droppedIndex], id: droppedIndex - 1 })
                }
                else {
                    tempList.push({ ...props.sortList[data.id], id: data.id - 1 })
                }

            })
        }
        tempList.sort((a, b) => { return a.id < b.id })

        props.setSortList(tempList)
    }

    const handleDragStart = (index) => {
        setDraggedId(index)
        //set Counter to prevent removing run onDragLeave by child Elements
        setCounter((count) => { return count + 1 });
        handleSelect(index)
    }

    const handleDragLeave = () => {
        setCounter((count) => { return count - 1 })
        if (counter <= 0) {
            setCounter(0)
            setDraggedOverId("");
        }
    }

    const handleDragOver = (e, id) => {
        e.preventDefault();
        setDraggedOverId(id);
    }

    return (
        <ClickAwayListener onClickAway={() => setAnchorEl(null)}>
            <div>
                <ButtonMemi
                    btnval="Sort By"
                    classNameMemi={props.ButtonClass}
                    endIcon={<Sort style={{ color: active ? props.activeColor : "" }} />}
                    btnsize={props.btnsize}
                    onClick={handleClick}
                />
                <Popper id={id} open={open} anchorEl={anchorEl} className={props.sortByClass} placement={props.placement} style={{ zIndex: "10000" }}>
                    <Box>
                        <Grid container>
                            <Grid item xs={12}>
                                <RadioMemi
                                    Mainlabel="Sort Order"
                                    label={[{ label: "Asc", value: "A" }, { label: "Desc", value: "D" }]}
                                    classnameMemi={"RadioSortByRadioClass2"}
                                    labelClass={props.RadioSortByLabelClass}
                                    radioGroupClass={"RadioSortByClass"}
                                    value={sortingOrder}
                                    setValue={(value) => setSortingOrder(value)}
                                    size="small"
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <label className={props.RadioSortByLabelClass}>
                                    Sort Items
                                    <span title="Rearrange, drag & drop and multiple selection can be performed">
                                        <Info

                                            style={{ fontSize: "16px", marginLeft: "10px" }}
                                        />
                                    </span>
                                    <span title="Reset Sort Items">
                                        <Sync
                                            style={{ fontSize: "16px", marginLeft: "9px" }}
                                            onClick={handleReset}
                                        />

                                    </span>
                                </label>
                            </Grid>
                            <Grid item xs={12} onDragLeave={handleDragLeave}>

                                {

                                    props.sortList.map((data, index) => (
                                        <div
                                            id={"sortByElement"+index}
                                            className={`listSortBy ${data.selected ? "listSortBySelected" : ""} ${draggedOverId === index ? "listSortByDraggedOver" : ""}`}
                                            onClick={() => handleSelect(index)}
                                            draggable={true}
                                            onDrop={(e) => handleDrop(index)}
                                            onDragStart={(e) => handleDragStart(index)}
                                            onDragOver={(e) => handleDragOver(e, index)}
                                        >
                                            {data.label}
                                        </div>
                                    ))
                                }

                            </Grid>
                            <Grid item xs={12}>
                                <ButtonMemi
                                    startIcon={<Check className="lookUpIcon" />}
                                    btnval="Apply"
                                    classNameMemi="sortByButton sortByApplyButton"
                                    btnsize="small"
                                    onClick={handleApply}

                                />
                                <ButtonMemi
                                    startIcon={<Close className="lookUpIcon" />}
                                    btnval="Close"
                                    classNameMemi="sortByButton sortByResetButton"
                                    btnsize="small"
                                    onClick={() => setAnchorEl(null)}
                                />
                            </Grid>
                        </Grid>
                    </Box>
                </Popper>
            </div>
        </ClickAwayListener>

    )
}

export default memo(SortByMemi)
