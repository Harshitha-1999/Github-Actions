import React, { useContext } from 'react'
import { Grid } from '@material-ui/core'
import SearchBarSkuUpc from 'components/SearchBarSkuUpc/SearchBarSkuUpc'
import TableMemi from 'components/TableMemi/TableMemi';
import NoRecordsDisplay from 'components/NoRecordsDisplay/NoRecordsDisplay';
import ApplicationContext from "../../context/ApplicationContext";
import { memiuServices } from 'api/memiu/memiuService';
import { RouteBase } from 'routes/constants';
import { useHistory } from 'react-router';

export default function ModelLikeMatch(props) {
    const AppData = useContext(ApplicationContext);
    const history = useHistory();
    const columns = [
        {
            field: "deptName",
            headerName: " ",
            sortable: false,
            flex: 0.35,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            disableColumnSelector: false,
            disableColumnFilter: false,
            disableColumnMenu: false

        },
        {
            field: "totalWHSERecords",
            headerName: "WHSE",
            sortable: false,
            headerClassName: "HeaderModelLikeMatchTable",
            disableColumnSelector: false,
            disableColumnFilter: false,
            disableColumnMenu: false,
            headerAlign: "left",
            flex: 0.07,
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, 'N', 'W')}>
                    {params.value}
                </span>
            )
        },
        {
            field: "totalDSDRecords",
            headerName: "DSD",
            sortable: false,
            flex: 0.07,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, 'N', 'D')}>
                    {params.value}
                </span>
            )
        },
        {
            field: "totalRecord",
            headerName: "Total",
            sortable: false,

            flex: 0.08,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, 'N', 'A')}>
                    {params.value}
                </span>
            )
        },
        {
            field: "unReviwExcelDownload",
            headerName: " ",
            sortable: false,

            headerAlign: "left",
            flex: 0.2,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span onClick={() => handleExcelDownload(params, "totalRecord", "O", "N")}>
                    <img src="/export_to_excel_icon.png" alt="/" title={params.row.totalRecord > 0 ? "Export To Excel" : ""} style={{cursor:params.row.totalRecord > 0 ? "pointer" : "default"}} />
                </span>
            )
        },
        {
            field: "completedWHSEItmCnt",
            headerName: "WHSE",
            sortable: false,

            headerAlign: "left",
            flex: 0.07,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, 'C', 'W')}>
                    {params.value}
                </span>
            )
        },
        {
            field: "completedDSDItmCnt",
            headerName: "DSD",
            sortable: false,

            headerAlign: "left",
            flex: 0.07,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, 'C', 'D')}>
                    {params.value}
                </span>
            )
        },
        {
            field: "completedItmCnt",
            headerName: "Total",
            sortable: false,

            headerAlign: "left",
            flex: 0.08,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass" } onClick={() => handleLinkClick(params, 'C', 'A')}>
                    {params.value}
                </span>
            )
        },
        {
            field: "reviwExcelDownload",
            headerName: " ",
            sortable: false,
            width: 100,
            headerAlign: "left",
            flex: 0.2,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span onClick={() => handleExcelDownload(params, "completedItmCnt", "O", "C")}>
                    <img src="/export_to_excel_icon.png" alt="/" title={params.row.completedItmCnt > 0 ? "Export To Excel" : ""} style={{cursor:params.row.completedItmCnt > 0 ? "pointer" : "default"}} />
                </span>
            )
        },
    ]

    const handleLinkClick = (params, status, type) => {
        if (params.value === 0) {
            AppData.setAlertBox(true, "No more item to view.")
        }
        else {
            memiuServices.getLoadOverideData2(params.row.deptCode, "O", AppData.companyId, AppData.divisionId, status, type)
                .then((res) => {
                    if (res.data === null || res.data.length === 0) {
                        AppData.setAlertBox(true, "No more item to view.")
                    }
                    else {
                        AppData.setOverideServiceKey("")
                        AppData.setMemi14({ updateoverridesku: res.data, UpdateOverrideManualSearch:{} })
                        history.push(RouteBase.MEMI14)
                    }
                })

                .catch((err) => {
                })
        }
    }

    const handleExcelDownload = (params, row, exceptionType, status) => {
        if (params.row[`${row}`] === 0) { return }
        else {
            let data = {
                deptName: params.row.deptName,
                deptCode: params.row.deptCode,
                division: AppData.divisionId,
                company: AppData.companyId,
                exceptionType,
                status
            }

            const deptName = params.row.deptName.toLowerCase()
            const capsDeptName = deptName.charAt(0).toUpperCase() + deptName.slice(1);

            memiuServices.getDownloadExcel(data).then((res) => {
                const url = window.URL.createObjectURL(new Blob([res.data],));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', `Exceptions_${capsDeptName}.xlsx`);
               
                link.click();
            })
        }
    }
    const customNoRowsOverlay = () => {
        return (
            <div className="customNoRows">
                <NoRecordsDisplay />
            </div>
        )
    }
    return (
        <Grid container>
            <Grid item xs={12} className="NoItemsMatchElementOne">
                <table style={{ width: "100%", fontSize: "15px" }}>
                    <tbody>
                        <tr>
                            <td style={{ width: "25%" }} align="left"> Retails Section</td>
                            <td style={{ width: "30%", textAlign: "left" }} align="left"> Un-reviewed Items</td>
                            <td style={{ width: "30%", textAlign: "left" }} align="left"> Completed Items</td>
                        </tr>
                    </tbody>
                </table>
            </Grid>
            <Grid item xs={12} style={{ height: "100%" }}>
                <TableMemi
                    autoHeight
                    columns={columns}
                    hideFooter
                    hideFooterPagination
                    NoRowsOverlay={customNoRowsOverlay}
                    classnameMemi="ModelLikeMatchTable"
                    data={AppData.memi13.data}
                    disableColumnMenu
                    disableColumnFilter
                    rowheight={22}
                />
            </Grid>
            <Grid item xs={12} className={`modelLikeMatchTotalItems ${AppData.memi13.data.length === 0 ? "totalItemsDisable" : AppData.memi13.data.length % 2 == 0 ? "totalItemsOdd" : "totalItemsEven"}`}>
                <div style={{ width: "100%", paddingLeft: "7px", display: "flex", fontWeight: "bold" }}>
                    <div style={{ flex: "0.296", fontWeight: "bold" }}> Total Count</div>
                    <div style={{ textAlign: "left", flex: "0.058", color: "rgb(100,150,200)" }} align="left"> {AppData.memi13.totalUnReviewWHSE}</div>
                    <div style={{ textAlign: "left", color: "rgb(100,150,200)", flex: "0.058" }} align="left"> {AppData.memi13.totalUnReviewDsd} </div>
                    <div style={{ textAlign: "left", color: "rgb(100,150,200)", flex: "0.234", }} align="left"> {AppData.memi13.totalUnReview} </div>

                    <div style={{ textAlign: "left", color: "rgb(100,150,200)", flex: "0.065" }} align="left"> {AppData.memi13.totalReviewWHSE}</div>
                    <div style={{ textAlign: "left", color: "rgb(100,150,200)", flex: "0.058" }} align="left">  {AppData.memi13.totalReviewDsd} </div>
                    <div style={{ textAlign: "left", color: "rgb(100,150,200)", flex: "0.08" }} align="left"> {AppData.memi13.totalReview} </div>
                </div>
            </Grid>
            <SearchBarSkuUpc/>
        </Grid>
    )
}
