import React from 'react';
import "../../css/App.css";
function FooterMeup(props) {
    return (

        <div className="footermeup">
            <font className="footlink"> <a className="linksafeway" target="_blank" href="http://home.safeway.com/it/standards/security/index.html" rel="noreferrer"><span className="footwarn">Warning: Authorized users only.</span></a><p className="foottext">All information herein is proprietary and confidential. Usage is monitored. Copyright
                Safeway Inc.<sup>@</sup> 2008. All rights reserved.</p></font>
        </div>

    );
}

export default FooterMeup;