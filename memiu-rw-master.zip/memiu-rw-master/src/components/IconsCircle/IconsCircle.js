import React from 'react';
import "../../css/App.css";

function IconsCircle(props) {
    return (
        <div className="icons" style={{ backgroundColor: props.color }}>

        </div>
    );
}

export default IconsCircle;