import React from 'react';
import { Grid, Button } from "@material-ui/core";
// import ButtonLogout from "components/ButtonLogout/ButtonLogout";
import HamburgerMenu from "components/HamburgerMenu/HamburgerMenu";
import routes from "../../routes/routes";
import { makeStyles } from "@material-ui/core/styles";
import { Buttons } from '../../routes/routes'
import { useHistory, useLocation } from 'react-router';
import { authTokenCookie } from 'utils';
import "../../css/App.css";

const useStyles = makeStyles((theme) => ({
  menuBtn: {
    color: "#fff",
    width: "100%",
    height: "100%",
    backgroundColor: "#897056",
    // boxShadow: "-3px 3px, -2px 2px, -1px 1px",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    // border: "1px solid #4caf50",
    "&:hover": {
      backgroundColor: "#897056",

    },
    "& .MuiButton-endIcon": {
      display: "none"

    },
    padding: "14px 16px",
    cursor: "pointer",
    textTransform: "none"
    // width: "fit-content"
  },
  navigationBar: {
    backgroundColor: "#3196d3",
    width: "max-content",
    display: "flex",
    marginBottom: "10px"
  },
  menuBtnActive: {
    color: "#897056",
    width: "100%",
    height: "100%",
    backgroundColor: "#897056",
    // boxShadow: "-3px 3px, -2px 2px, -1px 1px",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    // border: "1px solid #4caf50",
    "&:hover": {
      backgroundColor: "#897056",
      "& svg": {

        color: "black"
      },
      color: "#d6ebfb",
    },
    "& svg": {
      transform: "scale(1.5)",
      color: "black",

    },
    padding: "14px 16px",
    cursor: "pointer",
    textTransform: "none"
    // width: "fit-content"

  },
  linkItem: {
    textDecoration: "none",
  },

  formcontrol: {
    display: "flex",
    flexDirection: "row"
  },
}));


function HeaderMeup(props) {
  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();

  function changeRoute(path) {
    history.push(path);
  };

  let { userId } = authTokenCookie();
  const pstDate = new Date().toLocaleString("en-US", { timeZone: "America/Los_Angeles" }).split(",")[0].split("/");
  const month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
  const date = `${month[parseInt(pstDate[0]) - 1]} ${pstDate[1]}, ${pstDate[2]}`

  const getRoutes = () => {
    const newButtons = Buttons.filter((Button) => Button.navNames.includes("home") && Button.path !== location.pathname)
    return (newButtons.map((ButtonComp) => {
      return ButtonComp.component ? ButtonComp.component : <> <Button onClick={() => changeRoute(ButtonComp.path)} className="HeaderMeupButton">{ButtonComp.label}</Button> <font size="2" face="Tahoma" color="#FFFFFF">|</font> </>
    }))
  }
  return (
    <Grid container direction="row" spacing={0}>

      <Grid item xs={1}>
        <HamburgerMenu
          buttonClass={classes.menuBtn}
          menuData={routes.filter((item) => item.navigationBar === "yes" && item.navNames.includes("meup"))}

        />

      </Grid>
      <Grid item xs={3} sm={3} md={3} xl={3} className="logomeup">
        <div className="logo">
          <img src="/logo_abs.gif" alt="" />
        </div>

      </Grid>
      <Grid item xs={6} sm={6} md={6} xl={6} className="headingmeup headcotext">

        Unallocated Item Management

      </Grid>
      <Grid item xs={2} sm={2} md={2} xl={2} className="logoutmeup">
        {
          getRoutes()
        }
      </Grid>
      <Grid item xs={12} sm={12} md={12} xl={12}>
        <div className="titlemeup">
          <div style={{ backgroundColor: "#CFC3AD", width: "fit-content", padding: "0.5rem 1rem 0rem 1rem", height: "1.5rem" }}>
            <strong> {props.title} </strong>
          </div>
        </div>

      </Grid>
      <Grid item xs={12}>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div>

            You are logged in as {userId.toLowerCase()}

          </div>
          <div style={{ marginLeft: "auto" }}>
            {date}
          </div>
        </div>
      </Grid>
    </Grid>

  );
}

export default HeaderMeup;