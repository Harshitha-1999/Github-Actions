import React from 'react';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';

function RadioMemi(props) {
  return (
    <div className={props.classnameMemi}>
      <div className={props.labelClass}>{props.Mainlabel}</div>
      <RadioGroup row aria-label="gender" name="row-radio-buttons-group" value={props.value} onChange={(e) => props.setValue(e.target.value)} className={props.radioGroupClass}>
        {props.label.map((option, index) => (
          <FormControlLabel
            value={option.value}
            control={<Radio size={props.size} color="default" />}
            label={option.label}
            id={index}
            className={props.radioclassmemi}
          />
        ))}

      </RadioGroup>
    </div>
  );
}

export default RadioMemi;