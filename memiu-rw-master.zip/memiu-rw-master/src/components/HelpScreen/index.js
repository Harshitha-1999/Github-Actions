import React, { useEffect, useCallback, useState } from "react";
import { DateUtility } from 'utils';
import "./HelpScreen.scss";
import { useErrorField, useHelp } from "hooks";
//import { LabelWidget } from "components";

export const HelpScreen = ({ message, children, open = false, scope, onClose }) => {
    //let EOL;
    const { setErrorField, clearErrorField } = useErrorField();
    const { endOfListObject } = useHelp();
    const [finalPixel, setFinalPixel] = useState(350);
    const [lastPageReached, setLastPageReached] = useState(false)
    let [moreField, setMoreField] = useState("More...")
    const [error, setError] = useState(undefined);
    clearErrorField()
    // let elCheck = document.getElementById("help-content");
    const handleScroll = useCallback((key) => {
        let el = document.getElementById("help-content");

        if (key === "F7") {
            if (el.scrollTop === 0) {
                setErrorField("First Page is Already Displayed", null, "yellow")
            }
            else {
                clearErrorField()
                // alert(el.offsetHeight +" "+ el.scrollTop)
                setFinalPixel(el.scrollTop % 350);
                (finalPixel === 350 || finalPixel === 0) ? el.scrollBy(0, -350) : el.scrollBy(0, -finalPixel);
                setFinalPixel(350);
                setMoreField("More...");
                setLastPageReached(false);
            }

        }
        else {
            if (lastPageReached) {
                setErrorField("Last Page is Already Displayed", null, "yellow")
            }
            else {
                clearErrorField()
                setFinalPixel(350 - (el.scrollTop % 350));
                // el.scrollBy(0, 350);
                (finalPixel === 350 || finalPixel === 0) ? el.scrollBy(0, 350) : el.scrollBy(0, finalPixel);

                if (el.offsetHeight + el.scrollTop === el.scrollHeight) {

                    setFinalPixel(el.scrollTop % 350)
                    // alert(finalPixel)
                    setLastPageReached(true);
                    setMoreField("END OF LIST");
                }
                else {
                    setLastPageReached(false);
                    setMoreField("More...");
                }
                // alert(moreField)
            }

        }
    }, [clearErrorField, finalPixel, lastPageReached, setErrorField]);

    const onHotKeyPress = useCallback((event, key) => {
        let keyCode = event.key ? event.key : key;
        switch (keyCode) {
            case 'F1':
                event.preventDefault();
                event.stopPropagation();
                break;
            case 'F3':
                event.preventDefault();
                event.stopPropagation();
                onClose();
                break;
            case 'F7':
                event.preventDefault();
                event.stopPropagation();
                handleScroll("F7");
                break;
            case 'F8':
                event.preventDefault();
                event.stopPropagation();
                handleScroll("F8");
                break;
            default:
                break;
        }
    }, [handleScroll, onClose]);

    useEffect(() => {
        let el = document.getElementById("help-content");
        if (el) { el.scrollTop = 0; }
    }, [scope, open])

    useEffect(() => {
        if (endOfListObject.hasOwnProperty(scope) && endOfListObject[scope] === "Y") {
            setMoreField("END OF LIST");
            setLastPageReached(true);
        }
        else {
            setMoreField("More...");
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // add an event listener for keydown that uses the onHotKeyPress callback prop
    // to trigger keydown actions depending on which page the user is on
    // use and empty depedency array to make sure we only do this on the initial render.
    useEffect(() => {
        document.addEventListener("keydown", onHotKeyPress);
        return () => {
            document.removeEventListener("keydown", onHotKeyPress);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    useEffect(() => {
        let el = document.getElementById("txtError");
        el && setError(error);
    }, [error]);

    useEffect(() => {
        // // let elCheck = document.getElementById("help-content");
        // if (elCheck && elCheck.scrollTop != 0 && (elCheck.offsetHeight + elCheck.scrollTop === elCheck.scrollHeight)) {
        //     // alert(finalPixel)
        //     setMoreField("END OF LIST");
        // }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [setMoreField]);

    return (
        <React.Fragment>
            <dialog open={open}>
                <div className="helpmaincontainer">
                    <header className="helpheadertag">
                        <div className="helpcontainer">
                            <div className="helpHeaderDiv">
                                <h4 className="helpheader">
                                    BOS-help help text display
                                </h4>
                                <span className="helpTimeZone">
                                    {DateUtility.getMountainStdTime()}
                                </span>
                            </div>
                            <span className="helpmessage">
                                Message.. : {message}
                            </span>
                        </div>
                    </header>
                    <div id="help-content" className="helpcontent">
                        {children}
                    </div>
                    {/* <span className="helpcontent">
                                More.. 
                            </span> */}

                    <footer className="helpfooter">
                        <div className="endOfList">
                            {moreField}
                        </div>
                        <div className="errorBox" >
                            <input className="errorBox" id="txtError" type="text" readOnly value={error} />
                        </div>

                        <ul >
                            <li> <button id="f3-help-button" onClick={(event) => onHotKeyPress(event, "F3")}>F3=Exit</button> </li>
                            <li> <button id="f7-help-button" onClick={(event) => onHotKeyPress(event, "F7")}>F7=Bkwd</button> </li>
                            <li> <button id="f8-help-button" onClick={(event) => onHotKeyPress(event, "F8")}>F8=Fwd</button> </li>
                        </ul>
                    </footer>

                </div>
            </dialog>
        </React.Fragment>
    );
}

export default HelpScreen;
