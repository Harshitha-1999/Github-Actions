import React from 'react';
import { cleanup, fireEvent, render, waitFor } from "@testing-library/react";
import ReduxProvider from 'providers/ReduxProvider';
import HelpScreen from '.';

describe("<HelpScreen />", () => {
    const mockOnClose = jest.fn();
    const mockScroll = jest.fn();
    const defaultProps = {
        message: "test message",
        children: [],
        open: false,
        scope: 'ISC020',
        onClose: mockOnClose
    }
    let documentSpy;

    beforeEach(() => {
        // mock out getElementById
        documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue({
            scrollBy: mockScroll,
            focus: jest.fn(),
            value: '',
            style: {
                color: '',
                removeProperty: jest.fn()
            },
            scrollBy: jest.fn(),
                scrollHeight: 0,
                scrollTop: 0,
                offsetHeight: 0
        });
    })

    it('Should render without errors', () => {

        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        )
        expect(container).toBeTruthy();
    });

    it('Should do nothing when F1 key is pressed', () => {
        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        );

        fireEvent.keyDown(container.querySelector('#help-content'), { key: 'F1' });

        expect(container).toBeTruthy();
    });

    it('Should call onClose function when F3 key is pressed or clicked', () => {
        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        );

        fireEvent.click(container.querySelector('#f3-help-button'), { key: 'F3' });

        expect(container).toBeTruthy();
        expect(mockOnClose).toHaveBeenCalled();
    });

    it('Should scroll when F7 key is pressed or clicked', () => {
        documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
            {
                focus: jest.fn(),
                value: '',
                style: {
                    color: '',
                    removeProperty: jest.fn()
                },
                scrollBy: jest.fn(),
                scrollHeight: 0,
                scrollTop: 0,
                offsetHeight: 0
            });

        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        );

        global.scrollBy = mockScroll();


        fireEvent.click(container.querySelector('#f7-help-button'), { key: 'F7' });


        expect(container).toBeTruthy();
        expect(mockScroll).toHaveBeenCalled();
    });


    it('Should scroll when F7 key is pressed or clicked else part', () => {
        documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
            {
                focus: jest.fn(),
                value: '',
                style: {
                    color: '',
                    removeProperty: jest.fn()
                },
                scrollBy: jest.fn(),
                scrollHeight: 1,
                scrollTop: 1,
                offsetHeight: 1
            });

        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        );
        global.scrollBy = mockScroll();
        fireEvent.click(container.querySelector('#f7-help-button'), { key: 'F7' });


        expect(container).toBeTruthy();
        expect(mockScroll).toHaveBeenCalled();
    });

    it('Should scroll when F8 key is pressed or clicked', () => {
        documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
            {
                focus: jest.fn(),
                value: '',
                style: {
                    color: '',
                    removeProperty: jest.fn()
                },
                scrollBy: jest.fn(),
                scrollHeight: 0,
                scrollTop: 0,
                offsetHeight: 0
            });
        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        );
        global.scrollBy = mockScroll();
        fireEvent.click(container.querySelector('#f8-help-button'), { key: 'F8' });

        
        expect(container).toBeTruthy();
        expect(mockScroll).toHaveBeenCalled();
    });


    it('Should scroll when F8 key is pressed or clicked, offset === screenheight meaning end of list has been reached', () => {
        //redfine documentSpy

        documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
            {
                focus: jest.fn(),
                value: '',
                style: {
                    color: '',
                    removeProperty: jest.fn()
                },
                scrollBy: jest.fn(),
                scrollHeight: 0,
                scrollTop: 0,
                offsetHeight: 0
            });



        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...defaultProps} />
            </ReduxProvider>
        );

        global.scrollBy = mockScroll();

        fireEvent.click(container.querySelector('#f8-help-button'), { key: 'F8' });

        expect(container).toBeTruthy();
        expect(mockScroll).toHaveBeenCalled();
    });

    it('Should do nothing when F2 is pressed, testing default switch block', () => {
        let props = {
            ...defaultProps,
            open: true
        }
        let { debug, container } = render(
            <ReduxProvider>
                <HelpScreen {...props} />
            </ReduxProvider>
        );

        fireEvent.keyDown(container.querySelector('#help-content'), { key: 'F2' });

        expect(container).toBeTruthy();
    });

})