import React, { useEffect, useCallback,useContext } from "react";
import { useErrorField } from "hooks";
import { DateUtility, Environment } from 'utils';
import LabelWidget from "../LabelWidget/LabelWidget";
import { Footer } from 'layouts';
import "./ServiceError.scss";
import ApplicationContext from "../../context/ApplicationContext";

let errorMessage = "";
let errorStatus = "";

export const ServiceError = ({ programName, error }) => {

  const AppData = useContext(ApplicationContext);
  const { logStatus } = AppData;
  const { logStatusResult } = AppData;
  const { setErrorField, clearErrorField } = useErrorField();

  if (error && error.response && error.response.data && error.response.data.hasOwnProperty('ABSResponse')) {
    const { ABSResponse: { errors, message } } = error.response.data;
    errorStatus = errors ? errors[0]['code'] : "";
    errorMessage = message ? message : "";
  } else {
    errorStatus = error.response?.status;
    errorMessage = error.message ? error.message : "";
  }

  const getFunction = useCallback(() => {
    const { method } = error.config;
    switch (method.toUpperCase()) {
      case "POST":
      case "GET":
        return "READ";
      case "PUT":
        return "UPDATE";
      case "DELETE":
        return "DELETE";
      case "JS":
        return "JS";
      default:
        return null;
    }
  }, [error]);

  const onHotKeyPress = useCallback((event, key) => {
    let keyCode = event.key ? event.key : key;
    keyCode = event.shiftKey ? `shift+${keyCode}` : keyCode;

    switch (keyCode) {
      case 'shift+F3':
        event.preventDefault();
        event.stopPropagation();
        window.location.href = `${Environment.getAzureRedirectUri()}`;
        break;
      case `${['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12', 'shift+F1', 'shift+F2', 'shift+F4', 'shift+F5', 'shift+F6', 'shift+F7', 'shift+F8', 'shift+F9', 'shift+F10', 'shift+F11', 'shift+F12'].filter(pfKey => pfKey === keyCode).join("")}`:
        event.preventDefault();
        event.stopPropagation();
        setErrorField("Invalid PF/PA Key", null, "red");
        break;
      default:
        break;
    }
  }, [setErrorField]);

  // add an event listener for keydown that uses the onHotKeyPress callback prop
  // to trigger keydown actions depending on which page the user is on
  // use and empty depedency array to make sure we only do this on the initial render.
  useEffect(() => {

    document.addEventListener("keydown", onHotKeyPress);
    return () => {
      document.removeEventListener("keydown", onHotKeyPress);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // to clear error field while loading 
  useEffect(() => {
    clearErrorField();
  }, [clearErrorField])

  return (
    <>
      <div className="error-mainContainer">
        <div className="date-time">
          <label>{DateUtility.getMountainStdDate()} </label><label>{DateUtility.getMountainStdTime()}</label>
        </div>
        <div className="error-heading">
          <div className="" ><label>AN ERROR HAS OCCURRED IN {programName}. PLEASE CONTACT DATA PROCESSING IMMEDIATELY.</label></div>
          
        </div>
        <div className="error-detail-div">
          <div className="p1-y">
            <label className="error-detail">ERROR DETAILS:</label>
            <div>{logStatusResult}</div>
            <div>{logStatus}</div>
          </div>
          <div className="rootDiv">
            <LabelWidget controlId={"lblErrorFunctionLbl"} label={`FUNCTION\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0:`} />
            <LabelWidget controlId={"lblErrorFunction"} label={getFunction()} />
            {errorStatus && <><LabelWidget controlId={"lblErrorCodeLbl"} label={`ERROR CODE\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0:`} />
              <LabelWidget controlId={"lblErrorCode"} label={errorStatus} /></>}
            <LabelWidget controlId={"lblErrorDescLbl"} label={`ERROR DESCRIPTION : `} />
            <LabelWidget controlId={"lblErrorDesc"} label={errorMessage} />
           
          </div>
        </div>
      </div>
    </>

  );
}

export default ServiceError;
