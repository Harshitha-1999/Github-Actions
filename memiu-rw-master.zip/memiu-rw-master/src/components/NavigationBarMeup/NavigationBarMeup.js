
import React from "react";
import { useHistory } from "react-router-dom";
import { Button, Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import routes from "../../routes/routes";
import { useLocation } from "react-router";
import ButtonLogout from "components/ButtonLogout/ButtonLogout";
import clsx from 'clsx'
export default function NavigationBarMeup() {

  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();

  function changeRoute(path) {
    history.push(path);
  };

  const getRouteButtonJsx = (props) => {
    // only show navigationBar=true
    var resultsRoutes = routes.filter((item) => item.navNames.includes("meup"))
    return (resultsRoutes.map((detail, index) => {
      var buttonlabel = detail.label ? detail.label : detail.path.replace('/', '')
      return <Button onClick={() => changeRoute(detail.path)} className={location.pathname === detail.path ? classes.menuBtnActive : classes.menuBtn} key={index}>
        {buttonlabel}
      </Button>
    }))
  }

  return (
    <Grid container
      className={classes.navigationBar}
    >
      <Grid item xs={10}>
        {getRouteButtonJsx()}
        <ButtonLogout classNameMemi={clsx(classes.menuBtn)} />
      </Grid>
      {/* <Grid item xs={2}>
        <div className="meupdate">
            <p className="date">{date.trim()}</p>
        </div>
        </Grid> */}
    </Grid>
  );
}

const useStyles = makeStyles((theme) => ({
  menuBtn: {

    backgroundColor: "#CFC3AD",
    // boxShadow: "-3px 3px, -2px 2px, -1px 1px",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    border: '1px solid',
    "&:hover": {
      backgroundColor: "#897056",
      color: "#d6ebfb",
    },
    padding: "14px 16px",
    cursor: "pointer",
    textTransform: "none"
    // width: "fit-content"
  },
  navigationBar: {
    backgroundColor: "#CFC3AD",
    display: "flex",
    marginBottom: "10px"

  },
  menuBtnActive: {
    backgroundColor: "#897056",
    border: '1px solid',
    height: "4rem",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    "&:hover": {
      backgroundColor: "#CFC3AD",

    },
    padding: "14px 16px",
    cursor: "pointer",
    textTransform: "none"
    // width: "fit-content" 
  },
  linkItem: {
    textDecoration: "none",
  },
  formcontrol: {
    display: "flex",
    flexDirection: "row"
  },
}));
