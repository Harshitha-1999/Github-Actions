import React, { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { meupServices } from "../../api/meup/meupServices";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ListSelectMeup from "components/ListSelectMeup/ListSelectMeup";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";
import TextFieldMemi from "components/TextField/TextFieldMemi";
import { ApiMemi } from "../../components/ApiCallsMemi/ApiCallsMemi";
import { MEUP_APIs } from "../../service/apiUrls";
import { validateCicUpcStore } from "components/CommonFunctionsMeup/CommonFunctionsMeup";
import { RouteBase } from "routes/constants";

function SearchStoreItems() {
  const history = useHistory();
  const categoryUrl = MEUP_APIs.category;
  const groupUrl = MEUP_APIs.group;
  const [country, setCountry] = useState("us");
  const [state, setState] = useState("");
  const [status, setStatus] = useState("");
  const [selectedDivison, setDivision] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [selectedGroup, setGroup] = useState([]);
  const [groups, setGroups] = useState([]);
  const [category, setCategory] = useState([]);
  const [categories, setCategories] = useState([]);
  const [errCountry, setErrorCountry] = useState(false);
  const [cic, setCic] = useState("");
  const [upc, setUpc] = useState("");
  const [store, setStore] = useState("");
  const [errors, setErrors] = useState([]);
  const [errorCic, setErrorCic] = useState(false);
  const [errorUpc, setErrorUpc] = useState(false);
  const [errorStore, setErrorStore] = useState(false);

  // fetch division options
  useEffect(() => {
    // ApiMemi(divisonUrl,"GET")
    meupServices
      .getDivisions()
      .then((res) => {
        let data = res.data.map((x) => {
          return { label: x.dispDivision, value: x.divisionNumber };
        });
        setDivisions(data);
      })
      .catch((error) => {
        setDivisions([]);
      });
  }, [country]);

  useEffect(() => {
    setGroup([]);
    setGroups([]);
    // fetch group options
    if (selectedDivison.length === 0) {
      setCategories([]);
      setCategory([]);
    } else {
      ApiMemi(groupUrl + `?divisionNumbers=${selectedDivison}&corp=001`, "GET")
        .then((res) => {
          let data = res.data.map((x) => {
            return { label: x.dispGroup, value: x.groupCd };
          });
          setGroups(data);
        })
        .catch((error) => {
          setGroups([]);
        });
    }
  }, [selectedDivison, groupUrl]);

  useEffect(() => {
    // fetch category options
    setCategory([]);
    setCategories([]);
    if (selectedGroup.length === 0) {
      return;
    } else {
      ApiMemi(categoryUrl + `?groupCds=${selectedGroup}&corp=001`, "GET")
        .then((res) => {
          const data = res.data.map((data) => {
            return { label: data.dispCategory.trim(), value: data.categoryCd };
          });
          setCategories(data);
        })
        .catch((error) => {
          setCategories([]);
        });
    }
  }, [selectedGroup, categoryUrl]);

  const handleSubmit = () => {
    let errorList = [];

    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);

    validateCicUpcStore(
      "cic",
      cic,
      7,
      (error) => setErrorCic(error),
      errorList
    );
    validateCicUpcStore(
      "upc",
      upc,
      10,
      (error) => setErrorUpc(error),
      errorList
    );
    validateCicUpcStore(
      "store number",
      store,
      4,
      (error) => setErrorStore(error),
      errorList
    );

    setErrors(errorList);
    window.scrollTo(0, 0);
    /* let payLoad = { 
            "userId": "SMURA16", 
            "countryCd": "001", 
            "divisions": [{ "divisionNumber": "05" }], 
            "groups": [{ "groupCd": "01" }], 
            "categories": [{ "categoryCd": "0001" }], 
            "cic": "1015462", 
            "storeNumber": "1463", 
            " state ": "Allocated", 
            "status": "Blocked", 
            "upc": "001254601144", 
            "deleteDateStart": "1999-12-29", 
            "deleteDateEnd": "2022-01-30", 
            "userDto": { "userId": "SMURA16", "role": "divisionMgr", "division": "05" } 
        } */

    // ApiMemi(getAllItemsUrl,"POST",payLoad)
    meupServices
      .getAllItems(
        "SMURA16",
        country,
        selectedDivison,
        selectedGroup,
        category,
        cic,
        store,
        state,
        status,
        upc
      )
      .then((res) => {
      })
      .catch((reason) => {
      });
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <div
          style={{
            backgroundColor: "#CFC3AD",
            padding: "0.5rem 1rem 0rem 1rem",
            height: "1.5rem",
          }}
        >
          <strong> Enter Items to Block </strong>
        </div>
      </Grid>
      <Grid item xs={12}>
        <ErrorListMeup errors={errors} />
      </Grid>
      <Grid item xs={12}>
        <div
          style={{
            color: "rgb(0, 0, 128)",
            marginTop: "22px",
            fontSize: "medium",
          }}
        >
          <strong>
            {" "}
            Specify the search criteria. In addition to country, at least one
            other parameter should be specified.{" "}
          </strong>
        </div>
      </Grid>

      <Grid
        container
        style={{ border: "1px solid", width: "80rem" }}
        className="blockItemsMarginTop"
      >
        {/* <Button>Save</Button> */}
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label={
              <>
                {" "}
                Select Country <font color="red">*</font>{" "}
              </>
            }
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={["us"]}
            DropDownClass="blockItemsDropDown"
            value={country}
            error={errCountry}
            setValue={(value) => setCountry(value)}
            setError={(error) => setErrorCountry(error)}
            errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Division"
            LabelClass="labelClassStoreItems"
            options={divisions}
            value={selectedDivison}
            setValue={(value) => setDivision(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Group"
            LabelClass="labelClassStoreItems"
            options={groups}
            value={selectedGroup}
            setValue={(value) => setGroup(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Category"
            LabelClass="labelClassStoreItems"
            options={categories}
            value={category}
            setValue={(value) => setCategory(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="CIC"
            value={cic}
            LabelClass="labelClassStoreItems"
            setTextValue={(value) => setCic(value)}
            alignItems="row"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            errorText=""
            error={errorCic}
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="UPC"
            value={upc}
            LabelClass="labelClassStoreItems"
            setTextValue={(value) => setUpc(value)}
            alignItems="row"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            error={errorUpc}
            errorText=""
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="Store #"
            value={store}
            setTextValue={(value) => setStore(value)}
            alignItems="row"
            LabelClass="labelClassStoreItems"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            error={errorStore}
            errorText=""
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label={"State"}
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={["Allocated", "Unallocated"]}
            DropDownClass="blockItemsDropDown"
            value={state}
            // error={errCountry}
            setValue={(value) => setState(value)}
          // setError={(error) => setErrorCountry(error)}
          // errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label="Status"
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={["Blocked", "Unblocked"]}
            DropDownClass="blockItemsDropDown"
            value={status}
            // error={errCountry}
            setValue={(value) => setStatus(value)}
          // setError={(error) => setErrorCountry(error)}
          // errorText="Country is required"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv"></Grid>
      </Grid>

      <Grid
        item
        xs={12}
        className="blockItemsMarginTop"
        style={{ marginBottom: "3rem" }}
      >
        <ButtonMemi
          btnval="View Report"
          btnvariant="contained"
          classNameMemi="blockItemsButtons"
          onClick={handleSubmit}
        />

        <ButtonMemi
          btnval="Reset"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            window.location.reload();
          }}
        />

        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            history.push(RouteBase.MEUP50);
          }}
        />
      </Grid>
    </Grid>
  );
}

export default SearchStoreItems;
