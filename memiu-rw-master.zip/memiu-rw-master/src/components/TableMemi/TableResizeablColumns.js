import React, { useMemo, memo, useState, useEffect } from 'react'
import { TableContainer, Table, TableRow, TableBody, TableHead, TableCell, IconButton } from '@material-ui/core'
import TablePagination from '@mui/material/TablePagination';
import { ArrowDownward, ArrowUpward, FirstPage, LastPage } from '@material-ui/icons';

const SortingHeader = ({ column, props }) => {
    const [direction, setDirection] = useState("down")

    function handleSort() {
        if (direction === "up") {
            setDirection("down");
            const data = stableSort(props.data, getComparator('desc', column.field, column.numeric))
            props.setData(data);
        }
        else {
            setDirection("up")
            const data = stableSort(props.data, getComparator('asc', column.field))
            props.setData(data);
        }
    }
    function descendingComparator(a, b, orderBy) {
        const data_a = column.numeric ? Number(a[orderBy]) : a[orderBy]
        const data_b = column.numeric ? Number(b[orderBy]) : b[orderBy]
        if (data_b < data_a) {
            return -1;
        }
        if (data_b > data_a) {
            return 1;
        }
        return 0;
    }

    function getComparator(order, orderBy) {
        return order === 'desc'
            ? (a, b) => descendingComparator(a, b, orderBy)
            : (a, b) => -descendingComparator(a, b, orderBy);
    }

    // This method is created for cross-browser compatibility, if you don't
    // need to support IE11, you can use Array.prototype.sort() directly
    function stableSort(array, comparator) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = comparator(a[0], b[0]);
            if (order !== 0) {
                return order;
            }
            return a[1] - b[1];
        });
        return stabilizedThis.map((el) => el[0]);
    }

    return (
        <div style={{ display: "flex", alignItems: "center", width: "100%", cursor: "pointer" }} onClick={handleSort}>
            <div className="text">{column.headerName}</div>
            <div className="icon">
                {direction === "down" ?
                    <ArrowDownward
                        style={{ fontSize: "0.95rem", cursor: "pointer" }}
                        className="arrowntableHoldItem"
                    /> :
                    <ArrowUpward
                        style={{ fontSize: "0.95rem", cursor: "pointer" }}
                    />}

            </div>
        </div>
    )

}

const Row = memo((props) => {
    const { row, id, index } = props;
    const [open, setOpen] = useState(false);
    const [selected, setSelected] = useState(false);
    const disabled = props.setSelectionCriteria ? !props.setSelectionCriteria(row) : false

    useEffect(() => {
        setSelected(false);
    }, [row])

    const handleSelect = () => {
        if (!disabled) {
            setSelected((selected) => !selected);
            if (props.selectedRows && typeof (props.selectedRows) === "object") {
                if (selected) {
                    props.setSelectedRows(props.selectedRows.filter((x) => x.id !== row.id))
                }
                else {
                    props.setSelectedRows([...props.selectedRows, row])
                }
            }
        }
    }
    return (
        <TableRow sx={{ '& > *': { borderBottom: 'unset', fontSize: "12px" } }}>
            {props.columns.map((column, index) => (
                column.field === " " ?
                    <TableCell align="center" style={{ borderRight: "1px solid #ddd", resize:"none !important" }} >
                        <input
                            type="checkbox"
                            checked={selected}
                            onClick={handleSelect}
                            disabled={disabled}
                            style={{ cursor: disabled ? "not-allowed" : "pointer" }}
                        />
                    </TableCell> :
                    <TableCell
                        key={index}
                        style={{ textAlign: "left", cursor: "pointer", borderRight: "1px solid #ddd", overflow: "hidden", wordWrap: "pre" }}
                        title={row[column.field]}
                    >
                        {column.renderCell ? column.renderCell({ row: row, value: row[column.field] }) : row[column.field]}
                    </TableCell>
            ))}
        </TableRow >
    );
})



function TableResizeablColumns(props) {
    const [rowsPerPage, setRowsPerPage] = useState(15);
    const { data, columns, selectedRows } = props;
    const [page, setPage] = useState(0)

    const Columns = useMemo(() => {
        return columns.map((column, index) => {

            return (
                <TableCell align="left" key={index} className={column.headerCss} colSpan={column.colSpan} style={{ color: column.product, whiteSpace: "pre", minWidth: "1rem" }} >
                    {column.sortable ? <SortingHeader props={props} column={column} /> : column.headerName}
                    <div className="tableResizeableSlider">{" "}</div>
                </TableCell>
            )
        })
    }, [columns])

    const RowData = useMemo(() => {
        return data.slice((page) * rowsPerPage, (page) * rowsPerPage + rowsPerPage ).map((row, index) => (
            <Row columns={columns} key={row.name} row={row} index={index} {...props} />
        ))
    }, [data, page, selectedRows, rowsPerPage, columns])

    useEffect(() => {
        props.setSelectedRows([])
    }, [page])

    useEffect(() => {
        setPage(0);
    },[data])

    return (
        <>
            <TableContainer className={props.containerClass} style={{ overflow: "auto" }}>
                <Table className={props.classNameMemi} size={props.size} stickyHeader={props.stickyHeader} style={{ tableLayout: "fixed",minWidth:"max-content" }}>
                    <TableHead>
                        <TableRow>
                            {Columns}
                        </TableRow>
                    </TableHead>
                    <TableBody id={`databody-${props.id}}`}>
                        {RowData}
                    </TableBody>
                </Table>
            </TableContainer>
            <div style={{ display: "flex", paddingTop: "0.5rem", alignItems: "center" }}>

                <TablePagination
                    rowsPerPageOptions={[15, 25, 100]}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    showLastButton
                    showFirstButton
                    onRowsPerPageChange={(e) => setRowsPerPage(e.target.value)}
                    count={data.length}
                    variant="outlined"
                    shape="rounded"
                    onPageChange={(e, page) => setPage(Number(page))}
                    style={{ display: props.disablePagination ? "none" : "block", marginLeft: "auto" }}
                />

            </div>
        </>

    )
}

export default memo(TableResizeablColumns)
