import React, { useState, useCallback, useEffect, memo, useMemo } from 'react'
import { Table, TableBody, TableRow, TableContainer, TableHead, TableCell, Collapse } from '@material-ui/core'
import { KeyboardArrowDown, KeyboardArrowUp, ArrowDownward, ArrowUpward, PhoneDisabledRounded } from '@material-ui/icons'


const SortingHeader = ({ column, props, setData }) => {
    const [direction, setDirection] = useState("down")

    function handleSort() {
        if (direction === "up") {
            setDirection("down");
            const data = stableSort(props.data, getComparator('desc', column.field, column.numeric))
            setData(data);
        }
        else {
            setDirection("up")
            const data = stableSort(props.data, getComparator('asc', column.field))
            setData(data);
        }
    }
    function descendingComparator(a, b, orderBy) {
        const data_a = column.numeric ? Number(a[orderBy]) : a[orderBy]
        const data_b = column.numeric ? Number(b[orderBy]) : b[orderBy]
        if (data_b < data_a) {
            return -1;
        }
        if (data_b > data_a) {
            return 1;
        }
        return 0;
    }

    function getComparator(order, orderBy) {
        return order === 'desc'
            ? (a, b) => descendingComparator(a, b, orderBy)
            : (a, b) => -descendingComparator(a, b, orderBy);
    }

    // This method is created for cross-browser compatibility, if you don't
    // need to support IE11, you can use Array.prototype.sort() directly
    function stableSort(array, comparator) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = comparator(a[0], b[0]);
            if (order !== 0) {
                return order;
            }
            return a[1] - b[1];
        });
        return stabilizedThis.map((el) => el[0]);
    }

    return (
        <div style={{ display: "flex", alignItems: "center", width: "100%", cursor: "pointer" }} onClick={handleSort}>
            <div className="text">{column.headerName}</div>
            <div className="icon">
                {direction === "down" ?
                    <ArrowDownward
                        style={{ fontSize: "0.95rem", cursor: "pointer" }}
                        className="arrowntableHoldItem"
                    /> :
                    <ArrowUpward
                        style={{ fontSize: "0.95rem", cursor: "pointer" }}
                    />}

            </div>
        </div>
    )

}

const Row = memo((props) => {
    const { row, selectedRows, disableSelection, ColumnsForDisplay, index } = props;

    const [open, setOpen] = useState(false);
    const [selected, setSelected] = useState(false);
    const disabled = props.setSelectionCriteria ? !props.setSelectionCriteria(row) : false
    const disabledCollapsible = props.disableCollapsible ? props.disableCollapsible(row) : true
    useEffect(() => {
        if (disableSelection) { return }
        let isSelected = false
        selectedRows.forEach((selectedRow) => {
            console.log(row.id, selectedRow.id)

            if (selectedRow.id === row.id) {
                isSelected = true;
                return
            }
        })
        setSelected(isSelected);

    }, [row.id, selectedRows, disableSelection])

    const handleSelect = () => {
        if (!disabled) {
            if (props.selectedRows && typeof (props.selectedRows) === "object") {
                if (selected) {
                    props.setSelectedRows(props.selectedRows.filter((x) => x.id !== row.id))
                }
                else {
                    props.setSelectedRows([...props.selectedRows, row])
                }
            }
        }
    }
    return (
        <React.Fragment>
            <TableRow sx={{ '& > *': { fontSize: "14px" } }} style={{ border: "1px solid rgba(224, 224, 224, 1)", height: "1.5rem" }}>

                {
                    props.disableSelection ? "" : <TableCell align="left">
                        <input type="checkbox" checked={selected} onClick={handleSelect} disabled={disabled} style={{ cursor: disabled ? "not-allowed" : "pointer" }} />
                    </TableCell>

                }

                {props.columns.map((column, index) => (
                    <TableCell key={index} style={{ textAlign: column.textAlign ? column.textAlign : "left", cursor: "pointer", fontFamily: "calibri", fontSize: "12px" }}>
                        {column.renderCell ? column.renderCell({ row: row, value: row[column.field] }) : row[column.field]}</TableCell>
                ))}
                <TableCell align="left">
                    <div className="displayerCollapsibleArrow" style={{ display: disabledCollapsible ? "none" : "flex" }}>
                        {open ? <KeyboardArrowUp onClick={() => setOpen(!open)} style={{ transform: "scale(0.8)", }} /> : <KeyboardArrowDown onClick={() => setOpen(!open)} style={{ transform: "scale(0.8)" }} />}
                    </div>
                </TableCell>
            </TableRow>
            {
                !disabledCollapsible ?
                    <>
                        <TableRow></TableRow>
                        <TableRow>
                            <TableCell style={{ paddingBottom: 0, paddingTop: 0, borderBottom: "none",width:"99.9%" }} colspan={ColumnsForDisplay.length} style={{ display: open ? "table-cell" : "none" }}>
                                {props.collapsibleTabelContent ? props.collapsibleTabelContent(row, props.columns, index) : ""}
                            </TableCell>
                        </TableRow>

                    </>
                    : ""

            }

        </React.Fragment>
    );
})

function TableDisplayerCollapsible(props) {
    const {  columns, selectedRows } = props;

    const [data, setData] = useState([])

    useEffect(() => {
        setData(props.data)
    },[props.data])

    const Columns = useMemo(() => {
        const columnsToShow = columns.map((column, index) => (
            <TableCell align="left" key={index} className={column.headerCss} colSpan={column.colSpan} style={{ borderBottom: "none" }} width={column.width}>
                {column.sortable ? <SortingHeader props={props} column={column} setData={setData} /> : column.headerName}
            </TableCell>
        ))
        if (!props.disableSelection) {
            columnsToShow.unshift(<TableCell align="left" colSpan="1"></TableCell>)
        }

        columnsToShow.push(<TableCell align="left"></TableCell>)
        return columnsToShow

    }, [columns])

    const RowData = useMemo(() => {
        return data ? data.map((row, index) => (
            <Row columns={columns} key={row.name} row={row} index={index} {...props} disableSelection={props.disableSelection} disableCollapsible={props.disableCollapsible} ColumnsForDisplay={Columns} />
        )) : []
    }, [data, selectedRows, Columns])

    return (
        <>
            <TableContainer className={props.containerClass}>
                <Table className={props.classNameMemi} size={props.size} stickyHeader={props.stickyHeader}>
                    <TableHead>
                        <TableRow>
                            {Columns}
                        </TableRow>
                    </TableHead>
                    <TableBody id={`databody-${props.id}}`} style={{ backgroundColor: "white" }}>
                        {props.data && props.data.length > 0 ? RowData :
                            <TableRow>
                                <TableCell colSpan={props.columns.length + 2} style={{ borderBottom: "none", backgroundColor: "white" }}>
                                    <div className="TableMappingAlertLable" style={{ textAlign: "center", width: "100%" }}>
                                        {props.NoRowsOverlay ? props.NoRowsOverlay : ``}
                                    </div>
                                </TableCell>
                            </TableRow>
                        }
                    </TableBody>
                </Table>
            </TableContainer>
        </>
    )
}

export default memo(TableDisplayerCollapsible)