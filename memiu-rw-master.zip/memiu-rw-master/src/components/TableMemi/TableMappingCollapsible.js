import React, { useState, useCallback, useEffect, memo, useMemo, useLayoutEffect } from 'react'
import { Table, TableBody, TableRow, TableContainer, TableHead, TableCell, Collapse } from '@material-ui/core'
import { KeyboardArrowDown, KeyboardArrowUp, ArrowDownward, ArrowUpward } from '@material-ui/icons'
import ClickAwayListener from 'material-ui/internal/ClickAwayListener';
import Pagination from '@mui/material/Pagination';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';

const SortingHeader = ({ column, props }) => {
    const [direction, setDirection] = useState("down")

    function handleSort() {
        if (direction === "up") {
            setDirection("down");
            const data = stableSort(props.data, getComparator('desc', column.field, column.numeric))
            props.setData(data);
        }
        else {
            setDirection("up")
            const data = stableSort(props.data, getComparator('asc', column.field))
            props.setData(data);
        }
    }
    function descendingComparator(a, b, orderBy) {
        const data_a = column.numeric ? Number(a[orderBy]) : a[orderBy]
        const data_b = column.numeric ? Number(b[orderBy]) : b[orderBy]
        if (data_b < data_a) {
            return -1;
        }
        if (data_b > data_a) {
            return 1;
        }
        return 0;
    }

    function getComparator(order, orderBy) {
        return order === 'desc'
            ? (a, b) => descendingComparator(a, b, orderBy)
            : (a, b) => -descendingComparator(a, b, orderBy);
    }

    // This method is created for cross-browser compatibility, if you don't
    // need to support IE11, you can use Array.prototype.sort() directly
    function stableSort(array, comparator) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = comparator(a[0], b[0]);
            if (order !== 0) {
                return order;
            }
            return a[1] - b[1];
        });
        return stabilizedThis.map((el) => el[0]);
    }

    return (
        <div style={{ display: "flex", alignItems: "center", width: "100%", cursor: "pointer",justifyContent:"center" }} onClick={handleSort}>
            <div className="text">{column.headerName}</div>
            <div className="icon">
                {direction === "down" ?
                    <ArrowDownward
                        style={{ fontSize: "0.95rem", cursor: "pointer" }}
                        className="arrowntableHoldItem"
                    /> :
                    <ArrowUpward
                        style={{ fontSize: "0.95rem", cursor: "pointer" }}
                    />}

            </div>
        </div>
    )

}

const Row = memo((props) => {
    const { row, selectedRows } = props;
    
    const [open, setOpen] = useState(false);
    const [selected, setSelected] = useState(false);
    const disabled = props.setSelectionCriteria ? !props.setSelectionCriteria(row) : false

    useEffect(() => {
        let isSelected = false
        selectedRows.forEach((selectedRow) => {
            if(selectedRow.id === row.id) {
               isSelected = true;
                return
            }
        })
        setSelected(isSelected);

    }, [row.id, selectedRows])

    const handleSelect = () => {
        if (!disabled) {
            if (props.selectedRows && typeof (props.selectedRows) === "object") {
                if (selected) {
                    props.setSelectedRows(props.selectedRows.filter((x) => x.id !== row.id))
                }
                else {
                    props.setSelectedRows([...props.selectedRows, row])
                }
            }
        }
    }
    return (
        <React.Fragment>
            <TableRow sx={{ '& > *': {fontSize: "12px" } }} selected={selected} style={{border:"1px solid rgba(224, 224, 224, 1)"}}>
                <TableCell align="left">
                    <div style={{ display: "flex", alignItems: "center" }}>
                        <div className={`${row.mappingStatus} icons`} style={{width:"18px", height:"18px", justifyContent:"center",alignItems:"center", marginTop:"10px"}}>
                            {open ? <KeyboardArrowUp onClick={() => setOpen(!open)} style={{ transform: "scale(0.8)",color: "white" }} /> : <KeyboardArrowDown onClick={() => setOpen(!open)} style={{ transform: "scale(0.8)", color: "white" }} />}
                        </div>
                        <input type="checkbox" checked={selected} onClick={handleSelect} disabled={disabled} style={{ cursor: disabled ? "not-allowed" : "pointer" }} />
                    </div>
                </TableCell>
                {props.columns.map((column, index) => (
                    <TableCell key={index} style={{ textAlign: column.textAlign ? column.textAlign : "left", cursor: "pointer",fontFamily:"calibri",fontSize:"12px" }} title={row[column.field]} onClick={() => handleSelect()}>
                        {column.renderCell ? column.renderCell({ row: row, value: row[column.field] }) : row[column.field]}</TableCell>
                ))}
            </TableRow>
            <TableRow >
                <TableCell style={{ paddingBottom: 0, paddingTop: 0,borderBottom:"none" }} colspan={props.columns.length + 1} >
                    <Collapse in={open} timeout="auto" unmountOnExit>
                        {props.collapsibleTabelContent ? props.collapsibleTabelContent(row, props.columns) : ""}
                    </Collapse>
                </TableCell>
            </TableRow>
        </React.Fragment>
    );
})


function TableMappingCollapsible(props) {
    const { data, columns, selectedRows } = props;
    const [page, setPage] = useState(1)
    const [anchorPoint, setAnchorPoint] = useState({ x: 0, y: 0 })
    const [show, setShow] = useState(false);
    const handleClick = () => (show ? setShow(false) : null);

    useEffect(() => {
        setPage(1)
    },[data])
    const Columns = useMemo(() => {
        return columns.map((column, index) => (
            <TableCell align="center" key={index} className={column.headerCss} colSpan={column.colSpan} style={{borderBottom:"none"}}>
                {column.sortable ? <SortingHeader props={props} column={column} /> : column.headerName}
            </TableCell>
        ))
    }, [columns])

    const RowData = useMemo(() => {
        return data ? data.slice((page - 1) * 200, (page - 1) * 200 + 199).map((row, index) => (
            <Row columns={columns} key={row.name} row={row} index={index} {...props} />
        )) : []
    }, [data, page, selectedRows])

    useEffect(() => {
        document.getElementById(`databody-${props.id}}`).addEventListener("contextmenu", handleContextMenu);
        return () => {
            document.getElementById(`databody-${props.id}}`).removeEventListener("contextmenu", handleContextMenu);
        }
    }, []);

    const handleContextMenu = useCallback(
        (event) => {
            event.preventDefault();
            setAnchorPoint({ x: event.pageX, y: event.pageY - 30 });
            setShow(true);

        },
        [setAnchorPoint, setShow]
    );

    const handleMenuClick = (menu) => {
        if (typeof (menu.onClick) === "function") {
            menu.onClick();
        }
        handleClick()
    }


    return (
        <>
            <TableContainer className={props.containerClass}>
                <Table className={props.classNameMemi} size={props.size} stickyHeader={props.stickyHeader}>
                    <TableHead>
                        <TableRow>
                            {Columns}
                        </TableRow>
                    </TableHead>
                    <TableBody id={`databody-${props.id}}`} style={{backgroundColor:"white"}}>
                        {
                            show ?
                                <ClickAwayListener onClickAway={handleClick}>
                                    <ul
                                        className="menu"
                                        style={{
                                            top: anchorPoint.y,
                                            left: anchorPoint.x
                                        }}
                                    >
                                        {props.contextOptions.map((option, index) => (
                                            <li key={index} onClick={() => handleMenuClick(option)}>
                                                {option.label}
                                            </li>
                                        ))}
                                    </ul>
                                </ClickAwayListener> : ""
                        }
                        {props.data && props.data.length > 0 ? RowData :
                            <TableRow>
                                <TableCell colSpan={props.columns.length} style={{borderBottom:"none"}}>
                                    <div className="TableMappingAlertLable">
                                        {props.NoRowsOverlay ? props.NoRowsOverlay : `No Result Found`}
                                    </div>
                                </TableCell>
                            </TableRow>
                        }
                    </TableBody>
                </Table>
            </TableContainer>
            <div style={{ display: "flex", paddingTop: "0.5rem", width: "100%" }}>
                <ButtonMemi
                    btnval="Load More.."
                    classNameMemi={`tableLoadMoreButton ${props.disableLoadMore ? "disabledTableLoadMoreButton" : ""}`}
                    onClick={props.onLoadMore}
                    btnsize="small"
                />
                <Pagination
                    count={props.data ? Math.ceil(props.data.length / 200) : 0}
                    variant="outlined"
                    shape="rounded"
                    showFirstButton
                    showLastButton
                    onChange={(e, page) => setPage(Number(page))}
                    style={{ marginLeft: "auto", display: props.disablePagination ? "none" : "block" }}
                />
            </div>
            <div style={{ padding: "10px" }} style={{ display: props.placeholder ? "flex" : "none", alignItems: "center", width: "100%", color: "grey" }}>
                <span className="mutCountTxt"> {props.placeholder} </span>
                <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", width: "9rem" }}>
                    <span style={{ backgroundColor: "#ca6b09", width: "15px", height: "15px", color: "grey" }}></span>-WHSE
                </div>
                <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", width: "9rem" }}>
                    <span style={{ backgroundColor: "#05ab21", width: "15px", height: "15px" }}></span>-DSD
                </div>
                <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", width: "9rem" }}>
                    <span style={{ backgroundColor: "#04a6d6", width: "15px", height: "15px" }}></span>-WHSEDSD
                </div>

            </div>
        </>
    )
}

export default memo(TableMappingCollapsible)
