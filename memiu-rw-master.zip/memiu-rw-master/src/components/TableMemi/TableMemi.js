import React, { useContext } from "react";
import { withStyles } from "@material-ui/core/styles";
import { DataGrid } from "@mui/x-data-grid";
import Radio from "@material-ui/core/Radio";
import PropTypes from "prop-types";
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import Checkbox from '@mui/material/Checkbox';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import AlertBoxMemi from "components/AlertBoxMemi/AlertBoxMemi";
import { Grid } from "@material-ui/core";
// import ApplicationContext from "../../context/ApplicationContext";
import TablePopperMemi from "components/TablePopperMemi/TablePopperMemi";
import ApplicationContext from "context/ApplicationContext";


function TableMemi(props) {

  const AppData = useContext(ApplicationContext);
  const [selectedId, setSelectedId] = React.useState();
  let rowData = [];

  const changememi = (id) => {
    setSelectedId(id);
  };

  let columns;
  switch (props.classnameMemi) {
    case "tableDisplayer":
      columns = [];
      if (props.data.length > 0) {
        if (props.customcolumns) {
          if (props.customcolumns[0].hide === true) {
            Reflect.ownKeys(props.data[0]).forEach((data) => {
              columns.push({ field: data, headerName: data, width: 150 });
            });

            columns[0].width = "400";
            columns[4].width = "200";
            columns[8].width = "200";
          }
        }
      }
      break;
    case "tableDisplayerCont":
      columns = [];
      if (props.data.length > 0) {
        if (props.data[0].Pack) {
          if (props.customcolumns) {
            if (props.customcolumns[0].hide === true) {
              Reflect.ownKeys(props.data[0]).forEach((data) => {
                columns.push({ field: data, headerName: data, width: 150 });
              });

              columns[0].width = "400";
              columns[4].width = "200";
              columns[8].width = "200";
            }
          }
        } else {
          if (props.customcolumns) {
            if (props.customcolumns[0].hide === true) {
              Reflect.ownKeys(props.data[0]).forEach((data) => {
                columns.push({ field: data, headerName: data, width: 150 });
              });

            }
          }
        }
      }
      break;
    case "another case":
      //code block
      break;
    default:
      if (props.selectionType === "radio") {
        columns = [
          {
            field: " ",
            headerName: " ",
            width: 20,
            hide: props.selectionType === "checkbox" ? true : false,

            renderCell: (params) => (
              <div style={{ display: "flex", alignItems: "center" }}>
                <Radio
                  name="radio-buttons"
                  checked={selectedId === params.row.id}
                  onChange={() => changememi(params.row.id)}
                />
              </div>
            ),
          },
        ];
        if (props.data.length > 0) {
          Reflect.ownKeys(props.data[0]).forEach((data) => {
            columns.push({ field: data, headerName: data, width: 150 });
          });
        }
      } else {
        columns = [];
        if (props.data.length > 0) {
          if (props.customcolumns) {
            if (props.customcolumns[0].hide === true) {
              if (props.classnameMemi === "tableDisplayer") {
                // Reflect.ownKeys(props.data[0]).forEach((data) => {
                //   columns.push({ field: data, headerName: data, width: 150 });
                // });
                // const firstElement = columns.shift();
                // columns[0].width = "400";
              } else {
                Reflect.ownKeys(props.data[0]).forEach((data) => {
                  columns.push({ field: data, headerName: data, width: 150 });
                });

                columns[0].width = "400";
              }
            }
          } else {
            Reflect.ownKeys(props.data[0]).forEach((data) => {
              columns.push({ field: data, headerName: data, width: 150 });
            });
          }
        }
      }
  }

  if (props.tableType === "collapse")
    return (<div className={props.classnameMemi} style={{ height: "inherit" }}><TableMemiCollapse {...props} /></div>);
  else
    return (
      <div className={props.classnameMemi} style={{ height: "inherit" }}>
        <StyledDataGrid
          rows={props.data}
          rowHeight={props.rowheight}
          columns={props.columns ? props.columns : columns}
          autoPageSize={props.autoPageSize}
          autoHeight={props.autoHeight}
          checkboxSelection={props.selectionType === "checkbox" ? true : false}
          {...props}
          onPageChange={props.onPageChange}
          page={props.page}
          selectionModel={props.selectedRows}
          onSelectionModelChange={props.setSelectionModel}
          disableSelectionOnClick
          hideFooter={props.hideFooter}
          hideFooterPagination={props.hideFooter}
          hideFooterSelectedRowCount={props.hideFooter}
          showCellRightBorder={props.showCellRightBorder}
          showColumnRightBorder={props.showColumnRightBorder}
          isRowSelectable={props.selectionCriteria ? (params) => props.selectionCriteria(params) : (params) => { return true }}
          density={props.density}
          rowCount={props.rowCount}
          components={{
            NoRowsOverlay: props.NoRowsOverlay,
          }}
          disableDensitySelector={props.disableDensitySelector}
          disableColumnFilter={props.disableColumnFilter}
          rowCount={props.rowCount}
          rowsPerPageOptions={props.rowsPerPageOptions}
          onPageSizeChange={props.onPageSizeChange}
          onRowClick={props.onRowClick ? props.onRowClick : () => {}}
        />
      </div>

    )
}

TableMemi.propTypes = {
  hideFooter: PropTypes.bool,
  hideFooterPagination: PropTypes.bool,
  hideFooterSelectedRowCount: PropTypes.bool,
  showCellRightBorder: PropTypes.bool,
  showColumnRightBorder: PropTypes.bool,
  selectionCriteria: PropTypes.func,
  selectionType: PropTypes.string,
  autoHeight: PropTypes.bool,
  columns: PropTypes.array,
  data: PropTypes.array,
  rowheight: PropTypes.number,
  density: PropTypes.string,
  rowCount: PropTypes.number
};

export default TableMemi;

const StyledDataGrid = withStyles({
  root: {
    "& .MuiDataGrid-renderingZone": {
      maxHeight: "none !important",
    },
    "& .MuiDataGrid-cell": {
      lineHeight: "unset !important",
      maxHeight: "none !important",
      whiteSpace: "normal",
      wordWrap: "break-word",
      alignItems: "center",
    },

    "& .MuiDataGrid-row": {
      "&:hover": {
        backgroundColor: "inherit",
      },
    },
  },
  virtualScrollerContent: {
    height: "100% !important",
    overflow: "scroll",
  },
})(DataGrid);

//............................. collapsing table ..............................................


function Row(props) {
  const AppData = useContext(ApplicationContext);
  const { row } = props;
  const [open, setOpen] = React.useState(false);
  const label = { inputProps: { 'aria-label': 'Checkbox demo' } }

  const clickBadge = () => {
    // let columnData = data.map((x) => {return {[`${column}`]: x}});
    let columnData = [{ "UPC List": "1" }]
    AppData.setTableModal(true, ["UPC List"], columnData)
    // AppData.setTableModal(true, [column], columnData)

  }
  return (
    <React.Fragment>
      <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
        <TableCell className="tableRow">
          <IconButton
            aria-label="expand row"
            size="small"
            className="collapseIcon"
            onClick={() => setOpen(!open)}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell className="tableRow">
          <Checkbox className="tableCheckbox" {...label} />
        </TableCell>
        {/* <TableCell component="th" scope="row" className="tableRow">
          {row.name}
        </TableCell>
        <TableCell align="right" className="tableRow">{row.calories}</TableCell>
        <TableCell align="right" className="tableRow">{row.fat}</TableCell>
        <TableCell align="right" className="tableRow">{row.carbs}</TableCell>
        <TableCell align="right" className="tableRow">{row.protein}</TableCell>
        <TableCell align="right" className="tableRow">{row.protein}</TableCell> */}

        {props.columns.map((column, index) => (
          <TableCell key={index} style={{ textAlign: "left" }} className="tableRow" >
            {column.renderCell ? column.renderCell({ row: row, value: row[column.field] }) : row[column.field]}</TableCell>
        ))}
        <TableCell className="tableRow">
          <TablePopperMemi badge={"1"} columns={["UPC List"]} data={[{ "UPC List": "123-123" }]} />
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              {/* <div style = {{display:"flex", columnGap:"10%", width: "100%"}}>
                <div>
                  <div>Size Number</div>
                  <div>0.01</div>
                </div>
                <div>
                  <div>Size Number</div>
                  <div>0.01</div>
                </div>
                <div>
                  <div>Size Number</div>
                  <div>0.01</div>
                </div>
                <div>
                  <div>Size Number</div>
                  <div>0.01</div>
                </div>
                <div>
                  <div>Size Number</div>
                  <div>0.01</div>
                </div>
              </div> */}
              {/* <Table size="small" aria-label="purchases">
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Customer</TableCell>
                    <TableCell align="right">Amount</TableCell>
                    <TableCell align="right">Total price ($)</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {row.history.map((historyRow) => (
                    <TableRow key={historyRow.date}>
                      <TableCell component="th" scope="row">
                        {historyRow.date}
                      </TableCell>
                      <TableCell>{historyRow.customerId}</TableCell>
                      <TableCell align="right">{historyRow.amount}</TableCell>
                      <TableCell align="right">
                        {Math.round(historyRow.amount * row.price * 100) / 100}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table> */}
              <Grid container className="innerGrid">
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerHead">Heading 4</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 1</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 2</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 3</Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid className="innerData">Value 4</Grid>
                </Grid>
              </Grid>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

Row.propTypes = {
  row: PropTypes.shape({
    calories: PropTypes.number.isRequired,
    carbs: PropTypes.number.isRequired,
    fat: PropTypes.number.isRequired,
    history: PropTypes.arrayOf(
      PropTypes.shape({
        amount: PropTypes.number.isRequired,
        customerId: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
      }),
    ).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    protein: PropTypes.number.isRequired,
  }).isRequired,
};



function TableMemiCollapse(props) {
  return (
    <TableContainer component={Paper}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow>
            <TableCell />
            {/* <TableCell>Status</TableCell> */}
            {props.columns && props.columns.map((column) => (
              <TableCell align="right" key={column.field}>{column.headerName}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {props.data.map((row) => (
            <Row columns={props.columns} key={row.name} row={row} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}