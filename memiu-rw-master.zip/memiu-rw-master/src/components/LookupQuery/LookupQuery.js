
import React, { useState, useContext, useEffect } from "react";
import { Grid } from "@material-ui/core";
import { Autorenew, Check, Close } from "@material-ui/icons";
import DropDownMemi from '../DropDownMemi/DropDownMemi';
import SortByMemi from "components/SortByMemi/SortByMemi";
import TextFieldMemi from '../TextField/TextFieldMemi';
import ButtonMemi from '../ButtonMemi/ButtonMemi'
import ApplicationContext from "context/ApplicationContext";
import { memiuServices } from "api/memiu/memiuService";
import LookUpTable from "components/LookUpTable/LookUpTable";
import lookupData from './lookup-properties.json';
import { authTokenCookie } from "utils";
function LookupQuery(props) {
  const AppData = useContext(ApplicationContext)
  const {companyId, divisionId} = AppData

  const { userId } = authTokenCookie();

  const [productSku, setProductSku] = useState("")
  const [department, setDepartment] = useState("");
  const [itemSets, setItemSets] = useState("");
  const [itemDescription, setItemDescription] = useState("");
  const [upc, setUpc] = useState("");
  const [supplierName, setSupplierName] = useState("");
  const [supplierNumber, setSupplierNumber] = useState("");
  const [plu, setPlu] = useState("");
  const [conversionStatus, setConversionStatus] = useState("");
  const [corpItemCode, setCorpItemCode] = useState("");
  const [supplyType, setSupplyType] = useState("")
  const [productHierarchyName, setProductHierarchyName] = useState("");
  const [hierachyLevel1, setHierachyLevel1] = useState("")
  const [hierachyLevel2, setHierachyLevel2] = useState("")
  const [hierachyLevel3, setHierachyLevel3] = useState("")
  const [hierachyLevel4, setHierachyLevel4] = useState("")
  const [hierachyLevel5, setHierachyLevel5] = useState("")
  const [order, setOrder] = useState(null);
  const [sortList, setSortList] = useState(null);
  const [disableLoadMore, setDisableLoadMore] = useState(false);
  const [errorDepartment, setErrorDepartment] = useState(false);
  const [errorConversionStatus, setErrorConversionStatus] = useState(false);
  const [errorHierachyLevel4, setErrorHierachyLevel4] = useState(false);
  const [payload, setPayload] = useState({});

  const [active, setActive] = useState(false);
  const [sortableList, setSortableList] = useState([
    { label: "Conv GroupCode", value: "LKPCONGP", selected: false, id: 0 },
    { label: "Hierarchy 1", value: "LKPHIER1", selected: false, id: 1 },
    { label: "Hierarchy 2", value: "LKPHIER2", selected: false, id: 2 },
    { label: "Hierarchy 3", value: "LKPHIER3", selected: false, id: 3 },
    { label: "Supplier No", value: "LKPSUPNO", selected: false, id: 4 },
    { label: "Supplier Name", value: "LKPSUPNM", selected: false, id: 5 },
    { label: "Item Description", value: "LKPITMDS", selected: false, id: 6 }
  ])


  const supplyTypeOptions = [
    { label: "DSD", value: "D" },
    { label: "WHSE", value: "W" },
    { label: "Plant", value: "P" }
  ]

  useEffect(() => {
    if (divisionId === "" || companyId === "") { return }
    memiuServices.getLookUpScreen(companyId, divisionId, userId.toLowerCase())
      .then((res) => {
        
        const departmentOptions = res.data.departmentList.map((data) => {
          return { label: data.convGrpName, value: `${data.convGrpCode}-${data.convGrpName}` }
        })

        const itemSetsOptions = res.data.itemSets.map((data) => {
          return { label: data.itemTypeName, value: data.itemTypeCode }
        })

        const convStatusOptions = res.data.conversionStatus.map((data) => {
          return { label: data.convStatName, value: data.convStatCode }
        })

        const customVO = res.data.customVO !== null ? res.data.customVO : lookupData[0].customVO

        AppData.setLookUpScreen({ ...res.data, departmentList: departmentOptions, itemSets: itemSetsOptions, conversionStatus: convStatusOptions, customVO:customVO })
      })
      .catch((error) => {
        console.log(error)
      })
  }, [companyId, divisionId])

  const handleCancel = () => {
    setProductSku("")
    setDepartment("");
    setItemSets("");
    setItemDescription("");
    setUpc("");
    setSupplierName("");
    setSupplierNumber("");
    setPlu("");
    setConversionStatus("");
    setCorpItemCode("");
    setSupplyType("")
    setProductHierarchyName("");
    setHierachyLevel1("")
    setHierachyLevel2("")
    setHierachyLevel3("")
    setHierachyLevel4("")
    setHierachyLevel5("")
  }


  const handleReset = () => {
    handleCancel();
    setActive(false);
  }

  const handleSelectDepartment = (value) => {
    setDepartment(value)
    setHierachyLevel4(value.split("-")[0])
  }


  const handleApply = (sortList = null, order = null, type = "apply", startIndex = 1, endIndex = 500) => {
    setOrder(null);
    setSortList(null);
    memiuServices.postLookUpLoadSearch({
      productSku,
      department: department.split("-")[0],
      itemSets,
      itemDescription,
      upc,
      supplierName,
      supplierNumber,
      plu,
      conversionStatus,
      corpItemCode,
      supplyType,
      productHierarchyName,
      hierachyLevel1,
      hierachyLevel2,
      hierachyLevel3,
      hierachyLevel4,
      hierachyLevel5,
      setErrorConversionStatus,
      setErrorDepartment,
      setErrorHierachyLevel4,
      startIndex,
      endIndex,
      AppData,
      sortOrder: order,
      sortItems: sortList,
      setPayload
    }).then((res) => {

      let data = res.data;
      if (data.count < 500) {
        setDisableLoadMore(true)
      }
      else {
        setDisableLoadMore(false)
      }

      if (type === "loadMore") {
        data.serchResults = data.serchResults.map((x, index) => {
          return { id: startIndex + index, ...x }
        })
        AppData.setMemi06({ ...data, serchResults: [...AppData.memi06.serchResults, ...data.serchResults], ...AppData.lookUpScreen })
      }
      else {
        data.serchResults = data.serchResults.map((x, index) => {
          return { id: index, ...x }
        })
        AppData.setMemi06({ ...data, ...AppData.lookUpScreen });
      }


      if (res) {
        setActive(true)
      }
    })
      .catch((error) => {
      })
  }

  return (
    <>
      <Grid container spacing={0} className={props.direction === "up" ? "lookUpMenu" : "lookUpMenu clearFix collapse"}>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={productSku}
            setTextValue={(value) => setProductSku(value)}
            label="Product SKU"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
          // type="number"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <DropDownMemi
            value={department}
            setValue={handleSelectDepartment}
            label="Department *"
            alignItems="columns"
            DropDownClass="lookUpMenuDropdown"
            LabelClass="lookUpMenuLabelClass"
            options={AppData.lookUpScreen.departmentList}
            fullWidth={true}
            error={errorDepartment}
            errorText=""
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={upc}
            setTextValue={(value) => setUpc(value)}
            label="UPC"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <DropDownMemi
            value={itemSets}
            setValue={(value) => setItemSets(value)}
            label="Item Sets"
            alignItems="columns"
            DropDownClass="lookUpMenuDropdown"
            LabelClass="lookUpMenuLabelClass"
            options={AppData.lookUpScreen.itemSets}
            fullWidth={true}
          />
        </Grid>
        <Grid item sm={12} md={4} className="lookUpMenuPadding">
          <TextFieldMemi
            value={itemDescription}
            setTextValue={(value) => setItemDescription(value)}
            label="Item Description"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={supplierName}
            setTextValue={(value) => setSupplierName(value)}
            label="Supplier Name"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={supplierNumber}
            setTextValue={(value) => setSupplierNumber(value)}
            label="Supplier Number"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
          // type="number"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={plu}
            setTextValue={(value) => setPlu(value)}
            label="PLU"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
            type="number"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <DropDownMemi
            value={conversionStatus}
            setValue={(value) => setConversionStatus(value)}
            label="Conversion Status *"
            alignItems="columns"
            DropDownClass="lookUpMenuDropdown"
            LabelClass="lookUpMenuLabelClass"
            options={AppData.lookUpScreen.conversionStatus}
            fullWidth={true}
            error={errorConversionStatus}
            errorText=""
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={corpItemCode}
            setTextValue={(value) => setCorpItemCode(value)}
            label="Corp Item Code"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
            type="number"
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <DropDownMemi
            value={supplyType}
            setValue={(value) => setSupplyType(value)}
            label="Supply Type"
            alignItems="columns"
            DropDownClass="lookUpMenuDropdown"
            LabelClass="lookUpMenuLabelClass"
            options={supplyTypeOptions}
            fullWidth={true}
          />
        </Grid>
        <Grid item sm={12} md={2} className="lookUpMenuPadding">
          <TextFieldMemi
            value={productHierarchyName}
            setTextValue={(value) => setProductHierarchyName(value)}
            label="Product Hierarchy Name"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField"
            LabelClass="lookUpMenuLabelClass"
            type="number"
          />
        </Grid>
        <Grid item sm={12} md={6} className="lookUpMenuPadding" style={{ display: "flex", width: "100%" }}>
          <TextFieldMemi
            value={hierachyLevel1}
            setTextValue={(value) => setHierachyLevel1(value)}
            label="Hierachy Level"
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField lookUpMarginRight"
            LabelClass="lookUpMenuLabelClass"
            type="number"
            placeholder="Level 1"
            title="Level 1"
          />
          <TextFieldMemi
            value={hierachyLevel2}
            setTextValue={(value) => setHierachyLevel2(value)}
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField lookUpMarginRight"
            LabelClass="lookUpMenuLabelClass"
            type="number"
            placeholder="Level 2"
            title="Level 2"

          />
          <TextFieldMemi
            value={hierachyLevel3}
            setTextValue={(value) => setHierachyLevel3(value)}
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField lookUpMarginRight"
            LabelClass="lookUpMenuLabelClass"
            type="number"
            placeholder="Level 3"
            title="Level 3"
          />
          <TextFieldMemi
            value={hierachyLevel4}
            setTextValue={(value) => setHierachyLevel4(value)}
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField lookUpMarginRight"
            LabelClass="lookUpMenuLabelClass"
            placeholder="Level 4"
            title="Level 4"
            error={errorHierachyLevel4}
          />
          <TextFieldMemi
            value={hierachyLevel5}
            setTextValue={(value) => setHierachyLevel5(value)}
            alignItems="columns"
            TextFieldClass="lookUpMenuTextField lookUpMarginRight"
            LabelClass="lookUpMenuLabelClass"
            fullWidth={false}
            placeholder="Level 5"
            title="Level 5"
          />
        </Grid>
        <Grid item sm={12} md={1} className="lookUpMenuPadding" style={{ paddingTop: "10px" }}>
          <SortByMemi
            ButtonClass="lookUpScreenButton lookUpSortByButton"
            btnsize="small"
            sortList={sortableList}
            setSortList={setSortableList}
            RadioSortByLabelClass="RadioSortByLabel"
            sortByClass="sortByBox"
            onClickApply={handleApply}
          />
        </Grid>
        <Grid item sm={12} md={3} className="lookUpMenuPadding" style={{ paddingTop: "10px" }}>

          <ButtonMemi
            btnval={<> <Check className="lookUpIcon" /> Apply </>}
            classNameMemi="lookUpScreenButton lookUpApplyButton"
            btnsize="small"
            onClick={handleApply}

          />
          <ButtonMemi
            btnval={<><Close className="lookUpIcon" /> Cancel</>}
            classNameMemi="lookUpScreenButton lookUpCloseButton"
            btnsize="small"
            onClick={handleCancel}

          />
          <ButtonMemi
            btnval={<><Autorenew className="lookUpIcon" /> Reset All</>}
            classNameMemi="lookUpScreenButton lookUpResetButton"
            btnsize="small"
            onClick={handleReset}

          />
        </Grid>
      </Grid >
      <LookUpTable
        active={active}
        sortOrder={order}
        sortList={sortList}
        handleApply={handleApply}
        disableLoadMore={disableLoadMore}
        payload={payload}
      />
    </>

  );
}

export default LookupQuery