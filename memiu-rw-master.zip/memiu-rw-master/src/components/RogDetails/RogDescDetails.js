import React, { memo, useState } from 'react'
import { Popper } from '@material-ui/core';
import ButtonMemi from '../ButtonMemi/ButtonMemi';
import { Box } from '@mui/system';
function RogDescDetails(props) {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  console.log(open, anchorEl)
  const id = open ? 'simple-popper' : undefined;
  console.log("component rerenders")
  const handleHover = (event) => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };
  return (
    <div onMouseEnter={handleHover} onMouseLeave={handleHover} style={{paddingTop:"5px"}}>
      <ButtonMemi
        btnval={props.type === "ROG" ? "ROG Details" : "Desc Details"}
        classNameMemi={`bakeryMapInheritBtn ${props.buttonClass}`}
      />
      <Popper id={id} open={open} anchorEl={anchorEl} className="RogDescPopup" placement="bottom-end">
        <Box>
          <div style={{ textAlign: "center" }}>
            <li className="badgeheading"> {props.type === "ROG" ? "ROG -RUP -Ring -Hicon" : "DST -Pack -Size"}</li>
            {
              Array.isArray(props.list) ? props.list.map((listItem) => (
                  <li className="badgeContent"> {listItem} </li>
              )) : ""
            }
          </div>
        </Box>
      </Popper>
    </div>
  )
}

export default memo(RogDescDetails)