import { getNoCacheHeaders } from "api/util";
import axios from "axios";

export function ApiMemi(url, methodtype, body, responseType = "json") {
  var head = {
    method: methodtype,
    url: url,
    headers: getNoCacheHeaders(),
    responseType: responseType
  }

  if (methodtype === "GET") {
    return axios({
      ...head
    })
  } else if (methodtype === "POST") {
    return axios({
      ...head,
      data: body,
      options: {}
    })
  }
}