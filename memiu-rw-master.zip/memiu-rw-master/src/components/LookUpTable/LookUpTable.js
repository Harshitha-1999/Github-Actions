import { Grid } from '@material-ui/core'
import React, { useContext, useEffect, useState, useRef } from 'react'
import ApplicationContext from "context/ApplicationContext";
import NoRecordsDisplay from 'components/NoRecordsDisplay/NoRecordsDisplay';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import { NotInterested, Shuffle } from '@material-ui/icons';
import { memiuServices } from 'api/memiu/memiuService';
import TableResizeablColumns from 'components/TableMemi/TableResizeablColumns';
import SearchFieldMemi from 'components/SearchFieldMemi/SearchFieldMemi';
import RearrangeButtonPopup from 'components/RearrangeButtonPopup/RearrangeButtonPopup';

export default function LookUpTable(props) {
  const AppData = useContext(ApplicationContext)
  const { companyId, divisionId, memi06 } = AppData;
  const { serchResults } = memi06
  const [tableData, setTableData] = useState(serchResults);
  const [selectedRows, setSelectedRows] = useState([])
  const [searchValue, setSearchValue] = useState("")
  const [columns, setColumns] = useState([])
  const [disableLoadMoreWhenSearch, setDisableLoadMoreWhenSearch] = useState(false);
  useEffect(() => {
    let columns = memi06 && memi06.customVO && memi06.customVO.columnList ? memi06.customVO.columnList.map((column) => {
      return {
        ...column,
        field: column.id,
        headerName: column.label,
        headerCss: column.product === "#3196d3" ? "lookUpTableSource mappingTableHeader" : "lookUpTableTarget mappingTableHeader",
        colspan: 1,
      }
    }) : []


    setTableData(serchResults);
    setSearchValue("");
    setDisableLoadMoreWhenSearch(false)
    columns.unshift({ field: " ", headerCss: "lookUpTableSource" })
    setColumns(columns)
    setSelectedRows([]);
  }, [memi06])

  //handle Search

  const handleSearch = (search) => {
    if (search.trim() === "") {
      setDisableLoadMoreWhenSearch(false);
      setTableData(serchResults)
    }
    else {
      setDisableLoadMoreWhenSearch(true);
      let tempData = [];
      for (let i = 0; i < serchResults.length; i++) {
        let isValid = false;
        columns.filter((column) => { return column.product === "#3196d3" }).forEach((column) => {
          if (serchResults[i][`${column.field}`]) {
            if (serchResults[i][`${column.field}`].toString().toLowerCase().includes(search.toLowerCase().trim())) {
              isValid = true;
            }
          }
        })
        if (isValid) {
          tempData.push(serchResults[i])
        }
      }
      console.log(tempData)
      setTableData(tempData)
    }
  }
  // handle Load More
  const handleLoadMore = () => {
    let startIndexTemp = AppData.memi06.end_index + 1;
    let endIndexTemp = startIndexTemp + 500
    props.handleApply(props.order, props.sortList, "loadMore", startIndexTemp, endIndexTemp)
  }

  const handleMarkDead = () => {
    const action = (message) => {
      AppData.setConfirmationModal(false);
      let statusCode;
      let reqData = selectedRows.map((value) => {
        let saveLkpRequest = {};
        let item = value;
        saveLkpRequest.companyId = companyId;
        saveLkpRequest.divisionId = divisionId;
        saveLkpRequest.productSKU = item["src_prod_sku"];
        saveLkpRequest.upc = item["src_upc"];
        saveLkpRequest.currentStatusCd = item["src_conv_st_cd"];
        saveLkpRequest.currentStatusSubCd = item["src_conv_st_sb_cd"];
        saveLkpRequest.changestatusCd = "DEAD";
        saveLkpRequest.statusReasonComments = message;
        if (item["src_conv_st_cd"] === "C") {
          statusCode = 1;
        }
        if (item.currentStatusCd == "D") {
          statusCode = 2;
        }
        return saveLkpRequest;
      });
      if (statusCode == 1) {
        AppData.setAlertBox(true, "Completed items can't be marked as Dead.");
        return;
      } else if (statusCode == 2) {
        AppData.setAlertBox(true, "Dead items can't be marked as Dead again.");
        return;
      }
      else {
        memiuServices.performButtonAction(reqData, props.payload)
          .then((res) => {
            let data = res.data;
            data.serchResults = data.serchResults.map((x, index) => {
              return { ...x, id: index + data.start_index }
            })
            AppData.setMemi06({ ...data, ...AppData.lookUpScreen });
            setSelectedRows([]);
          })
          .catch((error) => {
          })
      }

    }
    if (selectedRows.length === 0) {
      AppData.setAlertBox(true, "Select any items to proceed.")
    }
    else {
      AppData.setConfirmationModal(true, action, "textBox", "Selected item(s) will be marked as dead. Provide a reason for it.")
    }
  }
  const handleExcelDownload = () => {
    memiuServices.postLookUpExportExcel(props.payload)
      .then((res) => {
        const url = window.URL.createObjectURL(new Blob([res.data],));
        const link = document.createElement('a');
        const date = Date.now()
        link.href = url;
        link.setAttribute('download', date + "_LookupResult_" + "Select" + ".xlsx");
        
        link.click();
      })
      .catch((error) => {
      })
  }
  const LookUpComponent = (
    <Grid container>
      <Grid item xs={12} className="lookUpTableHeaderGrid">
        <span className="lookUpTableHeader">
          <big> Result &nbsp; &nbsp; </big>
          <img src="/export_to_excel_icon.png" alt="/" style={{ cursor: "pointer" }} title="Export the result To Excel sheet" onClick={handleExcelDownload} />
        </span>
        &nbsp;
        &nbsp;
        <SearchFieldMemi
          // onClickSearch
          searchValue={searchValue}
          setSearchValue={setSearchValue}
          onSearch={handleSearch}
          disableSelectMenu
          classNameMemi="lookUpSearch"
          inputClass="lookUpSearchInput"
        />
        <span style={{ backgroundColor: "#04a6d6", width: "15px", height: "15px", marginLeft: "auto", color: "grey" }}></span><span style={{ color: "grey" }}>-Source</span> &nbsp;
        <span style={{ backgroundColor: "#ca6b09", width: "15px", height: "15px" }}></span><span style={{ color: "grey" }}>-Target</span>
        &nbsp;
        <RearrangeButtonPopup
          additionalFields={memi06 && memi06.customVO ? memi06.customVO.availableList : []}
          onChangeFields={(availableList, columnList) => AppData.setMemi06({ ...memi06, customVO: { ...memi06.customVO, availableList: availableList, columnList: columnList } })}
          viewableFields={memi06 && memi06.customVO ? memi06.customVO.columnList : []}
        />
      </Grid>
      <Grid item xs={12} style={{ height: "18rem", marginTop: "0.2rem" }}>
        <TableResizeablColumns
          data={tableData ? tableData : []}
          columns={columns}
          classNameMemi="lookUpTable"
          selectedRows={selectedRows}
          setSelectedRows={(rows) => setSelectedRows(rows)}
          containerClass="lookupTableContainer"
          stickyHeader={true}
        />
      </Grid>
      <Grid item xs={12} style={{ marginTop: "-30px", "paddingLeft": "6px", display: "flex", alignItems: "center" }}>
        <ButtonMemi
          classNameMemi="lookUpMarkDead"
          btnval={<><NotInterested style={{ transform: "scale(0.8" }} /> Mark As Dead</>}
          btnsize="small"
          onClick={handleMarkDead}
        />
        <ButtonMemi
          classNameMemi={props.disableLoadMore || disableLoadMoreWhenSearch ? "lookUpDisabledLoadMore" : "lookUpLoadMore"}
          btnval="Load More..."
          btnsize="small"
          onClick={handleLoadMore}
          btndisabled={props.disableLoadMore || disableLoadMoreWhenSearch}
        />
      </Grid>


    </Grid>
  )

  return (
    <Grid container style={{ marginTop: "0.55rem" }}>
      {
        props.active ? (serchResults && serchResults.length > 0 ?
          LookUpComponent : <NoRecordsDisplay classNameMemi="noRecordsLookUpScreen" />
        ) : ""
      }
    </Grid>
  )
}