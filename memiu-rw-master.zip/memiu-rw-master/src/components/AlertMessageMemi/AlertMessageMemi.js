import React, { useContext } from 'react'
import { Snackbar } from '@material-ui/core';
import { Alert } from '@mui/material';
import ApplicationContext from "../../context/ApplicationContext";

export default function AlertMessageMemi() {
    const AppData = useContext(ApplicationContext);

    const { open, type, message } = AppData.alertMessage

    const handleClose = () => {
        AppData.setAlertMessage(false)
    }

    const AlertComponet = React.forwardRef(function (props, ref) {
        return (
            <Alert sx={{ width: '100%' }} elevation={6} ref={ref} {...props}>
                {message}
            </Alert>
        )
    })

    return (
        <Snackbar open={open} autoHideDuration={4000} onClose={handleClose} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
            <AlertComponet onClose={handleClose} severity={type} />
        </Snackbar>
    )
}
