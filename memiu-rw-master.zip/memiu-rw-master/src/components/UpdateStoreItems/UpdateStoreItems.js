import React, { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { MEUP_APIs } from "../../service/apiUrls";
import { validateCicUpcStore } from "../CommonFunctionsMeup/CommonFunctionsMeup";
import { RouteBase } from "routes/constants";
import { meupServices } from "./../../api/meup/meupServices";
import { ApiMemi } from "../../components/ApiCallsMemi/ApiCallsMemi";
import CalendarMeup from "components/CalendarMeup/CalendarMeup";
import RadioMemi from "components/RadioMemi/RadioMemi";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ListSelectMeup from "components/ListSelectMeup/ListSelectMeup";
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ErrorListMeup from "components/ErrorListMeup/ErrorListMeup";
import TextFieldMemi from "components/TextField/TextFieldMemi";

function UpdateStoreItems() {
  const history = useHistory();
  const categoryUrl = MEUP_APIs.category;
  const groupUrl = MEUP_APIs.group;
  const divisionUrl = MEUP_APIs.division;
  const [optionSearch, setOptionSearch] = useState("Unblock");
  const [country, setCountry] = useState("001");
  const [selectedDivisions, setSelectedDivisions] = useState([]);
  const [selectedGroups, setSelectedGroups] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [categories, setCategories] = useState([]);
  const [groups, setGroups] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [cic, setCic] = useState("");
  const [upc, setUpc] = useState("");
  const [store, setStore] = useState("");
  const [deleteDateTo, setDeleteDateTo] = useState(null);
  const [deleteDateFrom, setDeleteDateFrom] = useState(null);
  const [errors, setErrors] = useState([]);
  const [errorCic, setErrorCic] = useState(false);
  const [errorUpc, setErrorUpc] = useState(false);
  const [errorStore, setErrorStore] = useState(false);

  useEffect(() => {
    ApiMemi(divisionUrl, "GET")
      .then((res) => {
        const data = res.data.map((data) => {
          return { label: data.dispDivision, value: data.divisionNumber };
        });

        setDivisions(data);
      })
      .catch((error) => {
        setDivisions([]);
      });
  }, [divisionUrl]);
  useEffect(() => {
    setSelectedGroups([]);
    setGroups([]);

    //api call to fetch group of that particular division
    if (selectedDivisions.length === 0) {
      setCategories([]);
      setSelectedCategories([]);
    } else {
      ApiMemi(
        groupUrl + `?divisionNumbers=${selectedDivisions}&corp=${country}`,
        "GET"
      )
        .then((res) => {
          const data = res.data.map((data) => {
            return { label: data.dispGroup.trim(), value: data.groupCd };
          });
          setGroups(data);
        })
        .catch((error) => {
          setGroups([]);
        });
    }
  }, [selectedDivisions, country, groupUrl]);

  useEffect(() => {
    //api call to fetch group of that particular category
    setSelectedCategories([]);
    setCategories([]);

    if (selectedGroups.length === 0) {
      return;
    } else {
      ApiMemi(
        categoryUrl + `?groupCds=${selectedGroups}&corp=${country}`,
        "GET"
      )
        .then((res) => {
          const data = res.data.map((data) => {
            return { label: data.dispCategory.trim(), value: data.categoryCd };
          });
          setCategories(data);
        })
        .catch((error) => {
          setCategories([]);
        });
    }
  }, [selectedGroups, categoryUrl, country]);

  const handleSubmit = () => {
    let errorList = [];
    setErrorUpc(false);
    setErrorCic(false);
    setErrorStore(false);

    if (
      selectedDivisions.length === 0 &&
      selectedCategories.length === 0 &&
      selectedGroups.length === 0 &&
      cic === "" &&
      upc === "" &&
      store === "" &&
      deleteDateTo === null &&
      deleteDateFrom === null
    ) {
      errorList.push(
        "Please specify at least one parameter other than Country"
      );
    } else if (deleteDateTo === null && deleteDateFrom !== null) {
      alert("Please enter 'To' Date");
      return;
    } else if (deleteDateFrom === null && deleteDateTo !== null) {
      alert("Please enter 'From' Date");
      return;
    } else {
      validateCicUpcStore(
        "cic",
        cic,
        7,
        (error) => setErrorCic(error),
        errorList
      );
      validateCicUpcStore(
        "upc",
        upc,
        10,
        (error) => setErrorUpc(error),
        errorList
      );
      validateCicUpcStore(
        "store number",
        store,
        4,
        (error) => setErrorStore(error),
        errorList
      );
    }

    if (errorList.length === 0) {
      meupServices
        .getAllItems(
          "SMURA16",
          country,
          selectedDivisions,
          selectedGroups,
          selectedCategories,
          cic,
          store,
          "",
          "",
          upc,
          deleteDateTo,
          deleteDateFrom,
          optionSearch
        )
        .then((res) => {
        })
        .catch((err) => {
          errorList.push(`An Exception occurred while retrieving the data.`);
          setErrors(errorList);
          window.scrollTo(0, 0);
        });
    } else {
      setErrors(errorList);
      window.scrollTo(0, 0);
    }
  };

  const onChangeCategory = (value) => {
    setSelectedCategories(value);
    setCic("");
    setUpc("");
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <div
          style={{
            backgroundColor: "#CFC3AD",
            width: "fit-content",
            padding: "0.5rem 1rem 0rem 1rem",
            height: "1.5rem",
          }}
        >
          <strong> Enter Items to Block </strong>
        </div>
      </Grid>
      <Grid item xs={12}>
        <ErrorListMeup errors={errors} />
      </Grid>
      <Grid item xs={12}>
        <div
          style={{
            color: "rgb(0, 0, 128)",
            marginTop: "22px",
            fontSize: "medium",
          }}
        >
          <strong>
            {" "}
            Specify the search criteria. In addition to country, at least one
            other parameter should be specified.{" "}
          </strong>
        </div>
      </Grid>

      <Grid
        container
        style={{ width: "80rem" }}
        className="blockItemsMarginTop"
      >
        {/* <Button>Save</Button> */}
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <DropDownMemi
            label={
              <>
                {" "}
                Select Country <font color="red">*</font>{" "}
              </>
            }
            LabelClass="labelClassStoreItems"
            alignItems="row"
            options={[{ label: "us", value: "001" }]}
            DropDownClass="blockItemsDropDown"
            value={country}
            setValue={(value) => setCountry(value)}
            errorText="Country is required"
          />
        </Grid>

        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Division"
            LabelClass="labelClassStoreItems"
            options={divisions}
            value={selectedDivisions}
            setValue={(value) => setSelectedDivisions(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>

        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <ListSelectMeup
            label="Group"
            LabelClass="labelClassStoreItems"
            options={groups}
            value={selectedGroups}
            setValue={(value) => setSelectedGroups(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <ListSelectMeup
            label="Category"
            LabelClass="labelClassStoreItems"
            options={categories}
            value={selectedCategories}
            setValue={(value) => onChangeCategory(value)}
            alignItems="row"
            classNameMeup="listStoreItems"
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <TextFieldMemi
            label="CIC"
            value={cic}
            LabelClass="labelClassStoreItems"
            setTextValue={(value) => setCic(value)}
            alignItems="row"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            limit={8}
            disabled={selectedCategories.length > 0}
            error={errorCic}
            errorText=""
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">

          <TextFieldMemi
            label="upc"
            value={upc}
            setTextValue={(value) => setUpc(value)}
            alignItems="row"
            LabelClass="labelClassStoreItems"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            limit={12}
            error={errorUpc}
            disabled={selectedCategories.length > 0}
            errorText=""
          />
        </Grid>
        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <TextFieldMemi
            label="Store #"
            value={store}
            setTextValue={(value) => setStore(value)}
            alignItems="row"
            LabelClass="labelClassStoreItems"
            TextFieldClass="textFieldStoreItems"
            fullWidth={false}
            limit={4}
            error={errorStore}
            errorText=""
          />
        </Grid>

        <Grid item xs={12} sm={6} className="storeItemsInnerDiv">
          <Grid item xs={12}>
            <label className="labelClassStoreItems"> Delete Date</label>
          </Grid>
          <Grid item xs={12} style={{ display: "flex", marginTop: "1rem" }}>
            <CalendarMeup
              meupcal="storeItemscal"
              label="from"
              LabelClass="labelClassUpdateStoreItems"
              alignItems="row"
              value={deleteDateFrom}
              setValue={(value) => setDeleteDateFrom(value)}
            />

            <CalendarMeup
              meupcal="storeItemscal"
              label="to"
              LabelClass="labelClassUpdateStoreItems"
              alignItems="row"
              value={deleteDateTo}
              setValue={(value) => setDeleteDateTo(value)}
            />
          </Grid>
        </Grid>

      </Grid>

      <Grid item xs={12} className="blockItemsMarginTop">
        <RadioMemi

          classnameMemi="blockItemsSearchItems"
          radioclassmemi="radioBlockItemsSearchItems"
          Mainlabel=" Please select an option before search."
          label={[
            { value: "Unblock", label: "Unblock" },
            { value: "modifyDelete", label: "Modify Delete Date" },
          ]}
          value={optionSearch}
          setValue={(value) => setOptionSearch(value)}
        />
      </Grid>

      <Grid
        item
        xs={12}
        className="blockItemsMarginTop"
        style={{ marginBottom: "3rem" }}
      >
        <ButtonMemi
          btnval="Search Store Items"
          btnvariant="contained"
          classNameMemi="blockItemsButtons"
          onClick={handleSubmit}
        />

        <ButtonMemi
          btnval="Reset"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            window.location.reload();
          }}
        />

        <ButtonMemi
          btnval="Cancel"
          btnvariant="contained"
          classNameMemi="blockItemsButtons blockItemsButtonMarginLeft"
          onClick={() => {
            history.push(RouteBase.MEUP50);
          }}
        />
      </Grid>
    </Grid>
  );
}

export default UpdateStoreItems;
