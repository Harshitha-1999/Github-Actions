import React, { useContext, useEffect, useState, useCallback, memo } from 'react';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";
import { OutlinedInput } from "@material-ui/core";

import { Grid } from '@material-ui/core';
import TextFieldMemi from 'components/TextField/TextFieldMemi';
import { CloseTwoTone } from '@material-ui/icons';
import DropDownMemi from '../DropDownMemi/DropDownMemi';
// import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import RogDescDetails from 'components/RogDetails/RogDescDetails'
function BakeryMappingModal() {

    const AppData = useContext(ApplicationContext);
    const [isEditChecked, setEditChecked] = useState(false);

    const [buyRogDetails, setBuyRogDetails] = useState([]);
    const [buyDescDetails, setBuyDescDetails] = useState([]);
    const [sellDescDetails, setSellDescDetails] = useState([]);
    const [sellRogDetails, setSellRogDetails] = useState([]);

    const { data, sellingData, skuTitle, cicBuyTitle, cicSellTitle } = AppData.mappingModal;

    const onHandleEdit = useCallback((e) => {
        setEditChecked(e.target.checked)
    }, [isEditChecked]);

    const handleClose = () => {
        AppData.setMappingModal(false);
    }

    // sellData.editsell_dstCntr = sellingData.sizeDetails[0].dstCntr.toString().replace(/^\s+|\s+$/gm, '');

    const [cicField, setCicField] = useState({ dcPackDesc: "", dcSizeDsc: "", prodwght: "", handlingCode: "", buyerNum: "", randomWtCd: "", sellByDays: "", useByDays: "", pullBydays: "", autoCostInv: "I", billingType: "", costAllow: "", costIb: "", costInv: "", costVend: "", retailUnitPack: "", labelSize: "", labelNumbers: "", ring: "", hicone: "", tareCd: "", sgnCount1: "", sgnCount2: "", sgnCount3: "", fdStmp: "", prcTypeCd: "" });

    const [cicSellingField, setCicSellingField] = useState({ dcPackDesc: "", dcSizeDsc: "", prodwght: "", handlingCode: "", buyerNum: "", randomWtCd: "", sellByDays: "", useByDays: "", pullBydays: "", autoCostInv: "I", billingType: "", costAllow: "", costIb: "", costInv: "", costVend: "", retailUnitPack: "", labelSize: "", labelNumbers: "", ring: "", hicone: "", tareCd: "", sgnCount1: "", sgnCount2: "", sgnCount3: "", fdStmp: "", prcTypeCd: "" });

    const [cicFieldError, setCicErrorField] = useState({ dcPackDesc_error: false, dcSizeDsc_error: false, prodwght_error: false, handlingCode_error: false, buyerNum_error: false, randomWtCd_error: false, sellByDays_error: false, useByDays_error: false, pullBydays_error: false, autoCostInv_error: "I", billingType_error: false, costAllow_error: false, costIb_error: false, costInv_error: false, costVend_error: false, retailUnitPack_error: false, labelSize_error: false, labelNumbers_error: false, ring_error: false, hicone_error: false, tareCd_error: false, sgnCount1_error: false, sgnCount2_error: false, sgnCount3_error: false, fdStmp_error: false, prcTypeCd_error: false });

    const [cicFieldSellingError, setCicErrorSellingField] = useState({ dcPackDesc_error: false, dcSizeDsc_error: false, prodwght_error: false, handlingCode_error: false, buyerNum_error: false, randomWtCd_error: false, sellByDays_error: false, useByDays_error: false, pullBydays_error: false, autoCostInv_error: "I", billingType_error: false, costAllow_error: false, costIb_error: false, costInv_error: false, costVend_error: false, retailUnitPack_error: false, labelSize_error: false, labelNumbers_error: false, ring_error: false, hicone_error: false, tareCd_error: false, sgnCount1_error: false, sgnCount2_error: false, sgnCount3_error: false, fdStmp_error: false, prcTypeCd_error: false });

    const onLoadFunction = useCallback((data, type) => {

        let buyData = {};
        if(type == "buy") {
            buyData={...cicField}
        } else {
            buyData={...cicSellingField}
        }
        if (data.sizeDetails) {
            let descDetails = [];
            for (var i = 0; i < data.sizeDetails.length; i++) {
                var sizd = data.sizeDetails[i].dstCntr + " - " + data.sizeDetails[i].dcPackDesc + " - " + data.sizeDetails[i].dcSizeDesc;
                descDetails.push(sizd);

                if (i == 0) {
                    buyData.dcPackDesc = data.sizeDetails[0].dcPackDesc.toString();
                    buyData.dcSizeDsc = data.sizeDetails[0].dcSizeDesc.toString();
                    buyData.autoCostInv = data.sizeDetails[0].autoCostInv.toString();
                    buyData.billingType = data.sizeDetails[0].billingType.toString();
                    buyData.buyerNum = data.sizeDetails[0].buyerNum.toString().replace(/^\s+|\s+$/gm, '');
                    // buyData.editbuy_dstCntr = data.sizeDetails[0].dstCntr.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.handlingCode = data.sizeDetails[0].handlingCode.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.randomWtCd = data.sizeDetails[0].randomWtCd.toString();
                    buyData.costAllow = data.sizeDetails[0].costAllow.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.costIb = data.sizeDetails[0].costIb.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.costInv = data.sizeDetails[0].costInv.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.costVend = data.sizeDetails[0].costVendor.toString().replace(/^\s+|\s+$/gm, '');
                    // buyData.editbuy_shelfLife = data.sizeDetails[0].shelfLife.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.sellByDays = Number(data.sizeDetails[0].shelfLife);
                    buyData.useByDays = (Number(data.sizeDetails[0].shelfLife) + 1);
                    buyData.pullBydays = Number(data.sizeDetails[0].shelfLife);
                    buyData.prcTypeCd = data.sizeDetails[0].prcTypeCd.toString().replace(/^\s+|\s+$/gm, '');
                }
            }
            if (type == "buy") {
                setBuyDescDetails(descDetails)
            } else {
                setSellDescDetails(descDetails)
            }
        }

        if (data.rogDetail) {
            let rogDetails = [];
            for (var j = 0; j < data.rogDetail.length; j++) {
                var rogd = data.rogDetail[j];
                var arrnaming = Object.keys(rogd);
                let val = rogd[arrnaming[0]].rog + " - " + rogd[arrnaming[0]].retailUnitPack + " - " + rogd[arrnaming[0]].ring + " - " + rogd[arrnaming[0]].hicone;
                rogDetails.push(val);
                // buyData.editbuy_rogDetails.push(val);
                if (rogd[arrnaming[0]].topRank) {
                    buyData.hicone = rogd[arrnaming[0]].hicone.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.retailUnitPack = rogd[arrnaming[0]].retailUnitPack.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.ring = rogd[arrnaming[0]].ring.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.fdStmp = rogd[arrnaming[0]].foodStamp.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.labelNumbers = rogd[arrnaming[0]].tagNumber.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.labelSize = rogd[arrnaming[0]].tagSize.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.tareCd = rogd[arrnaming[0]].tareCd.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.sgnCount1 = rogd[arrnaming[0]].sgnCount1.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.sgnCount2 = rogd[arrnaming[0]].sgnCount2.toString().replace(/^\s+|\s+$/gm, '');
                    buyData.sgnCount3 = rogd[arrnaming[0]].sgnCount3.toString().replace(/^\s+|\s+$/gm, '');
                }
            }
            if (type === "buy") {
                setBuyRogDetails(rogDetails);
            } else {
                setSellRogDetails(rogDetails)
            }
        }

        if (data.sourceWieght) {

            for (var i = 0; i < data.sourceWieght.length; i++) {
                var wtd = data.sourceWieght[i].prodWt;
                // $scope.editbuy_sourceWeight.push(wtd);
                if (i == 0) {
                    buyData.prodwght = data.sourceWieght[0].prodWt.toString().replace(/^\s+|\s+$/gm, '');
                }
            }
        }

        return buyData;
    }, [cicField, cicSellingField])

    useEffect(() => {

        let buyDataResult = {};
        let sellDataResult = {};

        setEditChecked(false);

        setCicErrorField({ dcPackDesc_error: false, dcSizeDsc_error: false, prodwght_error: false, handlingCode_error: false, buyerNum_error: false, randomWtCd_error: false, sellByDays_error: false, useByDays_error: false, pullBydays_error: false, autoCostInv_error: "I", billingType_error: false, costAllow_error: false, costIb_error: false, costInv_error: false, costVend_error: false, retailUnitPack_error: false, labelSize_error: false, labelNumbers_error: false, ring_error: false, hicone_error: false, tareCd_error: false, sgnCount1_error: false, sgnCount2_error: false, sgnCount3_error: false, fdStmp_error: false, prcTypeCd_error: false });

        setCicErrorSellingField({ dcPackDesc_error: false, dcSizeDsc_error: false, prodwght_error: false, handlingCode_error: false, buyerNum_error: false, randomWtCd_error: false, sellByDays_error: false, useByDays_error: false, pullBydays_error: false, autoCostInv_error: "I", billingType_error: false, costAllow_error: false, costIb_error: false, costInv_error: false, costVend_error: false, retailUnitPack_error: false, labelSize_error: false, labelNumbers_error: false, ring_error: false, hicone_error: false, tareCd_error: false, sgnCount1_error: false, sgnCount2_error: false, sgnCount3_error: false, fdStmp_error: false, prcTypeCd_error: false });


        if (data)
            buyDataResult = onLoadFunction(data, "buy");

        if (sellingData.length === 0) {
            sellingData.sizeDetails = data.sizeDetails;
            sellingData.rogDetail = data.rogDetail;
            sellingData.sourceWieght = data.sourceWieght;
        }

        if (sellingData) {
            sellDataResult = onLoadFunction(sellingData, "sell");
        }
        console.log("useEffect running")
        setCicField(buyDataResult);
        setCicSellingField(sellDataResult);

    }, [data, sellingData])


    const onHandleCicField = useCallback((value, type, isSellingType) => {

        if (isSellingType === "CIC")
            setCicField(preState => ({ ...preState, [type]: value }));
        else
            setCicSellingField(preState => ({ ...preState, [type]: value }));

    }, []);

    const onLoadError = useCallback((data) => {

        let cicError = {};

        data.map((value) => {
            cicError.dcPackDesc_error = value.dcPackDesc === "" || value.dcPackDesc === undefined ? true : false;
            cicError.dcSizeDsc_error = value.dcSizeDsc === "" || value.dcSizeDsc === undefined ? true : false;
            cicError.prodwght_error = value.prodwght === "" || value.prodwght === undefined ? true : false;
            cicError.handlingCode_error = value.handlingCode === "" || value.handlingCode === undefined ? true : false;
            cicError.buyerNum_error = value.buyerNum === "" || value.buyerNum === undefined ? true : false;
            cicError.sellByDays_error = value.sellByDays === "" || value.sellByDays === undefined ? true : false;
            cicError.useByDays_error = value.useByDays === "" || value.useByDays === undefined ? true : false;
            cicError.pullBydays_error = value.pullBydays === "" || value.pullBydays === undefined ? true : false;
            cicError.autoCostInv_error = value.autoCostInv === "" || value.autoCostInv === undefined ? true : false;
            cicError.costAllow_error = value.costAllow === "" || value.costAllow === undefined ? true : false;
            cicError.costIb_error = value.costIb === "" || value.costIb === undefined ? true : false;
            cicError.costInv_error = value.costInv === "" || value.costInv === undefined ? true : false;
            cicError.costVend_error = value.costVend === "" || value.costVend === undefined ? true : false;
            cicError.retailUnitPack_error = value.retailUnitPack === "" || value.retailUnitPack === undefined ? true : false;
            cicError.labelSize_error = value.labelSize === "" || value.labelSize === undefined ? true : false;
            cicError.labelNumbers_error = value.labelNumbers === "" || value.labelNumbers === undefined ? true : false;
            cicError.ring_error = value.ring === "" || value.ring === undefined ? true : false;
            cicError.hicone_error = value.hicone === "" || value.hicone === undefined ? true : false;
            cicError.tareCd_error = value.tareCd === "" || value.tareCd === undefined ? true : false;
            cicError.sgnCount1_error = value.sgnCount1 === "" || value.sgnCount1 === undefined ? true : false;
            cicError.sgnCount2_error = value.sgnCount2 === "" || value.sgnCount2 === undefined ? true : false;
            cicError.sgnCount3_error = value.sgnCount3 === "" || value.sgnCount3 === undefined ? true : false;
            cicError.fdStmp_error = value.fdStmp === "" || value.fdStmp === undefined ? true : false;
            cicError.prcTypeCd_error = value.prcTypeCd === "" || value.prcTypeCd === undefined ? true : false;

        });

        return cicError;

    }, [])

    const onClickSubmit = useCallback(() => {

        let cicErrorResult = {};
        let cicSellErrorResult = {};

        let isCicError = false;
        let isSellError = false;

        cicErrorResult = onLoadError([cicField]);
        cicSellErrorResult = onLoadError([cicSellingField]);

        setCicErrorField(cicErrorResult);
        setCicErrorSellingField(cicSellErrorResult);

        // Object.values(itemType).every((value) => { return !value })

        isCicError = Object.values(cicErrorResult).every((value) => { return !value });
        isSellError = Object.values(cicSellErrorResult).every((value) => { return !value });

        if (isCicError && isSellError) {
            AppData.mappingModal.onClickOk(cicField, cicSellingField);
        }

    }, [cicField, cicFieldError, cicSellingField, cicFieldSellingError]);

    const mappingContent = (

        <Grid container className={"bakeryMapContainer"}>
            <Grid container className="">
                <Grid item xs={6} className="">
                    <span className={"bakeryMapHeading"}>Add/Inherit Mapping</span>
                </Grid>
                <Grid item xs={6} className="" style={{ textAlign: "right" }}>
                    <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={handleClose} />
                </Grid>
            </Grid>

            <Grid container className={"bakeryMapDesc"}>
                <Grid item xs={4} className="">
                    {
                        skuTitle && skuTitle.map((value, index) =>
                            <>
                                <div className={"loadOnMapTxtDesc"} key={index}>{value}</div>
                            </>

                        )
                    }

                </Grid>
                <Grid item xs={4} className="">
                    <span className={"loadOnMapTxtDescTwo"}>{cicBuyTitle}</span>
                </Grid>
                <Grid item xs={4} className="">
                    <span className={"loadOnMapTxtDescThree"}>{cicSellTitle}</span>
                </Grid>
            </Grid>
            <Grid container className={"bakeryMapSubContainer"}>
                <Grid item xs={4} className="loadOnMapTxt">
                    <label className={"loadEditTxt"}><input type="checkbox" name={"ENABLE_EDIT"} checked={isEditChecked} onChange={onHandleEdit} /> Enable to edit</label>
                </Grid>
                <Grid item xs={4} style={{ paddingTop: "5px" }} style={{ display: "flex" }}>

                    <RogDescDetails
                        list={buyDescDetails}
                    />
                    &nbsp;
                    <RogDescDetails
                        list={buyRogDetails}
                        type="ROG"
                    />

                </Grid>
                <Grid item xs={4} style={{ paddingTop: "5px", display: "flex" }}>

                    <RogDescDetails
                        list={sellDescDetails}
                        buttonClass="bakeryMapDetails"
                    />
                    &nbsp;
                    <RogDescDetails
                        list={sellRogDetails}
                        type="ROG"
                        buttonClass="bakeryMapDetails"
                    />

                </Grid>
            </Grid>
            <Grid container className={"bakeryMapInputontainer"} style={{ padding: "10px" }}>

                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicField.dcPackDesc}
                        setTextValue={(value) => onHandleCicField(value, "dcPackDesc", "CIC")}
                        label="Desc Pack :"
                        alignItems="columns"
                        LabelClass="mapLabel"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        placeholder=""
                        error={cicFieldError.dcPackDesc_error}

                    />

                    <TextFieldMemi
                        value={cicField.dcSizeDsc}
                        setTextValue={(value) => onHandleCicField(value, "dcSizeDsc", "CIC")}
                        label="Desc Size :"
                        alignItems="columns"
                        LabelClass="mapLabel"
                        placeholder=""
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        error={cicFieldError.dcSizeDsc_error}
                    />
                    <TextFieldMemi
                        value={cicField.prodwght}
                        setTextValue={(value) => onHandleCicField(value, "prodwght", "CIC")}
                        label="Prod Wt :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.prodwght_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicSellingField.dcPackDesc}
                        setTextValue={(value) => onHandleCicField(value, "dcPackDesc", "SELLING_CIC")}
                        label="Desc Pack :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicSellingField.dcPackDesc_error}
                    />

                    <TextFieldMemi
                        value={cicSellingField.dcSizeDsc}
                        setTextValue={(value) => onHandleCicField(value, "dcSizeDsc", "SELLING_CIC")}
                        label="Desc Size :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.dcSizeDsc_error}
                    />
                    <TextFieldMemi
                        value={cicSellingField.prodwght}
                        setTextValue={(value) => onHandleCicField(value, "prodwght", "SELLING_CIC")}
                        label="Prod Wt :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.prodwght_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicField.handlingCode}
                        setTextValue={(value) => onHandleCicField(value, "handlingCode", "CIC")}
                        label="Handling Code :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.handlingCode_error}
                    />

                    <TextFieldMemi
                        value={cicField.buyerNum}
                        setTextValue={(value) => onHandleCicField(value, "buyerNum", "CIC")}
                        label="Buyer Num :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.buyerNum_error}
                    />
                    <DropDownMemi
                        value={cicField.randomWtCd}
                        setValue={(value) => onHandleCicField(value, "randomWtCd", "CIC")}
                        label="Random Wt Code :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "R", value: "R" }]}
                        fullWidth={true}
                        errorText=""
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicField.randomWtCd !== ""}
                    />

                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicSellingField.handlingCode}
                        setTextValue={(value) => onHandleCicField(value, "handlingCode", "SELLING_CIC")}
                        label="Handling Code :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.handlingCode_error}
                    />

                    <TextFieldMemi
                        value={cicSellingField.buyerNum}
                        setTextValue={(value) => onHandleCicField(value, "buyerNum", "SELLING_CIC")}
                        label="Buyer Num :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.buyerNum_error}
                    />
                    <DropDownMemi
                        value={cicSellingField.randomWtCd}
                        setValue={(value) => onHandleCicField(value, "randomWtCd", "SELLING_CIC")}
                        label="Random Wt Code :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "0", value: "0" }, { label: "R", value: "R" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicSellingField.randomWtCd !== ""}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicField.sellByDays}
                        setTextValue={(value) => onHandleCicField(value, "sellByDays", "CIC")}
                        label="Sell by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.sellByDays_error}
                    />

                    <TextFieldMemi
                        value={cicField.useByDays}
                        setTextValue={(value) => onHandleCicField(value, "useByDays", "CIC")}
                        label="Use by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.useByDays_error}
                    />
                    <TextFieldMemi
                        value={cicField.pullBydays}
                        setTextValue={(value) => onHandleCicField(value, "pullBydays", "CIC")}
                        label="Pull by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.pullBydays_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicSellingField.sellByDays}
                        setTextValue={(value) => onHandleCicField(value, "sellByDays", "SELLING_CIC")}
                        label="Sell by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.sellByDays_error}
                    />

                    <TextFieldMemi
                        value={cicSellingField.useByDays}
                        setTextValue={(value) => onHandleCicField(value, "useByDays", "SELLING_CIC")}
                        label="Use by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.useByDays_error}
                    />
                    <TextFieldMemi
                        value={cicSellingField.pullBydays}
                        setTextValue={(value) => onHandleCicField(value, "pullBydays", "SELLING_CIC")}
                        label="Pull by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.pullBydays_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>

                    <DropDownMemi
                        value={cicField.autoCostInv}
                        setValue={(value) => onHandleCicField(value, "autoCostInv", "CIC")}
                        label="Auto Cost Inv :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "A", value: "A" }, { label: "C", value: "C" }, { label: "I", value: "I" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={false}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicField.autoCostInv !== ""}
                    />

                    <DropDownMemi
                        value={cicField.billingType}
                        setValue={(value) => onHandleCicField(value, "billingType", "CIC")}
                        label="Billing Type Cd: "
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "A", value: "A" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicField.billingType !== ""}
                    />

                    {/* <TextFieldMemi
                        value={cicField.billingType}
                        setTextValue={(value) => onHandleCicField(value, "billingType", "CIC")}
                        label="Billing Type Cd: "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                    /> */}
                    <TextFieldMemi
                        value={cicField.costAllow}
                        setTextValue={(value) => onHandleCicField(value, "costAllow", "CIC")}
                        label="Cost Allow: "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.costAllow_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <DropDownMemi
                        value={cicSellingField.autoCostInv}
                        setValue={(value) => onHandleCicField(value, "autoCostInv", "SELLING_CIC")}
                        label="Auto Cost Inv :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "0", value: "0" }, { label: "A", value: "A" }, { label: "C", value: "C" }, { label: "I", value: "I" }]}
                        fullWidth={true}
                        errorText=""
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicSellingField.autoCostInv !== ""}
                    />
                    {/* <TextFieldMemi
                        value={cicSellingField.autoCostInv}
                        setTextValue={(value) => onHandleCicField(value, "autoCostInv", "SELLING_CIC")}
                        label="Auto Cost Inv: "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                    /> */}

                    <DropDownMemi
                        value={cicSellingField.billingType}
                        setValue={(value) => onHandleCicField(value, "billingType", "SELLING_CIC")}
                        label="Billing Type Cd :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "0", value: "0" }, { label: "A", value: "A" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicSellingField.billingType !== ""}
                    />

                    {/* <TextFieldMemi
                        value={cicSellingField.billingType}
                        setTextValue={(value) => onHandleCicField(value, "billingType", "SELLING_CIC")}
                        label="Billing Type Cd: "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                    /> */}
                    <TextFieldMemi
                        value={cicSellingField.costAllow}
                        setTextValue={(value) => onHandleCicField(value, "costAllow", "SELLING_CIC")}
                        label="Cost Allow:"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.costAllow_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicField.costIb}
                        setTextValue={(value) => onHandleCicField(value, "costIb", "CIC")}
                        label="Cost IB :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.costIb_error}
                    />

                    <TextFieldMemi
                        value={cicField.costInv}
                        setTextValue={(value) => onHandleCicField(value, "costInv", "CIC")}
                        label="Cost INV :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.costInv_error}
                    />
                    <TextFieldMemi
                        value={cicField.costVend}
                        setTextValue={(value) => onHandleCicField(value, "costVend", "CIC")}
                        label="Cost VEND :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.costVend_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicSellingField.costIb}
                        setTextValue={(value) => onHandleCicField(value, "costIb", "SELLING_CIC")}
                        label="Cost IB :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.costIb_error}
                    />

                    <TextFieldMemi
                        value={cicSellingField.costInv}
                        setTextValue={(value) => onHandleCicField(value, "costInv", "SELLING_CIC")}
                        label="Cost INV :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.costInv_error}
                    />
                    <TextFieldMemi
                        value={cicSellingField.costVend}
                        setTextValue={(value) => onHandleCicField(value, "costVend", "SELLING_CIC")}
                        label="Cost VEND :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.costVend_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicField.retailUnitPack}
                        setTextValue={(value) => onHandleCicField(value, "retailUnitPack", "CIC")}
                        label="RUP :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.retailUnitPack_error}
                    />

                    <DropDownMemi
                        value={cicField.labelSize}
                        setValue={(value) => onHandleCicField(value, "labelSize", "CIC")}
                        label="Tag Size :"
                        alignItems="column"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "M", value: "M" }, { label: "N", value: "N" }, { label: "S", value: "S" }]}
                        fullWidth={true}
                        errorText=""
                        disabled={!isEditChecked}
                        error={cicFieldError.labelSize_error}

                    />
                    {/* <TextFieldMemi
                        value={cicField.labelSize}
                        setTextValue={(value) => onHandleCicField(value, "labelSize", "CIC")}
                        label="Tag Size: "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                    /> */}

                    <DropDownMemi
                        value={cicField.labelNumbers}
                        setValue={(value) => onHandleCicField(value, "labelNumbers", "CIC")}
                        label="Tag Count :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }]}
                        fullWidth={true}
                        errorText=""
                        disabled={!isEditChecked}
                        error={cicFieldError.labelNumbers_error}

                    />





                    {/* <TextFieldMemi
                        value={cicField.labelNumbers}
                        setTextValue={(value) => onHandleCicField(value, "labelNumbers", "CIC")}
                        label="Tag Count: "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                    /> */}
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <TextFieldMemi
                        value={cicSellingField.retailUnitPack}
                        setTextValue={(value) => onHandleCicField(value, "retailUnitPack", "SELLING_CIC")}
                        label="RUP :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.retailUnitPack_error}
                    />

                    <DropDownMemi
                        value={cicSellingField.labelSize}
                        setValue={(value) => onHandleCicField(value, "labelSize", "SELLING_CIC")}
                        label="Tag Size :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "M", value: "M" }, { label: "N", value: "N" }, { label: "S", value: "S" }]}
                        fullWidth={true}
                        errorText=""
                        disabled={!isEditChecked}
                        error={cicFieldSellingError.labelSize_error}
                    />

                    <DropDownMemi
                        value={cicSellingField.labelNumbers}
                        setValue={(value) => onHandleCicField(value, "labelNumbers", "SELLING_CIC")}
                        label="Tag Count :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }]}
                        fullWidth={true}
                        errorText=""
                        error={cicFieldSellingError.labelNumbers_error}
                        disabled={!isEditChecked}
                    />

                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>

                    <DropDownMemi
                        value={cicField.ring}
                        setValue={(value) => onHandleCicField(value, "ring", "CIC")}
                        label="Ring :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }, { label: "2", value: "2" }, { label: "3", value: "3" }, { label: "4", value: "4" }, { label: "5", value: "5" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicField.ring !== ""}
                        error={cicFieldError.ring_error}
                    />

                    <DropDownMemi
                        value={cicField.hicone}
                        setValue={(value) => onHandleCicField(value, "hicone", "CIC")}
                        label="Hicon :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }, { label: "2", value: "2" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicField.hicone !== ""}
                        error={cicFieldError.hicone_error}
                    />

                    <TextFieldMemi
                        value={cicField.tareCd}
                        setTextValue={(value) => onHandleCicField(value, "tareCd", "CIC")}
                        label="Tare :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={cicFieldError.tareCd_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>

                    <DropDownMemi
                        value={cicSellingField.ring}
                        setValue={(value) => onHandleCicField(value, "ring", "SELLING_CIC")}
                        label="Ring :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }, { label: "2", value: "2" }, { label: "3", value: "3" }, { label: "4", value: "4" }, { label: "5", value: "5" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        inlineLabel=" "
                        disableNone={cicSellingField.ring !== ""}
                        error={cicFieldSellingError.ring_error}
                    />

                    <DropDownMemi
                        value={cicSellingField.hicone}
                        setValue={(value) => onHandleCicField(value, "hicone", "SELLING_CIC")}
                        label="Hicon :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }, { label: "2", value: "2" }]}
                        fullWidth={true}
                        errorText=""
                        inlineLabel=" "
                        disableNone={cicSellingField.hicone !== ""}
                        disabled={!isEditChecked}
                        error={cicFieldSellingError.hicone_error}  
                    />
                    <TextFieldMemi
                        value={cicSellingField.tareCd}
                        setTextValue={(value) => onHandleCicField(value, "tareCd", "SELLING_CIC")}
                        label="TARE :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel lookMapbuyingLabel"
                        placeholder=""
                        error={cicFieldSellingError.tareCd_error}
                    />
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <Grid container>
                        <Grid item xs={4}>
                            <label className="mapLabel"> Sign Count : </label>
                            <div style={{ width: "100%", display: 'flex' }}>
                                <TextFieldMemi
                                    value={cicField.sgnCount1}
                                    setTextValue={(value) => onHandleCicField(value, "sgnCount1", "CIC")}
                                    alignItems="columns"
                                    TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                                    disabled={!isEditChecked}
                                    LabelClass="mapLabel"
                                    placeholder=""
                                    error={cicFieldError.sgnCount1_error}
                                />
                                <TextFieldMemi
                                    value={cicField.sgnCount2}
                                    setTextValue={(value) => onHandleCicField(value, "sgnCount2", "CIC")}
                                    alignItems="columns"
                                    TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                                    disabled={!isEditChecked}
                                    LabelClass="mapLabel"
                                    placeholder=""
                                    error={cicFieldError.sgnCount2_error}
                                />

                                <TextFieldMemi
                                    value={cicField.sgnCount3}
                                    setTextValue={(value) => onHandleCicField(value, "sgnCount3", "CIC")}
                                    alignItems="columns"
                                    TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                                    disabled={!isEditChecked}
                                    LabelClass="mapLabel"
                                    placeholder=""
                                    error={cicFieldError.sgnCount3_error}
                                />
                            </div>
                        </Grid>

                        <Grid item xs={8} style={{ display: "flex" }}>

                            <DropDownMemi
                                value={cicField.fdStmp}
                                setValue={(value) => onHandleCicField(value, "fdStmp", "CIC")}
                                label="Food Stamp :"
                                alignItems="columns"
                                DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                                LabelClass="mapLabel"
                                options={[{ label: "0", value: "0" }, { label: "1", value: "1" }]}
                                fullWidth={true}
                                errorText=""
                                inlineLabel=" "
                                disableNone={cicField.fdStmp !== ""}
                                error={cicFieldError.fdStmp_error}
                                disabled={!isEditChecked}
                            />

                            <TextFieldMemi
                                value={cicField.prcTypeCd}
                                setTextValue={(value) => onHandleCicField(value, "prcTypeCd", "CIC")}
                                label="PRC Flag :"
                                alignItems="columns"
                                TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                                disabled={!isEditChecked}
                                LabelClass="mapLabel"
                                placeholder=""
                                error={cicFieldError.prcTypeCd_error}
                            />
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item xs={6} className="bakeryMappingPadding" style={{ display: "flex" }}>
                    <Grid container>
                        <Grid item xs={4}>
                            <label className="mapLabel"> Sign Count : </label>
                            <div style={{ display: "flex" }}>
                                <TextFieldMemi
                                    value={cicSellingField.sgnCount1}
                                    setTextValue={(value) => onHandleCicField(value, "sgnCount1", "SELLING_CIC")}

                                    alignItems="columns"
                                    TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                                    disabled={!isEditChecked}
                                    LabelClass="mapLabel lookMapbuyingLabel"
                                    placeholder=""
                                    error={cicFieldSellingError.sgnCount1_error}
                                />
                                <TextFieldMemi
                                    value={cicSellingField.sgnCount2}
                                    setTextValue={(value) => onHandleCicField(value, "sgnCount2", "SELLING_CIC")}
                                    alignItems="columns"
                                    TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                                    disabled={!isEditChecked}
                                    LabelClass="mapLabel lookMapbuyingLabel"
                                    placeholder=""
                                    error={cicFieldSellingError.sgnCount2_error}
                                />

                                <TextFieldMemi
                                    value={cicSellingField.sgnCount3}
                                    setTextValue={(value) => onHandleCicField(value, "sgnCount3", "SELLING_CIC")}
                                    alignItems="columns"
                                    TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                                    disabled={!isEditChecked}
                                    LabelClass="mapLabel"
                                    placeholder=""
                                    error={cicFieldSellingError.sgnCount3_error}
                                />
                            </div>
                        </Grid>

                        <Grid item xs={8} style={{ display: "flex" }}>

                            <DropDownMemi
                                value={cicSellingField.fdStmp}
                                setValue={(value) => onHandleCicField(value, "fdStmp", "SELLING_CIC")}
                                label="Food Stamp :"
                                alignItems="columns"
                                DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                                LabelClass="mapLabel lookMapbuyingLabel"
                                options={[{ label: "0", value: "0" }, { label: "1", value: "1" }]}
                                fullWidth={true}
                                errorText=""
                                isLabelEmpty={true}
                                disabled={!isEditChecked}
                                inlineLabel=" "
                                error={cicFieldSellingError.fdStmp_error}
                                disableNone={cicSellingField.fdStmp !== ""}
                            />

                            <TextFieldMemi
                                value={cicSellingField.prcTypeCd}
                                setTextValue={(value) => onHandleCicField(value, "prcTypeCd", "SELLING_CIC")}
                                label="PRC Flag :"
                                alignItems="columns"
                                TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                                disabled={!isEditChecked}
                                LabelClass="mapLabel lookMapbuyingLabel"
                                placeholder=""
                                error={cicFieldSellingError.prcTypeCd_error}
                            />
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
            <Grid container className={"bakeryMapDesc"}>

                <Grid item xs={12} style={{ textAlign: "right" }}>
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton textboxModalCancelBtn modalSubmitCls"
                        btnval="Submit"
                        onClick={onClickSubmit}
                    />
                </Grid>
            </Grid>
        </Grid>
    )

    return (
        <>
            <ModalPopup
                open={AppData.mappingModal.open}
                classNameMemi="bakeryMapModalCls"
                popupContentClass=""
                popupActionClass=""
                maxWidth="md"
                fullWidth
                popupContent={mappingContent}

            />
        </>

    )
}

export default memo(BakeryMappingModal)
