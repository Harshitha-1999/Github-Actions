import { Grid } from '@material-ui/core';
import TableMemi from 'components/TableMemi/TableMemi';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import React from 'react';

const DetailsComponent = (props) => {
    return (
        <Grid container style={{ paddingBottom: "1rem", "whiteSpace": "nowrap" }}>
            <Grid item xs={5}>
                <strong> {props.title} </strong>
            </Grid>
            <Grid item xs={7}>
                {props.value}
            </Grid>
        </Grid>

    )
}
function StoreItemsHistory(props) {
    const { item } = props;

    let columns = [

        {
            field: "state",
            headerName: "state",
            sortable: false,
            flex: 0.15,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "cic",
            headerName: "State Effective Date",
            sortable: false,
            flex: 0.3,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "status",
            headerName: "Status",
            sortable: false,
            flex: 0.15,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "lastDeleteDate",
            headerName: "Delete Date",
            sortable: false,
            flex: 0.2,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "lastUpdatedUser",
            headerName: "Last Update UserId",
            sortable: false,
            flex: 0.25,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"

        },
        {
            field: "lastUpdatedTimeStamp",
            headerName: "Last Update Date",
            sortable: false,
            flex: 0.25,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"
        },
        {
            field: "comments",
            headerName: "Comments",
            sortable: false,
            flex: 0.2,
            headerAlign: "center",
            headerClassName: "headerStoreItemHistory"

        }
    ];
    return (
        <Grid container>
            <Grid item xs={12} style={{ backgroundColor: "#CFC3AD", padding: "1rem" }}>
                <strong> Store Item History </strong>
            </Grid>
            <Grid container style={{ marginTop: "3rem", width: "75%" }}>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Division" value={item.divisionNumber} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Description" value={item.description} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Store" value={item.storeNumber} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="UPC" value={item.upc} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="Category" value={item.categoryDesc} />
                </Grid>
                <Grid item xs={12} md={6}>

                    <DetailsComponent title="CIC" value={item.cic} />
                </Grid>
            </Grid>
            <Grid container style={{ height: "100%" }}>
                <TableMemi
                    data={[item]}
                    columns={columns}
                    classnameMemi="tableStoreItemHistory"
                    showCellRightBorder={true}
                    showColumnRightBorder={true}
                    hideFooterPagination={true}
                    hideFooterSelectedRowCount={true}
                    autoHeight
                />
            </Grid>
            <Grid item xs={12}>
                <ButtonMemi
                    btnval="Close Window"
                    btnvariant="contained"
                    classNameMemi="blockItemsButtons"
                    onClick={() => window.close()}
                />
            </Grid>
        </Grid>
    )
}

export default StoreItemsHistory;