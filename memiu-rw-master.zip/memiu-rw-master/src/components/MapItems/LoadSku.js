import React, { useContext, useEffect, useRef, useCallback, useMemo } from 'react'
import { FormHelperText, Grid } from '@material-ui/core';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import { Add, CheckBox, LocalOffer, NotInterested, Star } from '@material-ui/icons';
import SelectMenuMemi from 'components/SelectMenuMemi/SelectMenuMemi';
import SortByMemi from 'components/SortByMemi/SortByMemi';
import FilterByMapping from 'components/FilterByMapping/FilterByMapping';
import SearchFieldMemi from 'components/SearchFieldMemi/SearchFieldMemi';
import FilterByStatus from 'components/FilterByStatus/FilterByStatus';
import ApplicationContext from 'context/ApplicationContext';
import TableMappingCollapsible from 'components/TableMemi/TableMappingCollapsible';
import { memiuServices } from 'api/memiu/memiuService';
import { authTokenCookie } from 'utils';
import { RouteBase } from 'routes/constants';
import { useHistory } from 'react-router-dom';
import UPCPopup from 'components/UPCPopup/UPCPopup';
import { usePersistState } from 'hooks/usePersistState';


export default function LoadSku(props) {
    const history = useHistory();
    const AppData = useContext(ApplicationContext)
    const { divisionId, companyId, memi03sku, memi03cic, memi03skuSelected, memi03cicSelected, memi03skuPayload, memi03cicPayload, listDepartmentSource } = AppData;
    const [itemType, setItemType] = usePersistState("", "mapItems_loadSku_itemType");
    const [filterByStatus, setFilterByStatus] = usePersistState("TO_BE_MAPPED", "mapItems_loadSku_filterByStatus");
    const [searchCriteria, setSearchCriteria] = usePersistState(null, "mapItems_loadSku_searchCriteria")
    const [sortableList, setSortableList] = usePersistState([
        { label: "Department", value: "DEPT", selected: false, id: 0 },
        { label: "Hierarchy 1", value: "HIER1", selected: false, id: 1 },
        { label: "Hierarchy 2", value: "HIER2", selected: false, id: 2 },
        { label: "Hierarchy 3", value: "HIER3", selected: false, id: 3 },
        { label: "Supplier", value: "SUPPL", selected: false, id: 4 },
        { label: "Product SKU", value: "PSKU", selected: false, id: 5 },
        { label: "Item Description", value: "ITDS", selected: false, id: 6 }
    ], "mapItems_loadSku_sortableList")
    const [sortItems, setSortItems] = usePersistState(null, "mapItems_loadSku_sortItems");
    const [sortOrder, setSortOrder] = usePersistState(null, "mapItems_loadSku_sortOrder");
    const [searchValue, setSearchValue] = usePersistState("", "mapItems_loadSku_searchValue")
    const [filterCriteria, setFilterCriteria] = usePersistState(null, "mapItems_loadSku_filterCriteria")

    const initialLoad = useRef(true)
    const index = useRef({});
    index.current.startIndex = 1001;
    index.current.endIndex = 2000;

    const unselectedMapRequests = useRef([]);
    const mappingRequests = useRef([]);
    const fromMarkAsdead = useRef(false);

    const disableReserve = useMemo(() => {
        let disabled = false
        memi03skuSelected.forEach((row) => {
            if (row.mappingStatus === "OTHERS" || row.mappingStatus === "AWAITING_NEW_CIC" || row.mappingStatus === "AWAITING_DIVISION_INPUT" || row.mappingStatus === "RESERVED") {
                disabled = true;
            }
        })
        return disabled
    }, [memi03skuSelected])


    const { userId } = authTokenCookie();

    useEffect(() => {
        if ((!memi03sku || Object.keys(memi03sku).length === 0) && (memi03skuPayload && Object.keys(memi03skuPayload).length > 0) && initialLoad.current) {
            console.log("resetting the data")
            memiuServices.getSourceListByPayload(memi03skuPayload)
                .then((res) => {
                    const { data } = res
                    if (data.itemType) {
                        Object.keys(data.itemType).forEach((key) => {
                            if (data.itemType[key]) {
                                setItemType(`${key}`);
                            }
                        })
                    }
                    if (data.mappingStatus) {
                        setFilterByStatus(data.mappingStatus);
                    }
                    if (data.searchCriteria) {
                        setSearchCriteria(data.searchCriteria)
                    }
                    if (data.searchCriteriaValue) {
                        setSearchValue(data.searchCriteriaValue)
                    }
                    if (data.filter) {
                        setFilterCriteria(data.filter)
                    }
                    AppData.setMemi03Sku(data);
                })
                .catch((error) => {
                    console.log("error")
                })
        }
        initialLoad.current = false;
    }, [memi03sku, memi03skuPayload, initialLoad])



    const innerComponent = (row, column) => {
        return (
            <Grid container className="innerGrid">
                <Grid item xs={3} className="innerHead">
                    Size Number
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Size UOM
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Usage Ind
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Display
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.sizeNumber}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.sizeUomCd}
                </Grid>
                <Grid item xs={3} className="innerData" style={{ display: "flex", justifyContent: "flex-start" }}>
                    {row.usage} {row.usage_Modification_Status === "MODIFIED" ? <Star style={{ fontSize: "1rem" }} /> : ""}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.display}
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Case UPC
                </Grid>
                <Grid item xs={3} className="innerHead">
                    PLU
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Department
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Created On
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.caseUpc}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.plu}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.deptName}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.createdOn}
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Hierarchy Level 1
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Hierarchy Level 2
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Hierarchy Level 3
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Shipment
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.hierarchyLevelOne}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.hierarchyLevelTwo}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.hierarchyLevelThree}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.shippedDetail}
                </Grid>
                <Grid item xs={6} className="innerHead">
                    Supplier No / Supplier Name
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Selling No
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Receiving Method
                </Grid>
                <Grid item xs={6} className="innerData">
                    {row.supplierNm} / {row.supplierNam}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.sellingMethodCd}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.recievingRandomInd}
                </Grid>
            </Grid>
        )
    }

    const columns = [
        {

            field: 'status',
            headerName: 'Status',
            headerAlign: "left",
            headerCss: "mappingTableHeader",
            colSpan: 2

        },
        {
            field: 'sku',
            headerName: 'SKU',
            headerAlign: "left",
            headerCss: "mappingTableHeader",
            sortable: true,
            renderCell: (params) => (
                <div className={`fontColor_${params.row.absDSDWhse}`} style={{ fontWeight: "bold" }}>
                    {params.value}
                </div>
            ),
            numeric: true
        },
        {
            field: 'itemDesc',
            headerName: 'Item Desc',
            headerAlign: "left",
            headerCss: "mappingTableHeader",
            sortable: true
        },

        {
            field: 'packNum',
            headerName: 'Pack',
            headerCss: "mappingTableHeader"
        },
        {
            field: 'vcf',
            headerName: 'Vcf',
            headerCss: "mappingTableHeader",
            sortable: true,
            numeric: true
        },
        {
            field: 'size',
            headerName: 'Size',
            headerCss: "mappingTableHeader"
        },
        {
            field: 'absUPCNo',
            headerName: 'UPC',
            headerCss: "mappingTableHeader",
            sortable: true,
            renderCell: (params) => (

                <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end" }}>
                    <span style={{ paddingRight: "5px" }}> {params.value.length < 6 ? params.value : `${params.value[0]}-${params.value[1]}-${params.value[2]}${params.value[3]}${params.value[4]}${params.value[5]}${params.value[6]}-${params.value[7]}${params.value[8]}${params.value[9]}${params.value[10]}${params.value[11]}`} </span>
                    {params.row.mappingStatus === "TO_BE_MAPPED" || params.row.mappingStatus === "OTHERS" || params.row.mappingStatus === "AWAITING_NEW_CIC" || params.row.mappingStatus === "AWAITING_DIVISION_INPUT" || params.row.mappingStatus === "RESERVED" ?
                        <UPCPopup
                            columns={[
                                { headerName: "UPC List", field: "upc" },
                                { field: "totalSales", headerName: "Total Sales" },
                                { field: "Last Sales Date", headerName: "L.Sales DT" }
                            ]}
                            number={params.row.upc.length}
                            color="#4bd4e2"
                            enableCheckbox={true}
                            onLoad={() => memiuServices.getUPCListDetails(companyId, divisionId, params.row.sku, filterByStatus, itemType)}
                        />
                        :
                        <UPCPopup
                            columns={[{ headerName: "UPC List", field: "upc" }]}
                            number={params.row.upc.length}
                            color="#74a1a9"
                            data={params.row.upc ? params.row.upc.map((upc) => { return { 'upc': upc } }) : []}
                        />
                    }
                </div>
            ),
            numeric: true
        },

    ];

    const createBaseMappingRequests = (mappingType, { mappingStatus, comments }) => {

        mappingRequests.current = [];
        let updatedUserID = userId;

        memi03skuSelected.forEach((sku) => {
            if (sku.upc && sku.upc.length > 0) {
                sku.upc.forEach((upc1) => {
                    if (upc1) {
                        let mappingrequest = {};
                        mappingrequest.companyID = companyId
                        mappingrequest.divisionID = divisionId;
                        mappingrequest.upc = upc1;
                        mappingrequest.sku = sku.sku;

                        if (comments) {
                            mappingrequest.comments = comments
                        }
                        mappingrequest.mappingType = mappingType;
                        mappingrequest.mappingstatus = "TO_BE_MAPPED";
                        mappingrequest.updatedUserId = updatedUserID;
                        mappingrequest.matchedItemTypeCd = sku.usage;
                        mappingrequest.targetPLU = null;
                        mappingrequest.targetEdited = false;
                        mappingrequest.dcPackDesc = null;
                        mappingrequest.dcSizeDsc = null;
                        mappingrequest.retailUnitPack = null;
                        mappingrequest.ring = null;
                        mappingrequest.hicone = null;

                        if (mappingType === "FORCE_NEW") {
                            mappingrequest.mappingstatus = "FORCE_NEW";
                        }
                        if (mappingType === "RESERVED") {
                            mappingrequest.mappingstatus = "RESERVED";
                        }

                        if (mappingStatus) {
                            mappingrequest.mappingstatus = mappingStatus
                        }
                        mappingRequests.current.push(mappingrequest);
                    }
                });
            }
        });


    }

    const action = () => {
        if (fromMarkAsdead.current && fromMarkAsdead.current == true) {
            // validatePLU(mappingRequests);
            return true;
        } else {
            let reserveAlertMsg = false;

            let disableTargetRefresh = false;
            // var actionResults = $scope.baseUrl + "perishable/actions";
            let wrapperRequest = {};
            wrapperRequest.sourceSearchRequest = {};
            wrapperRequest.sourceSearchRequest = { ...memi03skuPayload };

            wrapperRequest.sourceSearchRequest.companyId = companyId
            wrapperRequest.sourceSearchRequest.divisionId = divisionId

            wrapperRequest.targetSearchRequest = {};
            wrapperRequest.targetSearchRequest = { ...memi03cicPayload };
            wrapperRequest.mappingrequest = [];
            wrapperRequest.mappingrequest = mappingRequests.current;

            memiuServices.mappingAction(wrapperRequest)
                .then((response) => {
                    //function handles success condition
                    if (response.data) {
                        if (response.data.actionSuccessStatus == 0) {
                            AppData.setAlertBox(true, response.data.errorMessages[0]);
                            return;
                        } else {
                            if (response.data.sourceSearchRequest) {
                                let SKUResult = response.data.sourceSearchRequest.skuSearchResults;
                                let sourceCount = 0;

                                if (response.data.sourceSearchRequest.sourceCount && response.data.sourceSearchRequest.skuSearchResults) {
                                    sourceCount = response.data.sourceSearchRequest.sourceCount;

                                } else {
                                    sourceCount = 0;
                                }
                                AppData.setMemi03SkuSelected([]);
                                AppData.setMemi03Sku({ ...memi03sku, skuSearchResults: SKUResult, sourceCount: sourceCount });
                            }
                            for (var i = 0; i < response.data.mappingrequest.length; i++) {
                                if (response.data.mappingrequest[i].mappingType == "ADD_MAP" ||
                                    response.data.mappingrequest[i].mappingType == "INHERIT_MAP") {
                                    disableTargetRefresh = false;
                                    break;
                                } else {
                                    if (response.data.mappingrequest[i].mappingType == "RESERVED") {
                                        reserveAlertMsg = true;
                                    }
                                    disableTargetRefresh = true;
                                }
                            }


                            if (!disableTargetRefresh) {
                                if (response.data.targetSearchRequest) {
                                    let CICResult = response.data.targetSearchRequest.cicSearchResults;
                                    AppData.setMemi03SkuSelected([]);
                                    AppData.setmemi03Cic({ ...memi03cic, cicSearchResults: CICResult });
                                }
                            }
                            if (reserveAlertMsg) {
                                AppData.setAlertBox(true, "Selected Items moved to Reserve category.");
                                return;
                            } else {
                                AppData.setAlertBox(true, response.data.errorMessages[0]);
                                return;
                            }
                        }
                    }
                })
                .catch((response1) => {
                    //function handles error condition

                    AppData.setAlertBox(true, "There was an issue during the conversion.");
                    return;
                });
        }
    }

    //Button handlers
    const handleLetAutoMatch = () => {
        if (memi03skuSelected && memi03skuSelected.length > 0 && memi03cicSelected && memi03cicSelected.length < 1) {
            if (unselectedMapRequests.current && unselectedMapRequests.current.length > 0) {
                AppData.setAlertBox(true, "UPC's cannot be unselected for this action.");
                return;
            } else {
                createBaseMappingRequests("LET_AUTO_MATCH", {});
                action();
            }
        } else {
            AppData.setAlertBox(true, "Select only SKU to proceed.");
            return;
        }
    }

    const handleMarkDead = useCallback(() => {
        if (memi03skuSelected.length > 0 && memi03cicSelected.length === 0) {
            function markDead(comments) {
                createBaseMappingRequests("MARK_AS_DEAD", { comments });
                action();
                AppData.setConfirmationModal(false);
            }
            AppData.setConfirmationModal(true, markDead, "textBox", "The selected SKU's will be marked as dead. Enter the reason for marking as dead.")

        } else {
            AppData.setAlertBox(true, "Select only SKU to proceed.");
        }

    }, [memi03skuSelected, memi03cicSelected]);

    const handleForceNew = () => {

        let updatedUserID = userId;
        if (memi03skuSelected && memi03skuSelected.length > 0 &&
            memi03cicSelected && memi03cicSelected.length < 1) {
            if (memi03skuSelected.length > 1) {
                AppData.setAlertBox(true, "Select single SKU to proceed.");
                return;
            } else if (unselectedMapRequests.current && unselectedMapRequests.current.length > 0) {
                AppData.setAlertBox(true, "UPC's cannot be unselected for this action.");
                return;
            } else {
                let saveRequests = [];
                let skuSelected;
                let usageType = ""
                memi03skuSelected.forEach((sku) => {
                    let saveRequest = {};
                    saveRequest.sourceComponentUpc = [];
                    saveRequest.companyId = companyId;
                    saveRequest.divisionId = divisionId;
                    saveRequest.productSku = sku.sku;
                    saveRequest.cost = 0;
                    saveRequest.displayFlag = sku.display;
                    saveRequest.pack = sku.packNum;
                    saveRequest.vendorConvFactor = sku.vcf;
                    saveRequest.updatedUserId = updatedUserID;
                    skuSelected = saveRequest.productSku;

                    usageType = sku.usage;

                    sku.upc.forEach((upc) => {
                        let src = {};
                        src.upc = {};
                        src.upc = upc;
                        saveRequest.sourceComponentUpc.push(src);
                    });
                    saveRequests.push(saveRequest);

                });

                memiuServices.ForceNewCategory(saveRequests[0])
                    .then((response) => {

                        //service.mappingTargetSearch = $scope.searchTargetRequest;
                        //function handles success condition
                        if (response.data.ForceNewCategory === "A") {
                            // AugmentedDisplayer(Service.setProductSku($scope.skuSelected);
                            // AugmentedDisplayerService.setUsageType($scope.matchedUsageType);
                            // AugmentedDisplayerService.setDeptName($scope.markedSKUs[0].deptName);
                            // AugmentedDisplayerService.setKey("perishables");
                            // $.contextMenu('destroy');
                            AppData.setAugmentationServiceUsageType(usageType)
                            AppData.setAugmentationServiceDepartment(memi03skuSelected[0].deptName)
                            AppData.setAugmentationServiceKey("Perishables")
                            AppData.setMemi18({ updateaugmentationsku: [skuSelected], UpdateAugmentationManualSearch: {} })
                            history.push(RouteBase.MEMI18)
                        } else if (response.data.ForceNewCategory === "O") {
                            // OverrideMappingService.setCompanyID(service.selectedCompany.companyID);
                            // OverrideMappingService.setDivisionID(service.selectedDivision.divisionID);
                            // OverrideMappingService.setProductSku($scope.skuSelected);
                            // OverrideMappingService.setUsageType($scope.matchedUsageType);
                            // OverrideMappingService.setKey("perishables");
                            // $.contextMenu('destroy');
                            AppData.setOverideServiceKey("Perishables");
                            AppData.setOverideServiceUsageType(usageType);
                            AppData.setMemi14({ updateoverridesku: [skuSelected], UpdateOverrideManualSearch: {} })
                            history.push(RouteBase.MEMI14)
                        }
                    })
                    .catch((error) => {
                        console.log("error")
                    })
            }
        } else {
            AppData.setAlertBox(true, "Select only SKU to proceed.");
            return;
        }
    }

    const handleReserve = () => {
        if (memi03skuSelected.length > 0 && memi03cicSelected.length === 0) {
            function handlReserveOnConfirm(textValue, mappingStatus) {
                createBaseMappingRequests("RESERVED", { mappingStatus, comments: textValue })
                action();
                AppData.setConfirmationModal(false);
            }
            AppData.setConfirmationModal(true, handlReserveOnConfirm, "radioType", "Provide suitable reasons for marking it as reserved")

        } else {
            AppData.setAlertBox(true, "Select only SKU to proceed.");
        }
    }

    //Handles filtering based on popup values


    const handleFilter = (filter) => {
        setFilterCriteria(filter)
        if (itemType === "") {
            setItemType("all")
        }
        memiuServices.getSourceList(AppData, companyId, divisionId, filterByStatus, itemType, filter, searchCriteria, searchValue)
            .then((res) => {
                AppData.setMemi03SkuSelected([])
                AppData.setMemi03Sku(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }

    //Handle Load More functionality of table.

    const handleLoadMore = () => {
        memiuServices.getSourceList(AppData, companyId, divisionId, filterByStatus, itemType, filterCriteria, searchCriteria, searchValue, sortOrder, sortItems, index.current.startIndex, index.current.endIndex)
            .then((res) => {
                let data = res.data;
                data.skuSearchResults = [...memi03sku.skuSearchResults, ...data.skuSearchResults]
                data.sourceCount = data.sourceCount + memi03sku.sourceCount;
                index.current.startIndex = index.current.endIndex + 1;
                index.current.endIndex = index.current.startIndex + 1000;
                AppData.setMemi03Sku(data);
            })
            .catch((error) => {
                console.log(error)
            })
    }

    //Handles Filtering By Status

    const handleFilterByStatus = (value) => {
        setFilterByStatus(value)
        if (itemType === "") {
            setItemType("all")
        }
        memiuServices.getSourceList(AppData, companyId, divisionId, value, itemType, filterCriteria, searchCriteria, searchValue, sortOrder, sortItems)
            .then((res) => {
                AppData.setMemi03SkuSelected([])
                AppData.setMemi03Sku(res.data);
            })
            .catch((error) => {
                console.log(error)
            })

    }

    //Handle Change Usage

    const handleChangeUsage = (value) => {

        const type = value.value
        let isSameUsageType = false;
        let wrapperRequest = {};
        wrapperRequest.expenseChangeRequest = [];
        if (!memi03skuSelected || memi03skuSelected.length < 1) {
            AppData.setAlertBox(true, "Select any items from SKU.");
            return;
        } else if (memi03cicSelected && memi03cicSelected.length > 0) {
            AppData.setAlertBox(true, "Unselect CIC and proceed.");
            return;
        } else {
            if (memi03skuSelected) {
                memi03skuSelected.forEach((sku) => {
                    let expenseRequest = {};
                    expenseRequest.companyID = companyId;
                    expenseRequest.divisionID = divisionId;
                    expenseRequest.sku = sku.sku;
                    expenseRequest.expenseTypeCurrent = sku.usage;
                    expenseRequest.expeseTypeChange = type;
                    expenseRequest.updatedbyUser = userId;
                    if (type != sku.usage) {
                        wrapperRequest.expenseChangeRequest.push(expenseRequest);
                    } else {
                        isSameUsageType = true;
                    }
                });
                wrapperRequest.sourceSearchRequest = {};
                wrapperRequest.sourceSearchRequest = memi03skuPayload;

                if (isSameUsageType) {
                    AppData.setAlertBox(true, "Conversion to same Usage Ind will be omitted.");
                    isSameUsageType = false;
                }
                if (wrapperRequest.expenseChangeRequest.length == 0)
                    return;

                memiuServices.changeExpenseType(wrapperRequest)
                    .then((response) => {
                        //function handles success condition
                        if (response.data) {
                            if (response.data.sourceSearchRequest) {
                                AppData.setMemi03SkuSelected([])
                                AppData.setMemi03Sku(response.data.sourceSearchRequest)
                            }
                        }
                    }, function (response1) {
                        //function handles error condition
                    });
            }
        }

    }
    const handleSelectItemType = (e) => {
        setItemType(e.target.value)

        memiuServices.getSourceList(AppData, companyId, divisionId, filterByStatus, e.target.value, filterCriteria, searchCriteria, searchValue, sortOrder, sortItems)
            .then((res) => {
                AppData.setMemi03SkuSelected([])
                AppData.setMemi03Sku(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }

    const handleSearch = () => {
        if (itemType === "") {
            setItemType("all")
        }
        memiuServices.getSourceList(AppData, companyId, divisionId, filterByStatus, itemType, filterCriteria, searchCriteria, searchValue, sortOrder, sortItems)
            .then((res) => {
                AppData.setMemi03SkuSelected([])
                AppData.setMemi03Sku(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }

    const handleSelectedRows = (rows) => {
        AppData.setMemi03SkuSelected(rows)
    }

    const handleSortingData = (data) => {
        AppData.setMemi03Sku({ ...AppData.memi03sku, skuSearchResults: data })
    }

    const handleSortBy = (sortitems, sortorder) => {
        setSortOrder(sortorder);
        setSortItems(sortitems);
        if (itemType === "") {
            setItemType("all")
        }
        memiuServices.getSourceList(AppData, companyId, divisionId, filterByStatus, itemType, filterCriteria, searchCriteria, searchValue, sortorder, sortitems)
            .then((res) => {
                AppData.setMemi03SkuSelected([])
                AppData.setMemi03Sku(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }

    const sourceDepartment = useMemo(() => {
        if (listDepartmentSource && Array.isArray(listDepartmentSource)) {
            return listDepartmentSource.map((deptName) => {
                return { label: deptName.label, searchCriteria: "DEPT_NAME", value: deptName.value, searchLabel: "Department", inputValue: deptName.label, disabledInput: true }
            });
        }
        else {
            return []
        }
    }, [listDepartmentSource])

    return (
        <Grid container>
            <Grid item xs={12} style={{ display: "flex" }}>
                <ButtonMemi
                    startIcon={<CheckBox style={{ transform: "scale(0.9)" }} />}
                    classNameMemi="mapItemsButton mapItemsLetAutoMatchButton "
                    btnval={"Let Auto Match"}
                    btnsize="small"
                    onClick={handleLetAutoMatch}

                />
                <ButtonMemi
                    startIcon={<NotInterested style={{ transform: "scale(0.8)" }} />}
                    classNameMemi="mapItemsButton mapItemsMarkAsDeadButton"
                    btnval={"Mark As Dead"}
                    btnsize="small"
                    onClick={handleMarkDead}
                />
                <ButtonMemi
                    startIcon={<Add style={{ transform: "scale(0.9)" }} />}
                    classNameMemi="mapItemsButton  mapItemsForceNewButton"
                    btnval="Force New"
                    btnsize="small"
                    onClick={handleForceNew}
                />
                <ButtonMemi
                    startIcon={<LocalOffer style={{ transform: "scale(0.8)" }} />}
                    classNameMemi={`mapItemsButton  ${disableReserve ? "mapItemsReserveButtonDisabled" : "mapItemsReserveButton"}`}
                    btndisabled={disableReserve}
                    btnval="Reserve"
                    btnsize="small"
                    onClick={handleReserve}
                />
                <SelectMenuMemi
                    label="Change Usage"
                    options={[
                        { label: "To Resale", value: "R" },
                        { label: "To Material", value: "M" },
                        { label: "To Expense", value: "E" }
                    ]}
                    onSelect={handleChangeUsage}
                    btnsize="small"
                    classNameMemi="mapItemsButton  mapItemsChangeUsageButton"
                />

            </Grid>
            <Grid container className="mapItemsSearchField">
                <Grid item xs={12}>
                    <div className="itemTypeSection">
                        <span className="mapItemsRadioLabel"> Item Type </span>
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "all"} value="all" onClick={handleSelectItemType} /> All
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "system2"} value="system2" onClick={handleSelectItemType} /> System 2
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "system4"} value="system4" onClick={handleSelectItemType} /> System 4
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "plu"} value="plu" onClick={handleSelectItemType} /> PLU
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <SortByMemi
                            ButtonClass="mapItemsSortByButton"
                            btnsize="small"
                            sortList={sortableList}
                            setSortList={setSortableList}
                            RadioSortByLabelClass="RadioSortByLabelMapItems"
                            sortByClass="sortByBoxMapItems"
                            placement="left-start"
                            activeColor="red"
                            onClickApply={handleSortBy}
                            sortOrder={sortOrder}
                        // onClickApply={handleApply}
                        />
                    </div>
                </Grid>
                <p className="filterHdr">  Filter By Status</p>
                <Grid item xs={12} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: "10px" }}>
                    <FilterByStatus
                        options={[
                            { label: "To be Mapped", color: "#00adef", value: "TO_BE_MAPPED" },
                            { label: "Mapped", color: "#56912b", value: "MAPPED" },
                            { label: "Mark As Dead", color: "#808080", value: "MARK_AS_DEAD" },
                            { label: "Force New", color: "#e24f4b", value: "FORCE_NEW" },
                            { label: "Let Auto Match", color: "#694be2", value: "LET_AUTO_MATCH" },
                            { label: "Reserved", color: "#4be2bf", value: "RESERVED" },
                            { label: "Show All", color: "#f0ad4e", value: "SHOW_ALL" }
                        ]}
                        value={filterByStatus}
                        setValue={handleFilterByStatus}

                    />
                    <SearchFieldMemi
                        // onClickSearch
                        options={[
                            { label: "Select", searchCriteria: null, value: "", disabledInput: true },
                            { label: "Department", searchCriteria: "", children: sourceDepartment},
                            { label: "SKU", searchCriteria: "SKU_VAL" },
                            { label: "Item Description", searchCriteria: "ITEM_DESC" },
                            { label: "UPC", searchCriteria: "UPC_VAL" },
                            { label: "PLU", searchCriteria: "PLU_VAL" },
                            { label: "Total Sales", children: [{ label: "> Greater than", searchCriteria: "GREATER_THAN", value: "", searchLabel: "Total Salse >" }, { label: "< Less than", searchCriteria: "LESS_THAN", value: "", searchLabel: "Total Salse <" }, { label: "= Equal to", searchCriteria: "EQUAL_TO", value: "", searchLabel: "Total Salse =" }] },
                            { label: "Usage Ind", children: [{ label: "R (Resale)", value: "R", searchCriteria: "USAGE_TYPE", searchLabel: "Usage Ind", disabledInput: true }, { label: "M (Material)", value: "M", searchCriteria: "USAGE_TYPE", searchLabel: "Usage Ind", disabledInput: true }, { label: "E (Expense)", value: "E", searchCriteria: "USAGE_TYPE", searchLabel: "Usage Ind", disabledInput: true }] },
                            { label: "WHSE vs DSD", children: [{ label: "WHSE", value: "WHSE", searchCriteria: "WHSE_DSD", searchLabel: "WHSE vs DSD", disabledInput: true }, { label: "DSD", value: "DSD", searchCriteria: "WHSE_DSD", searchLabel: "WHSE vs DSD", disabledInput: true }] },
                            { label: "Display", children: [{ label: "Y", value: "Y", searchCriteria: "DISP", searchLabel: "Display", disabledInput: true }, { label: "N", value: "N", searchCriteria: "DISP", searchLabel: "Display", disabledInput: true }] }

                        ]}
                        searchCriteria={searchCriteria}
                        searchValue={searchValue}
                        setSearchValue={setSearchValue}
                        setSearchCriteria={setSearchCriteria}
                        onSearch={handleSearch}
                    />
                    <FilterByMapping
                        ButtonClass="mapItemsSortByButton"
                        btnsize="small"
                        filterCriteria={filterCriteria}
                        RadioSortByLabelClass="RadioSortByLabelMapItems"
                        sortByClass="filterByBoxMapItems"
                        placement="left-start"
                        onClickApply={handleFilter}
                    />
                </Grid>
            </Grid>
            <Grid container >
                <TableMappingCollapsible
                    columns={columns}
                    id="sku"
                    stickyHeader
                    data={memi03sku && memi03sku.skuSearchResults ? memi03sku.skuSearchResults : []}
                    contextOptions={[
                        { label: "Force New", onClick: handleForceNew },
                        { label: "Let Auto Match", onClick: handleLetAutoMatch },
                        { label: "Mark as Dead", onClick: handleMarkDead },
                        { label: "Suggested CIC", onClick: props.matchingTargetListing },
                        { label: "Reserve", onClick: handleReserve }
                    ]}
                    setData={handleSortingData}
                    setSelectionCriteria={(row) => { return row.mappingStatus !== "LET_AUTO_MATCH" && row.mappingStatus !== "FORCE_NEW" && row.mappingStatus !== "MAPPED" }}
                    containerClass="mappingTableContainer"
                    classNameMemi="loadSkuTable"
                    NoRowsOverlay={!memi03sku ? "Load SKU based upon Itemtype/Status/Search." : memi03sku && memi03sku.skuSearchResults ? null : ""}
                    placeholder={memi03sku ? `Showing ${memi03sku && memi03sku.sourceShowCount ? memi03sku.sourceShowCount : "0"} SKU out of ${memi03sku && memi03sku.sourceCount ? AppData.memi03sku.sourceCount : "0"} items` : ""}
                    selectedRows={memi03skuSelected}
                    setSelectedRows={handleSelectedRows}
                    collapsibleTabelContent={(row, columns) => innerComponent(row, columns)}
                    disablePagination={!memi03sku}
                    disableLoadMore={!memi03sku || !memi03sku.sourceCount || !memi03sku.sourceShowCount || memi03sku.sourceCount <= memi03sku.sourceShowCount}
                    onLoadMore={handleLoadMore}
                />
            </Grid>
        </Grid>
    )
}
