import React, { useState, useContext, memo, useRef, useEffect, useCallback, useMemo } from 'react'
import { Grid } from '@material-ui/core'
import { EditLocation, Search, Visibility, Help } from '@material-ui/icons';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import UPCPopup from 'components/UPCPopup/UPCPopup';
import FilterByMapping from 'components/FilterByMapping/FilterByMapping';
import SearchFieldMemi from 'components/SearchFieldMemi/SearchFieldMemi';
import FilterByStatus from 'components/FilterByStatus/FilterByStatus';
import TableMappingCollapsible from 'components/TableMemi/TableMappingCollapsible';
import ApplicationContext from 'context/ApplicationContext';
import { memiuServices } from 'api/memiu/memiuService';
import { authTokenCookie } from 'utils';
import MapItemsModal from 'components/MapItemsModal/MapItemsModal';
import { usePersistState } from 'hooks/usePersistState';

function LoadCic(props) {
    const [itemType, setItemType] = usePersistState("", "mapItems_loadCic_itemType");
    const [searchCriteria, setSearchCriteria] = usePersistState(null, "mapItems_loadCic_searchCriteria")
    const [filterByStatus, setFilterByStatus] = usePersistState("SHOW_ALL", "mapItems_loadCic_filterByStatus");
    const [searchValue, setSearchValue] = usePersistState("", "mapItems_loadCic_searchValue")
    const [filterCriteria, setFilterCriteria] = usePersistState(null, "mapItems_loadCic_filterCriteria")

    //Modal configs
    const [open, setOpen] = useState(false);
    const [skuTitle, setSkuTitle] = useState([]);
    const [cicBuyTitle, setCicBuyTitle] = useState("");
    const [buyData, setBuyData] = useState("");

    const index = useRef({});
    index.current.startIndex = 1001;
    index.current.endIndex = 2000

    const mappingType = useRef("")
    const AppData = useContext(ApplicationContext)
    const { companyId, divisionId, memi03cicSelected, memi03cic, memi03skuSelected, memi03sku, memi03skuPayload, memi03cicPayload, listDepartmentTarget } = AppData
    const fromMarkAsdead = useRef(false);

    const mappingRequests = useRef({});
    const validateSourceAddMapFunc = useRef(false);
    const columns = [
        {
            field: 'status',
            headerName: 'Status',
            headerAlign: "left",
            headerCss: "mappingTableHeader",
            colSpan: 2
        },
        {
            field: 'cic',
            headerName: 'CIC',
            headerAlign: "left",
            headerCss: "mappingTableHeader",
            renderCell: (params) => (
                <div className={`fontColor_${params.row.whseDsd}`} style={{ fontWeight: "bold" }}>
                    {params.value}
                </div>
            ),
            sortable: true,
            numeric: true
        },
        {
            field: 'itemDesc',
            headerName: 'Item Desc',
            headerAlign: "left",
            headerCss: "mappingTableHeader",
            sortable: true
        },

        {
            field: 'pack',
            headerName: 'Pack',
            headerCss: "mappingTableHeader"
        },
        {
            field: 'vcf',
            headerName: 'Vcf',
            headerCss: "mappingTableHeader",
            sortable: true,
            numeric: true
        },
        {
            field: 'size',
            headerName: 'Size',
            headerCss: "mappingTableHeader"
        },
        {
            field: 'upc',
            headerName: 'UPC',
            headerCss: "mappingTableHeader",
            renderCell: (params) => (
                <div style={{ display: "flex", alignItems: "center" }}>
                    <span style={{ paddingRight: "5px" }}>
                        {params.value[0].length < 6 ? params.value : `${params.value[0][0]}-${params.value[0][1]}-${params.value[0][2]}${params.value[0][3]}${params.value[0][4]}${params.value[0][5]}${params.value[0][6]}-${params.value[0][7]}${params.value[0][8]}${params.value[0][9]}${params.value[0][10]}${params.value[0][11]}`}
                    </span>
                    <UPCPopup
                        columns={[{ headerName: "UPC List", field: "upc" }]}
                        data={params.row.upc ? params.row.upc.map((upc) => { return { 'upc': upc } }) : []}
                        number={params.value.length}
                        color="#74a1a9"
                    />
                </div>
            ),
            sortable: true,
            numeric: true
        },

    ];


    useEffect(() => {
        if (memi03cic) {
            console.log(memi03cic)
            if (memi03cic.itemType) {
                Object.keys(memi03cic.itemType).forEach((key) => {
                    if (memi03cic.itemType[key]) {
                        setItemType(`${key}`);
                    }
                })
            }
            if (memi03cic.mappingStatus) {
                setFilterByStatus(memi03cic.mappingStatus);
            }
            if (memi03cic.filterCriteria) {
                setFilterCriteria(memi03cic.filterCriteria);
            }
            if (memi03cic.searchCriteria) {
                setSearchCriteria(memi03cic.searchCriteria)
            }
            if (memi03cic.searchCriteriaValue) {
                setSearchValue(memi03cic.searchCriteriaValue)
            }
        }
    }, [memi03cic])

    const createBaseMappingRequests = (skuSelected, cic) => {

        mappingRequests.current = [];
        const { userId } = authTokenCookie();
        let updatedUserID = userId;

        skuSelected.forEach((sku) => {
            if (sku.upc && sku.upc.length > 0) {
                console.log(sku)
                sku.upc.forEach((upc1) => {
                    if (upc1) {
                        let mappingrequest = {};
                        mappingrequest.companyID = companyId
                        mappingrequest.divisionID = divisionId;
                        mappingrequest.upc = upc1;
                        mappingrequest.sku = sku.sku;


                        mappingrequest.mappingType = mappingType.current;
                        mappingrequest.mappingstatus = "MAPPED";
                        mappingrequest.updatedUserId = updatedUserID;
                        mappingrequest.matchedItemTypeCd = sku.usage;
                        mappingrequest.targetPLU = null;
                        mappingrequest.targetEdited = false;
                        mappingrequest.dcPackDesc = null;
                        mappingrequest.dcSizeDsc = null;
                        mappingrequest.retailUnitPack = null;
                        mappingrequest.ring = null;
                        mappingrequest.hicone = null;
                        if (cic) {
                            cic.forEach((cic) => {
                                mappingrequest.cic = cic.cic
                            })
                        }
                        mappingRequests.current.push(mappingrequest);
                    }
                });
            }
        })
    }

    const handleFilter = useCallback((filter) => {
        setFilterCriteria(filter)
        AppData.setMemi03CicSelected([])

        if (itemType === "") {
            setItemType("all")
        }
        memiuServices.getTargetList(AppData, companyId, divisionId, filterByStatus, itemType, filter, searchCriteria, searchValue)
            .then((res) => {
                AppData.setMemi03Cic(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }, [itemType, AppData, companyId, divisionId, filterByStatus, itemType, searchCriteria, searchValue])

    const innerComponent = (row, column) => {
        return (
            <Grid container className="innerGrid">
                <Grid item xs={6} className="innerHead">
                    Sign & Scale Description
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Size
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Size UOM
                </Grid>
                <Grid item xs={6} className="innerData">
                    {row.sign_scale}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.size}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.size_uom}
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Usage Type
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Usage Ind
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Status Corp
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Display
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.usage}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.usage}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.statusCorp}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.display}
                </Grid>
                <Grid item xs={3} className="innerHead">
                    SMIC
                </Grid>
                <Grid item xs={3} className="innerHead">
                    VOC
                </Grid>
                <Grid item xs={3} className="innerHead">
                    PLU
                </Grid>
                <Grid item xs={3} className="innerHead">
                    Department
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.smic}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.voc}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.plu}
                </Grid>
                <Grid item xs={3} className="innerData">
                    {row.deptName}
                </Grid>
                <Grid item xs={6} className="innerHead">
                    Vendor Code-Vendor Name
                </Grid>
                <Grid item xs={6} className="innerHead">
                    ROG Count & more..
                </Grid>
                <Grid item xs={12} className="innerData">
                    <Help style={{ color: "grey", transform: "scale(0.8)" }} />
                </Grid>
            </Grid>
        )
    }


    const handleSortingData = useCallback((data) => {
        AppData.setMemi03Cic({ ...AppData.memi03cic, cicSearchResults: data })
    }, [AppData.memi03cic])

    const handleFilterByStatus = useCallback((value) => {
        setFilterByStatus(value)
        if (itemType === "") {
            setItemType("all")
        }
        AppData.setMemi03CicSelected([])
        memiuServices.getTargetList(AppData, companyId, divisionId, value, itemType, filterCriteria)
            .then((res) => {
                AppData.setMemi03Cic(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }, [AppData, companyId, divisionId, itemType, filterCriteria])

    const handleSelectItemType = useCallback((e) => {
        setItemType(e.target.value)
        AppData.setMemi03CicSelected([])

        memiuServices.getTargetList(AppData, companyId, divisionId, filterByStatus, e.target.value, filterCriteria, searchCriteria, searchValue)
            .then((res) => {
                AppData.setMemi03Cic(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }, [itemType, AppData, companyId, divisionId, filterByStatus, filterCriteria, searchCriteria, searchValue])

    const handleSelectedRows = useCallback((rows) => {
        console.log(rows)
        AppData.setMemi03CicSelected(rows)
    }, [])

    const handleSearch = useCallback(() => {
        if (itemType === "") {
            setItemType("all")
        }
        AppData.setMemi03CicSelected([])
        memiuServices.getTargetList(AppData, companyId, divisionId, filterByStatus, itemType, filterCriteria, searchCriteria, searchValue)
            .then((res) => {
                AppData.setMemi03Cic(res.data);
            })
            .catch((error) => {
                console.log(error)
            })
    }, [itemType, AppData, companyId, divisionId, filterByStatus, filterCriteria, searchCriteria, searchValue])

    const validateAddMapBasedOnUPCSystem = useCallback((from) => {
        let requests = mappingRequests.current;
        for (let k = 0; k < requests.length; k++) {
            if (requests[k] && requests[k].upc) {
                let upc = requests[k].upc;
                if (from == "source") {
                    if (upc && (upc[1] == "2" || upc[1] == "4")) {
                        validateSourceAddMapFunc.current = true;
                        break;
                    } else {
                        validateSourceAddMapFunc.current = false;
                        break;
                    }
                }
            }
        }
    }, [mappingRequests.current])

    const additionalPLUpopup = useCallback((type) => {
        let productSKUs = memi03skuSelected.map((value) => {
            return value.sku
        });
        let skuModalTitle = memi03skuSelected.map((value) => {
            return `${value.sku} / ${value.itemDesc}`
        });
        let cicBuyModalTitle = `${memi03cicSelected[0].cic} / ${memi03cicSelected[0].itemDesc}`;
        let reqData = { companyID: companyId, divisionID: divisionId, productSKUs: productSKUs, buyingCic: memi03cicSelected[0].cic, sellingCic: null, whseDsd: memi03cicSelected[0].whseDsd }
        memiuServices.loadOnMapEditFields(reqData).then((res) => {
            let { data } = res;
            setSkuTitle(skuModalTitle);
            setCicBuyTitle(cicBuyModalTitle);
            setBuyData(data.buyDto);
            setOpen(true);
        }).catch((error) => {
            console.log(error)
            AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
        });
    }, [AppData.setAlertBox, companyId, divisionId, mappingRequests, memi03cicSelected, memi03skuSelected])

    const handlePopupAction = (buyData) => {

        let skuSelected = mappingRequests.current.map((value) => {
            return { ...value, ...buyData, targetEdited: true }
        });




        // // AppData.setMappingModal(false)
        if (Object.keys(buyData).length > 0) {


            if (fromMarkAsdead.current && fromMarkAsdead.current === true) {
                // validatePLU(mappingRequests);
                return true;
            } else {
                let reserveAlertMsg = false;

                let disableTargetRefresh = false;
                // var actionResults = $scope.baseUrl + "perishable/actions";
                let wrapperRequest = {};
                wrapperRequest.sourceSearchRequest = {};
                wrapperRequest.sourceSearchRequest = { ...memi03skuPayload };

                wrapperRequest.sourceSearchRequest.companyId = companyId
                wrapperRequest.sourceSearchRequest.divisionId = divisionId

                wrapperRequest.targetSearchRequest = {};
                wrapperRequest.targetSearchRequest = { ...memi03cicPayload };
                wrapperRequest.mappingrequest = [];
                wrapperRequest.mappingrequest = skuSelected

                setOpen(false)
                memiuServices.mappingAction(wrapperRequest)
                    .then((response) => {
                        //function handles success condition
                        if (response.data) {
                            if (response.data.actionSuccessStatus == 0) {
                                AppData.setAlertBox(true, response.data.errorMessages[0]);
                                return;
                            } else {
                                if (response.data.sourceSearchRequest) {
                                    let SKUResult = response.data.sourceSearchRequest.skuSearchResults;
                                    let sourceCount = 0;
                                    if (response.data.sourceSearchRequest && response.data.sourceSearchRequest.sourceCount && response.data.sourceSearchRequest.skuSearchResults) {
                                        sourceCount = response.data.sourceSearchRequest.sourceCount;
                                    } else {
                                        sourceCount = 0;
                                    }
                                    AppData.setMemi03Sku({ ...response.data.sourceSearchRequest, skuSearchResults: SKUResult, sourceCount: sourceCount });
                                }
                                for (var i = 0; i < response.data.mappingrequest.length; i++) {
                                    if (response.data.mappingrequest[i].mappingType == "ADD_MAP" ||
                                        response.data.mappingrequest[i].mappingType == "INHERIT_MAP") {
                                        disableTargetRefresh = false;
                                        break;
                                    } else {
                                        if (response.data.mappingrequest[i].mappingType == "RESERVED") {
                                            reserveAlertMsg = true;
                                        }
                                        disableTargetRefresh = true;
                                    }
                                }
                                if (!disableTargetRefresh) {
                                    if (response.data.targetSearchRequest) {
                                        let CICResult = response.data.targetSearchRequest.cicSearchResults;
                                        let targetCount = 0;
                                        if (response.data.targetSearchRequest && response.data.targetSearchRequest.targetCount && response.data.targetSearchRequest.cicSearchResults) {
                                            targetCount = response.data.targetSearchRequest.targetCount;
                                        } else {
                                            targetCount = 0;
                                        }
                                        AppData.setMemi03Cic({ ...response.data.targetSearchRequest, cicSearchResults: CICResult, targetCount: targetCount });
                                    }
                                }
                                if (reserveAlertMsg) {
                                    AppData.setAlertBox(true, "Selected Items moved to Reserve category.");
                                    return;
                                } else {
                                    AppData.setAlertBox(true, response.data.errorMessages[0]);
                                    return;
                                }
                            }
                        }
                    })
                    .catch((response1) => {
                        //function handles error condition
                        console.log(response1)
                        AppData.setAlertBox(true, "There was an issue during the conversion.");
                        return;
                    });
            }
        }
    }

    const validatePLU = useCallback(() => {
        let results = mappingRequests.current;
        let addPlu = false;
        if (results && results.length > 0) {
            results.forEach((sku) => {
                if (sku && sku.upc) {
                    if (sku.upc <= 99999 && sku.mappingType !== "MARK_AS_DEAD") {
                        addPlu = true;
                    }
                }
            });
        }
        if (addPlu) {
            additionalPLUpopup("ADDMAP");
        } else {
            additionalPLUpopup("INHERITMAP");
        }
    }, [mappingRequests.current, memi03skuSelected, memi03cicSelected])

    const handleAddInheritMap = useCallback((type) => {
        let markedProductSrc = "";
        if (type === "INHERITMAP")
            mappingType.current = "INHERIT_MAP";
        else
            mappingType.current = "ADD_MAP";
        if (memi03skuSelected && memi03skuSelected.length > 0 && memi03cicSelected && memi03cicSelected.length > 0) {
            for (var i = 0; i < memi03skuSelected.length; i++) {
                if (memi03skuSelected[i].absDSDWhse !== memi03skuSelected[memi03skuSelected.length - 1].absDSDWhse) {
                    AppData.setAlertBox(true, "Different product source SKUs has been selected.");
                    return;
                }
                if (memi03cicSelected[0].whseDsd !== ("WHSE-DSD" || "whse-dsd")) {
                    if (memi03skuSelected[i].absDSDWhse !== memi03cicSelected[0].whseDsd) {
                        AppData.setAlertBox(true, "Select same product source items for SKU and CIC.");
                        return;
                    }
                }
                if (memi03skuSelected[i].usage !== memi03skuSelected[memi03skuSelected.length - 1].usage) {
                    AppData.setAlertBox(true, "Different usage ind SKUs has been selected.");
                    return;
                }
                if (memi03skuSelected[i].usage !== memi03cicSelected[0].itemUSageInd) {
                    AppData.setAlertBox(true, "SKU's Usage ind and CIC's Item usage should be same.");
                    return;
                }
                if ((memi03skuSelected[i].absDSDWhse == memi03cicSelected[0].whseDsd) || memi03cicSelected[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
                    //check for similar values and store in a boolean string
                    markedProductSrc = memi03skuSelected[i].absDSDWhse;
                }
            }
        }
        let validationMsg = "System 2 & 4 UPC's cannot be processed in add map. Do you want to proceed?";
        if (markedProductSrc == "WHSE" && (memi03skuSelected.length > 1 || memi03cicSelected.length > 1)) {
            AppData.setAlertBox(true, "Invalid selection. WHSE item only allows mapping of one SKU with one CIC.");
            return;
        } else {
            if (memi03skuSelected && memi03skuSelected.length > 0) {
                if (memi03cicSelected && memi03cicSelected.length < 1) {
                    AppData.setAlertBox(true, "Atleast one CIC must be selected.");
                    return;
                }
                if (memi03cicSelected && memi03cicSelected.length > 1) {
                    AppData.setAlertBox(true, "Only one CIC must be selected.");
                    return;
                }
                if (markedProductSrc == "WHSE" && memi03cicSelected && memi03cicSelected[0].expBtnClass == "bgGreen") {
                    AppData.setAlertBox(true, "WHSE items cannot be mapped again.");
                    return;
                }

                if (memi03cicSelected) {
                    createBaseMappingRequests(memi03skuSelected, memi03cicSelected, type);
                    console.log(memi03skuSelected, memi03cicSelected)
                    if (mappingRequests && mappingRequests.current && mappingRequests.current.length > 0) {
                        validateAddMapBasedOnUPCSystem("source");
                        if (type === "ADDMAP") {
                            if (validateSourceAddMapFunc.current) {
                                AppData.setConfirmationModal(true, validatePLU, "confirmationBox", validationMsg)
                            } else {
                                validatePLU()
                            }
                        }
                        else {
                            additionalPLUpopup("INHERITMAP");
                        }
                    }
                }
                // if ($scope.upcClicked) {
                //     if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
                //         $scope.createSubMappingRequests($scope.unselectedMapRequests, $scope.mappingRequests);
                //         if ($scope.mappingRequests && $scope.mappingRequests.length > 0) {
                //             $scope.validateAddMapBasedOnUPCSystem($scope.mappingRequests, "source");
                //         } else {
                //             $scope.validateSourceAddMapFunc = false;
                //         }
                //         if ($scope.validateSourceAddMapFunc) {
                //             alertify.confirm(validationMsg, function (e) {
                //                 if (e) {
                //                     $scope.markAsDeadPrompt($scope.unselectedMapRequests, "addmap");
                //                 } else {
                //                     //code incase of cancel
                //                     $scope.upcClicked = false;
                //                 }
                //             });
                //         } else {
                //             $scope.markAsDeadPrompt($scope.unselectedMapRequests, "addmap");
                //         }
                //     } else {
                //         $scope.validateAddMapBasedOnUPCSystem($scope.mappingRequests, "source");
                //         if ($scope.validateSourceAddMapFunc) {
                //             alertify.confirm(validationMsg, function (e) {
                //                 if (e) {
                //                     $scope.validatePLU($scope.mappingRequests);
                //                 } else {
                //                     //code incase of cancel
                //                     $scope.upcClicked = false;
                //                 }
                //             });
                //         } else {
                //             validatePLU("ADD_MAP");
                //         }
                //     }
                // }
            } else {
                AppData.setAlertBox(true, "Select SKU and CIC to proceed.");
                return;
            }
        }
    }, [validateSourceAddMapFunc, memi03skuSelected, memi03cicSelected, mappingRequests])

    const targetDepartment = useMemo(() => {
        if (listDepartmentTarget && Array.isArray(listDepartmentTarget)) {
            return listDepartmentTarget.map((deptName) => {
                return { label: deptName.label, searchCriteria: "DEPT_NAME", value: deptName.value, searchLabel: "Department", inputValue: deptName.label, disabledInput: true }
            });
        }
        else {
            return []
        }
    }, [listDepartmentTarget])

    return (
        <Grid container>
            <Grid item xs={2} className="mapItemsHeader">
                Map Items
            </Grid>
            <Grid item xs={10} style={{ display: "flex" }}>
                <ButtonMemi
                    startIcon={<Search />}
                    classNameMemi="mapItemsButton mapItemsSuggestedCicButton "
                    btnval={"Suggested CIC"}
                    btnsize="small"
                    onClick={props.matchingTargetListing}

                />
                <ButtonMemi
                    startIcon={<Visibility style={{ transform: "scale(0.8)" }} />}
                    classNameMemi="mapItemsButton mapItemsReserveButton"
                    btnval={"Inherit Map"}
                    btnsize="small"
                    title="The source will inherit all the UPCs from the target side. The UPCs on the source side will be ignored and the item will be converted with the UPCs available in SSIMS."
                    onClick={() => handleAddInheritMap("INHERIT_MAP")}
                />
                <ButtonMemi
                    startIcon={<EditLocation style={{ transform: "scale(0.9)" }} />}
                    classNameMemi="mapItemsButton mapItemsReserveButton"
                    btnval="Add Map"
                    btnsize="small"
                    title="All the selected UPC from the source side will be set up into SSIMS. All the extra UPCs will be setup into SSIMS by MIDAS."
                    onClick={() => handleAddInheritMap("ADD_MAP")}
                />
            </Grid>
            <Grid container className="mapItemsSearchField" >
                <Grid item xs={12}>
                    <div className="itemTypeSection">
                        <span className="mapItemsRadioLabel"> Item Type </span>
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "all"} value="all" onClick={handleSelectItemType} /> All
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "system2"} value="system2" onClick={handleSelectItemType} /> System 2
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "system4"} value="system4" onClick={handleSelectItemType} /> System 4
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType === "plu"} value="plu" onClick={handleSelectItemType} /> PLU
                    </div>
                </Grid>
                <p className="filterHdr"> Filter By Status</p>
                <Grid item xs={12} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: "10px" }}>
                    <FilterByStatus
                        type="cic"
                        options={[
                            { label: "Mapped", color: "#56912b", value: "MAPPED" },
                            { label: "To be Mapped", color: "#00adef", value: "TO_BE_MAPPED" },
                            { label: "Show All", color: "#f0ad4e", value: "SHOW_ALL" }
                        ]}
                        value={filterByStatus}
                        setValue={handleFilterByStatus}
                    />
                    <SearchFieldMemi
                        options={[
                            { label: "Select", searchCriteria: null, value: "", disabledInput: true },
                            { label: "Department", children:targetDepartment},
                            { label: "CIC", searchCriteria: "CIC_VAL", },
                            { label: "Item Description", searchCriteria: "ITEM_DESC" },
                            { label: "UPC", searchCriteria: "UPC_VAL" },
                            { label: "PLU", searchCriteria: "PLU_VAL" },
                            { label: "Total Sales", children: [{ label: "> Greater than", searchCriteria: "GREATER_THAN", value: "", searchLabel: "Total Salse >" }, { label: "< Less than", searchCriteria: "LESS_THAN", value: "", searchLabel: "Total Salse <" }, { label: "= Equal to", searchCriteria: "EQUAL_TO", value: "", searchLabel: "Total Salse =" }] },
                            { label: "Usage Ind", children: [{ label: "R (Resale)", value: "R", searchCriteria: "USAGE_TYPE", searchLabel: "Usage Ind", disabledInput: true }, { label: "M (Material)", value: "M", searchCriteria: "USAGE_TYPE", searchLabel: "Usage Ind", disabledInput: true }, { label: "E (Expense)", value: "E", searchCriteria: "USAGE_TYPE", searchLabel: "Usage Ind", disabledInput: true }] },
                            { label: "WHSE vs DSD", children: [{ label: "WHSE", value: "WHSE", searchCriteria: "WHSE_DSD", searchLabel: "WHSE vs DSD", disabledInput: true }, { label: "DSD", value: "DSD", searchCriteria: "WHSE_DSD", searchLabel: "WHSE vs DSD", disabledInput: true }] },
                            { label: "Display", children: [{ label: "Y", value: "Y", searchCriteria: "DISP", searchLabel: "Display", disabledInput: true }, { label: "N", value: "N", searchCriteria: "DISP", searchLabel: "Display", disabledInput: true }] }
                        ]}
                        searchCriteria={searchCriteria}
                        searchValue={searchValue}
                        setSearchValue={setSearchValue}
                        setSearchCriteria={setSearchCriteria}
                        onSearch={handleSearch}
                    />
                    <FilterByMapping
                        ButtonClass="mapItemsSortByButton"
                        btnsize="small"
                        RadioSortByLabelClass="RadioSortByLabelMapItems"
                        sortByClass="filterByBoxMapItems"
                        placement="left-start"
                        type="cic"
                        onClickApply={handleFilter}
                        filterCriteria={filterCriteria}
                    />
                </Grid>
            </Grid>
            <Grid container>
                <TableMappingCollapsible
                    id="cic"
                    columns={columns}
                    stickyHeader
                    containerClass="CicTableContainer"
                    data={memi03cic && memi03cic.cicSearchResults ? memi03cic.cicSearchResults : []}
                    classNameMemi="loadSkuTable"
                    NoRowsOverlay={!memi03cic ? "Load CIC based upon Itemtype/Status/Search." : AppData.memi03cic && AppData.memi03cic.cicSearchResults ? null : ""}
                    placeholder={memi03cic ? `Showing ${AppData.memi03cic && AppData.memi03cic.targetShowCount ? AppData.memi03cic.targetShowCount : ""} CIC out of ${AppData.memi03cic && AppData.memi03cic.targetCount ? AppData.memi03cic.targetCount : ""} items` : ""}
                    contextOptions={[
                        { label: "Inherit", onClick: () => handleAddInheritMap("INHERIT_MAP") },
                        { label: "Add Map", onClick: () => handleAddInheritMap("ADD_MAP") }
                    ]}
                    collapsibleTabelContent={(row, columns) => innerComponent(row, columns)}
                    setData={handleSortingData}
                    selectedRows={memi03cicSelected}
                    setSelectedRows={handleSelectedRows}
                    setSelectionCriteria={(row) => { return row.mappingStatus !== "LET_AUTO_MATCH" && row.mappingStatus !== "FORCE_NEW" }}
                    disableLoadMore={true}
                    disablePagination={true}
                />
            </Grid>
            <MapItemsModal
                open={open}
                onSubmit={(buyData) => handlePopupAction(buyData)}
                onClose={() => setOpen(false)}
                skuTitle={skuTitle}
                cicBuyTitle={cicBuyTitle}
                data={buyData}
            />

        </Grid>
    )
}

export default memo(LoadCic)