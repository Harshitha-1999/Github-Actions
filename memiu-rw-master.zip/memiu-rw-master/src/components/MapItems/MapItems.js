import React, { memo, useContext } from "react";
import { Grid } from "@material-ui/core";
import LoadCic from './LoadCic';
import LoadSku from './LoadSku';
import { memiuServices } from "api/memiu/memiuService";
import ApplicationContext from "context/ApplicationContext";
export const MappItems = (props) => {
  const AppData = useContext(ApplicationContext);
  const { memi03skuSelected, memi03cicSelected } = AppData;
  const matchingTargetListing = () => {
    let matchingTargetInputRequest = {};

    if (memi03skuSelected && memi03skuSelected.length > 1) {
      AppData.setAlertBox(true, "More than one SKU has been selected!");
      return;
    } else if (!memi03skuSelected || memi03skuSelected.length < 1) {
      AppData.setAlertBox(true, "Select any items from SKU.");
      return;
    } else if (memi03cicSelected && memi03cicSelected.length > 0) {
      AppData.setAlertBox(true, "Unselect CIC and proceed.");
      return;
    } else {
      if (memi03skuSelected) {
        memi03skuSelected.forEach((sku) => {
          matchingTargetInputRequest.upcs = sku.upc;
          if (sku.absDSDWhse == "WHSE") {
            matchingTargetInputRequest.whseDsd = "W";
          } else if (sku.absDSDWhse == "DSD") {
            matchingTargetInputRequest.whseDsd = "D";
          }
          matchingTargetInputRequest.dept = sku.deptName;
        });

        memiuServices.matchingTargetList(matchingTargetInputRequest)
          .then((response) => {
            //function handles success condition
            if (response.data) {
              let resData = response.data
              resData.targetCount = Array.isArray(resData.cicSearchResults) ? resData.cicSearchResults.length : 0
              AppData.setMemi03Cic(resData);
              AppData.setMemi03CicSelected([]);
            }
          })
          .catch((error) => {
            console.log(error)
          })
      }
    }
  };
  return (
    <Grid
      container
      style={{ padding: "3px" }}
    >
      <Grid item md={6} xs={12}>
        <LoadSku matchingTargetListing={matchingTargetListing} />
      </Grid>
      <Grid item md={6} xs={12} style={{ paddingLeft: "5px" }}>
        <LoadCic matchingTargetListing={matchingTargetListing} />
      </Grid>
    </Grid>

  );

};

export default memo(MappItems);


