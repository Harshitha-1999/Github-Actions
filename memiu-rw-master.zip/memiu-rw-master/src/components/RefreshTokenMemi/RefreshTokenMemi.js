import React, { useContext, useEffect } from "react";
import ApplicationContext from "../../context/ApplicationContext";
import { Paper } from "@material-ui/core";
import {
  configurationVarsAxios,
} from "../../api/memiuAxiosInstances/memiuAxiosInstances";

function RefreshTokenMemi() {
  const AppData = useContext(ApplicationContext);
  const paperStyle = {
    border: "1px solid grey",
    padding: 20,
    width: "80%",
    margin: "50px auto",
  };

  useEffect(() => {

    //////////////configurationVarsAxios//////////////////////////////////////////////////
    configurationVarsAxios.get("/").then((res) => {

      //get the last token and print to console
      //intercept and set the time in the lastTokenRefresh before setting the data.
      var lastToken = res.data.filter(function (el) {
        return el.name === 'lastTokenRefresh';
      });
      var currentTime = new Date();
      res.data[0].value = currentTime.getTime();
      // sets the new time 
      AppData.setConfigurationVars(res.data);
    });
    ////////////configurationVarsAxios///////////////////////////////////////////////////////

  }, [AppData]);


  return (
    <>

      <Paper elevation={3} style={paperStyle}>
        <h2 className="AppTitle">Global Application Context Data</h2>
        <div>
          <h2 className="AppTitle">Configuration Vars</h2>
          <div className="auto-card">
            <table>
              <thead>
                <tr>
                  <th>Configuration Vars</th>
                </tr>
              </thead>
              <tbody>
                {AppData.configurationVars.map((d) => {
                  return (
                    <tr key={d.id}>
                      <td>{d.name}=</td>
                      <td>{d.value} </td>

                      <td> {d.description}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </Paper>
    </>
  );
}

export function RequestNewRefreshTokenMemi() {
  const AppData = useContext(ApplicationContext);

  // request the variable and set the refresh token time.
  //////////////configurationVarsAxios//////////////////////////////////////////////////
  configurationVarsAxios.get("/").then((res) => {
    //get the last token and print to console
    //intercept and set the time in the lastTokenRefresh before setting the data.
    var lastToken = res.data.filter(function (el) {
      return el.name === 'lastTokenRefresh';
    });
    var currentTime = new Date();

    //only request and set a token if more than 200 secconds old
    if (currentTime - lastToken > 200) {
      res.data[0].value = currentTime.getTime();


      // sets the new time in config token config vars
      AppData.setConfigurationVars(res.data);
    }

  });
  ////////////configurationVarsAxios///////////////////////////////////////////////////////


  return "new"
};


export default RefreshTokenMemi;
