import React from "react";
import PropTypes from "prop-types";
import Button from "@material-ui/core/Button";

function ButtonMemi(props) {

  return (
    <Button
      color={props.btncolor}
      variant={props.btnvariant}
      size={props.btnsize}
      startIcon={props.startIcon}
      endIcon={props.endIcon}
      onClick={props.onClick}
      disabled={props.btndisabled}
      className={props.classNameMemi}
      id={props.idCss}
      title={props.title}
    >
      {props.btnval}
    </Button>
  );
}

export default ButtonMemi;

ButtonMemi.propTypes = {
  btncolor: PropTypes.string,
  btnval: PropTypes.any,
  btnvariant: PropTypes.any,
  btnsize: PropTypes.string,
  startIcon: PropTypes.node,
  endIcon: PropTypes.node,
  onClick: PropTypes.func,
  btndisabled: PropTypes.bool,
  classNameMemi: PropTypes.string,
  idCss: PropTypes.string
};
