import React, { useContext, useEffect, useState, useCallback } from 'react';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";
import { OutlinedInput } from "@material-ui/core";

export default function ConfirmationModalMemi() {

    const AppData = useContext(ApplicationContext);

    const [searchValue, setSearchVal] = useState("");

    const [itemType, setItemType] = useState("OTHERS");

    const onClickOk = () => {

        if (searchValue === "" && AppData.confirmationModal.type === "textbox")
            document.getElementById("textboxFieldId").focus();
        else if (AppData.confirmationModal.type === "radioType") {
            AppData.setConfirmationModalSearch(searchValue, itemType);
            if (typeof (AppData.confirmationModal.onClickOk) === "function") {
                AppData.confirmationModal.onClickOk(searchValue, itemType)
            }
        }
        else {
            AppData.setConfirmationModalSearch(searchValue);
            if (typeof (AppData.confirmationModal.onClickOk) === "function") {
                AppData.confirmationModal.onClickOk(searchValue)
            }

        }

        AppData.setConfirmationModal(false);
        AppData.setConfirmationModalSearch("");
        setItemType("OTHERS")
        setSearchVal("");
    }

    const onClickCancel = () => {
        AppData.setConfirmationModal(false);
        AppData.setConfirmationModalSearch("");
        setItemType("OTHERS")
        setSearchVal("");
    }

    useEffect(() => {
        let textElement = document.getElementById("textboxFieldId");

        if (textElement !== null)
            document.getElementById("textboxFieldId").focus();
    }, []);

    const handleSelectItemType = useCallback((e) => {

        if (e.target.checked)
            setItemType(e.target.value);

    }, [itemType]);

    const content = (
        <>
            <div>
                <div style={{ marginBottom: "10px" }}>
                    <span className={"textboxModalTitle"}> {AppData.confirmationModal.title}</span>
                </div>

                {
                    AppData.confirmationModal.type === "textBox" ?
                        <div style={{ marginBottom: "15px" }}>

                            <OutlinedInput
                                placeholder=""
                                className="textboxModalField"
                                id="textboxFieldId"
                                autoFocus={true}
                                value={searchValue}
                                onChange={(e) => setSearchVal(e.target.value)}
                            />
                        </div> : AppData.confirmationModal.type === "radioType" ? <div>
                            <div className={"radioBtn"}>
                                <div className={"confirmationRadioCls"}>
                                    <input type="radio" checked={itemType === "AWAITING_NEW_CIC"} value="AWAITING_NEW_CIC" onClick={handleSelectItemType} />Need New CIC Created
                                </div>
                                <div className={"confirmationRadioCls"}>
                                    <input type="radio" checked={itemType === "AWAITING_DIVISION_INPUT"} value="AWAITING_DIVISION_INPUT" onClick={handleSelectItemType} />Need Input From Division
                                </div>
                                <div className={"confirmationRadioCls"}>
                                    <input type="radio" checked={itemType === "OTHERS"} value="OTHERS" onClick={handleSelectItemType} />Others
                                </div>
                            </div>
                            <div style={{ marginBottom: "15px" }}>

                                <OutlinedInput
                                    placeholder="Comments..."
                                    className="textboxModalField"
                                    id="textboxFieldId"
                                    autoFocus={true}
                                    value={searchValue}
                                    onChange={(e) => setSearchVal(e.target.value)}
                                />
                            </div>
                        </div> : ""
                }
                <div style={{ display: "flex", columnGap: "10px", marginLeft: "135px" }}>
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton textboxModalCancelBtn"
                        btnval="Cancel"
                        onClick={onClickCancel}
                    />
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton textboxOkBtn"
                        btnval="OK"
                        onClick={onClickOk}
                    />
                </div>
            </div>
        </>

    )

    return (
        <>
            <ModalPopup
                open={AppData.confirmationModal.open}
                classNameMemi="textboxModalMemi"
                popupContentClass="texboxModalContent"
                popupActionClass="textboxModalAction"
                maxWidth="xs"
                fullWidth
                popupContent={content}
            />
        </>

    )
}
