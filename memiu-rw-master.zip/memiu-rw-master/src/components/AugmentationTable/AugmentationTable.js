import React, { useContext, useState } from 'react'
import { Grid } from '@material-ui/core'
import SearchBarSkuUpc from 'components/SearchBarSkuUpc/SearchBarSkuUpc'
import TableMemi from 'components/TableMemi/TableMemi';
import NoRecordsDisplay from 'components/NoRecordsDisplay/NoRecordsDisplay';
import ApplicationContext from "../../context/ApplicationContext";
import { memiuServices } from 'api/memiu/memiuService';

import FileUploadMoodalNewUPC from 'components/FileUploadModalMemi/FileUploadModalNewUPC';
import { useHistory } from 'react-router';
import { RouteBase } from 'routes/constants';

export default function AugmentationTable(props) {
    const AppData = useContext(ApplicationContext);
    const history = useHistory();
    const departments = AppData.memi17 && AppData.memi17.data ? AppData.memi17.data.map((x) => {
        return { label: x.deptName, value: `${x.deptName} ${x.deptCode}` }
    }) : []
    const [openFileModal, setOpenFileModal] = useState(false);
    const columns = [
        {
            field: "deptName",
            headerName: " ",
            sortable: false,
            flex: 0.28,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            disableColumnSelector: false,
            disableColumnFilter: false,
            disableColumnMenu: false
        },
        {
            field: "totalWHSERecords",
            headerName: "WHSE",
            sortable: false,
            headerClassName: "HeaderModelLikeMatchTable",
            disableColumnSelector: false,
            disableColumnFilter: false,
            disableColumnMenu: false,
            headerAlign: "left",
            flex: 0.1,
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "N", "W")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "totalDSDRecords",
            headerName: "DSD",
            sortable: false,
            flex: 0.1,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "N", "D")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "totalRecord",
            headerName: "Total",
            sortable: false,
            width: 100,
            flex: 0.1,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "N", "A")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "unReviwExcelDownload",
            headerName: " ",
            sortable: false,
            width: 215,
            headerAlign: "left",
            flex: 0.1,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span >
                    <img src="/export_to_excel_icon.png" alt="/" onClick={() => handleExcelDownload(params, "totalRecord", 'A', 'N')} title={params.row.totalRecord > 0 ? "Export To Excel" : ""} style={{cursor:params.row.totalRecord > 0 ? "pointer" : "default"}}  />
                    &nbsp; &nbsp;
                    <img src="./upload_from_excel_icon.png" alt="/" onClick={() => handleFileUpload(params.row.totalRecord)}  style={{cursor:params.row.totalRecord >= 0 ? "pointer" : "default"}} title="Upload from Excel"/>
                </span>

            )


        },
        {
            field: "reviewWHSEItmCnt",
            headerName: "WHSE",
            sortable: false,
            headerClassName: "HeaderModelLikeMatchTable",
            disableColumnSelector: false,
            disableColumnFilter: false,
            disableColumnMenu: false,
            headerAlign: "left",
            flex: 0.1,
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "R", "W")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "reviewDSDItmCnt",
            headerName: "DSD",
            sortable: false,
            flex: 0.1,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "R", "D")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "reviewItmCnt",
            headerName: "Total",
            sortable: false,
            width: 100,
            flex: 0.1,
            headerAlign: "left",
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "R", "A")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "ReviwitmExcelDownload",
            headerName: " ",
            sortable: false,
            width: 215,
            headerAlign: "left",
            flex: 0.1,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span onClick={() => handleExcelDownload(params, "reviewItmCnt", 'A', 'R')}>
                    <img src="/export_to_excel_icon.png" alt="/" title={params.row.reviewItmCnt > 0 ? "Export To Excel" : ""} style={{cursor:params.row.reviewItmCnt > 0 ? "pointer" : "default"}} />
                </span>
            )
        },

        {
            field: "completedWHSEItmCnt",
            headerName: "WHSE",
            sortable: false,
            width: 100,
            headerAlign: "left",
            flex: 0.1,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "C", "W")}>
                    {params.value}
                </span>
            )

        },
        {
            field: "completedDSDItmCnt",
            headerName: "DSD",
            sortable: false,
            width: 100,
            headerAlign: "left",
            flex: 0.1,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "C", "D")}>
                    {params.value}
                </span>
            )
        },
        {
            field: "completedItmCnt",
            headerName: "Total",
            sortable: false,
            width: 100,
            headerAlign: "left",
            flex: 0.1,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span className={"storeItemsReportLinkClass"} onClick={() => handleLinkClick(params, "C", "A")}>
                    {params.value}
                </span>
            )

        },
        {
            field: "reviwExcelDownload",
            headerName: " ",
            sortable: false,
            width: 100,
            headerAlign: "left",
            flex: 0.1,
            headerClassName: "HeaderModelLikeMatchTable",
            renderCell: (params) => (
                <span onClick={() => handleExcelDownload(params, "completedItmCnt", 'A', 'C')}>
                    <img src="/export_to_excel_icon.png" alt="/" title={params.row.completedItmCnt > 0 ? "Export To Excel" : ""} style={{cursor:params.row.completedItmCnt > 0 ? "pointer" : "default"}} />
                </span>
            )
        },
    ]

    const handleLinkClick = (params, status, type) => {
        if (params.value === 0) {
            AppData.setAlertBox(true, "No more item to view.")
        }
        else {
            memiuServices.getLoadOverideData2(params.row.deptCode, "A", AppData.companyId, AppData.divisionId, status, type)
                .then((res) => {
                    if (res.data === null || res.data.length === 0) {
                        AppData.setAlertBox(true, "No more item to view.")
                    }
                    else {
                        AppData.setAugmentationServiceDepartment("")
                        AppData.setAugmentationServiceKey("")
                        AppData.setMemi18({ updateaugmentationsku: res.data, UpdateAugmentationManualSearch:{} })
                        history.push(RouteBase.MEMI18)
                    }

                })

                .catch((err) => {
                })
        }
    }

    const handleExcelDownload = (params, row, exceptionType, status) => {
        if (params.row[`${row}`] === 0) { return }
        else {
            let data = {
                deptName: params.row.deptName,
                deptCode: params.row.deptCode,
                division: AppData.divisionId,
                company: AppData.companyId,
                exceptionType,
                status
            }

            const deptName = params.row.deptName.toLowerCase()
            const capsDeptName = deptName.charAt(0).toUpperCase() + deptName.slice(1);

            memiuServices.getDownloadExcel(data).then((res) => {
                const url = window.URL.createObjectURL(new Blob([res.data],));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', `Exceptions_${capsDeptName}.xlsx`);
                document.body.appendChild(link);
                link.click();
            })
        }
    }


    const handleFileUpload = (totalRcrods) => {
        if (totalRcrods>=0) {
            setOpenFileModal(true)
        }
    }

    const customNoRowsOverlay = () => {
        return (
            <div className="customNoRows">
                <NoRecordsDisplay />
            </div>
        )
    }


    return (
        <Grid container>
            <Grid item xs={12} className="NoItemsMatchElementOne">
                <table style={{ width: "100%",fontSize: "15px" }}>
                    <tbody>
                        <tr>
                            <td style={{ width: "19%" }} align="left"> Departments </td>
                            <td style={{ width: "27%", textAlign: "left" }} align="left"> Un-reviewed Items</td>
                            <td style={{ width: "27%", textAlign: "left" }} align="left"> Need further Review Items</td>
                            <td style={{ width: "30%", textAlign: "left" }} align="left"> Completed Items</td>
                        </tr>
                    </tbody>
                </table>
            </Grid>
            <Grid item xs={12}>
                <TableMemi
                    autoHeight
                    columns={columns}
                    hideFooter
                    hideFooterPagination
                    NoRowsOverlay={customNoRowsOverlay}
                    classnameMemi="ModelLikeMatchTable"
                    data={AppData.memi17.data}
                    disableColumnMenu
                    disableColumnFilter
                    rowheight={22}
                />
            </Grid>
            <Grid item xs={12} className={`modelLikeMatchTotalItems ${AppData.memi17.data.length === 0 ? "totalItemsDisable" : AppData.memi17.data.length % 2 == 0 ? "totalItemsOdd" : "totalItemsEven"}`}>

                <table style={{ width: "100%" }}>
                    <tbody>
                        <tr>
                            <td style={{ width: "14.7%", fontWeight: "bold" }} align="left"> Total Count</td>
                            <td style={{ width: "5.2%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalUnReviewWHSE}</td>
                            <td style={{ width: "5%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalUnReviewDsd} </td>
                            <td style={{ width: "10%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalUnReview} </td>

                            <td style={{ width: "5%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalreviewWHSEItmCnt}</td>
                            <td style={{ width: "5%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass">  {AppData.memi17.totalreviewDSDItmCnt} </td>
                            <td style={{ width: "10%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalreviewItmCnt} </td>


                            <td style={{ width: "5%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalReviewWHSE}</td>
                            <td style={{ width: "5%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass">  {AppData.memi17.totalReviewDsd} </td>
                            <td style={{ width: "10%", textAlign: "left" }} align="left" className="storeItemsReportLinkClass"> {AppData.memi17.totalReview} </td>


                        </tr>
                    </tbody>
                </table>
            </Grid>
            <FileUploadMoodalNewUPC
                open={openFileModal}
                setOpen={setOpenFileModal}
                departments={departments}
            />
            <SearchBarSkuUpc/>
        </Grid>
    )
}
