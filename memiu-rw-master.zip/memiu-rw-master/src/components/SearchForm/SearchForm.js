import React, { useContext } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Button, Grid, Paper, TextField } from "@material-ui/core";
import ApplicationContext from "../../context/ApplicationContext";
import { userInfoAxios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";
import { v4 as uuidv4 } from "uuid";

const validationSchema = Yup.object().shape({
  name: Yup.string().min(3, "It's too short").required("Required"),
  email: Yup.string().email("Enter valid email").required("Required"),
});
const initialValues = {
  name: "",
  email: "",
};

const SearchForm = () => {
  const AppData = useContext(ApplicationContext);

  const paperStyle = {
    border: "1px solid grey",
    padding: 20,
    width: "80%",
    margin: "50px auto",
  };

  const onSubmit = (values, props) => {
    setTimeout(() => {
      props.resetForm();
      props.setSubmitting(false);
    }, 2000);
    props.setSubmitting(true);
    const user = {
      username: values.name,
      email: values.email,
      id: uuidv4(),
    };
    AppData.addUserInfo(user);
    userInfoAxios.post("/", user);
  };

  return (
    <Paper elevation={3} style={paperStyle}>
      <Grid align="center">
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          {(props) => (
            <Form>
              <Grid container spacing={3}>
                <Grid item md={6}>
                  <Field
                    as={TextField}
                    fullWidth
                    name="name"
                    label="Username"
                    placeholder="Enter your username"
                    helperText={<ErrorMessage name="name" />}
                  />
                </Grid>
                <Grid item md={6}>
                  <Field
                    as={TextField}
                    fullWidth
                    name="email"
                    label="Email"
                    placeholder="Enter your email"
                    helperText={<ErrorMessage name="email" />}
                  />
                </Grid>
              </Grid>
              <Grid>
                <Grid
                  item
                  xs="auto"
                  style={{
                    display: "flex",
                    justifyContent: "flex-start",
                    marginTop: "10px",
                  }}
                >
                  <Button
                    type="submit"
                    color="primary"
                    variant="contained"
                    disabled={props.isSubmitting}
                  >
                    {props.isSubmitting ? "Loading" : "Submit"}
                  </Button>
                </Grid>
              </Grid>
            </Form>
          )}
        </Formik>
      </Grid>
    </Paper>
  );
};

export default SearchForm;
