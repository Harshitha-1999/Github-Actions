import React from 'react'
import { Grid } from '@material-ui/core'
import ButtonLogout from 'components/ButtonLogout/ButtonLogout'
export default function HeaderOverideProcessContd({title}) {
    return (
        <Grid container className="OverideHeaderContainer">
            <img src="/MultiUnitTypeLogo.png" alt="multiUnitType" />
            <big style={{ fontWeight: "bold", color: "#055166", fontSize: "24px", marginLeft: "1.5rem" }}>{title}</big>
            <ButtonLogout
                classNameMemi="OverideHeaderLogout"
            />
        </Grid >
    )
}
