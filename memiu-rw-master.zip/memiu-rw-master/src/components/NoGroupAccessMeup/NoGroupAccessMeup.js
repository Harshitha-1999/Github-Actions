import React from 'react'
import { Grid } from '@material-ui/core';
import { makeStyles } from "@material-ui/core/styles";
const useStyles = makeStyles((theme) => ({
    container: {
        paddingRight: "15px",
        paddingLeft: "15px",
        marginRight: "auto",
        marginLeft: "auto",
        marginTop: "8%"
    },
    jumboTron: {
        paddingLeft: "60px",
        paddingRight: "60px",
        backgroundColor: "#eee",
    }
}));

function NoGroupAccessMeup() {
    const classes = useStyles();
    return (
        <Grid container className={classes.container}>
            <Grid item xs={!2} className={classes.jumboTron}>
                <h2 style={{ fontWeight: "500" }}>
                    Login Error: Sorry, you are not Authorized to access the requested Screens
                </h2>
            </Grid>
        </Grid>
    )
}

export default NoGroupAccessMeup;
