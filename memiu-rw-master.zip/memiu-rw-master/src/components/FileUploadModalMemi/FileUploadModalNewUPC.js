import React, { useContext, useEffect, useState } from 'react';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";
import { CloseTwoTone, CloudUpload } from '@material-ui/icons';
import DropDownMemi from 'components/DropDownMemi/DropDownMemi';
import { authTokenCookie } from 'utils';
import { memiuServices } from 'api/memiu/memiuService';

export default function FileUploadMoodalNewUPC(props) {

    const AppData = useContext(ApplicationContext);
    const { divisionId, companyId } = AppData;
    const [selectedDepartment, setSelectedDepartment] = useState("");
    const [selectedFile, setSelectedFile] = useState("")
    const [message, setMessage] = useState("");
   
    const [isForcenewProduce, setIsForcenewProduce] = useState(false);
   
    const [colorClass, setColorClass] = useState("fontColor_WHSE")
    const selectFile = (event) => {
        setSelectedFile(event.target.files[0]);
    };
   

    const onCLickFileUpload = () => {
       

        
        const { userId } = authTokenCookie();
        let divisionName = ""
        AppData.divisions.forEach((division) => {
            if (division.value === divisionId) {
                divisionName = division.label
            }
        })
        const dept = selectedDepartment.split(" ")
        if (companyId && divisionId && selectedFile &&
            divisionName && dept[0] && dept[1] && userId) {
            setMessage("")
            let fd = new FormData();
            fd.append('file', selectedFile);
            fd.append('companyId', companyId);
            fd.append('divisionId', divisionId);
            fd.append('divisionName', divisionName);
            fd.append('deptName', dept[0]);
            fd.append('deptCode', dept[1]);
            fd.append('userId', userId);

            memiuServices.uploadFile(fd)
                .then((response1) => {
                    if (response1.data.status == "SUCCESS") {
                        setColorClass("fontColor_DSD");
                        setIsForcenewProduce(true)
                        
                        setMessage("The file is being processed. You will be notified through an email when processing is complete.");
                    } else if (response1.data.status == "FAILURE") {
                        setColorClass("fontColor_WHSE");
                        setMessage("File upload failed.");
                    } else if (response1.data.status == "ERROR") {
                        setColorClass("fontColor_WHSE");
                        setMessage("Issues in uploading the file.");
                    }
                    
                })
                .catch((error) => {
                    //function handles error condition

                    setColorClass("fontColor_WHSE")
                    setMessage("Internal network error.");
                });

        } else {
            setColorClass("fontColor_WHSE");
            setMessage("Error in uploading the file.");
        }
    
    }

    const handleClose = () => {
        props.setOpen(false);
        setSelectedFile("");
        setColorClass("");
        setSelectedDepartment("");
        setMessage("");
        setIsForcenewProduce(false)
       
    }


    const content = (
        <>
            <div style={{ display: "flex", columnGap: "20%" }}>
                <span style={{ color: "#339fe0", fontWeight: "700", paddingBottom: "15px" }} >Upload Excel File</span>
                <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)", marginLeft: "auto" }} onClick={handleClose} />
            </div>


            <DropDownMemi
                options={props.options}
                label="Department: "
                classNameMemi="dropdownOverideProcessCont"
                alignItems="row"
                options={props.departments}
                disabled={isForcenewProduce}
                value={selectedDepartment}
                setValue={(value) => setSelectedDepartment(value)}

            />
            <br />
            {isForcenewProduce==false?
            <div>
                <input type={"file"} accept={AppData.fileUpload.accept} onChange={selectFile} />
            </div>:
            
            <div>
                <input type={"file"} accept={AppData.fileUpload.accept} onChange={selectFile} disabled />
            </div>}
            <br/>
            <label className={colorClass}>
                {message}
            </label>
            {isForcenewProduce==false?
            <div style={{ marginTop: "1rem", marginRight: "20px" }}>
                <ButtonMemi
                    classNameMemi="MultiUnitScreenSearchButton FileUploadCls"
                    btnval="Upload"
                    onClick={onCLickFileUpload}
                    startIcon={<CloudUpload />}
                />
            </div>:""}
        </>
    )

    return (
        <>
            <ModalPopup
                open={props.open}
                classNameMemi="fileUploadModalPopup"
                popupContentClass="fileUploadModalContent"
                popupTitleClass="popupFileUploadModalTitle"
                popupContent={content}

            />
        </>

    )
}
