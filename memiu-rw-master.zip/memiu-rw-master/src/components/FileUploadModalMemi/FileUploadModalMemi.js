import React, { useContext, useEffect, useState } from 'react';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";
import { Grid, OutlinedInput } from "@material-ui/core";
import { CloseTwoTone } from '@material-ui/icons';

export default function FileUploadModal(props) {

    const AppData = useContext(ApplicationContext);
    const [selectedFiles, setSelectedFiles] = useState("")

    const handleSubmit = () => {
        AppData.setFileUploadModal(false, [], "", "")
        AppData.setFileUploadData(null)
    }

    const selectFile = (event) => {
        setSelectedFiles(event.target.files[0]);
    };


    const onCLickFileUpload = () => {
        AppData.setFileUploadData(selectedFiles)
    }

    const {pathname} = window.location;

    useEffect(() => {
        handleSubmit();
    },[pathname])

    const content = (
        <>
            <div style={{ display: "flex", columnGap: "20%" }}>
                <span style={{ color: "#339fe0", fontWeight: "700", paddingBottom: "15px" }} >Import Components from Excel</span>
                <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={handleSubmit} />
            </div>
            <div>
                <input type={"file"} accept={AppData.fileUpload.accept} onChange={selectFile} />
            </div>
            <div style={{ width: "275px", marginTop: '10px' }}>
                {selectedFiles ? <span style={{ color: AppData.fileUpload.msgColor, paddingBottom: "15px" }} >{AppData.fileUpload.msg}</span> : ""}
            </div>
            <div style={{ marginTop: AppData.fileUpload.msg === "" ? "13%" : '0' }}>
                <ButtonMemi
                    classNameMemi="MultiUnitScreenSearchButton FileUploadCls"
                    btnval="Upload"
                    onClick={onCLickFileUpload}
                />
            </div>
        </>
    )

    return (
        <>
            <ModalPopup
                open={AppData.fileUpload.open}
                classNameMemi="fileUploadModalPopup"
                popupContentClass="fileUploadModalContent"
                popupTitleClass="popupFileUploadModalTitle"
                popupContent={content}
            />
        </>
    )
}
