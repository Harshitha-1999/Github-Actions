
import React, { useState } from "react";
import { useHistory } from 'react-router-dom';
import { Button, MenuItem, Popper, Box, List, ListItemText, ListItem } from '@material-ui/core';
import ClickAwayListener from 'material-ui/internal/ClickAwayListener';
import { KeyboardArrowDown, KeyboardArrowRight } from '@material-ui/icons'
import { makeStyles } from "@material-ui/core/styles";
import './MenuStyle.css';

const useStyles = makeStyles((theme) => ({
    linkItem: {
        textDecoration: "none",
        color: "black",
    },
    listItem: {
        "&:hover": {
            backgroundColor: "whitesmoke"
        },
        cursor: "pointer"
    }
}));

function DropdownMenuMemiu(props) {

    const history = useHistory();
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        if (anchorEl) {
            setAnchorEl(null);
        }
        setAnchorEl(event.currentTarget);

    };
    const handleClose = (e) => {

        setAnchorEl(null);
    };
    const id = open ? 'simple-popper' : undefined;


    const classes = useStyles();

    const handleLinkClick = (path) => {
        history.push(path)
        setAnchorEl(null)
    }

    return (
        <>
            {
                props.child ?
                    <MenuItem onClick={handleClick} className={props.menuItemClass}>
                        <div style={{ display: "flex" }}>
                            {props.label} {<KeyboardArrowRight style={{ marginLeft: "1.1rem" }} />}
                        </div>

                    </MenuItem>
                    :
                    <Button
                        id="basic-button"
                        aria-controls="basic-menu"
                        aria-haspopup="true"
                        aria-expanded={open ? 'true' : undefined}
                        onClick={handleClick}
                        className={props.buttonClass}
                        endIcon={props.disableArrowDown ? null : <KeyboardArrowDown />}
                    >
                        {props.label}
                    </Button>
            }

            <ClickAwayListener onClickAway={handleClose}>
                <Popper
                    id={id}
                    open={open}
                    anchorEl={anchorEl}
                    placement={
                        props.child ? "right-start" : "top-start"

                    }
                    // onClose={handleClose}
                    disablePortal
                    elevation={10}
                    style={{ zIndex: "4000" }}
                    className={props.popperClass}
                >
                    <Box className="filterByStatusBox">

                        <List>
                            {
                                props.menuData ? props.menuData.map((route, index) => (

                                    route.children ? <DropdownMenuMemiu label={route.label} menuData={route.children} child={true} /> :

                                        <ListItem className={classes.listItem} onClick={() => handleLinkClick(route.path)}>
                                            {route.label}
                                        </ListItem>


                                )) : ""
                            }
                        </List>
                    </Box>
                </Popper>
            </ClickAwayListener>

        </>
    );
}

export default DropdownMenuMemiu;
