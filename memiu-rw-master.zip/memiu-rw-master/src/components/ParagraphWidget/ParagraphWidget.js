import React from 'react';
import "./ParagraphWidget.scss";


export const ParagraphWidget = ({ controlId, content }) => {
    return (
        <React.Fragment>
            <p id={controlId} >
                {content}
            </p>
        </React.Fragment>
    );
}

export default ParagraphWidget;