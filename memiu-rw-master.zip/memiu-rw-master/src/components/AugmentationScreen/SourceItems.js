import React, { useState, useEffect, useContext, useMemo, memo, useCallback } from 'react'
import { Grid } from "@material-ui/core";
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import { Add } from "@material-ui/icons";
import DropDownMemi from 'components/DropDownMemi/DropDownMemi';
import ApplicationContext from 'context/ApplicationContext';
import { memiuServices } from 'api/memiu/memiuService';
import { useHistory } from 'react-router';
import { authTokenCookie } from 'utils';
function SourceItems(props) {
  const history = useHistory()
  const AppData = useContext(ApplicationContext);
  const { pageNumber, setPageNumber } = props
  //const { selectedDepartment, setSelectedDepartment } = props
  const { UpdateAugmentationManualSearch, updateaugmentationsku, department } = AppData;
  console.log(UpdateAugmentationManualSearch)
  const [option, setOption] = useState("");
  const [disableMarkAsDead, setDisableMarkAsDead] = useState(false);
  const [disableMarkOutOfScope, setDisableMarkOutOfScope] = useState(false);
  const [disableGroupStatus, setDisableGroupStatus] = useState(true);
  const [disableAssignAnother, setDisableAssignAnother] = useState(false);
  const upcVd = useMemo(() => {
    return UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.upcVoList.map((upcVo) => {
      return { label: `${upcVo.upc} ${upcVo.primaryUPCInd}`, value: "1" }
    }) : []
  }, [UpdateAugmentationManualSearch])

  const departmentList = useMemo(() => {
    return department ? Object.keys(department).map((deptCode) => {
      return { value: deptCode, label: department[deptCode] }
    }) : []
  }, [department])

  const handleTableModel = (type = "source") => {
    const columnData = UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.upcVoList.map((data) => {
      return { "UPCs & Unit Type": data.upc }
    }) : []
    AppData.setTableModal(true, ["UPCs & Unit Type"], columnData)
  }
  const handleChecked = (e, type) => {
    if (type === "MarkOutOfScope" && e.target.checked) {
      setOption(type);
      setDisableMarkAsDead(true);
      props.setDisableSaveNext(true)
    }
    else if (type === "MarkAsDead" && e.target.checked) {
      setOption(type);
      setDisableMarkOutOfScope(true);
      props.setDisableSaveNext(true)
    }
    else if (!e.target.checked) {
      setOption("");
      setDisableMarkAsDead(false);
      setDisableMarkOutOfScope(false);
      props.setDisableSaveNext(false)
    }
  }
  const handlePrev = useCallback(() => {
    if (pageNumber <= 0) {
      AppData.setAlertBox(true, "This is the first item under this department.")
    }
    else {
      setPageNumber(pageNumber - 1)
      setOption("")
    }
  }, [pageNumber])
  const handleNext = useCallback(() => {
    if (!updateaugmentationsku) {
      history.goBack();
    }
    if (pageNumber >= updateaugmentationsku.length - 1) {
      AppData.setAlertBox(true, "This is the last item under this department.")
    }
    else {
      setPageNumber(pageNumber + 1)
      setOption("")
    }
  }, [pageNumber, updateaugmentationsku])

  const handleDisableGroupStatus = useCallback((status) => {
    props.setDisableSaveNext(!status);
    setDisableGroupStatus(status)
    if (status) {
      props.setSelectedDepartment(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.hierLevel4 : "")
      setDisableMarkAsDead(false);
      setDisableMarkOutOfScope(false);
    }
    else {
      setDisableMarkAsDead(true);
      setDisableMarkOutOfScope(true);
    }
  }, [UpdateAugmentationManualSearch])

  const saveNewDepartment = useCallback(() => {
    memiuServices.updateDepartment({ ...UpdateAugmentationManualSearch.uiEceptionSrcDto, hierLevel4: props.selectedDepartment, hierLevel5: department[props.selectedDepartment] })
      .then((res) => {
        handleNext();
      })
      .catch((error) => {
        console.log(error)
      })
  }, [UpdateAugmentationManualSearch, props.selectedDepartment])

  const handleMarkDead = useCallback((message) => {
    let whiteSpace = new RegExp(/^\s+$/);
    const { userId } = authTokenCookie()
    if (!whiteSpace.test(message)) {
      let UpdateAugmentationEditDetail = UpdateAugmentationManualSearch;
      UpdateAugmentationEditDetail.killProdSku = true;
      UpdateAugmentationEditDetail.newItemDto.dcPackDesc = UpdateAugmentationEditDetail.newItemDto.packwhse;
      UpdateAugmentationEditDetail.newItemDto.dcSizeDsc = UpdateAugmentationEditDetail.newItemDto.updSize;
      UpdateAugmentationEditDetail.newItemDto.ring = 0;
      UpdateAugmentationEditDetail.markAsDeadReason = message
      UpdateAugmentationEditDetail.newItemDto.hicone = 0;
      UpdateAugmentationEditDetail.uiEceptionSrcDto.updatedUserID = userId;
      //service call
      // console.log("data after being set"+UpdateAugmentationEditDetail);
      memiuServices.postSaveAugmentationDetails(UpdateAugmentationEditDetail)
        .then((response) => {
          //function handles success condition
          let saveStatus = response.data.status;
          if (saveStatus == 1) {

            if (pageNumber >= updateaugmentationsku.length - 1) {
              AppData.setAlertBox(true, "No more items under this department.");
              history.goBack();
            }
            else {
              setPageNumber(pageNumber + 1)
            }
          }
        })
        .catch((error) => {
          //function handles error condition
        })
      AppData.setConfirmationModal(false);
    }
  }, [pageNumber, UpdateAugmentationManualSearch])

  const handleMarkOutOfScope = useCallback(() => {
    let UpdateAugmentationEditDetail = UpdateAugmentationManualSearch;
    const { userId } = authTokenCookie();
    UpdateAugmentationEditDetail.manualMap = true;
    UpdateAugmentationEditDetail.newItemDto.createId = userId;
    UpdateAugmentationEditDetail.newItemDto.dcPackDesc = UpdateAugmentationEditDetail.newItemDto.packwhse;
    UpdateAugmentationEditDetail.newItemDto.dcSizeDsc = UpdateAugmentationEditDetail.newItemDto.updSize;
    UpdateAugmentationEditDetail.newItemDto.ring = 0;
    UpdateAugmentationEditDetail.newItemDto.hicone = 0;
    UpdateAugmentationEditDetail.uiEceptionSrcDto.updatedUserID = userId;
    //service call
    memiuServices.postSaveAugmentationDetails(UpdateAugmentationEditDetail)
      .then((response) => {
        //function handles success condition
        let saveStatus = response.data.status;
        if (saveStatus == 1) {
          if (pageNumber >= updateaugmentationsku.length - 1) {
            AppData.setAlertBox(true, "No more items under this department.");
            history.goBack();
          }
          else {
            setPageNumber(pageNumber + 1)
          }
        }
      })
      .catch((error) => {
        //function handles error condition
      })
    AppData.setConfirmationModal(false);
  }, [UpdateAugmentationManualSearch, pageNumber])

  useEffect(() => {
    setOption("");
    setDisableMarkAsDead(false);
    setDisableMarkOutOfScope(false);
    setDisableGroupStatus(true);
    setDisableAssignAnother(false)
    if (!UpdateAugmentationManualSearch || !UpdateAugmentationManualSearch.uiEceptionSrcDto) { return }
    if (UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd === "C") {
      if (UpdateAugmentationManualSearch.uiEceptionSrcDto.markedAsDead === true) {
        setDisableMarkAsDead(true)
        setOption("MarkAsDead");
        setDisableMarkOutOfScope(true);
        setDisableAssignAnother(true)
      }
      else if (UpdateAugmentationManualSearch.uiEceptionSrcDto.manualMapped === true) {
        setDisableMarkAsDead(true)
        setOption("MarkOutOfScope");
        setDisableMarkOutOfScope(true);
        setDisableAssignAnother(true);
      }
    }
  }, [UpdateAugmentationManualSearch])

  return (
    <Grid container className="overideProcessContainer overideProcessContainerBoxShadow" style={{ paddingRight: "11px" }}>
      <Grid item xs={12} className="overideProcessTitle">
        Source Items
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Product SKU
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.productSKU : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Primary UPC
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.primaryUPCVo.upc : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Pack
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.packWhse : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          VCF
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.vdCnvFactor : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Desc Size
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.szDesc : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Num Size
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? `${UpdateAugmentationManualSearch.uiEceptionSrcDto.sizeNbr} ${UpdateAugmentationManualSearch.uiEceptionSrcDto.szUom}` : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Usage
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.itmUsgeInd : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Display
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.dspFlag : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Item Description
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.itmDescrbtn : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Warehouse Desc
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.whseItmDescrbtn : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          S & S Desc
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.rtlItmDescrbtn : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Internet Desc
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.intenetItemDescrbtn : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          POS Desc
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.posDescrbtn : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Department
        </Grid>
        <Grid item xs={8} className="">
          {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.deptCd : ""}
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4} className="overideProcessRowTitle">
          Conv Group
        </Grid>
        <Grid item xs={8} className="" style={{ display: "flex" }}>
          <div>
            <DropDownMemi
              alignItems="inline"
              label=""
              options={departmentList}
              value={props.selectedDepartment}
              setValue={(value) => props.setSelectedDepartment(value)}
              disableNone
              disabled={disableGroupStatus}
              classNameMemi="augmentationGroupDropdown"
            />
          </div>
          &nbsp;
          {
            disableGroupStatus ?
              <ButtonMemi
                classNameMemi="MultiUnitScreenButtonConvGroup"
                btnval="Assign to another group"
                btncolor="default"
                onClick={() => handleDisableGroupStatus(false)}
                btndisabled={disableAssignAnother}
              /> :
              <>
                <ButtonMemi
                  classNameMemi="MultiUnitScreenButtonConvGroup"
                  btnval="Save & Next"
                  btncolor="default"
                  onClick={saveNewDepartment}
                />
                &nbsp;
                <ButtonMemi
                  classNameMemi="MultiUnitScreenButtonConvGroup"
                  btnval="Cancel"
                  btncolor="default"
                  onClick={() => handleDisableGroupStatus(true)}

                />
              </>
          }

          {/* </Grid> */}
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Product Src
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.productSrcCd : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Cost
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? `$${UpdateAugmentationManualSearch.uiEceptionSrcDto.costItm}` : ""}

          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            UPCs
          </Grid>
          <Grid item xs={8} className="overideProcessRowTitle" style={{ display: "flex" }}>
            <div>
              <DropDownMemi
                alignItems="inline"
                label=""
                options={upcVd}
                value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.primaryUPCforDisplay : ""}
                disableNone
                classNameMemi="dropdownOverideProcessCont"
              />
            </div>
            &nbsp;
            <Add
              style={{ cursor: "pointer", fontSize: "14", color: "black" }}
              onClick={handleTableModel}
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            New Date
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.salesData ? UpdateAugmentationManualSearch.salesData.newDate : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Last Ship Date
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.salesData ? UpdateAugmentationManualSearch.salesData.lastShipDate : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Last Sale Date
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.salesData ? UpdateAugmentationManualSearch.salesData.lastSaleDate : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Total Sales
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.salesData ? UpdateAugmentationManualSearch.salesData.totalSales : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Cases Ordered
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.salesData ? UpdateAugmentationManualSearch.salesData.casesOrdered : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            One Time Buy Ind
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.loglInd : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Selling Method
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.selling_method_cd : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Receiving Method
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.receiving_method_cd : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Sell By Days
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.sellByDays : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Use By Days
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.useByDays : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Pull By Days
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.pullBydays : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4} className="overideProcessRowTitle">
            Cost
          </Grid>
          <Grid item xs={8} className="">
            {UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.cost : ""}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">

          <Grid item xs={12} style={{ display: 'flex', alignItems: "center" }}>
            <strong>Mark Out Of Scope </strong><input type="checkbox" size="small" color="default" checked={option === "MarkOutOfScope"} onChange={(e) => handleChecked(e, "MarkOutOfScope")} disabled={disableMarkOutOfScope} />
            {
              option === "MarkOutOfScope" && !disableMarkOutOfScope ?
                <ButtonMemi
                  classNameMemi="MultiUnitScreenButton"
                  btnval="Save & Next"
                  onClick={() => AppData.setConfirmationModal(true, handleMarkOutOfScope, "confirmation", "Do you really wants to move this item out of automated process?")}
                  idCss="MarkOutOfScope"
                  btnsize="small"
                /> : ""
            }

            <label style={{ marginLeft: "auto" }}><strong> Mark as Dead</strong></label> <input type="checkbox" size="small" color="default" checked={option === "MarkAsDead"} onChange={(e) => handleChecked(e, "MarkAsDead")} disabled={disableMarkAsDead} />
            {
              option === "MarkAsDead" && !disableMarkAsDead ?
                <ButtonMemi
                  classNameMemi="MultiUnitScreenButton"
                  btnval="Save & Next"
                  onClick={() => AppData.setConfirmationModal(true, handleMarkDead, "textBox", "Enter the reason for marking this item as dead")}
                  idCss="MarkAsDead"
                /> : <div style={{ width: "80px" }}> </div>
            }
          </Grid>
        </Grid>
      </Grid>
      <Grid container style={{ marginTop: "10px" }}>
        <Grid item xs={12}>
          {/* style={{ paddingTop: "10px", display: `${updateoverridesku && updateoverridesku.length > 1 ? "flex" : "none"}` }} */}
          <ButtonMemi
            classNameMemi="MultiUnitScreenButton"
            btnval="Prev"
            btncolor="default"
            onClick={handlePrev}
          />
          <ButtonMemi
            classNameMemi="MultiUnitScreenButton overideSaveButton"
            btnval="Next"
            btncolor="default"
            onClick={handleNext}
            btndisabled={false}
          />
        </Grid>
      </Grid>
    </Grid >
  )
}

export default memo(SourceItems)
