import React, { useState, useContext, useEffect, useCallback, memo } from "react";
import { Grid } from "@material-ui/core";
import SourceItems from "./SourceItems";
import EditItems from "./EditItems";
import ApplicationContext from "../../context/ApplicationContext";
import { memiuServices } from "api/memiu/memiuService";
function AugmentationScreen(props) {
  const AppData = useContext(ApplicationContext)
  const { companyId, divisionId } = AppData;
  const { updateaugmentationsku, UpdateAugmentationManualSearch } = AppData
  const [pageNumber, setPageNumber] = useState(0);
  const [disableSaveNext, setDisableSaveNext] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState("");
  let AugmentedSrcEditDetails;
  /**
    Load usage type combo
  **/
  const loadUsageTypeCombo = () => {
    if (!AugmentedSrcEditDetails)
      return;
    if (AugmentedSrcEditDetails.newItemDto.innerPack === null) {
      AugmentedSrcEditDetails.newItemDto.innerPack = 1;
    }
    if (AugmentedSrcEditDetails.newItemDto.retailUnitPack === null || AugmentedSrcEditDetails.newItemDto.retailUnitPack === 0) {
      AugmentedSrcEditDetails.newItemDto.retailUnitPack = AugmentedSrcEditDetails.newItemDto.packwhse;
    }
  };

  /*
  load uom list
  */
  const loadUomList = () => {
    memiuServices.getUOMList().then((res) => {
      AppData.setUOMList(res.data);
    })
      .catch((error) => {
      })
  }

  const loadAugmentaionDetails = useCallback(() => {   
    memiuServices.getUpdateAugmentationManualSearch(companyId, divisionId, updateaugmentationsku[pageNumber])
      .then((res) => {
        AugmentedSrcEditDetails = res.data
        if (AugmentedSrcEditDetails) {
          if (AugmentedSrcEditDetails.newItemDto.dcSizeDsc == null) {
            AugmentedSrcEditDetails.newItemDto.dcSizeDsc = AugmentedSrcEditDetails.newItemDto.updSize;
          }
          if (AugmentedSrcEditDetails.newItemDto.dcPackDesc == null) {
            AugmentedSrcEditDetails.newItemDto.dcPackDesc = AugmentedSrcEditDetails.newItemDto.packwhse;
          }
          if (AugmentedSrcEditDetails.newItemDto.innerPack == null) {
            AugmentedSrcEditDetails.newItemDto.innerPack = 1;
          }
          if (AugmentedSrcEditDetails.newItemDto.retailUnitPack == null || AugmentedSrcEditDetails.newItemDto.retailUnitPack == 0) {
            AugmentedSrcEditDetails.newItemDto.retailUnitPack = AugmentedSrcEditDetails.newItemDto.packwhse;
          }
          if (AugmentedSrcEditDetails.newItemDto.pluCd == null) {
            AugmentedSrcEditDetails.newItemDto.pluCd = 0;
          }
          if (AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd === "C") {
            if (AugmentedSrcEditDetails.uiEceptionSrcDto.markedAsDead === true || AugmentedSrcEditDetails.uiEceptionSrcDto.manualMapped === true) {
              setDisableSaveNext(true)
            }
          }
          let tempVal = AugmentedSrcEditDetails.newItemDto.packwhse;
          AugmentedSrcEditDetails.newItemDto.updpackwhse = tempVal;
          if (AugmentedSrcEditDetails.newItemDto.productClsCd == null) {
            AugmentedSrcEditDetails.newItemDto.productClsCd = 0;
            if (AugmentedSrcEditDetails.newItemDto.borrowedSMIC == true || AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'C' || AugmentedSrcEditDetails.uiEceptionSrcDto.excptnProInd == 'R') {
              if (AugmentedSrcEditDetails.newItemDto.grpCd &&
                AugmentedSrcEditDetails.newItemDto.grpCd.toString().length == 1) {
                AugmentedSrcEditDetails.newItemDto.grpCd = '0' + AugmentedSrcEditDetails.newItemDto.grpCd;
              }
              if (AugmentedSrcEditDetails.newItemDto.ctgryCd &&
                AugmentedSrcEditDetails.newItemDto.ctgryCd.toString().length == 1) {
                AugmentedSrcEditDetails.newItemDto.ctgryCd = '0' + AugmentedSrcEditDetails.newItemDto.ctgryCd;
              }
              if (AugmentedSrcEditDetails.newItemDto.grpCd != null && AugmentedSrcEditDetails.newItemDto.ctgryCd != null) {
                AugmentedSrcEditDetails.newItemDto.productClsC = AugmentedSrcEditDetails.newItemDto.grpCd + '' + AugmentedSrcEditDetails.newItemDto.ctgryCd;
              }
            }
          }
        }
        loadUsageTypeCombo();
        setSelectedDepartment(res.data && res.data.uiEceptionSrcDto && res.data.uiEceptionSrcDto.hierLevel4!==null ? res.data.uiEceptionSrcDto.hierLevel4 : "")
        AppData.setMemi18({ UpdateAugmentationManualSearch: AugmentedSrcEditDetails })
      })
      .catch((error) => {
      })
  }, [companyId, divisionId, updateaugmentationsku, pageNumber])

  //Function to load department
  const loadDepartments = useCallback(() => {
    memiuServices.getDepartmentList(companyId, divisionId)
      .then((res) => {
        let departmentObject = {};
        res.data.forEach((data) => {
          departmentObject[data.departmentCode] = data.departmentName;
        })
        AppData.setDepartment(departmentObject);
      })
      .catch((err) => {
        console.log(err)
      })
  }, [companyId, divisionId])

  const loadSkuDetails = useCallback(() => {
    let type = ""
    if (UpdateAugmentationManualSearch.uiEceptionSrcDto.productSrcCd == "WHSE") {
      type = 'W';
    }
    else {
      type = 'D';
    }
    memiuServices.getLoadOverideData2(UpdateAugmentationManualSearch.uiEceptionSrcDto.hierLevel4, "A", UpdateAugmentationManualSearch.uiEceptionSrcDto.companyId, UpdateAugmentationManualSearch.uiEceptionSrcDto.divisionId, UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd, type)
      .then((res) => {
        if (res.data === null || res.data.length === 0) {
          AppData.setAlertBox(true, "No more item to view.")
        }
        else {
          let { data } = res
          data.sort((a,b) => {return Number(a)-Number(b)});
          setPageNumber(data.findIndex((sku) => sku ===UpdateAugmentationManualSearch.uiEceptionSrcDto.productSKU))
          AppData.setMemi18({ updateaugmentationsku: data })

        }
      })
      .catch((err) => {
      })
  }, [UpdateAugmentationManualSearch, companyId, divisionId, pageNumber])

  useEffect(() => {
    loadUomList();
    AppData.setMemi18({UpdateAugmentationManualSearch:{}})
  }, [])

  useEffect(() => {
    loadDepartments();
  }, [companyId, divisionId])


  useEffect(() => {
    if (updateaugmentationsku && updateaugmentationsku.length === 0 && UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto) {
      loadSkuDetails();
    }
  }, [updateaugmentationsku, UpdateAugmentationManualSearch, companyId, divisionId])

  useEffect(() => {
    if (updateaugmentationsku && updateaugmentationsku.length > 0) {
      loadAugmentaionDetails()
    }
  }, [pageNumber, companyId, divisionId, updateaugmentationsku])

  return (
    <Grid container>
      <Grid item xs={12} sm={4}>
        <SourceItems
          pageNumber={pageNumber}
          setPageNumber={setPageNumber}
          disableSaveNext={disableSaveNext}
          setDisableSaveNext={setDisableSaveNext}
          selectedDepartment={selectedDepartment}
          setSelectedDepartment={setSelectedDepartment}
        />
      </Grid>
      <Grid item xs={12} sm={8}>
        <EditItems
          disableSaveNext={disableSaveNext}
          setDisableSaveNext={setDisableSaveNext}
          selectedDepartment={selectedDepartment}
          AugmentedDisplayerServiceKey={props.AugmentedDisplayerServiceKey}
          pageNumber={pageNumber}
          setPageNumber={setPageNumber}
          disableDefaultNeedReview={props.disableDefaultNeedReview}
        />
      </Grid>
    </Grid>
  );
}

export default memo(AugmentationScreen);
