import React, { useState, useEffect, useContext, useMemo, memo, useCallback, useRef } from 'react'
import { Grid, Input, OutlinedInput } from "@material-ui/core"
import ButtonMemi from 'components/ButtonMemi/ButtonMemi'
import TextFieldMemi from 'components/TextField/TextFieldMemi'
import DropDownMemi from 'components/DropDownMemi/DropDownMemi'
import { Add, Update } from '@material-ui/icons'
import ApplicationContext from 'context/ApplicationContext';
import { useHistory } from 'react-router'
import { memiuServices } from 'api/memiu/memiuService'
import { authTokenCookie, numberValidation, specialCharacterValidation } from 'utils'

function EditItems(props) {
  const history = useHistory();
  const AppData = useContext(ApplicationContext);
  const { UpdateAugmentationManualSearch, uomList, department, groupDetail, productionGroupDetail, updateaugmentationsku, augmentationServiceKey, augmentationServiceDepartment, companyId, divisionId, augmentationServiceUsageType } = AppData;
  const { disableSaveNext, pageNumber, setPageNumber } = props;
  const [needReview, setNeedReview] = useState(false);
  const [privateLabel, setPrivateLabel] = useState("");
  const [updSize, setUpdSize] = useState("");
  const [innerPack, setInnerPack] = useState("");
  const [updSizeNmbr, setUpdSizeNmbr] = useState("")
  const [updSizeUom, setUpdSizeUom] = useState("")
  const [ethnicTypeCd, setEthnicTypeCd] = useState("");
  const [updUsgeInd, setUpdUsgeInd] = useState("");
  const [updUsgeTypeInd, setUpdUsgeTypeInd] = useState("");
  const [pckTypeCd, setPckTypeCd] = useState("");
  const [updDispFlag, setUpdDispFlag] = useState("");
  const [updItmDesc, setUpdItmDesc] = useState("");
  const [updWhseItmDesc, setUpdWhseItmDesc] = useState("");
  const [updRtlItmDesc, setUpdRtlItmDesc] = useState("");
  const [updIntenetItemDesc, setUpdIntenetItemDesc] = useState("")
  const [updPosDesc, setUpdPosDesc] = useState("")
  const [selectedUpc, setSelectedUpc] = useState("");
  const [pluCd, setPluCd] = useState("");
  const [dcPackDesc, setDcPackDesc] = useState("");
  const [dcPackSize, setDcPackSize] = useState("");
  const [prodwght, setProdWght] = useState("");
  const [convTeamComments, setConvTeamComments] = useState("");
  const [alreadySavedItem, setAlreadySavedItem] = useState("");
  const [handlingCode, setHandlingCode] = useState("");
  const [buyerNum, setBuyerNum] = useState("");
  const [randomWtCd, setRandomWtCd] = useState("");
  const [sellByDays, setSellByDays] = useState("");
  const [useByDays, setUseByDays] = useState("");
  const [pullBydays, setPullByDays] = useState("");
  const [autoCostInv, setAutoCostInv] = useState("");
  const [billingType, setBillingType] = useState("");
  const [retailUnitPack, setRetailUnitPack] = useState("");
  const [ring, setRing] = useState("");
  const [hicone, setHicone] = useState("");
  const [fdStmp, setFdStmp] = useState("");
  const [labelSize, setLabelSize] = useState("");
  const [labelNumbers, setLabelNumbers] = useState("");
  const [sgnCount1, setSgnCount1] = useState("");
  const [sgnCount2, setSgnCount2] = useState("");
  const [sgnCount3, setSgnCount3] = useState("");
  const [tareCd, setTareCd] = useState("");
  const [selectedGroup, setSelectedGroup] = useState("");
  const [selectedProductionGroup, setSelectedProductionGroup] = useState("");
  const [category, setCategory] = useState([]);
  const [productionCategory, setProductionCategory] = useState([]);
  const [classCode, setClassCode] = useState([]);
  const [subClassCode, setSubClassCode] = useState([]);
  const [subSubClassCode, setSubSubClassCode] = useState([]);
  const [prodClassCode, setProdClassCode] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedProdCategory, setSelectedProdCategory] = useState("");
  const [selectedClassCode, setSelectedClassCode] = useState("");
  const [selectedSubClassCode, setSelectedSubClassCode] = useState("");
  const [selectedProdClassCode, setSelectedProdClassCode] = useState("");
  const [selectedSubSubClassCode, setSelectedSubSubClassCode] = useState("");
  const [updPackWhse, setUpdPackWhse] = useState("")
  const [vendConvFactor, setVendConvFactor] = useState("");

  const [productionClassCode, setProductionClassCode] = useState("")
  const [disableProductClassCode, setDisableProductClassCode] = useState(true)

  const [errorGroup, setErrorGroup] = useState(false);
  const [errorClassCode, setErrorClassCode] = useState(false);
  const [errorSbClsCode, setErrorSbClsCd] = useState(false);
  const [errorProdClassCode, setErrorProdClassCode] = useState(false);
  const [errorSbSbClsCd, setErrorSbSbClsCd] = useState(false);
  const [errorPrivateLabel, setErrorPrivateLabel] = useState(false);
  const [errorUpdSize, setErrorUpdSize] = useState(false);
  const [errorUpdSizeNmbr, setErrorUpdSizeNmbr] = useState(false);
  const [errorUpdSizeUom, setErrorUpdSizeUom] = useState(false);
  const [errorUpdUsgeInd, setErrorUpdUsgeInd] = useState(false);
  const [errorUpdUsgeTypeInd, setErroruUpdUsgeTypeInd] = useState(false);
  const [errorUpdDispFlag, setErrorUpdDispFlag] = useState(false);
  const [errorUpdItmDesc, setErrorUpdItmDesc] = useState(false);
  const [errorUpdRtlItmDesc, setErrorUpdRtlItmDesc] = useState(false);
  const [errorUpdInternetItemDesc, setErrorUpdInternetItemDesc] = useState(false);
  const [errorUpdPosDesc, setErrorUpdPosDesc] = useState(false);
  const [errorUpdWhseItmDesc, setErrorUpdWhseItmDesc] = useState(false);
  const [errorInnerPack, setErrorInnerPack] = useState(false);
  const [errorRetailUnitPack, setErrorRetailUnitPack] = useState(false);
  const [errorPluCd, setErrorPluCd] = useState(false);
  const [errorProductClassCode, setErrorProductClassCode] = useState(false);
  const [errorDcPackDesc, setErrorDcPackDesc] = useState(false);
  const [errorDcPackSize, setErrorDcPackSize] = useState(false);
  const [errorRing, setErrorRing] = useState(false);
  const [errorHicone, setErrorHicone] = useState(false);
  const [errorUpdpackwhse, setErrorUpdPackWhse] = useState(false);
  const [errorVendConvFactor, setErrorVendConvFactor] = useState(false);
  const [errorPluUpcVal00, setErrorPluUpcVal00] = useState({});
  const [errorPluUpcVal01, setErrorPluUpcVal01] = useState({});
  const [errorPluUpcVal, setErrorPluUpcVal] = useState({})

  const defaulProductClassCodeEdited = useRef(false);
  const [isForcenewProduce, setIsForcenewProduce] = useState(false);

  useEffect(() => {
    //incase of FLPRD dont populate the SMIC values, enable pack and vcf to be editable
    if (augmentationServiceDepartment === "FLPRD") {
      setSelectedGroup(0);
      setSelectedProductionGroup(0);
      setIsForcenewProduce(true);
    } else {
      setIsForcenewProduce(false);
    }
  }, [augmentationServiceDepartment])

  useEffect(() => {
    if (UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.augOverCmplnInd === 'N' && !props.disableDefaultNeedReview) {
      setNeedReview(true)
    }
    if (!UpdateAugmentationManualSearch || !UpdateAugmentationManualSearch.uiEceptionSrcDto) { return }
    if (UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd === "C") {
      if (UpdateAugmentationManualSearch.uiEceptionSrcDto.markedAsDead === true) {
        setAlreadySavedItem("Item has been marked as dead.");
      }
      else if (UpdateAugmentationManualSearch.uiEceptionSrcDto.manualMapped === true) {
        setAlreadySavedItem("Item marked for old conversion process.");
      }
      else {
        setAlreadySavedItem("Item has already been worked.");
      }
    }

    setPrivateLabel(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updPtLabelInd : "")
    setUpdSize(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updSize : "")
    setInnerPack(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.innerPack : "1")
    setUpdSizeNmbr(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updSizeNmbr : "")
    setUpdSizeUom(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updSizeUom : "EA")
    setEthnicTypeCd(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.ethnicTypeCd : "")
    setUpdUsgeInd(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updUsgeInd : "")
    setPckTypeCd(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.pckTypeCd : "")
    setUpdDispFlag(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updDispFlag : "")
    setUpdItmDesc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updItmDesc : "")
    setUpdWhseItmDesc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updWhseItmDesc : "")
    setUpdRtlItmDesc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updRtlItmDesc : "")
    setUpdIntenetItemDesc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updIntenetItemDesc : "")
    setUpdPosDesc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updPosDesc : "")
    setSelectedUpc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.primayUpcString : "")
    setPluCd(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.pluCd : "0")
    setDcPackDesc(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.dcPackDesc : UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.packwhse : "")
    setDcPackSize(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.dcSizeDsc : UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updSize : "")
    setProdWght(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.prodwght : "")
    setHandlingCode(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.handlingCode : "")
    setBuyerNum(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.buyerNum : "")
    setRandomWtCd(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.randomWtCd : "")
    setSellByDays(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.sellByDays : "")
    setUseByDays(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.useByDays : "")
    setPullByDays(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.pullBydays : "")
    setAutoCostInv(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.autoCostInv : "")
    setBillingType(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.billingType : "")
    setRetailUnitPack(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.retailUnitPack : UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.packwhse : "")
    setRing(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.ring : "")
    setHicone(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.hicone : "")
    setFdStmp(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.fdStmp : "")
    setLabelSize(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.labelSize : "")
    setLabelNumbers(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.labelNumbers : "")
    setSgnCount1(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.sgnCount1 : "")
    setSgnCount2(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.sgnCount2 : "")
    setSgnCount3(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.sgnCount3 : "")
    setTareCd(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.tareCd : "")
    setConvTeamComments(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.covTeamComment : "")
    setUpdPackWhse(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.updpackwhse : "")
    setVendConvFactor(UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.vendConvFactor : "")
    //resetting the errors
    setErrorGroup(false);
    setErrorClassCode(false);
    setErrorSbClsCd(false);
    setErrorSbSbClsCd(false);
    setErrorProdClassCode(false);
    setErrorPrivateLabel(false);
    setErrorUpdSize(false);
    setErrorUpdSizeNmbr(false);
    setErrorUpdSizeUom(false);
    setErrorUpdUsgeInd(false);
    setErroruUpdUsgeTypeInd(false);
    setErrorUpdDispFlag(false);
    setErrorUpdItmDesc(false);
    setErrorUpdRtlItmDesc(false);
    setErrorUpdInternetItemDesc(false);
    setErrorUpdPosDesc(false);
    setErrorUpdWhseItmDesc(false);
    setErrorInnerPack(false);
    setErrorRetailUnitPack(false);
    setErrorPluCd(false);
    setErrorProductClassCode(false);
    setErrorDcPackDesc(false);
    setErrorDcPackSize(false);
    setErrorRing(false);
    setErrorHicone(false);
    setErrorUpdPackWhse(false);
    setErrorVendConvFactor(false);
    setErrorPluUpcVal({});
    setErrorPluUpcVal00({});
    setErrorPluUpcVal01({});
  }, [UpdateAugmentationManualSearch])



  const updPackWhseOptions = useMemo(() => {
    let temp = [];
    temp.push("1");
    if (UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.packwhse !== 1) {
      temp.pop("1");
      temp.push(UpdateAugmentationManualSearch.newItemDto.packwhse)
      temp.push("1");
    }
    console.log("temp" + temp);
    return temp
  }, [UpdateAugmentationManualSearch])

  const uomCodeOptions = useMemo(() => {
    return uomList ? uomList.map((data) => {
      return { label: data.uomCode, value: data.uomCode }
    }) : []
  }, [uomList])

  const upcVd = useMemo(() => {
    return UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.upcVoList.map((upcVo) => {
      return { label: `${upcVo.upc} ${upcVo.primaryUPCInd}`, value: `${upcVo.upc} ${upcVo.primaryUPCInd}` }
    }) : []
  }, [UpdateAugmentationManualSearch])

  const updUsgeIndOptions = [
    { value: "E", label: "E (Expense)" },
    { value: "M", label: "M (Material)" },
    { value: "Q", label: "Q (Coupons)" },
    { value: "R", label: "R (Resale)" }
  ]

  useEffect(() => {
    if (UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto) {
      if (updUsgeInd === 'E') {
        if (UpdateAugmentationManualSearch.newItemDto.updUsageTypInd !== 'L' &&
          UpdateAugmentationManualSearch.newItemDto.updUsageTypInd !== 'O' &&
          UpdateAugmentationManualSearch.newItemDto.updUsageTypInd !== 'W')
          setUpdUsgeTypeInd('L');
        else setUpdUsgeTypeInd(UpdateAugmentationManualSearch.newItemDto.updUsageTypInd)
      }

      if (updUsgeInd === 'M') {
        setUpdUsgeTypeInd("M")
      }

      if (updUsgeInd === 'Q') {
        setUpdUsgeTypeInd(" ")
      }

      if (updUsgeInd === 'R') {
        if (UpdateAugmentationManualSearch.newItemDto.updUsageTypInd !== 'C' &&
          UpdateAugmentationManualSearch.newItemDto.updUsageTypInd !== 'R' &&
          UpdateAugmentationManualSearch.newItemDto.updUsageTypInd !== 'S')
          setUpdUsgeTypeInd('C');
        else {
          setUpdUsgeTypeInd(UpdateAugmentationManualSearch.newItemDto.updUsageTypInd)
        }
      }
    }
  }, [updUsgeInd, UpdateAugmentationManualSearch])

  useEffect(() => {
    if (UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto) {
      loadSMICGroupCode();
      loadProductionGroupCode();
    }
  }, [UpdateAugmentationManualSearch])

  const updUsgeTypeIndOptions = useMemo(() => {
    let updUsgeIndOptions2 = [];
    console.log("updUsge")
    if (!UpdateAugmentationManualSearch || !UpdateAugmentationManualSearch.newItemDto) {
      return []
    }
    if (updUsgeInd === 'E') {
      updUsgeIndOptions2.push('L');
      updUsgeIndOptions2.push('O');
      updUsgeIndOptions2.push('W');
    }
    if (updUsgeInd === 'M') {
      updUsgeIndOptions2.push('M');
    }
    if (updUsgeInd === 'Q') {
      updUsgeIndOptions2.push('');
    }
    if (updUsgeInd === 'R') {
      updUsgeIndOptions2.push('C');
      updUsgeIndOptions2.push('R');
      updUsgeIndOptions2.push('S');
    }
    console.log(updUsgeIndOptions2)
    return updUsgeIndOptions2
  }, [updUsgeInd])

  /**
       * Method to Load SMIC Group
       */
  const loadSMICGroupCode = () => {
    /**
   * Function to evaluate production class code
   */
    setProductionClassCode(UpdateAugmentationManualSearch.newItemDto.productClsCd)
    memiuServices.getSmicDetail()
      .then((response) => {
        if (response.data != null) {
          const groups = response.data.map((groupObject) => {
            return { label: `${groupObject.code} ${groupObject.codeDesc}`, value: groupObject.code }
          })
          AppData.setGroupDetail(groups);
          let groupCodeSelected = null
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            for (var i = 0; i < groups.length; i++) {
              if (groups[i].value == UpdateAugmentationManualSearch.newItemDto.grpCd) {
                setSelectedGroup(groups[i].value);
                loadSMICCategoryCode(groups[i].value);
                groupCodeSelected = groups[i].value;
                break;
              }
            }
            if (groupCodeSelected === null) {
              setSelectedGroup(0);
              loadSMICCategoryCode(0);
            }
            if (groupCodeSelected !== '84') {
              setDisableProductClassCode(true)
            } else {
              setDisableProductClassCode(false)
            }
          }
        } else {
          setSelectedGroup("")
          AppData.setGroupDetail([]);
        }
      })
      .catch((response) => {
        //function handles error condition
      });
  };

  /**
   * Method to Load SMIC Category
   */
  const loadSMICCategoryCode = (groupCode) => {
    if (groupCode == null) {
      setDisableProductClassCode(true);
    }


    memiuServices.getSmicDetail(groupCode)
      .then((response) => {
        if (response.data !== null) {
          const data = response.data.map((categoryObject) => {
            return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
          })
          setCategory(data)
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            let selectedCategoryCode = null
            for (var i = 0; i < data.length; i++) {
              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.ctgryCd) {
                selectedCategoryCode = data[i].value;
                setSelectedCategory(data[i].value)
                loadSMICClassCode(groupCode, selectedCategoryCode);
                if (data[i].value !== '84') {
                  setProductionClassCode(makeProductClassCode(groupCode, selectedCategoryCode));
                } else {
                  if ((UpdateAugmentationManualSearch.newItemDto.productClsCd == '' || UpdateAugmentationManualSearch.newItemDto.productClsCd == null || UpdateAugmentationManualSearch.newItemDto.productClsCd.length == 0)) {
                    setProductionClassCode(makeProductClassCode(groupCode, selectedCategoryCode));
                  } else {
                    setProductionClassCode(UpdateAugmentationManualSearch.newItemDto.productClsCd)
                  }
                  setProductionClassCode(false)
                }
                break;
              }
            }
            if (selectedCategory === null) {
              // $scope.selectedCategoryCode = 0;
              setSelectedCategory(0)
              loadSMICClassCode(0, 0);
            }
          }
        } else {
          setSelectedCategory("")
          setCategory([])
        }
      })
      .catch((response) => {
        //function handles error condition
      })
  };


  /**
   * Method to Load SMIC Class
   */
  const loadSMICClassCode = (groupCode, categoryCode) => {
    if (groupCode == null) {
      groupCode = 0;
    }
    if (categoryCode == null) {
      categoryCode = 0;
    }


    memiuServices.getSmicDetail(groupCode, categoryCode)
      .then((response) => {
        if (response.data != null) {
          const data = response.data.map((categoryObject) => {
            return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
          })
          setClassCode(data)
          let selectedClassCode = null
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {

            for (var i = 0; i < data.length; i++) {
              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.clsCd) {
                setSelectedClassCode(data[i].value);
                selectedClassCode = data[i].value
                loadSMICSubClassCode(groupCode, categoryCode, data[i].value);
                break;
              }
            }
            if (selectedClassCode === null) {
              setSelectedClassCode(0)
              loadSMICSubClassCode(0, 0, 0);
            }
          }
        } else {
          setSelectedClassCode("");
          setClassCode([])
        }
      })
      .catch((response) => {
        //function handles error condition
      });
  };

  /**
   * Method to Load SMIC Sub Class
   */
  const loadSMICSubClassCode = (groupCode, categoryCode, classCode) => {
    if (groupCode == null) {
      groupCode = 0;
    }
    if (categoryCode == null) {
      categoryCode = 0;
    }
    if (classCode == null) {
      classCode = 0;
    }

    memiuServices.getSmicDetail(groupCode, categoryCode, classCode)
      .then((response) => {
        if (response.data != null) {
          const data = response.data.map((categoryObject) => {
            return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
          })
          setSubClassCode(data)
          let selectedSubClassCode = null
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            for (var i = 0; i < data.length; i++) {
              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.sbClsCd) {
                selectedSubClassCode = data[i].value;
                setSelectedSubClassCode(data[i].value)
                loadSMICSubSubClassCode(groupCode, categoryCode, classCode, data[i].value);
                break;
              }
            }
            if (selectedSubClassCode == null || selectedSubClassCode == undefined) {
              // $scope.selectedSubClassCode = 0;
              setSelectedSubClassCode(0)
              loadSMICSubSubClassCode(0, 0, 0, 0);
            }
          }
        } else {
          setSelectedSubClassCode([]);
          setSubClassCode("")
        }
      })
      .catch((response) => {
        //function handles error condition
      });
  };

  /**
   * Method to Load SMIC SubSub Class
   */
  const loadSMICSubSubClassCode = (groupCode, categoryCode, classCode, subClassCode) => {
    if (groupCode == null) {
      groupCode = 0;
    }
    if (categoryCode == null) {
      categoryCode = 0;
    }
    if (classCode == null) {
      classCode = 0;
    }
    if (subClassCode == null) {
      subClassCode = 0;
    }

    memiuServices.getSmicDetail(groupCode, categoryCode, classCode, subClassCode)
      .then((response) => {
        if (response.data != null) {
          const data = response.data.map((categoryObject) => {
            return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
          })
          setSubSubClassCode(data)
          let selectedSubClassCode = null
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            for (var i = 0; i < data.length; i++) {
              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.subSbClass) {
                selectedSubSubClassCode = data[i].value;
                setSelectedSubSubClassCode(data[i].value)
                break;
              }
            }
            if (selectedSubSubClassCode == null || selectedSubSubClassCode == undefined) {
              // $scope.selectedSubSubClassCode = 0;
              setSelectedSubSubClassCode(0)
            }
          }
        } else {
          setSelectedSubClassCode("")
          setSubSubClassCode([])
        }
      })
      .catch((response) => {
        //function handles error condition
      });
  };

  const makeProductClassCode = useCallback((selectedGroup, selectedCategory) => {
    console.log(selectedGroup, selectedCategory)
    if ((selectedGroup && selectedGroup !== "") || (selectedCategory && selectedCategory !== "")) {
      return `${selectedGroup.toString().length === 1 && selectedGroup !== 0 ? "0" + selectedGroup : selectedGroup}${selectedCategory.toString().length === 1 && selectedCategory.toString() !== 0 ? "0" + selectedCategory : selectedCategory}`
    } else if (UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && !defaulProductClassCodeEdited.current) {
      return UpdateAugmentationManualSearch.newItemDto.productClsCd
    } else {
      return "";
    }
  }, [UpdateAugmentationManualSearch, defaulProductClassCodeEdited])


  // /**
  //  * Method to Load ProductionGroupCode
  //  */
  const loadProductionGroupCode = () => {

    memiuServices.getPrdctncdDetails()
      .then((response) => {
        if (response.data != null) {
          const data = response.data.map((groupObject) => {
            return { label: `${groupObject.code} ${groupObject.codeDesc}`, value: groupObject.code }
          })
          AppData.setProductionGroupDetail(data);
          let selectedProductionGroup = null
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            for (var i = 0; i < data.length; i++) {

              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.productionGrpCd) {
                setSelectedProductionGroup(data[i].value);
                loadProductionCategoryCode(data[i].value);
                selectedProductionGroup = data[i].value
                break;
              }
            }
            if (selectedProductionGroup == null || selectedProductionGroup == undefined) {
              // $scope.selectedProductionGroupCode = 0;
              setSelectedProductionGroup(0);
              loadProductionCategoryCode(0);
            }
          }
        } else {
          setSelectedProductionGroup("");
          AppData.setProductionGroupDetail([]);
        }
      })
      .catch((response) => {
        //function handles error condition
      });
  };

  /**
   * Method to Load ProductionCategoryCode
   */
  const loadProductionCategoryCode = (productionGroupCode) => {
    if (productionGroupCode == null) {
      productionGroupCode = 0;
    }

    memiuServices.getPrdctncdDetails(productionGroupCode)
      .then((response) => {
        if (response.data != null) {
          let selectedProductionCategoryCode = null;
          const data = response.data.map((groupObject) => {
            return { label: `${groupObject.code} ${groupObject.codeDesc}`, value: groupObject.code }
          })
          setProductionCategory(data);
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            for (var i = 0; i < data.length; i++) {
              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.productionCtgryCd) {
                selectedProductionCategoryCode = data[i].value;
                setSelectedProdCategory(data[i].value)
                loadProductionClassCode(productionGroupCode, data[i].value);
                break;
              }
            }
            if (selectedProductionCategoryCode == null || selectedProductionCategoryCode == undefined) {
              // $scope.selectedProductionCategoryCode = 0;
              setSelectedProdCategory(0)
              // alert('no response',ProductionCategoryCodeDetailsUrl)
              loadProductionClassCode(0, 0);
            }
          }
        } else {
          setSelectedProdCategory("")
          setProductionCategory([])
        }
      }, function (response) {
        //function handles error condition
      });
  };

  /**
   * Method to Load ProductionClassCode
   */
  const loadProductionClassCode = (productionGroupCode, productionCategoryCode) => {
    if (productionGroupCode == null) {
      productionGroupCode = 0;
    }
    if (productionCategoryCode == null) {
      productionCategoryCode = 0;
    }

    memiuServices.getPrdctncdDetails(productionGroupCode, productionCategoryCode)
      .then(function (response) {
        if (response.data != null) {
          let selectedProdClassCode = null;
          const data = response.data.map((groupObject) => {
            return { label: `${groupObject.code} ${groupObject.codeDesc}`, value: groupObject.code }
          })
          setProdClassCode(data);
          if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'C' || UpdateAugmentationManualSearch.uiEceptionSrcDto.excptnProInd == 'R') {
            for (var i = 0; i < data.length; i++) {
              if (data[i].value == UpdateAugmentationManualSearch.newItemDto.productionClsCd) {
                selectedProdClassCode = data[i].value;
                setSelectedProdClassCode(data[i].value)
                break;
              }
            }
            if (selectedProdClassCode == null || selectedProdClassCode == undefined) {
              // $scope.selectedProductionClassCode = 0;
              setSelectedProdClassCode(0)
            }
          }
        } else {
          setProdClassCode([]);
          setSelectedProdClassCode("")
        }
      }, function (response) {
        //function handles error condition
      });
  };

  const handleTableModel = (type = "source") => {
    const columnData = UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.upcVoList.map((data) => {
      return { "UPCs & Unit Type": data.upc }
    }) : []
    AppData.setTableModal(true, ["UPCs & Unit Type"], columnData)
  }

  const handleSelectGroup = useCallback((group) => {
    setSelectedGroup(group)
    setSelectedCategory("")
    setErrorProductClassCode(false)
    setSelectedClassCode("")
    setSelectedSubClassCode("");
    setSelectedSubSubClassCode("");
    setSubClassCode([])
    setSubSubClassCode([]);
    setClassCode([]);
    setProductionClassCode(makeProductClassCode(group, ""))
    defaulProductClassCodeEdited.current = true
    memiuServices.getSmicDetail(group)
      .then((res) => {
        const data = res.data.map((categoryObject) => {
          return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
        })
        setCategory(data)
      })
      .catch((error) => {
        setCategory([])
      })
  }, [])


  const handleSelectProductionGroup = useCallback((group) => {
    setSelectedProductionGroup(group)
    setSelectedProdCategory("");
    setSelectedProdClassCode("");

    memiuServices.getPrdctncdDetails(group)
      .then((res) => {
        const data = res.data.map((categoryObject) => {
          return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
        })
        setProductionCategory(data)
      })
      .catch((error) => {
        setProductionCategory([])
      })
  }, [])

  const handleGoHome = () => {
    AppData.setMemi03SkuPayload({});
    history.goBack()
  }


  const handleSelectCategory = useCallback((category) => {
    setSelectedCategory(category)
    setSelectedClassCode("")
    setSelectedSubSubClassCode("");
    setSelectedSubClassCode("");
    setErrorProductClassCode(false)
    defaulProductClassCodeEdited.current = true
    setSubClassCode([])
    setSubSubClassCode([])
    setProductionClassCode(makeProductClassCode(selectedGroup, category))
    memiuServices.getSmicDetail(selectedGroup, category)
      .then((res) => {
        const data = res.data.map((categoryObject) => {
          return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
        })
        setClassCode(data)
      })
      .catch((error) => {
        setClassCode([])
      })
  }, [selectedGroup])

  const handleSelectProdCategory = useCallback((category) => {
    setSelectedProdCategory(category)
    setSelectedProdClassCode("")
    setProdClassCode([]);
    memiuServices.getPrdctncdDetails(selectedProductionGroup, category)
      .then((res) => {
        const data = res.data.map((categoryObject) => {
          return { label: `${categoryObject.code} ${categoryObject.codeDesc}`, value: categoryObject.code }
        })
        setProdClassCode(data)
      })
      .catch((error) => {
        setProdClassCode([])
      })
  }, [selectedProductionGroup])

  const handleSelectedClassCode = useCallback((classCode) => {
    setSelectedClassCode(classCode)
    setSelectedSubClassCode("")
    setSelectedSubClassCode("");
    setSubSubClassCode([]);
    memiuServices.getSmicDetail(selectedGroup, selectedCategory, classCode)
      .then((res) => {
        const data = res.data.map((Obj) => {
          return { label: `${Obj.code} ${Obj.codeDesc}`, value: Obj.code }
        })
        setSubClassCode(data)
      })
      .catch((error) => {
        setSubClassCode([])
      })
  }, [selectedGroup, selectedCategory])

  const handleSelectedSubClassCode = useCallback((subClassCode) => {
    setSelectedSubClassCode(subClassCode)
    setSelectedSubSubClassCode("");
    memiuServices.getSmicDetail(selectedGroup, selectedCategory, selectedClassCode, subClassCode)
      .then((res) => {
        const data = res.data.map((Obj) => {
          return { label: `${Obj.code} ${Obj.codeDesc}`, value: Obj.code }
        })
        setSubSubClassCode(data)
      })
      .catch((error) => {
        setSubSubClassCode([])
      })
  }, [selectedGroup, selectedCategory, selectedClassCode])

  const AugmentationValidateSave = (type) => {
    let AugmentedSrcEditDetails = UpdateAugmentationManualSearch;
    const { userId } = authTokenCookie();
    AugmentedSrcEditDetails.newItemDto.covTeamComment = convTeamComments
    AugmentedSrcEditDetails.newItemDto.updPtLabelInd = privateLabel;
    AugmentedSrcEditDetails.newItemDto.updSize = updSize;
    AugmentedSrcEditDetails.newItemDto.updSizeNmbr = String(updSizeNmbr);
    AugmentedSrcEditDetails.newItemDto.updSizeUom = updSizeUom;
    AugmentedSrcEditDetails.newItemDto.ethnicTypeCd = ethnicTypeCd;
    AugmentedSrcEditDetails.newItemDto.updUsgeInd = updUsgeInd;
    AugmentedSrcEditDetails.newItemDto.updUsageTypInd = updUsgeTypeInd;
    AugmentedSrcEditDetails.newItemDto.pckTypeCd = pckTypeCd;
    AugmentedSrcEditDetails.newItemDto.updDispFlag = updDispFlag;
    AugmentedSrcEditDetails.newItemDto.updItmDesc = updItmDesc;
    AugmentedSrcEditDetails.newItemDto.updWhseItmDesc = updWhseItmDesc;
    AugmentedSrcEditDetails.newItemDto.updRtlItmDesc = updRtlItmDesc;
    AugmentedSrcEditDetails.newItemDto.updPosDesc = updPosDesc;
    AugmentedSrcEditDetails.newItemDto.pluCd = pluCd;
    AugmentedSrcEditDetails.newItemDto.dcPackDesc = dcPackDesc;
    AugmentedSrcEditDetails.newItemDto.dcSizeDsc = dcPackSize;
    AugmentedSrcEditDetails.newItemDto.prodwght = prodwght;
    AugmentedSrcEditDetails.newItemDto.handlingCode = handlingCode;
    AugmentedSrcEditDetails.newItemDto.buyerNum = buyerNum;
    AugmentedSrcEditDetails.newItemDto.randomWtCd = randomWtCd;
    AugmentedSrcEditDetails.newItemDto.sellByDays = sellByDays;
    AugmentedSrcEditDetails.newItemDto.pullBydays = pullBydays;
    AugmentedSrcEditDetails.newItemDto.useByDays = useByDays;
    AugmentedSrcEditDetails.newItemDto.autoCostInv = autoCostInv;
    AugmentedSrcEditDetails.newItemDto.billingType = billingType;
    AugmentedSrcEditDetails.newItemDto.retailUnitPack = retailUnitPack;
    AugmentedSrcEditDetails.newItemDto.ring = ring;
    UpdateAugmentationManualSearch.newItemDto.innerPack = innerPack
    AugmentedSrcEditDetails.newItemDto.hicone = hicone;
    AugmentedSrcEditDetails.newItemDto.fdStmp = fdStmp;
    AugmentedSrcEditDetails.newItemDto.labelSize = labelSize;
    AugmentedSrcEditDetails.newItemDto.labelNumbers = labelNumbers
    AugmentedSrcEditDetails.newItemDto.sgnCount1 = sgnCount1;
    AugmentedSrcEditDetails.newItemDto.sgnCount2 = sgnCount2;
    AugmentedSrcEditDetails.newItemDto.sgnCount3 = sgnCount3;
    AugmentedSrcEditDetails.newItemDto.tareCd = tareCd;
    AugmentedSrcEditDetails.newItemDto.updIntenetItemDesc = updIntenetItemDesc;
    AugmentedSrcEditDetails.newItemDto.vendConvFactor = vendConvFactor;
    AugmentedSrcEditDetails.newItemDto.updPackWhse = updPackWhse


    setErrorGroup(false);
    setErrorClassCode(false);
    setErrorSbClsCd(false);
    setErrorSbSbClsCd(false);
    setErrorProdClassCode(false);
    setErrorPrivateLabel(false);
    setErrorUpdSize(false);
    setErrorUpdSizeNmbr(false);
    setErrorUpdSizeUom(false);
    setErrorUpdUsgeInd(false);
    setErroruUpdUsgeTypeInd(false);
    setErrorUpdDispFlag(false);
    setErrorUpdItmDesc(false);
    setErrorUpdRtlItmDesc(false);
    setErrorUpdInternetItemDesc(false);
    setErrorUpdPosDesc(false);
    setErrorUpdWhseItmDesc(false);
    setErrorInnerPack(false);
    setErrorRetailUnitPack(false);
    setErrorPluCd(false);
    setErrorProductClassCode(false);
    setErrorDcPackDesc(false);
    setErrorDcPackSize(false);
    setErrorRing(false);
    setErrorHicone(false);
    setErrorUpdPackWhse(false);
    setErrorVendConvFactor(false);
    setErrorUpdWhseItmDesc(false);
    let isValid = true;
    let isCharacterValid = true;
    let isNumberValid = true;
    let isRetailUnitPackZero = false
    if (!needReview) {
      if (selectedGroup === "" || selectedGroup === null) {
        isValid = false;
        setErrorGroup(true);
      }

      if ((selectedClassCode === "" || selectedClassCode === null ||  selectedClassCode == 0) && classCode.length > 0) {
        isValid = false;
        setErrorClassCode(true)
      }
      if ((selectedSubClassCode === "" || selectedSubClassCode === null || selectedSubClassCode == 0) && subClassCode.length > 0) {
        isValid = false;
        setErrorSbClsCd(true)
      }

      if ((selectedSubSubClassCode === "" || selectedSubSubClassCode === null || selectedSubSubClassCode == 0) && subSubClassCode.length > 0) {
        isValid = false;
        setErrorSbSbClsCd(true)
      }

      if (privateLabel === null || String(privateLabel).trim().length === 0) {
        isValid = false;
        setErrorPrivateLabel(true);
      }
      if (updSize === null || String(updSize).trim().length === 0) {
        isValid = false;
        setErrorUpdSize(true);
      }

      if (updSizeNmbr === null || String(updSizeNmbr).trim().length === 0) {
        isValid = false;
        setErrorUpdSizeNmbr(true);
      }
      if (updSizeUom === null || String(updSizeUom).trim().length === 0) {
        isValid = false;
        setErrorUpdSizeUom(true);
      }
      if (updUsgeInd === null || String(updUsgeInd).trim().length === 0) {
        isValid = false;
        setErrorUpdUsgeInd(true);
      }
      if (updUsgeTypeInd === null || String(updUsgeTypeInd).length === 0) {
        isValid = false;
        setErroruUpdUsgeTypeInd(true);
      }
      if (updDispFlag === null || String(updDispFlag).trim().length === 0) {
        isValid = false;
        setErrorUpdDispFlag(true);
      }
      if (updItmDesc === null || String(updItmDesc).trim().length === 0) {
        isValid = false
        setErrorUpdItmDesc(true);
      }
      if (updWhseItmDesc === null || String(updWhseItmDesc).trim().length === 0) {
        isValid = false;
        setErrorUpdWhseItmDesc(true);
      }
      if (updRtlItmDesc === null || String(updRtlItmDesc).trim().length === 0) {
        isValid = false;
        setErrorUpdRtlItmDesc(true);
      }

      if (updIntenetItemDesc === null || String(updIntenetItemDesc).trim().length === 0) {
        isValid = false;
        setErrorUpdInternetItemDesc(true);
      }

      if (updPosDesc === null || String(updPosDesc).trim().length === 0) {
        isValid = false;
        setErrorUpdPosDesc(true);
      }

      if (innerPack === null || String(innerPack).trim().length === 0) {
        isValid = false;
        setErrorInnerPack(true);
      }
      if (retailUnitPack === null || String(retailUnitPack).trim().length === 0) {
        isValid = false;
        setErrorRetailUnitPack(true);
      }

      if (!Number(retailUnitPack) || Number(retailUnitPack) === 0) {
        isRetailUnitPackZero = true;
        setErrorRetailUnitPack(true);
      }
      if (pluCd === null || String(pluCd).trim().length === 0) {
        setErrorPluCd(true);
        isValid = false;
      }

      if (isForcenewProduce && (updPackWhse === null || String(updPackWhse).trim().length == 0 || updPackWhse === 0)) {
        setErrorUpdPackWhse(true);
        isValid = false;
      }

      if (isForcenewProduce && (vendConvFactor === null || String(vendConvFactor).trim().length === 0 || vendConvFactor === 0)) {
        setErrorVendConvFactor(true);
        isValid = false;
      }

      // if (selectedProdClassCode === "") {
      //   setErrorProdClassCode(true);
      //   isValid = false;
      // }
      // if (dcPackDesc.length === 0 || dcPackDesc === null) {
      if (dcPackDesc === null || dcPackDesc.toString().trim().length === 0) {
        setErrorDcPackDesc(true);
        isValid = false;
      }
      if (ring.trim().length === 0 || ring === null) {
        setErrorRing(true);
        isValid = false;
      }
      if (hicone.length === 0 || hicone === null) {
        setErrorHicone(true);
        isValid = false;
      }

      isNumberValid = numberValidation(AugmentedSrcEditDetails);
      isCharacterValid = specialCharacterValidation(AugmentedSrcEditDetails);


      let errors = [];
      if (!isCharacterValid) {
        errors.push("Special characters not allowed.")
      }

      if (!isNumberValid) {
        errors.push("Invalid number in Num Size field");
      }


      if (isRetailUnitPackZero) {
        errors.push("Retail Unit Pack cannot be Zero or Empty.");

      }

      if (!isValid) {
        errors.push("Highlighted fields are Mandatory.");

      }

      if (errors.length > 0) {
        AppData.setAlertBox(true, errors)
        return
      }
    }
    //			Additional edit UPC/PLU added
    let editUpdUpc00 = [];
    let editUpdUpc01 = [];
    let editUpdUpc = [];
    let isUPC = false;

    if (AugmentedSrcEditDetails.newItemDto.updPlu) {
      for (let i = 0; i < AugmentedSrcEditDetails.newItemDto.updPlu.length; i++) {
        let upcObject00 = {};
        if (document.getElementById('pluUpcVal00_' + i).value != "") {
          upcObject00.sourceUpc = (AugmentedSrcEditDetails.newItemDto.updPlu[i].sourceUpc).replace(/\-/g, "");
          upcObject00.editedUpc = document.getElementById('pluUpcVal00_' + i).value;
          setErrorPluUpcVal00((value) => { return { ...value, [`${i}`]: false } })
        } else {
          setErrorPluUpcVal00((value) => { return { ...value, [`${i}`]: true } })
          isValid = false;
        }
        editUpdUpc00.push(upcObject00);
      }
      AugmentedSrcEditDetails.newItemDto.updPlu = editUpdUpc00;
    }
    if (AugmentedSrcEditDetails.newItemDto.updUpc) {
      for (let i = 0; i < AugmentedSrcEditDetails.newItemDto.updUpc.length; i++) {
        let upcObject01 = {};
        if (document.getElementById('pluUpcVal01_' + i).value != "") {
          upcObject01.sourceUpc = (AugmentedSrcEditDetails.newItemDto.updUpc[i].sourceUpc).replace(/\-/g, "");
          upcObject01.editedUpc = document.getElementById('pluUpcVal01_' + i).value;
          setErrorPluUpcVal01((value) => { return { ...value, [`${i}`]: false } })
        } else {
          setErrorPluUpcVal01((value) => { return { ...value, [`${i}`]: true } })
          document.getElementById('pluUpcVal01_' + i).style.borderColor = "red";
          isValid = false;
        }
        editUpdUpc01.push(upcObject01);
      }
      AugmentedSrcEditDetails.newItemDto.updUpc = editUpdUpc01;
    }

    if (AugmentedSrcEditDetails.newItemDto.updUpc === null && AugmentedSrcEditDetails.newItemDto.updPlu == null) {
      for (let i = 0; i < AugmentedSrcEditDetails.newItemDto.upcVoList.length; i++) {
        let upcObject = {};
        if (document.getElementById('pluUpcVal_' + i).value != "") {
          upcObject.sourceUpc = (AugmentedSrcEditDetails.newItemDto.upcVoList[i].upc).replace(/\-/g, "");
          upcObject.editedUpc = document.getElementById('pluUpcVal_' + i).value;
          document.getElementById('pluUpcVal_' + i).style.removeProperty('border');
          setErrorPluUpcVal((value) => { return { ...value, [`${i}`]: false } })
          if (upcObject.sourceUpc > 99999) {
            isUPC = true;
          }
        } else {
          setErrorPluUpcVal((value) => { return { ...value, [`${i}`]: true } })

          document.getElementById('pluUpcVal_' + i).style.borderColor = "red";
          isValid = false;
        }
        editUpdUpc.push(upcObject);
      }
      if (isUPC == true) {
        AugmentedSrcEditDetails.newItemDto.updUpc = editUpdUpc;
      } else {
        AugmentedSrcEditDetails.newItemDto.updPlu = editUpdUpc;
      }
    }
    //			Additional edit UPC/PLU added - END
    if (isValid == true && isCharacterValid == true && isNumberValid == true) {
      if (needReview) {
        AugmentedSrcEditDetails.newItemDto.augOverCmplnInd = 'N';
        setNeedReview(false);
      } else {
        AugmentedSrcEditDetails.newItemDto.augOverCmplnInd = 'Y';
      }

      AugmentedSrcEditDetails.newItemDto.createId = userId;
      AugmentedSrcEditDetails.uiEceptionSrcDto.updatedUserID = userId;

      if (selectedGroup !== null || selectedGroup !== "") {
        AugmentedSrcEditDetails.newItemDto.grpCd = selectedGroup;
        if (selectedGroup === 0) {
          AugmentedSrcEditDetails.newItemDto.grpCd = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.grpCd = 0;
      }
      if (selectedCategory !== null || selectedCategory !== "") {
        AugmentedSrcEditDetails.newItemDto.ctgryCd = selectedCategory;
        if (selectedCategory === 0) {
          AugmentedSrcEditDetails.newItemDto.ctgryCd = 0;
        }
      }
      if (selectedProdCategory !== null || selectedProdCategory!=="") {
        AugmentedSrcEditDetails.newItemDto.productionCtgryCd = selectedProdCategory;
        if (selectedCategory == 0) {
          AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
        }
      }
      if (selectedClassCode != null || selectedClassCode !== "") {
        AugmentedSrcEditDetails.newItemDto.clsCd = selectedClassCode;
        if (selectedClassCode == 0) {
          AugmentedSrcEditDetails.newItemDto.clsCd = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.clsCd = 0;
      }
      if (selectedSubClassCode !== null || selectedSubClassCode!=="") {
        AugmentedSrcEditDetails.newItemDto.sbClsCd = selectedSubClassCode;
        if (selectedSubClassCode == 0) {
          AugmentedSrcEditDetails.newItemDto.sbClsCd = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.sbClsCd = 0;
      }

      if (selectedSubSubClassCode !== null || selectedSubSubClassCode !== "") {
        AugmentedSrcEditDetails.newItemDto.subSbClass = selectedSubSubClassCode;
        if (selectedSubSubClassCode == 0) {
          AugmentedSrcEditDetails.newItemDto.subSbClass = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.subSbClass = 0;
      }
      if (selectedProductionGroup !== null || selectedProductionGroup !== "") {
        AugmentedSrcEditDetails.newItemDto.productionGrpCd = selectedProductionGroup;
        if (selectedProductionGroup == 0) {
          AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.productionGrpCd = 0;
      }
      if (selectedProdCategory !== null || selectedProdCategory !== "") {
        AugmentedSrcEditDetails.newItemDto.productionCtgryCd = selectedProdCategory;
        if (selectedProdCategory == 0) {
          AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.productionCtgryCd = 0;
      }
      if (selectedProdClassCode !== null) {
        AugmentedSrcEditDetails.newItemDto.productionClsCd = selectedProdClassCode;
        if (selectedProdClassCode == 0) {
          AugmentedSrcEditDetails.newItemDto.productionClsCd = 0;
        }
      } else {
        AugmentedSrcEditDetails.newItemDto.productionClsCd = 0;
      }

      memiuServices.postSaveAugmentationDetails(AugmentedSrcEditDetails)
        .then((response) => {
          //function handles success condition
          let saveStatus = response.data.status;
          if (saveStatus === 1) {
            AppData.setAlertMessage(true, "success", "Saved successfully!");
            if (augmentationServiceKey === "displayer") {
              history.goBack();
            } else if (augmentationServiceKey == "Perishables" || augmentationServiceKey == "Bakery") {
              triggerForceNewPerishables();
              //history.goBack()
            } else {
              
              if (type === "Next") {
                if (pageNumber >= updateaugmentationsku.length - 1) {
                  AppData.setAlertBox(true, "No more items under this department.");
                  history.goBack();
                }
                else {
                  setPageNumber(pageNumber + 1)
                }
              }
            }
          }
          if (saveStatus == 2) {
            let savedObject = response.data;
            let alertMsg = <div style={{ fontSize: "18px", textAlign: "center" }}>
              Please correct the following errors and try again.

              {
                savedObject.errorMessages.map((message, index) => (
                  <div style={{ color: "red", fontSize: "15px", border: "1px solid #edf0f1", marginTop: "15px", backgrounColor: index % 2 === 0 ? "#f9fafa" : "#ffffff" }}>
                    {message}
                  </div>
                ))
              }
            </div>
            AppData.setAlertBox(true, alertMsg);
            return;
          }
          if (saveStatus == 0) {
            triggerForceNewPerishables();
          }
        })
        .catch((response) => {
          //function handles error condition
        });
    }
  }

  const UpdateAugmentation = (type) => {
    if (prodClassCode) {
      if (selectedGroup && selectedCategory) {
        let prdclscode = `${selectedGroup.toString().length === 1 ? "0" + selectedGroup : selectedGroup}${selectedCategory.toString().length === 1 ? "0" + selectedCategory : selectedCategory}`;
        let dummyGrpCode = "GC";
        if (prdclscode !== "" && prdclscode !== null && prdclscode.length !== 0 && prdclscode.length > 2 && selectedGroup !== "") {
          memiuServices.getTargetProdClassValidate(prdclscode, dummyGrpCode)
            .then((response) => {
              //function handles success condition

              if (response.data === true) {
                setErrorProductClassCode(false)
                AugmentationValidateSave(type);
              }
              else {
                AppData.setAlertBox(true, "Invalid Product Class Code.")
                setErrorProductClassCode(true);
                return;
              }

            })
            .catch((error) => {
              console.log(error)
              //function handles error condition
              // setErrorProducClassCode(true);
              // AppData.setAlertBox(true, "Oops! Something wn")
              return;
            });
        }
      }
      else {
        setErrorProductClassCode(true);
        AppData.setAlertBox(true, "Select group code & category code to generate product class code")
        return;
      }
    }
  }

  const createMapRequestsForForceNew = () => {
    let mappingRequests = [];
    let updatedUserID = null;
    const { userId } = authTokenCookie();
    updatedUserID = userId;

    let upcList = UpdateAugmentationManualSearch.newItemDto.upcVoList.map((upcVo) => {
      return upcVo.upc
    })
    upcList.forEach((upc) => {
      if (upc) {
        let mappingrequest = {};
        mappingrequest.companyID = companyId;
        mappingrequest.divisionID = divisionId;
        mappingrequest.sku = updateaugmentationsku[0]
        mappingrequest.upc = upc;
        mappingrequest.mappingstatus = "FORCE_NEW";
        mappingrequest.mappingType = "FORCE_NEW";
        mappingrequest.updatedUserId = updatedUserID;
        if (augmentationServiceKey == "Perishables") {
          mappingrequest.matchedItemTypeCd = augmentationServiceUsageType;
        } else {
          mappingrequest.targetTypeIndicator = augmentationServiceUsageType;
        }
        mappingRequests.push(mappingrequest);
      }
    });

    return mappingRequests
  }

  const triggerForceNewPerishables = () => {
    let request = createMapRequestsForForceNew();
    if (augmentationServiceKey === "Perishables") {
      memiuServices.perishableForceNew(request)
        .finally(() => {
          console.log("trigger force new")
          history.goBack();
        })
    } else if (augmentationServiceKey === "Bakery") {
      memiuServices.bakeryForceNew(request)
        .finally((res) => {
          console.log("trigger force new")
          history.goBack();
        })
    }
    AppData.setAugmentationServiceKey("");
    AppData.setOverideServiceKey("");
  }

  /**
   * Function to check Usage IndType
   */
  const usageIndTypeCheck = useMemo(() => {
    return UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.borrowedUsageDetails
  }, [UpdateAugmentationManualSearch])



  // /**
  //  * Function to check SMIC
  //  */
  const smicCheck = useMemo(() => {
    if (UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto) {
      if (UpdateAugmentationManualSearch.newItemDto.borrowedSMIC == true && augmentationServiceKey != "Displayer" && augmentationServiceKey != "Perishables" && augmentationServiceKey != "Bakery") {
        return false
      } else {
        return true;
      }
    } else {
      return true;
    }
  }, [UpdateAugmentationManualSearch, augmentationServiceKey])

  console.log(errorPluUpcVal00, errorPluUpcVal01, errorPluUpcVal)

  return (
    <Grid container className="overideProcessContainer overideProcessContainerBoxShadow" style={{ paddingLeft: "15px" }}>
      <Grid container>
        <Grid item xs={12} className="overideProcessTitle">
          Edit Items
        </Grid>
        <Grid container className="overideProcessRow" style={{ color: "red", fontWeight: "bold" }}>
          <Grid item xs={2}></Grid>
          <Grid item xs={4}>
            {alreadySavedItem}
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.primaryUPCVo ? UpdateAugmentationManualSearch.newItemDto.primaryUPCVo.upc : ""}
              label="Primary UPC"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              disabled
            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? UpdateAugmentationManualSearch.newItemDto.onhandNbr : ""}
              label="On Hand"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              disabled
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <DropDownMemi
              label="Pack"
              LabelClass="overideProcessRowTitle"
              options={updPackWhseOptions}
              value={updPackWhse}
              setValue={(value) => setUpdPackWhse(value)}
              alignItems="row"
              titleXs={4}
              dropdownXs={3}
              fullWidth
              disabled={!isForcenewProduce}
              disableNone
              error={errorUpdpackwhse}
              classNameMemi="dropdownAugmentationCont"
            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.slotId != null ? UpdateAugmentationManualSearch.newItemDto.slotId : ""}
              label="Slot Id"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              disabled
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              value={vendConvFactor}
              setTextValue={(value) => setVendConvFactor(value)}
              label="VCF"
              error={errorVendConvFactor}
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={3}
              disabled={!isForcenewProduce}
              fullWidth={false}
            />
          </Grid>
          <Grid item xs={6}>
            <DropDownMemi
              label="Private Label"
              LabelClass="overideProcessRowTitle"
              alignItems="row"
              titleXs={4}
              dropdownXs={7}
              disableNone
              options={["H", "N", "G"]}
              value={privateLabel}
              error={errorPrivateLabel}
              classNameMemi="dropdownOverideUsgInd"
              setValue={(value) => setPrivateLabel(value)}
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              label="Desc Size"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              value={updSize}
              error={errorUpdSize}
              setTextValue={(value) => setUpdSize(value)}
              maxLength={10}

            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={innerPack}
              setTextValue={(value) => setInnerPack(value)}
              label="Inner Pack"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              error={errorInnerPack}
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6} style={{ display: "flex", columnGap: "5.4px" }}>
            <TextFieldMemi
              value={updSizeNmbr}
              setTextValue={(value) => setUpdSizeNmbr(value)}
              label="Num Size"
              alignItems="row"
              TextFieldClass="overideContTextField updNumSizeField"
              LabelClass="overideProcessRowTitle"
              labelXs={8}
              textFieldXs={4}
              error={errorUpdSizeNmbr}
            />

            <DropDownMemi
              alignItems="inline"
              LabelClass="overideProcessRowTitle"
              options={uomCodeOptions}
              value={updSizeUom}
              setValue={(value) => setUpdSizeUom(value)}
              disableNone
              classNameMemi="dropdownOverideNumSize"
              error={errorUpdSizeUom}
            />


          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={ethnicTypeCd}
              setTextValue={(value) => setEthnicTypeCd(value)}
              label="Ethnic Type Code"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              maxLength={2}
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6} style={{ display: "flex" }}>
            <Grid item xs={4} className="overideProcessRowTitle">Usage Ind & Type</Grid>
            <div>
              <DropDownMemi
                label=""
                alignItems="inline"
                LabelClass="overideProcessRowTitle"
                options={updUsgeIndOptions}
                value={updUsgeInd}
                setValue={(value) => setUpdUsgeInd(value)}
                classNameMemi="dropdownOverideUsgInd"
                error={errorUpdUsgeInd}
                disabled={usageIndTypeCheck}
              />
            </div>
            &nbsp;
            <div>
              <DropDownMemi
                alignItems="inline"
                LabelClass="overideProcessRowTitle"
                options={updUsgeTypeIndOptions}
                value={updUsgeTypeInd}
                setValue={(value) => setUpdUsgeTypeInd(value)}
                classNameMemi="dropdownOverideNumSize1"
                error={errorUpdUsgeTypeInd}
                disabled={usageIndTypeCheck}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={pckTypeCd}
              setTextValue={(value) => setPckTypeCd(value)}
              label="Package Type Code"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              maxLength={6}
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6} style={{ display: "flex" }}>
            <DropDownMemi
              label="Display"
              alignItems="row"
              LabelClass="overideProcessRowTitle"
              options={["Y", "N"]}
              value={updDispFlag}
              setValue={(value) => setUpdDispFlag(value)}
              titleXs={4}
              classNameMemi="dropdownOverideUsgInd"
              disableNone
              error={errorUpdDispFlag}
            />
          </Grid>
        </Grid>
        <Grid item xs={12} className="overideProcessRow">
          <TextFieldMemi
            value={updItmDesc}
            setTextValue={(value) => setUpdItmDesc(value)}
            label="Item Description"
            alignItems="row"
            TextFieldClass="overideContTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={2}
            textFieldXs={5}
            autoFill
            error={errorUpdItmDesc}
            maxLength={40}
          />
        </Grid>
        <Grid item xs={12} className="overideProcessRow">
          <TextFieldMemi
            value={updWhseItmDesc}
            setTextValue={(value) => setUpdWhseItmDesc(value)}
            label="Warehouse Desc"
            alignItems="row"
            TextFieldClass="overideContTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={2}
            textFieldXs={5}
            error={errorUpdWhseItmDesc}
            maxLength={30}
          />
        </Grid>
        <Grid item xs={12} className="overideProcessRow">
          <TextFieldMemi
            value={updRtlItmDesc}
            setTextValue={(value) => setUpdRtlItmDesc(value)}
            label="S&S Desc"
            alignItems="row"
            TextFieldClass="overideContTextField SFieldTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={2}
            textFieldXs={10}
            fullWidth={false}
            error={errorUpdRtlItmDesc}
            maxLength={64}

          />
        </Grid>
        <Grid item xs={12} className="overideProcessRow">
          <TextFieldMemi
            value={updIntenetItemDesc}
            setTextValue={(value) => setUpdIntenetItemDesc(value)}
            label="Internet Desc"
            alignItems="row"
            TextFieldClass="overideContTextField SFieldTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={2}
            textFieldXs={10}
            fullWidth={false}
            autoFill
            maxLength={75}
            error={errorUpdInternetItemDesc}
          />
        </Grid>
        <Grid item xs={12} className="overideProcessRow">
          <TextFieldMemi
            value={updPosDesc}
            setTextValue={(value) => setUpdPosDesc(value)}
            label="POS Desc"
            alignItems="row"
            TextFieldClass="overideContTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={2}
            textFieldXs={4}
            fullWidth={false}
            autoFill
            error={errorUpdPosDesc}
            maxLength={18}
          />
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.deptCd != null ? UpdateAugmentationManualSearch.newItemDto.deptCd : ""}
              label="Department"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={3}
              autoFill
              disabled
            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto && UpdateAugmentationManualSearch.uiEceptionSrcDto.deptName != null ? UpdateAugmentationManualSearch.uiEceptionSrcDto.deptName : ""}
              label="Department Name"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              value={department[props.selectedDepartment]}
              label="Conv Group"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.categoryDesc : ""}
              label="Category"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.productSrcCd : ""}
              label="Product Src"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto && UpdateAugmentationManualSearch.uiEceptionSrcDto.subCategoryDesc != null ? UpdateAugmentationManualSearch.uiEceptionSrcDto.subCategoryDesc : ""}
              label="Sub Category"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto ? `$ ${UpdateAugmentationManualSearch.newItemDto.cost}` : ""}
              label="Cost"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.uiEceptionSrcDto ? UpdateAugmentationManualSearch.uiEceptionSrcDto.groupDesc : ""}
              label="Group"
              alignItems="row"
              TextFieldClass="overideContDisabledTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              disabled
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={6} style={{ display: "flex", width: "100%" }}>
            <Grid item xs={4} className="overideProcessRowTitle">UPCs</Grid>
            <div>
              <DropDownMemi
                alignItems="inline"
                label="UPCs"
                options={upcVd}
                setValue={(value) => setSelectedUpc(value)}
                value={selectedUpc}
                disableNone
                classNameMemi="dropdownOverideProcessCont"
              />
            </div>
            &nbsp; &nbsp;
            <Add
              style={{ cursor: "pointer", fontSize: "14" }}
              onClick={handleTableModel}

            />
          </Grid>
          <Grid item xs={6}>
            <TextFieldMemi
              value={pluCd}
              setTextValue={(value) => setPluCd(value)}
              label="PLU Code"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={4}
              textFieldXs={7}
              autoFill
              error={errorPluCd}
              maxLength={5}
            />
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xs={12} className="augmentationSubRowTitle">
            SMIC Attributes
          </Grid>
          <Grid container className="overideProcessRow">
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label="Group Code *"
                inlineLabel="-Select Group Code-"
                options={groupDetail}
                setValue={handleSelectGroup}
                value={selectedGroup}
                error={errorGroup}
                LabelClass="overideProcessRowTitle"
                classNameMemi="dropdownAugmentationCont"
                labelXs={4}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}
              />
            </Grid>
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label="Prod Group Code"
                inlineLabel="-Select Production Group Code-"
                options={productionGroupDetail}
                setValue={handleSelectProductionGroup}
                value={selectedProductionGroup}
                classNameMemi="dropdownAugmentationCont"
                LabelClass="overideProcessRowTitle"
                titleXs={4}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}


              />
            </Grid>
          </Grid>
          <Grid container className="overideProcessRow">
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                inlineLabel="-Select Category Code-"
                label="Category Code *"
                options={category}
                setValue={handleSelectCategory}
                value={selectedCategory}
                LabelClass="overideProcessRowTitle"
                classNameMemi="dropdownAugmentationCont"
                labelXs={4}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}

              />
            </Grid>
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label="Prod Category Code"
                inlineLabel="-Select Production Category Code-"
                options={productionCategory}
                setValue={handleSelectProdCategory}
                value={selectedProdCategory}
                classNameMemi="dropdownAugmentationCont"
                LabelClass="overideProcessRowTitle"
                titleXs={4}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}
              />
            </Grid>
          </Grid>
          <Grid container className="overideProcessRow">
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label={`Class Code${classCode.length > 0 ? "*": ""}`}
                options={classCode}
                inlineLabel="-Select Class Code-"
                setValue={handleSelectedClassCode}
                value={selectedClassCode}
                error={errorClassCode}
                LabelClass="overideProcessRowTitle"
                classNameMemi="dropdownAugmentationCont"
                labelXs={4}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}

              />
            </Grid>
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label="Prod Class Code"
                inlineLabel="-Select Production Class Code-"
                options={prodClassCode}
                setValue={(value) => setSelectedProdClassCode(value)}
                value={selectedProdClassCode}
                classNameMemi="dropdownAugmentationCont"
                LabelClass="overideProcessRowTitle"
                titleXs={4}
                error={errorProdClassCode}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}

              />
            </Grid>
          </Grid>
          <Grid container className="overideProcessRow">
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label={`Sub Class Code${subClassCode.length>0 ? "*":""}`}
                inlineLabel="-Select Sub Class Code-"
                options={subClassCode}
                error={errorSbClsCode}
                setValue={handleSelectedSubClassCode}
                value={selectedSubClassCode}
                LabelClass="overideProcessRowTitle"
                classNameMemi="dropdownAugmentationCont"
                labelXs={4}
                dropdownXs={7}
                fullWidth
                disabled={!smicCheck}

              />
            </Grid>
            <Grid item xs={6}>
              <TextFieldMemi
                alignItems="row"
                label="Product Class Code"
                inlineLabel="-Select Production Class Code-"
                error={errorProductClassCode}
                value={productionClassCode}
                disabled={disableProductClassCode}
                TextFieldClass="overideContDisabledTextField overideProductClassCode"
                LabelClass="overideProcessRowTitle"
                labelXs={4}
                textFieldXs={7}
                fullWidth={false}
                maxLength={4}
                setTextValue={(value) => setProductionClassCode(value)}

              />
            </Grid>
          </Grid>
          <Grid container className="overideProcessRow">
            <Grid item xs={6}>
              <DropDownMemi
                alignItems="row"
                label={`Sub Sub Class Code${subSubClassCode.length>0?"*":""}`}
                inlineLabel="-Select Sub Sub Class Code-"
                options={subSubClassCode}
                setValue={(value) => setSelectedSubSubClassCode(value)}
                value={selectedSubSubClassCode}
                LabelClass="overideProcessRowTitle"
                classNameMemi="dropdownAugmentationCont"
                labelXs={4}
                dropdownXs={7}
                fullWidth
                error={errorSbSbClsCd}
                disabled={!smicCheck}

              />
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      <Grid item xs={12} className="augmentationSubRowTitle">
        DC Level Attributes
      </Grid>
      <Grid container>
        <Grid container className="overideProcessRow">
          <Grid item xs={4}>
            <TextFieldMemi
              value={dcPackDesc}
              setTextValue={(value) => setDcPackDesc(value)}
              label="Desc Pack"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              error={errorDcPackDesc}
              labelXs={6}
              textFieldXs={5}
              autoFill
              fullWidth={false}
              maxLength={3}
            />
          </Grid>
          <Grid item xs={4} >
            <TextFieldMemi
              value={dcPackSize}
              setTextValue={(value) => setDcPackSize(value)}
              label="Desc Size"
              alignItems="row"
              error={errorDcPackSize}
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={5}
              textFieldXs={6}
              autoFill
              maxLength={10}

            />
          </Grid>
          <Grid item xs={4} >
            <TextFieldMemi
              value={prodwght}
              setTextValue={(value) => setProdWght(value)}
              label="Prod Wt"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={5}
              textFieldXs={5}
              autoFill
              maxLength={10}
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4}>
            <TextFieldMemi
              value={handlingCode}
              setTextValue={(value) => setHandlingCode(value)}
              label="Handling Code"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={6}
              textFieldXs={5}
              autoFill
              fullWidth={false}
              maxLength={3}
            />
          </Grid>
          <Grid item xs={4} >
            <TextFieldMemi
              value={buyerNum}
              setTextValue={(value) => setBuyerNum(value)}
              label="Buyer Num"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={5}
              textFieldXs={6}
            // error={errorBuy}
            />
          </Grid>
          <Grid item xs={4} >
            <DropDownMemi
              alignItems="row"
              label="Random Wt Cd"
              options={[{ label: "R", value: "R" }]}
              setValue={(value) => setRandomWtCd(value)}
              value={randomWtCd}
              LabelClass="overideProcessRowTitle"
              classNameMemi="dropdownAugmentationCont"
              titleXs={5}
              dropdownXs={5}
              fullWidth
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4}>
            <TextFieldMemi
              value={sellByDays}
              setTextValue={(value) => setSellByDays(value)}
              label="Sell By Days"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={6}
              textFieldXs={5}
              fullWidth={false}
            />
          </Grid>
          <Grid item xs={4} >
            <TextFieldMemi
              value={useByDays}
              setTextValue={(value) => setUseByDays(value)}
              label="Use By Days"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={5}
              textFieldXs={6}
            />
          </Grid>
          <Grid item xs={4} >
            <TextFieldMemi
              value={pullBydays}
              setTextValue={(value) => setPullByDays(value)}
              label="Pull by Days"
              alignItems="row"
              TextFieldClass="overideContTextField"
              LabelClass="overideProcessRowTitle"
              labelXs={5}
              textFieldXs={5}
              autoFill
            />
          </Grid>
        </Grid>
        <Grid container className="overideProcessRow">
          <Grid item xs={4}>
            <DropDownMemi
              alignItems="row"
              label="Auto Cost Inv"
              options={["A", "C", "I"]}
              setValue={(value) => setAutoCostInv(value)}
              value={autoCostInv}
              LabelClass="overideProcessRowTitle"
              classNameMemi="dropdownAugmentationCont"
              titleXs={6}
              dropdownXs={5}
              fullWidth
            />
          </Grid>
          <Grid item xs={4} >
            <DropDownMemi
              alignItems="row"
              label="Billing Type Cd"
              options={[" ", "A"]}
              setValue={(value) => setBillingType(value)}
              value={billingType}
              LabelClass="overideProcessRowTitle"
              classNameMemi="dropdownAugmentationCont"
              titleXs={5}
              dropdownXs={6}
              fullWidth
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12} className="augmentationSubRowTitle">
        ROG/POS Attributes
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4}>
          <TextFieldMemi
            value={retailUnitPack}
            setTextValue={(value) => setRetailUnitPack(value)}
            label="RUP"
            alignItems="row"
            TextFieldClass="overideContTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={6}
            textFieldXs={5}
            autoFill
            error={errorRetailUnitPack}
          />
        </Grid>
        <Grid item xs={4}>
          <DropDownMemi
            alignItems="row"
            label="Ring"
            options={["0", "1", "2", "3", "4", "5"]}
            setValue={(value) => setRing(value)}
            value={ring}
            LabelClass="overideProcessRowTitle"
            classNameMemi="dropdownAugmentationCont"
            titleXs={5}
            error={errorRing}
            dropdownXs={6}
            fullWidth
          />
        </Grid>
        <Grid item xs={4} >
          <DropDownMemi
            alignItems="row"
            label="Hicon"
            options={["0", "1", "2"]}
            setValue={(value) => setHicone(value)}
            value={hicone}
            error={errorHicone}
            LabelClass="overideProcessRowTitle"
            classNameMemi="dropdownAugmentationCont"
            titleXs={5}
            dropdownXs={5}
            fullWidth
          />
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={4}>
          <DropDownMemi
            alignItems="row"
            label="Food Stamp"
            options={["0", "1"]}
            setValue={(value) => setFdStmp(value)}
            value={fdStmp}
            LabelClass="overideProcessRowTitle"
            classNameMemi="dropdownAugmentationCont"
            titleXs={6}
            // error={err}
            dropdownXs={5}
            fullWidth
          />
        </Grid>
        <Grid item xs={4}>
          <DropDownMemi
            alignItems="row"
            label="Tag Size"
            options={["M", "N", "S"]}
            setValue={(value) => setLabelSize(value)}
            value={labelSize}
            LabelClass="overideProcessRowTitle"
            classNameMemi="dropdownAugmentationCont"
            titleXs={5}
            dropdownXs={6}
            fullWidth
          />
        </Grid>
        <Grid item xs={4} >
          <DropDownMemi
            alignItems="row"
            label="Tag Count"
            options={["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]}
            setValue={(value) => setLabelNumbers(value)}
            value={labelNumbers}
            LabelClass="overideProcessRowTitle"
            classNameMemi="dropdownAugmentationCont"
            titleXs={5}
            dropdownXs={5}
            fullWidth
          />
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">

        <Grid item xs={2} className="overideProcessRowTitle">Sign Count </Grid>
        <Grid item xs={2} style={{ display: "flex", width: "fit=content", columnGap: "7px" }}>
          <div>
            <DropDownMemi
              alignItems="inline"
              label=""
              disableNone
              options={["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]}
              value={sgnCount1}
              setValue={(value) => setSgnCount1(value)}
              LabelClass="overideProcessRowTitle"
              classNameMemi="dropdownAugmentationCont dropdownSgnClass"
              fullWidth
              dropdownXs={6}
            />
          </div>
          <div>
            <DropDownMemi
              alignItems="inline"
              label=""
              disableNone
              options={["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]}
              value={sgnCount2}
              setValue={(value) => setSgnCount2(value)}
              LabelClass="overideProcessRowTitle"
              classNameMemi="dropdownAugmentationCont dropdownSgnClass"
              fullWidth
              dropdownXs={12}
            />
          </div>
          <div>
            <DropDownMemi
              alignItems="inline"
              label=""
              disableNone
              options={["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]}
              value={sgnCount3}
              setValue={(value) => setSgnCount3(value)}
              LabelClass="overideProcessRowTitle"
              classNameMemi="dropdownAugmentationCont dropdownSgnClass"
              fullWidth
              dropdownXs={12}
            />
          </div>
        </Grid>
        <Grid item xs={4}>
          <TextFieldMemi
            value={tareCd}
            setTextValue={(value) => setTareCd(value)}
            label="Tare Code"
            alignItems="row"
            TextFieldClass="overideContTextField"
            LabelClass="overideProcessRowTitle"
            labelXs={5}
            textFieldXs={6}
            autoFill
          />
        </Grid>
      </Grid>
      <Grid container className="overideProcessRow">
        <Grid item xs={2} className="overideProcessRowTitle">Edit UPC/PLU</Grid>
        <Grid item xs={8}>
          {
            UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.updPlu ?
              UpdateAugmentationManualSearch.newItemDto.updPlu.map((upc, index) => (
                <OutlinedInput
                  className="overideContTextField"
                  type="checked"

                  id={"pluUpcVal00_" + index}
                  key={upc}
                  defaultValue={upc.editedUpc}
                  maxLength={5}
                  error={errorPluUpcVal00[index] ? true : false}
                />
              ))
              : ""
          }
        </Grid>
      </Grid>
      {
        UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.updUpc ?
          UpdateAugmentationManualSearch.newItemDto.updUpc.map((upc, index) => (
            <Grid container className="overideProcessRow">
              <Grid item xs={2} className="overideProcessRowTitle"></Grid>
              <Grid item xs={4}>
                <OutlinedInput
                  type="checked"
                  className={upc.editedUpc.charAt(2) != 2 || (upc.editedUpc).charAt(2) == 0 && !((upc.editedUpc).charAt(4) == 0 && (upc.editedUpc).charAt(5) == 0 && (upc.editedUpc).charAt(6) == 0 && (upc.editedUpc).charAt(7) == 0 && (upc.editedUpc).charAt(8) == 0) ? "disabledtextfield overideContTextField" : "overideContTextField"}
                  id={"pluUpcVal01_" + index}
                  key={upc}
                  maxLength={12}
                  error={errorPluUpcVal01[index] ? true : false}
                  defaultValue={upc.editedUpc.replaceAll("-", "")}
                  disabled={upc.editedUpc.charAt(2) != 2 || (upc.editedUpc).charAt(2) == 0 && !((upc.editedUpc).charAt(4) == 0 && (upc.editedUpc).charAt(5) == 0 && (upc.editedUpc).charAt(6) == 0 && (upc.editedUpc).charAt(7) == 0 && (upc.editedUpc).charAt(8) == 0)}
                />
              </Grid>
            </Grid>
          ))
          : ""
      }
      <Grid container className="overideProcessRow">
        <Grid item xs={2}></Grid>
        <Grid item xs={8}>
          {
            UpdateAugmentationManualSearch && UpdateAugmentationManualSearch.newItemDto && UpdateAugmentationManualSearch.newItemDto.updPlu === null && UpdateAugmentationManualSearch.newItemDto.updUpc === null ?
              UpdateAugmentationManualSearch.newItemDto.upcVoList.map((upc, index) => (
                <OutlinedInput
                  id={"pluUpcVal_" + index}
                  className={upc.upc.charAt(2) != 2 || (upc.upc).charAt(2) == 0 && !((upc.upc).charAt(4) == 0 && (upc.upc).charAt(5) == 0 && (upc.upc).charAt(6) == 0 && (upc.upc).charAt(7) == 0 && (upc.upc).charAt(8) == 0) ? "disabledtextfield overideContTextField" : "overideContTextField"}
                  key={index}
                  maxLength={12}
                  error={errorPluUpcVal[index] ? true : false}
                  defaultValue={upc.upc.replaceAll("-", "")}
                  disabled={upc.upc.charAt(2) != 2 || (upc.upc).charAt(2) == 0 && !((upc.upc).charAt(4) == 0 && (upc.upc).charAt(5) == 0 && (upc.upc).charAt(6) == 0 && (upc.upc).charAt(7) == 0 && (upc.upc).charAt(8) == 0)} />
              ))
              : ""
          }

        </Grid>
      </Grid>
      <Grid item xs={12} style={{ marginTop: "15px" }}>
        <TextFieldMemi
          label="Conversion Team Comments"
          value={convTeamComments}
          setTextValue={(value) => setConvTeamComments(value)}
          LabelClass="boldLabel"
          TextFieldClass="overideContTextField"
          labelXs={3}
          textFieldXs={4}
          autoFill
          alignItems="row"
          maxLength={100}
        />
      </Grid>
      <Grid item xs={12}>
        <strong>
          Need Further Review
        </strong>
        &nbsp;
        &nbsp;
        <input type="checkbox" checked={needReview} onChange={(e) => setNeedReview(e.target.checked)} disabled={props.disableSaveNext} />
      </Grid>
      <br />
      <br />
      <Grid item xs={12} style={{ display: "flex" }}>
        <ButtonMemi
          classNameMemi="MultiUnitScreenButton"
          btnval="Home"
          onClick={handleGoHome}
        />
        <ButtonMemi
          classNameMemi="MultiUnitScreenButton overideSaveButton"
          btnval="Save"
          btndisabled={disableSaveNext}
          onClick={() => UpdateAugmentation("Save")}
        />
        {
          augmentationServiceKey === "Perishables" || augmentationServiceKey === "Bakery" ?
            <ButtonMemi
              classNameMemi="MultiUnitScreenButton overideSaveButton"
              btnval="Back To Mapping"
              onClick={() => history.goBack()}
            /> : ""
        }
        {
          augmentationServiceKey === "Perishables" || augmentationServiceKey === "Bakery" ? "" :
            <ButtonMemi
              classNameMemi="MultiUnitScreenButton overideCancelButton"
              btnval="Save & Next"
              btndisabled={disableSaveNext}
              onClick={() => UpdateAugmentation("Next")}
            />
        }
      </Grid>
    </Grid >
  )
}

export default memo(EditItems)
