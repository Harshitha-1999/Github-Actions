import React from 'react';
import TextField from '@mui/material/TextField';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import DatePicker from '@mui/lab/DatePicker';
import { Grid } from "@material-ui/core";
import PropTypes from "prop-types";

export default function CalendarMeup(props) {

  return (
    <Grid container>
      <Grid item md={props.alignItems === "row" ? 5 : 12}>
        <label className={props.LabelClass}>{props.label}</label>
      </Grid>
      <Grid item md={props.alignItems === "row" ? 7 : 12}>
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <DatePicker
            variant="outlined"
            className={props.meupcal}
            value={props.value}
            views={['month', 'year', 'day']}
            onChange={(newValue) => {
              props.setValue(newValue);
            }}
            renderInput={(params) => <TextField {...params} />}
          />
        </LocalizationProvider>
      </Grid>
    </Grid>
  );
}

CalendarMeup.propTypes = {
  value: PropTypes.string || PropTypes.number,
  meupcal: PropTypes.string,
  setValue: PropTypes.func,
  LabelClass: PropTypes.string,
  label: PropTypes.string || PropTypes.object,
  alignItems: PropTypes.string
};