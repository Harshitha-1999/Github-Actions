
import React, { useContext, useEffect, useState, useCallback, useRef } from "react";
import ApplicationContext from "../../context/ApplicationContext";
import TableMemi from '../TableMemi/TableMemi';
import { Grid } from "@material-ui/core";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import { memiuServices } from "../../api/memiu/memiuService";
import { useHistory } from 'react-router';
import { authTokenCookie } from 'utils';
import { GetApp, Publish } from "@material-ui/icons";
import TableDisplayerCollapsible from "components/TableMemi/TableDisplayerCollapsible";

function DisplayerItems({ onLoadFunc }) {

    const AppData = useContext(ApplicationContext);
    const history = useHistory();
    const { divisionId, companyId, memi16Data, memi16Criteria, rowData, fileUpload, fileUploadData, textboxModalSearch } = AppData;
    const [deptTableData, setDeptTableData] = useState([]);
    const [selectedRows, setSelectionModel] = useState([]);
    const [ssimsData, setSsimsData] = useState([]);
    const [sourceData, setSourcedata] = useState([]);
    const [selectedSsimsRows, setSelectedSsims] = useState([]);
    const [actualDeptData, setActualDeptData] = useState([])
    const { userId } = authTokenCookie();
    const refContainer = useRef(null);

    const deptColumns = [
        {
            field: 'productSku',
            headerName: 'Product SKU',
            width: 95,
            sortable: false,
            headerClassName: "MultiUnitTableProductSku",
        },
        {
            field: 'itemDesc',
            headerName: 'Item Desc',
            width: 210,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"

        },
        {
            field: 'shippingPackNumber',
            headerName: 'Pack',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'masterCasePackNumber',
            headerName: 'VCF',
            width: 55,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"

        },
        {
            field: 'sizeNumber',
            headerName: 'Size',
            sortable: false,
            width: 60,
            // sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'oneTimeBuyFlag',
            headerName: 'Disp Cand.',
            sortable: false,
            width: 70,
            // sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'multiComponentItemInd',
            headerName: 'Disp',
            sortable: false,
            width: 60,
            // sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'productSourceCode',

            headerName: 'WHSE/DSD',
            sortable: false,
            width: 70,
            // sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'displayCaseUpc',
            headerName: "Case UPC",
            width: 120,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'onHandQty',
            headerName: "OH",
            width: 55,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"

        },
        {
            field: 'onOrderQty',
            headerName: 'OO',
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            width: 55,
        },
        {
            field: 'slot',
            headerName: 'Slot',
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            width: 60,
        },
        {
            field: 'itemCreateDate',
            headerName: 'Item Created Dt.',
            headerClassName: "MultiUnitTableHeader",
            width: 105,
            sortable: false
        },
        {
            field: 'lastShipDate',
            headerName: 'Last Ship / Received Dt.',
            headerClassName: "MultiUnitTableHeader",
            width: 110,
            sortable: false
        },
        {
            field: 'cost',
            headerName: 'Cost',
            headerClassName: "MultiUnitTableHeader",
            width: 60,
            sortable: false,
        }
    ];

    const srcColumns = [
        {
            field: 'productSku',
            headerName: 'Product SKU',
            width: 120,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
        },
        {
            field: 'itemDesc',
            headerName: 'Item Desc',
            width: 190,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'displayCaseUpc',
            headerName: 'Case UPC',
            width: 150,
            sortable: false,
            headerClassName: "MultiUnitTableHeader"
        },
        {
            field: 'cost',
            headerName: 'Cost',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
        }
    ];

    const ssimsColumns = [
        {
            field: 'cic',
            headerName: 'CIC',
            width: 55,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'itemDesc',
            headerName: 'Item Desc',
            width: 100,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'displayCaseUpc',
            headerName: 'Case UPC',
            width: 110,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'cost',
            headerName: 'Cost',
            width: 59,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )

        },
        {
            field: 'displayItem',
            headerName: 'Display Item',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'upcMatch',
            headerName: 'UPC Match',
            width: 65,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'caseUpcMatch',
            headerName: 'Case UPC Match',
            width: 85,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'qtyMatch',
            headerName: 'QTY Match ',
            width: 65,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        },
        {
            field: 'costMatch',
            headerName: 'Cost Match',
            width: 60,
            sortable: false,
            headerClassName: "MultiUnitTableHeader",
            renderCell: (params) => (
                <span className={params.row.cicAlreadyProcessed === "Y" && memi16Data.type === "C"  ? "cicAlreadyProcess" : ""}>
                    {params.value}
                </span>  
            )
        }
    ];

    const innerComponent = (rowData) => {
        const columns = [
            {
                field: 'upc',
                headerName: 'upc',
                width: 120,
                sortable: false,
                headerClassName: "MultiUnitTableHeader",
            },
            {
                field: 'upcDesc',
                headerName: 'UPC Desc',
                width: 190,
                sortable: false,
                headerClassName: "MultiUnitTableHeader"
            },
            {
                field:'quantity',
                headerName:"Qty",
                width:150,
                headerClassName: "MultiUnitTableHeader"
            },
            {
                field: 'memoCost',
                headerName: 'Memo Cost',
                width: 70,
                sortable: false,
                headerClassName: "MultiUnitTableHeader",
            }
        ]
        

        return (
            <TableDisplayerCollapsible
                disableSelection={true}
                columns={columns}
                data={sourceData}
                classNameMemi="ssimSrcItemsCls ssmisSrcInnerTable"

                disableCollapsible={() => {return true}}

            />
        )
    }

    const innerComponent2 = (row) => {
        const columns = [
            {
                field: 'checkbox',
                colSpan:1,
                width:24
            },
            {
                field: 'upc',
                headerName: 'upc',
                sortable: false,
                headerClassName: "MultiUnitTableHeader",
                width:220
            },
            {
                field: 'upcDesc',
                headerName: 'UPC Desc',
                sortable: false,
                headerClassName: "MultiUnitTableHeader",
                width:20
            },
            {
                field:'quantity',
                headerName:"Qty",
                headerClassName: "MultiUnitTableHeader",
                width:150
            },
            {
                field: 'memoCost',
                headerName: 'Memo Cost',
                sortable: false,
                
                headerClassName: "MultiUnitTableHeader",
            }
        ]
        

        return (
            <TableDisplayerCollapsible
                disableCollapsible={() => {return true}}
                disableSelection={true}
                columns={columns}
                data={row ? row.displayItemUPC : []}
                classNameMemi="ssimSrcItemsCls ssmisSrcInnerTable"
            />
        )
    }

    const handleLoadMore = useCallback((totalDisplayed) => {

        setSelectionModel([]);
        setSelectedSsims([]);
        setSsimsData([]);
        setSourcedata([]);
        AppData.mapSelectedRowData([]);

        let currentTotalDisplayedValue;

        currentTotalDisplayedValue = totalDisplayed;

        totalDisplayed = totalDisplayed + 200;

        if (totalDisplayed >= refContainer.current.length) {
            totalDisplayed = currentTotalDisplayedValue + (refContainer.current.length - currentTotalDisplayedValue);
        }

        onLoadDeptData(totalDisplayed);

    }, [refContainer])


    const markDisplay = useCallback(() => {

        if (selectedRows.length > 0) {

            let isDisplay = false;

            isDisplay = selectedRows.every((value) => {
                return deptTableData[value].multiComponentItemInd === "Y"
            })

            if (isDisplay)
                AppData.setAlertBox(true, "Item already in display status.");
            else {
                let reqData = selectedRows.map((value, index) => {
                    return {
                        companyId: companyId, divisionId: divisionId, caseUpc: deptTableData[value].caseUpc, productSku: deptTableData[value].productSku, deptCode: memi16Data.deptCode, updatedUserID: userId
                    };
                });

                memiuServices.markDisplay(reqData).then((res) => {
                    if (res.hasOwnProperty('data')) {
                        let { data } = res;
                        onLoad();
                    }
                }).catch((error) => {
                    AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                });
            }
        } else {
            AppData.setAlertBox(true, "Select any items from ProductSKU.");
        }

    }, [selectedRows]);

    const matchToSsimsCic = useCallback(() => {

        if (selectedRows.length === 0 || ssimsData.length === 0) {
            AppData.setAlertBox(true, "Match to SSIMS not allowed. No Match from SSIMS.");
            return;
        }

        if (selectedSsimsRows.length === 0) {
            AppData.setAlertBox(true, "Please select any item details from SSIMS.");
            return;
        }

        if (selectedSsimsRows.length > 1) {
            AppData.setAlertBox(true, "More than one selection of item details from SSIMS not allowed.");
            return;
        }

        if (selectedSsimsRows.length === 1) {

            let reqData = [{
                companyId: companyId,
                divisionId: divisionId,
                productSku: deptTableData[selectedRows[0]].productSku,
                srcItemDesc: deptTableData[selectedRows[0]].itemDesc,
                caseUpc: deptTableData[selectedRows[0]].caseUpc,
                cic: selectedSsimsRows[0].cic,
                ssimsHeaderItemDesc: selectedSsimsRows[0].itemDesc,
                ssimsComponent: selectedSsimsRows[0].displayItemUPC
            }]

            memiuServices.matchToSimsCic(reqData).then((res) => {
                if (res.hasOwnProperty('data')) {
                    onLoad();

                }
            }).catch((error) => {
                AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
            });
        }

    }, [rowData, selectedRows, ssimsData, selectedSsimsRows]);

    const createNewCic = useCallback(() => {

        if (selectedRows.length === 0)
            AppData.setAlertBox(true, "No item details on source side.")
        else if (sourceData === "" || sourceData.length === 0)
            AppData.setAlertBox(true, "Component details not available.");
        else if (ssimsData.length > 0) {
            let error = "";
            ssimsData.map((value) => {
                if ((value.caseUpcMatch == 'Y' && value.qtyMatch == 'Y' && value.costMatch == 'Y') || (value.upcMatch == 'Y' && value.qtyMatch == 'Y' && value.costMatch == 'Y')) {
                    error = "Create New CIC not allowed. Already match found from SSIMS Item.";
                    return;
                }
            });

            if (error !== "") {
                AppData.setAlertBox(true, "Create New CIC not allowed. Already match found from SSIMS Item.");
                return;
            } else {

                let reqData = [{
                    companyId: companyId,
                    divisionId: divisionId,
                    caseUpc: deptTableData[selectedRows[0]].caseUpc,
                    cost: deptTableData[selectedRows[0]].cost,
                    displayFlag: deptTableData[selectedRows[0]].multiComponentItemInd,
                    pack: deptTableData[selectedRows[0]].shippingPackNumber,
                    productSku: deptTableData[selectedRows[0]].productSku,
                    srcItemDesc: deptTableData[selectedRows[0]].itemDesc,
                    updatedUserId: userId.toLowerCase(),
                    vendorConvFactor: deptTableData[selectedRows[0]].masterCasePackNumber,
                    sourceComponentUpc: sourceData
                }]

                memiuServices.createNewCic(reqData).then((res) => {
                    if (res.hasOwnProperty('data')) {
                        if (res.data) {
                            onLoad();
                        }
                    }
                }).catch((error) => {
                    AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                });
            }
        }

    }, [rowData, sourceData, ssimsData, selectedRows]);

    const onClickUnMap = useCallback(() => {

        if (selectedRows.length > 0) {

            let cicType = "C";

            if (ssimsData.length > 0) {

                ssimsData.map((value) => {

                    if ((value.cicAlreadyProcessed == 'Y') || (value.caseUpcMatch == 'Y' && value.qtyMatch == 'Y' && value.costMatch == 'Y') || (value.upcMatch == 'Y' && value.qtyMatch == 'Y' && value.costMatch == 'Y')) {
                        cicType = 'M';
                        return;
                    }
                })
            }

            let reqData = {
                companyId: companyId,
                divisionId: divisionId,
                cicType: cicType,
                updatedUserID: userId,
                productSku: deptTableData[selectedRows[0]].productSku
            }

            memiuServices.undoDisplayersCompleted(reqData).then((res) => {
                if (res.hasOwnProperty('data')) {
                    let { data } = res;

                    if (data.hasOwnProperty('Result')) {
                        let { Result } = data;

                        if (Result === " Item Already Converted By ETL") {
                            AppData.setAlertBox(true, "This item is already in completed status. Not able to unmap.");
                        }
                    }
                }
            }).catch((error) => {
                AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
            });

        }
        else
            AppData.setAlertBox(true, "Please select any item for unmap.");

    }, [rowData, ssimsData, selectedRows]);

    const onLoadDeptData = useCallback((dataLength) => {

        if (refContainer.current.length > 0) {

            setDeptTableData([]);
            let dataDeptData = [];

            refContainer.current.map((value, index) => {

                if (index < dataLength) {

                    dataDeptData.push({
                        ...value, id: index, displayCaseUpc: value.caseUpc !== null && value.caseUpc > 0 ? value.caseUpc.substring(0, 1) + "-" + value.caseUpc.substring(1, 2) + "-" + value.caseUpc.substring(2, 3) + "-" + value.caseUpc.substring(3, 8) + "-" + value.caseUpc.substring(9, 13) : "0"
                    })
                }
            });
            setDeptTableData(dataDeptData);

        } else {
            setDeptTableData([]);
        }

        setSelectionModel([]);
        setSelectedSsims([]);
        setSsimsData([]);
        setSourcedata([]);
        AppData.mapSelectedRowData([]);

    }, [deptTableData, refContainer]);

    const importComponentsDisplayer = useCallback(() => {

        AppData.setFileUploadModal(true, [".xlsx", ".xls"])

    }, [fileUpload]);

    const deptDownloadExcel = useCallback(() => {

        if (memi16Data) {

            let deptName = memi16Data.deptName.split(" ").join("");

            let data = {
                divisionId,
                companyId,
                deptCode: memi16Data.deptCode,
                deptName,
                itemType: memi16Data.itemType,
            }

            memiuServices.displayersExceptionExcelDownload(data).then((res) => {
                const url = window.URL.createObjectURL(new Blob([res.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', `DisplayExceptionItems_${AppData.memi16Data.deptName}.xlsx`);
                
                link.click();
            })
        }
    }, [memi16Data, divisionId, companyId]);

    const onLoad = useCallback(() => {

        if (memi16Data) {

            let data = {
                division: divisionId,
                company: companyId,
                deptCode: memi16Data.deptCode,
                type: memi16Data.type,
                itemType: memi16Data.itemType,
            }

            memiuServices.getMemiu16LoadDeptWiseDisplayItem(data).then((res) => {
                if (res.hasOwnProperty('data')) {
                    let { data } = res;
                    AppData.setMemi16Criteria({});
                    // onLoadDeptData(data)
                    setActualDeptData(data)
                    refContainer.current = data;
                    handleLoadMore(0);
                }
            }).catch((error) => {
                /*AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");*/
            });
        }
    }, [memi16Data, divisionId, companyId, selectedSsimsRows, sourceData, ssimsData])

    const unMarkDisplay = useCallback(() => {

        if (memi16Data && selectedRows.length > 0) {

            let isDisplay = false;

            isDisplay = selectedRows.every((value) => {
                return deptTableData[value].multiComponentItemInd === "N"
            })

            if (isDisplay)
                AppData.setAlertBox(true, "Item already in non display status.");
            else {

                let reqData = selectedRows.map((value) => {
                    return {
                        companyId: companyId,
                        divisionId: divisionId,
                        caseUpc: deptTableData[value].caseUpc,
                        productSku: deptTableData[value].productSku,
                        deptCode: memi16Data.deptCode,
                        updatedUserID: userId
                    };
                });

                memiuServices.unMarkDisplay(reqData).then((res) => {
                    if (res.hasOwnProperty('data')) {
                        let { data } = res;
                        // onLoadDeptData(data)
                        onLoad();
                    }
                }).catch((error) => {
                    AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                });

            }

        } else {
            AppData.setAlertBox(true, "Select any items from ProductSKU.");
        }

    }, [selectedRows, memi16Data, divisionId, companyId, rowData, onLoad]);

    const onClickMarkDead = useCallback(() => {

        if (memi16Data && selectedRows.length > 0) {
            AppData.setConfirmationModal(true, handleMarkDead, "textBox", "Enter the reason for marking this item as dead")
        } else {
            AppData.setAlertBox(true, "Select any items from ProductSKU.");
        }

    }, [selectedRows, memi16Data]);

    const handleMarkDead = useCallback((textboxModalSearch) => {

        if (memi16Data && selectedRows.length > 0) {

            let whiteSpace = new RegExp(/^\s+$/);

            if (!whiteSpace.test(textboxModalSearch)) {

                let reqData = selectedRows.map((value) => {
                    return {
                        companyId: companyId,
                        divisionId: divisionId,
                        productSku: deptTableData[value].productSku,
                        markAsDeadReason: textboxModalSearch.trim(),
                        updatedUserID: userId
                    }
                });

                memiuServices.markDead(reqData).then((res) => {
                    if (res.hasOwnProperty('data')) {
                        let { data } = res;
                        onLoad();
                    }
                }).catch((error) => {
                    AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                })
            }

            AppData.setConfirmationModal(false);
        }

    }, [memi16Data, selectedRows])

    const selectedDeptRow = useCallback((data) => {

        setSelectionModel(data);

        if (memi16Data && (data.length)) {
            

            let reqData = {
                companyId: companyId,
                divisionId: divisionId,
                caseUpc: Number(deptTableData[data[0]].caseUpc),
                productSku: deptTableData[data[0]].productSku,
                cost: deptTableData[data[0]].cost,
                productSourceCode: deptTableData[data[0]].productSourceCode
            }

            memiuServices.loadSourceSimsItems(reqData).then((res) => {
                if (res.hasOwnProperty('data')) {

                    let { data } = res;

                    let displaySimsLikeItemsProccessed = [];

                    if (data.displaySimsLikeItems) {

                        let displaySimsLikeItemsData = data.displaySimsLikeItems.map((value, index) => {
                            return {
                                ...value, id: index, displayCaseUpc: value.caseUpc !== null ? value.caseUpc : "0"
                            };
                        });

                        if (memi16Data.type == 'C') {
                            for (var i = 0; i < displaySimsLikeItemsData.length; i++) {
                               
                                if (displaySimsLikeItemsData[i].cicAlreadyProcessed == 'Y') {
                                    displaySimsLikeItemsProccessed.push(displaySimsLikeItemsData[i])
                                    break
                                }
                            }

                            setSsimsData(displaySimsLikeItemsProccessed);
                        }
                        else {
                            setSsimsData(displaySimsLikeItemsData);
                        }
                    }
                    if (data.displayItemSourceUPC) {

                        let displayItemSourceUPCData = data.displayItemSourceUPC.map((value, index) => {
                            return {
                                ...value, id: index
                            };
                        });

                        setSourcedata(displayItemSourceUPCData)
                    }

                }
            }).catch((error) => {
                /*AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");*/
            });
        } else {
            setSelectionModel([]);
            setSelectedSsims([]);
            setSsimsData([]);
            setSourcedata([]);
            AppData.mapSelectedRowData([]);
        }

    }, [memi16Data, divisionId, companyId, deptTableData, ssimsData, sourceData]);

    useEffect(() => {

        if (memi16Data) {
            onLoad();
        }

    }, [memi16Data]);

    useEffect(() => {

        if (memi16Data) {
            onLoadFunc.current = onLoad;
            setSelectionModel([])
        }

    }, [memi16Data]);

    useEffect(() => {

        if (memi16Data && memi16Criteria && Object.keys(memi16Criteria).length > 0) {

            let reqData = {
                divisionId: divisionId,
                companyId: companyId,
                deptCode: memi16Data.deptCode,
                itemType: memi16Data.itemType,
                [Object.keys(memi16Criteria)[0]]: Object.values(memi16Criteria)[0]
            }

            if (memi16Data && memi16Data.type === "N") {

                if (Object.keys(memi16Criteria)[0] === "itemDesc") {
                    memiuServices.displayersSearchOnItemDesc([reqData]).then((res) => {
                        if (res.hasOwnProperty('data')) {
                            let { data } = res;
                            setActualDeptData(data);
                            refContainer.current = data;
                            handleLoadMore(0);
                        }
                    }).catch((error) => {
                        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                    });
                } else if (Object.keys(memi16Criteria)[0] === "productSku") {
                    memiuServices.displayersSearchOnProductSku([reqData]).then((res) => {
                        if (res.hasOwnProperty('data')) {
                            let { data } = res;
                            setActualDeptData(data);
                            refContainer.current = data;
                            handleLoadMore(0);
                        }
                    }).catch((error) => {
                        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                    });

                } else if (Object.keys(memi16Criteria)[0] === "oneTimeBuyFlag") {
                    memiuServices.displayersSearchOnOneTimeBuyFlag([reqData]).then((res) => {
                        if (res.hasOwnProperty('data')) {
                            let { data } = res;
                            setActualDeptData(data);
                            refContainer.current = data;
                            handleLoadMore(0);
                        }
                    }).catch((error) => {
                        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                    });

                }
            } else if (memi16Data && memi16Data.type === "C") {

                if (Object.keys(memi16Criteria)[0] === "itemDesc") {

                    memiuServices.displayersSearchOnReviewedItemDesc([reqData]).then((res) => {
                        if (res.hasOwnProperty('data')) {
                            let { data } = res;
                            setActualDeptData(data);
                            refContainer.current = data;
                            handleLoadMore(0);
                        }
                    }).catch((error) => {
                        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                    });
                } else if (Object.keys(memi16Criteria)[0] === "productSku") {
                    memiuServices.displayersSearchOnReviewedProductSku([reqData]).then((res) => {
                        if (res.hasOwnProperty('data')) {
                            let { data } = res;
                            setActualDeptData(data);
                            refContainer.current = data;
                            handleLoadMore(0);
                        }
                    }).catch((error) => {
                        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                    });

                } else if (Object.keys(memi16Criteria)[0] === "oneTimeBuyFlag") {
                    memiuServices.displayersSearchOnReviewedOneTimeBuyFlag([reqData]).then((res) => {
                        if (res.hasOwnProperty('data')) {
                            let { data } = res;
                            setActualDeptData(data);
                            refContainer.current = data;
                            handleLoadMore(0);
                        }
                    }).catch((error) => {
                        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                    });

                }

            }
        }

    }, [memi16Data, divisionId, companyId, memi16Criteria]);

    useEffect(() => {


        if (fileUploadData && Object.keys('fileUploadData').length > 0 && memi16Data) {
            let formData = new FormData();
            formData.append("file", fileUploadData)
            formData.append("companyId", companyId)
            formData.append("divisionId", divisionId)
            formData.append("deptCode", memi16Data.deptCode)
            formData.append("displayType", "D")
            formData.append("userId", userId)

            memiuServices.uploadExceptionFile(formData)
                .then((res) => {
                    if (res.hasOwnProperty('data')) {

                        let { data } = res;
                        if (data.hasOwnProperty('status')) {
                            let { status } = data;

                            if (status === 'SUCCESS')
                                AppData.setFileUploadModal(true, [".xlsx", ".xls"], "The file is being processed. You will be notified through an email when processing is complete.", "#05ab21");
                            if (status === 'STR_CHANGE')
                                AppData.setFileUploadModal(true, [".xlsx", ".xls"], "File structure has been changed. Use the default structure of the Excel.", "#ca6b09");
                            if (status === 'NOT_EXCEL')
                                AppData.setFileUploadModal(true, [".xlsx", ".xls"], "Unsupported file format. Use the default template for uploading process.", "#ca6b09");
                            if (status === 'FAILURE')
                                AppData.setFileUploadModal(true, [".xlsx", ".xls"], "File upload failed.", "#ca6b09");
                            if (status === 'ERROR')
                                AppData.setFileUploadModal(true, [".xlsx", ".xls"], "Issues in uploading the file.", "#ca6b09");
                        }
                    }
                }).catch((error) => {
                    AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
                })
        }
    }, [fileUploadData]);

    const customNoRowsOverlay = (
        <div className="containerNoData">
            No Products to display
        </div>
    )


    return (
        <>
            <Grid item xs={12} className="displayerSource" >
                Department: {memi16Data && memi16Data.deptName}
            </Grid >

            {/* <SourceItems MappingStatus={props.MappingStatus} /> */}
            <Grid item xs={12} style={{ height: "15rem" }}>
                <TableMemi
                    classnameMemi="displayerItemsTableCls"
                    data={deptTableData}
                    columns={deptColumns}
                    selectionType="checkbox"
                    rowheight={22}
                    hideFooter
                    selectedRows={selectedRows}
                    setSelectionModel={(selectedRows) => selectedDeptRow(selectedRows)}
                />
            </Grid>

            <Grid item xs={12} className="displayerSourceResult" >
                Showing {deptTableData.length} out of {actualDeptData.length} items.
            </Grid >

            <Grid className="displayerTopButtons" >
                <div className="displayerBtnAlign">
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton displayerBtnWidth"
                        btnval="Mark Display"
                        onClick={markDisplay}
                    />
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                        btnval="Un Mark Display"
                        onClick={unMarkDisplay}
                    />
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                        btnval="Mark As Dead"
                        onClick={onClickMarkDead}
                    />
                    {memi16Data && memi16Data.type === "N" && <>
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                            onClick={deptDownloadExcel}
                            btnval={<>Export Exceptions <GetApp className="exportExceptionMultiunit" /></>}
                        />
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                            btnval="Import Components"
                            onClick={importComponentsDisplayer}
                            btnval={<>Import Components <Publish className="exportExceptionMultiunit" /></>}
                        />
                    </>}
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth displayerLoadMoreBtn"
                        btnval="Load More..."
                        onClick={() => handleLoadMore(deptTableData.length)}
                    />
                </div>
            </Grid >

            <div className="displayerSrcTable">
                <div style={{ width: "42%" }} className={"displayerOutline"}>
                    <Grid item xs={12} className="displayerSource" >
                        Source
                    </Grid >

                    <Grid item xs={12} style={{ height: "15rem", width: "99%", paddingLeft: "0.3rem" }}>

                        <TableDisplayerCollapsible
                            classNameMemi={"ssimSrcItemsCls  ssimSrcItemsRow"}
                            data={selectedRows.length > 0 ? [deptTableData[selectedRows[0]]] : []}
                            columns={srcColumns}
                            rowheight={22}
                            hideFooter
                            disableSelection={true}
                            NoRowsOverlay={customNoRowsOverlay}
                            disableCollapsible={(row) => {return sourceData.length === 0}}
                            collapsibleTabelContent={innerComponent}
                        // hideFooterPagination
                        // disableColumnMenu
                        // disableColumnFilter
                        // rowCount={AppData.memi21_sourceItems.length < 400 ? AppData.memi21_sourceItems : 400}
                        />
                    </Grid>
                </div>
                <div className={"displayerOutline"} style={{ width: "60%" }}>
                    <Grid item xs={12} className="displayerSource" >
                        SSIMS Item
                    </Grid >

                    <Grid item xs={12} style={{ height: "15rem", width: "100%", paddingLeft: "0.3rem",paddingRight:"0.3rem" }}>
                        <TableDisplayerCollapsible
                            classNameMemi={"ssimSrcItemsCls  ssimSrcItemsRow"}
                            data={ssimsData}
                            columns={ssimsColumns}
                            rowheight={22}
                            selectionType="checkbox"
                            hideFooter
                            NoRowsOverlay={customNoRowsOverlay}
                            selectedRows={selectedSsimsRows}
                            setSelectedRows={(selectedRows) => setSelectedSsims(selectedRows)}
                            collapsibleTabelContent={innerComponent2}
                            disableCollapsible={(row) => {return row.displayCaseUpc.length === 0 }}
                        // rowCount={AppData.memi21_sourceItems.length < 400 ? AppData.memi21_sourceItems : 400}
                        />
                    </Grid>
                </div>
            </div>

            <Grid className="displayerTopButtons" >
                <div className="displayerBottomBtnAlign">
                    {memi16Data && memi16Data.type === "N" && <>
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenSearchButton displayerMatchSSIMSBtnWidth"
                            btnval="Match to SSIMS CIC"
                            onClick={matchToSsimsCic}
                        />
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                            btnval="Create New CIC"
                            onClick={createNewCic}
                        />
                    </>}

                    <div className={`${memi16Data && memi16Data.type === "C" ? "displayerReviewdWidthCls" : ""}`}>
                        <ButtonMemi
                            classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                            btnval="Home"
                            onClick={() => history.push('/displayer')}
                        />


                        {memi16Data && memi16Data.type === "C" && <>
                            <ButtonMemi
                                classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft displayerBtnWidth"
                                btnval="Un Map"
                                onClick={onClickUnMap}
                            />
                        </>}
                    </div>
                </div>
            </Grid >
        </>



    )
}

export default DisplayerItems;