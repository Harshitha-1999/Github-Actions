import { ArrowDropDown, KeyboardArrowRightSharp, KeyboardArrowRightTwoTone } from '@material-ui/icons';
import { Button, Menu, MenuItem, Popper, Box, ClickAwayListener } from '@material-ui/core'
import React, { memo } from 'react'

function SelectMenuMemi(props) {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    const onSelectClose = () => {
        if (props.onSelectClose) {
            props.onSelectClose();
        } else {
            handleClose();
        }
    }
    const handleItemClick = (list) => {
        if (props.onSelect && typeof (props.onSelect) == "function") {
            props.onSelect({ ...list, value: list.value, child: props.child });
        }
        handleClose()
        onSelectClose();

    }
    return (
        <ClickAwayListener onClickAway={handleClose}>
            <div>
                {
                    props.child ?
                        <MenuItem onClick={handleClick} style={{ fontSize: "14px"}} className={props.menuClass} >
                            {props.label} <KeyboardArrowRightSharp style={{marginLeft:"-0.3rem"}} />
                        </MenuItem>
                        :
                        <Button
                            id="demo-customized-button"
                            aria-controls={open ? 'demo-customized-menu' : undefined}
                            aria-haspopup="true"
                            aria-expanded={open ? 'true' : undefined}
                            variant="contained"
                            className={`${props.classNameMemi}`}
                            onClick={handleClick}
                            disableElevation
                            size={props.btnsize}
                        >
                            {props.label} <ArrowDropDown style={{transform:"scale(0.9)"}}/>
                        </Button>

                }
                <Popper

                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleClose}
                    placement={
                        props.child ? "right-start" : "bottom-start"

                    }
                    className="filterByStatusBox"
                >
                    <Box style={{paddingTop:"6px", paddingLeft:"5px",paddingBottom:"6px",display:props.options.length > 0 ? "block" : "none", border:"1px solid #00000026"}} >
                        {
                            props.options.map((list, index) => (
                                list.children ?
                                    <SelectMenuMemi options={list.children} label={list.label} child={true} parentLabel={props.label} onSelect={props.onSelect} onSelectClose={onSelectClose} menuClass={props.menuClass} subMenuClass={props.subMenuClass} />
                                    :
                                    <MenuItem key={index} onClick={() => handleItemClick(list)} style={{ fontSize: "14px"}} className={props.child ? props.subMenuClass : props.menuClass}>
                                        {list.label}
                                    </MenuItem>
                            ))
                        }
                    </Box>

                </Popper>
            </div>
        </ClickAwayListener>
    )
}

export default memo(SelectMenuMemi)
