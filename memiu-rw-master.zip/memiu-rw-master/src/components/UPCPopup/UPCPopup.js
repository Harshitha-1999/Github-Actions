import React, { useState, useEffect, memo } from 'react'
import { Popper, Box } from '@material-ui/core';
import { CloseTwoTone } from '@material-ui/icons';
function UPCPopup(props) {
    const { data } = props
    const [anchorEl, setAnchorEl] = useState(null);
    const [rowData, setRowData] = useState([]);
    const open = Boolean(anchorEl);
    useEffect(() => {
        if (open) {
            if (data) {
                setRowData(data)
            } else {
                props.onLoad().then((res) => {
                    setRowData(res.data)
                })
                    .catch((error) => {
                        setRowData([])
                    })

            }
        }
    }, [open, data])
    return (
        <>
            <span className="MappingIconCircle" style={{ backgroundColor: props.color }} onClick={(e) => setAnchorEl(e.currentTarget)} >
                {props.number}
            </span>
            <Popper
                open={open}
                anchorEl={anchorEl}
                placement="bottom-end"
                className={`filterByStatusBox ${props.classNameMemi}`}
                style={{ padding: "5px"}}
            >
                <Box>
                    <div style={{ display: "flex" }}>
                        <table style={{ width: "100%" }}>
                            <thead>
                                <tr>
                                    <th> </th>
                                    {props.columns.map((data, index) => (
                                        <th
                                            className="tableModalTableHeading"
                                            style={{ textAlign: "left" }}
                                            key={index}>
                                            {data.headerName}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    rowData.map((row, index) => (
                                        <tr key={index}>
                                            {
                                                props.enableCheckbox ?
                                                    <th>
                                                        <input type="checkbox" disabled={rowData.length <= 1} checked={row.checkedUPc} onClick={props.onClickCheckbox ? props.onClickCheckbox : () => console.log("clicked")} />
                                                    </th>
                                                    :
                                                    <th>
                                                    </th>
                                            }
                                            {props.columns.map((column, index) => {
                                                return <th key={index} style={{ textAlign: "left" }}> {row[column.field]} </th>
                                            })}
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                        <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={() => setAnchorEl(null)} />
                    </div>
                </Box>
            </Popper>
        </>

    )

}

export default memo(UPCPopup)
