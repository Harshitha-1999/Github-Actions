import React, {
  useEffect,
  useContext,
  useState,
  useCallback,
} from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import { Add, CheckBox, LocalOffer, NotInterested, EditLocation, Search, Visibility } from '@material-ui/icons';
import ApplicationContext from "../../context/ApplicationContext";
import { memiuServices } from "api/memiu/memiuService";
import ButtonMemi from "../../components/ButtonMemi/ButtonMemi";
import LoadSkuAndCIC from './LoadSKUAndCIC';
import UPCPopup from 'components/UPCPopup/UPCPopup';
import { authTokenCookie } from 'utils';
import { RouteBase } from 'routes/constants';
import { useHistory } from 'react-router-dom';


const useStyles = makeStyles((theme) => ({
  root: {
    "& .super-app.positive": {
      color: "#50C878",
      fontWeight: "600",
    },
  },
  root1: {
    "& > *": {
      margin: theme.spacing(3),

      width: "40ch",
    },
  },
}));

export const BakeryMapping = (props) => {
  const history = useHistory();
  const AppData = useContext(ApplicationContext);
  const { companyId, divisionId } = AppData;
  const { userId } = authTokenCookie();

  const [searchValue, setSearchValue] = useState("");
  const [itemType, setItemType] = useState({ all: false, system2: false, system4: false, plu: false });
  const [bakerySkuSearchRes, setBakerySkuSearchRes] = useState({ bakerySkuSearch: null, sourceCount: 0 });
  const [filterByStatus, setFilterByStatus] = useState("TO_BE_MAPPED");
  const [searchSKUCriteria, setSearchSKUCriteria] = useState({ searchCriteria: null, searchCriteriaValue:"" });
  const [searchCriteria, setSearchCriteria] = useState(null);
  const [filterCriteria, setFilterCriteria] = useState(null);
  const [filterAvail, setFilterAvail] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [isReserved, setIsReserved] = useState(false);

  const [searchCicValue, setSearchCicValue] = useState("")
  const [buyingCicItemType, setBuyingCicItemType] = useState({ all: false, system2: false, system4: false, plu: false });
  const [bakeryCicSearchRes, setBakeryCicSearchRes] = useState({ bakeryCicSearch: null, targetCount: 0 });
  const [filterByCicStatus, setFilterByCicStatus] = useState("SHOW_ALL");
  const [searchCicCriteria, setSearchCicCriteria] = useState({ searchCriteria: null, searchCriteriaValue: "" });
  const [buyingCicFilterCriteria, setBuyingCicFilterCriteria] = useState(null);
  const [buyingCicFilterAvail, setBuyingCicFilterAvail] = useState(false);
  const [selectedCicBuyingRows, setSelectedCicBuyingRows] = useState([]);
  const [searchBuyCriteria, setSearchBuyCriteria] = useState(null);

  const [searchCicSellingValue, setSearchCicSellingValue] = useState("")
  const [buyingCicSellingItemType, setBuyingCicSellingItemType] = useState({ all: false, system2: false, system4: false, plu: false });
  const [bakeryCicSellingSearchRes, setBakeryCicSellingSearchRes] = useState({ bakeryCicSearch: null, targetCount: 0 });
  const [filterByCicSellingStatus, setFilterByCicSellingStatus] = useState("SHOW_ALL");
  const [searchCicSellingCriteria, setSearchCicSellingCriteria] = useState({ searchCriteria: null, searchCriteriaValue: null });
  const [buyingCicSellingFilterCriteria, setBuyingCicSellingFilterCriteria] = useState(null);
  const [buyingCicSellingFilterAvail, setBuyingCicSellingFilterAvail] = useState(false);
  const [selectedCicSellingRows, setSelectedCicSellingRows] = useState([]);
  const [searchSellCriteria, setSearchSellCriteria] = useState(null);


  const [sortableList, setSortableList] = useState([
    { label: "Department", value: "LKPCONGP", selected: true, id: 0 },
    { label: "Hierarchy 1", value: "LKPHIER1", selected: false, id: 1 },
    { label: "Hierarchy 2", value: "LKPHIER2", selected: false, id: 2 },
    { label: "Hierarchy 3", value: "LKPHIER3", selected: false, id: 3 },
    { label: "Supplier", value: "LKPSUPNO", selected: false, id: 4 },
    { label: "Product SKU", value: "LKPSUPNM", selected: false, id: 5 },
    { label: "Item Description", value: "LKPITMDS", selected: false, id: 6 }
  ]);

  const buyingCicColumns = [
    {

      field: 'status',
      headerName: 'Status',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      colSpan: 2
    },
    {
      field: 'cic',
      headerName: 'CIC',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      renderCell: (params) => (
        <div className={`fontColor_${params.row.whseDsd}`}>
          {params.value}
        </div>
      ),
      sortable:true,
      numeric:true
    },
    {
      field: 'itemDesc',
      headerName: 'Item Desc',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      sortable:true
    },

    {
      field: 'pack',
      headerName: 'Pack',
      headerCss: "mappingTableHeader",
      textAlign:"center"
    },
    {
      field: 'vcf',
      headerName: 'Vcf',
      headerCss: "mappingTableHeader",
      sortable:true,
      textAlign:"center",
      numeric:true
    },
    {
      field: 'size',
      headerName: 'Size',
      headerCss: "mappingTableHeader"
    },
    {
      field: 'upc',
      headerName: 'UPC',
      headerCss: "mappingTableHeader",
      renderCell: (params) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <span style={{ paddingRight: "5px" }}> {params.row.displayUpc} </span> {
            params.value.length > 1 ? <UPCPopup
              columns={[{ headerName: "UPC List", field: "upc" }]}
              data={params.row.upc ? params.value.map((upc) => { return { 'upc': upc } }) : []}
              number={params.value.length}
              color={filterByCicStatus === "TO_BE_MAPPED" ? "#00adef" : (filterByCicStatus === "RESERVED" || filterByCicStatus === "SHOW_ALL") ? "#4bd4e2" : "#74a1a9"}
            /> : ''
          }


        </div>
      ),
      sortable:true
    }
  ];

  const buyingCicSellingColumns = [
    {

      field: 'status',
      headerName: 'Status',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      colSpan: 2
    },
    {
      field: 'cic',
      headerName: 'CIC',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      renderCell: (params) => (
        <div className={`fontColor_${params.row.whseDsd}`}>
          {params.value}
        </div>
      ),
      sortable:true,
      numeric:true
    },
    {
      field: 'itemDesc',
      headerName: 'Item Desc',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      sortable:true
    },

    {
      field: 'pack',
      headerName: 'Pack',
      headerCss: "mappingTableHeader",
      textAlign:"center"
    },
    {
      field: 'vcf',
      headerName: 'Vcf',
      headerCss: "mappingTableHeader",
      sortable:true,
      textAlign:"center",
      numeric:true
    },
    {
      field: 'size',
      headerName: 'Size',
      headerCss: "mappingTableHeader"
    },
    {
      field: 'upc',
      headerName: 'UPC',
      headerCss: "mappingTableHeader",
      renderCell: (params) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <span style={{ paddingRight: "5px" }}> {params.row.displayUpc} </span> {
            params.value.length > 1 ? < UPCPopup
              columns={[{ headerName: "UPC List", field: "upc" }]}
              data={params.row.upc ? params.value.map((upc) => { return { 'upc': upc } }) : []}
              number={params.value.length}
              color={filterByCicSellingStatus === "TO_BE_MAPPED" ? "#00adef" : (filterByCicSellingStatus === "RESERVED" || filterByCicSellingStatus === "SHOW_ALL") ? "#4bd4e2" : "#74a1a9"}
            /> : ''
          }
        </div>
      ),
      sortable:true

    }
  ];

  const columns = [
    {

      field: 'status',
      headerName: 'Status',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      colSpan: 2
    },
    {
      field: 'sku',
      headerName: 'SKU',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      renderCell: (params) => (
        <div className={`fontColor_${params.row.absDSDWhse}`}>
          {params.value}
        </div>
      ),
      numeric: true,
      sortable:true
    },
    {
      field: 'itemDesc',
      headerName: 'Item Desc',
      headerAlign: "left",
      headerCss: "mappingTableHeader",
      sortable:true
    },

    {
      field: 'packNum',
      headerName: 'Pack',
      headerCss: "mappingTableHeader",
      textAlign:"center"
    },
    {
      field: 'vcf',
      headerName: 'Vcf',
      headerCss: "mappingTableHeader",
      sortable:true,
      numeric: true,
      textAlign:"center"
    },
    {
      field: 'size',
      headerName: 'Size',
      headerCss: "mappingTableHeader"
    },
    {
      field: 'upc',
      headerName: 'UPC',
      headerCss: "mappingTableHeader",
      renderCell: (params) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <span style={{ paddingRight: "5px" }}> {params.row.displayUpc} </span> {
            params.value.length > 1 ? < UPCPopup
              columns={[{ headerName: "UPC List", field: "upc" }]}
              data={params.row.upc ? params.value.map((upc) => { return { 'upc': upc } }) : []}
              number={params.value.length}
              color={filterByStatus === "TO_BE_MAPPED" ? "#00adef" : (filterByStatus === "RESERVED" || filterByStatus === "SHOW_ALL") ? "#4bd4e2" : "#74a1a9"}
            /> : ''
          }

        </div>
      ),
      sortable:true
    },
  ];

  let filterByOption = [
    { label: "To be Mapped", color: "#00adef", value: "TO_BE_MAPPED" },
    { label: "Mapped", color: "#56912b", value: "MAPPED" },
    { label: "Mark As Dead", color: "#808080", value: "MARK_AS_DEAD" },
    { label: "Force New", color: "#e24f4b", value: "FORCE_NEW" },
    { label: "Let Auto Match", color: "#694be2", value: "LET_AUTO_MATCH" },
    { label: "Reserved", color: "#4be2bf", value: "RESERVED" },
    { label: "Show All", color: "#f0ad4e", value: "SHOW_ALL" }
  ];

  let selectByOption = [
    { label: "Select", searchCriteria: null,searchValue:"",disabledInput:true },
    { label: "SKU", searchCriteria: "SKU_VAL", },
    { label: "Item Description", searchCriteria: "ITEM_DESC" },
    { label: "UPC", searchCriteria: "UPC_VAL" },
    { label: "PLU", searchCriteria: "PLU_VAL" },
    { label: "Total Sales", children: [{ label: "> Greater than", searchCriteria: "GREATER_THAN", value: "",searchLabel:"Total Salse >" }, { label: "< Less than", searchCriteria: "LESS_THAN", value: "",searchLabel:"Total Salse <"  }, { label: "= Equal to", searchCriteria: "EQUAL_TO", value: "",searchLabel:"Total Salse ="  }] },
    { label: "Usage Ind", children: [{ label: "R (Resale)", value: "R", searchCriteria: "USAGE_TYPE",searchLabel:"Usage Ind",disabledInput:true }, { label: "M (Material)", value: "M", searchCriteria: "USAGE_TYPE",searchLabel:"Usage Ind",disabledInput:true  }, { label: "E (Expense)", value: "E", searchCriteria: "USAGE_TYPE",searchLabel:"Usage Ind",disabledInput:true }] },
    { label: "WHSE vs DSD", children: [{ label: "WHSE", value: "WHSE", searchCriteria: "WHSE_DSD",searchLabel:"WHSE vs DSD",disabledInput:true  }, { label: "DSD", value: "DSD", searchCriteria: "WHSE_DSD",searchLabel:"WHSE vs DSD",disabledInput:true }] },
    { label: "Display", children: [{ label: "Y", value: "Y", searchCriteria: "DISP",searchLabel:"Display",disabledInput:true }, { label: "N", value: "N", searchCriteria: "DISP",searchLabel:"Display",disabledInput:true }] }
  ]

  let filterCicByOption = [
    { label: "To be Mapped", color: "#00adef", value: "TO_BE_MAPPED" },
    { label: "Mapped", color: "#56912b", value: "MAPPED" },
    { label: "Show All", color: "#f0ad4e", value: "SHOW_ALL" }
  ]

  let selectCicByOption = [
    { label: "Select", searchCriteria: null,searchValue:"",disabledInput:true },
    { label: "CIC", searchCriteria: "CIC_VAL"},
    { label: "Item Description", searchCriteria: "ITEM_DESC" },
    { label: "UPC", searchCriteria: "UPC_VAL" },
    { label: "PLU", searchCriteria: "PLU_VAL" },
    { label: "Usage Ind", children: [{ label: "R (Resale)", value: "R", searchCriteria: "USAGE_TYPE",disabledInput:true }, { label: "M (Material)", value: "M", searchCriteria: "USAGE_TYPE",disabledInput:true }, { label: "E (Expense)", value: "E", searchCriteria: "USAGE_TYPE",disabledInput:true }] },
    { label: "WHSE vs DSD", children: [{ label: "WHSE", value: "WHSE", searchCriteria: "WHSE_DSD",disabledInput:true }, { label: "DSD", value: "DSD", searchCriteria: "WHSE_DSD",disabledInput:true }] },
    { label: "Display", children: [{ label: "Y", value: "Y", searchCriteria: "DISP",disabledInput:true,searchLabel:"Display" }, { label: "N", value: "N", searchCriteria: "DISP",disabledInput:true,searchLabel:"Display"}] }
  ];

  let contextCicOptions = [
    { label: "Inherit" },
    { label: "Add Map" }
  ];

  const handleSelectedRows = useCallback((rows) => {

    setSelectedRows(rows);
    let isReservedCheck = rows.some((value) => { return value.mappingStatus === "AWAITING_NEW_CIC" })
    setIsReserved(isReservedCheck)

  }, [selectedRows, isReserved]);

  const handleSelectedCicBuyingRows = useCallback((rows) => {

    setSelectedCicBuyingRows(rows);

  }, [selectedCicBuyingRows]);

  const handleSelectedCicSellingRows = useCallback((rows) => {

    setSelectedCicSellingRows(rows);

  }, [selectedCicSellingRows]);

  const onClickForceNew = useCallback(() => {

    if (selectedRows && selectedRows.length > 0 && selectedCicBuyingRows && selectedCicBuyingRows.length < 1 && selectedCicSellingRows && selectedCicSellingRows.length < 1) {

      if (selectedRows.length > 1) {
        AppData.setAlertBox(true, "Select single SKU to proceed.");
        return;
        // } else if ($scope.unselectedMapRequests && $scope.unselectedMapRequests.length > 0) {
        //   alertify.alert("UPCs cannot be unselected for this action.");
      } else {

        let saveRequests = [];
        let skuSelected;
        let usageType = ""
        selectedRows.forEach((sku) => {
          let saveRequest = {};
          saveRequest.sourceComponentUpc = [];
          saveRequest.companyId = companyId;
          saveRequest.divisionId = divisionId;
          saveRequest.productSku = sku.sku;
          saveRequest.cost = 0;
          saveRequest.displayFlag = sku.display;
          saveRequest.pack = sku.packNum;
          saveRequest.vendorConvFactor = sku.vcf;
          saveRequest.updatedUserId = userId;
          skuSelected = saveRequest.productSku;

          usageType = sku.usage;

          sku.upc.forEach((upc) => {
            let src = {};
            src.upc = {};
            src.upc = upc;
            saveRequest.sourceComponentUpc.push(src);
          });
          saveRequests.push(saveRequest);

        });

        memiuServices.ForceNewCategory(saveRequests[0]).then((response) => {
          if (response.data.ForceNewCategory === "A") {
            AppData.setAugmentationServiceKey("Bakery")
            AppData.setAugmentationServiceDepartment(selectedRows[0].deptName)
            AppData.setAugmentationServiceUsageType(usageType)
            AppData.setMemi18({ updateaugmentationsku: [skuSelected], UpdateAugmentationManualSearch:{} })
            history.push(RouteBase.MEMI18)
          } else if (response.data.ForceNewCategory === "O") {
            AppData.setOverideServiceKey("Bakery")
            AppData.setOverideServiceUsageType(usageType);
            AppData.setMemi14({ updateoverridesku: [skuSelected],  UpdateOverrideManualSearch:{}})
            history.push(RouteBase.MEMI14)
          }
        })
          .catch((error) => {
            console.log("error")
          })
      }
    } else {
      AppData.setAlertBox(true, "Select only SKU to proceed.");
      return;
    }

  }, [selectedRows]);

  const onClickMarkDead = useCallback(() => {
    if (selectedRows.length > 0) {
      AppData.setConfirmationModal(true, onHandleMarkAsDead, "textBox", "The selected SKU's will be marked as dead. Enter the reason for marking as dead.")
    } else {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
    }
  }, [selectedRows]);

  const handleSelectItemType = useCallback((e, type) => {
    setItemType({ all: e.target.value === "all" ? e.target.checked : false, system2: e.target.value === "system2" ? e.target.checked : false, system4: e.target.value === "system4" ? e.target.checked : false, plu: e.target.value === "plu" ? e.target.checked : false });
  }, [itemType]);

  const handleSelectBuyCICItemType = useCallback((e, type) => {
    setBuyingCicItemType({ all: e.target.value === "all" ? e.target.checked : false, system2: e.target.value === "system2" ? e.target.checked : false, system4: e.target.value === "system4" ? e.target.checked : false, plu: e.target.value === "plu" ? e.target.checked : false });
  }, [buyingCicItemType]);

  const handleSelectBuyCICSellingItemType = useCallback((e, type) => {
    setBuyingCicSellingItemType({ all: e.target.value === "all" ? e.target.checked : false, system2: e.target.value === "system2" ? e.target.checked : false, system4: e.target.value === "system4" ? e.target.checked : false, plu: e.target.value === "plu" ? e.target.checked : false });
  }, [buyingCicSellingItemType]);

  const onHandleFilterByStatus = useCallback((value) => {
    setFilterByStatus(value);
    let isItemTypeTrue = Object.values(itemType).every((value) => { return !value });
    if (isItemTypeTrue) {
      setItemType({ all: true, system2: false, system4: false, plu: false });
    }
  }, [filterByStatus, itemType]);

  const onHandleCicFilterByStatus = useCallback((value) => {
    setFilterByCicStatus(value);
    let isCicItemTypeTrue = Object.values(buyingCicItemType).every((value) => { return !value });
    if (isCicItemTypeTrue) {
      setBuyingCicItemType({ all: true, system2: false, system4: false, plu: false });
    }
  }, [filterByCicStatus, buyingCicItemType]);

  const onHandleCicSellingFilterByStatus = useCallback((value) => {
    setFilterByCicSellingStatus(value);
    let isCicSellingItemTypeTrue = Object.values(buyingCicSellingItemType).every((value) => { return !value });
    if (isCicSellingItemTypeTrue) {
      setBuyingCicSellingItemType({ all: true, system2: false, system4: false, plu: false });
    }
  }, [filterByCicSellingStatus, buyingCicSellingItemType])

  const onHandleFilterByMapping = useCallback((data) => {
    let isItemTypeTrue = Object.values(itemType).every((value) => { return !value });
    if (isItemTypeTrue) {
      setItemType({ all: true, system2: false, system4: false, plu: false });
    }
    setFilterCriteria(data);
    if (data) {
      setFilterAvail(true);
    } else {
      setFilterAvail(false);
      setFilterCriteria(null);
    }
  }, [itemType, filterCriteria, filterAvail]);

  const onHandleCicFilterByMapping = useCallback((data) => {
    let isItemTypeTrue = Object.values(buyingCicItemType).every((value) => { return !value });
    if (isItemTypeTrue) {
      setBuyingCicItemType({ all: true, system2: false, system4: false, plu: false });
    }
    setBuyingCicFilterCriteria(data);
    if (data) {
      setBuyingCicFilterAvail(true);
    } else {
      setBuyingCicFilterAvail(false);
      setBuyingCicFilterCriteria(null);
    }

  }, [buyingCicFilterAvail, buyingCicItemType, buyingCicFilterCriteria]);

  const onHandleCicSellingFilterByMapping = useCallback((data) => {

    let isItemSellingTypeTrue = Object.values(buyingCicSellingItemType).every((value) => { return !value });

    if (isItemSellingTypeTrue) {
      setBuyingCicSellingItemType({ all: true, system2: false, system4: false, plu: false });
    }

    setBuyingCicSellingFilterCriteria(data);

    if (data) {
      setBuyingCicSellingFilterAvail(true);
    } else {
      setBuyingCicSellingFilterAvail(false);
      setBuyingCicSellingFilterCriteria(null);
    }

  }, [buyingCicSellingFilterAvail, buyingCicSellingItemType, buyingCicSellingFilterCriteria])

  const onHandleSelectStatus = useCallback(() => {

    setSearchSKUCriteria({ searchCriteria: searchCriteria, searchCriteriaValue: searchValue === "" ? null : searchValue });

    let isItemTypeTrue = Object.values(itemType).every((value) => { return !value });

    if (isItemTypeTrue) {
      setItemType({ all: true, system2: false, system4: false, plu: false });
    }

  }, [searchSKUCriteria, itemType, searchCriteria, searchValue]);

  const onHandleCicSelectStatus = useCallback(() => {

    setSearchCicCriteria({ searchCriteria: searchBuyCriteria, searchCriteriaValue: searchCicValue === "" ? null : searchCicValue });

    let isCicItemTypeTrue = Object.values(buyingCicItemType).every((value) => { return !value });

    if (isCicItemTypeTrue) {
      setBuyingCicItemType({ all: true, system2: false, system4: false, plu: false });
    }

  }, [searchCicCriteria, buyingCicItemType, searchBuyCriteria, searchCicValue]);

  const onHandleCicSellingSelectStatus = useCallback(() => {


    setSearchCicSellingCriteria({ searchCriteria: searchSellCriteria, searchCriteriaValue: searchCicSellingValue === "" ? null : searchCicSellingValue });

    let isCicSellingItemTypeTrue = Object.values(buyingCicSellingItemType).every((value) => { return !value });

    if (isCicSellingItemTypeTrue) {
      setBuyingCicSellingItemType({ all: true, system2: false, system4: false, plu: false });
    }

  }, [searchCicSellingCriteria, buyingCicSellingItemType, searchCicSellingValue, searchSellCriteria]);

  const onClickIsReserved = useCallback(() => {
    //console.log("selectedRows:"+selectedRows.length+"selectedCicBuyingRows,"+selectedCicBuyingRows.length+"selectedCicSellingRows"+selectedCicSellingRows.length);
    if (selectedRows && selectedRows.length > 0 && selectedCicBuyingRows && selectedCicBuyingRows.length < 1 && selectedCicSellingRows && selectedCicSellingRows.length < 1)
    {
      if (selectedRows.length > 0) {
        AppData.setConfirmationModal(true, onHandleIsReserved, "radioType", "Provide suitable reasons for marking it as reserved.");
      } else {
        AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
      }
    }
    else{
      AppData.setAlertBox(true, "Select only SKU to proceed.");
      return;
    }

  }, [selectedRows,selectedCicBuyingRows,selectedCicSellingRows]);

  const onHandleSuggestedCIC = useCallback(() => {

    if (selectedRows.length === 0) {
      AppData.setAlertBox(true, "Select any Product SKU from Source Items.");
    } else if (selectedRows.length > 1) {
      AppData.setAlertBox(true, "More than one SKUs has been selected.");
    } else if (selectedCicBuyingRows.length > 0) {
      AppData.setAlertBox(true, "Unselect Buying CIC and proceed.");
    } else if (selectedCicSellingRows.length > 0) {
      AppData.setAlertBox(true, "Unselect Selling CIC and proceed.");
    } else {

      let data = [];

      selectedRows.map((value) => {

        if (value.absDSDWhse === "WHSE") {
          data.push({ whseDsd: "W", upcs: value.upc, dept: value.deptName })
        } else if (value.absDSDWhse === "DSD") {
          data.push({ whseDsd: "D", upcs: value.upc, dept: value.deptName })
        }

      });

      memiuServices.matchingBakeryTargetList(data[0]).then((res) => {

        let { data: { bakeryCicSearchResults } } = res;
        let { data: { targetCount } } = res;

        if (bakeryCicSearchResults && bakeryCicSearchResults.length > 0) {

          let result = bakeryCicSearchResults.map((value) => {
            return { ...value, type: "cicBuyer", displayUpc: value.upc[0].charAt(0) + "-" + value.upc[0].charAt(1) + "-" + value.upc[0].substring(2, 7) + "-" + value.upc[0].substring(7, 12) }
          });

          setBakeryCicSearchRes({ bakeryCicSearch: result, targetCount });
          setBakeryCicSellingSearchRes({ bakeryCicSearch: result, targetCount });
        } else {
          setBakeryCicSearchRes({ bakeryCicSearch: [], targetCount: 0 });
          setBakeryCicSellingSearchRes({ bakeryCicSearch: [], targetCount: 0 });
        }

      }).catch((error) => {
        // AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
      });


    }

  }, [selectedRows, selectedCicSellingRows, selectedCicBuyingRows]);

  const onHandleInheritMap = useCallback((type) => {

    let markedBuyingSrc = "";
    let markedSellingSrc = "";
    let error = false;

    if (selectedRows.length > 0 && selectedCicSellingRows.length > 0 && selectedCicBuyingRows.length > 0) {

      selectedRows.map((value, index) => {
        if (value.absDSDWhse !== selectedRows[selectedRows.length - 1].absDSDWhse) {
          error = true;
          AppData.setAlertBox(true, "Different type of SKUs has been selected.");
          return;
        }
        if (selectedCicBuyingRows[0].whseDsd !== ("WHSE-DSD" || "whse-dsd")) {
          if (value.absDSDWhse !== selectedCicBuyingRows[0].whseDsd) {
            error = true;
            AppData.setAlertBox(true, "Select same product source items for SKU and Buying CIC.");
            return;
          }
        }
        if (selectedCicSellingRows[0].whseDsd != ("WHSE-DSD" || "whse-dsd")) {
          if (value.absDSDWhse != selectedCicSellingRows[0].whseDsd) {
            error = true;
            AppData.setAlertBox(true, "Select same product source items for SKU and Selling CIC.");
            return;
          }
        }
        if (value.usage != selectedRows[selectedRows.length - 1].usage) {
          error = true;
          AppData.setAlertBox(true, "Different usage ind SKUs has been selected.");
          return;
        }
        if ((value.usage != selectedCicBuyingRows[0].itemUSageInd) &&
          (value.usage != selectedCicSellingRows[0].itemUSageInd)) {
          error = true;
          AppData.setAlertBox(true, "SKU's Usage ind and Buying/Selling CIC's Item usage ind should be same.");
          return;
        }
        if ((value.absDSDWhse == selectedCicBuyingRows[0].whseDsd) || selectedCicBuyingRows[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
          //check for similar values and store in a boolean string
          markedBuyingSrc = value.absDSDWhse;
        }

        if ((value.absDSDWhse == selectedCicSellingRows[0].whseDsd) || selectedCicSellingRows[0].whseDsd == ("WHSE-DSD" || "whse-dsd")) {
          //check for similar values and store in a boolean string
          markedSellingSrc = value.absDSDWhse;
        }
      })

    }
    if (markedBuyingSrc == "WHSE" && markedSellingSrc == "WHSE" &&
      ((selectedRows.length > 1) || (selectedCicBuyingRows.length > 1) || (selectedCicSellingRows.length > 1))) {
      AppData.setAlertBox(true, "Invalid selection. WHSE item only allows mapping of one SKU with one Buying CIC & Selling CIC.");
      return;
    } else {
      if (selectedRows.length > 0) {

        if (selectedCicSellingRows.length < 1 || selectedCicBuyingRows.length < 1) {
          error = true;
          AppData.setAlertBox(true, "Atleast one CIC must be selected from Buying & Selling.");
          return;
        }
        if (selectedCicSellingRows.length > 1 || selectedCicBuyingRows.length > 1) {
          error = true;
          AppData.setAlertBox(true, "Only one CIC must be selected from Buying & Selling.");
          return;
        }

        if ((markedBuyingSrc == "WHSE" && selectedCicBuyingRows && selectedCicBuyingRows[0].mappingStatus == 'MAPPED') ||
          (markedSellingSrc == "WHSE" && selectedCicSellingRows && selectedCicSellingRows[0].mappingStatus == 'MAPPED')) {
          error = true;
          AppData.setAlertBox(true, "WHSE items cannot be mapped again.");
          return;
        }

        if (error !== true) {

          let productSKUs = selectedRows.map((value) => {
            return value.sku
          });

          let skuModalTitle = selectedRows.map((value) => {
            return `${value.sku} / ${value.itemDesc}`
          });

          let cicBuyModalTitle = `${selectedCicBuyingRows[0].cic} / ${selectedCicBuyingRows[0].itemDesc}`;

          let cicSellModalTitle = `${selectedCicSellingRows[0].cic} / ${selectedCicSellingRows[0].itemDesc}`;


          let reqData = { companyID: companyId, divisionID: divisionId, productSKUs: productSKUs, buyingCic: selectedCicBuyingRows[0].cic, sellingCic: selectedCicSellingRows[0].cic, whseDsd: selectedCicBuyingRows[0].whseDsd }

          memiuServices.loadOnMapEditFields(reqData).then((res) => {

            let { data } = res;

            if (type === "INHERIT_MAP")
              AppData.setMappingModal(true, onHandleInherit, data.buyDto, skuModalTitle, data.sellDto, cicBuyModalTitle, cicSellModalTitle);
            else if (type === "ADD_MAP")
              AppData.setMappingModal(true, onHandleAddMap, data.buyDto, skuModalTitle, data.sellDto, cicBuyModalTitle, cicSellModalTitle);

          }).catch((error) => {
            AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
          });
        }

        AppData.setConfirmationModal(false);

      } else {
        AppData.setAlertBox(true, "Select item from SKU, Buying CIC and Selling CIC to proceed.");
      }
    }

  }, [selectedRows, selectedCicSellingRows, selectedCicBuyingRows]);

  const onHandleInherit = useCallback((sellData, buyData) => {

    if (Object.keys(sellData).length > 0 && Object.keys(buyData).length > 0) {

      let buyFilterData = selectedRows.map((value) => {
        return { ...sellData, targetEdited: true, updatedUserId: userId, sku: value.sku, targetTypeIndicator: "B", companyID: companyId, divisionID: divisionId, upc: selectedCicBuyingRows[0].upc[0], cic: selectedCicBuyingRows[0].cic, mappingType: "INHERIT_MAP", mappingstatus: "MAPPED" }
      });

      let sellFilterData = selectedRows.map((value) => {
        return { ...buyData, targetEdited: true, updatedUserId: userId, sku: value.sku, targetTypeIndicator: "S", companyID: companyId, divisionID: divisionId, upc: selectedCicBuyingRows[0].upc[0], cic: selectedCicBuyingRows[0].cic, mappingType: "INHERIT_MAP", mappingstatus: "MAPPED" }
      });

      onHandleSKUMapping(buyFilterData, "INHERIT_MAP", sellFilterData);
    }

  }, [selectedCicBuyingRows, selectedCicSellingRows, companyId, divisionId, selectedRows]);


  const onHandleAddMap = useCallback((sellData, buyData) => {

    if (Object.keys(sellData).length > 0 && Object.keys(buyData).length > 0) {

      let buyFilterData = selectedRows.map((value) => {
        return { ...sellData, targetEdited: true, updatedUserId: userId, sku: value.sku, targetTypeIndicator: "B", companyID: companyId, divisionID: divisionId, upc: selectedCicBuyingRows[0].upc[0], cic: selectedCicBuyingRows[0].cic, mappingType: "ADD_MAP", mappingstatus: "MAPPED" }
      });

      let sellFilterData = selectedRows.map((value) => {
        return { ...buyData, targetEdited: true, updatedUserId: userId, sku: value.sku, targetTypeIndicator: "S", companyID: companyId, divisionID: divisionId, upc: selectedCicBuyingRows[0].upc[0], cic: selectedCicBuyingRows[0].cic, mappingType: "ADD_MAP", mappingstatus: "MAPPED" }
      });


      onHandleSKUMapping(buyFilterData, "ADD_MAP", sellFilterData);
    }

  }, [selectedCicBuyingRows, selectedCicSellingRows, companyId, divisionId, selectedRows]);

  const onHandleIsReserved = useCallback((comments, mappingstatus) => {
//console.log("selectedRows:"+selectedRows.length+"selectedCicBuyingRows,"+selectedCicBuyingRows.length+"selectedCicSellingRows"+selectedCicSellingRows.length);
    if (selectedRows.length > 0) {

      let letAutoMatchresult = selectedRows.map((value) => {
        return { companyID: companyId, divisionID: divisionId, upc: value.upc[0], sku: value.sku, mappingType: "RESERVED", targetTypeIndicator: "B", updatedUserId: userId, comments, mappingstatus }
      });

      onHandleSKUMapping(letAutoMatchresult, "RESERVED", []);

    } else {
      AppData.setAlertBox(true, "Select only SKU to proceed.");
    }

  }, [selectedRows])

  const onHandleMarkAsDead = useCallback((textValue) => {

    if (selectedRows.length > 0) {
   
      let letAutoMatchresult = selectedRows.map((value) => {
        return { companyID: companyId, divisionID: divisionId, upc: value.upc[0], sku: value.sku, comments: textValue, mappingType: "MARK_AS_DEAD", targetTypeIndicator: "B", updatedUserId: userId }
      });

      onHandleSKUMapping(letAutoMatchresult, "MARK_AS_DEAD", []);

    } else {
      AppData.setAlertBox(true, "Select only SKU to proceed.");
    }

  }, [selectedRows,selectedCicBuyingRows,selectedCicSellingRows]);

  const onHandleAutoMatch = useCallback(() => {

    if (selectedRows.length > 0) {

      let letAutoMatchresult = selectedRows.map((value) => {
        return { companyID: companyId, "divisionID": divisionId, upc: value.upc[0], sku: value.sku, mappingType: "LET_AUTO_MATCH", targetTypeIndicator: "B", updatedUserId: userId }
      });

      onHandleSKUMapping(letAutoMatchresult, "LET_AUTO_MATCH", []);

    } else {
      AppData.setAlertBox(true, "Select only SKU to proceed.");
    }

  }, [selectedRows]);

  const onHandleSKUMapping = useCallback((buyResData, bakMappingType, sellResData) => {

    let srcReq = {
      "companyID": companyId,
      "divisionID": divisionId,
      "mappingStatus": filterByStatus,
      "filterAvail": filterAvail,
      "filter": filterCriteria,
      "itemType": itemType,
      "searchCriteriaValue": searchSKUCriteria.searchCriteriaValue
    }

    if (searchSKUCriteria.searchCriteriaValue !== null) {
      srcReq.searchCriteria = searchSKUCriteria.searchCriteria
    }

    let targetBuyingReq = {
      "companyID": companyId,
      "divisionID": divisionId,
      "mappingStatus": filterByCicStatus,
      "filterAvail": buyingCicFilterAvail,
      "filter": buyingCicFilterCriteria,
      "itemType": buyingCicItemType,
      "searchCriteriaValue": searchCicCriteria.searchCriteriaValue,
      "targetTypeIndicator": "B"
    }

    if (searchCicCriteria.searchCriteriaValue !== null) {
      targetBuyingReq.searchCriteria = searchCicCriteria.searchCriteria
    }

    let tqrgetSellerReq = {
      "companyID": companyId,
      "divisionID": divisionId,
      "mappingStatus": filterByCicSellingStatus,
      "filterAvail": buyingCicSellingFilterAvail,
      "filter": buyingCicSellingFilterCriteria,
      "itemType": buyingCicSellingItemType,
      "searchCriteriaValue": searchCicSellingCriteria.searchCriteriaValue,
      "targetTypeIndicator": "S"
    }

    let data = {
      "sourceSearchRequest": srcReq,
      "targetBuyerSearchRequest": targetBuyingReq,
      "targetSellerSearchRequest": tqrgetSellerReq,
      "mappingrequestBuyer": buyResData,
      "mappingrequestSeller": sellResData
    };

    if (searchCicSellingCriteria.searchCriteriaValue !== null) {
      data.searchCriteria = searchCicSellingCriteria.searchCriteria
    }


    if (bakMappingType === "INHERIT_MAP" || bakMappingType === "ADD_MAP")
      AppData.setMappingModal(false);


    memiuServices.bakeryactions(data).then((res) => {

      let { data } = res;

      if (data) {
        if (data.actionSuccessStatus === 0) {
          AppData.setAlertBox(true, data.errorMessages[0]);
        } else {

          let { bakerySKUSearchResults } = data;
          let { sourceCount } = data;

          if (bakerySKUSearchResults) {
            let result = bakerySKUSearchResults.map((value) => {
              return { ...value, type: "sku", displayUpc: value.upc[0].charAt(0) + "-" + value.upc[0].charAt(1) + "-" + value.upc[0].substring(2, 7) + "-" + value.upc[0].substring(7, 12) }
            });

            AppData.setAlertBox(true, bakMappingType !== "RESERVED" ? data.errorMessages[0] : "Selected Items moved to Reserve category.");

            setSelectedRows([]);
            setSelectedCicBuyingRows([]);
            setSelectedCicSellingRows([]);

            setBakerySkuSearchRes({ bakerySkuSearch: result, sourceCount: sourceCount });
          } else {
            setBakerySkuSearchRes({ bakerySkuSearch: [], sourceCount: 0 });
          }


        }
      }

    }).catch((error) => {
      AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
    });

    AppData.setConfirmationModal(false);


  }, [itemType, filterByStatus, searchSKUCriteria, filterCriteria, filterAvail, filterByCicStatus, buyingCicItemType, searchCicCriteria, buyingCicFilterAvail, buyingCicFilterCriteria, filterByCicSellingStatus, buyingCicSellingItemType, searchCicSellingCriteria, buyingCicSellingFilterAvail, buyingCicSellingFilterCriteria, selectedRows])

  useEffect(() => {

    let isItemTypeTrue = Object.values(itemType).every((value) => { return !value });
    setSelectedRows([])
    if (companyId && divisionId && !isItemTypeTrue) {

      let data = {
        "companyID": companyId,
        "divisionID": divisionId,
        "mappingStatus": filterByStatus,
        "filterAvail": filterAvail,
        "filter": filterCriteria,
        "itemType": itemType,
        "searchCriteriaValue": searchSKUCriteria.searchCriteriaValue
      }

      if (searchSKUCriteria.searchCriteriaValue !== null) {
        data.searchCriteria = searchSKUCriteria.searchCriteria
      }

      memiuServices.bakerySourceList(data).then((res) => {

        let { data: { bakerySkuSearchResults } } = res;
        let { data: { sourceCount } } = res;

        if (bakerySkuSearchResults) {

          let result = bakerySkuSearchResults.map((value, index) => {
            return { ...value, id: index, type: "sku", displayUpc: value.upc[0].charAt(0) + "-" + value.upc[0].charAt(1) + "-" + value.upc[0].substring(2, 7) + "-" + value.upc[0].substring(7, 12) }
          });

          setBakerySkuSearchRes({ bakerySkuSearch: result, sourceCount: sourceCount });
        } else {
          setBakerySkuSearchRes({ bakerySkuSearch: [], sourceCount: 0 });
        }

      }).catch((error) => {
        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
      });
    }

  }, [itemType, companyId, divisionId, filterByStatus, searchSKUCriteria, filterCriteria, filterAvail]);

  useEffect(() => {
    setSelectedCicBuyingRows([]);
    let buyingCicItemTypeTrue = Object.values(buyingCicItemType).every((value) => { return !value });

    if (companyId && divisionId && !buyingCicItemTypeTrue) {

      let data = {
        "companyID": companyId,
        "divisionID": divisionId,
        "mappingStatus": filterByCicStatus,
        "filterAvail": buyingCicFilterAvail,
        "filter": buyingCicFilterCriteria,
        "itemType": buyingCicItemType,
        "searchCriteriaValue": searchCicCriteria.searchCriteriaValue,
        "targetTypeIndicator": "B"
      }

      if (searchCicCriteria.searchCriteriaValue !== null) {
        data.searchCriteria = searchCicCriteria.searchCriteria
      }

      memiuServices.bakeryTargetList(data).then((res) => {
        let { data: { bakeryCicSearchResults } } = res;
        let { data: { targetCount } } = res;
        if (bakeryCicSearchResults) {
          let result = bakeryCicSearchResults.map((value, index) => {
            return { ...value, id: index, type: "cicBuyer", displayUpc: value.upc[0].charAt(0) + "-" + value.upc[0].charAt(1) + "-" + value.upc[0].substring(2, 7) + "-" + value.upc[0].substring(7, 12) }
          });
          setBakeryCicSearchRes({ bakeryCicSearch: result, targetCount });
        } else {
          setBakeryCicSearchRes({ bakeryCicSearch: [], targetCount: 0 });
        }
      }).catch((error) => {
        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
      });
    }

  }, [filterByCicStatus, buyingCicItemType, companyId, divisionId, searchCicCriteria, buyingCicFilterAvail, buyingCicFilterCriteria]);

  useEffect(() => {
    setSelectedCicSellingRows([]);
    let buyingCicSellingItemTypeTrue = Object.values(buyingCicSellingItemType).every((value) => { return !value });

    if (companyId && divisionId && !buyingCicSellingItemTypeTrue) {

      let data = {
        "companyID": companyId,
        "divisionID": divisionId,
        "mappingStatus": filterByCicSellingStatus,
        "filterAvail": buyingCicSellingFilterAvail,
        "filter": buyingCicSellingFilterCriteria,
        "itemType": buyingCicSellingItemType,
        "searchCriteriaValue": searchCicSellingCriteria.searchCriteriaValue,
        "targetTypeIndicator": "S"
      }

      if (searchCicSellingCriteria.searchCriteriaValue !== null) {
        data.searchCriteria = searchCicSellingCriteria.searchCriteria
      }

      memiuServices.bakeryTargetList(data).then((res) => {
        let { data: { bakeryCicSearchResults } } = res;
        let { data: { targetCount } } = res;
        if (bakeryCicSearchResults) {
          let result = bakeryCicSearchResults.map((value, index) => {
            return { ...value, id: index, type: "cicSeller", displayUpc: value.upc[0].charAt(0) + "-" + value.upc[0].charAt(1) + "-" + value.upc[0].substring(2, 7) + "-" + value.upc[0].substring(7, 12) }
          });
          setBakeryCicSellingSearchRes({ bakeryCicSearch: result, targetCount });
        } else {
          setBakeryCicSellingSearchRes({ bakeryCicSearch: [], targetCount: 0 });
        }
      }).catch((error) => {
        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
      });
    }

  }, [filterByCicSellingStatus, buyingCicSellingItemType, companyId, divisionId, searchCicSellingCriteria, buyingCicSellingFilterAvail, buyingCicSellingFilterCriteria]);

  let contextSkuOptions = [
    { label: "Force New", onClick: onClickForceNew },
    { label: "Let Auto Match", onClick: onHandleAutoMatch },
    { label: "Mark as Dead", onClick: onClickMarkDead },
    { label: "Suggested CIC", onClick: onHandleAutoMatch },
    { label: "Reserve", onClick: onClickIsReserved }
  ]

  return (
    <Grid
      container
      style={{ padding: "10px" }}
    >
      <Grid item xs={6}>
        <Grid container>
          <Grid item xs={12}>
            <ButtonMemi
              startIcon={<CheckBox style={{ transform: "scale(0.9)" }} />}
              classNameMemi="mapItemsButton mapItemsLetAutoMatchButton "
              btnval={"Let Auto Match"}
              onClick={onHandleAutoMatch}
              btnsize="small"
            />
            <ButtonMemi
              startIcon={<NotInterested style={{ transform: "scale(0.8)" }} />}
              classNameMemi="mapItemsButton mapItemsMarkAsDeadButton"
              btnval={"Mark As Dead"}
              onClick={onClickMarkDead}
              btnsize="small"
            />
            <ButtonMemi
              startIcon={<Add style={{ transform: "scale(0.9)" }} />}
              classNameMemi="mapItemsButton  mapItemsForceNewButton"
              btnval="Force New"
              onClick={onClickForceNew}
              btnsize="small"
            />
            <ButtonMemi
              startIcon={<LocalOffer style={{ transform: "scale(0.8)" }} />}
              classNameMemi={`${isReserved ? "isReservedDisableCls mapItemsButton  mapItemsReserveButton" : "mapItemsButton  mapItemsReserveButton"}`}
              btnval="Reserve"
              btndisabled={isReserved}
              onClick={onClickIsReserved}
              btnsize="small"
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={6}>
        <Grid container>
          <Grid item xs={2} className="mapItemsHeader">
            Bakery Mapping
          </Grid>
          <Grid item xs={10} style={{ display: "flex" }}>
            <ButtonMemi
              startIcon={<Search />}
              classNameMemi="mapItemsButton mapItemsSuggestedCicButton "
              btnval={"Suggested CIC"}
              onClick={onHandleSuggestedCIC}
              btnsize="small"
            />
            <ButtonMemi
              startIcon={<Visibility style={{ transform: "scale(0.8)" }} />}
              classNameMemi="mapItemsButton mapItemsReserveButton"
              btnval={"Inherit Map"}
              onClick={() => onHandleInheritMap("INHERIT_MAP")}
              btnsize="small"
            />
            <ButtonMemi
              startIcon={<EditLocation style={{ transform: "scale(0.9)" }} />}
              classNameMemi="mapItemsButton mapItemsReserveButton"
              btnval="Add Map"
              onClick={() => onHandleInheritMap("ADD_MAP")}
              btnsize="small"
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={6}>

        <LoadSkuAndCIC
          itemType={itemType}
          handleSelectItemType={handleSelectItemType}
          filterByOption={filterByOption}
          filterByStatus={filterByStatus}
          onHandleFilterByStatus={onHandleFilterByStatus}
          selectByOption={selectByOption}
          onHandleSelectStatus={onHandleSelectStatus}
          searchCriteria={searchCriteria}
          searchValue={searchValue}
          setSearchValue={setSearchValue}
          setSearchCriteria={setSearchCriteria}
          sortableList={sortableList}
          setSortableList={setSortableList}
          filterCriteria={filterCriteria}
          onHandleFilterByMapping={onHandleFilterByMapping}
          type={"SKU"}
          columns={columns}
          bakeryData={bakerySkuSearchRes.bakerySkuSearch}
          totalCount={bakerySkuSearchRes.sourceCount}
          cicType={""}
          contextOptions={contextSkuOptions}
          selectedRows={selectedRows}
          setSelectedRows={handleSelectedRows}
          setData={(data) => setBakerySkuSearchRes({bakerySkuSearch:data, sourceCount:data.length})}
        />

        {/* {onHandleSKU("SKU", itemType)} */}
      </Grid>
      <Grid item xs={6}>

        <LoadSkuAndCIC
          itemType={buyingCicItemType}
          handleSelectItemType={handleSelectBuyCICItemType}
          filterByOption={filterCicByOption}
          filterByStatus={filterByCicStatus}
          onHandleFilterByStatus={onHandleCicFilterByStatus}
          selectByOption={selectCicByOption}
          onHandleSelectStatus={onHandleCicSelectStatus}
          searchCriteria={searchBuyCriteria}
          searchValue={searchCicValue}
          setSearchValue={setSearchCicValue}
          setSearchCriteria={setSearchBuyCriteria}
          sortableList={sortableList}
          setSortableList={setSortableList}
          filterCriteria={buyingCicFilterCriteria}
          onHandleFilterByMapping={onHandleCicFilterByMapping}
          type={"CIC"}
          columns={buyingCicColumns}
          bakeryData={bakeryCicSearchRes.bakeryCicSearch}
          totalCount={bakeryCicSearchRes.targetCount}
          cicType={"BUYING"}
          contextOptions={contextCicOptions}
          selectedRows={selectedCicBuyingRows}
          setSelectedRows={handleSelectedCicBuyingRows}
          setData={(data) => setBakeryCicSearchRes({bakeryCicSearch:data, sourceCount:data.length})}

        />

        <LoadSkuAndCIC
          itemType={buyingCicSellingItemType}
          handleSelectItemType={handleSelectBuyCICSellingItemType}
          filterByOption={filterCicByOption}
          filterByStatus={filterByCicSellingStatus}
          onHandleFilterByStatus={onHandleCicSellingFilterByStatus}
          selectByOption={selectCicByOption}
          onHandleSelectStatus={onHandleCicSellingSelectStatus}
          searchCriteria={searchSellCriteria}
          searchValue={searchCicSellingValue}
          setSearchValue={setSearchCicSellingValue}
          setSearchCriteria={setSearchSellCriteria}
          sortableList={sortableList}
          setSortableList={setSortableList}
          filterCriteria={buyingCicSellingFilterCriteria}
          onHandleFilterByMapping={onHandleCicSellingFilterByMapping}
          type={"CIC"}
          columns={buyingCicSellingColumns}
          bakeryData={bakeryCicSellingSearchRes.bakeryCicSearch}
          totalCount={bakeryCicSellingSearchRes.targetCount}
          cicType={"SELLING"}
          contextOptions={contextCicOptions}
          selectedRows={selectedCicSellingRows}
          setSelectedRows={handleSelectedCicSellingRows}
          setData={(data) => setBakeryCicSellingSearchRes({bakeryCicSearch:data, targetCount:data.length})}
        />
        {/* {onHandleSKU("BUYING_CIC", buyingCicItemType)} */}
      </Grid>
    </Grid >

  );

};

export default BakeryMapping;
