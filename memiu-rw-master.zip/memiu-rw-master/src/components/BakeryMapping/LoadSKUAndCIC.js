import React, { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { Grid } from '@material-ui/core';
import ButtonMemi from 'components/ButtonMemi/ButtonMemi';
import { Add, CheckBox, Help, LocalOffer, NotInterested, SyncDisabled } from '@material-ui/icons';
import SelectMenuMemi from 'components/SelectMenuMemi/SelectMenuMemi';
import SortByMemi from 'components/SortByMemi/SortByMemi';
import FilterByMapping from 'components/FilterByMapping/FilterByMapping';
import SearchFieldMemi from 'components/SearchFieldMemi/SearchFieldMemi';
import FilterByStatus from 'components/FilterByStatus/FilterByStatus';
import ApplicationContext from 'context/ApplicationContext';
import TableMappingCollapsible from 'components/TableMemi/TableMappingCollapsible';
import { memiuServices } from 'api/memiu/memiuService';

import TableMemi from "../../components/TableMemi/TableMemi";

export default function LoadSkuAndCIC(props) {

    const AppData = useContext(ApplicationContext)
    const { divisionId, companyId } = AppData;

    const { itemType, handleSelectItemType, filterByOption, filterByStatus, onHandleFilterByStatus, selectByOption, onHandleSelectStatus, searchValue, setSearchValue, setSearchCriteria, sortableList, setSortableList, filterCriteria, onHandleFilterByMapping, type, columns, bakeryData, totalCount, cicType, contextOptions, selectedRows, setSelectedRows, searchCriteria } = props;

    const innerComponent = (row, column) => {

        if (type === "SKU") {
            return (
                <Grid container className="innerGrid">
                    <Grid item xs={3} className="innerHead">
                        Sign Number
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Usage Ind
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Display
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Created On
                    </Grid>

                    <Grid item xs={3} className="innerData">
                        {row.sizeNumber}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.usage}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.display}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.createdOn}
                    </Grid>

                    <Grid item xs={3} className="innerHead">
                        PLU
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Hierarchy Level 1
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Hierarchy Level 2
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Hierarchy Level 3
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.plu}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.hierarchyLevelOne}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.hierarchyLevelTwo}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.hierarchyLevelThree}
                    </Grid>

                    <Grid item xs={6} className="innerHead">
                        Supplier No / Supplier Name
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Selling Method
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Receiving Method
                    </Grid>
                    <Grid item xs={6} className="innerData">
                        {row.supplierNm}/{row.supplierNam}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.sellingMethodCd != null ? row.sellingMethodCd : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.recievingRandomInd != null ? row.recievingRandomInd : ""}
                    </Grid>
                </Grid>
            )
        }

        if (cicType === "SELLING") {

            return (
                <Grid container className="innerGrid">
                    <Grid item xs={3} className="innerHead">
                        Usage Ind
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Usage Type
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Status Corp
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Display
                    </Grid>

                    <Grid item xs={3} className="innerData">
                        {row.usage}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.usage}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.statusCorp}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.display}
                    </Grid>

                    <Grid item xs={3} className="innerHead">
                        SMIC
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        PLU
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Farm/Wild
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Bakery Ingredients
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.smic}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.plu}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.farmOrWild}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.bakeryIngredients}
                    </Grid>

                    <Grid item xs={3} className="innerHead">
                        Scale SellByDays
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale EatByDays
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale NetWeight
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale NetWeightUnit
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleSellByDays !== null ? row.scaleSellByDays : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleEatByDays != null ? row.scaleEatByDays : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleNetWeight !== null ? row.scaleNetWeight : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleNetWeightUnit !== null ? row.scaleNetWeightUnit : ""}
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Tare Code
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Shelf Life
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        ROG Count & more.
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.tareCode !== null ? row.tareCode : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scale !== null ? row.scale : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.shelfLife !== null ? row.shelfLife : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        <Help style={{ color: "grey", transform: "scale(0.8)" }} />
                    </Grid>

                    <Grid item xs={4} className="innerHead">
                        VOC
                    </Grid>
                    <Grid item xs={4} className="innerHead">
                        Product Source
                    </Grid>
                    <Grid item xs={4} className="innerHead">
                        Vendor Code - Vendor Name
                    </Grid>
                    <Grid item xs={4} className="innerData">
                        {row.voc !== null ? row.voc : ""}
                    </Grid>
                    <Grid item xs={4} className="innerData">
                        {row.whseDsd !== null ? row.whseDsd : ""}
                    </Grid>
                    <Grid item xs={4} className="innerData">
                        {row.vendor_detail !== null ? row.vendor_detail : ""}
                    </Grid>

                </Grid>
            )
        }

        if (cicType === "BUYING") {

            return (
                <Grid container className="innerGrid">
                    <Grid item xs={3} className="innerHead">
                        Usage Ind
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Usage Type
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Status Corp
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Display
                    </Grid>

                    <Grid item xs={3} className="innerData">
                        {row.usage}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.usage}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.statusCorp}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.display}
                    </Grid>

                    <Grid item xs={3} className="innerHead">
                        SMIC
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        PLU
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Farm/Wild
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Bakery Ingredients
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.smic}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.plu}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.farmOrWild}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.bakeryIngredients}
                    </Grid>

                    <Grid item xs={3} className="innerHead">
                        Scale SellByDays
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale EatByDays
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale NetWeight
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale NetWeightUnit
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleSellByDays !== null ? row.scaleSellByDays : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleEatByDays !== null ? row.scaleEatByDays : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleNetWeight !== null ? row.scaleNetWeight : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scaleNetWeightUnit !== null ? row.scaleNetWeightUnit : ""}
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Tare Code
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Scale
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        Shelf Life
                    </Grid>
                    <Grid item xs={3} className="innerHead">
                        ROG Count & more.
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.tareCode !== null ? row.tareCode : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.scale !== null ? row.scale : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        {row.shelfLife !== null ? row.shelfLife : ""}
                    </Grid>
                    <Grid item xs={3} className="innerData">
                        <Help style={{ color: "grey", transform: "scale(0.8)" }} />
                    </Grid>

                    <Grid item xs={4} className="innerHead">
                        VOC
                    </Grid>
                    <Grid item xs={4} className="innerHead">
                        Product Source
                    </Grid>
                    <Grid item xs={4} className="innerHead">
                        Vendor Code - Vendor Name
                    </Grid>
                    <Grid item xs={4} className="innerData">
                        {row.voc !== null ? row.voc : ""}
                    </Grid>
                    <Grid item xs={4} className="innerData">
                        {row.whseDsd !== null ? row.whseDsd : ""}
                    </Grid>
                    <Grid item xs={4} className="innerData">
                        {row.vendor_detail !== null ? row.vendor_detail : ""}
                    </Grid>

                </Grid>
            )
        }
    }

    return (
        <>
            <Grid container className="bakeryMapItemsSearchField">
                <Grid item xs={12}>

                    <div className="itemTypeSection">
                        {cicType && <span className="itemDetailsData">{cicType === "BUYING" ? "Buying CIC" : "Selling CIC"} &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span>}
                        <span className="mapItemsRadioLabel"> Item Type </span>
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType.all} value="all" onClick={handleSelectItemType} /> All
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType.system2} value="system2" onClick={handleSelectItemType} /> System 2
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType.system4} value="system4" onClick={handleSelectItemType} /> System 4
                        &nbsp; &nbsp;
                        <input type="radio" checked={itemType.plu} value="plu" onClick={handleSelectItemType} /> PLU
                    </div>
                </Grid>
                <p className="filterHdr">  Filter By Status</p>
                <Grid item xs={12} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <FilterByStatus
                        options={filterByOption}
                        value={filterByStatus}
                        setValue={onHandleFilterByStatus}
                    />

                    <SearchFieldMemi
                        options={selectByOption}
                        onSearch={onHandleSelectStatus}
                        searchValue={searchValue}
                        setSearchValue={setSearchValue}
                        setSearchCriteria={setSearchCriteria}
                        searchCriteria={searchCriteria}
                    />

                    <FilterByMapping
                        ButtonClass="mapItemsSortByButton"
                        btnsize="small"
                        bakery={true}
                        filterCriteria={filterCriteria}
                        RadioSortByLabelClass="RadioSortByLabelMapItems"
                        sortByClass="filterByBoxMapItems"
                        placement="left-start"
                        onClickApply={onHandleFilterByMapping}
                    />
                </Grid>
            </Grid>
            <Grid container className="">
                <Grid item xs={12}>
                    <div className={type === "SKU" ? "mappingBakeryTable" : "mappingBakeryTable buyingAndSelling"}>
                        <TableMappingCollapsible
                            id={type === "SKU" ? "sku" : "cic"}
                            columns={columns}
                            stickyHeader
                            containerClass={type === "SKU" ? "bakeryMappingContainer1" : "bakeryMappingContainer2"}
                            data={bakeryData}
                            // !memi03sku ? "Load SKU based upon Itemtype/Status/Search." : memi03sku && memi03sku.skuSearchResults ? null : ""
                            classNameMemi={!bakeryData ? "noDataLoadSkuCic" : "loadSkuCicTable"}
                            NoRowsOverlay={!bakeryData ? `Load ${type !== "SKU" ? cicType === "BUYING" ? "buying" : "selling" : ""} ${type} based upon Itemtype/Status/Search.` : bakeryData ? null : ""}
                            placeholder={bakeryData ? `Showing ${bakeryData.length} ${type} out of ${totalCount} items` : ""}
                            contextOptions={contextOptions}
                            selectedRows={selectedRows}
                            setSelectedRows={setSelectedRows}
                            setSelectionCriteria={type === "SKU" ? (row) => { return row.mappingStatus === "TO_BE_MAPPED" || row.mappingStatus === "AWAITING_NEW_CIC" || row.mappingStatus === "AWAITING_DIVISION_INPUT" || row.mappingStatus === "OTHERS" } : ""}
                            disableLoadMore={true}
                            disablePagination={true}
                            collapsibleTabelContent={(row, columns) => innerComponent(row, columns, cicType)}
                            setData={props.setData}
                        />

                        {/* <TableMemi
                            // data={AppData.memi08} const [bakerySkuSearchRes, setBakerySkuSearchRes] = useState({ bakerySkuSearch: [], sourceCount: 0 });
                            classnameMemi={type === "SKU" ? "bakeryMappingTable1" : "bakeryMappingTable2"}
                            rowheight={22}
                            selectionType="checkbox"
                            tableType="collapse"
                            columns={columns}
                            data={bakeryData}
                            hideFooter
                            hideFooterPaginatio"n
                            disableColumnMenu
                            disableColumnFilter
                        /> */}
                    </div>
                    {/* {!Object.values(itemType).every((value) => { return !value }) &&
                        < div className="mapshowCount_tr">
                            <div style={{ width: "50%" }}>
                                <span className="totalCountCls">Showing {bakeryData.length} SKU out of {totalCount} items.</span>
                            </div>
                            <div style={{ display: "flex" }}>
                                <div style={{ width: "100px", display: "flex" }}><div style={{ color: "#ca6b09" }} class="whseSquare"></div><span className="filterHdr"> -WHSE</span></div>
                                <div style={{ width: "100px", display: "flex" }}><div style={{ color: "#05ab21" }} class="dsdSquare"></div><span className="filterHdr"> -DSD</span></div>
                                <div style={{ width: "100px", display: "flex" }}><div style={{ color: "#04a6d6" }} class="whseDsdSquare"></div><span className="filterHdr"> -WHSEDSD</span></div>
                            </div>
                        </div>
                    } */}
                </Grid>
            </Grid>
        </>
    )
}
