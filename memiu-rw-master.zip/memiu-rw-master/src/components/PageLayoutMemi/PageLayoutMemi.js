import React, { useContext, useEffect } from "react";
import { Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Environment } from '../../utils';
import { RouteBase } from "../../routes/constants";
import ApplicationContext from "../../context/ApplicationContext";

import LoaderStatusPanel from "components/LoaderStatusPanel/LoaderStatusPanel";
const useStyles = makeStyles((theme) => ({
  logout: {
    display: "flex",
    justifyContent: "flex-end",
  },
}));

export default function PageLayoutMemi(props) {
  const classes = useStyles();

  const AppData = useContext(ApplicationContext)
  const { pathname } = window.location
  const { BaseRoute } = RouteBase
  // console.log("pathname" + pathname);
  useEffect(() => {
    AppData.setLoader(0);
  }, [pathname])

  return (
    <Grid container style={{ marginTop: "1px" }}>

      <Grid container>
        {props.navigationBar}
      </Grid>

      <Grid container style={{ minHeight: "90vh" }}>
        <Grid container className={`${!props.isBroder ? "pageLayoutContentGrid" : ""} }`} style={{ minHeight: "85vh" }}>
          <Grid item xs={12} className={`${props.isBroder ? "contentOutlineBroder" : "contentOutline"}`} style={{ height: props.fullHeight ? "100%" : "fit-content" }}>
            <Grid item sm={12} >
              <div className='pageLayoutTitle'>{props.pageTitle}</div>
            </Grid>
            <Grid item sm={12} className={classes.fixedBottom}>
              {props.mainContent}
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12}  >
          <div className="fixedBottom" >  <strong> MEMIU-Version : 07-19-22-02</strong> : {Environment.getReactAppVersion()}   </div>
        </Grid>
      </Grid>
      <LoaderStatusPanel />

    </Grid>
  )
};
