import React, {
  useEffect,
  useContext,
  useState,
  useCallback,
  useMemo
} from "react";

import { Grid } from "@material-ui/core";
import TableMemi from "../../components/TableMemi/TableMemi";
import ApplicationContext from "../../context/ApplicationContext";
import FilterByStatus from 'components/FilterByStatus/FilterByStatus';
import ButtonMemi from "../../components/ButtonMemi/ButtonMemi";
import SearchFieldMemi from 'components/SearchFieldMemi/SearchFieldMemi';
import { memiuServices } from "api/memiu/memiuService";
import UPCPopup from "components/UPCPopup/UPCPopup";
import IconsCircle from "components/IconsCircle/IconsCircle";
import { CalendarToday, Link } from "@material-ui/icons";

export const Mapped = () => {

  const AppData = useContext(ApplicationContext);

  const [searchValue, setSearchValue] = useState("")
  const [searchCriteria, setSearchCriteria] = useState(null);
  const [filterByStatus, setFilterByStatus] = useState("BOTH");
  const [mappedData, setMappedData] = useState([]);
  const [deptName, setDeptName] = useState({ sourceDept: [], targetDept: [] });
  const [selectedRow, setSelectedRows] = useState([]);
  const [isLoadData, setIsLoad] = useState(false);

  const [searchSKUCriteria, setSearchSKUCriteria] = useState({ searchCriteria: "", searchCriteriaValue: null });

  const { listDepartmentSource, listDepartmentTarget, companyId, divisionId } = AppData;

  let filterByOption = [
    { label: "Mapped", color: "#56912b", value: "MAPPED", children: [{ label: <><Link style={{ transform: "scale(0.8)", color: "#0573fb", transform: "rotate(-45deg)" }} />Inherit Map</>, value: "INHERIT_MAP" }, { label: <><Link style={{ transform: "scale(0.8)", color: "#fb0505", transform: "rotate(-45deg)" }} />Add Map</>, value: "ADD_MAP" }, { label: <><Link style={{ transform: "scale(0.8)", color: "#5eb122", transform: "rotate(-45deg)" }} /> All</>, value: "BOTH" }] },
    { label: "Converted", color: "#00adef", value: "CONVERTED" },
    { label: "Show All", color: "#f0ad4e", value: "SHOW_ALL" }
  ];

  const handleSelect = (rowClicked) => {
      let alreadySelected = false;
      selectedRow.forEach((row) => {
        if(row.id === rowClicked.id) {
          alreadySelected = true;
          return;
        }
      })
      if(alreadySelected) {
        setSelectedRows((rows) => {return rows.filter((row) => row.id !== rowClicked.id)})
      } else {
        setSelectedRows((rows) => {return [...rows, rowClicked]})
      }
  }

 

  const SelectComponent = ({ params }) => {
    const [checked, setChecked] = useState(false);
    useEffect(() => {
      let check = selectedRow.find((row) => row.id === params.row.id)
      setChecked(check ? true : false)
    }, [selectedRow, params])
    return (
      <div style={{ display: "flex" }} onClick={() => handleSelect(params.row)}>
        <div>
          <IconsCircle color={params.row.mappedStatus === "MAPPED" ? "#56912b" : "#00adef"} />
          <br />
          {
            params.row.mappingType ?
              <Link style={{ color: params.row.mappingType === "INHERIT_MAP" ? "#0573fb" : "#fb0505", transform: "rotate(-45deg)" }} />
              : ""
          }
        </div>
        <input
          type="checkbox"
          onChange={(e) => handleSelect(params.row)}
          checked={checked}
          style={{cursor:"pointer"}}
        />
      </div>
    )
  }

  const columns = [
    {
      field: 'select',
      headerName: "  ",
      headerAlign: "left",
      renderCell: (params) => (
        <SelectComponent params={params} />
      ),
      width: 25,
      sortable: false
    },
    {

      field: 'sourceSKU',
      headerName: 'Source SKU',
      headerAlign: "left",
      width: 135,
      // textAlign:"left",
      headerClassName: "mappedTableSrcCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)} style={{textAlign:"center"}}>
            <Grid item xs={12} className="mappedSkuCls innerSkuDataCls" title={params.row.sourceSKU} >
              {params.row.sourceSKU}
            </Grid>
            <Grid item xs={12} className={`mappedSkuCls mappedTargetStatusCol-INHERIT_MAP`}>
              {/* one */}
            </Grid>
          </Grid>
        </>
      ),
      type: "number"
      // colSpan: 2
    },
    {
      field: 'targetTargetCic',
      headerName: 'Target CIC',
      headerAlign: "left",
      width: 110,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)} style={{textAlign:"left"}}>
            <Grid item xs={12} className="innerSkuDataCls">

            </Grid>
            <Grid item xs={12} className={`mappedCicCls mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetTargetCic}>
              {params.row.targetTargetCic}
            </Grid>
          </Grid>
        </>
      ),
      type: "number"
      // sortable: false,
    },
    {
      field: 'itemDesc',
      headerName: 'Item Desc',
      headerAlign: "center",
      width: 300,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)} style={{textAlign:"left"}}>
            <Grid item className="innerSkuDataCls" title={params.row.itemDesc}>
              {params.row.itemDesc ? params.row.itemDesc : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetItemDesc}>
              {params.row.targetItemDesc ? params.row.targetItemDesc : ""}
            </Grid>
          </Grid>
        </>
      )
      // sortable: false
    },
    {
      field: 'vcf',
      headerName: 'VCF',
      headerAlign: "left",
      width: 58,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)}>
            <Grid item className="innerSkuDataCls" title={params.row.vcf}>
              {params.row.vcf!==null ? params.row.vcf : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetVcf}>
              {params.row.targetVcf!==null ? params.row.targetVcf : ""}
            </Grid>
          </Grid>
        </>
      ),
      type: "number"
      // sortable: false
    },
    {
      field: 'pack',
      headerName: 'Pack',
      headerAlign: "left",
      width: 65,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid" onClick={() => handleSelect(params.row)}>
            <Grid item className="innerSkuDataCls" title={params.row.pack}>
              {params.row.pack!==null ? params.row.pack : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetPack}>
              {params.row.targetPack ? params.row.targetPack : ""}
            </Grid>
          </Grid>
        </>
      ),
      type: "number"
      // sortable: false
    },
    {
      field: 'size',
      headerName: 'Size',
      headerAlign: "left",
      width: 70,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)}>
            <Grid item className="innerSkuDataCls" title={params.row.size}>
              {params.row.size}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetSize}>
              {params.row.targetSize}
            </Grid>
          </Grid>
        </>
      ),
      type: "number"
      // sortable: false
    },
    {
      field: 'usage',
      headerName: 'Usage',
      headerAlign: "left",
      width: 65,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)}>
            <Grid className="innerSkuDataCls" title={params.row.usage}>
              {params.row.usage ? params.row.usage : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetUsage}>
              {params.row.targetUsage ? params.row.targetUsage : ""}
            </Grid>
          </Grid>
        </>
      )
      // sortable: false
    },
    {
      field: 'display',
      headerName: 'Display',
      headerAlign: "left",
      width: 70,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid"  onClick={() => handleSelect(params.row)}>
            <Grid item className="innerSkuDataCls" title={params.row.display}>
              {params.row.display ? params.row.display : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetDisplay}>
              {params.row.targetDisplay ? params.row.targetDisplay : ""}
            </Grid>
          </Grid>
        </>
      )
      // sortable: false
    },
    {
      field: 'displayUpcList',
      headerName: 'UPC',
      headerAlign: "center",
      width: 160,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid" style={{textAlign:"center"}} >
            <Grid item className="innerSkuDataCls" >
              <span onClick={() => handleSelect(params.row)}>
              {params.row.upcList ? params.row.upcList[0].length < 6 ? params.row.upcList[0] : `${params.row.upcList[0][0]}-${params.row.upcList[0][1]}-${params.row.upcList[0][2]}${params.row.upcList[0][3]}${params.row.upcList[0][4]}${params.row.upcList[0][5]}${params.row.upcList[0][6]}-${params.row.upcList[0][7]}${params.row.upcList[0][8]}${params.row.upcList[0][9]}${params.row.upcList[0][10]}${params.row.upcList[0][11]}` : ""}
              </span>
              &nbsp;
              <UPCPopup
                columns={[
                  { headerName: "UPC List", field: "upc" },
                  { field: "lastSalesDate", headerName: "Last Sales Date" },
                ]}
                number={params.row.upcList.length}
                color="#4bd4e2"
                classNameMemi="upcPopupClass"
                enableCheckbox={true}
                onLoad={() => memiuServices.getMappedUPCListDetails(companyId, divisionId, params.row.sourceSKU, filterByStatus, "ALL")}
              />
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} onClick={() => handleSelect(params.row)}>
              {params.row.targetUpcList ? params.row.targetUpcList[0] : "NA"}
              {/* <UPCPopup
                columns={[
                  { headerName: "UPC List", field: "upc" },
                  { field: "totalSales", headerName: "Total Sales" },
                  { field: "Last Sales Date", headerName: "L.Sales DT" }
                ]}
                number={params.row.upc.length}
                color="#4bd4e2"
                enableCheckbox={true}
                onLoad={() => memiuServices.getMappedUPCListDetails(companyId, divisionId, params.row.targetSku, filterByStatus, "ALL")}
              /> */}
            </Grid>
          </Grid>
        </>
      )
      // sortable: false
    },
    {
      field: 'createdOn',
      headerName: 'Created On',
      headerAlign: "left",
      width: 110,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid" onClick={() => handleSelect(params.row)}>
            <Grid item className="innerSkuDataCls" title={params.row.createdOn}>
              {params.row.createdOn ? params.row.createdOn : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetCreatedOn}>
              {params.row.targetCreatedOn ? params.row.targetCreatedOn : ""}
            </Grid>
          </Grid>
        </>
      ),
      renderHeader: (params) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <strong> Created On </strong>
          <CalendarToday />
        </div>

      ),
      sortable: false
    },
    {
      field: 'lastShipDate',
      headerName: 'Last Ship Date',
      headerAlign: "left",
      width: 130,
      headerClassName: "mappedTableHeaderCls",
      renderCell: (params) => (
        <>
          <Grid container className="tableCellGrid" onClick={() => handleSelect(params.row)}>
            <Grid item className="innerSkuDataCls" title={params.row.lastShipDate}>
              {params.row.lastShipDate ? params.row.lastShipDate : ""}
            </Grid>
            <Grid item className={`mappedTargetStatusCol-${params.row.mappingType}`} title={params.row.targetLastShipDate}>
              {params.row.targetLastShipDate ? params.row.targetLastShipDate : ""}
            </Grid>
          </Grid>
        </>
      ),
      renderHeader: (params) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <strong> Last Ship Date </strong>
          <CalendarToday />
        </div>
      ),
      sortable: false
    },


  ];

  const handleSelectAll = () => {

    if (mappedData.length === selectedRow.length) {
      setSelectedRows([])
    } else {

      setSelectedRows(mappedData);
    }

  }

  const handleUnMap = useCallback(() => {
  console.log("Entering handle UnMap Method ");
  console.log("Selected Mapped Item "+selectedRow);
    let selectedmapReq = selectedRow.map((value) => {
    //  return { "companyID": companyId, "divisionID": divisionId, "upc": mappedData.upcList[0], "sku": mappedData.sourceSKU, "cic": mappedData.targetTargetCic, "mappingType": mappedData.mappingType }
    return { "companyID": companyId, "divisionID": divisionId, "upc": value.upcList[0], "sku": value.sourceSKU, "cic": value.targetTargetCic, "mappingType": value.mappingType }
    })
    console.log("UnMap selected Value : "+ selectedmapReq);
    let payload = {
      "mappedSearchRequest": {
        "companyID": companyId,
        "divisionID": divisionId,
        "filterAvail": false,
        "filter": {},
        "mappingStatus": filterByStatus,
        "itemType": {
          "all": true,
          "system2": false,
          "system4": false,
          "plu": false
        },
        "searchCriteriaValue": searchSKUCriteria.searchCriteriaValue
      },
      "mappingrequest": selectedmapReq,
      "fromMappedScreen": true
    }
    console.log("UnMap payload : "+ payload);
    if (searchSKUCriteria.searchCriteriaValue !== null) {
      payload.searchCriteria = searchSKUCriteria.searchCriteria
    }

    memiuServices.mappingAction(payload).then((response) => {

      setSelectedRows([]);

      let { data: { mappedSearchRequest: { mappedResultWrapper } } } = response;

      if (mappedResultWrapper) {

        let mappedDataRes = mappedResultWrapper.map((value, index) => {
          return { ...value.source, id: index, targetCreatedOn: value.target.createdOn, targetTargetCic: value.target.targetCIC, targetItemDesc: value.target.itemDesc, targetVcf: value.target.vcf, targetPack: value.target.pack, targetSize: value.target.size, targetUsage: value.target.usage, targetDisplay: value.target.display, targetUpc: value.target.upc, targetLastShipDate: value.target.lastShipDate, mappedItemIndicator: value.mappedItemIndicator, mappedStatus: value.mappedStatus, mappingType: value.mappingType, displayUpcList: value.source.upcList }
        });


        setMappedData(mappedDataRes);
        AppData.setAlertBox(true, "The conversion has been processed successfully.");

      } else {
        setMappedData([]);
      }

    }).catch((error) => {
      console.log("error")
    })



  }, [selectedRow, companyId, divisionId, filterByStatus, searchSKUCriteria])

  const handleFilterByStatus = useCallback((value) => {

    setFilterByStatus(value);

    setSelectedRows([]);

    let srcReq = {
      "companyID": companyId,
      "divisionID": divisionId,
      "filterAvail": false,
      "filter": {},
      "mappingStatus": value,
      "searchIndicator": "SOURCE_INDICATOR",
      "itemType": {
        "all": true,
        "system2": false,
        "system4": false,
        "plu": false
      },
      "searchCriteriaValue": searchSKUCriteria.searchCriteriaValue
    }

    if (searchSKUCriteria.searchCriteriaValue !== null) {
      srcReq.searchCriteria = searchSKUCriteria.searchCriteria
    }

    populateMappedData(srcReq)


  }, [filterByStatus, searchSKUCriteria, isLoadData, companyId, divisionId]);

  const handleSearch = useCallback(() => {

    setSearchSKUCriteria({ searchCriteria: searchCriteria ? searchCriteria.split("-")[1] : null, searchCriteriaValue: searchValue === "" ? null : searchValue });
    setSelectedRows([]);

    let srcReq = {
      "companyID": companyId,
      "divisionID": divisionId,
      "filterAvail": false,
      "filter": {},
      "mappingStatus": filterByStatus,
      "searchIndicator": searchCriteria ? `${searchCriteria.split("-")[0]}_INDICATOR` : null,
      "itemType": {
        "all": true,
        "system2": false,
        "system4": false,
        "plu": false
      },
      "searchCriteriaValue": searchValue === "" ? null : searchValue
    }

    if (searchValue !== null && searchCriteria) {
      srcReq.searchCriteria = searchCriteria.split("-")[1]
    }

    populateMappedData(srcReq)

  }, [searchCriteria, searchValue, filterByStatus, companyId, divisionId]);

  const populateMappedData = useCallback((payload) => {

    memiuServices.mappedList(payload).then((response) => {

      let { data: { mappedResultWrapper } } = response;

      setIsLoad(true);

      if (mappedResultWrapper) {

        let mappedDataRes = mappedResultWrapper.map((value, index) => {
          return { ...value.source, id: index, targetCreatedOn: value.target.createdOn, targetTargetCic: value.target.targetCIC, targetItemDesc: value.target.itemDesc, targetVcf: value.target.vcf, targetPack: value.target.pack, targetSize: value.target.size, targetUsage: value.target.usage, targetDisplay: value.target.display, targetUpc: value.target.upc, targetLastShipDate: value.target.lastShipDate, mappedItemIndicator: value.mappedItemIndicator, mappedStatus: value.mappedStatus, mappingType: value.mappingType, displayUpcList: value.source.upcList }
        });


        mappedDataRes.sort((x, y) => { return Number(x.sourceSKU) - Number(y.sourceSKU) })
        // setSelectedRows(mappedDataRes);

        setMappedData(mappedDataRes);
      } else {
        setMappedData([]);
      }

    }).catch((error) => {
      console.log("error")
    })
  }, [isLoadData])

  useEffect(() => {

    let deptSrcResult = listDepartmentSource.map((deptName) => {
      return { label: deptName.label, searchCriteria: "SOURCE-DEPT_NAME", value: deptName.value, searchLabel: "Department", inputValue: deptName.label,disabledInput:true }
    });

    let deptTargetResult = listDepartmentTarget.map((deptName) => {
      return { label: deptName.label, searchCriteria: "TARGET-DEPT_NAME", value: deptName.value, searchLabel: "Department", inputValue: deptName.label,disabledInput:true }
    });

    setDeptName({ sourceDept: deptSrcResult, targetDept: deptTargetResult })

  }, [listDepartmentSource, listDepartmentTarget]);

  const customNoRowsOverlay = () => {
    return (
      <div >
        <p className="mappedCustomNoRows">
          {!isLoadData ? "Load mapped items based upon Status/Search." : "No Result Found"}
        </p>
      </div>
    )
  }

  const rowsSelctedForTable = useMemo(() => {
    return selectedRow.map((row) => { return row.id })
  }, [selectedRow])


  return (

    <>
      <Grid container>
        <Grid container className="mappedHeaderContainer">
          <Grid item xs={1} >
            <p className="filterHdr" style={{ paddingBottom: "5px" }}>  Filter By Status</p>
            <FilterByStatus
              options={filterByOption}
              value={filterByStatus}
              setValue={handleFilterByStatus}
            />
          </Grid>

          <Grid item xs={3} style={{ display: "flex", paddingLeft: "2rem" }}>

            <ButtonMemi
              classNameMemi="MultiUnitScreenButton mappedBtn selectAllBtn"
              btnval={mappedData.length > 0 ? selectedRow.length !== mappedData.length ? "Select All" : "De-Select All" : "Select All"}
              onClick={handleSelectAll}
            />
            &nbsp;
            {selectedRow.length > 0 ? <ButtonMemi
              classNameMemi="MultiUnitScreenButton mappedBtn unMapBtn"
              btnval="Un Map"
              onClick={handleUnMap}
            /> : ""}
          </Grid>

          <Grid item xs={4}>

            <SearchFieldMemi
              // onClickSearch
              options={[
                { label: "Select", searchCriteria: null, value: "",disabledInput:true },
                {
                  label: "Source",
                  children: [{
                    label: "Department", children: deptName.sourceDept
                  },
                  { label: "SKU", searchCriteria: "SOURCE-SKU_VAL" },
                  { label: "Item Description", searchCriteria: "SOURCE-ITEM_DESC" },
                  { label: "UPC", searchCriteria: "SOURCE-UPC_VAL" },
                  // { label: "Display-Y", searchLabel: "Display", searchCriteria: "Disp", value: "Y" },
                  // { label: "Display-N", searchLabel: "Display", searchCriteria: "Disp", value: "N" },
                  { label: "Display-Y", searchLabel: "Display", searchCriteria: "SOURCE-DISP", value: "Y",disabledInput:true },
                  { label: "Display-N", searchLabel: "Display", searchCriteria: "SOURCE-DISP", value: "N",disabledInput:true },
                  { label: "WHSE", searchCriteria: "SOURCE-WHSE", value: "Y",disabledInput:true },
                  { label: "DSD", searchCriteria: "SOURCE-DSD", value: "Y",disabledInput:true },
                  { label: "Usage Ind", children: [{ label: "Resale", searchCriteria: "SOURCE-USAGE_TYPE", value: "R", searchLabel: "Usage Ind",disabledInput:true }, { label: "Material", value: "M", searchCriteria: "SOURCE-USAGE_TYPE", searchLabel: "Usage Ind",disabledInput:true }, { label: "Expense", value: "E", searchCriteria: "SOURCE-USAGE_TYPE", searchLabel: "Usage Ind",disabledInput:true }] }]
                },
                {
                  label: "Target",
                  children: [{
                    label: "Department", children: deptName.targetDept
                  },
                  { label: "CIC", searchCriteria: "TARGET-CIC_VAL" },
                  { label: "Item Description", searchCriteria: "TARGET-ITEM_DESC" },
                 
                  // { label: "Display-Y", searchLabel: "Display", searchCriteria: "Disp", value: "Y" },
                  // { label: "Display-N", searchLabel: "Display", searchCriteria: "Disp", value: "N" },
                  { label: "Display-Y", searchLabel: "Display", searchCriteria: "TARGET-DISP", value: "Y",disabledInput:true },
                  { label: "Display-N", searchLabel: "Display", searchCriteria: "TARGET-DISP", value: "N",disabledInput:true },
                  { label: "WHSE", searchCriteria: "TARGET-WHSE", value: "Y",disabledInput:true },
                  { label: "DSD", searchCriteria: "TARGET-DSD", value: "Y",disabledInput:true },
                  { label: "Usage Ind", children: [{ label: "Resale", searchCriteria: "TARGET-USAGE_TYPE", value: "R", searchLabel: "Usage Ind",disabledInput:true }, { label: "Material", value: "M", searchCriteria: "TARGET-USAGE_TYPE", searchLabel: "Usage Ind",disabledInput:true }, { label: "Expense", value: "E", searchCriteria: "TARGET-USAGE_TYPE", searchLabel: "Usage Ind",disabledInput:true }] }]
                }
              ]}
              searchCriteria={searchCriteria}
              searchValue={searchValue}
              setSearchValue={setSearchValue}
              setSearchCriteria={setSearchCriteria}
              onSearch={handleSearch}
            />

          </Grid>
          <Grid item xs={3} style={{ marginLeft: "auto" }}>
            <div className={"mappingTypeCls"} >Mapping Type</div>
            <div style={{ display: "flex", columnGap: "5px", float: "right", alignItems: "center" }}>
              <Link style={{ color: "#0573fb", transform: "rotate(-45deg)" }} /> <span className={"mappingTypeSpan"}>- Inherit Map</span>
              <Link style={{ color: "#fb0505", transform: "rotate(-45deg)" }} /> <span className={"mappingTypeSpan"}> - Add Map</span>
              <Link style={{ color: "#008b8b", transform: "rotate(-45deg)" }} /> <span className={"mappingTypeSpan"}> - ETL</span>
            </div>
          </Grid>
        </Grid>
        <Grid item xs={12}>

          <TableMemi
            classnameMemi="mappedTableCls"
            data={mappedData}
            columns={columns}
            rowheight={80}
            rowCount={mappedData.length}
            autoHeight={true}
            autoPageSize
            hideFooter
            selectedRows={rowsSelctedForTable}
            NoRowsOverlay={customNoRowsOverlay}
            // onRowClick={handleSelect}
          />

        </Grid>
      </Grid>
    </>
  );
};

export default Mapped;
