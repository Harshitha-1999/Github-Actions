import React from "react";
import "../../css/App.css";
import { Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Environment } from '../../utils';

const useStyles = makeStyles((theme) => ({
  logout: {
    display: "flex",
    justifyContent: "flex-end",
  },
}));

export default function PageLayoutMeup(props) {
  const classes = useStyles();

  return (
    <Grid container style={{ marginTop: "1px" }} >
      <Grid item xs={12} className="pageLayoutContentGridMeup">
        <Grid item xs={12} className="contentOutlineMeup">
          <Grid item sm={12}>
            {props.header}
          </Grid>
          {/* <Grid item sm={1} style={{ marginTop: "15px", fontSize: "22px" }}>
              {Environment.getAppName()}
            </Grid> */}
          <Grid container>

            <Grid item sm={12} className={classes.fixedBottom}>
              {/* <NavigationBarMeup/> */}
              {props.mainContentMeup}
            </Grid>

            <Grid item sm={12} component="footer" style={{ width: "100%" }}>
              {props.footerMeup}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  )
};
