import React, { useEffect, useContext } from 'react';
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";
import { CloseTwoTone } from '@material-ui/icons';

export default function TableModalMemi(props) {
    const AppData = useContext(ApplicationContext);
    const {pathname} = window.location;
    const handleSubmit = () => {
        AppData.setTableModal(false)
    }

    useEffect(() => {
        handleSubmit();
    },[pathname])
    const content = (
        <div style={{ display: "flex" }}>
            <table style={{ width: "100%" }}>
                <thead>
                    <tr>
                        {AppData.tableModal.columns.map((data, index) => (
                            <th className="tableModalTableHeading" style={{ textAlign: "left" }} key={index}>{data} </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {
                        AppData.tableModal.data.map((data, index) => (
                            <tr key={index}>
                                {AppData.tableModal.columns.map((column, index) => {
                                    return <th key={index} style={{ textAlign: "left" }}> {data[column]} </th>
                                })}
                            </tr>
                        ))
                    }
                </tbody>
            </table>
            <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={handleSubmit} />
        </div>
    )
    return (
        <ModalPopup
            open={AppData.tableModal.open}
            classNameMemi="tableModalPopup"
            popupContentClass="tableModalContent"
            popupTitleClass="popupTableModalTitle"
            popupContent={content}
        />
    )
}
