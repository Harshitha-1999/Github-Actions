import * as React from 'react';
import Popper from '@mui/material/Popper';
import { CloseTwoTone } from '@material-ui/icons';

export default function TablePopperMemi(props) {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [open, setOpen] = React.useState(false);
    const [placement, setPlacement] = React.useState();
    const handleClick = (newPlacement) => (event) => {
        setAnchorEl(event.currentTarget);
        setOpen((prev) => placement !== newPlacement || !prev);
        setPlacement(newPlacement);
    };

    const handleSubmit = () => {
        setOpen(false)
    }
    const content = (
        <div style={{ display: "flex" }}>
            <table style={{ width: "100%" }}>
                <thead>
                    <tr>
                        {props.columns.map((data, index) => (
                            <th className="tableModalTableHeading" style={{ textAlign: "left" }} key={index}>{data} </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {
                        props.data.map((data, index) => (
                            <tr key={index}>
                                {props.columns.map((column, index) => {
                                    return <th key={index} style={{ textAlign: "left" }}> {data[column]} </th>
                                })}
                            </tr>
                        ))
                    }
                </tbody>
            </table>
            <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={handleSubmit} />
        </div>

    )

    return (
        <>
            <Popper open={open} anchorEl={anchorEl} placement={placement} transition>
                {content}
            </Popper>
            <span className="tableBadge" onClick={() => handleClick("bottom-end")}>{props.badge}</span>
        </>
    );
}