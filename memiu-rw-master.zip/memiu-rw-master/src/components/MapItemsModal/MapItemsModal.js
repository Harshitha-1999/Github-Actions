import React, { useContext, useEffect, useState, useCallback, memo, useMemo } from 'react';
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import ModalPopup from 'components/ModalPopup/ModalPopup';
import ApplicationContext from "../../context/ApplicationContext";
import { OutlinedInput } from "@material-ui/core";

import { Grid } from '@material-ui/core';
import TextFieldMemi from 'components/TextField/TextFieldMemi';
import { CloseTwoTone } from '@material-ui/icons';
import DropDownMemi from '../DropDownMemi/DropDownMemi';
import { authTokenCookie } from 'utils';
import RogDescDetails from 'components/RogDetails/RogDescDetails';
// import ButtonMemi from 'components/ButtonMemi/ButtonMemi';

function MapItemsModal(props) {

    const AppData = useContext(ApplicationContext);
    const [isEditChecked, setEditChecked] = useState(false);

    const { data, skuTitle, cicBuyTitle, onSubmit, open } = props;

    const [dcPackDesc, setDcPackDesc] = useState("");
    const [dcSizeDsc, setDcSizeDsc] = useState("");
    const [prodwght, setProdwght] = useState("");
    const [handlingCode, setHandlingCode] = useState("I");
    const [buyerNum, setBuyerNum] = useState("");
    const [randomWtCd, setRandomWtCd] = useState("");
    const [sellByDays, setSellByDays] = useState("");
    const [useByDays, setUseByDays] = useState("");
    const [pullBydays, setPullBydays] = useState("");
    const [autoCostInv, setAutoCostInv] = useState("");
    const [billingType, setBillingType] = useState("");
    const [costAllow, setCostAllow] = useState("");
    const [costIb, setCostIb] = useState("");
    const [costInv, setCostInv] = useState("")
    const [costVend, setCostVend] = useState("")
    const [retailUnitPack, setRetailUnitPack] = useState("");
    const [labelSize, setLabelSize] = useState("");
    const [labelNumbers, setLabelNumbers] = useState("");
    const [ring, setRing] = useState("");
    const [hicone, setHicone] = useState("");
    const [tareCd, setTareCd] = useState("");
    const [sgnCount1, setSgnCount1] = useState("");
    const [sgnCount2, setSgnCount2] = useState("");
    const [sgnCount3, setSgnCount3] = useState("");
    const [fdStmp, setFdStmp] = useState("");
    const [prcTypeCd, setPrcTypeCd] = useState("")

    const [errorDcPackDesc, setErrorDcPackDesc] = useState(false);
    const [errorDcSizeDsc, setErrorDcSizeDsc] = useState(false);
    const [errorProdwght, setErrorProdwght] = useState(false);
    const [errorHandlingCode, setErrorHandlingCode] = useState(false);
    const [errorBuyerNum, setErrorBuyerNum] = useState(false);
    const [errorRandomWtCd, setErrorRandomWtCd] = useState(false);
    const [errorSellByDays, setErrorSellByDays] = useState(false);
    const [errorUseByDays, setErrorUseByDays] = useState(false);
    const [errorPullBydays, setErrorPullBydays] = useState(false);
    const [errorAutoCostInv, setErrorAutoCostInv] = useState(false);
    const [errorBillingType, setErrorBillingType] = useState(false);
    const [errorCostAllow, setErrorCostAllow] = useState(false);
    const [errorCostIb, setErrorCostIb] = useState(false);
    const [errorCostInv, setErrorCostInv] = useState(false);
    const [errorCostVend, setErrorCostVend] = useState(false);
    const [errorRetailUnitPack, setErrorRetailUnitPack] = useState(false);
    const [errorLabelSize, setErrorLabelSize] = useState(false);
    const [errorLabelNumbers, setErrorLabelNumbers] = useState(false);
    const [errorRing, setErrorRing] = useState(false);
    const [errorHicone, setErrorHicone] = useState(false);
    const [errorTareCd, setErrorTareCd] = useState(false);
    const [errorSgnCount1, setErrorSgnCount1] = useState(false);
    const [errorSgnCount2, setErrorSgnCount2] = useState(false);
    const [errorSgnCount3, setErrorSgnCount3] = useState(false);
    const [errorFdStmp, setErrorFdStmp] = useState(false);
    const [errorPrcTypeCd, setErrorPrcTypeCd] = useState(false);

    const [rogDetails, setRogDetails] = useState([]);
    const [descDetails, setDescDetails] = useState([]);

    const resetError = useCallback(() => {
        setErrorDcPackDesc(false);
        setErrorDcSizeDsc(false);
        setErrorProdwght(false);
        setErrorHandlingCode(false);
        setErrorBuyerNum(false);
        setErrorRandomWtCd(false);
        setErrorSellByDays(false);
        setErrorUseByDays(false);
        setErrorPullBydays(false);
        setErrorAutoCostInv(false);
        setErrorBillingType(false);
        setErrorCostAllow(false);
        setErrorCostIb(false);
        setErrorCostInv(false);
        setErrorCostVend(false);
        setErrorRetailUnitPack(false);
        setErrorLabelSize(false);
        setErrorLabelNumbers(false);
        setErrorRing(false);
        setErrorHicone(false);
        setErrorTareCd(false);
        setErrorSgnCount1(false);
        setErrorSgnCount2(false);
        setErrorSgnCount3(false);
        setErrorFdStmp(false);
        setErrorProdwght(false)
        setErrorPrcTypeCd(false)
    }, [])

    const resetFields = useCallback(() => {
        setRetailUnitPack("");
        setHicone("");
        setRandomWtCd("");
        setBillingType("");
        setRing("");

    }, [data])

    useEffect(() => {
        resetError();
        resetFields();
        
        if (data && data.sizeDetails) {
            let descDetails = []
            for (let i = 0; i < data.sizeDetails.length; i++) {
                let sizd = data.sizeDetails[i].dstCntr + " - " + data.sizeDetails[i].dcPackDesc + " - " + data.sizeDetails[i].dcSizeDesc;
                descDetails.push(sizd)
                if (i === 0) {
                    setDcPackDesc(data.sizeDetails[i].dcPackDesc.toString());
                    setDcSizeDsc(data.sizeDetails[i].dcSizeDesc.toString());
                    setAutoCostInv(data.sizeDetails[i].autoCostInv)
                    setHandlingCode(data.handlingCode ? data.handlingCode : "I");
                    setBuyerNum(data.sizeDetails[i].buyerNum.toString());
                    setRandomWtCd(data.randomWtCd ? data.setRandomWtCd : "");
                    setSellByDays(data.sellByDays ? data.sellByDays : "");
                    setUseByDays(data.useByDays ? data.useByDays : "");
                    setPullBydays(data.pullBydays ? data.pullBydays : "");
                    setPrcTypeCd(data.sizeDetails[i].prcTypeCd)
                    setHandlingCode(data.sizeDetails[i].handlingCode.toString().replace(/^\s+|\s+$/gm, ''))
                    setBillingType(data.sizeDetails[i].billingType.toString());
                    setUseByDays(String(Number(data.sizeDetails[i].shelfLife) + 1))
                    setPullBydays(String(Number(data.sizeDetails[i].shelfLife)))
                    setSellByDays(String(Number(data.sizeDetails[i].shelfLife)))
                    setRandomWtCd(data.sizeDetails[i].randomWtCd.toString())
                    setCostAllow(data.sizeDetails[i].costAllow.toString().replace(/^\s+|\s+$/gm, ''))
                    setCostIb(data.sizeDetails[i].costIb.toString().replace(/^\s+|\s+$/gm, ''))
                    setCostInv(data.sizeDetails[i].costInv.toString().replace(/^\s+|\s+$/gm, ''))
                    setCostVend(data.sizeDetails[i].costVendor.toString().replace(/^\s+|\s+$/gm, ''))
                }
            }
            setDescDetails(descDetails);
        }
        if (data && data.rogDetail) {
            let rogDetails = []
            for (let j = 0; j < data.rogDetail.length; j++) {
                let rogd = data.rogDetail[j];
                let arrnaming = Object.keys(rogd);
                let val = rogd[arrnaming[0]].rog + " - " + rogd[arrnaming[0]].retailUnitPack + " - " + rogd[arrnaming[0]].ring + " - " + rogd[arrnaming[0]].hicone;
                rogDetails.push(val)
                if (rogd[arrnaming[0]].topRank == true) {
                    setHicone(rogd[arrnaming[0]].hicone.toString().replace(/^\s+|\s+$/gm, ''));
                    setRetailUnitPack(rogd[arrnaming[0]].retailUnitPack.toString().replace(/^\s+|\s+$/gm, ''));
                    setRing(rogd[arrnaming[0]].ring.toString().replace(/^\s+|\s+$/gm, ''));
                    setFdStmp(rogd[arrnaming[0]].foodStamp.toString().replace(/^\s+|\s+$/gm, ''));
                    setLabelNumbers(rogd[arrnaming[0]].tagNumber.toString().replace(/^\s+|\s+$/gm, ''));
                    setLabelSize(rogd[arrnaming[0]].tagSize.toString().replace(/^\s+|\s+$/gm, ''));
                    setTareCd(rogd[arrnaming[0]].tareCd.toString().replace(/^\s+|\s+$/gm, ''));
                    setSgnCount1(rogd[arrnaming[0]].sgnCount1[0].toString().replace(/^\s+|\s+$/gm, ''));
                    setSgnCount2(rogd[arrnaming[0]].sgnCount2.toString().replace(/^\s+|\s+$/gm, ''));
                    setSgnCount3(rogd[arrnaming[0]].sgnCount3.toString().replace(/^\s+|\s+$/gm, ''));
                }
            }
            console.log(rogDetails)
            setRogDetails(rogDetails)
        }
        if (data && data.sourceWieght) {
            for (let i = 0; i < data.sourceWieght.length; i++) {
                let wtd = data.sourceWieght[i].prodWt;
                if (i === 0) {
                    setProdwght(wtd.toString().replace(/^\s+|\s+$/gm, ''));
                }
            }
        }
    }, [data])

    const onClickSubmit = () => {
        let isValid = true;
        resetError();
        if (dcPackDesc.trim().length === 0) {
            setErrorDcPackDesc(true);
            isValid = false;
        }
        if (dcSizeDsc.trim().length === 0) {
            setErrorDcSizeDsc(true);
            isValid = false;
        }
        if (prodwght.trim().length === 0) {
            setErrorProdwght(true);
            isValid = false;
        }
        if (handlingCode.trim().length === 0) {
            setErrorHandlingCode(true);
            isValid = false;
        }
        if(autoCostInv.trim().length === 0) {
            setErrorAutoCostInv(true);
            isValid = false;
        }
        if (buyerNum.trim().length === 0) {
            setErrorHandlingCode(true);
            isValid = false;
        }
        // if (randomWtCd.length === 0) {
        //     setErrorRandomWtCd(true);
        //     isValid = false;
        // }
        // if (randomWtCd.length === 0) {
        //     setErrorRandomWtCd(true);
        //     isValid = false;
        // }
        if(buyerNum.trim().length === 0) {
            setErrorBuyerNum(true);
            isValid = false;
        }
        if (sellByDays.trim().length === 0) {
            setErrorSellByDays(true);
            isValid = false;
        }
        if (useByDays.trim().length === 0) {
            setErrorUseByDays(true);
            isValid = false;
        }
        if (pullBydays.trim().length === 0) {
            setErrorPullBydays(true);
            isValid = false;
        }
        if (costInv.trim().length === 0) {
            setErrorCostInv(true);
            isValid = false;
        }
        if (costAllow.trim().length === 0) {
            setErrorCostAllow(true);
            isValid = false;
        }
        if (costIb.trim().length === 0) {
            setErrorCostIb(true);
            isValid = false;
        }
        if (costVend.trim().length === 0) {
            setErrorCostVend(true);
            isValid = false;
        }
        if (retailUnitPack.trim().length === 0) {
            setErrorRetailUnitPack(true);
            isValid = false;
        }
        if (labelSize.trim().length === 0) {
            setErrorLabelSize(true);
            isValid = false;
        }
        if (labelNumbers.trim().length === 0) {
            setErrorLabelNumbers(true);
            isValid = false;
        }
        if (ring.trim().length === 0) {
            setErrorRing(true);
            isValid = false;
        }
        if (hicone.trim().length === 0) {
            setErrorHicone(true);
            isValid = false;
        }
        if (tareCd.trim().length === 0) {
            setErrorTareCd(true);
            isValid = false;
        }
        if (sgnCount1.trim().length === 0) {
            setErrorSgnCount1(true);
            isValid = false;
        }
        if (sgnCount2.trim().length === 0) {
            setErrorSgnCount2(true);
            isValid = false;
        }
        if (sgnCount3.trim().length === 0) {
            setErrorSgnCount3(true);
            isValid = false;
        }
        if (fdStmp.trim().length === 0) {
            setErrorFdStmp(true);
            isValid = false;
        }
        if (prcTypeCd.trim().length === 0) {
            setErrorPrcTypeCd(true);
            isValid = false;
        }
        if (isValid) {
            setEditChecked(false)
            props.onSubmit({
                dcPackDesc,
                dcSizeDsc,
                prodwght,
                handlingCode,
                buyerNum,
                randomWtCd,
                sellByDays,
                useByDays,
                pullBydays,
                autoCostInv,
                billingType,
                costAllow,
                costIb,
                costInv,
                costVend,
                retailUnitPack,
                labelSize,
                labelNumbers,
                ring,
                hicone,
                tareCd,
                sgnCount1,
                sgnCount2,
                sgnCount3,
                fdStmp,
            })
        }
    }

    const handleClose = useCallback(() => {
        setEditChecked(false);
        props.onClose()
    }, [props.onClose])

    const mappingContent = (

        <Grid container className={"bakeryMapContainer"}>
            <Grid container className="">
                <Grid item xs={6} className="">
                    <span className={"bakeryMapHeading"}>Add/Inherit Mapping</span>
                </Grid>
                <Grid item xs={6} className="" style={{ textAlign: "right" }}>
                    <CloseTwoTone style={{ cursor: "pointer", transform: "scale(0.6)" }} onClick={handleClose} />
                </Grid>
            </Grid>

            <Grid container className={"bakeryMapDesc"} style={{ display: "flex" }}>
                {
                    skuTitle && skuTitle.map((value, index) =>
                        <div className={"loadOnMapTxtDesc"} key={index}>{value}</div>
                    )
                }
                <div className={"loadOnMapTxtDescTwo"} style={{ marginLeft: "auto" }}>{cicBuyTitle}</div>
            </Grid>
            <Grid container className={"bakeryMapSubContainer"}>
                <Grid item xs={7} className="loadOnMapTxt" >
                    <label className={"loadEditTxt"}><input type="checkbox" name={"ENABLE_EDIT"} checked={isEditChecked} onChange={(e) => setEditChecked(e.target.checked)} /> Enable to edit</label>
                </Grid>
                <Grid item xs={5} style={{ display: "flex", width: "100%" }}  >
                    <RogDescDetails
                        list={descDetails}
                    />
                    <RogDescDetails
                        type="ROG"
                        list={rogDetails}
                    />
                </Grid>
            </Grid>
            <Grid container className={"bakeryMapInputontainer"}>

                <Grid item xs={4} className="bakeryMappingPadding">
                    <TextFieldMemi
                        value={dcPackDesc}
                        setTextValue={(value) => setDcPackDesc(value)}
                        label="Desc Pack : "
                        alignItems="columns"
                        LabelClass="mapLabel"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        placeholder=""
                        error={errorDcPackDesc}

                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding">
                    <TextFieldMemi
                        value={dcSizeDsc}
                        setTextValue={(value) => setDcSizeDsc(value)}
                        label="Desc Size : "
                        alignItems="columns"
                        LabelClass="mapLabel"
                        placeholder=""
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        error={errorDcSizeDsc}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding">
                    <TextFieldMemi
                        value={prodwght}
                        setTextValue={(value) => setProdwght(value)}
                        label="Prod Wt : "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorProdwght}
                    />
                </Grid>

                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={handlingCode}
                        setTextValue={(value) => setHandlingCode(value)}
                        label="Handling Code : "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorHandlingCode}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={buyerNum}
                        setTextValue={(value) => setBuyerNum(value)}
                        label="Buyer Num : "
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorBuyerNum}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <DropDownMemi
                        value={randomWtCd}
                        setValue={(value) => setRandomWtCd(value)}
                        label="Random Weight Code : "
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "R", value: "R" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        error={errorRandomWtCd}
                        inlineLabel=" "
                        disableNone={randomWtCd !== ""}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={sellByDays}
                        setTextValue={(value) => setSellByDays(value)}
                        label="Sell by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorSellByDays}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={useByDays}
                        setTextValue={(value) => setUseByDays(value)}
                        label="Use by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorUseByDays}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={pullBydays}
                        setTextValue={(value) => setPullBydays(value)}
                        label="Pull by Days :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorPullBydays}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding">
                    <DropDownMemi
                        value={autoCostInv}
                        setValue={(value) => setAutoCostInv(value)}
                        label="Auto Cost Inv :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "A", value: "A" }, { label: "C", value: "C" }, { label: "I", value: "I" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={false}
                        disabled={!isEditChecked}
                        error={errorAutoCostInv}
                        disableNone={autoCostInv !== ""}
                        inlineLabel=""
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <DropDownMemi
                        value={billingType}
                        setValue={(value) => setBillingType(value)}
                        label="Billing Type Cd :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "A", value: "A" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        error={errorBillingType}
                        inlineLabel=" "
                        disableNone={billingType!==""}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={costAllow}
                        setTextValue={(value) => setCostAllow(value)}
                        label="Cost Allow:"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorCostAllow}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={costIb}
                        setTextValue={(value) => setCostIb(value)}
                        label="Cost IB :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorCostIb}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={costInv}
                        setTextValue={(value) => setCostInv(value)}
                        label="Cost INV :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorCostInv}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={costVend}
                        setTextValue={(value) => setCostVend(value)}
                        label="Cost VEND :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorCostVend}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={retailUnitPack}
                        setTextValue={(value) => setRetailUnitPack(value)}
                        label="RUP :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorRetailUnitPack}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <DropDownMemi
                        value={labelSize}
                        setValue={(value) => setLabelSize(value)}
                        label="Tag Size :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "M", value: "M" }, { label: "N", value: "N" }, { label: "S", value: "S" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={false}
                        disabled={!isEditChecked}
                        error={errorLabelSize}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >

                    <DropDownMemi
                        value={labelNumbers}
                        setValue={(value) => setLabelNumbers(value)}
                        label="Tag Count :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={false}
                        disabled={!isEditChecked}
                        error={errorLabelNumbers}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <DropDownMemi
                        value={ring}
                        setValue={(value) => setRing(value)}
                        label="Ring :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }, { label: "2", value: "2" }, { label: "3", value: "3" }, { label: "4", value: "4" }, { label: "5", value: "5" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        error={errorRing}
                        inlineLabel=" "
                        disableNone={ring !== ""}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <DropDownMemi
                        value={hicone}
                        setValue={(value) => setHicone(value)}
                        label="Hicon :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }, { label: "2", value: "2" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        error={errorHicone}
                        inlineLabel=" "
                        disableNone={hicone !== ""}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={tareCd}
                        setTextValue={(value) => setTareCd(value)}
                        label="Tare :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorTareCd}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding">
                    <label className="mapLabel"> Sign Count : </label>
                    <div style={{ width: "100%", display: "flex" }}>
                        <TextFieldMemi
                            value={sgnCount1}
                            setTextValue={(value) => setSgnCount1(value)}
                            alignItems="column"
                            TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                            disabled={!isEditChecked}
                            LabelClass="mapItemsModalLabel"
                            placeholder=""
                            labelXs={1}
                            textFieldXs={11}
                            error={errorSgnCount1}
                        />
                        <TextFieldMemi
                            value={sgnCount2}
                            setTextValue={(value) => setSgnCount2(value)}
                            alignItems="column"
                            TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                            disabled={!isEditChecked}
                            LabelClass="mapItemsModalLabel"
                            placeholder=""
                            labelXs={1}
                            textFieldXs={11}
                            fullWidth={false}
                            error={errorSgnCount2}
                        />
                        <TextFieldMemi
                            value={sgnCount3}
                            setTextValue={(value) => setSgnCount3(value)}
                            alignItems="column"
                            TextFieldClass={`${isEditChecked ? 'lookMapFieldSignOutCls' : 'lookMapFieldSignOutCls bakeryMapFieldDisable'}`}
                            disabled={!isEditChecked}
                            LabelClass="mapItemsModalLabel"
                            placeholder=""
                            labelXs={1}
                            textFieldXs={11}
                            fullWidth={false}
                            error={errorSgnCount3}
                        />
                    </div>
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <DropDownMemi
                        value={fdStmp}
                        setValue={(value) => setFdStmp(value)}
                        label="Food Stamp :"
                        alignItems="columns"
                        DropDownClass={`${isEditChecked ? 'lookUpMenuDropdown dropDownCls mapItemsModal' : 'lookUpMenuDropdown dropDownCls bakeryMapFieldDropDownDisable'}`}
                        LabelClass="mapLabel"
                        options={[{ label: "0", value: "0" }, { label: "1", value: "1" }]}
                        fullWidth={true}
                        errorText=""
                        isLabelEmpty={true}
                        disabled={!isEditChecked}
                        error={errorFdStmp}
                        inlineLabel=" "
                        disableNone={fdStmp !== ""}
                    />
                </Grid>
                <Grid item xs={4} className="bakeryMappingPadding" >
                    <TextFieldMemi
                        value={prcTypeCd}
                        setTextValue={(value) => setPrcTypeCd(value)}
                        label="PRC Flag :"
                        alignItems="columns"
                        TextFieldClass={`${isEditChecked ? 'lookMapFieldCls' : 'lookMapFieldCls bakeryMapFieldDisable'}`}
                        disabled={!isEditChecked}
                        LabelClass="mapLabel"
                        placeholder=""
                        error={errorPrcTypeCd}
                    />
                </Grid>
            </Grid>
            <Grid container className={"bakeryMapDesc"} style={{ marginTop: "10px" }}>
                <Grid item xs={12} style={{ textAlign: "right" }}>
                    <ButtonMemi
                        classNameMemi="MultiUnitScreenSearchButton modalSubmitCls"
                        btnval="Submit"
                        onClick={onClickSubmit}
                    />
                </Grid>
            </Grid>
        </Grid >
    )

    return (
        <>
            <ModalPopup
                open={open}
                classNameMemi="bakeryMapModalCls mapItemsModalCls"
                popupContentClass="bakeryMapModalContent"
                popupActionClass=""
                maxWidth="md"

                popupContent={mappingContent}

            />
        </>

    )
}

export default memo(MapItemsModal)
