import React, { useState, useEffect, useContext, useCallback } from 'react'
import ButtonMemi from '../ButtonMemi/ButtonMemi';
import ApplicationContext from "../../context/ApplicationContext";
import { Info, Sort, Sync, Check, Close } from "@material-ui/icons";
import { Box, Popper, Grid, OutlinedInput } from '@material-ui/core';
import RadioMemi from "../RadioMemi/RadioMemi";

export default function FilterButtonMultiScreen(props) {
    const [anchorEl, setAnchorEl] = useState(null);
    const [deptData, setDeptData] = useState([]);
    const [whseData, setWhseData] = useState({ prodSourceCd: "WHSE", isChecked: false });
    const [dsdData, setDsdData] = useState({ prodSourceCd: "DSD", isChecked: false });
    const [pendingData, setPendingData] = useState({ prodSourceCd: "PENDING", isChecked: false });
    const [convertedData, setConvertedData] = useState({ prodSourceCd: "CONVERTED", isChecked: false });
    const [store1, setStore1] = useState("");
    const [store2, setStore2] = useState("");
    const [store3, setStore3] = useState("");
    const [store4, setStore4] = useState("");
    const [store5, setStore5] = useState("");
    const AppData = useContext(ApplicationContext);
    const { memi21_sourceItems, memi21_targetItems, multiUnitTargetFilter, multiUnitSrcFilter, multiUnitFilterDeptname, multiUnitFilterRetailSection } = AppData;
    const { isMultiTarget, isMultiSrc, MappingStatus, maxLength } = props;

    let open = Boolean(anchorEl);
    let id = open ? 'simple-popper' : undefined;

    const handleClick = (event) => {
        setAnchorEl(anchorEl ? null : event.currentTarget);
    };

    useEffect(() => {

        if (isMultiSrc) {

            setAnchorEl(null);
            setWhseData({ prodSourceCd: "WHSE", isChecked: false });
            setDsdData({ prodSourceCd: "DSD", isChecked: false });
            setPendingData({ prodSourceCd: "PENDING", isChecked: false });
            setConvertedData({ prodSourceCd: "CONVERTED", isChecked: false });
            setStore1("");
            setStore2("");
            setStore3("");
            setStore4("");
            setStore5("");

            const modifieDdeptName = deptData.map(deptName => {
                deptName.isChecked = false;
                return deptName;
            });

            setDeptData(modifieDdeptName);
            AppData.setMultiUnitSrcFilter(undefined);
        }

    }, [MappingStatus, memi21_sourceItems, isMultiSrc]);

    useEffect(() => {

        if (isMultiTarget) {

            setAnchorEl(null);
            setWhseData({ prodSourceCd: "WHSE", isChecked: false });
            setDsdData({ prodSourceCd: "DSD", isChecked: false });
            setPendingData({ prodSourceCd: "PENDING", isChecked: false });
            setConvertedData({ prodSourceCd: "CONVERTED", isChecked: false });
            setStore1("");
            setStore2("");
            setStore3("");
            setStore4("");
            setStore5("");

            const modifieDdeptName = deptData.map(deptName => {
                deptName.isChecked = false;
                return deptName;
            });

            setDeptData(modifieDdeptName);

            AppData.setMultiUnitTargetFilter(undefined);
        }

    }, [MappingStatus, memi21_targetItems, isMultiTarget]);

    useEffect(() => {
        setAnchorEl(null);

    }, [multiUnitSrcFilter, multiUnitTargetFilter])

    const onClickClearFilter = useCallback(() => {

        if (isMultiTarget) {

            setWhseData({ prodSourceCd: "WHSE", isChecked: false });
            setDsdData({ prodSourceCd: "DSD", isChecked: false });
            setPendingData({ prodSourceCd: "PENDING", isChecked: false });
            setConvertedData({ prodSourceCd: "CONVERTED", isChecked: false });
            setStore1("");
            setStore2("");
            setStore3("");
            setStore4("");
            setStore5("");

            const modifieDdeptName = deptData.map(deptName => {
                deptName.isChecked = false;
                return deptName;
            });

            setDeptData(modifieDdeptName);
            AppData.setMultiUnitTargetFilter(undefined);
        }
        if (isMultiSrc)    {
            setWhseData({ prodSourceCd: "WHSE", isChecked: false });
            setDsdData({ prodSourceCd: "DSD", isChecked: false });
            setPendingData({ prodSourceCd: "PENDING", isChecked: false });
            setConvertedData({ prodSourceCd: "CONVERTED", isChecked: false });
            setStore1("");
            setStore2("");
            setStore3("");
            setStore4("");
            setStore5("");

            const modifieDdeptName = deptData.map(deptName => {
                deptName.isChecked = false;
                return deptName;
            });

            setDeptData(modifieDdeptName);
            AppData.setMultiUnitSrcFilter(undefined);
        }
       
        
        setAnchorEl(null);
    }, [whseData, dsdData, pendingData, convertedData, store1, store2, store3, store4, store5, deptData, isMultiSrc, isMultiTarget])

    const onChangeCheckbox = useCallback((e) => {

        if (e.target.name === "DSD") {
            setDsdData({ ...dsdData, isChecked: e.target.checked })
        }

        if (e.target.name === "WHSE") {
            setWhseData({ ...whseData, isChecked: e.target.checked })
        }

        if (e.target.name === "CONVERTED") {
            setConvertedData({ ...convertedData, isChecked: e.target.checked })
        }

        if (e.target.name === "PENDING") {
            setPendingData({ ...pendingData, isChecked: e.target.checked })
        }

        const copyDeptName = [...deptData];
        const modifieDdeptName = copyDeptName.map(deptName => {
            if (e.target.name === deptName.deptName) {
                deptName.isChecked = !deptName.isChecked;
            }
            return deptName;
        });

        setDeptData(modifieDdeptName);

    }, [deptData, dsdData, whseData, pendingData, convertedData])

    useEffect(() => {
        if (multiUnitFilterDeptname && multiUnitFilterDeptname.length > 0 && isMultiSrc) {
            let deptArray = [];
            let unique = [... new Set(multiUnitFilterDeptname.map(item => item.deptName))];
            unique.map((value) => {
                deptArray.push({ deptName: value, isChecked: false })
            });
            setDeptData(deptArray);
        }

        if (multiUnitFilterRetailSection && multiUnitFilterRetailSection.length > 0 && isMultiTarget) {
            let deptArray = [];
            let unique = [... new Set(multiUnitFilterRetailSection.map(item => item.targetDepartment))];
            unique.map((value) => {
                deptArray.push({ deptName: value, isChecked: false })
            });
            setDeptData(deptArray);
        }

    }, [multiUnitFilterDeptname, multiUnitFilterRetailSection]);


    return (
        <div onMouseEnter={handleClick} onMouseLeave={handleClick}>
            <ButtonMemi
                btnval="Filter By"
                classNameMemi={props.ButtonClass}
                btnsize={props.btnsize}
               
            />
            <Popper id={id} open={open} anchorEl={anchorEl} className={props.sortByClass} style={{zIndex:"1500"}}>
                <Box>
                    <Grid container>
                        {MappingStatus !== "P" ?
                            <>
                                <Grid item xs={12} style={{ color: "blue", marginBottom: "10px" }}>
                                    Conversation Status
                                </Grid>
                                <Grid item xs={12}>
                                    <div style={{ marginBottom: "10px" }}>
                                        <div>
                                            <label><input type="checkbox" name={"PENDING"} checked={pendingData.isChecked} onChange={onChangeCheckbox} />Pending</label>
                                        </div>
                                        <div>
                                            <label><input type="checkbox" name={"CONVERTED"} checked={convertedData.isChecked} onChange={onChangeCheckbox} />Converted</label>
                                        </div>
                                    </div>
                                </Grid>
                            </> : ""}

                        <Grid item style={{ color: "blue", marginBottom: "10px" }} xs={12}>
                            {isMultiTarget ? "Retail Section" : "Department"}
                        </Grid>
                        <Grid item xs={12} style={{ marginBottom: "10px" }}>

                            {deptData && deptData.map((value) =>
                                <div>
                                    <div><label><input type="checkbox" name={value.deptName} checked={value.isChecked} onChange={onChangeCheckbox} />{value.deptName}</label></div>
                                </div>
                            )}

                        </Grid>
                        <Grid item xs={12} style={{ color: "blue", marginBottom: "10px" }}>
                            DSD/WHSE
                        </Grid>
                        <Grid item xs={12}>
                            <div style={{ marginBottom: "10px" }}>
                                <label><input type="checkbox" name={"DSD"} checked={dsdData.isChecked} onChange={onChangeCheckbox} />DSD</label>
                                <label><input type="checkbox" name={"WHSE"} checked={whseData.isChecked} onChange={onChangeCheckbox} />WHSE</label>
                            </div>
                        </Grid>

                        <Grid item xs={12} style={{ color: "blue", marginBottom: "10px" }}>
                            <div>
                                {isMultiTarget ? "SMIC" : "Product Hierarchy"}

                            </div>
                        </Grid>
                        <Grid item xs={12}>
                            <OutlinedInput
                                className="filterByTextFieldCls"
                                type="number"
                                value={store1}
                                inputProps={{ maxLength: maxLength }}
                                onChange={(e) => setStore1(e.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <OutlinedInput
                                className="filterByTextFieldCls"
                                type="number"
                                value={store2}
                                inputProps={{ maxLength: maxLength }}
                                onChange={(e) => setStore2(e.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <OutlinedInput
                                className="filterByTextFieldCls"
                                type="number"
                                value={store3}
                                inputProps={{ max: maxLength }}
                                onChange={(e) => setStore3(e.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <OutlinedInput
                                className={isMultiSrc ? "disableFilterByTextFieldCls" : "filterByTextFieldCls"}
                                type="number"
                                value={store4}
                                disabled={isMultiSrc ? true : false}
                                inputProps={{ maxLength: maxLength }}
                                onChange={(e) => setStore4(e.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <OutlinedInput
                                className={isMultiSrc ? "disableFilterByTextFieldCls" : "filterByTextFieldCls"}
                                type="number"
                                value={store5}
                                disabled={isMultiSrc ? true : false}
                                inputProps={{ maxLength: maxLength }}
                                onChange={(e) => setStore5(e.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12} style={{ marginTop: "10px", textAlign: "center" }} >
                            {/* <div style={{ marginBottom: "10px", color: "green", marginTop: "10px", textAlign: "center" }} onClick={() => props.onClick([...deptData, whseData, dsdData])}> */}
                            {/* const onClickApplyFilter = useCallback(() => { */}
                            <div style={{ textAlign: "center" }}>
                                <ButtonMemi
                                    btnval="Apply Filter"
                                    classNameMemi={"applyfilterCls"}
                                    btnsize={props.btnsize}
                                    onClick={() => props.onClick(deptData, whseData, dsdData, store1, store2, store3, store4, store5, pendingData, convertedData)}
                                />
                            </div>
                        </Grid>
                        <Grid item xs={12} style={{ marginBottom: "10px", textAlign: "center" }}>
                            <div style={{ textAlign: "center" }}>
                                <ButtonMemi
                                    btnval="Clear Filter"
                                    classNameMemi={"clearfilterCls"}
                                    btnsize={props.btnsize}
                                    onClick={onClickClearFilter}
                                />

                            </div>
                        </Grid>
                    </Grid>
                </Box>
            </Popper>
        </div >
    )

}
