import React, { useEffect, useContext, useState, useRef, useCallback } from "react";
import TableMemi from "components/TableMemi/TableMemi";
import NoRecordsDisplay from 'components/NoRecordsDisplay/NoRecordsDisplay';
import { Grid } from "@material-ui/core";
import { memiuServices } from "../../api/memiu/memiuService";
import ApplicationContext from "../../context/ApplicationContext";
import { useHistory } from 'react-router';
import {
  makeStyles,

} from "@material-ui/core/styles";
import "../../css/App.css";

const useStyles = makeStyles({
  root: {
    "& .super-app-theme--header": {
      backgroundColor: "rgba(255, 7, 0, 0.55)",
    },
  },
  divHeader: {
    backgroundColor: "#f9f1e1",
    height: "39px",
    display: "flex",
    alignItems: "center",
    padding: "2px",
    fontWeight: "bold",
    border: "1px solid #b0d2ec",
    fontSize:"15px"
  },
  elementOne: {
    width: "300px",
  },
  elementTwo: {
    width: "550px",
  },
  elementThree: {},
});

/*
 *  must make 'let customcolumns = null' if not using custom columns
 *  or don't pass customcolumns prop
 *  passing below an array with key/value hide:true allows for hiding a row
 */
//{ field: "image-a", headerName: "", width: "200" },

function DisplayerTable() {

  const classes = useStyles();
  const AppData = useContext(ApplicationContext);
  const { divisionId, companyId } = AppData;
  const [tableData, setTableData] = useState([]);
  const history = useHistory();

  let columns = [
    {
      field: "deptName",
      headerName: " ",
      sortable: false,
      width: 300,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      disableColumnSelector: false,
      disableColumnFilter: false,
      disableColumnMenu: false,
      renderCell: (params) => <span className={(params.row.id !== tableData.length - 1) ? "memi23DeptNameCls" : "memi23TotalCountCls"}>{params.row.deptName}</span>
    },
    {
      field: "totalWHSERecords",
      headerName: "WHSE",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      disableColumnSelector: false,
      disableColumnFilter: false,
      disableColumnMenu: false,
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span className={"storeItemsReportLinkClass"} onClick={() => unReviewed(params.row.totalWHSERecords, params, "unReview", "W")}>{params.row.totalWHSERecords}</span> : <span className={"displayerItemTotalClass"}>{params.row.totalWHSERecords}</span>

    },
    {
      field: "totalDSDRecords",
      headerName: "DSD",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span className={"storeItemsReportLinkClass"} onClick={() => unReviewed(params.row.totalDSDRecords, params, "unReview", "D")}>{params.row.totalDSDRecords}</span> : <span className={"displayerItemTotalClass"}>{params.row.totalDSDRecords}</span>
    },
    {
      field: "totalRecord",
      headerName: "Total",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span className={"storeItemsReportLinkClass"} onClick={() => unReviewed(params.row.totalRecord, params, "unReview", "A")}>{params.row.totalRecord}</span> : <span className={"displayerItemTotalClass"}>{params.row.totalRecord}</span>
    },
    {
      field: "unReviwExcelDownload",
      headerName: " ",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span onClick={() => displayerExcelDownload(params, "unReview")}><img className="imgLogoCls" src="/export_to_excel_icon.png" alt="" title={params.row.totalRecord > 0 ? "Export To Excel" : ""} style={{cursor:params.row.totalRecord > 0 ? "pointer" : "default"}}/></span> : ""
    },
    {
      field: " ",
      headerName: " ",
      sortable: false,
      width: 150,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
    },
    {
      field: "completedWHSEItmCnt",
      headerName: "WHSE",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span className={"storeItemsReportLinkClass"} onClick={() => unReviewed(params.row.completedWHSEItmCnt, params, "review", "W")}>{params.row.completedWHSEItmCnt}</span> : <span className={"displayerItemTotalClass"}>{params.row.completedWHSEItmCnt}</span>
    },
    {
      field: "completedDSDItmCnt",
      headerName: "DSD",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span className={"storeItemsReportLinkClass"} onClick={() => unReviewed(params.row.completedDSDItmCnt, params, "review", "D")}>{params.row.completedDSDItmCnt}</span> : <span className={"displayerItemTotalClass"}>{params.row.completedDSDItmCnt}</span>
    },
    {
      field: "completedItmCnt",
      headerName: "Total",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span className={"storeItemsReportLinkClass"} onClick={() => unReviewed(params.row.completedItmCnt, params, "review", "A")}>{params.row.completedItmCnt}</span> : <span className={"displayerItemTotalClass"}>{params.row.completedItmCnt}</span>
    },
    {
      field: "reviwExcelDownload",
      headerName: " ",
      sortable: false,
      width: 100,
      headerAlign: "left",
      headerClassName: "HeaderModelLikeMatchTable",
      renderCell: (params) => params.row.id !== tableData.length - 1 ? <span onClick={() => displayerExcelDownload(params, "review")}><img className="imgLogoCls" src="/export_to_excel_icon.png" alt="" title={params.row.completedDSDItmCnt ? "Export To Excel" : ""} style={{cursor:params.row.completedItmCnt > 0 ? "pointer" : "default"}}/></span> : ""
    },
  ];

  const displayerExcelDownload = useCallback((param, type) => {

    if (type === "unReview" && param.row.totalRecord > 0 || (type === "review" && param.row.completedItmCnt > 0)) {

      let data = {
        deptName: param.row.deptName,
        deptCode: param.row.deptCode,
        division: divisionId,
        company: companyId,
        type: type !== "review" ? "N" : "C"
      }

      memiuServices.getDisplayersDownloadExcel(data).then((res) => {
        const url = window.URL.createObjectURL(new Blob([res.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `DisplayItems_${param.row.deptName}.xlsx`);
        
        link.click();
      })
    }

  }, [divisionId, companyId])

  const unReviewed = useCallback((param, data, type, itemType) => {

    if (param > 0) {
      AppData.setMemi16Data({ ...data.row, type: type !== "review" ? "N" : "C", itemType })
      history.push('/MEMI16')
    }
    else
      AppData.setAlertBox(true, "No more item to view.")

  }, [companyId, divisionId])

  const customNoRowsOverlay = () => {
    return (
      <div className="customNoRows">
        <NoRecordsDisplay />
      </div>
    )
  }

  useEffect(() => {

    if (divisionId) {

      let data = {
        company: companyId,
        division: divisionId
      }

      memiuServices.getListDisplayerData(data).then((res) => {
        if (res.hasOwnProperty('data')) {
          let { data } = res;
          let totalUnReviewWhse = 0;
          let totalUnReviewDsd = 0;
          let totalUnReview = 0;
          let totalReviewWhse = 0;
          let totalReviewDsd = 0;
          let totalReview = 0;

          data.map((value) => {
            totalUnReviewWhse += value.totalWHSERecords;
            totalUnReviewDsd += value.totalDSDRecords;
            totalUnReview += value.totalRecord;
            totalReviewWhse += value.completedWHSEItmCnt;
            totalReviewDsd += value.completedDSDItmCnt;
            totalReview += value.completedItmCnt;
          });

          data.sort((a, b) => {
            let fa = a["deptName"].toLowerCase()
            let fb = b["deptName"].toLowerCase()
            if (fa < fb) {
              return -1;
            }
            if (fa > fb) {
              return 1;
            }
            return 0;
          })

          if (data.length > 0) {

            data.push({ deptName: "Total", totalWHSERecords: totalUnReviewWhse, totalDSDRecords: totalUnReviewDsd, totalRecord: totalUnReview, completedWHSEItmCnt: totalReviewWhse, completedDSDItmCnt: totalReviewDsd, completedItmCnt: totalReview });
          }

          let tableArray = data.map((value, index) => {
            return {
              ...value, id: index, unReviwExcelDownload: true, reviwExcelDownload: true
            };
          });

          setTableData(tableArray)
        }
      }).catch((error) => {
        AppData.setAlertBox(true, "An Exception occurred while retrieving the data.");
      });
    }
  }, [companyId, divisionId]);

  return (
    <Grid container >
      <Grid item xs={12} >
        <div className={classes.divHeader}>
          <div className={classes.elementOne}>Departments</div>
          <div className={classes.elementTwo}>
            Displayer - Un-reviewed Items
          </div>
          <div>Displayer - Reviewed Items</div>
        </div>
      </Grid>

      <Grid item xs={12} style={{ height: "100%" }}>
        <TableMemi
          autoHeight
          columns={columns}
          hideFooter
          hideFooterPagination
          NoRowsOverlay={customNoRowsOverlay}
          classnameMemi="ModelLikeMatchTable"
          data={tableData}
          disableColumnMenu
          disableColumnFilter
          rowheight={22}
        />
      </Grid>
    </Grid>

  );
}

export default DisplayerTable;