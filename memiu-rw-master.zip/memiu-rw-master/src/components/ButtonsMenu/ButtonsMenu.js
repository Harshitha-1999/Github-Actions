import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import {
  Button,
  ButtonGroup,
  InputLabel,
  MenuItem,
  Select,
  FormControl,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  menuBtn: {
    color: "#fff",
    backgroundColor: "green",
    boxShadow: "-3px 3px #4caf50, -2px 2px #4caf50, -1px 1px #4caf50",
    border: "1px solid #4caf50",
    "&:hover": {
      background: "#d32f2f",
    },
    padding: "10px 35px 10px 35px",
    cursor: "pointer",
  },
  linkItem: {
    textDecoration: "none",
  },
  formcontrol: {
    minWidth: 120,
  },
}));

function ButtonsMenu() {
  const classes = useStyles();
  const history = useHistory();
  const [dept, setDept] = useState("");

  const goHome = () => {
    history.push("/");
  };
  const handleChange = (e) => {
    setDept(e.target.value);
  };

  return (
    <ButtonGroup
      variant="contained"
      color="primary"
      aria-label="contained primary button group"
    >
      <Button onClick={goHome} className={classes.menuBtn}>
        Files
      </Button>
      <Button onClick={goHome} className={classes.menuBtn}>
        Edit
      </Button>
      <Button onClick={goHome} className={classes.menuBtn}>
        Tools
      </Button>
      <Button onClick={goHome} className={classes.menuBtn}>
        Help
      </Button>
      <FormControl variant="outlined" className={classes.formcontrol}>
        <InputLabel>dept</InputLabel>
        <Select
          name="dept"
          value={dept}
          onChange={handleChange}
          defaultValue="dept"
        >
          <MenuItem value={"office"}>office</MenuItem>
          <MenuItem value={"grocery"}>grocery</MenuItem>
        </Select>
      </FormControl>
    </ButtonGroup>
  );
}

export default ButtonsMenu;
