import React, { useState, useContext } from 'react'
import { Grid } from '@material-ui/core'
import DropDownMemi from 'components/DropDownMemi/DropDownMemi'
import TextFieldMemi from 'components/TextField/TextFieldMemi'
import ButtonMemi from 'components/ButtonMemi/ButtonMemi'
import ApplicationContext from "../../context/ApplicationContext";
import {useHistory} from 'react-router-dom';
import {memiuServices} from '../../api/memiu/memiuService'
import {RouteBase} from '../../routes/constants/RouteBase'
export default function SearchBarSkuUpc(props) {
    const [type, setType] = useState("");
    const [search, setSearch] = useState("");

    const history = useHistory();
    const AppData = useContext(ApplicationContext);
    const handleSearch = () => {
        if (AppData.divisionId === "" || AppData.companyId === "") {
            AppData.setAlertBox(true, "Please select company and division")
        } else if (type === "") {
            AppData.setAlertBox(true, "Please select Product SKU or Source UPC.")
        }
        else if (search.trim().length === 0) {
            AppData.setAlertBox(true, "Please enter a valid Product SKU or Source UPC.")
        }
        else if (type === "updateoverridesourceupc" && (search.length !== 12 || search.match(/[^0-9]/))) {
            AppData.setAlertBox(true, "Invalid Source UPC.")
        }
        else {
            if (type === "updateoverrideproductsku") {
                memiuServices.getUpdateOverideManualSearch(AppData.companyId, AppData.divisionId, search)
                    .then((response) => {
                        if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
                            memiuServices.getAugmentationEditData(AppData.companyId, AppData.divisionId, search)
                                .then((response) => {
                                    if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
                                        AppData.setAlertBox(true, "Item details are empty for this Product SKU.");
                                        return;
                                    }
                                    AppData.setAugmentationServiceDepartment("")
                                    AppData.setAugmentationServiceKey("")
                                    AppData.setMemi18({updateaugmentationsku:[]})
                                    AppData.setMemi18({ UpdateAugmentationManualSearch: response.data })
                                    history.push({
                                        pathname: RouteBase.MEMI18,
                                        state: { disableDefaultNeedReview: true }
                                    })
                                })
                                .catch((err) => {
                                })
                        }
                        else {
                            AppData.setOverideServiceKey("")
                            AppData.setMemi14({updateoverridesku: []})
                            AppData.setMemi14({ UpdateOverrideManualSearch: response.data })
                            history.push(RouteBase.MEMI14)
                        }
                    })
                    .catch((err) => {
                    })
            }

            if (type === "updateoverridesourceupc") {
                memiuServices.getUpdateOverideManualSearchByUpc(AppData.companyId, AppData.divisionId, search)
                    .then((response) => {
                        if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
                            memiuServices.getAugmentationEditDataByUpc(AppData.companyId, AppData.divisionId, search)
                                .then((response) => {
                                    if (response.data.uiEceptionSrcDto == null && response.data.newItemDto == null) {
                                        AppData.setAlertBox(true, "Item details are empty for this Product UPC.");
                                        return;
                                    }
                                    AppData.setAugmentationServiceDepartment("")
                                    AppData.setAugmentationServiceKey("")
                                    AppData.setMemi18({updateaugmentationsku:[]})
                                    AppData.setMemi18({ UpdateAugmentationManualSearch: response.data })
                                    history.push({
                                        pathname: RouteBase.MEMI18,
                                        state: { disableDefaultNeedReview: true }
                                    })
                                })
                                .catch((err) => {
                                })
                        }
                        else {
                            AppData.setOverideServiceKey("")
                            AppData.setMemi14({updateoverridesku: []})
                            AppData.setMemi14({ UpdateOverrideManualSearch: response.data })
                            history.push(RouteBase.MEMI14)
                        }
                    })
                    .catch((err) => {
                    })
            }


        }
    }
    return (
        <Grid item xs={12} className="SearchBarSkuUpc">
            <div>
                <div>
                    <DropDownMemi
                        options={[
                            { label: "Product SKU", value: "updateoverrideproductsku" },
                            { label: "Product UPC", value: "updateoverridesourceupc" },
                        ]}
                        label="-Select-"
                        alignItems="inline"
                        classNameMemi="SearchBarSkuUpcDropwdownButton"
                        value={type}
                        setValue={(value) => setType(value)}
                    // value={criteriaP}
                    // setValue={(value) => setCriteriaP(value)}
                    />
                </div>
                <div>
                    <TextFieldMemi
                        alignItems="column"
                        TextFieldClass="searchBarSkuUpcTextField"
                        value={search}
                        setTextValue={(value) => setSearch(value)}
                    />
                </div>
                <ButtonMemi
                    classNameMemi="searchBarSkuUpcButton"
                    btnval="Search Item"
                    onClick={handleSearch}
                />
            </div>
        </Grid>
    )
}
