import React from "react";
import PropTypes from "prop-types";
import TextareaAutosize from "@material-ui/core/TextareaAutosize";
import { Grid } from "@material-ui/core";

function TextAreaAutosizeMemi(props) {

  const onChangeText = (text) => {
    props.setTextValue(text);
  };

  return (
    <Grid container>
      <Grid item xs={props.alignItems === "row" ? (props.labelXs ? props.labelXs : 5) : 12}>
        <label className={props.LabelClass}>{props.label}</label>
      </Grid>
      <Grid item xs={props.alignItems === "row" ? (props.textFieldXs ? props.textFieldXs : 7) : 12}>
        <TextareaAutosize
          className={props.classNameMemi}
          minRows={props.minrow}
          maxRows={props.maxrow}
          value={props.value}
          onChange={(e) => onChangeText(e.target.value)}
          disabled={props.disabled}
          fullWidth={props.fullWidth}
        />
      </Grid>
    </Grid>
  );
}

export default TextAreaAutosizeMemi;

TextAreaAutosizeMemi.propTypes = {
  minRows: PropTypes.string || PropTypes.number,
  maxRows: PropTypes.string || PropTypes.number,
  value: PropTypes.string || PropTypes.number,
  error: PropTypes.bool,
  disabled: PropTypes.bool,
  classNameMemi: PropTypes.string,
  setTextValue: PropTypes.string,
  LabelClass: PropTypes.string,
  label: PropTypes.string || PropTypes.object,
  alignItems: PropTypes.string
};