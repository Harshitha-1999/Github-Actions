import { authTokenCookie } from 'utils';

export function isNumber(num) {

  if (parseInt(num).toString() === num) {
    return true;
  }
  return false;
}

export function validateCicUpcStore(label, value, min, setError, errorList) {
  setError(false)
  if (value === "") {
    return
  }
  if (!isNumber(value)) {
    errorList.push(`${label} must be numeric.`);
    setError(true)
  }
  else if (value.length < min) {
    errorList.push(`${label} should be minimum ${min} digits.`)
    setError(true);
  }
}

export function generateUserLevel() {

  const { adGroups } = authTokenCookie()
  let userLevel = "";
  let userLevelAmount = 0
  for (let i = 0; i < adGroups.length; i++) {

    if (adGroups[i] === "id.meup.admin") {
      userLevel = "meup-admin"
      userLevelAmount = 10

    }

    else if (adGroups[i] === "id.meup.all" && userLevelAmount < 5) {
      userLevel = "meup-standard"
      userLevelAmount = 5;

    }

    else if (adGroups[i] === "id.meup.schematicmgr" && userLevelAmount < 1) {
      userLevel = "meup-holduser";
      userLevelAmount = 1;

    }

  }
  return userLevel
}