import React, { useEffect, useContext, useCallback } from "react";
import { useHistory } from "react-router-dom";
import { Button } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import routes from "../../routes/routes";
import { useLocation } from "react-router";
import ButtonLogout from "components/ButtonLogout/ButtonLogout";
import { MEMIMenu } from 'components/MenuData/MenuData';
import DropdownMenuMemiu from 'components/DropdownMenuMemiu/DropdownMenuMemiu';
import DropDownMemi from "components/DropDownMemi/DropDownMemi";
import ApplicationContext from "../../context/ApplicationContext";
// import {apiUrl} from "../../service/apiUrls"
// import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
import { arrayEquals } from "utils";
import { memiuServices } from "api/memiu/memiuService";
export default function NavigationBarMemi() {

  const AppData = useContext(ApplicationContext);
  const classes = useStyles();
  const history = useHistory();
  const location = useLocation();
  const { companyId, setDivisionId } = AppData

  function changeRoute(path) {
    history.push(path);
  };

  useEffect(() => {
    memiuServices.getCompanies()
      .then((res) => {
        const companiesData = res.data.map((data) => {
          return { label: data.companyLglNm, value: data.companyID }
        })
        AppData.setCompanies(companiesData);
      })
      .catch((error) => {
        AppData.setCompanies([]);

      })
  }, [])

  const onChangeCompany = useCallback((value) => {

    AppData.setDivisionId("")
    AppData.setCompanyId(value)

    memiuServices.getDivisions(value)
      .then((res) => {

        const divisionData = res.data.map((data) => {
          return { value: data.divisionID, label: data.divisionNm }
        })


        if (!arrayEquals(AppData.divisions, divisionData)) {
          AppData.setDivisionId("");
        }

        AppData.setDivisions(divisionData);
      })
      .catch((error) => {
      })

  }, [AppData.companyId])
  const getRouteButtonJsx = (props) => {
    // only show navigationBar=true
    var resultsRoutes = routes.filter((item) => item.navigationBar === "yes")
    return (resultsRoutes.map((detail) => {
      var buttonlabel = detail.label ? detail.label : detail.path.replace('/', '')
      return <Button onClick={() => changeRoute(detail.path)} className={location.pathname === detail.path ? classes.menuBtnActive : classes.menuBtn} size="small">
        {buttonlabel}
      </Button>
    }))
  }

  return (
    <div
      className={classes.navigationBar}
    >
      {getRouteButtonJsx()}
      <DropdownMenuMemiu label="Mapping" menuData={MEMIMenu} buttonClass={classes.menuBtn} />

      <div style={{ display: "flex", flexDirection: "row", alignItems: "center", marginLeft: "auto" }}>
        <DropDownMemi
          alignItems="inline"
          label="-Select Company-"
          options={AppData.companies}
          value={AppData.companyId}
          setValue={onChangeCompany}
          DropDownClass="dropdownNavigationMemi"
        />
        <DropDownMemi
          alignItems="inline"
          label="-Select Division-"
          options={AppData.divisions}
          value={AppData.divisionId}
          setValue={(value) => AppData.setDivisionId(value)}
          DropDownClass="dropdownNavigationMemi"
        />

      </div>
      <ButtonLogout classNameMemi={classes.menuBtn} size="small" />


    </div>
  );
}

const useStyles = makeStyles((theme) => ({
  menuBtn: {
    color: "#fff !important",
    backgroundColor: "#3196d3",
    // boxShadow: "-3px 3px, -2px 2px, -1px 1px",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    // border: "1px solid #4caf50",
    "&:hover": {
      backgroundColor: "#63b4e4",
      color: "#d6ebfb",
    },
    padding: "13px 13px",
    cursor: "pointer",
    borderRadius: "0px !important",
    textTransform: "none !important",
    whiteSpace: "noWrap",
    width: "fit-content",
  },
  navigationBar: {
    backgroundColor: "#3196d3",
    width: "100%",
    display: "flex",
    height: "46.6px",
    marginBottom: "10px",
    paddingTop: "1px",
    paddingBottom: "1px",

  },
  menuBtnActive: {
    color: "#2e7fb1",
    background: "#d6ebfb",
    borderRadius: "0px !important",
    boxShadow: "0 0px 0px 0 rgb(0 0 0 / 10%), 0 0px 20px 0 rgb(0 0 0 / 10%)",
    "&:hover": {
      background: "#d6ebfb",
    },
    padding: "14px 14px",
    cursor: "pointer",
    textTransform: "none",
    whiteSpace: "noWrap",
    // width: "fit-content"

  },
  linkItem: {
    textDecoration: "none",
  },
  formcontrol: {
    display: "flex",
    flexDirection: "row"
  },
}));
