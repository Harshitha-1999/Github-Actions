import React from 'react';
import { Grid } from '@material-ui/core';

export default function NoRecordsDisplay(props) {
  return (
    <Grid container className={props.classNameMemi}>
      <Grid item xs={12}>
        No records to display.
      </Grid>
    </Grid>
  )
}
