import { UPDATE_HELP, FETCH_HELP_CONTENT } from './actions';
import {
  handleStateLifecycle,
  createAxiosAsyncDispatcher
} from 'middleware/asyncDispatcher';


export const helpInitialState = {
  helpOptions: {
    isOpen: false,
    contents: null,
    message: null,
    scope: null,
  },
};


export const helpReducer = (
  state = helpInitialState,
  action
) => {
  if (action.type === UPDATE_HELP) {
    return {
      ...state,
      helpOptions: action.payload,
    };
  }
  else {
    return state;
  }
};

export const HelpScreenContentDispatcher = createAxiosAsyncDispatcher((state, action) => {
  if (action.type === FETCH_HELP_CONTENT) {
    return handleStateLifecycle(state, action);
  }
  else {
    return state;
  }
});

export default helpReducer;


