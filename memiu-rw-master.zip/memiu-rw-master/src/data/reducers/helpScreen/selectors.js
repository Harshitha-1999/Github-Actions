import { createSelector } from 'reselect';

export const getHelpState = (state) =>
  state.help;

export const getHelpOptions = createSelector(
  [getHelpState],
  (helpState) => {
    return helpState.helpOptions;
  }
);

export const getHelpScreenContentState = (
  state
) => state.HelpScreenContent;

export const getHelpScreenContentLoading = createSelector(
  [getHelpScreenContentState],
  (HelpScreenContent) => {
    return HelpScreenContent.loading;
  }
);

export const getHelpScreenContentError = createSelector(
  [getHelpScreenContentState],
  (HelpScreenContent) => {
    return HelpScreenContent.error;
  }
);

export const getHelpScreenContentResponse = createSelector(
  [getHelpScreenContentState],
  (HelpScreenContent) => {
    return HelpScreenContent.response;
  }
);

export const getHelpScreenContentData = createSelector(
  [getHelpScreenContentResponse],
  (HelpScreenContent) => {
    return HelpScreenContent && HelpScreenContent.data;
  }
);
