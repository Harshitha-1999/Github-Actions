import { HelpScreenService } from "api/helpScreen";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const SET_HELP_KEYWORD = 'help/SET_HELP_KEYWORD';
export const UPDATE_HELP = 'help/UPDATE_HELP';
export const FETCH_HELP_CONTENT = 'help/FETCH_HELP_CONTENT';


const updateHelpAction = (helpOptions) => ({
  type: UPDATE_HELP,
  payload: helpOptions,
});


export const updateHelp = (helpOptions) => (
  dispatch
) => {
  dispatch(updateHelpAction(helpOptions));
};

export const getHelpContent = (programName) =>
  createAxiosAction({
    type: FETCH_HELP_CONTENT,
    promise: HelpScreenService.getHelpContent(programName),
  });
