import { FieldDetailsService } from "api/fieldDetails";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_FIELD_DETAILS = 'security/FETCH_FIELD_DETAILS';

export const getFieldDetails = () =>
    createAxiosAction({
        type: FETCH_FIELD_DETAILS,
        promise: FieldDetailsService.getFieldDetails()
    });