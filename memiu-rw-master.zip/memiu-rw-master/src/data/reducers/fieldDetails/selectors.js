import { createSelector } from 'reselect';

export const getFieldDetailsState = (
  state
) => state.FieldDetails;

export const getFieldDetailsLoading = createSelector(
  [getFieldDetailsState],
  (FieldDetails) => {
    return FieldDetails.loading;
  }
);

export const getFieldDetailsError = createSelector(
  [getFieldDetailsState],
  (FieldDetails) => {
    return FieldDetails.error;
  }
);

export const getFieldDetailsResponse = createSelector(
  [getFieldDetailsState],
  (FieldDetails) => {
    return FieldDetails.response;
  }
);

export const getFieldDetailsData = createSelector(
  [getFieldDetailsResponse],
  (FieldDetails) => {
    return FieldDetails && FieldDetails.data;
  }
);