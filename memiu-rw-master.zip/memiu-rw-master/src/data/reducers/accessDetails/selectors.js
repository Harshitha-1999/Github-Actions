import { createSelector } from 'reselect';

export const getAccessDetailsState = (
  state
) => state.AccessDetails;

export const getAccessDetailsLoading = createSelector(
  [getAccessDetailsState],
  (AccessDetails) => {
    return AccessDetails.loading;
  }
);

export const getAccessDetailsError = createSelector(
  [getAccessDetailsState],
  (AccessDetails) => {
    return AccessDetails.error;
  }
);

export const getAccessDetailsResponse = createSelector(
  [getAccessDetailsState],
  (AccessDetails) => {
    return AccessDetails.response;
  }
);

export const getAccessDetailsData = createSelector(
  [getAccessDetailsResponse],
  (AccessDetails) => {
    return AccessDetails && AccessDetails.data;
  }
);