import { createSelector } from 'reselect';

export const getISC020State = (
  state
) => state.ISC020;

export const getISC020Loading = createSelector(
  [getISC020State],
  (ISC020) => {
    return ISC020.loading;
  }
);

export const getISC020Error = createSelector(
  [getISC020State],
  (ISC020) => {
    return ISC020.error;
  }
);

export const getISC020Response = createSelector(
  [getISC020State],
  (ISC020) => {
    return ISC020.response;
  }
);

export const getISC020Data = createSelector(
  [getISC020Response],
  (ISC020) => {
    return ISC020 && ISC020.data;
  }
);