import {
  handleStateLifecycle,
  createAxiosAsyncDispatcher
} from 'middleware/asyncDispatcher';

import { FETCH_ISC020 } from './actions';

const ISC020Dispatcher = createAxiosAsyncDispatcher((state, action) => {
  switch (action.type) {
    case FETCH_ISC020:
      return handleStateLifecycle(state, action);
    default:
      return state;
  }
});

export default ISC020Dispatcher;


