import { ISC020AService } from "api/ISC/ISC020";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_ISC020 = 'isc/FETCH_ISC020';

export const getISC020AOnLoad = () =>
    createAxiosAction({
        type: FETCH_ISC020,
        promise: ISC020AService.getISC020AOnLoad()
    });


export const getISC020AOnTransaction = (countryCode, corporation, division, operationFacility, foPromptQuantity) =>
    createAxiosAction({
        type: FETCH_ISC020,
        promise: ISC020AService.getISC020AOnTransaction(countryCode, corporation, division, operationFacility, foPromptQuantity),

    });

export const getISC020AOnDelete = (userDefaultsId) =>
    createAxiosAction({
        type: FETCH_ISC020,
        promise: ISC020AService.getISC020Delete(userDefaultsId),

    });