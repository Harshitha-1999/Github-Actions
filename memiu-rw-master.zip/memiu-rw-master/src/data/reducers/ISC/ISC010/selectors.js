import { createSelector } from 'reselect';

export const getISC010State = (
  state
) => state.ISC010;

export const getISC010Loading = createSelector(
  [getISC010State],
  (ISC010) => {
    return ISC010.loading;
  }
);

export const getISC010Error = createSelector(
  [getISC010State],
  (ISC010) => {
    return ISC010.error;
  }
);

export const getISC010Response = createSelector(
  [getISC010State],
  (ISC010) => {
    return ISC010.response;
  }
);

export const getISC010Data = createSelector(
  [getISC010Response],
  (ISC010) => {
    return ISC010 && ISC010.data;
  }
);