import { ISC010Service } from "api/ISC/ISC010";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_ISC010 = 'isc/FETCH_ISC010';

export const getISC010OnLoad = () =>
    createAxiosAction({
        type: FETCH_ISC010,
        promise: ISC010Service.getISC010OnLoad()
    });
