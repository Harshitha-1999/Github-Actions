import {
  handleStateLifecycle,
  createAxiosAsyncDispatcher
} from 'middleware/asyncDispatcher';

import { FETCH_ISC010 } from './actions';

const ISC010Dispatcher = createAxiosAsyncDispatcher((state, action) => {
  switch (action.type) {
    case FETCH_ISC010:
      return handleStateLifecycle(state, action);
    default:
      return state;
  }
});

export default ISC010Dispatcher;
