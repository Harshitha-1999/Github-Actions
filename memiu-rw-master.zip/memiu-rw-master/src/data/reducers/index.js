import { combineReducers } from "redux";
import pspixReducer, { pspixInitialState } from './PSPIX';
import { helpReducer, HelpScreenContentDispatcher, helpInitialState } from './helpScreen';
import AccessDetailsDispatcher from './accessDetails';
import FieldDetailsDispatcher from './fieldDetails';
import transactionReducer, { transactionInitialState } from './transaction';
import ISC010Dispatcher from './ISC/ISC010';
import ISC020Dispatcher from './ISC/ISC020';
import PSC720Dispatcher from './PSC/PSC720';
import PSC710Dispatcher from './PSC/PSC710';
import PSC730Dispatcher from './PSC/PSC730';
import PSC700Dispatcher from './PSC/PSC700';


export const initialRootState = {
  help: helpInitialState,
  pspix: pspixInitialState,
  HelpScreenContent: HelpScreenContentDispatcher.initialState,
  AccessDetails: AccessDetailsDispatcher.initialState,
  FieldDetails: FieldDetailsDispatcher.initialState,
  PSC720: PSC720Dispatcher.initialState,
  PSC710: PSC710Dispatcher.initialState,
  PSC730: PSC730Dispatcher.initialState,
  PSC700: PSC700Dispatcher.initialState,
  transaction: transactionInitialState
};

const rootReducer = combineReducers({
  help: helpReducer,
  pspix: pspixReducer,
  HelpScreenContent: HelpScreenContentDispatcher.reducer,
  AccessDetails: AccessDetailsDispatcher.reducer,
  FieldDetails: FieldDetailsDispatcher.reducer,
  transaction: transactionReducer,
  PSC720: PSC720Dispatcher.reducer,
  ISC020: ISC020Dispatcher.reducer,
  ISC010: ISC010Dispatcher.reducer,
  PSC710: PSC710Dispatcher.reducer,
  PSC730: PSC730Dispatcher.reducer,
  PSC700: PSC700Dispatcher.reducer,
});

export default rootReducer;
