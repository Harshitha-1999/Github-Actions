import { PSC700Service } from "api/PSC/PSC700";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_PSC700 = 'foc/FETCH_PSC700';

export const getPSC700AOnLoad = () =>
    createAxiosAction({
        type: FETCH_PSC700,
        promise: PSC700Service.getPSC700AOnLoad(),
    });
export const getPSC700ATransaction = (refCorpvalue, refDivValue, refFacValue, stoItemScan2, sectType) =>
    createAxiosAction({
        type: FETCH_PSC700,
        promise: PSC700Service.getPSC700AOnTransaction(refCorpvalue, refDivValue, refFacValue, stoItemScan2, sectType),
    });




