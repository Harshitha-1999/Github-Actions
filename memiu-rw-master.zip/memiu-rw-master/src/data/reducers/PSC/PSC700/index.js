import {
  handleStateLifecycle,
  createAxiosAsyncDispatcher
} from 'middleware/asyncDispatcher';

import { FETCH_PSC700 } from './actions';

const PSC700Dispatcher = createAxiosAsyncDispatcher((state, action) => {
  switch (action.type) {
    case FETCH_PSC700:
      return handleStateLifecycle(state, action);
    default:
      return state;
  }
});

export default PSC700Dispatcher;
