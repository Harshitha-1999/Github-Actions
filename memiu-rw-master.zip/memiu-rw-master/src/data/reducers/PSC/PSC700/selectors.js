import { createSelector } from 'reselect';

export const getPSC700State = (
  state
) => state.PSC700;

export const getPSC700Loading = createSelector(
  [getPSC700State],
  (PSC700) => {
    return PSC700.loading;
  }
);

export const getPSC700Error = createSelector(
  [getPSC700State],
  (PSC700) => {
    return PSC700.error;
  }
);

export const getPSC700Response = createSelector(
  [getPSC700State],
  (PSC700) => {
    return PSC700.response;
  }
);

export const getPSC700Data = createSelector(
  [getPSC700Response],
  (PSC700) => {
    return PSC700 && PSC700.data;
  }
);