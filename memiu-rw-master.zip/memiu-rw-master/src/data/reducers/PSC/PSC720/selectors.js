import { createSelector } from 'reselect';

export const getPSC720State = (
  state
) => state.PSC720;

export const getPSC720Loading = createSelector(
  [getPSC720State],
  (PSC720) => {
    return PSC720.loading;
  }
);

export const getPSC720Error = createSelector(
  [getPSC720State],
  (PSC720) => {
    return PSC720.error;
  }
);

export const getPSC720Response = createSelector(
  [getPSC720State],
  (PSC720) => {
    return PSC720.response;
  }
);

export const getPSC720Data = createSelector(
  [getPSC720Response],
  (PSC720) => {
    return PSC720 && PSC720.data;
  }
);