import { PSC720Service } from "api/PSC/PSC720";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_PSC720 = 'foc/FETCH_PSC720';

export const getPSC720OnLoad = (requestParams) =>
    createAxiosAction({
        type: FETCH_PSC720,
        promise: PSC720Service.getPSC720OnLoad(requestParams),
    });

// export const getPSC720OnTransaction = () =>
// createAxiosAction({
//     type: FETCH_PSC720,
//     promise: PSC720Service.getPSC720OnTransaction(),
// });
