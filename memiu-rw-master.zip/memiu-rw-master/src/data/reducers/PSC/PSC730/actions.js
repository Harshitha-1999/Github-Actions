import { PSC730Service } from "api/PSC/PSC730";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_PSC730 = 'foc/FETCH_PSC730';

// export const getPSC730OnLoad = (pluStrt,pluEnd,rog,corp,div,fac,currentDate) =>
// createAxiosAction({
//     type: FETCH_PSC730,
//     promise: PSC730Service.getPSC730OnLoad(pluStrt,pluEnd,rog,corp,div,fac,currentDate),
// });
export const getPSC730OnLoad = (psc710ValuesTo730) =>
    createAxiosAction({
        type: FETCH_PSC730,
        promise: PSC730Service.getPSC730OnLoad(psc710ValuesTo730),
    });

export const getPSC730ItemMovementOnload = (itemMovementRequest) =>
    createAxiosAction({
        type: FETCH_PSC730,
        promise: PSC730Service.getPSC730ItemMovementOnload(itemMovementRequest),
    });

export const getPSC730WareHouseOnload = (wareHouseRequest, page) =>
    createAxiosAction({
        type: FETCH_PSC730,
        promise: PSC730Service.getPSC730WareHouseOnload(wareHouseRequest, page),
    });

export const getPSC730PricingOnload = (pricingRequest) =>
    createAxiosAction({
        type: FETCH_PSC730,
        promise: PSC730Service.getPSC730PricingOnload(pricingRequest),
    });

export const getPSC730PricingOnTransaction = (pricingRequest, ib_cost, prx_both_whs_dsd_sw, currentPriceRequest) =>
    createAxiosAction({
        type: FETCH_PSC730,
        promise: PSC730Service.getPSC730PricingOnTransaction(pricingRequest, ib_cost, prx_both_whs_dsd_sw, currentPriceRequest)
    });



