import { createSelector } from 'reselect';

export const getPSC730State = (
  state
) => state.PSC730;

export const getPSC730Loading = createSelector(
  [getPSC730State],
  (PSC730) => {
    return PSC730.loading;
  }
);

export const getPSC730Error = createSelector(
  [getPSC730State],
  (PSC730) => {
    return PSC730.error;
  }
);

export const getPSC730Response = createSelector(
  [getPSC730State],
  (PSC730) => {
    return PSC730.response;
  }
);

export const getPSC730Data = createSelector(
  [getPSC730Response],
  (PSC730) => {
    return PSC730 && PSC730.data;
  }
);