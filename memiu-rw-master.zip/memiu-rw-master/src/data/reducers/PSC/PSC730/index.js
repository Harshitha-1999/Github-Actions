import {
  handleStateLifecycle,
  createAxiosAsyncDispatcher
} from 'middleware/asyncDispatcher';

import { FETCH_PSC730 } from './actions';

const PSC730Dispatcher = createAxiosAsyncDispatcher((state, action) => {
  switch (action.type) {
    case FETCH_PSC730:
      return handleStateLifecycle(state, action);
    default:
      return state;
  }
});

export default PSC730Dispatcher;
