import { createSelector } from 'reselect';

export const getPSC710State = (
  state
) => state.PSC710;

export const getPSC710Loading = createSelector(
  [getPSC710State],
  (PSC710) => {
    return PSC710.loading;
  }
);

export const getPSC710Error = createSelector(
  [getPSC710State],
  (PSC710) => {
    return PSC710.error;
  }
);

export const getPSC710Response = createSelector(
  [getPSC710State],
  (PSC710) => {
    return PSC710.response;
  }
);

export const getPSC710Data = createSelector(
  [getPSC710Response],
  (PSC710) => {
    return PSC710 && PSC710.data;
  }
);