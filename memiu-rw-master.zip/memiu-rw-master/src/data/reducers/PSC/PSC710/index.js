import {
  handleStateLifecycle,
  createAxiosAsyncDispatcher
} from 'middleware/asyncDispatcher';

import { FETCH_PSC710 } from './actions';

const PSC710Dispatcher = createAxiosAsyncDispatcher((state, action) => {
  switch (action.type) {
    case FETCH_PSC710:
      return handleStateLifecycle(state, action);
    default:
      return state;
  }
});

export default PSC710Dispatcher;
