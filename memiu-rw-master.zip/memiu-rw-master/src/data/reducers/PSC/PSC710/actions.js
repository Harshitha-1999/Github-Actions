import { PSC710Service } from "api/PSC/PSC710";
import { createAxiosAction } from 'middleware/asyncDispatcher';

export const FETCH_PSC710 = 'foc/FETCH_PSC710';

export const getPSC710OnLoad = (requestParams) =>
    createAxiosAction({
        type: FETCH_PSC710,
        promise: PSC710Service.getPSC710OnLoad(requestParams),
    });

// export const getPSC710OnTransaction = () =>
// createAxiosAction({
//     type: FETCH_PSC710,
//     promise: PSC710Service.getPSC710OnTransaction(),
// });






