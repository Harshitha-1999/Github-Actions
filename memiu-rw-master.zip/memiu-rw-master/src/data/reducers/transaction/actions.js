export const UPDATE_TRANSACTION = 'transaction/UPDATE_TRANSACTION';
export const UPDATE_TRANSACTION_ID = 'transactionID/UPDATE_TRANSACTION_ID';


export const updateTransaction_Action = (transaction_ID) => ({
  type: UPDATE_TRANSACTION,
  payload: transaction_ID,
});

export const updateTransaction = (transaction_ID) => (
  dispatch
) => {
  dispatch(updateTransaction_Action(transaction_ID));
};