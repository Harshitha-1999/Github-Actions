import {
  UPDATE_TRANSACTION,
} from "./actions";

export const transactionInitialState = {
  transactionVariables: {
    transactionID: null
  },
};

export const transactionReducer = (state = transactionInitialState, action) => {
  switch (action.type) {
    case UPDATE_TRANSACTION:
      return {
        ...state,
        transactionVariables: action.payload,
      };
    default:
      return state;
  }
};

export default transactionReducer;


