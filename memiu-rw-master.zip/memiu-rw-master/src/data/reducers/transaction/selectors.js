import { createSelector } from 'reselect';

export const getTransactionState = (state) => state.transaction


export const getTransaction = createSelector(
  [getTransactionState],
  (state) => {
    return state.transactionVariables;
  }
);