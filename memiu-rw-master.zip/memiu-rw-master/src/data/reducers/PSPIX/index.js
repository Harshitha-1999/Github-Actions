import {
  UPDATE_PSPIX,
  UPDATE_PSPIX_CORP,
  UPDATE_PSPIX_DIV,
  UPDATE_PSPIX_STORE,
  UPDATE_PSPIX_ROG
} from "./actions";

export const pspixInitialState = {
  pspixVariables: {
    pspixRecapCorp: null,
    pspixRecapDiv: null,
    pspixRecapFac: null,
    pspixStore: null,
    pspixRecapRog: null,
    pspixDate: null,
    pspixYear: null,
    pspixWeekNum: null,
    pspixWeekEnding: null,
    pspixWeekStarting: null,
    pspixCountryCode: null,
    pspixType: null,
    pspixPrevYearMaxWeekNum: null,
    pspixStorePharmacyFlag: null,
    pspixStoreProvinceCode: null,
    pspixStoreSecurityAccess: null,
    pspixHoldSession: null,
    pspixCallingProgram: null,
    pspixPSC700Values: null,
    pspixPage710: null,
    pspixPage720: null,
    pspixToPSC730: null,
    pspixNoInfoFound: null,
    pspixCurrDateFndInd: null,
    pspixExitBackMenu700: null

  },
};

export const pspixReducer = (state = pspixInitialState, action) => {
  switch (action.type) {
    case UPDATE_PSPIX:
      return {
        ...state,
        pspixVariables: action.payload,
      };
    case UPDATE_PSPIX_CORP:
      return {
        ...state,
        pspixVariables: {
          ...state.pspixVariables,
          pspixRecapCorp: action.payload
        }
      };
    case UPDATE_PSPIX_DIV:
      return {
        ...state,
        pspixVariables: {
          ...state.pspixVariables,
          pspixRecapDiv: action.payload
        }
      };
    case UPDATE_PSPIX_STORE:
      return {
        ...state,
        pspixVariables: {
          ...state.pspixVariables,
          pspixStore: action.payload
        }
      };
    case UPDATE_PSPIX_ROG:
      return {
        ...state,
        pspixVariables: {
          ...state.pspixVariables,
          pspixRecapRog: action.payload
        }
      };

    default:
      return state;
  }
};

export default pspixReducer;


