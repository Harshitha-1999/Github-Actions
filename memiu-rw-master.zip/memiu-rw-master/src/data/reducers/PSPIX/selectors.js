import { createSelector } from 'reselect';

export const getPspixState = (state) =>
  state.pspix;

export const pspixVariables = createSelector(
  [getPspixState],
  (pspixState) => {
    return pspixState.pspixVariables;
  }
);
