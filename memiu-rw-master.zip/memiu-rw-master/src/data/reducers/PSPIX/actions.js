export const UPDATE_PSPIX = 'pspix/UPDATE_PSPIX';
export const UPDATE_PSPIX_CORP = 'corp/UPDATE_PSPIX_CORP';
export const UPDATE_PSPIX_DIV = 'div/UPDATE_PSPIX_DIV';
export const UPDATE_PSPIX_STORE = 'store/UPDATE_PSPIX_STORE';
export const UPDATE_PSPIX_ROG = 'rog/UPDATE_PSPIX_ROG';



export const updatePSPIX_Action = (pspix) => ({
  type: UPDATE_PSPIX,
  payload: pspix,
});

export const updatePSPIX_Corp_Action = (corp) => ({
  type: UPDATE_PSPIX_CORP,
  payload: corp,
});

export const updatePSPIX_Div_Action = (div) => ({
  type: UPDATE_PSPIX_DIV,
  payload: div,
});

export const updatePSPIX_Store_Action = (store) => ({
  type: UPDATE_PSPIX_STORE,
  payload: store,
});


export const updatePSPIX_Rog_Action = (rog) => ({
  type: UPDATE_PSPIX_ROG,
  payload: rog,
});

export const updatePSPIX = (pspix) => (
  dispatch
) => {
  dispatch(updatePSPIX_Action(pspix));
};

export const updatePSPIX_Corp = (corp) => (
  dispatch
) => {
  dispatch(updatePSPIX_Corp_Action(corp));
};

export const updatePSPIX_Div = (div) => (
  dispatch
) => {
  dispatch(updatePSPIX_Div_Action(div));
};

export const updatePSPIX_Store = (store) => (
  dispatch
) => {
  dispatch(updatePSPIX_Store_Action(store));
};

export const updatePSPIX_Rog = (rog) => (
  dispatch
) => {
  dispatch(updatePSPIX_Rog_Action(rog));
};