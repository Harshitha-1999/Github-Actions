import React, { useCallback } from "react";
import { Route } from "react-router-dom";
import { authTokenCookie } from 'utils'
import { Environment } from '../../utils'
const ProtectedRoutes = (props) => {
  const { authCookie } = authTokenCookie();

  const { component: Component, ...rest } = props;

  const handleAuthenticate = useCallback(() => {
    //Clear browser session storage on logout.
    sessionStorage.clear();
    if (window.location.href.toLowerCase() === `${process.env.REACT_APP_LOGIN_ROOT}/productinquirymenu`) {
      let sessionUrl = window.location.href
      document.cookie = `sessionUrl= ${sessionUrl}`
    }
    window.location.replace(Environment.getLoginUrl());
  }, []);

  return (
    <Route
      {...rest}
      render={prop =>
          authCookie && authCookie.name ? <Component {...prop} /> :handleAuthenticate()
      }
    />
  );
}

export default ProtectedRoutes;