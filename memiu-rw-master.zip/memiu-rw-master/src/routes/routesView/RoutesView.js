import React from "react";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Error404 } from "components";
import ProtectedRoutes from './ProtectedRoutes';
import routes from "../routes";
import { Environment } from '../../utils';

export const RoutesView = () => {
    return (

        <Router basename={Environment.getAppContextPath()}>
            <Switch>

                {routes.map((route, index) => {

                    if (route.level === 'ProtectedRoutes') {
                        return <ProtectedRoutes key={index} {...route}></ProtectedRoutes>;
                    }
                    return <Route key={index} {...route}></Route>;
                })}
                <Route component={Error404} />
            </Switch>
        </Router>
    )
}

export default RoutesView;