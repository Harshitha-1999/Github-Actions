import { RouteBase } from './constants';
import MEMI01 from "pages/MEMI/LookupPage";
import MEMI02 from "pages/MEMI/MappingPage";
import MEMI03 from "pages/MEMI/MapItemsPage";
import MEMI04 from "pages/MEMI/MappedPage";
import MEMI05 from "pages/MEMI/BakeryMappingPage";
import MEMI06 from "pages/MEMI/MEMI06";
import MEMI07 from "pages/MEMI/AugmentationScreenPage";
import MEMI08 from "pages/MEMI/MEMI08";
import MEMI09 from "pages/MEMI/MEMI09";
import MEMI10 from "pages/MEMI/MEMI10";
import MEMI11 from "pages/MEMI/manualMappingPage";
import MEMI111 from "pages/MEMI/MEMI111";
import MEMI12 from "pages/MEMI/MEMI12";
import MEMI13 from "pages/MEMI/UPCMatchPage";
import MEMI14 from "pages/MEMI/OverrideProcessContinuedPage";
import MEMI15 from "pages/MEMI/MEMI15";
import MEMI16 from "pages/MEMI/MEMI16";
import MEMI17 from "pages/MEMI/NewUPCPage";
import MEMI18 from "pages/MEMI/AugmentationContinuedPage";
import MEMI19 from "pages/MEMI/MEMI19";
import MEMI20 from "pages/MEMI/OverrideProcessPage";
import MEMI21 from "pages/MEMI/MultiUnitTypePage";
import MEMI22 from "pages/MEMI/MultiUnitContinuedPage";
import MEMI23 from "pages/MEMI/DisplayerPage";
import MEMI24 from "pages/MEMI/DisplayerContinuedPage";
import MEMI25 from "pages/MEMI/MEMI25";
import healthCheckPage from 'pages/MEMI/healthCheckPage'
import LookupPage from "pages/MEMI/lookup/LookupPage";
import { Apps } from '@material-ui/icons';
import ButtonLogout from 'components/ButtonLogout/ButtonLogout';
import { Environment } from 'utils';

const routes = [
  {
    path: `${RouteBase.MEMIHealthCheck}`,
    component: healthCheckPage,
    exact: true,
    level: "UnProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI10}`,
    component: MEMI10,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI06}`,
    component: MEMI06,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: <Apps />,
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI13}`,
    component: MEMI13,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: "UPC Match / Model Like Item",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI17}`,
    component: MEMI17,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: "New UPC / No Item Match",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },

  {
    path: `${RouteBase.MEMI23}`,
    component: MEMI23,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: "Displayer",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI21}`,
    component: MEMI21,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "yes", label: "Multi Unit Type",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },

  {
    path: `${RouteBase.LookupPage}`,
    component: LookupPage,
    exact: true,
    level: "ProtectedRoutes", navigationBar: false,
    navNames: ["main", "memi"],
  },
  {
    path: `${RouteBase.MEMI01}`,
    component: MEMI01,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI02}`,
    component: MEMI02,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI03}`,
    component: MEMI03,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "Mapping Items",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI04}`,
    component: MEMI04,
    exact: true,
    level: "ProtectedRoutes", navigationBar: 'no', label: "Mapped",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI05}`,
    component: MEMI05,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "Bakery Mapping",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },

  {
    path: `${RouteBase.MEMI07}`,
    component: MEMI07,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI08}`,
    component: MEMI08,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI15}`,
    component: MEMI15,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "Displayer",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI09}`,
    component: MEMI09,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI11}`,
    component: MEMI11,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "ManualMapping MI11",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI12}`,
    component: MEMI12,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI14}`,
    component: MEMI14,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "OverrideProcessCont MI14",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI16}`,
    component: MEMI16,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI18}`,
    component: MEMI18,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "AugmentationCont MI18",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI19}`,
    component: MEMI19,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI20}`,
    component: MEMI20,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "OverrideProcess MI20",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI22}`,
    component: MEMI22,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "MultiUnitCont MI22",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI24}`,
    component: MEMI24,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "Displayer Cont MEMI24",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI25}`,
    component: MEMI25,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no", label: "MEMI25",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },
  {
    path: `${RouteBase.MEMI111}`,
    component: MEMI111,
    exact: true,
    level: "ProtectedRoutes", navigationBar: "no",
    navNames: ["main", "memi"],
    appcode: "MEMI"
  },

];

///////////////////////////////////
// Buttons that are duplicate, or not routes, for later.
//////////////////////////////////
export const Buttons = [
  {
    path: `${RouteBase.MEUP50}`,
    navNames: ["main", "meup-standard", "home", "meup-holduser", "meup"],
    label: 'Home'
  },
  {
    component: <ButtonLogout classNameMemi="HeaderMeupButton" />,
    navNames: ["main", "meup-standard", "home", "meup-holduser", "meup"],
    label: 'Logout'
  },
];

////////////////////////////////////////////////////////////

/* Function that builds routes array - @Params - Array of strings of route */
const buildRoutes = (routesArray) => {





  let finalRoute = routesArray.filter((route) => {
    const validateAppCode = route.appcode === Environment.getReactAppCode() || Environment.getReactAppCode() === "TATA";
    return validateAppCode;
  })
  return finalRoute;
}

export default buildRoutes(routes);
