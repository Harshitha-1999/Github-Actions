import * as InputUtils from './InputUtils';


describe("Input Utility Tests", () => {

    describe("setFocus Utility", () => {
        it('Should call utility with given arguments', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    setSelectionRange: jest.fn()
                });
            InputUtils.setFocus('test');
            expect(documentSpy).toHaveBeenCalledWith('test');
        });

        it('Should not call utility with given arguments when element is not found', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(null);
            InputUtils.setFocus('test');
            expect(documentSpy).toHaveBeenCalledTimes(1);
        });
    });

    describe("keyCodeParser Utility", () => {
        it('Should return the string Tab when given an event object with a key of Tab', () => {
            let ev = new Event('keydown');
            ev.key = "Tab";

            let keyString = InputUtils.keyCodeParser(ev);
            expect(keyString).toEqual('Tab');
        });

        it('Should return the string Shift+Tab when given an event object with a key of Tab and shift key held', () => {
            let ev = new Event('keydown');
            ev.key = "Tab";
            ev.shiftKey = true;

            let keyString = InputUtils.keyCodeParser(ev);
            expect(keyString).toEqual('Shift+Tab');
        });

        it('Should return the string Ctrl+Tab when given an event object with a key of Tab and shift key held', () => {
            let ev = new Event('keydown');
            ev.key = "Tab";
            ev.ctrlKey = true;

            let keyString = InputUtils.keyCodeParser(ev);
            expect(keyString).toEqual('Ctrl+Tab');
        });
    });

    describe("tabAndArrowNavigationUtil", () => {
        it('Should call setFocus function with nextInput param when ev key is Tab', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    setSelectionRange: jest.fn(),
                });

            let ev = new Event('keydown');
            ev.key = "Tab";
            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            // let focusSpyOn = jest.spyOn(InputUtils, "setFocus");
            InputUtils.tabAndArrowNavigationUtil(ev, "next-input", "prev-input");
            expect(documentSpy).toHaveBeenCalled();

        });

        it('Should call setFocus function with prevInput param when ev key is Tab and Shift key is held', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    setSelectionRange: jest.fn(),
                });

            let ev = new Event('keydown');
            ev.key = "Tab";
            ev.shiftKey = true;

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            // let focusSpyOn = jest.spyOn(InputUtils, "setFocus");
            InputUtils.tabAndArrowNavigationUtil(ev, "next-input", "prev-input");
            expect(documentSpy).toHaveBeenCalled();

        });

        it('Should not call documentSpy when Tab is not the key pressed', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    setSelectionRange: jest.fn(),
                });

            let ev = new Event('keydown');
            ev.key = "";

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            // let focusSpyOn = jest.spyOn(InputUtils, "setFocus");
            InputUtils.tabAndArrowNavigationUtil(ev, "next-input", "prev-input");
            expect(documentSpy).not.toHaveBeenCalled();
        });

        it('Should not call documentSpy when nextInput and prevInput arguments are not supplied', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    setSelectionRange: jest.fn(),
                });

            let ev = new Event('keydown');
            ev.key = "";

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            // let focusSpyOn = jest.spyOn(InputUtils, "setFocus");
            InputUtils.tabAndArrowNavigationUtil(ev);
            expect(documentSpy).not.toHaveBeenCalled();
        });
    });

    describe("replaceNextCharacterOnSpacebarPress Utility", () => {
        it('Should call setFieldValue stub', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    selectionStart: 0,
                    setSelectionRange: jest.fn(),
                    maxLength: 1
                }
            );
            // spy on requestAnimationFrame function, just fires off the callback
            let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
                cb();
            })
            let ev = {};
            ev.key = "Tab";
            ev.target = {
                id: 'my-id',
                value: 'text'
            }

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            const setFieldvalueStub = jest.fn();

            InputUtils.replaceNextCharacterOnKeyPress(ev, setFieldvalueStub, 'next-input');
            expect(setFieldvalueStub).toHaveBeenCalled();
        });

        it('Should return out when the maxLength and position of the field are equal', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    selectionStart: 0,
                    setSelectionRange: jest.fn(),
                    maxLength: 0
                }
            );
            // spy on requestAnimationFrame function, just fires off the callback
            let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
                cb();
            })
            let ev = {};
            ev.key = "Tab";
            ev.target = {
                id: 'my-id',
                value: 'text'
            }

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            const setFieldvalueStub = jest.fn();

            InputUtils.replaceNextCharacterOnKeyPress(ev, setFieldvalueStub, 'my-id');
            expect(documentSpy).toHaveBeenCalled();
        });
        it('Should return out when the maxLength and position of the field are equal and nextInput is not defined', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    selectionStart: 0,
                    setSelectionRange: jest.fn(),
                    maxLength: 0
                }
            );
            // spy on requestAnimationFrame function, just fires off the callback
            let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
                cb();
            })
            let ev = {};
            ev.key = "Tab";
            ev.target = {
                id: 'my-id',
                value: 'text'
            }

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            const setFieldvalueStub = jest.fn();

            InputUtils.replaceNextCharacterOnKeyPress(ev, setFieldvalueStub);
            expect(documentSpy).toHaveBeenCalled();
        });
    });


    // describe("moveCaretBackOnBackSpacePress Utility", () => {
    //     it('Should skip all function logic on key down when event key is not Backspace', () => {
    //         let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
    //             {
    //                 focus: jest.fn(),
    //                 selectionStart: 0,
    //                 setSelectionRange: jest.fn(),
    //                 maxLength: 0
    //             }
    //             );
    //         // spy on requestAnimationFrame function, just fires off the callback
    //         let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
    //             cb();
    //         });

    //         let ev = {};
    //         ev.key = "a";
    //         ev.target = {
    //             id: 'my-id',
    //             value: 'text'
    //         }

    //         ev.stopPropagation = jest.fn();
    //         ev.preventDefault = jest.fn();

    //         InputUtils.moveCaretBackOnBackSpacePress(ev);
    //         expect(documentSpy).not.toHaveBeenCalled();
    //     });

    //     it('Should not return on key down when event key is Backspace', () => {
    //         let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
    //             {
    //                 focus: jest.fn(),
    //                 selectionStart: 1,
    //                 setSelectionRange: jest.fn(),
    //                 maxLength: 0
    //             }
    //             );
    //         // spy on requestAnimationFrame function, just fires off the callback
    //         let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
    //             cb();
    //         });

    //         let ev = {};
    //         ev.key = "Backspace";
    //         ev.target = {
    //             id: 'my-id',
    //             value: 'text'
    //         }

    //         ev.stopPropagation = jest.fn();
    //         ev.preventDefault = jest.fn();

    //         InputUtils.moveCaretBackOnBackSpacePress(ev);
    //         expect(documentSpy).toHaveBeenCalled();
    //     });

    //     it('Should return on key down when event key is Backspace and caret position is 0', () => {
    //         let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
    //             {
    //                 focus: jest.fn(),
    //                 selectionStart: 0,
    //                 setSelectionRange: jest.fn(),
    //                 maxLength: 0
    //             }
    //             );
    //         // spy on requestAnimationFrame function, just fires off the callback
    //         let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
    //             cb();
    //         });

    //         let ev = {};
    //         ev.key = "Backspace";
    //         ev.target = {
    //             id: 'my-id',
    //             value: 'text'
    //         }

    //         ev.stopPropagation = jest.fn();
    //         ev.preventDefault = jest.fn();

    //         InputUtils.moveCaretBackOnBackSpacePress(ev);
    //         expect(documentSpy).toHaveBeenCalled();
    //     });
    // });

    describe("setPageLevelErrorMessage Utility", () => {
        it('Should call utility with given arguments', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    value: '',
                    style: {
                        color: ''
                    }
                });

            let ele = documentSpy();
            InputUtils.setPageLevelErrorMessage('test message');
            //    expect(ele.value).toEqual('test message');
            //    expect(ele.style.color).toEqual('red');
        });
    });

    describe("replaceCharacterOnPaste", () => {
        it('Should call setFieldValue stub', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    selectionStart: 0,
                    setSelectionRange: jest.fn(),
                    maxLength: 2
                }
            );
            // spy on requestAnimationFrame function, just fires off the callback
            let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
                cb();
            })
            let ev = {};
            ev.key = "Tab";
            ev.target = {
                id: 'my-id',
                value: 'text'
            }

            ev.clipboardData = {
                getData: jest.fn().mockReturnValue("co")
            }

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            const setFieldvalueStub = jest.fn();

            InputUtils.replaceCharactersOnPaste(ev, setFieldvalueStub, 'next-input');
            expect(setFieldvalueStub).toHaveBeenCalled();
            // expect(ev.clipBoardData.getData).toHaveBeenCalled();
        });

        it('Should call setFieldValue stub, caret position is less than pasted text length', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    selectionStart: 0,
                    setSelectionRange: jest.fn(),
                    maxLength: 4
                }
            );
            // spy on requestAnimationFrame function, just fires off the callback
            let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
                cb();
            })
            let ev = {};
            ev.key = "Tab";
            ev.target = {
                id: 'my-id',
                value: 'text'
            }

            ev.clipboardData = {
                getData: jest.fn().mockReturnValue("co")
            }

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            const setFieldvalueStub = jest.fn();

            InputUtils.replaceCharactersOnPaste(ev, setFieldvalueStub);
            expect(setFieldvalueStub).toHaveBeenCalled();
            // expect(ev.clipBoardData.getData).toHaveBeenCalled();
        });

        it('Should call setFieldValue stub, paste length is maxLength', () => {
            let documentSpy = jest.spyOn(document, 'getElementById').mockReturnValue(
                {
                    focus: jest.fn(),
                    selectionStart: 0,
                    setSelectionRange: jest.fn(),
                    maxLength: 1,
                    style: {}
                }
            );
            // spy on requestAnimationFrame function, just fires off the callback
            let animationSpy = jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => {
                cb();
            })
            let ev = {};
            ev.key = "Tab";
            ev.target = {
                id: 'my-id',
                value: 'text'
            }

            ev.clipboardData = {
                getData: jest.fn().mockReturnValue("co")
            }

            ev.stopPropagation = jest.fn();
            ev.preventDefault = jest.fn();

            const setFieldvalueStub = jest.fn();

            let val = InputUtils.replaceCharactersOnPaste(ev, setFieldvalueStub, 'next-input');
            expect(val).toEqual(undefined);

        });
    });

    describe("sanitizeFormValue", () => {
        it('Should return an empty string when input value is *', () => {
            let val = InputUtils.sanitizeFormValue('*');
            expect(val).toEqual("");
        });

        it('Should return the same string when input value is not *', () => {
            let val = InputUtils.sanitizeFormValue('TEST');
            expect(val).toEqual("TEST");
        })
    })
});