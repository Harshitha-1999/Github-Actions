import moment from "moment-timezone";

export class DateUtility {
  static getFormattedDate(dateValue) {
    let date = new Date(dateValue);
    let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    return month + '/' + day + '/' + year;
  }

  static convertDate(dateValue) {
    let date = new Date(dateValue);
    let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    return year + '-' + month + '-' + day;
  }

  static getWeekDay(dayNum) {
    let weekday = new Array(7);
    weekday[1] = "Sunday";
    weekday[2] = "Monday";
    weekday[3] = "Tuesday";
    weekday[4] = "Wednesday";
    weekday[5] = "Thursday";
    weekday[6] = "Friday";
    weekday[7] = "Saturday";
    return weekday[dayNum];
  }

  static getSalesDateStatus(code) {
    switch (code) {
      case "O":
        return "Open";
      case "C":
        return "Closed";
      case "S":
        return "Setup is required";
      default:
        return " ";
    }
  }

  static compareDates(dateValue1, dateValue2, condition) {
    let date1 = new Date(dateValue1);
    let date2 = new Date(dateValue2);
    switch (condition) {
      case "<":
        return (date1.getTime() < date2.getTime());
      case ">":
        return (date1.getTime() > date2.getTime());
      case "=":
        return (date1.getTime() === date2.getTime());
      case "<=":
        return (date1.getTime() <= date2.getTime());
      case ">=":
        return (date1.getTime() >= date2.getTime());
      default:
        return true;

    }
  }

  static diffDates(dateValue1, dateValue2) {
    let date1 = moment(dateValue1);
    let date2 = moment(dateValue2);
    return date1.diff(date2, 'days');
  }

  static getWeekNumber(dateValue) {
    return moment(dateValue).isoWeek();

  }

  static addDays(dateValue, days) {
    return this.getFormattedDate(new Date(dateValue).getTime() + days * 24 * 60 * 60 * 1000);
  }

  static subDays(dateValue, days) {
    return this.getFormattedDate(new Date(dateValue).getTime() - days * 24 * 60 * 60 * 1000);
  }

  static getCurrentDate() {
    return this.convertDate(moment().format('MM/DD/YYYY'));
  }

  static getMountainStdTime() {
    return moment(new Date()).tz('America/Denver').format('HH:mm:ss');
  }

  static getMountainStdDate() {
    return moment(new Date()).tz('America/Denver').format('YYYY-MM-DD');
  }
}

export default DateUtility;

