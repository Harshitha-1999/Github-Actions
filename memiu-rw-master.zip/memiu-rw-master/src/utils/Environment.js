export class Environment {
  static getPublicUrl() {
    return process.env.PUBLIC_URL;
  }

  static getLoginUrl() {
    return process.env.REACT_APP_LOGIN_ROOT + '/authenticate';
  }

  static getLogoutUrl() {
    return process.env.REACT_APP_LOGOUT_URL;
  }

  static getReactAppVersion() {
    return process.env.REACT_APP_VERSION;
  }

  static getNodeEnvironment() {
    return process.env.NODE_ENV;
  }

  static getApiUrl() {
    return process.env.REACT_APP_API_URL;
  }

  static getAzureRedirectUri() {
    return process.env.REACT_APP_REDIRECT_URI;
  }

  static getFOCRedirectUri() {
    return process.env.REACT_APP_FOC_REDIRECT_URL;
  }

  static getHelpScreenApiUri() {
    return process.env.REACT_APP_HELP_SCREEN_URL;
  }

  static getAccessDetailsUri() {
    return process.env.REACT_APP_ACCESS_DETAILS_URL;
  }

  static getSubscriptionKey() {
    return process.env.REACT_APP_SUB_KEY;
  }

  static getMECRedirectUri() {
    return process.env.REACT_APP_MEC_REDIRECT_URL;
  }

  static getAppName() {
    return process.env.REACT_APP_APPCODE_NAME;
  }

  static getAppContextPath() {

    return process.env.REACT_APP_CONTEXT_PATH;
  }
  static getAppReactAppApiBaseUrl() {

    return process.env.REACT_APP_API_BASE_URL;
  }
  static getReactAppCode() {

    return process.env.REACT_APP_APPCODE;
  }
  static getReactAppTitle() {

    return process.env.REACT_APP_TITLE;
  }


}
export default Environment;
