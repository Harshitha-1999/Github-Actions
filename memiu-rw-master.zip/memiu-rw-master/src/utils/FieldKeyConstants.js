//Screen level access field keys..

export const SCREEN_ISC010 = 'SCREEN_ISC010';
export const SCREEN_ISC020 = 'SCREEN_ISC020';
export const SCREEN_PSC700 = 'SCREEN_PSC700';
export const SCREEN_PSC710 = 'SCREEN_PSC710';
export const SCREEN_PSC720 = 'SCREEN_PSC720';
export const SCREEN_PSC730 = 'SCREEN_PSC730';
export const SCREEN_FOC100 = 'SCREEN_FOC100';
export const PS_VENDOR_INFO = 'PS.VENDOR.INFO';
export const PS_TCA = 'PS.TCA';
export const PS_ITEM_MVMT = 'PS.ITEM.MVMT';
export const PS_STOCK_MESSAGE = 'PS.STOCK.MESSAGE';
export const PS_BILLING_GROSS = 'PS.BILLING.GROSS';
export const PS_IB_COST = 'PS.IB.COST';
export const PS_NEXT_RECEIVED_DATE = 'PS.NEXT.RECEIVED.DATE';
export const ACCESS_UPDATE = 'UPDATE';
export const ACCESS_READ = 'READ';
export const NO_ACCESS = '';














