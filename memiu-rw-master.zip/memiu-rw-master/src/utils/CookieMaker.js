import jwt_decode from "jwt-decode";
export const authTokenCookie = () => {
  //gets cookie and returns it as a key=value object

  try {
    let cookies = document.cookie ? document.cookie.split(";") : null;
    let cookieVal;
    let fields;
    if (cookies) {
      let cookie = cookies.filter(cookie => cookie.includes("ent-abs-auth"));
      cookieVal = cookie.length ? cookie[0] : null;
    }
    fields = cookieVal ? cookieVal.split("=") : null;
    const authCookie = {
      name: fields ? fields[1] : null,
    };
    let token = authCookie.name ? authCookie.name : null;
    let decodedToken = token ? jwt_decode(token) : null;


    return {
      authCookie,
      token: token,
      idToken: token ? token.split("%22")[3] : null,
      userId: decodedToken ? decodedToken.upn.split("@")[0].toUpperCase() : null,
      tid: decodedToken ? decodedToken.tid : null,
    }

  } catch (err) {
  }
};

