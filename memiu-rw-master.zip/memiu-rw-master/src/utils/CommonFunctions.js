export function arrayEquals(a, b) {

    if ((a.length !== b.length) || !Array.isArray(a) || !Array.isArray(b)) {
        return false;
    }
    for (let i = 0; i < a.length; i++) {
        if (typeof (a[i]) !== typeof (b[i])) {
            return false
        }
        else if (typeof (a) === 'object' && !objectEquals(a[i], b[i])) {
            return false
        }
        else if (typeof (a) !== 'object' && a[i] !== b[i]) {
            return false;
        }
    }
    return true;

}

export function objectEquals(a, b) {
    return JSON.stringify(a) === JSON.stringify(b)
}

export function checkEmpty(value) {
    if (value.trim() === "" || value === undefined) {
        return null
    }
    return value
}

export const smicFieldFirstColumnValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.grpCd === null || UpdateOverrideLikeSrcEditDetails.newItemDto.grpCd.length === 0) {
        setError(true);
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const smicFieldSecondColumnValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.ctgryCd === null || UpdateOverrideLikeSrcEditDetails.newItemDto.ctgryCd.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const PrivateLabelFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updPtLabelInd === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updPtLabelInd.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const DescSizeFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updSize === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updSize.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const NumSizeFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const SizeUOMFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const UsageIndFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updUsgeInd.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const UsageTypeFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updUsageTypInd.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const DisplayFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updDispFlag === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updDispFlag.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const ItemDescFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updItmDesc === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updItmDesc.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const WhseDescFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updWhseItmDesc === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updWhseItmDesc.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const SsDescFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updRtlItmDesc === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updRtlItmDesc.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const InternetDescFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updIntenetItemDesc === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updIntenetItemDesc.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const PosDescFieldValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.updPosDesc === null || UpdateOverrideLikeSrcEditDetails.newItemDto.updPosDesc.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const ProductClassCodeValidation = function (UpdateOverrideLikeSrcEditDetails, setError) {
    if (UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd === null || UpdateOverrideLikeSrcEditDetails.newItemDto.productClsCd.length === 0) {
        setError(true)
        return false;
    }
    else {
        setError(false);
        return true;
    }
};

export const numberValidation = function (UpdateOverrideLikeSrcEditDetails, AppData) {
    var number = new RegExp(/^[0-9]*(\.[0-9]{1,20})?$/);
    if (number.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr)) {
        return true
    }
    else {
        console.log("Invalid number in Num Size field");
    // AppData.setAlertBox(true, "Invalid number in Num Size field");
        return false
    }
};

export const specialCharacterValidation = function (UpdateOverrideLikeSrcEditDetails, AppData) {
    var pattern = new RegExp(/[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/);
    var updSizePattern = new RegExp(/[~`!#$%\^&*+=\\[\]\\';,/{}|\\":<>\?]/);
    // if (updSizePattern.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr) || pattern.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeUom)) {
    if (updSizePattern.test(UpdateOverrideLikeSrcEditDetails.newItemDto.cscDsc) || pattern.test(UpdateOverrideLikeSrcEditDetails.newItemDto.updSizeNmbr)) {
        console.log("Special characters not allowed.");
        // AppData.setAlertBox(true, "Special characters not allowed.");
        return false
    }
    else {
        return true;
    }
};

export const loadMore = function (totalDisplayed, totalLength) {

    let currentTotalDisplayedValue;

    currentTotalDisplayedValue = totalDisplayed;

    totalDisplayed = totalDisplayed + 200;

    if (totalDisplayed >= totalLength) {
        totalDisplayed = currentTotalDisplayedValue + (totalLength - currentTotalDisplayedValue);
    }

    return totalDisplayed;
};

//Function to trim plu
export const trimPLUFunc = (results) => {
    if (results && results.length > 0) {
        results.forEach((sku) => {
            if (sku && sku.absUPCNo) {
                if (Number(sku.absUPCNo) <= 99999) {
                    var s = sku.absUPCNo;
                    while (s.charAt(0) === '0') {
                        s = s.substr(1);

                    }
                    sku.absUPCNo = s;
                }
            }
        })
    }
    return results
};


