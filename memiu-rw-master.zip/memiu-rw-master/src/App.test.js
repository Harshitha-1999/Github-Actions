import React from "react";
import { render } from "@testing-library/react";
import { AppContextProvider, ReduxProvider } from 'providers';
import App from './App'

// app.test.js
describe('<app />', () => {
  it('test app without error', () => {

    const { debug, container } = render(
      <ReduxProvider>
        <AppContextProvider>
          <App />
        </AppContextProvider>
      </ReduxProvider>
    )
  });
});