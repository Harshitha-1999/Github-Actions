import Axios from 'axios';

import { getResponseInterceptor, getRequestInterceptor } from './sharedInterceptors';
import { REQUEST_TIMEOUT_LENGTH } from 'api/constants';

// create an Axios instance with a default timeout of 5000 ms for requests
export const DefaultAxios = Axios.create({
  timeout: REQUEST_TIMEOUT_LENGTH
});

export const getDefaultResponseInterceptors = () => {
  const responseInterceptor = getResponseInterceptor(
    DefaultAxios,
  );
  return [responseInterceptor];
};

export const getDefaultRequestInterceptors = () => {
  const requestInterceptor = getRequestInterceptor(DefaultAxios);
  return [requestInterceptor];
}
