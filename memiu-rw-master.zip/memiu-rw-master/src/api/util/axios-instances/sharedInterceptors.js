import {
  LOGIN_ROOT,
  AXIOS_RETRY_COUNT,
  AXIOS_RETRY_CODES,
} from "api/constants";

let RETRY_COUNT = AXIOS_RETRY_COUNT;
export const getRequestInterceptor = (axiosInstance) => {
  return axiosInstance.interceptors.request.use((config) => ({
    ...config,
    headers: {
      ...config.headers,
    },
  }));
};

export const getResponseInterceptor = (axiosInstance) => {
  return axiosInstance.interceptors.response.use(
    (response) => {
      if (response.status === 401) {
        //Clear browser session storage on logout.
        sessionStorage.clear();
        window.location.replace(`${LOGIN_ROOT}/azurelogout`);
      }
      return response;
    },
    (error) => {
      if (
        RETRY_COUNT > 0 &&
        error &&
        error.response &&
        AXIOS_RETRY_CODES.includes(error.response.status)
      ) {
        RETRY_COUNT = RETRY_COUNT - 1;
        return axiosInstance.request(error.config);
      }
      if (error && error.response && error.response.status === 401) {
        //Clear browser session storage on logout.
        sessionStorage.clear();
        window.location.replace(`${LOGIN_ROOT}/azurelogout`);
      }
      return Promise.reject(error);
    }
  );
};
