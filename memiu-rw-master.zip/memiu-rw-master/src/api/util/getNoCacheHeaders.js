import { authTokenCookie, Environment } from 'utils';
//import { Environment } from 'utils/Environment';

export const getNoCacheHeaders = () => {
  let { userId, idToken } = authTokenCookie();

  return {
    "Cache-control": "no-cache, no-store, must-revalidate, post-check=0, pre-check=0",
    Pragma: "no-cache",
    Expires: "0",
    userId: userId,
    "Ocp-Apim-Subscription-Key": Environment.getSubscriptionKey(),
    "Authorization": `Bearer ${idToken}`,

  };
};
