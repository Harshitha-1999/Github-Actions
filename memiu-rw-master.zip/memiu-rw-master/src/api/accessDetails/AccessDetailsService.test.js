import { AccessDetailsService } from './AccessDetailsService';
import { DefaultAxios } from 'api/util/axios-instances/DefaultAxios';

describe('AccessDetailsService class', () => {

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('fetch error', async () => {
        const errorMsg = "Network Error";
        jest.spyOn(DefaultAxios, 'post').mockImplementationOnce(() =>
            Promise.reject(new Error(errorMsg))
        )

        await expect(AccessDetailsService.getAccessDetails()).rejects.toThrow(errorMsg)
    });
})