import { DefaultAxios, getNoCacheHeaders } from 'api/util';
import { ENDPOINT_FIELD_DETAILS } from 'api/constants';

export class FieldDetailsService {
    static async getFieldDetails() {
        return DefaultAxios.post(ENDPOINT_FIELD_DETAILS, null, {
            headers: getNoCacheHeaders()
        });
    }
}
export default FieldDetailsService;
