
import { checkEmpty } from 'utils'
import { ApiMemi } from '../../components/ApiCallsMemi/ApiCallsMemi'
import { apiUrl } from '../../service/apiUrls'


export class memiuServices {

    static async getCompanies() {
        return ApiMemi(apiUrl.company, "GET")
    }

    static async getDivisions(companyId) {
        return ApiMemi(apiUrl.divisions + companyId, "GET")
    }

    static async getSourceTargetData(company, division, matchIndicator) {
        return ApiMemi(apiUrl.getSourceTargetData + `/${company}/${division}/${matchIndicator}`, "GET")
    }

    static async getDepartmentList(company, division) {
        return ApiMemi(apiUrl.getDepartmentList + `/${company}/${division}`, "GET")
    }


    static async getLookUpScreen(company, division, userId) {
        return ApiMemi(apiUrl.getLookUpScreen + `/${company}/${division}/${userId}`, "POST", {})
    }

    static async postLookUpLoadSearch({
        productSku,
        department,
        itemSets,
        itemDescription,
        upc,
        supplierName,
        supplierNumber,
        plu,
        conversionStatus,
        corpItemCode,
        supplyType,
        productHierarchyName,
        hierachyLevel1,
        hierachyLevel2,
        hierachyLevel3,
        hierachyLevel4,
        hierachyLevel5,
        setErrorConversionStatus,
        setErrorDepartment,
        setErrorHierachyLevel4,
        startIndex,
        endIndex,
        AppData,
        sortItems,
        sortOrder,
        setPayload
    }) {

        if (department === "" || conversionStatus === "" || hierachyLevel4 === "") {
            setErrorDepartment(department.trim() === "");
            setErrorConversionStatus(conversionStatus.trim() === "");
            setErrorHierachyLevel4(hierachyLevel4.trim() === "")

            AppData.setAlertBox(true, "Highlighted fields are Mandatory.");
        }
        else {
            setErrorDepartment(false);
            setErrorConversionStatus(false);
            setErrorHierachyLevel4(false)

            let payload = {
                "prodHierarchyLvl4Cd": checkEmpty(hierachyLevel4),
                "conversionGroupCd": checkEmpty(department),
                "conversionStatus": checkEmpty(conversionStatus),
                "companyId": checkEmpty(AppData.companyId),
                "divisionId": checkEmpty(AppData.divisionId),
                "productSKU": checkEmpty(productSku),
                "itemDescription": checkEmpty(itemDescription),
                "supplierNum": checkEmpty(supplierNumber),
                "supplierName": checkEmpty(supplierName),
                "prodHierarchyLvl1Cd": checkEmpty(hierachyLevel1),
                "prodHierarchyLvl2Cd": checkEmpty(hierachyLevel2),
                "prodHierarchyLvl3Cd": checkEmpty(hierachyLevel3),
                "prodHierarchyLvl5Cd": checkEmpty(hierachyLevel5),
                "producthierarchyName": checkEmpty(productHierarchyName),
                "upc": checkEmpty(upc),
                "plu": checkEmpty(plu),
                "corpItemCd": checkEmpty(corpItemCode),
                "itemType": checkEmpty(itemSets),
                "supplyType": checkEmpty(supplyType),
                "startIndex": startIndex,
                "endIndex": endIndex
            }

            if (sortOrder && sortItems) {
                payload["sortOrder"] = sortOrder;
                payload["sortItems"] = sortItems;
            }

            setPayload(payload)


            return ApiMemi(apiUrl.postLookUpLoadSearch, "POST", payload)
        }
    }

    static async getLoadOverideData(company, division) {

        return ApiMemi(apiUrl.getLoadOverideData + `/${company}/${division}`, "GET")
    }
    static async getListAugData(company, division) {

        return ApiMemi(apiUrl.getListAugData + `/${company}/${division}`, "GET")
    }

    static async getDisplayersDownloadExcel(data) {
        return ApiMemi(`${apiUrl.displayersDownloadExcel}/${data.company}/${data.division}/${data.deptCode}/${data.deptName}/${data.type}`, "GET", "", "arraybuffer");
    }

    static async getDownloadExcel(data) {
        return ApiMemi(`${apiUrl.getDownloadExcel}/${data.company}/${data.division}/${data.deptCode}/${data.exceptionType}/${data.status}`, "GET", "", "arraybuffer");
    }

    static async getLoadOverideData2(deptCode, exceptionType, selectedCompanyID, selectedDivisionID, status, type) {
        return ApiMemi(apiUrl.getLoadOverideData2 + selectedCompanyID + "/" + selectedDivisionID + "/" + deptCode + "/" + exceptionType + "/" + status + "/" + type, "GET")
    }

    static async getUpdateOverideManualSearch(selectedCompanyID, selectedDivisionID, UpdateOverrideProductSkuSourceUpc) {
        return ApiMemi(apiUrl.getUpdateOverideManualSearch + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc, "GET")
    }
    static async getUpdateAugmentationManualSearch(selectedCompanyID, selectedDivisionID, upc) {
        return ApiMemi(apiUrl.getUpdateAugmentationManualSearch + selectedCompanyID + "/" + selectedDivisionID + "/" + upc, "GET")
    }
    static async getAugmentationEditData(selectedCompanyID, selectedDivisionID, UpdateOverrideProductSkuSourceUpc) {
        return ApiMemi(apiUrl.getAugmentaionEditData + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc, "GET")
    }

    static async getUpdateOverideManualSearchByUpc(selectedCompanyID, selectedDivisionID, UpdateOverrideProductSkuSourceUpc) {
        return ApiMemi(apiUrl.getUpdateOverideManualSearchByUpc + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc, "GET")
    }
    static async getAugmentationEditDataByUpc(selectedCompanyID, selectedDivisionID, UpdateOverrideProductSkuSourceUpc) {
        return ApiMemi(apiUrl.getAugmentaionEditDataByUpc + selectedCompanyID + "/" + selectedDivisionID + "/" + UpdateOverrideProductSkuSourceUpc, "GET")
    }

    //sourceList
    static async getSourceList(AppData, companyID, divisionID, mappingValue, itemType, filter, searchCriteria, searchCriteriaValue, sortOrder, sortItem, startIndex, endIndex) {
        const itemTypeObj = {
            all: itemType === "all" || itemType === "",
            system2: itemType === "system2",
            system4: itemType === "system4",
            plu: itemType === "plu"
        }

        let payload = {

            companyID: companyID,
            divisionID: divisionID,
            mappingStatus: mappingValue,
            filterAvail: filter !== null,
            filter: filter ? filter : {},
            itemType: itemTypeObj,
            searchCriteriaValue: searchCriteriaValue ? searchCriteriaValue : null,
            startIndex: startIndex ? startIndex : 1,
            endIndex: endIndex ? endIndex : 1000
        }

        if (searchCriteria) {
            payload.searchCriteria = searchCriteria
        }

        if (sortOrder) {
            payload.sortOrder = sortOrder
        }

        if (sortItem) {
            payload.sortItems = sortItem;
        }

        AppData.setMemi03SkuPayload(payload)

        return ApiMemi(apiUrl.getSourceList, "POST", payload)

    }

    static async getSourceListByPayload(payload) {
        return ApiMemi(apiUrl.getSourceList, "POST", payload)
    }

    static async getTargetList(AppData, companyID, divisionID, mappingValue, itemType, filter, searchCriteria, searchCriteriaValue) {
        const itemTypeObj = {
            all: itemType === "all" || itemType === "",
            system2: itemType === "system2",
            system4: itemType === "system4",
            plu: itemType === "plu"
        }

        let payload = {

            companyID: companyID,
            divisionID: divisionID,
            mappingStatus: mappingValue,
            filterAvail: filter !== null,
            filter: filter ? filter : {},
            itemType: itemTypeObj,
            searchCriteriaValue: searchCriteriaValue ? searchCriteriaValue : null,
            startIndex: 1,
            endIndex: 1000
        }

        if (searchCriteria) {
            payload.searchCriteria = searchCriteria
        }

        AppData.setMemi03CicPayload(payload)

        return ApiMemi(apiUrl.getTargetList, "POST", payload)

    }

    static async getListDisplayerData(data) {
        return ApiMemi(`${apiUrl.listDisplayerData}/${data.company}/${data.division}`, "GET");
    }


    static async getMemiu16LoadDeptWiseDisplayItem(data) {
        return ApiMemi(`${apiUrl.getMemiu16LoadDeptWiseDisplayItem}/${data.company}/${data.division}/${data.deptCode}/Y/${data.type}/${data.itemType}`, "GET");
    }

    static async displayersSearchOnItemDesc(data) {
        return ApiMemi(apiUrl.displayersSearchOnItemDesc, "POST", data);
    }

    static async displayersSearchOnProductSku(data) {
        return ApiMemi(apiUrl.displayersSearchOnProductSku, "POST", data);
    }

    static async displayersSearchOnOneTimeBuyFlag(data) {
        return ApiMemi(apiUrl.displayersSearchOnOneTimeBuyFlag, "POST", data);
    }

    static async displayersExceptionExcelDownload(data) {
        return ApiMemi(`${apiUrl.displayersExceptionExcelDownload}/${data.companyId}/${data.divisionId}/${data.deptCode}/${data.deptName}/${data.itemType}`, "GET", "", "arraybuffer");
    }

    static async loadSourceSimsItems(data) {
        return ApiMemi(apiUrl.loadSourceSimsItems, "POST", data);
    }

    static async unMarkDisplay(data) {
        return ApiMemi(apiUrl.unMarkDisplay, "POST", data);
    }

    static async uploadExceptionFile(data) {
        return ApiMemi(apiUrl.uploadExceptionFile, "POST", data);
    }

    static async uploadFile(data) {
        return ApiMemi(apiUrl.uploadFile, "POST", data);
    }

    static async markDisplay(data) {
        return ApiMemi(apiUrl.markDisplay, "POST", data);
    }

    static async displayersSearchOnReviewedItemDesc(data) {
        return ApiMemi(apiUrl.displayersSearchOnReviewedItemDesc, "POST", data);
    }

    static async displayersSearchOnReviewedProductSku(data) {
        return ApiMemi(apiUrl.displayersSearchOnReviewedProductSku, "POST", data);
    }

    static async displayersSearchOnReviewedOneTimeBuyFlag(data) {
        return ApiMemi(apiUrl.displayersSearchOnReviewedOneTimeBuyFlag, "POST", data);
    }

    static async undoDisplayersCompleted(data) {
        return ApiMemi(apiUrl.undoDisplayersCompleted, "POST", data);
    }

    static async getUOMList() {
        return ApiMemi(apiUrl.getUOMList, "GET")
    }
    static async markDead(data) {
        return ApiMemi(apiUrl.markDead, "POST", data);
    }

    static async postSaveOverideDetails(data) {
        return ApiMemi(apiUrl.postSaveOverideDetails, "POST", data);
    }

    static async getSmicDetail(groupCode, categoryCode, classCode, subClassCode) {
        return ApiMemi(apiUrl.getSmicDetail + `/${groupCode !== undefined ? groupCode : ""}${categoryCode !== undefined ? "/" + categoryCode : ""}${classCode !== undefined ? "/" + classCode : ""}${subClassCode != undefined ? "/" + subClassCode : ""}`, "GET");
    }

    static async getSmicDetails(grpCd, ctgryCd, clsCd, sbClsCd, subSbClass) {
        return ApiMemi(apiUrl.getSmicDetails + `${grpCd}/${ctgryCd}/${clsCd}/${sbClsCd}/${subSbClass}`, "GET");
    }

    static async getPrdctncdDetails(groupCode, categoryCode, classCode) {
        return ApiMemi(apiUrl.getPrdctnCdDetail + `/${groupCode !== undefined ? groupCode : ""}${categoryCode !== undefined ? "/" + categoryCode : ""}${classCode !== undefined ? "/" + classCode : ""}`, "GET");
    }

    static async multiUnitSourceSearch(data) {
        return ApiMemi(apiUrl.multiUnitSourceSearch, "POST", data);
    }

    static async markMultiUnitDead(data) {
        return ApiMemi(apiUrl.markMultiUnitDead, "POST", data);
    }

    static async markNotAMultiUnit(data) {
        return ApiMemi(apiUrl.markNotAMultiUnit, "POST", data);
    }

    static async listSrcOnTarSel(data) {
        return ApiMemi(apiUrl.listSrcOnTarSel, "POST", data);
    }

    static async markItemAsMultiUnit(data) {
        return ApiMemi(apiUrl.markItemAsMultiUnit, "POST", data);
    }

    static async multiUnitTargetSearch(data) {
        return ApiMemi(apiUrl.multiUnitTargetSearch, "POST", data);
    }

    static async listTargetOnSrcSel(data) {
        return ApiMemi(apiUrl.listTargetOnSrcSel, "POST", data);
    }

    static async mapMultiUnitItem(data) {
        return ApiMemi(apiUrl.mapMultiUnitItem, "POST", data);
    }

    static async getTargetProdClassValidate(prodClass, groupCode) {
        return ApiMemi(apiUrl.getTargetProdClassValidate + `/${prodClass}/${groupCode}`, "GET")
    }

    static async unMapMultiUnitItem(data) {
        return ApiMemi(apiUrl.unMapMultiUnitItem, "POST", data);
    }

    static async createNewCic(data) {
        return ApiMemi(apiUrl.createNewCic, "POST", data);
    }

    static async matchToSimsCic(data) {
        return ApiMemi(apiUrl.matchToSimsCic, "POST", data);
    }

    static async postLookUpExportExcel(data) {
        return ApiMemi(apiUrl.postLookUpExportIntoExcel, "POST", data, "arraybuffer")
    }

    static async loadMultiUnitSourceRefresh(company, division, matchIndicator) {
        return ApiMemi(apiUrl.loadMultiUnitSourceRefresh + `/${company}/${division}/${matchIndicator}`, "GET")
    }

    static async loadMultiUnitTargetRefresh(company, division, matchIndicator) {
        return ApiMemi(apiUrl.loadMultiUnitTargetRefresh + `/${company}/${division}/${matchIndicator}`, "GET")
    }

    static async loadMultiUnitTargetUpcPopUp(cic) {
        return ApiMemi(apiUrl.loadMultiUnitTargetUpcPopUp + `/${cic}`, "GET")
    }

    static async performButtonAction(actionsRequests, searchInputs) {
        const payload = {
            actionsRequests,
            searchInputs
        }

        return ApiMemi(apiUrl.performActionButton, "POST", payload)
    }

    static async getSourceDepartment(companyId, divisionId) {
        return ApiMemi(apiUrl.getSourceDepartment + `/${companyId}/${divisionId}`, "GET")
    }
    static async getTargetDepartment(companyId, divisionId) {
        return ApiMemi(apiUrl.getTargetDepartment + `/${companyId}/${divisionId}`, "GET")
    }

    static async bakerySourceList(data) {
        return ApiMemi(apiUrl.bakerySourceList, "POST", data);
    }

    static async bakeryTargetList(data) {
        return ApiMemi(apiUrl.bakeryTargetList, "POST", data);
    }

    static async bakeryactions(data) {
        return ApiMemi(apiUrl.bakeryactions, "POST", data);
    }

    static async matchingBakeryTargetList(data) {
        return ApiMemi(apiUrl.matchingBakeryTargetList, "POST", data);
    }

    static async loadOnMapEditFields(data) {
        return ApiMemi(apiUrl.loadOnMapEditFields, "POST", data);

    }
    static async mappingAction(data) {
        return ApiMemi(apiUrl.mappingAction, "POST", data)
    }

    static async ForceNewCategory(data) {
        return ApiMemi(apiUrl.ForceNewCategory, "POST", data)
    }

    static async changeExpenseType(data) {
        return ApiMemi(apiUrl.changeExpenseType, "POST", data)
    }

    static async getUPCListDetails(companyId, divisionId, sku, filterByStatus, itemType) {
        const payload = [
            String(companyId).toUpperCase(),
            String(divisionId).toUpperCase(),
            String(sku).toUpperCase(),
            String(filterByStatus).toUpperCase(),
            String(itemType).toUpperCase()
        ]
        return ApiMemi(apiUrl.getUPCListDetails, "POST", payload)
    }

    static async getMappedUPCListDetails(companyId, divisionId, sku, filterByStatus, itemType) {
        const payload = [
            String(companyId).toUpperCase(),
            String(divisionId).toUpperCase(),
            String(sku).toUpperCase(),
            String(filterByStatus).toUpperCase(),
            String(itemType).toUpperCase()
        ]
        return ApiMemi(apiUrl.getMappedUPCListDetails, "POST", payload)
    } F

    static async matchingTargetList(payload) {
        return ApiMemi(apiUrl.matchingTargetList, "POST", payload)
    }

    static async postSaveColumnCustomization(payload) {
        return ApiMemi(apiUrl.postSaveColumnCustomization, "POST", payload)
    }

    static async mappedList(payload) {
        return ApiMemi(apiUrl.mappedList, "POST", payload)
    }
    static async updateDepartment(payload) {
        return ApiMemi(apiUrl.updateDepartment, "POST", payload)
    }

    static async postSaveAugmentationDetails(data) {
        return ApiMemi(apiUrl.postSaveAugmentationDetails, "POST", data);
    }

    static async perishableForceNew(data) {
        return ApiMemi(apiUrl.perishableForceNew, "POST", data)
    }

    static async bakeryForceNew(data) {
        return ApiMemi(apiUrl.bakeryForceNew, "POST", data)
    }
}
