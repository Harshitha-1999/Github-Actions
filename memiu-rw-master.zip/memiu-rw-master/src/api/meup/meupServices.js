


import { ApiMemi } from '../../components/ApiCallsMemi/ApiCallsMemi'
import { MEUP_APIs } from '../../service/apiUrls'


export class meupServices {




    static async getDivisions() {
        return ApiMemi(MEUP_APIs.getDivisionList, "GET");
    }

    static async getStockingSections() {
        return ApiMemi(MEUP_APIs.division, "GET");
    }

    static async getAllItems(
        userId, country, selectedDivisions,
        selectedGroups, selectedCategories,
        cic, store, state, status, upc, deleteDateTo,
        deleteDateFrom, optionSearch) {
        // && 
        // 
        if (country && userId &&
            (selectedDivisions.length > 0 || selectedGroups.length > 0 || selectedCategories.length > 0 || cic || store || state || status || upc || deleteDateTo || deleteDateFrom)
        ) {

            const payload = {
                "userId": userId,
                "countryCd": country,
                "divisions": selectedDivisions !== undefined ? selectedDivisions.map((division) => { return { divisionNumber: division } }) : undefined,
                "groups": selectedGroups !== undefined ? selectedGroups.map((group) => { return { groupCd: group } }) : undefined,
                "categories": selectedCategories !== undefined ? selectedCategories.map((category) => { return { "categoryCd": category } }) : undefined,
                "cic": cic,
                "storeNumber": store,
                "state": state,
                "status": status,
                "upc": upc,
                "deleteDateStart": deleteDateTo,
                "deleteDateEnd": deleteDateFrom,
                "option": optionSearch,
                "userDto": {
                    "userId": userId,
                    "role": "divisionMgr",
                    "division": selectedDivisions !== undefined ? selectedDivisions.map((division) => { return { division } }) : undefined
                }
            }
            Object.keys(payload).forEach(key => {
                if (payload[key] === undefined || payload[key] === "") {
                    delete payload[key];
                }
            });
            return ApiMemi(
                MEUP_APIs.getAllItems,
                "POST",
                payload
            );
        } else {
            alert("please select at least other field with country")
        }
    }

    static async getListDisplayerData(data) {
        return ApiMemi(`${MEUP_APIs.listDisplayerData}/${data.company}/${data.division}`, "GET");
    }

    static async getDisplayersDownloadExcel(data) {
        return ApiMemi(`${MEUP_APIs.displayersDownloadExcel}/${data.company}/${data.division}/${data.deptCode}/${data.deptName}/${data.type}`, "GET", "blob");
    }

    static async getMemiu16LoadDeptWiseDisplayItem(data) {
        return ApiMemi(`${MEUP_APIs.getMemiu16LoadDeptWiseDisplayItem}/${data.company}/${data.division}/${data.deptCode}/Y/N/D`, "GET");
    }

    static async displayersSearchOnItemDesc(data) {
        return ApiMemi(MEUP_APIs.displayersSearchOnItemDesc, "POST", data);
    }

    static async displayersSearchOnProductSku(data) {
        return ApiMemi(MEUP_APIs.displayersSearchOnProductSku, "POST", data);
    }

    static async displayersSearchOnOneTimeBuyFlag(data) {
        return ApiMemi(MEUP_APIs.displayersSearchOnOneTimeBuyFlag, "POST", data);
    }

    static async displayersExceptionExcelDownload(data) {
        return ApiMemi(`${MEUP_APIs.displayersExceptionExcelDownload}/${data.companyId}/${data.divisionId}/${data.deptCode}/${data.deptName}/${data.itemType}`, "GET", "blob");
    }

    static async loadSourceSimsItems(data) {
        return ApiMemi(MEUP_APIs.loadSourceSimsItems, "POST", data);
    }

}
