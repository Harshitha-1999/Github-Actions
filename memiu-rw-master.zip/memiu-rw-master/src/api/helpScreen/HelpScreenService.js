import { DefaultAxios, getNoCacheHeaders } from 'api/util';
import { ENDPOINT_HELP } from 'api/constants';

export class HelpScreenService {

    static async getHelpContent(programName) {

        return await DefaultAxios.get(`${ENDPOINT_HELP}is01/${programName}`, {
            headers: await getNoCacheHeaders()
        });
    }

    //     static async getHelpContent(programName){
    //         return await Promise.resolve({
    //             "data": {
    //                 "helpContent" : 
    //                 `
    //                 <div style='margin-left: 2%'>
    //                 <h4 style='color: turquoise;text-align: center;'>FOC120A-Firm Order Details-Store </h4>
    //                 <p style='color:lime'>HELP information is available on the following topics for this screen.</p>
    //                 <p style='color: lime;'>Please click on any topic below to navigate.</p>
    //                 <div style = 'display: flex; margin-left: 15%; flex-direction: column; line-height: 1.5;'> 
    //                     <span> <a href='#1' style='text-decoration:underline;color:turquoise'>1.0 - Introduction</a> </span>
    //                     <span> <a href='#2' style='text-decoration:underline;color:turquoise'>2.0 - Screen fields</a> </span>
    //                     <span> <a href='#3' style='text-decoration:underline;color:turquoise'>3.0 - PF keys</a> </span>
    //                     <span> <a href='#4' style='text-decoration:underline;color:turquoise'> 4.0 - Bulletin</a> </span>
    //                     <span> <a href='#5' style='text-decoration:underline;color:turquoise'> 5.0 - Allocation</a> </span>
    //                     <span> <a href='#6' style='text-decoration:underline;color:turquoise'>6.0 - Continuity Count</a> </span>
    //                 </div>
    //                 <br>
    //                 <br>
    //                 <br>
    //                 <br>
    //                 <br>
    //                 <br>
    //                 <br>
    //                 <br>
    //                 <br>
    //             <h4 id='1' style='color: turquoise;text-align:left;'>1.0 - Introduction </h4>
    //             <p style='color:lime'>This screen lists all the items on the Firm Order. This is where you
    //                 enter the amount you want to order for a Bulletin, or the amount you
    //                 counted for a Continuity Count. You can see the amount you will be
    //                 receiving for an Allocation (distribution). You may place an order
    //                 for the Firm Order or change the amounts you order any time before
    //                 the ORDER DATE. If you place your order early and want to change it
    //                 you can do so on this screen.
    //             </p><br />
    //             <p style='color:lime'>The screen can contain one or more than fifty items. You may want to
    //                 print the bulletin before you order to get a picture of the entire
    //                 Firm Order. The printed order contains additional information that may
    //                 help your ordering. This screen cannot always show the entire item
    //                 comment (if comment is too long) but the printed report does.
    //             </p><br />
    //             <p style='color:lime'>Once you enter an amount for any item, the Firm Order is considered
    //                 Ordered. You do not have to enter the complete order at one time. If
    //                 you want to finish ordering a Firm order, list the Ordered Firm Orders,
    //                 select it and order. This is also how you can change the amounts you
    //             </p><br/>

    //             <p style='color:lime'>have ordered (before the Order Date).</p><br />
    //             <p style='color:lime'>If a restricted drug item is included in the Firm Order and your store
    //                 does not have a Pharmacy you will not be able to order the item.
    //             </p><br />
    //             <p style='color:lime'>To prevent you from accidentally ordering an amount far greater than you
    //                 wanted, you can set a limit (prompt level) for the number of cases you
    //                 can order for an item. You can set this from the Store System User
    //                 Defaults screen (from the Store Systems Menu). Enter the amount in the
    //                 Firm Order Prompt Quantity. If you set your prompt quantity to 10 and
    //                 enter 90 (instead of 9), the 90 will be highlighted and you will see
    //                 a message warning you that you are ordering a quantity greater than
    //                 you usually do for an item. This gives you a chance to correct the
    //                 amount - otherwise you would receive 90 cases of the item. If you
    //                 do not set a prompt quantity you will not get a warning message.
    //             </p>

    //             <h4 id='2' style='color: turquoise;text-align:left;'>2.0 - Screen fields</h4>
    //             <h4 style='color: turquoise;text-align:left;'>Total</h4>
    //             <div style='margin-left: 2%;margin-top:-2%'>
    //             <p style='color:lime'>This is the total number of cases in the Firm Order. The number is
    //                 either the number you entered for a Bulletin or the amount of the
    //                 Allocation. If the order is a Bulletin or a Continuity Count and
    //                 the total is unusually high, check each item's order amount.
    //             </p><br />
    //             </div>
    //             <h4 style='color: turquoise;text-align:left;'>Page</h4>
    //             <div style='margin-left: 2%;margin-top:-2%'>
    //             <p style='color:lime'>This is page of the Firm Order you are on. This is not the same as
    //                 the page number on the printed Firm Order Items - Store report since
    //                 the report can have more items per page.
    //             </p><br />
    //             </div>
    //             <h4 style='color: turquoise;text-align:left;'>Corp Cd</h4>
    //             <div style='margin-left: 2%;margin-top:-2%'>
    //                 <p style='color:lime'>This is the item code of the item on the Firm Order.</p>
    //             </div >
    //             <h4 style='color: turquoise;text-align:left;'>Item Desc</h4>
    //             <div style='margin-left: 2%;margin-top:-2%'>
    //             <p style='color:lime'>This is the description of the item on the Firm Order. If there is
    //                 a comment for the item it will appear above the Item Desc.
    //             </p><br />
    //             </div>
    //             <h4 style="color: turquoise;text-align:left;">Pack-Size</h4>
    //             <div style="margin-left: 2%; margin-top:-2%;">
    //                 <p style="color:lime">This is the pack and size of the item.</p> </div>
    //             <h4 style="color: turquoise;text-align:left;">Cost</h4>
    //             <div style="margin-left: 2%;margin-top:-2%">
    //                 <p style="color:lime;">This is the Item Billing Cost of the item.</p>
    //             </div>
    //             <h4 style="color: turquoise;text-align:left;">Retail</h4>
    //             <div style="margin-left: 2%;margin-top:-2%">
    //                 <p style="color:lime">This is the Retail the item will sell for in your store.</p>
    //             </div>
    //             <h4 style="color: turquoise;text-align:left;">BG%</h4>
    //             <div style="margin-left: 2%;margin-top:-2%">
    //                 <p style="color:lime">This is the Billing Gross Percentage for the item.</p></div>
    //             <h4 style="color: turquoise;text-align:left;">Order</h4>
    //             <div style="margin-left: 2%;margin-top:-2%">
    //             <p style="color:lime">This is where you enter the amount you want to order for an item on
    //                 a Bulletin. If this is a Continuity Count, you enter the item count.
    //                 If you are looking at an Allocation(Distribution), this is the amount
    //                 you will receive.
    //             </p>
    //             </div>

    //             <h4 id='2' style='color: turquoise;text-align:left;'>2.0 - PF keys</h4>
    //             <p style='color:lime'>The Program Function keys (PF or F Keys) available on the Firm Order
    //             Details - Store screen perform the following functions:</p>
    //             <table style='width:50%'>
    //                 <tr ><td style='color:turquoise;vertical-align: top;'>F1</td ><td style='color:lime;vertical-align: top;'>Help</td><td style='color:lime;'>- If you have any questions, press F1 for Help.
    //                     <span style='margin-left:2%;'> Note: You are currently in the Help function.</span></td></tr>
    //                 <tr ><td style='color:turquoise;vertical-align: top;'>F2</td ><td style='color:lime;vertical-align: top;'>Exit</td><td style='color:lime;'>- Press F2 to return to Firm Order List - Store.</td></tr>
    //                 <tr ><td style='color:turquoise;vertical-align: top;'>F5</td ><td style='color:lime;vertical-align: top;'>Refresh</td><td style='color:lime;'>- Press F5 to refresh the screen. This resets the
    //                     <span style='margin-left:2%;'> screen and displays the previous data.</span></td></tr>
    //                 <tr ><td style='color:turquoise;vertical-align: top;'>F7</td ><td style='color:lime;vertical-align: top;'>Backward</td><td style='color:lime;'>- Press F7 to view the previous screen of data.
    //                     <span style='margin-left:2%;'>  If you are on Page 1 this will have no effect.</span></td></tr>
    //                 <tr ><td style='color:turquoise;vertical-align: top;'>F8</td ><td style='color:lime;vertical-align: top;'>Forward</td><td style='color:lime;'>- Press F8 to view the next screen of data.
    //                     <span style='margin-left:2%;'>  If there is no more data this will have no effect</span> </td></tr>
    //                 <tr ><td style='color:turquoise;vertical-align: top;'>F10</td ><td style='color:lime;vertical-align: top;'>No Order</td><td style='color:lime;'>- Press F10 to indicate that you want nothing for</td></tr>
    //             </table>





    //             <span style='color:lime;margin-left: 9%;'>the Firm Order. You cannot use this key if the<br /></span>
    //                 <span style='color:lime;margin-left: 9%;'>  amount does not total zero, or the order is an<br /></span>
    //                 <span style='color:lime;margin-left: 9%;'>Allocation.</span>




    //                 <h4 id='4' style='color:turquoise;text-align: left;'>4.0 - Bulletin</h4>
    //                 <p style='color:lime;'>You must place an order for every Bulletin even if it is a No-Order.
    // Enter the amount that you want to receive for each item. If you do
    // not want any of the items, press F10 (No-Order). This tells the
    // office (backstage) that you have looked at the Firm Order and do not
    // want any of the items.</p>
    //                 <p style='color:lime;'>If you do not respond to an order (by ordering or by specifying
    // No-Order) the office may assume you have not seen the order and may
    // arbitrarily send you cases of the item(s). For this reason, it is
    // important to review the Outstanding Firm Orders at least once a day.</p>






    //                 <h4 id='5' style='color:turquoise;text-align: left;'>5.0 - Allocation</h4>
    //                 <p style='color:lime;'>This shows you the amount you will receive for an item. You cannot
    // change the amount you will receive. You can print the Allocation to
    // see the items and amounts you will receive. An Allocation is also
    // referred to as a Distribution.</p>





    //                 <h4 id='6' style='color:turquoise;text-align: left;'>6.0 - Continuity Count</h4>
    //                 <p style='color:lime;'>You are asked to count the quantity you have in the store for each item
    //                 on the order. Enter the count of each item before the Order Date. You
    //                 can use F10 (No-Order) if you have zero quantity of all items.
    //                 NOTE: You are not ordering items, you are only counting: you will not
    //                 receive any of these items.</p>

    //                 </div>
    //                 `
    //             }
    //         })
    //     }
}

export default HelpScreenService;