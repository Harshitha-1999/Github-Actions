import { DefaultAxios, getNoCacheHeaders } from "api/util";
import { ENDPOINT_ISC020, ENDPOINT_ISC020_DELETE } from "api/constants";

export class ISC020AService {
  static async getISC020AOnLoad() {
    let requestBody = {
      userDefaultsRequest: {
        appCode: "IS02",
      },
    };

    return await DefaultAxios.post(`${ENDPOINT_ISC020}`, requestBody, {
      headers: await getNoCacheHeaders(),
    });
  }

  static async getISC020AOnTransaction(
    countryCode,
    corporation,
    division,
    operationFacility,
    foPromptQuantity
  ) {
    let requestBody = {
      userDefaultsRequest: {
        appCode: "IS02",
        country: countryCode,
        corporation: corporation,
        division: division,
        facility: operationFacility,
        foPromptQuantity: foPromptQuantity,
      },
    };

    return await DefaultAxios.put(`${ENDPOINT_ISC020}`, requestBody, {
      headers: await getNoCacheHeaders(),
    });
  }

  static async getISC020Delete(userDefaultsId) {
    let requestBody = {
      data: {
        userDefaultsRequest: {
          appCode: "IS02",
        },
      },
      headers: await getNoCacheHeaders(),
    };
    return await DefaultAxios.delete(
      `${ENDPOINT_ISC020_DELETE}/${userDefaultsId}`,
      requestBody
    );
  }
}
