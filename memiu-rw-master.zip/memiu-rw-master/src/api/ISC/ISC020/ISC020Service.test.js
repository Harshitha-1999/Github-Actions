import { ISC020AService } from './ISC020Service';
import { DefaultAxios } from 'api/util/axios-instances/DefaultAxios';

describe('ISC020Service class', () => {
    let axiosPostSpy = jest.spyOn(DefaultAxios, 'post').mockResolvedValue(true);
    let axiosPutSpy = jest.spyOn(DefaultAxios, 'put').mockResolvedValue(true);
    let axiosDeleteSpy = jest.spyOn(DefaultAxios, 'delete').mockResolvedValue(true);

    afterEach(() => {
        jest.clearAllMocks();
    })

    it('Should call the getISC020AOnLoad function', async () => {
        await ISC020AService.getISC020AOnLoad();
        expect(axiosPostSpy).toHaveBeenCalled();
    });

    it('Should call the getISC020AOnTransaction function', async () => {
        await ISC020AService.getISC020AOnTransaction();
        expect(axiosPutSpy).toHaveBeenCalled();
    });

    it('Should call the getISC020Delete function', async () => {
        await ISC020AService.getISC020Delete();
        expect(axiosDeleteSpy).toHaveBeenCalled();
    });
})