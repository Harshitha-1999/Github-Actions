import { DefaultAxios, getNoCacheHeaders } from 'api/util';
import { ENDPOINT_ISC010 } from 'api/constants';

export class ISC010Service {

    // static async getISC010OnLoad() {
    //     let buildUrl = `${ENDPOINT_ISC010}mode=load&programId=ISC010`;

    //     return await DefaultAxios.get(buildUrl);

    // }

    static async getISC010OnLoad() {
        let RequestBody = {
            "appCode": "IS01"
        }
        return await DefaultAxios.post(ENDPOINT_ISC010, RequestBody, {
            headers: await getNoCacheHeaders()
        });
    }

}
