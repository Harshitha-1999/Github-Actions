import { PSC720Service } from './PSC720Service';
import { DefaultAxios } from 'api/util/axios-instances/DefaultAxios';

const psc700values =
{
    corp: "001",
    div: "19",
    fac: "2604",
    rog: "",
    smic1: "",
    smic2: "",
    smic3: "",
    smic4: "",
    pcc1: "",
    pcc2: "",
    cic: "",
    upc1: "",
    upc2: "",
    upc3: "",
    upc4: "",
    upc5: "",
    plu1: "",
    plu2: "",
    itemDesc: "",
    retailSec: "",
    pageSize: "",
    pageNumber: "",
    prxPlu: ""
}

describe('PSC720Service class', () => {
    let axiosPostSpy = jest.spyOn(DefaultAxios, 'post').mockResolvedValue(true);


    afterEach(() => {
        jest.clearAllMocks();
    })

    it('Should call the getPSC720OnLoad function', async () => {
        await PSC720Service.getPSC720OnLoad(psc700values);
        expect(axiosPostSpy).toHaveBeenCalled();
    });


})