import { DefaultAxios, getNoCacheHeaders } from 'api/util';
import { ENDPOINT_PSC720 } from 'api/constants';

export class PSC720Service {

    static async getPSC720OnLoad(requestParams) {
        let requestBody =
        {
            "productInquiryInformationDisplayRequest":
            {
                "corp": requestParams.corp,
                "div": requestParams.div,
                "fac": requestParams.fac,
                "rog": requestParams.rog,
                "groupStart": requestParams.smic1,
                "groupEnd": requestParams.smic3,
                "categoryStart": requestParams.smic2,
                "categoryEnd": requestParams.smic4,
                "productClasscodeStart": requestParams.pcc1,
                "productClasscodeEnd": requestParams.pcc2,
                "upcCountry": requestParams.upc1,
                "upcSystem": requestParams.upc2,
                "upcManuf": requestParams.upc3,
                "upcUnitCodeStart": requestParams.upc4,
                "upcUnitCodeEnd": requestParams.upc5,
                "corpItemCd": requestParams.cic,
                "appCode": "psc",
                "optionSelected": requestParams.inputflag,
                "upcSales": requestParams.upcSales,
                "itemSect": requestParams.retailSec,
                "itemDescScan": requestParams.itemDesc,
                "pageSize": requestParams.pageSize,
                "pageNumber": requestParams.pageNumber,
                "pluStart": requestParams.plu1,
                "pluEnd": requestParams.plu2,
                "prxPlu": requestParams.pluCd
            }
        }
        return await DefaultAxios.post(`${ENDPOINT_PSC720}`, requestBody, {
            headers: await getNoCacheHeaders()
            // headers: {userId:'PS00000'}
        });
    }



}
