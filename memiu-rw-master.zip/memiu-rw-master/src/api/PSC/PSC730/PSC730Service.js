import { DefaultAxios, getNoCacheHeaders } from "api/util";
import { ENDPOINT_PSC730 } from "api/constants";

export class PSC730Service {
  static async getPSC730OnLoad(psc710ValuesTo730) {


    let requestBody = {

      productGeneralInformationRequest:
      {

        "corpItemCd": psc710ValuesTo730.corpItemCd,
        "rog": psc710ValuesTo730.rog,
        "upcManuf": psc710ValuesTo730.upcManf,
        "upcSales": psc710ValuesTo730.upcSales,
        "upcCountry": psc710ValuesTo730.upcCountry,
        "upcSystem": psc710ValuesTo730.upcSystem,
        "unitType": psc710ValuesTo730.unitType,
        "corp": psc710ValuesTo730.corp,
        "division": psc710ValuesTo730.division,
        "facility": psc710ValuesTo730.facility,
        "retailSelect": psc710ValuesTo730.retailSect,
        "currentDate": psc710ValuesTo730.currentDate,
        "priceArea": psc710ValuesTo730.priceAreaDetails
      }
    }

    return await DefaultAxios.post(`${ENDPOINT_PSC730}/general`, requestBody, {
      headers: await getNoCacheHeaders()
    });


  }

  static async getPSC730ItemMovementOnload(itemMovementRequest) {
    let requestBody =
    {
      "itemMovementRequest":
      {
        "appCode": itemMovementRequest.appCode,
        "rog": itemMovementRequest.rog,
        "facility": itemMovementRequest.facility,
        "upcManuf": itemMovementRequest.upcManuf,
        "upcCountry": itemMovementRequest.upcCountry,
        "upcSales": itemMovementRequest.upcSales,
        "upcSystem": itemMovementRequest.upcSystem,
        "corpItemCode": itemMovementRequest.corpItemCode,
        "mdyWeekNum": itemMovementRequest.mdyWeekNum,
        "mdyYear": itemMovementRequest.mdyYear,
        "prevYearMaxWeekNum": itemMovementRequest.prevYearMaxWeekNum
      }
    }
    return await DefaultAxios.post(`${ENDPOINT_PSC730}/item-movement`, requestBody, {
      headers: await getNoCacheHeaders()
    });
  }

  // wareHouseRequest

  static async getPSC730WareHouseOnload(wareHouseRequest, page) {
    let requestBody =
    {
      "wareHouseRequest":
      {
        "appCode": wareHouseRequest.appCode,
        "corporation": wareHouseRequest.corporation,
        "division": wareHouseRequest.division,
        "facility": wareHouseRequest.facility,
        "rog": wareHouseRequest.rog,
        "corpItemCode": wareHouseRequest.corpItemCode,
        "retailSector": wareHouseRequest.retailSector,
        "itemOnNewDsdSw": wareHouseRequest.itemOnNewDsdSw,
        "dtlProcessTypeInd": wareHouseRequest.dtlProcessTypeInd,
        "processDsdItem": wareHouseRequest.processDsdItem,
        "pageNumber": page,
        "pageSize": wareHouseRequest.pageSize
      }

    }
    return await DefaultAxios.post(`${ENDPOINT_PSC730}/warehouse-vendor`, requestBody, {
      headers: await getNoCacheHeaders()
    });
  }


  static async getPSC730PricingOnload(pricingRequest) {

    let requestBody = {
      "productPricingInformationRequest": {
        "corpItemCd": pricingRequest.dtlCic,
        "rog": pricingRequest.rog,
        "upcManuf": pricingRequest.dtlUpcManuf,
        "upcSales": pricingRequest.dtlUpcUnit,
        "upcCountry": pricingRequest.dtlUpcCtryCd,
        "upcSystem": pricingRequest.dtlUpcSysCd,
        "facility": pricingRequest.fac,
        "retailSelect": pricingRequest.dtlRetailSect,
        "currentDate": pricingRequest.currenDate,
        "priceArea": pricingRequest.dtlPriceArea,
        "processTypeIndi": pricingRequest.dtlProcessTypeInd,
        "storeType": pricingRequest.storeType,
        "corp": pricingRequest.corp,
        "division": pricingRequest.div,
        "whsDSD": "W",
        "weekStart": pricingRequest.weekStart,
        "weekEnd": pricingRequest.weekEnd,
        "retrieveCostBg": "N"
      }
    }

    return await DefaultAxios.post(`${ENDPOINT_PSC730}/pricing`, requestBody, {
      headers: await getNoCacheHeaders()
    });

  }

  static async getPSC730PricingOnTransaction(pricingRequest, ib_cost, prx_both_whs_dsd_sw, currentPriceRequest) {

    let requestBody = {
      "productPricingInformationRequest": {
        "ibCost": ib_cost,
        "corpItemCd": pricingRequest.dtlCic,
        "rog": pricingRequest.rog,
        "upcManuf": pricingRequest.dtlUpcManuf,
        "upcSales": pricingRequest.dtlUpcUnit,
        "upcCountry": pricingRequest.dtlUpcCtryCd,
        "upcSystem": pricingRequest.dtlUpcSysCd,
        "facility": pricingRequest.fac,
        "retailSelect": pricingRequest.dtlRetailSect,
        "currentDate": pricingRequest.currenDate,
        "priceArea": pricingRequest.dtlPriceArea,
        "processTypeIndi": pricingRequest.dtlProcessTypeInd,
        "storeType": pricingRequest.storeType,
        "corp": pricingRequest.corp,
        "division": pricingRequest.div,
        "whsDSD": prx_both_whs_dsd_sw,
        "weekStart": pricingRequest.weekStart,
        "weekEnd": pricingRequest.weekEnd,
        "currentPrice": currentPriceRequest.currentPrice,
        "currentFactor": currentPriceRequest.currentFactor,
        "currentOtlPrice": currentPriceRequest.currentOTLPrice,
        "currentOtlFactor": currentPriceRequest.currentOTLFactor,
        "currentOtlMethod": currentPriceRequest.currentOTLMethod,
        "retrieveCostBg": "Y"
      }
    }

    return await DefaultAxios.post(`${ENDPOINT_PSC730}/pricing`, requestBody, {
      headers: await getNoCacheHeaders()
    });

  }

}
