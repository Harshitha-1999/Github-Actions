import { PSC710Service } from './PSC710Service';
import { DefaultAxios } from 'api/util/axios-instances/DefaultAxios';

const psc700values =
{
    corp: "001",
    div: "19",
    fac: "2604",
    rog: "",
    smic1: "",
    smic2: "",
    smic3: "",
    smic4: "",
    pcc1: "",
    pcc2: "",
    cic: "",
    upc1: "",
    upc2: "",
    upc3: "",
    upc4: "",
    upc5: "",
    plu1: "",
    plu2: "",
    itemDesc: "",
    retailSec: "",
    pageSize: "",
    pageNumber: "",
}

describe('PSC710Service class', () => {
    let axiosPostSpy = jest.spyOn(DefaultAxios, 'post').mockResolvedValue(true);


    afterEach(() => {
        jest.clearAllMocks();
    })

    it('Should call the getPSC710OnLoad function', async () => {
        await PSC710Service.getPSC710OnLoad(psc700values);
        expect(axiosPostSpy).toHaveBeenCalled();
    });


})