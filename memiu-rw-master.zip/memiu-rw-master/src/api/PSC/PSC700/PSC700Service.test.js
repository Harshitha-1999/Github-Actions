import { PSC700Service } from './PSC700Service';
import { DefaultAxios } from 'api/util/axios-instances/DefaultAxios';

describe('PSC700Service class', () => {
    let axiosPostSpy = jest.spyOn(DefaultAxios, 'post').mockResolvedValue(true);
    let axiosPutSpy = jest.spyOn(DefaultAxios, 'put').mockResolvedValue(true);
    let axiosDeleteSpy = jest.spyOn(DefaultAxios, 'delete').mockResolvedValue(true);

    afterEach(() => {
        jest.clearAllMocks();
    })

    it('Should call the getPSC700AOnLoad function', async () => {
        await PSC700Service.getPSC700AOnLoad();
        expect(axiosPostSpy).toHaveBeenCalled();
    });

    it('Should call the getPSC700AOnTransaction function', async () => {
        await PSC700Service.getPSC700AOnTransaction();
        expect(axiosPutSpy).toHaveBeenCalled();
    });
})