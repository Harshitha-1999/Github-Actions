import { DefaultAxios, getNoCacheHeaders } from 'api/util';
import { ENDPOINT_PSC700 } from 'api/constants';

export class PSC700Service {

    // static async getPSC700Load(userId, programId) {
    //     return await Promise.resolve({

    //         "pscOnScreen700Response":
    //         {
    //             "comdytbl":
    //             {
    //                 "pspixMdyYear": "<value>",
    //                 "pspixMdyWeekNum": "<value>",
    //                 "pspixCurrentDate": "<value>",
    //                 "pspixWeekEnd": "<value>",
    //                 "pspixWeekStart": "<value>"
    //             },
    //             "coyrinfo":
    //             {
    //                 "yriLtWkNum": "<value>"
    //             },
    //             "pspiopt":
    //             {
    //                 "pspioptInclDescScanSw": "<value>"
    //             },
    //             "user":
    //             {
    //                 "isuserCorp": "001",
    //                 "isuserDiv": "19",
    //                 "isuserFac": "2604"
    //             },
    //             "ssstoctl":
    //             {
    //                 "stoRog": "<value>"
    //             },
    //             "corogtab":
    //             {
    //                 "rgtCountryCd": "<value>",
    //                 "rgtType": "<value>"
    //             },

    //         }
    //     })
    // }

    static async getPSC700AOnLoad() {
        let requestBody =
        {

            "productInquiryMenuRequest": {
                "appCode": "IS01",
                "corp": "test",
                "division": "test",
                "facility": "test",
                "sect": "",
                "sectType": ""

            }


        }

        return await DefaultAxios.post(`${ENDPOINT_PSC700}`, requestBody, {
            headers: await getNoCacheHeaders()
        });
    }

    static async getPSC700AOnTransaction(Corporation, Division, Facility, itemSect = "", sectType = "") {

        let requestBody = {

            "productInquiryMenuRequest": {
                "appCode": "IS01",
                "corp": Corporation,
                "division": Division,
                "facility": Facility,
                "sect": itemSect,
                "sectType": sectType
            }
        }

        return await DefaultAxios.put(`${ENDPOINT_PSC700}`, requestBody, {
            headers: await getNoCacheHeaders()
        });

    }

}
