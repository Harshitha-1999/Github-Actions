import { Environment } from "utils";

export const LOGIN_ROOT = `${Environment.getLoginUrl()}`;
export const API_ROOT = `${Environment.getApiUrl()}`;
export const API_ACCESS_DETAILS_ROOT = `${Environment.getAccessDetailsUri()}`;
export const API_HELP_SCREEN_ROOT = `${Environment.getHelpScreenApiUri()}`;

//export const API_ROOT = "https://apim-dev-01.albertsons.com/abs/dev/metrc";
//export const LOGIN_ROOT = "https://is01.dev.aks.platform.albertsons.com";
//export const LOGIN_ROOT = "http://localhost:7000";
//export const API_ACCESS_DETAILS_ROOT = `https://sims.dev.aks.platform.albertsons.com/sims-common-security/allFieldLevelAccess`;

//accessDetails
export const ENDPOINT_ACCESS_DETAILS = `${API_ACCESS_DETAILS_ROOT}/allScreenLevelAccess`;

//fieldDetails
export const ENDPOINT_FIELD_DETAILS = `${API_ACCESS_DETAILS_ROOT}/allFieldLevelAccess/IS01`;

//accessDetails old code before merge change
//export const ENDPOINT_ACCESS_DETAILS = `${API_ACCESS_DETAILS_ROOT}/IS01`;

//Add your on load storesystems endpoints
//ISC010
export const ENDPOINT_ISC010 = `${API_ROOT}/user-service/store-systems/menu`;

//helpscreen
export const ENDPOINT_HELP = `${API_HELP_SCREEN_ROOT}/help-service/`;

//ISC020
export const ENDPOINT_ISC020 = `${API_ROOT}/user-service/store-systems/user-defaults`;
export const ENDPOINT_ISC020_DELETE = `${API_ROOT}/user-service/store-systems/user-defaults/users`;

//PSC700
export const ENDPOINT_PSC700 = `${API_ROOT}/product-service/products/search-criteria`;
//PSC720
export const ENDPOINT_PSC720 = `${API_ROOT}/product-service/products/plu`;
//PSC710
export const ENDPOINT_PSC710 = `${API_ROOT}/product-service/products`;
//PSC730
//export const ENDPOINT_PSC730 = `${API_ROOT}/psc-service/screen730?`;
export const ENDPOINT_PSC730 = `${API_ROOT}/product-service/products/product`;
//

export const AXIOS_RETRY_COUNT = 2;

export const AXIOS_RETRY_CODES = [408, 500, 502, 503, 504, 522, 524];

export const REQUEST_TIMEOUT_LENGTH = 70000;




