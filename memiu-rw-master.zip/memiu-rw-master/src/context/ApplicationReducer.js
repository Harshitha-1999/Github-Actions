
import {
  ADD_DATA,
  DELETE_DATA,
  SET_DATA,
  ADD_USERINFO,
  SET_USERINFO,
  ADD_LASTSEARCH,
  SET_LASTSEARCH,
  ADD_MEMI01,
  SET_MEMI01,
  SET_MEMI08,
  ADD_MEMI08,
  SET_MEMI13,
  ADD_MEMI13,
  SET_MEMI20,
  SET_MEMI21_SOURCE_ITEMS,
  SET_MEMI21_TARGET_ITEMS,
  SET_MEMI22,
  SET_MEMIMenu,
  ADD_MEMIMenu,
  SET_CONFIGURATION_SETS,
  ADD_CONFIGURATION_SETS,
  SET_MEMI14,
  ADD_MEMI17,
  SET_MEMI17,
  SET_MEMI18,
  ADD_MEMI23,
  SET_MEMI23,
  ADD_MEMI24_A,
  SET_MEMI24_A,
  SET_CONFIGURATION_VARS,
  ADD_CONFIGURATION_VARS,
  ADD_MEMI24_B,
  SET_MEMI24_B,
  ADD_MEMI24_C,
  SET_MEMI24_C,
  SET_COMPANYID,
  SET_DIVISIONID,
  SET_ALERTBOX,
  SET_ALERTMESSAGE,
  SET_COMPANIES,
  SET_DIVISIONS,
  SET_TABLEMODAL,
  SET_DEPARTMENT,
  SET_LOOKUPSCREEN,
  SET_MEMI06,
  SET_LIST_DISPLAYER_DATA,
  SET_MEMI16_DATA,
  SET_MEMI16_CRITERIA,
  SET_SELECTED_ROWS,
  SET_FILEUPLOADMODAL,
  SET_FILEUPLOAD_DATA,
  SET_SELECTED_CRITERIA_SEARCH,
  SET_SELECTED_CRITERIA,
  SET_UOM_LIST,
  SET_CONFIRMATION_MODAL,
  SET_CONFIRMATION_MODAL_SEARCH,
  SET_UPDATEOVERIDESKU,
  SET_UPDATEOVERRIDEMANUALSEARCH,
  SET_SMIC_DETAILS,
  SET_MULTIUNIT_SRC_FILTER,
  SET_MULTIUNIT_TARGET_FILTER,
  SET_SOURCE_DEPARTMENT,
  SET_TARGET_DEPARTMENT,
  SET_MULTIUNIT_FILTER_DEPTNAME,
  SET_MULTIUNIT_FILTER_RETAILSECTION,
  SET_MULTIUNIT_SRC_DATA,
  SET_MULTIUNIT_TARGET_DATA,
  SET_MEMI03_SKU,
  SET_MEMI03_CIC,
  SET_MEMI03_SKU_SELECTED,
  SET_MEMI03_CIC_SELECTED,
  SET_MEMI03_CIC_PAYLOAD,
  SET_MEMI03_SKU_PAYLOAD,
  SET_MAPPING_MODAL,
  SET_UPDATEAUGMENTATIONSKU,
  SET_UPDATEAUGMENTATIONMANUALSEARCH,
  SET_LOADER,
  ADD_LOADER,
  SET_GROUP_DETAIL,
  SET_PRODUCTION_GROUP_DETAIL,
  SET_LOG_STATUS,
  SET_FULL_LOG_STATUS,
  SET_LOG_STATUS_RESULT,
  SET_AUGMENTATION_SERVICE_KEY,
  SET_OVERIDE_SERVICE_KEY,
  SET_AUGMENTATION_SERVICE_DEPARTMENT,
  SET_APP_STATE,
  ADD_APP_STATE,
  SET_OVERIDE_SERVICE_USAGE_TYPE,
  SET_AUGMENTATION_SERVICE_USAGE_TYPE
} from "./ApplicationConstants";

export const ApplicationReducer = (state, action) => {
  switch (action.type) {

    case SET_LOG_STATUS_RESULT:
      //console.log("reducer Log Status Result");
      // console.log("reducer Log Status value Result" + action.payload);
      return {
        ...state,
        logStatusResult: action.payload,
      };

    case SET_LOG_STATUS:
      //console.log("reducer Log Status");
      // console.log("reducer Log Status value" + action.payload);
      return {
        ...state,
        logStatus: action.payload,
      };
    case SET_FULL_LOG_STATUS:
      //  console.log("reducer Full Log Status loader");
      //  console.log("reducer Full Log Status loader value" + action.payload);
      return {
        ...state,
        fullLogStatus: state.fullLogStatus + action.payload,
      };
    case SET_LOADER:
      return {
        ...state,
        loader: action.payload,
      };
    case ADD_LOADER:
      return {
        ...state,
        loader: state.loader > 0 ? state.loader + action.payload : action.payload
      }
    case SET_DATA:
      return {
        ...state,
        data: action.payload,
      };
    case ADD_DATA:
      return {
        ...state,
        data: [...state.data, action.payload],
      };
    case DELETE_DATA:
      return {};
    case SET_USERINFO:
      return {
        ...state,
        userInfo: action.payload,
      };
    case ADD_USERINFO:
      return {
        ...state,
        userInfo: [...state.userInfo, action.payload],
      };
    case SET_LASTSEARCH:
      return {
        ...state,
        lastSearch: action.payload,
      };
    case ADD_LASTSEARCH:
      return {
        ...state,
        lastSearch: [...state.lastSearch, action.payload],
      };
    case SET_MEMI01:
      return {
        ...state,
        memi01: action.payload,
      };

    case SET_MEMI08:
      return {
        ...state,
        memi08: action.payload,
      };

    case SET_MEMI13:
      return {
        ...state,
        memi13: action.payload,
      };
    case SET_MEMI20:
      return {
        ...state,
        memi20: action.payload,
      };
    case SET_MEMI14:
      return {
        ...state,
        memi14: action.payload,
      };
    case SET_MEMI17:
      return {
        ...state,
        memi17: action.payload,
      };
    case SET_MEMI18:
      return {
        ...state,
        memi18: action.payload,
      };
    case SET_MEMI23:
      return {
        ...state,
        memi23: action.payload,
      };
    case SET_MEMI24_A:
      return {
        ...state,
        memi24_A: action.payload,
      };
    case SET_MEMI24_B:
      return {
        ...state,
        memi24_B: action.payload,
      };
    case SET_MEMI24_C:
      return {
        ...state,
        memi24_C: action.payload,
      };

    case SET_MEMI21_SOURCE_ITEMS:
      return {
        ...state,
        memi21_sourceItems: action.payload,
      };
    case SET_MEMI21_TARGET_ITEMS:
      return {
        ...state,
        memi21_targetItems: action.payload,
      };
    case SET_MEMI22:
      return {
        ...state,
        memi22: action.payload,
      };

    case ADD_MEMI01:
      return {
        ...state,
        memi01: [...state.memi01, action.payload],
      };
    case ADD_MEMI08:
      return {
        ...state,
        memi08: [...state.memi08, action.payload],
      };
    case ADD_MEMI13:
      return {
        ...state,
        memi13: [...state.memi13, action.payload],
      };
    case SET_MEMIMenu:
      return {
        ...state,
        configure: action.payload
      };
    case ADD_MEMIMenu:
      return {
        ...state,
        configure: [...state.configure, action.payload],
      }

    case SET_CONFIGURATION_SETS:
      return {
        ...state,
        configurationSets: action.payload,
      };
    case ADD_CONFIGURATION_SETS:
      return {
        ...state,
        configurationSets: [...state.configurationSets, action.payload],
      };


    case SET_CONFIGURATION_VARS:
      return {
        ...state,
        configurationVars: action.payload,
      };
    case ADD_CONFIGURATION_VARS:
      return {
        ...state,
        configurationVars: [...state.configurationVars, action.payload],
      };


    case ADD_MEMI17:
      return {
        ...state,
        memi17: [...state.memi17, action.payload],
      };
    case ADD_MEMI23:
      return {
        ...state,
        memi23: [...state.memi23, action.payload],
      };
    case ADD_MEMI24_A:
      return {
        ...state,
        memi24_A: [...state.memi24_A, action.payload],
      };
    case ADD_MEMI24_B:
      return {
        ...state,
        memi24_B: [...state.memi24_B, action.payload],
      };
    case ADD_MEMI24_C:
      return {
        ...state,
        memi24_C: [...state.memi24_C, action.payload],
      };
    case SET_ALERTBOX:
      return {
        ...state,
        alertBox: action.payload
      }
    case SET_ALERTMESSAGE:
      return {
        ...state,
        alertMessage: action.payload
      }
    case SET_TABLEMODAL:
      return {
        ...state,
        tableModal: action.payload
      }
    case SET_COMPANYID:
      return {
        ...state,
        companyId: action.payload
      }
    case SET_DIVISIONID:
      return {
        ...state,
        divisionId: action.payload
      }
    case SET_COMPANIES:
      return {
        ...state,
        companies: action.payload
      }
    case SET_DIVISIONS:
      return {
        ...state,
        divisions: action.payload
      }
    case SET_DEPARTMENT:
      return {
        ...state,
        department: action.payload
      }
    case SET_LOOKUPSCREEN:
      return {
        ...state,
        lookUpScreen: action.payload
      }
    case SET_MEMI06:
      return {
        ...state,
        memi06: action.payload
      }
    case SET_LIST_DISPLAYER_DATA:
      return {
        ...state,
        listDisplayerData: action.payload
      }
    case SET_MEMI16_DATA:
      return {
        ...state,
        memi16Data: action.payload
      }
    case SET_MEMI16_CRITERIA:
      return {
        ...state,
        memi16Criteria: action.payload
      }
    case SET_SELECTED_ROWS:
      return {
        ...state,
        rowData: action.payload,
      };
    case SET_FILEUPLOADMODAL:
      return {
        ...state,
        fileUpload: action.payload
      }
    case SET_FILEUPLOAD_DATA:
      return {
        ...state,
        fileUploadData: action.payload
      }
    case SET_SELECTED_CRITERIA_SEARCH:
      return {
        ...state,
        selectedCriteriaSearch: action.payload
      }
    case SET_SELECTED_CRITERIA:
      return {
        ...state,
        selectedCriteria: action.payload
      }
    case SET_UOM_LIST:
      return {
        ...state,
        uomList: action.payload
      }

    case SET_CONFIRMATION_MODAL:
      return {
        ...state,
        confirmationModal: action.payload
      }
    case SET_CONFIRMATION_MODAL_SEARCH:
      return {
        ...state,
        confirmationModalSearch: action.payload
      }

    case SET_UPDATEOVERIDESKU:
      return {
        ...state,
        updateoverridesku: action.payload
      }
    case SET_UPDATEOVERRIDEMANUALSEARCH:
      return {
        ...state,
        UpdateOverrideManualSearch: action.payload
      }
    case SET_UPDATEAUGMENTATIONSKU:
      return {
        ...state,
        updateaugmentationsku: action.payload
      }
    case SET_UPDATEAUGMENTATIONMANUALSEARCH:
      return {
        ...state,
        UpdateAugmentationManualSearch: action.payload
      }
    case SET_SMIC_DETAILS:
      return {
        ...state,
        smicDetails: action.payload
      }
    case SET_MULTIUNIT_SRC_FILTER:
      return {
        ...state,
        multiUnitSrcFilter: action.payload
      }
    case SET_MULTIUNIT_TARGET_FILTER:
      return {
        ...state,
        multiUnitTargetFilter: action.payload
      }
    case SET_SOURCE_DEPARTMENT:
      return {
        ...state,
        listDepartmentSource: action.payload
      }
    case SET_TARGET_DEPARTMENT:
      return {
        ...state,
        listDepartmentTarget: action.payload
      }
    case SET_UPDATEOVERIDESKU:
      return {
        ...state,
        updateoverridesku: action.payload
      }
    case SET_UPDATEOVERRIDEMANUALSEARCH:
      return {
        ...state,
        UpdateOverrideManualSearch: action.payload
      }
    case SET_SMIC_DETAILS:
      return {
        ...state,
        smicDetails: action.payload
      }
    case SET_MULTIUNIT_SRC_FILTER:
      return {
        ...state,
        multiUnitSrcFilter: action.payload
      }
    case SET_MULTIUNIT_TARGET_FILTER:
      return {
        ...state,
        multiUnitTargetFilter: action.payload
      }
    case SET_MULTIUNIT_FILTER_DEPTNAME:
      return {
        ...state,
        multiUnitFilterDeptname: action.payload
      }
    case SET_MULTIUNIT_FILTER_RETAILSECTION:
      return {
        ...state,
        multiUnitFilterRetailSection: action.payload
      }
    case SET_MULTIUNIT_SRC_DATA:
      return {
        ...state,
        multiUnitSrcData: action.payload
      }
    case SET_MULTIUNIT_TARGET_DATA:
      return {
        ...state,
        multiUnitTargetData: action.payload
      }
    case SET_MEMI03_SKU:
      return {
        ...state,
        memi03sku: action.payload
      }
    case SET_MEMI03_CIC:
      return {
        ...state,
        memi03cic: action.payload
      }
    case SET_MEMI03_SKU_SELECTED:
      return {
        ...state,
        memi03skuSelected: action.payload
      }
    case SET_MEMI03_CIC_SELECTED:
      return {
        ...state,
        memi03cicSelected: action.payload
      }
    case SET_MEMI03_SKU_PAYLOAD:
      return {
        ...state,
        memi03skuPayload: action.payload
      }
    case SET_MEMI03_CIC_PAYLOAD:
      return {
        ...state,
        memi03cicPayload: action.payload
      }
    case SET_MAPPING_MODAL:
      return {
        ...state,
        mappingModal: action.payload
      }
    case SET_GROUP_DETAIL:
      return {
        ...state,
        groupDetail: action.payload
      }
    case SET_PRODUCTION_GROUP_DETAIL:
      return {
        ...state,
        productionGroupDetail: action.payload
      }
    case SET_AUGMENTATION_SERVICE_KEY:
      return {
        ...state,
        augmentationServiceKey: action.payload
      }
    case SET_OVERIDE_SERVICE_KEY:
      return {
        ...state,
        overideServiceKey: action.payload
      }
    case SET_AUGMENTATION_SERVICE_DEPARTMENT:
      return {
        ...state,
        augmentationServiceDepartment: action.payload
      }
    case SET_OVERIDE_SERVICE_USAGE_TYPE:
      return {
        ...state,
        overideServiceUsageType: action.payload
      }
    case SET_AUGMENTATION_SERVICE_USAGE_TYPE:
        return {
          ...state,
          augmentationServiceUsageType: action.payload
        }
    case ADD_APP_STATE:
      return {
        ...state,
        appState: { ...state.appState, ...action.payload }
      }
    case SET_APP_STATE:
      return {
        ...state,
        appState: action.payload
      }
    default:
      return state;
  }
};
