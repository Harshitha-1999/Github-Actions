export const ADD_STRING = "ADD_STRING";
export const DELETE_STRING = "DELETE_STRING";
