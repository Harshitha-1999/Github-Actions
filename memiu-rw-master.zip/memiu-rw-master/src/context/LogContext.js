import React from "react";

export const LogContext = React.createContext();

export default LogContext;
