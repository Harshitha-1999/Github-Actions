import { useEffect, useContext, useCallback } from 'react';
import { AppContext } from 'context/AppContext';

export const useAppContext = () => {

    const appContext = useContext(AppContext);

    const setData = useCallback((key, value) => {
        let globalData = appContext.data;
        if (globalData.hasOwnProperty("sharedData")) {
            let sharedData = globalData.sharedData;
            sharedData[key] = value;
        }
        else {
            let sharedData = (globalData["sharedData"] = {});
            sharedData[key] = value;
        }

    }, [appContext]);

    const getData = useCallback((key) => {
        let globalData = appContext.data;
        if (!globalData.hasOwnProperty("sharedData")) {
            return null;
        }
        else {
            let sharedData = globalData.sharedData;
            if (sharedData.hasOwnProperty(key)) {

                return sharedData[key];
            }
            else {
                return null;
            }
        }

    }, [appContext]);

    const clearData = useCallback((key, value) => {
        let globalData = appContext.data;
        if (globalData.hasOwnProperty("sharedData")) {
            let sharedData = globalData.sharedData;
            delete sharedData[key];
        }
        else {
            return null;
        }

    }, [appContext]);

    useEffect(() => {
        let globalData = JSON.stringify(appContext.data);
        if (Object.entries(appContext.data).length) {
            sessionStorage.setItem('appContext', globalData)
        }
        else {
            appContext.data = sessionStorage.getItem('appContext') ? JSON.parse(sessionStorage.getItem('appContext')) : {};
        }

    }, [appContext]);

    return {
        getData,
        setData,
        clearData,
    }
}

export default useAppContext;