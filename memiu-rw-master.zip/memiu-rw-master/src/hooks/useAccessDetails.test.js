import { renderHook } from '@testing-library/react-hooks'
import { useAccessDetails } from './useAccessDetails';


let mockAccessDetails = "eyJBQlNTZWN1cml0eVJlc3BvbnNlIjp7ImluZGljYXRvciI6IlkiLCJmaWVsZEFjY2Vzc0xpc3QiOlt7ImZpZWxkIjoiUFMuTkVYVC5SRUNFSVZFRC5EQVRFIiwiYWNjZXNzTGV2ZWwiOiJSRUFEIiwiYXBwQ29kZSI6IklTMDEifSx7ImZpZWxkIjoiUFMuU1RPQ0suTUVTU0FHRSIsImFjY2Vzc0xldmVsIjoiUkVBRCIsImFwcENvZGUiOiJJUzAxIn0seyJmaWVsZCI6IlNDUkVFTl9JU0MwMTAiLCJhY2Nlc3NMZXZlbCI6IlJFQUQiLCJhcHBDb2RlIjoiSVMwMSJ9LHsiZmllbGQiOiJTQ1JFRU5fSVNDMDIwIiwiYWNjZXNzTGV2ZWwiOiJSRUFEIiwiYXBwQ29kZSI6IklTMDEifSx7ImZpZWxkIjoiUFMuVkVORE9SLklORk8iLCJhY2Nlc3NMZXZlbCI6IlJFQUQiLCJhcHBDb2RlIjoiSVMwMSJ9LHsiZmllbGQiOiJQUy5UQ0EiLCJhY2Nlc3NMZXZlbCI6IlJFQUQiLCJhcHBDb2RlIjoiSVMwMSJ9LHsiZmllbGQiOiJTQ1JFRU5fRk9DMTAwIiwiYWNjZXNzTGV2ZWwiOiJSRUFEIiwiYXBwQ29kZSI6IkZPMDEifSx7ImZpZWxkIjoiU0NSRUVOX0ZPQzExMCIsImFjY2Vzc0xldmVsIjoiUkVBRCIsImFwcENvZGUiOiJGTzAxIn0seyJmaWVsZCI6IlNDUkVFTl9GT0MxMjAiLCJhY2Nlc3NMZXZlbCI6IlJFQUQiLCJhcHBDb2RlIjoiRk8wMSJ9LHsiZmllbGQiOiJTQ1JFRU5fRk9DMzk1IiwiYWNjZXNzTGV2ZWwiOiJSRUFEIiwiYXBwQ29kZSI6IkZPMDEifSx7ImZpZWxkIjoiU0NSRUVOX0ZPQzE0MCIsImFjY2Vzc0xldmVsIjoiUkVBRCIsImFwcENvZGUiOiJGTzAxIn0seyJmaWVsZCI6IlNDUkVFTl9GT0MxNTAiLCJhY2Nlc3NMZXZlbCI6IlJFQUQiLCJhcHBDb2RlIjoiRk8wMSJ9LHsiZmllbGQiOiJTQ1JFRU5fRk9DMzkwIiwiYWNjZXNzTGV2ZWwiOiJSRUFEIiwiYXBwQ29kZSI6IkZPMDEifSx7ImZpZWxkIjoiU0NSRUVOX1BTQzczMCIsImFjY2Vzc0xldmVsIjoiUkVBRCIsImFwcENvZGUiOiJJUzAxIn0seyJmaWVsZCI6IlBTLklCLkNPU1QiLCJhY2Nlc3NMZXZlbCI6IlVQREFURSIsImFwcENvZGUiOiJGTzAxIn0seyJmaWVsZCI6IlBTLklURU0uTVZNVCIsImFjY2Vzc0xldmVsIjoiVVBEQVRFIiwiYXBwQ29kZSI6IklTMDEifSx7ImZpZWxkIjoiU0NSRUVOX1BTQzcyMCIsImFjY2Vzc0xldmVsIjoiUkVBRCIsImFwcENvZGUiOiJJUzAxIn0seyJmaWVsZCI6IlNDUkVFTl9QU0M3MTAiLCJhY2Nlc3NMZXZlbCI6IlJFQUQiLCJhcHBDb2RlIjoiSVMwMSJ9LHsiZmllbGQiOiJQUy5CSUxMSU5HLkdST1NTIiwiYWNjZXNzTGV2ZWwiOiJVUERBVEUiLCJhcHBDb2RlIjoiRk8wMSJ9LHsiZmllbGQiOiJTQ1JFRU5fUFNDNzAwIiwiYWNjZXNzTGV2ZWwiOiJSRUFEIiwiYXBwQ29kZSI6IklTMDEifV19fQ==";

jest.mock('react-redux', () => {
    return {
        useDispatch: jest.fn(),
        useSelector: () => {
            return mockAccessDetails
        }
    }
})

describe('useAccessDetails hook', () => {

    test('getAccessLevelByKey', () => {
        // const { result } = renderHook(() => useAccessDetails())
        // let val = result.current.getAccessLevelByKey('1');
        // expect(val).toEqual("")
    })

    //     test('getAccessLevelByKey with access', () => {
    //         //update accessdetails base64 string

    //         const { result } = renderHook(() => useAccessDetails())
    //         let val = result.current.getAccessLevelByKey('SCREEN_FOC100');
    //         expect(val).toEqual('READ')
    //     })

    //     test('fetchAccessDetails', () => {
    //         const { result } = renderHook(() => useAccessDetails())
    //         let val = result.current.fetchAccessDetails();
    //         expect(val).toEqual(null)
    //     })
})