import { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getISC020AOnLoad, getISC020AOnTransaction, getISC020AOnDelete } from 'data/reducers/ISC/ISC020/actions';


import {
  getISC020Loading,
  getISC020Error,
  getISC020Data,
} from 'data/reducers/ISC/ISC020/selectors';

export const useISC020 = () => {




  const dispatch = useDispatch();

  const isc020Data = useSelector(getISC020Data);
  const isc020Loading = useSelector(getISC020Loading);
  const isc020Error = useSelector(getISC020Error);

  const dispatchISC020OnLoad = useCallback(

    async () => await dispatch(getISC020AOnLoad()),
    [dispatch]
  );
  const dispatchISC020Transaction = useCallback(

    async (countryCode, corporation, division, operationFacility, foPromptQuantity) => await dispatch(getISC020AOnTransaction(countryCode, corporation, division, operationFacility, foPromptQuantity)),
    [dispatch]
  );
  const dispatchISC020Delete = useCallback(

    async (userDefaultsId) => await dispatch(getISC020AOnDelete(userDefaultsId)),
    [dispatch]
  );
  //function to set focus on next allowance
  const setFocus = useCallback((fieldName) => {

    document.getElementById(fieldName).setSelectionRange(0, 0);

    let fieldElement = document.getElementById(fieldName);
    if (fieldElement) {
      fieldElement.focus();
    }
  }, []);





  const updatePFKeys = useCallback((option, reflastFmDate) => {
    const PFKeys = [
      { key: "F1", label: "F1=Help" },
      { key: "F3", label: "F3=Exit" },
      { key: "F5", label: "F5=Refresh" },
      { key: "F15", label: "F15=Main Menu" }

    ]
    let newPFkeys = [...PFKeys];

    if (option === "DEL" && (reflastFmDate !== "" && reflastFmDate !== null && reflastFmDate !== undefined)) {
      newPFkeys.splice(3, 0, { key: "F6", label: "F6=Delete" })
      return newPFkeys;

    }
    else {
      return newPFkeys.filter(keys => keys.Key !== "F6");

    }


  }, []);

  return {
    isc020Data,
    isc020Loading,
    isc020Error,

    setFocus,
    updatePFKeys,
    fetchISCData: dispatchISC020OnLoad,
    fetchISC020Data: dispatchISC020Transaction,
    fetchISC020Delete: dispatchISC020Delete

  };
};

export default useISC020;