import { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getISC010OnLoad } from 'data/reducers/ISC/ISC010/actions';
import {
  getISC010Loading,
  getISC010Error,
  getISC010Data
} from 'data/reducers/ISC/ISC010/selectors';

export const useISC010 = () => {
  const dispatch = useDispatch();

  const isc010Data = useSelector(getISC010Data);
  const isc010Loading = useSelector(getISC010Loading);
  const isc010Error = useSelector(getISC010Error);

  const dispatchISC010OnLoad = useCallback(
    () => dispatch(getISC010OnLoad()),
    [dispatch]
  );

  return {
    isc010Data,
    isc010Loading,
    isc010Error,
    fetchISCData: dispatchISC010OnLoad,
  };
};

export default useISC010;