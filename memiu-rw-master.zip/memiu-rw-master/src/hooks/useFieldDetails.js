import { useCallback, useEffect, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getFieldDetails } from 'data/reducers/fieldDetails/actions';
import {
  getFieldDetailsLoading,
  getFieldDetailsError,
  getFieldDetailsData
} from 'data/reducers/fieldDetails/selectors';
import { FieldKeyConstants } from 'utils';

export const useFieldDetails = () => {
  const dispatch = useDispatch();

  const fieldDetailsData = useSelector(getFieldDetailsData);
  const fieldDetailsLoading = useSelector(getFieldDetailsLoading);
  const fieldDetailsError = useSelector(getFieldDetailsError);

  let fieldDetailsSessionData = useMemo(() => {
    return sessionStorage.getItem('fieldDetails') ? JSON.parse(`${sessionStorage.getItem('fieldDetails')}`) : fieldDetailsData;
  }, [fieldDetailsData]);

  const dispatchFieldDetails = useCallback(
    () => sessionStorage.getItem('fieldDetails') ? null : dispatch(getFieldDetails()),
    [dispatch]
  );

  const isBase64 = useCallback((str) => {
    if (str === '' || str.trim() === '') { return null; }
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return null;
    }
  }, []);

  const getFieldLevelByKey = useCallback((fieldKey) => {
    let fieldDetailsArray = [];
    if (fieldDetailsSessionData && isBase64(fieldDetailsSessionData)) {
      const { ABSSecurityResponse: { fieldAccessList } } = JSON.parse(atob(fieldDetailsSessionData));
      fieldDetailsArray = fieldAccessList ? fieldAccessList.filter(keys => keys.field.toUpperCase() === fieldKey.toUpperCase() && keys.accessLevel.toUpperCase() === FieldKeyConstants.ACCESS_UPDATE) : [];
      fieldDetailsArray = fieldDetailsArray.length ? fieldDetailsArray : fieldAccessList ? fieldAccessList.filter(keys => keys.field.toUpperCase() === fieldKey.toUpperCase() && keys.accessLevel.toUpperCase() === FieldKeyConstants.ACCESS_READ) : [];

    }

    return fieldDetailsArray.length ? fieldDetailsArray[0].accessLevel : "";

  }, [fieldDetailsSessionData, isBase64]);

  useEffect(() => {
    if (fieldDetailsData && isBase64(fieldDetailsData)) {
      sessionStorage.setItem('fieldDetails', JSON.stringify(`${fieldDetailsData}`));
    }
  }, [fieldDetailsData, isBase64]);

  return {
    fieldDetailsData: (fieldDetailsSessionData && isBase64(fieldDetailsSessionData)) && JSON.parse(atob(fieldDetailsSessionData)),
    fieldDetailsLoading,
    fieldDetailsError,
    getFieldLevelByKey,
    fetchFieldDetails: dispatchFieldDetails,
    isBase64
  };
};

export default useFieldDetails;
