import { useCallback, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updatePSPIX } from 'data/reducers/PSPIX/actions';
import { pspixVariables } from 'data/reducers/PSPIX/selectors';


export const usePspix = () => {
  const dispatch = useDispatch();
  const pspixVariablesData = useSelector(pspixVariables);

  const pspixSessionVariables = useMemo(() => {
    return sessionStorage.getItem('pspixVariables') ? JSON.parse(`${sessionStorage.getItem('pspixVariables')}`) : pspixVariablesData;
  }, [pspixVariablesData]);

  const updatePspixDispatch = useCallback(
    (options) => {
      dispatch(updatePSPIX(options));
      sessionStorage.setItem('pspixVariables', `${JSON.stringify(options)}`);
    },
    [dispatch]
  );

  return {
    updatePSPIX: updatePspixDispatch,
    pspixVariables: pspixSessionVariables

  };
}


