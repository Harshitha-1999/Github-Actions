import { useCallback, useEffect, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getAccessDetails } from 'data/reducers/accessDetails/actions';
import {
  getAccessDetailsLoading,
  getAccessDetailsError,
  getAccessDetailsData
} from 'data/reducers/accessDetails/selectors';
import { FieldKeyConstants } from 'utils';

export const useAccessDetails = () => {
  const dispatch = useDispatch();

  const accessDetailsData = useSelector(getAccessDetailsData);
  const accessDetailsLoading = useSelector(getAccessDetailsLoading);
  const accessDetailsError = useSelector(getAccessDetailsError);

  let accessDetailsSessionData = useMemo(() => {
    return sessionStorage.getItem('accessDetails') ? JSON.parse(`${sessionStorage.getItem('accessDetails')}`) : accessDetailsData;
  }, [accessDetailsData]);

  const dispatchAccessDetails = useCallback(
    () => sessionStorage.getItem('accessDetails') ? null : dispatch(getAccessDetails()),
    [dispatch]
  );

  const isBase64 = useCallback((str) => {
    if (str === '' || str.trim() === '') { return null; }
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return null;
    }
  }, []);

  const getAccessLevelByKey = useCallback((fieldKey) => {
    let accessDetailsArray = [];
    if (accessDetailsSessionData && isBase64(accessDetailsSessionData)) {
      const { ABSSecurityResponse: { screenAccessList } } = JSON.parse(atob(accessDetailsSessionData));
      accessDetailsArray = screenAccessList ? screenAccessList.filter(keys => keys.screen.toUpperCase() === fieldKey.toUpperCase() && keys.accessLevel.toUpperCase() === FieldKeyConstants.ACCESS_UPDATE) : [];
      accessDetailsArray = accessDetailsArray.length ? accessDetailsArray : screenAccessList ? screenAccessList.filter(keys => keys.screen.toUpperCase() === fieldKey.toUpperCase() && keys.accessLevel.toUpperCase() === FieldKeyConstants.ACCESS_READ) : [];
    }
    return accessDetailsArray.length ? accessDetailsArray[0].accessLevel : "";

  }, [accessDetailsSessionData, isBase64]);

  useEffect(() => {
    if (accessDetailsData && isBase64(accessDetailsData)) {
      sessionStorage.setItem('accessDetails', JSON.stringify(`${accessDetailsData}`));
    }
  }, [accessDetailsData, isBase64]);

  return {
    accessDetailsData: (accessDetailsSessionData && isBase64(accessDetailsSessionData)) && JSON.parse(atob(accessDetailsSessionData)),
    accessDetailsLoading,
    accessDetailsError,
    getAccessLevelByKey,
    fetchAccessDetails: dispatchAccessDetails,
    isBase64
  };
};

export default useAccessDetails;
