import { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getPSC730OnLoad, getPSC730ItemMovementOnload, getPSC730WareHouseOnload, getPSC730PricingOnload, getPSC730PricingOnTransaction } from 'data/reducers/PSC/PSC730/actions';
import {
  getPSC730Loading,
  getPSC730Error,
  getPSC730Data,
} from 'data/reducers/PSC/PSC730/selectors';

export const usePSC730 = () => {
  const dispatch = useDispatch();

  const psc730Data = useSelector(getPSC730Data);
  const pscLoading = useSelector(getPSC730Loading);
  const pscError = useSelector(getPSC730Error);

  // const dispatchPSC730OnLoad = useCallback(
  //   async (pluStrt,pluEnd,rog,corp,div,fac,currentDate) => await dispatch(getPSC730OnLoad(pluStrt,pluEnd,rog,corp,div,fac,currentDate)),
  //   [dispatch]
  // );
  const dispatchPSC730OnLoad = useCallback(
    async (psc710ValuesTo730) => await dispatch(getPSC730OnLoad(psc710ValuesTo730)),
    [dispatch]
  );

  const dispatchPSC730ItemMovemenetOnLoad = useCallback(
    (itemMovementRequest) => dispatch(getPSC730ItemMovementOnload(itemMovementRequest)),
    [dispatch]
  );

  const dispatchPSC730WareHouseOnload = useCallback(
    (wareHouseRequest, page) => dispatch(getPSC730WareHouseOnload(wareHouseRequest, page)),
    [dispatch]
  );

  const dispatchPSC730PricingOnload = useCallback(
    async (pricingRequest) => await dispatch(getPSC730PricingOnload(pricingRequest)),
    [dispatch]
  );

  const dispatchPSC730PricingOnTransaction = useCallback(
    async (pricingRequest, ib_cost, prx_both_whs_dsd_sw, currentPriceRequest) => await dispatch(getPSC730PricingOnTransaction(pricingRequest, ib_cost, prx_both_whs_dsd_sw, currentPriceRequest)),
    [dispatch]
  );


  return {
    psc730Data,
    pscLoading,
    pscError,
    fetchPSCData: dispatchPSC730OnLoad,
    fetchPSCDataItemMovement: dispatchPSC730ItemMovemenetOnLoad,
    fetchPSCDataWareHouse: dispatchPSC730WareHouseOnload,
    fetchPSCDataPricing: dispatchPSC730PricingOnload,
    fetchPSCDataPricingOnTransaction: dispatchPSC730PricingOnTransaction

  };
};

export default usePSC730;