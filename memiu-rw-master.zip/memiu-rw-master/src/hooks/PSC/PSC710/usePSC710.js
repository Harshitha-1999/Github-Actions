import { useCallback, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getPSC710OnLoad } from 'data/reducers/PSC/PSC710/actions';
import {
  getPSC710Loading,
  getPSC710Error,
  getPSC710Data,
} from 'data/reducers/PSC/PSC710/selectors';

export const usePSC710 = () => {
  const dispatch = useDispatch();

  const psc710Data = useSelector(getPSC710Data);
  const psc710Loading = useSelector(getPSC710Loading);
  const psc710Error = useSelector(getPSC710Error);
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [prevUrl, setPrevUrl] = useState(null);
  const [nextUrl, setNextUrl] = useState(null);

  const dispatchPSC710OnLoad = useCallback(
    (requestParams) => dispatch(getPSC710OnLoad(requestParams)),
    [dispatch]
  );

  //Function to capture next week url and next url properties from pagination object
  const checkNextUrl = useCallback(() => {
    if (psc710Data.hasOwnProperty("productInquiryInformationDisplayResponse")) {
      const { productInquiryInformationDisplayResponse } = psc710Data;
      if (productInquiryInformationDisplayResponse.hasOwnProperty("pagination")) {
        const { pagination } = productInquiryInformationDisplayResponse;
        if (pagination.hasOwnProperty("nextUrl")) {
          // const { nextUrl } = pagination;
          setNextUrl(pagination.nextUrl);
        }
        else {
          setNextUrl(null);
        }
      }
      else {
        setNextUrl(null);
      }
    }
  }, [psc710Data, setNextUrl]);

  //Function to capture previous week url and previous url properties from pagination object
  const checkPrevUrl = useCallback(() => {
    if (psc710Data.hasOwnProperty("productInquiryInformationDisplayResponse")) {
      const { productInquiryInformationDisplayResponse } = psc710Data;
      if (productInquiryInformationDisplayResponse.hasOwnProperty("pagination")) {
        const { pagination } = productInquiryInformationDisplayResponse;
        if (pagination.hasOwnProperty("previousUrl")) {
          const { previousUrl } = pagination;
          setPrevUrl(previousUrl);
        }
        else {
          setPrevUrl(null);
        }
      }
      else {
        setPrevUrl(null);
      }
    }
  }, [psc710Data, setPrevUrl]);



  //Effect to call checkNextUrl and checkPrevUrl to capture pagination object properties
  useEffect(() => {
    if (psc710Data) {
      checkPrevUrl();
      checkNextUrl();
    }
  }, [psc710Data, checkNextUrl, checkPrevUrl]);

  return {
    isMultiSelect,
    setIsMultiSelect,
    prevUrl,
    nextUrl,

    psc710Data,
    psc710Loading,
    // setFocus,
    psc710Error,
    fetchPSCData: dispatchPSC710OnLoad,
  };
};

export default usePSC710;