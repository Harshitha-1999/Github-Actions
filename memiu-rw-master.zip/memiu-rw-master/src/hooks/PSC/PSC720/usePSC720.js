import { useCallback, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getPSC720OnLoad } from 'data/reducers/PSC/PSC720/actions';
import {
  getPSC720Loading,
  getPSC720Error,
  getPSC720Data,
} from 'data/reducers/PSC/PSC720/selectors';

export const usePSC720 = () => {
  const dispatch = useDispatch();

  const psc720Data = useSelector(getPSC720Data);
  const psc720Loading = useSelector(getPSC720Loading);
  const psc720Error = useSelector(getPSC720Error);
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [prevUrl, setPrevUrl] = useState(null);
  const [nextUrl, setNextUrl] = useState(null);

  const dispatchPSC720OnLoad = useCallback(
    (requestParams) => dispatch(getPSC720OnLoad(requestParams)),
    [dispatch]
  );

  //Function to capture next week url and next url properties from pagination object
  const checkNextUrl = useCallback(() => {
    if (psc720Data.hasOwnProperty("productInquiryInformationDisplayResponse")) {
      const { productInquiryInformationDisplayResponse } = psc720Data;
      if (productInquiryInformationDisplayResponse.hasOwnProperty("pagination")) {
        const { pagination } = productInquiryInformationDisplayResponse;
        if (pagination.hasOwnProperty("nextUrl")) {
          //const { nextUrl  } = pagination;   
          setNextUrl(pagination.nextUrl);
        }
        else {
          setNextUrl(null);
        }
      }
      else {
        setNextUrl(null);
      }
    }
  }, [psc720Data, setNextUrl]);

  //Function to capture previous week url and previous url properties from pagination object
  const checkPrevUrl = useCallback(() => {
    if (psc720Data.hasOwnProperty("productInquiryInformationDisplayResponse")) {
      const { productInquiryInformationDisplayResponse } = psc720Data;
      if (productInquiryInformationDisplayResponse.hasOwnProperty("pagination")) {
        const { pagination } = productInquiryInformationDisplayResponse;
        if (pagination.hasOwnProperty("previousUrl")) {
          const { previousUrl } = pagination;
          setPrevUrl(previousUrl);
        }
        else {
          setPrevUrl(null);
        }
      }
      else {
        setPrevUrl(null);
      }
    }
  }, [psc720Data, setPrevUrl]);



  //Effect to call checkNextUrl and checkPrevUrl to capture pagination object properties
  useEffect(() => {
    if (psc720Data) {
      checkPrevUrl();
      checkNextUrl();
    }
  }, [psc720Data, checkNextUrl, checkPrevUrl]);

  return {
    isMultiSelect,
    setIsMultiSelect,
    prevUrl,
    nextUrl,

    psc720Data,
    psc720Loading,
    // setFocus,
    psc720Error,
    fetchPSCData: dispatchPSC720OnLoad,
  };
};

export default usePSC720;