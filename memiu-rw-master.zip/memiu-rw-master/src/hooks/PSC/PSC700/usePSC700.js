import { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getPSC700AOnLoad, getPSC700ATransaction } from 'data/reducers/PSC/PSC700/actions';
import {
  getPSC700Loading,
  getPSC700Error,
  getPSC700Data,
} from 'data/reducers/PSC/PSC700/selectors';

export const usePSC700 = () => {
  const dispatch = useDispatch();

  const getCallingProgram = useCallback(() => {
    let callingFromMecData = null;
    if (sessionStorage.getItem('appContext')) {
      const sessionData = JSON.parse(sessionStorage.getItem('appContext'));
      if (sessionData.hasOwnProperty('sharedData') && sessionData.sharedData.hasOwnProperty('callingFromMec')) {
        const { sharedData: { callingFromMec } } = sessionData;
        callingFromMecData = callingFromMec;
      }
    }
    return callingFromMecData;
  }, []);

  const psc700Data = useSelector(getPSC700Data);
  const psc700Loading = useSelector(getPSC700Loading);
  const psc700Error = useSelector(getPSC700Error);

  const dispatchPSC700OnLoad = useCallback(
    () => dispatch(getPSC700AOnLoad()),
    [dispatch]
  );
  const dispatchPSC700ATransaction = useCallback(
    (refCorpvalue, refDivValue, refFacValue, stoItemScan2, sectType) => dispatch(getPSC700ATransaction(refCorpvalue, refDivValue, refFacValue, stoItemScan2, sectType)),
    [dispatch]
  );

  // const setFocus = useCallback((fieldName) => {
  //   document.getElementById(fieldName).setSelectionRange(0,0);
  //   let el = document.getElementById(fieldName);
  //   if (el) { el.focus() }
  // }, []);
  const setFocus = useCallback((fieldName) => {

    // if(fieldName !=="" && fieldName !==null && fieldName !== undefined){

    //     //  document.getElementById(fieldName).setSelectionRange(0,0);
    // }

    let fieldElement = document.getElementById(fieldName);
    if (fieldElement) {
      fieldElement.setSelectionRange(0, 0);
      fieldElement.focus();
    }
  }, []);

  return {
    psc700Data,
    psc700Loading,
    psc700Error,
    getCallingProgram,
    setFocus,
    fetchPSC700Data: dispatchPSC700OnLoad,
    fetchPSC700TransactionData: dispatchPSC700ATransaction,
  };
};

export default usePSC700;