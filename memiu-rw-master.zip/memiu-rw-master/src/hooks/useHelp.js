import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateHelp, getHelpContent } from 'data/reducers/helpScreen/actions';
import { getHelpOptions, getHelpScreenContentData } from 'data/reducers/helpScreen/selectors';

export const useHelp = () => {
  const dispatch = useDispatch();

  const endOfListObject = {
    "ISC020A": "Y"
  };

  const updateHelpDispatch = useCallback(
    (options) => {
      dispatch(updateHelp(options));
    },
    [dispatch]
  );

  const setHelpContent = useCallback(
    (contents, message, scope) => {
      updateHelpDispatch({
        isOpen: true,
        contents,
        message,
        scope
      });
    },
    [updateHelpDispatch]
  )

  const closeHelp = useCallback(() => {
    updateHelpDispatch({
      isOpen: false,
      contents: null,
    });
  }, [updateHelpDispatch]);

  const dispatchHelpContent = useCallback(
    (programName) => {
      dispatch(getHelpContent(programName));
    },
    [dispatch]
  )

  return {
    updateHelp: updateHelpDispatch,
    helpOptions: useSelector(getHelpOptions),
    setHelpContent,
    closeHelp,
    endOfListObject,
    fetchHelpContent: dispatchHelpContent,
    helpScreenContent: useSelector(getHelpScreenContentData),
  };
}


