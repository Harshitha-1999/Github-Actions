import { useCallback, useMemo, useState, useEffect, useRef } from 'react';
import produce from 'immer';
import { setFocus } from 'utils';


export const usePagination = () => {
    const [pageData, setPageData] = useState([]);
    const [pageDataWithProperty, setPageDataWithProperty] = useState([]);
    const [endOfList, setEndOfList] = useState('MORE...');
    const [pageNo, setPageNo] = useState(1);
    const startOfClientPageNo = useRef([]);

    const pageMap = useMemo(() => new Map(), []);

    const getStartOfClientPageNo = useCallback(() => {
        startOfClientPageNo.current.length && startOfClientPageNo.current.shift();
        let startOfClientPageNum = startOfClientPageNo.current.length && startOfClientPageNo.current[0];
        return startOfClientPageNum;
    }, []);

    const createArrayChunks = useCallback((data, offset = 10, nextPageNo = null) => {
        if (data.length) {
            pageMap.clear();
            let chunkPageNo = 1;
            if (nextPageNo && nextPageNo !== 0) {
                chunkPageNo = nextPageNo;
            }
            else {
                chunkPageNo = 1;
                startOfClientPageNo.current.length = 0;
            }
            startOfClientPageNo.current.unshift(chunkPageNo);
            startOfClientPageNo.current = [...new Set(startOfClientPageNo.current)];
            for (let i = 0, k = chunkPageNo, j = data.length; i < j; i += parseInt(offset), k++) {
                pageMap.set(k, data.slice(i, i + parseInt(offset)));
            }
            setPageData(pageMap.get(chunkPageNo));
            setPageDataWithProperty(pageMap.get(chunkPageNo));
        }
        else {
            pageMap.clear();
            setPageData([]);
            setPageDataWithProperty([]);
        }
    }, [pageMap, setPageData, setPageDataWithProperty]);

    const getSelectedRecords = useCallback((field) => {
        let isSelected = pageData ? pageData.filter(row => row[field] !== "") : [];
        return isSelected;
    }, [pageData]);

    const getPageData = useCallback((key) => {
        if (key === 'F7') {
            pageMap.has(pageNo - 1) && setPageNo(prevState => prevState - 1);
        }
        else if (key === 'F8') {
            pageMap.has(pageNo + 1) && setPageNo(prevState => prevState + 1);
        }
    }, [pageNo, pageMap, setPageNo]);

    const checkEndofRecords = useCallback((keyCode) => {
        return keyCode === 'F8' ? !pageMap.has(pageNo + 1) : !pageMap.has(pageNo - 1)
    }, [pageNo, pageMap]);


    const hideIsValidProperty = useCallback((data) => {
        let newPageData = [];
        data.forEach(row => {
            if (row.hasOwnProperty('isValid')) {
                const { isValid, ...rest } = row;
                newPageData.push(rest);
            }
            else {
                newPageData.push(row);
            }
        });
        return newPageData;
    }, []);


    const validateMultiSelect = useCallback((data, field) => {
        let newPageData = [];
        if (data.filter(row => row[field].toUpperCase() === 'S').length > 1) {
            data.forEach(row => {
                if (row.hasOwnProperty('isValid') && row[field].toUpperCase() === 'S' && !data.some(dataRow => dataRow[field] !== '' && dataRow[field].toUpperCase() !== 'S')) {
                    newPageData.push({ ...row, isValid: false });
                }
                else if (row.hasOwnProperty('isValid') && row[field].toUpperCase() === 'S' && data.some(dataRow => dataRow[field] !== '' && dataRow[field].toUpperCase() !== 'S')) {
                    newPageData.push({ ...row, isValid: true });
                }
                else {
                    newPageData.push(row);
                }
            })
            setPageDataWithProperty(newPageData);
            let pageDataWithoutProperty = hideIsValidProperty(newPageData);
            setPageData(pageDataWithoutProperty);
            pageMap.set(pageNo, pageDataWithoutProperty);
        }
        else {
            data.forEach(row => {
                if (row.hasOwnProperty('isValid') && row[field].toUpperCase() === 'S') {
                    newPageData.push({ ...row, isValid: true });
                }
                else {
                    newPageData.push(row);
                }
            })
            setPageDataWithProperty(newPageData);
            let pageDataWithoutProperty = hideIsValidProperty(newPageData);
            setPageData(pageDataWithoutProperty);
            pageMap.set(pageNo, pageDataWithoutProperty);
        }
    }, [pageNo, pageMap, setPageData, setPageDataWithProperty, hideIsValidProperty]);

    const replaceNextCharacter = useCallback((ev, nextInput) => {
        // Prevent Default Spacebar behavior and stop event bubbling
        ev.preventDefault();
        ev.stopPropagation();

        let { id, value } = ev.target;
        let element = document.getElementById(id);
        let position = element.selectionStart;

        if (position === element.maxLength - 1 && nextInput) {
            setFocus(nextInput);
        }
        if (position >= element.maxLength && nextInput) {
            setFocus(nextInput);
        }

        if (position <= 1) {
            let valueArray = value.split("");
            valueArray[position] = ev.key;

            window.requestAnimationFrame(() => {
                element.setSelectionRange(++position, position);
            })
            if (position === 0 && id) {
                setFocus(id);
            }
            return valueArray.join("");
        }
        else {
            let valueArray = value.split("");
            valueArray[position] = ev.key;
            valueArray[position - 1] = ev.key

            window.requestAnimationFrame(() => {
                element.setSelectionRange(++position, position);
            })

            return valueArray.join("");
        }
    }, [])

    const handleSelection = useCallback((e, index, field, isMultiAllowed, nextInput = "") => {
        if (e.target.value.toUpperCase() === 'S') {
            let newPageData = produce(pageDataWithProperty.length ? pageDataWithProperty : pageData, pageDataCopy => {
                pageDataCopy[index][field] = replaceNextCharacter(e, nextInput);
                pageDataCopy[index].isValid = true;
            })
            setPageDataWithProperty(newPageData);
            if (isMultiAllowed) {
                let pageDataWithoutProperty = hideIsValidProperty(newPageData);
                setPageData(pageDataWithoutProperty);
                pageMap.set(pageNo, pageDataWithoutProperty);
            }
            else {
                validateMultiSelect(newPageData, field);
            }
        }
        else {
            let newPageData = produce(pageDataWithProperty.length ? pageDataWithProperty : pageData, pageDataCopy => {
                pageDataCopy[index][field] = replaceNextCharacter(e, nextInput);
                pageDataCopy[index].isValid = (e.target.value === "" || e.target.value === " ") ? true : false;
            })
            setPageDataWithProperty(newPageData);
            if (isMultiAllowed) {
                let pageDataWithoutProperty = hideIsValidProperty(newPageData);
                setPageData(pageDataWithoutProperty);
                pageMap.set(pageNo, pageDataWithoutProperty);
            }
            else {
                validateMultiSelect(newPageData, field);
            }
        }
    }, [pageNo, pageMap, pageData, setPageData, pageDataWithProperty, setPageDataWithProperty, replaceNextCharacter, validateMultiSelect, hideIsValidProperty]);

    const resetSelections = useCallback((field) => {
        let newPageData = [];
        pageData.forEach(row => {
            if (row.hasOwnProperty('isValid')) {
                const { isValid, ...rest } = row;
                newPageData.push({ ...rest, [field]: "" });
            }
            else {
                newPageData.push({ ...row, [field]: "" });
            }
        });
        setPageData(newPageData);
        setPageDataWithProperty(newPageData);
        pageMap.set(pageNo, newPageData);
    }, [pageNo, pageMap, pageData, setPageData, setPageDataWithProperty]);

    const changeToUpperCase = useCallback((field) => {
        let curPageData = pageDataWithProperty.length ? pageDataWithProperty : pageData;
        if (curPageData.length) {
            let newPageData = produce(curPageData, pageDataCopy => {
                [...Array(curPageData.length)].forEach((val, index) => {
                    pageDataCopy[index][field] = pageDataCopy[index][field].toUpperCase();
                });
            });
            setPageData(newPageData);
            setPageDataWithProperty(newPageData);
        }
    }, [pageData, pageDataWithProperty, setPageDataWithProperty, setPageData]);

    useEffect(() => {
        if (pageMap.get(pageNo)) {
            setPageData(pageMap.get(pageNo));
            setPageDataWithProperty(pageMap.get(pageNo));
        }
    }, [pageNo, pageMap, setPageData, setPageDataWithProperty]);

    useEffect(() => {
        if (!pageMap.size) {
            setEndOfList('END OF LIST');
        }
        else if (!pageMap.has(pageNo + 1)) {
            setEndOfList('END OF LIST');
        }
        else {
            setEndOfList('MORE...');
        }
    }, [setEndOfList, pageNo, pageMap, pageMap.size]);


    return {
        pageData,
        pageNo,
        endOfList,
        getStartOfClientPageNo,
        createArrayChunks,
        getPageData,
        handleSelection,
        resetSelections,
        getSelectedRecords,
        checkEndofRecords,
        changeToUpperCase,
        setPageData,
        setPageNo,
        pageMap,
        pageDataWithProperty
    }
}

export default usePagination;