import { useCallback, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateTransaction } from 'data/reducers/transaction/actions';
import { getTransaction } from 'data/reducers/transaction/selectors';


export const useTransaction = () => {
  const dispatch = useDispatch();
  const transactionVariablesData = useSelector(getTransaction);


  const transactionSessionVariables = useMemo(() => {
    return sessionStorage.getItem('transactionVariables') ? JSON.parse(`${sessionStorage.getItem('transactionVariables')}`) : transactionVariablesData;
  }, [transactionVariablesData]);

  const updateTransactionDispatch = useCallback(
    (options) => {
      dispatch(updateTransaction(options));
      sessionStorage.setItem('transactionVariables', `${JSON.stringify(options)}`);
    },
    [dispatch]
  );

  return {
    updateTransaction: updateTransactionDispatch,
    transactionVariables: transactionSessionVariables

  };
}


