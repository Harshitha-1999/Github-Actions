import React from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import AugmentationScreen from "components/AugmentationScreen/AugmentationScreen";
export const MEMI12 = () => {

  return (
    <PageLayoutMemi
      pageTitle="Augmentation Cont"
      mainContent={<AugmentationScreen />}
      navigationBar={<NavigationBar />}
    // footer={<Footer />}
    />
  );
};

export default MEMI12;
