import React from "react";

import PageLayoutMemi from '../../components/PageLayoutMemi/PageLayoutMemi';
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import SearchForm from "../../components/SearchForm/SearchForm";
import Footer from "../../components/Footer/Footer";


export const MEMI09 = () => {




  return (<PageLayoutMemi
    pageTitle="MEMI09"
    mainContent={<SearchForm />}
    navigationBar={<NavigationBar />}
    footer={<Footer />}
  />);
};

export default MEMI09;
