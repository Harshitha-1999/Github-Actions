import React, { useContext, useEffect } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import { memiuServices } from "api/memiu/memiuService";
import MapItems from "../../components/MapItems/MapItems"
import ApplicationContext from "../../context/ApplicationContext";
import NoRecordsDisplay from "components/NoRecordsDisplay/NoRecordsDisplay";
import "../../css/App.css";

export const MapItemsPage = () => {

  const AppData = useContext(ApplicationContext);
  const { divisionId, companyId } = AppData
  useEffect(() => {

    if (companyId !== "" && divisionId !== "") {
      memiuServices.getSourceDepartment(companyId, divisionId)
        .then((res) => {
          AppData.setSourceDepartment(res.data.map(x => { return { label: x[1], value: x[0] } }))
        })
        .catch((err) => {
        })
      memiuServices.getTargetDepartment(companyId, divisionId)
        .then((res) => {
          AppData.setTargetDepartment(res.data.map(x => { return { label: x[0], value: x[1] } }))
        })
        .catch((err) => {
        })
    }

  }, [companyId, divisionId]);

  return (
    <PageLayoutMemi
      // mainContent={<MapItems/>}
      navigationBar={<NavigationBar />}
      mainContent={
        AppData.companyId !== "" && AppData.divisionId !== "" ? <MapItems /> : <NoRecordsDisplay />
      }
      fullHeight={AppData.companyId !== "" && AppData.divisionId !== ""}

    />
  );

};

export default MapItemsPage;
