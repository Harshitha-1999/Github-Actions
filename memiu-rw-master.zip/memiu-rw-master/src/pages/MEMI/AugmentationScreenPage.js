import React, { memo } from "react";
import PageLayoutMemi from '../../components/PageLayoutMemi/PageLayoutMemi';
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Footer from "../../components/Footer/Footer";
import AugmentationScreen from '../../components/AugmentationScreen/AugmentationScreen'

const AugmentationScreenPage = () => {
  return (<PageLayoutMemi
    pageTitle="Augmentation Screen"
    mainContent={<AugmentationScreen />}
    navigationBar={<NavigationBar />}
    footer={<Footer />}
  />);
};

export default memo(AugmentationScreenPage);
