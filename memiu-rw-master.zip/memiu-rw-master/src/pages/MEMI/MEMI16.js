import React, { useCallback, useState, useContext, useEffect, useRef } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import ApplicationContext from "../../context/ApplicationContext";
import { Grid, OutlinedInput } from "@material-ui/core";
import ButtonMemi from "components/ButtonMemi/ButtonMemi";
import DropDownMemi from '../../components/DropDownMemi/DropDownMemi';
import { Loop } from "@material-ui/icons";
import Footer from "../../components/Footer/Footer";
import DisplayerItems from "../../components/DisplayerItems/DisplayerItems";
import ButtonLogout from "components/ButtonLogout/ButtonLogout";
export const MEMI16 = () => {

  const AppData = useContext(ApplicationContext);

  const { selectedCriteria, selectedCriteriaSearch, memi16Data } = AppData;

  const onLoadFunc = useRef(null);

  const handleSelectDepartment = useCallback((value) => {
    console.log(value)
    AppData.setMemi16Criteria({});

    AppData.setSelectedCriteria(value);
    AppData.setSelectedCriteriaSearch("")

    if (value === "oneTimeBuyFlag") {
      AppData.setSelectedCriteriaSearch("Y")
    }

  }, [])

  const onClickReset = useCallback(() => {

    AppData.setMemi16Criteria({});
    onLoadFunc.current();

    AppData.mapSelectedRowData([]);
    AppData.setSelectedCriteria("itemDesc")
    AppData.setSelectedCriteriaSearch("")
    AppData.mapSelectedRowData([]);

  }, []);

  const onSearchClick = useCallback(() => {

    AppData.setMemi16Criteria({});
    let whiteSpace = new RegExp(/^\s+$/);

    if (selectedCriteria === "")
      AppData.setAlertBox(true, "Please select any criteria")
    else if (selectedCriteriaSearch === "" || whiteSpace.test(selectedCriteriaSearch))
      AppData.setAlertBox(true, "Please enter any values to search")
    else {
      AppData.setMemi16Criteria({ [selectedCriteria]: selectedCriteriaSearch.trim() });
    }

  }, [selectedCriteria, selectedCriteriaSearch]);

  const HeaderMultiUnitScreen = (
    <Grid
      container
      className="MainContent"
    >
      <div style={{ display: "flex", alignItems: "center", width: "100%", marginBottom: "10px" }} className={"displayerContentOutline"}>
        <div style={{ justifyContent: "flex-start", width: "45%", display: "flex", flexDirection: "row", alignItems: "center" }}>
          <img src="/MultiUnitTypeLogo.png" alt="multiUnitType" />
          <big style={{ fontWeight: "bold", color: "#055166", fontSize: "21px" }}>Displayer Items - {memi16Data && memi16Data.type === "N" ? "Un-reviewed" : "Reviewed"}</big>
        </div>
        <div style={{ alignItems: "center", width: "16%" }}>
          <DropDownMemi
            options={[
              // { label: "-Criteria-", value: "criteria" },
              { label: "Item Desc", value: "itemDesc" },
              { label: "Product SKU", value: "productSku" },
              { label: "Candidate Display Items", value: "oneTimeBuyFlag" },

            ]}
            label="-Criteria-"
            alignItems="inline"
            classNameMemi="MultiUnitScreenDropwdownButton"
            value={selectedCriteria}
            setValue={handleSelectDepartment}
          />
        </div>
        <div style={{ alignItems: "center", width: "14%" }}>
          <OutlinedInput
            placeholder="Search..."
            className="MultiUnitScreenTextField"
            value={selectedCriteriaSearch}
            disabled={selectedCriteria === "oneTimeBuyFlag" ? true : false}
            onChange={(e) => AppData.setSelectedCriteriaSearch(e.target.value)}
            inputProps={{ maxLength: 30 }}
          />
        </div>

        <div style={{ alignItems: "center", width: "9%" }}>
          <ButtonMemi
            classNameMemi="MultiUnitScreenSearchButton MultiUnitScreenButtonMarginLeft"
            btnval="Search"
            onClick={onSearchClick}
          />
        </div>

        <div style={{ alignItems: "center" }}>
          <Loop
            className="MultiUnitScreenIconButton MultiUnitScreenButtonMarginLeft"
            onClick={onClickReset}
          />
        </div>
        <ButtonLogout
          classNameMemi="OverideHeaderLogout"
        />
      </div>
    </Grid>
  )


  return (
    <PageLayoutMemi
      pageTitle=""
      mainContent={<DisplayerItems onLoadFunc={onLoadFunc} />}
      navigationBar={HeaderMultiUnitScreen}
      footer={<Footer />}
      isBroder={true}
      fullHeight={true}
    />
  );
};

export default MEMI16;

