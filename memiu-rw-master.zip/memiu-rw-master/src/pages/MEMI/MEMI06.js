import React, { useEffect, useState, useContext, useRef } from "react";
import PageLayoutMemi from '../../components/PageLayoutMemi/PageLayoutMemi';
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import LookupQuery from "components/LookupQuery/LookupQuery";
import { KeyboardArrowDownTwoTone, KeyboardArrowUpTwoTone } from '@material-ui/icons';
import ApplicationContext from "../../context/ApplicationContext";
import NoRecordsDisplay from "components/NoRecordsDisplay/NoRecordsDisplay";

export const MEMI08 = () => {
  const AppData2 = useContext(ApplicationContext)
  const [direction, setDirection] = useState("up")
  const { companyId, divisionId } = AppData2;

  const handleArrowClick = () => {
    if (direction === "up") {
      setDirection("down");
    }
    else {
      setDirection("up");
    }
  }

  const header = (
    <div className="lookupScreenHeader">
      <span className="lookupSubHeading"> <big> LookUp Screen </big> </span>

      {direction === "down" ?
        <KeyboardArrowDownTwoTone className="lookupArrowIcon" onClick={handleArrowClick} /> :
        <KeyboardArrowUpTwoTone className="lookupArrowIcon" onClick={handleArrowClick} />
      }

    </div>
  )

  
  return (<PageLayoutMemi
    pageTitle={companyId === "" || divisionId === "" ? <NoRecordsDisplay /> : header}
    mainContent={companyId === "" || divisionId === "" ? "" : <LookupQuery direction={direction} />}
    navigationBar={<NavigationBar />}
    fullHeight={companyId !== "" && divisionId !== ""}
  // footer={<Footer />}
  />);
};

export default MEMI08;
