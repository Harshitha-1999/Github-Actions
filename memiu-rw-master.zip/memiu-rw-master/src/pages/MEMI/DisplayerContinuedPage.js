import React, { useEffect, useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Footer from "../../components/Footer/Footer";
import DisplayerScreenCont from "../../components/DisplayerScreenCont/DisplayerScreenCont";
import ApplicationContext from "../../context/ApplicationContext";
import {
  MEMI14_AAxios,
  MEMI24_AAxios,
  MEMI24_BAxios,
  MEMI24_CAxios,
} from "../../api/memiuAxiosInstances/memiuAxiosInstances";

export const DisplayerContinuedPage = () => {
  const AppData = useContext(ApplicationContext);

  useEffect(() => {
    MEMI14_AAxios.get("/").then((res) => {
      AppData.setMemi14_A(res.data);
    });
    MEMI24_AAxios.get("/").then((res) => {
      AppData.setMemi24_A(res.data);
    });
    MEMI24_BAxios.get("/").then((res) => {
      AppData.setMemi24_B(res.data);
    });
    MEMI24_CAxios.get("/").then((res) => {
      AppData.setMemi24_C(res.data);
    });
  });

  return (
    <PageLayoutMemi
      pageTitle="Displayer Cont"
      mainContent={<DisplayerScreenCont AppData={AppData} />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default DisplayerContinuedPage;
