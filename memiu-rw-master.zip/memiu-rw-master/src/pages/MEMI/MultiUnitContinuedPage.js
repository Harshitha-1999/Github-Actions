import React, { useEffect, useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import MultiUnitScreen from "components/MultiUnitScreen/MultiUnitScreen";
import ApplicationContext from "../../context/ApplicationContext";
import { MEMI21Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";
import { MEMI22Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";
import ButtonMemi from '../../components/ButtonMemi/ButtonMemi';
import SplitButtonMemi from '../../components/SplitButtonMemi/SplitButtonMemi'
import "../../css/App.css";
import TextField from '@material-ui/core/TextField';
import RefreshIcon from "@material-ui/icons/Refresh";
import IconButton from "@material-ui/core/IconButton";
import RadioMemi from "../../components/RadioMemi/RadioMemi";

// import {ApiMemi} from "../../components/ApiCallsMemi/ApiCallsMemi"
// import {apiUrl} from "../../service/apiUrls"
function sayHi() {
}

// const url=apiUrl.targetsource
export const MultiUnitContinuedPage = () => {
  const AppData = useContext(ApplicationContext);

  useEffect(() => {
    MEMI21Axios.get("/").then((res) => {
      AppData.setMemi21(res.data);
    });
    MEMI22Axios.get("/").then((res) => {
      AppData.setMemi22(res.data);
    });
  });

  const buttonRow1 = (
    <div className="multibtn">

      <ButtonMemi
        btncolor="primary"
        classNameMemi="notmulti0"
        btnval="Selected Target UPC"
        btnvariant="contained"
      />
      <SplitButtonMemi splitbtn="splitdrop1" splitbtnmemi="splitbtn" />
      <TextField variant="outlined"
        placeholder="search source Items"
        className="searchsource"
      />
      <ButtonMemi
        btncolor="primary"
        classNameMemi="notmulti1"
        btnval="Search"
        btnvariant="contained"
      />
      <IconButton onClick={sayHi} className="iconbtn">
        <RefreshIcon />
      </IconButton>

      <ButtonMemi
        btncolor="primary"
        classNameMemi="searchmlt1"
        btnval="Filter"
        btnvariant="contained"
      />
      <ButtonMemi
        btncolor="primary"
        classNameMemi="notmulti2"
        btnval="Load More"
        btnvariant="contained"
      />
    </div>
  )

  const buttonRow2 = (
    <div className="multibtn">


      <ButtonMemi
        btncolor="primary"
        classNameMemi="notmulti0"
        btnval="Selected Source UPC"
        btnvariant="contained"
      />
      <SplitButtonMemi splitbtn="splitdrop1" splitbtnmemi="splitbtn" />
      <TextField variant="outlined"
        placeholder="search source Items"
        className="searchsource"
      />
      <ButtonMemi
        btncolor="primary"
        classNameMemi="notmulti1"
        btnval="Search"
        btnvariant="contained"
      />
      <IconButton onClick={sayHi} className="iconbtn">
        <RefreshIcon />
      </IconButton>

      <ButtonMemi
        btncolor="primary"
        classNameMemi="searchmlt1"
        btnval="Filter"
        btnvariant="contained"
      />
      <ButtonMemi
        btncolor="primary"
        classNameMemi="notmulti2"
        btnval="Load More"
        btnvariant="contained"
      />
    </div>
  )

  return (
    <PageLayoutMemi
      pageTitle="MultiUnitScreen"
      mainContent={
        <div>
          <RadioMemi
            radioclassmemi="radio1"
            classnameMemi="radclass1"
            Mainlabel="Mapping Status"
            label={[
              { value: "to_be_matched", label: "To be Reached" },
              { value: "manually_matched", label: "Manually Matched" },
              { value: "Auto_Matched", label: "Auto Matched" },

            ]}
          />
          <MultiUnitScreen memi21data={AppData.memi21} heading1="sourceItems" heading2="Target Items" buttonRow1={buttonRow1} buttonRow2={buttonRow2} memi22data={AppData.memi22} />
        </div>

      }
      navigationBar={<NavigationBar />}
    // footer={<Footer />}
    />
  );
};

export default MultiUnitContinuedPage;

