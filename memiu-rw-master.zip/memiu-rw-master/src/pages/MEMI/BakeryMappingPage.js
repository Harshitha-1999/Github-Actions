import React, { useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import BakeryMapping from "../../components/BakeryMapping/BakeryMapping";
import ApplicationContext from "../../context/ApplicationContext";
import NoRecordsDisplay from "components/NoRecordsDisplay/NoRecordsDisplay";

export const BakeryMappingPage = () => {

  const AppData = useContext(ApplicationContext);
  const { companyId, divisionId } = AppData;

  return (
    <PageLayoutMemi
      pageTitle=""
      navigationBar={<NavigationBar />}
      // mainContent={<BakeryMapping /> }
      // fullHeight={companyId === "" && divisionId === ""}
      mainContent={companyId && divisionId ? <BakeryMapping /> : <NoRecordsDisplay />}
      fullHeight={companyId && divisionId}
    // footer={<Footer />}
    />
  );
};

export default BakeryMappingPage;
