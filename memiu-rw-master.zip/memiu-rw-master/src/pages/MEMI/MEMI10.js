import React, { useEffect, useContext } from "react";

import PageLayoutMemi from '../../components/PageLayoutMemi/PageLayoutMemi';
import NavigationBar from "../../components/NavigationBar/NavigationBar";

import Footer from "../../components/Footer/Footer";

import ApplicationContext from "../../context/ApplicationContext";
import {

  MEMI08Axios,

} from "../../api/memiuAxiosInstances/memiuAxiosInstances";
import LookupQuery from "components/LookupQuery/LookupQuery";





export const MEMI10 = () => {
  const AppData = useContext(ApplicationContext)

  useEffect(() => {

    MEMI08Axios.get("/").then((res) => {
      AppData.setMemi08(res.data);
    });
  }); // [] commented





  return (<PageLayoutMemi
    pageTitle="Lookup Screen"
    mainContent={<LookupQuery />}
    navigationBar={<NavigationBar />}
    footer={<Footer />}
  />);
};

export default MEMI10;
