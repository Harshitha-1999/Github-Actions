import React from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Footer from "../../components/Footer/Footer";
import LookupQuery from "../../components/LookupQuery/LookupQuery";

export const MEMI15 = () => {

  return (
    <PageLayoutMemi
      pageTitle="Displayer Screen"
      mainContent={<LookupQuery />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default MEMI15;

