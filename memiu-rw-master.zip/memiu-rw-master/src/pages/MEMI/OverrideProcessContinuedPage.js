import React, { useCallback, useContext, useEffect, useState } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import HeaderOverideProcessContd from '../../components/HeaderOverideProcessContd/HeaderOverideProcessContd';
import OverrideProcessCont from "../../components/OverrideProcessCont/OverrideProcessCont";
import ApplicationContext from "../../context/ApplicationContext";
import { memiuServices } from "api/memiu/memiuService";


export const OverrideProcessContinuedPage = (props) => {
  const AppData = useContext(ApplicationContext);

  const { state } = props.location
  const { companyId, divisionId, updateoverridesku, UpdateOverrideManualSearch } = AppData;
  const [pageNumber, setPageNumber] = useState(0);

  let updUsgeIndOptions2 = ["E", "M", "Q", "R"];
  let UpdateOverrideLikeSrcEditDetails;
  let currentUsageInd = ""
  /**
     *  Load usage type combo
     */
  const loadUsageTypeCombo = (newItemDto) => {
    if (!newItemDto)
      return;

    /**Added by NFRAN for bug fix**/
    if (newItemDto.innerPack === null) {
      newItemDto.innerPack = 1;
    }

    if (newItemDto.retailUnitPack === null || newItemDto.retailUnitPack === 0) {
      newItemDto.retailUnitPack = newItemDto.packwhse;
    }
    /**Added by NFRAN for bug fix**/

    if (currentUsageInd !== null && currentUsageInd === newItemDto.updUsgeInd)
      return;

    var val = newItemDto.updUsgeInd;

    currentUsageInd = val;
    updUsgeIndOptions2 = []

    if (val == 'E') {
      updUsgeIndOptions2.push('L');
      updUsgeIndOptions2.push('O');
      updUsgeIndOptions2.push('W');
      if (newItemDto.updUsageTypInd !== 'L' &&
        newItemDto.updUsageTypInd !== 'O' &&
        newItemDto.updUsageTypInd !== 'W')
        newItemDto.updUsageTypInd = 'L';
    }

    if (val === 'M') {
      updUsgeIndOptions2.push('M');
      newItemDto.updUsageTypInd = 'M';
    }

    if (val === 'Q') {
      updUsgeIndOptions2.push('');
      newItemDto.updUsageTypInd = ' ';
    }

    if (val === 'R') {
      updUsgeIndOptions2.push('C');
      updUsgeIndOptions2.push('R');
      updUsgeIndOptions2.push('S');
      if (newItemDto.updUsageTypInd !== 'C' &&
        newItemDto.updUsageTypInd !== 'R' &&
        newItemDto.updUsageTypInd !== 'S')
        newItemDto.updUsageTypInd = 'C';
    }

    if (!val) {
      newItemDto.updUsageTypInd = ' ';
    }

    return newItemDto
  };

  /*
  load uom list
  */
  const loadUomList = useCallback(() => {
    memiuServices.getUOMList().then((res) => {
      AppData.setUOMList(res.data);
    })
      .catch((error) => {
      })
  }, [])

  /*
  load Smic desc
  */

  const loadSmicDesc = (newItemDto) => {
    let uiEditObj = newItemDto;
    let groupCode = 0;
    let categoryCode = 0;
    let classCode = 0;
    let subClassCode = 0;
    let subSubClassCode = 0;
    if (uiEditObj.grpCd === null || uiEditObj.ctgryCd === null || uiEditObj.grpCd.length === 0 || uiEditObj.ctgryCd.length === 0) {
      AppData.setSmicDetails(null)
      return;
    }
    else {
      groupCode = uiEditObj.grpCd;
      categoryCode = uiEditObj.ctgryCd;
      if (uiEditObj.clsCd == null || uiEditObj.clsCd.length == 0)
        classCode = 0;
      else
        classCode = uiEditObj.clsCd;
      if (uiEditObj.sbClsCd == null || uiEditObj.sbClsCd.length == 0)
        subClassCode = 0;
      else
        subClassCode = uiEditObj.sbClsCd;
      if (uiEditObj.subSbClass == null || uiEditObj.subSbClass.length == 0) {
        subSubClassCode = 0;
      }
      else {
        subSubClassCode = uiEditObj.subSbClass;
        memiuServices.getSmicDetails(groupCode, categoryCode, classCode, subClassCode, subSubClassCode)
          .then((data) => {
            if (data.data.length > 0) {
              AppData.setSmicDetails(data.data[0].smicdesc)
            }
            else {
              AppData.setAlertBox(true, "Invalid SMIC Code.")
            }
          })
          .catch((error) => {
          })
      }
    }

  }

  const loadOverideDetails = useCallback(() => {
    memiuServices.getUpdateOverideManualSearch(companyId, divisionId, updateoverridesku[pageNumber])
      .then((res) => {
        UpdateOverrideLikeSrcEditDetails = res.data
        if (UpdateOverrideLikeSrcEditDetails.uiEceptionSrcDto.excptnProInd === "C") {
          for (let i = 0; i < UpdateOverrideLikeSrcEditDetails.likeItems.length; i++) {
            UpdateOverrideLikeSrcEditDetails.likeItems[i].mostRecommendedItem = false;
          }
        }
        UpdateOverrideLikeSrcEditDetails.newItemDto = loadUsageTypeCombo(UpdateOverrideLikeSrcEditDetails.newItemDto);
        loadSmicDesc(UpdateOverrideLikeSrcEditDetails.newItemDto);
        console.log(UpdateOverrideLikeSrcEditDetails)
        AppData.setMemi14({ UpdateOverrideManualSearch: UpdateOverrideLikeSrcEditDetails })
      })
      .catch((error) => {
        console.log(error)
      })
  }, [companyId, divisionId, updateoverridesku, pageNumber, UpdateOverrideLikeSrcEditDetails])

  const loadSkuDetails = useCallback(() => {
    let type = ""
    if (UpdateOverrideManualSearch && UpdateOverrideManualSearch.uiEceptionSrcDto) {
      if (UpdateOverrideManualSearch.uiEceptionSrcDto.productSrcCd == "WHSE") {
        type = 'W';
      }
      else {
        type = 'D';
      }
      memiuServices.getLoadOverideData2(UpdateOverrideManualSearch.uiEceptionSrcDto.hierLevel4, "O", UpdateOverrideManualSearch.uiEceptionSrcDto.companyId, UpdateOverrideManualSearch.uiEceptionSrcDto.divisionId, UpdateOverrideManualSearch.uiEceptionSrcDto.excptnProInd, type)
        .then((res) => {
          if (res.data === null || res.data.length === 0) {
            AppData.setAlertBox(true, "No more item to view.")
          }
          else {
            let { data } = res
            data.sort((a, b) => { return Number(a) - Number(b) });
            setPageNumber(data.findIndex((sku) => sku === UpdateOverrideManualSearch.uiEceptionSrcDto.productSKU))
            AppData.setMemi14({ updateoverridesku: data })

          }
        })
        .catch((err) => {
        })
    }
  }, [UpdateOverrideManualSearch, companyId, divisionId, pageNumber])

  useEffect(() => {
    loadUomList();
    AppData.setAppState({});
    AppData.setMemi03Sku(null);
    AppData.setMemi03SkuSelected([]);
    AppData.setMemi03Cic(null)
    AppData.setMemi14({ UpdateOverrideManualSearch: {} })
  }, [])

  useEffect(() => {
    if (updateoverridesku && updateoverridesku.length === 0 && UpdateOverrideManualSearch) {
      loadSkuDetails();
    }
  }, [updateoverridesku, UpdateOverrideManualSearch, companyId, divisionId, state])

  useEffect(() => {
    if (updateoverridesku && updateoverridesku.length > 0) {
      loadOverideDetails()
    }
  }, [pageNumber, companyId, divisionId, updateoverridesku])

  return (
    <PageLayoutMemi
      navigationBar={<HeaderOverideProcessContd title="UPC Match / Model Like Item" />}
      mainContent={
        <OverrideProcessCont
          loadUomList={loadUomList}
          loadSmicDesc={loadSmicDesc}
          updUsgeIndOptions2={updUsgeIndOptions2}
          pageNumber={pageNumber}
          setPageNumber={setPageNumber}
          loadUsageTypeCombo={loadUsageTypeCombo}
        />
      }
      isBroder

    />
  );
};

export default OverrideProcessContinuedPage;
