import React, { useEffect, useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Footer from "../../components/Footer/Footer";
//import AugmentationTable from "../../components/AugmentationTable/AugmentationTable";
import ApplicationContext from "../../context/ApplicationContext";
import { MEMI23Axios } from "../../api/memiuAxiosInstances/memiuAxiosInstances";
import DisplayerScreen from "components/DisplayerScreen/DisplayerScreen";
import { ApiMemi } from "../../components/ApiCallsMemi/ApiCallsMemi"
import { apiUrl } from "../../service/apiUrls"

export const DisplayerPage = () => {

    const AppData = useContext(ApplicationContext);

    useEffect(() => {
        AppData.setMemi16Criteria({});
        AppData.mapSelectedRowData([]);
        AppData.setSelectedCriteria("itemDesc")
        AppData.setSelectedCriteriaSearch("")
        AppData.mapSelectedRowData([]);
    }, []);

  return (
    <PageLayoutMemi
      // pageTitle="Displayer"
      mainContent={<DisplayerScreen />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default DisplayerPage;
