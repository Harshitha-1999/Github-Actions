import React, { useContext, useEffect, useRef } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import ApplicationContext from "../../context/ApplicationContext";
import ModelLikeMatch from "components/ModelItemsMatch/ModelLikeMatch";
import { memiuServices } from "api/memiu/memiuService";

export const UPCMatchPage = () => {
  const AppData = useContext(ApplicationContext);
  const AppData2 = useRef(useContext(ApplicationContext))
  const { divisionId, companyId } = AppData;

  useEffect(() => {

    if (divisionId === "" || companyId === "") { return }
    else {
      let totalUnReviewDsd = 0;
      let totalUnReviewWHSE = 0;
      let totalUnReview = 0

      let totalReviewDsd = 0;
      let totalReviewWHSE = 0;
      let totalReview = 0

      AppData2.current.setMemi13({ data: [], totalUnReviewDsd, totalUnReviewWHSE, totalUnReview, totalReviewWHSE, totalReviewDsd, totalReview })
      memiuServices.getLoadOverideData(companyId, divisionId)
        .then((res) => {
          let data = res.data.map((data, index) => {
            totalUnReviewWHSE += data.totalWHSERecords;
            totalUnReviewDsd += data.totalDSDRecords;
            totalUnReview += data.totalRecord;

            totalReviewWHSE += data.completedWHSEItmCnt;
            totalReviewDsd += data.completedDSDItmCnt;
            totalReview += data.completedItmCnt;

            return { ...data, id: index }
          })

          data.sort((a, b) => {
            let fa = a["deptName"].toLowerCase()
            let fb = b["deptName"].toLowerCase()
            if (fa < fb) {
              return -1;
            }
            if (fa > fb) {
              return 1;
            }
            return 0;
          })

          AppData2.current.setMemi13({ data, totalUnReviewDsd, totalUnReviewWHSE, totalUnReview, totalReviewWHSE, totalReviewDsd, totalReview })
        })
        .catch((err) => {
        })
    }
  }, [divisionId, companyId])



  return (
    <PageLayoutMemi
      mainContent={<ModelLikeMatch />}
      navigationBar={<NavigationBar />}
      isBroder={false}
    />
  );
};
export default UPCMatchPage;