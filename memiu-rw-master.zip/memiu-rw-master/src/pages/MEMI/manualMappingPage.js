import React from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Footer from "../../components/Footer/Footer";
import MapItems from "../../components/MapItems/MapItems"
import "../../css/App.css";

export const manualMappingPage = (props) => {

  return (
    <PageLayoutMemi
      mainContent={<MapItems />}
      navigationBar={<NavigationBar />}
      footer={<Footer />}
    />
  );
};

export default manualMappingPage;
