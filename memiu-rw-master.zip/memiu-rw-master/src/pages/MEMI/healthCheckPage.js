import React, { useEffect, useContext } from "react";




export const healthCheckPage = () => {

  return (
 <div>
   <strong>App is running!!</strong>
 </div>
    );
};

export default healthCheckPage;
