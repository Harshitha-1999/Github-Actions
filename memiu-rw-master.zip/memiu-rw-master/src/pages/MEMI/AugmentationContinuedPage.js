import React, { useEffect, useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import HeaderOverideProcessContd from '../../components/HeaderOverideProcessContd/HeaderOverideProcessContd';
import AugmentationScreen from "components/AugmentationScreen/AugmentationScreen";
import ApplicationContext from "context/ApplicationContext";


export const AugmentationContinuedPage = (props) => {
  const AppData = useContext(ApplicationContext)
  useEffect(() => {
    //resetting state managment
    AppData.setAppState({});
    AppData.setMemi03Sku(null);
    AppData.setMemi03SkuSelected([]);
    AppData.setMemi03Cic(null)
  }, [])
  return (
    <PageLayoutMemi
      mainContent={<AugmentationScreen
        AugmentedDisplayerServiceKey={props.location.state && props.location.state.AugmentedDisplayerServiceKey ? props.location.state.AugmentedDisplayerServiceKey : null}
        disableDefaultNeedReview={props.location.state && props.location.state.disableDefaultNeedReview ? props.location.state.disableDefaultNeedReview : null}
      />}
      navigationBar={<HeaderOverideProcessContd title="New UPC / No Item Match" />}
      isBroder
    />
  );
};

export default AugmentationContinuedPage;
