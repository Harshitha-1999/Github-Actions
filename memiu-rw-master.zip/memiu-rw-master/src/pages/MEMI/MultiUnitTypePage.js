import React, { useState, useContext, useEffect, useCallback } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import MultiUnitScreen from "components/MultiUnitScreen/MultiUnitScreen";
import ApplicationContext from "../../context/ApplicationContext";
import RadioMemi from "../../components/RadioMemi/RadioMemi";
import NoRecordsDisplay from "components/NoRecordsDisplay/NoRecordsDisplay";
import { memiuServices } from "api/memiu/memiuService";
import { loadMore } from 'utils/CommonFunctions'

export const MultiUnitTypePage = () => {

  const AppData = useContext(ApplicationContext);
  const [MappingStatus, setMappingStatus] = useState("P")
  const { companyId, divisionId, memi21_sourceItems } = AppData;

  const onLoadMultiUnit = useCallback(() => {

    if (companyId !== "" && divisionId !== "") {

      AppData.setMemi21_sourceItems([])
      AppData.setMemi21_targetItems([])
      AppData.setMultiUnitFilterDeptname([]);
      AppData.setMultiUnitFilterRetailSection([]);

      memiuServices.getSourceTargetData(companyId, divisionId, MappingStatus)
        .then((res) => {

          AppData.setMultiUnitFilterDeptname(res.data.multiUnitSource);
          let currentSrcPageCount = loadMore(0, res.data.multiUnitSource ? res.data.multiUnitSource.length : 0);
          let multiUnitSrcCurrentPgData = [];
          let multiUnitSrcDisplayData = [];

          if (res.data.multiUnitSource) {
            res.data.multiUnitSource.map((data, index) => {

              multiUnitSrcDisplayData.push({
                ...data, id: index, displayUpc: data.upcs[0].charAt(0) + "-" + data.upcs[0].charAt(1) + "-" + data.upcs[0].substring(2, 7) + "-" + data.upcs[0].substring(7, 12)
              });

              if (index < currentSrcPageCount) {

                multiUnitSrcCurrentPgData.push({
                  ...data, id: index, displayUpc: data.upcs[0].charAt(0) + "-" + data.upcs[0].charAt(1) + "-" + data.upcs[0].substring(2, 7) + "-" + data.upcs[0].substring(7, 12)
                });

              }
            });
          }

          AppData.setMultiUnitSrcData(multiUnitSrcDisplayData);
          AppData.setMemi21_sourceItems(multiUnitSrcCurrentPgData);

          AppData.setMultiUnitFilterRetailSection(res.data.multiUnitTarget);
          let currentTargetPageCount = loadMore(0, res.data.multiUnitTarget ? res.data.multiUnitTarget.length : 0);
          let multiUnitTargetCurrentPgData = [];
          let multiUnitTargetDisplayData = [];

          if(res.data.multiUnitTarget) {
            res.data.multiUnitTarget.map((data, index) => {

              multiUnitTargetDisplayData.push({
                ...data, id: index, displayUpc: data.upcList[0].charAt(0) + "-" + data.upcList[0].charAt(1) + "-" + data.upcList[0].substring(2, 7) + "-" + data.upcList[0].substring(7, 12)
              });
  
              if (index < currentTargetPageCount) {
  
                multiUnitTargetCurrentPgData.push({
                  ...data, id: index, displayUpc: data.upcList[0].charAt(0) + "-" + data.upcList[0].charAt(1) + "-" + data.upcList[0].substring(2, 7) + "-" + data.upcList[0].substring(7, 12)
                });
  
              }
            });
          }
         
          AppData.setMultiUniTargetData(multiUnitTargetDisplayData);
          AppData.setMemi21_targetItems(multiUnitTargetCurrentPgData);

        })
        .catch((error) => {

          AppData.setMultiUniTargetData([]);
          AppData.setMemi21_targetItems([]);
          console.log(error)
          // AppData.setAlertBox(true, "Error")
        })
    }
  }, [companyId, divisionId, MappingStatus]);



  useEffect(() => {
    onLoadMultiUnit();

  }, [companyId, divisionId, MappingStatus])

  const HeaderMultiUnitScreen = (
    <div style={{ display: "flex", alignItems: "center", width: "100%" }}>
      <div style={{ justifyContent: "flex-start", display: "flex", flexDirection: "row", alignItems: "center" }}>
        <img src="/MultiUnitTypeLogo.png" alt="multiUnitType" />
        <big style={{ fontWeight: "bold", color: "#055166", fontSize: "21px" }}> Multi Unit Type Items</big>
      </div>
      <div style={{ width: "fitContent", marginLeft: "8%" }}>
        <RadioMemi
          Mainlabel="Mapping Status:"
          label={[{ label: "To Be Matched", value: "P" }, { label: "Manually Matched", value: "M" }, { label: "Auto Matched", value: "A" }]}
          classnameMemi="RadioMultiUnitScreen"
          labelClass="RadioMultiUnitScreenLabel"
          radioGroupClass="RadioMultiUnitScreenRadioClass"
          value={MappingStatus}
          setValue={(value) => setMappingStatus(value)}
          size="small"
        />

      </div>
    </div>
  )

  return (
    <PageLayoutMemi
      navigationBar={<NavigationBar />}
      pageTitle={AppData.companyId !== "" && AppData.divisionId !== "" ? HeaderMultiUnitScreen : <NoRecordsDisplay />}
      mainContent={
        AppData.companyId !== "" && AppData.divisionId !== "" ? <MultiUnitScreen onLoadMultiUnit={onLoadMultiUnit} MappingStatus={MappingStatus} /> : ""
      }

    // footer={<Footer />}
    />
  );
};

export default MultiUnitTypePage;

