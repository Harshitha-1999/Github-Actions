import React, { useEffect, useContext } from "react";
import PageLayoutMemi from "../../components/PageLayoutMemi/PageLayoutMemi";
import NavigationBar from "../../components/NavigationBar/NavigationBar";
import Mapped from "../../components/Mapped/Mapped";
import { memiuServices } from "api/memiu/memiuService";
import ApplicationContext from "../../context/ApplicationContext";
import NoRecordsDisplay from "components/NoRecordsDisplay/NoRecordsDisplay";

export const MappedPage = () => {

  const AppData = useContext(ApplicationContext);
  const { divisionId, companyId } = AppData;

  useEffect(() => {

    if (companyId !== "" && divisionId !== "") {
      memiuServices.getSourceDepartment(companyId, divisionId)
        .then((res) => {
          AppData.setSourceDepartment(res.data.map(x => { return { label: x[1], value: x[0] } }))
        })
        .catch((err) => {
        })
      memiuServices.getTargetDepartment(companyId, divisionId)
        .then((res) => {
          AppData.setTargetDepartment(res.data.map(x => { return { label: x[0], value: x[1] } }))
        })
        .catch((err) => {
        })
    }

  }, [companyId, divisionId]);

  return (
    <PageLayoutMemi
      navigationBar={<NavigationBar />}
      mainContent={
        companyId !== "" && divisionId !== "" ? <Mapped /> : <NoRecordsDisplay />
      }
      fullHeight={companyId !== "" && divisionId !== ""}
    />
  );
};

export default MappedPage;
