import React, {useCallback} from 'react';
import { LabelWidget } from 'components';
import {LOGIN_ROOT} from 'api/constants';
import "./Header.scss";

export const Header = ({ programName, foNumber, screenName, pageNumber }) => {

    const handleLogout = useCallback( () => {
        //Clear browser session storage on logout.
        sessionStorage.clear();
        window.location.replace(`${LOGIN_ROOT}/azurelogout`);
    },[]);
    
    return (
        <React.Fragment>
            <div className='logout' align="right">
                <button onClick={handleLogout}>Logout</button>
            </div>
            <div className="screenHeader">
                <LabelWidget controlId={`lbl${programName}`} label={programName} />
                {foNumber &&
                    <div className="firmOrderNumber">
                        <LabelWidget controlId={"lblFoNumber"} label={"FO#:"} />
                        <input id="txtFoNumber" type="text" readOnly value={foNumber} />
                    </div>
                }
                <LabelWidget controlId={`lbl${programName}screen`} label={screenName} />
                {pageNumber &&
                    <div className="pageNumber">
                        <LabelWidget controlId={"lblPageNumber"} label={"Page:"} />
                        <input id="txtPageNumber" type="text" readOnly value={pageNumber} />
                    </div>
                }
            </div>
        </React.Fragment>
    );
}

export default Header;