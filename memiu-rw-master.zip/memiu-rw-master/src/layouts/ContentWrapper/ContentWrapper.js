import React from "react";
import { SiteWideHelpScreen, ServiceError } from 'components';
import { Header, Footer } from 'layouts';
import { useHelp } from "hooks";


export const ContentWrapper = ({ children, programName, foNumber, screenName, pageNumber, error, pfKeys, onHotKeyPress }) => {

    const { helpOptions } = useHelp();

    return (
        <React.Fragment>
            {error ?
                <ServiceError programName={programName} error={error} />
                :
                helpOptions.isOpen ?
                    <SiteWideHelpScreen />
                    :
                    <>
                        <Header programName={programName} foNumber={foNumber} screenName={screenName} pageNumber={pageNumber} />
                        {children}
                        <Footer pfKeys={pfKeys} onHotKeyPress={onHotKeyPress} />
                    </>
            }
        </React.Fragment>
    );
};

export default ContentWrapper;