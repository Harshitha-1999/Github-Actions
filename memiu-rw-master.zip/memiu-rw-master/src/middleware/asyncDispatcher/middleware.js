import handleDispatchLifecycle from './util/handleDispatchLifecycle';

const isPromise = (obj) => obj instanceof Promise;

const isEmpty = (item) =>
  item === '' || item === 'undefined' || item === null;

const isAction = (action) =>
  Object.prototype.hasOwnProperty.call(action, 'promise') &&
  !isEmpty(action.promise) &&
  isPromise(action.promise);

const shouldHandleAction = (action) => isAction(action);

const middleware = (store) => (next) => (
  action
) =>
  shouldHandleAction(action)
    ? handleDispatchLifecycle(store.dispatch, action)
    : next(action);

export default middleware;
