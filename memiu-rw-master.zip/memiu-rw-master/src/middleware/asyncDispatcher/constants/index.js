export const PROMISE_TYPE = {
  AXIOS: 'axios',
  DEFAULT: 'default',
}

export const INITIAL_AD_STATE = {
  response: null,
  error: null,
  loading: false,
};

export const TYPE = {
  LIFECYCLE: 'AD/LIFECYCLE',
}

export const LIFECYCLE_STAGES = {
  START: 'start',
  FINISH: 'finish',
  SUCCESS: 'success',
  FAILURE: 'failure',
}
