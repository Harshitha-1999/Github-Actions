
import { LIFECYCLE_STAGES } from '../constants';
import { createLifecycleAction } from './createLifecycleAction';

export const createDispatchPromiseHandle = (
  dispatch,
  { type, promise }
) => {
  if (promise) {
    dispatch(
      createLifecycleAction({
        type,
        lifecycle: LIFECYCLE_STAGES.START,
      })
    );
    return promise
      .then((res) => {
        dispatch(
          createLifecycleAction({
            type,
            payload: res,
            lifecycle: LIFECYCLE_STAGES.SUCCESS,
          })
        );
      })
      .catch((error) => {
        dispatch(
          createLifecycleAction({
            type,
            error,
            lifecycle: LIFECYCLE_STAGES.FAILURE,
          })
        );
      })
      .finally(() => {
        dispatch(
          createLifecycleAction({
            type,
            lifecycle: LIFECYCLE_STAGES.FINISH,
          })
        );
      });
  } else {
    return null;
  }
};

export default createDispatchPromiseHandle;
