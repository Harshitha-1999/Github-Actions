import { INITIAL_AD_STATE } from '../constants';

export const createInitialState = (initialState) =>
  Object.assign(INITIAL_AD_STATE, initialState);

export default createInitialState;
