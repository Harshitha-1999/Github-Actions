export const createReducer = (initialState, hook) => (
  state = initialState,
  action
) => hook(state, action);

export default createReducer;
