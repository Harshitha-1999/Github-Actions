import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import {
  ReduxProvider,
  ErrorBoundary,
  AppContextProvider,

  LogContextProvider,
  ApplicationContextProvider,
} from "./providers";
import "./index.scss";
import AlertBoxMemi from "components/AlertBoxMemi/AlertBoxMemi";
import TableModalMemi from "components/TableModalMemi/TableModalMemi";
import AlertMessageMemi from "components/AlertMessageMemi/AlertMessageMemi";
import ConfirmationModalMemi from "components/ConfirmationModalMemi/ConfirmationModalMemi";
import FileUploadModal from "components/FileUploadModalMemi/FileUploadModalMemi";
import BakeryMappingModal from "components/BakeryMappingModal/BakeryMappingModal";
import LoaderMeup from "components/LoaderMeup/LoaderMeup";

ReactDOM.render(
  <React.StrictMode>
    <ReduxProvider>
      {/* <ErrorBoundary> */}
      <AppContextProvider>
        <LogContextProvider>
          <ApplicationContextProvider>
            <ErrorBoundary>
              <App />
              </ErrorBoundary>
              <AlertBoxMemi />
              <TableModalMemi />
              <AlertMessageMemi />
              <ConfirmationModalMemi />
              <FileUploadModal />
              <BakeryMappingModal />
            </ApplicationContextProvider>
          </LogContextProvider>
        </AppContextProvider>
    </ReduxProvider>
  </React.StrictMode>,
  document.getElementById("root")
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
