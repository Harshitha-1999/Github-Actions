import React, { useState, useReducer } from "react";
import { LogContext } from "../context/LogContext";
import { logReducer } from "../context/LogReducer";
import { ADD_STRING } from "../context/LogConstants";

export const LogContextProvider = (props) => {
  let initialState = {
    messages: [
      { id: "1", msg: "an error occcured on the server" },
      { id: "2", msg: "an api sent information back" },
      { id: "3", msg: "a component had an error" },
    ],
  };
  let [state, dispatch] = useReducer(logReducer, initialState);
  let [hideElement, setHideElement] = useState(false);

  const addString = (message) => {
    dispatch({
      type: ADD_STRING,
      payload: message,
    });
  };
  const deleteString = (messageId) => {
    dispatch({
      type: ADD_STRING,
      payload: messageId,
    });
  };

  return (
    <LogContext.Provider
      value={{
        messages: state.messages,
        addString,
        deleteString,
        hideElement,
        setHideElement,
      }}
    >
      {props.children}
    </LogContext.Provider>
  );
};

export default LogContextProvider;
