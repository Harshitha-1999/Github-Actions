import React, {useContext} from 'react';
import { ServiceError } from 'components';
import ApplicationContext from "../context/ApplicationContext";
import PropTypes from 'prop-types';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false ,
      error: '',
      errorInfo: '',
    };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true,error };
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    //logErrorToMyService(error, errorInfo);
    this.setState({ errorInfo });
    let AppData = this.context;
    AppData.setLoader(-1)
    AppData.setLogStatusResult("Error Stack")
    AppData.setLogStatus(errorInfo.componentStack.toString())
  }

  render() {
    const { hasError, errorInfo } = this.state;

    if (hasError) {
     
      // You can render any custom fallback UI
      // return (
      //   <ServiceError programName={"MEMIU"} error={{ config: { method: 'JS' }, message: "Internal JS Error" }} />
      // );
    }
    return this.props.children;
  }
}
ErrorBoundary.propTypes = {
  children: PropTypes.oneOfType([ PropTypes.object, PropTypes.array ]).isRequired,
};
ErrorBoundary.contextType = ApplicationContext;

export default ErrorBoundary;