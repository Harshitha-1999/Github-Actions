import React, { useReducer } from "react";
import { ApplicationContext } from "../context/ApplicationContext";
import { ApplicationReducer } from "../context/ApplicationReducer";
import {
  ADD_DATA,
  DELETE_DATA,
  SET_DATA,
  ADD_USERINFO,
  SET_USERINFO,
  ADD_LASTSEARCH,
  SET_LASTSEARCH,
  ADD_MEMI01,
  SET_MEMI01,
  SET_MEMI08,
  ADD_MEMI08,
  SET_MEMI13,
  SET_MEMI20,
  SET_MEMI22,
  ADD_MEMI13,
  SET_CONFIGURATION_SETS,
  ADD_CONFIGURATION_SETS,
  SET_CONFIGURATION_VARS,
  ADD_CONFIGURATION_VARS,
  ADD_MEMI17,
  SET_MEMI17,
  SET_MEMI18,
  ADD_MEMI23,
  SET_MEMI23,
  ADD_MEMI24_A,
  SET_MEMI24_A,
  ADD_MEMI24_B,
  SET_MEMI24_B,
  ADD_MEMI24_C,
  SET_MEMI24_C,
  SET_COMPANYID,
  SET_DIVISIONID,
  SET_DIVISIONS,
  SET_COMPANIES,
  SET_USERLEVEL,
  SET_ALERTBOX,
  SET_ALERTMESSAGE,
  SET_MEMI21_SOURCE_ITEMS,
  SET_MEMI21_TARGET_ITEMS,
  SET_TABLEMODAL,
  SET_DEPARTMENT,
  SET_LOOKUPSCREEN,
  SET_MEMI06,
  SET_LIST_DISPLAYER_DATA,
  SET_MEMI16_DATA,
  SET_MEMI16_CRITERIA,
  SET_SELECTED_ROWS,
  SET_FILEUPLOADMODAL,
  SET_FILEUPLOAD_DATA,
  SET_SELECTED_CRITERIA_SEARCH,
  SET_SELECTED_CRITERIA,
  SET_UOM_LIST,
  SET_CONFIRMATION_MODAL,
  SET_CONFIRMATION_MODAL_SEARCH,
  SET_UPDATEOVERIDESKU,
  SET_UPDATEOVERRIDEMANUALSEARCH,
  SET_UPDATEAUGMENTATIONMANUALSEARCH,
  SET_UPDATEAUGMENTATIONSKU,
  SET_SMIC_DETAILS,
  SET_MULTIUNIT_SRC_FILTER,
  SET_MULTIUNIT_TARGET_FILTER,
  SET_SOURCE_DEPARTMENT,
  SET_TARGET_DEPARTMENT,
  SET_MULTIUNIT_FILTER_DEPTNAME,
  SET_MULTIUNIT_FILTER_RETAILSECTION,
  SET_MULTIUNIT_SRC_DATA,
  SET_MULTIUNIT_TARGET_DATA,
  SET_MEMI03_SKU,
  SET_MEMI03_CIC,
  SET_MEMI03_SKU_SELECTED,
  SET_MEMI03_CIC_SELECTED,
  SET_MEMI03_SKU_PAYLOAD,
  SET_MEMI03_CIC_PAYLOAD,
  SET_MAPPING_MODAL,
  SET_LOADER,
  ADD_LOADER,
  SET_GROUP_DETAIL,
  SET_PRODUCTION_GROUP_DETAIL,
  SET_LOG_STATUS,
  SET_FULL_LOG_STATUS,
  SET_LOG_STATUS_RESULT,
  SET_AUGMENTATION_SERVICE_KEY,
  SET_OVERIDE_SERVICE_KEY,
  SET_AUGMENTATION_SERVICE_DEPARTMENT,
  SET_APP_STATE,
  ADD_APP_STATE,
  SET_AUGMENTATION_SERVICE_USAGE_TYPE,
  SET_OVERIDE_SERVICE_USAGE_TYPE
} from "../context/ApplicationConstants";
import { trimPLUFunc } from "utils";

export const ApplicationContextProvider = (props) => {
  let initialState = {
    data: [{}],
    userInfo: [{}],
    lastSearch: [{}],
    memi01: [{}],
    memi06: { searchResults: null, start_index: null, end_index: null },
    memi08: [],
    memi13: { data: [], totalUnReviewDsd: 0, totalUnReviewWHSE: 0, totalUnReview: 0, totalReviewWHSE: 0, totalReviewDsd: 0, totalReview: 0 },
    configurationSets: [{}],
    configurationVars: [{}],
    memi17: { data: [], totalUnReviewDsd: 0, totalUnReviewWHSE: 0, totalreviewWHSEItmCnt: 0, totalreviewDSDItmCnt: 0, totalreviewItmCnt: 0, totalUnReview: 0, totalReviewWHSE: 0, totalReviewDsd: 0, totalReview: 0 },
    memi23: [],
    memi20: [],
    memi24_A: [],
    memi24_B: [],
    memi24_C: [],
    memi21_sourceItems: [],
    memi21_targetItems: [],
    memi22: [],
    divisions: [],
    companies: [],
    companyId: "",
    divisionId: "",
    userLevel: null,
    alertBox: { open: false, message: "", type: "" },
    alertMessage: { open: false, type: "success", message: "" },
    tableModal: { open: false, columns: [], data: [] },
    department: { "": "" },
    rowData: [],
    lookUpScreen: { conversionStatus: [], customVO: null, departmentList: [], itemSets: [] },
    fileUpload: { open: false, accept: [], msg: "", msgColor: "" },
    uomList: [],
    confirmationModal: { open: false, type: "", onClickOk: null },
    confirmationModalSearch: "",
    UpdateOverrideManualSearch: null,
    updateoverridesku: null,
    UpdateAugmentationManualSearch: {},
    updateaugmentataionsku: null,
    smicDetails: "",
    groupDetail: [],
    productionGroupDetail: [],
    listDepartmentSource: [],
    listDepartmentTarget: [],
    memi03sku: null,
    memi03cic: null,
    memi03skuSelected: [],
    memi03cicSelected: [],
    memi03skuPayload: {},
    memi03cicPayload: {

    },
    mappingModal: { open: false, onClickOk: null, data: [], skuTitl: [], sellingData: [], cicBuyTitle: "", cicSellTitle: "" },
    loader: 0,
    //logStatus:"",
    fullLogStatus: "",
    logStatusResult: "Sucess",
    augmentationServiceKey: "",
    overideServiceKey: "",
    augmentationServiceDepartment: "",
    overideServiceUsageType:"",
    augmentationServiceUsageType:"",
    appState: {}
  };
  let [state, dispatch] = useReducer(ApplicationReducer, initialState);

  const setLogStatusResult = (logStatusResult) => {
    dispatch({
      type: SET_LOG_STATUS_RESULT,
      payload: logStatusResult
    })
  }

  const setLogStatus = (logStatus) => {
    dispatch({
      type: SET_LOG_STATUS,
      payload: logStatus
    })
  }

  const setFullLogStatus = (fullLogStatus) => {
    dispatch({
      type: SET_FULL_LOG_STATUS,
      payload: fullLogStatus
    })
  }

  const setLoader = (loader) => {
    dispatch({
      type: SET_LOADER,
      payload: loader
    })
  }

  const addLoader = (loader) => {
    dispatch({
      type: ADD_LOADER,
      payload: loader
    })
  }

  const setData = (data) => {
    dispatch({
      type: SET_DATA,
      payload: data,
    });
  };

  const addData = (data) => {
    dispatch({
      type: ADD_DATA,
      payload: data,
    });
  };
  const deleteData = (dataId) => {
    dispatch({
      type: DELETE_DATA,
      payload: dataId,
    });
  };
  const setUserInfo = (userInfo) => {
    dispatch({
      type: SET_USERINFO,
      payload: userInfo,
    });
  };

  const addUserInfo = (userInfo) => {
    dispatch({
      type: ADD_USERINFO,
      payload: userInfo,
    });
  };

  const setLastSearch = (lastSearch) => {
    dispatch({
      type: SET_LASTSEARCH,
      payload: lastSearch,
    });
  };

  const addLastSearch = (lastSearch) => {
    dispatch({
      type: ADD_LASTSEARCH,
      payload: lastSearch,
    });
  };

  const setMemi01 = (memi01) => {
    dispatch({
      type: SET_MEMI01,
      payload: memi01,
    });
  };

  const setMemi13 = (memi13) => {
    dispatch({
      type: SET_MEMI13,
      payload: memi13,
    });
  };

  const setMemi20 = (memi20) => {
    dispatch({
      type: SET_MEMI20,
      payload: memi20,
    });
  };
  const setMemi21_sourceItems = (memi21_source) => {
    dispatch({
      type: SET_MEMI21_SOURCE_ITEMS,
      payload: memi21_source,
    });
  };
  const setMemi21_targetItems = (memi21_target) => {
    dispatch({
      type: SET_MEMI21_TARGET_ITEMS,
      payload: memi21_target,
    });
  };
  const setMemi14 = ({ UpdateOverrideManualSearch, updateoverridesku }) => {

    if (UpdateOverrideManualSearch) {
      dispatch({
        type: SET_UPDATEOVERRIDEMANUALSEARCH,
        payload: UpdateOverrideManualSearch,
      });
    }
    if (updateoverridesku) {
      dispatch({
        type: SET_UPDATEOVERIDESKU,
        payload: Array.isArray(updateoverridesku) ? updateoverridesku.sort((a, b) => { return Number(a) - Number(b) }) : updateoverridesku
      });
    }


  };
  const setMemi17 = (memi17) => {
    dispatch({
      type: SET_MEMI17,
      payload: memi17,
    });
  };
  const setMemi18 = ({ UpdateAugmentationManualSearch, updateaugmentationsku }) => {
    if (UpdateAugmentationManualSearch) {
      dispatch({
        type: SET_UPDATEAUGMENTATIONMANUALSEARCH,
        payload: UpdateAugmentationManualSearch,
      });
    }
    if (updateaugmentationsku) {
      dispatch({
        type: SET_UPDATEAUGMENTATIONSKU,
        payload: Array.isArray(updateaugmentationsku) ? updateaugmentationsku.sort((a, b) => { return Number(a) - Number(b) }) : updateaugmentationsku
      });
    }
  };
  const setMemi23 = (memi23) => {
    dispatch({
      type: SET_MEMI23,
      payload: memi23,
    });
  };
  const setMemi24_A = (memi24_A) => {
    dispatch({
      type: SET_MEMI24_A,
      payload: memi24_A,
    });
  };
  const setMemi24_B = (memi24_B) => {
    dispatch({
      type: SET_MEMI24_B,
      payload: memi24_B,
    });
  };
  const setMemi24_C = (memi24_C) => {
    dispatch({
      type: SET_MEMI24_C,
      payload: memi24_C,
    });
  };



  const setMemi22 = (memi22) => {
    dispatch({
      type: SET_MEMI22,
      payload: memi22,
    });
  };
  const addMemi01 = (memi01) => {
    dispatch({
      type: ADD_MEMI01,
      payload: memi01,
    });
  };

  const setMemi08 = (memi08) => {
    dispatch({
      type: SET_MEMI08,
      payload: memi08,
    });
  };

  const addMemi08 = (memi08) => {
    dispatch({
      type: ADD_MEMI08,
      payload: memi08,
    });
  };
  const addMemi13 = (memi13) => {
    dispatch({
      type: ADD_MEMI13,
      payload: memi13,
    });
  };

  const setConfigurationSets = (configurationSets) => {
    dispatch({
      type: SET_CONFIGURATION_SETS,
      payload: configurationSets,
    });
  };
  const addConfigurationSets = (configurationSets) => {
    dispatch({
      type: ADD_CONFIGURATION_SETS,
      payload: configurationSets,
    });
  };

  const setConfigurationVars = (configurationVars) => {
    dispatch({
      type: SET_CONFIGURATION_VARS,
      payload: configurationVars,
    });
  };
  const addConfigurationVars = (configurationVars) => {
    dispatch({
      type: ADD_CONFIGURATION_VARS,
      payload: configurationVars,
    });
  };


  const addMemi17 = (memi17) => {
    dispatch({
      type: ADD_MEMI17,
      payload: memi17,
    });
  };
  const addMemi23 = (memi23) => {
    dispatch({
      type: ADD_MEMI23,
      payload: memi23,
    });
  };
  const addMemi24_A = (memi24_A) => {
    dispatch({
      type: ADD_MEMI24_A,
      payload: memi24_A,
    });
  };
  const addMemi24_B = (memi24_B) => {
    dispatch({
      type: ADD_MEMI24_B,
      payload: memi24_B,
    });
  };
  const addMemi24_C = (memi24_C) => {
    dispatch({
      type: ADD_MEMI24_C,
      payload: memi24_C,
    });
  };
  const setCompanyId = (companyId) => {
    dispatch({
      type: SET_COMPANYID,
      payload: companyId,
    });
  }

  const setAugmentationServiceKey = (serviceKey) => {
    dispatch({
      type: SET_AUGMENTATION_SERVICE_KEY,
      payload: serviceKey
    })
  }

  const setOverideServiceKey = (serviceKey) => {
    dispatch({
      type: SET_OVERIDE_SERVICE_KEY,
      payload: serviceKey
    })
  }

  const setAugmentationServiceUsageType = (usageType) => {
    dispatch({
      type: SET_AUGMENTATION_SERVICE_USAGE_TYPE,
      payload:usageType
    })
  }

  const setOverideServiceUsageType = (usageType) => {
    dispatch({
      type: SET_OVERIDE_SERVICE_USAGE_TYPE,
      payload:usageType
    })
  }

  const setDivisionId = (divisionId) => {
    dispatch({
      type: SET_DIVISIONID,
      payload: divisionId,
    });
  }

  const setCompanies = (companies) => {
    dispatch({
      type: SET_COMPANIES,
      payload: companies,
    });
  }

  const setDivisions = (divisions) => {
    dispatch({
      type: SET_DIVISIONS,
      payload: divisions,
    });
  }

  const setUserLevel = (userLevel) => {
    dispatch({
      type: SET_USERLEVEL,
      payload: userLevel,
    });
  }

  const setAlertBox = (open, message = "") => {
    if (open) {
      dispatch({
        type: SET_ALERTBOX,
        payload: { open, message }
      })
    }
    else {

      if (!Array.isArray(state.alertBox.message) || state.alertBox.message.length === 1) {
        dispatch({
          type: SET_ALERTBOX,
          payload: { open, message }
        })
      } else {

        dispatch({
          type: SET_ALERTBOX,
          payload: { open: true, message: state.alertBox.message.slice(1) }
        })
      }
    }
  }

  const setAlertMessage = (open, type = "success", message = "") => {
    dispatch({
      type: SET_ALERTMESSAGE,
      payload: { open, type, message }
    })
  }

  const setTableModal = (open, columns = [], data = []) => {
    dispatch({
      type: SET_TABLEMODAL,
      payload: { open, columns, data }
    })
  }

  const setDepartment = (department) => {
    dispatch({
      type: SET_DEPARTMENT,
      payload: department
    })
  }

  const setLookUpScreen = (lookUpScreen) => {
    dispatch({
      type: SET_LOOKUPSCREEN,
      payload: lookUpScreen
    })
  }
  const setMemi06 = (memi06) => {
    dispatch({
      type: SET_MEMI06,
      payload: memi06
    })
  }
  const setListDisplayerData = (listDisplayerData) => {
    dispatch({
      type: SET_LIST_DISPLAYER_DATA,
      payload: listDisplayerData
    })
  }
  const setMemi16Data = (memi16Data) => {
    dispatch({
      type: SET_MEMI16_DATA,
      payload: memi16Data
    })
  }

  const setMemi16Criteria = (memi16Criteria) => {
    dispatch({
      type: SET_MEMI16_CRITERIA,
      payload: memi16Criteria
    })
  }

  const mapSelectedRowData = (data) => {
    dispatch({
      type: SET_SELECTED_ROWS,
      payload: data
    })
  }

  const setFileUploadModal = (open, accept = [], msg = "", msgColor = "") => {
    dispatch({
      type: SET_FILEUPLOADMODAL,
      payload: { open, accept, msg, msgColor }
    })
  }

  const setFileUploadData = (fileUploadData) => {
    dispatch({
      type: SET_FILEUPLOAD_DATA,
      payload: fileUploadData
    })
  }

  const setSelectedCriteriaSearch = (selectedCriteriaSearch) => {
    dispatch({
      type: SET_SELECTED_CRITERIA_SEARCH,
      payload: selectedCriteriaSearch
    })
  }

  const setSelectedCriteria = (selectedCriteria) => {
    dispatch({
      type: SET_SELECTED_CRITERIA,
      payload: selectedCriteria
    })
  }


  const setUOMList = (list) => {
    dispatch({
      type: SET_UOM_LIST,
      payload: list,
    });
  };

  const setSmicDetails = (desc) => {
    dispatch({
      type: SET_SMIC_DETAILS,
      payload: desc,
    });
  };


  const setConfirmationModal = (open, onClickOk, type = "textBox", title = "") => {
    dispatch({
      type: SET_CONFIRMATION_MODAL,
      payload: { open, type, onClickOk, title }
    })
  }

  const setConfirmationModalSearch = (confirmationModalSearch) => {
    dispatch({
      type: SET_CONFIRMATION_MODAL_SEARCH,
      payload: confirmationModalSearch
    })
  }

  const setMultiUnitTargetFilter = (multiUnitTargetFilter) => {
    dispatch({
      type: SET_MULTIUNIT_TARGET_FILTER,
      payload: multiUnitTargetFilter
    })
  }

  const setMultiUnitSrcFilter = (multiUnitSrcFilter) => {
    dispatch({
      type: SET_MULTIUNIT_SRC_FILTER,
      payload: multiUnitSrcFilter
    })
  }

  const setSourceDepartment = (department) => {
    dispatch({
      type: SET_SOURCE_DEPARTMENT,
      payload: department
    })
  }


  const setTargetDepartment = (department) => {
    dispatch({
      type: SET_TARGET_DEPARTMENT,
      payload: department
    })
  }

  const setMultiUnitFilterRetailSection = (multiUnitFilterRetailSection) => {
    dispatch({
      type: SET_MULTIUNIT_FILTER_RETAILSECTION,
      payload: multiUnitFilterRetailSection
    })
  }

  const setMultiUnitFilterDeptname = (multiUnitFilterDeptname) => {
    dispatch({
      type: SET_MULTIUNIT_FILTER_DEPTNAME,
      payload: multiUnitFilterDeptname
    })
  }

  const setMultiUnitSrcData = (multiUnitSrcData) => {
    dispatch({
      type: SET_MULTIUNIT_SRC_DATA,
      payload: multiUnitSrcData
    })
  }

  const setMultiUniTargetData = (multiUnitTargetData) => {
    dispatch({
      type: SET_MULTIUNIT_TARGET_DATA,
      payload: multiUnitTargetData
    })
  }

  const setAugmentationServiceDepartment = (augmentationServiceDepartment) => {
    dispatch({
      type: SET_AUGMENTATION_SERVICE_DEPARTMENT
    })
  }

  const setMemi03Sku = (data) => {
    if (data) {
      data.skuSearchResults = trimPLUFunc(data.skuSearchResults);
      if (data.sourceCount && data.skuSearchResults) {
        data.sourceCount = data.sourceCount;
        data.sourceShowCount = data.skuSearchResults.length;

        if (data.sourceCount <= data.sourceShowCount) {
          data.sourceCount = data.sourceShowCount;
        }
      } else {
        data.sourceCount = 0;
        data.sourceShowCount = 0;
      }
      if (data.skuSearchResults) {
        data.skuSearchResults = data.skuSearchResults.map((x, index) => {
          if(x.id !== undefined) {return x}
          return { ...x, id: index }
        })
      }
    }
    dispatch({
      type: SET_MEMI03_SKU,
      payload: data
    })
  }

  const setMemi03Cic = (data) => {
    let dataTemp = data;
    if (dataTemp) {
      if (dataTemp.targetCount && dataTemp.cicSearchResults) {
        dataTemp.targetCount = dataTemp.targetCount;
        dataTemp.targetShowCount = dataTemp.cicSearchResults.length;

        if (dataTemp.targetCount <= dataTemp.sourceShowCount) {
          dataTemp.targetCount = dataTemp.targetShowCount;
        }
      } else {
        dataTemp.sourceCount = 0;
        dataTemp.sourceShowCount = 0;
      }
      if (dataTemp.cicSearchResults) {
        dataTemp.cicSearchResults = dataTemp.cicSearchResults.map((x, index) => {
          
          if (x.id !== undefined) { return x }
          return { ...x, id: index }
        })
      }
    }
    dispatch({
      type: SET_MEMI03_CIC,
      payload: dataTemp
    })
  }

  const setMemi03SkuSelected = (data) => {
    dispatch({
      type: SET_MEMI03_SKU_SELECTED,
      payload: data
    })
  }

  const setMemi03CicSelected = (data) => {
    dispatch({
      type: SET_MEMI03_CIC_SELECTED,
      payload: data
    })
  }

  const setMemi03SkuPayload = (data) => {
    dispatch({
      type: SET_MEMI03_SKU_PAYLOAD,
      payload: data
    })
  }

  const setMemi03CicPayload = (data) => {
    dispatch({
      type: SET_MEMI03_CIC_PAYLOAD,
      payload: data
    })
  }

  const setMappingModal = (open, onClickOk, data = [], skuTitle = [], sellingData = [], cicBuyTitle = "", cicSellTitle = "") => {
    dispatch({
      type: SET_MAPPING_MODAL,
      payload: { open, onClickOk, data, skuTitle, sellingData, cicBuyTitle, cicSellTitle }
    })
  }

  const setDepartmentList = (departments) => {
    dispatch({
      type: SET_DEPARTMENT,
      payload: departments
    })
  }

  const setGroupDetail = (groups) => {
    dispatch({
      type: SET_GROUP_DETAIL,
      payload: groups
    })
  }

  const setProductionGroupDetail = (groups) => {
    dispatch({
      type: SET_PRODUCTION_GROUP_DETAIL,
      payload: groups
    })
  }

  const addAppState = (key, value) => {
    dispatch({
      type: ADD_APP_STATE,
      payload: { [`${key}`]: value }
    })
  }

  const setAppState = (state) => {
    dispatch({
      type: SET_APP_STATE,
      payload: state
    })
  }


  return (
    <ApplicationContext.Provider
      value={{
        memi01: state.memi01,
        memi06: state.memi06,
        memi08: state.memi08,
        memi13: state.memi13,
        memi20: state.memi20,
        memi21_sourceItems: state.memi21_sourceItems,
        memi21_targetItems: state.memi21_targetItems,
        memi22: state.memi22,
        lastSearch: state.lastSearch,
        userInfo: state.userInfo,
        data: state.data,
        configurationSets: state.configurationSets,
        configurationVars: state.configurationVars,
        memi14: state.memi14,
        memi17: state.memi17,
        memi18: state.memi18,
        memi23: state.memi23,
        memi24_A: state.memi24_A,
        memi24_B: state.memi24_B,
        memi24_C: state.memi24_C,
        division: state.division,
        division2: state.division2,
        companyId: state.companyId,
        divisionId: state.divisionId,
        companies: state.companies,
        divisions: state.divisions,
        alertBox: state.alertBox,
        alertMessage: state.alertMessage,
        tableModal: state.tableModal,
        department: state.department,
        lookUpScreen: state.lookUpScreen,
        MEMI06: state.memi06,
        listDisplayerData: state.listDisplayerData,
        memi16Data: state.memi16Data,
        memi16Criteria: state.memi16Criteria,
        rowData: state.rowData,
        fileUpload: state.fileUpload,
        fileUploadData: state.fileUploadData,
        selectedCriteriaSearch: state.selectedCriteriaSearch,
        selectedCriteria: state.selectedCriteria,
        uomList: state.uomList,
        confirmationModal: state.confirmationModal,
        confirmationModalSearch: state.confirmationModalSearch,
        updateoverridesku: state.updateoverridesku,
        UpdateOverrideManualSearch: state.UpdateOverrideManualSearch,
        updateaugmentationsku: state.updateaugmentationsku,
        UpdateAugmentationManualSearch: state.UpdateAugmentationManualSearch,
        smicDetails: state.smicDetails,
        multiUnitSrcFilter: state.multiUnitSrcFilter,
        multiUnitTargetFilter: state.multiUnitTargetFilter,
        listDepartmentSource: state.listDepartmentSource,
        listDepartmentTarget: state.listDepartmentTarget,
        multiUnitFilterDeptname: state.multiUnitFilterDeptname,
        multiUnitFilterRetailSection: state.multiUnitFilterRetailSection,
        multiUnitSrcData: state.multiUnitSrcData,
        multiUnitTargetData: state.multiUnitTargetData,
        memi03sku: state.memi03sku,
        memi03cic: state.memi03cic,
        memi03skuSelected: state.memi03skuSelected,
        memi03cicSelected: state.memi03cicSelected,
        memi03skuPayload: state.memi03skuPayload,
        memi03cicPayload: state.memi03cicPayload,
        mappingModal: state.mappingModal,
        loader: state.loader,
        groupDetail: state.groupDetail,
        productionGroupDetail: state.productionGroupDetail,
        logStatus: state.logStatus,
        fullLogStatus: state.fullLogStatus,
        logStatusResult: state.logStatusResult,
        augmentationServiceKey: state.augmentationServiceKey,
        overideServiceKey: state.overideServiceKey,
        augmentationServiceDepartment: state.augmentationServiceDepartment,
        appState: state.appState,
        augmentationServiceUsageType: state.augmentationServiceUsageType,
        overideServiceUsageType: state.overideServiceUsageType,
        addAppState,
        setAppState,
        addData,
        deleteData,
        setData,
        setUserInfo,
        addUserInfo,
        setLastSearch,
        addLastSearch,
        setMemi01,
        addMemi01,
        setMemi08,
        addMemi08,
        addMemi13,
        setMemi13,
        setMemi20,
        setMemi21_sourceItems,
        setMemi21_targetItems,
        setMemi22,
        setConfigurationSets,
        addConfigurationSets,
        setConfigurationVars,
        addConfigurationVars,
        setMemi14,
        addMemi17,
        setMemi17,
        setMemi18,
        addMemi23,
        setMemi23,
        addMemi24_A,
        setMemi24_A,
        addMemi24_B,
        setMemi24_B,
        addMemi24_C,
        setMemi24_C,
        setCompanyId,
        setDivisionId,
        setCompanies,
        setDivisions,
        setUserLevel,
        setAlertBox,
        setAlertMessage,
        setTableModal,
        setDepartment,
        setLookUpScreen,
        setMemi06,
        setListDisplayerData,
        setMemi16Data,
        setMemi16Criteria,
        mapSelectedRowData,
        setFileUploadModal,
        setFileUploadData,
        setSelectedCriteriaSearch,
        setSelectedCriteria,
        setUOMList,
        setConfirmationModal,
        setConfirmationModalSearch,
        setSmicDetails,
        setMultiUnitTargetFilter,
        setMultiUnitSrcFilter,
        setSourceDepartment,
        setTargetDepartment,
        setMultiUnitFilterRetailSection,
        setMultiUnitFilterDeptname,
        setMultiUnitSrcData,
        setMultiUniTargetData,
        setMemi03Sku,
        setMemi03Cic,
        setMemi03SkuSelected,
        setMemi03CicSelected,
        setMemi03SkuPayload,
        setMemi03CicPayload,
        setMappingModal,
        setLoader,
        addLoader,
        setGroupDetail,
        setProductionGroupDetail,
        setLogStatus,
        setFullLogStatus,
        setLogStatusResult,
        setAugmentationServiceKey,
        setOverideServiceKey,
        
        setOverideServiceKey,
        setAugmentationServiceDepartment,
        setAugmentationServiceUsageType,
        setOverideServiceUsageType
      }}
    >
      {props.children}
    </ApplicationContext.Provider>
  );
};

export default ApplicationContextProvider;
