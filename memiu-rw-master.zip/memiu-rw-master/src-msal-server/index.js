/**
 * Sample Node JS application
 */
const express = require("express");
const app = express();
const msal1="@azure/msal-node";
const msal = require(msal1);
const AlbertsonsMsal = require("@albertsons-authn/abs-node-authn");
//const testObj = require("./externalize.js")
var cookieParser = require("cookie-parser");
var path = require("path");
require("custom-env").env(); // to remove dependency on dev

const MSAL_BASE_URL = process.env.MSAL_BASE_URL;
const APP_BASE_URL = process.env.APP_BASE_URL;
const CONTEXT_PATH = process.env.MSAL_CONTEXT_PATH;
const REDIRECT_URL = MSAL_BASE_URL + process.env.MSAL_CONTEXT_PATH + "/azureAdRedirect";
const POST_LOGOUT_URL = MSAL_BASE_URL + process.env.MSAL_CONTEXT_PATH + "/authenticate";
const LOGIN_ERROR_URL = MSAL_BASE_URL + process.env.MSAL_CONTEXT_PATH + "/loginError";

const SERVER_PORT = process.env.MSAL_PORT || 7000;

app.use(cookieParser());



// Azure AD application configuration
const config = {
  scopes: process.env.SCOPES.split(","), //externalize and remove from github
  auth: {
    clientId: process.env.REACT_APP_CLIENT_ID,
    authority: process.env.REACT_APP_AUTHORITY,
    clientSecret: process.env.REACT_APP_CLIENT_SECRET,
    validateAuthority: true,
    baseUri: APP_BASE_URL,
    redirectUri: REDIRECT_URL,
    postLogoutRedirectUri: POST_LOGOUT_URL,
  },
  system: {
    loggerOptions: {
      loggerCallback(loglevel, message, containsPii) {
        //  console.log(message);
      },
      piiLoggingEnabled: false,
      logLevel: msal.LogLevel.Verbose,
    },
  },
};

AlbertsonsMsal.msalInitialize(config);

app.get(["/loginError", CONTEXT_PATH + "/loginError",], (req, res) => {
  res.sendFile(path.join(__dirname + "/home.html"));
});

// requires corresponding changes for err call back in wcax 
app.get(["/azureAdRedirect", CONTEXT_PATH + "/azureAdRedirect"], (req, res) => {
  try {
    AlbertsonsMsal.msalExchangeCodeForToken(req, res, function (err) {
      //  console.log("token received in browser");
      // Once a token is obtained and msalExchangeCodeForToken() returns back to the calling handler function, the Application should redirect to desired location
      // positive casee
      if (err === undefined) {
        // console.log("azureAdRedirect:no error redirecting to app_base_url", APP_BASE_URL);
        if (CONTEXT_PATH != undefined || CONTEXT_PATH != "")
          res.redirect(APP_BASE_URL);
      }
      else {
        
        res.redirect(LOGIN_ERROR_URL);
      }
    });
  } catch (err) {
    console.log('ERROR CAUGHT: AlbertsonsMsal.msalExchangeCodeForToken:' + error);
  }
}
);

app.get(["/azurelogout", CONTEXT_PATH + "/azurelogout"], (req, res) => {
  AlbertsonsMsal.msalLogout(req, res);
});

app.get(["/authenticate", CONTEXT_PATH + "/authenticate"], (req, res) => {
  //console.log("authenticate called token  in browser");
  AlbertsonsMsal.msalCheckAuthStatus(res, req.cookies, function (authResult) {
    res.redirect(APP_BASE_URL);
  });
});

app.listen(SERVER_PORT, () =>{});
 //-------------------Jeff Steinberg Notes: 11172021 ---------------
