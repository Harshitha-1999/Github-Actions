ls
npm run buildsrv
npm run startsrv &  npm run build  && npx serve -s -n -l 3000 build


