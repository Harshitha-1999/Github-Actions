//eslint-disable-next-line
const { defaults } = require('jest-config');

module.exports = {
  
  setupFilesAfterEnv: ["<rootDir>/src/setupTests.js"]

};