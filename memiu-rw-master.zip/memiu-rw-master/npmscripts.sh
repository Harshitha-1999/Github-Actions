ls
npm run buildsrv
npm run startsrv & npm start
