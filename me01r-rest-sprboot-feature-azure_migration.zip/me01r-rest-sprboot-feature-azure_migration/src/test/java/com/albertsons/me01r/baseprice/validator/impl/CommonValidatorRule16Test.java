package com.albertsons.me01r.baseprice.validator.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule16.class)
public class CommonValidatorRule16Test {
	@Autowired
	private CommonValidatorRule16 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testNotValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextNotValidCic());
		assertNotNull(getContextNotValidCic());
		assertEquals(null, getContextNotValidCic().getCommonContext().getCicInfo());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextNotValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(null);
		context.setCommonContext(commonContext);
		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setRupcStatus("S");
		return upcItemDetail;
	}

}
