package com.albertsons.me01r.baseprice.service.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.dao.PriceAreaUpdateDAO;
import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.LogHandlingService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = PriceAreaUpdateServiceImpl.class)
public class PriceAreaUpdateServiceImplTest {

	@Autowired
	private PriceAreaUpdateServiceImpl classUnderTest;

	@MockBean
	private PriceAreaUpdateDAO priceAreaUpdateDAO;

	@MockBean
	private AuditHandlingServiceImpl auditHandlingServiceImpl;

	@MockBean
	private LogHandlingService logHandlingService;

	@MockBean
	private PriceAreaService priceAreaService;

	@MockBean
	private MessageHandlingService messageHandlingService;
	
	@MockBean
	private ErrorHandlingService errorHandlingService;



	@MockBean
	private ValidatePriceAreaDAO validatePriceAreaDAO;

	@Test
	public void testAddItemPriceInitialPriceWithRetStatusV() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
		ipUpdateContext.setCommonContext(cc);
		ipUpdateContext.getCommonContext().setCicInfo(itemDetails);
		ipUpdateContext.setBasePricingMsg(basePricingMsg);
		ipUpdateContext.getBasePricingMsg().setRetailSection("312");
		ipUpdateContext.getBasePricingMsg().setPaStoreInfo("09");
		List<ItemPriceData> itmPrcDataList = createPriceHistorydata(ipUpdateContext);
		itmPrcDataList.get(0).setRupcStatus("N");
		itmPrcDataList.get(0).setRetStatus("V");
		ipUpdateContext.setItemPriceDataList(itmPrcDataList);
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		doNothing().when(priceAreaUpdateDAO).insertItemNewPrice(anyObject());
		doNothing().when(priceAreaUpdateDAO).insertPriceHistory(anyList(), anyObject(), anyObject());
		// doNothing().when(priceAreaUpdateDAO).insertItemPendingPrice(anyObject(),
		// anyObject());
		doNothing().when(priceAreaUpdateDAO).updateUpcStatus(anyList());
		doNothing().when(priceAreaUpdateDAO).updatePosBibSwitch(anyList());
		doNothing().when(priceAreaUpdateDAO).updateRogStatus(anyString(), anyInt(), anyString(), anyString());
		doNothing().when(auditHandlingServiceImpl).insertAuditMsg(anyList());
		doNothing().when(logHandlingService).insertInitialPriceLog(anyObject(), anyList(), anyString());
		doReturn(auditMsgList).when(auditHandlingServiceImpl).prepareAuditMsgInitialPrice(anyObject(), anyString(),
				anyString());

		classUnderTest.addItemPrice(ipUpdateContext, paUpdateContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemPriceInitialPriceWithRetStatusC() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		itemDetails.get(0).setRetStatus("C");
		itemDetails.get(0).setStatusDST("C");
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
		ipUpdateContext.setCommonContext(cc);
		ipUpdateContext.getCommonContext().setCicInfo(itemDetails);
		ipUpdateContext.setBasePricingMsg(basePricingMsg);
		ipUpdateContext.getBasePricingMsg().setRetailSection("312");
		ipUpdateContext.getBasePricingMsg().setPaStoreInfo("09");
		List<ItemPriceData> itmPrcDataList = createPriceHistorydata(ipUpdateContext);
		itmPrcDataList.get(0).setRupcStatus("N");
		itmPrcDataList.get(0).setRetStatus("C");
		ipUpdateContext.setItemPriceDataList(itmPrcDataList);
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		doNothing().when(priceAreaUpdateDAO).insertItemNewPrice(anyObject());
		doNothing().when(priceAreaUpdateDAO).insertPriceHistory(anyList(), anyObject(), anyObject());
		// doNothing().when(priceAreaUpdateDAO).insertItemPendingPrice(anyObject(),
		// anyObject());
		doNothing().when(priceAreaUpdateDAO).updateUpcStatus(anyList());
		doNothing().when(priceAreaUpdateDAO).updatePosBibSwitch(anyList());
		doNothing().when(priceAreaUpdateDAO).updateRogStatus(anyString(), anyInt(), anyString(), anyString());
		doNothing().when(auditHandlingServiceImpl).insertAuditMsg(anyList());
		doNothing().when(logHandlingService).insertInitialPriceLog(anyObject(), anyList(), anyString());
		doReturn(auditMsgList).when(auditHandlingServiceImpl).prepareAuditMsgInitialPrice(anyObject(), anyString(),
				anyString());

		classUnderTest.addItemPrice(ipUpdateContext, paUpdateContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemPricePendingPrice() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
		ipUpdateContext.setBasePricingMsg(basePricingMsg);
		ipUpdateContext.getBasePricingMsg().setOptionalCutDetails(Arrays.asList(new OptionalCutDetail()));
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		paUpdateContext.setCommonContext(cc);
		paUpdateContext.getCommonContext().setCicInfo(itemDetails);
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		paUpdateContext.getBasePricingMsg().setRetailSection("312");
		paUpdateContext.getBasePricingMsg().setPaStoreInfo("09");
		List<PendingPriceData> pendingPrcDataList = createPendingPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(pendingPrcDataList);

//		doNothing().when(priceAreaUpdateDAO).insertItemNewPrice(anyObject());
//		doNothing().when(priceAreaUpdateDAO).insertPriceHistory(anyList(), anyObject(), anyObject());
		doReturn(1).when(priceAreaUpdateDAO).deletePendingItemPrice(anyList());
//		doNothing().when(priceAreaUpdateDAO).updateUpcStatus(anyList());
//		doNothing().when(priceAreaUpdateDAO).updatePosBibSwitch(anyList());
//		doNothing().when(priceAreaUpdateDAO).updateRogStatus(anyString(), anyInt(), anyString(), anyString());
		doNothing().when(auditHandlingServiceImpl).insertAuditMsg(anyList());
		doNothing().when(logHandlingService).insertPendingPriceLog(anyList());
//		doReturn(auditMsgList).when(auditHandlingServiceImpl).prepareAuditMsgInitialPrice(anyObject(), anyString(),
//				anyString());
		doReturn(pendingPrcDataList).when(priceAreaService).fetchPendingItemDetailToDelete(anyList());
		doNothing().when(messageHandlingService).processMeatItem(anyObject(), anyObject());

		classUnderTest.addItemPrice(ipUpdateContext, paUpdateContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemPricePendingPriceWithDateChange() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
		ipUpdateContext.setBasePricingMsg(basePricingMsg);
		ipUpdateContext.getBasePricingMsg().setOptionalCutDetails(Arrays.asList(new OptionalCutDetail()));
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		paUpdateContext.setCommonContext(cc);
		paUpdateContext.getCommonContext().setCicInfo(itemDetails);
		// paUpdateContext.getCommonContext().setDateChange(PromotionEnum.DATE_EFFECTIVE_CHANGE);
		paUpdateContext.getCommonContext().getDateChange().addAll(Arrays.asList("TEST", "TEST"));
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		paUpdateContext.getBasePricingMsg().setRetailSection("312");
		paUpdateContext.getBasePricingMsg().setPaStoreInfo("09");
		List<PendingPriceData> pendingPrcDataList = createPendingPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(pendingPrcDataList);

//		doNothing().when(priceAreaUpdateDAO).insertItemNewPrice(anyObject());
//		doNothing().when(priceAreaUpdateDAO).insertPriceHistory(anyList(), anyObject(), anyObject());
		doReturn(1).when(priceAreaUpdateDAO).deletePendingItemPrice(anyList());
//		doNothing().when(priceAreaUpdateDAO).updateUpcStatus(anyList());
//		doNothing().when(priceAreaUpdateDAO).updatePosBibSwitch(anyList());
//		doNothing().when(priceAreaUpdateDAO).updateRogStatus(anyString(), anyInt(), anyString(), anyString());
		doNothing().when(auditHandlingServiceImpl).insertAuditMsg(anyList());
		doNothing().when(logHandlingService).insertPendingPriceLog(anyList());
//		doReturn(auditMsgList).when(auditHandlingServiceImpl).prepareAuditMsgInitialPrice(anyObject(), anyString(),
//				anyString());
		doReturn(pendingPrcDataList).when(priceAreaService).fetchPendingItemDetailToDelete(anyList());
		doNothing().when(messageHandlingService).processMeatItem(anyObject(), anyObject());

		classUnderTest.addItemPrice(ipUpdateContext, paUpdateContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemPricePendingPriceWithLts() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setLtsPresent(true);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		CommonContext cc = new CommonContext();
		InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
		ipUpdateContext.setBasePricingMsg(basePricingMsg);
		ipUpdateContext.getBasePricingMsg().setOptionalCutDetails(Arrays.asList(new OptionalCutDetail()));
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		paUpdateContext.setCommonContext(cc);
		paUpdateContext.getCommonContext().setCicInfo(itemDetails);
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		paUpdateContext.getBasePricingMsg().setRetailSection("312");
		paUpdateContext.getBasePricingMsg().setPaStoreInfo("09");
		List<PendingPriceData> pendingPrcDataList = createPendingPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(pendingPrcDataList);

//		doNothing().when(priceAreaUpdateDAO).insertItemNewPrice(anyObject());
////		doNothing().when(priceAreaUpdateDAO).insertPriceHistory(anyList(), anyObject(), anyObject());
//		doReturn(1).when(priceAreaUpdateDAO).deletePendingItemPrice(anyList());
//		doNothing().when(priceAreaUpdateDAO).updateUpcStatus(anyList());
//		doNothing().when(priceAreaUpdateDAO).updatePosBibSwitch(anyList());
//		doNothing().when(priceAreaUpdateDAO).updateRogStatus(anyString(), anyInt(), anyString(), anyString());
//		doNothing().when(auditHandlingServiceImpl).insertAuditMsg(anyList());
//		doNothing().when(logHandlingService).insertPendingPriceLog(anyList());
//		doReturn(auditMsgList).when(auditHandlingServiceImpl).prepareAuditMsgInitialPrice(anyObject(), anyString(),
//				anyString());
//		doReturn(pendingPrcDataList).when(priceAreaService).fetchPendingItemDetailToDelete(anyList());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		doNothing().when(messageHandlingService).processMeatItem(anyObject(), anyObject());

		classUnderTest.addItemPrice(ipUpdateContext, paUpdateContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	private List<Promotion> getPromotionList(BasePricingMsg basePricingMsg) {
		List<Promotion> promotionList = new ArrayList<Promotion>();

		Promotion promotion = new Promotion();
		promotion.setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-16"));
		promotion.setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promotion.setPromotionType("L");
		promotion.setCic(basePricingMsg.getCorpItemCd());
		promotion.setRog(basePricingMsg.getRogCd());
		promotion.setUnitType(basePricingMsg.getUnitType());
		promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
		promotion.setPrice(1.1);
		promotion.setPriceFactor(1);
		promotion.setUpcCountry(00000);
		promotion.setUpcManuf(0);
		promotion.setUpcSales(00000);
		promotion.setUpcSystem(0);
		basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());
		promotionList.add(promotion);
		return promotionList;

	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("09");
		msg.setSuggLevel("Price Area");
		msg.setSuggPrice(5.1);
		msg.setScenarioId(12);
		msg.setScenarioName("Scenario_Price_Area");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setUpdatedEffectiveStartDt("2019-05-18");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		msg.setProjectedSales(94.90);
		msg.setProjectedMargin(84.90);
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		msg.setPriceOverrideReason(2);

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		item.setInitialPrice(false);
		item.setRetStatus("P");
		item.setStatusDST("V");

		itemDetailsList.add(item);

		return itemDetailsList;
	}

	private List<ItemPriceData> createPriceHistorydata(InitialPricingUpdateContext ipUpdateContext) {
		List<ItemPriceData> itemPriceDataList = new ArrayList<ItemPriceData>();
		ItemPriceData itemPriceData = new ItemPriceData();
		itemPriceData.setCorp("0001");
		itemPriceData.setDivision("25");
		itemPriceData.setRogCd("SACG");
		itemPriceData.setUpcManuf(00000);
		itemPriceData.setUpcSales(00000);
		itemPriceData.setUpcCountry(0);
		itemPriceData.setUpcSystem(0);
		itemPriceData.setEffectiveStartDt(ipUpdateContext.getBasePricingMsg().getEffectiveStartDt());
		itemPriceData.setPaStoreInfo(ipUpdateContext.getBasePricingMsg().getPaStoreInfo());
		itemPriceData.setReason(ConstantsUtil.SPACE);
		itemPriceData.setPriceMtd(ConstantsUtil.R);
		itemPriceData.setLimQty(ConstantsUtil.ZERO);
		itemPriceData.setPriceFactor(ipUpdateContext.getBasePricingMsg().getPriceFactor());
		itemPriceData.setSuggPrice(ipUpdateContext.getBasePricingMsg().getSuggPrice());
		itemPriceData.setPriceFctAlt(ConstantsUtil.ZERO.toString());
		itemPriceData.setPriceAlt(ConstantsUtil.ZERO.toString());
		itemPriceData.setLtsFlag(ConstantsUtil.SPACE);
		itemPriceData.setLastUpdUserId(ipUpdateContext.getBasePricingMsg().getLastUpdUserId());
		// itemPriceData.setRupcStatus("N");

		itemPriceDataList.add(itemPriceData);

		return itemPriceDataList;
	}

	private List<PendingPriceData> createPendingPriceDataList(PriceAreaUpdateContext paUpdateContext) {
		List<PendingPriceData> pendingPriceDataList = paUpdateContext.getCommonContext().getCicInfo().stream()
				.map(item -> {
					PendingPriceData pendingPriceData = new PendingPriceData();
					pendingPriceData.setCic(item.getCorpItemCd());
					pendingPriceData.setCorp(item.getCorp());
					pendingPriceData.setPaStoreInfo(item.getPriceArea());
					return pendingPriceData;
				}).collect(Collectors.toList());

		return pendingPriceDataList;

	}

}
