package com.albertsons.me01r.baseprice.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;

import com.albertsons.me01r.baseprice.dao.PropertyLoadDAO;

@SpringBootTest(classes = PropertyLoadServiceImpl.class)
public class PropertyLoadServiceImplTest {

	@Autowired
	private PropertyLoadServiceImpl classUnderTest;

	@MockBean
	private PropertyLoadDAO propertyLoadDAO;

	@MockBean
	private Environment env;

	@Test
	public void loadProperties() {
		List<Map<String, Object>> configs = getConfig();
		when(propertyLoadDAO.loadProperties()).thenReturn(configs);
		classUnderTest.loadProperties();
	}

	@Test
	public void loadPropertiesNullReturn() {
		List<Map<String, Object>> configs = new ArrayList<>();
		when(propertyLoadDAO.loadProperties()).thenReturn(configs);
		classUnderTest.loadProperties();
	}

	private List<Map<String, Object>> getConfig() {
		List<Map<String, Object>> configs = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("SRC_KEY_CD", "1");
		map.put("SRC_VAL", "1");
		configs.add(map);
		return configs;
	}
}
