package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule19.class)
public class CommonValidatorRule19Test {
	@Autowired
	private CommonValidatorRule19 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-OPT-PRICE-SW");
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateNonMeat() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-OPT-PRICE-SW");
		classUnderTest.validate(getBasePricingMsgNonMeat(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateNoOptionalCut() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-OPT-PRICE-SW");
		classUnderTest.validate(getBasePricingMsgNoOptionalCut(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateWithZeroCrc() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-OPT-PRICE-SW");
		classUnderTest.validate(getBasePricingMsgWithZeroCrc(), getContextValidCicWithZeroCrc());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateWithZeroCrcNon() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-OPT-PRICE-SW");
		classUnderTest.validate(getBasePricingMsgWithZeroCrc(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setCrcId(12345);
		basePricingMsg.setHasOptionalCut(true);
		basePricingMsg.setIsMeatItem(true);
		return basePricingMsg;
	}

	private BasePricingMsg getBasePricingMsgNonMeat() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setCrcId(12345);
		basePricingMsg.setHasOptionalCut(false);
		basePricingMsg.setIsMeatItem(false);
		return basePricingMsg;
	}

	private BasePricingMsg getBasePricingMsgNoOptionalCut() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setCrcId(12345);
		basePricingMsg.setHasOptionalCut(false);
		basePricingMsg.setIsMeatItem(true);
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setCrc(12345);
		return upcItemDetail;
	}

	private ValidationContext getContextValidCicWithZeroCrc() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetailWithZeroCrc());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsgWithZeroCrc() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setCrcId(0);
		basePricingMsg.setHasOptionalCut(true);
		basePricingMsg.setIsMeatItem(true);
		return basePricingMsg;
	}

	private BasePricingMsg getBasePricingMsgWithZeroCrcNonMeat() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setCrcId(0);
		basePricingMsg.setHasOptionalCut(true);
		basePricingMsg.setIsMeatItem(false);
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetailWithZeroCrc() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setCrc(0);
		return upcItemDetail;
	}

}
