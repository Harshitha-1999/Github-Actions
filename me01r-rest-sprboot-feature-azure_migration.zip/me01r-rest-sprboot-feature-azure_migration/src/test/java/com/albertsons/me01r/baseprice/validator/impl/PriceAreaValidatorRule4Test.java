package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = PriceAreaValidatorRule4.class)
public class PriceAreaValidatorRule4Test {

	@Autowired
	private PriceAreaValidatorRule4 classUnderTest;

	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "NO-PRICE-ROG-STAT");
	}

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(6, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testInValid() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextInValidCic());
		assertNotNull(getContextInValidCic());
	}

	@Test
	public void testInValidate() throws SystemException {
		classUnderTest.validate(getInvalidBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(6, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	private ValidationContext getContextInValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		cicInfo.add(getUPCDetailInvalid());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		cicInfo.add(getUPCDetail1());
		cicInfo.add(getUPCDetail2());
		cicInfo.add(getUPCDetail3());
		cicInfo.add(getUPCDetail4());
		cicInfo.add(getUPCDetail5());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setCorpItemCd(1234);
		basePricingMsg.setPriceArea(true);
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setPriceArea(false);
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("P");
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetailInvalid() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("");
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetail1() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("C");
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetail2() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("V");
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetail3() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("S");
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetail4() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("D");
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetail5() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRetStatus("A");
		return upcItemDetail;
	}

}
