package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;


@SpringBootTest(classes = CommonValidatorRule5.class)
public class CommonValidatorRule5Test {

	@Autowired
	private CommonValidatorRule5 classUnderTest;

	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "DISPLAYER-NOT-ALLOWED");
	}

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testInValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextInValidCic());
		assertNotNull(getContextInValidCic());
		assertEquals(1, getContextInValidCic().getCommonContext().getCicInfo().size());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<>());
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);

		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private ValidationContext getContextInValidCic() {
		ValidationContext context = new ValidationContext();
		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<>());
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetailWithoutDisplayFlag());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setDisplayFlag("Y");
		upcItemDetail.setCorpItemCd(0);
		return upcItemDetail;
	}

	private UPCItemDetail getUPCDetailWithoutDisplayFlag() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setDisplayFlag(" ");
		upcItemDetail.setCorpItemCd(0);
		return upcItemDetail;
	}

}
