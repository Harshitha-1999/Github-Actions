package com.albertsons.me01r.baseprice.kafka;

import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.GroupCodeValidateService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = KafkaPriceAreaConsumer.class)
public class KafkaPriceAreaConsumerTest {

	@Autowired
	private KafkaPriceAreaConsumer kafkaPriceAreaConsumer;

	private final static String basePriceMessage = "{\"crcId\": \"0\",\"corpItemCd\": \"86100079\",\"unitType\": \"1\",\"rogCd\": \"SNCA\",\"retailSection\": \"330\",\"paStoreInfo\": \"2840\",\"suggLevel\": \"PA\",\"suggPrice\": \"4.4\",\"scenarioId\": \"12\",\"scenarioName\": \"MSG1\",\"lastUpdUserId\": \"AMEHT04\",\"lastUpdUserTs\": \"2021-06-26 22:45:3\",\"effectiveStartDt\": \"2021-07-20\",\"effectiveEndDt\": \"2019-12-30\",\"scenarioFlg\": \"S\",\"projectedSales\": \"94.90\",\"projectedMargin\": \"84.90\",\"projectedUnits\": \"10\",\"priceFactor\": \"3\",\"priceOverrideReason\": \"2\"}";

	@MockBean
	private MessageHandlingService messageHandlingService;

	@MockBean
	private GroupCodeValidateService groupCodeValidateService;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private PropertiesUtils propertyLoadService;
	
	@MockBean
	private ValidationContext validationContext;
	
	@MockBean
	private PriceAreaService priceAreaService;
	
	@MockBean
	private StorePriceService storePriceService;
	
	private final static InboundMessage message = new InboundMessage(null); 

    private final static InboundMessage storeSpecificMessage = new InboundMessage(null);

	private final static InboundMessage msg = new InboundMessage(null);
	
	private final static String basePriceStoreSpecifcMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        }    ]}";

	
	@Test
	public void testOnMessage() throws SystemException {
		try {
			String uuid = UUID.randomUUID().toString();
			kafkaPriceAreaConsumer.onMessage(basePriceMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testInValidOnMessage() throws Exception {
		String payload = "{\r\n"
				+ "  \"priceChangeHeader\": {\r\n"
				+ "    \"requestId\": \"202201201953\",\r\n"
				+ "    \"recordCount\": \"1\",\r\n"
				+ "    \"suggLevel\": \"PA\"\r\n"
				+ "  },\r\n"
				+ "  \"priceList\": [\r\n"
				+ "    {\r\n"
				+ "      \"recordCount\": \"1\",\r\n"
				+ "      \"crcId\": \"0\",\r\n"
				+ "      \"corpItemCd\": \"86080603\",\r\n"
				+ "      \"unitType\": \"1\",\r\n"
				+ "      \"rogCd\": \"SNCA\",\r\n"
				+ "      \"retailSection\": \"331\",\r\n"
				+ "      \"paStoreInfo\": \"53\",\r\n"
				+ "      \"suggLevel\": \"PA\",\r\n"
				+ "      \"suggPrice\": \"55.55\",\r\n"
				+ "      \"scenarioId\": \"1\",\r\n"
				+ "      \"scenarioName\": \"MSG1\",\r\n"
				+ "      \"lastUpdUserId\": \"sraje09\",\r\n"
				+ "      \"lastUpdUserTs\": \"2022-01-12 20:20:3\",\r\n"
				+ "      \"effectiveStartDt\": \"2022-01-12\",\r\n"
				+ "      \"effectiveEndDt\": \"2022-06-27\",\r\n"
				+ "      \"scenarioFlg\": \"C\",\r\n"
				+ "      \"projectedSales\": \"555\",\r\n"
				+ "      \"projectedMargin\": \"555\",\r\n"
				+ "      \"projectedUnits\": 15.5,\r\n"
				+ "      \"priceFactor\": \"55\",\r\n"
				+ "      \"priceOverrideReason\": \"2\",\r\n"
				+ "      \"hasStoreSplit\": true\r\n"
				+ "    }\r\n"
				+ "  ]\r\n"
				+ "}";
		String uuid = UUID.randomUUID().toString();
		InboundMessage inboundMessage = new InboundMessage();
		inboundMessage.setPayload(payload);
		Method method = KafkaPriceAreaConsumer.class.getDeclaredMethod("corruptMessageError", InboundMessage.class);
		method.setAccessible(true);
		method.invoke(kafkaPriceAreaConsumer, inboundMessage);
	}
	
	@Test
	public void testOnMessageProcessPriceAreaMessage() throws SystemException {
		try {
			SystemException sysEx = null;
			SystemException se = new SystemException("System", sysEx);
			BasePricingMessages basePricingMessages = new BasePricingMessages();
			String uuid = UUID.randomUUID().toString();
			when(messageHandlingService.processIncomingMessage
					(Mockito.any(), Mockito.any())).thenReturn(basePricingMessages);
			kafkaPriceAreaConsumer.onMessage(basePriceMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testProcessDataIntegrityExDUPLICATE_DATAException() throws SystemException, Exception {
		SystemException se = new SystemException("Failed validation rule(s)", null);
		String uuid = UUID.randomUUID().toString();
		doThrow(se).when(storePriceService).process(anyObject());
		msg.setPayload(basePriceStoreSpecifcMessage);
		message.setPayload(basePriceStoreSpecifcMessage);
		kafkaPriceAreaConsumer.onMessage(basePriceStoreSpecifcMessage);
	}
}

