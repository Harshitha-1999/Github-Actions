package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule17.class)
public class CommonValidatorRule17Test {
	@Autowired
	private CommonValidatorRule17 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(2, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(getUPCDetail());
		context.setCommonContext(commonContext);
		context.setBasePricingMsg(getBasePricingMsg());
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private List<UPCItemDetail> getUPCDetail() {
		List<UPCItemDetail> upcList = new ArrayList<UPCItemDetail>();
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setPriceValid(true);

		UPCItemDetail upcItemDetail1 = new UPCItemDetail();
		upcItemDetail1.setUpcCountry(0);
		upcItemDetail1.setPriceValid(false);
		upcList.add(upcItemDetail);
		upcList.add(upcItemDetail1);
		return upcList;
	}

}
