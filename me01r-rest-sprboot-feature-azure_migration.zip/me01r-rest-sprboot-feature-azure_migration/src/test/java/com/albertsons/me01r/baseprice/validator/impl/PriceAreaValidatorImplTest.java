package com.albertsons.me01r.baseprice.validator.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.PriceAreaValidator;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = PriceAreaValidatorImpl.class)
public class PriceAreaValidatorImplTest {

	@Autowired
	private PriceAreaValidatorImpl classUnderTest;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private PriceAreaValidator paValidators;
	
	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "paValidators", getValidatorsList());
	}

	private List<PriceAreaValidator> getValidatorsList() {
		List<PriceAreaValidator> validatorList = new ArrayList<PriceAreaValidator>();
		PriceAreaValidatorRule4 priceAreaValidatorRule4 = new PriceAreaValidatorRule4();
		validatorList.add(priceAreaValidatorRule4);
		return validatorList;
	}

	@Test
	public void testValidate() throws SystemException {

		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(new ArrayList<ErrorMsg>());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());

	}

	@Test
	public void testValidateWithHandleScenariosWithoutCics() throws SystemException {
		List<ErrorMsg> errorList = new ArrayList<ErrorMsg>();
		ErrorMsg errorMsg = new ErrorMsg();
		errorMsg.setCic(123);
		errorMsg.setCoMsgCd("test");
		errorList.add(errorMsg);
		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(errorList);
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		ValidationContext vc = getContextValidCicWithAllHandleScenarios();
		vc.getCommonContext().setCicInfo(new ArrayList<>());
		Assertions.assertThrows(SystemException.class, ()->{
			classUnderTest.validate(getBasePricingMsg(), vc);
		});
		
		assertNotNull(getContextValidCicWithAllHandleScenarios());

	}

	@Test
	public void testValidateWithHandleScenariosWithCics() throws SystemException {
		List<ErrorMsg> errorList = new ArrayList<ErrorMsg>();
		ErrorMsg errorMsg = new ErrorMsg();
		errorMsg.setCic(123);
		errorMsg.setCoMsgCd("test");
		errorList.add(errorMsg);
		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(errorList);
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		Assertions.assertThrows(SystemException.class, ()->{
			classUnderTest.validate(getBasePricingMsg(), getContextValidCicWithAllHandleScenarios());
		});
		
		assertNotNull(getContextValidCicWithAllHandleScenarios());

	}

	@Test
	public void testValidateWithNullInitialValidator() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "paValidators", null);
		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(new ArrayList<ErrorMsg>());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());

	}

	@Test
	public void handleValidationResultTest() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(null);
		context.setCommonContext(commonContext);
		ReflectionTestUtils.invokeMethod(classUnderTest, "handleValidationResult", getBasePricingMsg(), context);
	}

	@Test
	public void handleValidationResultTest1() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(new ArrayList<>());
		context.setCommonContext(commonContext);
		ReflectionTestUtils.invokeMethod(classUnderTest, "handleValidationResult", getBasePricingMsg(), context);
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(getUPCDetail());
		commonContext.setRogExistChkResult(1);
		commonContext.isRogExist();
		context.setCommonContext(commonContext);
		context.setBasePricingMsg(getBasePricingMsg());
		return context;
	}

	private ValidationContext getContextValidCicWithAllHandleScenarios() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(getUPCDetail());
		commonContext.setRogExistChkResult(1);
		commonContext.isRogExist();
		context.setCommonContext(commonContext);
		context.setBasePricingMsg(getBasePricingMsg());
		context.getDiscontinuedUpc().addAll(getUPCDetail());
		context.getSeasonalPriceDiffUpc().addAll(getUPCDetail());
		context.getMissingUpc().addAll(getUPCDetail());
		context.getSamePriceUpc().addAll(getUPCDetail());
		context.getInvalidPriceDiffUpc().addAll(getUPCDetail());
		context.getWarningTypeMsgList().addAll(Arrays.asList("Warning1", "Warning1"));
		context.getErrorTypeMsgList().addAll(Arrays.asList("ERROR1", "ERROR2"));
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private List<UPCItemDetail> getUPCDetail() {

		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();

		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRupcStatus(ConstantsUtil.S);
		UPCItemDetail upcItemDetail1 = new UPCItemDetail();
		upcItemDetail1.setRupcStatus("D");
		upcItemDetail1.isPriceValid();
		UPCItemDetail upcItemDetail2 = new UPCItemDetail();
		upcItemDetail2.setRupcStatus("D");
		upcItemDetail2.isUpcExists();
		UPCItemDetail upcItemDetail3 = new UPCItemDetail();
		upcItemDetail3.setRupcStatus("D");

		cicInfo.add(upcItemDetail);
		cicInfo.add(upcItemDetail1);
		cicInfo.add(upcItemDetail2);
		cicInfo.add(upcItemDetail3);

		return cicInfo;
	}

}
