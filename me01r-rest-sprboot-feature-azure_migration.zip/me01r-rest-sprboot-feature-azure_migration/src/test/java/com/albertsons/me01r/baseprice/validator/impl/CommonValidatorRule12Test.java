package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule12.class)
public class CommonValidatorRule12Test {
	@Autowired
	private CommonValidatorRule12 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());
		assertEquals(1, getContext().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testInitialPrice() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getInvalidContext());
		assertNotNull(getInvalidContext());
		assertEquals(1, getInvalidContext().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidPriceDiff() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());
		assertEquals(1, getContext().getCommonContext().getCicInfo().size());
	}

	@Test()
	public void testInValidPriceDiff() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getInvalidPriceDiffContext());
		assertNotNull(getInvalidPriceDiffContext());
		assertEquals(1, getInvalidPriceDiffContext().getCommonContext().getCicInfo().size());
	}

	private ValidationContext getContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getInvalidContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getInvalidUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getInvalidPriceDiffContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getInvalidPriceDiffUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		LocalDate effDate = LocalDate.now().plusDays(14);
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setEffectiveEndDt(String.valueOf(effDate));
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(false);
		upcItemDetail.setValidPriceDiff(true);
		return upcItemDetail;
	}

	private UPCItemDetail getInvalidPriceDiffUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(false);
		upcItemDetail.setValidPriceDiff(false);
		return upcItemDetail;
	}

	private UPCItemDetail getInvalidUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(true);
		return upcItemDetail;
	}
}
