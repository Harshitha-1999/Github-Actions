package com.albertsons.me01r.baseprice.validator.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaUpdateService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.StorePriceValidator;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = StorePriceValidatorImpl.class)
public class StorePriceValidatorImplTest {

	@Autowired
	private StorePriceValidatorImpl classUnderTest;

	@MockBean
	@Qualifier("CommonValidatorImpl")
	private ValidatorImpl commonValidatorImpl;

	@MockBean
	private StorePriceValidator storeValidators;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private ValidateStorePriceDAO validateStorePriceDAO;

	@MockBean
	PriceAreaUpdateService priceAreaUpdateService;

	@MockBean
	CommonValidationService commonValidationService;

	private List<StorePriceValidator> getValidatorsList() {
		List<StorePriceValidator> validatorList = new ArrayList<StorePriceValidator>();
		StorePriceValidatorRule8 storePriceValidatorRule8 = new StorePriceValidatorRule8();
		validatorList.add(storePriceValidatorRule8);
		return validatorList;
	}

	@Test
	public void testValidateWithValidators() throws Exception {
		ReflectionTestUtils.setField(classUnderTest, "storeValidators", getValidatorsList());
		ValidationContext validationContext = getContextValidCic();
		validationContext.getCommonContext().setCicInfo(null);
		when(commonValidatorImpl.validate(getBasePricingMsg(), validationContext)).thenReturn(validationContext);
		List<UPCItemDetail> item = getUPCDetail();
		item.get(0).setUpcExists(true);
		validationContext.getCommonContext().setCicInfo(item);
		classUnderTest.validate(getBasePricingMsg(), validationContext);
	}

	@Test
	public void testValidateWithValidators1() throws Exception {
		ReflectionTestUtils.setField(classUnderTest, "storeValidators", getValidatorsList());
		ValidationContext validationContext = getContextValidCic();
		List<UPCItemDetail> item = getUPCDetail();
		item.get(0).setUpcExists(false);
		item.get(0).setInitialPrice(1.0);
		item.get(0).setUpcCountry(0);
		item.get(0).setUpcSystem(4);
		item.get(0).setPluCd(0);
		item.get(0).setSendBibDef("");
		item.get(0).setSendNewItmDef("");
		item.forEach(cic -> {
			cic.setUpcCountry(0);
			cic.setUpcSystem(4);
			cic.setPluCd(0);
			cic.setRupcStatus("");
			cic.setPriceValid(false);
			cic.setUpcExists(false);
		});
		validationContext.getCommonContext().setCicInfo(item);
		BasePricingMsg msg = getBasePricingMsg();
		msg.setIsOptionalCut(true);
		msg.setCorpItemCd(1);
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalItemGap(1.0);
		optionalCutDetail.setOptionalCic(1);
		msg.setOptionalCutDetails(Arrays.asList(optionalCutDetail));
		when(commonValidatorImpl.validate(msg, null)).thenReturn(validationContext);
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(item.get(0));
		when(commonValidationService.fetchItemBibSwitches(item.get(0), msg)).thenReturn(item.get(0));
		classUnderTest.validate(msg, validationContext);
	}

	@Test
	public void testValidate() throws Exception {

		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(new ArrayList<ErrorMsg>());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());

	}

	@Test
	public void testValidateWithHandleScenariosWithoutCics() throws Exception {
		List<ErrorMsg> errorList = new ArrayList<ErrorMsg>();
		ErrorMsg errorMsg = new ErrorMsg();
		errorMsg.setCic(123);
		errorMsg.setCoMsgCd("test");
		errorList.add(errorMsg);
		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(errorList);
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		ValidationContext vc = getContextValidCicWithAllHandleScenarios();
		vc.getCommonContext().setCicInfo(new ArrayList<>());
		SystemException except=Assertions.assertThrows(SystemException.class, ()->{
			classUnderTest.validate(getBasePricingMsg(), vc);
		});
				
		assertNotNull(getContextValidCicWithAllHandleScenarios());

	}

	@Test
	public void testValidateWithHandleScenariosWithCics() throws Exception {
		List<ErrorMsg> errorList = new ArrayList<ErrorMsg>();
		ErrorMsg errorMsg = new ErrorMsg();
		errorMsg.setCic(123);
		errorMsg.setCoMsgCd("test");
		errorList.add(errorMsg);
		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(errorList);
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		Assertions.assertThrows(SystemException.class, ()->{
			classUnderTest.validate(getBasePricingMsg(), getContextValidCicWithAllHandleScenarios());
		});
		
		assertNotNull(getContextValidCicWithAllHandleScenarios());

	}

	// TODO : currently the code will not throw system exception if storeValidators
	// is null
	// @Test(expected = Exception.class)
	public void testValidateWithNullStoreValidator() throws Exception {
		ReflectionTestUtils.setField(classUnderTest, "storeValidators", null);
		when(errorHandlingService.prepareErrorMsg(anyObject(), anyList(), anyString(), anyList()))
				.thenReturn(new ArrayList<ErrorMsg>());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());

	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(getUPCDetail());
		commonContext.setRogExistChkResult(1);
		commonContext.isRogExist();
		context.setCommonContext(commonContext);
		context.setBasePricingMsg(getBasePricingMsg());
		return context;
	}

	private ValidationContext getContextValidCicWithAllHandleScenarios() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(getUPCDetail());
		commonContext.setRogExistChkResult(1);
		commonContext.isRogExist();
		context.setCommonContext(commonContext);
		context.setBasePricingMsg(getBasePricingMsg());
		context.getDiscontinuedUpc().addAll(getUPCDetail());
		context.getSeasonalPriceDiffUpc().addAll(getUPCDetail());
		context.getMissingUpc().addAll(getUPCDetail());
		context.getSamePriceUpc().addAll(getUPCDetail());
		context.getInvalidPriceDiffUpc().addAll(getUPCDetail());
		// context.getWarningType().setMsgList(Arrays.asList("Warning1","Warning2"));
		// context.getErrorType().setMsgList(Arrays.asList("ERROR1","ERROR2"));
		context.getWarningTypeMsgList().addAll(Arrays.asList("Warning1", "Warning2"));
		context.getErrorTypeMsgList().addAll(Arrays.asList("ERROR1", "ERROR2"));
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(2.00);
		return basePricingMsg;
	}

	private List<UPCItemDetail> getUPCDetail() {

		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();

		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setRupcStatus(ConstantsUtil.S);
		upcItemDetail.setUpcExists(true);
		upcItemDetail.setUpcCountry(1);
		upcItemDetail.setUpcSystem(1);
		upcItemDetail.setPluCd(1);
		UPCItemDetail upcItemDetail1 = new UPCItemDetail();
		upcItemDetail1.setRupcStatus("D");
		upcItemDetail1.setUpcExists(false);
		upcItemDetail1.isPriceValid();
		upcItemDetail1.setUpcCountry(1);
		upcItemDetail1.setUpcSystem(1);
		upcItemDetail1.setPluCd(1);
		UPCItemDetail upcItemDetail2 = new UPCItemDetail();
		upcItemDetail2.setRupcStatus("D");
		upcItemDetail2.isUpcExists();
		upcItemDetail2.setUpcCountry(1);
		upcItemDetail2.setUpcSystem(1);
		upcItemDetail2.setPluCd(1);
		UPCItemDetail upcItemDetail3 = new UPCItemDetail();
		upcItemDetail3.setRupcStatus("D");
		upcItemDetail3.setUpcCountry(1);
		upcItemDetail3.setUpcSystem(1);
		upcItemDetail3.setPluCd(1);
		cicInfo.add(upcItemDetail);
		cicInfo.add(upcItemDetail1);
		cicInfo.add(upcItemDetail2);
		cicInfo.add(upcItemDetail3);

		return cicInfo;
	}

	@Test
	public void testGetInitialPriceDataList() {

		InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
		ipUpdateContext.setCommonContext(new CommonContext());
		ipUpdateContext.getCommonContext().setCicInfo(new ArrayList<>());
		UPCItemDetail uPCItemDetail = new UPCItemDetail();
		uPCItemDetail.setCorp("001");
		uPCItemDetail.setRogCd("001");
		uPCItemDetail.setDivision("001");
		uPCItemDetail.setUpcManuf(001);
		uPCItemDetail.setUpcSales(001);
		uPCItemDetail.setUpcCountry(001);
		uPCItemDetail.setUpcSystem(001);
		uPCItemDetail.setReason("001");
		uPCItemDetail.setReasonType("001");

		uPCItemDetail.setUnitType(001);
		uPCItemDetail.setSensitiveItem("001");
		uPCItemDetail.setSendPriceSw("001");
		uPCItemDetail.setSendLabelSw("001");
		uPCItemDetail.setSendBibDef("001");
		uPCItemDetail.setSendNewItmDef("001");
		uPCItemDetail.setRupcStatus("001");
		uPCItemDetail.setRetStatus("001");
		uPCItemDetail.setPluCd(001);
		ipUpdateContext.getCommonContext().getCicInfo().addAll(Arrays.asList(uPCItemDetail));
		ipUpdateContext.setBasePricingMsg(getBasePricingMsg());

		ReflectionTestUtils.invokeMethod(classUnderTest, "getInitialPriceDataList", ipUpdateContext, "02");
	}

	@Test
	public void testPriceOptionalCut() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setRogCd("SHAW");
		basePricingMsg.setPaStoreInfo("Check");
		basePricingMsg.setRetailSection("001");
		basePricingMsg.setBaseCutCic(1010016);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(0.00);
		basePricingMsg.setOptionalCutDetails(getOptipnalCutList());
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(new UPCItemDetail());
		when(validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(), basePricingMsg.getPaStoreInfo(),
				basePricingMsg.getRetailSection())).thenReturn("2");
		ReflectionTestUtils.invokeMethod(classUnderTest, "priceOptionalCut", basePricingMsg, getUPCDetail(),
				getContextValidCic());
	}

	@Test
	public void testDiffPriceOptionalCut() throws SystemException {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setRogCd("SHAW");
		basePricingMsg.setPaStoreInfo("Check");
		basePricingMsg.setRetailSection("001");
		basePricingMsg.setBaseCutCic(1010016);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(2.00);
		basePricingMsg.setOptionalCutDetails(getOptipnalCutList());
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(new UPCItemDetail());
		when(validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(), basePricingMsg.getPaStoreInfo(),
				basePricingMsg.getRetailSection())).thenReturn("2");
		UPCItemDetail upc = new UPCItemDetail();
		upc.setSendBibDef("");
		upc.setRetStatus("");
		upc.setUpcSystem(3);
		upc.setUpcCountry(1);
		upc.setPluCd(1);
		ReflectionTestUtils.invokeMethod(classUnderTest, "priceOptionalCut", basePricingMsg, Arrays.asList(upc),
				getContextValidCic());
	}

	@Test
	public void testDiffPriceOptionalCut1() throws SystemException {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setRogCd("SHAW");
		basePricingMsg.setPaStoreInfo("Check");
		basePricingMsg.setRetailSection("001");
		basePricingMsg.setBaseCutCic(1010016);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(2.00);
		basePricingMsg.setOptionalCutDetails(getOptipnalCutList());
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(new UPCItemDetail());
		when(validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(), basePricingMsg.getPaStoreInfo(),
				basePricingMsg.getRetailSection())).thenReturn("2");
		UPCItemDetail upc = new UPCItemDetail();
		upc.setSendBibDef("");
		upc.setRetStatus("");
		upc.setUpcSystem(4);
		upc.setUpcCountry(0);
		upc.setPluCd(0);
		ReflectionTestUtils.invokeMethod(classUnderTest, "priceOptionalCut", basePricingMsg, Arrays.asList(upc),
				getContextValidCic());
	}

	@Test
	public void testDiffPriceOptionalCut2() throws SystemException {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setRogCd("SHAW");
		basePricingMsg.setPaStoreInfo("Check");
		basePricingMsg.setRetailSection("001");
		basePricingMsg.setBaseCutCic(1010016);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(2.00);
		basePricingMsg.setOptionalCutDetails(getOptipnalCutList());
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(new UPCItemDetail());
		when(validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(), basePricingMsg.getPaStoreInfo(),
				basePricingMsg.getRetailSection())).thenReturn("2");
		UPCItemDetail upc = new UPCItemDetail();
		upc.setSendBibDef("");
		upc.setRetStatus("");
		upc.setUpcSystem(4);
		upc.setUpcCountry(0);
		upc.setPluCd(1);
		ReflectionTestUtils.invokeMethod(classUnderTest, "priceOptionalCut", basePricingMsg, Arrays.asList(upc),
				getContextValidCic());
	}

	@Test
	public void testDiffPriceOptionalCut3() throws SystemException {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setRogCd("SHAW");
		basePricingMsg.setPaStoreInfo("Check");
		basePricingMsg.setRetailSection("001");
		basePricingMsg.setBaseCutCic(1010016);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(2.00);
		basePricingMsg.setOptionalCutDetails(getOptipnalCutList());
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(new UPCItemDetail());
		when(validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(), basePricingMsg.getPaStoreInfo(),
				basePricingMsg.getRetailSection())).thenReturn("2");
		UPCItemDetail upc = new UPCItemDetail();
		upc.setSendBibDef("");
		upc.setRetStatus("");
		upc.setUpcSystem(4);
		upc.setUpcCountry(1);
		upc.setPluCd(1);
		ReflectionTestUtils.invokeMethod(classUnderTest, "priceOptionalCut", basePricingMsg, Arrays.asList(upc),
				getContextValidCic());
	}

	@Test
	public void testDiffPriceOptionalCut4() throws SystemException {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setRogCd("SHAW");
		basePricingMsg.setPaStoreInfo("Check");
		basePricingMsg.setRetailSection("001");
		basePricingMsg.setBaseCutCic(1010016);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setSuggPrice(2.00);
		basePricingMsg.setOptionalCutDetails(getOptipnalCutList());
		when(validateStorePriceDAO.fetchInitialPriceBaseCut(anyObject(), anyObject(), anyObject(), anyObject()))
				.thenReturn(new UPCItemDetail());
		when(validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(), basePricingMsg.getPaStoreInfo(),
				basePricingMsg.getRetailSection())).thenReturn("2");
		UPCItemDetail upc = new UPCItemDetail();
		upc.setSendBibDef("");
		upc.setRetStatus("");
		upc.setUpcSystem(4);
		upc.setUpcCountry(1);
		upc.setPluCd(0);
		ReflectionTestUtils.invokeMethod(classUnderTest, "priceOptionalCut", basePricingMsg, Arrays.asList(upc),
				getContextValidCic());
	}

	private List<OptionalCutDetail> getOptipnalCutList() {
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(1010016);
		optionalCutDetail.setOptionalItemGap(1.00);
		return Arrays.asList(optionalCutDetail);
	}
}
