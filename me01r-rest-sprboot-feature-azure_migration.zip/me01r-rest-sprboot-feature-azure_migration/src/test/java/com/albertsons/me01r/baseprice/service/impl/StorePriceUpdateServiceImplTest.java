package com.albertsons.me01r.baseprice.service.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.context.update.StoreLevelUpdateContext;
import com.albertsons.me01r.baseprice.dao.StorePriceUpdateDAO;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.LogMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.AuditHandlingService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.LogHandlingService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = StorePriceUpdateServiceImpl.class)
public class StorePriceUpdateServiceImplTest {

	@Autowired
	private StorePriceUpdateServiceImpl classUnderTest;

	@MockBean
	StorePriceUpdateDAO storePriceUpdateDAO;

	@MockBean
	AuditHandlingService auditHandlingService;

	@MockBean
	private LogHandlingService logHandlingService;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private StorePriceService storePriceService;

	@MockBean
	private MessageHandlingService messageHandlingService;

	@Test
	public void testAddItemStorePriceWithNoItem() throws Exception {
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(null);
		sLupdatedContext.setBasePricingMsg(new BasePricingMsg());
		sLupdatedContext.getBasePricingMsg().setHasStoreSplit(true);
		sLupdatedContext.getBasePricingMsg().setIsOptionalCut(true);
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		sLupdatedContext.getBasePricingMsg().setOptionalCutDetails(Arrays.asList(optionalCutDetail));
		sLupdatedContext.getBasePricingMsg().setStartDateDueToPromotion(LocalDate.now().toString());
		sLupdatedContext.getBasePricingMsg().setUpdatedEffectivEndtDt(LocalDate.now().toString());
		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(cc);
	}

	@Test
	public void testAddItemStorePriceWithNoItem1() throws Exception {
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(null);
		sLupdatedContext.setBasePricingMsg(new BasePricingMsg());
		sLupdatedContext.getBasePricingMsg().setHasStoreSplit(false);
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		sLupdatedContext.getBasePricingMsg().setOptionalCutDetails(Arrays.asList(optionalCutDetail));
		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(cc);
	}

	@Test
	public void testAddItemStorePriceWithPromotion() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		List<LogMsg> logMsgList = new ArrayList<LogMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		LogMsg logMsg = new LogMsg();
		logMsg.setMsgNm("");
		logMsg.setRemTxt("");
		logMsgList.add(logMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithPromotion(sLupdatedContext);
		sLupdatedContext.getBasePricingMsg().setUpdatedEffectivEndtDt(LocalDate.now().toString());
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);
		doReturn(storeSpecificDetails).when(storePriceService).fetchStoreSpecificDetails(new ArrayList<>(),
				basePricingMsg);
		storeSpecificDetails.get(0).setStartDate(LocalDate.now());
		storeSpecificDetails.get(0).setEndDate(LocalDate.now().plusDays(10));
		sLupdatedContext.getBasePricingMsg().setEffectiveStartDt(LocalDate.now().minusDays(10).toString());
		Object[] args = new Object[2];
		sLupdatedContext.getBasePricingMsg().setEffectiveEndDt(LocalDate.now().plusDays(15).toString());
		args[0] = storeSpecificDetails.get(0);
		args[1] = sLupdatedContext;

		ReflectionTestUtils.invokeMethod(classUnderTest, "updateStoreSpecificPromotion", args);

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemStorePriceWithPromotionAndEffDates() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		List<LogMsg> logMsgList = new ArrayList<LogMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		LogMsg logMsg = new LogMsg();
		logMsg.setMsgNm("");
		logMsg.setRemTxt("");
		logMsgList.add(logMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		// sLupdatedContext.getCommonContext().setDateChange(PromotionEnum.DATE_EFFECTIVE_CHANGE);
		// sLupdatedContext.getCommonContext().getDateChange().setMsgList(Arrays.asList("TEST","TEST"));
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		sLupdatedContext.getBasePricingMsg().setStartDateDueToPromotion("");
		sLupdatedContext.getBasePricingMsg().setUpdatedEffectivEndtDt(LocalDate.now().toString());
		List<StorePriceData> storeSpecificDetails = new ArrayList<StorePriceData>();
		StorePriceData storePriceData = new StorePriceData();
		storePriceData.setFacility(sLupdatedContext.getBasePricingMsg().getPaStoreInfo());
		storePriceData.setRogCd("SACG");
		storePriceData.setPromotionType("Y");
		storePriceData.setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-17"));
		storePriceData.setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-26"));
		sLupdatedContext.getBasePricingMsg().setUpdatedEffectivEndtDt("2019-05-26");
		storeSpecificDetails.add(storePriceData);
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);
		doReturn(storeSpecificDetails).when(storePriceService).fetchStoreSpecificDetails(storeSpecificDetails,
				basePricingMsg);
		doNothing().when(storePriceUpdateDAO).deleteItemStoreRetail(anyList());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		doNothing().when(storePriceUpdateDAO).updateItemStoreRetail(anyList());
		doNothing().when(storePriceUpdateDAO).deleteItemStoreRetail(anyList());
		doNothing().when(storePriceUpdateDAO).insertItemStorePriceBatch(anyList());
		doNothing().when(auditHandlingService).insertAuditMsg(anyList());
		doNothing().when(logHandlingService).insertStorePriceLog(anyList());
		doReturn(logMsgList).when(logHandlingService).prepareStorePriceLog(anyObject(), anyList(), anyString(),
				anyString());
		doReturn(auditMsgList).when(auditHandlingService).prepareAuditMsgInitialPrice(anyObject(), anyString(),
				anyString());
		doNothing().when(auditHandlingService).insertAuditMsg(anyList());

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemStorePriceWithoutPromotion() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();

		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithoutPromotion(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);

		sLupdatedContext.getBasePricingMsg().setEffectiveStartDt(LocalDate.now().toString());
		storeSpecificDetails.get(0).setStartDate(LocalDate.now());
		sLupdatedContext.getBasePricingMsg().setEffectiveEndDt(LocalDate.now().toString());
		Object[] args = new Object[4];
		args[0] = storeSpecificDetails.get(0);
		args[1] = sLupdatedContext;
		args[2] = new ArrayList<>();
		args[3] = new ArrayList<>();
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchStoreSpecificRetailToUpdate", args);

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemStorePriceWithoutPromotionUpdate3() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();

		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithoutPromotion(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);
		sLupdatedContext.getBasePricingMsg().setCorpItemCd(1);
		sLupdatedContext.getBasePricingMsg().setEffectiveStartDt(LocalDate.now().minusDays(10).toString());
		storeSpecificDetails.get(0).setStartDate(LocalDate.now().plusDays(1));
		sLupdatedContext.getBasePricingMsg().setEffectiveEndDt(LocalDate.now().plusDays(10).toString());
		storeSpecificDetails.get(0).setCic(10);
		Object[] args = new Object[4];
		args[0] = storeSpecificDetails.get(0);
		args[1] = sLupdatedContext;
		args[2] = new ArrayList<>();
		args[3] = new ArrayList<>();
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchStoreSpecificRetailToUpdate", args);

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemStorePriceWithoutPromotionUpdate2() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();

		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithoutPromotion(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);
		sLupdatedContext.getBasePricingMsg().setCorpItemCd(1);
		sLupdatedContext.getBasePricingMsg().setEffectiveStartDt(LocalDate.now().minusDays(10).toString());
		storeSpecificDetails.get(0).setStartDate(LocalDate.now().plusDays(1));
		sLupdatedContext.getBasePricingMsg().setEffectiveEndDt(LocalDate.now().plusDays(10).toString());
		storeSpecificDetails.get(0).setCic(1);
		Object[] args = new Object[4];
		args[0] = storeSpecificDetails.get(0);
		args[1] = sLupdatedContext;
		args[2] = new ArrayList<>();
		args[3] = new ArrayList<>();
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchStoreSpecificRetailToUpdate", args);

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemStorePriceWithoutPromotionUpdate() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();

		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithoutPromotion(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);

		// sLupdatedContext.getBasePricingMsg().setEffectiveStartDt(LocalDate.now().toString());
		// storeSpecificDetails.get(0).setStartDate(LocalDate.now());
		Object[] args = new Object[4];
		args[0] = storeSpecificDetails.get(0);
		args[1] = sLupdatedContext;
		args[2] = new ArrayList<>();
		args[3] = new ArrayList<>();
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchStoreSpecificRetailToUpdate", args);

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testAddItemStorePriceWithoutPromotionEffDates() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		List<AuditMsg> auditMsgList = new ArrayList<AuditMsg>();
		List<LogMsg> logMsgList = new ArrayList<LogMsg>();
		AuditMsg auditMsg = new AuditMsg();
		auditMsgList.add(auditMsg);
		LogMsg logMsg = new LogMsg();
		logMsg.setMsgNm("");
		logMsg.setRemTxt("");
		logMsgList.add(logMsg);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		CommonContext cc = new CommonContext();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		sLupdatedContext.setCommonContext(cc);
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithoutPromotion(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);
//		doReturn(storeSpecificDetails).when(storePriceService).fetchStoreSpecificDetails(storeSpecificDetails,
//				basePricingMsg);
//		doNothing().when(storePriceUpdateDAO).deleteItemStoreRetail(anyList());
//		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		doNothing().when(storePriceUpdateDAO).updateItemStoreRetail(anyList());
		doNothing().when(storePriceUpdateDAO).deleteItemStoreRetail(anyList());
		doNothing().when(storePriceUpdateDAO).insertItemStorePriceBatch(anyList());
//		doNothing().when(auditHandlingService).insertAuditMsg(anyList());
		doNothing().when(logHandlingService).insertStorePriceLog(anyList());
		doReturn(logMsgList).when(logHandlingService).prepareStorePriceLog(anyObject(), anyList(), anyString(),
				anyString());
//		doReturn(auditMsgList).when(auditHandlingService).prepareAuditMsgInitialPrice(anyObject(), anyString(),
//				anyString());
//		doNothing().when(auditHandlingService).insertAuditMsg(anyList());

		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	@Test
	public void testNonEmptyErrorList() throws Exception {
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		CommonContext cc = new CommonContext();
		sLupdatedContext.setCommonContext(cc);
		List<UPCItemDetail> itemDetails = getItemDetailList();
		sLupdatedContext.getCommonContext().setCicInfo(itemDetails);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		sLupdatedContext.getBasePricingMsg().setRetailSection("312");
		sLupdatedContext.getBasePricingMsg().setPaStoreInfo("09");
		List<StorePriceData> storeSpecificDetails = createStorePriceDataListWithoutPromotion(sLupdatedContext);
		ErrorMsg errorMsg = new ErrorMsg();
		List<ErrorMsg> errorMsgList = new ArrayList<>();
		sLupdatedContext.setStorePriceUpcList(storeSpecificDetails);
		classUnderTest.addItemPrice(sLupdatedContext, new ValidationContext());
		assertNotNull(itemDetails);
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("09");
		msg.setSuggLevel("Price Area");
		msg.setSuggPrice(5.1);
		// msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Price_Area");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setUpdatedEffectiveStartDt("2019-05-18");
		msg.setEffectiveEndDt("2019-05-25");
		msg.setScenarioFlg("SCN");
		// msg.setProjectedSales("94.90");
		// msg.setProjectedMargin("84.90");
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		// msg.setPriceOverrideReason("2");

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		item.setInitialPrice(false);
		item.setRetStatus("C");
		item.setStatusDST("V");

		itemDetailsList.add(item);

		return itemDetailsList;
	}

	private List<StorePriceData> createStorePriceDataListWithPromotion(StoreLevelUpdateContext sLupdatedContext) {
		List<StorePriceData> storePriceDataList = sLupdatedContext.getCommonContext().getCicInfo().stream()
				.map(item -> {
					StorePriceData storePriceData = new StorePriceData();
					storePriceData.setFacility(sLupdatedContext.getBasePricingMsg().getPaStoreInfo());
					storePriceData.setRogCd(item.getRogCd());
					storePriceData.setPromotionType("Y");
					storePriceData.setStartDate(BasePriceUtil
							.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getEffectiveStartDt()));
					storePriceData.setEndDate(BasePriceUtil
							.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getEffectiveEndDt()));
					return storePriceData;
				}).collect(Collectors.toList());

		return storePriceDataList;

	}

	private List<StorePriceData> createStorePriceDataListWithoutPromotion(StoreLevelUpdateContext sLupdatedContext) {
		List<StorePriceData> storePriceDataList = sLupdatedContext.getCommonContext().getCicInfo().stream()
				.map(item -> {
					StorePriceData storePriceData = new StorePriceData();
					storePriceData.setFacility(sLupdatedContext.getBasePricingMsg().getPaStoreInfo());
					storePriceData.setRogCd(item.getRogCd());
					storePriceData.setPromotionType("");
					storePriceData.setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
					storePriceData.setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-17"));
					return storePriceData;
				}).collect(Collectors.toList());

		return storePriceDataList;

	}

}
