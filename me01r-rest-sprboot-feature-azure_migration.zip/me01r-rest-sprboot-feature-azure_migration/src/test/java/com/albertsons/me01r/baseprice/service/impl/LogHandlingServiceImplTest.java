package com.albertsons.me01r.baseprice.service.impl;

import static com.albertsons.me01r.baseprice.util.ConstantsUtil.DEFAULT_INBOUND_VALIDATION_MESSAGE;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.dao.LogHandlingDAO;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.LogMsg;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;

@SpringBootTest(classes = LogHandlingServiceImpl.class)
public class LogHandlingServiceImplTest {

	@Autowired
	private LogHandlingServiceImpl classUnderTest;

	@MockBean
	private LogHandlingDAO logHandlingDAO;

	@MockBean
	private Environment env;

	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "appId", "testusr");
		when(this.env.getProperty(ConstantsUtil.EFFECTIVE_START_DATE_REVISED))
				.thenReturn(ConstantsUtil.EFFECTIVE_START_DATE_REVISED);
	}

	@Test
	public void testPrepareInitialPriceLog() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<ItemPriceData> itemPriceDataList = getItemPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "I";
		// classUnderTest.prepareInitialPriceLog(basePricingMsg, itemPriceDataList,
		// msgCd);
	}

	@Test
	public void testPreparePendingPriceLogDelete() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "D";
		String msg = "LogDelete";
		classUnderTest.preparePendingPriceLog(basePricingMsg, paPriceDataList, msgCd, msg);
	}

	@Test
	public void testPreparePendingPriceLogProcess() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE;
		classUnderTest.preparePendingPriceLog(basePricingMsg, paPriceDataList, msgCd, msg);
	}

	@Test
	public void testPreparePendingPriceLogProcessWrongMsg() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = "TEST";
		classUnderTest.preparePendingPriceLog(basePricingMsg, paPriceDataList, msgCd, msg);
	}

	@Test
	public void testPreparePendingPriceLogProcessNullMsg() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = null;
		classUnderTest.preparePendingPriceLog(basePricingMsg, paPriceDataList, msgCd, msg);
	}

	@Test
	public void testPreparePendingPriceLog() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = "LogProcess";
		basePricingMsg.setEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectiveStartDt(LocalDate.now().toString());
		classUnderTest.preparePendingPriceLog(basePricingMsg, paPriceDataList, msgCd, msg);
	}

	@Test
	public void testPreparePendingPriceLogUpdate() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "U";
		String msg = "LogUpdate";
		classUnderTest.preparePendingPriceLog(basePricingMsg, paPriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogDelete() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "D";
		String msg = "LogDelete";
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcess() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = " ";
		basePricingMsg.setStartDateDueToPromotion(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcessSTART_DATE_ON_WEEKEND_MESSAGE() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE;
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setInboundEffectivEndtDt(LocalDate.now().toString());
		basePricingMsg.setStartDateDueToPromotion(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcessLTS_PROMOTION() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = ConstantsUtil.LTS_PROMOTION;
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setStartDateDueToPromotion(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcessDEFAULT_INBOUND_VALIDATION_MESSAGE() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = ConstantsUtil.DEFAULT_INBOUND_VALIDATION_MESSAGE;
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setStartDateDueToPromotion(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcessSTART_DATE_UPDATED_FROM() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = ConstantsUtil.START_DATE_UPDATED_FROM;
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcessNullMsg() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = null;
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLog() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = "LogProcess";
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogUpdate() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "U";
		String msg = ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE;
		storePriceDataList.get(0).setEndDate(LocalDate.now());
		storePriceDataList.get(0).setDateOff(LocalDate.now().toString());
		storePriceDataList.get(0).setStartDate(LocalDate.now());
		storePriceDataList.get(0).setDateEff(LocalDate.now().toString());
		basePricingMsg.setEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setEffectiveEndDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectivEndtDt(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}
	
	@Test
	public void testPrepareStorePriceLogProcessDefault() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = DEFAULT_INBOUND_VALIDATION_MESSAGE;
		storePriceDataList.get(0).setEndDate(LocalDate.now());
		storePriceDataList.get(0).setDateOff(LocalDate.now().toString());
		storePriceDataList.get(0).setStartDate(LocalDate.now());
		storePriceDataList.get(0).setDateEff(LocalDate.now().toString());
		basePricingMsg.setEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setEffectiveEndDt(LocalDate.now().toString());
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().plusDays(1).toString());
		basePricingMsg.setInboundEffectivEndtDt(LocalDate.now().plusDays(1).toString());
		basePricingMsg.setUpdatedEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectivEndtDt(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}
	
	@Test
	public void testPrepareStorePriceLogProcessEqualDate() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = DEFAULT_INBOUND_VALIDATION_MESSAGE;
		storePriceDataList.get(0).setEndDate(LocalDate.now());
		storePriceDataList.get(0).setDateOff(LocalDate.now().toString());
		storePriceDataList.get(0).setStartDate(LocalDate.now());
		storePriceDataList.get(0).setDateEff(LocalDate.now().toString());
		basePricingMsg.setEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setEffectiveEndDt(LocalDate.now().toString());
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setInboundEffectivEndtDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectivEndtDt(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogProcessNotEqualDate() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = ConstantsUtil.START_DATE_UPDATED_FROM;
		storePriceDataList.get(0).setEndDate(LocalDate.now());
		storePriceDataList.get(0).setDateOff(LocalDate.now().toString());
		storePriceDataList.get(0).setStartDate(LocalDate.now());
		storePriceDataList.get(0).setDateEff(LocalDate.now().toString());
		basePricingMsg.setEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setEffectiveEndDt(LocalDate.now().toString());
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().plusDays(1).toString());
		basePricingMsg.setInboundEffectivEndtDt(LocalDate.now().plusDays(1).toString());
		basePricingMsg.setUpdatedEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectivEndtDt(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}
	
	@Test
	public void testPrepareStorePriceLogProcessNotEmptyMsg() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "P";
		String msg = "";
		storePriceDataList.get(0).setEndDate(LocalDate.now());
		storePriceDataList.get(0).setDateOff(LocalDate.now().toString());
		storePriceDataList.get(0).setStartDate(LocalDate.now());
		storePriceDataList.get(0).setDateEff(LocalDate.now().toString());
		basePricingMsg.setEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setEffectiveEndDt(LocalDate.now().toString());
		basePricingMsg.setInboundEffectiveStartDt(LocalDate.now().plusDays(1).toString());
		basePricingMsg.setInboundEffectivEndtDt(LocalDate.now().plusDays(1).toString());
		basePricingMsg.setUpdatedEffectiveStartDt(LocalDate.now().toString());
		basePricingMsg.setUpdatedEffectivEndtDt(LocalDate.now().toString());
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}
	
	@Test
	public void testPrepareStorePriceLogUpdateSTART_DATE_UPDATED_FROM() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "U";
		String msg = ConstantsUtil.START_DATE_UPDATED_FROM;
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogUpdate1() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "U";
		String msg = "tess";
		basePricingMsg.setStartDateDueToPromotion("test");
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, msg);
	}

	@Test
	public void testPrepareStorePriceLogUpdateNullMsg() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<StorePriceData> storePriceDataList = getStorePriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "U";
		String msg = ConstantsUtil.START_DATE_UPDATED_FROM;
		classUnderTest.prepareStorePriceLog(basePricingMsg, storePriceDataList, msgCd, null);
	}

	@Test
	public void testInsertInitialPriceLog() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		List<ItemPriceData> itemPriceDataList = getItemPriceDataList(itemDetailList, basePricingMsg);
		String msgCd = "I";
		doNothing().when(logHandlingDAO).insertLogMessage(anyList());
		classUnderTest.insertInitialPriceLog(basePricingMsg, itemPriceDataList, msgCd);
	}

	@Test
	public void testInsertPendingPriceLog() throws Exception {
		List<LogMsg> logMsgList = Arrays.asList(new LogMsg());
		doNothing().when(logHandlingDAO).insertLogMessage(anyList());
		classUnderTest.insertPendingPriceLog(logMsgList);
	}

	@Test
	public void testInsertStorePriceLog() throws Exception {
		List<LogMsg> logMsgList = Arrays.asList(new LogMsg());
		doNothing().when(logHandlingDAO).insertLogMessage(anyList());
		classUnderTest.insertStorePriceLog(logMsgList);
	}

	private List<StorePriceData> getStorePriceDataList(List<UPCItemDetail> itemDetailList,
			BasePricingMsg basePricingMsg) {
		List<StorePriceData> storePriceDataList = itemDetailList.stream().map(itemDetail -> {
			StorePriceData itemPriceData = new StorePriceData();
			itemPriceData.setRogCd(itemDetail.getRogCd());
			itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
			itemPriceData.setUpcSales(itemDetail.getUpcSales());
			itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
			itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
			itemPriceData.setDateOff("2019-05-15");
			itemPriceData.setEndDate(LocalDate.parse(basePricingMsg.getEffectiveEndDt()));
			itemPriceData.setDateEff("2019-05-12");
			itemPriceData.setStartDate(LocalDate.parse(basePricingMsg.getEffectiveStartDt()));
			return itemPriceData;
		}).collect(Collectors.toList());
		return storePriceDataList;
	}

	private List<PendingPriceData> getPaPriceDataList(List<UPCItemDetail> itemDetailList,
			BasePricingMsg basePricingMsg) {
		List<PendingPriceData> paPriceDataList = itemDetailList.stream().map(itemDetail -> {
			PendingPriceData itemPriceData = new PendingPriceData();
			itemPriceData.setCorp(itemDetail.getCorp());
			itemPriceData.setRogCd(itemDetail.getRogCd());
			itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
			itemPriceData.setUpcSales(itemDetail.getUpcSales());
			itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
			itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
			itemPriceData.setReason(ConstantsUtil.SPACE);
			itemPriceData.setSuggPrice(5.1);
			itemPriceData.setEffectiveStartDt("2019-05-16");
			return itemPriceData;
		}).collect(Collectors.toList());
		return paPriceDataList;
	}

	private List<ItemPriceData> getItemPriceDataList(List<UPCItemDetail> itemDetailList,
			BasePricingMsg basePricingMsg) {
		List<ItemPriceData> itemPriceDataList = itemDetailList.stream().map(itemDetail -> {
			ItemPriceData itemPriceData = new ItemPriceData();
			itemPriceData.setCorp(itemDetail.getCorp());
			itemPriceData.setDivision(itemDetail.getDivision());
			itemPriceData.setRogCd(itemDetail.getRogCd());
			itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
			itemPriceData.setUpcSales(itemDetail.getUpcSales());
			itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
			itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
			itemPriceData.setEffectiveStartDt(basePricingMsg.getEffectiveStartDt());
			itemPriceData.setPaStoreInfo(basePricingMsg.getPaStoreInfo());
			itemPriceData.setReason(ConstantsUtil.SPACE);
			itemPriceData.setPriceMtd(ConstantsUtil.R);
			itemPriceData.setLimQty(ConstantsUtil.ZERO);
			itemPriceData.setPriceFactor(basePricingMsg.getPriceFactor());
			itemPriceData.setSuggPrice(basePricingMsg.getSuggPrice());
			itemPriceData.setPriceFctAlt(ConstantsUtil.ZERO.toString());
			itemPriceData.setPriceAlt(ConstantsUtil.ZERO.toString());
			itemPriceData.setLtsFlag(ConstantsUtil.SPACE);
			itemPriceData.setLastUpdUserId(basePricingMsg.getLastUpdUserId());
			return itemPriceData;
		}).collect(Collectors.toList());
		return itemPriceDataList;
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("0009");
		msg.setSuggLevel("Store Price");
		msg.setSuggPrice(5.1);
		// msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Store_Price");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setUpdatedEffectiveStartDt("2019-05-17");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setUpdatedEffectivEndtDt("2019-05-18");
		msg.setLastUpdUserTs("2019-04-08 22:45:3");
		msg.setScenarioFlg("SCN");
		// msg.setProjectedSales("94.90");
		// msg.setProjectedMargin("84.90");
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		// msg.setPriceOverrideReason("2");

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(true);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

}
