package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = StorePriceValidatorRule8.class)
public class StorePriceValidatorRule8Test {

	@Autowired
	private StorePriceValidatorRule8 classUnderTest;

	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "invalidFacility", "INVALID-FACILITY");
		ReflectionTestUtils.setField(classUnderTest, "invalidRog", "INVALID-ROG-RETSECT-PA");

	}

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidStore());
		assertNotNull(getContextValidStore());
	}

	@Test
	public void testValidate1() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidStore1());
		assertNotNull(getContextValidStore());
	}

	@Test
	public void testValidate2() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidStore2());
		assertNotNull(getContextValidStore());
	}

	@Test
	public void testValidate3() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidStore3());
		assertNotNull(getContextValidStore());
	}

	@Test
	public void testInvalidData() throws SystemException {
		classUnderTest.validate(getInvalidBasePricingMsg(), getContextValidStore());
		assertNotNull(getContextValidStore());
	}

	private ValidationContext getContextValidStore() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setStoreExistChkResult(0);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextValidStore1() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setStoreExistChkResult(1);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextValidStore2() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setStoreExistChkResult(0);
		context.getErrorTypeMsgList().add("INVALID-ROG-RETSECT-PA");
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextValidStore3() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setStoreExistChkResult(0);
		context.getErrorTypeMsgList().add(" ");
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setStoreSpecific(true);
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setStoreSpecific(false);
		return basePricingMsg;
	}
}
