package com.albertsons.me01r.baseprice.validator.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule1.class)
public class CommonValidatorRule1Test {
	@Autowired
	private CommonValidatorRule1 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidRog());
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-ROG-RETSECT-PA");
		assertNotNull(getContextValidRog());
		assertEquals(1, getContextValidRog().getCommonContext().getRogExistChkResult());
	}

	@Test
	public void testNotValidatRog() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextNonValidRog());
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "INVALID-ROG-RETSECT-PA");
		assertNotNull(getContextValidRog());
		assertEquals(0, getContextNonValidRog().getCommonContext().getRogExistChkResult());
	}

	private ValidationContext getContextValidRog() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setRogExistChkResult(1);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextNonValidRog() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setRogExistChkResult(0);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}
}
