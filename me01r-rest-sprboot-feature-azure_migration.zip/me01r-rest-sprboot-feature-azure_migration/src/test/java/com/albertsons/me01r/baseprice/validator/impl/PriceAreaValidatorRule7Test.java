package com.albertsons.me01r.baseprice.validator.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = PriceAreaValidatorRule7.class)
public class PriceAreaValidatorRule7Test {

	@Autowired
	private PriceAreaValidatorRule7 classUnderTest;
	

	@BeforeEach
	public void setUp() {
	    ReflectionTestUtils.setField(classUnderTest, "invalidPARog", "INVALID-ROG-RETSECT-PA");
	    
	}

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidRetailPriceSection());
		assertNotNull(getContextValidRetailPriceSection());
	}

	@Test
	public void testInValidate() throws SystemException {
		classUnderTest.validate(getInvalidBasePricingMsg(), getContextValidRetailPriceSection());
		assertNotNull(getContextValidRetailPriceSection());
	}

	private ValidationContext getContextValidRetailPriceSection() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setRetailSectionPriceAreaExist(0);
		context.setCommonContext(commonContext);
		ArrayList<String> msgList = new ArrayList<String>();
		msgList.add("");
		// context.getErrorType().setMsgList(msgList);
		context.getErrorTypeMsgList().addAll(msgList);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setPriceArea(true);
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setPriceArea(false);
		return basePricingMsg;
	}
}
