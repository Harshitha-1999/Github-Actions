package com.albertsons.me01r.baseprice.validator.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule15.class)
public class CommonValidatorRule15Test {
	@Autowired
	private CommonValidatorRule15 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(3, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testNotValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextNotValidCic());
		assertNotNull(getContextNotValidCic());
		assertEquals(null, getContextNotValidCic().getCommonContext().getCicInfo());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(getUPCDetail());
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextNotValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(null);
		context.setCommonContext(commonContext);
		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private List<UPCItemDetail> getUPCDetail() {
		List<UPCItemDetail> upcList = new ArrayList<UPCItemDetail>();
		UPCItemDetail upcItemDetail1 = new UPCItemDetail();
		upcItemDetail1.setInitialPrice(true);;
		upcItemDetail1.setRupcStatus("D");
		
		UPCItemDetail upcItemDetail2 = new UPCItemDetail();
		upcItemDetail2.setInitialPrice(true);;
		upcItemDetail2.setRupcStatus("S");
		
		UPCItemDetail upcItemDetail3 = new UPCItemDetail();
		upcItemDetail3.setInitialPrice(false);;
		upcItemDetail3.setRupcStatus("D");
		
		upcList.add(upcItemDetail1);
		upcList.add(upcItemDetail2);
		upcList.add(upcItemDetail3);
		
		return upcList;
	}

}
