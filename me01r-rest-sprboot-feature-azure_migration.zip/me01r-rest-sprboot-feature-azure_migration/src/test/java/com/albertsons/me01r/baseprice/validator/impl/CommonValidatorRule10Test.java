package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule10.class)
public class CommonValidatorRule10Test {

	@Autowired
	private CommonValidatorRule10 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testInvalidData() throws SystemException {
		classUnderTest.validate(getInvalidBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testInitialPrice() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMsg();
		basePricingMsg.setStoreSpecific(true);
		classUnderTest.validate(basePricingMsg, getInvalidContext());
		assertNotNull(getContext());
	}

	@Test
	public void testValidateInValidEndDate() throws SystemException {
		classUnderTest.validate(getInvalidDateBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testValidateException() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());

	}

	@Test
	public void testValidateBeforeCurrentDate() throws SystemException {
		classUnderTest.validate(getInvalidCurrentDateBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testValidateCurrentDate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());

	}

	@Test
	public void testValidateAfterCurrentDate() throws SystemException {
		classUnderTest.validate(getBasePricingMsgAfterToday(), getContext());
		assertNotNull(getContext());

	}
	
	private ValidationContext getContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		// TODO needed?
		// context.getWarningType().setMsgList(new ArrayList<String>());
		return context;
	}

	private ValidationContext getInvalidContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getInvalidUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getInvalidCurrentDateBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		LocalDate effDate = LocalDate.now().minusDays(1);
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setUpdatedEffectiveStartDt(String.valueOf(effDate));
		return basePricingMsg;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		LocalDate effDate = LocalDate.now();
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setUpdatedEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setStoreSpecific(true);
		return basePricingMsg;
	}
	
	private BasePricingMsg getBasePricingMsgAfterToday() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		LocalDate effDate = LocalDate.now().plusDays(1);
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setUpdatedEffectiveStartDt(String.valueOf(effDate));
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidDateBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		LocalDate effDate = LocalDate.now().plusDays(15);
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setUpdatedEffectiveStartDt(String.valueOf(effDate.minusDays(20)));
		basePricingMsg.setStoreSpecific(false);
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setEffectiveStartDt(null);
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(false);
		return upcItemDetail;
	}

	private UPCItemDetail getInvalidUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(true);
		return upcItemDetail;
	}
}
