package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule9.class)
public class CommonValidatorRule9Test {
	@Autowired
	private CommonValidatorRule9 classUnderTest;

	/*
	 * @Before public void setUp() { ReflectionTestUtils.setField(classUnderTest,
	 * "priceFactorNotValid", "INVALID-PRICE-FACTOR");
	 * ReflectionTestUtils.setField(classUnderTest, "priceNotValid",
	 * "INVALID-PRICE-LMT");
	 * 
	 * }
	 */

	@Test
	public void testValidatePrice() throws SystemException {

		classUnderTest.validate(getBasePricingMsgValidPrice(), getContext());
		assertNotNull(getContext());
		assertEquals(100, getBasePricingMsgValidPrice().getPriceFactor().intValue());
	}

	@Test
	public void testValidatePriceFactor() throws SystemException {

		classUnderTest.validate(getBasePricingMsgValidPriceFactor(), getContext());
		assertNotNull(getContext());
		assertEquals(15, getBasePricingMsgValidPriceFactor().getPriceFactor().intValue());
	}

	private ValidationContext getContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		context.setCommonContext(commonContext);
		// TODO needed?
		// context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private BasePricingMsg getBasePricingMsgValidPriceFactor() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setSuggPrice(999.99);
		basePricingMsg.setPriceFactor(15);
		return basePricingMsg;
	}

	private BasePricingMsg getBasePricingMsgValidPrice() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setSuggPrice(70.00);
		basePricingMsg.setPriceFactor(100);
		return basePricingMsg;
	}

}
