package com.albertsons.me01r.baseprice.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

@SpringBootTest(classes = CommonProcessServiceImpl.class)
@PropertySource("classpath:application.properties")
public class CommonProcessServiceImplTest {

	@Autowired
	private CommonProcessServiceImpl classUnderTest;

	@MockBean
	ValidatePriceAreaDAO validatePriceAreaDAO;

	@MockBean
	ValidateStorePriceDAO validateStorePriceDAO;

	@Test
	public void testvalidateEffectiveStartDatePAWhenNoPromotionNoWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDatePAWhenNoPromotionButWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-18");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDatePAWhenSPromotionNoWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-23"));
		promoList.get(0).setPromotionType("S");
		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDatePAWhenSPromotionButWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-18");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setHasOptionalInitialPriced(false);
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promoList.forEach(promo -> promo.setPromotionType("S"));
		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDatePAWhenCPromotionNoWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setHasOptionalInitialPriced(false);
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-23"));
		promoList.forEach(promo -> promo.setPromotionType("C"));
		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDatePAWhenCPromotionButWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-18");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promoList.get(0).setPromotionType("C");
		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDateSSWhenNoPromotionNoWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-16");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setStartDateDueToPromotion("");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
//		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
//		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDateSSWhenNoPromotionNoWeekend1() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-11");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-11");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setStartDateDueToPromotion(null);
		basePricingMsg.setItemOnPromotion(true);
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
//		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
//		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	// WhenEffEndDateIsSmallerThanRevisedEffStartDate -- Not Ok
	@Test
	public void testvalidateEffectiveStartDateSSWhenNoPromotionButWeekendS() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-18");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
//		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
//		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	// WhenEffEndDateIsGreaterthanRevisedEffStartDate --OK
	@Test
	public void testvalidateEffectiveStartDateSSWhenNoPromotionButWeekendG() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-21");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-18");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-22");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
//		doReturn(promoList).when(validatePriceAreaDAO).fetchPromoitonDetails(anyObject());
//		doReturn(promoList).when(validatePriceAreaDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	// When Revised Effective Start Date becomes greater than effective end date and
	// promo start date is equal to
	// eff start date- Not OK
	@Test
	public void testvalidateEffectiveStartDateSSWhenSPromotionNoWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-23"));
		promoList.get(0).setPromotionType("S");
		promoList.get(1).setPromotionType("S");
		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	// When Effective Start Date becomes greater than effective end date and promo
	// start date is greater than
	// eff start date- Not OK
	@Test
	public void testvalidateEffectiveStartDateSSWhenSPromotionNoWeekend1() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-16"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-21"));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-17"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-23"));
		promoList.get(0).setPromotionType("S");
		promoList.get(1).setPromotionType("S");
		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	//// UpdatedEffStartDate is less than EffEndDate
	@Test
	public void testvalidateEffectiveStartDateSSWhenSPromotionButWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-18");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promoList.get(0).setPromotionType("S");
		promoList.get(1).setPromotionType("S");
		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	// UpdatedEffStartDate is Greater than EffEndDate
	@Test
	public void testvalidateEffectiveStartDateSSWhenSPromotionButWeekend2() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-18");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-20");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-22");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-21"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-26"));
		promoList.get(0).setPromotionType("S");
		promoList.get(1).setPromotionType("S");
		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDateSSWhenCPromotionNoWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-23"));
		promoList.get(0).setPromotionType("C");
		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDateSSWhenCPromotionButWeekend() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-19");
		basePricingMsg.setEffectiveEndDt("2019-05-20");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-19");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-20");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-19"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-26"));
		promoList.forEach(promo -> promo.setPromotionType("C"));
		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testUpdateDateForPromotionsStoreSpecific() throws SystemException {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		List<String> msgList = new ArrayList<String>();
		msgList.add("Message1");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		CommonContext cc = new CommonContext();
		cc.getDateChange().addAll(msgList);
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-14"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-28"));
		promoList.forEach(promo -> promo.setPromotionType("C"));
//		doReturn(promoList).when(validateStorePriceDAO).fetchPromoitonDetails(anyObject());
//		doReturn(promoList).when(validateStorePriceDAO).fetchLTSPromoitonDetails(anyObject());
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateDateForPromotionsStoreSpecific", promoList,
				basePricingMsg);
		assertNotNull(itemDetails);
	}

	@Test
	public void testvalidateEffectiveStartDateOptionalPrice() throws SystemException {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setHasOptionalInitialPriced(true);
		CommonContext cc = new CommonContext();
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
	}

	@Test
	public void validateEffectiveStartDateStoreSpecific() throws SystemException {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setStoreSpecific(false);
		CommonContext cc = new CommonContext();
		classUnderTest.validateEffectiveStartDateStoreSpecific(basePricingMsg, itemDetails, cc);
	}

	@Test
	public void testvalidateEffectiveStartDateOptionalPrice1() throws SystemException {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-15");
		basePricingMsg.setEffectiveEndDt("2019-05-19");
		basePricingMsg.setUpdatedEffectiveStartDt("2019-05-15");
		basePricingMsg.setUpdatedEffectivEndtDt("2019-05-19");
		basePricingMsg.setPriceArea(false);
		basePricingMsg.setHasOptionalInitialPriced(false);
		CommonContext cc = new CommonContext();
		classUnderTest.validateEffectiveStartDatePA(basePricingMsg, itemDetails, cc);
	}

	private List<Promotion> getPromotionList(BasePricingMsg basePricingMsg) {
		List<Promotion> promotionList = new ArrayList<Promotion>();

		Promotion promotion = new Promotion();
		promotion.setStartDate(BasePriceUtil.convertStringToLocalDate("2019-03-18"));
		promotion.setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promotion.setPromotionType("T");
		promotion.setCic(basePricingMsg.getCorpItemCd());
		promotion.setRog(basePricingMsg.getRogCd());
		promotion.setUnitType(basePricingMsg.getUnitType());
		promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
		promotion.setPrice(1.1);
		promotion.setPriceFactor(1);
		promotion.setUpcCountry(00000);
		promotion.setUpcManuf(0);
		promotion.setUpcSales(00000);
		promotion.setUpcSystem(0);
		basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());

		Promotion promotion1 = new Promotion();
		promotion1.setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-18"));
		promotion1.setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promotion1.setPromotionType("T");
		promotion1.setCic(basePricingMsg.getCorpItemCd());
		promotion1.setRog(basePricingMsg.getRogCd());
		promotion1.setUnitType(basePricingMsg.getUnitType());
		promotion1.setPriceArea(basePricingMsg.getPaStoreInfo());
		promotion1.setPrice(1.1);
		promotion1.setPriceFactor(1);
		promotion1.setUpcCountry(00000);
		promotion1.setUpcManuf(0);
		promotion1.setUpcSales(00000);
		promotion1.setUpcSystem(0);

		promotionList.add(promotion);
		promotionList.add(promotion1);
		return promotionList;

	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("09");
		msg.setSuggLevel("Price Area");
		msg.setSuggPrice(5.1);
		msg.setScenarioId(12);
		msg.setScenarioName("Scenario_Price_Area");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-18");
		msg.setEffectiveEndDt("2019-05-19");
		msg.setUpdatedEffectiveStartDt("2019-05-18");
		msg.setUpdatedEffectivEndtDt("2019-05-19");
		msg.setScenarioFlg("SCN");
		msg.setProjectedSales(94.90);
		msg.setProjectedMargin(84.90);
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		msg.setPriceOverrideReason(2);

		return msg;

	}

	private List<UPCItemDetail> getItemDetailInitialPriceList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(true);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

	private List<UPCItemDetail> getItemDetailPendingPriceList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(false);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

}
