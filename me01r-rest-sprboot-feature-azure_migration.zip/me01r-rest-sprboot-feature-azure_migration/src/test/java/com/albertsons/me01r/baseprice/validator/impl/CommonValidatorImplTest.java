package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorImpl.class)
public class CommonValidatorImplTest {

	@Autowired
	private CommonValidatorImpl classUnderTest;
	
	@MockBean
	private CommonValidator commonValidators;

	@MockBean
	CommonValidationService commonValidationService;

	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "commonValidators", getValidatorsList());
	}

	private List<CommonValidator> getValidatorsList() {
		List<CommonValidator> validatorList = new ArrayList<CommonValidator>();
		CommonValidatorRule1 commonValidatorRule1 = new CommonValidatorRule1();
		validatorList.add(commonValidatorRule1);
		return validatorList;
	}

	@Test
	public void testValidateWithNullCommonContext() throws SystemException {

		when(commonValidationService.getCommonValidationContext(anyObject())).thenReturn(getCommontContext());
		classUnderTest.validate(getBasePricingMsg(), getContextWithNullCc());
		assertNotNull(getContextValidCic());

	}

	@Test
	public void testValidateWithNullValidationContext() throws SystemException {

		when(commonValidationService.getCommonValidationContext(anyObject())).thenReturn(getCommontContext());
		classUnderTest.validate(getBasePricingMsg(), null);
		assertNotNull(getBasePricingMsg());
	}

	@Test
	public void testValidate() throws SystemException {

		when(commonValidationService.getCommonValidationContext(anyObject())).thenReturn(getCommontContext());
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateWithNoCommonValidators() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "commonValidators", null);
		when(commonValidationService.getCommonValidationContext(anyObject())).thenReturn(getCommontContext());
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		commonContext.setRogExistChkResult(1);
		commonContext.isRogExist();
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextWithNullCc() {
		ValidationContext context = new ValidationContext();
		context.setCommonContext(null);
		return context;
	}

	private CommonContext getCommontContext() {
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		commonContext.setRogExistChkResult(1);
		commonContext.isRogExist();
		return commonContext;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		return upcItemDetail;
	}

	@Test
	public void contextLoads() {
	}

}
