package com.albertsons.me01r.baseprice.service.impl;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.context.update.StoreLevelUpdateContext;
import com.albertsons.me01r.baseprice.dao.AuditHandlingDAO;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

@SpringBootTest(classes = AuditHandlingServiceImpl.class)
public class AuditHandlingServiceImplTest {

	@Autowired
	private AuditHandlingServiceImpl classUnderTest;

	@MockBean
	AuditHandlingDAO auditHandlingDAO;

	@Test
	public void testPrepareAuditMsgInitialPrice() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		InitialPricingUpdateContext initialPricingContext = new InitialPricingUpdateContext();
		CommonContext commonContext = new CommonContext();
		initialPricingContext.setCommonContext(commonContext);
		initialPricingContext.getCommonContext().setCicInfo(items);
		initialPricingContext.setBasePricingMsg(basePricingMsg);
		String flow = " ";
		String operation = "";
		classUnderTest.prepareAuditMsgInitialPrice(initialPricingContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgInitialPrice_SSITMROG() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		InitialPricingUpdateContext initialPricingContext = new InitialPricingUpdateContext();
		CommonContext commonContext = new CommonContext();
		initialPricingContext.setCommonContext(commonContext);
		initialPricingContext.getCommonContext().setCicInfo(items);
		initialPricingContext.setBasePricingMsg(basePricingMsg);
		String flow = "SSITMROG";
		String operation = "";
		classUnderTest.prepareAuditMsgInitialPrice(initialPricingContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgInitialPrice_SSITMURX() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		InitialPricingUpdateContext initialPricingContext = new InitialPricingUpdateContext();
		CommonContext commonContext = new CommonContext();
		initialPricingContext.setCommonContext(commonContext);
		initialPricingContext.getCommonContext().setCicInfo(items);
		initialPricingContext.setBasePricingMsg(basePricingMsg);
		List<ItemPriceData> itemPriceDataList = getItemPriceDataList(initialPricingContext);
		initialPricingContext.setItemPriceDataList(itemPriceDataList);
		String flow = "SSITMURX";
		String operation = "";
		classUnderTest.prepareAuditMsgInitialPrice(initialPricingContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgInitialPrice_SSITMPRC() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		InitialPricingUpdateContext initialPricingContext = new InitialPricingUpdateContext();
		CommonContext commonContext = new CommonContext();
		initialPricingContext.setCommonContext(commonContext);
		initialPricingContext.getCommonContext().setCicInfo(items);
		initialPricingContext.setBasePricingMsg(basePricingMsg);
		List<ItemPriceData> itemPriceDataList = getItemPriceDataList(initialPricingContext);
		initialPricingContext.setItemPriceDataList(itemPriceDataList);
		String flow = "SSITMPRC";
		String operation = "";
		classUnderTest.prepareAuditMsgInitialPrice(initialPricingContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgInitialPrice_SSITMPOS() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		InitialPricingUpdateContext initialPricingContext = new InitialPricingUpdateContext();
		CommonContext commonContext = new CommonContext();
		initialPricingContext.setCommonContext(commonContext);
		initialPricingContext.getCommonContext().setCicInfo(items);
		initialPricingContext.setBasePricingMsg(basePricingMsg);
		List<ItemPriceData> itemPriceDataList = getItemPriceDataList(initialPricingContext);
		initialPricingContext.setItemPriceDataList(itemPriceDataList);
		String flow = "SSITMPOS";
		String operation = "";
		classUnderTest.prepareAuditMsgInitialPrice(initialPricingContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgPendingPrice_SSPENPRC_N() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		CommonContext commonContext = new CommonContext();
		paUpdateContext.setCommonContext(commonContext);
		paUpdateContext.getCommonContext().setCicInfo(items);
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(paPriceDataList);
		String flow = "SSPENPRC";
		String operation = "N";
		classUnderTest.prepareAuditMsgPendingPrice(paUpdateContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgPendingPrice() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		CommonContext commonContext = new CommonContext();
		paUpdateContext.setCommonContext(commonContext);
		paUpdateContext.getCommonContext().setCicInfo(items);
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(paPriceDataList);
		String flow = " ";
		String operation = "N";
		classUnderTest.prepareAuditMsgPendingPrice(paUpdateContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgPendingPrice_SSPENPRC_D() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		CommonContext commonContext = new CommonContext();
		paUpdateContext.setCommonContext(commonContext);
		paUpdateContext.getCommonContext().setCicInfo(items);
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(paPriceDataList);
		String flow = "SSPENPRC";
		String operation = "D";
		classUnderTest.prepareAuditMsgPendingPrice(paUpdateContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgPendingPrice_SSPENPRC_U() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
		CommonContext commonContext = new CommonContext();
		paUpdateContext.setCommonContext(commonContext);
		paUpdateContext.getCommonContext().setCicInfo(items);
		paUpdateContext.setBasePricingMsg(basePricingMsg);
		List<PendingPriceData> paPriceDataList = getPaPriceDataList(paUpdateContext);
		paUpdateContext.setPendingPriceDataList(paPriceDataList);
		String flow = "SSPENPRC";
		String operation = "U";
		classUnderTest.prepareAuditMsgPendingPrice(paUpdateContext, flow, operation);

	}

	@Test
	public void testPrepareAuditMsgStorePrice_SSSPCRTL_D() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		CommonContext commonContext = new CommonContext();
		sLupdatedContext.setCommonContext(commonContext);
		sLupdatedContext.getCommonContext().setCicInfo(items);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		List<StorePriceData> storePriceDataList = getStorePriceDataList(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storePriceDataList);
		String flow = "SSSPCRTL";
		String operation = "D";
		classUnderTest.prepareAuditMsgStorePrice(sLupdatedContext.getBasePricingMsg(), storePriceDataList, flow,
				operation);

	}

	@Test
	public void testPrepareAuditMsgStorePrice_SSSPCRTL_U() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		CommonContext commonContext = new CommonContext();
		sLupdatedContext.setCommonContext(commonContext);
		sLupdatedContext.getCommonContext().setCicInfo(items);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		List<StorePriceData> storePriceDataList = getStorePriceDataList(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storePriceDataList);
		String flow = "SSSPCRTL";
		String operation = "U";
		classUnderTest.prepareAuditMsgStorePrice(sLupdatedContext.getBasePricingMsg(), storePriceDataList, flow,
				operation);

	}

	@Test
	public void testPrepareAuditMsgStorePrice_SSSPCRTL_P() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		CommonContext commonContext = new CommonContext();
		sLupdatedContext.setCommonContext(commonContext);
		sLupdatedContext.getCommonContext().setCicInfo(items);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		List<StorePriceData> storePriceDataList = getStorePriceDataList(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storePriceDataList);
		String flow = "SSSPCRTL";
		String operation = "P";
		classUnderTest.prepareAuditMsgStorePrice(sLupdatedContext.getBasePricingMsg(), storePriceDataList, flow,
				operation);

	}

	@Test
	public void testPrepareAuditMsgStorePrice() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = getItemDetailList();
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		CommonContext commonContext = new CommonContext();
		sLupdatedContext.setCommonContext(commonContext);
		sLupdatedContext.getCommonContext().setCicInfo(items);
		sLupdatedContext.setBasePricingMsg(basePricingMsg);
		List<StorePriceData> storePriceDataList = getStorePriceDataList(sLupdatedContext);
		sLupdatedContext.setStorePriceUpcList(storePriceDataList);
		String flow = " ";
		String operation = "P";
		classUnderTest.prepareAuditMsgStorePrice(sLupdatedContext.getBasePricingMsg(), storePriceDataList, flow,
				operation);

	}

	@Test
	public void testInsertAuditMsg() throws Exception {
		when(auditHandlingDAO.insertAuditMsg(anyList())).thenReturn(1);
		// doReturn(1).when(auditHandlingDAO).insertAuditMsg(anyList());
		List<AuditMsg> auditList = Arrays.asList(new AuditMsg());
		classUnderTest.insertAuditMsg(auditList);

	}

	private List<StorePriceData> getStorePriceDataList(StoreLevelUpdateContext sLupdatedContext) {
		List<StorePriceData> storePriceDataList = sLupdatedContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					StorePriceData itemPriceData = new StorePriceData();
					itemPriceData.setRogCd(itemDetail.getRogCd());
					itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
					itemPriceData.setUpcSales(itemDetail.getUpcSales());
					itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
					itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
					return itemPriceData;
				}).collect(Collectors.toList());
		return storePriceDataList;
	}

	private List<PendingPriceData> getPaPriceDataList(PriceAreaUpdateContext paUpdateContext) {
		List<PendingPriceData> paPriceDataList = paUpdateContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					PendingPriceData itemPriceData = new PendingPriceData();
					itemPriceData.setCorp(itemDetail.getCorp());
					itemPriceData.setRogCd(itemDetail.getRogCd());
					itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
					itemPriceData.setUpcSales(itemDetail.getUpcSales());
					itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
					itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
					itemPriceData.setReason(ConstantsUtil.SPACE);
					return itemPriceData;
				}).collect(Collectors.toList());
		return paPriceDataList;
	}

	private List<ItemPriceData> getItemPriceDataList(InitialPricingUpdateContext ipUpdateContext) {
		List<ItemPriceData> itemPriceDataList = ipUpdateContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					ItemPriceData itemPriceData = new ItemPriceData();
					itemPriceData.setCorp(itemDetail.getCorp());
					itemPriceData.setDivision(itemDetail.getDivision());
					itemPriceData.setRogCd(itemDetail.getRogCd());
					itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
					itemPriceData.setUpcSales(itemDetail.getUpcSales());
					itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
					itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
					itemPriceData.setEffectiveStartDt(ipUpdateContext.getBasePricingMsg().getEffectiveStartDt());
					itemPriceData.setPaStoreInfo(ipUpdateContext.getBasePricingMsg().getPaStoreInfo());
					itemPriceData.setReason(ConstantsUtil.SPACE);
					itemPriceData.setPriceMtd(ConstantsUtil.R);
					itemPriceData.setLimQty(ConstantsUtil.ZERO);
					itemPriceData.setPriceFactor(ipUpdateContext.getBasePricingMsg().getPriceFactor());
					itemPriceData.setSuggPrice(ipUpdateContext.getBasePricingMsg().getSuggPrice());
					itemPriceData.setPriceFctAlt(ConstantsUtil.ZERO.toString());
					itemPriceData.setPriceAlt(ConstantsUtil.ZERO.toString());
					itemPriceData.setLtsFlag(ConstantsUtil.SPACE);
					itemPriceData.setLastUpdUserId(ipUpdateContext.getBasePricingMsg().getLastUpdUserId());
					return itemPriceData;
				}).collect(Collectors.toList());
		return itemPriceDataList;
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("0009");
		msg.setSuggLevel("Store Price");
		msg.setSuggPrice(5.1);
		// msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Store_Price");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		// msg.setProjectedSales("94.90");
		// msg.setProjectedMargin("84.90");
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		// msg.setPriceOverrideReason("2");

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {
		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();
		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);
		item.setRetStatus("C");
		item.setUpdatedRogStatus("P");
		item.setInitialPrice(true);
		itemDetailsList.add(item);
		return itemDetailsList;
	}

	// @Test
	public void testPrepareAuditMsgInitialPriceNoRetStatus() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> items = new ArrayList<>();// getItemDetailList();
		InitialPricingUpdateContext initialPricingContext = new InitialPricingUpdateContext();
		CommonContext commonContext = new CommonContext();
		initialPricingContext.setCommonContext(commonContext);
		initialPricingContext.getCommonContext().setCicInfo(items);
		initialPricingContext.setBasePricingMsg(basePricingMsg);
		String flow = "SSITMROG";
		String operation = "";
		classUnderTest.prepareAuditMsgInitialPrice(initialPricingContext, flow, operation);

	}

}
