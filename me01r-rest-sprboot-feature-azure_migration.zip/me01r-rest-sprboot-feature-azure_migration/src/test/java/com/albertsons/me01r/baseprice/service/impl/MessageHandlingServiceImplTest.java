package com.albertsons.me01r.baseprice.service.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.dao.MessageHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.kafka.KafkaPriceAreaProducer;
import com.albertsons.me01r.baseprice.kafka.KafkaStorePriceProducer;
import com.albertsons.me01r.baseprice.model.BasePricingHeader;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsgJson;
import com.albertsons.me01r.baseprice.model.CICItemDetail;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.PriceLevel;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.TableUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(classes = MessageHandlingServiceImpl.class)
public class MessageHandlingServiceImplTest {

	@Autowired
	private MessageHandlingServiceImpl classUnderTest;

	@MockBean
	private MessageHandlingDAO messageHandlingDAO;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private KafkaPriceAreaProducer kafkaPriceAreaQProducer;

	@MockBean
	private KafkaStorePriceProducer kafkaStorePriceQProducer;

	@MockBean
	private PriceAreaService priceAreaService;

	@MockBean
	private StorePriceService storePriceService;

	@MockBean
	private BasePricingMessages basePricingMsgs;

	private final static String basePriceMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"ab\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3       }    ]}";

	private final static String basePriceMessageEmptySuggLevel = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"ab\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3       }    ]}";

	private final static String basePriceMessageCRC = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 100,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"ab\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3       }    ]}";

	private final static String basePriceMessageCRCStore = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 100,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"ab\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3       }    ]}";

	private final static String invalidBasePriceMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": -3      }    ]}";

	private final static String invalidBasePriceMsg = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": \"a\",            \"corpItemCd\": \"a\",            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"ab\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07\",            \"effectiveEndDt\": \"12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": \"a\"      }    ]}";

	private final static String invalidBasePriceMsgStore = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": \"a\",            \"corpItemCd\": \"a\",            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"ab\",            \"suggLevel\": \"STORE\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07\",            \"effectiveEndDt\": \"12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": \"a\"      }    ]}";

	private final static String basePriceMessageNonNumericCount = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"a\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3, \"exceptionMessage\" : true        }    ]}";

	private final static String basePriceMessageNumericCount = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": \"SDEN\",            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3, \"exceptionMessage\" : true        }    ]}";

	private final static String basePriceStoreSpecifcMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        }    ]}";

	private final static String basePriceMessageCrc = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 123,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3 ,\"exceptionMessage\" : true       }    ]}";

	private final static String basePriceStoreSpecifcMessageCrc = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"1\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 123,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3,\"exceptionMessage\": true        }    ]}";

	private final static String basePriceMultipleMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"2\", \"suggLevel\": \"PA\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        },{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Price Area\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        }    ]}";

	private final static String basePriceStoreSpecifcMultipleMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"2\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        },{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        }    ]}";

	private final static String basePriceWrongMultipleMessage = "{ \"priceChangeHeader\": { \"requestId\": \"20190722161414\", \"recordCount\": \"4\", \"suggLevel\": \"Store\" },\"priceList\": [{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        },{ \"recordCount\": 1,    \"crcId\": 0,            \"corpItemCd\": 1010055,            \"unitType\": 1,            \"rogCd\": \"SDEN\",            \"retailSection\": 328,           \"paStoreInfo\": \"0008\",            \"suggLevel\": \"Store\",            \"suggPrice\": 3,            \"scenarioId\": 0,           \"scenarioName\": \"test\",            \"lastUpdUserId\": \"test\",            \"lastUpdUserTs\": \"2019-07-25 22:45:37\",            \"effectiveStartDt\": \"2019-07-25\",            \"effectiveEndDt\": \"2019-12-13\",           \"scenarioFlg\": \"M\",            \"projectedSales\": 0,            \"projectedMargin\": 0,            \"projectedUnits\": 0,            \"priceFactor\": 4,            \"priceOverrideReason\": 3        }    ]}";

	private final static InboundMessage message = new InboundMessage(null); 

    private final static InboundMessage storeSpecificMessage = new InboundMessage(null);

	private final static InboundMessage msg = new InboundMessage(null);
	
	@Test
	public void testProcessIncomingMessage() throws SystemException, Exception {
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessDataIntegrityExDUPLICATE_DATAException() throws SystemException, Exception {
		DataIntegrityViolationException se = new DataIntegrityViolationException(ConstantsUtil.DUPLICATE_DATA);
		doThrow(se).when(priceAreaService).process(anyObject());
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
	}

	@Test
	public void testProcessDataIntegrityEx() throws SystemException, Exception {
		DataIntegrityViolationException se = new DataIntegrityViolationException("");
		doThrow(se).when(priceAreaService).process(anyObject());
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
	}

	@Test
	public void testProcessDataIntegrityExSqlException() throws SystemException, Exception {
		DataIntegrityViolationException se = new DataIntegrityViolationException(ConstantsUtil.SQL_EXCEPTION);
		doThrow(se).when(priceAreaService).process(anyObject());
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
	}

	@Test
	public void testProcessSystemException() throws SystemException, Exception {
		SystemException se = new SystemException(" ", null);
		doThrow(se).when(storePriceService).process(anyObject());
		msg.setPayload(basePriceStoreSpecifcMessage);
		message.setPayload(basePriceStoreSpecifcMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.Store);
	}
	
	@Test
	public void testProcessSystemExceptionFailed() throws SystemException, Exception {
		SystemException se = new SystemException("Failed validation rule(s)", null);
		doThrow(se).when(storePriceService).process(anyObject());
		msg.setPayload(basePriceStoreSpecifcMessage);
		message.setPayload(basePriceStoreSpecifcMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.Store);
	}

	@Test
	public void testProcessDataIntegrityExStoreDUPLICATE_DATAException() throws SystemException, Exception {
		DataIntegrityViolationException se = new DataIntegrityViolationException(ConstantsUtil.DUPLICATE_DATA);
		doThrow(se).when(storePriceService).process(anyObject());
		msg.setPayload(basePriceStoreSpecifcMessage);
		message.setPayload(basePriceStoreSpecifcMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.Store);
	}

	@Test
	public void testProcessDataIntegrityExStore() throws SystemException, Exception {
		DataIntegrityViolationException se = new DataIntegrityViolationException("");
		doThrow(se).when(storePriceService).process(anyObject());
		msg.setPayload(basePriceStoreSpecifcMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.Store);
	}

	@Test
	public void testProcessDataIntegrityStoreExSqlException() throws SystemException, Exception {
		DataIntegrityViolationException se = new DataIntegrityViolationException(ConstantsUtil.SQL_EXCEPTION);
		doThrow(se).when(storePriceService).process(anyObject());
		msg.setPayload(basePriceStoreSpecifcMessage);
		message.setPayload(basePriceStoreSpecifcMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.Store);
	}

	@Test
	public void testProcessIncomingMessageEmptySuggLevel() throws SystemException, Exception {
		msg.setPayload(basePriceMessageEmptySuggLevel);
		message.setPayload(basePriceMessageEmptySuggLevel);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
	}

	@Test
	public void testProcessIncomingMessageException() throws SystemException, Exception {
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);		
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		BasePricingMessages basePriceMsg = getBasePricingMessages();
		basePriceMsg.getPriceList().get(0)
				.setExceptionMessage(TableUtil.SSITMROG + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + "501");
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", basePriceMsg, msg);
	}

	@Test
	public void testProcessIncomingMessageEmptyPriceList() throws SystemException, Exception {
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);	
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		BasePricingMessages basePriceMsg = getBasePricingMessages();
		basePriceMsg.getPriceList().clear();
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", basePriceMsg, msg);
	}

	@Test
	public void testProcessIncomingMessageTotalCountNonZero() throws SystemException, Exception {
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);	
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		BasePricingMessages basePriceMsg = getBasePricingMessages();
		basePriceMsg.getPriceList().get(0).setTotalCount(1);
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateBasePriceMsg", basePriceMsg, msg);
	}

	@Test
	public void testProcessIncomingMessageSqlException() throws SystemException, Exception {
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);	
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		BasePricingMessages basePriceMsg = getBasePricingMessages();
		basePriceMsg.getPriceList().get(0)
				.setExceptionMessage(TableUtil.SSITMROG + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + "501");
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", basePriceMsg, msg);
	}

	@Test
	public void testProcessIncomingMessageCRC() throws SystemException, Exception {
		msg.setPayload(basePriceMessageCRC);
		message.setPayload(basePriceMessageCRC);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageCRCStore() throws SystemException, Exception {
		msg.setPayload(basePriceMessageCRCStore);
		message.setPayload(basePriceMessageCRCStore);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMsgInvalid() throws SystemException, Exception {
		msg.setPayload(invalidBasePriceMsg);
		message.setPayload(invalidBasePriceMsg);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMsgInvalidStore() throws SystemException, Exception {
		msg.setPayload(invalidBasePriceMsgStore);
		message.setPayload(invalidBasePriceMsgStore);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageInvalid() throws SystemException, Exception {
		msg.setPayload(invalidBasePriceMsgStore);
		message.setPayload(invalidBasePriceMsgStore);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageMismatchCount() throws SystemException, Exception {
		msg.setPayload(basePriceWrongMultipleMessage);
		message.setPayload(basePriceWrongMultipleMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMultiMessage() throws SystemException, Exception {
		msg.setPayload(basePriceMultipleMessage);
		message.setPayload(basePriceMultipleMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingSSMultiMessage() throws SystemException, Exception {
		msg.setPayload(basePriceStoreSpecifcMultipleMessage);
		message.setPayload(basePriceStoreSpecifcMultipleMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageJsonException() throws SystemException, Exception {
		msg.setPayload(basePriceMessageNonNumericCount);
		message.setPayload(basePriceMessageNonNumericCount);
		doReturn(Arrays.asList(new ErrorMsg())).when(errorHandlingService).prepareInvlaidRecordCount(anyObject());
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
	}

	@Test
	public void testProcessIncomingMessageNumericRecordCount() throws SystemException, Exception {
		msg.setPayload(basePriceMessageNumericCount);
		message.setPayload(basePriceMessageNumericCount);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
	}

	@Test
	public void testNullMdcValues() throws SystemException, Exception {
		msg.setPayload(basePriceMessage);
		message.setPayload(basePriceMessage);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageStoreSpecific() throws SystemException, Exception {
		storeSpecificMessage.setPayload(basePriceStoreSpecifcMessage);
		message.setPayload(basePriceStoreSpecifcMessage);
		classUnderTest.processIncomingMessage(storeSpecificMessage, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(),
				storeSpecificMessage);
	}

	@Test
	public void testProcessIncomingMessageCrc() throws SystemException, Exception {
		msg.setPayload(basePriceMessageCrc);
		message.setPayload(basePriceMessageCrc);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageStoreSpecificCrc() throws SystemException, Exception {
		message.setPayload(basePriceStoreSpecifcMessageCrc);
		storeSpecificMessage.setPayload(basePriceStoreSpecifcMessageCrc);
		classUnderTest.processIncomingMessage(storeSpecificMessage, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getBasePricingMessages(),
				storeSpecificMessage);
	}

	@Test
	public void testProcessIncomingMessageMultipleMessage() throws SystemException, Exception {
		msg.setPayload(basePriceMessageCrc);
		message.setPayload(basePriceMessageCrc);
		classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getMultiBasePricingMessages(), msg);
	}

	@Test
	public void testProcessIncomingMessageStoreSpecificMultipleMessage() throws SystemException, Exception {
		storeSpecificMessage.setPayload(basePriceStoreSpecifcMessageCrc);
		message.setPayload(basePriceStoreSpecifcMessageCrc);
		classUnderTest.processIncomingMessage(storeSpecificMessage, PriceLevel.PA);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkMessageSize", getMultiBasePricingStoreSpecificMessages(),
				storeSpecificMessage);
	}

	@Test
	public void testProcessWrongIncomingMessage() throws SystemException, Exception {
		msg.setPayload("test");
		message.setPayload("test");
		assertThrows(JsonParseException.class, ()->{
			classUnderTest.processIncomingMessage(msg, PriceLevel.PA);
		});	
	}

	@Test
	public void testProcessIncomingMessageMsgNull() throws SystemException, Exception {
		assertThrows(NullPointerException.class, ()->{
			classUnderTest.processIncomingMessage(null, PriceLevel.PA);
		});
	}

	@Test
	public void testProcessIncomingMessageMsgNotText() throws SystemException, Exception {
		assertThrows(IllegalArgumentException.class, ()->{
		classUnderTest.processIncomingMessage(new InboundMessage(), PriceLevel.PA);
		});
	}

	private BasePricingMessages getBasePricingMessages()
			throws JsonParseException, JsonMappingException, IOException {
		message.setPayload(basePriceMessage);
		return new ObjectMapper().readValue(message.getPayload(), BasePricingMessages.class);
	}

	private BasePricingMessages getMultiBasePricingMessages()
			throws JsonParseException, JsonMappingException, IOException {
		message.setPayload(basePriceMultipleMessage);
		return new ObjectMapper().readValue(message.getPayload(), BasePricingMessages.class);
	}

	private BasePricingMessages getMultiBasePricingStoreSpecificMessages()
			throws JsonParseException, JsonMappingException, IOException {
		message.setPayload(basePriceStoreSpecifcMultipleMessage);
		return new ObjectMapper().readValue(message.getPayload(), BasePricingMessages.class);
	}

	@Test
	public void testProcessPriceAreaMsg() throws Exception {
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(true);
		basePricingMsg.setPriceArea(true);
		validationContext.setBasePricingMsg(basePricingMsg);
		List<CICItemDetail> cicList = getCICItemDetail(basePricingMsg);
		doReturn(cicList).when(messageHandlingDAO).fetchCrcInformation(anyObject());
		doNothing().when(kafkaPriceAreaQProducer).sendMsg(anyObject());
		ReflectionTestUtils.invokeMethod(classUnderTest, "process", validationContext);
	}

	@Test
	public void testProcessStorePriceMsg() throws Exception {
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(true);
		basePricingMsg.setStoreSpecific(true);
		validationContext.setBasePricingMsg(basePricingMsg);
		List<CICItemDetail> cicList = getCICItemDetail(basePricingMsg);
		doReturn(cicList).when(messageHandlingDAO).fetchCrcInformation(anyObject());
		doNothing().when(kafkaStorePriceQProducer).sendMsg(anyObject());
		ReflectionTestUtils.invokeMethod(classUnderTest, "process", validationContext);
	}

	@Test
	public void testProcessNonCrcMsg() throws Exception {
		ValidationContext validationContext = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(false);
		validationContext.setBasePricingMsg(basePricingMsg);
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		validationContext.setBasePricingMessages(basePricingMessages);
		List<CICItemDetail> cicList = getCICItemDetail(basePricingMsg);
		doReturn(cicList).when(messageHandlingDAO).fetchCrcInformation(anyObject());
		doNothing().when(kafkaStorePriceQProducer).sendMsg(anyObject());
		List<ErrorMsg> errList = Arrays.asList(new ErrorMsg());
		doReturn(errList).when(errorHandlingService).prepareErrorMsg(anyObject(), anyList(), anyString(), anyList());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		doNothing().when(errorHandlingService).insertNonNumericErrorMessage(anyObject(), anyList());

		ReflectionTestUtils.invokeMethod(classUnderTest, "process", validationContext);
	}

	@Test
	public void testProcessMeatItemStorePriceMsg() throws Exception {

		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		List<OptionalCutDetail> optionalCutDetails = getOptionalCutDetails();
		basePricingMsg.setOptionalCutDetails(optionalCutDetails);
		List<CICItemDetail> cicList = getCICItemDetail(basePricingMsg);
		doReturn(cicList).when(messageHandlingDAO).fetchCrcInformation(anyObject());
		doNothing().when(kafkaStorePriceQProducer).sendMsg(anyObject());
		List<ErrorMsg> errList = Arrays.asList(new ErrorMsg());
		doReturn(errList).when(errorHandlingService).prepareErrorMsg(anyObject(), anyList(), anyString(), anyList());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		doNothing().when(errorHandlingService).insertNonNumericErrorMessage(anyObject(), anyList());
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(anyList());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);

		classUnderTest.processMeatItem(basePricingMsg, validationContext);
	}

	@Test
	public void testProcessMeatItemPriceAreaMsg() throws Exception {

		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		List<OptionalCutDetail> optionalCutDetails = getOptionalCutDetails();
		basePricingMsg.setOptionalCutDetails(optionalCutDetails);
		List<CICItemDetail> cicList = getCICItemDetail(basePricingMsg);
		doReturn(cicList).when(messageHandlingDAO).fetchCrcInformation(anyObject());
		doNothing().when(kafkaPriceAreaQProducer).sendMsg(anyObject());
		List<ErrorMsg> errList = Arrays.asList(new ErrorMsg());
		doReturn(errList).when(errorHandlingService).prepareErrorMsg(anyObject(), anyList(), anyString(), anyList());
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		doNothing().when(errorHandlingService).insertNonNumericErrorMessage(anyObject(), anyList());
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(anyList());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		classUnderTest.processMeatItem(basePricingMsg, validationContext);
	}

	@Test
	public void testPrepareStoreSplit() throws SystemException, Exception {
		ReflectionTestUtils.invokeMethod(classUnderTest, "prepareStoreSplit", getBasePricingMessage());
	}

	@Test
	public void testprocessStoreSplit() throws SystemException {
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(true);
		basePricingMsg.setPriceArea(true);
		validationContext.setBasePricingMsg(basePricingMsg);
		classUnderTest.processStoreSplit(getBasePricingMessage(), validationContext);
	}

	@Test
	public void testprocessStoreSplit1() throws SystemException {
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(true);
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setInboundEffectivEndtDt("2019-01-01");
		basePricingMsg.setInboundEffectiveStartDt(null);
		validationContext.setBasePricingMsg(basePricingMsg);
		classUnderTest.processStoreSplit(basePricingMsg, validationContext);
	}

	@Test
	public void testprocessStoreSplit2() throws SystemException {
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(true);
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setInboundEffectivEndtDt("2019-01-01");
		basePricingMsg.setInboundEffectiveStartDt("2019-01-01");
		validationContext.setBasePricingMsg(basePricingMsg);
		classUnderTest.processStoreSplit(basePricingMsg, validationContext);
	}

	@Test
	public void testprocessStoreSplit3() throws SystemException {
		ValidationContext validationContext = new ValidationContext();
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		basePricingMessages.setPriceList(new ArrayList<>());
		basePricingMessages.setPriceChangeHeader(new BasePricingHeader());
		validationContext.setBasePricingMessages(basePricingMessages);
		CommonContext commonContext = new CommonContext();
		validationContext.setCommonContext(commonContext);
		validationContext.getCommonContext().setCicInfo(getItemDetailList());
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setCrcPricing(true);
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setInboundEffectivEndtDt(null);
		basePricingMsg.setInboundEffectiveStartDt("2019-01-01");
		validationContext.setBasePricingMsg(basePricingMsg);
		classUnderTest.processStoreSplit(basePricingMsg, validationContext);
	}

	@Test
	public void testprepareErrorMsg() throws SystemException {
		BasePricingMsg basePricingMsg = null;
		ReflectionTestUtils.invokeMethod(classUnderTest, "prepareErrorMsg", basePricingMsg, getItemDetailList(), "",
				new ArrayList<>());
	}

	@Test
	public void testinsertError() throws SystemException {
		ReflectionTestUtils.invokeMethod(classUnderTest, "insertError", new ArrayList<>());
	}

	@Test
	public void testgetExceptionForNumericField() throws SystemException {
		BasePricingMsgJson basePriceJson = new BasePricingMsgJson();
		basePriceJson.setSuggPrice("9");
		basePriceJson.setProjectedSales("9");
		basePriceJson.setUnitType("1");
		basePriceJson.setPriceFactor("1");
		basePriceJson.setProjectedMargin("9");
		basePriceJson.setScenarioId("-9");
		ReflectionTestUtils.invokeMethod(classUnderTest, "getExceptionForNumericField", basePriceJson,
				new ValidationContext());
	}

	@Test
	public void testgetExceptionForNumericField1() throws SystemException {
		BasePricingMsgJson basePriceJson = new BasePricingMsgJson();
		basePriceJson.setSuggPrice("a");
		basePriceJson.setProjectedSales("a");
		basePriceJson.setProjectedMargin("as");
		ReflectionTestUtils.invokeMethod(classUnderTest, "getExceptionForNumericField", basePriceJson,
				new ValidationContext());
	}

	@Test
	public void testupdateValidationContextPriceArea()
			throws SystemException, JsonParseException, JsonMappingException, IOException {
		BasePricingMessages basePriceMessages = new BasePricingMessages();
		basePriceMessages.setPriceList(Arrays.asList(getBasePricingMessage()));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateValidationContextPriceArea", basePriceMessages,
				anyObject());
	}

	private List<OptionalCutDetail> getOptionalCutDetails() {
		List<OptionalCutDetail> ocList = new ArrayList<OptionalCutDetail>();
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(12345);
		optionalCutDetail.setOptionalItemGap(1.1);
		ocList.add(optionalCutDetail);
		return ocList;
	}

	private List<CICItemDetail> getCICItemDetail(BasePricingMsg basePricingMsg) {
		List<CICItemDetail> cicList = new ArrayList<CICItemDetail>();
		CICItemDetail cic = new CICItemDetail();
		cic.setCorpItemCd(12345);
		cic.setCrcId(basePricingMsg.getCrcId());
		cic.setPriceArea(basePricingMsg.getPaStoreInfo());
		cic.setRogCd(basePricingMsg.getRogCd());
		cic.setUnitType(basePricingMsg.getUnitType());
		cicList.add(cic);
		cic.setCorpItemCd(23456);
		cicList.add(cic);
		return cicList;
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("0009");
		msg.setSuggLevel("Store Price");
		msg.setSuggPrice(5.1);
		// msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Store_Price");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		// msg.setProjectedSales("94.90");
		// msg.setProjectedMargin("84.90");
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		// msg.setPriceOverrideReason("2");

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(true);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

}
