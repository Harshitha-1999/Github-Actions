package com.albertsons.me01r.baseprice.service.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.StorePriceUpdateService;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;
import com.albertsons.me01r.baseprice.validator.impl.CommonValidatorImpl;

@SpringBootTest(classes = StorePriceServiceImpl.class)
public class StorePriceServiceImplTest {

	@Autowired
	private StorePriceServiceImpl classUnderTest;

	@MockBean
	CommonValidatorImpl commonValidatorImpl;

	@MockBean
	@Qualifier("StorePriceValidatorImpl")
	ValidatorImpl storeValidatorImpl;

	@MockBean
	StorePriceUpdateService storePriceUpdateService;

	@MockBean
	CommonValidationService commonValidationService;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private ValidateStorePriceDAO validateStorPriceDAO;

	@Test
	public void testProcessWithBasePricingMessage() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		// doNothing().when(classUnderTest).performUpdate(anyObject(), anyObject());
		// doNothing().when(priceAreaUpdateDAO).insertItemPendingPrice(anyObject(),
		// anyObject());

		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(storeValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		doReturn(itemDetails.get(0)).when(commonValidationService).fetchItemBibSwitches(anyObject(), anyObject());
		try {
			doNothing().when(storePriceUpdateService).addItemPrice(anyObject(), anyObject());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testProcessWithoutBasePricingMessage() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		// vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);

//		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(storeValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		doReturn(itemDetails.get(0)).when(commonValidationService).fetchItemBibSwitches(anyObject(), anyObject());
		try {
//			doNothing().when(storePriceUpdateService).addItemPrice(anyObject(), anyObject());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testFetchStoreSpecificDetails() throws SystemException {

		List<StorePriceData> storePriceUpcList = new ArrayList<StorePriceData>();
		doReturn(storePriceUpcList).when(validateStorPriceDAO).fetchStoreSpecificDetails(anyList(), anyObject());
		classUnderTest.fetchStoreSpecificDetails(anyList(), anyObject());
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("0009");
		msg.setSuggLevel("Store Price");
		msg.setSuggPrice(5.1);
		// msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Store_Price");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		// msg.setProjectedSales("94.90");
		// msg.setProjectedMargin("84.90");
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		// msg.setPriceOverrideReason("2");

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(true);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

}
