package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule11.class)
public class CommonValidatorRule11Test {

	@Autowired
	private CommonValidatorRule11 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testValidateEndDateIsAfterStartDate() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMsg();
		LocalDate effDate = LocalDate.now().plusDays(14);
		LocalDate offDate = LocalDate.now();
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setEffectiveEndDt(String.valueOf(offDate));
		classUnderTest.validate(basePricingMsg, getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testInvalidData() throws SystemException {
		classUnderTest.validate(getInvalidBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testInvalidStartDate() throws SystemException {
		classUnderTest.validate(getInvalidStartDateBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testInvalidEndDate() throws SystemException {
		classUnderTest.validate(getInvalidEndDateBasePricingMsg(), getContext());
		assertNotNull(getContext());
	}

	@Test
	public void testInitialPrice() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getInvalidContext());
		assertNotNull(getContext());
	}

	@Test
	public void testValidateException() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContext());
		assertNotNull(getContext());

	}

	private ValidationContext getContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		// TODO needed?
		// context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private ValidationContext getInvalidContext() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getInvalidUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		LocalDate effDate = LocalDate.now().plusDays(14);
		basePricingMsg.setEffectiveStartDt(String.valueOf(effDate));
		basePricingMsg.setEffectiveEndDt(String.valueOf(effDate));
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setEffectiveStartDt(null);
		basePricingMsg.setEffectiveEndDt(null);
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidEndDateBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setEffectiveStartDt(String.valueOf(LocalDate.now()));
		basePricingMsg.setEffectiveEndDt(null);
		return basePricingMsg;
	}

	private BasePricingMsg getInvalidStartDateBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setEffectiveStartDt(null);
		basePricingMsg.setEffectiveEndDt(String.valueOf(LocalDate.now()));
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(false);
		return upcItemDetail;
	}

	private UPCItemDetail getInvalidUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		upcItemDetail.setInitialPrice(true);
		return upcItemDetail;
	}
}
