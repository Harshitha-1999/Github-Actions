package com.albertsons.me01r.baseprice.service.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaUpdateService;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;
import com.albertsons.me01r.baseprice.validator.impl.CommonValidatorImpl;

@SpringBootTest(classes = PriceAreaServiceImpl.class)
public class PriceAreaServiceImplTest {

	@Autowired
	private PriceAreaServiceImpl classUnderTest;

	@MockBean
	CommonValidatorImpl commonValidatorImpl;

	@MockBean
	@Qualifier("PriceAreaValidatorImpl")
	ValidatorImpl paValidatorImpl;

	@MockBean
	@Qualifier("InitialPriceValidatorImpl")
	ValidatorImpl initialPriceValidatorImpl;

	@MockBean
	PriceAreaUpdateService priceAreaUpdateService;

	@MockBean
	CommonValidationService commonValidationService;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private ValidatePriceAreaDAO validatePriceAreaDAO;

	@Test
	public void testProcessForInitialPriceArea() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getBasePricingMsg().setIsOptionalCut(false);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		doReturn(itemDetails.get(0)).when(commonValidationService).fetchItemBibSwitches(anyObject(), anyObject());
		doNothing().when(priceAreaUpdateService).addItemPrice(anyObject(), anyObject(), anyObject());
		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testProcessForInitialPriceAreaOptionalCut() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getBasePricingMsg().setIsOptionalCut(true);
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<>();
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(2);
		optionalCutDetail.setOptionalItemGap(1.0);
		optionalCutDetails.add(optionalCutDetail);
		vc.getBasePricingMsg().setCorpItemCd(2);
		vc.getBasePricingMsg().setOptionalCutDetails(optionalCutDetails);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		UPCItemDetail baseCutDetail = new UPCItemDetail();
		baseCutDetail.setInitialPrice(1.0);
		doReturn(itemDetails.get(0)).when(commonValidationService).fetchItemBibSwitches(anyObject(), anyObject());
		doReturn(baseCutDetail).when(validatePriceAreaDAO).fetchInitialPriceBaseCut(anyObject(), anyObject(),
				anyObject());
		doNothing().when(priceAreaUpdateService).addItemPrice(anyObject(), anyObject(), anyObject());
		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testProcessForInitialPriceAreaOptionalCutEqualAmount() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getBasePricingMsg().setIsOptionalCut(true);
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<>();
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(2);
		optionalCutDetail.setOptionalItemGap(1.0);
		optionalCutDetails.add(optionalCutDetail);
		vc.getBasePricingMsg().setCorpItemCd(2);
		vc.getBasePricingMsg().setOptionalCutDetails(optionalCutDetails);
		vc.getBasePricingMsg().setSuggPrice(2.0);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		UPCItemDetail baseCutDetail = new UPCItemDetail();
		baseCutDetail.setInitialPrice(1.0);
		doReturn(itemDetails.get(0)).when(commonValidationService).fetchItemBibSwitches(anyObject(), anyObject());
		doReturn(baseCutDetail).when(validatePriceAreaDAO).fetchInitialPriceBaseCut(anyObject(), anyObject(),
				anyObject());
		doNothing().when(priceAreaUpdateService).addItemPrice(anyObject(), anyObject(), anyObject());
		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testProcessForPendingPriceArea() throws Exception {

		List<UPCItemDetail> itemDetails = getItemDetailPendingPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);

		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		doReturn(itemDetails.get(0)).when(commonValidationService).fetchItemBibSwitches(anyObject(), anyObject());
		doNothing().when(priceAreaUpdateService).addItemPrice(anyObject(), anyObject(), anyObject());
		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("09");
		msg.setSuggLevel("Price Area");
		msg.setSuggPrice(5.1);
		msg.setScenarioId(12);
		msg.setScenarioName("Scenario_Price_Area");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		msg.setProjectedSales(94.90);
		msg.setProjectedMargin(84.90);
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		msg.setPriceOverrideReason(2);

		return msg;

	}

	private List<UPCItemDetail> getItemDetailInitialPriceList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);
		item.setInitialPrice(true);
		item.setSendBibDef("");
		item.setSendNewItmDef("");
		UPCItemDetail item1 = new UPCItemDetail();
		item1.setSendBibDef(null);
		item1.setSendNewItmDef(null);
		item1.setCorp("001");
		item1.setCorpItemCd(123456);//
		item1.setDisplayFlag("");
		// item.setInitialPrice(false);
		item1.setRupcStatus("P");
		item1.setUpcSystem(0);
		item1.setUpcCountry(1);
		item1.setPluCd(0);
		item1.setInitialPrice(true);
		itemDetailsList.add(item);
		itemDetailsList.add(item1);
		return itemDetailsList;
	}

	private List<UPCItemDetail> getItemDetailPendingPriceList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(false);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

	@Test
	public void fetchPendingItemDetailToDeleteTest() throws SystemException {
		classUnderTest.fetchPendingItemDetailToDelete(anyList());
	}

	@Test
	public void testProcessForInitialPriceAreaErrorMessage() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getErrorTypeMsgList().add("");

		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testProcessForInitialPriceAreaNull() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(null);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getErrorTypeMsgList().add("");

		classUnderTest.process(vc);
		assertNotNull(itemDetails);
	}

	@Test
	public void testProcessContextCicEmpty() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(new ArrayList<>());
		vc.getBasePricingMsg().setIsOptionalCut(false);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		classUnderTest.process(vc);
	}

	@Test
	public void testProcessContextCicNull() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(null);
		vc.getBasePricingMsg().setIsOptionalCut(false);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		classUnderTest.process(vc);
	}

	@Test
	public void testProcessContextInvalidPrice() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setPriceValid(false);
		itemDetails.get(1).setPriceValid(true);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(1));
		classUnderTest.process(vc);
	}
	
	@Test
	public void testProcessContextInvalidPrice3() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setPriceValid(false);
		itemDetails.get(1).setPriceValid(true);
		itemDetails.get(1).setPluCd(1);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(1));
		classUnderTest.process(vc);
	}
	
	@Test
	public void testProcessContextInvalidPrice1() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setPriceValid(false);
		itemDetails.get(1).setPriceValid(true);
		itemDetails.get(1).setPluCd(1);
		itemDetails.get(1).setUpcSystem(4);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(1));
		classUnderTest.process(vc);
	}
	
	@Test
	public void testfetchItemBibSwitches() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setPriceValid(false);
		itemDetails.get(1).setPriceValid(true);
		itemDetails.get(1).setPluCd(1);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenThrow(SystemException.class);
		classUnderTest.process(vc);
	}
	
	@Test
	public void testProcessContextInvalidPrice2() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setPriceValid(false);
		itemDetails.get(1).setPriceValid(true);
		itemDetails.get(1).setSendBibDef("");
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(1));
		classUnderTest.process(vc);
	}
	
	@Test
	public void testProcessContextPendingPrice() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setInitialPrice(true);
		itemDetails.get(1).setInitialPrice(false);
		itemDetails.get(0).setPluCd(1);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getBasePricingMsg().setIsOptionalCut(true);
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<>();
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(2);
		optionalCutDetail.setOptionalItemGap(1.0);
		optionalCutDetails.add(optionalCutDetail);
		vc.getBasePricingMsg().setOptionalCutDetails(optionalCutDetails);
		vc.getBasePricingMsg().setCorpItemCd(21);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(0));
		UPCItemDetail baseCutDetail = new UPCItemDetail();
		baseCutDetail.setInitialPrice(1.0);
		baseCutDetail.setInitialFactor(1);
		doReturn(baseCutDetail).when(validatePriceAreaDAO).fetchInitialPriceBaseCut(anyObject(), anyObject(),
				anyObject());
		classUnderTest.process(vc);
	}
	
	@Test
	public void testProcessContextPendingPrice1() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setInitialPrice(true);
		itemDetails.get(1).setInitialPrice(false);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getBasePricingMsg().setIsOptionalCut(true);
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<>();
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(2);
		optionalCutDetail.setOptionalItemGap(1.0);
		optionalCutDetails.add(optionalCutDetail);
		vc.getBasePricingMsg().setOptionalCutDetails(optionalCutDetails);
		vc.getBasePricingMsg().setCorpItemCd(2);
		vc.getBasePricingMsg().setSuggPrice(2.0);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		UPCItemDetail baseCutDetail = new UPCItemDetail();
		baseCutDetail.setInitialPrice(1.0);
		doReturn(baseCutDetail).when(validatePriceAreaDAO).fetchInitialPriceBaseCut(anyObject(), anyObject(),
				anyObject());
		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(0));
		classUnderTest.process(vc);
	}
	
	@Test
	public void testProcessContextPendingPrice2() throws Exception {
		List<UPCItemDetail> itemDetails = getItemDetailInitialPriceList();
		itemDetails.get(0).setInitialPrice(false);
		itemDetails.get(1).setInitialPrice(false);
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		ValidationContext vc = new ValidationContext();
		CommonContext cc = new CommonContext();
		vc.setBasePricingMsg(basePricingMsg);
		vc.setCommonContext(cc);
		vc.getCommonContext().setCicInfo(itemDetails);
		vc.getBasePricingMsg().setIsOptionalCut(true);
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<>();
		OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
		optionalCutDetail.setOptionalCic(2);
		optionalCutDetail.setOptionalItemGap(1.0);
		optionalCutDetails.add(optionalCutDetail);
		vc.getBasePricingMsg().setOptionalCutDetails(optionalCutDetails);
		vc.getBasePricingMsg().setCorpItemCd(2);
		vc.getBasePricingMsg().setSuggPrice(2.0);
		when(commonValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		when(paValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
//		when(initialPriceValidatorImpl.validate(anyObject(), anyObject())).thenReturn(vc);
		UPCItemDetail baseCutDetail = new UPCItemDetail();
		baseCutDetail.setInitialPrice(1.0);
//		doReturn(baseCutDetail).when(validatePriceAreaDAO).fetchInitialPriceBaseCut(anyObject(), anyObject(),
//				anyObject());
//		when(commonValidationService.fetchItemBibSwitches(anyObject(), anyObject())).thenReturn(itemDetails.get(0));
//		classUnderTest.process(vc);
	}
}
