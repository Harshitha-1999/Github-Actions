package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule18.class)
public class CommonValidatorRule18Test {
	@Autowired
	private CommonValidatorRule18 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		ReflectionTestUtils.setField(classUnderTest, "errorMessage", "NO-PRICE-ON-PROMO");
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	
	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		//TODO needed?
		//context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	
	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setItemOnPromotion(true);
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		return upcItemDetail;
	}

}
