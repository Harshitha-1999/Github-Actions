package com.albertsons.me01r.baseprice.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.dao.ErrorHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingHeader;
import com.albertsons.me01r.baseprice.model.BasePricingHeaderJson;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsgJson;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;

@SpringBootTest(classes = ErrorHandlingServiceImpl.class)
public class ErrorHandlingServiceImplTest {

	@Autowired
	private ErrorHandlingServiceImpl classUnderTest;

	@MockBean
	private ErrorHandlingDAO errorHandlingDAO;

	@MockBean
	private Environment env;

	@BeforeEach
	public void setUp() {
		ReflectionTestUtils.setField(classUnderTest, "appId", "testusr");
		ReflectionTestUtils.setField(classUnderTest, "crcCicExist", "CRC-RECORD-INCLDS-CIC");

	}

	@Test
	public void testinsertNonRollBackErrorMessage() throws SystemException {
		classUnderTest.insertNonRollBackErrorMessage(new ArrayList<>());
	}

	@Test
	public void testPrepareErrorMsg1() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		String statCd = "E";
		List<String> errorList = Arrays.asList(ConstantsUtil.INVALID_UT, ConstantsUtil.INVALID_CIC,
				ConstantsUtil.INVALID_CRC, ConstantsUtil.COM_CD_NOEXIST, ConstantsUtil.INVALID_PRICE_FACTOR,
				ConstantsUtil.INVALID_PA, ConstantsUtil.INVALID_FACILITY, ConstantsUtil.INVALID_PRICE,
				ConstantsUtil.CRC_HAS_CIC);
		classUnderTest.prepareErrorMsg(basePricingMsg, itemDetailList, statCd, errorList, "", "");
	}

	@Test
	public void testPrepareErrorMsg2() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = new ArrayList<>();
		String statCd = "E";
		List<String> errorList = Arrays.asList(ConstantsUtil.INVALID_UT, ConstantsUtil.INVALID_CIC,
				ConstantsUtil.INVALID_CRC, ConstantsUtil.COM_CD_NOEXIST, ConstantsUtil.INVALID_PRICE_FACTOR,
				ConstantsUtil.INVALID_PA, ConstantsUtil.INVALID_FACILITY, ConstantsUtil.INVALID_PRICE,
				ConstantsUtil.CRC_HAS_CIC);
		classUnderTest.prepareErrorMsg(basePricingMsg, itemDetailList, statCd, errorList, "", "");
	}

	@Test
	public void testPrepareErrorMsg() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		String statCd = "E";
		List<String> errorList = Arrays.asList(ConstantsUtil.INVALID_UT, ConstantsUtil.INVALID_CIC,
				ConstantsUtil.INVALID_CRC, ConstantsUtil.COM_CD_NOEXIST, ConstantsUtil.INVALID_PRICE_FACTOR,
				ConstantsUtil.INVALID_PA, ConstantsUtil.INVALID_FACILITY, ConstantsUtil.INVALID_PRICE,
				ConstantsUtil.CRC_HAS_CIC);
		List<ErrorMsg> errList = classUnderTest.prepareErrorMsg(basePricingMsg, itemDetailList, statCd, errorList);
		assertNotNull(errList);
	}

	@Test
	public void testPrepareErrorMsgWithNoItems() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = new ArrayList<UPCItemDetail>();
		String statCd = "E";
		List<String> errorList = Arrays.asList(ConstantsUtil.INVALID_UT, ConstantsUtil.INVALID_CIC,
				ConstantsUtil.INVALID_CRC, ConstantsUtil.COM_CD_NOEXIST, ConstantsUtil.INVALID_PRICE_FACTOR,
				ConstantsUtil.INVALID_PA, ConstantsUtil.INVALID_FACILITY, ConstantsUtil.INVALID_PRICE);
		classUnderTest.prepareErrorMsg(basePricingMsg, itemDetailList, statCd, errorList);
	}

	@Test
	public void testInsertNonNumericErrorMessagePa() throws Exception {
		List<String> errorMessage = Arrays.asList(ConstantsUtil.INVALID_UT, ConstantsUtil.INVALID_CIC,
				ConstantsUtil.INVALID_CRC, ConstantsUtil.COM_CD_NOEXIST, ConstantsUtil.INVALID_PRICE_FACTOR,
				ConstantsUtil.INVALID_PA, ConstantsUtil.INVALID_PRICE, ConstantsUtil.INVALID_SCENARIO_ID,
				ConstantsUtil.INVALID_DATE_OFF, ConstantsUtil.INVALID_DATE_EFF, ConstantsUtil.INVALID_PROJECTED_SALES,
				ConstantsUtil.INVALID_PROJECTED_UNITS, ConstantsUtil.INVALID_PROJECTED_MARGIN,
				ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
		BasePricingMsgJson basePricingMsgJson = getBasePricingMessageJson();
		doNothing().when(errorHandlingDAO).insertErrorMessage(anyList());
		classUnderTest.insertNonNumericErrorMessage(basePricingMsgJson, errorMessage);
	}

	@Test
	public void testInsertNonNumericErrorMessageFacility() throws Exception {
		List<String> errorMessage = Arrays.asList(ConstantsUtil.INVALID_UT, ConstantsUtil.INVALID_CIC,
				ConstantsUtil.INVALID_CRC, ConstantsUtil.COM_CD_NOEXIST, ConstantsUtil.INVALID_PRICE_FACTOR,
				ConstantsUtil.INVALID_FACILITY, ConstantsUtil.INVALID_PRICE);
		BasePricingMsgJson basePricingMsgJson = getBasePricingMessageJson();
		doNothing().when(errorHandlingDAO).insertErrorMessage(anyList());
		classUnderTest.insertNonNumericErrorMessage(basePricingMsgJson, errorMessage);
	}

	@Test
	public void testPrepareErrorMsgWithOtherError() throws Exception {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> itemDetailList = getItemDetailList();
		String statCd = "E";
		List<String> errorList = Arrays.asList("TESTERROR1", "TESTERROR2");
		classUnderTest.prepareErrorMsg(basePricingMsg, itemDetailList, statCd, errorList);
	}

	@Test
	public void testInsertNonNumericErrorMessageWithOtherError() throws Exception {
		List<String> errorMessage = Arrays.asList("TESTERROR1", "TESTERROR2");
		BasePricingMsgJson basePricingMsgJson = getBasePricingMessageJson();
		doNothing().when(errorHandlingDAO).insertErrorMessage(anyList());
		classUnderTest.insertNonNumericErrorMessage(basePricingMsgJson, errorMessage);
	}

	@Test
	public void testInsertErrorMessage() throws Exception {
		List<ErrorMsg> errorMessage = Arrays.asList(new ErrorMsg());
		doNothing().when(errorHandlingDAO).insertErrorMessage(anyList());
		classUnderTest.insertErrorMessage(errorMessage);
	}

	@Test
	public void testPrepareGroupCdExistsSmicError() throws Exception {

		List<ErrorMsg> errorMsgList = classUnderTest.prepareGroupCdExistsSmicError();
		assertNotNull(errorMsgList);
	}

	@Test
	public void testPrepareInvlaidRecordCount() throws Exception {

		List<ErrorMsg> errorMsgList = classUnderTest.prepareInvlaidRecordCount(new BasePricingHeaderJson());
		assertNotNull(errorMsgList);
	}

	@Test
	public void testPrepareInvlaidPriceLevel() throws Exception {

		List<ErrorMsg> errorMsgList = classUnderTest.prepareInvlaidPriceLevel(new BasePricingHeader(), "");
		assertNotNull(errorMsgList);
	}

	@Test
	public void testPrepareCorruptMessage() throws Exception {
		BasePricingHeaderJson basePricingHeader = new BasePricingHeaderJson();
		basePricingHeader.setRecordCount("2");
		List<ErrorMsg> errorMsgList = classUnderTest.prepareCorruptMessage(basePricingHeader);
		assertNotNull(errorMsgList);
	}

	@Test
	public void testprepareMismatchRecordCount() throws Exception {
		BasePricingMessages basePricingMessages = new BasePricingMessages();
		BasePricingHeader basePricingHeader = new BasePricingHeader();
		basePricingHeader.setRecordCount(2);
		basePricingMessages.setPriceChangeHeader(basePricingHeader);
		basePricingMessages.setPriceList(new ArrayList<>());
		List<ErrorMsg> errorMsgList = classUnderTest.prepareMismatchRecordCount(basePricingMessages);
		assertNotNull(errorMsgList);
	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("0009");
		msg.setSuggLevel("Store Price");
		msg.setSuggPrice(5.1);
		// msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Store_Price");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		msg.setLastUpdUserTs("2019-04-08 22:45:3");
		// msg.setProjectedSales("94.90");
		// msg.setProjectedMargin("84.90");
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		// msg.setPriceOverrideReason("2");

		return msg;

	}

	private BasePricingMsgJson getBasePricingMessageJson() {

		BasePricingMsgJson msg = new BasePricingMsgJson();
		msg.setCrcId("91926");
		msg.setCorpItemCd("56971180");
		msg.setUnitType("1");
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("0009");
		msg.setSuggLevel("Store Price");
		msg.setSuggPrice("5.1");
		msg.setScenarioId("12");
		msg.setScenarioName("Scenario_Store_Price");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		msg.setLastUpdUserTs("2019-04-08 22:45:3");
		msg.setProjectedSales("94.90");
		msg.setProjectedMargin("84.90");
		msg.setProjectedUnits("10");
		msg.setPriceFactor("4");
		msg.setPriceOverrideReason("2");

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("");
		// item.setInitialPrice(false);
		item.setRupcStatus("P");
		item.setUpcSystem(4);
		item.setUpcCountry(0);
		item.setPluCd(0);

		// itemDetailsList.add(item);

		item.setInitialPrice(true);

		itemDetailsList.add(item);

		return itemDetailsList;
	}

}
