package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule6.class)
public class CommonValidatorRule6Test {

	@Autowired
	private CommonValidatorRule6 classUnderTest;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testInValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateStoreSpecific() throws SystemException {
		classUnderTest.validate(getBasePricingMsgStoreSpecific(), getContextValidCic());
		assertNotNull(getContextValidCic());
	}

	@Test
	public void testInValidateStoreSpecific() throws SystemException {
		System.setProperty("storeFeildLength", "5");
		classUnderTest.validate(getBasePricingMsgStoreSpecific(), getContextValidCic());
		assertNotNull(getContextValidCic());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		// TODO needed?
		// context.getErrorType().setMsgList(new ArrayList<String>());
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setPaStoreInfo("12");
		return basePricingMsg;
	}

	private BasePricingMsg getBasePricingMsgStoreSpecific() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setPaStoreInfo("1234");
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setDisplayFlag(" ");
		return upcItemDetail;
	}
}
