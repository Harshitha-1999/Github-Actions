package com.albertsons.me01r.baseprice.validator.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@SpringBootTest(classes = CommonValidatorRule2.class)
public class CommonValidatorRule2Test {
	@Autowired
	private CommonValidatorRule2 classUnderTest;

	@Value("INVALID-ROG-RETSECT-PA")
	private String invalidRog;

	@Test
	public void testValidate() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCic());
		assertNotNull(getContextValidCic());
		assertEquals(1, getContextValidCic().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testValidateErrorMessage() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextValidCicErrorMessage());
		assertNotNull(getContextValidCicErrorMessage());
		assertEquals(1, getContextValidCicErrorMessage().getCommonContext().getCicInfo().size());
	}

	@Test
	public void testEmptyCic() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextNotValidCic());
		assertNotNull(getContextNotValidCic());
		assertEquals(null, getContextNotValidCic().getCommonContext().getCicInfo());
	}
	
	@Test
	public void testEmptyCicWithErrorMessage() throws SystemException {
		classUnderTest.validate(getBasePricingMsg(), getContextNotValidCicErrorMessage());
		assertNotNull(getContextNotValidCicErrorMessage());
		assertEquals(null, getContextNotValidCicErrorMessage().getCommonContext().getCicInfo());
	}

	private ValidationContext getContextValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextValidCicErrorMessage() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		List<UPCItemDetail> cicInfo = new ArrayList<UPCItemDetail>();
		cicInfo.add(getUPCDetail());
		commonContext.setCicInfo(cicInfo);
		context.getErrorTypeMsgList().add(invalidRog);
		context.setCommonContext(commonContext);
		return context;
	}

	private ValidationContext getContextNotValidCic() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(null);
		context.setCommonContext(commonContext);
		return context;
	}
	
	private ValidationContext getContextNotValidCicErrorMessage() {
		ValidationContext context = new ValidationContext();
		CommonContext commonContext = new CommonContext();
		commonContext.setCicInfo(null);
		context.getErrorTypeMsgList().add(invalidRog);
		context.setCommonContext(commonContext);
		return context;
	}

	private BasePricingMsg getBasePricingMsg() {
		BasePricingMsg basePricingMsg = new BasePricingMsg();
		return basePricingMsg;
	}

	private UPCItemDetail getUPCDetail() {
		UPCItemDetail upcItemDetail = new UPCItemDetail();
		upcItemDetail.setUpcCountry(0);
		return upcItemDetail;
	}

}
