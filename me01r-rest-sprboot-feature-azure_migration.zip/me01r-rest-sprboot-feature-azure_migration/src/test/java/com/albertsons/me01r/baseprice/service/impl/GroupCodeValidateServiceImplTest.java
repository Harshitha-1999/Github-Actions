package com.albertsons.me01r.baseprice.service.impl;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;

@SpringBootTest(classes = GroupCodeValidateServiceImpl.class)
public class GroupCodeValidateServiceImplTest {

	@Autowired
	private GroupCodeValidateServiceImpl classUnderTest;

	@MockBean
	private Environment env;

	@MockBean
	private ErrorHandlingService errorHandlingService;

	@MockBean
	private BasePriceUtil basePriceUtil;

	@Test
	public void testValidateGroupCode() throws SystemException {
		ReflectionTestUtils.invokeMethod(classUnderTest, "validateGroupCode", "8902", "0");
		classUnderTest.validateGroupCode();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInvalidateGroupCode() throws SystemException {
//		when(errorHandlingService.prepareGroupCdExistsSmicError()).thenThrow(SystemException.class);
		doNothing().when(errorHandlingService).insertErrorMessage(anyList());
		classUnderTest.validateGroupCode();
	}

	@Test
	public void testValidateSmic() throws SystemException {

		ReflectionTestUtils.invokeMethod(classUnderTest, "validateGroupCode", "0", "89");
		classUnderTest.validateGroupCode();
	}

}
