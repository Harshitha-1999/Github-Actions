package com.albertsons.me01r.baseprice.service.impl;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import com.albertsons.me01r.baseprice.dao.ValidateCommonDAO;
import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonProcessService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

@SpringBootTest(classes = CommonValidationServiceImpl.class)
public class CommonValidationServiceImplTest {

	@MockBean
	private ValidateCommonDAO validateCommonDAO;

	@MockBean
	private CommonProcessService commonProcessService;

	@Autowired
	CommonValidationServiceImpl classUnderTest;

	@MockBean
	private ValidatePriceAreaDAO validatePriceAreaDAO;

	@MockBean
	ValidateStorePriceDAO validateStorePriceDAO;

	@Test
	public void testValidateRogCd() throws SystemException {
		when(validateCommonDAO.validateRogCd(anyString())).thenReturn(1);
		classUnderTest.validateRogCd("SHAW");
		verify(validateCommonDAO).validateRogCd("SHAW");
	}

	@Test
	public void testCommonValidationContextWithPriceArea() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setCorpItemCd(0);
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchCicInformation", basePricingMsg);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);
	}

	@Test
	public void testCommonValidationContextWithPriceAreaCicMeat() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setCorpItemCd(56971180);
		basePricingMsg.setIsMeatItem(false);
		basePricingMsg.setOptionalCutDetails(new ArrayList<>());
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchCicInformation", basePricingMsg);
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setRing("");
		when(validatePriceAreaDAO.fetchCicInformation(basePricingMsg)).thenReturn(upcList);
		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);
	}

	@Test
	public void testCommonValidationContextWithPriceAreaNonSmic() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		List<UPCItemDetail> cicInfo = new ArrayList<>();
		UPCItemDetail uPCItemDetail = new UPCItemDetail();
		uPCItemDetail.setDivision("");
		uPCItemDetail.setSmic("");
		uPCItemDetail.setGroupCode("");
		cicInfo.add(uPCItemDetail);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkDivSmicExclusion", basePricingMsg, cicInfo);

		assertNotNull(basePricingMsg);
	}

	@Test
	public void testCommonValidationContextNonSmic() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		List<UPCItemDetail> cicInfo = new ArrayList<>();
		UPCItemDetail uPCItemDetail = new UPCItemDetail();
		uPCItemDetail.setDivision("");
		uPCItemDetail.setSmic("0");
		uPCItemDetail.setGroupCode("");
		cicInfo.add(uPCItemDetail);
		ReflectionTestUtils.invokeMethod(classUnderTest, "checkDivSmicExclusion", basePricingMsg, cicInfo);

		assertNotNull(basePricingMsg);
	}

	@Test
	public void testCommonValidationContextWithPriceAreaMeat() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		basePricingMsg.setCorpItemCd(0);
		basePricingMsg.setIsMeatItem(true);
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchCicInformation", basePricingMsg);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);
	}

	@Test
	public void testCommonValidationContextWithSSMeat() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setCorpItemCd(0);
		basePricingMsg.setIsMeatItem(true);
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchCicInformation", basePricingMsg);
		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);
	}

	@Test
	public void testCommonValidationContextWithSS() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		basePricingMsg.setCorpItemCd(0);
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchCicInformation", basePricingMsg);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);
	}

	@Test
	public void testGetCommonValidationContextWithPriceArea() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		List<UPCItemDetail> upcList = getItemDetailList();
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<OptionalCutDetail>();
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setPromotionType("C");
		when(validatePriceAreaDAO.fetchCicInformation(anyObject())).thenReturn(upcList);
//		when(validatePriceAreaDAO.fetchOptionalCuts(anyObject())).thenReturn(optionalCutDetails);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
//		when(validatePriceAreaDAO.fetchPromoitonDetails(anyObject())).thenReturn(promoList);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);

	}

	@Test
	public void testGetCommonValidationContextInitialPrcWithSmicExclusion() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setDivision("99");
		upcList.get(0).setSmic("9901");
		upcList.get(0).setGroupCode("99");
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<OptionalCutDetail>();
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setPromotionType("C");
		when(validatePriceAreaDAO.fetchCicInformation(anyObject())).thenReturn(upcList);
//		when(validatePriceAreaDAO.fetchOptionalCuts(anyObject())).thenReturn(optionalCutDetails);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
//		when(validatePriceAreaDAO.fetchPromoitonDetails(anyObject())).thenReturn(promoList);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);

	}

	@Test
	public void testGetCommonValidationContextWithStorePrice() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setStoreSpecific(true);
		List<UPCItemDetail> upcList = getItemDetailList();
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<OptionalCutDetail>();
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		when(validatePriceAreaDAO.fetchCicInformation(anyObject())).thenReturn(upcList);
//		when(validatePriceAreaDAO.fetchOptionalCuts(anyObject())).thenReturn(optionalCutDetails);
		when(validateStorePriceDAO.validateStore(anyObject())).thenReturn(1);
		when(validateStorePriceDAO.checkUpcIsPaPriced(anyObject(), anyObject())).thenReturn(1.0);
//		when(validateStorePriceDAO.fetchPromoitonDetails(anyObject())).thenReturn(promoList);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);

	}

	@Test
	public void testGetCommonValidationContextWithStorePrcWitcSmicExclusion() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();

		basePricingMsg.setStoreSpecific(true);
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setDivision("99");
		upcList.get(0).setSmic("9901");
		upcList.get(0).setGroupCode("99");
		List<OptionalCutDetail> optionalCutDetails = new ArrayList<OptionalCutDetail>();
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		when(validatePriceAreaDAO.fetchCicInformation(anyObject())).thenReturn(upcList);
//		when(validatePriceAreaDAO.fetchOptionalCuts(anyObject())).thenReturn(optionalCutDetails);
		when(validateStorePriceDAO.validateStore(anyObject())).thenReturn(1);
		when(validateStorePriceDAO.checkUpcIsPaPriced(anyObject(), anyObject())).thenReturn(1.0);
//		when(validateStorePriceDAO.fetchPromoitonDetails(anyObject())).thenReturn(promoList);

		classUnderTest.getCommonValidationContext(basePricingMsg);
		assertNotNull(basePricingMsg);

	}

	@Test
	public void testFetchItemBibSwitches() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setPriceArea(true);
		List<UPCItemDetail> upcList = getItemDetailList();
		when(validatePriceAreaDAO.fetchBibSwitches(anyObject(), anyObject())).thenReturn(upcList.get(0));

		classUnderTest.fetchItemBibSwitches(upcList.get(0), basePricingMsg);
		assertNotNull(basePricingMsg);

	}

	@Test
	public void testFetchInitialPrice() throws SystemException {
		List<UPCItemDetail> upcList = getItemDetailList();
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject()))
				.thenThrow(new SystemException("New Exception", new Exception()));
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchInitialPrice", upcList.get(0));
	}

	@Test
	public void testFetchPriceIfPaPriced() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		when(validateStorePriceDAO.checkUpcIsPaPriced(anyObject(), anyObject()))
				.thenThrow(new SystemException("New Exception", new Exception()));
		ReflectionTestUtils.invokeMethod(classUnderTest, "fetchPriceIfPaPriced", upcList.get(0), basePricingMsg);
	}

	/*
	 * @Test public void testUpdateDateForWeekendsDay6() throws SystemException {
	 * ReflectionTestUtils.invokeMethod(classUnderTest, "updateDateForWeekends",
	 * "2019-07-13"); }
	 * 
	 * @Test public void testUpdateDateForWeekendsDay7() throws SystemException {
	 * ReflectionTestUtils.invokeMethod(classUnderTest, "updateDateForWeekends",
	 * "2019-07-14"); }
	 */

	@Test
	public void testUpdateCicInfoPriceAreaZeroPriceDiff() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(0.0);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateCicInfoPriceAreaInitialPrice() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setInitialPrice(0.00);
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(0.0);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateCicInfoPriceAreaPendingPrice() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setInitialPrice(1.00);
		upcList.get(0).setEffectivePenPriceStartDate(LocalDate.now());
		upcList.get(0).setInitialFactor(1);
		upcList.get(0).setPendingPrice(2.00);
		upcList.get(0).setPendingFactor(1);
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(0.0);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		when(validatePriceAreaDAO.fetchPenPriceEffDate(anyObject(), anyObject())).thenReturn(upcList.get(0));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateCicInfoPriceAreaEqualPrice() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setInitialPrice(1.00);
		upcList.get(0).setEffectivePenPriceStartDate(LocalDate.now());
		upcList.get(0).setInitialFactor(1);
		upcList.get(0).setPendingPrice(1.00);
		upcList.get(0).setPendingFactor(1);
		basePricingMsg.setSuggPrice(1.00);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setHasStoreSplit(false);
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(0.0);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		when(validatePriceAreaDAO.fetchPenPriceEffDate(anyObject(), anyObject())).thenReturn(upcList.get(0));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateCicInfoPriceAreaStoreSpeicific() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setInitialPrice(1.00);
		upcList.get(0).setEffectivePenPriceStartDate(LocalDate.now());
		upcList.get(0).setInitialFactor(1);
		upcList.get(0).setPendingPrice(1.00);
		upcList.get(0).setPendingFactor(1);
		basePricingMsg.setSuggPrice(1.00);
		basePricingMsg.setPriceFactor(1);
		basePricingMsg.setHasStoreSplit(true);
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(0.0);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		when(validatePriceAreaDAO.fetchPenPriceEffDate(anyObject(), anyObject())).thenReturn(upcList.get(0));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateCicInfoPriceAreaStoreSpeicificPriceUnequal() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		upcList.get(0).setInitialPrice(1.00);
		upcList.get(0).setEffectivePenPriceStartDate(LocalDate.now());
		upcList.get(0).setInitialFactor(1);
		upcList.get(0).setPendingPrice(1.00);
		upcList.get(0).setPendingFactor(1);
		basePricingMsg.setSuggPrice(1.00);
		basePricingMsg.setPriceFactor(12);
		basePricingMsg.setHasStoreSplit(true);
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(0.0);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		when(validatePriceAreaDAO.fetchPenPriceEffDate(anyObject(), anyObject())).thenReturn(upcList.get(0));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateCicInfoPriceAreaNonZeroPriceDiff() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		List<UPCItemDetail> upcList = getItemDetailList();
		when(validatePriceAreaDAO.fetchPriceDiff(anyString())).thenReturn(1.1);
		when(validatePriceAreaDAO.fetchInitialPrice(anyObject())).thenReturn(upcList.get(0));
		when(validatePriceAreaDAO.fetchPenPriceEffDate(anyObject(), anyString()))
				.thenThrow(new SystemException("New Exception", new Exception()));
		ReflectionTestUtils.invokeMethod(classUnderTest, "updateCicInfoPriceArea", basePricingMsg, upcList);

	}

	@Test
	public void testUpdateDateForPromotionsisBefore() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-16");
		// basePricingMsg.setEffectiveEndDt("");
		// basePricingMsg.setUpdatedEffectiveStartDt("");
		// basePricingMsg.setUpdatedEffectivEndtDt("");
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		/*
		 * ReflectionTestUtils.invokeMethod(classUnderTest, "updateDateForPromotions",
		 * promoList, basePricingMsg);
		 */

	}

	@Test
	public void testUpdateDateForPromotionsisEqual() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-02");
		basePricingMsg.setEffectiveEndDt("2019-05-18");
		// basePricingMsg.setUpdatedEffectiveStartDt("");
		// basePricingMsg.setUpdatedEffectivEndtDt("");
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-02"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		promoList.addAll(getPromotionList(basePricingMsg));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-12"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		/*
		 * ReflectionTestUtils.invokeMethod(classUnderTest, "updateDateForPromotions",
		 * promoList, basePricingMsg);
		 */

	}

	@Test
	public void testUpdateDateForPromotionsStoreSpecificPromoStartDateIsBefore() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-16");
		// basePricingMsg.setEffectiveEndDt("");
		// basePricingMsg.setUpdatedEffectiveStartDt("");
		// basePricingMsg.setUpdatedEffectivEndtDt("");
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-15"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		/*
		 * ReflectionTestUtils.invokeMethod(classUnderTest,
		 * "updateDateForPromotionsStoreSpecific", promoList, basePricingMsg);
		 */

	}

	@Test
	public void testUpdateDateForPromotionsStoreSpecificPromoStartDateIsAfter() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-02");
		basePricingMsg.setEffectiveEndDt("2019-05-18");
		// basePricingMsg.setUpdatedEffectiveStartDt("");
		// basePricingMsg.setUpdatedEffectivEndtDt("");
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-17"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		/*
		 * ReflectionTestUtils.invokeMethod(classUnderTest,
		 * "updateDateForPromotionsStoreSpecific", promoList, basePricingMsg);
		 */

	}

	@Test
	public void testUpdateDateForPromotionsStoreSpecificPromoStartDateIsEqual() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt("2019-05-02");
		basePricingMsg.setEffectiveEndDt("2019-05-18");
		// basePricingMsg.setUpdatedEffectiveStartDt("");
		// basePricingMsg.setUpdatedEffectivEndtDt("");
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-02"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		promoList.addAll(getPromotionList(basePricingMsg));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-12"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		/*
		 * ReflectionTestUtils.invokeMethod(classUnderTest,
		 * "updateDateForPromotionsStoreSpecific", promoList, basePricingMsg);
		 */

	}

	@Test
	public void testValidateEffectiveStartDateStoreSpecific() throws SystemException {
		BasePricingMsg basePricingMsg = getBasePricingMessage();
		basePricingMsg.setEffectiveStartDt(String.valueOf(LocalDate.now()));
		basePricingMsg.setEffectiveEndDt("2019-05-18");
		// basePricingMsg.setUpdatedEffectiveStartDt("");
		// basePricingMsg.setUpdatedEffectivEndtDt("");
		basePricingMsg.setStoreSpecific(true);
		List<UPCItemDetail> upcList = getItemDetailList();
		CommonContext commonContext = new CommonContext();
		List<Promotion> promoList = getPromotionList(basePricingMsg);
		promoList.get(0).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-02"));
		promoList.get(0).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		promoList.addAll(getPromotionList(basePricingMsg));
		promoList.get(1).setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-12"));
		promoList.get(1).setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-20"));
		/*
		 * ReflectionTestUtils.invokeMethod(classUnderTest,
		 * "validateEffectiveStartDateStoreSpecific", basePricingMsg, upcList,
		 * commonContext);
		 */

	}

	private BasePricingMsg getBasePricingMessage() {

		BasePricingMsg msg = new BasePricingMsg();
		msg.setCrcId(91926);
		msg.setCorpItemCd(56971180);
		msg.setUnitType(1);
		msg.setRogCd("SACG");
		msg.setRetailSection("302");
		msg.setPaStoreInfo("09");
		msg.setSuggLevel("Price Area");
		msg.setSuggPrice(5.1);
		msg.setScenarioId(12);
		msg.setScenarioName("Scenario_Price_Area");
		msg.setLastUpdUserId("TestUsr");
		msg.setEffectiveStartDt("2019-05-16");
		msg.setUpdatedEffectiveStartDt("2019-05-18");
		msg.setEffectiveEndDt("2019-05-17");
		msg.setScenarioFlg("SCN");
		msg.setProjectedSales(94.90);
		msg.setProjectedMargin(84.90);
		msg.setProjectedUnits(10);
		msg.setPriceFactor(4);
		msg.setPriceOverrideReason(2);

		return msg;

	}

	private List<UPCItemDetail> getItemDetailList() {

		List<UPCItemDetail> itemDetailsList = new ArrayList<UPCItemDetail>();

		UPCItemDetail item = new UPCItemDetail();
		item.setCorp("001");
		item.setDivision("25");
		item.setRogCd("SHAW");
		item.setUpcManuf(000);
		item.setUpcSales(123);
		item.setUpcCountry(0);
		item.setUpcSystem(0);
		item.setReason("A");
		item.setReasonType("A");
		item.setCorpItemCd(123456);//
		item.setDisplayFlag("Y");
		item.setInitialPrice(false);
		item.setSendBibDef("");
		item.setSendNewItmDef("");
		item.setSendPriceSw("");
		item.setSendLabelSw("");
		item.setSensitiveItem("0");
		item.setUnitType(1);
		item.setPluCd(15140);
		item.setSmic("8901");
		item.setGroupCode("89");
		item.setRing("1");
		item.setInitialPrice(1.0);
		item.setInitialFactor(1);
		item.setPendingFactor(1);
		item.setPendingPrice(2.0);
		itemDetailsList.add(item);

		return itemDetailsList;
	}

	private List<Promotion> getPromotionList(BasePricingMsg basePricingMsg) {
		List<Promotion> promotionList = new ArrayList<Promotion>();

		Promotion promotion = new Promotion();
		promotion.setStartDate(BasePriceUtil.convertStringToLocalDate("2019-05-16"));
		promotion.setEndDate(BasePriceUtil.convertStringToLocalDate("2019-05-25"));
		promotion.setPromotionType("S");
		promotion.setCic(basePricingMsg.getCorpItemCd());
		promotion.setRog(basePricingMsg.getRogCd());
		promotion.setUnitType(basePricingMsg.getUnitType());
		promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
		promotion.setPrice(1.1);
		promotion.setPriceFactor(1);
		promotion.setUpcCountry(00000);
		promotion.setUpcManuf(0);
		promotion.setUpcSales(00000);
		promotion.setUpcSystem(0);
		basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());
		promotionList.add(promotion);
		return promotionList;

	}

}
