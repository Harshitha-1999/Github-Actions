package com.albertsons.me01r.baseprice.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.KafkaTemplate;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.kafka.KafkaStorePriceProducer;
import com.albertsons.me01r.baseprice.model.BasePricingHeader;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;

@SpringBootTest(classes = KafkaStorePriceProducer.class)
public class KafkaStorePriceProducerTest {
	
	@Autowired
	private KafkaStorePriceProducer kafkaStorePriceProducer;
	
	@MockBean
	private KafkaTemplate<String, String> kakfaTemplate;
	
	@Test
	public void testSendError() {
		BasePricingMessages basePricingMsg = new BasePricingMessages();
		try {
			kafkaStorePriceProducer.sendMsg(basePricingMsg);
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testSend() throws SystemException {
		BasePricingMessages basePricingMsg = new BasePricingMessages();
		BasePricingHeader basePricingHeader = new BasePricingHeader();
		basePricingHeader.setRecordCount(1);
		basePricingHeader.setRequestId("11");
		basePricingHeader.setSuggLevel("PA");
		basePricingMsg.setPriceChangeHeader(basePricingHeader);
		kafkaStorePriceProducer.sendMsg(basePricingMsg);
	}

}
