package com.albertsons.me01r.baseprice.service.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaService;
import com.albertsons.me01r.baseprice.service.PriceAreaUpdateService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Service
public class PriceAreaServiceImpl implements PriceAreaService {
	private static final Logger LOGGER = LoggerFactory.getLogger(PriceAreaServiceImpl.class);

	@Autowired
	@Qualifier("CommonValidatorImpl")
	ValidatorImpl commonValidatorImpl;

	@Autowired
	@Qualifier("PriceAreaValidatorImpl")
	ValidatorImpl paValidatorImpl;

	@Autowired
	@Qualifier("InitialPriceValidatorImpl")
	ValidatorImpl initialPriceValidatorImpl;

	@Autowired
	PriceAreaUpdateService priceAreaUpdateService;

	@Autowired
	CommonValidationService commonValidationService;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private ValidatePriceAreaDAO validatePriceAreaDAO;

	@Override
	public void process(ValidationContext validationContext)
			throws DataIntegrityViolationException, SystemException, Exception {
		// check if base pricing message is null else check of error message
		if (null != validationContext.getBasePricingMsg()
				&& CollectionUtils.isEmpty(validationContext.getErrorTypeMsgList())) {
			// && CollectionUtils.isEmpty(validationContext.getErrorType().getMsgList())) {
			validationContext.getBasePricingMsg().setPriceArea(true);
			validationContext.getBasePricingMsg()
					.setUpdatedEffectiveStartDt(validationContext.getBasePricingMsg().getEffectiveStartDt());
			validationContext.getBasePricingMsg()
					.setUpdatedEffectivEndtDt(validationContext.getBasePricingMsg().getEffectiveEndDt());
			ValidationContext updatedContext = commonValidatorImpl.validate(validationContext.getBasePricingMsg(),
					null);

			if (null != updatedContext.getCommonContext().getCicInfo()
					&& updatedContext.getCommonContext().getCicInfo().isEmpty()) {
				updatedContext = initialPriceValidatorImpl.validate(validationContext.getBasePricingMsg(),
						updatedContext);
				updatedContext = paValidatorImpl.validate(validationContext.getBasePricingMsg(), updatedContext);
			}

			if (null != updatedContext.getCommonContext().getCicInfo()
					&& !updatedContext.getCommonContext().getCicInfo().isEmpty()) {

				if (updatedContext.getCommonContext().getCicInfo().stream().anyMatch(cic -> cic.isInitialPrice())) {
					updatedContext = initialPriceValidatorImpl.validate(validationContext.getBasePricingMsg(),
							updatedContext);
					// Added as per JIRA# PO-1319
					updatedContext.getCommonContext().getCicInfo()
							.removeIf(cic -> cic.getRupcStatus().equalsIgnoreCase("D"));
				}

				if (updatedContext.getCommonContext().getCicInfo().stream().anyMatch(cic -> !cic.isInitialPrice())) {
					updatedContext = paValidatorImpl.validate(validationContext.getBasePricingMsg(), updatedContext);
				}
				// Removed as per JIRA# PO-1319
				/*
				 * updatedContext.getCommonContext().getCicInfo() .removeIf(cic ->
				 * cic.getRupcStatus().equalsIgnoreCase("D"));
				 */
				updatedContext.getCommonContext().getCicInfo()
						.removeIf(cic -> cic.getRupcStatus().equalsIgnoreCase("S"));
				updatedContext.getCommonContext().getCicInfo().removeIf(cic -> !cic.isPriceValid());

				List<UPCItemDetail> initialPriceUpcList = updatedContext.getCommonContext().getCicInfo().stream()
						.filter(cic -> cic.isInitialPrice()).collect(Collectors.toList());

				List<UPCItemDetail> pendingPriceUpcList = updatedContext.getCommonContext().getCicInfo().stream()
						.filter(cic -> !cic.isInitialPrice()).collect(Collectors.toList());

				InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
				PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
				ipUpdateContext.setBasePricingMsg(validationContext.getBasePricingMsg());
				paUpdateContext.setBasePricingMsg(validationContext.getBasePricingMsg());

				if (validationContext.getBasePricingMsg().getIsOptionalCut()) {
					if (!initialPriceUpcList.isEmpty()) {
						UPCItemDetail baseCutDetail = validatePriceAreaDAO.fetchInitialPriceBaseCut(
								String.valueOf(validationContext.getBasePricingMsg().getBaseCutCic()),
								validationContext.getBasePricingMsg().getRogCd(),
								validationContext.getBasePricingMsg().getPaStoreInfo());
						Double amount = 0.0;
						Integer priceFactor = 1;
						double inboundAmount = validationContext.getBasePricingMsg().getSuggPrice();
						int inboundFactor = validationContext.getBasePricingMsg().getPriceFactor();
						for (OptionalCutDetail cic : validationContext.getBasePricingMsg().getOptionalCutDetails()) {
							if (cic.getOptionalCic().equals(validationContext.getBasePricingMsg().getCorpItemCd())) {
								amount = cic.getOptionalItemGap().doubleValue()
										+ baseCutDetail.getInitialPrice().doubleValue();
								priceFactor = baseCutDetail.getInitialFactor();
							}
						}
						DecimalFormat df = new DecimalFormat("0.00");
						if (Double.valueOf(df.format(amount.doubleValue())) == validationContext.getBasePricingMsg()
								.getSuggPrice().doubleValue()
								&& priceFactor.equals(validationContext.getBasePricingMsg().getPriceFactor())) {
							if (!initialPriceUpcList.isEmpty()) {
								ipUpdateContext.setCommonContext(updatedContext.getCommonContext());
								ipUpdateContext.getCommonContext().setCicInfo(initialPriceUpcList);
								ipUpdateContext.getCommonContext().setCicInfo(toggleItemBibSwitch(ipUpdateContext));
								ipUpdateContext.setItemPriceDataList(getInitialPriceDataList(ipUpdateContext));
							}
							if (!pendingPriceUpcList.isEmpty()) {
								paUpdateContext.setCommonContext(updatedContext.getCommonContext());
								paUpdateContext.getCommonContext().setCicInfo(pendingPriceUpcList);
								paUpdateContext.setPendingPriceDataList(getPendingPriceDataList(paUpdateContext));
							}
							priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext, validationContext);
						} else {
							if (!initialPriceUpcList.isEmpty()) {
								ipUpdateContext.setCommonContext(updatedContext.getCommonContext());
								ipUpdateContext.getCommonContext()
										.setCicInfo(updatedContext.getCommonContext().getCicInfo());
								ipUpdateContext.getCommonContext().setCicInfo(toggleItemBibSwitch(ipUpdateContext));
								ipUpdateContext.getBasePricingMsg().setSuggPrice(amount);
								ipUpdateContext.getBasePricingMsg().setPriceFactor(baseCutDetail.getInitialFactor());
								ipUpdateContext.setItemPriceDataList(getInitialPriceDataList(ipUpdateContext));
								paUpdateContext.setPendingPriceDataList(new ArrayList<>());
								priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext,
										validationContext);
								ipUpdateContext.setItemPriceDataList(new ArrayList<ItemPriceData>());
								ipUpdateContext.getCommonContext().setCicInfo(new ArrayList<>());
								validationContext.getBasePricingMsg().setSuggPrice(inboundAmount);
								validationContext.getBasePricingMsg().setPriceFactor(inboundFactor);
								validationContext.getBasePricingMsg().setHasOptionalInitialPriced(false);
								validationContext.getBasePricingMsg().setEffectiveEndDt(
										validationContext.getBasePricingMsg().getUpdatedEffectivEndtDt());
								validationContext.getBasePricingMsg().setEffectiveStartDt(
										validationContext.getBasePricingMsg().getUpdatedEffectiveStartDt());
								updatedContext = commonValidatorImpl.validate(validationContext.getBasePricingMsg(),
										null);
								updatedContext = paValidatorImpl.validate(validationContext.getBasePricingMsg(),
										updatedContext);
								paUpdateContext.setCommonContext(updatedContext.getCommonContext());
								paUpdateContext.getCommonContext()
										.setCicInfo(updatedContext.getCommonContext().getCicInfo());
								paUpdateContext.getBasePricingMsg().setSuggPrice(inboundAmount);
								paUpdateContext.getBasePricingMsg().setPriceFactor(inboundFactor);
								paUpdateContext.setPendingPriceDataList(getPendingPriceDataList(paUpdateContext));
								priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext,
										validationContext);
							}
							if (!pendingPriceUpcList.isEmpty()) {
								paUpdateContext.setCommonContext(updatedContext.getCommonContext());
								paUpdateContext.getCommonContext().setCicInfo(pendingPriceUpcList);
								paUpdateContext.setPendingPriceDataList(getPendingPriceDataList(paUpdateContext));
								priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext,
										validationContext);
							}
						}
					} else {
						if (!pendingPriceUpcList.isEmpty()) {
							paUpdateContext.setCommonContext(updatedContext.getCommonContext());
							paUpdateContext.getCommonContext().setCicInfo(pendingPriceUpcList);
							paUpdateContext.setPendingPriceDataList(getPendingPriceDataList(paUpdateContext));
						}
						priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext, validationContext);
					}

				} else {
					if (!initialPriceUpcList.isEmpty()) {
						ipUpdateContext.setCommonContext(updatedContext.getCommonContext());
						ipUpdateContext.getCommonContext().setCicInfo(initialPriceUpcList);
						ipUpdateContext.getCommonContext().setCicInfo(toggleItemBibSwitch(ipUpdateContext));
						ipUpdateContext.setItemPriceDataList(getInitialPriceDataList(ipUpdateContext));
					}
					if (!pendingPriceUpcList.isEmpty()) {
						paUpdateContext.setCommonContext(updatedContext.getCommonContext());
						paUpdateContext.getCommonContext().setCicInfo(pendingPriceUpcList);
						paUpdateContext.setPendingPriceDataList(getPendingPriceDataList(paUpdateContext));
					}
					priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext, validationContext);
				}

			}

		} else {
			insertNonNumericErrorMessage(validationContext);
		}
	}

	private void insertNonNumericErrorMessage(ValidationContext validationContext) throws SystemException {
		errorHandlingService.insertNonNumericErrorMessage(validationContext.getBasePricingMsgJson(),
				// validationContext.getErrorType().getMsgList());
				validationContext.getErrorTypeMsgList());
	}

	private UPCItemDetail fetchItemBibSwitches(UPCItemDetail upcItemDetail, BasePricingMsg basePriceMsg)
			throws SystemException {
		UPCItemDetail item = commonValidationService.fetchItemBibSwitches(upcItemDetail, basePriceMsg);
		return item;
	}

	private List<UPCItemDetail> toggleItemBibSwitch(InitialPricingUpdateContext ipUpdateContext)
			throws SystemException {

		List<UPCItemDetail> itemDetailList = ipUpdateContext.getCommonContext().getCicInfo().stream().map(item -> {

			UPCItemDetail retItem = new UPCItemDetail();
			try {
				retItem = fetchItemBibSwitches(item, ipUpdateContext.getBasePricingMsg());
			} catch (SystemException e) {
				LOGGER.error(e.getMessage(), e);
			}
			// This if condition can be removed, as it is handled in DAO Layer.
			if (null != retItem.getSendBibDef() && null != retItem.getSendNewItmDef()) {
				item.setSendBibDef(retItem.getSendBibDef());
				item.setSendNewItmDef(retItem.getSendNewItmDef());
			} else {
				item.setSendBibDef(ConstantsUtil.SPACE);
				item.setSendNewItmDef(ConstantsUtil.SPACE);
			}
			if (item.getUpcSystem() == 4 && item.getUpcCountry() == 0) {
				if (item.getPluCd() == 0) {
					item.setSendPriceSw(ConstantsUtil.D);
				} else {
					item.setSendPriceSw(ConstantsUtil.P);
				}
			} else {
				if (item.getPluCd() == 0) {
					item.setSendPriceSw(ConstantsUtil.U);
				} else {
					item.setSendPriceSw(ConstantsUtil.B);
				}
			}
			item.setSendLabelSw(ConstantsUtil.Y);
			return item;

		}).collect(Collectors.toList());

		return itemDetailList;
	}

	private List<ItemPriceData> getInitialPriceDataList(InitialPricingUpdateContext ipUpdateContext)
			throws SystemException {
		List<ItemPriceData> itemPriceDataList = ipUpdateContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					ItemPriceData itemPriceData = new ItemPriceData();
					itemPriceData.setCorp(itemDetail.getCorp());
					itemPriceData.setRogCd(itemDetail.getRogCd());
					itemPriceData.setDivision(itemDetail.getDivision());
					itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
					itemPriceData.setUpcSales(itemDetail.getUpcSales());
					itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
					itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
					itemPriceData.setReason(itemDetail.getReason());
					itemPriceData.setReasonType(itemDetail.getReasonType());
					itemPriceData.setEffectiveStartDt(ipUpdateContext.getBasePricingMsg().getEffectiveStartDt());
					itemPriceData.setPaStoreInfo(ipUpdateContext.getBasePricingMsg().getPaStoreInfo());
					itemPriceData.setCrcId(ipUpdateContext.getBasePricingMsg().getCrcId());
					itemPriceData.setSuggPrice(ipUpdateContext.getBasePricingMsg().getSuggPrice());
					itemPriceData.setPriceFactor(ipUpdateContext.getBasePricingMsg().getPriceFactor());
					itemPriceData.setLastUpdUserId(ipUpdateContext.getBasePricingMsg().getLastUpdUserId());
					itemPriceData.setUnitType(ipUpdateContext.getBasePricingMsg().getUnitType());
					itemPriceData.setSensitiveItem(itemDetail.getSensitiveItem());
					itemPriceData.setSendPriceSw(itemDetail.getSendPriceSw());
					itemPriceData.setSendLabelSw(itemDetail.getSendLabelSw());
					itemPriceData.setSendBibDef(itemDetail.getSendBibDef());
					itemPriceData.setSendNewItmDef(itemDetail.getSendNewItmDef());
					itemPriceData.setCic(itemDetail.getCorpItemCd());
					itemPriceData.setRupcStatus(itemDetail.getRupcStatus());
					itemPriceData.setRetStatus(itemDetail.getRetStatus());
					itemPriceData.setPluCd(itemDetail.getPluCd());
					return itemPriceData;
				}).collect(Collectors.toList());
		return itemPriceDataList;
	}

	private List<PendingPriceData> getPendingPriceDataList(PriceAreaUpdateContext paUpdateContext)
			throws SystemException {
		List<PendingPriceData> pendingPriceDataList = paUpdateContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					PendingPriceData itemPriceData = new PendingPriceData();
					itemPriceData.setCorp(itemDetail.getCorp());
					itemPriceData.setRogCd(itemDetail.getRogCd());
					itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
					itemPriceData.setUpcSales(itemDetail.getUpcSales());
					itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
					itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
					itemPriceData.setReason(itemDetail.getReason());
					itemPriceData.setReasonType(itemDetail.getReasonType());
					itemPriceData.setEffectiveStartDt(paUpdateContext.getBasePricingMsg().getEffectiveStartDt());
					itemPriceData.setPaStoreInfo(paUpdateContext.getBasePricingMsg().getPaStoreInfo());
					itemPriceData.setCrcId(paUpdateContext.getBasePricingMsg().getCrcId());
					itemPriceData.setSuggPrice(paUpdateContext.getBasePricingMsg().getSuggPrice());
					itemPriceData.setPriceFactor(paUpdateContext.getBasePricingMsg().getPriceFactor());
					itemPriceData.setLastUpdUserId(paUpdateContext.getBasePricingMsg().getLastUpdUserId());
					itemPriceData.setUnitType(paUpdateContext.getBasePricingMsg().getUnitType());
					itemPriceData.setCic(itemDetail.getCorpItemCd());
					return itemPriceData;
				}).collect(Collectors.toList());
		return pendingPriceDataList;
	}

	public List<PendingPriceData> fetchPendingItemDetailToDelete(List<PendingPriceData> pendingPriceDataList)
			throws SystemException {
		return validatePriceAreaDAO.fetchPendingItemDetailToDelete(pendingPriceDataList);

	}
}