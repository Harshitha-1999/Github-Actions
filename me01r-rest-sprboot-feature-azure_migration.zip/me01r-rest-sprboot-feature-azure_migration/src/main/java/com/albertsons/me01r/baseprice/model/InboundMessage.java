package com.albertsons.me01r.baseprice.model;

public class InboundMessage {

	private String payload;
	
	public InboundMessage(String payload) {
		super();
		this.payload = payload;
	}
	
	public void setPayload(String payload) {
		this.payload = payload;
	}

	public InboundMessage() {
		super();
	}

	public String getPayload() {
		return payload;
	}
	@Override
	public String toString() {
		return "InboundMessage [payload=" + payload + "]";
	}
	
}
