package com.albertsons.me01r.baseprice.dao;

import com.albertsons.me01r.baseprice.exception.SystemException;

public interface ValidateCommonDAO {

	public int validateRogCd(String rogCd) throws SystemException;

}
