package com.albertsons.me01r.baseprice.model;

public class AuditMsg {
	
	
	private String userId;
	private String tableName;
	private String indexValue;
	private String fieldName;
	private Integer corpItemCd;
	private String oldData;
	private String newData;
	private String reportSwitch;
	
		
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getIndexValue() {
		return indexValue;
	}

	public void setIndexValue(String indexValue) {
		this.indexValue = indexValue;
	}
	
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public Integer getCorpItemCd() {
		return corpItemCd;
	}

	public void setCorpItemCd(Integer corpItemCd) {
		this.corpItemCd = corpItemCd;
	}

	public String getOldData() {
		return oldData;
	}

	public void setOldData(String oldData) {
		this.oldData = oldData;
	}

	public String getNewData() {
		return newData;
	}

	public void setNewData(String newData) {
		this.newData = newData;
	}
	
	public String getReportSwitch() {
		return reportSwitch;
	}

	public void setReportSwitch(String reportSwitch) {
		this.reportSwitch = reportSwitch;
	}

	//TODO
	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();

		return sb.toString();
	}
}
