package com.albertsons.me01r.baseprice.validator.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.PriceAreaValidator;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Qualifier("PriceAreaValidatorImpl")
public class PriceAreaValidatorImpl implements ValidatorImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(PriceAreaValidatorImpl.class);

	@Autowired
	private List<PriceAreaValidator> paValidators;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Override
	public ValidationContext validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {

		//LOGGER.debug("PriceAreaValidators validation.");

		for (PriceAreaValidator paValidator : getValidators()) {
			paValidator.validate(basePricingMsg, context);
		}

		handleValidationResult(basePricingMsg, context);

		return context;
	}

	private void handleValidationResult(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		List<ErrorMsg> errorMsgList = new ArrayList<>();
		List<ErrorMsg> invalidPriceDiffErrorList = handleInvalidPriceDiffWarning(basePricingMsg, context);
		List<ErrorMsg> invalidSamePriceErrorList = handleSamePriceError(basePricingMsg, context);

		List<ErrorMsg> seasonalUpcErrorList = handleSeasonalUpc(basePricingMsg, context);
		List<ErrorMsg> missingUpcErrorList = handleMisisingUpc(basePricingMsg, context);

		if (!CollectionUtils.isEmpty(invalidPriceDiffErrorList)) {
			errorMsgList.addAll(invalidPriceDiffErrorList);
		}
		if (!CollectionUtils.isEmpty(invalidSamePriceErrorList)) {
			errorMsgList.addAll(invalidSamePriceErrorList);
		}

		if (!CollectionUtils.isEmpty(seasonalUpcErrorList)) {
			errorMsgList.addAll(seasonalUpcErrorList);
		}
		if (!CollectionUtils.isEmpty(missingUpcErrorList)) {
			errorMsgList.addAll(missingUpcErrorList);
		}
		List<ErrorMsg> warningList = new ArrayList<>();

		if (!context.getErrorTypeMsgList().isEmpty() && context.getCommonContext().getCicInfo().isEmpty()) {
			List<UPCItemDetail> itemDetailList = new ArrayList<>();
			List<ErrorMsg> errorList = prepareErrorMsg(basePricingMsg, itemDetailList, context.getErrorTypeMsgList(),
					context.getErrorTypeInd());

			warningList = handleDateWarning(basePricingMsg, itemDetailList, context.getWarningTypeMsgList(),
					context.getWarningTypeInd(), context);
			errorMsgList.addAll(errorList);

			insertError(errorMsgList);
			throw BasePriceUtil.getSystemException("Failed validation rule(s) ", basePricingMsg);
		}
		if (null != context.getCommonContext().getCicInfo() && !context.getCommonContext().getCicInfo().isEmpty()) {
			List<UPCItemDetail> itemDetailList = context.getCommonContext().getCicInfo();

			warningList = handleDateWarning(basePricingMsg, itemDetailList, context.getWarningTypeMsgList(),
					context.getWarningTypeInd(), context);
			if (!CollectionUtils.isEmpty(warningList)) {
				errorMsgList.addAll(warningList);
			}

			if (!context.getErrorTypeMsgList().isEmpty()) {
				List<ErrorMsg> errorList = prepareErrorMsg(basePricingMsg, itemDetailList,
						context.getErrorTypeMsgList(), context.getErrorTypeInd());
				errorMsgList.addAll(errorList);
				insertError(errorMsgList);
				throw BasePriceUtil.getSystemException("Failed validation rule(s) ", basePricingMsg);
			}
		}
		insertError(errorMsgList);
	}

	private List<ErrorMsg> handleDateWarning(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd, ValidationContext context) throws SystemException {
		if (!CollectionUtils.isEmpty(context.getWarningTypeMsgList())) {
			return prepareErrorMsg(basePriceMsg, itemDetailList, errorList, statCd);
		}
		return null;
	}

	private List<ErrorMsg> handleInvalidPriceDiffWarning(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getInvalidPriceDiffUpc().isEmpty()) {

			return prepareErrorMsg(basePricingMsg, context.getInvalidPriceDiffUpc(),
					Arrays.asList(ConstantsUtil.PRICE_CHG_EXCEEDS), context.getInvalidPriceDiffUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleSamePriceError(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getSamePriceUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getSamePriceUpc(),
					Arrays.asList(ConstantsUtil.CURRENT_PRICE_SAME_AS_SGGESTED), context.getSamePriceUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleSeasonalUpc(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getSeasonalPriceDiffUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getSeasonalPriceDiffUpc(),
					Arrays.asList(ConstantsUtil.SEASONAL_ITEM), context.getSeasonalPriceDiffUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleMisisingUpc(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getMissingUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getMissingUpc(),
					Arrays.asList(ConstantsUtil.MISSING_UPC_INFO), context.getMissingUpcInd());
		}
		return null;
	}

	private void insertError(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingService.insertErrorMessage(errorMessage);
	}

	private List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd) throws SystemException {
		return errorHandlingService.prepareErrorMsg(basePriceMsg, itemDetailList, statCd, errorList);
	}

	private List<PriceAreaValidator> getValidators() {

		if (paValidators == null) {
			LOGGER.error("No PriceAreaValidator Available!");
			paValidators = new ArrayList<>();
		}
		return paValidators;
	}
}
