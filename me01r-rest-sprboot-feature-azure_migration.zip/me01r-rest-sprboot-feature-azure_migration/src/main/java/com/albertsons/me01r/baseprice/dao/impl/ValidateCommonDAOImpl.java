package com.albertsons.me01r.baseprice.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.dao.ValidateCommonDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.TableUtil;

@Repository
public class ValidateCommonDAOImpl implements ValidateCommonDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidateCommonDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.validation.rog.exist}")
	private String sqlValidateRogExist;

	@Value(value = "${sql.fetch.retail.section}")
	private String sqlfetchRetailSection;

	@Override
	public int validateRogCd(String rogCd) throws SystemException {
		//LOGGER.debug("validateRogCd sql: {}", sqlValidateRogExist);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("rogCd", rogCd);

		Integer result = null;
		try {
			result = namedJdbc.queryForObject(sqlValidateRogExist, paramSource, Integer.class);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append("SQL: ");
			sb.append(sqlValidateRogExist);
			sb.append(" SQLparam: ");
			sb.append(paramSource.getValues().toString());
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMROG + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		//LOGGER.debug("validateRogCd result: {}", result);

		return (result != null) ? result.intValue() : 0;
	}

}
