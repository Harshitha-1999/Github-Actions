package com.albertsons.me01r.baseprice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.dao.AuditHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.service.AuditHandlingService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.TableUtil;

@Service
public class AuditHandlingServiceImpl implements AuditHandlingService {

	@Autowired
	AuditHandlingDAO auditHandlingDAO;

	@Override
	public List<AuditMsg> prepareAuditMsgInitialPrice(InitialPricingUpdateContext initialPricingContext, String flow,
			String operation) throws SystemException {
		List<AuditMsg> auditMsgList = new ArrayList<>();
		switch (flow) {
		case TableUtil.SSITMROG:
			itmRogSetUp(initialPricingContext, auditMsgList);
			break;
		case TableUtil.SSITMURX:
			itmUrxSetup(initialPricingContext, auditMsgList);
			break;
		case TableUtil.SSITMPRC:
			itmPrcSetUp(initialPricingContext, auditMsgList);
			break;
		case TableUtil.SSITMPOS:
			itmPosSetUp(initialPricingContext, auditMsgList);
			break;
		default:
			break;
		}
		return auditMsgList;
	}

	private void itmPosSetUp(InitialPricingUpdateContext initialPricingContext, List<AuditMsg> auditMsgList) {
		auditMsgList.addAll(initialPricingContext.getItemPriceDataList().stream().map(upcItemDetail -> {
			AuditMsg auditMsg = new AuditMsg();
			StringBuilder sb = new StringBuilder();
			auditMsg.setCorpItemCd(ConstantsUtil.ZERO);
			auditMsg.setUserId(initialPricingContext.getBasePricingMsg().getLastUpdUserId());
			auditMsg.setTableName(TableUtil.SSITMPOS);
			auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_CHG);
			auditMsg.setFieldName(TableUtil.SSITMPOS_FIELD_NAME);
			auditMsg.setOldData(ConstantsUtil.SPACE);
			auditMsg.setNewData("Y");
			auditMsg.setIndexValue(sb.append(upcItemDetail.getRogCd()).append(ConstantsUtil.SPACE)
					.append(getUPC(upcItemDetail, ConstantsUtil.NONE)).toString());
			return auditMsg;
		}).collect(Collectors.toList()));

	}

	private void itmPrcSetUp(InitialPricingUpdateContext initialPricingContext, List<AuditMsg> auditMsgList) {
		auditMsgList.addAll(initialPricingContext.getItemPriceDataList().stream().map(upcItemDetail -> {
			AuditMsg auditMsg = new AuditMsg();
			StringBuilder sb = new StringBuilder();
			auditMsg.setCorpItemCd(ConstantsUtil.ZERO);
			auditMsg.setUserId(initialPricingContext.getBasePricingMsg().getLastUpdUserId());
			auditMsg.setTableName(TableUtil.SSITMPRC);
			auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_NEW);
			auditMsg.setFieldName(TableUtil.SSITMPRC_FIELD_NAME);
			auditMsg.setOldData(ConstantsUtil.SPACE);
			auditMsg.setNewData(ConstantsUtil.SPACE);
			auditMsg.setIndexValue(sb.append(upcItemDetail.getRogCd()).append(ConstantsUtil.SPACE)
					.append(getUPC(upcItemDetail, ConstantsUtil.NONE)).append(ConstantsUtil.SPACE)
					.append(upcItemDetail.getPaStoreInfo()).toString());

			return auditMsg;
		}).collect(Collectors.toList()));

	}

	public void insertAuditMsg(List<AuditMsg> auditList) throws SystemException {
		auditHandlingDAO.insertAuditMsg(auditList);
	}

	private void itmRogSetUp(InitialPricingUpdateContext initialPricingContext, List<AuditMsg> auditMsgList) {
		Optional<String> retStatusValue = initialPricingContext.getCommonContext().getCicInfo().stream()
				.map(cic -> cic.getRetStatus()).findAny();
		String retStatus = "";
		if (retStatusValue.isPresent()) {
			retStatus = retStatusValue.get();
		}

		Optional<String> updatedRetStatusValue = initialPricingContext.getCommonContext().getCicInfo().stream()
				.map(cic -> cic.getUpdatedRogStatus()).findAny();
		String updatedRetStatus = "";
		if (updatedRetStatusValue.isPresent()) {
			updatedRetStatus = updatedRetStatusValue.get();
		}

		AuditMsg auditMsg = new AuditMsg();
		auditMsg.setCorpItemCd(initialPricingContext.getBasePricingMsg().getCorpItemCd());
		auditMsg.setUserId(initialPricingContext.getBasePricingMsg().getLastUpdUserId());
		auditMsg.setTableName(TableUtil.SSITMROG);
		auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_CHG);
		auditMsg.setFieldName(TableUtil.SSITMROG_FIELD_NAME);
		auditMsg.setOldData(retStatus);// retStatus
		auditMsg.setNewData(updatedRetStatus);
		auditMsg.setIndexValue(initialPricingContext.getBasePricingMsg().getRogCd());
		auditMsgList.add(auditMsg);
	}

	private void itmUrxSetup(InitialPricingUpdateContext initialPricingContext, List<AuditMsg> auditMsgList) {
		auditMsgList.addAll(initialPricingContext.getItemPriceDataList().stream().map(upcItemDetail -> {
			AuditMsg auditMsg = new AuditMsg();
			StringBuilder sb = new StringBuilder();
			auditMsg.setCorpItemCd(initialPricingContext.getBasePricingMsg().getCorpItemCd());
			auditMsg.setUserId(initialPricingContext.getBasePricingMsg().getLastUpdUserId());
			auditMsg.setTableName(TableUtil.SSITMURX);
			auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_CHG);
			auditMsg.setFieldName(TableUtil.SSITMURX_FIELD_NAME);
			auditMsg.setOldData(upcItemDetail.getRupcStatus());
			auditMsg.setNewData(upcItemDetail.getUpdatedRupcStatus());
			auditMsg.setIndexValue(sb.append(upcItemDetail.getRogCd()).append(ConstantsUtil.SPACE)
					.append(getUPC(upcItemDetail, ConstantsUtil.NONE)).toString());
			return auditMsg;
		}).collect(Collectors.toList()));

	}

	private void strPrcSetup(BasePricingMsg basePricingMsg, List<StorePriceData> storePricingList,
			List<AuditMsg> auditMsgList, String operation) {
		auditMsgList.addAll(storePricingList.stream().map(upcItemDetail -> {
			AuditMsg auditMsg = new AuditMsg();
			StringBuilder sb = new StringBuilder();
			auditMsg.setCorpItemCd(basePricingMsg.getCorpItemCd());
			auditMsg.setUserId(basePricingMsg.getLastUpdUserId());
			auditMsg.setTableName(TableUtil.SSSPCRTL);
			auditMsg.setIndexValue(sb.append(upcItemDetail.getRogCd()).append(ConstantsUtil.COMMA)
					.append(getUPC(upcItemDetail, ConstantsUtil.COMMA)).append(ConstantsUtil.COMMA)
					.append(basePricingMsg.getPaStoreInfo()).toString());
			if (operation.equalsIgnoreCase(ConstantsUtil.P)) {
				auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_NEW);
				auditMsg.setFieldName(TableUtil.SSSPCRTL_FIELD_NAME);
				auditMsg.setOldData(ConstantsUtil.SPACE);
				auditMsg.setNewData(ConstantsUtil.SPACE);
			}
			if (operation.equalsIgnoreCase(ConstantsUtil.U)) {
				auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_CHG);
				auditMsg.setFieldName(TableUtil.SSSPCRTL_FIELD_NAME_UPDATE);
				auditMsg.setOldData(upcItemDetail.getDateEff() + "/" + upcItemDetail.getDateOff());
				auditMsg.setNewData(upcItemDetail.getStartDate() + "/" + upcItemDetail.getEndDate());
			}
			if (operation.equalsIgnoreCase(ConstantsUtil.D)) {
				auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_DEL);
				auditMsg.setFieldName(TableUtil.SSSPCRTL_FIELD_NAME);
				auditMsg.setOldData(ConstantsUtil.SPACE);
				auditMsg.setNewData(ConstantsUtil.SPACE);
			}
			return auditMsg;
		}).collect(Collectors.toList()));

	}

	private String getUPC(StorePriceData upcItemDetail, String delimiter) {
		StringBuilder sb = new StringBuilder();

		sb.append(upcItemDetail.getUpcManuf()).append(delimiter).append(upcItemDetail.getUpcSales()).append(delimiter)
				.append(upcItemDetail.getUpcCountry()).append(delimiter).append(upcItemDetail.getUpcSystem());

		return sb.toString();
	}

	private String getUPC(ItemPriceData itemPriceData, String delimiter) {
		StringBuilder sb = new StringBuilder();
		sb.append(itemPriceData.getUpcManuf()).append(delimiter).append(itemPriceData.getUpcSales()).append(delimiter)
				.append(itemPriceData.getUpcCountry()).append(delimiter).append(itemPriceData.getUpcSystem());
		return sb.toString();
	}

	private String getUPC(PendingPriceData itemPriceData, String delimiter) {
		StringBuilder sb = new StringBuilder();
		sb.append(itemPriceData.getUpcManuf()).append(delimiter).append(itemPriceData.getUpcSales()).append(delimiter)
				.append(itemPriceData.getUpcCountry()).append(delimiter).append(itemPriceData.getUpcSystem());
		return sb.toString();
	}

	@Override
	public List<AuditMsg> prepareAuditMsgPendingPrice(PriceAreaUpdateContext paUpdateContext, String flow,
			String operation) throws SystemException {
		List<AuditMsg> auditMsgList = new ArrayList<>();
		switch (flow) {
		case TableUtil.SSPENPRC:
			penPrcSetUp(paUpdateContext, auditMsgList, operation);
			break;
		default:
			break;
		}
		return auditMsgList;
	}

	private void penPrcSetUp(PriceAreaUpdateContext paUpdateContext, List<AuditMsg> auditMsgList, String operation) {
		auditMsgList.addAll(paUpdateContext.getPendingPriceDataList().stream().map(upcItemDetail -> {
			AuditMsg auditMsg = new AuditMsg();
			StringBuilder sb = new StringBuilder();

			auditMsg.setTableName(TableUtil.SSPENPRC);
			auditMsg.setFieldName(TableUtil.SSPENPRC_FIELD_NAME);
			auditMsg.setUserId(paUpdateContext.getBasePricingMsg().getLastUpdUserId());
			auditMsg.setIndexValue(sb.append(upcItemDetail.getRogCd()).append(ConstantsUtil.COMMA)
					.append(getUPC(upcItemDetail, ConstantsUtil.COMMA)).append(ConstantsUtil.COMMA)
					.append(String.valueOf(paUpdateContext.getBasePricingMsg().getPaStoreInfo())).toString());
			if (operation.equalsIgnoreCase(ConstantsUtil.N)) {
				auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_NEW);
				auditMsg.setCorpItemCd(paUpdateContext.getBasePricingMsg().getCorpItemCd());
				auditMsg.setOldData(ConstantsUtil.SPACE);
				auditMsg.setNewData(
						String.valueOf(paUpdateContext.getBasePricingMsg().getSuggPrice()).concat(ConstantsUtil.COMMA)
								.concat(String.valueOf(paUpdateContext.getBasePricingMsg().getPriceFactor())
										.concat(ConstantsUtil.COMMA).concat(upcItemDetail.getReason())));

			}
			if (operation.equalsIgnoreCase(ConstantsUtil.D)) {
				auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_DEL);
				auditMsg.setCorpItemCd(ConstantsUtil.ZERO);
				auditMsg.setOldData(ConstantsUtil.SPACE);
				auditMsg.setNewData(ConstantsUtil.SPACE);

			}
			if (operation.equalsIgnoreCase(ConstantsUtil.U)) {
				auditMsg.setReportSwitch(TableUtil.REPORT_SWITCH_CHG);
				auditMsg.setCorpItemCd(paUpdateContext.getBasePricingMsg().getCorpItemCd());
				auditMsg.setOldData(
						String.valueOf(upcItemDetail.getSuggPrice()) + "/" + upcItemDetail.getPriceFactor());
				auditMsg.setNewData(paUpdateContext.getBasePricingMsg().getSuggPrice() + "/"
						+ paUpdateContext.getBasePricingMsg().getPriceFactor());
				auditMsg.setFieldName(TableUtil.SSPENPRC_FIELD_NAME_UPDATE);
			}

			return auditMsg;
		}).collect(Collectors.toList()));

	}

	@Override
	public List<AuditMsg> prepareAuditMsgStorePrice(BasePricingMsg basePricingMsg,
			List<StorePriceData> storePricingList, String flow, String operation) throws SystemException {
		List<AuditMsg> auditMsgList = new ArrayList<>();
		switch (flow) {

		case "SSSPCRTL":
			strPrcSetup(basePricingMsg, storePricingList, auditMsgList, operation);
			break;
		default:
			break;
		}
		return auditMsgList;

	}

}
