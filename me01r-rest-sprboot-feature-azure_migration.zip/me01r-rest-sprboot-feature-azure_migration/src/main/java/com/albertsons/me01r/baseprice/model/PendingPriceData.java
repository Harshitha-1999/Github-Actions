package com.albertsons.me01r.baseprice.model;

public class PendingPriceData {

	private String corp;
	private String rogCd;
	private Integer upcManuf;
	private Integer upcSales;
	private Integer upcCountry;
	private Integer upcSystem;
	private String reason;
	private String reasonType;
	private String effectiveStartDt;
	private String paStoreInfo;
	private Integer crcId;
	private Integer cic;
	private double suggPrice;
	private Integer priceFactor;
	private String lastUpdUserId;
	private Integer unitType;

	public String getCorp() {
		return corp;
	}

	public void setCorp(String corp) {
		this.corp = corp;
	}

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public Integer getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(Integer upcManuf) {
		this.upcManuf = upcManuf;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReasonType() {
		return reasonType;
	}

	public void setReasonType(String reasonType) {
		this.reasonType = reasonType;
	}

	public String getEffectiveStartDt() {
		return effectiveStartDt;
	}

	public void setEffectiveStartDt(String effectiveStartDt) {
		this.effectiveStartDt = effectiveStartDt;
	}

	public String getPaStoreInfo() {
		return paStoreInfo;
	}

	public void setPaStoreInfo(String paStoreInfo) {
		this.paStoreInfo = paStoreInfo;
	}

	public Integer getCrcId() {
		return crcId;
	}

	public void setCrcId(Integer crcId) {
		this.crcId = crcId;
	}

	public double getSuggPrice() {
		return suggPrice;
	}

	public void setSuggPrice(double suggPrice) {
		this.suggPrice = suggPrice;
	}

	public Integer getPriceFactor() {
		return priceFactor;
	}

	public void setPriceFactor(Integer priceFactor) {
		this.priceFactor = priceFactor;
	}

	public String getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public Integer getUnitType() {
		return unitType;
	}

	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}

	public Integer getCic() {
		return cic;
	}

	public void setCic(Integer cic) {
		this.cic = cic;
	}

}
