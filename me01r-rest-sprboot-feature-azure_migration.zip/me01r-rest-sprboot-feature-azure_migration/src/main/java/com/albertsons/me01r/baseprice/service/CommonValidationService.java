package com.albertsons.me01r.baseprice.service;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

public interface CommonValidationService {

	public CommonContext getCommonValidationContext(BasePricingMsg basePricingMsg);

	public int validateRogCd(String rogCd) throws SystemException;

	public UPCItemDetail fetchItemBibSwitches(UPCItemDetail upcItemDetail, BasePricingMsg basePriceMsg)
			throws SystemException;

}
