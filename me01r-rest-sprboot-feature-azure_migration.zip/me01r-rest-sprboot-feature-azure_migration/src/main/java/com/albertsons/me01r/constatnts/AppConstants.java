package com.albertsons.me01r.constatnts;

public class AppConstants {
	private AppConstants() {
	}

	public static final String SQL = "SQL: ";
	public static final String SQL_PARAM = " SQLparam: ";
	public static final String UPC_MANUF = "upcManuf";
	public static final String UPC_SALES = "upcSales";
	public static final String UPC_COUNTRY = "upcCountry";
	public static final String UPC_SYSTEM = "upcSystem";
	public static final String FACILITY = "facility";
	public static final String ROG = "rog";
	public static final String DIVISION = "division";
	public static final String SUGGESTED_START_DATE = "suggestedStartDate";
	public static final String DATE_EFF = "DATE_EFF";
	public static final String DATE_OFF = "DATE_OFF";
	public static final String UNIT_TYPE = "unitType";
	public static final String RETAIL_SECTION = "retailSection";
	public static final String PRICE_FCTR = "PRICE_FCTR";
	public static final String PRICE = "PRICE";
	public static final String PRICE_AREA = "priceArea";

}
