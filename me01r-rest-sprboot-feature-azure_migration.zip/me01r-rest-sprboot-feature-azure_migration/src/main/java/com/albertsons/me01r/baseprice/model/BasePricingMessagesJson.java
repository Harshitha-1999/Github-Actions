package com.albertsons.me01r.baseprice.model;

import java.util.List;

public class BasePricingMessagesJson {

	private String UUID;
	private BasePricingHeaderJson priceChangeHeader;
	private List<BasePricingMsgJson> priceList;

	public BasePricingHeaderJson getPriceChangeHeader() {
		return priceChangeHeader;
	}

	public void setPriceChangeHeader(BasePricingHeaderJson priceChangeHeader) {
		this.priceChangeHeader = priceChangeHeader;
	}

	public List<BasePricingMsgJson> getPriceList() {
		return priceList;
	}

	public void setPriceList(List<BasePricingMsgJson> priceList) {
		this.priceList = priceList;
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}
}
