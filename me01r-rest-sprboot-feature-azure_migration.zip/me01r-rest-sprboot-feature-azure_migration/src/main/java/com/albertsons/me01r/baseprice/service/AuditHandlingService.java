package com.albertsons.me01r.baseprice.service;

import java.util.List;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.StorePriceData;

public interface AuditHandlingService {

	public List<AuditMsg> prepareAuditMsgInitialPrice(InitialPricingUpdateContext initialPricingContext, String flow,
			String operation) throws SystemException;

	public void insertAuditMsg(List<AuditMsg> auditList) throws SystemException;

	public List<AuditMsg> prepareAuditMsgPendingPrice(PriceAreaUpdateContext paUpdateContext, String flow,
			String operation) throws SystemException;

	public List<AuditMsg> prepareAuditMsgStorePrice(BasePricingMsg basePricingMsg,
			List<StorePriceData> storePricingList, String flow, String operation) throws SystemException;

}
