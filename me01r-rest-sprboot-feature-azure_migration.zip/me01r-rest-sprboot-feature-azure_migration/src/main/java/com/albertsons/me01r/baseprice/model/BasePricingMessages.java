package com.albertsons.me01r.baseprice.model;

import java.util.List;

public class BasePricingMessages {

	private String UUID;
	private BasePricingHeader priceChangeHeader;
	private List<BasePricingMsg> priceList;

	public BasePricingHeader getPriceChangeHeader() {
		return priceChangeHeader;
	}

	public void setPriceChangeHeader(BasePricingHeader priceChangeHeader) {
		this.priceChangeHeader = priceChangeHeader;
	}

	public List<BasePricingMsg> getPriceList() {
		return priceList;
	}

	public void setPriceList(List<BasePricingMsg> priceList) {
		this.priceList = priceList;
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("BasePricingMessages: [priceList=");
		sb.append(priceList);
		sb.append(", priceChangeHeader=");
		sb.append(priceChangeHeader);
		return sb.toString();
	}
}
