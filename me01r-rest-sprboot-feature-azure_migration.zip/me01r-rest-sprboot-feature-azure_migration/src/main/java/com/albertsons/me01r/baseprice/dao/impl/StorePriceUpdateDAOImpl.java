package com.albertsons.me01r.baseprice.dao.impl;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.dao.StorePriceUpdateDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.TableUtil;
import com.albertsons.me01r.constatnts.AppConstants;

@Repository
public class StorePriceUpdateDAOImpl implements StorePriceUpdateDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(StorePriceUpdateDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.insert.price.spcrtl}")
	private String sqlInsertItemStorePrice;

	@Value(value = "${sql.update.price.spcrtl}")
	private String sqlUpdateItemStorePrice;

	@Value(value = "${sql.delete.price.spcrtl}")
	private String sqlDeleteItemStorePrice;
	
	@Override
	public void insertItemStorePriceBatch(List<StorePriceData> storePriceUpcList) throws SystemException {

		//LOGGER.debug("InsertItemStorePrice sql: {}", sqlInsertItemStorePrice);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			long start = System.currentTimeMillis();
			paramSource = SqlParameterSourceUtils.createBatch(storePriceUpcList.toArray());
			result = namedJdbc.batchUpdate(sqlInsertItemStorePrice, paramSource);
			long end = System.currentTimeMillis();
			long execution = end - start;
			LOGGER.info("Time taken to insert the message in SSPENPRC DB = {}", execution);
		} catch (DataIntegrityViolationException dke) {
			throw new SystemException(TableUtil.SSSPCRTL + "|" + ConstantsUtil.DUPLICATE_DATA, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlInsertItemStorePrice);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(Arrays.toString(paramSource));
			LOGGER.error("Failed to execute sql: {}", sb);
			throw new SystemException(ConstantsUtil.SQL_EXCEPTION, dae);
		}

		//LOGGER.debug("InsertItemStorePrice result: {}", result.length);

	}

	public void updateItemStoreRetail(List<StorePriceData> updateStoreSpecificList) throws SystemException {
		//LOGGER.debug("sqlUpdateItemStorePrice sql: {}", sqlUpdateItemStorePrice);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(updateStoreSpecificList.toArray());
			result = namedJdbc.batchUpdate(sqlUpdateItemStorePrice, paramSource);
		} catch (DataIntegrityViolationException dke) {
			throw new SystemException(TableUtil.SSSPCRTL + "|" + ConstantsUtil.DUPLICATE_DATA, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlUpdateItemStorePrice);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(Arrays.toString(paramSource));
			LOGGER.error("Failed to execute sql: {}", sb);
			throw new SystemException(ConstantsUtil.SQL_EXCEPTION, dae);
		}

		//LOGGER.debug("sqlUpdateItemStorePrice result: {}", result.length);
	}

	public void deleteItemStoreRetail(List<StorePriceData> deleteStoreSpecificList) throws SystemException {
		//LOGGER.debug("sqlDeleteItemStorePrice sql: {}", sqlDeleteItemStorePrice);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(deleteStoreSpecificList.toArray());
			result = namedJdbc.batchUpdate(sqlDeleteItemStorePrice, paramSource);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlDeleteItemStorePrice);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(Arrays.toString(paramSource));
			LOGGER.error("Failed to execute sql: {}", sb);
			throw new SystemException(ConstantsUtil.SQL_EXCEPTION, dae);
		}

		//LOGGER.debug("sqlDeleteItemStorePrice result: {}", result.length);
	}

}