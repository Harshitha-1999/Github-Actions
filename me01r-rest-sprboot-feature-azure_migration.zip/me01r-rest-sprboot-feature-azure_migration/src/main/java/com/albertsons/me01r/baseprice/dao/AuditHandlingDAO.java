package com.albertsons.me01r.baseprice.dao;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;

public interface AuditHandlingDAO {

	public int insertAuditMsg(List<AuditMsg> auditList) throws SystemException;

}
