package com.albertsons.me01r.baseprice.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.kafka.KafkaPriceAreaProducer;
import com.albertsons.me01r.baseprice.kafka.KafkaStorePriceProducer;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMessagesJson;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * REST service controller class for Division
 * 
 */
@Controller
@RequestMapping("/baseprice")
public class BasePriceController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BasePriceController.class);

	@Autowired
	KafkaPriceAreaProducer kafkaPriceAreaProducer;

	@Autowired
	KafkaStorePriceProducer kafkaStorePriceProducer;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Value("${paprocess.url.enable}")
	private boolean isPAProcessEnabled;

	@Value("${storeprocess.url.enable}")
	private boolean isStoreprocessEnabled;

	/**
	 * @throws SystemException
	 * @throws IOException
	 * @contextPath /finalize-promotion puts a message in Kafka queue and updates
	 *              the database, setting the status to Finalized.
	 **/
	@RequestMapping(value = BasePriceUtil.WEB_BASEPRICE_STORE_ENDPOINT, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<BasePricingMessages> processStorePrice(@RequestBody String basePriceMsg)
			throws IOException, SystemException {

		if (isStoreprocessEnabled) {
			try {
				BasePricingMessages basePricingMsg = new ObjectMapper().readValue(
						new ObjectMapper().writeValueAsString(trimString(basePriceMsg)), BasePricingMessages.class);
				kafkaStorePriceProducer.sendMsg(basePricingMsg);
				return new ResponseEntity<>(basePricingMsg, HttpStatus.OK);
			} catch (SystemException | IOException | KafkaException exception) {
				InboundMessage inboundMessage = new InboundMessage();
				inboundMessage.setPayload(basePriceMsg);
				corruptMessageError(inboundMessage);
				LOGGER.error("Exception: {}", exception.getMessage());
				return new ResponseEntity<>(HttpStatus.OK);
			} catch (Exception exception) {
				LOGGER.error("Exception: {}", exception.getMessage());
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}

		LOGGER.debug("@BasePriceController.processStorePrice not implemented!");
		return new ResponseEntity<>(null, HttpStatus.NOT_IMPLEMENTED);
	}

	/**
	 * @throws SystemException
	 * @throws IOException
	 * @contextPath /finalize-promotion puts a message in Kafka queue and updates
	 *              the database, setting the status to Finalized.
	 **/
	@RequestMapping(value = BasePriceUtil.WEB_BASEPRICE_PA_ENDPOINT, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<BasePricingMessages> processPriceArea(@RequestBody String basePriceMsg)
			throws IOException, SystemException {

		if (isPAProcessEnabled) {
			try {
				BasePricingMessages basePricingMsg = new ObjectMapper().readValue(
						new ObjectMapper().writeValueAsString(trimString(basePriceMsg)), BasePricingMessages.class);
				kafkaPriceAreaProducer.sendMsg(basePricingMsg);
				return new ResponseEntity<>(basePricingMsg, HttpStatus.OK);
			} catch (SystemException | IOException | KafkaException exception) {
				InboundMessage inboundMessage = new InboundMessage();
				inboundMessage.setPayload(basePriceMsg);
				corruptMessageError(inboundMessage);
				LOGGER.error("Exception: {}", exception.getMessage());
				return new ResponseEntity<>(HttpStatus.OK);
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}

		LOGGER.debug("@BasePriceController.processPriceArea not implemented!");
		return new ResponseEntity<>(null, HttpStatus.NOT_IMPLEMENTED);

	}

	private void corruptMessageError(InboundMessage message) throws IOException, SystemException {
		BasePricingMessagesJson basePricingMsgsJson = null;
		basePricingMsgsJson = new ObjectMapper().readValue(message.getPayload(), BasePricingMessagesJson.class);
		List<ErrorMsg> baseMessageErrorList = errorHandlingService
				.prepareCorruptMessage(basePricingMsgsJson.getPriceChangeHeader());
		List<ErrorMsg> errorMsgList = baseMessageErrorList;
		errorHandlingService.insertNonRollBackErrorMessage(errorMsgList);
	}

	private Map<String, Object> trimString(String basePriceMsg) throws JsonMappingException, JsonProcessingException {
		Map<String, Object> trimmedResult = new HashMap<>();
		Map<String, Object> basePricingMsg = new ObjectMapper().readValue(basePriceMsg, HashMap.class);
		if (basePricingMsg.containsKey("priceList")) {
			Object priceListObject = basePricingMsg.get("priceList");
			List<Map<String, Object>> price = new ObjectMapper().readValue(
					new ObjectMapper().writeValueAsString(priceListObject),
					new TypeReference<List<Map<String, Object>>>() {
					});
			List<Map<String, Object>> priceTrimmed = new ArrayList<>();
			price.stream().forEach(s -> {
				Map<String, Object> trimMap = new HashMap<>();
				for (Entry<String, Object> entry : s.entrySet()) {
					String key = entry.getKey().trim();
					Object value = null;
					if (entry.getValue() instanceof String) {
						value = entry.getValue().toString().trim();
					} else {
						value = entry.getValue();
					}
					trimMap.put(key, value);
				}
				priceTrimmed.add(trimMap);
			});
			trimmedResult.put("priceList", priceTrimmed);
		}
		if (basePricingMsg.containsKey("priceChangeHeader")) {
			Map<String, Object> trimMap = new HashMap<>();
			Map<String, Object> trim = (Map<String, Object>) basePricingMsg.get("priceChangeHeader");
			for (Entry<String, Object> entry : trim.entrySet()) {
				String key = entry.getKey().trim();
				Object value = null;
				if (entry.getValue() instanceof String) {
					value = entry.getValue().toString().trim();
				} else {
					value = entry.getValue();
				}
				trimMap.put(key, value);
			}
			trimmedResult.put("priceChangeHeader", trimMap);
		}

		return trimmedResult;
	}

}
