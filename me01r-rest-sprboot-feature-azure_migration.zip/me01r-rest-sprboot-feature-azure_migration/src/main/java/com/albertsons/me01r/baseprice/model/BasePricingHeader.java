package com.albertsons.me01r.baseprice.model;

public class BasePricingHeader {
	private String requestId;
	private String suggLevel;
	private int recordCount;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSuggLevel() {
		return suggLevel;
	}

	public void setSuggLevel(String suggLevel) {
		this.suggLevel = suggLevel;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

}
