package com.albertsons.me01r.baseprice.service.impl;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonProcessService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

@Service
public class CommonProcessServiceImpl implements CommonProcessService {

	@Autowired
	ValidatePriceAreaDAO validatePriceAreaDAO;

	@Autowired
	ValidateStorePriceDAO validateStorePriceDAO;

	public void validateEffectiveStartDatePA(BasePricingMsg basePricingMsg, List<UPCItemDetail> cicInfo,
			CommonContext commonContext) throws SystemException {
		if (!basePricingMsg.isHasOptionalInitialPriced()) {
			if (basePricingMsg.isPriceArea()) {

				String inboundDate = basePricingMsg.getEffectiveStartDt();
				String updatedStartDate = updateDateForWeekends(basePricingMsg.getEffectiveStartDt());
				inboundDate = updatedStartDate;
				if (!updatedStartDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
					commonContext.getDateChange()
							.add(ConstantsUtil.START_DATE_UPDATED_FROM + basePricingMsg.getEffectiveStartDt() + " to "
									+ updatedStartDate + ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE);
				}
				basePricingMsg.setEffectiveStartDt(updatedStartDate);
				List<Promotion> promotionDetails = fetchPromoitonDetails(basePricingMsg);
				List<Promotion> couponPromotionDetails = promotionDetails.stream()
						.filter(cic -> cic.getPromotionType().equalsIgnoreCase("C")).collect(Collectors.toList());
				Collections.sort(couponPromotionDetails,
						(promotion1, promotion2) -> promotion1.getStartDate().compareTo(promotion2.getStartDate()));

				updateDateForPromotions(couponPromotionDetails, basePricingMsg);
				if (!inboundDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
					commonContext.getDateChange().add(ConstantsUtil.START_DATE_UPDATED_FROM + inboundDate + " to "
							+ basePricingMsg.getEffectiveStartDt() + ConstantsUtil.SSCOUPON_PROMOTION);
					inboundDate = basePricingMsg.getEffectiveStartDt();
				}
				List<Promotion> stsPromotionDetails = promotionDetails.stream()
						.filter(cic -> cic.getPromotionType().equalsIgnoreCase("S")).collect(Collectors.toList());
				Collections.sort(stsPromotionDetails,
						(promotion1, promotion2) -> promotion1.getStartDate().compareTo(promotion2.getStartDate()));
				if (!basePricingMsg.isItemOnPromotion()) {
					updateDateForPromotions(stsPromotionDetails, basePricingMsg);
					if (!inboundDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
						commonContext.getDateChange().add(ConstantsUtil.START_DATE_UPDATED_FROM + inboundDate + " to "
								+ basePricingMsg.getEffectiveStartDt() + ConstantsUtil.STS_PROMOTION);
						inboundDate = basePricingMsg.getEffectiveStartDt();
					}
				}

				if (updateLTSPromotion(basePricingMsg) > 0 && !basePricingMsg.isItemOnPromotion()) {
					basePricingMsg.setLtsPresent(true);
				} else {
					basePricingMsg.setLtsPresent(false);
				}
			}
		}

	}

	public void validateEffectiveStartDateStoreSpecific(BasePricingMsg basePricingMsg, List<UPCItemDetail> cicInfo,
			CommonContext commonContext) throws SystemException {
		if (basePricingMsg.isStoreSpecific()) {

			String inboundDate = basePricingMsg.getEffectiveStartDt();
			String inboundEndDate = basePricingMsg.getEffectiveEndDt();
			String updatedStartDate = "";
			if (null == basePricingMsg.getStartDateDueToPromotion()) {
				updatedStartDate = updateDateForWeekends(basePricingMsg.getEffectiveStartDt());
			} else {
				updatedStartDate = basePricingMsg.getEffectiveStartDt();
			}

			inboundDate = updatedStartDate;
			if (!updatedStartDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
				commonContext.getDateChange()
						.add(ConstantsUtil.START_DATE_UPDATED_FROM + basePricingMsg.getEffectiveStartDt() + " to "
								+ updatedStartDate + ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE);
			}
			basePricingMsg.setEffectiveStartDt(updatedStartDate);
			List<Promotion> promotionDetails = fetchPromoitonDetailsStoreSpecific(basePricingMsg);
			List<Promotion> couponPromotionDetails = promotionDetails.stream()
					.filter(cic -> cic.getPromotionType().equalsIgnoreCase("C")).collect(Collectors.toList());
			Collections.sort(couponPromotionDetails,
					(promotion1, promotion2) -> promotion1.getStartDate().compareTo(promotion2.getStartDate()));
			updateDateForPromotions(couponPromotionDetails, basePricingMsg);
			if (!inboundDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
				commonContext.getDateChange().add(ConstantsUtil.START_DATE_UPDATED_FROM + inboundDate + " to "
						+ basePricingMsg.getEffectiveStartDt() + ConstantsUtil.SSCOUPON_PROMOTION);
				inboundDate = basePricingMsg.getEffectiveStartDt();
			}
			List<Promotion> stsPromotionDetails = promotionDetails.stream()
					.filter(cic -> cic.getPromotionType().equalsIgnoreCase("S")).collect(Collectors.toList());
			Collections.sort(stsPromotionDetails,
					(promotion1, promotion2) -> promotion1.getStartDate().compareTo(promotion2.getStartDate()));
			if (!basePricingMsg.isItemOnPromotion()) {
				updateDateForPromotionsStoreSpecific(stsPromotionDetails, basePricingMsg);
				if (!inboundDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
					commonContext.getDateChange().add(ConstantsUtil.START_DATE_UPDATED_FROM + inboundDate + " to "
							+ basePricingMsg.getEffectiveStartDt() + ConstantsUtil.STS_PROMOTION);
					inboundDate = basePricingMsg.getEffectiveStartDt();
				}
				if (!inboundEndDate.equalsIgnoreCase(basePricingMsg.getEffectiveEndDt())) {
					commonContext.getDateChange().add(ConstantsUtil.END_DATE_UPDATED_FROM + inboundEndDate + " to "
							+ basePricingMsg.getEffectiveEndDt() + ConstantsUtil.STS_PROMOTION);
					inboundEndDate = basePricingMsg.getEffectiveEndDt();
				}
			}
			List<Promotion> LTSPromotionDetails = updateLTSPromotionStoreSpecific(basePricingMsg);
			if (LTSPromotionDetails.size() > 0 && !basePricingMsg.isItemOnPromotion()) {
				updateDateForPromotions(LTSPromotionDetails, basePricingMsg);
				if (!inboundDate.equalsIgnoreCase(basePricingMsg.getEffectiveStartDt())) {
					commonContext.getDateChange().add(ConstantsUtil.START_DATE_UPDATED_FROM + inboundDate + " to "
							+ basePricingMsg.getEffectiveStartDt() + ConstantsUtil.LTS_PROMOTION);
					inboundDate = basePricingMsg.getEffectiveStartDt();
				}
			}
		}
	}

	private int updateLTSPromotion(BasePricingMsg basePricingMsg) throws SystemException {
		List<Promotion> promotionDetails = validatePriceAreaDAO.fetchLTSPromoitonDetails(basePricingMsg);
		return promotionDetails.size();
	}

	private List<Promotion> updateLTSPromotionStoreSpecific(BasePricingMsg basePricingMsg) throws SystemException {
		return validateStorePriceDAO.fetchLTSPromoitonDetails(basePricingMsg);
	}

	private List<Promotion> fetchPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException {
		return validatePriceAreaDAO.fetchPromoitonDetails(basePricingMsg);
	}

	private List<Promotion> fetchPromoitonDetailsStoreSpecific(BasePricingMsg basePricingMsg) throws SystemException {
		return validateStorePriceDAO.fetchPromoitonDetails(basePricingMsg);
	}

	private void updateDateForPromotions(List<Promotion> promotionDetails, BasePricingMsg basePricingMsg)
			throws SystemException {
		Long promotionDate = "".equals(PropertiesUtils.getProperty("PR_DT_CK")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("PR_DT_CK"));
		LocalDate effectiveStartdate = LocalDate.parse(basePricingMsg.getEffectiveStartDt());
		if (!CollectionUtils.isEmpty(promotionDetails)) {
			for (int i = 0; i < promotionDetails.size(); i++) {
				if (i == 0) {
					if ((promotionDetails.get(i).getStartDate().isBefore(effectiveStartdate.plusDays(promotionDate))
							&& effectiveStartdate.isBefore(promotionDetails.get(i).getEndDate()))
							|| (promotionDetails.get(i).getStartDate().isBefore(effectiveStartdate)
									&& promotionDetails.get(i).getEndDate().isAfter(effectiveStartdate))) {
						effectiveStartdate = promotionDetails.get(i).getEndDate().plusDays(1);
					}
				} else {
					if (promotionDetails.get(i).getStartDate().isEqual(effectiveStartdate)) {
						effectiveStartdate = promotionDetails.get(i).getEndDate().plusDays(1);
					}
				}

			}
		}
		if (effectiveStartdate.isAfter(LocalDate.parse(basePricingMsg.getEffectiveEndDt()))
				&& !LocalDate.parse(basePricingMsg.getUpdatedEffectiveStartDt())
						.isAfter(LocalDate.parse(basePricingMsg.getEffectiveEndDt()))) {
			basePricingMsg.setItemOnPromotion(true);
		} else {
			basePricingMsg.setItemOnPromotion(false);
		}
		basePricingMsg.setEffectiveStartDt(effectiveStartdate.toString());
	}

	private void updateDateForPromotionsStoreSpecific(List<Promotion> promotionDetails, BasePricingMsg basePricingMsg)
			throws SystemException {
		Long promotionDate = "".equals(PropertiesUtils.getProperty("PR_DT_CK")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("PR_DT_CK"));
		LocalDate effectiveStartdate = LocalDate.parse(basePricingMsg.getEffectiveStartDt());
		LocalDate effectiveEndDate = LocalDate.parse(basePricingMsg.getEffectiveEndDt());
		if (!CollectionUtils.isEmpty(promotionDetails)) {
			for (int i = 0; i < promotionDetails.size(); i++) {
				if (i == 0) {
					if ((promotionDetails.get(i).getStartDate().isBefore(effectiveStartdate.plusDays(promotionDate))
							&& effectiveStartdate.isBefore(promotionDetails.get(i).getEndDate()))
							|| (promotionDetails.get(i).getStartDate().isBefore(effectiveStartdate)
									&& promotionDetails.get(i).getEndDate().isAfter(effectiveStartdate))) {
						effectiveStartdate = promotionDetails.get(i).getEndDate().plusDays(1);
					}
					if (promotionDetails.get(i).getStartDate().isAfter(effectiveStartdate)
							&& (promotionDetails.get(i).getEndDate().isAfter(effectiveEndDate)
									|| promotionDetails.get(i).getEndDate().isBefore(effectiveEndDate)
									|| promotionDetails.get(i).getEndDate().isEqual(effectiveEndDate))) {
						effectiveEndDate = promotionDetails.get(i).getStartDate().minusDays(1);
					}
				} else {
					if (promotionDetails.get(i).getStartDate().isEqual(effectiveStartdate)) {
						effectiveStartdate = promotionDetails.get(i).getEndDate().plusDays(1);
					}
				}

			}
		}
		if (effectiveStartdate.isAfter(LocalDate.parse(basePricingMsg.getEffectiveEndDt()))
				&& !LocalDate.parse(basePricingMsg.getUpdatedEffectiveStartDt()).isAfter(effectiveEndDate)) {
			basePricingMsg.setItemOnPromotion(true);
		} else {
			basePricingMsg.setItemOnPromotion(false);
		}
		basePricingMsg.setEffectiveStartDt(effectiveStartdate.toString());
		basePricingMsg.setEffectiveEndDt(effectiveEndDate.toString());
	}

	private String updateDateForWeekends(String effectiveStartDt) {
		LocalDate inboundEffectiveStartDate = BasePriceUtil.convertStringToLocalDate(effectiveStartDt);
		LocalDate updatedStartDate = inboundEffectiveStartDate;
		DayOfWeek dayOfWeek = inboundEffectiveStartDate.getDayOfWeek();
		int dayOfWeekValue = dayOfWeek.getValue();
		if (dayOfWeekValue == 6) {
			updatedStartDate = inboundEffectiveStartDate.plusDays(2);
		}
		if (dayOfWeekValue == 7) {
			updatedStartDate = inboundEffectiveStartDate.plusDays(1);
		}
		return updatedStartDate.toString();
	}
}