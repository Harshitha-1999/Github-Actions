package com.albertsons.me01r.baseprice.service;

import com.albertsons.me01r.baseprice.exception.SystemException;

public interface GroupCodeValidateService {
	public void validateGroupCode() throws SystemException;
}
