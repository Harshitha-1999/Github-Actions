package com.albertsons.me01r.baseprice.validator.impl;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.PriceAreaValidator;
import com.albertsons.me01r.baseprice.validator.StorePriceValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 10)
public class CommonValidatorRule10 implements PriceAreaValidator, StorePriceValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule10.class);

	@Value("INVALID-DATE-EFF")
	private String invalidDateEff;

	@Value("FUT-EFF-DATE-LMT")
	private String priceNotValid;

	/*
	 * @Value("${DT_OFFSET}") private Long effDateOffset;
	 */

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule10 {} ", context.getCommonContext().getCicInfo());
		Long effDateOffset = "".equals(PropertiesUtils.getProperty("DT_OFFSET")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("DT_OFFSET"));
		if (context.getCommonContext().getCicInfo().stream().anyMatch(cic -> !cic.isInitialPrice())
				|| basePricingMsg.isStoreSpecific()) {
			if (basePricingMsg.getEffectiveStartDt() != null) {
				if (BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt())
						.isBefore(LocalDate.now())) {
					LOGGER.error("INVALID-DATE-EFF : {}", basePricingMsg.getUpdatedEffectiveStartDt());
					// context.getErrorType().getMsgList().add(invalidDateEff);
					context.getErrorTypeMsgList().add(invalidDateEff);
				}
				if ((BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt())
						.isAfter(LocalDate.now())
						|| BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt())
								.isEqual(LocalDate.now()))
						&& !LocalDate.now().plusDays(effDateOffset).isBefore(
								BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt()))) {
					LOGGER.error("FUT-EFF-DATE-LMT : {}", basePricingMsg.getEffectiveStartDt());
					// context.getWarningType().getMsgList().add(priceNotValid);
					context.getWarningTypeMsgList().add(priceNotValid);
				}
				//LOGGER.debug("CommonValidatorRule10 OK.");
			}
		}

	}
}
