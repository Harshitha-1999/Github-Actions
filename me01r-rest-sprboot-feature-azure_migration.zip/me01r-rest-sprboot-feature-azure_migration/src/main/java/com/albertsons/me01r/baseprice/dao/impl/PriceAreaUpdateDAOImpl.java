package com.albertsons.me01r.baseprice.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.dao.PriceAreaUpdateDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.TableUtil;
import com.albertsons.me01r.constatnts.AppConstants;

@Repository
public class PriceAreaUpdateDAOImpl implements PriceAreaUpdateDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(PriceAreaUpdateDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.update.price.itmprc}")
	private String sqlInsertItemNewPrice;

	@Value(value = "${sql.update.price.penprc}")
	private String sqlInsertItemPendingPrice;

	@Value(value = "${sql.update.upc.status}")
	private String sqlUpdateUpcStatus;

	@Value(value = "${sql.update.pos.bibsw}")
	private String sqlUpdatePosBibSw;

	@Value(value = "${sql.update.rog.status}")
	private String sqlUpdateRogStatus;

	@Value(value = "${sql.update.rog.status.ret.status.p}")
	private String sqlUpdateRogStatusRetStatusP;

	@Value(value = "${sql.insert.price.history}")
	private String sqlinsertPriceHistory;

	@Value(value = "${sql.delete.penprc}")
	private String sqlDeletePenPrc;

	@Value(value = "${sql.update.price.lts}")
	private String sqlUpdatePriceLts;

	@Value(value = "${sql.fetch.dup.prc.hist.entry}")
	private String sqlFetchDuplicatePriceHistory;
	

	public void updateUpcStatus(List<ItemPriceData> itemPriceDataList) throws SystemException {

		LOGGER.debug("sqlUpdateUpcStatus sql: {}", sqlUpdateUpcStatus);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(itemPriceDataList.toArray());
			result = namedJdbc.batchUpdate(sqlUpdateUpcStatus, paramSource);
		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMURX + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlUpdateUpcStatus);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMURX + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("sqlUpdateUpcStatus result: {}", result.length);
	}

	public void updatePosBibSwitch(List<ItemPriceData> itemPriceData) throws SystemException {

		LOGGER.debug("sqlUpdatePosBibSw sql: {}", sqlUpdatePosBibSw);
		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(itemPriceData.toArray());
			result = namedJdbc.batchUpdate(sqlUpdatePosBibSw, paramSource);
		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMPOS + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlUpdatePosBibSw);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}",sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMPOS + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("sqlUpdatePosBibSw result: {}", result.length);
	}

	@Override
	public void updateRogStatus(String rogCd, Integer corpItemCd, String updatedRogStatus, String poGuideNewItem)
			throws SystemException {

		LOGGER.debug("sqlUpdateRogStatus sql: {}", sqlUpdateRogStatus);
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("rogCd", rogCd);
		paramSource.addValue("poGuideNewItem", poGuideNewItem);
		paramSource.addValue("cic", corpItemCd);
		paramSource.addValue("rogStatus", updatedRogStatus);
		Integer result = null;
		try {
			if (poGuideNewItem != null) {
				result = namedJdbc.update(sqlUpdateRogStatus, paramSource);
			} else {
				result = namedJdbc.update(sqlUpdateRogStatusRetStatusP, paramSource);
			}

		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMROG + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlUpdateRogStatus);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMROG + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}
		LOGGER.debug("sqlUpdateRogStatus result: {}", result);

	}

	@Override
	public int deletePendingItemPrice(List<PendingPriceData> pendingPriceDataList) throws SystemException {

		LOGGER.debug("sqlDeletePenPrc sql: {}", sqlDeletePenPrc);
		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(pendingPriceDataList.toArray());
			result = namedJdbc.batchUpdate(sqlDeletePenPrc, paramSource);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlDeletePenPrc);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSPENPRC + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("sqlDeletePenPrc result: {}", result.length);
		return result[0];

	}

	@Override
	public void updatePriceForLts(List<PendingPriceData> pendingPriceDataList) throws SystemException {

		LOGGER.debug("sqlUpdatePriceLts sql: {}", sqlUpdatePriceLts);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(pendingPriceDataList.toArray());
			result = namedJdbc.batchUpdate(sqlUpdatePriceLts, paramSource);
		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSPENPRC + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlUpdatePriceLts);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSPENPRC + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("sqlUpdatePriceLts result: {}", result.length);

	}

	public void insertPriceHistory(List<ItemPriceData> historyPriceData, InitialPricingUpdateContext ipUpdateContext,
			PriceAreaUpdateContext paUpdateContext) throws SystemException {
		LOGGER.debug("sqlinsertPriceHistory sql: {}", sqlinsertPriceHistory);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(historyPriceData.toArray());
			result = namedJdbc.batchUpdate(sqlinsertPriceHistory, paramSource);
		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSHISPRC + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlinsertPriceHistory);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSHISPRC + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("sqlinsertPriceHistory result: {}", result.length);

	}

	@Override
	public void insertItemNewPrice(List<ItemPriceData> initialPriceData) throws SystemException {
		LOGGER.debug("insertItemNewPrice sql: {}", sqlInsertItemNewPrice);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			paramSource = SqlParameterSourceUtils.createBatch(initialPriceData.toArray());
			result = namedJdbc.batchUpdate(sqlInsertItemNewPrice, paramSource);
		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMPRC + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlInsertItemNewPrice);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSITMPRC + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("insertItemNewPrice result: {}", result.length);

	}

	@Override
	public void insertItemPendingPrice(List<PendingPriceData> pendingPriceData) throws SystemException {
		LOGGER.debug("insertItemPendingPrice sql: {}", sqlInsertItemPendingPrice);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			long start = System.currentTimeMillis();
			paramSource = SqlParameterSourceUtils.createBatch(pendingPriceData.toArray());
			result = namedJdbc.batchUpdate(sqlInsertItemPendingPrice, paramSource);
			long end = System.currentTimeMillis();
			long execution = end - start;
			LOGGER.info("Time taken to insert the message in SSPENPRC DB{}", execution);
		} catch (DataIntegrityViolationException dke) {
			String errorCode = "";
			if (dke.getCause().getMessage().contains("=") && dke.getCause().getMessage().contains("-")) {
				errorCode = dke.getCause().getMessage().split("=")[1].split(",")[0];
			}
			//throw new DataIntegrityViolationException(
			//		TableUtil.SSPENPRC + "%" + ConstantsUtil.DUPLICATE_DATA + "%" + errorCode, dke);
			LOGGER.error("DataIntegrityViolationException occured while inserting the data in SSPENPRC : {}", pendingPriceData.get(0).getSuggPrice());
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlInsertItemPendingPrice);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource);
			LOGGER.error("Failed to execute sql: {}", sb);
			String errorCode = "";
			if (dae.getCause().getMessage().contains("=") && dae.getCause().getMessage().contains("-")) {
				errorCode = dae.getCause().getMessage().split("=")[1].split(",")[0];
			}
			throw new DataIntegrityViolationException(
					TableUtil.SSPENPRC + "%" + ConstantsUtil.SQL_EXCEPTION + "%" + errorCode, dae);
		}

		LOGGER.debug("insertItemPendingPrice result: {}", result);

	}

}