package com.albertsons.me01r.baseprice.service;

import java.util.Map;

public interface PropertyLoadService {

	public Map<String, Object> loadProperties();

}
