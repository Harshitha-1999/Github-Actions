package com.albertsons.me01r.baseprice.service.impl;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.albertsons.me01r.baseprice.dao.MessageHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.kafka.KafkaPriceAreaProducer;
import com.albertsons.me01r.baseprice.kafka.KafkaStorePriceProducer;
import com.albertsons.me01r.baseprice.model.BasePricingHeaderJson;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMessagesJson;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsgJson;
import com.albertsons.me01r.baseprice.model.CICItemDetail;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.model.PriceLevel;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MessageHandlingServiceImpl implements MessageHandlingService {

	private final Logger LOGGER = LoggerFactory.getLogger(MessageHandlingServiceImpl.class);
	@Value("INVALID-PRICE-FACTOR")
	private String invalidPriceFactorErrorMessage;

	@Value("INVALID-PRICE-LMT")
	private String invalidPriceErrorMessage;

	@Value("CORPCD-NO-EXIST-ROG")
	private String invalidCicErrorMessage;

	@Value("INVALID-UNITTYPE")
	private String invalidUTErrorMessage;

	@Value("INVALID-COMMONCD")
	private String invalidCrcErrorMessage;

	@Value("INVALID-DATE-EFF")
	private String invalidEffDateErrorMessage;

	@Value("INVALID-DATE-OFF")
	private String invalidOffDateErrorMessage;
	@Autowired
	private MessageHandlingDAO messageHandlingDAO;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private KafkaPriceAreaProducer kafkaPriceAreaProducer;

	@Autowired
	private KafkaStorePriceProducer kafkaStorePriceProducer;

	@Autowired
	private StorePriceService storePriceService;

	@Autowired
	private PriceAreaService priceAreaService;

	@Value("CRC-RECORD-INCLDS-CIC")
	private String crcCicExist;

	@Override
	public BasePricingMessages processIncomingMessage(InboundMessage msg, PriceLevel priceLvl) throws Exception {
		String msgText = msg.getPayload();
		//LOGGER.info("msg received >> {}", msgText);
		BasePricingMessages basePricingMsgs = new BasePricingMessages();

		try {
			long start = System.currentTimeMillis();
			basePricingMsgs = new ObjectMapper().readValue(msgText, BasePricingMessages.class);
			LOGGER.info("Request Id received {}", basePricingMsgs.getPriceChangeHeader().getRequestId());
			if (validatePriceLevel(basePricingMsgs, priceLvl)) {
				updateBasePriceMsg(basePricingMsgs, msg);
				//LOGGER.info("msg received: {}", basePricingMsgs);
				checkMessageSize(basePricingMsgs, msg);
				long end = System.currentTimeMillis();
				long execution = end - start;
				LOGGER.info("Request Id received and time taken to process the message {}, {}", basePricingMsgs.getPriceChangeHeader().getRequestId(), execution);
			}

		} catch (DataIntegrityViolationException se) {

			String suggestedLevel = (basePricingMsgs.getPriceChangeHeader().getSuggLevel() == null) ? ""
					: basePricingMsgs.getPriceChangeHeader().getSuggLevel();
			PriceLevel priceLevel = PriceLevel.valueOf(suggestedLevel);
			Optional<String> exceptionMessageOptional = Optional.of(se.getMessage());
			String exceptionMessage = exceptionMessageOptional.isPresent()
					? exceptionMessageOptional.get().toLowerCase()
					: "";
			if (exceptionMessage.contains(ConstantsUtil.DUPLICATE_DATA.toLowerCase())) {
				String tableName = exceptionMessage.substring(0, 8);
				String message = exceptionMessage.substring(9);
				LOGGER.error("TableName: {}, Message: {}", tableName, message);

				switch (priceLevel) {
				case PA:
					basePricingMsgs.getPriceList()
							.forEach(basePriceMessage -> basePriceMessage.setExceptionMessage(se.getMessage()));
					sendMsgToPriceAreaQueue(basePricingMsgs);
					break;
				case Store:
					basePricingMsgs.getPriceList()
							.forEach(basePriceMessage -> basePriceMessage.setExceptionMessage(se.getMessage()));
					sendMsgToStorePriceQueue(basePricingMsgs);
					break;
				default:
					break;
				}
			} else if (exceptionMessage.contains(ConstantsUtil.SQL_EXCEPTION.toLowerCase())) {

				switch (priceLevel) {
				case PA:
					basePricingMsgs.getPriceList()
							.forEach(basePriceMessage -> basePriceMessage.setExceptionMessage(se.getMessage()));
					sendMsgToPriceAreaQueue(basePricingMsgs);
					break;
				case Store:
					basePricingMsgs.getPriceList()
							.forEach(basePriceMessage -> basePriceMessage.setExceptionMessage(se.getMessage()));
					sendMsgToStorePriceQueue(basePricingMsgs);
					break;
				default:
					break;
				}
			} else {
				switch (priceLevel) {
				case PA:
					basePricingMsgs.getPriceList()
							.forEach(basePriceMessage -> basePriceMessage.setExceptionMessage(se.getMessage()));
					sendMsgToPriceAreaQueue(basePricingMsgs);
					break;
				case Store:
					basePricingMsgs.getPriceList()
							.forEach(basePriceMessage -> basePriceMessage.setExceptionMessage(se.getMessage()));
					sendMsgToStorePriceQueue(basePricingMsgs);
					break;
				default:
					break;
				}
			}

		} catch (SystemException e) {
			if (!e.getMessage().contains("Failed validation rule(s)")) {
				BasePricingMessagesJson basePricingMsgsJson = new ObjectMapper().readValue(msgText,
						BasePricingMessagesJson.class);
				List<ErrorMsg> baseMessageErrorList = errorHandlingService
						.prepareCorruptMessage(basePricingMsgsJson.getPriceChangeHeader());
				List<ErrorMsg> errorMsgList = baseMessageErrorList;
				errorHandlingService.insertNonRollBackErrorMessage(errorMsgList);
			}

		} catch (JsonMappingException e) {
			BasePricingMessagesJson basePricingMsgsJson = new ObjectMapper().readValue(msgText,
					BasePricingMessagesJson.class);
			List<ErrorMsg> errorMsgList = null;
			if (!checkRecordCount(basePricingMsgsJson.getPriceChangeHeader())) {
				errorMsgList = errorHandlingService
						.prepareInvlaidRecordCount(basePricingMsgsJson.getPriceChangeHeader());
			} else {
				errorMsgList = errorHandlingService.prepareCorruptMessage(basePricingMsgsJson.getPriceChangeHeader());
			}

			LOGGER.debug(errorMsgList.toString());
			if (!CollectionUtils.isEmpty(errorMsgList)) {
				errorHandlingService.insertNonRollBackErrorMessage(errorMsgList);
			}
		}
		return basePricingMsgs;
	}

	private boolean validatePriceLevel(BasePricingMessages basePricingMsgs, PriceLevel priceLvl)
			throws SystemException {
		if (!StringUtils.isEmpty(basePricingMsgs.getPriceChangeHeader().getSuggLevel())
				&& !basePricingMsgs.getPriceChangeHeader().getSuggLevel().equalsIgnoreCase(priceLvl.getLevel())) {
			List<ErrorMsg> errorMsgList = errorHandlingService
					.prepareInvlaidPriceLevel(basePricingMsgs.getPriceChangeHeader(), priceLvl.getLevel());
			errorHandlingService.insertErrorMessage(errorMsgList);
			return false;
		}
		return true;
	}

	private boolean checkRecordCount(BasePricingHeaderJson priceChangeHeader) throws SystemException {
		try {
			Integer.valueOf(priceChangeHeader.getRecordCount());
			return true;
		} catch (NumberFormatException exception) {
			LOGGER.error(ConstantsUtil.INVALID_RECORD_COUNT);
			return false;
		}

	}

	private void insertErrorMessage(String se, BasePricingMessages basePricingMsgs) throws SystemException {
		List<String> errorList = new ArrayList<>();
		List<ErrorMsg> errorMsgList = new ArrayList<>();
		List<UPCItemDetail> upcList = new ArrayList<>();
		if (se.contains(ConstantsUtil.DUPLICATE_DATA)) {
			String tableName = se.split("%")[0];
			String message = se.split("%")[1];
			String errorCode = se.split("%")[2].split(";")[0];

			LOGGER.error("TableName: {} ,Message: {}", tableName, message);
			errorList.add(ConstantsUtil.SQL_EXCEPTION);
			for (BasePricingMsg basePriceMsg : basePricingMsgs.getPriceList()) {
				errorMsgList.addAll(errorHandlingService.prepareErrorMsg(basePriceMsg, upcList, ConstantsUtil.E,
						errorList, tableName, errorCode));
			}

			errorHandlingService.insertNonRollBackErrorMessage(errorMsgList);
		} else if (se.contains(ConstantsUtil.SQL_EXCEPTION)) {
			String tableName = se.split("%")[0];
			String message = se.split("%")[1];
			String errorCode = se.split("%")[2].split(";")[0];
			LOGGER.error("TableName: {} , Message: {}", tableName, message);

			errorList.add(ConstantsUtil.SQL_EXCEPTION);
			for (BasePricingMsg basePriceMsg : basePricingMsgs.getPriceList()) {
				errorMsgList.addAll(errorHandlingService.prepareErrorMsg(basePriceMsg, upcList, ConstantsUtil.E,
						errorList, tableName, errorCode));
			}

			errorHandlingService.insertNonRollBackErrorMessage(errorMsgList);
		}
	}

	private void checkMessageSize(BasePricingMessages basePricingMsgs, InboundMessage msg) throws Exception {
		//LOGGER.debug("Base Pricing Messages : {}", basePricingMsgs);
		if (!CollectionUtils.isEmpty(basePricingMsgs.getPriceList())) {
			if (basePricingMsgs.getPriceChangeHeader().getRecordCount() != basePricingMsgs.getPriceList().size()) {
				LOGGER.error(ConstantsUtil.RECORD_COUNT_MISMATCH);
				List<ErrorMsg> errorMsgList = errorHandlingService.prepareMismatchRecordCount(basePricingMsgs);
				errorHandlingService.insertErrorMessage(errorMsgList);
			} else {
				if (basePricingMsgs.getPriceChangeHeader().getRecordCount() == 1) {
					if (basePricingMsgs.getPriceChangeHeader().getSuggLevel().equals(ConstantsUtil.STORE)) {
						if (!StringUtils.isEmpty(basePricingMsgs.getPriceList().get(0).getExceptionMessage())) {
							insertErrorMessage(basePricingMsgs.getPriceList().get(0).getExceptionMessage(),
									basePricingMsgs);
						} else {
							updateValidationContextStoreSpecific(basePricingMsgs, msg);
						}
					}
					if (basePricingMsgs.getPriceChangeHeader().getSuggLevel().equals(ConstantsUtil.PRICE_AREA)) {
						if (!StringUtils.isEmpty(basePricingMsgs.getPriceList().get(0).getExceptionMessage())) {
							insertErrorMessage(basePricingMsgs.getPriceList().get(0).getExceptionMessage(),
									basePricingMsgs);
						} else {
							updateValidationContextPriceArea(basePricingMsgs, msg);
						}

					}

				} else {
					LOGGER.debug(basePricingMsgs.getPriceList().toString());
					if (basePricingMsgs.getPriceChangeHeader().getSuggLevel().equals(ConstantsUtil.STORE)) {

						sendMsgToStorePriceQueue(basePricingMsgs);
					}
					if (basePricingMsgs.getPriceChangeHeader().getSuggLevel().equals(ConstantsUtil.PRICE_AREA)) {

						sendMsgToPriceAreaQueue(basePricingMsgs);
					}
				}
			}

		}

	}

	private ValidationContext updateValidationContext(BasePricingMessages basePricingMessages) throws Exception {
		ValidationContext context = new ValidationContext();
		//LOGGER.debug("Context {}", context);
		//LOGGER.debug("basePricingMessages {}", basePricingMessages);
		//LOGGER.debug("Error List {}", context.getErrorTypeMsgList());
		context = getMessageFromKafkaInput(basePricingMessages, context);
		//LOGGER.debug("Error List {}", context.getErrorTypeMsgList());
		return context;
	}

	private ValidationContext getMessageFromKafkaInput(BasePricingMessages basePricingMessages,
			ValidationContext context) throws Exception {

		context.setBasePricingMessages(basePricingMessages);
		context.setCommonContext(new CommonContext());
		BasePricingMsgJson basePricingMsgJson = new BasePricingMsgJson();
		try {
			BasePricingMsg basePricingMsg = basePricingMessages.getPriceList().get(0);
			String msg = new ObjectMapper().writeValueAsString(basePricingMessages.getPriceList().get(0));
			basePricingMsgJson = new ObjectMapper().readValue(msg, BasePricingMsgJson.class);
			validateScenarioId(String.valueOf(basePricingMsg.getScenarioId()), context);
			checkPaStore(basePricingMsg.getPaStoreInfo(), basePricingMsg.getSuggLevel(), context);
			validateOverriddenReason(String.valueOf(basePricingMsg.getPriceOverrideReason()), context);
			validateProjectSales(String.valueOf(basePricingMsg.getProjectedSales()), context);
			validateProjectedMargin(String.valueOf(basePricingMsg.getProjectedMargin()), context);
			validateProjectedUnits(String.valueOf(basePricingMsg.getProjectedUnits()), context);
			checkDateField(basePricingMsgJson, context);
			context.setBasePricingMsg(basePricingMsg);
			context.setBasePricingMsgJson(basePricingMsgJson);
			return context;
		} catch (Exception e) {
			LOGGER.error("Can not update context");
			String msg = new ObjectMapper().writeValueAsString(basePricingMessages.getPriceList().get(0));
			basePricingMsgJson = new ObjectMapper().readValue(msg, BasePricingMsgJson.class);
			checkPaStore(basePricingMsgJson.getPaStoreInfo(), basePricingMsgJson.getSuggLevel(), context);
			context = getExceptionForNumericField(basePricingMsgJson, context);
			checkDateField(basePricingMsgJson, context);

		}
		return context;
	}

	private void checkDateField(BasePricingMsgJson basePricingMsgJson, ValidationContext context) throws Exception {
		try {
			LocalDate.parse(basePricingMsgJson.getEffectiveStartDt());
		} catch (DateTimeParseException exception) {
			LOGGER.error(invalidEffDateErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_DATE_EFF);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_DATE_EFF);
		}
		try {
			LocalDate.parse(basePricingMsgJson.getEffectiveEndDt());
		} catch (DateTimeParseException exception) {
			LOGGER.error(invalidOffDateErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_DATE_OFF);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_DATE_OFF);
		}
	}

	private void checkPaStore(String paStoreInfo, String recommendedLevel, ValidationContext context) {

		try {
			Integer.valueOf(paStoreInfo);
		} catch (NumberFormatException exception) {
			if (recommendedLevel.toUpperCase().contains("PA")) {
				LOGGER.error("INVALID-PRICE_AREA");
				// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PA);
				context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PA);
			}
			if (recommendedLevel.toUpperCase().contains("STORE")) {
				LOGGER.error("INVALID-FACILITY");
				// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_FACILITY);
				context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_FACILITY);
			}
		}
	}

	private ValidationContext getExceptionForNumericField(BasePricingMsgJson basePricingMsgJson,
			ValidationContext context) throws SystemException {

		validateCRC(basePricingMsgJson.getCrcId(), context);

		validateCIC(basePricingMsgJson.getCorpItemCd(), context);
		try {
			Integer.valueOf(basePricingMsgJson.getUnitType());
		} catch (NumberFormatException exception) {
			LOGGER.error(invalidUTErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_UT);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_UT);
		}
		try {
			Double.parseDouble(basePricingMsgJson.getSuggPrice());
		} catch (NumberFormatException exception) {
			LOGGER.error(invalidPriceErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PRICE);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PRICE);
		}
		try {
			Integer.valueOf(basePricingMsgJson.getPriceFactor());
		} catch (NumberFormatException exception) {
			LOGGER.error(invalidPriceFactorErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PRICE_FACTOR);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PRICE_FACTOR);
		}

		validateScenarioId(basePricingMsgJson.getScenarioId(), context);
		validateOverriddenReason(basePricingMsgJson.getPriceOverrideReason(), context);
		validateProjectSales(basePricingMsgJson.getProjectedSales(), context);
		validateProjectedMargin(basePricingMsgJson.getProjectedMargin(), context);
		validateProjectedUnits(basePricingMsgJson.getProjectedUnits(), context);
		context.setBasePricingMsgJson(basePricingMsgJson);
		return context;
	}

	private void validateProjectedUnits(String projectedUnits, ValidationContext context) {

		try {
			Integer.valueOf(projectedUnits);

		} catch (NumberFormatException exception) {
			LOGGER.error(ConstantsUtil.INVALID_PROJECTED_UNITS);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PROJECTED_UNITS);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PROJECTED_UNITS);
		}
	}

	private void validateScenarioId(String scenarioId, ValidationContext context) {
		try {
			Integer.valueOf(scenarioId);
			if (scenarioId.contains("-")) {
				LOGGER.error(ConstantsUtil.INVALID_SCENARIO_ID);
				// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_SCENARIO_ID);
				context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_SCENARIO_ID);
			}
		} catch (NumberFormatException exception) {
			LOGGER.error(ConstantsUtil.INVALID_SCENARIO_ID);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_SCENARIO_ID);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_SCENARIO_ID);
		}
	}

	private void validateProjectedMargin(String projectedMargin, ValidationContext context) {
		try {
			Double.parseDouble(projectedMargin);

		} catch (NumberFormatException exception) {
			LOGGER.error(ConstantsUtil.INVALID_PROJECTED_MARGIN);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PROJECTED_MARGIN);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PROJECTED_MARGIN);
		}
	}

	private void validateProjectSales(String projectedSales, ValidationContext context) {
		try {
			Double.parseDouble(projectedSales);

		} catch (NumberFormatException exception) {
			LOGGER.error(ConstantsUtil.INVALID_PROJECTED_SALES);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PROJECTED_SALES);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PROJECTED_SALES);
		}
	}

	private void validateOverriddenReason(String priceOverrideReason, ValidationContext context) {

		try {
			Integer.valueOf(priceOverrideReason);
			if (priceOverrideReason.contains("-")) {
				LOGGER.error(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
				// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
				context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
			}
		} catch (NumberFormatException exception) {
			LOGGER.error(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON);
		}
	}

	private void validateCIC(String cic, ValidationContext context) {
		try {
			Integer.valueOf(cic);
		} catch (NumberFormatException exception) {
			LOGGER.error(invalidCicErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_CIC);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_CIC);
		}
	}

	private void validateCRC(String crc, ValidationContext context) {
		try {
			Integer.valueOf(crc);
		} catch (NumberFormatException exception) {
			LOGGER.error(invalidCrcErrorMessage);
			// context.getErrorType().getMsgList().add(ConstantsUtil.INVALID_CRC);
			context.getErrorTypeMsgList().add(ConstantsUtil.INVALID_CRC);
		}
	}

	private void updateValidationContextStoreSpecific(BasePricingMessages basePricingMsgs, InboundMessage msg)
			throws Exception {

		ValidationContext validationContext = updateValidationContext(basePricingMsgs);
		updateMdcValues(validationContext.getBasePricingMsg(), msg);
		//LOGGER.debug("Kafka Store Msg: {}", validationContext.getBasePricingMsg());
		// if (CollectionUtils.isEmpty(validationContext.getErrorType().getMsgList())) {
		if (CollectionUtils.isEmpty(validationContext.getErrorTypeMsgList())) {
			if (validationContext.getBasePricingMsg().getCrcId().equals(ConstantsUtil.ZERO)) {
				validationContext.getBasePricingMsg().setCrcPricing(false);
				validationContext.getBasePricingMsg().setStoreSpecific(true);
				storePriceService.process(validationContext);
			} else {
				if (validationContext.getBasePricingMsg().isCrcPricing()) {
					validationContext.getBasePricingMsg().setStoreSpecific(true);
					storePriceService.process(validationContext);
				} else {
					validationContext.getBasePricingMsg().setCrcPricing(true);
					validationContext.getBasePricingMsg().setStoreSpecific(true);
					if (!validationContext.getBasePricingMsg().getCorpItemCd().equals(ConstantsUtil.ZERO)) {
						// validationContext.getInfoType().getMsgList().add(crcCicExist);
						validationContext.getInfoTypeMsgList().add(crcCicExist);
					}
					process(validationContext);
				}
			}
		} else {
			validationContext.getBasePricingMsgJson().setStoreSpecific(true);
			storePriceService.process(validationContext);
		}

	}

	private void updateValidationContextPriceArea(BasePricingMessages basePricingMsgs, InboundMessage msg)
			throws DataIntegrityViolationException, SystemException, Exception {

		ValidationContext validationContext = updateValidationContext(basePricingMsgs);
		//LOGGER.debug("Kafka PriceArea Msg: {}", validationContext.getBasePricingMsg());
		// if (CollectionUtils.isEmpty(validationContext.getErrorType().getMsgList())) {
		if (CollectionUtils.isEmpty(validationContext.getErrorTypeMsgList())) {
			if (validationContext.getBasePricingMsg().getCrcId().equals(ConstantsUtil.ZERO)) {
				validationContext.getBasePricingMsg().setCrcPricing(false);
				validationContext.getBasePricingMsg().setPriceArea(true);
				priceAreaService.process(validationContext);
			} else {
				if (validationContext.getBasePricingMsg().isCrcPricing()) {
					validationContext.getBasePricingMsg().setPriceArea(true);
					priceAreaService.process(validationContext);
				} else {
					validationContext.getBasePricingMsg().setCrcPricing(true);
					validationContext.getBasePricingMsg().setPriceArea(true);
					if (!validationContext.getBasePricingMsg().getCorpItemCd().equals(ConstantsUtil.ZERO)) {
						// validationContext.getInfoType().getMsgList().add(crcCicExist);
						validationContext.getInfoTypeMsgList().add(crcCicExist);
					}
					process(validationContext);
				}
			}

		} else {
			validationContext.getBasePricingMsgJson().setPriceArea(true);
			priceAreaService.process(validationContext);
		}
	}

	private void updateBasePriceMsg(BasePricingMessages basePricingMsgs, InboundMessage msg) {
		basePricingMsgs.getPriceList().forEach(basePriceMsg -> {
			if (basePriceMsg.getTotalCount() == 0) {
				basePriceMsg.setRequestId(basePricingMsgs.getPriceChangeHeader().getRequestId());
				basePriceMsg.setTotalCount(basePricingMsgs.getPriceChangeHeader().getRecordCount());
				basePriceMsg.setSuggLevel(basePricingMsgs.getPriceChangeHeader().getSuggLevel());
				basePriceMsg.setUUID(getBasePriceMsgUUID(basePriceMsg, msg));
				basePriceMsg.setUserID(basePriceMsg.getLastUpdUserId());
				basePriceMsg.setUpdatedEffectivEndtDt(basePriceMsg.getEffectiveEndDt());
				basePriceMsg.setUpdatedEffectiveStartDt(basePriceMsg.getEffectiveStartDt());
			}
		});
	}

	private void updateMdcValues(BasePricingMsg basePricingMsg, InboundMessage msg)
			throws IllegalArgumentException, KafkaException {
		MDC.put("userId", basePricingMsg.getLastUpdUserId());
		//MDC.put("kafkaMsgId", msg.getMessageKey());
		//MDC.put("kafkaCorlId", getBasePriceMsgUUID(basePricingMsg, msg));
	}

	private String getBasePriceMsgUUID(BasePricingMsg basePricingMsgs, InboundMessage msg) {

		if (basePricingMsgs.getUUID() == null) {
			basePricingMsgs.setUUID(getMsgUUID(msg));
		}

		return basePricingMsgs.getUUID();
	}

	private String getMsgUUID(InboundMessage msg) {
		String uuid = null;

		if (uuid == null) {
			uuid = UUID.randomUUID().toString();
			LOGGER.info("uuid generated: {}", uuid);
		}

		return uuid;
	}

	private void process(ValidationContext validationContext) throws SystemException {
		//LOGGER.debug("Starting CRC/UT Processing..");
		// check if base pricing message is null else check of error message
		if (null != validationContext.getBasePricingMsg() && validationContext.getBasePricingMsg().isCrcPricing()) {
			List<ErrorMsg> errorMsgList = new ArrayList<>();
			// if (!CollectionUtils.isEmpty(validationContext.getInfoType().getMsgList())) {
			if (!CollectionUtils.isEmpty(validationContext.getInfoTypeMsgList())) {
				List<ErrorMsg> errorList = prepareErrorMsg(validationContext.getBasePricingMsg(),
						// new ArrayList<UPCItemDetail>(),
						// validationContext.getInfoType().getMsgTypeInd(),
						// validationContext.getInfoType().getMsgList());
						new ArrayList<UPCItemDetail>(), validationContext.getInfoTypeInd(),
						validationContext.getInfoTypeMsgList());
				if (!CollectionUtils.isEmpty(errorList)) {
					insertError(errorList);
				}
			}
			ValidationContext updatedContext = performCrcValidationAndExpansion(validationContext);

			if (!CollectionUtils.isEmpty(updatedContext.getCommonContext().getCrcInfo())) {
				List<BasePricingMsg> basePricingMsgList = createBasePricingMsg(validationContext);

				if (!CollectionUtils.isEmpty(basePricingMsgList)) {
					if (updatedContext.getBasePricingMsg().isPriceArea()) {
						validationContext.getBasePricingMessages().setPriceList(new ArrayList<>());
						validationContext.getBasePricingMessages().setPriceList(basePricingMsgList);
						sendMsgToPriceAreaQueue(validationContext.getBasePricingMessages());
					}
					if (updatedContext.getBasePricingMsg().isStoreSpecific()) {
						validationContext.getBasePricingMessages().setPriceList(new ArrayList<>());
						validationContext.getBasePricingMessages().setPriceList(basePricingMsgList);
						sendMsgToStorePriceQueue(validationContext.getBasePricingMessages());
					}
				}
				//LOGGER.debug("Finishing CRC/UT Processing..");
			} else {

				List<ErrorMsg> errorList = prepareErrorMsg(updatedContext.getBasePricingMsg(),
						// new ArrayList<UPCItemDetail>(),
						// updatedContext.getErrorType().getMsgTypeInd(),
						new ArrayList<UPCItemDetail>(), updatedContext.getErrorTypeInd(),
						Arrays.asList(ConstantsUtil.COM_CD_NOEXIST));
				errorMsgList.addAll(errorList);
				insertError(errorMsgList);
			}

		} else {
			insertNonNumericErrorMessage(validationContext);
		}

	}

	private ValidationContext performCrcValidationAndExpansion(ValidationContext validationContext)
			throws SystemException {
		if (validationContext.getBasePricingMsg().isCrcPricing()) {
			validationContext.setCommonContext(new CommonContext());
			validationContext.getCommonContext().setCrcInfo(fetchCrcInformation(validationContext.getBasePricingMsg()));
		}
		return validationContext;
	}

	private List<BasePricingMsg> createBasePricingMsg(ValidationContext vc) throws SystemException {
		if (!CollectionUtils.isEmpty(vc.getCommonContext().getCrcInfo())) {
			List<BasePricingMsg> basePricingMsgList = vc.getCommonContext().getCrcInfo().stream().map(crc -> {
				try {
					String msg = new ObjectMapper().writeValueAsString(vc.getBasePricingMsg());
					BasePricingMsg basePricingMsg = new BasePricingMsg();
					basePricingMsg = new ObjectMapper().readValue(msg, BasePricingMsg.class);
					basePricingMsg.setCorpItemCd(crc.getCorpItemCd());
					return basePricingMsg;
				} catch (IOException e) {
					LOGGER.error("Not able to Expand CICs from CRC");
				}
				return null;

			}).collect(Collectors.toList());

			return basePricingMsgList;
		}
		return null;
	}

	private List<CICItemDetail> fetchCrcInformation(BasePricingMsg basePricingMsg) throws SystemException {
		List<CICItemDetail> itemDetails = new ArrayList<CICItemDetail>();
		try {
			itemDetails = messageHandlingDAO.fetchCrcInformation(basePricingMsg);
		} catch (SystemException se) {
			LOGGER.error("Failed to fetch the CICs with crcId: {}", basePricingMsg.getCrcId());
		}
		return itemDetails;
	}

	private void insertError(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingService.insertErrorMessage(errorMessage);
	}

	private void sendMsgToStorePriceQueue(BasePricingMessages basePricingMessages) throws SystemException {
		List<BasePricingMessages> basePriceMessages = new ArrayList<>();
		for (BasePricingMsg msg : basePricingMessages.getPriceList()) {
			BasePricingMessages basePriceMessage = prepareBasePrcingMessages(msg, basePricingMessages);
			basePriceMessages.add(basePriceMessage);
		}
		for (BasePricingMessages basePriceMessage : basePriceMessages) {
			kafkaStorePriceProducer.sendMsg(basePriceMessage);
		}

	}

	private void sendMsgToPriceAreaQueue(BasePricingMessages basePricingMessages) throws SystemException {

		List<BasePricingMessages> basePriceMessages = new ArrayList<>();
		for (BasePricingMsg msg : basePricingMessages.getPriceList()) {
			BasePricingMessages basePriceMessage = prepareBasePrcingMessages(msg, basePricingMessages);
			basePriceMessages.add(basePriceMessage);
		}
		for (BasePricingMessages basePriceMessage : basePriceMessages) {
			kafkaPriceAreaProducer.sendMsg(basePriceMessage);
		}

	}

	private BasePricingMessages prepareBasePrcingMessages(BasePricingMsg msg, BasePricingMessages basePricingMessages) {

		BasePricingMessages basePricingMessage = new BasePricingMessages();
		basePricingMessage.setPriceChangeHeader(basePricingMessages.getPriceChangeHeader());
		basePricingMessage.getPriceChangeHeader().setRecordCount(1);
		basePricingMessage.setPriceList(Arrays.asList(msg));
		return basePricingMessage;
	}

	private List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			String statCd, List<String> errorList) throws SystemException {
		return errorHandlingService.prepareErrorMsg(basePriceMsg, itemDetailList, statCd, errorList);
	}

	private void insertNonNumericErrorMessage(ValidationContext validationContext) throws SystemException {
		errorHandlingService.insertNonNumericErrorMessage(validationContext.getBasePricingMsgJson(),
				// validationContext.getErrorType().getMsgList());
				validationContext.getErrorTypeMsgList());
	}

	public void processMeatItem(BasePricingMsg basePricingMsg, ValidationContext validationContext)
			throws SystemException {
		List<BasePricingMsg> basePricingMsgList = prepareOptionalCutCic(basePricingMsg);
		if (!CollectionUtils.isEmpty(basePricingMsgList)) {
			if (basePricingMsg.isPriceArea()) {
				validationContext.getBasePricingMessages().setPriceList(new ArrayList<>());
				validationContext.getBasePricingMessages().setPriceList(basePricingMsgList);
				sendMsgToPriceAreaQueue(validationContext.getBasePricingMessages());
			}
			if (basePricingMsg.isStoreSpecific()) {
				validationContext.getBasePricingMessages().setPriceList(new ArrayList<>());
				validationContext.getBasePricingMessages().setPriceList(basePricingMsgList);
				sendMsgToStorePriceQueue(validationContext.getBasePricingMessages());
			}
		}
	}

	private List<BasePricingMsg> prepareOptionalCutCic(BasePricingMsg basePricingMsg) {

		List<BasePricingMsg> basePricingMsgList = new ArrayList<>();

		basePricingMsgList = basePricingMsg.getOptionalCutDetails().stream().map(optionalCut -> {

			try {
				String msg = new ObjectMapper().writeValueAsString(basePricingMsg);
				BasePricingMsg basePricingMsgs = new BasePricingMsg();
				basePricingMsgs = new ObjectMapper().readValue(msg, BasePricingMsg.class);
				basePricingMsgs.setCorpItemCd(optionalCut.getOptionalCic());
				basePricingMsgs.setSuggPrice(basePricingMsg.getSuggPrice() + optionalCut.getOptionalItemGap());
				basePricingMsgs.setEffectiveStartDt(basePricingMsg.getUpdatedEffectiveStartDt());
				basePricingMsgs.setEffectiveEndDt(basePricingMsg.getUpdatedEffectivEndtDt());
				basePricingMsgs.setStartDateDueToPromotion(null);
				basePricingMsgs.setIsOptionalCut(true);
				basePricingMsgs.setExceptionMessage("");
				return basePricingMsgs;
			} catch (IOException e) {
				LOGGER.error("Not able to Expand Optional Cuts");
			}
			return null;

		}).collect(Collectors.toList());
		return basePricingMsgList;
	}

	private List<BasePricingMsg> prepareStoreSplit(BasePricingMsg basePricingMsg) {

		List<BasePricingMsg> basePricingMsgList = new ArrayList<>();
		String msg;
		try {
			msg = new ObjectMapper().writeValueAsString(basePricingMsg);
			BasePricingMsg basePricingMsgs = new BasePricingMsg();
			basePricingMsgs = new ObjectMapper().readValue(msg, BasePricingMsg.class);
			basePricingMsgs.setEffectiveStartDt(basePricingMsg.getStartDateDueToPromotion());
			basePricingMsgs.setEffectiveEndDt(basePricingMsg.getUpdatedEffectivEndtDt());
			basePricingMsgs.setStartDateDueToPromotion("");
			basePricingMsgs.setExceptionMessage("");
			basePricingMsgs.setHasStoreSplit(true);
			basePricingMsgList.add(basePricingMsgs);
		} catch (JsonProcessingException e) {
			LOGGER.error("Not able to Expand store split");
		} catch (IOException e) {
			LOGGER.error("Not able to Expand store split");
		}

		return basePricingMsgList;
	}

	public void processStoreSplit(BasePricingMsg basePricingMsg, ValidationContext validationContext)
			throws SystemException {
		if (null == basePricingMsg.getInboundEffectiveStartDt() || null == basePricingMsg.getInboundEffectivEndtDt()) {
			basePricingMsg.setInboundEffectiveStartDt(basePricingMsg.getUpdatedEffectiveStartDt());
			basePricingMsg.setInboundEffectivEndtDt(basePricingMsg.getUpdatedEffectivEndtDt());
		}

		List<BasePricingMsg> basePricingMsgList = prepareStoreSplit(basePricingMsg);

		if (!CollectionUtils.isEmpty(basePricingMsgList)) {
			if (basePricingMsg.isPriceArea()) {
				validationContext.getBasePricingMessages().setPriceList(new ArrayList<>());
				validationContext.getBasePricingMessages().setPriceList(basePricingMsgList);
				sendMsgToPriceAreaQueue(validationContext.getBasePricingMessages());
			}
			if (basePricingMsg.isStoreSpecific()) {
				validationContext.getBasePricingMessages().setPriceList(new ArrayList<>());
				validationContext.getBasePricingMessages().setPriceList(basePricingMsgList);
				sendMsgToStorePriceQueue(validationContext.getBasePricingMessages());
			}
		}
	}
}