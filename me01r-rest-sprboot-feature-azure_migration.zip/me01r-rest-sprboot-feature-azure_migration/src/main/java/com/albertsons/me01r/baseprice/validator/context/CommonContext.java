package com.albertsons.me01r.baseprice.validator.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.albertsons.me01r.baseprice.enumObj.PromotionEnum;
import com.albertsons.me01r.baseprice.model.CICItemDetail;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;

public class CommonContext {

	private int rogExistChkResult = 0;
	private List<UPCItemDetail> cicInfo;
	private List<CICItemDetail> crcInfo;
	private int retailSectionPriceAreaExist = 0;
	private int storeExistChkResult = 0;
	private boolean isSmicExclusion = false;
	private PromotionEnum dateChange = PromotionEnum.DATE_EFFECTIVE_CHANGE;
	private Map<PromotionEnum, List<String>> promotionMap;

	public CommonContext() {
		promotionMap = new HashMap<>();
		promotionMap.put(PromotionEnum.DATE_EFFECTIVE_CHANGE, new ArrayList<>());
	}

	public int getRogExistChkResult() {
		return rogExistChkResult;
	}

	public void setRogExistChkResult(int rogExistChkResult) {
		this.rogExistChkResult = rogExistChkResult;
	}

	public boolean isRogExist() {
		return rogExistChkResult == 0 ? false : true;
	}

	public List<UPCItemDetail> getCicInfo() {
		return cicInfo;
	}

	public void setCicInfo(List<UPCItemDetail> cicInfo) {
		this.cicInfo = cicInfo;
	}

	public List<CICItemDetail> getCrcInfo() {
		return crcInfo;
	}

	public void setCrcInfo(List<CICItemDetail> crcInfo) {
		this.crcInfo = crcInfo;
	}

	public int getRetailSectionPriceAreaExist() {
		return retailSectionPriceAreaExist;
	}

	public void setRetailSectionPriceAreaExist(int retailSectionPriceAreaExist) {
		this.retailSectionPriceAreaExist = retailSectionPriceAreaExist;
	}

	public boolean isRetailSectionPriceAreaExist() {
		return retailSectionPriceAreaExist == 0 ? false : true;
	}

	public int getStoreExistChkResult() {
		return storeExistChkResult;
	}

	public void setStoreExistChkResult(int storeExistChkResult) {
		this.storeExistChkResult = storeExistChkResult;
	}

	public boolean isStoreExist() {
		return storeExistChkResult == 0 ? false : true;
	}

	public boolean isSmicExclusion() {
		return isSmicExclusion;
	}

	public void setSmicExclusion(boolean isSmicExclusion) {
		this.isSmicExclusion = isSmicExclusion;
	}

	public List<String> getDateChange() {
		return promotionMap.get(PromotionEnum.DATE_EFFECTIVE_CHANGE);
	}

	/*
	 * public PromotionEnum getDateChange() { return dateChange; } //TODO need to
	 * fix test cases before comment out the following public void
	 * setDateChange(PromotionEnum dateChange) { this.dateChange = dateChange; }
	 **/

}
