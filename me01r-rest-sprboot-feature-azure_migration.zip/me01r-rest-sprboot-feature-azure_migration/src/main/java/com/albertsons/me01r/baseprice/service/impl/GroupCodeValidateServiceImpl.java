package com.albertsons.me01r.baseprice.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.GroupCodeValidateService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;

@Service
public class GroupCodeValidateServiceImpl implements GroupCodeValidateService {
	private static final Logger LOGGER = LoggerFactory.getLogger(GroupCodeValidateServiceImpl.class);

	@Autowired
	private ErrorHandlingService errorHandlingService;

	public void validateGroupCode() throws SystemException {
		String smicCode = PropertiesUtils.getProperty("SMIC_CTGRY");
		String groupCd = PropertiesUtils.getProperty("GRP_CD");
		if (!smicCode.isEmpty() && !groupCd.isEmpty()) {
			validateGroupCode(smicCode, groupCd);
		}
	}

	private void validateGroupCode(String smicCode, String groupCd) throws SystemException {
		if (!smicCode.equals("0")) {
			String[] smicValues = smicCode.split(",");
			for (String smic : smicValues) {
				if (groupCd.contains(smic.substring(0, 2))) {
					LOGGER.error(ConstantsUtil.CONFIGURATION_ERROR);
					List<ErrorMsg> errorMessage = errorHandlingService.prepareGroupCdExistsSmicError();
					errorHandlingService.insertErrorMessage(errorMessage);
					throw BasePriceUtil.getSystemException(ConstantsUtil.CONFIGURATION_ERROR, new BasePricingMsg());
				}
			}
		}
	}
}
