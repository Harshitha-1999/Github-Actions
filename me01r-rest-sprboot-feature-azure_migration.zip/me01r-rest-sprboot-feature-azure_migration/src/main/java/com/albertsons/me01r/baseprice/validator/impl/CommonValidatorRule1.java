package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 1)
public class CommonValidatorRule1 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule1.class);

	@Value("INVALID-ROG-RETSECT-PA")
	private String errorMessage;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule1 {}", context.getCommonContext().getRogExistChkResult());
		if (!context.getCommonContext().isRogExist()) {
			LOGGER.error("INVALID-ROG-RETSECT-PA : {}", basePricingMsg.getRogCd());
			// context.getErrorType().getMsgList().add(errorMessage);
			context.getErrorTypeMsgList().add(errorMessage);
		}
		//LOGGER.debug("CommonValidatorRule1 OK.");
	}
}
