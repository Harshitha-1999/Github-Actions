package com.albertsons.me01r.baseprice.validator.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 12)
public class CommonValidatorRule12 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule12.class);

	@Value("PRICE-CHG-EXCEEDS-LIMIT")
	private String invalidPriceDiff;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule12 {} ", context.getCommonContext().getCicInfo());
		if (context.getCommonContext().getCicInfo().stream().anyMatch(cic -> !cic.isInitialPrice())) {
			if (context.getCommonContext().getCicInfo().stream().anyMatch(cic -> !cic.isValidPriceDiff())) {
				List<UPCItemDetail> inValidUpcList = context.getCommonContext().getCicInfo().stream()
						.filter(cic -> !cic.isValidPriceDiff()).collect(Collectors.toList());
				LOGGER.warn("PRICE-CHG-EXCEEDS-LIMIT {}", inValidUpcList);
				context.getInvalidPriceDiffUpc().addAll(inValidUpcList);
			}
		}
	}
}
