package com.albertsons.me01r.baseprice.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.constatnts.AppConstants;

@Repository
public class ValidateStorePriceDAOImpl implements ValidateStorePriceDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidateStorePriceDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.validate.store}")
	private String sqlValidateStore;

	@Value(value = "${sql.check.upc.exist.itmprc}")
	private String sqlCheckIfUpcPaPriced;

	@Value(value = "${sql.fetch.promotion.details.store.specific}")
	private String sqlFetchPromotionDetails;

	@Value(value = "${sql.fetch.lts.promotion.store.specific}")
	private String sqlFetchLtsPromotion;

	@Value(value = "${sql.fetch.store.specific.details.SSSPCRTL}")
	private String sqlFetchStoreSpecificDetails;

	@Value(value = "${sql.fetch.store.price.eff.start.date}")
	private String sqlFetchStorePriceEffDate;

	@Value(value = "${sql.fetch.optional.cut.store.specific}")
	private String sqlFetchOptionalCut;

	@Value(value = "${sql.fetch.initial.price.base.cut.ss}")
	private String sqlFetchInitialPriceBaseCut;

	@Value(value = "${sql.fetch.pa}")
	private String sqlFetchPA;

	public int validateStore(BasePricingMsg basePricingMsg) throws SystemException {

		//LOGGER.debug("sqlValidateStore sql: {}", sqlValidateStore);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("rogCd", basePricingMsg.getRogCd());
		paramSource.addValue("storeId", basePricingMsg.getPaStoreInfo());
		paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());
		Integer result = null;
		try {
			result = namedJdbc.queryForObject(sqlValidateStore, paramSource, Integer.class);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlValidateStore);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}

		//LOGGER.debug("sqlValidateStore result: {}", result);
		return (result != null) ? result.intValue() : 0;

	}

	// method to check if it is initial price
	public Double checkUpcIsPaPriced(UPCItemDetail item, BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("CheckIfUpcPaPriced sql: {}", sqlCheckIfUpcPaPriced);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue(AppConstants.UPC_MANUF, item.getUpcManuf());
		paramSource.addValue(AppConstants.UPC_SALES, item.getUpcSales());
		paramSource.addValue(AppConstants.UPC_COUNTRY, item.getUpcCountry());
		paramSource.addValue(AppConstants.UPC_SYSTEM, item.getUpcSystem());
		paramSource.addValue(AppConstants.FACILITY, basePricingMsg.getPaStoreInfo());
		paramSource.addValue(AppConstants.ROG, item.getRogCd());
		paramSource.addValue("retailSect", basePricingMsg.getRetailSection());
		paramSource.addValue(AppConstants.DIVISION, item.getDivision());
		Double result = null;
		try {
			result = namedJdbc.queryForObject(sqlCheckIfUpcPaPriced, paramSource, Double.class);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlCheckIfUpcPaPriced);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}

		//LOGGER.debug("CheckIfUpcPaPriced result: {}", result);
		return result;
	}

	public List<Promotion> fetchPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("sqlFetchPromotionDetails sql: {}", sqlFetchPromotionDetails);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if (basePricingMsg.getIsMeatItem() && !CollectionUtils.isEmpty(basePricingMsg.getOptionalCutDetails())) {
			List<Integer> optionalCutList = basePricingMsg.getOptionalCutDetails().stream().map(cic -> {
				return cic.getOptionalCic();
			}).collect(Collectors.toList());
			if (!CollectionUtils.isEmpty(optionalCutList)) {
				optionalCutList.add(basePricingMsg.getBaseCutCic());
			}
			List<String> retailSection = new ArrayList<>();
			retailSection.add(basePricingMsg.getRetailSection());
			retailSection.add(basePricingMsg.getBaseRetailSection());
			paramSource.addValue("cic", optionalCutList);
			paramSource.addValue(AppConstants.RETAIL_SECTION, retailSection);
		} else {
			paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
			paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());
		}
		paramSource.addValue(AppConstants.FACILITY, basePricingMsg.getPaStoreInfo());
		paramSource.addValue(AppConstants.ROG, basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.SUGGESTED_START_DATE, basePricingMsg.getEffectiveStartDt());
		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		List<Promotion> promotionList = null;
		try {
			promotionList = this.namedJdbc.query(sqlFetchPromotionDetails, paramSource, (rs, rowNum) -> {
				Promotion promotion = new Promotion();
				promotion.setStartDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
				promotion.setEndDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_OFF)));
				promotion.setPromotionType(rs.getString("PROMOTION_TYPE"));
				promotion.setCic(rs.getInt("CORP_ITEM_CD"));
				promotion.setRog(basePricingMsg.getRogCd());
				promotion.setUnitType(basePricingMsg.getUnitType());
				promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
				basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());
				return promotion;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchPromotionDetails);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("sqlFetchPromotionDetails result: {}", basePricingMsg);
		return promotionList;
	}

	public List<Promotion> fetchLTSPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("sqlFetchLtsPromotion sql: {}", sqlFetchLtsPromotion);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if (basePricingMsg.getIsMeatItem() && !CollectionUtils.isEmpty(basePricingMsg.getOptionalCutDetails())) {
			List<Integer> optionalCutList = basePricingMsg.getOptionalCutDetails().stream().map(cic -> {
				return cic.getOptionalCic();
			}).collect(Collectors.toList());
			if (!CollectionUtils.isEmpty(optionalCutList)) {
				optionalCutList.add(basePricingMsg.getBaseCutCic());
			}
			List<String> retailSection = new ArrayList<>();
			retailSection.add(basePricingMsg.getRetailSection());
			retailSection.add(basePricingMsg.getBaseRetailSection());
			paramSource.addValue("cic", optionalCutList);
			paramSource.addValue(AppConstants.RETAIL_SECTION, retailSection);
		} else {
			paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
			paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());
		}
		paramSource.addValue(AppConstants.FACILITY, basePricingMsg.getPaStoreInfo());
		paramSource.addValue(AppConstants.ROG, basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.SUGGESTED_START_DATE, basePricingMsg.getEffectiveStartDt());
		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		List<Promotion> promotionList = null;
		try {
			promotionList = this.namedJdbc.query(sqlFetchLtsPromotion, paramSource, (rs, rowNum) -> {
				Promotion promotion = new Promotion();
				promotion.setStartDate(BasePriceUtil.convertStringToLocalDate(rs.getString("DATE_LINK")));
				promotion.setEndDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
				promotion.setPromotionType(rs.getString("PROMOTION_TYPE"));
				promotion.setCic(basePricingMsg.getCorpItemCd());
				promotion.setRog(basePricingMsg.getRogCd());
				promotion.setUnitType(basePricingMsg.getUnitType());
				promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
				basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());
				return promotion;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchLtsPromotion);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("sqlFetchLtsPromotion result: {}", basePricingMsg);
		return promotionList;
	}

	public List<StorePriceData> fetchStoreSpecificDetails(List<StorePriceData> storePriceUpcList,
			BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("sqlFetchStoreSpecificDetails sql: {}", sqlFetchStoreSpecificDetails);
		List<StorePriceData> promotionList = new ArrayList<>();
		try {
			storePriceUpcList.forEach(item -> {
				List<StorePriceData> promotionStoreList = null;
				MapSqlParameterSource paramSource = new MapSqlParameterSource();
				if (basePricingMsg.getIsMeatItem()
						&& !CollectionUtils.isEmpty(basePricingMsg.getOptionalCutDetails())) {
					List<Integer> optionalCutList = basePricingMsg.getOptionalCutDetails().stream().map(cic -> {
						return cic.getOptionalCic();
					}).collect(Collectors.toList());
					if (!CollectionUtils.isEmpty(optionalCutList)) {
						optionalCutList.add(basePricingMsg.getBaseCutCic());
					}
					List<String> retailSection = new ArrayList<>();
					retailSection.add(basePricingMsg.getRetailSection());
					retailSection.add(basePricingMsg.getBaseRetailSection());
					paramSource.addValue("cic", optionalCutList);
				} else {
					paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
				}

				paramSource.addValue(AppConstants.FACILITY, item.getFacility());
				paramSource.addValue(AppConstants.ROG, item.getRogCd());

				promotionStoreList = this.namedJdbc.query(sqlFetchStoreSpecificDetails, paramSource, (rs, rowNum) -> {
					StorePriceData promotion = new StorePriceData();
					promotion.setStartDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
					promotion.setEndDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_OFF)));
					promotion.setDateEffStoreSpecific(rs.getString(AppConstants.DATE_EFF));
					promotion.setDateOffStoreSpecific(rs.getString("DATE_EFF"));
					promotion.setDateEff(rs.getString(AppConstants.DATE_EFF));
					promotion.setDateOff(rs.getString(AppConstants.DATE_OFF));
					promotion.setUpcManuf(item.getUpcManuf());
					promotion.setUpcSales(item.getUpcSales());
					promotion.setUpcCountry(item.getUpcCountry());
					promotion.setUpcSystem(item.getUpcSystem());
					promotion.setFacility(item.getFacility());
					promotion.setCic(rs.getInt("CORP_ITEM_CD"));
					promotion.setRogCd(item.getRogCd());
					promotion.setPromotionType(rs.getString("PROMOTION_IND"));

					return promotion;
				});
				promotionList.addAll(promotionStoreList);
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchStoreSpecificDetails);
			sb.append(AppConstants.SQL_PARAM);
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("sqlFetchPromotionDetails result: {}", promotionList.size());
		return promotionList;
	}

	public UPCItemDetail fetchStorePriceEffDate(UPCItemDetail item, String effectiveStartDate) throws SystemException {
		//LOGGER.debug("fetchPenPriceEffDate sql: {}", sqlFetchStorePriceEffDate);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue(AppConstants.UPC_MANUF, item.getUpcManuf());
		paramSource.addValue(AppConstants.UPC_SALES, item.getUpcSales());
		paramSource.addValue(AppConstants.UPC_COUNTRY, item.getUpcCountry());
		paramSource.addValue(AppConstants.UPC_SYSTEM, item.getUpcSystem());
		paramSource.addValue(AppConstants.FACILITY, item.getPriceArea());
		paramSource.addValue(AppConstants.ROG, item.getRogCd());
		paramSource.addValue(AppConstants.SUGGESTED_START_DATE, effectiveStartDate);
		try {
			this.namedJdbc.query(sqlFetchStorePriceEffDate, paramSource, rs -> {
				item.setPendingPrice(rs.getDouble(AppConstants.PRICE));
				item.setPendingFactor(rs.getInt(AppConstants.PRICE_FCTR));
				item.setPendingReason(rs.getString("REASON_PRICE"));
				if (rs.getString(AppConstants.DATE_EFF) != null && !rs.getString(AppConstants.DATE_EFF).isEmpty()) {
					item.setEffectivePenPriceStartDate(
							BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
				}
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchStorePriceEffDate);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("fetchPenPriceEffDate result: {}", item);
		return item;
	}

	public List<OptionalCutDetail> fetchOptionalCuts(BasePricingMsg basePricingMsg) throws SystemException {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		paramSource.addValue("rogCd", basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.FACILITY, basePricingMsg.getPaStoreInfo());

		List<OptionalCutDetail> optionalCuts = new ArrayList<>();
		try {
			optionalCuts = this.namedJdbc.query(sqlFetchOptionalCut, paramSource, (rs, rowNum) -> {
				OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
				optionalCutDetail.setOptionalCic(rs.getInt("CORP_ITEM_OPTIONAL"));
				optionalCutDetail.setOptionalItemGap(rs.getDouble("OPT_ITEM_GAP"));
				return optionalCutDetail;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchOptionalCut);
			sb.append(AppConstants.SQL_PARAM);
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		return optionalCuts;
	}

	public UPCItemDetail fetchInitialPriceBaseCut(String cic, String rogCd, String paStoreInfo, String retailSection) {
		//LOGGER.debug("sqlFetchInitialPriceBaseCut sql: {}", sqlFetchInitialPriceBaseCut);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("cic", cic);
		paramSource.addValue(AppConstants.FACILITY, paStoreInfo);
		paramSource.addValue(AppConstants.ROG, rogCd);
		paramSource.addValue(AppConstants.RETAIL_SECTION, retailSection);
		Double result = null;
		UPCItemDetail initialItem = new UPCItemDetail();
		try {
			this.namedJdbc.query(sqlFetchInitialPriceBaseCut, paramSource, rs -> {
				initialItem.setInitialPrice(rs.getDouble(AppConstants.PRICE));
				initialItem.setInitialFactor(rs.getInt(AppConstants.PRICE_FCTR));
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchInitialPriceBaseCut);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			LOGGER.debug("No Initial Price Present");
		}

		//LOGGER.debug("fetch sqlFetchInitialPriceBaseCut result: {}", result);
		return initialItem;

	}

	public String fetchPriceArea(String rogCd, String paStoreInfo, String retailSection) {
		//LOGGER.debug("sqlFetchPA sql: {}", sqlFetchPA);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue(AppConstants.FACILITY, paStoreInfo);
		paramSource.addValue(AppConstants.ROG, rogCd);
		paramSource.addValue(AppConstants.RETAIL_SECTION, retailSection);
		try {
			return this.namedJdbc.queryForObject(sqlFetchPA, paramSource, String.class);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchPA);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			//LOGGER.debug("No Initial Price Present");
			return "";
		}

	}
}
