package com.albertsons.me01r.baseprice.dao;

import java.util.List;
import java.util.Map;

public interface PropertyLoadDAO {
	public List<Map<String, Object>> loadProperties();

}
