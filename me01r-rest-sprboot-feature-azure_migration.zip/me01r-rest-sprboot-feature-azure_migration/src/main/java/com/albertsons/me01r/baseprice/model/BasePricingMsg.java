package com.albertsons.me01r.baseprice.model;

import java.text.DecimalFormat;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

//TODO Add in all required fields
public class BasePricingMsg {
	private static DecimalFormat df = new DecimalFormat("0.00");

	private String UUID;
	private boolean isPriceArea = false;
	private boolean isStoreSpecific = false;
	private boolean isCrcPricing = false;
	private Integer crcId;
	private Integer corpItemCd;
	private Integer unitType;
	private String rogCd;
	private String retailSection;
	private String paStoreInfo;
	private String suggLevel;
	private Double suggPrice;
	private Integer scenarioId;
	private String scenarioName;
	private String lastUpdUserId;
	private String lastUpdUserTs;
	private String effectiveStartDt;
	private String updatedEffectiveStartDt;
	private String updatedEffectivEndtDt;
	private String effectiveEndDt;
	private String scenarioFlg;
	private double projectedSales;
	private double projectedMargin;
	private Integer projectedUnits;
	private Integer priceFactor;
	private Integer priceOverrideReason;
	private boolean isItemOnPromotion;
	private boolean isLtsPresent;
	private Boolean isMeatItem = false;
	private Boolean hasOptionalCut = false;
	private Boolean isOptionalCut = false;
	private List<OptionalCutDetail> optionalCutDetails;
	private Integer baseCutCic;
	private String baseRetailSection;
	private boolean hasOptionalInitialPriced = false;
	private boolean hasStoreSplit = false;
	private String reason;
	private String reasonType;

	public String getBaseRetailSection() {
		return baseRetailSection;
	}

	public void setBaseRetailSection(String baseRetailSection) {
		this.baseRetailSection = baseRetailSection;
	}

	private int recordCount;
	private String requestId;
	private int totalCount;
	private String startDateDueToPromotion;
	private String inboundEffectiveStartDt;
	private String inboundEffectivEndtDt;
	private String exceptionMessage;
	@JsonIgnore
	private String userID;

	public boolean isPriceArea() {
		return isPriceArea;
	}

	public void setPriceArea(boolean isPriceArea) {
		this.isPriceArea = isPriceArea;
	}

	public boolean isStoreSpecific() {
		return isStoreSpecific;
	}

	public void setStoreSpecific(boolean isStoreSpecific) {
		this.isStoreSpecific = isStoreSpecific;
	}

	public boolean isCrcPricing() {
		return isCrcPricing;
	}

	public void setCrcPricing(boolean isCrcPricing) {
		this.isCrcPricing = isCrcPricing;
	}

	public Integer getCrcId() {
		return crcId;
	}

	public void setCrcId(Integer crcId) {
		this.crcId = crcId;
	}

	public Integer getCorpItemCd() {
		return corpItemCd;
	}

	public void setCorpItemCd(Integer corpItemCd) {
		this.corpItemCd = corpItemCd;
	}

	public Integer getUnitType() {
		return unitType;
	}

	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public String getRetailSection() {
		return retailSection;
	}

	public void setRetailSection(String retailSection) {
		this.retailSection = retailSection;
	}

	public String getPaStoreInfo() {
		return paStoreInfo;
	}

	public void setPaStoreInfo(String paStoreInfo) {
		this.paStoreInfo = paStoreInfo;
	}

	public String getSuggLevel() {
		return suggLevel;
	}

	public void setSuggLevel(String suggLevel) {
		this.suggLevel = suggLevel;
	}

	public Double getSuggPrice() {
		return Double.valueOf(df.format(suggPrice));
	}

	public void setSuggPrice(Double suggPrice) {
		this.suggPrice = suggPrice;
	}

	public Integer getScenarioId() {
		return scenarioId;
	}

	public void setScenarioId(Integer scenarioId) {
		this.scenarioId = scenarioId;
	}

	public String getScenarioName() {
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	public String getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getEffectiveStartDt() {
		return effectiveStartDt;
	}

	public void setEffectiveStartDt(String effectiveStartDt) {
		this.effectiveStartDt = effectiveStartDt;
	}

	public String getEffectiveEndDt() {
		return effectiveEndDt;
	}

	public void setEffectiveEndDt(String effectiveEndDt) {
		this.effectiveEndDt = effectiveEndDt;
	}

	public String getScenarioFlg() {
		return scenarioFlg;
	}

	public void setScenarioFlg(String scenarioFlg) {
		this.scenarioFlg = scenarioFlg;
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("BasePricingMsg: [requestId=");
		sb.append(requestId);
		sb.append(", totalCount=");
		sb.append(totalCount);
		sb.append(", recordCount=");
		sb.append(recordCount);
		sb.append(", corpItemCd=");
		sb.append(corpItemCd);
		sb.append(", crcId=");
		sb.append(crcId);
		sb.append(", corpItemCd=");
		sb.append(corpItemCd);
		sb.append(", unitType=");
		sb.append(unitType);
		sb.append(", rogCd=");
		sb.append(rogCd);
		sb.append(", isPriceArea=");
		sb.append(isPriceArea);
		sb.append(", isStoreSpecific=");
		sb.append(isStoreSpecific);
		sb.append(", isCrcPricing=");
		sb.append(isCrcPricing);
		sb.append(", retailSection=");
		sb.append(retailSection);
		sb.append(", paStoreInfo=");
		sb.append(paStoreInfo);
		sb.append(", suggLevel=");
		sb.append(suggLevel);
		sb.append(", suggPrice=");
		sb.append(suggPrice);
		sb.append(", scenarioId=");
		sb.append(scenarioId);
		sb.append(", scenarioName=");
		sb.append(scenarioName);
		sb.append(", lastUpdUserId=");
		sb.append(lastUpdUserId);
		sb.append(", lastUpdUserTs=");
		sb.append(lastUpdUserTs);
		sb.append(", effectiveStartDt=");
		sb.append(effectiveStartDt);
		sb.append(", effectiveEndDt=");
		sb.append(effectiveEndDt);
		sb.append(", updatedEffectiveStartDt=");
		sb.append(updatedEffectiveStartDt);
		sb.append(", updatedEffectivEndtDt=");
		sb.append(updatedEffectivEndtDt);
		sb.append(", scenarioFlg=");
		sb.append(scenarioFlg);
		sb.append(", projectedSales=");
		sb.append(projectedSales);
		sb.append(", projectedMargin=");
		sb.append(projectedMargin);
		sb.append(", projectedUnits=");
		sb.append(projectedUnits);
		sb.append(", priceOverrideReason=");
		sb.append(priceOverrideReason);
		sb.append(", UUID=");
		sb.append(UUID);
		sb.append(", isItemOnPromotion=");
		sb.append(isItemOnPromotion);
		sb.append(", isLtsPresent=");
		sb.append(isLtsPresent);
		sb.append(", isMeatItem=");
		sb.append(isMeatItem);
		sb.append(", hasOptionalCut=");
		sb.append(hasOptionalCut);
		sb.append(", isOptionalCut=");
		sb.append(isOptionalCut);
		sb.append(", optionalCutDetails=");
		sb.append(optionalCutDetails);
		sb.append("]");

		return sb.toString();
	}

	public double getProjectedSales() {
		return projectedSales;
	}

	public void setProjectedSales(double projectedSales) {
		this.projectedSales = projectedSales;
	}

	public double getProjectedMargin() {
		return projectedMargin;
	}

	public void setProjectedMargin(double projectedMargin) {
		this.projectedMargin = projectedMargin;
	}

	public Integer getProjectedUnits() {
		return projectedUnits;
	}

	public void setProjectedUnits(Integer projectedUnits) {
		this.projectedUnits = projectedUnits;
	}

	public Integer getPriceFactor() {
		return priceFactor;
	}

	public void setPriceFactor(Integer priceFactor) {
		this.priceFactor = priceFactor;
	}

	public Integer getPriceOverrideReason() {
		return priceOverrideReason;
	}

	public void setPriceOverrideReason(Integer priceOverrideReason) {
		this.priceOverrideReason = priceOverrideReason;
	}

	public String getLastUpdUserTs() {
		return lastUpdUserTs;
	}

	public void setLastUpdUserTs(String lastUpdUserTs) {
		this.lastUpdUserTs = lastUpdUserTs;
	}

	public boolean isItemOnPromotion() {
		return isItemOnPromotion;
	}

	public void setItemOnPromotion(boolean isItemOnPromotion) {
		this.isItemOnPromotion = isItemOnPromotion;
	}

	public boolean isLtsPresent() {
		return isLtsPresent;
	}

	public void setLtsPresent(boolean isLtsPresent) {
		this.isLtsPresent = isLtsPresent;
	}

	public String getUpdatedEffectiveStartDt() {
		return updatedEffectiveStartDt;
	}

	public void setUpdatedEffectiveStartDt(String updatedEffectiveStartDt) {
		this.updatedEffectiveStartDt = updatedEffectiveStartDt;
	}

	public Boolean getIsMeatItem() {
		return isMeatItem;
	}

	public void setIsMeatItem(Boolean isMeatItem) {
		this.isMeatItem = isMeatItem;
	}

	public Boolean getHasOptionalCut() {
		return hasOptionalCut;
	}

	public void setHasOptionalCut(Boolean hasOptionalCut) {
		this.hasOptionalCut = hasOptionalCut;
	}

	public Boolean getIsOptionalCut() {
		return isOptionalCut;
	}

	public void setIsOptionalCut(Boolean isOptionalCut) {
		this.isOptionalCut = isOptionalCut;
	}

	public List<OptionalCutDetail> getOptionalCutDetails() {
		return optionalCutDetails;
	}

	public void setOptionalCutDetails(List<OptionalCutDetail> optionalCutDetails) {
		this.optionalCutDetails = optionalCutDetails;
	}

	public String getUpdatedEffectivEndtDt() {
		return updatedEffectivEndtDt;
	}

	public void setUpdatedEffectivEndtDt(String updatedEffectivEndtDt) {
		this.updatedEffectivEndtDt = updatedEffectivEndtDt;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public String getStartDateDueToPromotion() {
		return startDateDueToPromotion;
	}

	public void setStartDateDueToPromotion(String startDateDueToPromotion) {
		this.startDateDueToPromotion = startDateDueToPromotion;
	}

	public String getInboundEffectiveStartDt() {
		return inboundEffectiveStartDt;
	}

	public void setInboundEffectiveStartDt(String inboundEffectiveStartDt) {
		this.inboundEffectiveStartDt = inboundEffectiveStartDt;
	}

	public String getInboundEffectivEndtDt() {
		return inboundEffectivEndtDt;
	}

	public void setInboundEffectivEndtDt(String inboundEffectivEndtDt) {
		this.inboundEffectivEndtDt = inboundEffectivEndtDt;
	}

	public Integer getBaseCutCic() {
		return baseCutCic;
	}

	public void setBaseCutCic(Integer baseCutCic) {
		this.baseCutCic = baseCutCic;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public boolean isHasOptionalInitialPriced() {
		return hasOptionalInitialPriced;
	}

	public void setHasOptionalInitialPriced(boolean hasOptionalInitialPriced) {
		this.hasOptionalInitialPriced = hasOptionalInitialPriced;
	}

	public boolean isHasStoreSplit() {
		return hasStoreSplit;
	}

	public void setHasStoreSplit(boolean hasStoreSplit) {
		this.hasStoreSplit = hasStoreSplit;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReasonType() {
		return reasonType;
	}

	public void setReasonType(String reasonType) {
		this.reasonType = reasonType;
	}
}
