package com.albertsons.me01r.baseprice.service.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.albertsons.me01r.baseprice.dao.ErrorHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingHeader;
import com.albertsons.me01r.baseprice.model.BasePricingHeaderJson;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsgJson;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;

@Service
public class ErrorHandlingServiceImpl implements ErrorHandlingService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandlingServiceImpl.class);

	@Autowired
	ErrorHandlingDAO errorHandlingDAO;

	@Value("${application.user.id}")
	private String appId;

	@Autowired
	private Environment env;

	@Value("CRC-CIC-EXIST")
	private String crcCicExist;

	@Value("INVALID-INBOUND-MSG")
	private String invalidInbounsMsg;

	public List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePricingMsg, List<UPCItemDetail> itemDetailList,
			String statCd, List<String> errorList) throws SystemException {
		List<ErrorMsg> errorMessageList = new ArrayList<>();
		errorList.stream().distinct().collect(Collectors.toList()).forEach(error -> {
			if (CollectionUtils.isEmpty(itemDetailList)) {
				UPCItemDetail upcItemDetail = new UPCItemDetail();
				upcItemDetail.setUpcCountry(0);
				upcItemDetail.setUpcSystem(0);
				upcItemDetail.setUpcManuf(0);
				upcItemDetail.setUpcSales(0);
				ErrorMsg errorMsg = new ErrorMsg();
				updateErrorMessage(upcItemDetail, basePricingMsg, errorMsg, errorList, error, ConstantsUtil.SPACE,
						ConstantsUtil.SPACE);
				errorMsg.setUpcCountry(0);
				errorMsg.setUpcSystem(0);
				errorMsg.setUpcManuf(0);
				errorMsg.setUpcSales(0);
				errorMsg.setStatCd(statCd);
				errorMsg.setMsgNm(error);
				errorMsg.setMsgSysCd(env.getProperty(error));
				errorMsg.setCrtUsrId(appId);
				errorMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
				errorMessageList.add(errorMsg);
			} else if (!itemDetailList.isEmpty()) {
				itemDetailList.forEach(upcItemDetail -> {
					ErrorMsg errorMsg = new ErrorMsg();
					updateErrorMessage(upcItemDetail, basePricingMsg, errorMsg, errorList, error, ConstantsUtil.SPACE,
							ConstantsUtil.SPACE);
					errorMsg.setUpcCountry(upcItemDetail.getUpcCountry());
					errorMsg.setUpcSystem(upcItemDetail.getUpcSystem());
					errorMsg.setUpcManuf(upcItemDetail.getUpcManuf());
					errorMsg.setUpcSales(upcItemDetail.getUpcSales());
					errorMsg.setStatCd(statCd);
					errorMsg.setMsgNm(error);
					errorMsg.setMsgSysCd(env.getProperty(error));
					errorMsg.setCrtUsrId(appId);
					errorMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
					errorMessageList.add(errorMsg);
				});
			}
		});
		return errorMessageList;

	}

	public List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePricingMsg, List<UPCItemDetail> itemDetailList,
			String statCd, List<String> errorList, String tableName, String errorCode) throws SystemException {
		List<ErrorMsg> errorMessageList = new ArrayList<>();
		errorList.stream().distinct().collect(Collectors.toList()).forEach(error -> {
			if (CollectionUtils.isEmpty(itemDetailList)) {
				UPCItemDetail upcItemDetail = new UPCItemDetail();
				upcItemDetail.setUpcCountry(0);
				upcItemDetail.setUpcSystem(0);
				upcItemDetail.setUpcManuf(0);
				upcItemDetail.setUpcSales(0);
				ErrorMsg errorMsg = new ErrorMsg();
				updateErrorMessage(upcItemDetail, basePricingMsg, errorMsg, errorList, error, tableName, errorCode);
				errorMsg.setUpcCountry(upcItemDetail.getUpcCountry());
				errorMsg.setUpcSystem(upcItemDetail.getUpcSystem());
				errorMsg.setUpcManuf(upcItemDetail.getUpcManuf());
				errorMsg.setUpcSales(upcItemDetail.getUpcSales());
				errorMsg.setStatCd(statCd);
				errorMsg.setMsgNm(error);
				errorMsg.setMsgSysCd(env.getProperty(error));
				errorMsg.setCrtUsrId(appId);
				errorMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
				errorMessageList.add(errorMsg);
			} else if (!itemDetailList.isEmpty()) {
				itemDetailList.forEach(upcItemDetail -> {
					ErrorMsg errorMsg = new ErrorMsg();
					updateErrorMessage(upcItemDetail, basePricingMsg, errorMsg, errorList, error, tableName, errorCode);
					errorMsg.setUpcCountry(upcItemDetail.getUpcCountry());
					errorMsg.setUpcSystem(upcItemDetail.getUpcSystem());
					errorMsg.setUpcManuf(upcItemDetail.getUpcManuf());
					errorMsg.setUpcSales(upcItemDetail.getUpcSales());
					errorMsg.setStatCd(statCd);
					errorMsg.setMsgNm(error);
					errorMsg.setMsgSysCd(env.getProperty(error));
					errorMsg.setCrtUsrId(appId);
					errorMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
					errorMessageList.add(errorMsg);
				});
			}
		});
		return errorMessageList;

	}

	private void updateErrorMessage(UPCItemDetail upcItemDetail, BasePricingMsg basePricingMsg, ErrorMsg errorMsg,
			List<String> errorList, String error, String tableName, String errorCode) {

		if (errorList.contains(ConstantsUtil.COM_CD_NOEXIST)) {
			errorMsg.setCrcId(0);
			if (error.equalsIgnoreCase(ConstantsUtil.COM_CD_NOEXIST)) {
				errorMsg.setRemTxt(
						"CRC :" + basePricingMsg.getCrcId() + ConstantsUtil.COMMA + "ROG :" + basePricingMsg.getRogCd()
								+ ConstantsUtil.COMMA + "Unit Type :" + basePricingMsg.getUnitType());
			}
		} else {
			errorMsg.setRemTxt("");
			errorMsg.setCrcId(basePricingMsg.getCrcId());
		}
		if (errorList.contains(ConstantsUtil.INVALID_CIC)) {
			errorMsg.setCic(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_CIC)) {
				errorMsg.setRemTxt("CIC :" + basePricingMsg.getCorpItemCd() + ConstantsUtil.COMMA + "ROG :"
						+ basePricingMsg.getRogCd() + ConstantsUtil.COMMA + "Unit Type :"
						+ basePricingMsg.getUnitType());
			}
		} else {
			// errorMsg.setRemTxt("");
			errorMsg.setCic(basePricingMsg.getCorpItemCd());
		}
		if (errorList.contains(crcCicExist)) {
			if (error.equalsIgnoreCase(crcCicExist)) {
				errorMsg.setRemTxt(ConstantsUtil.CRC_HAS_CIC);
			} else {
				errorMsg.setRemTxt("");
			}
		}
		if (errorList.contains(ConstantsUtil.SQL_EXCEPTION)) {

			if (!StringUtils.isEmpty(tableName)) {
				errorMsg.setRemTxt("Table Name: " + tableName + ConstantsUtil.COMMA + "Error Code: " + errorCode + " ["
						+ " ROG:" + basePricingMsg.getRogCd() + ConstantsUtil.COMMA + " CIC:"
						+ basePricingMsg.getCorpItemCd() + ConstantsUtil.COMMA + " PRICE_AREA:"
						+ basePricingMsg.getPaStoreInfo() + " ]");
			} else {
				errorMsg.setRemTxt(ConstantsUtil.UNABLE_TO_PROCESS_I_B_MSG_TXT);
			}
		}
		errorMsg.setUnitType(basePricingMsg.getUnitType());
		errorMsg.setRogCd(basePricingMsg.getRogCd());
		errorMsg.setRtlSection(basePricingMsg.getRetailSection());
		errorMsg.setPaStoreInfo(basePricingMsg.getPaStoreInfo());
		errorMsg.setRcmdLvl(basePricingMsg.getSuggLevel());
		errorMsg.setScenarioId(basePricingMsg.getScenarioId());
		errorMsg.setScenarioNm(basePricingMsg.getScenarioName());
		errorMsg.setEffStrtDt(basePricingMsg.getEffectiveStartDt());
		errorMsg.setEffEndDt(basePricingMsg.getEffectiveEndDt());
		errorMsg.setScenarioFl(basePricingMsg.getScenarioFlg());
		errorMsg.setProjectSls(basePricingMsg.getProjectedSales());
		errorMsg.setProjectMgn(basePricingMsg.getProjectedMargin());
		errorMsg.setProjectUnt(basePricingMsg.getProjectedUnits());

		if (errorList.contains(ConstantsUtil.INVALID_PRICE_FACTOR)) {
			errorMsg.setPriceFctr(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PRICE_FACTOR)) {
				errorMsg.setRemTxt(ConstantsUtil.PRICE_FACTOR_INBOUND + basePricingMsg.getPriceFactor() + ","
						+ ConstantsUtil.PRICE_INBOUND + basePricingMsg.getSuggPrice());
			}
		} else {
			errorMsg.setPriceFctr(basePricingMsg.getPriceFactor());
		}
		if (errorList.contains(ConstantsUtil.INVALID_PRICE)) {
			errorMsg.setRcmdPrc(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PRICE)) {
				errorMsg.setRemTxt(ConstantsUtil.PRICE_FACTOR_INBOUND + basePricingMsg.getPriceFactor() + ","
						+ ConstantsUtil.PRICE_INBOUND + basePricingMsg.getSuggPrice());
			}
		} else {
			errorMsg.setRcmdPrc(basePricingMsg.getSuggPrice());
		}

		errorMsg.setPriceRsnCd(basePricingMsg.getPriceOverrideReason());
		errorMsg.setLstUpdtUsrTs(Timestamp.valueOf(basePricingMsg.getLastUpdUserTs()));
		errorMsg.setLstUpdtUsrId(basePricingMsg.getLastUpdUserId());
		errorMsg.setCoMsgCd(ConstantsUtil.SPACE);
		errorMsg.setRptIndicator(ConstantsUtil.SPACE);
		errorMsg.setRequestId(basePricingMsg.getRequestId());
		errorMsg.setTotalCount(basePricingMsg.getTotalCount());
		errorMsg.setRecordCount(basePricingMsg.getRecordCount());
	}

	@Override
	public void insertErrorMessage(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingDAO.insertErrorMessage(errorMessage);
	}

	@Override
	@Transactional(noRollbackFor = DataIntegrityViolationException.class)
	public void insertNonRollBackErrorMessage(List<ErrorMsg> errorMsgList) throws SystemException {
		errorHandlingDAO.insertErrorMessage(errorMsgList);
	}

	@Override
	@Transactional
	public void insertNonNumericErrorMessage(BasePricingMsgJson basePricingMsgJson, List<String> errorList)
			throws SystemException {
		errorList.forEach(error -> {
			List<ErrorMsg> errorMessage = new ArrayList<>();
			try {
				errorMessage = prepareNonNumericErrorMsg(basePricingMsgJson, error, errorList);
				errorHandlingDAO.insertErrorMessage(errorMessage);
			} catch (SystemException e) {
				LOGGER.error("Processing Failed");
			}

		});

	}

	private List<ErrorMsg> prepareNonNumericErrorMsg(BasePricingMsgJson basePricingMsg, String error,
			List<String> errorList) throws SystemException {
		List<ErrorMsg> errorMessageList = new ArrayList<>();

		ErrorMsg errorMsg = new ErrorMsg();
		errorMsg.setMsgNm(error);
		errorMsg.setMsgSysCd(env.getProperty(error));

		if (errorList.contains(ConstantsUtil.INVALID_CRC)) {
			errorMsg.setCrcId(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_CRC)) {
				errorMsg.setRemTxt(ConstantsUtil.CRC_INBOUND + basePricingMsg.getCrcId() + ","
						+ ConstantsUtil.CIC_INBOUND + basePricingMsg.getCorpItemCd());
			}
		} else {
			errorMsg.setCrcId(Integer.valueOf(basePricingMsg.getCrcId()));
		}

		if (errorList.contains(ConstantsUtil.INVALID_CIC)) {
			errorMsg.setCic(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_CIC)) {
				errorMsg.setRemTxt(ConstantsUtil.CIC_INBOUND + basePricingMsg.getCorpItemCd() + ","
						+ ConstantsUtil.PRICE_INBOUND + basePricingMsg.getSuggPrice());
			}
		} else {
			errorMsg.setCic(Integer.valueOf(basePricingMsg.getCorpItemCd()));
		}

		if (errorList.contains(ConstantsUtil.INVALID_UT)) {
			errorMsg.setUnitType(ConstantsUtil.ZERO);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_UT)) {
				errorMsg.setRemTxt(ConstantsUtil.CIC_INBOUND + basePricingMsg.getCorpItemCd() + ","
						+ ConstantsUtil.UT_INBOUND + basePricingMsg.getUnitType());
			}
		} else {
			errorMsg.setUnitType(Integer.valueOf(basePricingMsg.getUnitType()));
		}

		if (errorList.contains(ConstantsUtil.INVALID_PA)) {
			errorMsg.setPaStoreInfo("0");
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PA)) {
				errorMsg.setRemTxt(ConstantsUtil.CIC_INBOUND + basePricingMsg.getCorpItemCd() + ","
						+ ConstantsUtil.PA_INFO + basePricingMsg.getPaStoreInfo());
			}

		} else if (errorList.contains(ConstantsUtil.INVALID_FACILITY)) {
			errorMsg.setPaStoreInfo("0");
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_FACILITY)) {
				errorMsg.setRemTxt(ConstantsUtil.CIC_INBOUND + basePricingMsg.getCorpItemCd() + ","
						+ ConstantsUtil.FACILITY_INFO + basePricingMsg.getPaStoreInfo());
			}
		} else {
			errorMsg.setPaStoreInfo(basePricingMsg.getPaStoreInfo());
		}

		errorMsg.setRcmdLvl(basePricingMsg.getSuggLevel());
		if (errorList.contains(ConstantsUtil.INVALID_PRICE)) {
			errorMsg.setRcmdPrc(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PRICE)) {
				errorMsg.setRemTxt(ConstantsUtil.PRICE_FACTOR_INBOUND + basePricingMsg.getPriceFactor() + ","
						+ ConstantsUtil.PRICE_INBOUND + basePricingMsg.getSuggPrice());
			}
		} else {
			errorMsg.setRcmdPrc(Double.parseDouble(basePricingMsg.getSuggPrice()));
		}
		if (errorList.contains(ConstantsUtil.INVALID_DATE_EFF)) {
			errorMsg.setEffStrtDt(LocalDate.now().toString());
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_DATE_EFF)) {
				errorMsg.setRemTxt(ConstantsUtil.EFF_DATE + basePricingMsg.getEffectiveStartDt() + ConstantsUtil.COMMA
						+ ConstantsUtil.OFF_DATE + basePricingMsg.getEffectiveEndDt());
			}
		} else {
			errorMsg.setEffStrtDt(basePricingMsg.getEffectiveStartDt());
		}
		if (errorList.contains(ConstantsUtil.INVALID_DATE_OFF)) {
			errorMsg.setEffEndDt(LocalDate.now().toString());
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_DATE_OFF)) {
				errorMsg.setRemTxt(ConstantsUtil.EFF_DATE + basePricingMsg.getEffectiveStartDt() + ConstantsUtil.COMMA
						+ ConstantsUtil.OFF_DATE + basePricingMsg.getEffectiveEndDt());
			}
		} else {
			errorMsg.setEffEndDt(basePricingMsg.getEffectiveEndDt());
		}
		if (errorList.contains(ConstantsUtil.INVALID_PRICE_FACTOR)) {
			errorMsg.setPriceFctr(0);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PRICE_FACTOR)) {
				errorMsg.setRemTxt(ConstantsUtil.PRICE_FACTOR_INBOUND + basePricingMsg.getPriceFactor() + ","
						+ ConstantsUtil.PRICE_INBOUND + basePricingMsg.getSuggPrice());
			}
		} else {
			errorMsg.setPriceFctr(Integer.valueOf(basePricingMsg.getPriceFactor()));
		}

		if (errorList.contains(ConstantsUtil.INVALID_SCENARIO_ID)) {
			errorMsg.setScenarioId(ConstantsUtil.ZERO);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_SCENARIO_ID)) {
				errorMsg.setRemTxt(ConstantsUtil.SCENARIO_ID + basePricingMsg.getScenarioId());
				errorMsg.setMsgNm(invalidInbounsMsg);
				errorMsg.setMsgSysCd(env.getProperty(invalidInbounsMsg));
			}
		} else {
			errorMsg.setScenarioId(Integer.valueOf(basePricingMsg.getScenarioId()));
		}
		if (errorList.contains(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON)) {
			errorMsg.setPriceRsnCd(ConstantsUtil.ZERO);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PRICE_OVERRIDE_REASON)) {
				errorMsg.setRemTxt(ConstantsUtil.PRICE_OVERRIDE_REASON + basePricingMsg.getPriceOverrideReason());
				errorMsg.setMsgNm(invalidInbounsMsg);
				errorMsg.setMsgSysCd(env.getProperty(invalidInbounsMsg));
			}
		} else {
			errorMsg.setPriceRsnCd(Integer.valueOf(basePricingMsg.getPriceOverrideReason()));
		}
		if (errorList.contains(ConstantsUtil.INVALID_PROJECTED_UNITS)) {
			errorMsg.setProjectUnt(ConstantsUtil.ZERO);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PROJECTED_UNITS)) {
				errorMsg.setRemTxt(ConstantsUtil.PROJECTED_UNITS + basePricingMsg.getProjectedUnits());
				errorMsg.setMsgNm(invalidInbounsMsg);
				errorMsg.setMsgSysCd(env.getProperty(invalidInbounsMsg));
			}
		} else {
			errorMsg.setProjectUnt(Integer.valueOf(basePricingMsg.getProjectedUnits()));
		}
		if (errorList.contains(ConstantsUtil.INVALID_PROJECTED_SALES)) {
			errorMsg.setProjectSls(ConstantsUtil.ZERO);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PROJECTED_SALES)) {
				errorMsg.setRemTxt(ConstantsUtil.PROJECTED_SALES + basePricingMsg.getProjectedSales());
				errorMsg.setMsgNm(invalidInbounsMsg);
				errorMsg.setMsgSysCd(env.getProperty(invalidInbounsMsg));
			}
		} else {
			errorMsg.setProjectSls(Double.valueOf(basePricingMsg.getProjectedSales()));
		}
		if (errorList.contains(ConstantsUtil.INVALID_PROJECTED_MARGIN)) {
			errorMsg.setProjectMgn(ConstantsUtil.ZERO);
			if (error.equalsIgnoreCase(ConstantsUtil.INVALID_PROJECTED_MARGIN)) {
				errorMsg.setRemTxt(ConstantsUtil.PROJECTED_MARGIN + basePricingMsg.getProjectedMargin());
				errorMsg.setMsgNm(invalidInbounsMsg);
				errorMsg.setMsgSysCd(env.getProperty(invalidInbounsMsg));
			}
		} else {
			errorMsg.setProjectMgn(Double.valueOf(basePricingMsg.getProjectedMargin()));
		}
		errorMsg.setScenarioNm(basePricingMsg.getScenarioName());
		errorMsg.setRogCd(basePricingMsg.getRogCd());
		errorMsg.setRtlSection(basePricingMsg.getRetailSection());
		errorMsg.setScenarioFl(basePricingMsg.getScenarioFlg());

		errorMsg.setUpcCountry(0);
		errorMsg.setUpcSystem(0);
		errorMsg.setUpcManuf(0);
		errorMsg.setUpcSales(0);
		errorMsg.setStatCd("E");
		errorMsg.setCoMsgCd(ConstantsUtil.SPACE);

		errorMsg.setLstUpdtUsrTs(Timestamp.valueOf(basePricingMsg.getLastUpdUserTs()));
		errorMsg.setLstUpdtUsrId(basePricingMsg.getLastUpdUserId());
		errorMsg.setCrtUsrId(appId);
		errorMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		errorMsg.setRptIndicator(ConstantsUtil.SPACE);
		errorMsg.setRequestId(basePricingMsg.getRequestId());
		errorMsg.setTotalCount(basePricingMsg.getTotalCount());
		errorMsg.setRecordCount(basePricingMsg.getRecordCount());
		errorMessageList.add(errorMsg);
		return errorMessageList;
	}

	public List<ErrorMsg> prepareGroupCdExistsSmicError() {

		ErrorMsg errorMsg = new ErrorMsg();
		createBlankMsgVal(errorMsg);
		errorMsg.setRemTxt(ConstantsUtil.CONFIGURATION_ERROR);
		errorMsg.setRequestId(ConstantsUtil.ZERO.toString());
		return Arrays.asList(errorMsg);
	}

	public List<ErrorMsg> prepareInvlaidRecordCount(BasePricingHeaderJson priceChangeHeader) {

		ErrorMsg errorMsg = new ErrorMsg();
		createBlankMsgVal(errorMsg);
		errorMsg.setRemTxt(ConstantsUtil.RECORD_COUNT + " : " + priceChangeHeader.getRecordCount());
		errorMsg.setMsgNm(ConstantsUtil.INVALID_RECORD_COUNT);
		errorMsg.setMsgSysCd(env.getProperty(ConstantsUtil.INVALID_RECORD_COUNT));
		errorMsg.setRequestId(priceChangeHeader.getRequestId());
		errorMsg.setRecordCount(0);
		errorMsg.setTotalCount(0);
		return Arrays.asList(errorMsg);
	}

	public List<ErrorMsg> prepareInvlaidPriceLevel(BasePricingHeader priceChangeHeader, String priceLevel) {

		ErrorMsg errorMsg = new ErrorMsg();
		createBlankMsgVal(errorMsg);
		errorMsg.setRemTxt(ConstantsUtil.INVALID_SUGG_LEVEL_MSG + " : " + priceChangeHeader.getSuggLevel()
				+ " Expected Sugg Level : " + priceLevel);
		errorMsg.setMsgNm(ConstantsUtil.INVALID_SUGG_LEVEL);
		errorMsg.setMsgSysCd(env.getProperty(ConstantsUtil.INVALID_SUGG_LEVEL));
		errorMsg.setRequestId(priceChangeHeader.getRequestId());
		errorMsg.setRecordCount(0);
		errorMsg.setTotalCount(priceChangeHeader.getRecordCount());
		return Arrays.asList(errorMsg);
	}

	public List<ErrorMsg> prepareMismatchRecordCount(BasePricingMessages basePricingMsgs) {

		ErrorMsg errorMsg = new ErrorMsg();
		createBlankMsgVal(errorMsg);
		errorMsg.setRemTxt("Header Count: " + basePricingMsgs.getPriceChangeHeader().getRecordCount()
				+ ", Count of Pricing Message: " + basePricingMsgs.getPriceList().size());
		errorMsg.setMsgNm(ConstantsUtil.RECORD_COUNT_MISMATCH);
		errorMsg.setMsgSysCd(env.getProperty(ConstantsUtil.RECORD_COUNT_MISMATCH));
		errorMsg.setRequestId(basePricingMsgs.getPriceChangeHeader().getRequestId());
		errorMsg.setRecordCount(0);
		errorMsg.setTotalCount(basePricingMsgs.getPriceChangeHeader().getRecordCount());
		return Arrays.asList(errorMsg);
	}

	private void createBlankMsgVal(ErrorMsg errorMsg) {
		errorMsg.setCrcId(ConstantsUtil.ZERO);
		errorMsg.setCic(ConstantsUtil.ZERO);
		errorMsg.setUnitType(ConstantsUtil.ZERO);
		errorMsg.setRogCd("0");
		errorMsg.setRtlSection("0");
		errorMsg.setPaStoreInfo("0");
		errorMsg.setPriceRsnCd(ConstantsUtil.ZERO);
		errorMsg.setLstUpdtUsrTs(new Timestamp(System.currentTimeMillis()));
		errorMsg.setLstUpdtUsrId(appId);
		errorMsg.setCoMsgCd(ConstantsUtil.SPACE);
		errorMsg.setRptIndicator(ConstantsUtil.SPACE);
		errorMsg.setPriceFctr(ConstantsUtil.ZERO);
		errorMsg.setRcmdPrc(ConstantsUtil.ZERO);
		errorMsg.setRcmdLvl(ConstantsUtil.SPACE);
		errorMsg.setScenarioId(ConstantsUtil.ZERO);
		errorMsg.setScenarioNm(ConstantsUtil.SPACE);
		errorMsg.setEffStrtDt(LocalDate.now().toString());
		errorMsg.setEffEndDt(LocalDate.now().toString());
		errorMsg.setScenarioFl(ConstantsUtil.SPACE);
		errorMsg.setProjectSls(ConstantsUtil.ZERO);
		errorMsg.setProjectMgn(ConstantsUtil.ZERO);
		errorMsg.setProjectUnt(ConstantsUtil.ZERO);
		errorMsg.setUpcCountry(ConstantsUtil.ZERO);
		errorMsg.setUpcSystem(ConstantsUtil.ZERO);
		errorMsg.setUpcManuf(ConstantsUtil.ZERO);
		errorMsg.setUpcSales(ConstantsUtil.ZERO);
		errorMsg.setStatCd("E");
		errorMsg.setMsgNm(ConstantsUtil.SPACE);
		errorMsg.setTotalCount(ConstantsUtil.ZERO);
		errorMsg.setRecordCount(ConstantsUtil.ZERO);
		errorMsg.setMsgSysCd("E");
		errorMsg.setCrtUsrId(appId);
		errorMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
	}

	public List<ErrorMsg> prepareCorruptMessage(BasePricingHeaderJson priceChangeHeader) {
		ErrorMsg errorMsg = new ErrorMsg();
		createBlankMsgVal(errorMsg);
		errorMsg.setRemTxt(ConstantsUtil.CORRUPT_MESSAGE_TEXT);
		errorMsg.setMsgNm(ConstantsUtil.CORRUPT_MESSAGE);
		errorMsg.setMsgSysCd(env.getProperty(ConstantsUtil.CORRUPT_MESSAGE));
		errorMsg.setRequestId(priceChangeHeader.getRequestId());
		errorMsg.setRecordCount(0);
		errorMsg.setTotalCount(Integer.valueOf(priceChangeHeader.getRecordCount()));
		return Arrays.asList(errorMsg);
	}
}
