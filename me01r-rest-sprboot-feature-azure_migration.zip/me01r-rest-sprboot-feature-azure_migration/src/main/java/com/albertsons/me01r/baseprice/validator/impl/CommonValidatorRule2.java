package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 2)
public class CommonValidatorRule2 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule2.class);

	@Value("CORPCD-NO-EXIST-ROG")
	private String errorMessage;

	@Value("INVALID-ROG-RETSECT-PA")
	private String invalidRog;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule2 {}", context.getCommonContext().getCicInfo());
		if (CollectionUtils.isEmpty(context.getCommonContext().getCicInfo())
				&& !context.getErrorTypeMsgList().contains(invalidRog)) {
			LOGGER.error("CORPCD-NO-EXIST-ROG : {}", basePricingMsg.getCorpItemCd());
			context.getErrorTypeMsgList().add(errorMessage);
		}
		//LOGGER.debug("CommonValidatorRule2 OK.");
	}
}
