package com.albertsons.me01r.baseprice.util;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Value;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;

public class BasePriceUtil {
	public static final String WEB_BASEPRICE_STORE_ENDPOINT = "/storeprocess";
	public static final String WEB_BASEPRICE_PA_ENDPOINT = "/paprocess";

	@Value("INVALID-PRICE-FACTOR")
	private static String invalidPriceFactorErrorMessage;

	@Value("INVALID-PRICE-LMT")
	private static String invalidPriceErrorMessage;

	@Value("CORPCD-NO-EXIST-ROG")
	private static String invalidCicErrorMessage;

	@Value("INVALID-UNITTYPE")
	private static String invalidUTErrorMessage;

	@Value("INVALID-COMMONCD")
	private static String invalidCrcErrorMessage;

	@Value("INVALID-DATE-EFF")
	private static String invalidEffDateErrorMessage;

	@Value("INVALID-DATE-OFF")
	private static String invalidOffDateErrorMessage;

	public static SystemException getSystemException(String sysExceptionMsg, BasePricingMessages basePricingMsg) {
		return new SystemException(sysExceptionMsg, getException(basePricingMsg));
	}

	public static SystemException getSystemException(String sysExceptionMsg, BasePricingMsg basePricingMsg) {
		return new SystemException(sysExceptionMsg, getException(basePricingMsg));
	}

	public static Exception getException(BasePricingMessages basePricingMsg) {
		return basePricingMsg != null ? getException("BasePricingMsg> " + basePricingMsg)
				: getException("BasePricingMsg is null!");
	}

	public static Exception getException(BasePricingMsg basePricingMsg) {
		return basePricingMsg != null ? getException("BasePricingMsg> " + basePricingMsg)
				: getException("BasePricingMsg is null!");
	}

	public static Exception getException(String exceptionMsg) {
		return new Exception(exceptionMsg);
	}

	// parse string to Local Date
	public static LocalDate convertStringToLocalDate(String date) {
		return date == null ? null : LocalDate.parse(date);
	}



	
}
