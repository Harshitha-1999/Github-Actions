package com.albertsons.me01r.baseprice.enumObj;

public enum ValMsgTypeEnum {
	ERROR("E"),
	WARNING("W"),	
	PROCESS("P"),
	INFORMATION("I"),
	UPDATE("U");
	
	String msgTypeInd;
	
	ValMsgTypeEnum(String msgTypeInd) {
		this.msgTypeInd = msgTypeInd;
	}

	public String getMsgTypeInd() {
		return msgTypeInd;
	}

}