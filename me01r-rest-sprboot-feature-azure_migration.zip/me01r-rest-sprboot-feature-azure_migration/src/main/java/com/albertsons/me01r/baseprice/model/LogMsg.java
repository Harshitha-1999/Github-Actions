package com.albertsons.me01r.baseprice.model;

import java.sql.Timestamp;

public class LogMsg {

	private Integer crcId;
	private Integer cic;
	private Integer unitType;
	private String rogCd;
	private String rtlSection;
	private String paStoreInfo;
	private String rcmdLvl;
	private double rcmdPrc;
	private Integer scenarioId;
	private String scenarioNm;
	private String effStrtDt;
	private String effEndDt;
	private String scenarioFl;
	private double projectSls;
	private double projectMgn;
	private Integer projectUnt;
	private Integer priceFctr;
	private Integer priceRsnCd;
	private Integer upcCountry;
	private Integer upcSystem;
	private Integer upcManuf;
	private Integer upcSales;
	private String statCd;
	private String coMsgCd;
	private String msgNm;
	private String inbdFileTypCd;
	private String remTxt;
	private String msgSysCd;
	private Timestamp lstUpdtUsrTs;
	private String lstUpdtUsrId;
	private String crtUsrId;
	private Timestamp createTimeStamp;
	private String rptIndicator;
	private int recordCount;
	private String requestId;
	private int totalCount;
	
	public Integer getCrcId() {
		return crcId;
	}

	public void setCrcId(Integer crcId) {
		this.crcId = crcId;
	}

	public Integer getCic() {
		return cic;
	}

	public void setCic(Integer cic) {
		this.cic = cic;
	}

	public Integer getUnitType() {
		return unitType;
	}

	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public String getRtlSection() {
		return rtlSection;
	}

	public void setRtlSection(String rtlSection) {
		this.rtlSection = rtlSection;
	}

	public String getPaStoreInfo() {
		return paStoreInfo;
	}

	public void setPaStoreInfo(String paStoreInfo) {
		this.paStoreInfo = paStoreInfo;
	}

	public String getRcmdLvl() {
		return rcmdLvl;
	}

	public void setRcmdLvl(String rcmdLvl) {
		this.rcmdLvl = rcmdLvl;
	}

	public double getRcmdPrc() {
		return rcmdPrc;
	}

	public void setRcmdPrc(double rcmdPrc) {
		this.rcmdPrc = rcmdPrc;
	}

	public Integer getScenarioId() {
		return scenarioId;
	}

	public void setScenarioId(Integer scenarioId) {
		this.scenarioId = scenarioId;
	}

	public String getScenarioNm() {
		return scenarioNm;
	}

	public void setScenarioNm(String scenarioNm) {
		this.scenarioNm = scenarioNm;
	}

	public String getEffStrtDt() {
		return effStrtDt;
	}

	public void setEffStrtDt(String effStrtDt) {
		this.effStrtDt = effStrtDt;
	}

	public String getEffEndDt() {
		return effEndDt;
	}

	public void setEffEndDt(String effEndDt) {
		this.effEndDt = effEndDt;
	}

	public String getScenarioFl() {
		return scenarioFl;
	}

	public void setScenarioFl(String scenarioFl) {
		this.scenarioFl = scenarioFl;
	}

	public double getProjectSls() {
		return projectSls;
	}

	public void setProjectSls(double projectSls) {
		this.projectSls = projectSls;
	}

	public double getProjectMgn() {
		return projectMgn;
	}

	public void setProjectMgn(double projectMgn) {
		this.projectMgn = projectMgn;
	}

	public Integer getProjectUnt() {
		return projectUnt;
	}

	public void setProjectUnt(Integer projectUnt) {
		this.projectUnt = projectUnt;
	}

	public Integer getPriceFctr() {
		return priceFctr;
	}

	public void setPriceFctr(Integer priceFctr) {
		this.priceFctr = priceFctr;
	}

	public Integer getPriceRsnCd() {
		return priceRsnCd;
	}

	public void setPriceRsnCd(Integer priceRsnCd) {
		this.priceRsnCd = priceRsnCd;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public Integer getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(Integer upcManuf) {
		this.upcManuf = upcManuf;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public String getStatCd() {
		return statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public String getMsgNm() {
		return msgNm;
	}

	public void setMsgNm(String msgNm) {
		this.msgNm = msgNm;
	}

	public String getInbdFileTypCd() {
		return inbdFileTypCd;
	}

	public void setInbdFileTypCd(String inbdFileTypCd) {
		this.inbdFileTypCd = inbdFileTypCd;
	}

	public String getRemTxt() {
		return remTxt;
	}

	public void setRemTxt(String remTxt) {
		this.remTxt = remTxt;
	}

	public String getMsgSysCd() {
		return msgSysCd;
	}

	public void setMsgSysCd(String msgSysCd) {
		this.msgSysCd = msgSysCd;
	}

	public Timestamp getLstUpdtUsrTs() {
		return lstUpdtUsrTs;
	}

	public void setLstUpdtUsrTs(Timestamp lstUpdtUsrTs) {
		this.lstUpdtUsrTs = lstUpdtUsrTs;
	}

	public String getLstUpdtUsrId() {
		return lstUpdtUsrId;
	}

	public void setLstUpdtUsrId(String lstUpdtUsrId) {
		this.lstUpdtUsrId = lstUpdtUsrId;
	}

	public String getCrtUsrId() {
		return crtUsrId;
	}

	public void setCrtUsrId(String crtUsrId) {
		this.crtUsrId = crtUsrId;
	}

	// TODO
	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();

		return sb.toString();
	}

	public String getCoMsgCd() {
		return coMsgCd;
	}

	public void setCoMsgCd(String coMsgCd) {
		this.coMsgCd = coMsgCd;
	}

	public Timestamp getCreateTimeStamp() {
		return createTimeStamp;
	}

	public void setCreateTimeStamp(Timestamp createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}

	public String getRptIndicator() {
		return rptIndicator;
	}

	public void setRptIndicator(String rptIndicator) {
		this.rptIndicator = rptIndicator;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
}
