package com.albertsons.me01r.baseprice.model;

import java.util.List;

//TODO Add in all required fields
public class BasePricingMsgJson {

	private String UUID;
	private boolean isPriceArea = false;
	private boolean isStoreSpecific = false;
	private boolean isCrcPricing = false;
	private String crcId;
	private String corpItemCd;
	private String unitType;
	private String rogCd;
	private String retailSection;
	private String paStoreInfo;
	private String suggLevel;
	private String suggPrice;
	private String scenarioId;
	private String scenarioName;
	private String lastUpdUserId;
	private String lastUpdUserTs;
	private String effectiveStartDt;
	private String effectiveEndDt;
	private String scenarioFlg;
	private String projectedSales;
	private String projectedMargin;
	private String projectedUnits;
	private String priceFactor;
	private String priceOverrideReason;
	private boolean hasStoreSplit = false;
	private boolean isItemOnPromotion;
	private String updatedEffectiveStartDt;
	private String updatedEffectivEndtDt;
	private Boolean isMeatItem = false;
	private Boolean hasOptionalCut = false;
	private Boolean isOptionalCut = false;
	private List<OptionalCutDetail> optionalCutDetails;
	private boolean isLtsPresent;
	private int recordCount;
	private String requestId;
	private int totalCount;
	private String startDateDueToPromotion;
	private String inboundEffectiveStartDt;
	private String inboundEffectivEndtDt;
	private Integer baseCutCic;
	private String exceptionMessage;
	private String baseRetailSection;
	private boolean hasOptionalInitialPriced;
	private String reason;
	private String reasonType;
	
	public String getBaseRetailSection() {
		return baseRetailSection;
	}

	public void setBaseRetailSection(String baseRetailSection) {
		this.baseRetailSection = baseRetailSection;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("BasePricingMsg: [crcId=");
		sb.append(crcId);
		sb.append(", corpItemCd=");
		sb.append(corpItemCd);
		sb.append(", unitType=");
		sb.append(unitType);
		sb.append(", rogCd=");
		sb.append(rogCd);
		sb.append(", isPriceArea=");
		sb.append(isPriceArea);
		sb.append(", isStoreSpecific=");
		sb.append(isStoreSpecific);
		sb.append(", isCrcPricing=");
		sb.append(isCrcPricing);
		sb.append(", retailSection=");
		sb.append(retailSection);
		sb.append(", paStoreInfo=");
		sb.append(paStoreInfo);
		sb.append(", suggLevel=");
		sb.append(suggLevel);
		sb.append(", suggPrice=");
		sb.append(suggPrice);
		sb.append(", scenarioId=");
		sb.append(scenarioId);
		sb.append(", scenarioName=");
		sb.append(scenarioName);
		sb.append(", lastUpdUserId=");
		sb.append(lastUpdUserId);
		sb.append(", lastUpdUserTs=");
		sb.append(lastUpdUserTs);
		sb.append(", effectiveStartDt=");
		sb.append(effectiveStartDt);
		sb.append(", effectiveEndDt=");
		sb.append(effectiveEndDt);
		sb.append(", scenarioFlg=");
		sb.append(scenarioFlg);
		sb.append(", projectedSales=");
		sb.append(projectedSales);
		sb.append(", projectedMargin=");
		sb.append(projectedMargin);
		sb.append(", projectedUnits=");
		sb.append(projectedUnits);
		sb.append(", priceOverrideReason=");
		sb.append(priceOverrideReason);
		sb.append(", UUID=");
		sb.append(UUID);
		sb.append("]");

		return sb.toString();
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}

	public boolean isPriceArea() {
		return isPriceArea;
	}

	public void setPriceArea(boolean isPriceArea) {
		this.isPriceArea = isPriceArea;
	}

	public boolean isStoreSpecific() {
		return isStoreSpecific;
	}

	public void setStoreSpecific(boolean isStoreSpecific) {
		this.isStoreSpecific = isStoreSpecific;
	}

	public boolean isCrcPricing() {
		return isCrcPricing;
	}

	public void setCrcPricing(boolean isCrcPricing) {
		this.isCrcPricing = isCrcPricing;
	}

	public String getCrcId() {
		return crcId;
	}

	public void setCrcId(String crcId) {
		this.crcId = crcId;
	}

	public String getCorpItemCd() {
		return corpItemCd;
	}

	public void setCorpItemCd(String corpItemCd) {
		this.corpItemCd = corpItemCd;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public String getRetailSection() {
		return retailSection;
	}

	public void setRetailSection(String retailSection) {
		this.retailSection = retailSection;
	}

	public String getPaStoreInfo() {
		return paStoreInfo;
	}

	public void setPaStoreInfo(String paStoreInfo) {
		this.paStoreInfo = paStoreInfo;
	}

	public String getSuggLevel() {
		return suggLevel;
	}

	public void setSuggLevel(String suggLevel) {
		this.suggLevel = suggLevel;
	}

	public String getSuggPrice() {
		return suggPrice;
	}

	public void setSuggPrice(String suggPrice) {
		this.suggPrice = suggPrice;
	}

	public String getScenarioId() {
		return scenarioId;
	}

	public void setScenarioId(String scenarioId) {
		this.scenarioId = scenarioId;
	}

	public String getScenarioName() {
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	public String getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public String getLastUpdUserTs() {
		return lastUpdUserTs;
	}

	public void setLastUpdUserTs(String lastUpdUserTs) {
		this.lastUpdUserTs = lastUpdUserTs;
	}

	public String getEffectiveStartDt() {
		return effectiveStartDt;
	}

	public void setEffectiveStartDt(String effectiveStartDt) {
		this.effectiveStartDt = effectiveStartDt;
	}

	public String getEffectiveEndDt() {
		return effectiveEndDt;
	}

	public void setEffectiveEndDt(String effectiveEndDt) {
		this.effectiveEndDt = effectiveEndDt;
	}

	public String getScenarioFlg() {
		return scenarioFlg;
	}

	public void setScenarioFlg(String scenarioFlg) {
		this.scenarioFlg = scenarioFlg;
	}

	public String getProjectedSales() {
		return projectedSales;
	}

	public void setProjectedSales(String projectedSales) {
		this.projectedSales = projectedSales;
	}

	public String getProjectedMargin() {
		return projectedMargin;
	}

	public void setProjectedMargin(String projectedMargin) {
		this.projectedMargin = projectedMargin;
	}

	public String getProjectedUnits() {
		return projectedUnits;
	}

	public void setProjectedUnits(String projectedUnits) {
		this.projectedUnits = projectedUnits;
	}

	public String getPriceFactor() {
		return priceFactor;
	}

	public void setPriceFactor(String priceFactor) {
		this.priceFactor = priceFactor;
	}

	public String getPriceOverrideReason() {
		return priceOverrideReason;
	}

	public void setPriceOverrideReason(String priceOverrideReason) {
		this.priceOverrideReason = priceOverrideReason;
	}

	public String getUpdatedEffectiveStartDt() {
		return updatedEffectiveStartDt;
	}

	public void setUpdatedEffectiveStartDt(String updatedEffectiveStartDt) {
		this.updatedEffectiveStartDt = updatedEffectiveStartDt;
	}

	public String getUpdatedEffectivEndtDt() {
		return updatedEffectivEndtDt;
	}

	public void setUpdatedEffectivEndtDt(String updatedEffectivEndtDt) {
		this.updatedEffectivEndtDt = updatedEffectivEndtDt;
	}

	public Boolean getIsMeatItem() {
		return isMeatItem;
	}

	public void setIsMeatItem(Boolean isMeatItem) {
		this.isMeatItem = isMeatItem;
	}

	public Boolean getHasOptionalCut() {
		return hasOptionalCut;
	}

	public void setHasOptionalCut(Boolean hasOptionalCut) {
		this.hasOptionalCut = hasOptionalCut;
	}

	public Boolean getIsOptionalCut() {
		return isOptionalCut;
	}

	public void setIsOptionalCut(Boolean isOptionalCut) {
		this.isOptionalCut = isOptionalCut;
	}

	public List<OptionalCutDetail> getOptionalCutDetails() {
		return optionalCutDetails;
	}

	public void setOptionalCutDetails(List<OptionalCutDetail> optionalCutDetails) {
		this.optionalCutDetails = optionalCutDetails;
	}

	public boolean isLtsPresent() {
		return isLtsPresent;
	}

	public void setLtsPresent(boolean isLtsPresent) {
		this.isLtsPresent = isLtsPresent;
	}

	public boolean isItemOnPromotion() {
		return isItemOnPromotion;
	}

	public void setItemOnPromotion(boolean isItemOnPromotion) {
		this.isItemOnPromotion = isItemOnPromotion;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public String getStartDateDueToPromotion() {
		return startDateDueToPromotion;
	}

	public void setStartDateDueToPromotion(String startDateDueToPromotion) {
		this.startDateDueToPromotion = startDateDueToPromotion;
	}

	public String getInboundEffectiveStartDt() {
		return inboundEffectiveStartDt;
	}

	public void setInboundEffectiveStartDt(String inboundEffectiveStartDt) {
		this.inboundEffectiveStartDt = inboundEffectiveStartDt;
	}

	public String getInboundEffectivEndtDt() {
		return inboundEffectivEndtDt;
	}

	public void setInboundEffectivEndtDt(String inboundEffectivEndtDt) {
		this.inboundEffectivEndtDt = inboundEffectivEndtDt;
	}

	public Integer getBaseCutCic() {
		return baseCutCic;
	}

	public void setBaseCutCic(Integer baseCutCic) {
		this.baseCutCic = baseCutCic;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public boolean isHasOptionalInitialPriced() {
		return hasOptionalInitialPriced;
	}

	public void setHasOptionalInitialPriced(boolean hasOptionalInitialPriced) {
		this.hasOptionalInitialPriced = hasOptionalInitialPriced;
	}

	public boolean isHasStoreSplit() {
		return hasStoreSplit;
	}

	public void setHasStoreSplit(boolean hasStoreSplit) {
		this.hasStoreSplit = hasStoreSplit;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReasonType() {
		return reasonType;
	}

	public void setReasonType(String reasonType) {
		this.reasonType = reasonType;
	}

}
