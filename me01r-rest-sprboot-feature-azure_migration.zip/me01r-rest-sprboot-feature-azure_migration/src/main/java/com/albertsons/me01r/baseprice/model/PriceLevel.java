package com.albertsons.me01r.baseprice.model;

/**
 * Price Level is defined as either "Price Area" with code "PA" 
 * or "store" defined with code "store".
 *
 */
public enum PriceLevel {
	
	PA("PA"),
	Store("Store");
	
	private final String level;
	
	PriceLevel( String level ) {
		this.level = level;
	}

	public String getLevel() {
		return level;
	}
		
	@Override
	public String toString() {
		return this.level;
	}
}
