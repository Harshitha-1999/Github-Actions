package com.albertsons.me01r.baseprice.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.albertsons.me01r.baseprice.dao.ValidateCommonDAO;
import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonProcessService;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

@Service
public class CommonValidationServiceImpl implements CommonValidationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidationServiceImpl.class);
	@Autowired
	ValidateCommonDAO validateCommonDAO;

	@Autowired
	ValidatePriceAreaDAO validatePriceAreaDAO;

	@Autowired
	ValidateStorePriceDAO validateStorePriceDAO;

	@Autowired
	private CommonProcessService commonProcessService;

	@Override
	public CommonContext getCommonValidationContext(BasePricingMsg basePricingMsg) {

		CommonContext commonContext = new CommonContext();

		try {
			commonContext.setRogExistChkResult(validateRogCd(basePricingMsg.getRogCd()));
			if (basePricingMsg.isPriceArea()) {
				commonContext.setCicInfo(fetchCicInformation(basePricingMsg));
				// fetch retail section from SSITMURX
				if (!CollectionUtils.isEmpty(commonContext.getCicInfo())) {
					String retailSection = commonContext.getCicInfo().get(0).getRetailSection();
					basePricingMsg.setRetailSection(retailSection);
				}
				commonContext.setRetailSectionPriceAreaExist(validateRetailSectionPriceArea(basePricingMsg));
				if (!basePricingMsg.getIsMeatItem()) {
					checkIfCicIsMeatItem(basePricingMsg, commonContext.getCicInfo());
				}

				if (!checkDivSmicExclusion(basePricingMsg, commonContext.getCicInfo())) {
					commonProcessService.validateEffectiveStartDatePA(basePricingMsg, commonContext.getCicInfo(),
							commonContext);
					commonContext.setSmicExclusion(false);
				} else {
					commonContext.setSmicExclusion(true);
				}
				updateCicInfoPriceArea(basePricingMsg, commonContext.getCicInfo());
			}
			if (basePricingMsg.isStoreSpecific()) {
				commonContext.setCicInfo(fetchCicInformation(basePricingMsg));
				// fetch retail section from SSITMURX
				if (!CollectionUtils.isEmpty(commonContext.getCicInfo())) {
					String retailSection = commonContext.getCicInfo().get(0).getRetailSection();
					basePricingMsg.setRetailSection(retailSection);
				}
				commonContext.setStoreExistChkResult(validateStore(basePricingMsg));
				if (!basePricingMsg.getIsMeatItem()) {
					checkIfCicIsMeatItem(basePricingMsg, commonContext.getCicInfo());
				}
				if (!checkDivSmicExclusion(basePricingMsg, commonContext.getCicInfo())) {
					commonProcessService.validateEffectiveStartDateStoreSpecific(basePricingMsg,
							commonContext.getCicInfo(), commonContext);
					commonContext.setSmicExclusion(false);
				} else {
					commonContext.setSmicExclusion(true);
				}
				updateCicInfoStoreSpecific(basePricingMsg, commonContext.getCicInfo());
			}

		} catch (SystemException e) {
			LOGGER.error("Failed to validate JSON {}", basePricingMsg, e);
		}

		return commonContext;
	}

	private boolean checkDivSmicExclusion(BasePricingMsg basePricingMsg, List<UPCItemDetail> cicInfo) {
		String smicExclusionDetail = PropertiesUtils.getProperty("SMIC_CTGRY");
		String grpCdExclusionDetail = PropertiesUtils.getProperty("GRP_CD");
		String divisionDetailForSmicExclusion = PropertiesUtils.getProperty("DIV_SMIC");
		if (cicInfo.stream()
				.anyMatch(cic -> divisionDetailForSmicExclusion.contains(cic.getDivision())
						&& smicExclusionDetail.contains(cic.getSmic()))
				|| cicInfo.stream().anyMatch(cic -> divisionDetailForSmicExclusion.contains(cic.getDivision())
						&& grpCdExclusionDetail.contains(cic.getGroupCode()))) {
			return true;
		}

		return false;
	}

	@Override
	public UPCItemDetail fetchItemBibSwitches(UPCItemDetail upcItemDetail, BasePricingMsg basePriceMsg)
			throws SystemException {

		UPCItemDetail item = validatePriceAreaDAO.fetchBibSwitches(upcItemDetail, basePriceMsg);

		return item;
	}

	@Override
	public int validateRogCd(String rogCd) throws SystemException {
		return validateCommonDAO.validateRogCd(rogCd);
	}

	private List<UPCItemDetail> fetchCicInformation(BasePricingMsg basePricingMsg) throws SystemException {
		List<UPCItemDetail> itemDetails = validatePriceAreaDAO.fetchCicInformation(basePricingMsg);
		return itemDetails;
	}

	private void updateCicInfoPriceArea(BasePricingMsg basePricingMsg, List<UPCItemDetail> itemDetails)
			throws SystemException {

		if (!CollectionUtils.isEmpty(itemDetails)) {

			Double priceDiffPercentage = validatePriceAreaDAO.fetchPriceDiff(basePricingMsg.getRogCd());
			itemDetails.forEach(item -> {
				fetchInitialPrice(item);
				Double initialPrice = item.getInitialPrice();
				item.setInitialPrice(initialPrice);

				if (initialPrice > 0.00) {
					item.setInitialPrice(false);
					item.setPendingPrice(true);
					// check price difference validation
					try {
						validatePriceDiffRange(item, priceDiffPercentage, basePricingMsg);
					} catch (SystemException e) {
						item.setInitialPrice(true);
						LOGGER.info("No Initial Price for CIC");
					}
				} else {
					item.setInitialPrice(true);
					item.setValidPriceDiff(true);
					item.setPriceValid(true);
				}
			});
		}
	}

	private void checkIfCicIsMeatItem(BasePricingMsg basePricingMsg, List<UPCItemDetail> itemDetails) {
		try {
			String ringValue = PropertiesUtils.getProperty("RING_VAL");
			if (null != basePricingMsg.getOptionalCutDetails()) {
				basePricingMsg.setOptionalCutDetails(new ArrayList<>());
			}
			if (itemDetails.stream()
					.anyMatch(cic -> !StringUtils.isEmpty(cic.getRing()) && ringValue.contains(cic.getRing()))) {
				basePricingMsg.setIsMeatItem(true);
				basePricingMsg.setBaseCutCic(basePricingMsg.getCorpItemCd());
				basePricingMsg.setBaseRetailSection(basePricingMsg.getRetailSection());
				List<OptionalCutDetail> optionalCutDetails = new ArrayList<OptionalCutDetail>();
				if (basePricingMsg.isPriceArea()) {
					optionalCutDetails = validatePriceAreaDAO.fetchOptionalCuts(basePricingMsg);
				}
				if (basePricingMsg.isStoreSpecific()) {
					optionalCutDetails = validateStorePriceDAO.fetchOptionalCuts(basePricingMsg);
				}
				if (!CollectionUtils.isEmpty(optionalCutDetails)) {
					basePricingMsg.setHasOptionalCut(true);
					basePricingMsg.setOptionalCutDetails(optionalCutDetails);
				} else {
					basePricingMsg.setHasOptionalCut(false);
				}
			} else {
				basePricingMsg.setIsMeatItem(false);
				basePricingMsg.setHasOptionalCut(false);
			}
		} catch (SystemException e) {
			basePricingMsg.setIsMeatItem(false);
			basePricingMsg.setHasOptionalCut(false);
		}
	}

	private List<UPCItemDetail> updateCicInfoStoreSpecific(BasePricingMsg basePricingMsg,
			List<UPCItemDetail> itemDetails) throws SystemException {
		if (!CollectionUtils.isEmpty(itemDetails)) {
			Double priceDiffPercentage = validatePriceAreaDAO.fetchPriceDiff(basePricingMsg.getRogCd());
			itemDetails.forEach(item -> {
				item.setPriceArea(basePricingMsg.getPaStoreInfo());
				Double initialPrice = fetchPriceIfPaPriced(item, basePricingMsg);
				item.setInitialPrice(initialPrice);
				if (initialPrice > 0.00) {
					// item.setInitialPrice(false);
					item.setUpcExists(true);
					item.setPriceValid(true);
					// check price difference validation
					try {
						validatePriceDiffRangeStoreSpecific(item, priceDiffPercentage, basePricingMsg);
					} catch (SystemException e) {
						LOGGER.info("No Initial Price for CIC");
					}
				} else {
					// item.setInitialPrice(true);
					item.setUpcExists(false);
					item.setValidPriceDiff(true);
					item.setPriceValid(true);
				}
			});
		}
		return itemDetails;
	}

	private void updateReasonAndReasonType(double suggPrice, Double initialPrice, Double price, int factor,
			UPCItemDetail item, BasePricingMsg basePricingMsg) {
		if (suggPrice > initialPrice) {
			item.setReason("OA");
			item.setReasonType("A");
			basePricingMsg.setReason("OA");
			basePricingMsg.setReasonType("A");
		}
		if (suggPrice < initialPrice) {
			item.setReason("OB");
			item.setReasonType("D");
			basePricingMsg.setReason("OB");
			basePricingMsg.setReasonType("D");
		}

		if (basePricingMsg.getSuggPrice().doubleValue() == price && basePricingMsg.getPriceFactor() == factor
				&& !basePricingMsg.isHasStoreSplit()) {
			item.setPriceValid(false);
		} else {
			item.setPriceValid(true);
			if (basePricingMsg.isHasStoreSplit()) {
				item.setReason(basePricingMsg.getReason());
				item.setReasonType(basePricingMsg.getReasonType());
			}
		}
	}

	private UPCItemDetail validatePriceDiffRange(UPCItemDetail item, Double priceDiffPercentage,
			BasePricingMsg basePricingMsg) throws SystemException {
		if (basePricingMsg.getPriceFactor() != 0 && basePricingMsg.getSuggPrice() != 0) {
			validatePriceAreaDAO.fetchPenPriceEffDate(item, basePricingMsg.getEffectiveStartDt());
			Double calculatedPriceDiffPercentage = calculatePriceDiff(item, basePricingMsg);
			if (calculatedPriceDiffPercentage > priceDiffPercentage) {
				item.setValidPriceDiff(false);
			} else {
				item.setValidPriceDiff(true);
			}
		} else {
			item.setValidPriceDiff(true);
		}
		return item;
	}

	private UPCItemDetail validatePriceDiffRangeStoreSpecific(UPCItemDetail item, Double priceDiffPercentage,
			BasePricingMsg basePricingMsg) throws SystemException {
		if (basePricingMsg.getPriceFactor() != 0 && basePricingMsg.getSuggPrice() != 0) {
			validateStorePriceDAO.fetchStorePriceEffDate(item, basePricingMsg.getEffectiveStartDt());
			Double calculatedPriceDiffPercentage = calculatePriceDiff(item, basePricingMsg);
			if (calculatedPriceDiffPercentage > priceDiffPercentage) {
				item.setValidPriceDiff(false);
			} else {
				item.setValidPriceDiff(true);
			}
		} else {
			item.setValidPriceDiff(true);
		}
		return item;
	}

	private Double calculatePriceDiff(UPCItemDetail item, BasePricingMsg basePricingMsg) {
		Double calculatedPriceDiff = 0.00;
		Double calculatedPriceDiffPercentage = 0.00;
		Double currentPrice = 0.00;
		int currentFactor = 1;
		Double unitPrice = 0.01;
		if (item.getEffectivePenPriceStartDate() == null && item.getInitialFactor() != 0) {
			unitPrice = item.getInitialPrice() / item.getInitialFactor();
			calculatedPriceDiff = unitPrice - basePricingMsg.getSuggPrice() / basePricingMsg.getPriceFactor();
			currentPrice = item.getInitialPrice();
			currentFactor = item.getInitialFactor();
			String reason = item.getInitialReason().startsWith("O") ? item.getInitialReason()
					: "O".concat(item.getInitialReason());
			item.setReason(reason);
			item.setReasonType(item.getInitialReasonType());

		} else if (item.getPendingFactor() != 0) {
			unitPrice = item.getPendingPrice() / item.getPendingFactor();
			calculatedPriceDiff = item.getPendingPrice() / item.getPendingFactor()
					- basePricingMsg.getSuggPrice() / basePricingMsg.getPriceFactor();
			currentPrice = item.getPendingPrice();
			currentFactor = item.getPendingFactor();
			String reason = item.getPendingReason().startsWith("O") ? item.getPendingReason()
					: "O".concat(item.getPendingReason());
			item.setReason(reason);
			item.setReasonType(item.getPendingReasonType());
		}
		basePricingMsg.setReason(item.getReason());
		basePricingMsg.setReasonType(item.getReasonType());
		calculatedPriceDiffPercentage = (Math.abs(calculatedPriceDiff) / unitPrice) * 100;
		// update value of reason and reason type
		updateReasonAndReasonType(basePricingMsg.getSuggPrice() / basePricingMsg.getPriceFactor(), unitPrice,
				currentPrice, currentFactor, item, basePricingMsg);
		return calculatedPriceDiffPercentage;
	}

	private void fetchInitialPrice(UPCItemDetail item) {
		try {
			validatePriceAreaDAO.fetchInitialPrice(item);
		} catch (SystemException e) {
			LOGGER.info("No Initial Price for CIC {}", item);
		}
	}

	private Double fetchPriceIfPaPriced(UPCItemDetail item, BasePricingMsg basePricingMsg) {
		try {
			return validateStorePriceDAO.checkUpcIsPaPriced(item, basePricingMsg);

		} catch (SystemException e) {
			LOGGER.info("UPC is not PA priced {}", item);
			return 0.00;
		}
	}

	private int validateRetailSectionPriceArea(BasePricingMsg basePricingMsg) throws SystemException {
		return validatePriceAreaDAO.validateRetailSectionPriceArea(basePricingMsg);
	}

	private int validateStore(BasePricingMsg basePricingMsg) throws SystemException {
		return validateStorePriceDAO.validateStore(basePricingMsg);
	}

}
