package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.StorePriceValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 8)
public class StorePriceValidatorRule8 implements StorePriceValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(StorePriceValidatorRule8.class);

	@Value("INVALID-FACILITY")
	private String invalidFacility;

	@Value("INVALID-ROG-RETSECT-PA")
	private String invalidRog;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		if (basePricingMsg.isStoreSpecific()) {
			//LOGGER.debug("StorePriceValidatorRule8 {}", context.getCommonContext().getStoreExistChkResult());
			if (!context.getCommonContext().isStoreExist() && !context.getErrorTypeMsgList().contains(invalidRog)) {
				// && !context.getErrorType().getMsgList().contains(invalidRog)) {
				LOGGER.error("INVALID-FACILITY : {}", basePricingMsg.getPaStoreInfo());
				// context.getErrorType().getMsgList().add(invalidFacility);
				context.getErrorTypeMsgList().add(invalidFacility);
			}
			//LOGGER.debug("StorePriceValidatorRule8 OK.");
		}
	}
}
