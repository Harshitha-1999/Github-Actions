package com.albertsons.me01r.baseprice.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceConfiguration {
	@Value("${spring.datasource.url}")
	String dataSourceURL;
	@Value("${spring.datasource.driverClassName}")
	String driverClassName;
	@Value("${spring.datasource.username}")
	String userName;
	@Value("${spring.datasource.password}")
	String password;

	@Bean
	public DataSource getDataSource() {
		HikariConfig config = new HikariConfig();
		config.setDriverClassName(driverClassName);
		config.setJdbcUrl(dataSourceURL);
		config.setUsername(userName);
		config.setPassword(password);
		return new HikariDataSource(config);
	}
}
