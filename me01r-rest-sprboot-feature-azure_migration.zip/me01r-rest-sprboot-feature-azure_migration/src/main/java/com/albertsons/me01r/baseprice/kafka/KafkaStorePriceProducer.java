package com.albertsons.me01r.baseprice.kafka;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaStorePriceProducer {

	protected final static Logger LOGGER = LoggerFactory.getLogger(KafkaStorePriceProducer.class);

	@Autowired
	private KafkaTemplate<String, String> kakfaTemplate;
	
	@Value("${me01r.topic.store}")
	private String topicBasePricingStoreInput;

	private static final String kafkaErrorMessage = "Failed to send message in kafka message due to wrong Json format : ";

	public void sendMsg(BasePricingMessages basePricingMsgs) throws SystemException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info("sending msg='{}'", basePricingMsgs);
		}

		try {
			String msg = new ObjectMapper().writeValueAsString(basePricingMsgs);
			Message<String> message = MessageBuilder.withPayload(msg)
					.setHeader(KafkaHeaders.TOPIC, topicBasePricingStoreInput)
					.build();
			kakfaTemplate.send(message);

		} catch (KafkaException jse) {
			LOGGER.error(kafkaErrorMessage, jse);
			throw BasePriceUtil.getSystemException(kafkaErrorMessage, basePricingMsgs);
		} catch (Exception e) {
			LOGGER.error(kafkaErrorMessage, e);
			throw BasePriceUtil.getSystemException(kafkaErrorMessage, basePricingMsgs);
		}
	}
}
