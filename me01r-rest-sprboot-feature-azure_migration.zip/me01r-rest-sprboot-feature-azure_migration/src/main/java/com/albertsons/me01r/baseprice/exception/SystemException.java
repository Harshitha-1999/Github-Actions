package com.albertsons.me01r.baseprice.exception;

public class SystemException extends Exception {

	private static final long serialVersionUID = 7834517676292464647L;

	public SystemException(String systemMsg, Exception cause) {
		super(systemMsg, cause);
	}
}
