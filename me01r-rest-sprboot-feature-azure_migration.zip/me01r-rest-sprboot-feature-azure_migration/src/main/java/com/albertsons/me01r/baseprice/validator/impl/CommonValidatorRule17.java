package com.albertsons.me01r.baseprice.validator.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 17)
public class CommonValidatorRule17 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule17.class);

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule17 {}", context.getCommonContext().getCicInfo());
		if (null != context.getCommonContext().getCicInfo() && !context.getCommonContext().getCicInfo().isEmpty()) {
			if (context.getCommonContext().getCicInfo().stream().anyMatch(cic -> !cic.isPriceValid())
					&& !context.getBasePricingMsg().isHasStoreSplit()) {
				List<UPCItemDetail> inValidUpcList = context.getCommonContext().getCicInfo().stream()
						.filter(cic -> !cic.isPriceValid()).collect(Collectors.toList());
				context.getSamePriceUpc().addAll(inValidUpcList);
				LOGGER.error("Suggested Price is equal to initial price for UPC: {}", inValidUpcList);
			}
		}
		//LOGGER.debug("CommonValidatorRule17 OK.");
	}
}
