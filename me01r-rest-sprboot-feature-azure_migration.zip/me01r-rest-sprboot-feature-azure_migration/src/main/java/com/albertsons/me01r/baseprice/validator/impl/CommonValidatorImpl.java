package com.albertsons.me01r.baseprice.validator.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Qualifier("CommonValidatorImpl")
public class CommonValidatorImpl implements ValidatorImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorImpl.class);

	@Autowired
	private List<CommonValidator> commonValidators;

	@Autowired
	CommonValidationService commonValidationService;

	@Override
	public ValidationContext validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {

		//LOGGER.debug("CommonValidators validation.");

		ValidationContext udpatedContext = updateValidationContext(basePricingMsg, context);

		for (CommonValidator commonValidator : getValidators()) {
			commonValidator.validate(basePricingMsg, udpatedContext);
		}

		handleValidationResult(basePricingMsg, udpatedContext);

		return udpatedContext;
	}

	private void handleValidationResult(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		// TODO after rm all the exception throw from validators
		// need to check the ValidationContext error and/or warning type
		// if !context.getErrorType().getMsgList().isEmpty(), write the message into the
		// log and throw an exception
		// throw BasePriceUtil.getSystemException("Failed validation rule(s).",
		// basePricingMsg);
		// if warning msg only, no need to write to the DB,
		// defer it to later for updateService

	}

	private ValidationContext updateValidationContext(BasePricingMsg basePricingMsg, ValidationContext context) {
		if (context == null) {
			context = new ValidationContext();
			context.setCommonContext(commonValidationService.getCommonValidationContext(basePricingMsg));
			context.setBasePricingMsg(basePricingMsg);
		} else if (context.getCommonContext() == null) {
			context.setCommonContext(commonValidationService.getCommonValidationContext(basePricingMsg));
			context.setBasePricingMsg(basePricingMsg);
		}

		return context;
	}

	private List<CommonValidator> getValidators() {

		if (commonValidators == null) {
			LOGGER.error("No CommonValidator Available!");
			commonValidators = new ArrayList<>();
		}
		return commonValidators;
	}
}
