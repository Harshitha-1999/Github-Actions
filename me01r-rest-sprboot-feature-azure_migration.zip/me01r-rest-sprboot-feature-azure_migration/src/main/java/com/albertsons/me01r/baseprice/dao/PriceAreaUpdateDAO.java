package com.albertsons.me01r.baseprice.dao;

import java.util.List;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.PendingPriceData;

public interface PriceAreaUpdateDAO {

	public void insertItemNewPrice(List<ItemPriceData> initialPriceData) throws SystemException;

	public void insertItemPendingPrice(List<PendingPriceData> pendingPriceData) throws SystemException;

	public void updatePosBibSwitch(List<ItemPriceData> itemPriceData) throws SystemException;

	public void insertPriceHistory(List<ItemPriceData> historyPriceData, InitialPricingUpdateContext ipUpdateContext,
			PriceAreaUpdateContext paUpdateContext) throws SystemException;

	public void updateRogStatus(String rogCd, Integer corpItemCd, String updatedRogStatus, String poGuideNewItem)
			throws SystemException;

	public void updateUpcStatus(List<ItemPriceData> itemPriceDataList) throws SystemException;

	public void updatePriceForLts(List<PendingPriceData> pendingPriceDataList) throws SystemException;

	public int deletePendingItemPrice(List<PendingPriceData> pendingPriceDataList) throws SystemException;

}
