package com.albertsons.me01r.baseprice.enumObj;

public enum PromotionEnum {

	DATE_EFFECTIVE_CHANGE("W");

	String msgTypeInd;

	PromotionEnum(String msgTypeInd) {
		this.msgTypeInd = msgTypeInd;
	}

	public String getMsgTypeInd() {
		return msgTypeInd;
	}

}
