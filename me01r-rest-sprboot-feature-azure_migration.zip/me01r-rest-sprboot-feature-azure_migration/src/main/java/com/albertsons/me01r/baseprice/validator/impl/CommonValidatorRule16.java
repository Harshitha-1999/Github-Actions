package com.albertsons.me01r.baseprice.validator.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 16)
public class CommonValidatorRule16 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule16.class);

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule16 {}", context.getCommonContext().getCicInfo());
		if (null != context.getCommonContext().getCicInfo() && !context.getCommonContext().getCicInfo().isEmpty()) {
			if (context.getCommonContext().getCicInfo().stream()
					.anyMatch(cic -> cic.getRupcStatus().equalsIgnoreCase(ConstantsUtil.S))) {

				List<UPCItemDetail> inValidUpcList = context.getCommonContext().getCicInfo().stream()
						.filter(cic -> cic.getRupcStatus().equalsIgnoreCase(ConstantsUtil.S))
						.collect(Collectors.toList());
				LOGGER.error("Failed to validate UPC {}", inValidUpcList);
				// context.getSeasonalPriceDiffUpc().getupcList().addAll(inValidUpcList);
				context.getSeasonalPriceDiffUpc().addAll(inValidUpcList);
			}
		}
		//LOGGER.debug("CommonValidatorRule16 OK.");
	}
}
