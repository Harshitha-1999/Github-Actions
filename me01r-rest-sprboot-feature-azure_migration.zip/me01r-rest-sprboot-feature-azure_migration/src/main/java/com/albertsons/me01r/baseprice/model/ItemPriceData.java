package com.albertsons.me01r.baseprice.model;

public class ItemPriceData {

	private String corp;
	private String rogCd;
	private String division;
	private Integer upcManuf;
	private Integer upcSales;
	private Integer upcCountry;
	private Integer upcSystem;
	private String reason;
	private String reasonType;
	private String effectiveStartDt;
	private String paStoreInfo;
	private Integer crcId;
	private Integer cic;
	private double suggPrice;
	private Integer priceFactor;
	private String lastUpdUserId;
	private Integer unitType;
	private String sensitiveItem;
	private String sendPriceSw;
	private String sendLabelSw;
	private String sendBibDef;
	private String sendNewItmDef;
	// price history parameters
	private String priceMtd;
	private int limQty;
	private String priceFctAlt;
	private String priceAlt;
	private String ltsFlag;
	// for updating sims table
	private String rupcStatus;
	private String statusDST;
	private String updatedRogStatus;
	private String updatedRupcStatus;
	private String retStatus;
	private Integer pluCd;

	public String getCorp() {
		return corp;
	}

	public void setCorp(String corp) {
		this.corp = corp;
	}

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public Integer getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(Integer upcManuf) {
		this.upcManuf = upcManuf;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReasonType() {
		return reasonType;
	}

	public void setReasonType(String reasonType) {
		this.reasonType = reasonType;
	}

	public String getEffectiveStartDt() {
		return effectiveStartDt;
	}

	public void setEffectiveStartDt(String effectiveStartDt) {
		this.effectiveStartDt = effectiveStartDt;
	}

	public String getPaStoreInfo() {
		return paStoreInfo;
	}

	public void setPaStoreInfo(String paStoreInfo) {
		this.paStoreInfo = paStoreInfo;
	}

	public Integer getCrcId() {
		return crcId;
	}

	public void setCrcId(Integer crcId) {
		this.crcId = crcId;
	}

	public double getSuggPrice() {
		return suggPrice;
	}

	public void setSuggPrice(double suggPrice) {
		this.suggPrice = suggPrice;
	}

	public Integer getPriceFactor() {
		return priceFactor;
	}

	public void setPriceFactor(Integer priceFactor) {
		this.priceFactor = priceFactor;
	}

	public String getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(String lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public Integer getUnitType() {
		return unitType;
	}

	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}

	public String getSensitiveItem() {
		return sensitiveItem;
	}

	public void setSensitiveItem(String sensitiveItem) {
		this.sensitiveItem = sensitiveItem;
	}

	public String getSendPriceSw() {
		return sendPriceSw;
	}

	public void setSendPriceSw(String sendPriceSw) {
		this.sendPriceSw = sendPriceSw;
	}

	public String getSendLabelSw() {
		return sendLabelSw;
	}

	public void setSendLabelSw(String sendLabelSw) {
		this.sendLabelSw = sendLabelSw;
	}

	public String getSendBibDef() {
		return sendBibDef;
	}

	public void setSendBibDef(String sendBibDef) {
		this.sendBibDef = sendBibDef;
	}

	public String getSendNewItmDef() {
		return sendNewItmDef;
	}

	public void setSendNewItmDef(String sendNewItmDef) {
		this.sendNewItmDef = sendNewItmDef;
	}

	public String getPriceMtd() {
		return priceMtd;
	}

	public void setPriceMtd(String priceMtd) {
		this.priceMtd = priceMtd;
	}

	public int getLimQty() {
		return limQty;
	}

	public void setLimQty(int limQty) {
		this.limQty = limQty;
	}

	public String getPriceFctAlt() {
		return priceFctAlt;
	}

	public void setPriceFctAlt(String priceFctAlt) {
		this.priceFctAlt = priceFctAlt;
	}

	public String getPriceAlt() {
		return priceAlt;
	}

	public void setPriceAlt(String priceAlt) {
		this.priceAlt = priceAlt;
	}

	public String getLtsFlag() {
		return ltsFlag;
	}

	public void setLtsFlag(String ltsFlag) {
		this.ltsFlag = ltsFlag;
	}

	public String getRupcStatus() {
		return rupcStatus;
	}

	public void setRupcStatus(String rupcStatus) {
		this.rupcStatus = rupcStatus;
	}

	public String getStatusDST() {
		return statusDST;
	}

	public void setStatusDST(String statusDST) {
		this.statusDST = statusDST;
	}

	public String getUpdatedRogStatus() {
		return updatedRogStatus;
	}

	public void setUpdatedRogStatus(String updatedRogStatus) {
		this.updatedRogStatus = updatedRogStatus;
	}

	public String getUpdatedRupcStatus() {
		return updatedRupcStatus;
	}

	public void setUpdatedRupcStatus(String updatedRupcStatus) {
		this.updatedRupcStatus = updatedRupcStatus;
	}

	public String getRetStatus() {
		return retStatus;
	}

	public void setRetStatus(String retStatus) {
		this.retStatus = retStatus;
	}

	public Integer getCic() {
		return cic;
	}

	public void setCic(Integer cic) {
		this.cic = cic;
	}

	public Integer getPluCd() {
		return pluCd;
	}

	public void setPluCd(Integer pluCd) {
		this.pluCd = pluCd;
	}

}
