package com.albertsons.me01r.baseprice.context.update;

import java.util.List;

import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

public class StoreLevelUpdateContext {

	private CommonContext commonContext;

	private BasePricingMsg basePricingMsg;

	private List<UPCItemDetail> validUpcList;

	private List<UPCItemDetail> invalidUpcList;

	private List<StorePriceData> storePriceUpcList;

	public CommonContext getCommonContext() {
		return commonContext;
	}

	public void setCommonContext(CommonContext commonContext) {
		this.commonContext = commonContext;
	}

	public BasePricingMsg getBasePricingMsg() {
		return basePricingMsg;
	}

	public void setBasePricingMsg(BasePricingMsg basePricingMsg) {
		this.basePricingMsg = basePricingMsg;
	}

	public List<UPCItemDetail> getValidUpcList() {
		return validUpcList;
	}

	public void setValidUpcList(List<UPCItemDetail> validUpcList) {
		this.validUpcList = validUpcList;
	}

	public List<UPCItemDetail> getInvalidUpcList() {
		return invalidUpcList;
	}

	public void setInvalidUpcList(List<UPCItemDetail> invalidUpcList) {
		this.invalidUpcList = invalidUpcList;
	}

	public List<StorePriceData> getStorePriceUpcList() {
		return storePriceUpcList;
	}

	public void setStorePriceUpcList(List<StorePriceData> storePriceUpcList) {
		this.storePriceUpcList = storePriceUpcList;
	}

}
