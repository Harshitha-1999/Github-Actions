package com.albertsons.me01r.baseprice.validator;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface ValidatorImpl {
	public ValidationContext validate(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException, Exception;

}
