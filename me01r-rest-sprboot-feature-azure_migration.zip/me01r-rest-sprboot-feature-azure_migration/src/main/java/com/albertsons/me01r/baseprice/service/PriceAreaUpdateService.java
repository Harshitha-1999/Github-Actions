package com.albertsons.me01r.baseprice.service;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface PriceAreaUpdateService {

	public void addItemPrice(InitialPricingUpdateContext ipUpdateContext, PriceAreaUpdateContext paUpdateContext, ValidationContext validationContext)
			throws SystemException;

}
