package com.albertsons.me01r.baseprice.validator.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.InitialPricingValidator;
//import com.albertsons.me01r.baseprice.validator.InitialPricingValidator;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Qualifier("InitialPriceValidatorImpl")
public class InitialPriceValidatorImpl implements ValidatorImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(InitialPriceValidatorImpl.class);
	@Autowired
	private List<InitialPricingValidator> initPriceValidators;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Override
	public ValidationContext validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {

		//LOGGER.debug("InitialPricingValidator validation.");

		// TODO is there any price area SQL, if not, no need to update
		// ValidationContext udpatedContext = updateValidationContext(basePricingMsg,
		// context);

		for (InitialPricingValidator initiaValidator : getValidators()) {
			initiaValidator.validate(basePricingMsg, context);
		}

		handleValidationResult(basePricingMsg, context);

		return context;
	}

	private void handleValidationResult(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		List<ErrorMsg> errorMsgList = new ArrayList<>();
		List<ErrorMsg> discontinuedUPCErrorList = handleDiscontinuedUpc(basePricingMsg, context);
		List<ErrorMsg> seasonalUpcErrorList = handleSeasonalUpc(basePricingMsg, context);
		List<ErrorMsg> missingUpcErrorList = handleMisisingUpc(basePricingMsg, context);

		if (!CollectionUtils.isEmpty(discontinuedUPCErrorList)) {
			errorMsgList.addAll(discontinuedUPCErrorList);
		}
		if (!CollectionUtils.isEmpty(seasonalUpcErrorList)) {
			errorMsgList.addAll(seasonalUpcErrorList);
		}
		if (!CollectionUtils.isEmpty(missingUpcErrorList)) {
			errorMsgList.addAll(missingUpcErrorList);
		}
		// if ((!context.getErrorType().getMsgList().isEmpty() ||
		// !context.getInvalidPriceDiffUpc().getupcList().isEmpty()
		if ((!context.getErrorTypeMsgList().isEmpty() || !context.getInvalidPriceDiffUpc().isEmpty()
				|| !context.getSamePriceUpc().isEmpty()) && context.getCommonContext().getCicInfo().isEmpty()) {
			List<UPCItemDetail> itemDetailList = new ArrayList<>();
			List<ErrorMsg> errorList = prepareErrorMsg(basePricingMsg, itemDetailList, context.getErrorTypeMsgList(),
					context.getErrorTypeInd());
			// context.getErrorType().getMsgList(), context.getErrorType().getMsgTypeInd());
			errorMsgList.addAll(errorList);
			insertError(errorMsgList);
			throw BasePriceUtil.getSystemException("Failed validation rule(s) ", basePricingMsg);
		}
		// if (null != context.getCommonContext().getCicInfo() &&
		// (!context.getErrorType().getMsgList().isEmpty()
		if (null != context.getCommonContext().getCicInfo() && (!context.getErrorTypeMsgList().isEmpty()
				|| !context.getInvalidPriceDiffUpc().isEmpty() || !context.getSamePriceUpc().isEmpty())) {
			List<UPCItemDetail> itemDetailList = context.getCommonContext().getCicInfo();
			// check if error is present
			// if (!context.getErrorType().getMsgList().isEmpty()) {
			if (!context.getErrorTypeMsgList().isEmpty()) {
				List<ErrorMsg> errorList = prepareErrorMsg(basePricingMsg, itemDetailList,
						context.getErrorTypeMsgList(), context.getErrorTypeInd());
				// context.getErrorType().getMsgList(), context.getErrorType().getMsgTypeInd());
				errorMsgList.addAll(errorList);
				insertError(errorMsgList);
				throw BasePriceUtil.getSystemException("Failed validation rule(s) ", basePricingMsg);
			}
		}
		insertError(errorMsgList);
	}

	private List<ErrorMsg> handleDiscontinuedUpc(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getDiscontinuedUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getDiscontinuedUpc(),
					Arrays.asList(ConstantsUtil.DISCONTINUED_ITEM_INFO), context.getDiscontinuedUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleSeasonalUpc(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getSeasonalPriceDiffUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getSeasonalPriceDiffUpc(),
					Arrays.asList(ConstantsUtil.SEASONAL_ITEM), context.getSeasonalPriceDiffUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleMisisingUpc(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getMissingUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getMissingUpc(),
					Arrays.asList(ConstantsUtil.MISSING_UPC_INFO), context.getMissingUpcInd());
		}
		return null;
	}

	private void insertError(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingService.insertErrorMessage(errorMessage);
	}

	private List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd) throws SystemException {
		return errorHandlingService.prepareErrorMsg(basePriceMsg, itemDetailList, statCd, errorList);
	}

	private ValidationContext updateValidationContext(BasePricingMsg basePricingMsg, ValidationContext context) {

		// TODO: is there a need to call the PriceArea specific service
		// and update back to PriceAreaContext, then stored it in ValidationContext
		// (Similar to CommonContext handling)

		return context;
	}

	private List<InitialPricingValidator> getValidators() {

		if (initPriceValidators == null) {
			LOGGER.error("No PriceAreaValidator Available!");
			initPriceValidators = new ArrayList<>();
		}
		return initPriceValidators;
	}

}
