package com.albertsons.me01r.baseprice.kafka;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessagesJson;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.model.PriceLevel;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.GroupCodeValidateService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaStorePriceConsumer {

	@Autowired
	StorePriceService storePriceService;

	@Autowired
	private MessageHandlingService messageHandlingService;

	@Autowired
	private GroupCodeValidateService groupCodeValidateService;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private PropertiesUtils propertyUtil;

	@Value("CRC-RECORD-INCLDS-CIC")
	private String crcCicExist;
	
	private static final String KAFKA_EXCEPTION="StoreLevelProcess: Unable to Process Inbound Message ";

	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaStorePriceConsumer.class);
	
	@KafkaListener(topics = "#{'${me01r.topic.store}'}", groupId = "#{'${me01r.group}'}")
	public void onMessage(
			@Payload String message) {
		LOGGER.info("Payload : {}", message);
		InboundMessage inboundMessage = new InboundMessage(message);
		try {
			LOGGER.debug("Inside method onMessage() in KafkaStorePriceConsumer.");
			propertyUtil.loadProperties();
			groupCodeValidateService.validateGroupCode();
			processStoreMessage(inboundMessage); 
		} catch (Exception ex) {
			LOGGER.error("Error occured while processing", ex.getMessage());
			try {
				corruptMessageError(inboundMessage);
			} catch (Exception e) {
				LOGGER.error("Error occured while inserting into the error table");
			} 
		}
	}

	private void corruptMessageError(InboundMessage message)
			throws IOException, SystemException {
		BasePricingMessagesJson basePricingMsgsJson = null;
		basePricingMsgsJson = new ObjectMapper().readValue(message.getPayload(), BasePricingMessagesJson.class);
		List<ErrorMsg> baseMessageErrorList = errorHandlingService
				.prepareCorruptMessage(basePricingMsgsJson.getPriceChangeHeader());
		List<ErrorMsg> errorMsgList = baseMessageErrorList;
		errorHandlingService.insertErrorMessage(errorMsgList);
	}

	private void processStoreMessage(InboundMessage msg)
			throws IOException, SystemException {

		try {
			messageHandlingService.processIncomingMessage(msg, PriceLevel.Store);

		} catch (Exception ex) {
			try {
				corruptMessageError(msg);
			} catch (Exception e) {
				LOGGER.error("Error occured while inserting into the error table");
			} 
			LOGGER.error(KAFKA_EXCEPTION, ex);
		}
	}
}
