package com.albertsons.me01r.baseprice.service;

import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface PriceAreaService {

	public void process(ValidationContext validationContext) throws SystemException, DataIntegrityViolationException, Exception;

	public List<PendingPriceData> fetchPendingItemDetailToDelete(List<PendingPriceData> pendingPriceDataList)
			throws SystemException;
}
