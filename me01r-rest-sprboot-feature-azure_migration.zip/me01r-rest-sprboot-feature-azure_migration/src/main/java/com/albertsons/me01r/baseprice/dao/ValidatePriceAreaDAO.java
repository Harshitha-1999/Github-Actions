package com.albertsons.me01r.baseprice.dao;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;

public interface ValidatePriceAreaDAO {

	public List<UPCItemDetail> fetchCicInformation(BasePricingMsg basePricingMsg) throws SystemException;

	public UPCItemDetail fetchInitialPrice(UPCItemDetail item) throws SystemException;

	public int validateRetailSectionPriceArea(BasePricingMsg basePricingMsg) throws SystemException;

	public Double fetchPriceDiff(String rogCd) throws SystemException;

	public UPCItemDetail fetchPenPriceEffDate(UPCItemDetail item, String effectiveStartDate) throws SystemException;

	public List<Promotion> fetchPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException;

	public UPCItemDetail fetchBibSwitches(UPCItemDetail item, BasePricingMsg basePricingMsg) throws SystemException;

	public List<Promotion> fetchLTSPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException;

	public List<PendingPriceData> fetchPendingItemDetailToDelete(List<PendingPriceData> pendingPriceDataList)
			throws SystemException;

	public List<OptionalCutDetail> fetchOptionalCuts(BasePricingMsg basePricingMsg) throws SystemException;

	public UPCItemDetail fetchInitialPriceBaseCut(String item, String rog, String priceArea) throws SystemException;

}
