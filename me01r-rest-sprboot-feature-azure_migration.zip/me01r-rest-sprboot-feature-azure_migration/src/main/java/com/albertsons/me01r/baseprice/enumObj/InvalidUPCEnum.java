package com.albertsons.me01r.baseprice.enumObj;

public enum InvalidUPCEnum {

	INVALID_PRICE("W"), DISCONTINUED_UPC("E"), SEASONAL_UPC("E"), SAME_PRICE("I"), MISSING_UPC_INFO("I");

	String msgTypeInd;

	InvalidUPCEnum(String msgTypeInd) {
		this.msgTypeInd = msgTypeInd;
	}

	public String getMsgTypeInd() {
		return msgTypeInd;
	}

}
