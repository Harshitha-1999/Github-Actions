package com.albertsons.me01r.baseprice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.context.update.StoreLevelUpdateContext;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.service.StorePriceUpdateService;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Service
public class StorePriceServiceImpl implements StorePriceService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StorePriceServiceImpl.class);

	@Autowired
	@Qualifier("CommonValidatorImpl")
	ValidatorImpl commonValidatorImpl;

	@Autowired
	@Qualifier("StorePriceValidatorImpl")
	ValidatorImpl storeValidatorImpl;

	@Autowired
	StorePriceUpdateService storePriceUpdateService;

	@Autowired
	CommonValidationService commonValidationService;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private ValidateStorePriceDAO validateStorePriceDAO;

	@Override
	public void process(ValidationContext validationContext) throws SystemException, Exception {
		// check if base pricing message is null else check of error message
		if (null != validationContext.getBasePricingMsg()
				&& CollectionUtils.isEmpty(validationContext.getErrorTypeMsgList())) {
			// && CollectionUtils.isEmpty(validationContext.getErrorType().getMsgList())) {

			StoreLevelUpdateContext sLupdatedContext = performValidationAndContextSwitching(validationContext);

			if (!CollectionUtils.isEmpty(sLupdatedContext.getStorePriceUpcList())) {
				performUpdate(sLupdatedContext, validationContext);
			}

		} else {
			insertNonNumericErrorMessage(validationContext);
		}

	}

	private StoreLevelUpdateContext performValidationAndContextSwitching(ValidationContext validationContext)
			throws SystemException, Exception {

		validationContext.getBasePricingMsg().setStoreSpecific(true);
		validationContext.getBasePricingMsg()
				.setUpdatedEffectiveStartDt(validationContext.getBasePricingMsg().getEffectiveStartDt());
		validationContext.getBasePricingMsg()
				.setUpdatedEffectivEndtDt(validationContext.getBasePricingMsg().getEffectiveEndDt());
		ValidationContext updatedContext = commonValidatorImpl.validate(validationContext.getBasePricingMsg(), null);
		//LOGGER.info("ItemDetails List size: {}", updatedContext.getCommonContext().getCicInfo().size());

		// To validate store specific rules and update validation context accordingly
		updatedContext = storeValidatorImpl.validate(validationContext.getBasePricingMsg(), updatedContext);

		// Switch context from validation context to storeLevelUpdate context for
		// further processing
		StoreLevelUpdateContext sLupdatedContext = switchContext(updatedContext);

		return sLupdatedContext;

	}

	private void insertNonNumericErrorMessage(ValidationContext validationContext) throws SystemException {
		errorHandlingService.insertNonNumericErrorMessage(validationContext.getBasePricingMsgJson(),
				// validationContext.getErrorType().getMsgList());
				validationContext.getErrorTypeMsgList());
	}

	/**
	 * For all the StorePrice DB Update transactions that need to go in all at once.
	 * No need to put SELECT transactions in the scope.
	 * 
	 * @param validationContext
	 * 
	 * @param basePriceMsg
	 * @param udpatedContext
	 * @throws SystemException
	 */
	private void performUpdate(StoreLevelUpdateContext sLupdatedContext, ValidationContext validationContext)
			throws SystemException, Exception {
		if (!sLupdatedContext.getCommonContext().getCicInfo().isEmpty()) {
			try {
				storePriceUpdateService.addItemPrice(sLupdatedContext, validationContext);
			} catch (SystemException se) {

				List<String> errorList = new ArrayList<>();
				List<ErrorMsg> errorMsgList = new ArrayList<>();

				if (se.getMessage().contains(ConstantsUtil.DUPLICATE_DATA)) {

					String tableName = se.getMessage().substring(0, 8);
					String message = se.getMessage().substring(9);
					LOGGER.error("TableName: {},  Message: {}", tableName,  message);
					
					errorList.add(ConstantsUtil.SQL_EXCEPTION);
					errorMsgList = errorHandlingService.prepareErrorMsg(sLupdatedContext.getBasePricingMsg(),
							sLupdatedContext.getCommonContext().getCicInfo(), ConstantsUtil.E, errorList, tableName,
							"");

					errorHandlingService.insertErrorMessage(errorMsgList);
					throw new SystemException(ConstantsUtil.SQL_EXCEPTION + sLupdatedContext.getBasePricingMsg(), se);

				} else if (se.getMessage().contains(ConstantsUtil.SQL_EXCEPTION)) {

					errorList.add(ConstantsUtil.SQL_EXCEPTION);
					errorMsgList = errorHandlingService.prepareErrorMsg(sLupdatedContext.getBasePricingMsg(),
							sLupdatedContext.getCommonContext().getCicInfo(), ConstantsUtil.E, errorList);
					errorHandlingService.insertErrorMessage(errorMsgList);
					throw new SystemException(ConstantsUtil.SQL_EXCEPTION + sLupdatedContext.getBasePricingMsg(), se);

				} else {
					throw new SystemException(se.getMessage(), se);
				}

			}

		}
	}

	private StoreLevelUpdateContext switchContext(ValidationContext validationContext) throws SystemException {
		StoreLevelUpdateContext sLupdatedContext = new StoreLevelUpdateContext();
		if (!CollectionUtils.isEmpty(sLupdatedContext.getStorePriceUpcList())) {
			sLupdatedContext.setStorePriceUpcList(new ArrayList<>());
		}
		sLupdatedContext.setCommonContext(validationContext.getCommonContext());
		sLupdatedContext.getCommonContext().setCicInfo(validationContext.getCommonContext().getCicInfo());
		sLupdatedContext.setBasePricingMsg(validationContext.getBasePricingMsg());

		if (!CollectionUtils.isEmpty(sLupdatedContext.getCommonContext().getCicInfo())) {
			sLupdatedContext.setStorePriceUpcList(getUpdatedStorePriceUpcList(validationContext));
		}
		return sLupdatedContext;
	}

	private List<StorePriceData> getUpdatedStorePriceUpcList(ValidationContext sLupdatedContext)
			throws SystemException {
		List<StorePriceData> storePriceDataList = sLupdatedContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					StorePriceData spd = new StorePriceData();
					spd.setRogCd(itemDetail.getRogCd());
					spd.setFacility(sLupdatedContext.getBasePricingMsg().getPaStoreInfo());
					spd.setUpcManuf(itemDetail.getUpcManuf());
					spd.setUpcSales(itemDetail.getUpcSales());
					spd.setUpcCountry(itemDetail.getUpcCountry());
					spd.setUpcSystem(itemDetail.getUpcSystem());
					spd.setDateEff(sLupdatedContext.getBasePricingMsg().getEffectiveStartDt());
					spd.setDateOff(sLupdatedContext.getBasePricingMsg().getEffectiveEndDt());
					spd.setPrice(sLupdatedContext.getBasePricingMsg().getSuggPrice());
					spd.setPriceFctr(sLupdatedContext.getBasePricingMsg().getPriceFactor());
					spd.setReasonPrice(itemDetail.getReason());
					spd.setLstUpdUsrId(sLupdatedContext.getBasePricingMsg().getLastUpdUserId());
					spd.setPluCd(itemDetail.getPluCd());

					return spd;
				}).collect(Collectors.toList());

		return storePriceDataList;
	}

	// PO 171
	public List<StorePriceData> fetchStoreSpecificDetails(List<StorePriceData> storePriceUpcList,
			BasePricingMsg basePricingMsg) throws SystemException {
		return validateStorePriceDAO.fetchStoreSpecificDetails(storePriceUpcList,basePricingMsg);
	}
}
