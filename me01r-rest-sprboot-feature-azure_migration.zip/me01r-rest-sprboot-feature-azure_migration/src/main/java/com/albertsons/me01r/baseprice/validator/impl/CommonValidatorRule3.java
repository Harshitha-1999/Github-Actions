package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 3)
public class CommonValidatorRule3 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule3.class);

	@Value("PRICE-ONLY-RETAIL")
	private String errorMessage;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule3 {}", context.getCommonContext().getCicInfo());
		if (!context.getCommonContext().getCicInfo().isEmpty() && !context.getCommonContext().getCicInfo().stream()
				.allMatch(cic -> cic.getItemUsageIndicator().equalsIgnoreCase(ConstantsUtil.R))) {
			LOGGER.error("PRICE-ONLY-RETAIL FOR CIC : {}", basePricingMsg.getCorpItemCd());
			// context.getErrorType().getMsgList().add(errorMessage);
			context.getErrorTypeMsgList().add(errorMessage);
		}
		//LOGGER.debug("CommonValidatorRule3 OK.");
	}
}
