package com.albertsons.me01r.baseprice.model;

import java.time.LocalDate;

public class Promotion {
	private Integer cic;
	private String retailSection;
	private String priceArea;
	private Integer unitType;
	private String rog;
	private LocalDate startDate;
	private LocalDate endDate;
	private String promotionType;
	private Double price;
	private int priceFactor;
	private Integer upcCountry;
	private Integer upcSystem;
	private Integer upcManuf;
	private Integer upcSales;

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getPromotionType() {
		return promotionType;
	}

	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}

	public Integer getCic() {
		return cic;
	}

	public void setCic(Integer cic) {
		this.cic = cic;
	}

	public String getRetailSection() {
		return retailSection;
	}

	public void setRetailSection(String retailSection) {
		this.retailSection = retailSection;
	}

	public String getPriceArea() {
		return priceArea;
	}

	public void setPriceArea(String priceArea) {
		this.priceArea = priceArea;
	}

	public String getRog() {
		return rog;
	}

	public void setRog(String rog) {
		this.rog = rog;
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("Promotion: [corpItemCd=");
		sb.append(cic);
		sb.append(", unitType=");
		sb.append(unitType);
		sb.append(", rogCd=");
		sb.append(rog);
		sb.append(", priceArea=");
		sb.append(priceArea);
		sb.append(", retailSection=");
		sb.append(retailSection);
		sb.append(", startDate=");
		sb.append(startDate);
		sb.append(", endDate=");
		sb.append(endDate);
		sb.append("]");

		return sb.toString();
	}

	public Integer getUnitType() {
		return unitType;
	}

	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public Integer getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(Integer upcManuf) {
		this.upcManuf = upcManuf;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public int getPriceFactor() {
		return priceFactor;
	}

	public void setPriceFactor(int priceFactor) {
		this.priceFactor = priceFactor;
	}
}
