package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.InitialPricingValidator;
import com.albertsons.me01r.baseprice.validator.PriceAreaValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 4)
public class PriceAreaValidatorRule4 implements PriceAreaValidator, InitialPricingValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(PriceAreaValidatorRule4.class);

	@Value("NO-PRICE-ROG-STAT")
	private String errorMessage;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		if (basePricingMsg.isPriceArea()) {
			//LOGGER.debug("PriceAreaValidatorRule4 {}", context.getCommonContext().getCicInfo());
			if (!context.getCommonContext().getCicInfo().stream()
					.allMatch(cic -> (cic.getRetStatus().equalsIgnoreCase(ConstantsUtil.C)
							|| cic.getRetStatus().equalsIgnoreCase(ConstantsUtil.P)
							|| cic.getRetStatus().equalsIgnoreCase(ConstantsUtil.V)
							|| cic.getRetStatus().equalsIgnoreCase(ConstantsUtil.S)
							|| cic.getRetStatus().equalsIgnoreCase(ConstantsUtil.D)))) {
				LOGGER.error("NO-PRICE-ROG-STAT FOR CIC : {}", basePricingMsg.getCorpItemCd());
				// context.getErrorType().getMsgList().add(errorMessage);
				context.getErrorTypeMsgList().add(errorMessage);
			}
			//LOGGER.debug("PriceAreaValidatorRule4 OK.");
		}
	}
}
