package com.albertsons.me01r.baseprice.validator.context;

import java.util.List;

import com.albertsons.me01r.baseprice.model.UPCItemDetail;

public class PriceAreaContext {
	
	private List<UPCItemDetail> cicInfo;

}
