package com.albertsons.me01r.baseprice.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.service.PropertyLoadService;

@Component
public class PropertiesUtils {

	@Autowired
	private PropertyLoadService propertyLoad;

	static Map<String, Object> properties = new HashMap<>();

	public void loadProperties() {
		Map<String, Object> propertiesMap = propertyLoad.loadProperties();
		initializePropeties(propertiesMap);
	}

	public static void initializePropeties(Map<String, Object> propertiesMap) {
		properties = propertiesMap;
	}

	public static String getProperty(String name) {
		return (null == properties.get(name)) ? "" : properties.get(name).toString();
	}
}
