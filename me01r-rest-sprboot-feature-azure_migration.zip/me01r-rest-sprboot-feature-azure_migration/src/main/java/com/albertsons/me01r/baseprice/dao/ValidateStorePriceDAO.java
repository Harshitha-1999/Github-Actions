package com.albertsons.me01r.baseprice.dao;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;

public interface ValidateStorePriceDAO {

	public int validateStore(BasePricingMsg basePricingMsg) throws SystemException;

	public Double checkUpcIsPaPriced(UPCItemDetail item, BasePricingMsg basePricingMsg) throws SystemException;

	public List<Promotion> fetchPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException;

	public List<Promotion> fetchLTSPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException;

	public List<StorePriceData> fetchStoreSpecificDetails(List<StorePriceData> storePriceUpcList,
			BasePricingMsg basePricingMsg) throws SystemException;

	public UPCItemDetail fetchStorePriceEffDate(UPCItemDetail item, String effectiveStartDate) throws SystemException;

	public List<OptionalCutDetail> fetchOptionalCuts(BasePricingMsg basePricingMsg) throws SystemException;

	public UPCItemDetail fetchInitialPriceBaseCut(String cic, String rogCd, String paStoreInfo, String retailSection);

	public String fetchPriceArea(String rogCd, String paStoreInfo, String retailSection);
}
