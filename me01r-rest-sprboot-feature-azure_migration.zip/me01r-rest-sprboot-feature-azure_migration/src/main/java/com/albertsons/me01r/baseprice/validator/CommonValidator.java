package com.albertsons.me01r.baseprice.validator;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface CommonValidator {

	//TODO: new interface without throwing SystemException.
	// public void validate(BasePricingMsg basePricingMsg, ValidationContext context);
	
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException;
	
	//TODO can be removed as there is no more exception thrown	
    default SystemException getSystemException(String sysExceptionMsg, BasePricingMsg basePricingMsg) {     
    	return BasePriceUtil.getSystemException(sysExceptionMsg, basePricingMsg);
    } 	
}
