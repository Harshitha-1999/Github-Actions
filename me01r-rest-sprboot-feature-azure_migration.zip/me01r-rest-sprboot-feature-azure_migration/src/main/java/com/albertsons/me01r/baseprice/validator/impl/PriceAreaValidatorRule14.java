package com.albertsons.me01r.baseprice.validator.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.InitialPricingValidator;
import com.albertsons.me01r.baseprice.validator.PriceAreaValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 14)
public class PriceAreaValidatorRule14 implements PriceAreaValidator, InitialPricingValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(PriceAreaValidatorRule14.class);

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		if (basePricingMsg.isPriceArea()) {
			//LOGGER.debug("PriceAreaValidatorRule14 {}", context.getCommonContext().getCicInfo());
		if (null != context.getCommonContext().getCicInfo() && !context.getCommonContext().getCicInfo().isEmpty()) {
				if (context.getCommonContext().getCicInfo().stream()
						.anyMatch(cic -> cic.getRupcStatus().equalsIgnoreCase(ConstantsUtil.N))) {
					List<UPCItemDetail> inValidUpcList = context.getCommonContext().getCicInfo().stream()
							.filter(cic -> cic.getRupcStatus().equalsIgnoreCase(ConstantsUtil.N))
							.collect(Collectors.toList());
					context.getMissingUpc().addAll(inValidUpcList);
					// # Changed as per JIRA# PO-1215
				}
			}
		//LOGGER.debug("PriceAreaValidatorRule14 OK.");
		}
	}
}
