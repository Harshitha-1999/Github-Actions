package com.albertsons.me01r.baseprice.service;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

public interface CommonProcessService {
	public void validateEffectiveStartDatePA(BasePricingMsg basePricingMsg, List<UPCItemDetail> cicInfo,
			CommonContext commonContext) throws SystemException;
	
	public void validateEffectiveStartDateStoreSpecific(BasePricingMsg basePricingMsg, List<UPCItemDetail> cicInfo,
			CommonContext commonContext) throws SystemException;
}
