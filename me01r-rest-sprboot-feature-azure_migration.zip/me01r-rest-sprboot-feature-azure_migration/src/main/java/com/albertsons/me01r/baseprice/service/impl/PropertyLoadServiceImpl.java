package com.albertsons.me01r.baseprice.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.albertsons.me01r.baseprice.dao.PropertyLoadDAO;
import com.albertsons.me01r.baseprice.service.PropertyLoadService;

@Service
public class PropertyLoadServiceImpl implements PropertyLoadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PropertyLoadServiceImpl.class);

	@Autowired
	private PropertyLoadDAO propertyLoadDAO;

	@Override
	public Map<String, Object> loadProperties() {
		Map<String, Object> properties = new HashMap<>();

		List<Map<String, Object>> configs = propertyLoadDAO.loadProperties();
		for (Map<String, Object> config : configs) {
			properties.put((config.get("SRC_KEY_CD")).toString().trim(), (config.get("SRC_VAL")).toString().trim());
		}

		return properties;

	}

}
