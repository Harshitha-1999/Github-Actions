/* **************************************************************************
 * Copyright 2016 Safeway, Inc.
 *
 * This document/file contains proprietary data that is the property of Safeway, Inc. 
 * Information contained herein may not be used,copied or disclosed in whole or in part
 * except as permitted by a written agreement signed by an officer of Safeway.
 *
 * Unauthorized use, copying or other reproduction of this document/file
 * is prohibited by law.
 *
 ***************************************************************************/
package com.albertsons.me01r;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@PropertySource("classpath:/sql.properties")
@PropertySource("classpath:/error.properties")
public class Me01rApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(Me01rApplication.class);


	public static void main(String[] args) {
		LOGGER.debug("Main method of Me01rApplication");
		SpringApplication.run(Me01rApplication.class, args);
	}

}
