package com.albertsons.me01r.baseprice.dao;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.StorePriceData;

public interface StorePriceUpdateDAO {

	/*public void insertItemStorePrice(UPCItemDetail itemDetail, BasePricingMsg basePricingMsg) throws SystemException;*/

	public void insertItemStorePriceBatch(List<StorePriceData> storePriceUpcList) throws SystemException;

	public void updateItemStoreRetail(List<StorePriceData> updateStoreSpecificList) throws SystemException;

	public void deleteItemStoreRetail(List<StorePriceData> deleteStoreSpecificList) throws SystemException;

}
