package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 19)
public class CommonValidatorRule19 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule19.class);

	@Value("INVALID-OPT-PRICE-SW")
	private String errorMessage;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule19 {}", context.getCommonContext().getCicInfo());
		boolean isCrcPresent = context.getCommonContext().getCicInfo().stream()
				.anyMatch(cic -> !cic.getCrc().equals(ConstantsUtil.ZERO));

		if (basePricingMsg.getIsMeatItem() && (!basePricingMsg.getCrcId().equals(ConstantsUtil.ZERO) || isCrcPresent)
				&& basePricingMsg.getHasOptionalCut()) {
			LOGGER.error("You can not reprice optional items and use Common Code processing at the same time. {}",
					basePricingMsg.getCorpItemCd());
			context.getErrorTypeMsgList().add(errorMessage);
		}
		//LOGGER.debug("CommonValidatorRule19 OK.");
	}
}
