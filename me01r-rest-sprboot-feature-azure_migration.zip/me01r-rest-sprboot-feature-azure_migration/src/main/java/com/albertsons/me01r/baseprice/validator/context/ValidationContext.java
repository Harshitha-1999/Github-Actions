package com.albertsons.me01r.baseprice.validator.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.albertsons.me01r.baseprice.enumObj.InvalidUPCEnum;
import com.albertsons.me01r.baseprice.enumObj.ValMsgTypeEnum;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsgJson;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;

public class ValidationContext {

	private CommonContext commonContext;
	private PriceAreaContext priceAreaContext;
	private StorePriceContext storePriceContext;
	private BasePricingMsg basePricingMsg;
	private BasePricingMsgJson basePricingMsgJson;
	private BasePricingMessages basePricingMessages;

	private Map<ValMsgTypeEnum, List<String>> valTypeMsgMap;
	private Map<InvalidUPCEnum, List<UPCItemDetail>> invalidUPCMap;

	public ValidationContext() {
		valTypeMsgMap = new HashMap<>();
		valTypeMsgMap.put(ValMsgTypeEnum.ERROR, new ArrayList<>());
		valTypeMsgMap.put(ValMsgTypeEnum.WARNING, new ArrayList<>());
		valTypeMsgMap.put(ValMsgTypeEnum.PROCESS, new ArrayList<>());
		valTypeMsgMap.put(ValMsgTypeEnum.INFORMATION, new ArrayList<>());

		invalidUPCMap = new HashMap<>();
		invalidUPCMap.put(InvalidUPCEnum.DISCONTINUED_UPC, new ArrayList<>());
		invalidUPCMap.put(InvalidUPCEnum.INVALID_PRICE, new ArrayList<>());
		invalidUPCMap.put(InvalidUPCEnum.SEASONAL_UPC, new ArrayList<>());
		invalidUPCMap.put(InvalidUPCEnum.SAME_PRICE, new ArrayList<>());
		invalidUPCMap.put(InvalidUPCEnum.MISSING_UPC_INFO, new ArrayList<>());
	}

	public List<String> getInfoTypeMsgList() {
		return valTypeMsgMap.get(ValMsgTypeEnum.INFORMATION);
	}

	public List<String> getProcessTypeMsgList() {
		return valTypeMsgMap.get(ValMsgTypeEnum.PROCESS);
	}

	public List<String> getErrorTypeMsgList() {
		return valTypeMsgMap.get(ValMsgTypeEnum.ERROR);
	}

	public List<String> getWarningTypeMsgList() {
		return valTypeMsgMap.get(ValMsgTypeEnum.WARNING);
	}

	public String getErrorTypeInd() {
		return ValMsgTypeEnum.ERROR.getMsgTypeInd();
	}

	public String getWarningTypeInd() {
		return ValMsgTypeEnum.WARNING.getMsgTypeInd();
	}

	public String getInfoTypeInd() {
		return ValMsgTypeEnum.INFORMATION.getMsgTypeInd();
	}

	public String getProcessTypeInd() {
		return ValMsgTypeEnum.PROCESS.getMsgTypeInd();
	}

	public CommonContext getCommonContext() {
		return commonContext;
	}

	public void setCommonContext(CommonContext commonContext) {
		this.commonContext = commonContext;
	}

	public PriceAreaContext getPriceAreaContext() {
		return priceAreaContext;
	}

	public void setPriceAreaContext(PriceAreaContext priceAreaContext) {
		this.priceAreaContext = priceAreaContext;
	}

	public StorePriceContext getStorePriceContext() {
		return storePriceContext;
	}

	public void setStorePriceContext(StorePriceContext storePriceContext) {
		this.storePriceContext = storePriceContext;
	}

	public List<UPCItemDetail> getInvalidPriceDiffUpc() {
		return invalidUPCMap.get(InvalidUPCEnum.INVALID_PRICE);
	}

	public String getInvalidPriceDiffUpcInd() {
		return InvalidUPCEnum.INVALID_PRICE.getMsgTypeInd();
	}

	public BasePricingMsg getBasePricingMsg() {
		return basePricingMsg;
	}

	public void setBasePricingMsg(BasePricingMsg basePricingMsg) {
		this.basePricingMsg = basePricingMsg;
	}

	public BasePricingMsgJson getBasePricingMsgJson() {
		return basePricingMsgJson;
	}

	public void setBasePricingMsgJson(BasePricingMsgJson basePricingMsgJson) {
		this.basePricingMsgJson = basePricingMsgJson;
	}

	public List<UPCItemDetail> getDiscontinuedUpc() {
		return invalidUPCMap.get(InvalidUPCEnum.DISCONTINUED_UPC);
	}

	public String getDiscontinuedUpcInd() {
		return InvalidUPCEnum.DISCONTINUED_UPC.getMsgTypeInd();
	}

	public List<UPCItemDetail> getSeasonalPriceDiffUpc() {
		return invalidUPCMap.get(InvalidUPCEnum.SEASONAL_UPC);
	}

	public String getSeasonalPriceDiffUpcInd() {
		return InvalidUPCEnum.SEASONAL_UPC.getMsgTypeInd();
	}

	public List<UPCItemDetail> getSamePriceUpc() {
		return invalidUPCMap.get(InvalidUPCEnum.SAME_PRICE);
	}

	public String getSamePriceUpcInd() {
		return InvalidUPCEnum.SAME_PRICE.getMsgTypeInd();
	}

	public List<UPCItemDetail> getMissingUpc() {
		return invalidUPCMap.get(InvalidUPCEnum.MISSING_UPC_INFO);
	}

	public String getMissingUpcInd() {
		return InvalidUPCEnum.MISSING_UPC_INFO.getMsgTypeInd();
	}

	public BasePricingMessages getBasePricingMessages() {
		return basePricingMessages;
	}

	public void setBasePricingMessages(BasePricingMessages basePricingMessages) {
		this.basePricingMessages = basePricingMessages;
	}

}
