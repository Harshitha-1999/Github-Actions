package com.albertsons.me01r.baseprice.model;

public class OptionalCutDetail {
	private Integer optionalCic;
	private Double optionalItemGap;

	public Integer getOptionalCic() {
		return optionalCic;
	}

	public void setOptionalCic(Integer optionalCic) {
		this.optionalCic = optionalCic;
	}

	public Double getOptionalItemGap() {
		return optionalItemGap;
	}

	public void setOptionalItemGap(Double optionalItemGap) {
		this.optionalItemGap = optionalItemGap;
	}
}
