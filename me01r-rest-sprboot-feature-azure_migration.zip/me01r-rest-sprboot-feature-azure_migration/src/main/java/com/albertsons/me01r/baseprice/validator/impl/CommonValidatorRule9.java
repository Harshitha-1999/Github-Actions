package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 9)
public class CommonValidatorRule9 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule9.class);

	@Value("INVALID-PRICE-FACTOR")
	private String priceFactorNotValid;

	@Value("INVALID-PRICE-LMT")
	private String priceNotValid;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {

		//LOGGER.debug("CommonValidatorRule9 {}", context.getCommonContext().getCicInfo());
		Double maxPriceOffset = "".equals(PropertiesUtils.getProperty("MAX_PRC")) ? 0
				: Double.valueOf(PropertiesUtils.getProperty("MAX_PRC"));
		Double minPriceOffset = "".equals(PropertiesUtils.getProperty("MIN_PRC")) ? 0
				: Double.valueOf(PropertiesUtils.getProperty("MIN_PRC"));
		Double maxPrcFctrOffset = "".equals(PropertiesUtils.getProperty("MAX_PRC_FT")) ? 0
				: Double.valueOf(PropertiesUtils.getProperty("MAX_PRC_FT"));
		Double minPrcFctrOffset = "".equals(PropertiesUtils.getProperty("MIN_PRC_FT")) ? 0
				: Double.valueOf(PropertiesUtils.getProperty("MIN_PRC_FT"));

		if (basePricingMsg.getPriceFactor() <= minPrcFctrOffset.intValue()
				|| basePricingMsg.getPriceFactor().intValue() > maxPrcFctrOffset.intValue()) {
			LOGGER.error("INVALID-PRICE-FACTOR : {}", basePricingMsg.getPriceFactor());
			// context.getErrorType().getMsgList().add(priceFactorNotValid);
			context.getErrorTypeMsgList().add(priceFactorNotValid);
		}
		if (basePricingMsg.getSuggPrice() < minPriceOffset.doubleValue()
				|| basePricingMsg.getSuggPrice() > maxPriceOffset.doubleValue()) {
			LOGGER.error("INVALID-PRICE-LMT : {}", basePricingMsg.getSuggPrice());
			context.getErrorTypeMsgList().add(priceNotValid);
		}
		//LOGGER.debug("CommonValidatorRule9 OK.");
	}
}
