package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 6)
public class CommonValidatorRule6 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule6.class);

	@Value("INVALID-PRICE-AREA")
	private String paNotValid;

	@Value("INVALID-FACILITY")
	private String invalidFacility;

	/*
	 * @Value("${PA_LEN}") private Integer paFeildLength;
	 */

	/*
	 * @Value("${ST_LEN}") private Integer storeFeildLength;
	 */

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule6 {}", context.getCommonContext().getCicInfo());
		Integer storeFeildLength = ("".equals(PropertiesUtils.getProperty("ST_LEN")) ? 0
				: Integer.valueOf(PropertiesUtils.getProperty("ST_LEN")));
		Integer paFeildLength = ("".equals(PropertiesUtils.getProperty("PA_LEN")) ? 0
				: Integer.valueOf(PropertiesUtils.getProperty("PA_LEN")));

		if (basePricingMsg.isPriceArea() && basePricingMsg.getPaStoreInfo().length() != paFeildLength.intValue()) {
			LOGGER.error("INVALID-PRICE_AREA : {}", basePricingMsg.getPaStoreInfo());
			context.getErrorTypeMsgList().add(paNotValid);
		}
		if (basePricingMsg.isStoreSpecific()
				&& basePricingMsg.getPaStoreInfo().length() != storeFeildLength.intValue()) {
			LOGGER.error("INVALID-FACILITY : {}", basePricingMsg.getPaStoreInfo());
			context.getErrorTypeMsgList().add(invalidFacility);
		}
		//LOGGER.debug("CommonValidatorRule6 OK.");
	}
}
