package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.validator.PriceAreaValidator;
import com.albertsons.me01r.baseprice.validator.StorePriceValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 11)
public class CommonValidatorRule11 implements PriceAreaValidator, StorePriceValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule11.class);

	@Value("INVALID-DATE-OFF")
	private String invalidDateEff;

	/*
	 * @Value("${ST_DT_CHCK}") private Long validDiffStartEndDate;
	 */

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule11 {} ", context.getCommonContext().getCicInfo());
		Long validDiffStartEndDate = "".equals(PropertiesUtils.getProperty("ST_DT_CHCK")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("ST_DT_CHCK"));
		if (context.getCommonContext().getCicInfo().stream().anyMatch(cic -> !cic.isInitialPrice())
				&& !basePricingMsg.isItemOnPromotion() || basePricingMsg.isStoreSpecific()) {
			if (basePricingMsg.getEffectiveStartDt() != null && basePricingMsg.getEffectiveEndDt() != null) {

				if (BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt())
						.isAfter(BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt()))) {
					LOGGER.error("INVALID-DATE-OFF : {}", basePricingMsg.getEffectiveEndDt());
					// context.getErrorType().getMsgList().add(invalidDateEff);
					context.getErrorTypeMsgList().add(invalidDateEff);
				}
				if (BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt())
						.plusDays(validDiffStartEndDate)
						.isAfter(BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt()))) {
					LOGGER.error("INVALID-DATE-OFF : {}", basePricingMsg.getEffectiveEndDt());
					// context.getErrorType().getMsgList().add(invalidDateEff);
					context.getErrorTypeMsgList().add(invalidDateEff);
				}
				//LOGGER.debug("CommonValidatorRule11 OK.");
			}

		}

	}
}
