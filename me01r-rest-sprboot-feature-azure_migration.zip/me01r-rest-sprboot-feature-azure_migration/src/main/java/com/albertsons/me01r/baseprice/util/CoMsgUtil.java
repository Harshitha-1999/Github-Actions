package com.albertsons.me01r.baseprice.util;

/**
 * For the error code matching COMSG
 * 
 * @author yfung00
 *
 */
public class CoMsgUtil {

}
