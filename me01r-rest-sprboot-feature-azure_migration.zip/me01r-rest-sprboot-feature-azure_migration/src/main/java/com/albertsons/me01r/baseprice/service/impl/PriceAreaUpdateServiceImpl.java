package com.albertsons.me01r.baseprice.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.dao.PriceAreaUpdateDAO;
import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.LogMsg;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.AuditHandlingService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.LogHandlingService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaService;
import com.albertsons.me01r.baseprice.service.PriceAreaUpdateService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.util.TableUtil;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Service
public class PriceAreaUpdateServiceImpl implements PriceAreaUpdateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PriceAreaUpdateServiceImpl.class);

	@Autowired
	PriceAreaUpdateDAO priceAreaUpdateDAO;

	@Autowired
	AuditHandlingService auditHandlingService;

	@Autowired
	ValidatePriceAreaDAO validatePriceAreaDAO;

	@Autowired
	private LogHandlingService logHandlingService;

	@Autowired
	private PriceAreaService priceAreaService;

	/*
	 * @Value(value = "${VALID_DAY}") private Long validDaysDiff;
	 */

	@Value("NO-PRICE-ON-PROMO")
	private String noPrcForRog;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private MessageHandlingService messageHandlingService;

	private void updatePosBibSwitch(InitialPricingUpdateContext ipUpdateContext) throws SystemException {
		priceAreaUpdateDAO.updatePosBibSwitch(ipUpdateContext.getItemPriceDataList());
	}

	private List<ItemPriceData> updateUpcStatus(InitialPricingUpdateContext ipUpdateContext) throws SystemException {
		List<ItemPriceData> itemPriceDataList = new ArrayList<>();
		prepareUpcUpdateData(ipUpdateContext, itemPriceDataList);
		if (!itemPriceDataList.isEmpty()) {
			priceAreaUpdateDAO.updateUpcStatus(itemPriceDataList);
		}
		return itemPriceDataList;
	}

	private void prepareUpcUpdateData(InitialPricingUpdateContext ipUpdateContext,
			List<ItemPriceData> itemPriceDataList) {
		ipUpdateContext.getItemPriceDataList().forEach(itemDetail -> {
			if (null != itemDetail.getRupcStatus() && !itemDetail.getRupcStatus().isEmpty()) {
				if (itemDetail.getRupcStatus().equalsIgnoreCase("N")) {
					if (itemDetail.getRetStatus().equalsIgnoreCase("V")) {
						itemDetail.setUpdatedRupcStatus("V");
						itemPriceDataList.add(itemDetail);
					} else {
						itemDetail.setUpdatedRupcStatus("H");
						itemPriceDataList.add(itemDetail);
					}
				}
			}
		});
	}

	private void addInitialItemPrice(InitialPricingUpdateContext ipUpdateContext) throws SystemException {
		priceAreaUpdateDAO.insertItemNewPrice(ipUpdateContext.getItemPriceDataList());
	}

	private void addPendingItemPrice(PriceAreaUpdateContext paUpdateContext) throws SystemException {
		priceAreaUpdateDAO.insertItemPendingPrice(paUpdateContext.getPendingPriceDataList());
	}

	@Override
	@Transactional(rollbackFor = SystemException.class)
	public void addItemPrice(InitialPricingUpdateContext ipUpdateContext, PriceAreaUpdateContext paUpdateContext,
			ValidationContext validationContext) throws SystemException {
		if (null != ipUpdateContext.getCommonContext() && null != ipUpdateContext.getCommonContext().getCicInfo()
				&& !ipUpdateContext.getCommonContext().getCicInfo().isEmpty()) {
			/*LOGGER.debug("Initial Price for Item: {} , Retail Section: {} and Price Area: {}",
					ipUpdateContext.getCommonContext().getCicInfo(),
					ipUpdateContext.getBasePricingMsg().getRetailSection(),
					ipUpdateContext.getBasePricingMsg().getPaStoreInfo());*/
			// insert for SSITMPRC
			addInitialItemPrice(ipUpdateContext);
			// insert for SSHISPRC
			insertPriceHistory(ipUpdateContext, paUpdateContext);
			List<AuditMsg> auditMsgList = new ArrayList<>();

			// audit msg for SSITMPRC
			List<AuditMsg> itmPrcAuditMsg = prepareAuditMsg(ipUpdateContext, TableUtil.SSITMPRC, ConstantsUtil.NONE);
			auditMsgList.addAll(itmPrcAuditMsg);
			// update SSITMROG status
			Optional<String> retStatusValue = ipUpdateContext.getCommonContext().getCicInfo().stream()
					.map(cic -> cic.getRetStatus()).findAny();
			String retStatus = "";
			if (retStatusValue.isPresent()) {
				retStatus = retStatusValue.get();
			}

			String updatedRogStatus = updateRogStatus(ipUpdateContext);
			ipUpdateContext.getCommonContext().getCicInfo().forEach(cic -> {
				cic.setUpdatedRogStatus(updatedRogStatus);
			});
			// update SSITMURX Status
			List<ItemPriceData> itemPriceDataList = updateUpcStatus(ipUpdateContext);
			// update SSITMPOS switches
			updatePosBibSwitch(ipUpdateContext);

			if (!retStatus.equalsIgnoreCase(updatedRogStatus)) {
				List<AuditMsg> rogAuditMsg = prepareAuditMsg(ipUpdateContext, TableUtil.SSITMROG, ConstantsUtil.NONE);
				auditMsgList.addAll(rogAuditMsg);
			}

			if (!itemPriceDataList.isEmpty()) {
				InitialPricingUpdateContext initialPricingUpdateContext = new InitialPricingUpdateContext();
				initialPricingUpdateContext.setBasePricingMsg(ipUpdateContext.getBasePricingMsg());
				initialPricingUpdateContext.setItemPriceDataList(itemPriceDataList);
				List<AuditMsg> urxAuditMsg = prepareAuditMsg(initialPricingUpdateContext, TableUtil.SSITMURX,
						ConstantsUtil.NONE);
				auditMsgList.addAll(urxAuditMsg);
			}

			List<AuditMsg> posAuditMsg = prepareAuditMsg(ipUpdateContext, TableUtil.SSITMPOS, ConstantsUtil.NONE);
			auditMsgList.addAll(posAuditMsg);

			// insert in MEFMAUDT
			if (!auditMsgList.isEmpty()) {
				auditHandlingService.insertAuditMsg(auditMsgList);
			}

			// insert in MERCPRLG
			insertInitialPriceLog(ipUpdateContext.getBasePricingMsg(), ipUpdateContext.getItemPriceDataList());
		}
		if (null != paUpdateContext.getCommonContext() && null != paUpdateContext.getCommonContext().getCicInfo()
				&& !paUpdateContext.getCommonContext().getCicInfo().isEmpty()) {
			/*
			 * LOGGER.
			 * debug("Pending Price for Item: {} , Retail Section:{}  and Price Area: {}",
			 * paUpdateContext.getCommonContext().getCicInfo(),
			 * paUpdateContext.getBasePricingMsg().getRetailSection(),
			 * paUpdateContext.getBasePricingMsg().getPaStoreInfo());
			 */
			List<ErrorMsg> errorList = new ArrayList<>();
			validateEffStartDateAndEndDate(paUpdateContext.getBasePricingMsg(),
					paUpdateContext.getCommonContext().getCicInfo(), errorList);
			if (CollectionUtils.isEmpty(errorList)) {
				List<LogMsg> pendingPriceLog = new ArrayList<>();
				if (paUpdateContext.getBasePricingMsg().isLtsPresent()) {
					List<Promotion> promotionDetails = validatePriceAreaDAO
							.fetchLTSPromoitonDetails(ipUpdateContext.getBasePricingMsg());
					if (!CollectionUtils.isEmpty(ipUpdateContext.getBasePricingMsg().getOptionalCutDetails())) {
						if (null != promotionDetails && promotionDetails.size() >= 1) {
							paUpdateContext.getBasePricingMsg()
									.setEffectiveStartDt(promotionDetails.get(0).getStartDate().toString());
							validateEffStartDateAndEndDate(paUpdateContext.getBasePricingMsg(),
									paUpdateContext.getUpcItemDetailList(), errorList);
							if (CollectionUtils.isEmpty(errorList) && !promotionDetails.stream()
									.anyMatch(promo -> promo.getCic().intValue() == paUpdateContext.getBasePricingMsg()
											.getCorpItemCd().intValue())) {
								paUpdateContext.getPendingPriceDataList().forEach(upc -> upc
										.setEffectiveStartDt(promotionDetails.get(0).getStartDate().toString()));
								pendingPricePriceArea(paUpdateContext, pendingPriceLog);
							} else {
								promotionDetails.forEach(promo -> {
									if (promo.getCic().intValue() == paUpdateContext.getBasePricingMsg().getCorpItemCd()
											.intValue()) {
										try {
											updateLtsPriceArea(paUpdateContext, pendingPriceLog, promotionDetails);
										} catch (SystemException e) {
											LOGGER.error(e.getMessage(), e);
										}
									}
								});

							}
						}
					} else {
						updateLtsPriceArea(paUpdateContext, pendingPriceLog, promotionDetails);
					}
				} else {
					pendingPricePriceArea(paUpdateContext, pendingPriceLog);
				}
			}

		}
		if (!CollectionUtils.isEmpty(ipUpdateContext.getBasePricingMsg().getOptionalCutDetails())
				&& !ipUpdateContext.getBasePricingMsg().getIsOptionalCut()) {
			messageHandlingService.processMeatItem(ipUpdateContext.getBasePricingMsg(), validationContext);
		}
	}

	private void updateLtsPriceArea(PriceAreaUpdateContext paUpdateContext, List<LogMsg> pendingPriceLog,
			List<Promotion> promotionDetails) throws SystemException {
		updatePriceForLts(paUpdateContext.getPendingPriceDataList());

		List<PendingPriceData> pendingPrice = createLtsList(promotionDetails, paUpdateContext.getBasePricingMsg());
		paUpdateContext.setPendingPriceDataList(new ArrayList<>());
		paUpdateContext.getPendingPriceDataList().addAll(pendingPrice);
		List<AuditMsg> insertLtsPriceUpdateAuditMsg = prepareAuditMsgPendingPrice(paUpdateContext, TableUtil.SSPENPRC,
				ConstantsUtil.U);
		if (!CollectionUtils.isEmpty(insertLtsPriceUpdateAuditMsg)) {
			auditHandlingService.insertAuditMsg(insertLtsPriceUpdateAuditMsg);
		}
		List<LogMsg> deletePendingPriceList = logHandlingService
				.preparePendingPriceLog(paUpdateContext.getBasePricingMsg(), pendingPrice, ConstantsUtil.U, null);
		pendingPriceLog.addAll(deletePendingPriceList);
		insertPendingPriceLog(pendingPriceLog);
	}

	private void pendingPricePriceArea(PriceAreaUpdateContext paUpdateContext, List<LogMsg> pendingPriceLog)
			throws SystemException {
		List<AuditMsg> pendingPriceAuditMsg = new ArrayList<>();
		List<PendingPriceData> pendingPrice = priceAreaService
				.fetchPendingItemDetailToDelete(paUpdateContext.getPendingPriceDataList());
		int deleteCount = deletePendingItemPrice(paUpdateContext.getPendingPriceDataList());
		if (deleteCount != 0) {
			List<AuditMsg> deletePendingPriceAuditMsg = prepareAuditMsgPendingPrice(paUpdateContext, TableUtil.SSPENPRC,
					ConstantsUtil.D);
			auditHandlingService.insertAuditMsg(pendingPriceAuditMsg);
			pendingPriceAuditMsg.addAll(deletePendingPriceAuditMsg);
			// update MERCPRLG with a D update
			List<LogMsg> deletePendingPriceList = logHandlingService
					.preparePendingPriceLog(paUpdateContext.getBasePricingMsg(), pendingPrice, ConstantsUtil.D, null);
			pendingPriceLog.addAll(deletePendingPriceList);
		}
		addPendingItemPrice(paUpdateContext);
		// Audit for SSPENPRC - insert
		List<AuditMsg> insertPendingPriceAuditMsg = prepareAuditMsgPendingPrice(paUpdateContext, TableUtil.SSPENPRC,
				ConstantsUtil.N);
		pendingPriceAuditMsg.addAll(insertPendingPriceAuditMsg);
		auditHandlingService.insertAuditMsg(pendingPriceAuditMsg);
		// insert in MERCPRLG
		if (!CollectionUtils.isEmpty(paUpdateContext.getCommonContext().getDateChange())) {
			paUpdateContext.getCommonContext().getDateChange().forEach(msg -> {
				List<LogMsg> updatePendingPriceList = logHandlingService.preparePendingPriceLog(
						paUpdateContext.getBasePricingMsg(), paUpdateContext.getPendingPriceDataList(), ConstantsUtil.P,
						msg);
				pendingPriceLog.addAll(updatePendingPriceList);
			});
		} else {
			List<LogMsg> updatePendingPriceList = logHandlingService.preparePendingPriceLog(
					paUpdateContext.getBasePricingMsg(), paUpdateContext.getPendingPriceDataList(), ConstantsUtil.P,
					null);
			pendingPriceLog.addAll(updatePendingPriceList);
		}

		insertPendingPriceLog(pendingPriceLog);
	}

	private List<PendingPriceData> createLtsList(List<Promotion> promotionDetails, BasePricingMsg basePricingMsg) {
		List<PendingPriceData> pendingPriceDataList = new ArrayList<>();
		promotionDetails.forEach(item -> {
			if (basePricingMsg.getCorpItemCd().intValue() == item.getCic().intValue()) {
				PendingPriceData promotion = new PendingPriceData();
				promotion.setEffectiveStartDt(item.getStartDate().toString());
				promotion.setSuggPrice(item.getPrice());
				promotion.setUpcManuf(item.getUpcManuf());
				promotion.setUpcSales(item.getUpcSales());
				promotion.setUpcCountry(item.getUpcCountry());
				promotion.setUpcSystem(item.getUpcSystem());
				promotion.setPaStoreInfo(basePricingMsg.getPaStoreInfo());
				promotion.setPriceFactor(item.getPriceFactor());
				promotion.setRogCd(basePricingMsg.getRogCd());
				pendingPriceDataList.add(promotion);
			}
		});

		return pendingPriceDataList;
	}

	private void validateEffStartDateAndEndDate(BasePricingMsg basePricingMsg, List<UPCItemDetail> list,
			List<ErrorMsg> errorMsgList) throws SystemException {
		Long validDaysDiff = "".equals(PropertiesUtils.getProperty("VALID_DAY")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("VALID_DAY"));
		LocalDate effStartdate = BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt());
		LocalDate inboundStartDate = BasePriceUtil
				.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt());
		List<String> errorList = new ArrayList<>();
		if (inboundStartDate.plusDays(validDaysDiff).isBefore(effStartdate)) {
			errorList.add(noPrcForRog);
		}

		if (!CollectionUtils.isEmpty(errorList)) {
			errorMsgList.addAll(prepareErrorMsg(basePricingMsg, list, errorList, ConstantsUtil.E));
			insertError(errorMsgList);
		}

	}

	private void insertError(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingService.insertErrorMessage(errorMessage);
	}

	private List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd) throws SystemException {
		return errorHandlingService.prepareErrorMsg(basePriceMsg, itemDetailList, statCd, errorList);
	}

	private int deletePendingItemPrice(List<PendingPriceData> pendingPriceDataList) throws SystemException {
		return priceAreaUpdateDAO.deletePendingItemPrice(pendingPriceDataList);
	}

	private void updatePriceForLts(List<PendingPriceData> pendingPriceDataList) throws SystemException {
		priceAreaUpdateDAO.updatePriceForLts(pendingPriceDataList);
	}

	private List<AuditMsg> prepareAuditMsg(InitialPricingUpdateContext ipUpdateContext, String flow, String operation)
			throws SystemException {
		return auditHandlingService.prepareAuditMsgInitialPrice(ipUpdateContext, flow, operation);
	}

	private List<AuditMsg> prepareAuditMsgPendingPrice(PriceAreaUpdateContext paUpdateContext, String flow,
			String operation) throws SystemException {
		return auditHandlingService.prepareAuditMsgPendingPrice(paUpdateContext, flow, operation);
	}

	private String updateRogStatus(InitialPricingUpdateContext ipUpdateContext) throws SystemException {

		Optional<String> retStatusValue = ipUpdateContext.getCommonContext().getCicInfo().stream()
				.map(cic -> cic.getRetStatus()).findAny();
		String retStatus = "";
		if (retStatusValue.isPresent()) {
			retStatus = retStatusValue.get();
		}

		Optional<String> dstStatusValue = ipUpdateContext.getCommonContext().getCicInfo().stream()
				.map(cic -> cic.getStatusDST()).findAny();
		String dstStatus = "";
		if (dstStatusValue.isPresent()) {
			dstStatus = dstStatusValue.get();
		}

		String updatedRogStatus = retStatus;
		if (null != retStatus && !retStatus.isEmpty()) {
			if (retStatus.equalsIgnoreCase("C") || retStatus.equalsIgnoreCase("P")) {
				if (dstStatus.equalsIgnoreCase("V")) {
					updatedRogStatus = "V";
					String poGuideNewItem = " ";
					priceAreaUpdateDAO.updateRogStatus(ipUpdateContext.getBasePricingMsg().getRogCd(),
							ipUpdateContext.getBasePricingMsg().getCorpItemCd(), updatedRogStatus, poGuideNewItem);
				} else {
					if (retStatus.equalsIgnoreCase("C")) {
						updatedRogStatus = "P";
						String poGuideNewItem = "Y";
						priceAreaUpdateDAO.updateRogStatus(ipUpdateContext.getBasePricingMsg().getRogCd(),
								ipUpdateContext.getBasePricingMsg().getCorpItemCd(), updatedRogStatus, poGuideNewItem);
					}
				}
			}
		}
		return updatedRogStatus;

	}

	private void insertInitialPriceLog(BasePricingMsg basePricingMsg, List<ItemPriceData> itemPriceDataList)
			throws SystemException {
		logHandlingService.insertInitialPriceLog(basePricingMsg, itemPriceDataList, ConstantsUtil.P);
	}

	private void insertPendingPriceLog(List<LogMsg> logMsgList) throws SystemException {
		logHandlingService.insertPendingPriceLog(logMsgList);
	}

	private void insertPriceHistory(InitialPricingUpdateContext ipUpdateContext, PriceAreaUpdateContext paUpdateContext)
			throws SystemException {
		List<ItemPriceData> historyPriceData = createPriceHistorydata(ipUpdateContext);
		priceAreaUpdateDAO.insertPriceHistory(historyPriceData, ipUpdateContext, paUpdateContext);
	}

	private List<ItemPriceData> createPriceHistorydata(InitialPricingUpdateContext ipUpdateContext) {
		List<ItemPriceData> historyPriceData = ipUpdateContext.getItemPriceDataList().stream().map(itemDetail -> {
			ItemPriceData itemPriceData = new ItemPriceData();
			itemPriceData.setCorp(itemDetail.getCorp());
			itemPriceData.setDivision(itemDetail.getDivision());
			itemPriceData.setRogCd(itemDetail.getRogCd());
			itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
			itemPriceData.setUpcSales(itemDetail.getUpcSales());
			itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
			itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
			itemPriceData.setEffectiveStartDt(ipUpdateContext.getBasePricingMsg().getEffectiveStartDt());
			itemPriceData.setPaStoreInfo(ipUpdateContext.getBasePricingMsg().getPaStoreInfo());
			itemPriceData.setReason(ConstantsUtil.SPACE);
			itemPriceData.setPriceMtd(ConstantsUtil.R);
			itemPriceData.setLimQty(ConstantsUtil.ZERO);
			itemPriceData.setPriceFactor(ipUpdateContext.getBasePricingMsg().getPriceFactor());
			itemPriceData.setSuggPrice(ipUpdateContext.getBasePricingMsg().getSuggPrice());
			itemPriceData.setPriceFctAlt(ConstantsUtil.ZERO.toString());
			itemPriceData.setPriceAlt(ConstantsUtil.ZERO.toString());
			itemPriceData.setLtsFlag(ConstantsUtil.SPACE);
			itemPriceData.setLastUpdUserId(ipUpdateContext.getBasePricingMsg().getLastUpdUserId());
			return itemPriceData;
		}).collect(Collectors.toList());
		return historyPriceData;
	}
}
