package com.albertsons.me01r.baseprice.validator.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.CommonValidator;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Order(value = 5)
public class CommonValidatorRule5 implements CommonValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorRule5.class);

	@Value("DISPLAYER-NOT-ALLOWED")
	private String errorMessage;

	@Override
	public void validate(BasePricingMsg basePricingMsg, ValidationContext context) throws SystemException {
		//LOGGER.debug("CommonValidatorRule5 {}", context.getCommonContext().getCicInfo());
		if (!context.getCommonContext().getCicInfo().stream()
				.allMatch(cic -> !cic.getDisplayFlag().equalsIgnoreCase(ConstantsUtil.Y))) {
			LOGGER.error("DISPLAY-ITEM CIC {}", basePricingMsg.getCorpItemCd());
			// context.getErrorType().getMsgList().add(errorMessage);
			context.getErrorTypeMsgList().add(errorMessage);
		}
		//LOGGER.debug("CommonValidatorRule5 OK.");
	}
}
