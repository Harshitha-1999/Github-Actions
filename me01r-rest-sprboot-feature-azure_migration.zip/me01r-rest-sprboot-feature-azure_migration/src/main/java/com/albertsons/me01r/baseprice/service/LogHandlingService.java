package com.albertsons.me01r.baseprice.service;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.LogMsg;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.StorePriceData;

public interface LogHandlingService {
	public void insertPendingPriceLog(List<LogMsg> logMsgList) throws SystemException;

	public void insertInitialPriceLog(BasePricingMsg basePricingMsg, List<ItemPriceData> itemPriceDataList,
			String msgCd) throws SystemException;

	public void insertStorePriceLog(List<LogMsg> logMsgList) throws SystemException;

	public List<LogMsg> prepareStorePriceLog(BasePricingMsg basePricingMsg, List<StorePriceData> storePriceDataList,
			String msgCd, String msg);

	public List<LogMsg> preparePendingPriceLog(BasePricingMsg basePricingMsg, List<PendingPriceData> itemPriceDataList,
			String msgCd, String msg);
}
