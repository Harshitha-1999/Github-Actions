package com.albertsons.me01r.baseprice.context.update;

import java.util.List;

import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.validator.context.CommonContext;

public class InitialPricingUpdateContext {

	private CommonContext commonContext;

	private BasePricingMsg basePricingMsg;

	private List<UPCItemDetail> upcItemDetailList;

	private List<ItemPriceData> itemPriceDataList;

	public CommonContext getCommonContext() {
		return commonContext;
	}

	public void setCommonContext(CommonContext commonContext) {
		this.commonContext = commonContext;
	}

	public BasePricingMsg getBasePricingMsg() {
		return basePricingMsg;
	}

	public void setBasePricingMsg(BasePricingMsg basePricingMsg) {
		this.basePricingMsg = basePricingMsg;
	}

	public List<UPCItemDetail> getUpcItemDetailList() {
		return upcItemDetailList;
	}

	public void setUpcItemDetailList(List<UPCItemDetail> upcItemDetailList) {
		this.upcItemDetailList = upcItemDetailList;
	}

	public List<ItemPriceData> getItemPriceDataList() {
		return itemPriceDataList;
	}

	public void setItemPriceDataList(List<ItemPriceData> itemPriceDataList) {
		this.itemPriceDataList = itemPriceDataList;
	}

}
