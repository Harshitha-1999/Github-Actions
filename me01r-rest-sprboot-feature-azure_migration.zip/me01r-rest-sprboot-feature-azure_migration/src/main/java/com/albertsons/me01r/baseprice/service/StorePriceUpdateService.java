package com.albertsons.me01r.baseprice.service;

import com.albertsons.me01r.baseprice.context.update.StoreLevelUpdateContext;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface StorePriceUpdateService {

	public void addItemPrice(StoreLevelUpdateContext sLupdatedContext, ValidationContext validationContext)
			throws SystemException, Exception;

}
