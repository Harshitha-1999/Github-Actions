package com.albertsons.me01r.baseprice.model;

import java.time.LocalDate;

public class UPCItemDetail {
	private String corp;
	private Integer corpItemCd;
	private Integer crc;
	private Integer unitType;
	private String rogCd;
	private String itemUsageIndicator;
	private String retStatus;
	private String displayFlag;
	private Integer upcCountry;
	private Integer upcSystem;
	private Integer upcManuf;
	private Integer upcSales;
	private String rupcStatus;
	private boolean isPendingPrice = false;
	private boolean isInitialPrice = true;;
	private String priceArea;
	private Integer pluCd;
	private String reason;
	private String reasonType;
	private boolean isPriceValid = true;
	private Double initialPrice;
	private int initialFactor;
	private Double pendingPrice;
	private int pendingFactor;
	private String pendingReason = "";
	private String pendingReasonType = "";
	private String initialReason = "";
	private String initialReasonType = "";
	private boolean upcExists = true;
	private LocalDate effectivePenPriceStartDate;
	private boolean validPriceDiff = true;
	private String division;
	private String sensitiveItem;
	private String sendBibDef;
	private String sendNewItmDef;
	private String sendPriceSw;
	private String sendLabelSw;
	private String statusDST;
	private String updatedRogStatus;
	private String updatedRupcStatus;
	private String smic;
	private String groupCode;
	private String ring;
	private String retailSection;

	public Integer getCorpItemCd() {
		return corpItemCd;
	}

	public void setCorpItemCd(Integer corpItemCd) {
		this.corpItemCd = corpItemCd;
	}

	public Integer getUnitType() {
		return unitType;
	}

	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public String getItemUsageIndicator() {
		return itemUsageIndicator;
	}

	public void setItemUsageIndicator(String itemUsageIndicator) {
		this.itemUsageIndicator = itemUsageIndicator;
	}

	public String getRetStatus() {
		return retStatus;
	}

	public void setRetStatus(String retStatus) {
		this.retStatus = retStatus;
	}

	public String getDisplayFlag() {
		return displayFlag;
	}

	public void setDisplayFlag(String displayFlag) {
		this.displayFlag = displayFlag;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public Integer getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(Integer upcManuf) {
		this.upcManuf = upcManuf;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public String getRupcStatus() {
		return rupcStatus;
	}

	public void setRupcStatus(String rupcStatus) {
		this.rupcStatus = rupcStatus;
	}

	public boolean isPendingPrice() {
		return isPendingPrice;
	}

	public void setPendingPrice(boolean isPendingPrice) {
		this.isPendingPrice = isPendingPrice;
	}

	public boolean isInitialPrice() {
		return isInitialPrice;
	}

	public void setInitialPrice(boolean isInitialPrice) {
		this.isInitialPrice = isInitialPrice;
	}

	public String getPriceArea() {
		return priceArea;
	}

	public void setPriceArea(String priceArea) {
		this.priceArea = priceArea;
	}

	public Integer getPluCd() {
		return pluCd;
	}

	public void setPluCd(Integer pluCd) {
		this.pluCd = pluCd;
	}

	public String getCorp() {
		return corp;
	}

	public void setCorp(String corp) {
		this.corp = corp;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getReasonType() {
		return reasonType;
	}

	public void setReasonType(String reasonType) {
		this.reasonType = reasonType;
	}

	public boolean isPriceValid() {
		return isPriceValid;
	}

	public void setPriceValid(boolean isPriceValid) {
		this.isPriceValid = isPriceValid;
	}

	public Double getInitialPrice() {
		return initialPrice;
	}

	public void setInitialPrice(Double initialPrice) {
		this.initialPrice = initialPrice;
	}

	public Double getPendingPrice() {
		return pendingPrice;
	}

	public void setPendingPrice(Double pendingPrice) {
		this.pendingPrice = pendingPrice;
	}

	public boolean isUpcExists() {
		return upcExists;
	}

	public void setUpcExists(boolean upcExists) {
		this.upcExists = upcExists;
	}

	public LocalDate getEffectivePenPriceStartDate() {
		return effectivePenPriceStartDate;
	}

	public void setEffectivePenPriceStartDate(LocalDate effectivePenPriceStartDate) {
		this.effectivePenPriceStartDate = effectivePenPriceStartDate;
	}

	public boolean isValidPriceDiff() {
		return validPriceDiff;
	}

	public void setValidPriceDiff(boolean validPriceDiff) {
		this.validPriceDiff = validPriceDiff;
	}

	public String getSendBibDef() {
		return sendBibDef;
	}

	public void setSendBibDef(String sendBibDef) {
		this.sendBibDef = sendBibDef;
	}

	public String getSendNewItmDef() {
		return sendNewItmDef;
	}

	public void setSendNewItmDef(String sendNewItmDef) {
		this.sendNewItmDef = sendNewItmDef;
	}

	public String getSendPriceSw() {
		return sendPriceSw;
	}

	public void setSendPriceSw(String sendPriceSw) {
		this.sendPriceSw = sendPriceSw;
	}

	public String getSendLabelSw() {
		return sendLabelSw;
	}

	public void setSendLabelSw(String sendLabelSw) {
		this.sendLabelSw = sendLabelSw;
	}

	public String getSensitiveItem() {
		return sensitiveItem;
	}

	public void setSensitiveItem(String sensitiveItem) {
		this.sensitiveItem = sensitiveItem;
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("UPCItemDetail: [corpItemCd=");
		sb.append(corpItemCd);
		sb.append(", unitType=");
		sb.append(unitType);
		sb.append(", rogCd=");
		sb.append(rogCd);
		sb.append(", upc=");
		sb.append(upcManuf);
		sb.append(upcSales);
		sb.append(upcCountry);
		sb.append(upcSystem);
		sb.append(", upcManuf=");
		sb.append(upcManuf);
		sb.append(", upcSales=");
		sb.append(upcSales);
		sb.append(", upcCountry=");
		sb.append(upcCountry);
		sb.append(", upcSystem=");
		sb.append(upcSystem);
		sb.append(", isPendingPrice=");
		sb.append(isPendingPrice);
		sb.append(", isInitialPrice=");
		sb.append(isInitialPrice);
		sb.append("]");

		return sb.toString();
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getStatusDST() {
		return statusDST;
	}

	public void setStatusDST(String statusDST) {
		this.statusDST = statusDST;
	}

	public String getUpdatedRogStatus() {
		return updatedRogStatus;
	}

	public void setUpdatedRogStatus(String updatedRogStatus) {
		this.updatedRogStatus = updatedRogStatus;
	}

	public String getUpdatedRupcStatus() {
		return updatedRupcStatus;
	}

	public void setUpdatedRupcStatus(String updatedRupcStatus) {
		this.updatedRupcStatus = updatedRupcStatus;
	}

	public String getSmic() {
		return smic;
	}

	public void setSmic(String smic) {
		this.smic = smic;
	}

	public String getRing() {
		return ring;
	}

	public void setRing(String ring) {
		this.ring = ring;
	}

	public String getRetailSection() {
		return retailSection;
	}

	public void setRetailSection(String retailSection) {
		this.retailSection = retailSection;
	}

	public int getInitialFactor() {
		return initialFactor;
	}

	public void setInitialFactor(int initialFactor) {
		this.initialFactor = initialFactor;
	}

	public int getPendingFactor() {
		return pendingFactor;
	}

	public void setPendingFactor(int pendingFactor) {
		this.pendingFactor = pendingFactor;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public Integer getCrc() {
		return crc;
	}

	public void setCrc(Integer crc) {
		this.crc = crc;
	}

	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		this.pendingReason = pendingReason;
	}

	public String getPendingReasonType() {
		return pendingReasonType;
	}

	public void setPendingReasonType(String pendingReasonType) {
		this.pendingReasonType = pendingReasonType;
	}

	public String getInitialReason() {
		return initialReason;
	}

	public void setInitialReason(String initialReason) {
		this.initialReason = initialReason;
	}

	public String getInitialReasonType() {
		return initialReasonType;
	}

	public void setInitialReasonType(String initialReasonType) {
		this.initialReasonType = initialReasonType;
	}

}
