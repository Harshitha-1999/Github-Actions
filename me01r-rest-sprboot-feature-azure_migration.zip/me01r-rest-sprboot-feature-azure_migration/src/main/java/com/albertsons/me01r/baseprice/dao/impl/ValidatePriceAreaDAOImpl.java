package com.albertsons.me01r.baseprice.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.dao.ValidatePriceAreaDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.Promotion;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.constatnts.AppConstants;

@Repository
public class ValidatePriceAreaDAOImpl implements ValidatePriceAreaDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidatePriceAreaDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.fetch.cic.info}")
	private String sqlFetchCicInformation;

	@Value(value = "${sql.fetch.sp.cic.info}")
	private String sqlFetchSpCicInformation;

	@Value(value = "${sql.check.initial.price}")
	private String sqlFetchInitialPrice;

	@Value(value = "${sql.fetch.initial.price.base.cut}")
	private String sqlFetchInitialPriceBaseCut;

	@Value(value = "${sql.validate.retail.section.price.area}")
	private String sqlValidateRetailSectionPriceArea;

	@Value(value = "${sql.fetch.price.range}")
	private String sqlFetchPriceDifFRange;

	@Value(value = "${sql.fetch.pending.price.eff.start.date}")
	private String sqlFetchPenPriceEffDate;

	@Value(value = "${sql.fetch.promotion.details}")
	private String sqlFetchPromotionDetails;

	@Value(value = "${sql.fetch.bibsw.itmprc}")
	private String sqlFetchBibSwitches;

	@Value(value = "${sql.fetch.lts.promotion}")
	private String sqlFetchLtsPromotion;

	@Value(value = "${sql.fetch.item.to.delete.penprc}")
	private String sqlFetchPenPrcToDelete;

	@Value(value = "${sql.fetch.optional.cut}")
	private String sqlFetchOptionalCut;

	@Override
	public List<UPCItemDetail> fetchCicInformation(BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("validateCic sql: {}", sqlFetchCicInformation);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		paramSource.addValue("rogCd", basePricingMsg.getRogCd());

		List<UPCItemDetail> itemDetails = new ArrayList<>();
		try {
			itemDetails = this.namedJdbc.query(sqlFetchCicInformation, paramSource, (rs, rowNum) -> {
				UPCItemDetail itemDetail = new UPCItemDetail();
				itemDetail.setCorp(getTrimmedString(rs.getString("CORP")));
				itemDetail.setDivision(getTrimmedString(rs.getString("DIVISION")));
				itemDetail.setCorpItemCd(rs.getInt("CORP_ITEM_CD"));
				itemDetail.setUnitType(rs.getInt("UNIT_TYPE"));
				itemDetail.setRogCd(getTrimmedString(rs.getString("ROG")));
				itemDetail.setItemUsageIndicator(getTrimmedString(rs.getString("ITEM_USAGE_IND")));
				itemDetail.setRetStatus(getTrimmedString(rs.getString("STATUS_RET")));
				itemDetail.setDisplayFlag(getTrimmedString(rs.getString("DISP_FLAG")));
				itemDetail.setUpcCountry(rs.getInt("UPC_COUNTRY"));
				itemDetail.setUpcSystem(rs.getInt("UPC_SYSTEM"));
				itemDetail.setUpcManuf(rs.getInt("UPC_MANUF"));
				itemDetail.setUpcSales(rs.getInt("UPC_SALES"));
				itemDetail.setRupcStatus(getTrimmedString(rs.getString("STATUS_RUPC")));
				itemDetail.setPriceArea(basePricingMsg.getPaStoreInfo());
				itemDetail.setPluCd(rs.getInt("PLU_CD"));
				itemDetail.setSensitiveItem(getTrimmedString(rs.getString("SENSITIVE_ITEM")));
				itemDetail.setStatusDST(getTrimmedString(rs.getString("STATUS_DST")));
				String groupCd = StringUtils.leftPad(getTrimmedString(rs.getString("GROUP_CD")), 2, '0');
				String categoryCd = StringUtils.leftPad(getTrimmedString(rs.getString("CTGRY_CD")), 2, '0');
				itemDetail.setGroupCode(groupCd);
				itemDetail.setSmic(groupCd + categoryCd);
				itemDetail.setRing(rs.getString("RING"));
				itemDetail.setRetailSection(rs.getString("RETAIL_SECT"));
				itemDetail.setCrc(rs.getInt("COMMON_CD"));
				return itemDetail;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchCicInformation);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			LOGGER.error("Failed to execute sql: {}, {}", sb, dae);
		}

		//LOGGER.debug("CIC after UPC/UT expansion : {}", itemDetails);

		return itemDetails;
	}

	private String getTrimmedString(String columnValue) throws SQLException {
		return columnValue == null ? "" : columnValue.trim();
	}

	// method to fetch initial price
	public UPCItemDetail fetchInitialPrice(UPCItemDetail item) throws SystemException {
		//LOGGER.debug("sqlFetchInitialPrice sql: {}", sqlFetchInitialPrice);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue(AppConstants.UPC_MANUF, item.getUpcManuf());
		paramSource.addValue(AppConstants.UPC_SALES, item.getUpcSales());
		paramSource.addValue(AppConstants.UPC_COUNTRY, item.getUpcCountry());
		paramSource.addValue(AppConstants.UPC_SYSTEM, item.getUpcSystem());
		paramSource.addValue(AppConstants.PRICE_AREA, item.getPriceArea());
		paramSource.addValue(AppConstants.ROG, item.getRogCd());
		try {
			item.setInitialPrice(0.00);
			item.setInitialFactor(1);
			this.namedJdbc.query(sqlFetchInitialPrice, paramSource, rs -> {
				item.setInitialPrice(rs.getDouble(AppConstants.PRICE));
				item.setInitialFactor(rs.getInt(AppConstants.PRICE_FCTR));
				item.setInitialReason(rs.getString("REASON"));
				item.setInitialReasonType(rs.getString("STATUS_PR_REC"));
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchInitialPrice);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			LOGGER.debug("No Initial Price Present");

			return item;
		}

		//LOGGER.debug("fetch InitialPrice result: {}", item.getInitialPrice());
		return item;
	}

	public int validateRetailSectionPriceArea(BasePricingMsg basePricingMsg) throws SystemException {

		//LOGGER.debug("sqlValidateRetailSectionPriceArea sql: {}", sqlValidateRetailSectionPriceArea);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("rogCd", basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());
		paramSource.addValue(AppConstants.PRICE_AREA, basePricingMsg.getPaStoreInfo());

		Integer result = null;
		try {
			result = namedJdbc.queryForObject(sqlValidateRetailSectionPriceArea, paramSource, Integer.class);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlValidateRetailSectionPriceArea);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			LOGGER.error("Failed to execute sql: :{}{}{}", basePricingMsg.getRogCd(), basePricingMsg.getCorpItemCd(), basePricingMsg.getRequestId());
			//throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}

		//LOGGER.debug("sqlValidateRetailSectionPriceArea result: {}", result);

		return (result != null) ? result.intValue() : 0;

	}

	public Double fetchPriceDiff(String rogCd) throws SystemException {
		//LOGGER.debug("fetchPriceDiff sql: {}", sqlFetchPriceDifFRange);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("rogCd", rogCd);
		Double defaultValueMissingRog = "".equals(PropertiesUtils.getProperty("ROG_RNG")) ? 0
				: Double.valueOf(PropertiesUtils.getProperty("ROG_RNG"));
		Double result = defaultValueMissingRog;
		try {
			result = namedJdbc.queryForObject(sqlFetchPriceDifFRange, paramSource, Double.class);
		} catch (DataAccessException dae) {
			return result;
		}

		//LOGGER.debug("fetchPriceDiff result: {}", result);

		return result;
	}

	public UPCItemDetail fetchPenPriceEffDate(UPCItemDetail item, String effectiveStartDate) throws SystemException {
		//LOGGER.debug("fetchPenPriceEffDate sql: {}", sqlFetchPenPriceEffDate);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue(AppConstants.UPC_MANUF, item.getUpcManuf());
		paramSource.addValue(AppConstants.UPC_SALES, item.getUpcSales());
		paramSource.addValue(AppConstants.UPC_COUNTRY, item.getUpcCountry());
		paramSource.addValue(AppConstants.UPC_SYSTEM, item.getUpcSystem());
		paramSource.addValue(AppConstants.PRICE_AREA, item.getPriceArea());
		paramSource.addValue(AppConstants.ROG, item.getRogCd());
		paramSource.addValue(AppConstants.SUGGESTED_START_DATE, effectiveStartDate);
		try {
			item.setPendingPrice(0.00);
			item.setPendingFactor(1);
			this.namedJdbc.query(sqlFetchPenPriceEffDate, paramSource, rs -> {
				item.setPendingPrice(rs.getDouble(AppConstants.PRICE));
				item.setPendingFactor(rs.getInt(AppConstants.PRICE_FCTR));
				item.setPendingReason(rs.getString("REASON"));
				item.setPendingReasonType(rs.getString("REASON_TYPE"));
				if (rs.getString(AppConstants.DATE_EFF) != null && !rs.getString(AppConstants.DATE_EFF).isEmpty()) {
					item.setEffectivePenPriceStartDate(
							BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
				}
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchPenPriceEffDate);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("fetchPenPriceEffDate result: {}", item);
		return item;
	}

	public List<Promotion> fetchPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("sqlFetchPromotionDetails sql: {}", sqlFetchPromotionDetails);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if (basePricingMsg.getIsMeatItem() && !CollectionUtils.isEmpty(basePricingMsg.getOptionalCutDetails())) {
			List<Integer> optionalCutList = basePricingMsg.getOptionalCutDetails().stream().map(cic -> {
				return cic.getOptionalCic();
			}).collect(Collectors.toList());
			if (!CollectionUtils.isEmpty(optionalCutList)) {
				optionalCutList.add(basePricingMsg.getBaseCutCic());
			}
			List<String> retailSection = new ArrayList<>();
			retailSection.add(basePricingMsg.getRetailSection());
			retailSection.add(basePricingMsg.getBaseRetailSection());
			paramSource.addValue("cic", optionalCutList);
			paramSource.addValue(AppConstants.RETAIL_SECTION, retailSection);
		} else {
			paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
			paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());
		}
		paramSource.addValue(AppConstants.PRICE_AREA, basePricingMsg.getPaStoreInfo());
		paramSource.addValue(AppConstants.ROG, basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.SUGGESTED_START_DATE, basePricingMsg.getEffectiveStartDt());

		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		List<Promotion> promotionList = null;
		try {
			promotionList = this.namedJdbc.query(sqlFetchPromotionDetails, paramSource, (rs, rowNum) -> {
				Promotion promotion = new Promotion();
				promotion.setStartDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
				promotion.setEndDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_OFF)));
				promotion.setPromotionType(rs.getString("PROMOTION_TYPE"));
				promotion.setCic(basePricingMsg.getCorpItemCd());
				promotion.setRog(basePricingMsg.getRogCd());
				promotion.setUnitType(basePricingMsg.getUnitType());
				promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
				basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());
				return promotion;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchPromotionDetails);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("sqlFetchPromotionDetails result: {}", basePricingMsg);
		return promotionList;
	}

	public List<Promotion> fetchLTSPromoitonDetails(BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("sqlFetchLtsPromotion sql: {}", sqlFetchLtsPromotion);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if (basePricingMsg.getIsMeatItem() && !CollectionUtils.isEmpty(basePricingMsg.getOptionalCutDetails())) {
			List<Integer> optionalCutList = basePricingMsg.getOptionalCutDetails().stream().map(cic -> {
				return cic.getOptionalCic();
			}).collect(Collectors.toList());
			if (!CollectionUtils.isEmpty(optionalCutList)) {
				optionalCutList.add(basePricingMsg.getBaseCutCic());

			}
			List<String> retailSection = new ArrayList<>();
			retailSection.add(basePricingMsg.getRetailSection());
			retailSection.add(basePricingMsg.getBaseRetailSection());
			paramSource.addValue("cic", optionalCutList);
			paramSource.addValue(AppConstants.RETAIL_SECTION, retailSection);
		} else {
			paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
			paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());
		}
		paramSource.addValue(AppConstants.PRICE_AREA, basePricingMsg.getPaStoreInfo());
		paramSource.addValue(AppConstants.ROG, basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.SUGGESTED_START_DATE, basePricingMsg.getEffectiveStartDt());

		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		List<Promotion> promotionList = null;
		try {
			promotionList = this.namedJdbc.query(sqlFetchLtsPromotion, paramSource, (rs, rowNum) -> {
				Promotion promotion = new Promotion();
				promotion.setStartDate(BasePriceUtil.convertStringToLocalDate(rs.getString(AppConstants.DATE_EFF)));
				promotion.setEndDate(BasePriceUtil.convertStringToLocalDate(rs.getString("DATE_LINK")));
				promotion.setPromotionType(rs.getString("PROMOTION_TYPE"));
				promotion.setCic(rs.getInt("CORP_ITEM_CD"));
				promotion.setRog(basePricingMsg.getRogCd());
				promotion.setUnitType(basePricingMsg.getUnitType());
				promotion.setPriceArea(basePricingMsg.getPaStoreInfo());
				promotion.setPrice(rs.getDouble("price"));
				promotion.setPriceFactor(rs.getInt(AppConstants.PRICE_FCTR));
				promotion.setUpcCountry(rs.getInt("UPC_COUNTRY"));
				promotion.setUpcManuf(rs.getInt("UPC_MANUF"));
				promotion.setUpcSales(rs.getInt("UPC_SALES"));
				promotion.setUpcSystem(rs.getInt("UPC_SYSTEM"));
				basePricingMsg.setRetailSection(basePricingMsg.getRetailSection());
				return promotion;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchLtsPromotion);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("sqlFetchPromotionDetails result: {}", basePricingMsg);
		return promotionList;
	}

	@Override
	public UPCItemDetail fetchBibSwitches(UPCItemDetail itemDetail, BasePricingMsg basePricingMsg)
			throws SystemException {

		//LOGGER.debug("sqlFetchBibSwitches sql: {}", sqlFetchBibSwitches);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("rogCd", itemDetail.getRogCd());
		paramSource.addValue(AppConstants.RETAIL_SECTION, basePricingMsg.getRetailSection());

		List<UPCItemDetail> itemDetailList = null;
		try {
			itemDetailList = this.namedJdbc.query(sqlFetchBibSwitches, paramSource, (rs, rowNum) -> {
				UPCItemDetail upcItemDetail = new UPCItemDetail();
				upcItemDetail.setSendBibDef(rs.getString("SEND_BIB_DEF"));
				upcItemDetail.setSendNewItmDef(rs.getString("SND_NEW_ITM_DEF"));

				return upcItemDetail;
			});
			if (itemDetailList.isEmpty()) {
				itemDetail.setSendBibDef(" ");
				itemDetail.setSendNewItmDef(" ");
				itemDetailList.add(itemDetail);
			}
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchBibSwitches);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}

		/*
		 * LOGGER.debug(
		 * "sqlFetchBibSwitches result: SendBibDef: {}  SendLabelSw: {}  SendNewItemDef: {}  SendPriceSw: {} "
		 * , itemDetailList.get(0).getSendBibDef(),
		 * itemDetailList.get(0).getSendLabelSw(),
		 * itemDetailList.get(0).getSendNewItmDef(),
		 * itemDetailList.get(0).getSendPriceSw());
		 */
		return itemDetailList.get(0);
	}

	public List<PendingPriceData> fetchPendingItemDetailToDelete(List<PendingPriceData> pendingPriceDataList)
			throws SystemException {
		//LOGGER.debug("sqlFetchStoreSpecificDetails sql: {}", sqlFetchPenPrcToDelete);
		List<PendingPriceData> promotionList = new ArrayList<>();
		try {
			pendingPriceDataList.forEach(item -> {
				List<PendingPriceData> promotionStoreList = null;
				MapSqlParameterSource paramSource = new MapSqlParameterSource();
				paramSource.addValue(AppConstants.UPC_MANUF, item.getUpcManuf());
				paramSource.addValue(AppConstants.UPC_SALES, item.getUpcSales());
				paramSource.addValue(AppConstants.UPC_COUNTRY, item.getUpcCountry());
				paramSource.addValue(AppConstants.UPC_SYSTEM, item.getUpcSystem());
				paramSource.addValue("paStoreInfo", item.getPaStoreInfo());
				paramSource.addValue("rogCd", item.getRogCd());
				paramSource.addValue("effectiveStartDt", item.getEffectiveStartDt());

				promotionStoreList = this.namedJdbc.query(sqlFetchPenPrcToDelete, paramSource, (rs, rowNum) -> {
					PendingPriceData promotion = new PendingPriceData();
					promotion.setEffectiveStartDt(rs.getString(AppConstants.DATE_EFF));
					promotion.setSuggPrice(rs.getDouble(AppConstants.PRICE));
					promotion.setUpcManuf(item.getUpcManuf());
					promotion.setUpcSales(item.getUpcSales());
					promotion.setUpcCountry(item.getUpcCountry());
					promotion.setUpcSystem(item.getUpcSystem());
					promotion.setPaStoreInfo(item.getPaStoreInfo());
					promotion.setRogCd(item.getRogCd());

					return promotion;
				});
				promotionList.addAll(promotionStoreList);
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchPenPrcToDelete);
			sb.append(AppConstants.SQL_PARAM);
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		//LOGGER.debug("sqlFetchPromotionDetails result: {}", promotionList.size());
		return promotionList;
	}

	public List<OptionalCutDetail> fetchOptionalCuts(BasePricingMsg basePricingMsg) throws SystemException {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("cic", basePricingMsg.getCorpItemCd());
		paramSource.addValue(AppConstants.UNIT_TYPE, basePricingMsg.getUnitType());
		paramSource.addValue("rogCd", basePricingMsg.getRogCd());
		paramSource.addValue(AppConstants.PRICE_AREA, basePricingMsg.getPaStoreInfo());

		List<OptionalCutDetail> optionalCuts = new ArrayList<>();
		try {
			optionalCuts = this.namedJdbc.query(sqlFetchOptionalCut, paramSource, (rs, rowNum) -> {
				OptionalCutDetail optionalCutDetail = new OptionalCutDetail();
				optionalCutDetail.setOptionalCic(rs.getInt("CORP_ITEM_OPTIONAL"));
				optionalCutDetail.setOptionalItemGap(rs.getDouble("OPT_ITEM_GAP"));
				return optionalCutDetail;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchOptionalCut);
			sb.append(AppConstants.SQL_PARAM);
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}
		return optionalCuts;
	}

	@Override
	public UPCItemDetail fetchInitialPriceBaseCut(String item, String rog, String priceArea) throws SystemException {
		//LOGGER.debug("sqlFetchInitialPriceBaseCut sql: {}", sqlFetchInitialPriceBaseCut);

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("cic", item);
		paramSource.addValue(AppConstants.PRICE_AREA, priceArea);
		paramSource.addValue(AppConstants.ROG, rog);
		Double result = null;
		UPCItemDetail initialItem = new UPCItemDetail();
		try {
			this.namedJdbc.query(sqlFetchInitialPriceBaseCut, paramSource, rs -> {
				initialItem.setInitialPrice(rs.getDouble(AppConstants.PRICE));
				initialItem.setInitialFactor(rs.getInt(AppConstants.PRICE_FCTR));
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append(AppConstants.SQL);
			sb.append(sqlFetchInitialPriceBaseCut);
			sb.append(AppConstants.SQL_PARAM);
			sb.append(paramSource.getValues().toString());
			//LOGGER.debug("No Initial Price Present");
		}

		//LOGGER.debug("fetch sqlFetchInitialPriceBaseCut result: {}", result);
		return initialItem;

	}

}
