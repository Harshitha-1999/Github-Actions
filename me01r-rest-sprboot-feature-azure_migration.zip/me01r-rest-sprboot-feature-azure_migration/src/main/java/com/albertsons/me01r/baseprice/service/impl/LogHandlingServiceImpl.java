package com.albertsons.me01r.baseprice.service.impl;

import static com.albertsons.me01r.baseprice.util.ConstantsUtil.DEFAULT_INBOUND_VALIDATION_MESSAGE;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.albertsons.me01r.baseprice.dao.LogHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.LogMsg;
import com.albertsons.me01r.baseprice.model.PendingPriceData;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.service.LogHandlingService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;

@Service
public class LogHandlingServiceImpl implements LogHandlingService {
	private static final Logger LOGGER = LoggerFactory.getLogger(LogHandlingServiceImpl.class);

	@Value("${application.user.id}")
	private String appId;

	@Autowired
	private Environment env;

	@Autowired
	private LogHandlingDAO logHandlingDAO;

	@Override
	public void insertInitialPriceLog(BasePricingMsg basePricingMsg, List<ItemPriceData> itemPriceDataList,
			String msgCd) throws SystemException {
		List<LogMsg> logMsgList = prepareInitialPriceLog(basePricingMsg, itemPriceDataList, msgCd);
		logHandlingDAO.insertLogMessage(logMsgList);
	}

	@Override
	public void insertPendingPriceLog(List<LogMsg> logMsgList) throws SystemException {
		logHandlingDAO.insertLogMessage(logMsgList);
	}

	@Override
	public void insertStorePriceLog(List<LogMsg> logMsgList) throws SystemException {
		logHandlingDAO.insertLogMessage(logMsgList);

	}

	private List<LogMsg> prepareInitialPriceLog(BasePricingMsg basePricingMsg, List<ItemPriceData> itemPriceDataList,
			String msgCd) {
		return itemPriceDataList.stream().map(itemDetail -> {
			LogMsg logMsg = new LogMsg();
			updateLogMessage(basePricingMsg, logMsg);
			logMsg.setUpcCountry(itemDetail.getUpcCountry());
			logMsg.setUpcSystem(itemDetail.getUpcSystem());
			logMsg.setUpcManuf(itemDetail.getUpcManuf());
			logMsg.setUpcSales(itemDetail.getUpcSales());
			logMsg.setStatCd(msgCd);
			logMsg.setMsgNm(ConstantsUtil.SPACE);
			logMsg.setRemTxt("");
			logMsg.setMsgSysCd(ConstantsUtil.SPACE);
			logMsg.setCrtUsrId(appId);
			logMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
			logMsg.setRequestId(basePricingMsg.getRequestId());
			logMsg.setTotalCount(basePricingMsg.getTotalCount());
			logMsg.setRecordCount(basePricingMsg.getRecordCount());
			return logMsg;
		}).collect(Collectors.toList());
	}

	public List<LogMsg> preparePendingPriceLog(BasePricingMsg basePricingMsg, List<PendingPriceData> itemPriceDataList,
			String msgCd, String msg) {
		return itemPriceDataList.stream().map(itemDetail -> {
			LogMsg logMsg = new LogMsg();
			updateLogMessage(basePricingMsg, logMsg);
			logMsg.setUpcCountry(itemDetail.getUpcCountry());
			logMsg.setUpcSystem(itemDetail.getUpcSystem());
			logMsg.setUpcManuf(itemDetail.getUpcManuf());
			logMsg.setUpcSales(itemDetail.getUpcSales());
			logMsg.setStatCd(msgCd);
			logMsg.setMsgNm(ConstantsUtil.SPACE);
			logMsg.setRemTxt("");

			if (msgCd.equalsIgnoreCase(ConstantsUtil.D)) {
				logMsg.setRemTxt(ConstantsUtil.DELETE_DATE + itemDetail.getEffectiveStartDt() + " and Price as : "
						+ itemDetail.getSuggPrice());
				logMsg.setMsgNm(ConstantsUtil.DELETE_FUTURE_PRICE);
				logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.DELETE_FUTURE_PRICE));
			}

			if (msgCd.equalsIgnoreCase(ConstantsUtil.P)) {
				if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt())
						.isEqual(BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt()))) {
					if (!StringUtils.isEmpty(msg)) {
						logMsg.setRemTxt(msg);
						logMsg.setStatCd(ConstantsUtil.U);
						if (msg.contains(ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE)) {
							logMsg.setMsgNm(ConstantsUtil.EFF_START_WEEKEND);
							logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFF_START_WEEKEND));
						} else {
							logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_START_DATE_REVISED);
							logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_START_DATE_REVISED));
						}
					}
				} else {
					logMsg.setRemTxt(ConstantsUtil.NONE);
				}
			}
			if (msgCd.equalsIgnoreCase(ConstantsUtil.U)) {
				logMsg.setRemTxt("Price Updated from :" + itemDetail.getSuggPrice() + " to "
						+ basePricingMsg.getSuggPrice() + " for date " + itemDetail.getEffectiveStartDt().toString());
				logMsg.setStatCd(ConstantsUtil.U);
				logMsg.setMsgNm(ConstantsUtil.LTS_PRICE_UPDATED);
			}
			logMsg.setMsgSysCd(ConstantsUtil.SPACE);// to be changed
			logMsg.setCrtUsrId(appId);
			logMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
			return logMsg;
		}).collect(Collectors.toList());
	}

	public List<LogMsg> prepareStorePriceLog(BasePricingMsg basePricingMsg, List<StorePriceData> storePriceDataList,
			String msgCd, @NotNull String msg) {
		ArrayList<LogMsg> logMsgList = new ArrayList<>();
		for (StorePriceData itemDetail : storePriceDataList) {

			LogMsg logMsg = new LogMsg();
			updateLogMessage(basePricingMsg, logMsg);
			logMsg.setMsgSysCd(ConstantsUtil.SPACE);
			logMsg.setUpcCountry(itemDetail.getUpcCountry());
			logMsg.setUpcSystem(itemDetail.getUpcSystem());
			logMsg.setUpcManuf(itemDetail.getUpcManuf());
			logMsg.setUpcSales(itemDetail.getUpcSales());
			logMsg.setStatCd(msgCd);
			logMsg.setMsgNm(ConstantsUtil.SPACE);
			if (msgCd.equalsIgnoreCase(ConstantsUtil.U)) {
				if (!itemDetail.getEndDate().isEqual(BasePriceUtil.convertStringToLocalDate(itemDetail.getDateOff()))
						|| !itemDetail.getStartDate()
								.isEqual(BasePriceUtil.convertStringToLocalDate(itemDetail.getDateEff()))
						|| !BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt()).isEqual(
								BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt()))
						|| !BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt()).isEqual(
								BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectivEndtDt()))) {

					logMsg.setRemTxt(msg);

				} else {
					logMsg.setRemTxt(ConstantsUtil.NONE);
				}

				if (!StringUtils.isEmpty(msg)) {
					if (msg.contains(ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE)) {
						logMsg.setMsgNm(ConstantsUtil.EFF_START_WEEKEND);
						logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFF_START_WEEKEND));
					} else if (msg.contains(ConstantsUtil.START_DATE_UPDATED_FROM)) {
						logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_START_DATE_REVISED);
						logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_START_DATE_REVISED));
					} else {
						logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_END_DATE_REVISED);
						logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_END_DATE_REVISED));
					}
				}
				if (basePricingMsg.getStartDateDueToPromotion() != null) {
					logMsg.setRemTxt(ConstantsUtil.STORE_SPLIT + ConstantsUtil.EFF_DATE + " :"
							+ basePricingMsg.getInboundEffectiveStartDt() + " and " + ConstantsUtil.OFF_DATE
							+ basePricingMsg.getInboundEffectivEndtDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
					logMsg.setMsgNm(ConstantsUtil.STORE_SPECIFIC_SPLIT);
				}
			}
			if (msgCd.equalsIgnoreCase(ConstantsUtil.D)) {
				logMsg.setRemTxt(ConstantsUtil.DELETE_DATE + itemDetail.getDateEff());
				logMsg.setMsgNm(ConstantsUtil.DELETE_SS_PRICE);
				logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.DELETE_SS_PRICE));
			}
			if (msgCd.equalsIgnoreCase(ConstantsUtil.P)) {

				if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt())
						.isEqual(BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt()))
						|| !BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt()).isEqual(
								BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectivEndtDt()))) {
					logMsg.setStatCd(ConstantsUtil.U);
					if (null == msg) {
						if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt()).isEqual(
								BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt()))) {
							logMsg.setRemTxt(ConstantsUtil.START_DATE_UPDATED_FROM
									+ basePricingMsg.getUpdatedEffectiveStartDt() + " to "
									+ basePricingMsg.getEffectiveStartDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
							// logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_START_DATE_REVISED);
							// logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_START_DATE_REVISED));
						}
						if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt()).isEqual(
								BasePriceUtil.convertStringToLocalDate(basePricingMsg.getUpdatedEffectivEndtDt()))) {
							String encoded = Encode.forHtml("END_DATE_UPDATED" + basePricingMsg.toString());
							logMsg.setRemTxt(ConstantsUtil.END_DATE_UPDATED_FROM
									+ basePricingMsg.getUpdatedEffectivEndtDt() + " to "
									+ basePricingMsg.getEffectiveEndDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
							// logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_END_DATE_REVISED);
							// logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_END_DATE_REVISED));
						}

					} else {
						logMsg.setRemTxt(msg);
						if (msg.contains(ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE)) {
							logMsg.setMsgNm(ConstantsUtil.EFF_START_WEEKEND);
							logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFF_START_WEEKEND));
						} else if (msg.contains(ConstantsUtil.START_DATE_UPDATED_FROM)) {
							logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_START_DATE_REVISED);
							logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_START_DATE_REVISED));
						} else {
							logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_END_DATE_REVISED);
							logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_END_DATE_REVISED));
						}
					}
				} else {
					logMsg.setRemTxt(ConstantsUtil.NONE);
				}
				if (!StringUtils.isEmpty(basePricingMsg.getInboundEffectiveStartDt())
						&& !StringUtils.isEmpty(basePricingMsg.getInboundEffectivEndtDt())) {
					if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt()).isEqual(
							BasePriceUtil.convertStringToLocalDate(basePricingMsg.getInboundEffectiveStartDt()))
							|| !BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt())
									.isEqual(BasePriceUtil
											.convertStringToLocalDate(basePricingMsg.getInboundEffectivEndtDt()))) {
						logMsg.setStatCd(ConstantsUtil.U);
						if (DEFAULT_INBOUND_VALIDATION_MESSAGE.equals(msg)) {
							if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt())
									.isEqual(BasePriceUtil
											.convertStringToLocalDate(basePricingMsg.getInboundEffectiveStartDt()))) {
								logMsg.setMsgNm(ConstantsUtil.STORE_SPECIFIC_SPLIT);
								logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.STORE_SPECIFIC_SPLIT));
								logMsg.setRemTxt(ConstantsUtil.STORE_SPLIT + ConstantsUtil.EFF_DATE + " :"
										+ basePricingMsg.getEffectiveStartDt() + " and " + ConstantsUtil.OFF_DATE
										+ basePricingMsg.getEffectiveEndDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
							}
							if (!BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt())
									.isEqual(BasePriceUtil
											.convertStringToLocalDate(basePricingMsg.getInboundEffectivEndtDt()))) {
								logMsg.setMsgNm(ConstantsUtil.STORE_SPECIFIC_SPLIT);
								logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.STORE_SPECIFIC_SPLIT));
								logMsg.setRemTxt(ConstantsUtil.STORE_SPLIT + ConstantsUtil.EFF_DATE + " :"
										+ basePricingMsg.getEffectiveStartDt() + " and " + ConstantsUtil.OFF_DATE
										+ basePricingMsg.getEffectiveEndDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
							}

						} else {
							logMsg.setRemTxt(msg);
							if (msg.contains(ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE)) {
								logMsg.setMsgNm(ConstantsUtil.EFF_START_WEEKEND);
								logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFF_START_WEEKEND));
							} else if (msg.contains(ConstantsUtil.START_DATE_UPDATED_FROM)) {
								logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_START_DATE_REVISED);
								logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_START_DATE_REVISED));
							} else {
								logMsg.setMsgNm(ConstantsUtil.EFFECTIVE_END_DATE_REVISED);
								logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.EFFECTIVE_END_DATE_REVISED));
							}
						}
					} else {
						logMsg.setRemTxt(ConstantsUtil.NONE);
					}
				}
				if (!StringUtils.isEmpty(basePricingMsg.getStartDateDueToPromotion())) {
					if ((null == basePricingMsg.getInboundEffectiveStartDt()
							|| null == basePricingMsg.getInboundEffectivEndtDt())) {

						if (!StringUtils.isEmpty(msg) && (!msg.contains(ConstantsUtil.START_DATE_ON_WEEKEND_MESSAGE)
								&& !msg.contains(ConstantsUtil.LTS_PROMOTION))) {
							logMsg.setStatCd(ConstantsUtil.U);
							logMsg.setMsgNm(ConstantsUtil.STORE_SPECIFIC_SPLIT);
							logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.STORE_SPECIFIC_SPLIT));
							logMsg.setRemTxt(ConstantsUtil.STORE_SPLIT + ConstantsUtil.EFF_DATE + " :"
									+ basePricingMsg.getEffectiveStartDt() + " and " + ConstantsUtil.OFF_DATE
									+ basePricingMsg.getEffectiveEndDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
						}
					}
					if (DEFAULT_INBOUND_VALIDATION_MESSAGE.equals(msg)) {
						logMsg.setStatCd(ConstantsUtil.U);
						logMsg.setMsgNm(ConstantsUtil.STORE_SPECIFIC_SPLIT);
						logMsg.setMsgSysCd(env.getProperty(ConstantsUtil.STORE_SPECIFIC_SPLIT));
						logMsg.setRemTxt(ConstantsUtil.STORE_SPLIT + ConstantsUtil.EFF_DATE + " :"
								+ basePricingMsg.getEffectiveStartDt() + " and " + ConstantsUtil.OFF_DATE
								+ basePricingMsg.getEffectiveEndDt() + ConstantsUtil.STORE_SPECIFIC_PROMOTION);
					}
				}

			}

			logMsg.setCrtUsrId(appId);
			logMsg.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
			logMsgList.add(logMsg);
		}
		return logMsgList;

	}

	private void updateLogMessage(BasePricingMsg basePricingMsg, LogMsg logMsg) {
		logMsg.setCrcId(basePricingMsg.getCrcId());
		logMsg.setCic(basePricingMsg.getCorpItemCd());
		logMsg.setUnitType(basePricingMsg.getUnitType());
		logMsg.setRogCd(basePricingMsg.getRogCd());
		logMsg.setRtlSection(basePricingMsg.getRetailSection());
		logMsg.setPaStoreInfo(basePricingMsg.getPaStoreInfo());
		logMsg.setRcmdLvl(basePricingMsg.getSuggLevel());
		logMsg.setRcmdPrc(basePricingMsg.getSuggPrice());
		logMsg.setScenarioId(basePricingMsg.getScenarioId());
		logMsg.setScenarioNm(basePricingMsg.getScenarioName());
		logMsg.setEffStrtDt(basePricingMsg.getEffectiveStartDt());
		logMsg.setEffEndDt(basePricingMsg.getEffectiveEndDt());
		logMsg.setScenarioFl(basePricingMsg.getScenarioFlg());
		logMsg.setProjectSls(basePricingMsg.getProjectedSales());
		logMsg.setProjectMgn(basePricingMsg.getProjectedMargin());
		logMsg.setProjectUnt(basePricingMsg.getProjectedUnits());
		logMsg.setPriceFctr(basePricingMsg.getPriceFactor());
		logMsg.setPriceRsnCd(basePricingMsg.getPriceOverrideReason());
		logMsg.setLstUpdtUsrTs(Timestamp.valueOf(basePricingMsg.getLastUpdUserTs()));
		logMsg.setLstUpdtUsrId(basePricingMsg.getLastUpdUserId());
		logMsg.setCoMsgCd(ConstantsUtil.SPACE);
		logMsg.setRptIndicator(ConstantsUtil.SPACE);
		logMsg.setRequestId(basePricingMsg.getRequestId());
		logMsg.setTotalCount(basePricingMsg.getTotalCount());
		logMsg.setRecordCount(basePricingMsg.getRecordCount());
	}

}
