package com.albertsons.me01r.baseprice.model;

import java.time.LocalDate;

public class StorePriceData {

	private String rogCd;
	private String facility;
	private Integer upcManuf;
	private Integer upcSales;
	private Integer upcCountry;
	private Integer upcSystem;
	private String dateEff;
	private String dateOff;
	private Double price;
	private Integer priceFctr;
	private String reasonPrice;
	private String lstUpdUsrId;
	private Integer pluCd;
	private LocalDate startDate;
	private LocalDate endDate;
	private String promotionType;
	private String dateEffStoreSpecific;
	private String dateOffStoreSpecific;
	private Integer cic;

	public String getRogCd() {
		return rogCd;
	}

	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public Integer getUpcManuf() {
		return upcManuf;
	}

	public void setUpcManuf(Integer upcManuf) {
		this.upcManuf = upcManuf;
	}

	public Integer getUpcSales() {
		return upcSales;
	}

	public void setUpcSales(Integer upcSales) {
		this.upcSales = upcSales;
	}

	public Integer getUpcCountry() {
		return upcCountry;
	}

	public void setUpcCountry(Integer upcCountry) {
		this.upcCountry = upcCountry;
	}

	public Integer getUpcSystem() {
		return upcSystem;
	}

	public void setUpcSystem(Integer upcSystem) {
		this.upcSystem = upcSystem;
	}

	public String getDateEff() {
		return dateEff;
	}

	public void setDateEff(String dateEff) {
		this.dateEff = dateEff;
	}

	public String getDateOff() {
		return dateOff;
	}

	public void setDateOff(String dateOff) {
		this.dateOff = dateOff;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getPriceFctr() {
		return priceFctr;
	}

	public void setPriceFctr(Integer priceFctr) {
		this.priceFctr = priceFctr;
	}

	public String getReasonPrice() {
		return reasonPrice;
	}

	public void setReasonPrice(String reasonPrice) {
		this.reasonPrice = reasonPrice;
	}

	public String getLstUpdUsrId() {
		return lstUpdUsrId;
	}

	public void setLstUpdUsrId(String lstUpdUsrId) {
		this.lstUpdUsrId = lstUpdUsrId;
	}

	public Integer getPluCd() {
		return pluCd;
	}

	public void setPluCd(Integer pluCd) {
		this.pluCd = pluCd;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getPromotionType() {
		return promotionType;
	}

	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}

	public String getDateEffStoreSpecific() {
		return dateEffStoreSpecific;
	}

	public void setDateEffStoreSpecific(String dateEffStoreSpecific) {
		this.dateEffStoreSpecific = dateEffStoreSpecific;
	}

	public String getDateOffStoreSpecific() {
		return dateOffStoreSpecific;
	}

	public void setDateOffStoreSpecific(String dateOffStoreSpecific) {
		this.dateOffStoreSpecific = dateOffStoreSpecific;
	}

	public Integer getCic() {
		return cic;
	}

	public void setCic(Integer cic) {
		this.cic = cic;
	}

}
