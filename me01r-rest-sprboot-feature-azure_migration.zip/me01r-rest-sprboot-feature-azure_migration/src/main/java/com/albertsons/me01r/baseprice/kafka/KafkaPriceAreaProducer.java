package com.albertsons.me01r.baseprice.kafka;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaPriceAreaProducer {

	private static final String kafkaErrorMessgae = "Failed to send message in kafka message due to wrong Json format : ";

	protected final static Logger LOGGER = LoggerFactory.getLogger(KafkaPriceAreaProducer.class);

	@Autowired
	private KafkaTemplate<String, String> kakfaTemplate;

	@Value("${me01r.topic.price}")
	private String topicBasePricingPriceAreaInput;
	
	public void sendMsg(BasePricingMessages basePricingMsg) throws SystemException {

		try {
			String msg = new ObjectMapper().writeValueAsString(basePricingMsg);
			LOGGER.debug("sending msg='{}'", msg);
			Message<String> message = MessageBuilder.withPayload(msg)
					.setHeader(KafkaHeaders.TOPIC, topicBasePricingPriceAreaInput)
					.build();
			kakfaTemplate.send(message);
		} catch (KafkaException jse) {
			LOGGER.error(kafkaErrorMessgae, jse);
			throw BasePriceUtil.getSystemException(kafkaErrorMessgae, basePricingMsg);
		} catch (Exception e) {
			LOGGER.error(kafkaErrorMessgae, e);
			throw BasePriceUtil.getSystemException(kafkaErrorMessgae, basePricingMsg);
		}
	}
}
