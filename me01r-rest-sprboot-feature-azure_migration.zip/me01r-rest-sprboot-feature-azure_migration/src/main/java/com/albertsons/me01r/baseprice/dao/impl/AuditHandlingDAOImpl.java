package com.albertsons.me01r.baseprice.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.dao.AuditHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;

@Repository
public class AuditHandlingDAOImpl implements AuditHandlingDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuditHandlingDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.update.audit.details}")
	private String sqlUpdateAuditDetails;

	@Override
	public int insertAuditMsg(List<AuditMsg> auditList) throws SystemException {

		//LOGGER.debug("UpdateAuditDetails sql: {}", sqlUpdateAuditDetails);

		int[] result = null;
		SqlParameterSource[] paramSource = null;
		try {
			long start = System.currentTimeMillis();
			paramSource = SqlParameterSourceUtils.createBatch(auditList.toArray());
			result = namedJdbc.batchUpdate(sqlUpdateAuditDetails, paramSource);
			long end = System.currentTimeMillis();
			long execution = end - start;
			LOGGER.info("Time taken to insert the message in MEFMAUDT DB{}", execution);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append("SQL: ");
			sb.append(sqlUpdateAuditDetails);
			sb.append(" SQLparam: ");
			sb.append(paramSource);
			//throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
			LOGGER.error("UpdateAuditDetails result: {}", result);
		}

		//LOGGER.debug("UpdateAuditDetails result: {}", result);
		if (result != null) {
			return result.length;
		}
		return 0;
	}

}
