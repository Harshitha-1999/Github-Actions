package com.albertsons.me01r.baseprice.dao;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.ErrorMsg;

public interface ErrorHandlingDAO {

	public void insertErrorMessage(List<ErrorMsg> errorMessage) throws SystemException;
}
