package com.albertsons.me01r.baseprice.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.dao.ErrorHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.ErrorMsg;

@Repository
public class ErrorHandlingDAOImpl implements ErrorHandlingDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandlingDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.insert.error.details}")
	private String sqlInsertErrorDetails;

	@Override
	public void insertErrorMessage(List<ErrorMsg> errorMessage) throws SystemException {

		//LOGGER.debug("InsertErrorDetails sql: {}", sqlInsertErrorDetails);

		SqlParameterSource[] params = null;
		int[] result = null;
		try {
			long start = System.currentTimeMillis();
			params = SqlParameterSourceUtils.createBatch(errorMessage.toArray());
			result = this.namedJdbc.batchUpdate(sqlInsertErrorDetails, params);
			long end = System.currentTimeMillis();
			long execution = end - start;
			LOGGER.info("Time taken to insert the message in MERCPRLG DB = {}", execution);
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append("SQL: ");
			sb.append(sqlInsertErrorDetails);
			sb.append(" SQLparam: ");
			sb.append(params);
			LOGGER.error(dae.getMessage(), dae);
			throw new SystemException("Failed to execute sql: " + sb.toString() + errorMessage.toString(), dae);
		}
		//LOGGER.debug("InsertErrorDetails result: {}", result.length);

	}

}
