package com.albertsons.me01r.baseprice.service.impl;

import static com.albertsons.me01r.baseprice.util.ConstantsUtil.DEFAULT_INBOUND_VALIDATION_MESSAGE;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.context.update.StoreLevelUpdateContext;
import com.albertsons.me01r.baseprice.dao.StorePriceUpdateDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.AuditMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.LogMsg;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.AuditHandlingService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.LogHandlingService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.service.StorePriceService;
import com.albertsons.me01r.baseprice.service.StorePriceUpdateService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.albertsons.me01r.baseprice.util.TableUtil;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Service
public class StorePriceUpdateServiceImpl implements StorePriceUpdateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StorePriceUpdateServiceImpl.class);

	@Value("NO-PRICE-ON-PROMO")
	private String noPrcForRog;

	@Value("FUT-EFF-DATE-LMT")
	private String invalidDayDiff;

	@Autowired
	StorePriceUpdateDAO storePriceUpdateDAO;

	@Autowired
	AuditHandlingService auditHandlingService;

	@Autowired
	private LogHandlingService logHandlingService;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private StorePriceService storePriceService;

	@Autowired
	private MessageHandlingService messageHandlingService;

	@Override
	@Transactional(rollbackFor = SystemException.class)
	public void addItemPrice(StoreLevelUpdateContext sLupdatedContext, ValidationContext validationContext)
			throws SystemException, Exception {

		if (!CollectionUtils.isEmpty(sLupdatedContext.getCommonContext().getCicInfo())) {

			/*
			 * LOGGER.debug( "Updating store price for Items: {} and Facility: {}",
			 * sLupdatedContext.getCommonContext().getCicInfo() ,
			 * sLupdatedContext.getBasePricingMsg().getPaStoreInfo());
			 */

			// PO 171
			List<LogMsg> logMsgList = new ArrayList<>();
			List<StorePriceData> storeSpecificDetails = storePriceService.fetchStoreSpecificDetails(
					sLupdatedContext.getStorePriceUpcList(), validationContext.getBasePricingMsg());
			List<StorePriceData> updateStoreSpecificList = new ArrayList<>();
			List<StorePriceData> deleteStoreSpecificList = new ArrayList<>();
			if (!CollectionUtils.isEmpty(storeSpecificDetails)) {
				storeSpecificDetails.forEach(storeDetail -> {
					if (storeDetail.getPromotionType().trim().isEmpty()) {
						fetchStoreSpecificRetailToUpdate(storeDetail, sLupdatedContext, updateStoreSpecificList,
								deleteStoreSpecificList);
					} else {
						updateStoreSpecificPromotion(storeDetail, sLupdatedContext);
					}
				});
			}
			List<ErrorMsg> errorMsgList = new ArrayList<>();
			validateEffStartDateAndEndDate(sLupdatedContext.getBasePricingMsg(),
					sLupdatedContext.getCommonContext().getCicInfo(), errorMsgList);
			if (CollectionUtils.isEmpty(errorMsgList)) {
				// update store specific retail
				updateStoreSpecific(updateStoreSpecificList);

				// delete store specific retail
				deleteStoreSpecific(deleteStoreSpecificList);

				// Add Store Price
				addAsStoreItemPrice(sLupdatedContext);
				// prepare Log Message

				if (!CollectionUtils.isEmpty(sLupdatedContext.getCommonContext().getDateChange())) {
					List<String> messages = sLupdatedContext.getCommonContext().getDateChange().stream().distinct()
							.collect(Collectors.toList());
					messages.forEach(msg -> {
						List<LogMsg> updateStoreLogList = logHandlingService.prepareStorePriceLog(
								sLupdatedContext.getBasePricingMsg(), updateStoreSpecificList, ConstantsUtil.U, msg);
						logMsgList.addAll(updateStoreLogList);
					});
				} else {
					List<LogMsg> updateStoreLogList = logHandlingService.prepareStorePriceLog(
							sLupdatedContext.getBasePricingMsg(), updateStoreSpecificList, ConstantsUtil.U,
							DEFAULT_INBOUND_VALIDATION_MESSAGE);
					logMsgList.addAll(updateStoreLogList);
				}
				List<LogMsg> deleteStoreLogList = logHandlingService.prepareStorePriceLog(
						sLupdatedContext.getBasePricingMsg(), deleteStoreSpecificList, ConstantsUtil.D,
						DEFAULT_INBOUND_VALIDATION_MESSAGE);
				logMsgList.addAll(deleteStoreLogList);

				// PO-170,599,600 - Perform the Auditing of the inserted store price.
				List<AuditMsg> auditMsgList = new ArrayList<>();

				List<AuditMsg> spAuditMsg = prepareAuditMsg(sLupdatedContext.getBasePricingMsg(),
						sLupdatedContext.getStorePriceUpcList(), TableUtil.SSSPCRTL, ConstantsUtil.P);

				List<AuditMsg> spUpdateAuditMsg = prepareAuditMsg(sLupdatedContext.getBasePricingMsg(),
						updateStoreSpecificList, TableUtil.SSSPCRTL, ConstantsUtil.U);
				List<AuditMsg> spDeleteAuditMsg = prepareAuditMsg(sLupdatedContext.getBasePricingMsg(),
						deleteStoreSpecificList, TableUtil.SSSPCRTL, ConstantsUtil.D);

				auditMsgList.addAll(spAuditMsg);
				auditMsgList.addAll(spUpdateAuditMsg);
				auditMsgList.addAll(spDeleteAuditMsg);

				// insert in MEFMAUDT
				if (!auditMsgList.isEmpty()) {
					auditHandlingService.insertAuditMsg(auditMsgList);
				}

				// Logging the input message
				if (!CollectionUtils.isEmpty(sLupdatedContext.getCommonContext().getDateChange().stream().distinct()
						.collect(Collectors.toList()))
						&& (CollectionUtils.isEmpty(logMsgList) || !CollectionUtils.isEmpty(deleteStoreLogList))) {
					sLupdatedContext.getCommonContext().getDateChange().stream().distinct().collect(Collectors.toList())
							.forEach(msg -> {
								List<LogMsg> insertStoreList = logHandlingService.prepareStorePriceLog(
										sLupdatedContext.getBasePricingMsg(), sLupdatedContext.getStorePriceUpcList(),
										ConstantsUtil.P, msg);
								logMsgList.addAll(insertStoreList);
							});
				} else {
					List<LogMsg> insertStoreList = logHandlingService.prepareStorePriceLog(
							sLupdatedContext.getBasePricingMsg(), sLupdatedContext.getStorePriceUpcList(),
							ConstantsUtil.P, DEFAULT_INBOUND_VALIDATION_MESSAGE);
					logMsgList.addAll(insertStoreList);
				}
				List<LogMsg> inValidList = logMsgList.stream()
						.filter(logMsg -> StringUtils.isEmpty(logMsg.getMsgNm().trim())
								&& !StringUtils.isEmpty(logMsg.getRemTxt().trim()))
						.collect(Collectors.toList());
				logMsgList.removeAll(inValidList);
				List<LogMsg> inValidMsgList = logMsgList.stream()
						.filter(logMsg -> logMsg.getRemTxt() != null
								&& logMsg.getRemTxt().trim().equalsIgnoreCase(DEFAULT_INBOUND_VALIDATION_MESSAGE))
						.collect(Collectors.toList());
				logMsgList.removeAll(inValidMsgList);
				insertStorePriceLog(logMsgList);
			}

		}
		if (!sLupdatedContext.getBasePricingMsg().isHasStoreSplit()
				&& !CollectionUtils.isEmpty(sLupdatedContext.getBasePricingMsg().getOptionalCutDetails())
				&& !sLupdatedContext.getBasePricingMsg().getIsOptionalCut()) {
			messageHandlingService.processMeatItem(sLupdatedContext.getBasePricingMsg(), validationContext);
		}
		if (!sLupdatedContext.getBasePricingMsg().isHasStoreSplit()
				&& !StringUtils.isEmpty(sLupdatedContext.getBasePricingMsg().getStartDateDueToPromotion())
				&& BasePriceUtil
						.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getStartDateDueToPromotion())
						.isBefore(BasePriceUtil.convertStringToLocalDate(
								sLupdatedContext.getBasePricingMsg().getUpdatedEffectivEndtDt()))) {
			messageHandlingService.processStoreSplit(sLupdatedContext.getBasePricingMsg(), validationContext);
		}
	}

	private void validateEffStartDateAndEndDate(BasePricingMsg basePricingMsg, List<UPCItemDetail> list,
			List<ErrorMsg> errorMsgList) throws Exception {
		Long validDaysDiff = "".equals(PropertiesUtils.getProperty("VALID_DAY")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("VALID_DAY"));
		Long startEndValidDays = "".equals(PropertiesUtils.getProperty("ST_DT_CHCK")) ? 0
				: Long.valueOf(PropertiesUtils.getProperty("ST_DT_CHCK"));

		LocalDate effStartdate = BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveStartDt());
		LocalDate inboundStartDate = BasePriceUtil
				.convertStringToLocalDate(basePricingMsg.getUpdatedEffectiveStartDt());
		LocalDate effEndDate = BasePriceUtil.convertStringToLocalDate(basePricingMsg.getEffectiveEndDt());
		List<String> errorList = new ArrayList<>();
		if (inboundStartDate.plusDays(validDaysDiff).isBefore(effStartdate)) {
			errorList.add(noPrcForRog);
		}
		if (effStartdate.plusDays(startEndValidDays).isAfter(effEndDate)) {
			errorList.add(noPrcForRog);
		}
		if (!CollectionUtils.isEmpty(errorList)) {
			// List<ErrorMsg> errorMsgList;
			try {
				errorMsgList.addAll(prepareErrorMsg(basePricingMsg, list, errorList, ConstantsUtil.E));
				insertError(errorMsgList);
			} catch (Exception e) {
				throw new Exception("Failed validation rule(s) " + basePricingMsg);
			}
		}
	}

	private void insertError(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingService.insertErrorMessage(errorMessage);
	}

	private List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd) throws SystemException {
		return errorHandlingService.prepareErrorMsg(basePriceMsg, itemDetailList, statCd, errorList);
	}

	private void deleteStoreSpecific(List<StorePriceData> deleteStoreSpecificList) throws SystemException {
		storePriceUpdateDAO.deleteItemStoreRetail(deleteStoreSpecificList);

	}

	private void updateStoreSpecificPromotion(StorePriceData storeDetail, StoreLevelUpdateContext sLupdatedContext) {
		if (!sLupdatedContext.getCommonContext().isSmicExclusion()) {
			LocalDate effStartdate = BasePriceUtil
					.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getEffectiveStartDt());
			String inboundDate = sLupdatedContext.getBasePricingMsg().getEffectiveStartDt();
			String inboundEndDate = sLupdatedContext.getBasePricingMsg().getEffectiveEndDt();
			LocalDate effEndDate = BasePriceUtil
					.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getEffectiveEndDt());
			if ((storeDetail.getStartDate().isBefore(effStartdate) || storeDetail.getStartDate().isEqual(effStartdate))
					&& (effStartdate.isBefore(storeDetail.getEndDate())
							|| effStartdate.isEqual(storeDetail.getEndDate()))) {
				LocalDate updatedDate = storeDetail.getEndDate().plusDays(1);
				sLupdatedContext.getBasePricingMsg().setEffectiveStartDt(updatedDate.toString());
				if (!inboundDate.equalsIgnoreCase(sLupdatedContext.getBasePricingMsg().getEffectiveStartDt())) {
					sLupdatedContext.getCommonContext().getDateChange()
							.add(ConstantsUtil.START_DATE_UPDATED_FROM + inboundDate + " to "
									+ sLupdatedContext.getBasePricingMsg().getEffectiveStartDt()
									+ ConstantsUtil.STORE_SPECIFIC_PROMOTION);
				}
				sLupdatedContext.getStorePriceUpcList().stream().forEach(cic -> cic.setDateEff(updatedDate.toString()));
			}
			if (effStartdate.isBefore(storeDetail.getStartDate()) && effEndDate.isAfter(storeDetail.getStartDate())) {
				LocalDate updatedDate = storeDetail.getStartDate().minusDays(1);
				sLupdatedContext.getBasePricingMsg().setEffectiveEndDt(updatedDate.toString());
				sLupdatedContext.getStorePriceUpcList().stream().forEach(cic -> cic.setDateOff(updatedDate.toString()));
				if (!inboundEndDate.equalsIgnoreCase(sLupdatedContext.getBasePricingMsg().getEffectiveEndDt())) {
					sLupdatedContext.getCommonContext().getDateChange()
							.add(ConstantsUtil.END_DATE_UPDATED_FROM + inboundEndDate + " to "
									+ sLupdatedContext.getBasePricingMsg().getEffectiveEndDt()
									+ ConstantsUtil.STORE_SPECIFIC_PROMOTION);
					sLupdatedContext.getBasePricingMsg()
							.setStartDateDueToPromotion(storeDetail.getEndDate().plusDays(1).toString());
				}
			}
		}
	}

	private void fetchStoreSpecificRetailToUpdate(StorePriceData storeDetail, StoreLevelUpdateContext sLupdatedContext,
			List<StorePriceData> updateStoreSpecificList, List<StorePriceData> deleteStoreSpecificList) {
		LocalDate effStartdate = BasePriceUtil
				.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getEffectiveStartDt());
		LocalDate effEndDate = BasePriceUtil
				.convertStringToLocalDate(sLupdatedContext.getBasePricingMsg().getEffectiveEndDt());
		String storeEndDate = storeDetail.getEndDate().toString();
		if (storeDetail.getStartDate().isBefore(effStartdate) && !storeDetail.getEndDate().isBefore(effStartdate)) {
			storeDetail.setEndDate(effStartdate.minusDays(1));
			storeDetail.setDateOffStoreSpecific(storeDetail.getEndDate().toString());
			if (!updateStoreSpecificList.stream()
					.anyMatch(upc -> upc.getUpcCountry().equals(storeDetail.getUpcCountry())
							&& upc.getUpcSystem().equals(storeDetail.getUpcSystem())
							&& upc.getUpcSales().equals(storeDetail.getUpcSales())
							&& upc.getUpcManuf().equals(storeDetail.getUpcManuf()))) {
				updateStoreSpecificList.add(storeDetail);
			}
			sLupdatedContext.getCommonContext().getDateChange().add(ConstantsUtil.END_DATE_UPDATED_FROM + storeEndDate
					+ " to " + storeDetail.getEndDate() + ConstantsUtil.STORE_SPECIFIC_RETAIL);
		}
		if ((effStartdate.isBefore(storeDetail.getStartDate()) || effStartdate.isEqual(storeDetail.getStartDate()))
				&& (effEndDate.isAfter(storeDetail.getStartDate()) || effEndDate.isEqual(storeDetail.getStartDate()))
				&& storeDetail.getStartDate().isAfter(LocalDate.now())
				&& sLupdatedContext.getBasePricingMsg().getCorpItemCd().equals(storeDetail.getCic())) {
			deleteStoreSpecificList.add(storeDetail);
		}

	}

	private void addAsStoreItemPrice(StoreLevelUpdateContext sLupdatedContext) throws SystemException {
		storePriceUpdateDAO.insertItemStorePriceBatch(sLupdatedContext.getStorePriceUpcList());
	}

	private void updateStoreSpecific(List<StorePriceData> updateStoreSpecificList) throws SystemException {
		storePriceUpdateDAO.updateItemStoreRetail(updateStoreSpecificList);
	}

	private List<AuditMsg> prepareAuditMsg(BasePricingMsg basePricingMsg, List<StorePriceData> storePricingList,
			String flow, String operation) throws SystemException {
		return auditHandlingService.prepareAuditMsgStorePrice(basePricingMsg, storePricingList, flow, operation);
	}

	private void insertStorePriceLog(List<LogMsg> logMsgList) throws SystemException {
		logHandlingService.insertStorePriceLog(logMsgList);
	}

}
