package com.albertsons.me01r.baseprice.service;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingHeader;
import com.albertsons.me01r.baseprice.model.BasePricingHeaderJson;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.BasePricingMsgJson;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;

public interface ErrorHandlingService {

	public void insertErrorMessage(List<ErrorMsg> errorMessage) throws SystemException;

	public void insertNonNumericErrorMessage(BasePricingMsgJson basePricingMsgJson, List<String> errorList)
			throws SystemException;

	public List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePricingMsg, List<UPCItemDetail> itemDetailList,
			String statCd, List<String> errorList) throws SystemException;

	public List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePricingMsg, List<UPCItemDetail> itemDetailList,
			String statCd, List<String> errorList, String tableName, String errorCode) throws SystemException;

	public List<ErrorMsg> prepareGroupCdExistsSmicError();

	public List<ErrorMsg> prepareInvlaidRecordCount(BasePricingHeaderJson priceChangeHeader);

	public List<ErrorMsg> prepareCorruptMessage(BasePricingHeaderJson priceChangeHeader);

	public List<ErrorMsg> prepareMismatchRecordCount(BasePricingMessages basePricingMsgs);

	public void insertNonRollBackErrorMessage(List<ErrorMsg> errorMsgList) throws SystemException;

	public List<ErrorMsg> prepareInvlaidPriceLevel(BasePricingHeader priceChangeHeader, String priceLevel);
}
