package com.albertsons.me01r.baseprice.dao.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.dao.PropertyLoadDAO;

@Repository
public class PropertyLoadDAOImpl implements PropertyLoadDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(PropertyLoadDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.fetch.config.values}")
	private String sqlFetchConfigValues;

	@Override
	public List<Map<String, Object>> loadProperties() {
		//LOGGER.debug("fetch config values sql: {}", sqlFetchConfigValues);
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		try {
			List<Map<String, Object>> configs = namedJdbc.queryForList(sqlFetchConfigValues, paramSource);
			return configs;
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append("SQL: ");
			sb.append(sqlFetchConfigValues);
			sb.append(" SQLparam: ");
			LOGGER.error("Failed to execute sql: {}", sb);
		}
		return null;

	}
}
