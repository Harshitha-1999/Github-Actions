package com.albertsons.me01r.baseprice.validator.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.albertsons.me01r.baseprice.context.update.InitialPricingUpdateContext;
import com.albertsons.me01r.baseprice.context.update.PriceAreaUpdateContext;
import com.albertsons.me01r.baseprice.dao.ValidateStorePriceDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.ItemPriceData;
import com.albertsons.me01r.baseprice.model.OptionalCutDetail;
import com.albertsons.me01r.baseprice.model.UPCItemDetail;
import com.albertsons.me01r.baseprice.service.CommonValidationService;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.PriceAreaUpdateService;
import com.albertsons.me01r.baseprice.util.BasePriceUtil;
import com.albertsons.me01r.baseprice.util.ConstantsUtil;
import com.albertsons.me01r.baseprice.validator.StorePriceValidator;
import com.albertsons.me01r.baseprice.validator.ValidatorImpl;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

@Component
@Qualifier("StorePriceValidatorImpl")
public class StorePriceValidatorImpl implements ValidatorImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonValidatorImpl.class);
	@Autowired
	@Qualifier("CommonValidatorImpl")
	ValidatorImpl commonValidatorImpl;
	@Autowired
	private List<StorePriceValidator> storeValidators;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private ValidateStorePriceDAO validateStorePriceDAO;

	@Autowired
	PriceAreaUpdateService priceAreaUpdateService;

	@Autowired
	CommonValidationService commonValidationService;

	@Override
	public ValidationContext validate(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException, Exception {

		//LOGGER.debug("StorePriceValidators validation.");

		// TODO is there any store specific SQL, if not, no need to update
		// ValidationContext udpatedContext = updateValidationContext(basePricingMsg,
		// context);

		for (StorePriceValidator storeValidator : getValidators()) {
			storeValidator.validate(basePricingMsg, context);
		}

		handleValidationResult(basePricingMsg, context);

		ValidationContext updatedContext = updateValidationContext(basePricingMsg, context);

		return updatedContext;
	}

	private void handleValidationResult(BasePricingMsg basePricingMsg, ValidationContext context) throws Exception {

		List<ErrorMsg> errorMsgList = new ArrayList<>();
		List<ErrorMsg> seasonalUpcErrorList = handleSeasonalUpc(basePricingMsg, context);
		List<ErrorMsg> missingPaPriceUpcErrorList = handleMissingUpcInPaPricing(basePricingMsg, context);
		List<ErrorMsg> invalidPriceDiffErrorList = handleInvalidPriceDiffWarning(basePricingMsg, context);
		List<ErrorMsg> invalidSamePriceErrorList = handleSamePriceError(basePricingMsg, context);

		if (!CollectionUtils.isEmpty(invalidPriceDiffErrorList)) {
			errorMsgList.addAll(invalidPriceDiffErrorList);
		}

		if (!CollectionUtils.isEmpty(invalidSamePriceErrorList)) {
			errorMsgList.addAll(invalidSamePriceErrorList);
		}

		if (!CollectionUtils.isEmpty(seasonalUpcErrorList)) {
			errorMsgList.addAll(seasonalUpcErrorList);
		}

		if (!CollectionUtils.isEmpty(missingPaPriceUpcErrorList)) {
			errorMsgList.addAll(missingPaPriceUpcErrorList);
		}
		List<ErrorMsg> warningList = new ArrayList<>();
		// if (!context.getErrorType().getMsgList().isEmpty() &&
		// context.getCommonContext().getCicInfo().isEmpty()) {
		if (!context.getErrorTypeMsgList().isEmpty() && context.getCommonContext().getCicInfo().isEmpty()) {
			List<UPCItemDetail> itemDetailList = new ArrayList<>();
			List<ErrorMsg> errorList = prepareErrorMsg(basePricingMsg, itemDetailList, context.getErrorTypeMsgList(),
					context.getErrorTypeInd());
			// context.getErrorType().getMsgList(), context.getErrorType().getMsgTypeInd());
			// warningList = handleDateWarning(basePricingMsg, itemDetailList,
			// context.getWarningType().getMsgList(),
			// context.getWarningType().getMsgTypeInd(), context);
			warningList = handleDateWarning(basePricingMsg, itemDetailList, context.getWarningTypeMsgList(),
					context.getWarningTypeInd(), context);
			errorMsgList.addAll(errorList);
			/*
			 * if (!CollectionUtils.isEmpty(warningList)) {
			 * errorMsgList.addAll(warningList); }
			 */
			insertError(errorMsgList);
			throw BasePriceUtil.getSystemException("Failed validation rule(s) ", basePricingMsg);
		}
		if (null != context.getCommonContext().getCicInfo() && !context.getCommonContext().getCicInfo().isEmpty()) {
			List<UPCItemDetail> itemDetailList = context.getCommonContext().getCicInfo();
			// warningList = handleDateWarning(basePricingMsg, itemDetailList,
			// context.getWarningType().getMsgList(),
			// context.getWarningType().getMsgTypeInd(), context);
			warningList = handleDateWarning(basePricingMsg, itemDetailList, context.getWarningTypeMsgList(),
					context.getWarningTypeInd(), context);
			if (!CollectionUtils.isEmpty(warningList)) {
				errorMsgList.addAll(warningList);
			}
			// check if error is present
			// if (!context.getErrorType().getMsgList().isEmpty()) {
			if (!context.getErrorTypeMsgList().isEmpty()) {
				List<ErrorMsg> errorList = prepareErrorMsg(basePricingMsg, itemDetailList,
						context.getErrorTypeMsgList(), context.getErrorTypeInd());
				errorMsgList.addAll(errorList);
				insertError(errorMsgList);
				throw BasePriceUtil.getSystemException("Failed validation rule(s) ", basePricingMsg);
			}

		}
		insertError(errorMsgList);

	}

	private List<ErrorMsg> handleDateWarning(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd, ValidationContext context) throws SystemException {
		// if (!CollectionUtils.isEmpty(context.getWarningType().getMsgList())) {
		if (!CollectionUtils.isEmpty(context.getWarningTypeMsgList())) {
			return prepareErrorMsg(basePriceMsg, itemDetailList, errorList, statCd);
		}
		return null;
	}

	private List<ErrorMsg> handleInvalidPriceDiffWarning(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getInvalidPriceDiffUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getInvalidPriceDiffUpc(),
					Arrays.asList(ConstantsUtil.PRICE_CHG_EXCEEDS), context.getInvalidPriceDiffUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleSamePriceError(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getSamePriceUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getSamePriceUpc(),
					Arrays.asList(ConstantsUtil.CURRENT_PRICE_SAME_AS_SGGESTED), context.getSamePriceUpcInd());
		}
		return null;
	}

	private void insertError(List<ErrorMsg> errorMessage) throws SystemException {
		errorHandlingService.insertErrorMessage(errorMessage);
	}

	private List<ErrorMsg> prepareErrorMsg(BasePricingMsg basePriceMsg, List<UPCItemDetail> itemDetailList,
			List<String> errorList, String statCd) throws SystemException {
		return errorHandlingService.prepareErrorMsg(basePriceMsg, itemDetailList, statCd, errorList);
	}
	// Removed as per JIRA# PO-1319
	/*
	 * private List<ErrorMsg> handleDiscontinuedUpc(BasePricingMsg basePricingMsg,
	 * ValidationContext context) throws SystemException { if
	 * (!context.getDiscontinuedUpc().getupcList().isEmpty()) { return
	 * prepareErrorMsg(basePricingMsg, context.getDiscontinuedUpc().getupcList(),
	 * Arrays.asList(ConstantsUtil.DISCONTINUED_ITEM_INFO),
	 * context.getDiscontinuedUpc().getMsgTypeInd()); } return null; }
	 */

	private List<ErrorMsg> handleSeasonalUpc(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException {
		if (!context.getSeasonalPriceDiffUpc().isEmpty()) {
			return prepareErrorMsg(basePricingMsg, context.getSeasonalPriceDiffUpc(),
					Arrays.asList(ConstantsUtil.SEASONAL_ITEM), context.getSeasonalPriceDiffUpcInd());
		}
		return null;
	}

	private List<ErrorMsg> handleMissingUpcInPaPricing(BasePricingMsg basePricingMsg, ValidationContext context)
			throws Exception {
		if (!CollectionUtils.isEmpty(context.getCommonContext().getCicInfo())) {
			List<UPCItemDetail> invalidItems = context.getCommonContext().getCicInfo().stream()
					.filter(upc -> !upc.isUpcExists()).collect(Collectors.toList());
			//LOGGER.info("UPC(s) not available in ITMPRC table: {}", invalidItems);
			if (!CollectionUtils.isEmpty(invalidItems)) {
				if (!basePricingMsg.getIsOptionalCut()) {
					return prepareErrorMsg(basePricingMsg, invalidItems, Arrays.asList(ConstantsUtil.PRICE_NOT_SETUP),
							ConstantsUtil.E);
				} else {
					priceOptionalCut(basePricingMsg, invalidItems, context);
				}
			}
		}
		return null;
	}

	private void priceOptionalCut(BasePricingMsg basePricingMsg, List<UPCItemDetail> invalidItems,
			ValidationContext context) throws Exception {
		String facility = basePricingMsg.getPaStoreInfo();
		UPCItemDetail baseCutDetail = validateStorePriceDAO.fetchInitialPriceBaseCut(
				String.valueOf(basePricingMsg.getBaseCutCic()), basePricingMsg.getRogCd(),
				basePricingMsg.getPaStoreInfo(), basePricingMsg.getRetailSection());
		String priceArea = validateStorePriceDAO.fetchPriceArea(basePricingMsg.getRogCd(),
				basePricingMsg.getPaStoreInfo(), basePricingMsg.getRetailSection());
		double amount = 0;
		int factor = 0;
		double inboundAmount = basePricingMsg.getSuggPrice();
		int inboundFactor = basePricingMsg.getPriceFactor();
		for (OptionalCutDetail cic : basePricingMsg.getOptionalCutDetails()) {
			if (cic.getOptionalCic().equals(basePricingMsg.getCorpItemCd())) {
				amount = cic.getOptionalItemGap() + baseCutDetail.getInitialPrice();
				factor = baseCutDetail.getInitialFactor();
			}
		}
		if (amount != basePricingMsg.getSuggPrice() || factor != basePricingMsg.getPriceFactor()) {
			InitialPricingUpdateContext ipUpdateContext = new InitialPricingUpdateContext();
			PriceAreaUpdateContext paUpdateContext = new PriceAreaUpdateContext();
			ipUpdateContext.setBasePricingMsg(basePricingMsg);
			ipUpdateContext.getBasePricingMsg().setPaStoreInfo(priceArea);
			ipUpdateContext.getBasePricingMsg().setSuggPrice(amount);
			ipUpdateContext.getBasePricingMsg().setPriceFactor(factor);
			ipUpdateContext.setCommonContext(context.getCommonContext());
			ipUpdateContext.getCommonContext().setCicInfo(invalidItems);
			ipUpdateContext.getCommonContext().setCicInfo(toggleItemBibSwitch(ipUpdateContext));
			ipUpdateContext.setItemPriceDataList(getInitialPriceDataList(ipUpdateContext, priceArea));
			priceAreaUpdateService.addItemPrice(ipUpdateContext, paUpdateContext, context);
			ipUpdateContext.getBasePricingMsg().setPaStoreInfo(facility);
			ipUpdateContext.getBasePricingMsg().setSuggPrice(inboundAmount);
			ipUpdateContext.getBasePricingMsg().setPriceFactor(inboundFactor);
			context.setBasePricingMsg(basePricingMsg);
		}

	}

	private UPCItemDetail fetchItemBibSwitches(UPCItemDetail upcItemDetail, BasePricingMsg basePriceMsg)
			throws SystemException {
		UPCItemDetail item = commonValidationService.fetchItemBibSwitches(upcItemDetail, basePriceMsg);
		return item;
	}

	private List<UPCItemDetail> toggleItemBibSwitch(InitialPricingUpdateContext ipUpdateContext)
			throws SystemException {

		List<UPCItemDetail> itemDetailList = ipUpdateContext.getCommonContext().getCicInfo().stream().map(item -> {

			UPCItemDetail retItem = new UPCItemDetail();
			try {
				retItem = fetchItemBibSwitches(item, ipUpdateContext.getBasePricingMsg());
			} catch (SystemException e) {
				LOGGER.error(e.getMessage(), e);
			}
			// This if condition can be removed, as it is handled in DAO Layer.
			if (null != retItem && null != retItem.getSendBibDef() && null != retItem.getSendNewItmDef()) {
				item.setSendBibDef(retItem.getSendBibDef());
				item.setSendNewItmDef(retItem.getSendNewItmDef());
			} else {
				item.setSendBibDef(ConstantsUtil.SPACE);
				item.setSendNewItmDef(ConstantsUtil.SPACE);
			}
			if (item.getUpcSystem() == 4 && item.getUpcCountry() == 0) {
				if (item.getPluCd() == 0) {
					item.setSendPriceSw(ConstantsUtil.D);
				} else {
					item.setSendPriceSw(ConstantsUtil.P);
				}
			} else {
				if (item.getPluCd() == 0) {
					item.setSendPriceSw(ConstantsUtil.U);
				} else {
					item.setSendPriceSw(ConstantsUtil.B);
				}
			}
			item.setSendLabelSw(ConstantsUtil.Y);
			return item;

		}).collect(Collectors.toList());

		return itemDetailList;
	}

	private List<ItemPriceData> getInitialPriceDataList(InitialPricingUpdateContext ipUpdateContext, String priceArea)
			throws SystemException {
		List<ItemPriceData> itemPriceDataList = ipUpdateContext.getCommonContext().getCicInfo().stream()
				.map(itemDetail -> {
					ItemPriceData itemPriceData = new ItemPriceData();
					itemPriceData.setCorp(itemDetail.getCorp());
					itemPriceData.setRogCd(itemDetail.getRogCd());
					itemPriceData.setDivision(itemDetail.getDivision());
					itemPriceData.setUpcManuf(itemDetail.getUpcManuf());
					itemPriceData.setUpcSales(itemDetail.getUpcSales());
					itemPriceData.setUpcCountry(itemDetail.getUpcCountry());
					itemPriceData.setUpcSystem(itemDetail.getUpcSystem());
					itemPriceData.setReason(itemDetail.getReason());
					itemPriceData.setReasonType(itemDetail.getReasonType());
					itemPriceData.setEffectiveStartDt(ipUpdateContext.getBasePricingMsg().getEffectiveStartDt());
					itemPriceData.setPaStoreInfo(priceArea);
					itemPriceData.setCrcId(ipUpdateContext.getBasePricingMsg().getCrcId());
					itemPriceData.setSuggPrice(ipUpdateContext.getBasePricingMsg().getSuggPrice());
					itemPriceData.setPriceFactor(ipUpdateContext.getBasePricingMsg().getPriceFactor());
					itemPriceData.setLastUpdUserId(ipUpdateContext.getBasePricingMsg().getLastUpdUserId());
					itemPriceData.setUnitType(ipUpdateContext.getBasePricingMsg().getUnitType());
					itemPriceData.setSensitiveItem(itemDetail.getSensitiveItem());
					itemPriceData.setSendPriceSw(itemDetail.getSendPriceSw());
					itemPriceData.setSendLabelSw(itemDetail.getSendLabelSw());
					itemPriceData.setSendBibDef(itemDetail.getSendBibDef());
					itemPriceData.setSendNewItmDef(itemDetail.getSendNewItmDef());
					itemPriceData.setCic(itemDetail.getCorpItemCd());
					itemPriceData.setRupcStatus(itemDetail.getRupcStatus());
					itemPriceData.setRetStatus(itemDetail.getRetStatus());
					itemPriceData.setPluCd(itemDetail.getPluCd());
					return itemPriceData;
				}).collect(Collectors.toList());
		return itemPriceDataList;
	}

	private ValidationContext updateValidationContext(BasePricingMsg basePricingMsg, ValidationContext context)
			throws SystemException, Exception {

		List<UPCItemDetail> invalidItems = context.getCommonContext().getCicInfo().stream()
				.filter(upc -> !upc.isUpcExists()).collect(Collectors.toList());
		if (basePricingMsg.getIsOptionalCut() && !CollectionUtils.isEmpty(invalidItems)) {
			basePricingMsg.setEffectiveEndDt(basePricingMsg.getUpdatedEffectivEndtDt());
			basePricingMsg.setEffectiveStartDt(basePricingMsg.getUpdatedEffectiveStartDt());
			context = commonValidatorImpl.validate(basePricingMsg, null);
		}

		context.getCommonContext().getCicInfo().removeIf(cic -> cic.getRupcStatus().equalsIgnoreCase(ConstantsUtil.S));
		context.getCommonContext().getCicInfo().removeIf(cic -> !cic.isPriceValid());
		context.getCommonContext().getCicInfo().removeIf(cic -> !cic.isUpcExists());
		context.setBasePricingMsg(basePricingMsg);

		return context;
	}

	private List<StorePriceValidator> getValidators() {

		if (storeValidators == null) {
			LOGGER.error("No StorePriceValidator Available!");
			storeValidators = new ArrayList<>();
		}
		return storeValidators;
	}
}
