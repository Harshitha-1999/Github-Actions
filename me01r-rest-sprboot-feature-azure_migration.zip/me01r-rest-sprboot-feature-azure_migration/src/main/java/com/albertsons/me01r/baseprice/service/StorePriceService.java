package com.albertsons.me01r.baseprice.service;

import java.util.List;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.StorePriceData;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface StorePriceService {

	public void process(ValidationContext validationContext) throws SystemException, Exception;

	public List<StorePriceData> fetchStoreSpecificDetails(List<StorePriceData> storePriceUpcList,
			BasePricingMsg basePricingMsg) throws SystemException;
}
