package com.albertsons.me01r.baseprice.model;

public class GeneralLogMsg {
	
	private String msgStatus; 
	
	//TODO
	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();

		return sb.toString();
	}

	public String getMsgStatus() {
		return msgStatus;
	}

	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}
}
