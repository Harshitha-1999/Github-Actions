package com.albertsons.me01r.baseprice.service;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessages;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.model.PriceLevel;
import com.albertsons.me01r.baseprice.validator.context.ValidationContext;

public interface MessageHandlingService {

	public void processMeatItem(BasePricingMsg basePricingMsg, ValidationContext validationContext)
			throws SystemException;

	public BasePricingMessages processIncomingMessage(InboundMessage message, PriceLevel priceLevel)
			throws SystemException, Exception;

	public void processStoreSplit(BasePricingMsg basePricingMsg, ValidationContext validationContext)
			throws SystemException;

}
