package com.albertsons.me01r.baseprice.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.albertsons.me01r.baseprice.dao.MessageHandlingDAO;
import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMsg;
import com.albertsons.me01r.baseprice.model.CICItemDetail;

@Repository
public class MessageHandlingDAOImpl implements MessageHandlingDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(MessageHandlingDAOImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedJdbc;

	@Value(value = "${sql.fetch.crc.info}")
	private String sqlFetchCrcInformation;

	@Override
	public List<CICItemDetail> fetchCrcInformation(BasePricingMsg basePricingMsg) throws SystemException {
		//LOGGER.debug("validateCrc sql: {}", sqlFetchCrcInformation);
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("crcId", basePricingMsg.getCrcId());
		paramSource.addValue("unitType", basePricingMsg.getUnitType());
		paramSource.addValue("rogCd", basePricingMsg.getRogCd());

		List<CICItemDetail> itemDetails = new ArrayList<>();
		try {
			itemDetails = this.namedJdbc.query(sqlFetchCrcInformation, paramSource, (rs, rowNum) -> {
				CICItemDetail itemDetail = new CICItemDetail();
				itemDetail.setCrcId(basePricingMsg.getCrcId());
				itemDetail.setCorpItemCd(rs.getInt("CORP_ITEM_CD"));
				itemDetail.setUnitType(rs.getInt("UNIT_TYPE"));
				itemDetail.setRogCd(getTrimmedString(rs.getString("ROG")));
				itemDetail.setPriceArea(basePricingMsg.getPaStoreInfo());
				return itemDetail;
			});
		} catch (DataAccessException dae) {
			StringBuilder sb = new StringBuilder();
			sb.append("SQL: ");
			sb.append(sqlFetchCrcInformation);
			sb.append(" SQLparam: ");
			sb.append(paramSource.getValues().toString());
			throw new SystemException("Failed to execute sql: " + sb.toString(), dae);
		}

		//LOGGER.debug("CRC after UPC/UT expansion : {}", itemDetails);

		return itemDetails;
	}

	private String getTrimmedString(String columnValue) {
		return columnValue == null ? "" : columnValue.trim();
	}

}
