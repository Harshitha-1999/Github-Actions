package com.albertsons.me01r.baseprice.util;

public class TableUtil {

	public static final String SSITMPRC = "SSITMPRC";
	public static final String SSITMPOS = "SSITMPOS";
	public static final String SSITMROG = "SSITMROG";
	public static final String SSITMURX = "SSITMURX";
	public static final String SSPENPRC = "SSPENPRC";
	public static final String SSSPCRTL = "SSSPCRTL";
	public static final String SSHISPRC = "SSHISPRC";
	

	public static final String REPORT_SWITCH_NEW = "N";
	public static final String REPORT_SWITCH_CHG = "C";
	public static final String REPORT_SWITCH_DEL = "D";

	public static final String SSITMPRC_FIELD_NAME = " ";
	public static final String SSITMPOS_FIELD_NAME = "PAL-SW";
	public static final String SSITMROG_FIELD_NAME = "STATUS-RET";
	public static final String SSITMURX_FIELD_NAME = "STATUS-RUPC";
	public static final String SSPENPRC_FIELD_NAME = " ";
	public static final String SSSPCRTL_FIELD_NAME = " ";
	public static final String SSPENPRC_FIELD_NAME_UPDATE = "PRICE/PRICE_FCTR";
	public static final String SSSPCRTL_FIELD_NAME_UPDATE = "DATE_EFF/DATE_OFF";

}
