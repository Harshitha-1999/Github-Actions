package com.albertsons.me01r.baseprice.model;

public class CICItemDetail {
	
	private Integer crcId;
	private Integer corpItemCd;
	private Integer unitType;
	private String rogCd;
	private String priceArea;
	
	public Integer getCrcId() {
		return crcId;
	}
	public void setCrcId(Integer crcId) {
		this.crcId = crcId;
	}
	public Integer getCorpItemCd() {
		return corpItemCd;
	}
	public void setCorpItemCd(Integer corpItemCd) {
		this.corpItemCd = corpItemCd;
	}
	public Integer getUnitType() {
		return unitType;
	}
	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}
	public String getRogCd() {
		return rogCd;
	}
	public void setRogCd(String rogCd) {
		this.rogCd = rogCd;
	}
	public String getPriceArea() {
		return priceArea;
	}
	public void setPriceArea(String priceArea) {
		this.priceArea = priceArea;
	}

}
