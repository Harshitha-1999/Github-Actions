package com.albertsons.me01r.baseprice.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.service.GroupCodeValidateService;

@Component
public class GroupCodeValidator {
	@Autowired
	private GroupCodeValidateService service;

	public void validate() throws SystemException {
		service.validateGroupCode();
	}
}
