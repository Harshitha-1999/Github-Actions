package com.albertsons.me01r.baseprice.kafka;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.albertsons.me01r.baseprice.exception.SystemException;
import com.albertsons.me01r.baseprice.model.BasePricingMessagesJson;
import com.albertsons.me01r.baseprice.model.ErrorMsg;
import com.albertsons.me01r.baseprice.model.InboundMessage;
import com.albertsons.me01r.baseprice.model.PriceLevel;
import com.albertsons.me01r.baseprice.service.ErrorHandlingService;
import com.albertsons.me01r.baseprice.service.GroupCodeValidateService;
import com.albertsons.me01r.baseprice.service.MessageHandlingService;
import com.albertsons.me01r.baseprice.util.PropertiesUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaPriceAreaConsumer {

	@Autowired
	MessageHandlingService messageHandlingService;

	@Autowired
	private GroupCodeValidateService groupCodeValidateService;

	@Autowired
	private ErrorHandlingService errorHandlingService;

	@Autowired
	private PropertiesUtils propertyUtil;
	

	private static final String KAFKA_EXCEPTION_MESSAGE="Price Area : Unable to Process Inbound Message ";

	@Value("CRC-RECORD-INCLDS-CIC")
	private String crcCicExist;
	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaPriceAreaConsumer.class);

	@KafkaListener(topics = "#{'${me01r.topic.price}'}", groupId = "#{'${me01r.group}'}")
	public void onMessage(@Payload String message)
			throws IOException, SystemException {
		LOGGER.info("Payload : {}", message);
		InboundMessage inboundMessage = new InboundMessage(message);
		try {
			LOGGER.debug("Inside method onMessage() in KafkaPriceAreaConsumer.");
			propertyUtil.loadProperties();
			groupCodeValidateService.validateGroupCode();
			processPriceAreaMessage(inboundMessage); 
		} catch (Exception ex) {
			LOGGER.error("Error occured while processing", ex.getMessage());
			try {
				corruptMessageError(inboundMessage);
			} catch (Exception e) {
				LOGGER.error("Error occured while inserting into the error table");
			} 
		}
	}

	private void corruptMessageError(InboundMessage message)
			throws IOException, SystemException {
		BasePricingMessagesJson basePricingMsgsJson = null;
		basePricingMsgsJson = new ObjectMapper().readValue(message.getPayload(), BasePricingMessagesJson.class);
		List<ErrorMsg> baseMessageErrorList = errorHandlingService
				.prepareCorruptMessage(basePricingMsgsJson.getPriceChangeHeader());
		List<ErrorMsg> errorMsgList = baseMessageErrorList;
		errorHandlingService.insertNonRollBackErrorMessage(errorMsgList);
	}

	private void processPriceAreaMessage(InboundMessage msg)
			throws IOException, SystemException {
		try {
			messageHandlingService.processIncomingMessage(msg, PriceLevel.PA);

		} catch (Exception ex) {
			try {
				corruptMessageError(msg);
			} catch (Exception e) {
				LOGGER.error("Error occured while inserting into the error table");
			} 
			LOGGER.error(KAFKA_EXCEPTION_MESSAGE, ex);
		} 
	}

}
