package com.albertsons.me01r.baseprice.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.Signature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

@Aspect
@Configuration
public class CommonJoinPointConfig {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonJoinPointConfig.class);
	
	@Around("execution(* com.albertsons.me01r.baseprice.dao.impl.*.*(..))")
	public Object aroundDAOImplMethods(ProceedingJoinPoint joinPoint) throws Throwable {
				
        try {
    		long startTime = System.currentTimeMillis();
            Object result = joinPoint.proceed();
     		long timeTaken = System.currentTimeMillis() - startTime;
    		//LOGGER.info("TIME_TRACKING by {}={}", joinPoint, timeTaken);
             return result;
        } catch (Exception ex){
            Signature sig = joinPoint.getSignature();
            Object[] args = joinPoint.getArgs();
			StringBuilder sb = new StringBuilder();
			sb.append(sig.getDeclaringTypeName());
			sb.append(".");
			sb.append(sig.getName());
			sb.append(", args=");
			sb.append(Arrays.toString(args));
            LOGGER.warn("DAO Exception Details: {}", sb, ex);
            throw(ex);
        }
	}
}
