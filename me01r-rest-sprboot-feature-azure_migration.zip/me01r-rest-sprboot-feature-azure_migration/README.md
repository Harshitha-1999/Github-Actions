# me01r-rest-sprboot

Local Setup Steps:

Clone Application in STS or any IDE.
Update below details in src/main/resources/application.yml file in Local Profile.
  - `Username` : med0001r
  - `password` : Get from Azure key vault or Connect to AKS team.
  - `ssl.keystore.location` : Get certificate from AKS team and place in your local folder and update local folder location in this field.
  - `ssl.keystore.password` : Get from Azure key vault or Connect to AKS team.
  - `kafka.sasl.username`   : me01r-01
  - `kafka.sasl.password`   : Get from Azure key vault or Connect to AKS team.

  ```
   spring:
  config: 
    activate:
      on-profile: Local
  datasource:
    url: jdbc:db2://dv01.safeway.com:484/DBU4
    driverClassName: com.ibm.db2.jcc.DB2Driver
    username: med0001r
    password: 
  kafka:
    consumer:
      bootstrap-servers: dgm010cd4.albertsons.com:9095, dgm010cd5.albertsons.com:9095, dgm010cd6.albertsons.com:9095
      group-id: ME01R_CG_001_Azure
      auto-offset-reset: earliest
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.apache.kafka.common.serialization.StringDeserializer
    producer:
      bootstrap-servers: dgm010cd4.albertsons.com:9095, dgm010cd5.albertsons.com:9095, dgm010cd6.albertsons.com:9095
    properties:
      sasl.jaas.config:  org.apache.kafka.common.security.scram.ScramLoginModule required username='me01r-01' password='';
      sasl.mechanism: SCRAM-SHA-512
      security.protocol: SASL_SSL
      ssl.keystore.location: D:/me01r/me01r-identity-kafka-dev.jks
      ssl.keystore.password: 
sql:
  schema: DEVSQL3
me01r:
  topic:
     price: ME01R_C02_DEV_BASEPRICING_PRICEAREA_INPUT
     store : ME01R_C02_DEV_BASEPRICING_STORE_INPUT
  group: ME01R_CG_001_Azure
paprocess:
  url:
    enable: true
storeprocess:  
  url:
    enable: true
application:
  user:
    id: me0001r
```
Maven Build: Right click on project -> Run As -> Maven Build -> Goals : clean install -> Run.
Run Application: Right click on project -> Run As -> Spring Boot App.

Test URL for Price Area : http://localhost:8080/me01r/baseprice/paprocess
 Method : POST
  ```
{
  "priceChangeHeader": {
    "requestId": "2022021000084",
    "recordCount": "1",
    "suggLevel": "PA"
  },
  "priceList": [
    {
      "recordCount": 1,
      "crcId": 0,
      "corpItemCd": "86080603",
      "unitType": 1,
      "rogCd": "SNCA",
      "retailSection": "338",
      "paStoreInfo": "53",
      "suggLevel": "PA",
      "suggPrice": "11ABC73",
      "scenarioId": "1",
      "scenarioName": "MSG1",
      "lastUpdUserId": "mjosh10",
      "lastUpdUserTs": "2022-02-09 19:20:3",
      "effectiveStartDt": "2022-03-04",
      "effectiveEndDt": "2022-04-05",
      "scenarioFlg": "C",
      "projectedSales": 9,
      "projectedMargin": 53,
      "projectedUnits": 15.5,
      "priceFactor": 23,
      "priceOverrideReason": 2,
      "hasStoreSplit": true
    }
  ]
}
```

Test URL for Store-Price Area : http://localhost:8080/me01r/baseprice/storeprocess
Method : POST
```
{
  "priceChangeHeader": {
    "requestId": "2022020900018",
    "recordCount": "1",
    "suggLevel": "Store"
  },
  "priceList": [
    {
      "recordCount": 1,
      "crcId": 0,
      "corpItemCd": "86080603",
      "unitType": 1,
      "rogCd": "SNCA",
      "retailSection": "331",
      "paStoreInfo": "0309",
      "suggLevel": "Store",
      "suggPrice": "14.79",
      "scenarioId": "1",
      "scenarioName": "MSG1",
      "lastUpdUserId": "Vball19",
      "lastUpdUserTs": "2022-02-09 18:20:30",
      "effectiveStartDt": "2022-05-10",
      "effectiveEndDt": "2022-06-15",
      "scenarioFlg": "C",
      "projectedSales": 0,
      "projectedMargin": 0,
      "projectedUnits": 15.5,
      "priceFactor": 1,
      "priceOverrideReason": 2
    }
  ]
}
  ```

